/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:    M3UA Layer (M3UA)

     Type:    C source file

     Desc:    Code for M3UA protocol related functions:
                  Timer controller
                  Upper interface support
                  MTP3 message parser and router
                  Management Interworking
                  M3UA message handler

     File:    it_bdy2.c

     Sid:      it_bdy2.c@@/main/7 - Thu Apr  1 03:51:22 2004

     Prg:     mrw

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_ss7.h"        /* common SS7 */
#include "cm_tpt.h"        /* common transport defines */
#include "lit.h"           /* layer management M3UA  */
#include "sct.h"           /* SCT interface */
#include "snt.h"           /* SNT interface */
#include "it_err.h"        /* M3UA error */
#ifdef IT_FTHA
#include "sht.h"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "it.h"            /* M3UA internal defines */
#ifdef DI
#include "dit.h"
#endif /* DI */
#ifdef ZV
#include "cm_ftha.h"
#include "cm_psfft.h"          /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.h"
#include "cmzvdvlb.h"
#endif /* ZV_DFTHA */
#include "mrs.h"
#include "lzv.h"
#include "zv.h"            /* m3ua  PSF */
#endif /* ZV */
/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_ss7.x"        /* common SS7 */
#include "cm_tpt.x"        /* common transport */
#include "sct.x"           /* SCT interface */
#ifdef IT_FTHA
#include "sht.x"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "lit.x"           /* layer management M3UA */
#include "snt.x"           /* SNT interface */
#include "it.x"            /* M3UA internal typedefs */
#ifdef DI
#include "dit.x"
#endif /* DI */
#ifdef ZV
#include "cm_ftha.x"
#include "cm_psfft.x"
#ifdef ZV_DFTHA
#include "cmzvdv.x"
#include "cmzvdvlb.x"
#endif
#include "mrs.x"
#include "lzv.x"
#include "zv.x"            /* m3ua PSF */
#endif /* ZV */

#include "it_star.h"

/* function prototypes */

PRIVATE S16 itMmhPkString ARGS((Buffer **mBuf, Txt *str, U16 tag));
PRIVATE S16 itMmhExamString ARGS((Buffer **mBuf, Txt *str, U16 len,
                                  U16 *idx));

/* functions */

/**********************************************************************
 *                         TIMER CONTROLLER
 **********************************************************************/

/*
*
*       Fun:   Activate Task - timer
*
*       Desc:  Invoked by system services every timer tick. Uses common
*              timer library to invoke any timeouts that have been
*              reached.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef SS_MULTIPLE_PROCS
#ifdef ANSI
PUBLIC S16 itActvTmr
(
ProcId   proc,                /* Proc Id */
Ent      entity,              /* entity */
Inst     inst                /* instance */
)
#else
PUBLIC S16 itActvTmr(proc, entity, inst)
ProcId   proc;                /* Proc Id */
Ent      entity;              /* entity */
Inst     inst;                /* instance */
#endif /* ANSI */ 
#else  /* SS_MULTIPLE_PROCS */
#ifdef ANSI
PUBLIC S16 itActvTmr
(
void
)
#else
PUBLIC S16 itActvTmr()
#endif /* ANSI */ 
#endif /* SS_MULTIPLE_PROCS */ 
{
   TRC3(itActvTmr)
#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(proc, entity, inst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EIT005,0,
	       "itActvTmr() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_SI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       proc, entity , inst));
#endif /* SS_MULTIPLE_PROCS */



   if (!itGlobalCb.timerFreezeFlg)
   cmPrcTmr(&itGlobalCb.itTqCp, itGlobalCb.itTq, itTcTmrEvnt);

   RETVALUE (ROK);
} /* end of itActvTmr */


/*
*
*       Fun:   itTcInit
*
*       Desc:  Called by LMI to initialize the TC.  Sets up the global
*              timer table. Registers the layer timer task.
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itTcInit
(
void
)
#else
PUBLIC S16 itTcInit()
#endif
{
   U16   i;                   /* loop index */

   TRC2(itTcInit)

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
            "itTcInit()\n"));

   itGlobalCb.itTqCp.nxtEnt = (U16) 0;
   itGlobalCb.itTqCp.tmrLen = (U16) IT_TQSIZE;

   for (i = 0; i < IT_TQSIZE; i++)
   {
      itGlobalCb.itTq[i].first   = (CmTimer *)NULLP;
      itGlobalCb.itTq[i].tail    = (CmTimer *)NULLP;
   }
#ifdef SS_MULTIPLE_PROCS
   if (SRegTmr(itGlobalCb.itInit.procId,
	itGlobalCb.itInit.ent, itGlobalCb.itInit.inst,
      itGlobalCb.genCfg.timeRes, itActvTmr)
      != ROK)
#else
   if (SRegTmr(itGlobalCb.itInit.ent, itGlobalCb.itInit.inst,
      itGlobalCb.genCfg.timeRes, itActvTmr)
      != ROK)
#endif /* SS_MULTIPLE_PROCS */
   {
      RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /* end of itTcInit */


/*
*
*       Fun:   itTcTmrEvnt
*
*       Desc:  Called by common timer utilities on expiry of a timer.
*              Switches on the event and dispatches control to the
*              appropriate timeout handling function, passing the
*              control block pointer.
*
*       Ret:   Failure:
*
*              Success:
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC Void itTcTmrEvnt
(
PTR   cb,                     /* context control block */
S16   event                   /* timer event */
)
#else
PUBLIC Void itTcTmrEvnt(cb, event)
PTR   cb;                     /* context control block */
S16   event;                  /* timer event */
#endif
{
   S16         ret;           /* return code */
   TRC2(itTcTmrEvnt)

   ITADDZVUPDPEERCTR()
   ret = ROK;
#if (ERRCLASS & ERRCLS_DEBUG)
#ifdef ZV
   if (!((zvCb.genCfg.distEnv) && (event == IT_TMR_LSCSLS_SEQ)))
   {
      ITCHKPROTSTATE(EIT167, STITGEN, NULLD, ret, IT_EVENT_CRIT);
      if (ret != ROK)
      {
         ITZVUPDPEER();
         RETVOID;
      }
   }
#endif

   if (cb == (PTR)NULLP)
   {
      ITLOGERROR(ERRCLS_DEBUG, EIT168, (ErrVal) event,
                "itTcTmrEvnt(): invalid control block");
      ITZVUPDPEER();
      RETVOID;
   }
#endif /* ERRRCLS_DEBUG */
   switch (event)
   {
#if ( defined (ITSG) && defined (SNTIWF) )
      case IT_TMR_STA_POLL:
         itMifStaTimeout((ItDpcCb *)cb);
         break;
#ifndef SNT_BACK_COMP_MERGED_NIF
      case IT_TMR_MTP3_SAP_BND:
         itLiBndMtp3TmrExp((ItNSapCb *)cb);
         break;
#endif /* SNT_BACK_COMP_MERGED_NIF */
#endif
#ifdef ITASP
      case IT_TMR_DAUD:
         itMifDaudTimeout((ItDpcCb *)cb);
         break;
#endif
      case IT_TMR_NWK_RST:
         itMifNwkRstTimeout((ItNwkCb *)cb);
         break;
      case IT_TMR_CONGPOLL:
         itCcDeadlockTimeout((ItAssocCb *)cb);
         break;
      case IT_TMR_HBEAT_RX:
         itPsmHBeatTimeout((ItAssocCb *)cb);
         break;
      case IT_TMR_HBEAT_TX:
         itPsmTxHBeatTimeout((ItAssocCb *)cb);
         break;
#ifdef  ITASP
      case IT_TMR_ASPM:
         itPsmAspTimeout((ItAssocCb *)cb);
         break;
#endif /* ITASP */
      case IT_TMR_AS_PENDING:
         itPsmPsPendTimeout((ItPsCb *)cb);
         break;
      case IT_TMR_SCT_BND:
         itLiBndTmrExp((ItSctSapCb *)cb);
         break;
      case IT_TMR_LSC_CTX:
         itLscCtxTmrExp((ItLscCtxHdr *)cb);
         break;
      case IT_TMR_SCT_ENDPOPEN:
         itLiEndpTmrExp((ItSctSapCb *)cb);
         break;
      case IT_TMR_ASSOC_REQ:
         itAcPrimTimeout((ItAssocCb *)cb);
         break;
      case IT_TMR_DUNA_SETTLE:
         break; /* do nothing */
#ifdef ITASP
      case IT_TMR_RKM:
         itAtRkmTimeout((ItRegReqTmrCb *)cb);
         break; 
#endif /* ITASP */
      case IT_TMR_LSCSLS_SEQ:
         itLscSlsSeqTmrExp((ItLscSlsSeq *)cb);
         break; 
/*chenning startwork*/
#ifdef ITASP
        case IT_SG_TMR_RECONNECT:
            itAspReconnectTimeout((ItPspCb *)cb);
        break;
#endif
      default:
         break;
   }

   ITZVUPDPEER();
   RETVOID;
} /* end of itTcTmrEvnt */


/*
*
*       Fun:    itTcStartTimer - start a timer
*
*       Desc:   Start the timer with the specified parameters
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC Void itTcStartTimer
(
CmTimer  *tmr,                /* Timer control block */
PTR      cb,                  /* Parent control block */
S16      event,               /* Event tag */
TmrCfg   *wait                /* Timeout wait */
)
#else
PUBLIC Void itTcStartTimer(tmr, cb, event, wait)
CmTimer  *tmr;                /* Timer control block */
PTR      cb;                  /* Parent control block */
S16      event;               /* Event tag */
TmrCfg   *wait;               /* Timeout wait */
#endif /* ANSI */
{
   CmTmrArg arg;              /* timer argument */

   TRC3(itTcStartTimer)

   if (wait->enb == TRUE)
   {
      if (wait->val != 0)
      {
         if (tmr->tmrEvnt != TMR_NONE)
         {
            /* Timer is currently in use - reset */
            (Void) itTcStopTimer(tmr);
         }
         arg.tq      = itGlobalCb.itTq;
         arg.tqCp    = &itGlobalCb.itTqCp;
         arg.timers  = tmr;
         arg.cb      = cb;
         arg.evnt    = event;
         arg.wait    = wait->val;
         arg.tNum    = NOTUSED;
         arg.max     = 1;
         cmPlcCbTq(&arg);
      }
      else
      {
         /* Zero wait - trigger event instantaneously */
         itTcTmrEvnt(cb, event);
      }
   }

   RETVOID;
} /* end of itTcStartTimer() */


/*
*
*       Fun:    itTcStopTimer - stop a timer
*
*       Desc:   Stop the timer
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC Void itTcStopTimer
(
CmTimer *tmr                  /* Timer control block */
)
#else
PUBLIC Void itTcStopTimer(tmr)
CmTimer *tmr;                 /* Timer control block */
#endif /* ANSI */
{
   CmTmrArg arg;              /* timer argument */

   TRC3(itTcStopTimer)

   if (tmr->tmrEvnt != TMR_NONE)
   {
      arg.tq      = itGlobalCb.itTq;
      arg.tqCp    = &itGlobalCb.itTqCp;
      arg.timers  = tmr;
      arg.cb      = (PTR)NULLP;
      arg.evnt    = NOTUSED;
      arg.wait    = NOTUSED;
      arg.tNum    = 0;
      arg.max     = 1;
      cmRmvCbTq(&arg);
   }
   RETVOID;
} /* end of itTcStopTimer() */

/*************************** END OF TIMER CONTROLLER ***********/

/**********************************************************************
 *               UPPER INTERFACE SUPPORT FUNCTIONS
 **********************************************************************/

/*
*
*       Fun:   Configure upper SAP
*
*       Desc:  This function creates and intializes an upper SAP
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*              ROUTRES - failed, out of resources
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itUiCfgSap
(
ItNSapCfg   *cfg,             /* configuration information */
CmStatus    *sta              /* return status */
)
#else
PUBLIC S16 itUiCfgSap(cfg, sta)
ItNSapCfg   *cfg;             /* configuration information */
CmStatus    *sta;             /* return status */
#endif
{
   ItNSapCb *cb;              /* upper SAP CB */

   TRC2(itUiCfgSap)

   if (itUiVerifyNSapCfg(cfg, sta) != ROK)
   {
      RETVALUE(RFAILED);
   }

   /* allocate and zero the Upper SAP CB */
   if ((cb = itGlobalCb.nSap[cfg->sapId]) == (ItNSapCb *)NULLP)
   {
      IT_ALLOC(sizeof(ItNSapCb), cb)
      if (cb == (ItNSapCb *)NULLP)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_MEM_NOAVAIL;
         RETVALUE(ROUTRES);
      }
      itGlobalCb.nSap[cfg->sapId] = cb;
#ifdef IT_RUG
      cb->remIntfValid = FALSE;
      if (cfg->remIntfValid == TRUE)
      {
         cb->remIntfValid = TRUE;
         cb->pst.intfVer = cfg->remIntfVer;
         cb->verContEnt = ENTSM;
      }
      else
      {
         cb->verContEnt = ENTNC;
      }
#endif /* IT_RUG */
   }
   else
   {
      if (cfg->nwkId != cb->sntCfg.nwkId)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_RECONFIG_FAIL;
         RETVALUE(RFAILED);
      }
      if (cb->sntCfg.suType != cfg->suType)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_RECONFIG_FAIL;
         RETVALUE(RFAILED);
      }
#ifdef IT_RUG
      cb->remIntfValid = FALSE;

      if (cfg->remIntfValid == TRUE)
      {
         cb->remIntfValid = TRUE;
         cb->pst.intfVer = cfg->remIntfVer;
         cb->verContEnt = ENTSM;
      }
      else
      {
         cb->verContEnt = ENTNC;
      }
#endif /* IT_RUG */
   }
#ifdef ITSG
#ifdef IT_FTHA
   /* Initialize the Controlling Entity */
    cb->contEnt = ENTNC;
#endif
#endif

   /* initialize SAP post structure */
   cb->pst.selector  = cfg->selector;
   cb->pst.region    = cfg->mem.region;
   cb->pst.pool      = cfg->mem.pool;
   cb->pst.prior     = cfg->prior;
   cb->pst.route     = cfg->route;
   /* for M3UA user saps: dstProcId, dstEnt, and dstInst are assigned during 
      bind request, for MTP3 sap it is configured by LM */
#ifdef ITSG
#ifdef SNTIWF
   if (cfg->suType == LIT_SP_MTP3)
   {
      cb->pst.dstProcId = cfg->procId;
      cb->pst.dstEnt    = cfg->ent;
      cb->pst.dstInst   = cfg->inst;
   }
   else
#endif /* ITSG */
#endif /* SNTIWF */
   {
      cb->pst.dstProcId = PROCIDNC;
      cb->pst.dstEnt    = ENTNC;
      cb->pst.dstInst   = INSTNC;
   }
   cb->pst.srcProcId = itGlobalCb.itInit.procId;
   cb->pst.srcEnt    = itGlobalCb.itInit.ent;
   cb->pst.srcInst   = itGlobalCb.itInit.inst;
   cb->pst.event     = EVTNONE;
   /* copy configuration */
   cmMemcpy((U8 *) &cb->sntCfg, (U8 *) cfg, sizeof(ItNSapCfg));
   /* link to parent network CB */
   cb->nwk = itGlobalCb.nwk[cfg->nwkId];
   /* initialize status */
   cb->sntSta.remSapId = 0;
   cb->sntSta.lclSapId = cfg->sapId;
   cb->sntSta.hlSt = LIT_SAP_UNBOUND;
   cb->sntSts.spId = cfg->sapId;
   SGetDateTime(&(cb->sntSts.dt));
#ifdef ITSG
   if (cfg->suType == LIT_SP_MTP3)
   {
      cb->nwk->mtp3NSap = cb;
      cb->sntSta.remSapId = cfg->mtp3SapId;
   }
#endif /* ITSG */

#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   cb->lpsId = IT_INVALID_PS_ID;
#endif

   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   RETVALUE(ROK);
} /* end of itUiCfgSap */


/*
*
*       Fun:   itUiVerifyNSapCfg
*
*       Desc:  This function checks the validity of the NSapCfg struct
*              passed to itUiCfgsap
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itUiVerifyNSapCfg
(
ItNSapCfg   *cfg,             /* configuration information */
CmStatus    *sta              /* return status */
)
#else
PUBLIC S16 itUiVerifyNSapCfg(cfg, sta)
ItNSapCfg   *cfg;             /* configuration information */
CmStatus    *sta;             /* return status */
#endif
{
   TRC2(itUiVerifyNSapCfg);

   /* check that the nwkCb has been configured */
   if (cfg->nwkId >= itGlobalCb.genCfg.maxNmbNwk)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT169,
                 (ErrVal) cfg->nwkId,
                 "itUiVerifyNSapCfg: invalid nwkId");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_INVALID_NWKID;
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.nwk[cfg->nwkId] == (ItNwkCb *) NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT170,
                 (ErrVal) cfg->nwkId,
                 "itUiVerifyNSapCfg: network unconfigured");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_INVALID_NWKID;
      RETVALUE(RFAILED);
   } /* end check for nwkId */

   if (cfg->suType > 0x0f)
   {                 
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT171,
                       (ErrVal) cfg->suType,
                             "itUiVerifyNSapCfg: invalid suType");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }
#ifdef ITSG
#ifdef SNTIWF
      /* 1st config: nwk->mtp3NSap and nSap[spId] are both NULLP */
   if (cfg->suType == LIT_SP_MTP3)
   {
      if (itGlobalCb.nwk[cfg->nwkId]->mtp3NSap != itGlobalCb.nSap[cfg->sapId])
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT172, (ErrVal) cfg->nwkId,
                    "itUiVerifyNSapCfg: network already has a MTP3-SAP");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
      }
   }
#endif /* SNTIWF */
#endif /* ITSG */

   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   RETVALUE(ROK);
} /* end of itUiVerifyNSapCfg */


/*
*
*       Fun:   Delete upper SAP
*
*       Desc:  This function deletes an upper SAP
*
*       Ret:   ROK - ok
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itUiDelSap
(
ItNSapCb *nSap,               /* SAP CB */
CmStatus *sta,                /* return status */
Bool     itabort              /* layer shutdown? */
)
#else
PUBLIC S16 itUiDelSap(nSap, sta, itabort)
ItNSapCb *nSap;               /* SAP CB */
CmStatus *sta;                /* return status */
Bool     itabort;             /* layer shutdown? */
#endif
{
   ItDpcCb     *prevEnt;      /* previous DPC CB */
   ItDpcCb     *entry;        /* current DPC CB */
   ItRouteCb   *curRouteCb;   /* current route CB */

   TRC2(itUiDelSap)

   if (nSap == (ItNSapCb *)NULLP)
   {
      sta->reason = LCM_REASON_NOT_APPL;
      sta->status = LCM_PRIM_OK;
      RETVALUE(ROK);
   }

   prevEnt = (ItDpcCb *)NULLP;

   if (itabort == FALSE)
   {
      /* Check for dependent routes */
      while (cmHashListGetNext(&itGlobalCb.addrTrn.dpcList,
                               (PTR) prevEnt, (PTR *) &entry) ==  ROK)
      {
         if (entry->nSap == nSap)
         {
            /* return failed */
            ITLOGERROR(ERRCLS_INT_PAR, EIT173, (ErrVal) entry->dpc,
                       "itUiDelSap(): SAP in use by route entry");
            sta->reason = LIT_REASON_SERVICE_IN_USE;
            sta->status = LCM_PRIM_NOK;
            RETVALUE(RFAILED);
         }
         for (curRouteCb = (ItRouteCb *)cmLListFirst(&entry->routes);
              curRouteCb;
              curRouteCb = (ItRouteCb *)cmLListNext(&entry->routes))
         {
            if ((curRouteCb->rteCfg.nSapIdPres == TRUE) &&
                (curRouteCb->rteCfg.nSapId == nSap->sntCfg.sapId))
            {
               /* return failed */
               ITLOGERROR(ERRCLS_INT_PAR, EIT174, (ErrVal) 0,
                          "itUiDelSap(): SAP in use by route entry");
               sta->reason = LIT_REASON_SERVICE_IN_USE;
               sta->status = LCM_PRIM_NOK;
               RETVALUE(RFAILED);
            }
         }
         prevEnt = entry;
      } /* end while */

      /* search all global routes for nwkId match */
      for (curRouteCb = (ItRouteCb *)cmLListFirst(&itGlobalCb.addrTrn.rtList);
           curRouteCb;
           curRouteCb = (ItRouteCb *)cmLListNext(&itGlobalCb.addrTrn.rtList))
      {
         if ((curRouteCb->rteCfg.nSapIdPres == TRUE) &&
             (curRouteCb->rteCfg.nSapId == nSap->sntCfg.sapId))
         {
            /* return failed */
            ITLOGERROR(ERRCLS_INT_PAR, EIT175, (ErrVal) 0,
                       "itUiDelSap(): SAP in use by route entry");
            sta->reason = LIT_REASON_SERVICE_IN_USE;
            sta->status = LCM_PRIM_NOK;
            RETVALUE(RFAILED);
         }
      }

      /* If bound, first unbind */
      if (nSap->sntSta.hlSt == LIT_SAP_BOUND)
      {
         itUiUBndSap(nSap, sta);
      }
   }

#ifdef ITSG
   itTcStopTimer(&nSap->tmrPrim);
#endif
#ifdef ZV
    /* SYNC update needs to be done before confirm can be sent to LM  */

    zvRTUpd(CMPFTHA_ACTN_DEL, ZV_NSAPCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) nSap, NULLP);
#endif
   itGlobalCb.nSap[nSap->sntCfg.sapId] = (ItNSapCb *)NULLP;
   IT_FREE(sizeof(ItNSapCb), nSap)

   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;

   RETVALUE(ROK);
} /* end of itUiDelSap */


/*
*
*       Fun:   Unbind upper SAP
*
*       Desc:  This function unbinds an upper SAP
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itUiUBndSap
(
ItNSapCb *nSap,               /* SAP CB */
CmStatus *sta                 /* return status */
)
#else
PUBLIC S16 itUiUBndSap(nSap, sta)
ItNSapCb *nSap;               /* SAP CB */
CmStatus *sta;                /* return status */
#endif
{
   TRC2(itUiUBndSap)

#ifdef DI
   if(nSap->sntCfg.suType == SI_ISUP)
   {
      U8     nmbInsts;               /* No. of ISUP inst. on SAP */
      U8     i;                      /* Loop variable  */
      Inst   instList[DIT_MAX_INSTS]; /* List of ISUP inst on SAP */

      nmbInsts = 0;
      nSap->sntSta.hlSt =  LIT_SAP_UNBOUND;

      DiDitGetUpInstList(nSap->sntCfg.sapId, &nmbInsts, &instList[0]);

      /* Mark all instances on SAP as unbound   */
      for (i = 0; i < nmbInsts; i++)
      {
         DiDitSetUpSapState(DIT_BNDSTA, PROCIDNC, instList[i],
                         nSap->sntCfg.sapId, DIT_UNBND);
#ifdef ZV
        /* Set up SAP control block for RT update; one for each *
                   * instance on the SAP  */
         nSap->pst.dstInst = instList[i];
         zvRTUpd(CMPFTHA_ACTN_MOD, ZV_NSAPCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) nSap, NULLP);
#endif
         /* One RT update is generated for every instance on SAP */
         ITZVUPDPEER()
         /* A run time update has been generated; increment ctr  */
         ITADDZVUPDPEERCTR()

      } /* for i < nmbInsts */
      RETVALUE(ROK);
   } /* if ISUP */
#endif /* DI */

#ifdef IT_RUG
   if (nSap->verContEnt == ENTNC)
      nSap->remIntfValid = FALSE;
#endif  /* IT_RUG */
   if (nSap->sntSta.hlSt == LIT_SAP_BOUND)
   {
      /* update state */
      nSap->sntSta.hlSt = LIT_SAP_UNBOUND;
      (Void) itMifUserEvt(IT_MIF_USER_DOWN, nSap);
   }
   else
   {
      (Void) itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                        LCM_CAUSE_INV_STATE, (U32) nSap->sntCfg.sapId);
   }
 
   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;

   RETVALUE(ROK);
} /* end of itUiUBndSap */


/*
*
*       Fun:   Data indication
*
*       Desc:  This function sends data to the user
*
*       Ret:   ROK  - ok
*              RNA  - user not available (restart in progress)
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itUiUDatInd
(
ItNSapCb *nSap,               /* SAP CB */
Buffer   **mBuf,              /* message buffer */
Dpc      opc,                 /* opc */
Dpc      dpc,                 /* dpc */
SrvInfo  sio,                 /* service indicator octet*/
LnkSel   sls                  /* link selection */
)
#else
PUBLIC S16 itUiUDatInd(nSap, mBuf, opc, dpc, sio, sls)
ItNSapCb *nSap;               /* SAP CB */
Buffer   **mBuf;              /* message buffer */
Dpc      opc;                 /* opc */
Dpc      dpc;                 /* dpc */
SrvInfo  sio;                 /* service indicator octet*/
LnkSel   sls;                 /* link selection */
#endif
{
   TRC2(itUiUDatInd)

   if (nSap->nwk->restart == TRUE)
   {
      RETVALUE(RNA);
   }

   if (nSap->sntSta.hlSt != LIT_SAP_BOUND)
   {
      RETVALUE(RNA);
   }
   if (mBuf == (Buffer **)NULLP) 
   {
      RETVALUE(RFAILED);
   }

   IT_STS_INC_MTP3_TX(nSap, data);
   IT_STS_INC_DATA_TX_SNT(nSap, *mBuf);
    /*chenning add for msg trace*/
    ITDBGP(IT_DBGMASK_MSGTRACE, (itGlobalCb.itInit.prntBuf, 
    "\r\n[MSG Trace] M3UA>>>>M3UA UA (NSAP ID(%x), Type(%x), DPC(%x), OPC(%x), SrvInfo(%x), LnkSel(%x))\r\n\r\n", 
     nSap->sntCfg.sapId, nSap->sntCfg.suType, dpc, opc, (U8)(0x0F & sio), sls));
    
   {
      /* This check should be removed as the Priority is not
         getting passed to the user. This check has been removed to 
         resolve the problem of Priority of the message not getting
         passed to the NIF and intern to the SS7 network */
#ifdef SNT_BACK_COMP_MERGED_NIF
      (Void) ItUiSntUDatInd(&nSap->pst, nSap->sntSta.remSapId, opc, dpc, 
                         sio, sls, *mBuf);
#else
#ifdef ITSG
      /* If Data request is towards MTP3 */
      if (nSap->sntCfg.suType == LIT_SP_MTP3)
      {
         (Void) ItLiSntUDatReq(&nSap->pst, nSap->sntCfg.mtp3SapId, opc, dpc, 
                         sio, sls, (U8)IT_SIOPRI(sio), *mBuf);
      }
      else
#endif
      {
         (Void) ItUiSntUDatInd(&nSap->pst, nSap->sntSta.remSapId, opc, dpc, 
                         sio, sls, *mBuf);
      }
#endif /* SNT_BACK_COMP_MERGED_NIF */
   }

   RETVALUE(ROK);
} /* end of itUiUDatInd */


/*
*
*       Fun:   Get NSAP
*
*       Desc:  This function selects the correct upper SAP according
*              to the information provided in the parameters
*
*       Ret:   ROK   - ok
*              RNA   - not available
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itUiGetNSap
(
U8       nwkId,               /* Network ID */
SrvInfo  srvInfo,             /* service indicator octet */
Bool     nifFlag,             /* Nodal Interworking Function flag */
ItNSapCb **nSap               /* SAP CB */
)
#else
PUBLIC S16 itUiGetNSap(nwkId, srvInfo, nifFlag, nSap)
U8       nwkId;               /* Network ID */
SrvInfo  srvInfo;             /* service indicator octet */
Bool     nifFlag;             /* Nodal Interworking Function flag */
ItNSapCb **nSap;              /* SAP CB */
#endif
{
   SpId     spId;             /* service provider ID */
   ItNSapCb *cb;              /* upper SAP CB */
   ItNwkCb  *nwkCb;           /* network CB */

   TRC2(itUiGetNSap)

   *nSap = (ItNSapCb *)NULLP;

#ifdef ITSG
   if (nifFlag == TRUE)
   {
      /* No need to search - we have a shortcut to the NIF SAP */
      if ((nwkCb = itGlobalCb.nwk[nwkId]) != (ItNwkCb *)NULLP)
      {
         if ((cb = nwkCb->mtp3NSap) != (ItNSapCb *)NULLP)
         {
            if (cb->sntSta.hlSt == LIT_SAP_BOUND)
            {
               *nSap = cb;
               RETVALUE(ROK);
            }
         }
      }
      RETVALUE(RNA);
   }
#else
   nwkCb = (ItNwkCb *)NULLP;
   UNUSED(nifFlag);
   UNUSED(nwkCb);
#endif

   for (spId = 0; spId < itGlobalCb.genCfg.maxNmbNSap; spId++)
   {
      cb = itGlobalCb.nSap[spId];
      if (cb != (ItNSapCb *)NULLP)
      {
         if (cb->sntCfg.nwkId == nwkId)
         {
            if (cb->sntCfg.suType == IT_SRVIND(srvInfo))
            {
               if (cb->sntSta.hlSt == LIT_SAP_BOUND)
               {
                  *nSap = cb;
                  RETVALUE(ROK);
               }
            }
         }
      }
   }

   RETVALUE(RNA);
} /* end of itUiGetNSap */

/**********************************************************************
 *                       MTP3-USER MESSAGE PARSER
 **********************************************************************/

/*
*
*       Fun:   itMupEncHdr
*
*       Desc:  This function encodes the MTP3 header and prepends to message
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*              ROUTRES - out of resources
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMupEncHdr
(
ItMupMsg *msg                 /* MUP message */
)
#else
PUBLIC S16 itMupEncHdr(msg)
ItMupMsg *msg;                /* MUP message */
#endif
{
   S16    ret;              /* return value */

   U8    sls;               /* Signaling Link Selection */
   U8    msgPrior;          /* Message Priority */
   U8    nwkInd;            /* Network Indicator */
   U8    srvInfo;           /* Service Info Octet */
   U8    dpcLen;            /* DPC Length */
   U8               pkArray[16];    /* Msg Packing array : size 16 is enough */
   U16              pkCtr;          /* Pking array length */

   TRC2(itMupEncHdr)
   IT_ZERO(&pkArray[0], 16);
   pkCtr = 0;           
   sls = msg->lnkSel;
   msgPrior = (U8)((msg->srvInfo >> 4) & 0x03);
   nwkInd = (U8)(msg->srvInfo >> 6);
   srvInfo = (U8)(msg->srvInfo & 0x0f);
   
   dpcLen = itGlobalCb.nwk[msg->nwkId]->nwkCfg.dpcLen;
   IT_MMH_PREPK_U8(sls) 
   IT_MMH_PREPK_U8(msgPrior) 
   IT_MMH_PREPK_U8(nwkInd) 
   IT_MMH_PREPK_U8(srvInfo) 
   IT_MMH_PREPK_DPC(msg->dpc, dpcLen)
   IT_MMH_PREPK_DPC(msg->opc, dpcLen)
   /* Add the pkArray to msg->mBuf */
   /* M3UA_PERF changes */
   /* Add all the pkArray bytes to msg->mBuf */
   if (pkCtr != 0)
   {
      if ((ret = SAddPreMsgMult((Data *)&pkArray[0], pkCtr, msg->mBuf)) != ROK)
      {
         RETVALUE(ret);
      }
   }
   msg->hdrState = IT_MSGHDR_PRESEX;

   RETVALUE(ROK);
} /* end of itMupEncHdr */


/*
*
*       Fun:   itMupDecHdr
*
*       Desc:  This function decodes the MTP3 header and optionally removes
*              from message
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*              ROUTRES - out of resources
*              RNA     - failed, not available
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMupDecHdr
(
ItMupMsg *msg,                /* MUP message */
Bool     strip                /* strip header if TRUE */
)
#else
PUBLIC S16 itMupDecHdr(msg, strip)
ItMupMsg *msg;                /* MUP message */
Bool     strip;               /* strip header if TRUE */
#endif
{

   U8       m3uaHdr[IT_M3UA_DATA_HDR_SIZE]; /* MTP3 header data */
   U8       cur;              /* current position */
   U8       tmp8;             /* For temporary storage */
   U16      tmp16;             /* For temporary storage */ 
   Dpc      opc;              /* Originating Point Code */
   Dpc      dpc;              /* Destiantion Point Code */
   S16      ret;              /* return value */

   TRC2(itMupDecHdr)

   UNUSED(strip);

   if ((ret = SRemPreMsgMult((Data *)m3uaHdr,
       (MsgLen) IT_M3UA_DATA_HDR_SIZE, msg->mBuf)) != ROK) 
   { 
      RETVALUE(ret);
   }
   
   cur = 0;
   tmp8 = 0;
   tmp16 = 0;

   tmp16 = m3uaHdr[cur++];
   opc = ((tmp16 << 8) | (m3uaHdr[cur++]));
   tmp16 = m3uaHdr[cur++];
   tmp16 = (U16)((tmp16 << 8) | (m3uaHdr[cur++]));
   opc = ((opc << 16) | tmp16);
   
   tmp16 = m3uaHdr[cur++];
   dpc = ((tmp16 << 8) | (m3uaHdr[cur++]));
   tmp16 = m3uaHdr[cur++];
   tmp16 = (U16)((tmp16 << 8) | (m3uaHdr[cur++]));
   dpc = ((dpc << 16) | tmp16);
   
   msg->opc = opc;
   msg->dpc = dpc;
   
   tmp8 = m3uaHdr[cur++];
   tmp8 = (U8)(tmp8 | (m3uaHdr[cur++] << 6));
   msg->srvInfo = (U8)(tmp8 | ((m3uaHdr[cur++] << 4) & 0x30));
   msg->lnkSel = m3uaHdr[cur];

   msg->hdrState = (U8)((strip == TRUE) ? IT_MSGHDR_NONE : IT_MSGHDR_PRESEX);

   RETVALUE(ROK);
} /* end of itMupDecHdr */


/*
*
*       Fun:   MUP Unit Data Request
*
*       Desc:  This function allocates a new MUPM for the Unit Data Request
*              from a local MTP3-User or the Nodal Interworking Function
*              and passes it to itMupData for routing
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*              ROUTRES - out of resources
*              RNA     - failed, not available
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMupUDatReq
(
ItNSapCb *nSap,               /* Network SAP CB */
Dpc      opc,                 /* Originator point code */
Dpc      dpc,                 /* Destination point code */
SrvInfo  srvInfo,             /* Service information octet */
LnkSel   lnkSel,              /* Link selector */
Priority prior,               /* Message priority */
Buffer   **mBuf               /* pointer to Message buffer */
)
#else
PUBLIC S16 itMupUDatReq(nSap, opc, dpc, srvInfo, lnkSel, prior, mBuf)
ItNSapCb *nSap;               /* Network SAP CB */
Dpc      opc;                 /* Originator point code */
Dpc      dpc;                 /* Destination point code */
SrvInfo  srvInfo;             /* Service information octet */
LnkSel   lnkSel;              /* Link selector */
Priority prior;               /* Message priority */
Buffer   **mBuf;              /* pointer to Message buffer */
#endif
{
   ItMupMsg *mupm;            /* MUP message */
   S16      ret;              /* return value */

   TRC2(itMupUDatReq)

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Entered itMupUDatReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif
   if (mBuf == (Buffer **)NULLP)
   {
      RETVALUE(RFAILED);
   }

   IT_STS_INC_MTP3_RX(nSap, data);
   IT_STS_INC_DATA_RX_SNT(nSap, *mBuf);
    /*chenning add for msg trace*/
    ITDBGP(IT_DBGMASK_MSGTRACE, (itGlobalCb.itInit.prntBuf, 
    "\r\n[MSG Trace] M3UA UA>>>>M3UA (NSAP ID(%x), Type(%x), DPC(%x), OPC(%x), SrvInfo(%x), LnkSel(%x))\r\n\r\n", 
     nSap->sntCfg.sapId, nSap->sntCfg.suType, dpc, opc, (U8)(0x0F & srvInfo), lnkSel));
    
   if (itGlobalCb.nmbMsg >= itGlobalCb.genCfg.maxNmbMsg)
   {
      itMiStaInd(STITGEN, LCM_CATEGORY_PROTOCOL, LIT_EVENT_MSG_FAIL, 
                 LCM_CAUSE_MEM_ALLOC_FAIL, NULLD);
      IT_DROPDATA(*mBuf);
      RETVALUE(ROUTRES);
   }

   IT_ALLOC(sizeof(ItMupMsg), mupm)
   if (mupm == (ItMupMsg *)NULLP)
   {
      IT_DROPDATA(*mBuf);
      RETVALUE(ROUTRES);
   }

   itGlobalCb.nmbMsg++;

   mupm->dir         = IT_MSG_DOWN;
   mupm->originator  = (PTR)nSap;
   mupm->nSap        = nSap;
   mupm->nwkId       = nSap->sntCfg.nwkId;
   mupm->dpc         = dpc;
   mupm->opc         = opc;
   mupm->srvInfo     = (U8)((srvInfo & 0xCF) | (prior << 4));
   mupm->lnkSel      = lnkSel;
   mupm->mBuf        = *mBuf;
   mupm->msgState    = IT_MSG_UNROUTED;
   mupm->hdrState    = IT_MSGHDR_NONE;
   
   if ((ret = itMupData(mupm)) != ROK)
   {
      IT_DROPDATA(mupm->mBuf);
      *mBuf = mupm->mBuf;
      IT_FREE(sizeof(ItMupMsg), mupm);
      itGlobalCb.nmbMsg--;
      RETVALUE(ret);
   }

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Leaving itMupUDatReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif   
   RETVALUE(ROK);
} /* end of itMupUDatReq */


/*
*
*       Fun:   MUP Data
*
*       Desc:  This function routes a message from an MTP3 User or from a peer
*              M3UA by calling the Address Translation, Upper Interface,
*              M3UA Message Handler, Signaling Gateway Controller,
*              Application Server Manager functional blocks as required
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*              ROUTRES - out of resources
*              RNA     - failed, not available
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMupData
(
ItMupMsg *msg                 /* MUP message */
)
#else
PUBLIC S16 itMupData(msg)
ItMupMsg *msg;                /* MUP message */
#endif
{
   S16       ret;             /* return value */
   
   TRC2(itMupData)
   
   /* Initialize ret to take case of warnings */
   ret = ROK;

   /* Check for network restart */
   if (itGlobalCb.nwk[msg->nwkId]->restart == TRUE)
   {
      /* Network restarting: route unavailable */
      IT_STS_INC_DATERR(msg, dropNoRoute)
      RETVALUE(RNA);
   }

   /* Add or extract header as required */
   switch (msg->hdrState)
   {
      case IT_MSGHDR_PRES:
         /* Decode header to extract routing label */
         if ((ret = itMupDecHdr(msg, TRUE)) != ROK)
         {
            RETVALUE(ret);
         } 
         /*chenning add for msg trace*/
         ITDBGP(IT_DBGMASK_MSGTRACE, (itGlobalCb.itInit.prntBuf, 
      "\r\n[MSG Trace] SCTP>>>>M3UA (DPC(%x), OPC(%x), SrvInfo(%x), LnkSel(%x))\r\n\r\n", 
      msg->dpc, msg->opc, (U8)(0x0F & msg->srvInfo), msg->lnkSel));
         break;
      default:                   
         break;
   }
   if (msg->msgState == IT_MSG_UNROUTED)
   {
      /*
      * Stage 1 routing: Call AT to obtain the PS CB
      * AT will call itMupGetUserInfo if required
      */
      if ((ret = itAtTranslate(msg)) != ROK)
      {
         if (itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP)
         {
            (Void) itMifDpcEvt(FALSE, (UConnId) NULLD, IT_MIF_DATAREQ, 
                               IT_MIF_PC_UPU, msg->nwkId,msg->dpc, 
                               msg->opc, 0x40, msg->srvInfo, (ItDpcCb *) NULLP);
         }
         else
         {
            itGlobalCb.mgmt.hdr.elmId.elmnt       = STITADRTRAN;
            itGlobalCb.mgmt.hdr.msgType           = TUSTA;
            itGlobalCb.mgmt.t.usta.alarm.category = LIT_CATEGORY_STATUS;
            itGlobalCb.mgmt.t.usta.alarm.event    = LIT_EVENT_NO_ROUTE_FOUND;
            itGlobalCb.mgmt.t.usta.alarm.cause    = LIT_CAUSE_MSG_RECEIVED;
            itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc   = msg->dpc;
            itGlobalCb.mgmt.t.usta.t.dpcEvt.p.servInd = 
                                                 (U8)(0x0F & msg->srvInfo);        
            /* call itMiStaIndM to add timestamp and call ItLitMiStaInd */
            (Void) itMiStaIndM(&itGlobalCb.mgmt);
         }
         IT_STS_INC_DATERR(msg, dropNoRoute)
         RETVALUE(ret);
      }
   }
   /* Check status of point code, if present */
   if (msg->dpcCb != (ItDpcCb *)NULLP)
   {
      /* Drop data, and exit if point code exists but is unavailable */
      if (msg->dpcCb->dpcSt == IT_DPC_UNAVAILABLE)
      {
#ifdef ZV_DFTHA
         ZvUpdSpecParams updSpec;
#endif
         /* Point code is unavailable */
         IT_STS_INC_DATERR(msg, dropPcUnavail)
/* DFTHA-hook */
#ifdef ZV_DFTHA
         /* Reverse update is required to send DUNA/PAUSE from Active copy */ 
         if ((itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP) &&
             (msg->dir == IT_MSG_UP) &&
             (itProtState != CMPFTHA_STATE_ACTIVE))
         {
            updSpec.p.revUpd.updType = ZV_REV_ACT_DUNA;
            updSpec.p.revUpd.assocId = 
                              ((ItAssocCb *)msg->originator)->assocId;
            updSpec.p.revUpd.r.duna.affPc = msg->dpcCb->dpc;
            updSpec.p.revUpd.r.duna.dpc   = msg->opc;
            updSpec.p.revUpd.r.duna.nwkId = msg->nwkId;
            zvPackNSendRevUpd(ZV_REV_ACT_DUNA, &updSpec);
            RETVALUE(RNA);
          }
          else
#endif
#ifdef ZV
#endif
         /* Indicate to users in the network that share this opc */
         if ((ret = itMifDpcEvt(FALSE, (UConnId) NULLD, IT_MIF_DATAREQ,
                                IT_MIF_PC_UNA, msg->nwkId,
                                msg->dpc, msg->opc, 0, msg->srvInfo,
                                msg->dpcCb)) != ROK)
         {
            RETVALUE(ret);
         }
         RETVALUE(RNA);
      }
       /* check congestion status of dpc only for national network. 
        * For International network route the message unconditionally 
        * Also, check for congestion level even if the dpc state is not 
        * congested as dpc can be both congested and restricted.*/
 
      if ((msg->dpcCb->congLevel > SN_PRI0) &&
                 (msg->msgState == IT_MSG_ROUTED_ONE))
      {
         if (IT_SIOPRI(msg->srvInfo) < msg->dpcCb->congLevel)
         {
            msg->msgState = IT_MSG_DISCARD;
            if ((ret = itMifDpcEvt(FALSE, (UConnId) NULLD, IT_MIF_DATAREQ, 
                                   IT_MIF_PC_CON, msg->nwkId,
                                   msg->dpc, msg->opc, msg->dpcCb->congLevel, 
                                   msg->srvInfo, msg->dpcCb)) != ROK)
            {
               RETVALUE(ret);
            }
         }
      }
   }
   if (msg->msgState == IT_MSG_ROUTED_ONE)
   {
      /*
       * Stage 2 routing: depends on the route type from stage 1:
       *  - if PS/PSP route, call itPsmGetPsp to select an PSP
       *  - if SS7 route or not found, call itUiGetNSap to select an NSAP
       */
      switch (msg->routeType)
      {
         /* Routing to a distributed PS */
         case LIT_RTTYPE_PS:
         {
            if ((msg->routeTgt1)->psCfg.lclFlag == TRUE)
            {
               Bool error;   /* Error occurred? */

               error = FALSE;
               if ((msg->routeTgt1)->psSta.asSt == LIT_AS_ACTIVE) 
               {
                  /* At ASP/IPSP, the Local PS route should also
                   * contain the NSAP Id. If present, route the message to
                   * this NSAP else search for a matching NSAP */
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
                  if ((itGlobalCb.genCfg.nodeType == LIT_TYPE_ASP) &&
                      (msg->nSap == NULLP))
                  {
#endif
                     /* Get NSAP */
                     if ((ret = itUiGetNSap(msg->nwkId, msg->srvInfo, 
                                     FALSE, &msg->nSap)) != ROK)
                     {
                        error = TRUE;
                     }
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
                  } /* if msg->nSap is NULLP */
#endif
                  /* Send data to Local nSap */
                  if ((error == FALSE) && 
                      (ret = itUiUDatInd(msg->nSap, 
                          &(msg->mBuf), msg->opc, msg->dpc, msg->srvInfo, 
                           msg->lnkSel)) != ROK)
                  {
                     error = TRUE;
                  }
               }
               else /* LPS is not ACTIVE */
               {
                  error = TRUE;
                  ret   = RFAILED;
               }
                 
               if (error == TRUE)
               {
                  itGlobalCb.mgmt.hdr.elmId.elmnt       = STITADRTRAN;
                  itGlobalCb.mgmt.hdr.msgType           = TUSTA;
                  itGlobalCb.mgmt.t.usta.alarm.category = LIT_CATEGORY_STATUS;
                  itGlobalCb.mgmt.t.usta.alarm.event    =
                                                      LIT_EVENT_NO_ROUTE_FOUND;
                  itGlobalCb.mgmt.t.usta.alarm.cause   = LIT_CAUSE_MSG_RECEIVED;
                  itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc   = msg->dpc;
                  itGlobalCb.mgmt.t.usta.t.dpcEvt.p.servInd = 
                                               (U8)(0x0F & msg->srvInfo);  
                  /* call itMiStaIndM to add timestamp and call ItLitMiStaInd */
                  (Void) itMiStaIndM(&itGlobalCb.mgmt);
                  IT_STS_INC_DATERR(msg, dropNoNSapAvail)
                  RETVALUE(ret);
               } /* End of error == TRUE */
               else /* Data delivered */
               {
                  /* it023.106 - Update Data Rx sts for Local PS */
#ifdef LITV6
                  IT_STS_INC_RX_PS(msg->routeTgt1, IT_M3UA_DATA)
#endif /* LITV6 */
                  /* Data sent successfully, drop MUPM (but not message) */
                  IT_FREE(sizeof(ItMupMsg), msg);
                  itGlobalCb.nmbMsg--;
                  RETVALUE(ROK);
               }
            } /* End of psCfg.lclFlag == TRUE */

            /* To filter out messages from SGP which are
             * destined to be sent back to SGP */
#ifdef ITASP
            /* If the message is destined to be dilevered to the local
             * user and the PS found is of remote user then dump the 
             * message and give a status indication to layer manager */
            else if((msg->dir == IT_MSG_UP) &&
                    (itGlobalCb.genCfg.nodeType != LIT_TYPE_SGP))
            {
               itGlobalCb.mgmt.hdr.elmId.elmnt       = STITADRTRAN;
               itGlobalCb.mgmt.hdr.msgType           = TUSTA;
               itGlobalCb.mgmt.t.usta.alarm.category = LIT_CATEGORY_STATUS;
               itGlobalCb.mgmt.t.usta.alarm.event    =
                                                   LIT_EVENT_NO_ROUTE_FOUND;
               itGlobalCb.mgmt.t.usta.alarm.cause   = LIT_CAUSE_MSG_RECEIVED;
               itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc   = msg->dpc;
               itGlobalCb.mgmt.t.usta.t.dpcEvt.p.servInd = 
                                            (U8)(0x0F & msg->srvInfo);  
               /* call itMiStaIndM to add timestamp and call ItLitMiStaInd */
               (Void) itMiStaIndM(&itGlobalCb.mgmt);
               IT_STS_INC_DATERR(msg, dropNoRoute)
               RETVALUE(RFAILED); 
            }
#endif
            /* Call PSM to select a Assoc */
            if ((ret = itPsmGetAssoc(msg)) != ROK)
            {
               RETVALUE(ret);
            }
            if (msg->msgState == IT_MSG_REJECTED)
            {
               /* PS is inactive, we've reached a dead end */
               (Void) itMifDpcEvt(FALSE, (UConnId) NULLD, IT_MIF_DATAREQ, 
                                  IT_MIF_PC_UPU, msg->nwkId,
                                  msg->dpc, msg->opc, 0x80, msg->srvInfo,
                                  (ItDpcCb *) NULLP);
               IT_STS_INC_DATERR(msg, dropNoPspAvail)
               RETVALUE(RNA);
            }
            else if (msg->msgState == IT_MSG_QUEUED_PSM)
            {
               /* Message was queued, can do no more with it */
               IT_STS_INC_DATERR(msg, dataQAsPend)
               RETVALUE(ROK);
            }
            break;
         }
         /* Routing to local SS7 point code - fall through */
         case LIT_RTTYPE_LOCAL:
         /* Routing to a remote SS7 point code via NIF */
         case LIT_RTTYPE_MTP3:
         {
            Bool nifFlag;     /* TRUE if NIF */

            nifFlag = (Bool)((msg->routeType == LIT_RTTYPE_MTP3) ? TRUE : FALSE);
            if (msg->nSap == (ItNSapCb *)NULLP)
            {
               /* Get NSAP */
               if ((ret =
                  itUiGetNSap(msg->nwkId, msg->srvInfo, nifFlag, &msg->nSap))
                  != ROK)
               {
                  (Void) itMifDpcEvt(FALSE, (UConnId) NULLD, IT_MIF_DATAREQ, 
                                     IT_MIF_PC_UPU, msg->nwkId,
                                     msg->dpc, msg->opc, 0x40, msg->srvInfo,
                                     (ItDpcCb *) NULLP);
                  IT_STS_INC_DATERR(msg, dropNoNSapAvail)
                  RETVALUE(ret);
               }
            }
            msg->msgState = IT_MSG_RDY_NSAP;
            break;
         }
         default:
            RETVALUE(RFAILED);
      }
      /* If message is still at stage 1 routing, need to use load-sharing */
      if (msg->msgState == IT_MSG_ROUTED_ONE)
      {
         if ((ret = itLscExec(msg)) != ROK)
         {
            (Void) itMifDpcEvt(FALSE, (UConnId) NULLD, IT_MIF_DATAREQ, 
                               IT_MIF_PC_UPU, msg->nwkId,
                               msg->dpc, msg->opc, 0x40, msg->srvInfo,
                               (ItDpcCb *) NULLP);
            IT_STS_INC_DATERR(msg, dropLoadShFail)
            RETVALUE(ret);
         }
      }
   } /* end if msgState == IT_MSG_ROUTED_ONE */

   if (msg->msgState == IT_MSG_ROUTED_TWO)
   {
      /* Check for local ASP routing */
      if (msg->routeType == LIT_RTTYPE_PS)
      {
         ItPspCb *psp;        /* PSP control block */
         psp = msg->routeTgt2->owner;
         if (psp->pspCfg.pspId == IT_LOCAL_PSPID)
         {
            if (msg->nSap == (ItNSapCb *)NULLP)
            {
               /* Get NSAP using UI demux */
               if ((ret =
                    itUiGetNSap(msg->nwkId, msg->srvInfo, FALSE, &msg->nSap))
                    != ROK)
               {
                  (Void) itMifDpcEvt(FALSE, (UConnId) NULLD, IT_MIF_DATAREQ, 
                                     IT_MIF_PC_UPU, msg->nwkId,
                                     msg->dpc, msg->opc, 0x40, msg->srvInfo,
                                     (ItDpcCb *) NULLP);
                  IT_STS_INC_DATERR(msg, dropNoNSapAvail)
                  RETVALUE(ret);
               }
            }
            msg->msgState = IT_MSG_RDY_NSAP;
         }
      } /* end if route type is PS */
      if (msg->msgState == IT_MSG_ROUTED_TWO)
      {
         msg->msgState = IT_MSG_RDY_MMH;
         /* Remote ASP or SGP: queue if congested */
         if ((ret = itCcChkQueue(msg)) != ROK)
         {
            RETVALUE(ret);
         }
      }
   } /* end if msgState */
   switch (msg->msgState)
   {
      case IT_MSG_RDY_NSAP:
         /* Send to upper interface */
         if ((ret = itUiUDatInd(msg->nSap, &(msg->mBuf), msg->opc, msg->dpc,
            msg->srvInfo, msg->lnkSel)) != ROK)
         {
            if (itMifDpcEvt(FALSE, (UConnId) NULLD, IT_MIF_DATAREQ, 
                            IT_MIF_PC_UPU, msg->nwkId, msg->dpc, msg->opc, 
                            0x40, msg->srvInfo, (ItDpcCb *) NULLP) != ROK)
            {
               RETVALUE(RFAILED);
            }
            IT_STS_INC_DATERR(msg, dropNoNSapAvail)
            RETVALUE(ret);
         }
         /* Data sent successfully, drop MUPM (but not message) */
         IT_FREE(sizeof(ItMupMsg), msg);
         itGlobalCb.nmbMsg--;
         break;
      case IT_MSG_RDY_MMH:
         /* Prepend header to message if necessary */
         if (msg->hdrState == IT_MSGHDR_NONE)
         {
            if ((ret = itMupEncHdr(msg)) != ROK)
            {
               RETVALUE(ret);
            }
         }
         /* Send to MMH for M3UA packaging */
         if ((ret = itMmhData(msg)) != ROK)
         {
            (Void) itMifDpcEvt(FALSE, (UConnId) NULLD, IT_MIF_DATAREQ, 
                               IT_MIF_PC_UPU, msg->nwkId, msg->dpc, msg->opc, 
                               0x40, msg->srvInfo, (ItDpcCb *) NULLP);
            IT_STS_INC_DATERR(msg, dropMmhFail)
            RETVALUE(ret);
         }
         /* Data sent successfully, drop MUPM (but not message) */
         IT_FREE(sizeof(ItMupMsg), msg);
         itGlobalCb.nmbMsg--;
         break;
      case IT_MSG_QUEUED_CC:
         /* Message was queued in congestion queue, do nothing further */
         IT_STS_INC_DATERR(msg, dataQCong)
         break;
      case IT_MSG_DISCARD:
         /* Message to be discarded (congestion priority) */
         IT_STS_INC_DATERR(msg, dropPcCong)
         /* Caller will discard message on receiving RNA return code */
         RETVALUE(RNA);
         break;
      case IT_MSG_QUEUED_LSCSLS:
         /* Message is queued in the SLS sequence control queue in 
          * Loadshare SLS control block */
         break;
      default:
         RETVALUE(RFAILED);
   } /* end switch */

   RETVALUE(ROK);
} /* end of itMupData */


/*
*
*       Fun:   MUP extract user information
*
*       Desc:  This function is called by Address Translation to extract
*              MTP3-User information from the message
*
*       Ret:
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMupGetUserInfo
(
ItMupMsg *msg,                /* MUP message */
U8       what                 /* What to extract */
)
#else
PUBLIC S16 itMupGetUserInfo(msg, what)
ItMupMsg *msg;                /* MUP message */
U8       what;                /* What to extract */
#endif
{
   U16      mvp;              /* parameter position */
   ItNwkCb  *nwk;             /* network CB */

   TRC2(itMupGetUserInfo)

   mvp               = 0;
   msg->userInfoLen  = 0;
   nwk               = itGlobalCb.nwk[msg->nwkId];

   if (msg->mBuf == (Buffer *)NULLP)
   {
      RETVALUE(ROKDNA);
   }

   /* Calculate start of user content */
   if (msg->hdrState == IT_MSGHDR_NONE)
   {
      mvp = 0;
   }
   else
   {
      switch (nwk->nwkCfg.dpcLen)
      {
         case DPC14:
            mvp = 5;
            break;
         case DPC24:
            mvp = 8;
            break;
         case DPC16:
            mvp = 7;
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   /* Extract MTP3-User information */
   switch (IT_SRVIND(msg->srvInfo))
   {
      case SI_SCCP:
      {
         U8    msgType;       /* message type */
         U8    tmp8;          /* temp */
         U16   ptr[5];        /* parameter pointers */
         Bool  pres[5];       /* parameter present flags */
         Bool  longPtr;       /* long pointer */
         U16   i;             /* loop index */

         longPtr = FALSE;
         /*
          * Mapping of ptr[] and pres[] index to parameter:
          * 0 = called party
          * 1 = calling party
          * 2 = data
          * 3 = optional part
          * 4 = segmentation
          */

         for (i = 0; i < 5; i++)
         {
            ptr[i]   = 0;
            pres[i]  = FALSE;
         }

         /* Get message type */
         SExamMsg((Data *)&msgType, msg->mBuf, mvp++);
         /* Find called party address location based on message type */
         /* Skip mandatory fixed part */
         switch (msgType)
         {
            case SCCP_CR:
               mvp      += 4;
               pres[0]  = TRUE; /* Called party */
               pres[3]  = TRUE; /* Optional part */
               break;
            case SCCP_CC:
               mvp      += 7;
               pres[3]  = TRUE; /* Optional part */
               break;
            case SCCP_CREF:
               mvp      += 4;
               pres[3]  = TRUE; /* Optional part */
               break;
            case SCCP_UDT:
            /* fall through */
            case SCCP_UDTS:
               pres[0]  = TRUE; /* Called party */
               pres[1]  = TRUE; /* Calling party */
               pres[2]  = TRUE; /* Data */
               mvp      += 1;
               break;
            case SCCP_XUDT:
            /* fall through */
            case SCCP_XUDTS:
               pres[0]  = TRUE; /* Called party */
               pres[1]  = TRUE; /* Calling party */
               pres[2]  = TRUE; /* Data */
               pres[3]  = TRUE; /* Optional part */
               pres[4]  = TRUE; /* Optional part */
               mvp      += 2;
               break;
            case SCCP_LUDT:
            /* fall through */
            case SCCP_LUDTS:
               pres[0]  = TRUE; /* Called party */
               pres[1]  = TRUE; /* Calling party */
               pres[2]  = TRUE; /* Data */
               pres[3]  = TRUE; /* Optional part */
               longPtr  = TRUE;
               mvp      += 2;
               break;
            default:
               break;
         }
         /* Extract pointer values */
         for (i = 0; i < 4; i++)
         {
            if (pres[i] == TRUE)
            {
               if (longPtr == TRUE)
               {
                  /* Mandatory variable part, called address = first pointer */
                  SExamMsg((Data *)&tmp8, msg->mBuf, mvp++);
                  ptr[i] = PutLoByte(ptr[i], tmp8);
                  SExamMsg((Data *)&tmp8, msg->mBuf, mvp);
                  ptr[i] = PutHiByte(ptr[i], tmp8);
                  if (ptr[i] == 0)
                  {
                     pres[i] = FALSE;
                  }
                  else
                  {
                     ptr[i] = (U16)(ptr[i] + mvp);
                  }
                  mvp++;
               }
               else
               {
                  SExamMsg((Data *)&tmp8, msg->mBuf, mvp);
                  ptr[i] = tmp8;
                  if (ptr[i] == 0)
                  {
                     pres[i] = FALSE;
                  }
                  else
                  {
                     ptr[i] = (U16)(ptr[i] + mvp);
                  }
                  mvp++;
               }
            }
         }
         /* If optional part present, search for interesting parameters */
         if (pres[3] == TRUE)
         {
            MsgLen   len;     /* message length */
            U16      skip;    /* skip value */
            mvp = ptr[3];
            SFndLenMsg(msg->mBuf, &len);
            /* Search for optional parameters */
            while (mvp < (U16)len)
            {
               SExamMsg((Data *)&tmp8, msg->mBuf, mvp++);
               switch (tmp8)
               {
                   case SCCP_PARAM_CALLED_PARTY :
                      pres[0] = TRUE;
                      ptr[0] = (U16)(mvp); /* ptr now points to length */
                      SExamMsg((Data *)&tmp8, msg->mBuf, mvp++);
                      skip = tmp8;
                      break;

                   case SCCP_PARAM_SEGMENTATION :
                      pres[4] = TRUE;
                      ptr[4] = (U16)(mvp); /* ptr now points to length */ 
                      SExamMsg((Data *)&tmp8, msg->mBuf, mvp++);
                      skip = tmp8;
                      break;

                   case SCCP_PARAM_LONG_DATA :
                      skip = 0;
                      SExamMsg((Data *)&tmp8, msg->mBuf, mvp++);
                      skip = PutLoByte(skip, tmp8);
                      SExamMsg((Data *)&tmp8, msg->mBuf, mvp);
                      skip = PutHiByte(skip, tmp8);
                      break;
 
                   default :
                      SExamMsg((Data *)&tmp8, msg->mBuf, mvp++);
                      skip = tmp8;
                      break;
               }
               /* Skip this parameter */
               mvp = (U16)(mvp + skip);
            }
         }
         if (what == IT_USER_SEGLOCREF)
         {
            if (pres[4] == TRUE)
            {
               mvp = ptr[4];
               /* Get length */
               SExamMsg((Data *)&tmp8, msg->mBuf, mvp++);
               for (i = 0; i < tmp8; i++)
               { 
                  SExamMsg((Data *)&msg->userInfo[i], msg->mBuf, mvp++);
               }
               msg->userInfoLen = tmp8;
            }
         }
         else
         {
            if (pres[0] == TRUE)
            {
               /* Extract called party address */
               mvp = ptr[0];
               /* Skip length field */
               mvp++;
               /* mvp points to the beginning of the address parameter */
               SExamMsg((Data *)&tmp8, msg->mBuf, mvp++);
               switch (nwk->nwkCfg.suSwtch)
               {
                  case LIT_SW_ANS:
                  /* fall through */
                  case LIT_SW_ANS96:
                     if (tmp8 & SCCP_AI_SSNI_ANSI)
                     {
                        SExamMsg((Data *)&msg->userInfo[0], msg->mBuf, mvp);
                        msg->userInfoLen = 1;
                     }
                     break;
                  case LIT_SW_ITU:
                  case LIT_SW_CHINA:
                     if (tmp8 & SCCP_AI_PCI_ITU)
                     {
                        /* Skip point code if present */
                        mvp = (U16)(mvp +
                          (U16)((itGlobalCb.nwk[msg->nwkId]->nwkCfg.dpcLen
                                      == DPC14) ? 2 : 3));
                     }
                     if (tmp8 & SCCP_AI_SSNI_ITU)
                     {
                        SExamMsg((Data *)&msg->userInfo[0], msg->mBuf, mvp);
                        msg->userInfoLen = 1;
                     }
                     break;
                  /* Others: not implemented */
                  default:
                     break;
               }
            }
            if (what == IT_USER_TCAP)
            {
               /* If data is present */
               if (pres[2] == TRUE)
               {
                  U8 tidLen;  /* transaction ID length */
                  mvp = ptr[2];
                  /* Skip length field */
                  mvp++;
                  /* TCAP type is taken from su2Swtch */
                  switch (nwk->nwkCfg.su2Swtch)
                  {
                     case LIT_SW2_ITU:
                     case LIT_SW2_TTC:
                        SExamMsg((Data *)&tmp8, msg->mBuf, mvp++);
                        switch (tmp8)
                        {
                           /* the following 4 case statements fall through */
                           case TCAP_MSGTYPE_BEGIN:
                           case TCAP_MSGTYPE_END:
                           case TCAP_MSGTYPE_CONTINUE:
                           case TCAP_MSGTYPE_ABORT:
                              SExamMsg((Data *)&tmp8, msg->mBuf, mvp++);
                              /* skip total TCAP msg length */
                              if (tmp8 > 128) /* long length field */
                              {
                                 mvp = (U16)(mvp + (tmp8 & 0x7f));
                              }
                              SExamMsg((Data *)&tmp8, msg->mBuf, mvp++);
                              if ((tmp8 == TCAP_TAG_ORIGTID) ||
                                 (tmp8  == TCAP_TAG_DESTTID))
                              {
                                 SExamMsg((Data *)&tidLen, msg->mBuf, mvp++);
                                 for (i = 0; i < tidLen; i++)
                                 {
                                    SExamMsg((Data *)&msg->userInfo[1 + i],
                                       msg->mBuf, mvp++);
                                    msg->userInfoLen++;
                                 }
                              }
                              break;
                           default:
                              break;
                        }
                        break;
                     case LIT_SW2_ANS:
                        SExamMsg((Data *)&tmp8, msg->mBuf, mvp++);
                        switch (tmp8)
                        {
                           /* the following 6 case statements fall through */
                           case ST_ANS_MSG_QWP_TAG:
                           case ST_ANS_MSG_QWOP_TAG:
                           case ST_ANS_MSG_RSP_TAG:
                           case ST_ANS_MSG_CWP_TAG:
                           case ST_ANS_MSG_CWOP_TAG:
                           case ST_ANS_MSG_ABT_TAG:
                              SExamMsg((Data *)&tmp8, msg->mBuf, mvp++);
                              /* skip total TCAP msg length */
                              if (tmp8 > 128) /* long length field */
                              {
                                 mvp = (U16)(mvp + (tmp8 & 0x7f));
                              }
                              SExamMsg((Data *)&tmp8, msg->mBuf, mvp++);
                              if (tmp8 == ST_ANS_TID_TAG)
                              {
                                 SExamMsg((Data *)&tidLen, msg->mBuf, mvp++);
                                 for (i = 0; i < tidLen; i++)
                                 {
                                    SExamMsg((Data *)&msg->userInfo[1 + i],
                                       msg->mBuf, mvp++);
                                    msg->userInfoLen++;
                                 }
                              }
                              break;
                           default:
                              break;
                        }
                        break;
                     case LIT_SW2_ETS:
                        /* ETSI: Not implemented */
                        break;
                     /* it005.106 - su2swtch set to unused though the 
                      * Transaction Id is being used in the route */
                     case LIT_SW2_UNUSED:
#if (ERRCLASS & ERRCLS_DEBUG)
                        ITLOGERROR(ERRCLS_DEBUG, EITXXX, 
                                   (ErrVal) nwk->nwkCfg.nwkId,
                                   "   su2Swtch unused in network config though Transaction ID used in route!");
#endif /* ERRCLS_DEBUG */
                        break;
                     default:
                        break;
                  }
               } /* end if data present */
            } /* end if TCAP */
         } /* end else */
         break;
      } /* end case SCCP */
      case SI_ISUP:
      {
         /* Extract CIC low order */
         SExamMsg((Data *)&msg->userInfo[0], msg->mBuf, mvp++);
         /* CIC high order */
         SExamMsg((Data *)&msg->userInfo[1], msg->mBuf, mvp++);
         msg->userInfoLen = 2;
         break;
      }

      case SI_TUP:
      {
         Data high;

         switch (nwk->nwkCfg.suSwtch)
         {
            case LIT_SW_CHINA:
               /* Extract CIC low order */
               SExamMsg((Data *)&msg->userInfo[0], msg->mBuf, mvp++);
               /* CIC high order */
               SExamMsg((Data *)&msg->userInfo[1], msg->mBuf, mvp++);
               msg->userInfoLen = 2;
               break;

            default:
               SExamMsg((Data *)&high, msg->mBuf, mvp++);
               msg->userInfo[0] = 
                     (U8)((msg->lnkSel & 0x0F) | ((high & 0x0F) << 4));
               msg->userInfo[1] = (U8)((high >> 4) & 0x0F);
               msg->userInfoLen = 2;
               break;
         }
         break;
      }

      default:
         msg->userInfoLen = 0;
         break;
   }

   RETVALUE(ROK);
} /* end of itMupGetUserInfo */

/**********************************************************************
 *              MANAGEMENT INTERWORKING FUNCTION
 **********************************************************************/

#ifdef ITSG
/*
*
*       Fun:   itMifStaSet
*
*       Desc:  Called by UI when the co-resident MTP3 at an SG wants to
*              indicate a status change in a remote SS7 point code.
*              Performs the management interworking function for the
*              change of status.
*
*       Ret:
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMifStaSet
(
ItNSapCb *nSapCb,             /* upper SAP */
Dpc      aPc,                 /* affected point code */
Dpc      dpc,                 /* destination point code */
Status   status,              /* new status */
Prior    congLevel,           /* congestion level */
SrvInfo  srvInfo,             /* SIO for NIF user part indication */
Bool     qryFlag              /* Flag to find fnct from StaQryRsp/StaApyReq */
)
#else
PUBLIC S16 itMifStaSet(nSapCb, aPc, dpc, status, congLevel, srvInfo, qryFlag)
ItNSapCb *nSapCb;             /* upper SAP */
Dpc      aPc;                 /* affected point code */
Dpc      dpc;                 /* destination point code */
Status   status;              /* new status */
Prior    congLevel;           /* congestion level */
SrvInfo  srvInfo;             /* SIO for NIF user part indication */
Bool     qryFlag;             /* Flag to find fnct from StaQryRsp/StaApyReq */
#endif
{
   ItDpcCb     *dpcCb;        /* DPC control block */
   U8          dpcEv;         /* DPC related event */
   U8          dpcStSs7;      /* local DPC state */
   S16         ret;           /* return value */
   U8    oldDpcSt;            /* old DPC state */
   U8    oldDpcCong;          /* old DPC congestion level */
   Dpc         curaPc;        /* affected point code */
   Dpc         aPcMask;       /* Affected PC Mask */
   Dpc         tmpaPcMask;    /* temporary Affected PC Mask */

   oldDpcSt = IT_DPC_UNKNOWN;
   oldDpcCong = 0;

   TRC2(itMifStaSet)

   /* it013.106 - Added a debug print */
#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, "itMifStaSet(nSapCb(%d), apc(%d), dpc(%d), status(%d), congLevel(%d), srvInfo(%d), qryFlag(%d))\n", nSapCb->sntCfg.sapId, aPc, dpc, status, congLevel, srvInfo, qryFlag));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, "itMifStaSet(nSapCb(%d), apc(%ld), dpc(%ld), status(%d), congLevel(%d), srvInfo(%d), qryFlag(%d))\n", nSapCb->sntCfg.sapId, aPc, dpc, status, congLevel, srvInfo, qryFlag));
#endif

   dpcCb = (ItDpcCb *)NULLP;
   aPcMask = MAX32BIT;

   curaPc = IT_MAX_DPC_MASK;

   switch (status)
   {
      case SN_RSTBEG:      /* restart begin */
         if ((ret = itMifRestart(nSapCb->sntCfg.nwkId)) != ROK)
         {
            RETVALUE(ret);
         }
         (Void) itMifUserEvt(IT_MIF_USER_UP, nSapCb);
         break;
      case SN_RSTEND:      /* restart end */
         if (nSapCb->nwk->restart == TRUE)
         {
            itTcStopTimer(&nSapCb->nwk->tmrRestart);
            (Void) itMifNwkEvt(IT_MIF_RST_COMP, (ItPspId) 0, nSapCb->nwk);
         }
         break;
      
         /* the following 6 case statements fall through */
      case SN_RESTRICT:    /* MTP-Destnation Restricted */
      case SN_PAUSE:       /* MTP-PAUSE */
      case SN_RESUME:      /* MTP-RESUME */
      case SN_CONG:        /* start congestion */
      case SN_STPCONG:     /* stop congestion */
      case SN_RMTUSRUNAV:  /* user part unavailable */
      {
         /* Determine Mask from first 8 bits of aPc. This implies
          * the number of aPc Least significant bits to be wildcarded */
         aPcMask = (Dpc) (MAX32BIT << (aPc >> 24));
         tmpaPcMask = (nSapCb->nwk->nwkCfg.dpcLen == DPC14) ? 0x3fff :
                      (nSapCb->nwk->nwkCfg.dpcLen == DPC16) ? 0xffff : 0xffffff;

         /* Also added the check for aPc Mask when all the aPc bits
          * are wildcarded. */
         if (((aPc == (Dpc) 0) || ((aPcMask & tmpaPcMask) == NULLD)) && 
             (dpc == (Dpc) 0) && (nSapCb->sntCfg.suType == LIT_SP_MTP3))
         {
            /* special case: the NIF is telling us that MTP3 is not present */
            if (status == SN_PAUSE)
            {
               RETVALUE(itMifUserEvt(IT_MIF_MTP3_NOTPRSNT, nSapCb));
            }
            /* special case: the NIF is telling us that MTP3 is present */
            else if (status == SN_RESUME)
            {
               RETVALUE(itMifUserEvt(IT_MIF_MTP3_PRSNT, nSapCb));
            }
            else
            {
               RETVALUE(RFAILED);
            }
         }
         /* Determine the actual aPc from last 24 bits of aPc. 
          * And mask should not be present if status is SN_RMTUSRUNAV. */
         if ((status == SN_RMTUSRUNAV) && (aPcMask != MAX32BIT))
         {
            RETVALUE(RFAILED);
         }

         curaPc  = aPc & IT_MAX_DPC_MASK;

         /* Changed the if statement to check the DPC CB only if
          * Mask is equal to MAX32BIT */
         /* if ((ret = itAtGetDpc(nSapCb->sntCfg.nwkId, aPc, &dpcCb))
            != ROK) */
         if ((aPcMask == MAX32BIT) &&
             ((ret = itAtGetDpc(nSapCb->sntCfg.nwkId, aPc, &dpcCb)) != ROK))
         {
            if (itGlobalCb.genCfg.dpcLrnFlag == TRUE)
            {
               if ((ret = itAtAddDpc(nSapCb->sntCfg.nwkId, aPc, &dpcCb,
                                     IT_DPCCB_SS7)) != ROK)
               {
                  RETVALUE(ret);
               }
/* DFHTA-hooks : comment : No DPC creation update required here, it is
                 taken care from inside the CalcDpcStatus function */
                  if ((ret = itMifCalcDpcStatus(dpcCb, IT_MIF_PC_NEW, 0)) 
                      != ROK)
                  {
                     RETVALUE(ret);
                  }
            }
         }
         break;
      }
      default:
         RETVALUE(RFAILED);
   }
   
   dpcStSs7 = IT_DPC_UNAVAILABLE;

   switch (status)
   {
      case SN_PAUSE:
         IT_STS_INC_MTP3_RX(nSapCb, pause);
         dpcEv = IT_MIF_PC_UNA;
         dpcStSs7 = IT_DPC_UNAVAILABLE;
         break;
      case SN_RESUME:
         dpcEv = IT_MIF_PC_AVA;
         dpcStSs7 = IT_DPC_AVAILABLE;
         /* Deleted the defensive check to reset the DPC congestion
          * level for International networks. This is done later in the while 
          * loop for all the DPCs in the Mask range. */
         /*
         * a defensive check added so that the initial value of the
          * congetion level stored in dpcCb should not be other than
          * SN_PRI0 for any case *
         if ((dpcCb != (ItDpcCb *) NULLP) &&
            ((dpcCb->nwk->nwkCfg.ssf == SSF_INTL) &&
             (dpcCb->nwk->nwkCfg.dpcLen != DPC16)))
         {
            dpcCb->congLevel  = SN_PRI0;
         } */
         IT_STS_INC_MTP3_RX(nSapCb, resume);
         break;
      case SN_RESTRICT:
         if (itGlobalCb.genCfg.drstSupp == FALSE)
         {
            dpcStSs7 = IT_DPC_AVAILABLE;
            dpcEv = IT_MIF_PC_AVA;
         }
         else
         {
            dpcEv = IT_MIF_PC_RST;
         }
         IT_STS_INC_MTP3_RX(nSapCb, drst);
         break;
      case SN_STPCONG:
         /* a defensive check added as this indication should never be sent
          * by MTP3  for international networks
          * but if sent then simply return with no indicatin */
         /* Changed the defensive check for International
          * networks, to check the network config using NSAP CB instead of DPC
          * CB, as in case aPc Mask is valid DPC CB will be null */
         /*if ((dpcCb != (ItDpcCb *) NULLP) &&
            ((dpcCb->nwk->nwkCfg.ssf == SSF_INTL) &&
             (dpcCb->nwk->nwkCfg.dpcLen != DPC16))) */
         if ((nSapCb->nwk->nwkCfg.ssf == SSF_INTL) &&
             (nSapCb->nwk->nwkCfg.dpcLen != DPC16))
         {
            RETVALUE(ROK);
         }
      /* fall through */
      case SN_CONG:
         dpcEv = IT_MIF_PC_CON;
         IT_STS_INC_MTP3_RX(nSapCb, cong);
         break;
      case SN_RMTUSRUNAV:
         IT_STS_INC_MTP3_RX(nSapCb, upu);
         dpcStSs7 = IT_DPC_AVAILABLE;
         dpcEv = IT_MIF_PC_UPU;
         break;
      case SN_RSTBEG:
         IT_STS_INC_MTP3_RX(nSapCb, rstBeg);
         dpcEv = IT_MIF_RST_BEG;
         break;
      case SN_RSTEND:
         IT_STS_INC_MTP3_RX(nSapCb, rstEnd);
         dpcEv = IT_MIF_RST_END;
         break;
      default:
         RETVALUE(RFAILED);
   }

   /* Update state of DPC CB if existing */
   /* Replaced the check on DPC CB with a while loop to update the
    * status of all DPCs in the Mask range, if mask is not equal to MAX32BIT. 
    * Otherwise update the status of single DPC if Mask is MAX32BIT */
   /* if (dpcCb != (ItDpcCb *) NULLP) */
   while ((aPcMask != MAX32BIT) || 
          (dpcCb != (ItDpcCb *) NULLP))
          
   {
      Bool  wasAvail;         /* TRUE if DPC was available */
      Bool  isAvail;          /* TRUE if DPC is now available */

      if (aPcMask != MAX32BIT)
      {
         if (itAtGetDpcs(nSapCb->sntCfg.nwkId, curaPc, aPcMask, &dpcCb) == ROK)
         {
            if (dpcCb->type != IT_DPCCB_SS7)
            {
               continue;
            }
         }
         else
         {
            break;
         }
      }

      /* Moved the following check from the switch statement
       * above to reset the congestion level for all DPCs in the Mask range
       * if status is SN_RESUME */
      /* a defensive check added so that the initial value of the
       * congetion level stored in dpcCb should not be other than
       * SN_PRI0 for any case */
      if ((status == SN_RESUME) &&
          ((dpcCb->nwk->nwkCfg.ssf == SSF_INTL) &&
           (dpcCb->nwk->nwkCfg.dpcLen != DPC16)))
      {
         dpcCb->congLevel  = SN_PRI0;
      }

      oldDpcSt    = dpcCb->dpcSt;
      oldDpcCong  = dpcCb->congLevel;
      dpcCb->dpcStSs7 = dpcStSs7;
      if ((dpcCb->dpcSt == IT_DPC_UNAVAILABLE) && (dpcEv == IT_MIF_PC_CON)
           && (qryFlag == FALSE))
      {
         /* If aPc Mask is valid i.e. not MAX32BIT, then go to
          * next DPC in the Mask range */
         if (aPcMask == MAX32BIT)
         {
            RETVALUE(ROK);
         }
         else
         {
            continue;
         }
      }
      if ((ret = itMifCalcDpcStatus(dpcCb, dpcEv, congLevel)) != ROK)
      {
         RETVALUE(ret);
      }
      /* If the SN_RESUME is received in query response primitive then
       * it means that there is no congestion otherwise we should have
       * received SN_CONG. So congestion should be removed unconditionally */

      if (qryFlag == TRUE)
      {
         if (dpcEv == IT_MIF_PC_CON)
         {
            dpcCb->dpcSt = IT_DPC_AVAILABLE;
            dpcCb->dpcStSs7 = IT_DPC_AVAILABLE;
            dpcEv = IT_MIF_PC_AVA;
         }
         else if (dpcEv == IT_MIF_PC_AVA)
         {
            dpcCb->congLevel = SN_PRI0;
         }
         else if (dpcEv == IT_MIF_PC_RST)
         {
            if ((dpcCb->nwk->nwkCfg.ssf == SSF_NAT) ||
                 (dpcCb->nwk->nwkCfg.dpcLen == DPC16))
            {
               dpcCb->congLevel  = congLevel;
            }
            else
            {
               dpcCb->congLevel  = SN_PRI0;
            }
         }

      }
      /* 1. If the event type is IT_MIF_PC_CON, don't calculate PC status
       * 2. If the event type is IT_MIF_PC_RST, on't calculate PC status
       * 3. If the event type is IT_MIF_PC_AVA, and if the PC was 
       *    Congested + Restricted then also don't calculate the PC status
       *    this scenerio is equivalent to case 1. */
      if (((dpcEv == IT_MIF_PC_AVA) && (dpcCb->congLevel == SN_PRI0)) ||
          (dpcEv == IT_MIF_PC_UNA) || (dpcEv == IT_MIF_PC_UPU))
      {
         if ((ret = itMifCalcDpcStatus(dpcCb, IT_MIF_PC_SUM, congLevel))
              != ROK)
         {
            RETVALUE(ret);
         }
      }
      wasAvail = (Bool)((oldDpcSt == IT_DPC_UNAVAILABLE) ? FALSE : TRUE);
      isAvail  = (Bool)((dpcCb->dpcSt == IT_DPC_UNAVAILABLE) ? FALSE : TRUE);
      if (((dpcEv == IT_MIF_PC_UNA) || (dpcEv == IT_MIF_PC_AVA)) &&
         (wasAvail == isAvail) && (oldDpcCong == dpcCb->congLevel))
      {
         /* Check if this is a split LOCAL / SS7 PC and if states differ */
         if ((dpcCb->dpcSt == IT_DPC_AVAILABLE) &&
             (dpcCb->dpcStSs7 == IT_DPC_UNAVAILABLE) &&
             (nSapCb->nwk->restart == FALSE))
         {
            /* Changed the aPc parameter to take DPC from DPC CB
             * in call to itMifDpcEvt */
            /*RETVALUE(itMifDpcEvt(FALSE, (ItPspId) NULLD, IT_MIF_SS7, 
                                 IT_MIF_PC_UPU, nSapCb->sntCfg.nwkId, aPc, dpc,
                                 congLevel, srvInfo, dpcCb)); */
            /*  If aPc Mask is valid i.e. not MAX32BIT, then go to
             * next DPC in the Mask range */
            if (aPcMask == MAX32BIT)
            {
               RETVALUE(itMifDpcEvt(FALSE, (UConnId) NULLD, IT_MIF_SS7, 
                                 IT_MIF_PC_UPU, nSapCb->sntCfg.nwkId, 
                                 dpcCb->dpc, dpc, congLevel, srvInfo, dpcCb));
            }
            else
            {
               if (itMifDpcEvt(FALSE, (UConnId) NULLD, IT_MIF_SS7, 
                                 IT_MIF_PC_UPU, nSapCb->sntCfg.nwkId, 
                                 dpcCb->dpc, dpc, congLevel, srvInfo, 
                                 dpcCb) != ROK)
               {
                  RETVALUE(RFAILED);
               }
               continue;
            }
         }
      }
      /* if the congestion indication is received for a PC in international
       * network then we don't store the congestion level in dpcCb but still
       * we need to send the SCON message to the remote ASP */
      if ((oldDpcSt == dpcCb->dpcSt) && (dpcCb->congLevel == oldDpcCong) &&
          (dpcEv != IT_MIF_PC_UPU)  &&
         !((dpcEv == IT_MIF_PC_CON) && 
          ((dpcCb->nwk->nwkCfg.ssf == SSF_INTL) &&
          (dpcCb->nwk->nwkCfg.dpcLen != DPC16))))
      {
         /* This is a non-event - the DPC has not changed in status */
         /* - If aPc Mask is valid i.e. not MAX32BIT, then go to
          * next DPC in the Mask range */
         if (aPcMask == MAX32BIT)
         {
            RETVALUE(ROK);
         }
         else
         {
            continue;
         }
      }

      /* - Added code to send SCON for each DPC if network is not
       * under restart and Congestion level has changed. Here SCON should be
       * sent only if aPcMask is valid but the event is not IT_MIF_PC_CON and 
       * congestion level changed. If the event is IT_MIF_PC_CON and aPcMask 
       * is valid, then SCON will be sent with aPc Mask later.
       * Also changed the aPc parameter to take DPC from DPC CB in call to
       * itMifDpcEvt() */
      if ((nSapCb->nwk->restart != TRUE) &&
          (dpcCb->congLevel != oldDpcCong) &&
          ((dpcEv != IT_MIF_PC_CON) && (aPcMask != MAX32BIT)))
      {
         if (itMifDpcEvt(FALSE, (UConnId) NULLD, IT_MIF_SS7, IT_MIF_PC_CON,
                        nSapCb->sntCfg.nwkId, dpcCb->dpc, dpc, congLevel, 
                        srvInfo, dpcCb) != ROK)
         {
            RETVALUE(RFAILED);
         }
      }

      /* - Added code to prevent further iteration in while loop if
       * Mask is equal to MAX32BIT */
      if (aPcMask == MAX32BIT)
      {
         break;
      }

   } /* end of while */

   /* it014.106 - If status is SN_RSTBEG or SN_RSTEND, do not exit, 
    * so that this indication can be forwarded to M3UA user NSAPs. */
   if ((nSapCb->nwk->restart == TRUE) && (status != SN_RSTBEG)) 
   {
      /* Network restarting, do not forward status */
      RETVALUE(ROK);
   }
   /* - Changed the check on DPC CB, to send SCON if DPC congestion
    * level has changed or for international network only when aPcMask is
    * invalid. */
   
   if ((aPcMask == MAX32BIT) && (dpcCb != (ItDpcCb *) NULLP))
   {
      /* In case of international network the oldcongestion level would be
       * same as new one as we don't change the congestion level in dpcCb 
       * so a special case is added for international network to send SCON
       */
      if ((dpcCb->congLevel != oldDpcCong) ||
         ((dpcEv == IT_MIF_PC_CON) && 
         ((dpcCb->nwk->nwkCfg.ssf == SSF_INTL) &&
         (dpcCb->nwk->nwkCfg.dpcLen != DPC16))))
      {
         if (itMifDpcEvt(FALSE, (UConnId) NULLD, IT_MIF_SS7, IT_MIF_PC_CON,
                        nSapCb->sntCfg.nwkId, aPc, dpc, congLevel, 
                        srvInfo, dpcCb) != ROK)
         {
            RETVALUE(RFAILED);
         }
      } 
   }

   /* it013.106 - Changes to send SCON with congestion level SN_PRI0, when 
    * SN_RESUME is received in SntStaQryRsp for a non-existing fully specified 
    * DPC (i.e. apcMask == MAX32BIT) in a National network. */
   if ((qryFlag == TRUE) && (aPcMask == MAX32BIT) && (dpcCb == (ItDpcCb *) NULLP))
   {
      if ((dpcEv == IT_MIF_PC_AVA) && 
         ((nSapCb->nwk->nwkCfg.ssf == SSF_NAT) ||
          (nSapCb->nwk->nwkCfg.dpcLen == DPC16)))
      {
         if (itMifDpcEvt(FALSE, (UConnId) NULLD, IT_MIF_SS7, IT_MIF_PC_CON,
                        nSapCb->sntCfg.nwkId, aPc, dpc, SN_PRI0, 
                        srvInfo, dpcCb) != ROK)
         {
            RETVALUE(RFAILED);
         }
      } 
   }

   /* Forward to rest of system */
   /* - Changed the check to call itMifDpcEvt also when Mask is
    * not equal to MAX32BIT */
   /*if ((dpcCb == (ItDpcCb *) NULLP) || (oldDpcSt != dpcCb->dpcSt) ||
       (dpcEv == IT_MIF_PC_UPU))*/
   if ((aPcMask != MAX32BIT) || (dpcCb == (ItDpcCb *) NULLP) || 
       (oldDpcSt != dpcCb->dpcSt) || (dpcEv == IT_MIF_PC_UPU))
   {
      RETVALUE(itMifDpcEvt(FALSE, (UConnId) NULLD, IT_MIF_SS7, dpcEv, 
                        nSapCb->sntCfg.nwkId, aPc, dpc, congLevel, 
                        srvInfo, dpcCb));
   }
   RETVALUE(ROK);
} /* end of itMifStaSet */
#endif /* ITSG */

/*
*
*       Fun:   itMifSsnm
*
*       Desc:  Called by MMH when an SS7 Network Management message is
*              received from an M3UA peer. Performs the management
*              interworking function for the change of status.
*
*       Ret:
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMifSsnm
(
ItAssocCb   *assocCb,         /* association received on */
U32         msgType,          /* message type */
U8          nwkId,            /* network context ID */
Dpc         dpc,              /* affected point code */
U8          mask,             /* point code mask */
Txt         *info,            /* additional INFO */
U16         xtraParam1,       /* extra parameter 1 */
U16         xtraParam2,       /* extra parameter 2 */
Buffer      **mBuf            /* pointer to original message */
)
#else
PUBLIC S16 itMifSsnm(assocCb, msgType, nwkId, dpc, mask, info, xtraParam1,
                     xtraParam2, mBuf)
ItAssocCb   *assocCb;         /* association received on */
U32         msgType;          /* message type */
U8          nwkId;            /* network context ID */
Dpc         dpc;              /* affected point code */
U8          mask;             /* point code mask */
Txt         *info;            /* additional INFO */
U16         xtraParam1;       /* extra parameter 1 */
U16         xtraParam2;       /* extra parameter 2 */
Buffer      **mBuf;           /* pointer to original message */
#endif
{
   Bool     dpcValid;         /* TRUE if DPC fully specified (not masked) */
   Bool     dpcAll;           /* TRUE if DPC fully masked */
   ItDpcCb  *dpcCb;           /* DPC control block */
   Dpc      dpcMask;          /* expanded DPC mask */
   U8       dpcLen;           /* DPC length */
#ifdef SNTIWF
   ItNSapCb *nSapCb;          /* upper SAP CB */
#endif
   Dpc      curDpc;           /* current DPC value */
   ItPspCb  *pspCb;           /* PSP control block */
   ItPspId  pspId;            /* PSP ID */
   U8       dpcEv;            /* DPC related event */
#ifdef ITSG
   ItNwkCb  *nwkCb;           /* Network control block */
#endif
   Bool     allDpcs;          /* TRUE if status to be updated for all DPCs in 
                                 mask range */
   Dpc      maxDpc;           /* Maximum DPC value in Mask range */
   Dpc      maxDpcMask;       /* Maximum DPC mask */
   U8       event;            /* DPC related event */
   UConnId  assocId;          /* Association Id */
   Bool wasAvail;
#if (defined(ITASP) && defined(SGVIEW))
   ItPspCb  *pspCbTemp;    /* PSP control block */
   ItPspId  pspIdTemp;     /* PSP Id */
   ItAssocCb  *assocCbTemp;    /* Assoc control block */
   UConnId     assocIdTemp;    /* Assoc Id */
#endif /* ITASP && SGVIEW */

#ifdef ZV
   /* it018.106 - addition - DFTHA Enhancement */
   ZvUpdSpecParams updArgs;
#endif /* ZV */

   TRC2(itMifSsnm)

   UNUSED(info);
   UNUSED(mBuf);

   dpcLen   = 0;
   dpcEv    = 0;
   dpcMask  = (Dpc) MAX32BIT << mask;
   dpcCb    = (ItDpcCb *)NULLP;
   pspCb    = assocCb->owner;
   pspId    = pspCb->pspCfg.pspId;
   assocId  = assocCb->assocId;
   maxDpc = 0;

   /* if SCON Message is received from ASP client or IPSP then just send 
    * a status indication message to layer manager and return */

   if (((pspCb->pspCfg.pspType == LIT_PSPTYPE_ASP) ||
        (pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP)) &&
       (msgType == IT_SSNM_SCON))
   {
      /* Send an indication to LM that unexpected msg received */   
      IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))                     
      itGlobalCb.mgmt.hdr.elmId.elmnt       = STITAPC;              
      itGlobalCb.mgmt.t.usta.alarm.category = LIT_CATEGORY_STATUS;  
      itGlobalCb.mgmt.t.usta.alarm.event    = LIT_EVENT_PC_CONGESTED;
      itGlobalCb.mgmt.t.usta.alarm.cause    = LCM_CAUSE_UNKNOWN;
      itGlobalCb.mgmt.t.usta.s.nwkId        = nwkId;
      itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc   = dpc;
      itGlobalCb.mgmt.t.usta.t.dpcEvt.p.congLevel = (U8)xtraParam1;
                                                                    
      (Void) itMiStaIndM(&itGlobalCb.mgmt);                         
      RETVALUE(ROK);                                                
   }

   /* if DAUD message is received at IPSP then send a status indication
    * message to layer manager and return as at IPSP DPC state information is
    * not available */

   if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) &&
       (itGlobalCb.genCfg.nodeType == LIT_TYPE_ASP) &&
       (msgType == IT_SSNM_DAUD))
   {
      /* Send an indication to LM that unexpected msg received */   
      IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))                     
      itGlobalCb.mgmt.hdr.elmId.elmnt       = STITAPC;              
      itGlobalCb.mgmt.t.usta.alarm.category = LIT_CATEGORY_STATUS;  
      itGlobalCb.mgmt.t.usta.alarm.event    = LIT_EVENT_DAUD_RXD;
      itGlobalCb.mgmt.t.usta.alarm.cause    = LCM_CAUSE_UNKNOWN;
      itGlobalCb.mgmt.t.usta.s.nwkId        = nwkId;
      itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc   = dpc;
                                                                    
      (Void) itMiStaIndM(&itGlobalCb.mgmt);                         
      RETVALUE(ROK);                      
   }
   /* Added code to determine the DPC Mask as per number of DPC
    * bits */
   switch (itGlobalCb.nwk[nwkId]->nwkCfg.dpcLen)
   {
      case DPC14:
         dpcLen = 14;
         maxDpcMask = 0x3fff;
         break;
      case DPC16:
         dpcLen = 16;
         maxDpcMask = 0xffff;
         break;
      case DPC24:
         dpcLen = 24;
         maxDpcMask = 0xffffff;
         break;
      default:
         RETVALUE(RFAILED);
   }

   switch (msgType)
   {
      case IT_SSNM_DAUD:
         dpcEv = IT_MIF_NONE;
         break;
      case IT_SSNM_DUNA:
         dpcEv = IT_MIF_PC_UNA;
         break;
      case IT_SSNM_DRST:
         /* if we receive DRST message and if we don't support DRST message
          * processing then this message is processed as DAVA message */ 
         if (itGlobalCb.genCfg.drstSupp == TRUE)
         {
            dpcEv = IT_MIF_PC_RST;
         }
         else
         {
            dpcEv = IT_MIF_PC_AVA;
         }
         break;
      case IT_SSNM_DAVA:
         dpcEv = IT_MIF_PC_AVA;
         break;
      case IT_SSNM_SCON:
         dpcEv = IT_MIF_PC_CON;
         break;
      case IT_SSNM_DUPU:
         dpcEv = IT_MIF_PC_UPU;
         /* add the cause to the most significant two bits of the priority */
         xtraParam1 = (U8) ((xtraParam1) << 6);
         break;
      default:
         RETVALUE(RFAILED);
   }

   dpcValid = (Bool)((mask == 0) ? TRUE : FALSE);

   /* mask may be greater than dpcLen in this case also the
      network is down */
   dpcAll   = (Bool)((mask >= dpcLen) ? TRUE : FALSE);

   /* Upper 2 bits are used for the the cause received in the DUPU message
    * cause value of 0x03 is not a valid values , so sending error on that */
   if ((msgType == IT_SSNM_DUPU) && ((mask != 0) || (xtraParam1 == 0xc0)))
      RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_INV_PARMVAL, (Buffer **) NULLP,
                          (U32) mask, (ItM3uaTag *) NULLP, (ItRtCtx *) NULLP,
                          0, IT_M3UA_DFLT));

   if (msgType == IT_SSNM_DAUD)
   {
      while ((itAtGetDpcs(nwkId, dpc, dpcMask, &dpcCb) == ROK) ||
             (dpcValid == TRUE) || (dpcAll == TRUE))
      {
         if (dpcCb != (ItDpcCb *)NULLP)
         {
            curDpc = dpcCb->dpc;

            /* it023.106 - Update Daud Rx sts for owner PS */
#ifdef LITV6
            if (dpcCb->owner != NULLP)
            {
               IT_STS_INC_RX_PS(dpcCb->owner, IT_SSNM_DAUD)
            }
#endif /* LITV6 */
         }
         else
         {
            curDpc = dpc;
         }
         /* if (msgType == IT_SSNM_DAUD) */

#ifdef ITSG
         nwkCb = itGlobalCb.nwk[nwkId];
         if (nwkCb->restart == TRUE)
         {
            itMmhSsnm(assocCb, IT_SSNM_DUNA, nwkId, dpc, mask, (Txt *) NULLP,
                      0,0);
            RETVALUE(ROK);
         }
#endif
#ifdef SNTIWF
         if (dpcCb == (ItDpcCb *)NULLP)
         {
            if (dpcValid == TRUE)
            {
               S16 ret;       /* return value */
               /* No stored DPC state, pass query up to NIF */
               if ((ret = itUiGetNSap(nwkId, (SrvInfo)0, TRUE, &nSapCb)) ==
                  ROK)
               {
                  if (nSapCb->nwk->restart == FALSE)
                  {
#ifdef SNT_BACK_COMP_MERGED_NIF
                     (Void) ItUiSntStaQryInd(&nSapCb->pst,
                                             nSapCb->sntSta.remSapId, curDpc,
                                             (Dpc) 0);
#else
                     (Void) ItLiSntStaQryReq(&nSapCb->pst,
                                             nSapCb->sntCfg.mtp3SapId, curDpc,
                                             (Dpc) 0);
#endif
                  }

               }
               else
               {
                  (Void) itMmhSsnm(assocCb, IT_SSNM_DUNA, nwkId, curDpc, 0,
                                   (Txt *) NULLP, 0, 0);
               }
            }
            else if (dpcAll == TRUE)
            {
               (Void) itMmhSsnm(assocCb, IT_SSNM_DUNA, nwkId, (Dpc) 0, mask,
                                (Txt *) NULLP, 0, 0);
            }
         }
         else
#endif /* SNTIWF */
         {
            U16 repMsgType;   /* reply message type */
            if (dpcCb != (ItDpcCb *)NULLP)
            {
               /* We have the DPC state, send it back to querying ASP */
               switch (dpcCb->dpcSt)
               {
                  case IT_DPC_RESTRICTED:
                     repMsgType = IT_SSNM_DRST;
                     break;
                  case IT_DPC_AVAILABLE:
                     repMsgType = IT_SSNM_DAVA;
                     break;
                  case IT_DPC_UNAVAILABLE:
                     repMsgType = IT_SSNM_DUNA;
                     break;
                  default:
                     RETVALUE(RFAILED);
               }
            }
            else
            {
               repMsgType = IT_SSNM_DUNA;
            }
        /* In DAUD response always two messages will be sent if current
         * PC state is not IT_DPC_UNAVAILABLE. First message (SCON) will 
         * indicate the congestion level and the second message will 
         * either be DAVA or DRST indicating the PC availability status. */

            if ((repMsgType != IT_SSNM_DUNA)
                 && ((dpcCb->nwk->nwkCfg.ssf == SSF_NAT) ||
                     (dpcCb->nwk->nwkCfg.dpcLen == DPC16)))
            {
               (Void) itMmhSsnm(assocCb,IT_SSNM_SCON, nwkId, curDpc, 0,
                               (Txt *)NULLP,(U16)(dpcCb->congLevel), 0);
            }
             
            (Void) itMmhSsnm(assocCb, repMsgType, nwkId, curDpc, 0,
                            (Txt *)NULLP,0, 0);
         }
         /* Allow only one pass through if there are no matching DPCs */
         dpcValid = FALSE;
         dpcAll = FALSE;
      } /* end while */
   } /* end if msgType IT_SSNM_DAUD */
   else
   {
      /* For messages other than DAUD */

      /* - Check if there are any DPC CBs existing in the SSNM Mask
       * range if dpcValid is FALSE. If no, then call itMifPspEvt with DPC and
       * Mask packed into first 8 bits of DPC */
      if ((dpcValid == FALSE) && (dpcAll == FALSE))
      {
         if (itAtGetDpcs(nwkId, dpc, dpcMask, &dpcCb) == ROK)
         {
            allDpcs = TRUE;
            dpcCb   = NULLP;
            curDpc  = (dpc & dpcMask);
            maxDpc  = (dpc | (~dpcMask)) & maxDpcMask;
         }
         else
         {
            allDpcs = FALSE;

            /* if we receive DRST message for point codes for which we don't
             * have any entry in the routing table then we indicate the point
             * code status to be available to the users */
            if (dpcEv == IT_MIF_PC_RST)
            {
               dpcEv = IT_MIF_PC_AVA;
            }   
            /* Pack mask into curDpc */
            curDpc = (dpc | (mask << 24));
            /* Pass to remote peer MIF processing */
            if (itMifPspEvt(dpcEv, nwkId, curDpc,
                            (U8)(((dpcEv == IT_MIF_PC_CON) || 
                                  (dpcEv == IT_MIF_PC_UPU) ) ? xtraParam1 : 0),
                            (U8)((dpcEv == IT_MIF_PC_UPU) ? xtraParam2 : 0),
                            assocCb, dpcCb) != ROK)
            {
               RETVALUE(RFAILED);
            }
         } /* end of if no DPC CB exists */
      } /* end of if dpcValid FALSE */
      else
      {
         allDpcs = TRUE;
         curDpc  = dpc;
         maxDpc  = dpc;
      }

      if (itGlobalCb.genCfg.dpcLrnFlag == TRUE)
      {
         while (allDpcs == TRUE)
         {
            event = dpcEv;

         /* - If dpcAll is FALSE, then only send Status Indications
          * for non-existing DPCs, else send status indications for all
          * existing DPCs in the given network. */
            if (dpcAll == FALSE)
            {
               itAtGetDpc(nwkId, curDpc, &dpcCb);
            }
            else if (itAtGetDpcs(nwkId, dpc, dpcMask, &dpcCb) != ROK)
            {
               break;
            }

            if (dpcCb == (ItDpcCb *) NULLP)
            {
               if (dpcValid == TRUE)
               {
                  S16 ret;          /* return value */
                  /* If learning mode enabled, add DPC to table */
                  if (itGlobalCb.genCfg.dpcLrnFlag == TRUE)
                  {
                     if ((ret = itAtAddDpc(nwkId, curDpc, &dpcCb,
                                        IT_DPCCB_NONROUTE)) != ROK)
                     {
                        RETVALUE(ret);
                     }
/* DFHTA-hooks : comment : No DPC creation update required here, it is
                 taken care from inside the CalcDpcStatus function */
                     if ((ret = itMifCalcDpcStatus(dpcCb, IT_MIF_PC_NEW, 0)) 
                         != ROK)
                     {
                        RETVALUE(ret);
                     }
                  }
               }
            }
            /* if we receive DRST message for a point code for which we don't
          * have any entry in the routing table then we indicate the point
          * code status to be available to the users */

            if ((dpcCb == (ItDpcCb *) NULLP) && (event == IT_MIF_PC_RST))
            {
               event = IT_MIF_PC_AVA;
            }      
         /* check dpcCb again - could have been created above */
            if (dpcCb != (ItDpcCb *) NULLP)
            {
               /* it023.106 - Update SSNM Rx sts for owner PS */
#ifdef LITV6
               if (dpcCb->owner != NULLP)
               {
                  IT_STS_INC_RX_PS(dpcCb->owner, msgType)
               }
#endif /* LITV6 */

               wasAvail = (Bool)((dpcCb->pspDpcSt[assocId] == IT_DPC_UNAVAILABLE) ?
                              FALSE : TRUE);
               if ((event == IT_MIF_PC_CON) && 
                 (dpcCb->pspDpcSt[assocId] == IT_DPC_UNAVAILABLE))
               {
                  /* RETVALUE(ROK); */

                  if(dpcValid == TRUE)
                  {
                     RETVALUE(ROK);
                  }
                  else if (dpcAll == FALSE)
                  {
                     curDpc++;
                     if (curDpc > maxDpc)
                     {
                        allDpcs = FALSE;
                     }
                  }
                  else
                  {
                     continue;
                  }
               }

               if ((wasAvail == FALSE) && ((event == IT_MIF_PC_AVA) ||
                    (event == IT_MIF_PC_RST)))
               {
                  if (dpcCb->nwk->sgpRst[pspId] == TRUE)
                  {
                     (Void) itMifNwkEvt(IT_MIF_NWK_RESTORED, pspId, dpcCb->nwk);
                  }
               }
               if (event == IT_MIF_PC_UNA)
               {
#ifdef LIT_RTE_ALARMS
#ifndef SGVIEW
                 /* send alarm only if DPC state for the PSP changes */
                 if (dpcCb->pspDpcSt[assocId] == IT_DPC_AVAILABLE)
                 {
                   IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt));
                   itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP;
                   itGlobalCb.mgmt.hdr.msgType            = TUSTA;
                   itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS;
                   itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_RTE_UNAVAIL;
                   itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_RCV_DUNA;
                   itGlobalCb.mgmt.t.usta.s.pspId         = pspId;
                   itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc    = dpcCb->dpc;

                   (Void) itMiStaIndM(&itGlobalCb.mgmt);
                 }
#else /* SGVIEW */
                 /* send alarm only if overall DPC availability changes */
                 if (dpcCb->dpcSt == IT_DPC_AVAILABLE)
                 {
                   IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt));
                   itGlobalCb.mgmt.hdr.elmId.elmnt        = STITSG;
                   itGlobalCb.mgmt.hdr.msgType            = TUSTA;
                   itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS;
                   itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_RTE_UNAVAIL;
                   itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_RCV_DUNA;
                   itGlobalCb.mgmt.t.usta.s.sgId          = pspCb->pspCfg.sgId;
                   itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc    = dpcCb->dpc;

                   (Void) itMiStaIndM(&itGlobalCb.mgmt);
                 }
#endif /* SGVIEW */
#endif /* LIT_RTE_ALARMS */
                  dpcCb->pspDpcSt[assocId] = IT_DPC_UNAVAILABLE;
                  dpcCb->pspDpcCong[assocId] = SN_PRI0;
               }
               else if (event == IT_MIF_PC_RST)
               {
                  dpcCb->pspDpcSt[assocId] = IT_DPC_RESTRICTED;
               }
               else if (event == IT_MIF_PC_AVA)
               {
#ifdef LIT_RTE_ALARMS
#ifndef SGVIEW
                 /* send alarm only if DPC state for the PSP changes */
                 if (dpcCb->pspDpcSt[assocId] == IT_DPC_UNAVAILABLE)
                 {
                   IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt));
                   itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP;
                   itGlobalCb.mgmt.hdr.msgType            = TUSTA;
                   itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS;
                   itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_RTE_AVAIL;
                   itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_RCV_DAVA;
                   itGlobalCb.mgmt.t.usta.s.pspId         = pspId;
                   itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc    = dpcCb->dpc;

                   (Void) itMiStaIndM(&itGlobalCb.mgmt);
                 }
#else /* SGVIEW */
                 /* send alarm only if overall DPC availability changes */
                 if (dpcCb->dpcSt == IT_DPC_UNAVAILABLE)
                 {
                   IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt));
                   itGlobalCb.mgmt.hdr.elmId.elmnt        = STITSG;
                   itGlobalCb.mgmt.hdr.msgType            = TUSTA;
                   itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS;
                   itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_RTE_AVAIL;
                   itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_RCV_DAVA;
                   itGlobalCb.mgmt.t.usta.s.sgId          = pspCb->pspCfg.sgId;
                   itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc    = dpcCb->dpc;

                   (Void) itMiStaIndM(&itGlobalCb.mgmt);
                 }
#endif /* SGVIEW */
#endif /* LIT_RTE_ALARMS */
                 dpcCb->pspDpcSt[assocId] = IT_DPC_AVAILABLE;
               }

               else if ((event == IT_MIF_PC_CON) && 
                   ((dpcCb->nwk->nwkCfg.ssf == SSF_NAT) ||
                    (dpcCb->nwk->nwkCfg.dpcLen == DPC16)))
               {
                  /* National method: store congestion level and state */
                  /* only congestion level will be changed to handle 
                   * SCON and DAVA together. We will not assume DPC to 
                   * be available until and unless we get stop congestion 
                   * from SGP */

                  dpcCb->pspDpcCong[assocId] = (U8)xtraParam1;
               }
#ifdef ZV
    /* SYNC update needs to be done */
               zvRTUpd(CMPFTHA_ACTN_MOD, ZV_DPCCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) dpcCb, NULLP);
               
               /* it018.106 - addition - DFTHA Enhancement Updating tabType 
                  ZV_DPCSTA*/
               updArgs.p.regReqUpd.assocId = assocId ;
               zvRTUpd(CMPFTHA_ACTN_MOD, ZV_DPCSTA,
                       CMPFTHA_UPDTYPE_SYNC, (Void *) dpcCb, &updArgs);

#endif
               if ((dpcCb->pspDpcSt[assocId] != IT_DPC_AVAILABLE) 
                 || (dpcCb->pspDpcCong[assocId] != SN_PRI0))
               {
                  if (IT_TMRACTIVE(&dpcCb->tmrDaud) == FALSE)
                  {
                     itTcStartTimer(&dpcCb->tmrDaud, (PTR)dpcCb, IT_TMR_DAUD,
                        &itGlobalCb.genCfg.tmr.tmrDaud);
                  }
               }
#if (defined(ITASP) && defined(SGVIEW))
               for (assocIdTemp = 0; assocIdTemp < itGlobalCb.maxNmbAssoc; 
                    assocIdTemp++)
               {
                  assocCbTemp = itGlobalCb.assoc[assocIdTemp];
                  pspIdTemp = IT_ASSOC2PSPID(assocIdTemp);

                  if ((assocCbTemp != (ItAssocCb *)NULLP) && 
                      ((pspCbTemp = assocCbTemp->owner) != (ItPspCb *)NULLP) &&
                      (pspCbTemp->pspCfg.pspId != IT_LOCAL_PSPID) &&
                      (pspCbTemp->pspCfg.sgId == pspCb->pspCfg.sgId))
                  {
                     if ((assocCbTemp->assocSta->aspSt == LIT_ASP_INACTIVE) ||
                         (assocCbTemp->assocSta->aspSt == LIT_ASP_ACTIVE))
                     {
                        wasAvail = (Bool)((dpcCb->pspDpcSt[assocIdTemp] == 
                                        IT_DPC_UNAVAILABLE) ?  FALSE : TRUE);
                        if ((wasAvail == FALSE) && ((event == IT_MIF_PC_AVA) ||
                          (event == IT_MIF_PC_RST)))
                        {
                           if (dpcCb->nwk->sgpRst[pspCbTemp->pspCfg.pspId] == TRUE)
                           {
                              (Void) itMifNwkEvt(IT_MIF_NWK_RESTORED, pspIdTemp, 
                                              dpcCb->nwk);
                           }
                        }
                        dpcCb->pspDpcSt[assocIdTemp] = dpcCb->pspDpcSt[assocId];
                        dpcCb->pspDpcCong[assocIdTemp] = dpcCb->pspDpcCong[assocId];
#ifdef ZV
                        /* it018.106 - addition - DFTHA Enhancement Updating 
                           tabType ZV_DPCSTA*/
                        updArgs.p.regReqUpd.assocId = assocIdTemp ;
                        zvRTUpd(CMPFTHA_ACTN_MOD, ZV_DPCSTA,
                                CMPFTHA_UPDTYPE_SYNC, (Void *) dpcCb, &updArgs);
#endif /* ZV */                  
                     }
                  }
               } /* end of loop on PSPs */
#ifdef ZV
           /* SYNC update needs to be done */
              zvRTUpd(CMPFTHA_ACTN_MOD, ZV_DPCCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) dpcCb, NULLP);
#endif
#endif /* ITASP && SGVIEW */
            }
            /* - itMifPspEvt has to be called always for existing or
             * non-existing DPC, either dpcValid is TRUE or FALSE */
            /*if ((dpcCb != (ItDpcCb *) NULLP) || (dpcValid == TRUE))*/
            /* Pass to remote peer MIF processing */
            if ((dpcCb != (ItDpcCb *) NULLP) || (dpcValid == TRUE))
            {
               if (itMifPspEvt(event, nwkId, curDpc,
                         (U8)(((event == IT_MIF_PC_CON) || 
                               (event == IT_MIF_PC_UPU) ) ? xtraParam1 : 0),
                         (U8)((event == IT_MIF_PC_UPU) ? xtraParam2 : 0),
                         assocCb, dpcCb) != ROK)
               {
                  RETVALUE(RFAILED);
               }
            }
            /* Changes done to avoid large number of status
            indications going to the layer manager in case mask 
            is non zero with a large number */
            /* This is the case when dpcCb == NULLP , and mask is specified
               so in order to avoid large number of status indications going
               to the layer manager, send the status indication with mask
               only when we are on the last point code within the mask */
            if ((curDpc == maxDpc) &&
                (dpcValid == FALSE) &&
                (dpcAll == FALSE))
            {
               if (itMifPspEvt(event, nwkId, (dpc | (mask << 24)),
                            (U8)(((event == IT_MIF_PC_CON) || 
                                  (event == IT_MIF_PC_UPU) ) ? xtraParam1 : 0),
                            (U8)((event == IT_MIF_PC_UPU) ? xtraParam2 : 0),
                            assocCb, dpcCb) != ROK)
               {
                  RETVALUE(RFAILED);
               }
            }

#ifdef ITASP
            if (dpcCb != (ItDpcCb *) NULLP)
            {
               itLscSlsDpcEvt(event, dpcCb, assocId);
            }
#endif  /* ITASP */
            if (dpcAll == FALSE)
            {
               curDpc++;
               if (curDpc > maxDpc)
               {
                  allDpcs = FALSE;
               }
            }
         } /* end while */
      } /* end of if (itGlobalCb.genCfg.dpcLrnFlag == TRUE)  */
   /*
   1. If dpcLearning is not enabled then search is done only on configured
   dpcs, and loop functionality is performed if dpc is found.
   2. If dpcLrn is set to TRUE then only all dpcs are searched and if 
   not found not to be already created then new entries are created in 
   the dpclist.
   */
      else /* if (itGlobalCb.genCfg.dpcLrnFlag == FALSE) */
      {
         ItDpcCb *prevEnt; /* Previous DPC entry in dpcList hash list */
         /* it001.106 - Added a flag to check if the DPC cb is found
          * in following while loop. */
         Bool     dpcFound; /* TRUE if matching DPC cb is found in dpcList */

         dpcFound = FALSE;
         prevEnt  = (ItDpcCb *)NULLP;

         event = dpcEv;
         while (cmHashListGetNext(&itGlobalCb.addrTrn.dpcList, 
                (PTR) prevEnt,
                (PTR *) &dpcCb) == ROK)
         {
            prevEnt = dpcCb;
            if (((dpcCb->dpc & dpcMask) == (dpc & dpcMask)) &&
               dpcCb->nwk->nwkCfg.nwkId == nwkId)
            {
               /* it023.106 - Update SSNM Rx sts for owner PS */
#ifdef LITV6
               if (dpcCb->owner != NULLP)
               {
                  IT_STS_INC_RX_PS(dpcCb->owner, msgType)
               }
#endif /* LITV6 */

               /* it001.106 - Set the dpcFound flag to TRUE because matching
                * DPC found */
               dpcFound = TRUE;
               /* it001.106: modifications; correct assocId is used */
               wasAvail = (Bool)((dpcCb->pspDpcSt[assocId] == 
                                  IT_DPC_UNAVAILABLE)  ?  FALSE : TRUE);
               if ((event == IT_MIF_PC_CON) && 
                       (dpcCb->pspDpcSt[assocId] == IT_DPC_UNAVAILABLE))
               {
                  if (dpcValid == TRUE)
                  {
                     RETVALUE(ROK);
                  }
                  else
                  {
                     continue;
                  }
               }
               if ((wasAvail == FALSE) && ((event == IT_MIF_PC_AVA) ||
                  (event == IT_MIF_PC_RST)))
               {
                  if (dpcCb->nwk->sgpRst[pspId] == TRUE)
                  {
                     (Void) itMifNwkEvt(IT_MIF_NWK_RESTORED, pspId, dpcCb->nwk);
                  }
               }
               if (event == IT_MIF_PC_UNA)
               {
#ifdef LIT_RTE_ALARMS
#ifndef SGVIEW
               /* send alarm only if DPC state for the PSP changes */
               /* it001.106: modifications; correct assocId is used */
                  if (dpcCb->pspDpcSt[assocId] == IT_DPC_AVAILABLE)
                  {
                     IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt));
                     itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP;
                     itGlobalCb.mgmt.hdr.msgType            = TUSTA;
                     itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS;
                     itGlobalCb.mgmt.t.usta.alarm.event   = LIT_EVENT_RTE_UNAVAIL;
                     itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_RCV_DUNA;
                     itGlobalCb.mgmt.t.usta.s.pspId         = pspId;
                     itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc    = dpcCb->dpc;
                
                     (Void) itMiStaIndM(&itGlobalCb.mgmt);
                  }
#else /* SGVIEW */
                  /* send alarm only if overall DPC availability changes */
                  if (dpcCb->dpcSt == IT_DPC_AVAILABLE)
                  {
                     IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt));
                     itGlobalCb.mgmt.hdr.elmId.elmnt        = STITSG;
                     itGlobalCb.mgmt.hdr.msgType            = TUSTA;
                     itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS;
                     itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_RTE_UNAVAIL;
                     itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_RCV_DUNA;
                     itGlobalCb.mgmt.t.usta.s.sgId          = pspCb->pspCfg.sgId;
                     itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc    = dpcCb->dpc;
                
                     (Void) itMiStaIndM(&itGlobalCb.mgmt);
                  }
#endif /* SGVIEW */
#endif /* LIT_RTE_ALARMS */
                  /* it001.106: modifications; correct assocId is used */
                  dpcCb->pspDpcSt[assocId] = IT_DPC_UNAVAILABLE;
                  dpcCb->pspDpcCong[assocId] = SN_PRI0;
               }
               else if (event == IT_MIF_PC_RST)
               {
                  /* it001.106: modifications; correct assocId is used */
                  dpcCb->pspDpcSt[assocId] = IT_DPC_RESTRICTED;
               }
               else if (event == IT_MIF_PC_AVA)
               {
#ifdef LIT_RTE_ALARMS
#ifndef SGVIEW
               /* send alarm only if DPC state for the PSP changes */
                  /* it001.106: modifications; correct assocId is used */
                  if (dpcCb->pspDpcSt[assocId] == IT_DPC_UNAVAILABLE)
                  {
                     IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt));
                     itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP;
                     itGlobalCb.mgmt.hdr.msgType            = TUSTA;
                     itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS;
                     itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_RTE_AVAIL;
                     itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_RCV_DAVA;
                     itGlobalCb.mgmt.t.usta.s.pspId         = pspId;
                     itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc    = dpcCb->dpc;
                 
                     (Void) itMiStaIndM(&itGlobalCb.mgmt);
                  }
#else /* SGVIEW */
               /* send alarm only if overall DPC availability changes */
                  if (dpcCb->dpcSt == IT_DPC_UNAVAILABLE)
                  {
                     IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt));
                     itGlobalCb.mgmt.hdr.elmId.elmnt        = STITSG;
                     itGlobalCb.mgmt.hdr.msgType            = TUSTA;
                     itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS;
                     itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_RTE_AVAIL;
                     itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_RCV_DAVA;
                     itGlobalCb.mgmt.t.usta.s.sgId          = pspCb->pspCfg.sgId;
                     itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc    = dpcCb->dpc;
                 
                     (Void) itMiStaIndM(&itGlobalCb.mgmt);
                  }
#endif /* SGVIEW */
#endif /* LIT_RTE_ALARMS */
                  /* it001.106: modifications; correct assocId is used */
                  dpcCb->pspDpcSt[assocId] = IT_DPC_AVAILABLE;
               }

               else if ((event == IT_MIF_PC_CON) && 
                      ((dpcCb->nwk->nwkCfg.ssf == SSF_NAT) ||
                       (dpcCb->nwk->nwkCfg.dpcLen == DPC16)))
               {
                     /* National method: store congestion level and state */
                     /* only congestion level will be changed to handle 
                      * SCON and DAVA together. We will not assume DPC to 
                      * be available until and unless we get stop congestion 
                      * from SGP */
          
                  /* it001.106: modifications; correct assocId is used */
                  dpcCb->pspDpcCong[assocId] = (U8)xtraParam1;
               }

#ifdef ZV
               /* it018.106 - addition - DFTHA Enhancement Updating tabType 
                  ZV_DPCSTA*/
               updArgs.p.regReqUpd.assocId = assocId ;
               zvRTUpd(CMPFTHA_ACTN_MOD, ZV_DPCSTA,
                       CMPFTHA_UPDTYPE_SYNC, (Void *) dpcCb, &updArgs);
#endif /* ZV */

                  /* it001.106: modifications; correct assocId is used */
               if ((dpcCb->pspDpcSt[assocId] != IT_DPC_AVAILABLE) 
                       || (dpcCb->pspDpcCong[assocId] != SN_PRI0))
               {
                  if (IT_TMRACTIVE(&dpcCb->tmrDaud) == FALSE)
                  {
                     itTcStartTimer(&dpcCb->tmrDaud, (PTR)dpcCb, IT_TMR_DAUD,
                     &itGlobalCb.genCfg.tmr.tmrDaud);
                  }
               }
#if (defined(ITASP) && defined(SGVIEW))
               /* Update the DPC status for all other SGPs in the
                * same SG */
               for (assocIdTemp = 0; assocIdTemp < itGlobalCb.maxNmbAssoc; 
                    assocIdTemp++)
               {
                  assocCbTemp = itGlobalCb.assoc[assocIdTemp];
                  pspIdTemp = IT_ASSOC2PSPID(assocIdTemp);

                  if ((assocCbTemp != (ItAssocCb *)NULLP) && 
                      ((pspCbTemp = assocCbTemp->owner) != (ItPspCb *)NULLP) &&
                      (pspCbTemp->pspCfg.pspId != IT_LOCAL_PSPID) &&
                      (pspCbTemp->pspCfg.sgId == pspCb->pspCfg.sgId))
                  {
                     if ((assocCbTemp->assocSta->aspSt == LIT_ASP_INACTIVE) ||
                         (assocCbTemp->assocSta->aspSt == LIT_ASP_ACTIVE))
                     {
                        wasAvail = (Bool)((dpcCb->pspDpcSt[assocIdTemp] == 
                                        IT_DPC_UNAVAILABLE) ?  FALSE : TRUE);
                        if ((wasAvail == FALSE) && ((event == IT_MIF_PC_AVA) ||
                          (event == IT_MIF_PC_RST)))
                        {
                           if (dpcCb->nwk->sgpRst[pspCbTemp->pspCfg.pspId] == TRUE)
                           {
                              (Void) itMifNwkEvt(IT_MIF_NWK_RESTORED, pspIdTemp, 
                                              dpcCb->nwk);
                           }
                        }
                        dpcCb->pspDpcSt[assocIdTemp] = dpcCb->pspDpcSt[assocId];
                        dpcCb->pspDpcCong[assocIdTemp] = dpcCb->pspDpcCong[assocId];
#ifdef ZV
                        /* it018.106 - addition - DFTHA Enhancement Updating 
                           tabType ZV_DPCSTA*/
                        updArgs.p.regReqUpd.assocId = assocIdTemp;
                        zvRTUpd(CMPFTHA_ACTN_MOD, ZV_DPCSTA,
                                CMPFTHA_UPDTYPE_SYNC, (Void *) dpcCb, &updArgs);
#endif /* ZV */                        
                     }
                  }
               } /* end of loop on PSPs */
#endif /* ITASP && SGVIEW */
               /* it001.106 - itMifPspEvt and itLscSlsDpcEvt needs to be 
                * called for all the DPCs which are affected by the received 
                * SSNM message */
               if (itMifPspEvt(event, nwkId, dpc,
                           (U8)(((event == IT_MIF_PC_CON) || 
                                 (event == IT_MIF_PC_UPU) ) ? xtraParam1 : 0),
                            (U8)((event == IT_MIF_PC_UPU) ? xtraParam2 : 0),
                                  assocCb, dpcCb) != ROK)
               {
                  RETVALUE(RFAILED);
               }

               /* it001.106: modifications; correct assocId is used */
               itLscSlsDpcEvt(event, dpcCb, assocId);
            } /* if dpc matched with dpcMask & nwkId */
          
            /* it001.106 - Moved the call to itMifPspEvt and itLscSlsDpcEvt, 
             * because it should not be called for DPCs for which SSNM is 
             * not received. */
         } /* end while */
         /* it001.106 - If dpcValid is TRUE (single DPC), but this DPC is
          * not found in dpcList i.e. dpcFound is FALSE, call itMifPspEvt() */
         if ((dpcValid == TRUE) && (dpcFound == FALSE))
         {
            if (itMifPspEvt(event, nwkId, dpc,
                               (U8)(((event == IT_MIF_PC_CON) || 
                                (event == IT_MIF_PC_UPU) ) ? xtraParam1 : 0),
                               (U8)((event == IT_MIF_PC_UPU) ? xtraParam2 : 0),
                               assocCb, NULLP) != ROK)
            {
               RETVALUE(RFAILED);
            }
         }
      } /* end of itGlobalCb.genCfg.dpcLrnFlag == FALSE */
   } /* end of else if msgType IT_SSNM_DAUD */
      

   if (mask >= dpcLen)
   {
      /*
       * Special case: if we receive DUNA(*) or DAVA(*), indicate network
       * isolation or restoration
       */
      (Void) itMifNwkEvt((U8)((dpcEv == IT_MIF_PC_UNA) ?
                  IT_MIF_NWK_ISOLATED : IT_MIF_NWK_RESTORED),
                  (ItPspId) assocId, itGlobalCb.nwk[nwkId]);
   }

   RETVALUE(ROK);
} /* end of itMifSsnm */


/*
*
*       Fun:   itMifNwkEvt
*
*       Desc:  Called by MIF to indicate a network related event
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMifNwkEvt
(
U8       event,               /* event */
ItPspId  pspId,               /* PSP ID */
ItNwkCb  *nwkCb               /* Network control block */
)
#else
PUBLIC S16 itMifNwkEvt(event, pspId, nwkCb)
U8       event;               /* event */
ItPspId  pspId;               /* PSP ID */
ItNwkCb  *nwkCb;              /* Network control block */
#endif
{
   ItDpcCb  *dpcCb;           /* DPC control block */
   ItPspCb  *pspCb;           /* PSP control block */
   U16      i;                /* loop index */

   TRC2(itMifNwkEvt)

   dpcCb = (ItDpcCb *)NULLP;
   pspCb = (ItPspCb *)NULLP;
   switch (event)
   {
      case IT_MIF_NWK_ISOLATED:
         if (itGlobalCb.genCfg.tmr.tmrRestart.enb == TRUE)
         {
            nwkCb->sgpRst[pspId] = TRUE;
            nwkCb->restart = TRUE;
            /* start timer */
            itTcStartTimer(&nwkCb->tmrRestart, (PTR) nwkCb, IT_TMR_NWK_RST,
                           &itGlobalCb.genCfg.tmr.tmrRestart);
         }
         break;

      case IT_MIF_NWK_RESTORED:
      {
         /* In the meantime, a DAVA was received */
         Bool restart;        /* TRUE if any SGP restarting */
         restart              = FALSE;
         nwkCb->sgpRst[pspId] = FALSE;
         for (i = 0; i < LIT_MAX_PSP; i++)
         {
            if (nwkCb->sgpRst[i] == TRUE)
            {
               restart = TRUE;
               break;
            }
         }
         if (restart == FALSE)
         {
            /* stop timer */
            itTcStopTimer(&nwkCb->tmrRestart);
            nwkCb->restart = FALSE;
         }
         break;
      }

      case IT_MIF_RST_COMP:
      {
         nwkCb->restart = FALSE;
#ifdef ITASP
         dpcCb = (ItDpcCb *)NULLP;
         UNUSED(dpcCb);
         if (itGlobalCb.genCfg.nodeType == LIT_TYPE_ASP)
         {
            U16      j;       /* loop index */
            U16      z;       /* loop index */
            /* for each PSP that has zero DPCs active, deactivate all PSs */
            for (i = 0; i < LIT_MAX_PSP; i++)
            {
               if ((pspCb = itGlobalCb.psp[i]) != (ItPspCb *) NULLP)
               {
                  if (nwkCb->sgpRst[i] == TRUE)
                  {
                     UConnId    assocId; /* association Id */
                     ItAssocCb  *assocCb; /* association Cb */

                     /* called when restart timer times out */
                     /* For all the associations of this PSP */
                     for (z = 0; z < LIT_MAX_SEP; z++)
                     {
                        assocId = IT_PSPnENDP2ASSOC(i, z);
                        assocCb = itGlobalCb.assoc[assocId];
                        for (j = 0; j < assocCb->assocSta->nmbAct; j++)
                        {
                           ItPsCb   *psCb;      /* PS control block */
                           ItRtCtx  locRtCtx;   /* local route context */
                      
                           locRtCtx.rtCtx = assocCb->assocSta->actPs[j];
                           psCb = itPsmFindPs(assocCb->assocSta->actPs[j]);

                           if (psCb != (ItPsCb *) NULLP)
                           {
                              if (psCb->nwk == nwkCb)
                              {
                                 (Void) itPsmPsEvt(&locRtCtx, assocId,
                                                   IT_EVT_ASP_IA, 0);
                       
                              }
                           }
                        }
                     } /* end of for (z = 0; z < LIT_MAX_SEP; z++) */
                     nwkCb->sgpRst[i] = FALSE;
                  }
               }
            }
         }
#endif /* ITASP */
#ifdef ITSG
         if (itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP)
         {
            /*
             * For all DPCs in network, indicate the event to local and IP users
             * This updates the state of all local and IP users at the end of SG
             * restart
             */
            dpcCb = (ItDpcCb *) NULLP;
            while (itAtGetDpcs(nwkCb->nwkCfg.nwkId, (Dpc) 0, (Dpc) 0, &dpcCb)
                   == ROK)
            {
               U8 dpcEv;      /* DPC related event */
               dpcEv = (U8)(((dpcCb->dpcSt == IT_DPC_AVAILABLE) && 
                               (dpcCb->congLevel == SN_PRI0)) ? IT_MIF_PC_AVA :
                               ((dpcCb->dpcSt == IT_DPC_AVAILABLE) &&
                               (dpcCb->congLevel > SN_PRI0)) ? IT_MIF_PC_CON :
                               (dpcCb->dpcSt == IT_DPC_RESTRICTED) ? IT_MIF_PC_RST: 
                                IT_MIF_PC_UNA);

               if (dpcEv == IT_MIF_PC_RST && dpcCb->congLevel > SN_PRI0)
               {
                  (Void) itMifDpcEvt(FALSE, (UConnId) NULLD, IT_MIF_RST, 
                                  IT_MIF_PC_CON, nwkCb->nwkCfg.nwkId,
                                  dpcCb->dpc, 0,
                                  (U8)(dpcCb->congLevel),
                                  0, dpcCb);
               }
               if (dpcCb->type == IT_DPCCB_SS7)
               {
                  (Void) itMifDpcEvt(FALSE, (UConnId) NULLD, IT_MIF_RST, 
                                  dpcEv, nwkCb->nwkCfg.nwkId,
                                  dpcCb->dpc, 0,
                                  (U8)((dpcEv == IT_MIF_PC_CON) ?
                                  dpcCb->congLevel : 0),
                                  0, dpcCb);
               }
            }

         }
#endif /* ITSG */
         break;
      }

      default:
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of itMifNwkEvt */


/*
*
*       Fun:   itMifPspEvt
*
*       Desc:  Called by MIF or PSM when a remote PSP-related event occurs
*              Performs the management interworking function for the
*              change of status.
*
*       Ret:
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMifPspEvt
(
U8       event,               /* internal event code */
U8       nwkId,               /* network context ID */
Dpc      dpc,                 /* affected point code */
U8       congLevel,           /* congestion level */
SrvInfo  userPart,            /* user part identifier */
ItAssocCb *assocCb,           /* remote Assoc control block */
ItDpcCb  *dpcCb               /* DPC control block */
)
#else
PUBLIC S16 itMifPspEvt(event, nwkId, dpc, congLevel, userPart, assocCb, dpcCb)
U8       event;               /* internal event code */
U8       nwkId;               /* network context ID */
Dpc      dpc;                 /* affected point code */
U8       congLevel;           /* congestion level */
SrvInfo  userPart;            /* user part identifier */
ItAssocCb *assocCb;           /* remote Assoc control block */
ItDpcCb  *dpcCb;              /* DPC control block */
#endif
{
   Bool     dpcAll;                   /* TRUE if all DPCs considered */
   Bool     dpcDone;                  /* TRUE when DPC loop done */
   S16      ret;                      /* return value */
   U16      i;                        /* loop index */
   ItPsCb   *psCb = (ItPsCb *) NULLP; /* PS control block */
   U16      count;                    /* count of PSs in network */
   ItPspCb  *pspCb;                   /* PSP control block */


   TRC2(itMifPspEvt)
#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, "itMifPspEvt(event(%d), \
          nwkId(%d), dpc(%d), congLevel(%d), userPart, assocCb(%d), \
          dpcCb(%d))\n", event, nwkId, dpc, congLevel,
          (assocCb != (ItAssocCb *)NULLP) ? assocCb->assocId : 0,
          (dpcCb != (ItDpcCb *)NULLP) ? dpcCb->dpc : 0));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, "itMifPspEvt(event(%d), \
          nwkId(%d), dpc(%ld), congLevel(%d), userPart, assocCb(%ld), \
          dpcCb(%ld))\n", event, nwkId, dpc, congLevel,
          (assocCb != (ItAssocCb *)NULLP) ? assocCb->assocId : 0,
          (dpcCb != (ItDpcCb *)NULLP) ? dpcCb->dpc : 0));
#endif
   pspCb = assocCb->owner;
   switch (event)
   {
      /* the following 4 cases fall through */
      case IT_MIF_PC_RST:
      case IT_MIF_PC_UNA:
      case IT_MIF_PC_AVA:
      case IT_MIF_PC_CON:
      case IT_MIF_PC_UPU:
         /* Special behavior if there is no stored DPC state */
         if (dpcCb == (ItDpcCb *)NULLP)
         {
            /* Distribute event to local users */
            if (assocCb->assocSta->aspSt != LIT_ASP_DOWN)
            {
               RETVALUE(itMifDpcEvt(TRUE, assocCb->assocId, 
                  (U8)((itGlobalCb.genCfg.nodeType == LIT_TYPE_ASP) ?
                  IT_MIF_SGP : IT_MIF_SPMC),
                  event, nwkId, dpc, (Dpc)0, congLevel, userPart,
                  (ItDpcCb *)NULLP));
            }
            RETVALUE(ROK);
         }
         dpcAll = FALSE;
         break;

      case IT_MIF_ASP_CONG:
         dpcAll = TRUE;
         break;

      case IT_MIF_ASP_ACTIVE:
      {
#ifdef ITSG
         /*
          * May need to download DPC status to an ASP for a particular network.
          * Count up the number of active  PSs in the network.
          */
         count = 0;
         /* Initialize psCb */
         psCb = (ItPsCb *) NULLP;
         for (i = 0; i < assocCb->assocSta->nmbAct; i++)
         {
            psCb = itPsmFindPs(assocCb->assocSta->actPs[i]);
            if (psCb != (ItPsCb *) NULLP)
            {
               if (psCb->nwk->nwkCfg.nwkId == nwkId)
               {
                  count++;
               }
            }
         }

         /*
          * At SGP: if the event was ASP-ACTIVE, and there is now exactly 1 PS
          * active in this network, we need to send DPC info for the network
          * to the newly-active client ASP
          */
         if ((event == IT_MIF_ASP_ACTIVE) && (count == 1) &&
             (itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP))
         {
            /* this event marks the activation of the 1st PS in the network */

            if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_ASP) ||
                (pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP))
            {
               dpcCb = (ItDpcCb *) NULLP;
               while (itAtGetDpcs(nwkId, (Dpc) 0, (Dpc) 0, &dpcCb) == ROK)
               {
                  Bool     spmcFound;  /* TRUE if SPMC found */
                  U16      msgType;    /* M3UA message type */
                  spmcFound   = FALSE;
                  if ((dpcCb->dpcSt != IT_DPC_AVAILABLE) ||
                        (dpcCb->congLevel > SN_PRI0))
                  {
                     for (i = 0;
                          (i < assocCb->nmbPs) && (spmcFound == FALSE);
                          i++)
                     {
                        psCb = assocCb->ps[i];
                        /* Is the DPC represented in the PSP's PS list? */
                        if (psCb->spmc == dpcCb)
                        {
                           spmcFound = TRUE;
                        }
                     }
                     /*
                      * This DPC is only relevant to the ASP if the ASP does not
                      * support the DPC in one of its ASs
                      */
                     if (spmcFound == FALSE)
                     {
                        msgType = (U16)(((dpcCb->dpcSt == IT_DPC_AVAILABLE) && 
                                         (dpcCb->congLevel > SN_PRI0)) ? 
                                          IT_SSNM_SCON :
                                          (dpcCb->dpcSt == IT_DPC_RESTRICTED) ?
                                           IT_SSNM_DRST : IT_SSNM_DUNA);

                        if ((msgType == IT_SSNM_DRST) && 
                             (dpcCb->congLevel > SN_PRI0))
                        {
                           itMmhSsnm(assocCb, IT_SSNM_SCON, nwkId,
                                     dpcCb->dpc, 0, (Txt *)NULLP,
                                     (U16)(dpcCb->congLevel), 0);
                        }

                        if ((ret = itMmhSsnm(assocCb, msgType, nwkId,
                           dpcCb->dpc, 0, (Txt *)NULLP,
                           (U16)((msgType == IT_SSNM_SCON) ?
                                 dpcCb->congLevel : 0), 0)) != ROK)
                        {
                           RETVALUE(ret);
                        }
                     }
                  } /* end if DPC not available */
               } /* end while itAtGetDpcs */
            } /* end if client */
         }
#endif /* ITSG */
#ifdef ITASP
        /* ASP & IPSP */ 
        /* if a large number of DPCs are configured then a large
        delay is added in activation due to repeated call to 
        itMifCalcDpcStatus function which has already been called
        to handle DPCs other than Non routing ones. and the status 
        of Non routing DPCs can be taken care. outside this function
        or the same thing will be repeated multiple times. 
        Note: Non routing DPCs are only meaningful in ASP-SG scenario 
        SO we can safely exit in this step */ 

        if (itGlobalCb.genCfg.nodeType != LIT_TYPE_SGP)
        {
           RETVALUE(ROK);
        }
#endif /* ITASP */

         dpcAll = TRUE;
         break; 
      }
      /* next 3 cases fall through */
      case IT_MIF_ASP_INACTIVE:
      case IT_MIF_ASP_UP:
#if (defined(ITASP) && defined(SGVIEW))
      /* - If the peer is an SGP -
       * IT_MIF_ASP_INACTIVE : If the peer is an SGP, do not reset the 
       * DPC status to Available when ASP becomes Inactive.
       * IT_MIF_ASP_UP : If this is not the first SGP being added in the SG,
       * synchronize the DPC status. */
      if ((itGlobalCb.genCfg.nodeType == LIT_TYPE_ASP) &&
          (pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP))
      {
         ItAssocCb  *assocCbTemp;     /* remote Assoc control block */
         UConnId    assocIdTemp;      /* Assoc ID */
#ifdef ZV
         /* it020.106 - Define updArgs. */
         ZvUpdSpecParams updArgs;
#endif /* ZV */

         if (event == IT_MIF_ASP_INACTIVE)
         {
            RETVALUE(ROK);
         }
         /* else proceed as follows for event IT_MIF_ASP_UP */
         for (assocIdTemp = 0; assocIdTemp < itGlobalCb.maxNmbAssoc; 
              assocIdTemp++)
         {
            /* if same PSP then continue to next PSP */
            if (assocIdTemp == assocCb->assocId)
               continue;

            assocCbTemp = itGlobalCb.assoc[assocIdTemp];
            if ((assocCbTemp != (ItAssocCb *)NULLP) &&
                (assocCbTemp->owner  != (ItPspCb *)NULLP) &&
                (assocCbTemp->owner->pspCfg.pspId != IT_LOCAL_PSPID) &&
                (assocCbTemp->owner->pspCfg.sgId == pspCb->pspCfg.sgId))
            {
               if ((assocCbTemp->assocSta->aspSt == LIT_ASP_INACTIVE) ||
                   (assocCbTemp->assocSta->aspSt == LIT_ASP_ACTIVE))
               {
                  break;
               }
            }
         } /* end of for */

         if (assocIdTemp != itGlobalCb.maxNmbAssoc)
         {
            dpcDone = FALSE;
            /* Get first DPC in hash list */
            if (cmHashListGetNext(&itGlobalCb.addrTrn.dpcList, (PTR) NULLP,
               (PTR *)&dpcCb) != ROK)
            {
               dpcDone = TRUE;
            }
            while (dpcDone == FALSE)
            {
               /* no active  PSs left in the network, reset status */
               dpcCb->pspDpcSt[assocCb->assocId] = 
                                                dpcCb->pspDpcSt[assocIdTemp];
               dpcCb->pspDpcCong[assocCb->assocId] = 
                                                dpcCb->pspDpcCong[assocIdTemp];
  /* DFTHA-hook */
#ifdef ZV
               /* it018.106 - addition - DFTHA Enhancement Updating tabType 
                  ZV_DPCSTA*/
               updArgs.p.regReqUpd.assocId = assocCb->assocId ;
               zvRTUpd(CMPFTHA_ACTN_MOD, ZV_DPCSTA,
                       CMPFTHA_UPDTYPE_SYNC, (Void *) dpcCb, &updArgs);

               /* update required for dpcCb->pspDpcSt state change */ 
               zvRTUpd(CMPFTHA_ACTN_MOD, ZV_DPCCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *)dpcCb, NULLP);
#endif
               /* Get next DPC in hash list */
               if (cmHashListGetNext(&itGlobalCb.addrTrn.dpcList, (PTR)dpcCb,
                  (PTR *)&dpcCb) != ROK)
               {
                  dpcDone = TRUE;
               }
            } /* end while !dpcDone */
            RETVALUE(ROK);
         }
         /* else if assocIdTemp is not valid proceed to the handling in 
          * following case statement */
      }
#endif /* ITASP && SGVIEW */
      case IT_MIF_ASP_DOWN: /* Fall through */
      {
         dpcDone = FALSE;
         /* Initialize psCb */
         psCb = (ItPsCb *) NULLP;
         /* Get first DPC in hash list */
         if (cmHashListGetNext(&itGlobalCb.addrTrn.dpcList, (PTR) NULLP,
            (PTR *)&dpcCb) != ROK)
         {
            dpcDone = TRUE;
         }
         while (dpcDone == FALSE)
         {
            /* it013.106 - Check dpcCb nwkId if event is IT_MIF_ASP_INACTIVE.*/
            if (((event == IT_MIF_ASP_INACTIVE) && 
                 (dpcCb->nwk->nwkCfg.nwkId == nwkId)) ||
                (event != IT_MIF_ASP_INACTIVE))
            {
            /* count the number of PSs related to each DPC */
            count = 0;
            for (i = 0; i < assocCb->assocSta->nmbAct; i++)
            {
               psCb = itPsmFindPs(assocCb->assocSta->actPs[i]);
               if (psCb != (ItPsCb *) NULLP)
               {
                  if (psCb->nwk == dpcCb->nwk)
                  {
                     count++;
                     break;
                  }
               }
            }

            if (count == 0)
            {
               /* no active  PSs left in the network, reset status */
               dpcCb->pspDpcSt[assocCb->assocId] = IT_DPC_AVAILABLE;
               dpcCb->pspDpcCong[assocCb->assocId] = SN_PRI0;
  /* DFTHA-hook */
#ifdef ZV
               /* update required for dpcCb->pspDpcSt state change */ 
               zvRTUpd(CMPFTHA_ACTN_MOD, ZV_DPCCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *)dpcCb, NULLP);
#endif
            }
            }
            /* Get next DPC in hash list */
            if (cmHashListGetNext(&itGlobalCb.addrTrn.dpcList, (PTR)dpcCb,
               (PTR *)&dpcCb) != ROK)
            {
               dpcDone = TRUE;
               break;
            }
         } /* end while !dpcDone */
         RETVALUE(ROK);
      }
      default:
         RETVALUE(RFAILED);
   } /* end switch event */

   dpcDone = FALSE;
   if (dpcAll == TRUE)
   {
      /* Get first DPC in hash list */
      if (cmHashListGetNext(&itGlobalCb.addrTrn.dpcList, (PTR) NULLP,
         (PTR *)&dpcCb) != ROK)
      {
         dpcDone = TRUE;
      }
   }
   /*
    * For the set of DPCs (one DPC or all DPCs), recalculate the overall
    * accessibility state and report any change of state to rest of system
    */
   while (dpcDone == FALSE)
   {
      if ((dpcCb->type == IT_DPCCB_SPMC) || (dpcCb->type == IT_DPCCB_NONROUTE))
      {
         U8    oldDpcSt;   /* old DPC state */
         U8    oldDpcCong; /* old DPC congestion level */
         U8    dpcEv;      /* DPC related event */
         Bool  dpcFwd;     /* TRUE if event to be forwarded */
         dpcFwd   = FALSE;
         dpcEv    = 0;
         /* Evaluate overall accessibility/congestion of the DPC */
         oldDpcSt    = dpcCb->dpcSt;
         oldDpcCong  = dpcCb->congLevel;
         itMifCalcDpcStatus(dpcCb, IT_MIF_PC_SUM, 0);

         if (dpcCb->congLevel != oldDpcCong)
         {
            dpcEv = IT_MIF_PC_CON;
            dpcFwd = TRUE;
         }
         
         else if (dpcCb->dpcSt != oldDpcSt) 
         {
            switch (dpcCb->dpcSt)
            {
               case IT_DPC_AVAILABLE:
                  dpcEv = IT_MIF_PC_AVA;
                  break;
               case IT_DPC_UNAVAILABLE:
                  dpcEv = IT_MIF_PC_UNA;
                  break;
               default:
                  RETVALUE(RFAILED);
            }
            dpcFwd = TRUE;
         }
         /* stateless forwarding of UPU/CON */
         if ((event == IT_MIF_PC_UPU) ||
            ((event == IT_MIF_PC_CON) &&
             ((dpcCb->nwk->nwkCfg.ssf != SSF_NAT) &&
              (dpcCb->nwk->nwkCfg.dpcLen != DPC16))))
         {
            dpcEv    = event;
            dpcFwd   = TRUE;
         }
         if ((dpcFwd == TRUE) && (event == IT_MIF_PC_RST))
         {
            dpcEv = IT_MIF_PC_RST;
         }
         
         /* if there is information to forward to users, do so */
         if (dpcFwd == TRUE)
         {
            if ((dpcCb->type == IT_DPCCB_NONROUTE) ||
              ((dpcCb->owner != NULL) && (dpcCb->owner->psCfg.lclFlag != TRUE)))
            {
               if ((ret = itMifDpcEvt(TRUE, assocCb->assocId, 
                  (U8)((itGlobalCb.genCfg.nodeType == LIT_TYPE_ASP) ?
                  IT_MIF_SGP : IT_MIF_SPMC),
                  dpcEv, dpcCb->nwk->nwkCfg.nwkId, dpcCb->dpc, (Dpc)0,
                  (U8)((dpcEv == IT_MIF_PC_CON) ? dpcCb->congLevel :
                       ((event == IT_MIF_PC_UPU) ? congLevel : 0)),
                  (U8)((dpcEv == IT_MIF_PC_UPU) ? userPart : (SrvInfo)0),
                  dpcCb)) != ROK)
               {
                  RETVALUE(ret);
               }
            }
         }
      }
      if (dpcAll == FALSE)
      {
         dpcDone = TRUE;
      }
      else
      {
         /* Get next DPC in hash list */
         if (cmHashListGetNext(&itGlobalCb.addrTrn.dpcList, (PTR)dpcCb,
            (PTR *)&dpcCb) != ROK)
         {
            dpcDone = TRUE;
         }
      }
   } /* end while !dpcDone */

   RETVALUE(ROK);
} /* end of itMifPspEvt */


/*
*
*       Fun:   itMifUserEvt
*
*       Desc:  Called by UI when a user binds or unbinds
*              Performs the management interworking function for the
*              change of status.
*
*       Ret:
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMifUserEvt
(
U8       event,               /* internal event code */
ItNSapCb *nSapCb              /* NSAP control block */
)
#else
PUBLIC S16 itMifUserEvt(event, nSapCb)
U8       event;               /* internal event code */
ItNSapCb *nSapCb;             /* NSAP control block */
#endif
{
   ItDpcCb  *dpcCb;           /* DPC control block */
   S16      ret;              /* return value */
   U8       ss7DpcEv;         /* DPC related event */
   U8       source;           /* Source of event */

   TRC2(itMifUserEvt)

   /* Search list of DPCs in this network */
   ss7DpcEv = IT_MIF_PC_SUM;
   dpcCb = (ItDpcCb *) NULLP;
   source = IT_MIF_USER;
   
#if ( defined (ITSG) && defined (SNTIWF) )
   if ((itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP) && 
       (event == IT_MIF_MTP3_NOTPRSNT))
   {
      ss7DpcEv = IT_MIF_PC_UNA;
      source = IT_MIF_SS7;
   }
   else if ((itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP) && 
            (event == IT_MIF_MTP3_PRSNT))
   {
      ss7DpcEv = IT_MIF_PC_AVA;
      source = IT_MIF_SS7;
   }
#endif

   while (itAtGetDpcs(nSapCb->sntCfg.nwkId, (Dpc) 0, (Dpc) 0, &dpcCb) == ROK)
   {
      /* Pass event on */
      U8          oldDpcSt;      /* old DPC state */
      U8          oldDpcCong;    /* old DPC congestion level */
      Bool        wasAvail;      /* TRUE if DPC was available */
      Bool        isAvail;       /* TRUE if DPC is now available */
      U16         idx;           /* cluster index */
      U8          rtType;        /* route type */
      ItPsCb      *owner;     /* route owner */
      ItRouteCb   *routeCb;      /* route CB */
      Bool        done;          /* TRUE when loop done */

      oldDpcSt    = dpcCb->dpcSt;
      oldDpcCong  = dpcCb->congLevel;
      done     = FALSE;
      /* Check if PC is split between SS7 and local IP domain */
      if ((dpcCb->type == IT_DPCCB_SS7) && (source == IT_MIF_SS7))
      {
         idx      = 0;
         routeCb  = (ItRouteCb *) NULLP;   
         while (((ret = 
            itMifGetNextInCluster(dpcCb, &rtType, &owner, &idx, &routeCb)) 
            == ROK) && (done == FALSE))
         {
            if (rtType == LIT_RTTYPE_LOCAL)
            {
               done = TRUE;
            }
         }
      } /* end if dpcCb->type == IT_DPCCB_SS7 */
      if (done == FALSE)
      {
         /* Evaluate overall accessibility/congestion of the SPMC */
         if ((ret = itMifCalcDpcStatus(dpcCb, 
                                       (U8) ((dpcCb->type == IT_DPCCB_SS7) ? 
                                       ss7DpcEv : IT_MIF_PC_SUM), 0)) != ROK)
         {
            RETVALUE(ret);
         }
         if (source == IT_MIF_SS7)
         {
            if ((ret = itMifCalcDpcStatus(dpcCb, IT_MIF_PC_SUM, 0)) != ROK)
      
            {
               RETVALUE(ret);
            }
         }
         /* If DPC availability state has changed, forward to rest of system */
         wasAvail = (Bool)((oldDpcSt == IT_DPC_UNAVAILABLE) ? FALSE : TRUE);
         isAvail  = (Bool)((dpcCb->dpcSt == IT_DPC_UNAVAILABLE) ? FALSE : TRUE);
         if ((wasAvail != isAvail) ||
            ((event == IT_MIF_AS_CONG) && (dpcCb->congLevel != oldDpcCong)))
         {
            U8 dpcEv;         /* DPC related event */
            if (wasAvail != isAvail)
            {
               dpcEv = (U8)((isAvail == TRUE) ? IT_MIF_PC_AVA : IT_MIF_PC_UNA);
            }
            else
            {
               dpcEv = IT_MIF_PC_CON;
            }
            if ((ret = itMifDpcEvt(FALSE, (UConnId) NULLD, source, dpcEv, 
                                   dpcCb->nwk->nwkCfg.nwkId, dpcCb->dpc, 0,
               (U8)((dpcEv == IT_MIF_PC_CON) ? dpcCb->congLevel : 0),
               (SrvInfo)0, dpcCb)) != ROK)
            {
               RETVALUE(ret);
            }
         }
         if (event == IT_MIF_USER_UP)
         {
            /* Indicate status of point code to user if not available */
            Status   status;
            Bool     skip;       /* TRUE if we must skip this NSAP */
            idx      = 0;
            skip     = FALSE;
            routeCb  = (ItRouteCb *) NULLP;   
            status = (Status)((((dpcCb->dpcSt == IT_DPC_AVAILABLE) &&
            (dpcCb->congLevel == SN_PRI0))||
            (dpcCb->dpcSt == IT_DPC_RESTRICTED && 
            dpcCb->congLevel == SN_PRI0)) ? SN_RESUME :
            (((dpcCb->dpcSt == IT_DPC_AVAILABLE) && 
            (dpcCb->congLevel > SN_PRI0)) ? SN_CONG : SN_PAUSE));
            /* check for routes to this NSAP for DPC - if found, skip */
            while ((ret = itMifGetNextInCluster(dpcCb, &rtType, &owner,
                                                &idx, &routeCb)) == ROK)
            {
               if (routeCb == (ItRouteCb *) NULLP)
               {
                  if (nSapCb == dpcCb->nSap)
                  {
                     skip = TRUE;
                     break;
                  }
                  if ((dpcCb->owner != NULL) && 
                                  (dpcCb->owner->psCfg.lclFlag == TRUE))
                  {
                     skip = TRUE;
                     break;
                  }
               }
               else
               {
                  if ((routeCb->rteCfg.nSapIdPres == TRUE) &&
                      (routeCb->rteCfg.nSapId == nSapCb->sntCfg.sapId))
                  {
                     skip = TRUE;
                     break;
                  }
                  else if ((routeCb->owner != (ItPsCb *)NULLP) &&
                                  (routeCb->owner->psCfg.lclFlag == TRUE))
                  {
                     skip = TRUE;
                     break;
                  }
               }
            } /* end while */
            if (skip == FALSE)
            {
               /* don't send DPC info to local users during nwk restart */
               if (nSapCb->nwk->restart == FALSE)
               {
#ifdef ZV_DFTHA
                  if ((zvCb.genCfg.distEnv == TRUE) &&
                      (itProtState == CMPFTHA_STATE_ACTIVE))
                  {
                     if (status == SN_RESUME)
                     {
                         itGlobalCb.primQueFlg = TRUE;
                         /* No need of checking (itGlobalCb.primQueFlg)  */
                         itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].event =
                                                          EVTSNTSTAIND;
                         itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].p.\
                                 sntStaInd.status = status;
                         itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].p.\
                                 sntStaInd.spId = nSapCb->sntSta.lclSapId;
                         itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].p.\
                                 sntStaInd.aPc = dpcCb->dpc;
                         itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].p.\
                                 sntStaInd.congLevel =  0; 
                         itGlobalCb.l4Lst.nmbPrims++;
#if (ERRCLASS & ERRCLS_DEBUG)
                         if (itGlobalCb.l4Lst.nmbPrims > 
                                               itGlobalCb.genCfg.maxNmbDpcEnt)
                         {
                            ITLOGERROR(ERRCLS_DEBUG, EIT176, 
                                   (ErrVal) itGlobalCb.l4Lst.nmbPrims,
                      "   More primitives to be queued than max allowd. Change logic!");
                         }
#endif
                     }
                  }
                  else
#endif /* ZV_DFTHA */
                  (Void) ItUiSntStaInd(&nSapCb->pst,
                     nSapCb->sntSta.remSapId, dpcCb->dpc, status,
                     (U8)((status == SN_CONG) ? dpcCb->congLevel : 
                          (Priority) 0));
                  IT_STS_INC_MTP3_TX_STA(nSapCb, status);
               }
            }
         } /* end if event == IT_MIF_USER_UP */
      }/* end if (done == FALSE) - PC is split between local and SS7 users */
   } /* end while itAtGetDpcs */
#ifdef ITSG
   if ((nSapCb->nwk->restart == TRUE) && (nSapCb->sntCfg.suType != LIT_SP_MTP3))
   {
      /* Let this newly-bound user know that a restart is in progress */
      (Void) ItUiSntStaInd(&nSapCb->pst,
         nSapCb->sntSta.remSapId, 0, SN_RSTBEG, (Priority) 0);
      IT_STS_INC_MTP3_TX(nSapCb, rstBeg)
   }
#endif

   RETVALUE(ROK);
} /* end of itMifUserEvt */


/*
*
*       Fun:   itMifPsEvt
*
*       Desc:  Called by PSM and MIF when an PS-related event occurs
*              Performs the management interworking function for the
*              change of status.
*
*       Ret:
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMifPsEvt
(
UConnId  assocId,             /* Assoc ID */
U8       event,               /* internal event code */
Dpc      opc,                 /* originating point code */
ItPsCb   *psCb                /* PS control block */
)
#else
PUBLIC S16 itMifPsEvt(assocId, event, opc, psCb)
UConnId  assocId;             /* Assoc ID */
U8       event;               /* internal event code */
Dpc      opc;                 /* originating point code */
ItPsCb   *psCb;               /* PS control block */
#endif
{
   ItDpcCb  *dpcCb;           /* DPC control block */
   Bool     isAvail;          /* TRUE if DPC is now available */
   Bool     wasAvail;         /* TRUE if DPC was available */
   S16      ret;              /* return value */

   TRC2(itMifPsEvt)
#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
                        "itMifPsEvt(event(%d), opc(%d), psCb(%d))\n",
                        event, opc,
                        (psCb == (ItPsCb *)NULLP) ? 0 : psCb->psCfg.psId));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
                        "itMifPsEvt(event(%d), opc(%ld), psCb(%ld))\n",
                        event, opc,
                        (psCb == (ItPsCb *)NULLP) ? 0 : psCb->psCfg.psId));
#endif
   dpcCb = psCb->spmc;
   /*
    * A PS without fully-specified DPC has no effect on DPC management
    * interworking and will have a NULL spmc field
    */
   if (dpcCb == (ItDpcCb *)NULLP)
   {
      RETVALUE(ROK);
   }
                                 
   switch (event)
   {
      /* the following 3 cases fall through */
      case IT_MIF_AS_ACTIVE:
      case IT_MIF_AS_INACTIVE:
      case IT_MIF_AS_CONG:
      case IT_MIF_AS_DOWN:
      {
         U8 oldDpcSt;         /* old DPC state */
         U8 oldDpcCong;       /* old DPC congestion level */
         oldDpcSt    = dpcCb->dpcSt;
         oldDpcCong  = dpcCb->congLevel;
         /* Evaluate overall accessibility/congestion of the SPMC */
         if ((ret = itMifCalcDpcStatus(dpcCb, IT_MIF_PC_SUM, 0)) != ROK)
         {
            RETVALUE(ret);
         }
         /* If SPMC availability state has changed, forward to rest of system */
         wasAvail = (Bool)((oldDpcSt == IT_DPC_UNAVAILABLE) ? FALSE : TRUE);
         isAvail  = (Bool)((dpcCb->dpcSt == IT_DPC_UNAVAILABLE) ? FALSE : TRUE);
         /* - The check for IT_MIF_AS_CONG event is removed, because
          * DPC congestion level can also change because of PS state change.
          * Since the changed congestion level should only be updated if DPC
          * is available, the check for isAvail to be TRUE is added */
         if ((wasAvail != isAvail) ||
            ((dpcCb->congLevel != oldDpcCong) && (isAvail == TRUE)))
         {
            U8 dpcEv;         /* DPC related event */
            if (wasAvail != isAvail)
            {
               dpcEv = (U8)((isAvail == TRUE) ? IT_MIF_PC_AVA : IT_MIF_PC_UNA);
            }
            else
            {
               dpcEv = IT_MIF_PC_CON;
            }
            if (psCb->psCfg.lclFlag != TRUE)
            {
               if ((ret = itMifDpcEvt(TRUE, assocId, IT_MIF_SPMC, 
                   dpcEv, dpcCb->nwk->nwkCfg.nwkId, dpcCb->dpc, opc,
                  (U8)((dpcEv == IT_MIF_PC_CON) ? dpcCb->congLevel : 0),
                  (SrvInfo)0, dpcCb)) != ROK)
               {
                  RETVALUE(ret);
               }
            }
         }
         break;
      }
      default:
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of itMifPsEvt */


/*
*
*       Fun:   itMifCongEvt
*
*       Desc:  Called by MIF when a local congestion event occurs
*              Performs the management interworking function for the
*              change of status. Reports congestion only to those point codes
*              or users that actually have messages queued
*
*       Ret:
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMifCongEvt
(
ItAssocCb   *assocCb,         /* association CB */
U8          congLevel,        /* congestion level */
ItMupMsg    *msg              /* affected message */
)
#else
PUBLIC S16 itMifCongEvt(assocCb, congLevel, msg)
ItAssocCb   *assocCb;         /* association CB */
U8          congLevel;        /* congestion level */
ItMupMsg    *msg;             /* affected message */
#endif
{
   U16      i;                /* loop index */
   U16      j;                /* loop index */
   U16      k;                /* loop index */
   S16      ret;              /* return value */
   ItPspCb  *pspCb;           /* PSP control block */
   ItPsCb   *psCb;            /* PS control block */
   U8       oldCong;          /* old congestion level */
   U8       tmpCong;          /* temp congestion level */
#ifdef ZV_DFTHA
   ZvUpdSpecParams updSpec;
#endif


   TRC2(itMifCongEvt)

   UNUSED(msg);

   pspCb = assocCb->owner;

      /* National method or unknown (no originating message) */

   /* Handle PSP congestion */
   for (i = 0; i < assocCb->nmbPs; i++)
   {
      psCb = assocCb->ps[i];
      /* Local PS congestion level and the congestion level
       * of corresponding local DPC should not be modified */
      if ((psCb->psCfg.lclFlag == FALSE) &&
          ((psCb->nwk->nwkCfg.ssf == SSF_NAT) ||
          (psCb->nwk->nwkCfg.dpcLen == DPC16)))
      {
         /* National method - update PS and SPMC congestion */
         oldCong           = psCb->congLevel;
         psCb->congLevel   = SN_PRI0;
         /* Find highest congestion level of PS's active assocs */
         /* PS congestion level is not per EndP basis but it is unique for
            all supported EndPoints */
         for (k = 0; k < LIT_MAX_SEP; k++) 
         {
            for (j = 0; j < psCb->psSta.psStaEndp[k].nmbAct; j++)
            {
               UConnId tmpAssocId; /* temporary Assoc ID */
               tmpAssocId = IT_PSPnENDP2ASSOC(psCb->psSta.psStaEndp[k].\
                                              actPsp[j], k);
               if (IT_ASSOC2PSPID(tmpAssocId) != IT_LOCAL_PSPID)
               {
                  tmpCong = IT_CONGPRIOR(cmLListLen(&itGlobalCb.\
                                         assoc[tmpAssocId]->congQ));
                  if (tmpCong > psCb->congLevel)
                  {
                     psCb->congLevel = tmpCong;
                  }
               }
            }
         }
         if (psCb->congLevel != oldCong)
         {
/* DFTHA-hook */
#ifdef ZV
#ifdef ZV_DFTHA
            /* Reverse update for PS congestion level change */
            if (itProtState != CMPFTHA_STATE_ACTIVE)
            {
               updSpec.p.revUpd.updType = ZV_REV_ACT_PSCONG;
               updSpec.p.revUpd.assocId = assocCb->assocId;
               updSpec.p.revUpd.r.cong.psId = psCb->psCfg.psId;
               updSpec.p.revUpd.r.cong.congLvl = psCb->congLevel;
               zvPackNSendRevUpd(ZV_REV_ACT_PSCONG, &updSpec);
            }
            else
#endif
            {
               /* RT update for PS Congestion level */
               zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSCB,
                         CMPFTHA_UPDTYPE_NORMAL, (Void *) psCb, NULLP);
            }
#endif
            /* Update the management cluster status */
            if ((ret = itMifPsEvt(assocCb->assocId, IT_MIF_AS_CONG, 
                                  (Dpc) 0, psCb))
               != ROK)
            {
               RETVALUE(ret);
            }
         }
      } /* end if national method */
   } /* end for */

   /* Handle remote peer congestion */
   if ((ret = itMifPspEvt(IT_MIF_ASP_CONG, 0, (Dpc) 0, congLevel, 0, assocCb,
      (ItDpcCb *)NULLP)) != ROK)
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of itMifCongEvt */


/*
*
*       Fun:   itMifDpcEvt
*
*       Desc:  Called by MIF when a DPC-related event occurs.
*              Distributes the event to local and remote users
*
*       Ret:
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMifDpcEvt
(
Bool     assocIdPres,         /* Is there a assocId present? */
UConnId  assocId,             /* Source assocId id */
U8       source,              /* internal source code */
U8       event,               /* internal event code */
U8       nwkId,               /* network context ID */
Dpc      aPc,                 /* affected point code */
Dpc      dpc,                 /* destination point code */
U8       congLevel,           /* congestion level */
SrvInfo  srvInfo,             /* service information octet */
ItDpcCb  *dpcCb               /* DPC control block */
)
#else
PUBLIC S16 itMifDpcEvt(assocIdPres, assocId,  source, event, nwkId, aPc, 
                       dpc, congLevel, srvInfo, dpcCb)
Bool     assocIdPres;         /* Is there a assocId present? */
UConnId  assocId;             /* Source assocId id */
U8       source;              /* internal source code */
U8       event;               /* internal event code */
U8       nwkId;               /* network context ID */
Dpc      aPc;                 /* affected point code */
Dpc      dpc;                 /* destination point code */
U8       congLevel;           /* congestion level */
SrvInfo  srvInfo;             /* service information octet */
ItDpcCb  *dpcCb;              /* DPC control block */
#endif
{
   SpId     spId;             /* service provider ID */
   ItNSapCb *nSapCb;          /* upper SAP CB */
   ItNwkCb  *nwkCb;           /* network CB */
   U32      msgType;          /* message type */
   U8       status;           /* DPC status */
   U16      staEvent;         /* Status indication event*/
   Bool     staInd;           /* TRUE if StaInd to be send */
   U16      i;                /* loop index */
   U16      j;                /* loop index */
   U16      k;                /* loop index */
   Bool     nSapAll;          /* TRUE if all NSAPs considered */
   ItDpcCb  *oDpcCb;          /* originating SAP CB */
   S16      ret;              /* return value */
   U8       dpcEvt;           /* event received */
   Dpc      aPcMask;          /* Affected PC Mask */
   Dpc      curaPc=0;         /* DPC in the aPc Mask range */
   Dpc      maxaPc;           /* Maximum DPC value in aPc Mask range */
   Bool     nextaPc;          /* while loop flag */
   UConnId  tmpAssocId;       /* Temp assoc Id */ 

   TRC2(itMifDpcEvt)

#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
          "itMifDpcEvt(source(%d), event(%d), nwkId(%d), aPc(%d), opc(%d), "
          "congLevel(%d), srvInfo, dpcCb(%d))\n", source, event, nwkId, aPc,
          dpc, congLevel, (dpcCb != (ItDpcCb *)NULLP) ? dpcCb->dpc : 0));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
          "itMifDpcEvt(source(%d), event(%d), nwkId(%d), aPc(%ld), opc(%ld)), "
          "congLevel(%d), srvInfo, dpcCb(%ld))\n", source, event, nwkId, aPc,
          dpc, congLevel, (dpcCb != (ItDpcCb *)NULLP) ? dpcCb->dpc : 0));
#endif

   nwkCb    = itGlobalCb.nwk[nwkId];
   oDpcCb   = (ItDpcCb *)NULLP;
   nSapCb   = (ItNSapCb *)NULLP;
   msgType  = 0xffffffff;
   staInd   = FALSE;
   staEvent = 0;
   tmpAssocId = 0;
   
   /* - Determine aPc Mask from first 8 bits of aPc and actual DPC
    * from last 24 bits of aPc. */
   aPcMask = (Dpc) (MAX32BIT << (aPc >> 24));

   /* If destination is specified, get the cb */
   if (dpc != (Dpc) 0)
   {
      if ((ret = itAtGetDpc(nwkId, dpc, &oDpcCb)) != ROK)
      {
         oDpcCb = (ItDpcCb *)NULLP;
      }
   }
   /* If not already passed, get the aPc cb */
   /* if ((dpcCb == (ItDpcCb *)NULLP) && (aPc != (Dpc) 0)) */
   if ((aPcMask == MAX32BIT) &&
       (dpcCb == (ItDpcCb *)NULLP) && (aPc != (Dpc) 0))
   {
      if ((ret = itAtGetDpc(nwkId, aPc, &dpcCb)) != ROK)
      {
         dpcCb = (ItDpcCb *)NULLP;
      }
   }

   switch (event)
   {
      case IT_MIF_PC_UNA:
         status   = SN_PAUSE;
         msgType  = IT_SSNM_DUNA;
         staInd   = TRUE;
         staEvent = LIT_EVENT_PC_UNAVAILABLE;
         break;
      case IT_MIF_PC_RST:
         status   = SN_RESTRICT;
         msgType  = IT_SSNM_DRST;
         staInd   = TRUE;
         staEvent = LIT_EVENT_PC_RESTRICTED;
         break;
      case IT_MIF_PC_AVA:
         status   = SN_RESUME;
         msgType  = IT_SSNM_DAVA;
         staInd   = TRUE;
         staEvent = LIT_EVENT_PC_AVAILABLE;
         break;
      case IT_MIF_PC_CON:
         status   = SN_CONG;
         msgType  = IT_SSNM_SCON;
         staInd   = TRUE;
         staEvent = LIT_EVENT_PC_CONGESTED;
         if ((nwkCb->nwkCfg.ssf == SSF_NAT) ||
             (nwkCb->nwkCfg.dpcLen == DPC16))
         {
            if (congLevel == SN_PRI0)
            {
               status = SN_STPCONG;
            }
         }
         break;
      case IT_MIF_PC_UPU:
         status   = SN_RMTUSRUNAV;
         staEvent = LIT_EVENT_PC_USER_PART_UNA;
         staInd   = TRUE;
         msgType  = IT_SSNM_DUPU;
         break;
      case IT_MIF_RST_BEG:
         status = SN_RSTBEG;
         /* it014.106 - Send USTA to LM. */
         staEvent = LIT_EVENT_NWK_RSTBEG;
         staInd   = TRUE;
         break;
      case IT_MIF_RST_END:
         status = SN_RSTEND;
         /* it014.106 - Send USTA to LM. */
         staEvent = LIT_EVENT_NWK_RSTEND;
         staInd   = TRUE;
         break;
      default:
         RETVALUE(RFAILED);
   }
   
   if ((staInd == TRUE) && (source != IT_MIF_DATAREQ))
   {
      itGlobalCb.mgmt.hdr.elmId.elmnt           = STITAPC;
      itGlobalCb.mgmt.hdr.msgType               = TUSTA;
      itGlobalCb.mgmt.t.usta.alarm.category     = LIT_CATEGORY_STATUS;
      itGlobalCb.mgmt.t.usta.alarm.event        = staEvent;
      itGlobalCb.mgmt.t.usta.alarm.cause        = LCM_CAUSE_UNKNOWN;
      itGlobalCb.mgmt.t.usta.s.nwkId            = nwkId;
      /* send the aPc Mask as per the first 8 bits of aPc */
      /*itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc       = aPc; */
      itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc       = (Dpc)(aPc & IT_MAX_DPC_MASK);
      itGlobalCb.mgmt.t.usta.t.dpcEvt.mask      = (U8)(aPc >> 24);

      if (staEvent == LIT_EVENT_PC_CONGESTED)
      {
         itGlobalCb.mgmt.t.usta.t.dpcEvt.p.congLevel = congLevel;
      }
      else
      {
         itGlobalCb.mgmt.t.usta.t.dpcEvt.p.servInd = (U8)(0x0F & srvInfo);
      }

      /* call itMiStaIndM to add timestamp and call ItLitMiStaInd */
      (Void) itMiStaIndM(&itGlobalCb.mgmt);
   }

#if ( defined (ITSG) && defined (SNTIWF) )
   if (itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP)
   {
      /* Send to NIF */
      if ((source == IT_MIF_SPMC) || (source == IT_MIF_DATAREQ) ||
         (source == IT_MIF_USER))
      {
         /* event originates from an SPMC or from a data request */
         if ((oDpcCb == (ItDpcCb *)NULLP) || (oDpcCb->type == IT_DPCCB_SS7))
         {
            /* Event is destined for the NIF */
            if (nwkCb->mtp3NSap != (ItNSapCb *)NULLP)
            {
               if (nwkCb->mtp3NSap->sntSta.hlSt == LIT_SAP_BOUND)
               {
                 /* Suppress "TFA" and "TFP" if configured as such */
                  if ((dpcCb == (ItDpcCb *)NULLP) ||
                     !((dpcCb->noStatus == TRUE) &&
                      ((status == SN_PAUSE) || (status == SN_RESUME))))
                  {  
                     if ((dpcCb != NULLP) && (dpcCb->type != IT_DPCCB_SS7))
                     {
#ifdef ZV_DFTHA
                /* Queue Cong indications to user until standbys are updated. */
                  if ((zvCb.genCfg.distEnv == TRUE) &&
                      (itProtState == CMPFTHA_STATE_ACTIVE))
                  {
                   if (status == SN_RESUME)
                   {
                      itGlobalCb.primQueFlg = TRUE;
                      itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].event
                                                  = EVTSNTSTAAPYIND;
                      itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].p.\
                                 sntStaInd.status = status;
                      itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].p.\
                             sntStaInd.spId = nwkCb->mtp3NSap->sntSta.lclSapId;
                      itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].p.\
                                 sntStaInd.aPc = aPc;
                      itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].p.\
                                 sntStaInd.oPc = dpc;
                      itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].p.\
                           sntStaInd.srvInfo = (U8)((event == IT_MIF_PC_UPU) ?
                                               IT_SRVIND(srvInfo) : 0);
                      itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].p.\
                          sntStaInd.congLevel  = (U8)(((event == IT_MIF_PC_CON) 
                                  || (event == IT_MIF_PC_UPU)) ? congLevel : 0);
                      itGlobalCb.l4Lst.nmbPrims++;
#if (ERRCLASS & ERRCLS_DEBUG)
                      if (itGlobalCb.l4Lst.nmbPrims > 
                                               itGlobalCb.genCfg.maxNmbDpcEnt)
                      {
                         ITLOGERROR(ERRCLS_DEBUG, EIT177, 
                                   (ErrVal) itGlobalCb.l4Lst.nmbPrims,
                      "More primitives to be queued than max allowd. Change logic!");
                      }
#endif
                    }
                    else
                    {
#ifdef SNT_BACK_COMP_MERGED_NIF
                        (Void) ItUiSntStaApyInd(&nwkCb->mtp3NSap->pst,
                        nwkCb->mtp3NSap->sntSta.remSapId, aPc, dpc,
                        (U8)((event == IT_MIF_PC_UPU) ? 
                             IT_SRVIND(srvInfo) : 0),
                        status,
                        (U8)(((event == IT_MIF_PC_CON) || 
                              (event == IT_MIF_PC_UPU)) ? congLevel : 0));
#else
                        (Void) ItLiSntStaApyReq(&nwkCb->mtp3NSap->pst,
                        nwkCb->mtp3NSap->sntCfg.mtp3SapId, aPc, dpc,
                        (U8)((event == IT_MIF_PC_UPU) ? 
                             IT_SRVIND(srvInfo) : 0),
                        status,
                        (U8)(((event == IT_MIF_PC_CON) || 
                              (event == IT_MIF_PC_UPU)) ? congLevel : 0));
#endif
                    }
                 }
                 else
#endif /* ZV_DFTHA */
#ifdef SNT_BACK_COMP_MERGED_NIF
                        (Void) ItUiSntStaApyInd(&nwkCb->mtp3NSap->pst,
                        nwkCb->mtp3NSap->sntSta.remSapId, aPc, dpc,
                        (U8)((event == IT_MIF_PC_UPU) ? 
                             IT_SRVIND(srvInfo) : 0),
                        status,
                        (U8)(((event == IT_MIF_PC_CON) || 
                              (event == IT_MIF_PC_UPU)) ? congLevel : 0));
#else
                        (Void) ItLiSntStaApyReq(&nwkCb->mtp3NSap->pst,
                        nwkCb->mtp3NSap->sntCfg.mtp3SapId, aPc, dpc,
                        (U8)((event == IT_MIF_PC_UPU) ? 
                             IT_SRVIND(srvInfo) : 0),
                        status,
                        (U8)(((event == IT_MIF_PC_CON) || 
                              (event == IT_MIF_PC_UPU)) ? congLevel : 0));
#endif
                        IT_STS_INC_MTP3_TX_STA(nwkCb->mtp3NSap, status);
                     }
                  }
               }
            }
         }
      }
      else
      {
         /* source == IT_MIF_SS7 or IT_MIF_RST (i.e. originates from NIF) */
         /* - To Start/Stop the Polling timer for
          each DPC in Mask range, if Mask is not equal to MAX32BIT */
         /*if (dpcCb != (ItDpcCb *)NULLP)
         {
            * For type SS7 DPCs on the SG, start or stop the poll timer *
            if (dpcCb->type == IT_DPCCB_SS7)
            {
               if ((dpcCb->dpcSt == IT_DPC_RESTRICTED) 
                   || (dpcCb->dpcSt == IT_DPC_UNAVAILABLE)
                   || (dpcCb->congLevel > SN_PRI0))
               {
                  itTcStartTimer(&dpcCb->tmrPoll, (PTR)dpcCb,
                     IT_TMR_STA_POLL, &itGlobalCb.genCfg.tmr.tmrMtp3Sta);
               }
               else
               {
                  itTcStopTimer(&dpcCb->tmrPoll);
               }
            } * end if type SS7 *
         } */
         while (((aPcMask != MAX32BIT) &&
                 (itAtGetDpcs(nwkId, (aPc & IT_MAX_DPC_MASK), aPcMask, 
                                                           &dpcCb) == ROK)) ||
                ((aPcMask == MAX32BIT) && (dpcCb != (ItDpcCb *)NULLP)))
         {
            /* For type SS7 DPCs on the SG, start or stop the poll timer */
            if (dpcCb->type == IT_DPCCB_SS7)
            {
               if ((dpcCb->dpcSt == IT_DPC_RESTRICTED) 
                   || (dpcCb->dpcSt == IT_DPC_UNAVAILABLE)
                   || (dpcCb->congLevel > SN_PRI0))
               {
                  itTcStartTimer(&dpcCb->tmrPoll, (PTR)dpcCb,
                     IT_TMR_STA_POLL, &itGlobalCb.genCfg.tmr.tmrMtp3Sta);
               }
               else
               {
                  itTcStopTimer(&dpcCb->tmrPoll);
               }
            } /* end if type SS7 */

            /* If Mask is equal to MAX32BIT, then no further iteration 
             * required in loop */
            if (aPcMask == MAX32BIT)
            {
               break;
            }
         } /* end of while */

         /* it014.106 - if event is IT_MIF_RST_BEG or IT_MIF_RST_END, 
          * send indication to all user NSAPs in the same nwk. */
         if ((event == IT_MIF_RST_BEG) || (event == IT_MIF_RST_END))
         {
            for (spId = 0; spId < itGlobalCb.genCfg.maxNmbNSap; spId++)
            {
               nSapCb = itGlobalCb.nSap[spId];
               if (nSapCb != (ItNSapCb *)NULLP)
               {
                  if ((nSapCb->sntCfg.nwkId == nwkId) &&
                      (nSapCb->sntCfg.suType != LIT_SP_MTP3))
                  {
                     /* The address and priority parameters are not used for 
                      * SN_RSTBEG/SN_RSTEND indications. */
                     (Void) ItUiSntStaInd(&nSapCb->pst, nSapCb->sntSta.remSapId,
                                          0, status, 0);
                      IT_STS_INC_MTP3_TX_STA(nSapCb, status);
                  }
               }
            }
            RETVALUE(ROK);
         } /* end of if event IT_MIF_RST_BEG/IT_MIF_RST_END */
      }
   } /* end if nodetype SG */
#endif /* ITSG && SNTIWF */

   /* If assocId is present (assocIdPres == TRUE) then DPC event is to be
      broadcasted only from the SEP on which original
      message (which is causing this effect) was received */
   /* If assocId is not present then this event is broadcasted to all active
      associations which does not have psCb->spmc->dpc same as aPc */
   if (source != IT_MIF_SGP)
   {
      /* Broadcast event to the distributed SPMCs */
      /* Initialize all assocCbs to "unlisted" */
      for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)
      {
         if (itGlobalCb.assoc[i] != (ItAssocCb *)NULLP)
         {
            itGlobalCb.assoc[i]->mifSt = IT_MIF_UNLISTED;
         }
      }
      nSapAll = FALSE;
      if (dpc == (Dpc)0)
      {
         if (itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP)
         {
            /* Originator not specified, broadcast to all PSs in the network */
            for (i = 0; 
                (i < nwkCb->nmbPs); i++)
            {                                                          
               ItPsCb   *curPsCb;   /* current PS CB */        
               Bool     itsMe;      /* TRUE if I'm the affected DPC */  
               itsMe    = FALSE;                                        
               curPsCb  = nwkCb->ps[i];                                 
               /* Don't forward if this PS supports the same DPC as the 
                  affected DPC */                                       
               /*if (curPsCb->spmc != (ItDpcCb *) NULLP)                  */
               if ((curPsCb->spmc != (ItDpcCb *) NULLP) &&                  
                   (aPcMask == MAX32BIT))
               {                                                        
                  if ((curPsCb->spmc->nwk == nwkCb) && 
                       (curPsCb->spmc->dpc == aPc))
                  {                                                     
                     itsMe = TRUE;                                      
                     /* eliminate Assocs that support this dpc */        
                     for (k = 0; k < LIT_MAX_SEP; k++)
                     {
                        for (j = 0; j < curPsCb->psSta.psStaEndp[k].nmbAct; j++)
                        {                                                  
                           tmpAssocId = IT_PSPnENDP2ASSOC(curPsCb->psSta.\
                                                   psStaEndp[k].actPsp[j], k);
                           itGlobalCb.assoc[tmpAssocId]->mifSt = 
                                                              IT_MIF_ELIMINATED;
                        }
                     }
                  }
               }
               if (itsMe == FALSE)                                              
               {                                                                
                  if (assocIdPres == TRUE)                               
                  {                                                  
                     SuId     msgRcvdSuId; /* SuId of the association on which 
                                          * mesg is received */
                     /* forward to active associations from the same SEP
                        on which original message was received and not to
                        the association on which message was originally came
                        from */
                        /* SuId of actAssoc is to be same as suId of 'assocId'
                           on which original message was received */
                     msgRcvdSuId = IT_ASSOC2SUID(assocId);
                     for (j = 0; j < curPsCb->psSta.psStaEndp[msgRcvdSuId].\
                                     nmbAct; j++)  
                     {                                           
                        tmpAssocId = IT_PSPnENDP2ASSOC(curPsCb->psSta.\
                                        psStaEndp[msgRcvdSuId].actPsp[j], 
                                        msgRcvdSuId);
                        /* it001.106 : modification, correct assocId is used */
                        if ((tmpAssocId != assocId) &&      
                            (itGlobalCb.assoc[tmpAssocId]->mifSt
                                               != IT_MIF_ELIMINATED)) 
                        {                                             
                           itGlobalCb.assoc[tmpAssocId]->mifSt = IT_MIF_LISTED;
                        }                                                       
                     }                                                          
                  }                                                             
                  else                                                          
                  {                                                             
                     for (k = 0; k < LIT_MAX_SEP; k++)
                     {
                        /* forward to active assocs */                   
                        for (j = 0; j < curPsCb->psSta.psStaEndp[k].nmbAct;j++)
                        {                                                  
                           tmpAssocId = IT_PSPnENDP2ASSOC(curPsCb->psSta.\
                                        psStaEndp[k].actPsp[j], k);
                           if (itGlobalCb.assoc[tmpAssocId]->mifSt != 
                                                             IT_MIF_ELIMINATED)
                           {
                              itGlobalCb.assoc[tmpAssocId]->mifSt =
                                                                IT_MIF_LISTED;
                           }
                        }
                     } /* end of for (k = 0; k < LIT_MAX_SEP; k++) */
                  }
               } /* end of if (itsMe == FALSE) */                                              
            }                                                                   
         }
         /* ... and to all user SAPs */
         nSapAll = TRUE;
      }
      else
      {
         ItPsCb *curPsCb;     /* current PS CB */
         if (oDpcCb != (ItDpcCb *)NULLP)
         {
            U16         idx;        /* index */
            U8          rtType;     /* route type */
            ItPsCb      *owner;     /* route owner */
            ItRouteCb   *routeCb;   /* route CB */
            idx      = 0;
            nSapCb   = (ItNSapCb *)NULLP;
            routeCb  = (ItRouteCb *) NULLP;   
            /* Scan cluster of routes related to the oDpc */
            while ((ret =
               itMifGetNextInCluster(oDpcCb, &rtType, &owner, &idx, &routeCb))
               == ROK)
            {
               Bool localUser;      /* TRUE if local user */
               localUser = FALSE;
               if ((rtType == LIT_RTTYPE_PS) && 
                   (itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP))
               {
                  curPsCb = owner;
                  for (k = 0; k < LIT_MAX_SEP; k++)
                  {
                     for (j = 0; j < curPsCb->psSta.psStaEndp[k].nmbAct; j++)
                     {
                        itGlobalCb.assoc[IT_PSPnENDP2ASSOC(curPsCb->psSta.\
                          psStaEndp[k].actPsp[j], k)]->mifSt = IT_MIF_LISTED;
                     }
                     if (curPsCb->psSta.psStaEndp[k].aspSt[IT_LOCAL_PSPID] != 
                                                                 LIT_ASP_UNSUPP)
                     {
                        localUser = TRUE;
                     }
                  }
               }
               else if (rtType == LIT_RTTYPE_LOCAL)
               {
                  localUser = TRUE;
               }
               else if ((rtType == LIT_RTTYPE_PS) &&
                         (owner->psCfg.lclFlag == TRUE))
               {
                   (Void) itUiGetNSap(nwkId, srvInfo, FALSE, &nSapCb);
               }

               if (localUser == TRUE)
               {
                  /* Local PSP: get NSAP from route */
                  if (routeCb == (ItRouteCb *) NULLP)
                  {
                     nSapCb = oDpcCb->nSap;
                     if (nSapCb == (ItNSapCb *) NULLP)
                     {
                        nSapAll = TRUE;
                     }
                  }
                  else
                  {
                     if (routeCb->rteCfg.nSapIdPres == TRUE)
                     {
                        nSapCb = itGlobalCb.nSap[routeCb->rteCfg.nSapId];
                     }
                     else if (routeCb->rteCfg.rtFilter.sioMask & 0x0F)
                     {
                        (Void) itUiGetNSap(nwkId,
                           routeCb->rteCfg.rtFilter.sio, FALSE,
                           &nSapCb);
                     }
                     else
                     {
                        nSapAll = TRUE;
                     }
                  }
               } /* end if local user */
            } /* end while */
            if (ret == RFAILED)
            {
               RETVALUE(RFAILED);
            }
         } /* end if non-null oDpcCb */
      } /* end else */
      /* Distribute to the tagged Assocs */
      if (itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP)
      {
         for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)
         {
            if (itGlobalCb.assoc[i] != (ItAssocCb *)NULLP)
            {
               if ((itGlobalCb.assoc[i]->mifSt == IT_MIF_LISTED) &&
                (itGlobalCb.assoc[i]->owner != (ItPspCb *)NULLP) &&
                (itGlobalCb.assoc[i]->owner->pspCfg.pspId != IT_LOCAL_PSPID)
                   && (itGlobalCb.assoc[i]->assocSta->aspSt != LIT_ASP_DOWN))
               {
                   /* if msgType is DUNA and source is DATAREQ then Check 
                    * whether the Duna-settle timer is running for
                    * this assoc, if not then send the DUNA message to assoc.
                    * This Duna-settle is started when the SGP receives the 
                    * data msg for a unavailable destination and timer is
                    * enabled but not running. Expiry of this timer will 
                    * do nothing */

                  Bool sendFlg;

                  sendFlg = TRUE;
                  if ((msgType == IT_SSNM_DUNA) && (source == IT_MIF_DATAREQ)) 
                  {
                     if (itGlobalCb.genCfg.tmr.tmrDunaSettle.enb == TRUE)
                     {
                        sendFlg = FALSE; /* message sent */
                        if (itGlobalCb.assoc[i]->tmrDunaSettle.tmrEvnt == 
                                                                TMR_NONE)
                        {
                          /* Send the DUNA message */        
                           if ((ret = itMmhSsnm(itGlobalCb.assoc[i], 
                                (U16)msgType, nwkId, aPc, 0, (Txt *)NULLP,
                                (U16)0, (U16)0))
                               != ROK)
                           {
                               RETVALUE(ret);
                           }
                           /* Start the DUNA-settle timer */
                           itTcStartTimer(&(itGlobalCb.assoc[i]->tmrDunaSettle),
                                (PTR)itGlobalCb.assoc[i], IT_TMR_DUNA_SETTLE,
                                &itGlobalCb.genCfg.tmr.tmrDunaSettle);
                        }
                     }
                  }

                  if (sendFlg == TRUE)
                  {
                     /* - Changed the call to itMmhSsnm to pass
                      * Mask as per first 8 bits of aPc and pass DPC as per 
                      * last 24 bits of aPc */
                     /*if ((ret = itMmhSsnm(itGlobalCb.psp[i]->assoc, 
                          (U16)msgType, nwkId, aPc, 0, (Txt *)NULLP,
                          (U16)((msgType == IT_SSNM_SCON) ? congLevel :
                           ((msgType == IT_SSNM_DUPU) ? 
                           ((U8) ((congLevel) >> 6)) : 0)), 
                          (U16)((msgType == IT_SSNM_DUPU) ? 
                                IT_SRVIND(srvInfo) : 0)))
                          != ROK)*/
                     if ((ret = itMmhSsnm(itGlobalCb.assoc[i],
                          (U16)msgType, nwkId, (aPc & IT_MAX_DPC_MASK), 
                          ((U8) (aPc >> 24)), (Txt *)NULLP,
                          (U16)((msgType == IT_SSNM_SCON) ? congLevel :
                           ((msgType == IT_SSNM_DUPU) ? 
                           ((U8) ((congLevel) >> 6)) : 0)), 
                          (U16)((msgType == IT_SSNM_DUPU) ? 
                                IT_SRVIND(srvInfo) : 0)))
                          != ROK)
                     {
                        RETVALUE(ret);
                     }
                  } /* end sendFlg */
               }
            }
         } /* end for */
      }
   }
   else
   {
      /* Restart events - all user SAPs must know about these */
      /* SGP-originated events (SSNM), all local users must know */
      nSapAll = TRUE;
   }
   
   /* SN_RESTRICT is not sent to user. So modify the event before
    * sending it to users */

   dpcEvt = event;

   if (dpcEvt == IT_MIF_PC_RST) 
   {
      dpcEvt = IT_MIF_PC_AVA;
      status = SN_RESUME;
   }
   /* Distribute event to local user(s) */
   if (nSapAll == TRUE)
   {
      for (spId = 0; spId < itGlobalCb.genCfg.maxNmbNSap; spId++)
      {
         nSapCb = itGlobalCb.nSap[spId];
         if (nSapCb != (ItNSapCb *)NULLP)
         {
            if (nSapCb->sntCfg.nwkId == nwkId)
#ifdef ITSG
            if (nSapCb->sntCfg.suType != LIT_SP_MTP3)
#endif
            {
               Bool skip;     /* TRUE if we're skipping this NSAP */
               /* send Status Indication to
                * the NSAP for each individual DPC in the Mask range as per
                * aPc parameter */
               ItDpcCb *prevEnt; 
               prevEnt  = (ItDpcCb *)NULLP;
               maxaPc  = (aPc | (~aPcMask)) & IT_MAX_DPC_MASK;
               while (cmHashListGetNext(&itGlobalCb.addrTrn.dpcList, 
                      (PTR) prevEnt,
                      (PTR *) &dpcCb) == ROK)

               {
                  prevEnt = dpcCb;
                  if (((dpcCb->dpc & aPcMask) == (aPc & aPcMask)) &&
                      dpcCb->nwk->nwkCfg.nwkId == nwkId)
                  {
                     if ((source == IT_MIF_SS7) && 
                         (dpcCb->type != IT_DPCCB_SS7))
                     
                     {
                        continue;
                     }
                  }
                  else /* DPC not found, get to next dpc */
                  {
                     continue;
                  }

                  skip = FALSE;
                  
                  if (dpcCb != (ItDpcCb *) NULLP)
                  {
                     U16         idx;        /* index */
                     U8          rtType;     /* route type */
                     ItPsCb      *owner;     /* route owner */
                     ItRouteCb   *routeCb;   /* route CB */
                     idx = 0;
                     routeCb  = (ItRouteCb *) NULLP;   
                     /* check for routes to this NSAP for DPC - if found, 
                      * skip */
                     while ((ret = itMifGetNextInCluster(dpcCb, &rtType, &owner,
                                                        &idx, &routeCb)) == ROK)
                     {
                        if (routeCb == (ItRouteCb *) NULLP)
                        {
                           if (nSapCb == dpcCb->nSap)
                           {
                              skip = TRUE;
                              break;
                           }
                        }
                        else
                        {
                           if ((routeCb->rteCfg.nSapIdPres == TRUE) &&
                               (routeCb->rteCfg.nSapId == spId))
                           {
                              skip = TRUE;
                              break;
                           }
                        }
                     } /* end while */
                  } /* end if dpcCb != NULLP */
                  if (skip == FALSE)
                  {
                     if ((dpcEvt != IT_MIF_PC_UPU) ||
                         (nSapCb->sntCfg.suType == IT_SRVIND(srvInfo)))
                     {
                        if (nSapCb->sntSta.hlSt == LIT_SAP_BOUND)
                        {
                           /* Modification, Status indications 
                               blocked for DPC(*)  */
                             /* No notification is sent for NULL DpcCb */
                           if (dpcCb != NULLP)
                           {
                              if ((dpcCb->type == IT_DPCCB_SPMC) ||
                                   (nSapCb->nwk->restart == FALSE))
                              {
                               /* M3UA users should not get indications in 
                                 non-synchronized way, hence we are queuing this
                                 interface primitive too */
#ifdef ZV_DFTHA
               /* Queue Cong indications to user until standbys are updated. */
                             if (((status == SN_RESUME) ||
                               (status  == SN_CONG) ||
                               (status  == SN_STPCONG)) &&
                               (zvCb.genCfg.distEnv == TRUE))
                             {
                                itGlobalCb.primQueFlg = TRUE;
                                itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].\
                                    event = EVTSNTSTAIND;
                                itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].p.\
                                    sntStaInd.status = status;
                                itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].p.\
                                    sntStaInd.spId = nSapCb->sntSta.lclSapId;
                                itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].p.\
                                    sntStaInd.aPc = curaPc;
                                itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].p.\
                                   sntStaInd.congLevel = 
                                          (U8)(((dpcEvt == IT_MIF_PC_CON) ||
                                          (dpcEvt == IT_MIF_PC_UPU)) ? congLevel :
                                                     (Priority)0);
                                itGlobalCb.l4Lst.nmbPrims++;
#if (ERRCLASS & ERRCLS_DEBUG)
                                if (itGlobalCb.l4Lst.nmbPrims > 
                                                  itGlobalCb.genCfg.maxNmbDpcEnt)
                                {
                                   ITLOGERROR(ERRCLS_DEBUG, EIT178, 
                                      (ErrVal) itGlobalCb.l4Lst.nmbPrims,
                                "More primitives to be queued than max allowd. Change logic!");
                                }
#endif
                             }
                             else
#endif /* ZV_DFTHA */
                                  /* it013.106 - Fixed the call to SntStaInd to
                                   * use remSapId. */
                                  (Void) ItUiSntStaInd(&nSapCb->pst,
                                        nSapCb->sntSta.remSapId, dpcCb->dpc,
                                        status,
                                       (U8)(((dpcEvt == IT_MIF_PC_CON) ||
                                       (dpcEvt == IT_MIF_PC_UPU)) ? 
                                       congLevel : (Priority)0));
                                  IT_STS_INC_MTP3_TX_STA(nSapCb, status);
                              } 
                           }
                        }
                     }
                  }
                  
                  curaPc++;
                  if ((curaPc > maxaPc) || (aPcMask == MAX32BIT))
                  {
                     nextaPc = FALSE;
                  }
               } /* end of while */
               /*
               skip = FALSE;
               if (dpcCb != (ItDpcCb *) NULLP)
               {
                  U16         idx;        * index *
                  U8          rtType;     * route type *
                  ItPsCb      *owner;     * route owner *
                  ItRouteCb   *routeCb;   * route CB *
                  idx = 0;
                  routeCb  = (ItRouteCb *) NULLP;   
                  * check for routes to this NSAP for DPC - if found, skip *
                  while ((ret = itMifGetNextInCluster(dpcCb, &rtType, &owner,
                                                      &idx, &routeCb)) == ROK)
                  {
                     if (routeCb == (ItRouteCb *) NULLP)
                     {
                        if (nSapCb == dpcCb->nSap)
                        {
                           skip = TRUE;
                           break;
                        }
                     }
                     else
                     {
                        if ((routeCb->rteCfg.nSapIdPres == TRUE) &&
                            (routeCb->rteCfg.nSapId == spId))
                        {
                           skip = TRUE;
                           break;
                        }
                     }
                  } * end while *
               } * end if dpcCb != NULLP *
               if (skip == FALSE)
               {
                  if ((dpcEvt != IT_MIF_PC_UPU) ||
                      (nSapCb->sntCfg.suType == IT_SRVIND(srvInfo)))
                  {
                     if (nSapCb->sntSta.hlSt == LIT_SAP_BOUND)
                     {
                        if (((dpcCb != NULLP) && 
                             (dpcCb->type == IT_DPCCB_SPMC)) ||
                            (nSapCb->nwk->restart == FALSE))
                        {
                            (Void) ItUiSntStaInd(&nSapCb->pst,
                                      nSapCb->sntSta.suId, aPc, status,
                                 (U8)(((dpcEvt == IT_MIF_PC_CON) ||
                                 (dpcEvt == IT_MIF_PC_UPU)) ? 
                                 congLevel : (Priority)0));
                            IT_STS_INC_MTP3_TX_STA(nSapCb, status);
                        }
                     }
                  }
               } */
            }
         } /* end if nSapCb != NULLP */
      } /* end for */
   } /* end if nSapAll == TRUE */
   else
   {
      /* NSAP was selected previously */
      if (nSapCb != (ItNSapCb *)NULLP)
      {
         if (nSapCb->sntSta.hlSt == LIT_SAP_BOUND)
         {
            nextaPc = TRUE;
            curaPc  = (aPc & aPcMask) & IT_MAX_DPC_MASK;
            maxaPc  = (aPc | (~aPcMask)) & IT_MAX_DPC_MASK;
            while (nextaPc == TRUE)
            {
               if (aPcMask != MAX32BIT)
               {
                  if ((ret = itAtGetDpc(nwkId, curaPc, &dpcCb)) != ROK)
                  {
                     dpcCb = (ItDpcCb *)NULLP;
                  }
                  else
                  {
                     /* - Send Status Indication to NSAP for only 
                      * SS7 DPCs in aPcMask range since Mask can only be 
                      * valid in case of Status Indication from NIF at 
                      * SGP. */
                     if ((source == IT_MIF_SS7) && 
                         (dpcCb->type != IT_DPCCB_SS7))
                     {
                        curaPc++;
                        if (curaPc > maxaPc)
                        {
                           nextaPc = FALSE;
                        }
                        continue;
                     }
                  }
               }
               if (dpcCb != (ItDpcCb *) NULLP)
               {
                  if ((dpcCb->type == IT_DPCCB_SPMC) ||
                   (nSapCb->nwk->restart == FALSE))
                  {
#ifdef ZV_DFTHA
                 /* Queue  indications to user until standbys are updated. */
                     if (status == SN_RESUME)
                     {
                        itGlobalCb.primQueFlg = TRUE;
                        itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].event
                                 = EVTSNTSTAIND;
                        itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].p.\
                                 sntStaInd.status = status;
                        itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].p.\
                                 sntStaInd.spId = nSapCb->sntSta.lclSapId;
                        itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].p.\
                                 sntStaInd.aPc = curaPc;
                        itGlobalCb.l4Lst.lst[itGlobalCb.l4Lst.nmbPrims].p.\
                           sntStaInd.congLevel = (U8)(((dpcEvt == IT_MIF_PC_CON) ||
                             (dpcEvt == IT_MIF_PC_UPU)) ? congLevel : (Priority)0);
                        itGlobalCb.l4Lst.nmbPrims++;
#if (ERRCLASS & ERRCLS_DEBUG)
                        if (itGlobalCb.l4Lst.nmbPrims > 
                                                itGlobalCb.genCfg.maxNmbDpcEnt)
                        {
                           ITLOGERROR(ERRCLS_DEBUG, EIT179, 
                              (ErrVal) itGlobalCb.l4Lst.nmbPrims,
                        "More primitives to be queued than max allowd. Change logic!");
                        }
#endif
                      }
                      else
#endif /* ZV_DFTHA */
                        /* it013.106 - Fixed the call to SntStaInd to use 
                         * remSapId. */
                        (Void) ItUiSntStaInd(&nSapCb->pst, nSapCb->sntSta.remSapId, 
                               curaPc, status,
                        (U8)(((dpcEvt == IT_MIF_PC_CON) ||
                                (dpcEvt == IT_MIF_PC_UPU)) ? congLevel : 
                                  (Priority)0));
                        IT_STS_INC_MTP3_TX_STA(nSapCb, status);
                  }
               }

               curaPc++;
               if ((curaPc > maxaPc) || (aPcMask == MAX32BIT))
               {
                  nextaPc = FALSE;
               }
            } /* end of while */
            /*
            if ((dpcCb->type == IT_DPCCB_SPMC) ||
                (nSapCb->nwk->restart == FALSE))
            {
               (Void) ItUiSntStaInd(&nSapCb->pst, nSapCb->sntSta.suId, aPc,
                  status,
                  (U8)(((dpcEvt == IT_MIF_PC_CON) ||
                        (dpcEvt == IT_MIF_PC_UPU)) ? congLevel : (Priority)0));
               IT_STS_INC_MTP3_TX_STA(nSapCb, status);
            }
            */
         }
      }
   }

   RETVALUE(ROK);
} /* end of itMifDpcEvt */
#if ( defined(ITSG) && defined(SNTIWF) )

/*
*
*       Fun:   itMifStaTimeout
*
*       Desc:  Called by TC when the status poll timer expires
*
*       Ret:   None
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC Void itMifStaTimeout
(
ItDpcCb *dpcCb                /* DPC control block */
)
#else
PUBLIC Void itMifStaTimeout(dpcCb)
ItDpcCb *dpcCb;               /* DPC control block */
#endif
{
   ItNSapCb *nSapCb;          /* upper SAP CB */

   TRC2(itMifStaTimeout)

   if (dpcCb == NULLP)
   {
      RETVOID;        
   }
   /* Get NIF SAP */
   if (itUiGetNSap(dpcCb->nwk->nwkCfg.nwkId, (SrvInfo)0, TRUE, &nSapCb)
      != ROK)
   {
      /* This will happen if the NIF SAP is nonexistent or not bound */
      RETVOID;
   }
/*   if (nSapCb->nwk->restart == FALSE)
   {*/

   if(nSapCb == NULLP)
   {
      RETVOID;
   }
   /* Query status via NIF */
#ifdef SNT_BACK_COMP_MERGED_NIF
   (Void) ItUiSntStaQryInd(&nSapCb->pst, nSapCb->sntSta.remSapId, dpcCb->dpc,
   (Dpc)0);
#else
   (Void) ItLiSntStaQryReq(&nSapCb->pst, nSapCb->sntCfg.mtp3SapId, dpcCb->dpc,
   (Dpc)0);
#endif
   /* Restart poll timer */
   itTcStartTimer(&dpcCb->tmrPoll, (PTR)dpcCb,
   IT_TMR_STA_POLL, &itGlobalCb.genCfg.tmr.tmrMtp3Sta);
/*   }*/

   RETVOID;
} /* end of itMifStaTimeout */
#endif /* ITSG && SNTIWF */


/*
*
*       Fun:   itMifNwkRstTimeout
*
*       Desc:  Called by TC when the network restart timer expires
*
*       Ret:   None
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC Void itMifNwkRstTimeout
(
ItNwkCb *nwkCb                /* Network control block */
)
#else
PUBLIC Void itMifNwkRstTimeout(nwkCb)
ItNwkCb *nwkCb;               /* Network control block */
#endif
{
   TRC2(itMifNwkRstTimeout)

   (Void) itMifNwkEvt(IT_MIF_RST_COMP, (ItPspId) LIT_MAX_PSP, nwkCb);

   RETVOID;
} /* end of itMifNwkRstTimeout */

#ifdef ITASP
/*
*
*       Fun:   itMifDaudTimeout
*
*       Desc:  Called by TC when the DAUD timer expires
*
*       Ret:   None
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC Void itMifDaudTimeout
(
ItDpcCb     *dpcCb            /* DPC control block */
)
#else
PUBLIC Void itMifDaudTimeout(dpcCb)
ItDpcCb     *dpcCb;           /* DPC control block */
#endif
{
   ItAssocCb   *assocCb;      /* Assoc control block */
   Bool        tmrRestart;    /* TRUE if timer to be restarted */
   U16         i;             /* loop index */
   U16         j;             /* loop index */
   ItRouteCb   *routeCb;      /* route CB */
   ItPsCb      *psCb;         /* route owner */
   U8          rtType;        /* route type */
   U16         idx;           /* route index */
   U16         ret;           /* return value */


   TRC2(itMifDaudTimeout)

   for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)
   {
      if (itGlobalCb.assoc[i] != (ItAssocCb *)NULLP)
      {
         itGlobalCb.assoc[i]->mifSt = IT_MIF_UNLISTED;
      }
   }

   tmrRestart  = FALSE;

   idx         = 0;
   ret         = ROK;
   rtType      = (U8)NULLD;
   psCb        = (ItPsCb *) NULLP;
   routeCb     = (ItRouteCb *) NULLP;


   if (dpcCb == NULLP)
   {
      RETVOID;        
   }

   /* Step through the list of routes associated with this DPC */
   while (ret == ROK)
   {
      if (dpcCb->type == IT_DPCCB_NONROUTE)
      {
         ret = itMifGetNextGlobalMatch(dpcCb->nwk->nwkCfg.nwkId, dpcCb->dpc,
                                       &routeCb);
         if (ret == ROK)
         {
            psCb = routeCb->owner;
            rtType = routeCb->rteCfg.rtType;
         }
      }
      else
      {
         ret = itMifGetNextInCluster(dpcCb, &rtType, &psCb, &idx, &routeCb);
      }
      if (ret == ROK)
      {
         if (rtType == LIT_RTTYPE_PS)
         {
#if (defined(ITASP) && defined(SGVIEW))
            /* - DAUD will be sent to all the Inactive or Active
             * PSPs for which the DPC is Unavailable/Restricted/Congested.
             * This is required because -
             * a) DAUD is sent to an Inactive SGP, because in an SG an 
             * Inactive SGP can be responsible to send the SSNM messages 
             * to update DPC status for whole SG. 
             * b) DAUD is sent to all the SGPs, so that if the association 
             * breaks with the SSNM sending SGP, still the auditing continues
             * with other available SGPs */
            for (i = 0; i < LIT_MAX_SEP; i++)
            {
               for (j = 0; j < LIT_MAX_PSP; j++)
               {
                  if ((psCb->psSta.psStaEndp[i].aspSt[j] == LIT_ASP_ACTIVE) ||
                      (psCb->psSta.psStaEndp[i].aspSt[j] == LIT_ASP_INACTIVE))
                  {
                     if ((assocCb = itGlobalCb.assoc[IT_PSPnENDP2ASSOC(j, i)])
                                         != (ItAssocCb *)NULLP)
                     {
                        assocCb->mifSt = IT_MIF_LISTED;
                     }
                  }
               }
            }
#else /* ITASP && SGVIEW */
            /* peers that are active for this PS are of interest */
            for (j = 0; j < LIT_MAX_SEP; j++)
            {
               for (i = 0; i < psCb->psSta.psStaEndp[j].nmbAct; i++)
               {
                  /* it001.106 : modifications, correct assocId is used */
                  if ((assocCb = itGlobalCb.assoc[IT_PSPnENDP2ASSOC(psCb->psSta.
                                  psStaEndp[j].actPsp[i], j)]) != 
                                                      (ItAssocCb *)NULLP)
                  {
                     assocCb->mifSt = IT_MIF_LISTED;
                  }
               }
            }
#endif /* ITASP && SGVIEW */
         }
      }
   }
   /* dpcCb->pspDpcSt[i] == IT_DPC_CONGESTED need to be replaced with
    * congestion level check */
   /* In case pspDpcCong state is available and congestion level is
    * not equal to zero then also we need send DAUD message and 
    * restart DAUD timer */
   for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)
   {
      if ((dpcCb->pspDpcSt[i] == IT_DPC_UNAVAILABLE) ||
          (dpcCb->pspDpcSt[i] == IT_DPC_RESTRICTED) ||
          (dpcCb->pspDpcCong[i] > SN_PRI0))
      {
         if ((assocCb = itGlobalCb.assoc[i]) != (ItAssocCb *) NULLP)
         {
            if ((assocCb->mifSt == IT_MIF_LISTED)
               && (assocCb->owner != (ItPspCb *)NULLP)
               && (assocCb->owner->pspCfg.pspId != IT_LOCAL_PSPID))
            {
               (Void) itMmhSsnm(itGlobalCb.assoc[i], IT_SSNM_DAUD,
                  dpcCb->nwk->nwkCfg.nwkId, dpcCb->dpc, 0, (Txt *)NULLP, 0, 0);
               tmrRestart = TRUE;
            }
         }
      }
   }

   if (tmrRestart == TRUE)
   {
      itTcStartTimer(&dpcCb->tmrDaud, (PTR)dpcCb, IT_TMR_DAUD,
         &itGlobalCb.genCfg.tmr.tmrDaud);
   }

   RETVOID;
} /* end of itMifDaudTimeout */
#endif /* ITASP */

/*
*
*       Fun:   itMifStaGet
*
*       Desc:  Called by UI when the co-resident MTP3 or a local MTP3-User
*              enquires about the status of a point code.
*              Performs the management interworking function for the
*              user.
*
*       Ret:
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMifStaGet
(
ItNSapCb *nSapCb,             /* upper SAP */
Dpc      aPc,                 /* affected point code */
Dpc      opc                  /* originating point code */
)
#else
PUBLIC S16 itMifStaGet(nSapCb, aPc, opc)
ItNSapCb *nSapCb;             /* upper SAP */
Dpc      aPc;                 /* affected point code */
Dpc      opc;                 /* originating point code */
#endif
{
   ItDpcCb     *dpcCb;        /* DPC control block */
   U8          status;        /* DPC status */
   U8          congLevel;     /* DPC congestion level */
   Bool        gotStatus;     /* TRUE when got status */

   TRC2(itMifStaGet)
#ifdef ITASP
   UNUSED(opc);
#endif /* ITASP */

   dpcCb       = (ItDpcCb *)NULLP;
   congLevel   = SN_PRI0;
   status      = SN_PAUSE;
   gotStatus = FALSE;

   if (itAtGetDpc(nSapCb->sntCfg.nwkId, aPc, &dpcCb) == ROK)
   {
      switch (dpcCb->dpcSt)
      {
         case IT_DPC_AVAILABLE:
         case IT_DPC_RESTRICTED:
            if (dpcCb->congLevel == SN_PRI0)
            {
               status = SN_RESUME;
            }
            else
            {
               status      = SN_CONG;
               congLevel   = dpcCb->congLevel;  
            }
            break;
         case IT_DPC_UNAVAILABLE:
            status = SN_PAUSE;
            break;
         default:
            RETVALUE(RFAILED);
      }
      gotStatus = TRUE;
   }
   else
   {
      ItRouteCb   *routeCb;   /* route CB */
      Bool        done;       /* TRUE when loop done */
      status      = SN_PAUSE;
      congLevel   = SN_PRI0;
      done        = FALSE;
      routeCb     = (ItRouteCb *) NULLP;
      while ((itMifGetNextGlobalMatch(nSapCb->sntCfg.nwkId,
                                      aPc, &routeCb) == ROK) &&
             (done == FALSE))
      {
         gotStatus = TRUE;
         if (routeCb->rteCfg.rtType == LIT_RTTYPE_PS)
         {
            /* DPC status is based on status of PSs */
            if ((routeCb->owner->psSta.asSt == LIT_AS_ACTIVE) ||
                (routeCb->owner->psSta.asSt == LIT_AS_PENDING))
            {
               if (status == SN_PAUSE)
               {
                  status = SN_RESUME;
               }
               if ((nSapCb->nwk->nwkCfg.ssf == SSF_NAT) ||
                   (nSapCb->nwk->nwkCfg.dpcLen == DPC16))
               {
                  if (routeCb->owner->congLevel > congLevel)
                  {
                     congLevel  = routeCb->owner->congLevel;
                     status     = SN_CONG;
                  }
               }
            }
            else
            {
               if (routeCb->owner->psCfg.reqAvail == TRUE)
               {
                  /* this PS is required but not active */
                  status      = SN_PAUSE;
                  congLevel   = SN_PRI0;
                  done              = TRUE;
               }
            }
         } /* end if rtType == LIT_RTTYPE_PS */
      }
   } /* end if IT_DPCCB_NONROUTE */

#if ( defined(ITSG) && defined(SNTIWF) )
   if (gotStatus == FALSE)
   {
      if (nSapCb->sntCfg.suType == LIT_SP_MTP3)
      {
         status = SN_PAUSE;
         gotStatus = TRUE;
      }
      else
      {
         /* relay to MTP3 SAP */
         ItNSapCb *nifSapCb;
         if (itUiGetNSap(nSapCb->nwk->nwkCfg.nwkId, (SrvInfo) 0, TRUE,
            &nifSapCb) == ROK)
         {
#ifdef SNT_BACK_COMP_MERGED_NIF
            (Void) ItUiSntStaQryInd(&nifSapCb->pst, nifSapCb->sntSta.remSapId,
               aPc, opc);
#else
            (Void) ItLiSntStaQryReq(&nifSapCb->pst, nifSapCb->sntCfg.mtp3SapId,
               aPc, opc);
#endif
         }
         else
         {
            status = SN_PAUSE;
            gotStatus = TRUE;
         }
      }
   }
   if (nSapCb->sntCfg.suType == LIT_SP_MTP3)
   {
      if (gotStatus == TRUE)
      {
#ifdef SNT_BACK_COMP_MERGED_NIF
         (Void) ItUiSntStaQryCfm(&nSapCb->pst, nSapCb->sntSta.remSapId, aPc, 
                                 opc, status, congLevel);
#else
         (Void) ItLiSntStaQryRsp(&nSapCb->pst, nSapCb->sntCfg.mtp3SapId, aPc, 
            opc, status, congLevel);
#endif
      }
   }
   else
#endif
   {
      if (gotStatus == TRUE)
      {
         (Void) ItUiSntStaCfm(&nSapCb->pst, nSapCb->sntSta.remSapId, aPc, 
                                                            status, congLevel);
      }
   }

   RETVALUE(ROK);
} /* end of itMifStaGet */


/*
*
*       Fun:   itMifCalcDpcStatus
*
*       Desc:  Called to calculate the overall MTP3 status of a DPC
*              The DPC could be an SPMC DPC, SS7 domain DPC or local DPC
*
*       Ret:
*
*       Notes: None
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMifCalcDpcStatus
(
ItDpcCb  *dpcCb,              /* DPC control block */
U8       dpcEv,               /* DPC event */
U8       congLevel            /* congestion level */
)
#else
PUBLIC S16 itMifCalcDpcStatus(dpcCb, dpcEv, congLevel)
ItDpcCb  *dpcCb;              /* DPC control block */
U8       dpcEv;               /* DPC event */
U8       congLevel;           /* congestion level */
#endif
{
   S16         ret;           /* return value */
   U16         idx;           /* cluster index */
   U8          rtType;        /* route type */
   ItPsCb      *psCb;        /* route owner */
   ItRouteCb   *routeCb;      /* route CB */
   Bool        done;          /* TRUE when loop done */
#ifdef ITASP
   UNUSED(congLevel);
#endif /* ITASP */

   TRC2(itMifCalcDpcStatus)

   if (dpcEv == IT_MIF_PC_CHANGED)
   {
      U8 tmpType;             /* temporary route type */
      /* DPC's route config changed: make sure that the DPC's type is correct */
      idx      = 0;
      done     = FALSE;
      tmpType  = IT_DPCCB_UNKNOWN;
      routeCb  = (ItRouteCb *) NULLP;   
      while (((ret =
         itMifGetNextInCluster(dpcCb, &rtType, &psCb, &idx, &routeCb))
         == ROK) && (done == FALSE))
      {
         switch (rtType)
         {
            /* the following 3 cases fall through */
            case LIT_RTTYPE_PS:
            case LIT_RTTYPE_MTP3:
            case LIT_RTTYPE_NOTFOUND:
               dpcCb->type = IT_RTTYPE2DPC(rtType);
               done        = TRUE;
               break;
            case LIT_RTTYPE_LOCAL:
               dpcCb->type = IT_RTTYPE2DPC(rtType);
               /* carry on searching for a "stronger" type */
               break;
            default:
               RETVALUE(RFAILED);
         }
      }
   }

   switch (dpcEv)
   {
      case IT_MIF_PC_NEW:
      case IT_MIF_PC_CHANGED:
      case IT_MIF_PC_SUM:
         if ((dpcCb->type == IT_DPCCB_LOCAL) || 
             (dpcCb->type == IT_DPCCB_SPMC) ||
             (dpcCb->type == IT_DPCCB_SS7))
         {
           /* * if the dpc state is restricted then dpc state can only 
            * be changed by a Pause or Resume message. 
            * In all other cases dpc state shall 
            * remain to be restricted only */

            if (dpcCb->dpcSt == IT_DPC_RESTRICTED)
            {
               RETVALUE(ROK);
            }
            /* dpcEv could be IT_MIF_PC_SUM */
            idx   = 0;
            done  = FALSE;
            dpcCb->dpcSt      = IT_DPC_UNAVAILABLE;
            routeCb           = (ItRouteCb *) NULLP;   
            dpcCb->congLevel  = SN_PRI0;

            /* Step through the list of routes associated with this DPC */
            while (((ret = itMifGetNextInCluster(dpcCb, &rtType, &psCb, &idx, 
                                                 &routeCb)) == ROK) && 
                    (done == FALSE))
            {
               ItNSapCb *nSapCb;    /* NSAP control block */
               Bool     userUp;     /* TRUE if user "up" */
               nSapCb   = (ItNSapCb *)NULLP;
               userUp   = FALSE;
               switch (rtType)
               {
#ifdef ITSG
                  case LIT_RTTYPE_MTP3:
                     /* change SS7 PC state to unavailable if unbound */
                     if (routeCb != (ItRouteCb *)NULLP)
                     {
                        /* Get NSAP CB from route if possible */
                        if (routeCb->rteCfg.nSapIdPres == TRUE)
                        {
                           nSapCb = itGlobalCb.nSap[routeCb->rteCfg.nSapId];
                        }
                     }
                     if (nSapCb == (ItNSapCb *) NULLP)
                     {
                        nSapCb = dpcCb->nSap;      
                     }
                     if (nSapCb != (ItNSapCb *) NULLP)
                     {
                        if ((nSapCb->sntCfg.suType == LIT_SP_MTP3) && 
                            (nSapCb->sntSta.hlSt == LIT_SAP_BOUND) &&
                            (dpcCb->dpcSt == IT_DPC_UNAVAILABLE) &&
                            (dpcCb->dpcStSs7 == IT_DPC_AVAILABLE))
                        {
                           dpcCb->dpcSt     = IT_DPC_AVAILABLE;
                        }
                     }
                     break;
#endif /* ITSG */
                  case LIT_RTTYPE_LOCAL:
                  {
                     if (routeCb != (ItRouteCb *)NULLP)
                     {
                        /* Get NSAP CB from route if possible */
                        if (routeCb->rteCfg.nSapIdPres == TRUE)
                        {
                           nSapCb = itGlobalCb.nSap[routeCb->rteCfg.nSapId];
                        }
                        else
                        {
                           if (routeCb->rteCfg.rtFilter.sioMask & 0x0F)
                           {
                              (Void) itUiGetNSap(dpcCb->nwk->nwkCfg.nwkId,
                                 routeCb->rteCfg.rtFilter.sio, FALSE,
                                 &nSapCb);
                           }
                        }
                     }
                     else
                     {
                        /* routing DPC's nSap will be NULLP if nSapIdPres 
                         * was FALSE 
                         */
                        nSapCb = dpcCb->nSap;
                     }
                     if (nSapCb == (ItNSapCb *)NULLP)
                     {
                        /* Still no NSAP found, do a search */
                        SpId spId;
                        for (spId = 0;
                           (spId < itGlobalCb.genCfg.maxNmbNSap) && 
                           (userUp == FALSE);
                           spId++)
                        {
                           nSapCb = itGlobalCb.nSap[spId];
                           if (nSapCb != (ItNSapCb *)NULLP)
                           {
                              if (nSapCb->nwk == dpcCb->nwk)
#ifdef ITSG
                              if (nSapCb->sntCfg.suType != LIT_SP_MTP3)
#endif
                              {
                                 if (nSapCb->sntSta.hlSt == LIT_SAP_BOUND)
                                 {
                                    userUp = TRUE;
                                 }
                              }
                           }
                        }
                     }
                     else
                     {
                        if (nSapCb->sntSta.hlSt == LIT_SAP_BOUND)
                        {
                           userUp = TRUE;
                        }
                     }
                     if ((userUp == TRUE) && 
                         (dpcCb->dpcSt == IT_DPC_UNAVAILABLE))
                     {
                        dpcCb->dpcSt = IT_DPC_AVAILABLE;
                     }
                     break;
                  }
                  case LIT_RTTYPE_PS:
                  {
                     /* DPC status is based on status of PSs */
                     if ((psCb->psSta.asSt == LIT_AS_ACTIVE) ||
                         (psCb->psSta.asSt == LIT_AS_PENDING))
                     {
                        U16 i;      /* loop index */
                        U16 j;      /* loop index */
                        /* 
                         * In pending state, we may not have any active peers,
                         * but must still assume available.
                         */
                        if (psCb->psSta.asSt == LIT_AS_PENDING)
                        {
                           dpcCb->dpcSt = IT_DPC_AVAILABLE;
                        }
                        for (j = 0; j < LIT_MAX_SEP; j++)
                        {
                           for (i = 0; i < psCb->psSta.psStaEndp[j].nmbAct; i++)
                           {
                              UConnId assocId; /* Assoc ID */
                              /* it001.106 : modifications, correct assocId is 
                                             used */
                              assocId = IT_PSPnENDP2ASSOC(psCb->psSta.\
                                              psStaEndp[j].actPsp[i], j);
                              /*
                               * DPC availability and congestion status is 
                               * evaluated with respect to the SSNM status
                               * of the set of active peers
                               */
                              /* If pspDpcSt[assocId] == IT_DPC_RESTRICTED
                               * then also DPC dpc is still considered to be 
                               * available but through a restricted route */
                         
                              if (((dpcCb->pspDpcSt[assocId] == 
                                                               IT_DPC_AVAILABLE)
                                 || (dpcCb->pspDpcSt[assocId] == 
                                                             IT_DPC_RESTRICTED))
                                  && (dpcCb->dpcSt == IT_DPC_UNAVAILABLE))
                              {
                                 dpcCb->dpcSt = IT_DPC_AVAILABLE;
                              }
                              if ((dpcCb->nwk->nwkCfg.ssf == SSF_NAT) ||
                                  (dpcCb->nwk->nwkCfg.dpcLen == DPC16))
                              {
                                 /* Stateful congestion control */
                                 if (dpcCb->pspDpcCong[assocId] > 
                                                               dpcCb->congLevel)
                                 {
                                    dpcCb->congLevel = 
                                                     dpcCb->pspDpcCong[assocId];
                                 }
                                 /* incorporate PS congestion (local cong) */
                                 if (psCb->congLevel > dpcCb->congLevel)
                                 {
                                    dpcCb->congLevel  = psCb->congLevel;
                                 }
                             }
                          } /* end of for on psCb->psSta.psStaEnd[j].nmbAct */
                        } /* end of for (j = 0; j < LIT_MAX_SEP; j++) */
                     }
                     else
                     {
                        if (psCb->psCfg.reqAvail == TRUE)
                        {
                           /* this PS is required but not active */
                           dpcCb->dpcSt      = IT_DPC_UNAVAILABLE;
                           dpcCb->congLevel  = SN_PRI0;
                           done = TRUE;
                        }
                     }
                     break;
                  }
                  default:
                     RETVALUE(RFAILED);
               }
            } /* end while */
         }
         else if (dpcCb->type == IT_DPCCB_NONROUTE)
         {
            routeCb           = (ItRouteCb *)NULLP;
            dpcCb->dpcSt      = IT_DPC_UNAVAILABLE;
            dpcCb->congLevel  = SN_PRI0;
            done = FALSE;
            /* Find global route(s) for this non-routing DPC */
            while ((itMifGetNextGlobalMatch(dpcCb->nwk->nwkCfg.nwkId,
                                            dpcCb->dpc, &routeCb) == ROK) &&
                    done == FALSE)
            {
               if (routeCb->rteCfg.rtType == LIT_RTTYPE_PS)
               {
                  /* DPC status is based on status of PSs */
                  if ((routeCb->owner->psSta.asSt == LIT_AS_ACTIVE) ||
                      (routeCb->owner->psSta.asSt == LIT_AS_PENDING))
                  {
                     U32 i;            /* loop index */
                     U32 k;            /* loop index */
                     for (i = 0; i < LIT_MAX_SEP; i++)
                     {
                        UConnId  assocId; /* Assoc ID */
                        for (k = 0; k < routeCb->owner->psSta.psStaEndp[i].\
                                        nmbAct; k++)
                        {
                           /* it001.106 : modifications, correct assoc Id is
                                          used */
                           assocId = IT_PSPnENDP2ASSOC(routeCb->owner->psSta.\
                                            psStaEndp[i].actPsp[k], i);
                           /*
                            * DPC availability and congestion status is 
                              evaluated with respect to the SSNM status of the
                              set of * active peers */
                           /* If pspDpcSt[assocId] == IT_DPC_RESTRICTED 
                            * then also DPC dpc is still considered to be 
                              available * but through a restricted route */
                           if (((dpcCb->pspDpcSt[assocId] == IT_DPC_AVAILABLE) 
                                 || (dpcCb->pspDpcSt[assocId] == 
                                                             IT_DPC_RESTRICTED))
                                   && (dpcCb->dpcSt == IT_DPC_UNAVAILABLE))
                           {
                              dpcCb->dpcSt = IT_DPC_AVAILABLE;
                           }
                           if ((dpcCb->nwk->nwkCfg.ssf == SSF_NAT) ||
                               (dpcCb->nwk->nwkCfg.dpcLen == DPC16))
                           {
                              /* Stateful congestion control */
                              if (dpcCb->pspDpcCong[assocId] > dpcCb->congLevel)
                              {
                                 dpcCb->congLevel  = dpcCb->pspDpcCong[assocId];
                              }
                              /* incorporate PS congestion (local congestion) */
                              if (routeCb->owner->congLevel > dpcCb->congLevel)
                              {
                                 dpcCb->congLevel  = routeCb->owner->congLevel;
                              }
                           }   
                        } /* end for on k < routeCb->owner->psSta.psStaEndp[i].
                           * nmbAct */
                     } /* end of for on LIT_MAX_SEP */
                  }
                  else
                  {
                     if (routeCb->owner->psCfg.reqAvail == TRUE)
                     {
                        /* this PS is required but not active */
                        dpcCb->dpcSt      = IT_DPC_UNAVAILABLE;
                        dpcCb->congLevel  = SN_PRI0;
                        done              = TRUE;
                     }
                  }
               } /* end if rtType == LIT_RTTYPE_PS */
            }
         } /* end if IT_DPCCB_NONROUTE */
         break;

#ifdef ITSG

      /* next 2 cases fall through */
      case IT_MIF_RST_BEG:
         if ((itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP) && 
             (dpcCb->type == IT_DPCCB_SS7))
         {
            dpcCb->dpcStSs7  = IT_DPC_UNAVAILABLE;
            dpcCb->congLevel = SN_PRI0;
            itTcStartTimer(&dpcCb->tmrPoll, (PTR)dpcCb,
               IT_TMR_STA_POLL, &itGlobalCb.genCfg.tmr.tmrMtp3Sta);
         }
         else
         {
            RETVALUE(RFAILED);
         }
         break;
      case IT_MIF_PC_AVA:
         if ((itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP) && 
             (dpcCb->type == IT_DPCCB_SS7))
         {
         /* if an event IT_MIF_PC_AVA is received for a point
          * code & if the point code is not congested then it 
          * should be made available in any condition. This 
          * change was required to satisfy check dpcStSs7 ===  IT_DPC_AVAILABLE
          *  in case of event IT_MIF_PC_SUM in this function above 
          * Previously we're removing the congestion also at the reception of 
          * this event but the congestion level should be maintained and
          * state should be changed to congested if the congestion level 
          * is not zero.*/

            dpcCb->dpcSt      = IT_DPC_AVAILABLE;
         }
         else
         {
            RETVALUE(RFAILED);
         }
         break;
      /* New case statement added for new event type generated
       * when Destination Restricted message is received from 
       * MTP3 */
      case IT_MIF_PC_RST:
         if ((itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP) && 
             (dpcCb->type == IT_DPCCB_SS7))
         {
            dpcCb->dpcSt      = IT_DPC_RESTRICTED;
         }
         else
         {
            RETVALUE(RFAILED);
         }
         break;
      case IT_MIF_PC_UNA:
         if ((itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP) && 
             (dpcCb->type == IT_DPCCB_SS7))
         {
            dpcCb->dpcSt     = IT_DPC_UNAVAILABLE;
            dpcCb->dpcStSs7  = IT_DPC_UNAVAILABLE;
            dpcCb->congLevel = SN_PRI0;
         }
         else
         {
            RETVALUE(RFAILED);
         }
         break;
      case IT_MIF_PC_CON:
         if ((itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP) && 
             (dpcCb->type == IT_DPCCB_SS7))
         {
            if ((dpcCb->nwk->nwkCfg.ssf == SSF_NAT) ||
                (dpcCb->nwk->nwkCfg.dpcLen == DPC16))
            {
               dpcCb->congLevel  = congLevel;
            }
            else
            {
               dpcCb->congLevel = SN_PRI0;
            }
         }
         else
         {
            RETVALUE(RFAILED);
         }
         break;
      /* the following 2 cases fall through */
      case IT_MIF_PC_UPU:
      case IT_MIF_RST_END:
         break;
#endif /* ITSG */
      default:
         RETVALUE(RFAILED);
   } /* end switch */

#ifdef ZV
  /* dpcCB state change Update should take place if dpcEv is
     not IT_MIF_PC_CHANGED (this dpcEv takes place only in case of
     Route configuration/deletion, hence it will be taken care by
     route updates  */
     /* For IT_MIF_PC_UPU & IT_MIF_RST_END : no state is changed for dpcCb */
   if ((dpcEv != IT_MIF_PC_CHANGED)
#ifdef ITSG
       && (dpcEv != IT_MIF_PC_UPU) 
       && (dpcEv != IT_MIF_RST_END)
#endif
      )
   {
      /* dpcCB state change Update should take place */ 
      zvRTUpd(CMPFTHA_ACTN_MOD, ZV_DPCCB,
                      (U8)((dpcEv == IT_MIF_PC_CON) ? CMPFTHA_UPDTYPE_NORMAL :
                          CMPFTHA_UPDTYPE_SYNC), (Void *) dpcCb, NULLP);
   }
#endif


   RETVALUE(ROK);
} /* end of itMifCalcDpcStatus */


/*
*
*       Fun:   itMifGetNextInCluster
*
*       Desc:  Called by MIF to get successive routes in a cluster
*
*       Ret:
*
*       Notes: <None>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMifGetNextInCluster
(
ItDpcCb     *dpcCb,           /* DPC control block */
U8          *type,            /* route type */
ItPsCb      **owner,          /* route owner */
U16         *idx,             /* cluster index */
ItRouteCb   **routeCbPtr      /* route CB, if available */
)
#else
PUBLIC S16 itMifGetNextInCluster(dpcCb, type, owner, idx, routeCbPtr)
ItDpcCb     *dpcCb;           /* DPC control block */
U8          *type;            /* route type */
ItPsCb      **owner;          /* route owner */
U16         *idx;             /* cluster index */
ItRouteCb   **routeCbPtr;     /* route CB, if available */
#endif
{
   TRC2(itMifGetNextInCluster)

   if (cmLListLen(&dpcCb->routes) > 0)
   {
      if ((*idx == 0) || (*routeCbPtr == (ItRouteCb *)NULLP))
      {
         *routeCbPtr = (ItRouteCb *)cmLListFirst(&dpcCb->routes);
         *idx        = 0;
      }
      else
      {
         cmLListCrnt(&dpcCb->routes) = &(*routeCbPtr)->node;
         *routeCbPtr = (ItRouteCb *)cmLListNext(&dpcCb->routes);
      }

      if (*routeCbPtr == (ItRouteCb *)NULLP)
      {
         RETVALUE(ROKDNA);
      }

      *owner   = (*routeCbPtr)->owner;
      *type    = (*routeCbPtr)->rteCfg.rtType;
   }
   else
   {
      if ((*idx) >= 1)
      {
         RETVALUE(ROKDNA);
      }
      /* Standalone (routing) DPC CB */
      *owner      = dpcCb->owner;
      *type       = IT_DPC2RTTYPE(dpcCb->type);
      *routeCbPtr = (ItRouteCb *) NULLP;
   } /* end else */

   (*idx)++;

   RETVALUE(ROK);
} /* end of itMifGetNextInCluster */


/*
*
*       Fun:   itMifGetNextGlobalMatch
*
*       Desc:  Called by MIF to get successive global route matches by
*              nwkId and DPC value
*
*       Ret:
*
*       Notes: <None>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMifGetNextGlobalMatch
(
U8          nwkId,            /* network to match */
Dpc         dpc,              /* DPC to match */
ItRouteCb   **routeCbPtr      /* route CB, if available */
)
#else
PUBLIC S16 itMifGetNextGlobalMatch(nwkId, dpc, routeCbPtr)
U8          nwkId;            /* network to match */
Dpc         dpc;              /* DPC to match */
ItRouteCb   **routeCbPtr;     /* route CB, if available */
#endif
{
   TRC2(itMifGetNextGlobalMatch)

   if (*routeCbPtr == (ItRouteCb *)NULLP)
   {
      *routeCbPtr = (ItRouteCb *)cmLListFirst(&itGlobalCb.addrTrn.rtList);
   }
   else
   {
      cmLListCrnt(&itGlobalCb.addrTrn.rtList) = &(*routeCbPtr)->node;
      *routeCbPtr = (ItRouteCb *)cmLListNext(&itGlobalCb.addrTrn.rtList);
   }

   while (*routeCbPtr != (ItRouteCb *)NULLP)
   {
      if (((*routeCbPtr)->rteCfg.nwkId == nwkId) &&
          (((*routeCbPtr)->rteCfg.rtFilter.dpc &
            (*routeCbPtr)->rteCfg.rtFilter.dpcMask) ==
           (dpc & (*routeCbPtr)->rteCfg.rtFilter.dpcMask)))
      {
         /* Found a global route with matching network and DPC filter */
         break;
      }

      *routeCbPtr = (ItRouteCb *)cmLListNext(&itGlobalCb.addrTrn.rtList);
   }

   if (*routeCbPtr == (ItRouteCb *)NULLP)
   {
      RETVALUE(ROKDNA);
   }

   RETVALUE(ROK);
} /* end of itMifGetNextGlobalMatch */


#ifdef ITSG
/*
*
*       Fun:   itMifRestart
*
*       Desc:  Called by MIF when a network restart occurs at the SG
*
*       Ret:
*
*       Notes: <None>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMifRestart
(
U8 nwkId                      /* Network context ID */
)
#else
PUBLIC S16 itMifRestart(nwkId)
U8 nwkId;                     /* Network context ID */
#endif
{
   ItNwkCb  *nwkCb;           /* network CB */
   ItDpcCb  *dpcCb;           /* DPC CB */
   U16      ret;              /* return value */

   TRC2(itMifRestart)

   nwkCb          = itGlobalCb.nwk[nwkId];
   /* Network Restart Timer: make the network restart   *
    * transient if and only if restart timer is enabled */
   if (itGlobalCb.genCfg.tmr.tmrRestart.enb == TRUE)
   {
      nwkCb->restart = TRUE;
      itTcStartTimer(&nwkCb->tmrRestart, (PTR)nwkCb, IT_TMR_NWK_RST,
         &itGlobalCb.genCfg.tmr.tmrRestart);
   }


   /* Initialize status of all SS7 DPCs in network */
   dpcCb = (ItDpcCb *) NULLP;
   while (itAtGetDpcs(nwkId, (Dpc) 0, (Dpc) 0, &dpcCb) == ROK)
   {
      if (dpcCb->type == IT_DPCCB_SS7)
      {
         if ((ret = itMifCalcDpcStatus(dpcCb, IT_MIF_RST_BEG, 0)) != ROK)
         {
            RETVALUE(ret);
         }
      }
   }

   RETVALUE(ROK);
} /* end of itMifRestart */
#endif /* ITSG */

/**********************************************************************
 *                        CONGESTION CONTROLLER
 **********************************************************************/

/*
*
*       Fun:   itCcCongStart
*
*       Desc:  Called by LI to indicate start of congestion on the
*              SCTP association
*
*       Ret:   Failure:
*
*              Success:
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itCcCongStart
(
ItAssocCb *assocCb            /* association CB */
)
#else
PUBLIC S16 itCcCongStart(assocCb)
ItAssocCb *assocCb;           /* association CB */
#endif
{
   TRC2(itCcCongStart)

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
            "itCcCongStart(assocCb)\n"));

   /* it016.106 - Update "cong" statistics. */
#ifdef LITV3
   if (assocCb->congActive != TRUE)
   {
      /* Association hits congestion update congestion counter. */
      IT_STS_INC_ASSOC_CONG(assocCb, SN_PRI0);

      /* Take time stamp when association became congested. */
      SGetSysTime(&assocCb->ticksCong);
   }
#endif /* LITV3 */
   assocCb->congActive = TRUE;
#ifdef ZV
    /* Update assoc CongActive */
    zvRTUpd(CMPFTHA_ACTN_MOD, ZV_ASSOCCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) assocCb, NULLP);
#endif
   /* Start (or reset) deadlock avoidance timer */
   itTcStartTimer(&assocCb->tmrCong, (PTR)assocCb, IT_TMR_CONGPOLL,
      &assocCb->sctSap->sctCfg.tmrSta);

   RETVALUE(ROK);

} /* end of itCcCongStart */

/*
*
*       Fun:   itCcDeadlockTimeout
*
*       Desc:  Called by TC to indicate timeout of the deadlock timer
*
*       Ret:   <none>
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC Void itCcDeadlockTimeout
(
ItAssocCb *assocCb            /* association CB */
)
#else
PUBLIC Void itCcDeadlockTimeout(assocCb)
ItAssocCb *assocCb;           /* association CB */
#endif
{
   TRC2(itCcDeadlockTimeout)

   (Void) itLiStaReq(assocCb, SCT_GET_FLC_INFO);
   /* Start a deadlock avoidance timer */
   itTcStartTimer(&assocCb->tmrCong, (PTR)assocCb, IT_TMR_CONGPOLL,
      &assocCb->sctSap->sctCfg.tmrSta);

   RETVOID;
} /* end of itCcDeadlockTimeout */


/*
*
*       Fun:   itCcCongEnd
*
*       Desc:  Called by LI to indicate end of congestion on the SCTP
*              association. Sends the oldest message in the congestion queue
*              and then re-requests the flow control status from SCTP
*
*       Ret:   Failure:
*
*              Success:
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itCcCongEnd
(
ItAssocCb *assocCb            /* association CB */
)
#else
PUBLIC S16 itCcCongEnd(assocCb)
ItAssocCb *assocCb;           /* association CB */
#endif
{
   S16   ret;                 /* return value */
   Bool  done;                /* TRUE if loop done */
#ifdef ZV
   Bool  oldCongActive;       /* Congestion was active or not */
#endif

   TRC2(itCcCongEnd)

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
            "itCcCongEnd(assocCb)\n"));

   /* Stop the deadlock timer */
   itTcStopTimer(&assocCb->tmrCong);
   done = FALSE;

#ifdef ZV
   oldCongActive = assocCb->congActive;
#endif
   while ((assocCb->congActive == TRUE) && (cmLListLen(&assocCb->congQ) > 0)
      && (done == FALSE))
   {
      ItMupMsg *msg;          /* MUP message */
      U8       pre_pri;       /* pre-queueing priority */
      U8       post_pri;      /* post-queueing priority */

      pre_pri  = IT_CONGPRIOR(cmLListLen(&assocCb->congQ));
      /* Remove message from head of queue */
      msg      = (ItMupMsg *)cmLListDelFrm(&assocCb->congQ,
                 cmLListFirst(&assocCb->congQ));
      if (msg != (ItMupMsg *)NULLP)
      {
         msg->msgState = IT_MSG_RDY_MMH;
         if ((ret = itMupData(msg)) != ROK)
         {
            /* if DPC has become unavailable, we'll get here */
            IT_DROPDATA(msg->mBuf);
            IT_FREE(sizeof(ItMupMsg), msg);
            itGlobalCb.nmbMsg--;
            /* Try next message */
            continue;
         }
      }
      post_pri = IT_CONGPRIOR(cmLListLen(&assocCb->congQ));
      if (post_pri < pre_pri)
      {
         /* Inform MIF of congestion event */
         if ((ret = itMifCongEvt(assocCb, post_pri, (ItMupMsg *)NULLP))
            != ROK)
         {
            RETVALUE(ret);
         }
      }
      if (cmLListLen(&assocCb->congQ) == 0)
      {
         assocCb->congActive  = FALSE;
         /* In case the first threshold has been set to 0 */
         post_pri             = SN_PRI0;
      }
      else
      {
         /*
          * Keep a tight rein on the flow to the service provider by polling
          * the state of the input queue after each message is sent. We expect a
          * status confirm from the provider, which is used to continue the
          * process of emptying the congestion queue.
          */
         (Void) itLiStaReq(assocCb, SCT_GET_FLC_INFO);
         /* Start a deadlock avoidance timer */
         itTcStartTimer(&assocCb->tmrCong, (PTR)assocCb, IT_TMR_CONGPOLL,
            &assocCb->sctSap->sctCfg.tmrSta);
         /* ... and exit the loop */
         done = TRUE;
      }
   } /* end while */
   if (cmLListLen(&assocCb->congQ) == 0)
   {
      /* for robustness' sake */
      assocCb->congActive = FALSE;
   }

   /* it016.106 - Update "durCong" statistics. */
#ifdef LITV3
   if ((assocCb->congActive == FALSE) && (assocCb->ticksCong))
   {
      Ticks  dur;     /* time duration */
      Ticks  curTime; /* current timestamp */

      ret = SGetSysTime(&curTime);
      if (ret != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         ITLOGERROR(ERRCLS_DEBUG, EITXXX, (ErrVal) ret, 
                    "itCcPspDn: SGetSysTime failed");
#endif /* ERRCLS_DEBUG */
      }
      else
      {
         dur = curTime - assocCb->ticksCong;
         IT_STS_UPD_ASSOC_DUR_CONG(assocCb, dur);
      }
      assocCb->ticksCong = 0;
   }
#endif /* LITV3 */

#ifdef ZV
   /* Update the assoc congestion only if it got changed */
   if (oldCongActive != assocCb->congActive)
   {
      /* Update assoc CongActive */
      zvRTUpd(CMPFTHA_ACTN_MOD, ZV_ASSOCCB,
                        CMPFTHA_UPDTYPE_SYNC, (Void *) assocCb, NULLP);
   }
#endif

   RETVALUE(ROK);

} /* end of itCcCongEnd */





/*
*
*       Fun:   itCcPspDn
*
*       Desc:  Called when PSP goes down. Clears the congestion queue by
*              re-routing the messages.
*
*       Ret:   Failure:
*
*              Success:
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itCcPspDn
(
ItAssocCb *assocCb            /* association CB */
)
#else
PUBLIC S16 itCcPspDn(assocCb)
ItAssocCb *assocCb;           /* association CB */
#endif
{
   S16   ret;                 /* return value */

   TRC2(itCcPspDn)

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
            "itCcPspDn(assocCb)\n"));

   /* Stop the deadlock timer */
   itTcStopTimer(&assocCb->tmrCong);

   if (assocCb->congActive == FALSE)
      RETVALUE(ROK);
   /* Inform MIF of congestion event */
   if ((ret = itMifCongEvt(assocCb, SN_PRI0, (ItMupMsg *)NULLP))
      != ROK)
   {
      RETVALUE(ret);
   }

   while (cmLListLen(&assocCb->congQ) > 0)
   {
      ItMupMsg *msg;          /* MUP message */

      /* Remove message from head of queue */
      msg      = (ItMupMsg *)cmLListDelFrm(&assocCb->congQ,
                 cmLListFirst(&assocCb->congQ));
      if (msg != (ItMupMsg *)NULLP)
      {
         msg->msgState = IT_MSG_ROUTED_ONE;

         if ((ret = itMupData(msg)) != ROK)
         {
            /* if DPC has become unavailable, we'll get here */
            IT_DROPDATA(msg->mBuf);
            IT_FREE(sizeof(ItMupMsg), msg);
            itGlobalCb.nmbMsg--;
            /* Try next message */
            continue;
         }
      }
   } /* end while */
   if (cmLListLen(&assocCb->congQ) == 0)
   {
      /* for robustness' sake */
      assocCb->congActive = FALSE;
   }

   /* it016.106 - Update "durCong" statistics. */
#ifdef LITV3
   if (assocCb->ticksCong)
   {
      Ticks  dur;     /* time duration */
      Ticks  curTime; /* current timestamp */

      ret = SGetSysTime(&curTime);
      if (ret != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         ITLOGERROR(ERRCLS_DEBUG, EITXXX, (ErrVal) ret, 
                    "itCcPspDn: SGetSysTime failed");
#endif /* ERRCLS_DEBUG */
      }
      else
      {
         dur = curTime - assocCb->ticksCong;
         IT_STS_UPD_ASSOC_DUR_CONG(assocCb, dur);
      }
      assocCb->ticksCong = 0;
   }
#endif /* LITV3 */

#ifdef ZV
   /* Update the assoc congestion : it gets changed in this function */
   /* Update assoc CongActive */
   zvRTUpd(CMPFTHA_ACTN_MOD, ZV_ASSOCCB,
                        CMPFTHA_UPDTYPE_SYNC, (Void *) assocCb, NULLP);
#endif
   RETVALUE(ROK);

} /* end of itCcPspDn */



/*
*
*       Fun:   itCcChkQueue
*
*       Desc:  Called by MUP to check if congestion queue is active. If
*              active, queue the message in its association MUPM queue
*              and set the message state to indicate that it has been
*              queued. Else exit.
*
*       Ret:   Failure:
*
*              Success:
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itCcChkQueue
(
ItMupMsg *msg                 /* User message */
)
#else
PUBLIC S16 itCcChkQueue(msg)
ItMupMsg *msg;                /* User message */
#endif
{
   ItAssocCb *assocCb;        /* association CB */

   TRC2(itCcChkQueue)

   ITDBGP(DBGMASK_MI|IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf,
               "itCcChkQueue(assocCb)\n"));

   /* Get association to remote peer */
   assocCb = msg->routeTgt2;

   /* If congestion queue is active, the message must be queued or dropped */
   if (assocCb->congActive == TRUE)
   {
      S16      ret;           /* return value */
      U8       pre_pri;       /* pre-queueing priority */
      U8       post_pri;      /* post-queueing priority */
            
      pre_pri  = IT_CONGPRIOR(cmLListLen(&assocCb->congQ));
      if ((cmLListLen(&assocCb->congQ) + 1) > itGlobalCb.genCfg.qSize)
      {
         U8 tmp;
         tmp = (U8)(((itGlobalCb.nwk[msg->nwkId]->nwkCfg.ssf == SSF_NAT) || 
                (itGlobalCb.nwk[msg->nwkId]->nwkCfg.dpcLen == DPC16)) ? 
                 (U8)IT_CONGPRIOR(cmLListLen(&assocCb->congQ)) : 0);
         msg->msgState = IT_MSG_DISCARD;
         ret = itMifDpcEvt(FALSE, (UConnId) NULLD, IT_MIF_DATAREQ, 
                                IT_MIF_PC_CON, msg->nwkId,
                                msg->dpc, msg->opc,
                                tmp,
                                (SrvInfo)0,
                                       (ItDpcCb *)(msg->dpcCb));
         if (ret != ROK)
         {
            RETVALUE(ret);
         }
         RETVALUE(ROK);
      }
      /* Queue the message in the congestion queue for this association */
      cmLListAdd2Tail(&assocCb->congQ, &msg->llHdr);
      msg->msgState = IT_MSG_QUEUED_CC;
      post_pri  = IT_CONGPRIOR(cmLListLen(&assocCb->congQ));
      if (post_pri > pre_pri)
      {
         /* it016.106 - Update congestion statistics */
#ifdef LITV3
         IT_STS_INC_ASSOC_CONG(assocCb, post_pri);
#endif /* LITV3 */

         /* Inform MIF of congestion event */
         if ((ret = itMifCongEvt(assocCb, post_pri, msg))
            != ROK)
         {
            RETVALUE(ret);
         }
      }
   }

   RETVALUE(ROK);
} /* end of itCcChkQueue */

/************************************************************************
 *       M3UA MESSAGE HANDLER BLOCK
 ************************************************************************/

/*
*
*       Fun:   itMmhHdrSend
*
*       Desc:  Add the common header and send the message
*
*       Ret:   Failure:
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhHdrSend
(
ItAssocCb   *assocCb,         /* association CB */
Buffer      **mBuf,           /* pointer to message */
U16         msgType,          /* M3UA message type */
LnkSel      sls               /* Link selector for data message */
)
#else
PUBLIC S16 itMmhHdrSend(assocCb, mBuf, msgType, sls)
ItAssocCb   *assocCb;         /* association CB */
Buffer      **mBuf;           /* pointer to message */
U16         msgType;          /* M3UA message type */
LnkSel      sls;              /* Link selector for data message */
#endif
{
   MsgLen   len;              /* message length */
   U32      tmp32;            /* temporary U32 */
   U16      tmp16;            /* temporary U16 */
   U8       hdr[8];           /* temporary buffer for M3UA header */
   S16      ret;              /* return value */

   TRC2(itMmhHdrSend)
   
   if (mBuf == (Buffer **)NULLP)
   {
      RETVALUE(RFAILED);
   }
   (Void) SFndLenMsg(*mBuf, &len);

   /* SAddPreMsgMult works in reverse, so we build the header backwards */
   hdr[7]   = IT_M3UA_VERSION;
   hdr[6]   = 0; /* spare */
   hdr[5]   = (U8) GetHiByte(msgType); /* message class */
   hdr[4]   = (U8) GetLoByte(msgType); /* message type */
   tmp32    = (U32)len + 8; /* length includes 8 header bytes */
   tmp16    = (U16) GetHiWord(tmp32);
   hdr[3]   = (U8) GetHiByte(tmp16);
   hdr[2]   = (U8) GetLoByte(tmp16);
   tmp16    = (U16) GetLoWord(tmp32);
   hdr[1]   = (U8) GetHiByte(tmp16);
   hdr[0]   = (U8) GetLoByte(tmp16);

   if ((ret = SAddPreMsgMult((Data *)hdr, 8, *mBuf)) != ROK)
   {
      RETVALUE(ret);
   }

   ret = itSmDatReq(assocCb, mBuf,
                    (Bool)((msgType == IT_M3UA_DATA) ? TRUE : FALSE), sls);

   RETVALUE(ret);
} /* end of itMmhHdrSend */


/*
*
*       Fun:   itMmhPkString
*
*       Desc:  Pack a string parameter
*
*       Ret:   Failure:
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 itMmhPkString
(
Buffer   **mBuf,              /* pointer to pointer to message */
Txt      *str,                /* string */
U16      tag                  /* M3UA parameter tag */
)
#else
PRIVATE S16 itMmhPkString(mBuf, str, tag)
Buffer   **mBuf;              /* pointer to pointer to message */
Txt      *str;                /* string */
U16      tag;                 /* M3UA parameter tag */
#endif
{
   U16 i;                     /* loop index */
   U16 len;                   /* string length */
   S16 ret;                   /* return value */

   TRC2(itMmhPkString)
   
   if (mBuf == (Buffer **)NULLP)
   {
      RETVALUE(RFAILED);
   }

   if (str != (Txt *)NULLP)
   {
      len = cmStrlen((U8 *)str);
      if (len > 0)
      {
         IT_MMH_PK_U16(*mBuf, tag, ret);
         IT_MMH_CHKLOG(*mBuf, ret, EIT180)
         IT_MMH_PK_U16(*mBuf, IT_MMH_LEN_ADJ(len), ret);
         IT_MMH_CHKLOG(*mBuf, ret, EIT181)
         ret = SAddPstMsgMult((Data *)str, len, *mBuf);
         IT_MMH_CHKLOG(*mBuf, ret, EIT182)
         for (i = 0; i < ((sizeof(U32) - (len % sizeof(U32))) % sizeof(U32));
            i++)
         {
            IT_MMH_PK_U8(*mBuf, 0, ret);
            IT_MMH_CHKLOG(*mBuf, ret, EIT183)
         }
      }
   }

   RETVALUE(ROK);
} /* end of itMmhPkString */


/*
*
*       Fun:   itMmhExamString
*
*       Desc:  Examine and decode a string parameter
*
*       Ret:   Failure:
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 itMmhExamString
(
Buffer   **mBuf,              /* pointer to message */
Txt      *str,                /* string */
U16      len,                 /* length of string */
U16      *idx                 /* index in message */
)
#else
PRIVATE S16 itMmhExamString(mBuf, str, len, idx)
Buffer   **mBuf;               /* pointer to message */
Txt      *str;                /* string */
U16      len;                 /* length of string */
U16      *idx;                /* index in message */
#endif
{
   U16   i;                   /* loop index */
   S16   ret;                 /* return value */
   U8    tmp8;                /* temporary U8 */

   TRC2(itMmhExamString)

   for (i = 0; i < len; i++)
   {
      IT_MMH_EXAM_U8(*mBuf, tmp8, *idx, ret)
      IT_MMH_CHKLOG(*mBuf, ret, EIT184)
      str[i] = (Txt) tmp8;
   }
   str[i] = (Txt) 0;

   /* skip the padding octets */
   *idx = (U16)(*idx + (sizeof(U32) - (len % sizeof(U32))) % sizeof(U32));

   RETVALUE(ROK);
} /* end of itMmhExamString */


/*
*
*       Fun:   itMmhData
*
*       Desc:  Called by the MUP to request processing of a MUPM
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhData
(
ItMupMsg *msg                 /* user message */
)
#else
PUBLIC S16 itMmhData(msg)
ItMupMsg *msg;                /* user message */
#endif
{
   MsgLen   len;                     /* message length */
   S16      ret;                     /* return value */
   ItNwkApp nwkAppVal;               /* network appearance value */
   ItPspCb  *pspCb;                  /* PSP control block */
   U16      i;                       /* loop index */
   ItPsCb   *psCb = (ItPsCb *)NULLP; /* PS CB */
   U32      rtCtx;                  /* Routing Context */
   U8       pkArray[IT_MAX_M3UA_MSG_LEN];    /* Msg Packing array */
   U16      pkCtr;                  /* Pking array length */

   TRC2(itMmhData)

   rtCtx = 0;
   IT_ZERO(&pkArray[0], IT_MAX_M3UA_MSG_LEN)
   pkCtr = 0;
   /* Assemble M3UA message */
   (Void) SFndLenMsg(msg->mBuf, &len);
   /* prepend data tag and length */
   /* M3UA_PERF changes */
   IT_MMH_PREPK_U16((U16) IT_MMH_LEN_ADJ(len))
   IT_MMH_PREPK_U16(IT_M3UA_TAG_DATA)
   /* add the padding zeros */
   /* M3UA_PERF:*/ 
   /* The following loop adds byte at the end of mBuf whereas pkArray will 
      append at the begining */
   for (i = 0; i < ((sizeof(U32) - (len % sizeof(U32))) % sizeof(U32));
       i++)
   {
      IT_MMH_PK_U8(msg->mBuf, 0, ret);
      IT_MMH_CHKLOG(msg->mBuf, ret, EIT185)
   }
   
   pspCb       = msg->routeTgt2->owner;
   /* At ASP and IPSP SE, RC is not sent in outgoing Data */
   /* At SGP and IPSP DE, RC to be sent is of Outgoing remote PS */
   if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_ASP) ||
                ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
                 (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_DE)))
   {
      psCb = (ItPsCb *)msg->routeTgt1;
      /* Pack the RC in DATA msgs from Remote PS */
      if (psCb != NULLP)
      {
         rtCtx = psCb->psSta.psStaEndp[IT_ASSOC2SUID(msg->routeTgt2->assocId)].\
                 rteCtx[pspCb->pspCfg.pspId].rCtx;
      }
      /* M3UA_PERF changes */
      IT_MMH_PREPK_U32(rtCtx)
      IT_MMH_PREPK_U16(IT_MMH_LEN_ADJ(sizeof(U32)))
      IT_MMH_PREPK_U16(IT_M3UA_TAG_RCTX)
   } /* End of if pspType == "ASP/IPSP-DE */
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   else /* At ASP or IPSP SE */
   {
      ItPsId      lpsId;          /* Local PS Id */

      if (msg->originator != NULLP)
      {
         lpsId = ((ItNSapCb *)msg->originator)->lpsId;
         /* Check if the Local PS Id for originator NSAP is valid */
         if (lpsId != IT_INVALID_PS_ID)
         {
            psCb = itPsmFindPs(lpsId);
            /* Pack the RC in DATA msgs from Remote PS */
            if (psCb != NULLP)
            {
               rtCtx = psCb->psSta.psStaEndp[IT_ASSOC2SUID(
                     msg->routeTgt2->assocId)].rteCtx[pspCb->pspCfg.pspId].rCtx;
            }
            /* M3UA_PERF changes */
            IT_MMH_PREPK_U32(rtCtx)
            IT_MMH_PREPK_U16(IT_MMH_LEN_ADJ(sizeof(U32)))
            IT_MMH_PREPK_U16(IT_M3UA_TAG_RCTX)
         } /* if lpsId is valid */
      } /* if originator is not NULLP */
   } /* ASP or IPSP SE */
#endif

   nwkAppVal   = itGlobalCb.nwk[msg->nwkId]->nwkCfg.nwkApp[pspCb->pspCfg.pspId];

   /* prepend Network Appearance (if selected in msg options) */
   if (pspCb->pspCfg.nwkAppIncl == TRUE)
   {
      /* M3UA_PERF changes */
      IT_MMH_PREPK_U32(nwkAppVal);
      IT_MMH_PREPK_U16(IT_MMH_LEN_ADJ(sizeof(U32)))
      IT_MMH_PREPK_U16(IT_M3UA_TAG_NWKAPP)
   }
   /* M3UA_PERF changes */
   /* Add all the pkArray bytes to msg->mBuf */
   if (pkCtr != 0)
   {
      if ((ret = SAddPreMsgMult((Data *)&pkArray[0], pkCtr, msg->mBuf)) != ROK)
      {
         RETVALUE(ret);
      }
   }
   /* prepend Common Message Header */
   if ((ret = itMmhHdrSend(msg->routeTgt2, &msg->mBuf, IT_M3UA_DATA,
      msg->lnkSel))
      != ROK)
   {
      RETVALUE(ret);
   }
   IT_STS_INC_M3UA_TX(msg->routeTgt2, data);
   /*chenning add for msg trace*/
    ITDBGP(IT_DBGMASK_MSGTRACE, (itGlobalCb.itInit.prntBuf, 
    "\r\n[MSG Trace] M3UA>>>>SCTP (DPC(%x), OPC(%x), SrvInfo(%x), LnkSel(%x))\r\n\r\n", 
    msg->dpc, msg->opc, (U8)(0x0F & msg->srvInfo), msg->lnkSel));
   /* it023.106 - Update Data Tx sts for Remote PS */
#ifdef LITV6
   IT_STS_INC_TX_PS(msg->routeTgt1, IT_M3UA_DATA)
#endif /* LITV6 */
   RETVALUE(ROK);
} /* end of itMmhData */


/*
*
*       Fun:   itMmhDatInd
*
*       Desc:  Called by the SM to indicate an incoming message from an M3UA
*              peer. Decodes the Common Message Header and all the parameters.
*              The action taken depends on the message type.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhDatInd
(
ItAssocCb   *assocCb,         /* association CB */
Buffer      **mBuf,           /* pointer to  message */
SctStrmId   strmId            /* SCTP stream identifier */
)
#else
PUBLIC S16 itMmhDatInd(assocCb, mBuf, strmId)
ItAssocCb   *assocCb;         /* association CB */
Buffer      **mBuf;           /* pointer to message */
SctStrmId   strmId;           /* SCTP stream identifier */
#endif
{
   S16         ret;           /* return value */
   U8          tmp8;          /* temporary U8 */
   ItM3uaTag   tag[IT_M3UA_TAGARRAYSIZE]; /* parameter state array */
   Txt         info[LIT_MAX_INFO + 1];    /* INFO parameter value */
   ItRtCtx     rCtx[LIT_MAX_PSID];        /* Routing Context list */
   U16         rCtxLen;       /* Routing Context length */
   U16         i;             /* loop index */
   MsgLen      len;           /* message length */
   MsgLen      cur;           /* current message offset */
   U8          m3uaVer;       /* M3UA version */
   U16         msgType;       /* M3UA message type */
   U32         msgLen;        /* M3UA message length */
   Bool        fstPrmtDecd;   /* First parameter decoded */
   ItPspCb    *pspCb;         /* PSP control block */
   ItRtCtx     irCtx; /* Invalid routing context */
   U16         irCtxLen;      /* Invalid routing context length */
   ItRtCtx     nrCtx; /* new routing context  */
   U16         nrCtxLen;      /* new routing context length */
   ItPspId     pspId;         /* PSP Id */


   TRC2(itMmhDatInd)

   if (mBuf == (Buffer **)NULLP)
   {
      RETVALUE(RFAILED);
   }

   (Void) SFndLenMsg(*mBuf, &len);
   cur         = (MsgLen) 0;
   info[0]     = (Txt) 0;
   rCtxLen     = 0;
   pspId       = assocCb->owner->pspCfg.pspId;
   (Void) cmMemset((U8 *)&tag, 0, IT_M3UA_TAGARRAYSIZE * sizeof(ItM3uaTag));

   nrCtxLen    = 0;
   irCtxLen    = 0;
   nrCtx.rtCtx = 0;
   nrCtx.ntfySend  = FALSE;
   nrCtx.ntfyStaId = 0;
   nrCtx.thmType   = 0;
   irCtx.rtCtx = 0;
   irCtx.ntfySend  = FALSE;
   irCtx.ntfyStaId = 0;
   irCtx.thmType   = 0;

   /* Set parameter flags to FALSE */
   for (i = 0; i < IT_M3UA_TAGARRAYSIZE; i++)
   {
      tag[i].mand    = FALSE;
      tag[i].opt     = FALSE;
      tag[i].pres    = FALSE;
      tag[i].valid   = FALSE;
   }

   IT_MMH_SET_TAGS(tag);
   if (len < 8)
   {
      /* Invalid M3UA hdr */
      RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PROTO_ERR, mBuf, NULLD, 
                         (ItM3uaTag *) NULLP, (ItRtCtx *) NULLP, 0,
                          IT_M3UA_DFLT));
   }

   /* M3UA version */
   IT_MMH_EXAM_U8(*mBuf, m3uaVer, cur, ret)
   IT_MMH_CHKLOG(*mBuf, ret, EIT186)
   if (m3uaVer != IT_M3UA_VERSION)
   {
      /* Send an indication to the layer that invalid version is received */
      itMiStaInd(STITPSP, LCM_CATEGORY_PROTOCOL, LIT_EVENT_STATUS_IND, 
                 LIT_CAUSE_INV_VERSION, pspId);
      /* Invalid M3UA version: reply to peer with supported version and exit */
      RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_INV_VERSION, mBuf,
                          IT_M3UA_VERSION, (ItM3uaTag *) NULLP, (ItRtCtx *) 
                          NULLP, 0, IT_M3UA_DFLT));
   }
   /* spare */
   IT_MMH_EXAM_U8(*mBuf, tmp8, cur, ret)
   IT_MMH_CHKLOG(*mBuf, ret, EIT187)
   /* message class/type */
   IT_MMH_EXAM_U16(*mBuf, msgType, cur, ret)
   IT_MMH_CHKLOG(*mBuf, ret, EIT188)
   /* message length - includes common header length */
   IT_MMH_EXAM_U32(*mBuf, msgLen, cur, ret)
   IT_MMH_CHKLOG(*mBuf, ret, EIT189)
   /* it015.106 If message length is greater than the overall
      length of the message buffer, then it is a faulty scenario
      so send back an error */
   /* it020.106 - If any of the following checks on message length fails
    * then message length in M3UA message in invalid -
    * a) It should not be greater than SCT message buffer length.
    * b) It should atleast be 8. */
   if ((msgLen > (U32)len) ||
       (msgLen < 8))
   {
      RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR,
                         mBuf, NULLD, (ItM3uaTag *) NULLP, (ItRtCtx *) NULLP,
                         0, IT_M3UA_DFLT));
   } 
   else 
   {
      len = (MsgLen) msgLen;
   }
   msgLen -= 8; /* subtract size of common message header */


   itMiTrcInd(assocCb->sctSap->sctCfg.suId, LIT_MSG_RX, *mBuf);
   /* check for supported/unsupported message classes */
   switch (IT_MMH_MSGCLASS(msgType))
   {
      /* supported message classes: next 5 case fall through */
      case IT_MSGCLASS_MGMT:
      case IT_MSGCLASS_M3UA_XFER:
      case IT_MSGCLASS_SSNM:
      case IT_MSGCLASS_ASPSM:
      case IT_MSGCLASS_ASPTM:
         break;

      case IT_MSGCLASS_RKM:

         /* Check if the Dynamic Registration Procedures are supported */
         if (itGlobalCb.genCfg.drkmSupp != TRUE)
         {
            RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNSUP_MSGCLS, mBuf, 0,
                            (ItM3uaTag *) NULLP, (ItRtCtx *) NULLP, 
                             0, IT_M3UA_DFLT));
         }
         break;
      /* unsupported message classes */
      default:
         /* unsupported message classes: return error */
         RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNSUP_MSGCLS, mBuf, 0,
                            (ItM3uaTag *) NULLP, (ItRtCtx *) NULLP, 
                             0, IT_M3UA_DFLT));
   }
   /* Check that mgmt message must be received on stream ID 0 */
   if (((IT_MMH_MSGCLASS(msgType) == IT_MSGCLASS_MGMT) && (strmId != 0)) ||
       ((IT_MMH_MSGCLASS(msgType) == IT_MSGCLASS_M3UA_XFER) && (strmId == 0)))
   {
      RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_INV_STRMID, mBuf, 0,
                         (ItM3uaTag *) NULLP, (ItRtCtx *) NULLP, 0,
                          IT_M3UA_DFLT));
   }
   if  (((assocCb->assocSta->aspSt == LIT_ASP_DOWN)) &&
       ((IT_MMH_MSGCLASS(msgType)) != IT_MSGCLASS_MGMT) &&
       ((IT_MMH_MSGCLASS(msgType)) != IT_MSGCLASS_ASPSM))
   {
     /* for IPSP DE allow any message in down state */
     if (!((assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_IPSP) &&
           (assocCb->owner->pspCfg.ipspMode == LIT_IPSPMODE_DE)))
     {
        ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
               "itMmhDatInd(): message not allowed in down state "
               "(msg = %04X)\n", msgType));
        /* silent discard - no ERR message */
        IT_DROPDATA(*mBuf);
        RETVALUE(ROK);
     }
   }

   /* Determine fixed, mandatory and optional parameters for the message type */
   switch (msgType)
   {
      case IT_M3UA_ERROR:
      {
         /* Mandatory part */
         tag[IT_M3UA_TAG_IDX_ERRCODE].mand    = TRUE;
         /* Optional part */
         
         tag[IT_M3UA_TAG_IDX_ADPC].opt        = TRUE;

         tag[IT_M3UA_TAG_IDX_RCTX].opt        = TRUE;

         tag[IT_M3UA_TAG_IDX_NWKAPP].opt       = TRUE;

         tag[IT_M3UA_TAG_IDX_DIAG].opt        = TRUE;
         break;
      }
      case IT_M3UA_NOTIFY:
      {
         /* Mandatory part: status type | status code */
         tag[IT_M3UA_TAG_IDX_STATUS].mand     = TRUE;
         /* Optional part */
         tag[IT_M3UA_TAG_IDX_ASPID].opt       = TRUE;
         tag[IT_M3UA_TAG_IDX_RCTX].opt        = TRUE;
         tag[IT_M3UA_TAG_IDX_INFO].opt        = TRUE;
         break;
      }
      case IT_M3UA_DATA:
      {
         /* Mendatory part */
         tag[IT_M3UA_TAG_IDX_DATA].mand       = TRUE;
         /* Optional part */

         tag[IT_M3UA_TAG_IDX_CORELTN_ID].opt  = TRUE;

         tag[IT_M3UA_TAG_IDX_RCTX].opt        = TRUE;
         tag[IT_M3UA_TAG_IDX_NWKAPP].opt      = TRUE;
         break;
      }
      case IT_SSNM_SCON:
      {
         /* Mandatory part */
         tag[IT_M3UA_TAG_IDX_ADPC].mand       = TRUE;
         /* Optional part */
         tag[IT_M3UA_TAG_IDX_RCTX].opt        = TRUE;
         tag[IT_M3UA_TAG_IDX_NWKAPP].opt      = TRUE;
         tag[IT_M3UA_TAG_IDX_CONGLEVEL].opt   = TRUE;
         tag[IT_M3UA_TAG_IDX_INFO].opt        = TRUE;
         tag[IT_M3UA_TAG_IDX_CNCRNDPC].opt    = TRUE;
         break;
      }
      case IT_SSNM_DUPU:
      {
         /* Mandatory part */
         tag[IT_M3UA_TAG_IDX_ADPC].mand       = TRUE;
         tag[IT_M3UA_TAG_IDX_CAUSEUSER].mand  = TRUE;
         /* Optional part */
         tag[IT_M3UA_TAG_IDX_RCTX].opt        = TRUE;
         tag[IT_M3UA_TAG_IDX_NWKAPP].opt      = TRUE;
         tag[IT_M3UA_TAG_IDX_INFO].opt        = TRUE;
         break;
      }
      /* the following 4 cases fall through */
      case IT_SSNM_DRST:
      case IT_SSNM_DUNA:
      case IT_SSNM_DAVA:
      case IT_SSNM_DAUD:
      {
         /* Mandatory part */
         tag[IT_M3UA_TAG_IDX_ADPC].mand       = TRUE;
         /* Optional part */
         tag[IT_M3UA_TAG_IDX_RCTX].opt        = TRUE;
         tag[IT_M3UA_TAG_IDX_NWKAPP].opt      = TRUE;
         tag[IT_M3UA_TAG_IDX_INFO].opt        = TRUE;
         break;
      }
      case IT_ASPM_ASPUP:
      {
         /* Optional part */
         tag[IT_M3UA_TAG_IDX_INFO].opt        = TRUE;
         tag[IT_M3UA_TAG_IDX_ASPID].opt       = TRUE;
         break;
      }
      case IT_ASPM_ASPUP_ACK:
      {
         /* Optional part */
         tag[IT_M3UA_TAG_IDX_INFO].opt        = TRUE;
         break;
      }
      case IT_ASPM_ASPDN:
      /* fall through */
      case IT_ASPM_ASPDN_ACK:
      {
         /* Optional part */
         tag[IT_M3UA_TAG_IDX_INFO].opt        = TRUE;
         break;
      }
      /* the following 2 cases fall through */
      case IT_ASPM_ASPAC:
      case IT_ASPM_ASPAC_ACK:
      {
         /* Optional part */
         tag[IT_M3UA_TAG_IDX_TRAFMODE].opt    = TRUE;
         tag[IT_M3UA_TAG_IDX_RCTX].opt        = TRUE;
         tag[IT_M3UA_TAG_IDX_INFO].opt        = TRUE;
         break;
      }
      /* the following 2 cases fall through */
      case IT_ASPM_ASPIA:
      case IT_ASPM_ASPIA_ACK:
      {
         /* Optional part */
         tag[IT_M3UA_TAG_IDX_RCTX].opt        = TRUE;
         tag[IT_M3UA_TAG_IDX_INFO].opt        = TRUE;
         break;
      }
      case IT_ASPM_BEAT:
      /* fall through */
      case IT_ASPM_BEAT_ACK:
      {
         /* Optional part */
         tag[IT_M3UA_TAG_IDX_HBEATDATA].opt   = TRUE;
         break;
      }
      case IT_RKM_REGREQ:
      {
         /* Mandatory part */
         tag[IT_M3UA_TAG_IDX_RK].mand = TRUE;
         tag[IT_M3UA_TAG_IDX_DPC].mand = TRUE;
         tag[IT_M3UA_TAG_IDX_LCLRKID].mand = TRUE;
         /* Optional part */
         tag[IT_M3UA_TAG_IDX_TRAFMODE].opt = TRUE;
         tag[IT_M3UA_TAG_IDX_NWKAPP].opt = TRUE;
         tag[IT_M3UA_TAG_IDX_SI].opt = TRUE;
         tag[IT_M3UA_TAG_IDX_OPC].opt = TRUE;
         tag[IT_M3UA_TAG_IDX_CICRNG].opt = TRUE;
         break;
      }
      case IT_RKM_REGRSP:
      {
         /* Mandatory part */
         tag[IT_M3UA_TAG_IDX_REGRSLT].mand  = TRUE;
         tag[IT_M3UA_TAG_IDX_LCLRKID].mand   = TRUE;
         tag[IT_M3UA_TAG_IDX_REGSTA].mand    = TRUE;
         tag[IT_M3UA_TAG_IDX_RCTX].mand      = TRUE;
         break;
      }
      case IT_RKM_DREGREQ:
      {
         /* Mandatory part */
         tag[IT_M3UA_TAG_IDX_RCTX].mand      = TRUE;
         break;
      }
      case IT_RKM_DREGRSP:
      {
         /* Mandatory part */
         tag[IT_M3UA_TAG_IDX_DREGRSLT].mand  = TRUE;
         tag[IT_M3UA_TAG_IDX_RCTX].mand       = TRUE;
         tag[IT_M3UA_TAG_IDX_DREGSTA].mand    = TRUE;
         break;
      }
      default:
      {
         /* Invalid/unsupported message type: reply to peer and exit */
         RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNSUP_MSGTYPE, mBuf, 0,
                            (ItM3uaTag *) NULLP, (ItRtCtx *) NULLP, 
                             0, IT_M3UA_DFLT));
      }
   }
   /* For some RKM msg types (IT_RKM_REGREQ, IT_RKM_REGRSP, IT_RKM_DREGRSP) 
    * special processing is done as these messages contains Sub Parameters 
    * as well. For RKM message type (IT_RKM_DREGREQ) processing is done as
    * per normal procedure*/

   if ((msgType == IT_RKM_REGREQ) || (msgType == IT_RKM_REGRSP) || 
       (msgType == IT_RKM_DREGRSP))
   {
       /* Do Special Processing */
      if ((ret = itMmhVerifyRkm(assocCb, msgType, mBuf, len, cur, tag)) 
                     != ROK) 
      { 
         RETVALUE(ROK);
      }
      RETVALUE(itMmhProcRkm(assocCb, msgType, mBuf, len, cur, tag));
   }
   fstPrmtDecd = FALSE;
   /* Scan message for parameters */

   while (cur <= (len - (MsgLen) sizeof(U32)))
   {
      U16 tagId;              /* tag identifier */
      U16 tagLen;             /* parameter length */
      U8  tagIdx;             /* tag Index */
      IT_MMH_EXAM_U16(*mBuf, tagId, cur, ret)
      IT_MMH_CHKLOG(*mBuf, ret, EIT190)
      IT_MMH_EXAM_U16(*mBuf, tagLen, cur, ret)
      IT_MMH_CHKLOG(*mBuf, ret, EIT191)
      /* it015.106 Tag length should not be less than 4.
         If it is then send back an error */
      if (tagLen < 4)
      {
         /* Invalid M3UA hdr */
         RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR,
                            mBuf, NULLD, (ItM3uaTag *) NULLP, 
                            (ItRtCtx *) NULLP, 0, IT_M3UA_DFLT));
      }
      tagLen = (U16)IT_MMH_LEN_UNADJ(tagLen);
      if ((fstPrmtDecd == TRUE) && (tagId == IT_M3UA_TAG_NWKAPP))
      {
         /* Error : NwkApp is present but its not the first parameter in msg */
         RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PROTO_ERR, mBuf, 0,
                            (ItM3uaTag *) NULLP, (ItRtCtx *) NULLP, 
                            0, IT_M3UA_DFLT));
      }
      /* Convert the parameter id received in the msg to a tag index */
      for (tagIdx = 0; tagIdx < IT_M3UA_TAGARRAYSIZE; tagIdx++)
      {
         if (tag[tagIdx].tag == tagId)
         {
            break;
         }
      }
      
      if (tagIdx == IT_M3UA_TAGARRAYSIZE)
      {
         /* Invalid tag: Currently Protocol does not have any defined error
          *  code for this case */
         RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNEXPECTED_PARAM, mBuf, 0, 
               (ItM3uaTag *) NULLP, (ItRtCtx *) NULLP, 0, 
                IT_M3UA_DFLT));
      }
      
      if (tagLen > 0)
      {
         /* it020.106 - If tagLen is more than (len - cur) then either message 
          * length or tagLen is invalid, send an ERROR message. */
         if (tagLen <= (len - cur))
         {
            if (tag[tagIdx].pres == TRUE)
            {
               /* Repeated parameter */
               ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
                  "itMmhDatInd(): Repeated parameter (msg = %04X tag = %02X)\n",
                  msgType, tagId))
               RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PROTO_ERR, mBuf, 0,
                                  (ItM3uaTag *) NULLP, (ItRtCtx *) NULLP, 
                                   0, IT_M3UA_DFLT));
            }
            tag[tagIdx].pres      = TRUE;
            tag[tagIdx].length    = tagLen;
            tag[tagIdx].offset    = cur;
            cur = (S16)(cur + tagLen);
            /* skip the padding octets */
            cur = (S16)(cur + (sizeof(U32) - 
                               (tagLen % sizeof(U32))) % sizeof(U32));
         }
         else
         {
            /* it020.106 - Invalid tag length */
            RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR,
                               mBuf, NULLD, (ItM3uaTag *) NULLP, 
                               (ItRtCtx *) NULLP, 0, IT_M3UA_DFLT));
         }
      }
      else if ((tagLen == 0) && (tag[tagIdx].mand == TRUE))
      {
          /* Invalid tag/length */
         ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
    "itMmhDatInd(): Invalid M3UA parameter (msg = %04X tag = %02X len = %d)\n",
            msgType, tagId, IT_MMH_LEN_ADJ(tagLen)))
         RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR, mBuf, 0,
                            (ItM3uaTag *) NULLP, (ItRtCtx *) NULLP, 
                                0, IT_M3UA_DFLT));
      }
      fstPrmtDecd = TRUE;
   }
   for (i = 0; i < IT_M3UA_TAGARRAYSIZE; i++)
   {
      /* Check actual parameters against expected parameters */
      if ((tag[i].mand == TRUE) && (tag[i].pres == FALSE))
      {
         /* Mandatory parameter is not present */
         ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
         "itMmhDatInd(): Mandatory parameter missing (msg = %04X tag = %02X)\n",
            msgType, i))
         RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_MISSING_PARAM, mBuf, 0,
                             (ItM3uaTag *) NULLP, (ItRtCtx *) NULLP, 
                                0, IT_M3UA_DFLT));
      }
      if (tag[i].pres == TRUE)
      {
         if ((tag[i].mand == FALSE) && (tag[i].opt == FALSE))
         {
            /* Parameter is not allowed for this message type */
            ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
      "itMmhDatInd(): Invalid parameter for message (msg = %04X tag = %02X)\n",
               msgType, i))
            RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PROTO_ERR, mBuf, 0,
                                (ItM3uaTag *) NULLP, (ItRtCtx *) NULLP, 
                                0, IT_M3UA_DFLT));
         }
         /* Do parameter-specific checking and processing */
         switch (i)
         {

            case IT_M3UA_TAG_IDX_DATA:
               break;
            case IT_M3UA_TAG_IDX_NWKAPP:
            {
               if (tag[i].length == sizeof(U32))
               {
                  Bool  done;       /* TRUE if loop done */
                  U32   nwkAppVal;  /* network appearance value */
                  U16   j;          /* loop index */
                  cur = tag[i].offset;
                  IT_MMH_EXAM_U32(*mBuf, nwkAppVal, cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT192)
                  /* search nwkCbs for network appearance */
                  done = FALSE;
                  for (j = 0; (j < itGlobalCb.genCfg.maxNmbNwk) &&
                     (done == FALSE); j++)
                  {
                     if (itGlobalCb.nwk[j] != (ItNwkCb *)NULLP)
                     {
                        if (itGlobalCb.nwk[j]->nwkCfg.nwkApp[pspId] 
                                                               == nwkAppVal)
                        {
                           tag[i].u.nwkId = (U8)j;
                           tag[i].valid   = TRUE;
                           done           = TRUE;
                        }
                     }
                  }
                /* -If for this pspId network Appearance is not 
                   configured in any network control block and 
                   in incoming message NA is present then 
                   layer will not give any error */ 
                  if (done == FALSE)
                  {
                     Bool nwkAppConfigForPsp; 
                     /* Netwprk Appearance is configured for this pspId */

                     nwkAppConfigForPsp = FALSE;

                     for (j = 0; j < itGlobalCb.genCfg.maxNmbNwk; j++) 
                     {
                        if (itGlobalCb.nwk[j] != (ItNwkCb *)NULLP)
                        {
                           if (itGlobalCb.nwk[j]->nwkCfg.nwkApp[pspId] != 0)
                           {
                              nwkAppConfigForPsp = TRUE;
                              break;
                           }
                        } /* if itGlobalCb  */
                     } /* for (j = 0.. */ 
                    
                     if (nwkAppConfigForPsp == FALSE)
                     {
                           tag[i].valid   = FALSE;
                           done           = TRUE;
                     }
                  } /* if (done == FALSE ) */
                  if (done == FALSE)
                  {
                     /* Invalid network appearance value */
#ifdef BIT_64
                     ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
                            "itMmhDatInd(): Invalid network appearance "
                            "(msg = %04X nwkApp = %08X)\n",
                            msgType, nwkAppVal))
#else
                     ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
                            "itMmhDatInd(): Invalid network appearance "
                            "(msg = %04X nwkApp = %08lX)\n",
                            msgType, nwkAppVal))
#endif
                     RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_INV_NWKAPP,
                                         mBuf, nwkAppVal, (ItM3uaTag *) NULLP,
                                        (ItRtCtx *) NULLP, 0, nwkAppVal));
                  }
               }
               else
               {
                  /* Invalid network appearance length */
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
                         "itMmhDatInd(): Invalid network appearance length "
                         "(msg = %04X len = %d)\n",
                         msgType, IT_MMH_LEN_ADJ(tag[i].length)))
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR,
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));
               }
               break;
            }
            case IT_M3UA_TAG_IDX_INFO:
            {
               if (tag[i].length > LIT_MAX_INFO)
               {
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
               "itMmhDatInd(): Invalid info parameter (msg = %04X len = %d)\n",
                     msgType, IT_MMH_LEN_ADJ(tag[i].length)))
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR,
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));
               }
               cur = tag[i].offset;
               ret = itMmhExamString(mBuf, info,
                  (U16)MIN(tag[i].length, LIT_MAX_INFO), (U16 *)&cur);
               if (ret != ROK)
               {
                  RETVALUE(ret);
               }
               tag[i].valid = TRUE;
               break;
            }
            case IT_M3UA_TAG_IDX_RCTX:
            {
               cur = tag[IT_M3UA_TAG_IDX_RCTX].offset;
               if ((tag[IT_M3UA_TAG_IDX_RCTX].length % sizeof(U32))
                    || ((msgType == IT_M3UA_DATA)
                         && (tag[IT_M3UA_TAG_IDX_RCTX].length != sizeof(U32))))
               {
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
               "itMmhDatInd(): Invalid info parameter (msg = %04X len = %d)\n",
                     msgType, IT_MMH_LEN_ADJ(tag[i].length)))
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR,
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));
               }
               while (((cur - (MsgLen) tag[IT_M3UA_TAG_IDX_RCTX].offset) <=
                  (tag[IT_M3UA_TAG_IDX_RCTX].length - (MsgLen) sizeof(U32))) &&
                  (rCtxLen < LIT_MAX_PSID))
               {
                  IT_MMH_EXAM_U32(*mBuf, rCtx[rCtxLen].rtCtx, cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT193)
                  rCtx[rCtxLen].ntfySend = FALSE;
                  rCtx[rCtxLen].ntfyStaId = NULLD;
                  rCtxLen++;
               }
               tag[i].valid = TRUE;
               break;
            }
            case IT_M3UA_TAG_IDX_CAUSEUSER:
            {
               if (tag[i].length == sizeof(U32))
               {
                  cur = tag[i].offset;
                  IT_MMH_EXAM_U16(*mBuf, tag[i].u.causeuser.cause, cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT194)
                  IT_MMH_EXAM_U16(*mBuf, tag[i].u.causeuser.user, cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT195)
                  tag[i].valid = TRUE;
               }
               else
               {
                  /* Invalid cause/user length */
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR,
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));
               }
               break;
            }
            case IT_M3UA_TAG_IDX_TRAFMODE:
            {
               if (tag[i].length == sizeof(U32))
               {
                  cur = tag[i].offset;
                  IT_MMH_EXAM_U32(*mBuf, tag[i].u.trafmode, cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT196)
                  switch (tag[i].u.trafmode)
                  {
                     /* the following 4 cases fall through */
                     case IT_M3UA_THM_OVERRIDE:
                     case IT_M3UA_THM_LOADSHARE:
                        break;
                     case IT_M3UA_THM_BROADCAST:
                        RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNSUPP_THM,
                                            mBuf, tag[i].u.trafmode,
                                            (ItM3uaTag *) NULLP, (ItRtCtx *)
                                             NULLP, 0, IT_M3UA_DFLT));
                        break;
                     default:
                        ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
                               "itMmhDatInd(): Invalid value for traffic"
                               "handling mode parameter received"
                               "(msg = %04X type = %02X)\n",
                               msgType, (U16)tag[i].u.trafmode))
                        RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_INV_PARMVAL,
                                            mBuf, tag[i].u.trafmode,
                                            (ItM3uaTag *) NULLP, (ItRtCtx *)
                                             NULLP, 0, IT_M3UA_DFLT));
                        break;
                  }
                  tag[i].valid = TRUE;
               }
               else
               {
                  /* Invalid traffic mode length */
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
      "itMmhDatInd(): Invalid traffic mode length (msg = %04X len = %d)\n",
                     msgType, IT_MMH_LEN_ADJ(tag[i].length)))
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR,
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));
               }
               break;
            }
            case IT_M3UA_TAG_IDX_ERRCODE:
            {
               if (tag[i].length == sizeof(U32))
               {
                  cur = tag[i].offset;
                  IT_MMH_EXAM_U32(*mBuf, tag[i].u.errcode, cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT197)
                  tag[i].valid = TRUE;
               }
               else
               {
                  /* Invalid error code length */
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
      "itMmhDatInd(): Invalid error code length (msg = %04X len = %d)\n",
                     msgType, IT_MMH_LEN_ADJ(tag[i].length)))
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR,
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));
               }
               break;
            }
            case IT_M3UA_TAG_IDX_STATUS:
            {
               if (tag[i].length == sizeof(U32))
               {
                  Bool  ok;   /* TRUE if OK */
                  U16   invPrm; /* Invalid status type or id */
                  ok    = TRUE;
                  cur   = tag[i].offset;
                  invPrm = 0;
                  IT_MMH_EXAM_U16(*mBuf, tag[i].u.status.type, cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT198)
                  IT_MMH_EXAM_U16(*mBuf, tag[i].u.status.id, cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT199)
                  switch (tag[i].u.status.type)
                  {
                     case IT_M3UA_NTFY_TYPE_ASCHG:
                        switch (tag[i].u.status.id)
                        {
                           /* the following 3 cases fall through */
                           case IT_M3UA_NTFY_INFO_AS_INACTIVE:
                           case IT_M3UA_NTFY_INFO_AS_ACTIVE:
                           case IT_M3UA_NTFY_INFO_AS_PENDING:
                              break;
                           default:
                              ok = FALSE;
                              invPrm = tag[i].u.status.id;
                              break;
                        }
                        break;
                     case LIT_NTFY_TYPE_OTHER:
                        switch (tag[i].u.status.id)
                        {
                           /* the following 2 cases fall through */
                           case IT_M3UA_NTFY_INFO_INSUF_RSRC:
                           case IT_M3UA_NTFY_INFO_ALT_ASPACT:
                           case IT_M3UA_NTFY_INFO_ASP_FLR:
                              break;
                           default:
                              ok = FALSE;
                              invPrm = tag[i].u.status.id;
                              break;
                        }
                        break;
                     default:
                        ok = FALSE;
                        invPrm = tag[i].u.status.type;
                        break;
                  }
                  if (ok == FALSE)
                  {
                     ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
                            "itMmhDatInd(): Invalid status parameter"
                            "(staType = %02X staInfo = %02X)\n",
                            tag[i].u.status.type, tag[i].u.status.id))
                     RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_INV_PARMVAL,
                                         mBuf, (U32)invPrm, &tag[i], (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));
                  }
                  tag[i].valid = TRUE;
               }
               else
               {
                  /* Invalid status length */
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
                "itMmhDatInd(): Invalid status length (msg = %04X len = %d)\n",
                     msgType, IT_MMH_LEN_ADJ(tag[i].length)))
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR,
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));
               }
               break;
            }
            case IT_M3UA_TAG_IDX_CONGLEVEL:
            {
               if (tag[i].length == sizeof(U32))
               {
                  cur = tag[i].offset;
                  cur += 3; /* 3 reserved bytes */
                  IT_MMH_EXAM_U8(*mBuf, tag[i].u.conglevel, cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT200)
                  switch (tag[i].u.conglevel)
                  {
                     /* next 4 cases fall through */
                     case SN_PRI0:
                     case SN_PRI1:
                     case SN_PRI2:
                     case SN_PRI3:
                        break;
                     default:
                        /* Invalid congestion level length */
                        ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
                               "itMmhDatInd(): Invalid cong level parameter "
                               "(msg = %04X)\n", msgType))
                        RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_INV_PARMVAL,
                                            mBuf, (U32)(tag[i].u.conglevel),
                                            &tag[i], (ItRtCtx *)
                                            NULLP, 0, IT_M3UA_DFLT));
                  }
                  tag[i].valid = TRUE;
               }
               else
               {
                  /* Invalid congestion level length */
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
                         "itMmhDatInd(): Invalid congestion level length "
                         "(msg = %04X len = %d)\n",
                         msgType, IT_MMH_LEN_ADJ(tag[i].length)))
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR,
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));
               }
               break;
            }
            case IT_M3UA_TAG_IDX_ADPC:
            {
                    
               /* check for tag length as a multiple of 4 */
               if ((tag[i].length % sizeof(U32)) != NULLD)
               {
                  /* Invalid aDpc length */
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
                         "itMmhDatInd(): APC tag length should always be a "
                         " multiple of 4 bytes (msg = %04X len = %d)\n",
                         msgType, IT_MMH_LEN_ADJ(tag[i].length)))
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR,
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));
               }
               break;
            }
            case IT_M3UA_TAG_IDX_ASPID:
            {
               if (tag[i].length == sizeof(U32))
               {
                  cur = tag[i].offset;
                  IT_MMH_EXAM_U16(*mBuf, tag[i].u.status.aspId, cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT201)
                  tag[i].valid = TRUE;

               }
               else
               {
                  /* Invalid ASP Id length */
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
                         "itMmhDatInd(): Invalid ASP Id length Rxd"
                         "(msg = %04X len = %d)\n",
                         msgType, IT_MMH_LEN_ADJ(tag[i].length)))
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR,
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));
               }
            }
            case IT_M3UA_TAG_IDX_CORELTN_ID:
               break;

            default:
               /* other cases: do nothing */
               break;
         }
      } /* end if present */
   } /* end for */
   
   /* Do message-specific processing */
   switch (msgType)
   {
      case IT_M3UA_ERROR:
      {
         U32 errCode;
         errCode =  tag[IT_M3UA_TAG_IDX_ERRCODE].u.errcode;    /* error code */
         IT_STS_INC_M3UA_RX(assocCb, err);
         /* Report received error message to layer management */
         itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP;
         itGlobalCb.mgmt.t.usta.s.pspId         = pspId;
         itGlobalCb.mgmt.t.usta.alarm.category  = LCM_CATEGORY_PROTOCOL;
         itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_M3UA_PROTO_ERROR;
         switch (errCode)
         {
            case IT_M3UA_ERROR_INV_VERSION:
               itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_INV_VERSION;
               (Void) itMiStaIndM(&itGlobalCb.mgmt);
               break;
            case IT_M3UA_ERROR_INV_NWKAPP:
               itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_INV_NWK_APP;
               (Void) itMiStaIndM(&itGlobalCb.mgmt);
               break;
            case IT_M3UA_ERROR_UNSUP_MSGCLS:
               itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_UNSUP_MSG_CLASS;
               (Void) itMiStaIndM(&itGlobalCb.mgmt);
               break;
            case IT_M3UA_ERROR_UNSUP_MSGTYPE:
               itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_UNSUP_MSG_TYPE;
               (Void) itMiStaIndM(&itGlobalCb.mgmt);
               break;
            case IT_M3UA_ERROR_UNSUPP_THM:
               itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_INV_TRAFFIC_MODE;
               (Void) itMiStaIndM(&itGlobalCb.mgmt);
               break;
            case IT_M3UA_ERROR_UNEXP_MSG:
               itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_UNEXP_MSG;
               (Void) itMiStaIndM(&itGlobalCb.mgmt);
               break;
            case IT_M3UA_ERROR_PROTO_ERR:
               itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_PROTO_ERR;
               (Void) itMiStaIndM(&itGlobalCb.mgmt);
               break;
            case IT_M3UA_ERROR_INV_RCTX:
               itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_INV_RCTX;
               (Void) itMiStaIndM(&itGlobalCb.mgmt);
               break;
            case IT_M3UA_ERROR_INV_STRMID:
               itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_INV_STRMID;
               (Void) itMiStaIndM(&itGlobalCb.mgmt);
               break;
            case IT_M3UA_ERROR_INV_PARMVAL:
               itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_INV_M3UA_PARMVAL;
               (Void) itMiStaIndM(&itGlobalCb.mgmt);
               break;
            case IT_M3UA_ERROR_RFSD_MGMTBLKD:
               itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_RFSD_MGMT_BLKD;
               (Void) itMiStaIndM(&itGlobalCb.mgmt);
               break;
            case IT_M3UA_ERROR_PARAM_FIELD_ERROR:
               itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_PARAM_FIELD_ERROR;
               (Void) itMiStaIndM(&itGlobalCb.mgmt);
               break;
            case IT_M3UA_ERROR_NO_AS_FOR_ASP:
               itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_NO_AS_FOR_ASP;
               (Void) itMiStaIndM(&itGlobalCb.mgmt);
               break;
            case IT_M3UA_ERROR_UNEXPECTED_PARAM:
               itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_UNEXPECTED_PARAM;
               (Void) itMiStaIndM(&itGlobalCb.mgmt);
               break;
            case IT_M3UA_ERROR_MISSING_PARAM:
               itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_MISSING_PARAM;
               (Void) itMiStaIndM(&itGlobalCb.mgmt);
               break;
            case IT_M3UA_ERROR_ASPID_REQD:
               itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_ASPID_REQUIRED;
               (Void) itMiStaIndM(&itGlobalCb.mgmt);
               break;
            case IT_M3UA_ERROR_INV_ASPID:
               itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_INVALID_ASPID;
               (Void) itMiStaIndM(&itGlobalCb.mgmt);
               break;
#ifdef  ITASP
            case IT_M3UA_ERROR_DPC_STATUS_UNKNOWN:
               itMmhErrorDpcUnkwn(assocCb, tag, mBuf, cur);
               break;
#endif  /* ITASP */
            default:
               itGlobalCb.mgmt.t.usta.alarm.cause = LCM_CAUSE_UNKNOWN;
               (Void) itMiStaIndM(&itGlobalCb.mgmt);
               break;
         }
         IT_DROPDATA(*mBuf);
         break;
      }
      case IT_M3UA_NOTIFY:
      {
         U32    aspId;     /* ASP Id received */
         Bool   aspIdPres; /* ASP ID Present Flag */

         aspIdPres = FALSE;
         aspId = NULLD;
         
         if (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_ASP)
         {
            /* message not expected from ASP */
            RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNEXP_MSG,
                                mBuf, 0, (ItM3uaTag *) NULLP, 
                                      rCtx, rCtxLen, IT_M3UA_DFLT));
         } 
         IT_STS_INC_M3UA_RX(assocCb, notify);
         if (tag[IT_M3UA_TAG_IDX_ASPID].valid == TRUE)
         {
            cur = tag[IT_M3UA_TAG_IDX_ASPID].offset;
            IT_MMH_EXAM_U32(*mBuf, aspId, cur, ret)
            IT_MMH_CHKLOG(*mBuf, ret, EIT202)
            aspIdPres = TRUE;
         }
#ifdef  ITASP
         if ((ret = itPsmNotify(assocCb, info,
                  (rCtxLen == 0) ? (ItRtCtx *)NULLP : rCtx, rCtxLen,
                  tag[IT_M3UA_TAG_IDX_STATUS].u.status.type,
                  tag[IT_M3UA_TAG_IDX_STATUS].u.status.id, aspIdPres, aspId))
            != ROK)
         {
            RETVALUE(ret);
         }
#endif /* ITASP */
         break;
      }
      case IT_M3UA_DATA:
      {
         Data     tmp[IT_M3UA_MAXHDR]; /* temp buffer for stripping header */
         ItMupMsg *mupm;               /* MUP message */

         Bool   found;
         ItPsCb *psCb;
         
         found = FALSE;
         psCb  = (ItPsCb *)NULLP; 

         if (rCtxLen != NULLD)
         {
            /* Validate rCtx list according to configured routing */
            pspCb    = (assocCb != (ItAssocCb *)NULLP) ?
            assocCb->owner : itGlobalCb.psp[IT_LOCAL_PSPID];

            nrCtx.rtCtx = rCtx[0].rtCtx; 
           
            nrCtxLen = rCtxLen; /* In DATA rCtxLen will be 1 only */
           
            irCtxLen = 0;

            /* ackFlag should be TRUE in case of data from 
               peer as in this case only Local PS need to be searched
               for in IPSP DE implementation. Ackflag has been provided
               to allow Same RC on both Local as well as remote PS 
               in case of IPSP DE */
               
            itAtMapRcToPs(assocCb, &nrCtx, &nrCtxLen, &irCtx,
                                         &irCtxLen, TRUE);

            /* verify that RC is stored in local PS or remote PS  */
            /* At receiving node of a DATA message, the DATA will
             * contain the RC of the "receiving side" and NOT of the sending
             * side,  Received RC is validated as follows 
             * ---------------------------------------------
             * S#    Self-Node     RC-to-verify      Remote Node 
             *                      in               (pspCb.psCfg.pspType)
             * ---------------------------------------------
             * 1.    ASP  -------- Local PS   -----  SGP
             * 2.    SGP  -------- Remote PS  -----  ASP
             * 3.    IPSP-SE ----- Local PS   -----  IPSP-SE
             * 4.    IPSP-DE ----- Local PS   -----  IPSP-DE
             */
            if ((nrCtxLen != 0) && (irCtxLen == 0) &&
                    ((psCb  = itPsmFindPs(nrCtx.rtCtx)) != (ItPsCb *)NULLP))
            {
                /* Case 1, 3 and 4 from above table */
                    /* ipspMode is not required to check as pspType == IPSP 
                     * is sufficient */
                if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP) || 
                    (pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP))
                {
                   if ((psCb->psSta.psStaEndp[IT_ASSOC2SUID(assocCb->assocId)].\
                                aspSt[pspCb->pspCfg.pspId] != LIT_ASP_UNSUPP) &&
                       (psCb->psSta.psStaEndp[IT_ASSOC2SUID(assocCb->assocId)].\
                                    aspSt[pspCb->pspCfg.pspId] !=  LIT_ASP_DOWN)
                        && (psCb->psCfg.lclFlag == TRUE))

                   {
                      found = TRUE;
                   }
                   else
                   {
                      found = FALSE;
                   }

                } /* End of S# 1, 3 and 4 */
                else /* Case 2 at SGP node :  RC to 
                        verify is stored in RPS  */
                {
                   if (pspCb->pspCfg.pspType == LIT_PSPTYPE_ASP)
                   { 
                       if ((psCb->psSta.psStaEndp[IT_ASSOC2SUID(assocCb->assocId
                             )].aspSt[pspCb->pspCfg.pspId] != LIT_ASP_UNSUPP) &&
                       (psCb->psSta.psStaEndp[IT_ASSOC2SUID(assocCb->assocId)].\
                                    aspSt[pspCb->pspCfg.pspId] !=  LIT_ASP_DOWN)
                        && (psCb->psCfg.lclFlag != TRUE))
                        {
                           found = TRUE;
                        }
                        else
                        {
                           found = FALSE;
                        }
                   } /* End of IF: pspType == LIT_PSPTYPE_ASP */
                }
            }  /* end of psCb != NULLP */
            if (found == FALSE)
            {

               /* Function is returned form here, DATA is dropped in
                * itMmhError function */
               RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_INV_RCTX,  
                           (Buffer **)mBuf, 0, 0, &irCtx, irCtxLen,   
                           IT_M3UA_DFLT));
            }
         } /* if (rCtxLen != NULLD) */
         IT_STS_INC_M3UA_RX(assocCb, data);

         if ((assocCb->assocSta->aspSt != LIT_ASP_ACTIVE) &&
            ! ((assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_IPSP) &&
              (assocCb->owner->pspCfg.ipspMode == LIT_IPSPMODE_DE)))
         {
            /* silent discard - no ERR message */
            RETVALUE(RFAILED);
         }
         /* remove header info */
         ret = SRemPreMsgMult(tmp, tag[IT_M3UA_TAG_IDX_DATA].offset, *mBuf);
         IT_MMH_CHKLOG(*mBuf, ret, EIT203)
         /* remove trailing info */
         SFndLenMsg(*mBuf, &len);
         len = (S16)(len - tag[IT_M3UA_TAG_IDX_DATA].length);
         if (len > 0)
         {
            ret = SRemPstMsgMult(tmp, len, *mBuf);
            IT_MMH_CHKLOG(*mBuf, ret, EIT204)
         }

         if (itGlobalCb.nmbMsg >= itGlobalCb.genCfg.maxNmbMsg)
         {
            itMiStaInd(STITGEN, LCM_CATEGORY_PROTOCOL, LIT_EVENT_MSG_FAIL, 
                       LCM_CAUSE_MEM_ALLOC_FAIL, NULLD);
            IT_DROPDATA(*mBuf);
            RETVALUE(ROUTRES);
         }
         /* Create new MUP message */
         IT_ALLOC(sizeof(ItMupMsg), mupm)
         if (mupm == (ItMupMsg *)NULLP)
         {
            IT_DROPDATA(*mBuf);
            RETVALUE(ROUTRES);
         }

         itGlobalCb.nmbMsg++;

         mupm->dir         = IT_MSG_UP;
         mupm->originator  = (PTR)assocCb;
         /* Use decoded network ID, or default if none present */
         if (tag[IT_M3UA_TAG_IDX_NWKAPP].valid == TRUE)
         {
            mupm->nwkId = tag[IT_M3UA_TAG_IDX_NWKAPP].u.nwkId;
         }
         else
         {
            /* default network ID from PSP config */
            mupm->nwkId = assocCb->owner->pspCfg.nwkId;
         }
         /* changes for passing the pointer to function */
         mupm->mBuf        = *mBuf;
         mupm->msgState    = IT_MSG_UNROUTED;
         mupm->hdrState    = IT_MSGHDR_PRES;
         if ((ret = itMupData(mupm)) != ROK)
         {
            *mBuf = mupm->mBuf;
            IT_FREE(sizeof(ItMupMsg), mupm);
            itGlobalCb.nmbMsg--;
            RETVALUE(ret);
         }
         break;
      }
      /* the following 5 cases fall through */
      case IT_SSNM_DRST:
      case IT_SSNM_DUNA:
      case IT_SSNM_DAVA:
      case IT_SSNM_DAUD:
      case IT_SSNM_SCON:
      case IT_SSNM_DUPU:
      {
         U8    nwkId;         /* network ID */
         Dpc   dpc;           /* DPC value */
         U16   xtra1;         /* extra value 1 */
         U16   xtra2;         /* extra value 2 */
         U8    mask;          /* DPC mask */
         IT_STS_INC_M3UA_RX_SSNM(assocCb, msgType);
         if ((assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_ASP) ||
             (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_IPSP))
         {
            if ((msgType == IT_SSNM_DUNA) || (msgType == IT_SSNM_DAVA) ||
                (msgType == IT_SSNM_DUPU) || (msgType == IT_SSNM_DRST))
            {
               /* message not expected from ASP or IPSP */
               RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNEXP_MSG,
                                   mBuf, 0, (ItM3uaTag *) NULLP, 
                                      rCtx, rCtxLen , IT_M3UA_DFLT));
            }
               
         } 
         else
         {
            if (msgType == IT_SSNM_DAUD)
            {
               /* message not expected from SGP */               
               RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNEXP_MSG,
                                      mBuf, 0, (ItM3uaTag *) NULLP, 
                                      rCtx, rCtxLen, IT_M3UA_DFLT)); 
            }
         }
         /* Use decoded network ID, or default if none present */
         if (tag[IT_M3UA_TAG_IDX_NWKAPP].valid == TRUE)
         {
            nwkId = tag[IT_M3UA_TAG_IDX_NWKAPP].u.nwkId;
         }
         else
         {
            /* default network ID from PSP config */
            nwkId = assocCb->owner->pspCfg.nwkId;
         }
         if (msgType == IT_SSNM_DUPU)
         {
            xtra1 = tag[IT_M3UA_TAG_IDX_CAUSEUSER].u.causeuser.cause;
            xtra2 = tag[IT_M3UA_TAG_IDX_CAUSEUSER].u.causeuser.user;
            switch (xtra1)
            {
               case IT_M3UA_DUPU_CAUSE_UNKNOWN:
               case IT_M3UA_DUPU_CAUSE_UNEQUIPPED:
               case IT_M3UA_DUPU_CAUSE_INACC:
                   break;
                     default:
                  /* Invalid 'cause', response with error message */
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_INV_PARMVAL,
                                      mBuf, xtra1, (ItM3uaTag *) NULLP, 
                                      rCtx, rCtxLen, IT_M3UA_DFLT)); 
            }
         }
         else if (msgType == IT_SSNM_SCON)
         {
            if (tag[IT_M3UA_TAG_IDX_CONGLEVEL].pres == TRUE)
            {
               xtra1 = (U16) tag[IT_M3UA_TAG_IDX_CONGLEVEL].u.conglevel;
            }
            else
            {
               /* international method - don't expect a cong level */
               xtra1 = 0;
            }
            xtra2 = 0;
         }
         else
         {
            xtra1 = 0;
            xtra2 = 0;
         }
         /* Extract affected DPCs and report to MIF */
         cur = tag[IT_M3UA_TAG_IDX_ADPC].offset;
         while ((cur - (MsgLen) tag[IT_M3UA_TAG_IDX_ADPC].offset) <=
            (tag[IT_M3UA_TAG_IDX_ADPC].length - (MsgLen) sizeof(U32)))
         {
            IT_MMH_EXAM_U8(*mBuf, mask, cur, ret)
            IT_MMH_CHKLOG(*mBuf, ret, EIT205)
            IT_MMH_EXAM_DPC(*mBuf, dpc, itGlobalCb.nwk[nwkId]->nwkCfg.dpcLen,
                            cur, ret)
            IT_MMH_CHKLOG(*mBuf, ret, EIT206)
            if ((ret = itMifSsnm(assocCb, msgType, nwkId, dpc, mask, info,
                                 xtra1, xtra2, mBuf))
               != ROK)
            {
               RETVALUE(ret);
            }
         }
         break;
      }
      case IT_ASPM_ASPUP:
      {
         IT_STS_INC_M3UA_RX(assocCb, aspUp);
         if (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_SGP)
         {
            /* message not expected from SGP */
            RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNEXP_MSG,
                                mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));
         } 
         /* If rxTxAspId flag for this PSP is set to true then ASPUP message 
          * should be received with ASPID parameter in it */

         if ((assocCb->owner->pspCfg.rxTxAspId == TRUE)
             && (tag[IT_M3UA_TAG_IDX_ASPID].valid == FALSE))
         {

            
            /* ASP ID parameter is not present */
            RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_ASPID_REQD,
                                mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));
         }
         /* it016.106 - Changes to make ASPID in ASPUP message optional
          * when rxTxAspId is FALSE. */
         if (tag[IT_M3UA_TAG_IDX_ASPID].valid == TRUE)
         {
            U32         aspId;     /* ASP Id */

            cur = tag[IT_M3UA_TAG_IDX_ASPID].offset;
            IT_MMH_EXAM_U32(*mBuf, aspId, cur, ret)
            IT_MMH_CHKLOG(*mBuf, ret, EIT207)

            if (itMmhVerifyAspId(assocCb, aspId) != ROK)
            {
               RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_INV_ASPID,
                                   mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                   NULLP, 0, IT_M3UA_DFLT));                
            }
            else
            {
               itGlobalCb.aspIdCb.aspIdLst[pspId] = aspId;
               itGlobalCb.aspIdCb.aspIdValid[pspId] = TRUE;

#ifdef ZV
               /* it018.106 - modification - changing table type as 
                  ZV_ASPID */
               /* SYNC update for ZV_ASPID for aspIdValid & aspIdLst */
               zvRTUpd(CMPFTHA_ACTN_MOD, ZV_ASPID,
                       CMPFTHA_UPDTYPE_SYNC, (Void *) &pspId, NULLP);
#endif
            }
         }
         (Void) itPsmAspUp(assocCb, FALSE, info);
         break;
      }
      case IT_ASPM_ASPUP_ACK:
      {
         IT_STS_INC_M3UA_RX(assocCb, aspUpAck);
         if (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_ASP)
         {
            /* message not expected from ASP */
            RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNEXP_MSG,
                                mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));
         } 
         (Void) itPsmAspUp(assocCb, TRUE, info);
         break;
      }
      case IT_ASPM_ASPDN:
      {
         IT_STS_INC_M3UA_RX(assocCb, aspDn);
         if (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_SGP)
         {
            /* message not expected from SGP */
            RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNEXP_MSG,
                                mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));
         } 
         (Void) itPsmAspDn(assocCb, FALSE, info, TRUE);
         break;
      }
      case IT_ASPM_ASPDN_ACK:
      {
         IT_STS_INC_M3UA_RX(assocCb, aspDnAck);
         if (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_ASP)
         {
            /* message not expected from ASP */
            RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNEXP_MSG,
                                mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));
         } 
         (Void) itPsmAspDn(assocCb, TRUE, info, TRUE);
         break;
      }
      case IT_ASPM_ASPAC:
      {
         U8 trafMode;    /* Traffic handling Mode */
                 
         IT_STS_INC_M3UA_RX(assocCb, aspAc);
         if (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_SGP)
         {
            /* message not expected from SGP */
            RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNEXP_MSG,
                                mBuf, 0, (ItM3uaTag *) NULLP, 
                                      rCtx, rCtxLen, IT_M3UA_DFLT));
         } 
         if (tag[IT_M3UA_TAG_IDX_TRAFMODE].pres == FALSE)
         {
            trafMode = IT_M3UA_DFLT;
         }
         else
         {
            trafMode = (U8)(tag[IT_M3UA_TAG_IDX_TRAFMODE].u.trafmode);
         }
         if ((ret = itPsmAspAc(assocCb,
                               FALSE,
                               (U8)trafMode,
                               info,
                               (rCtxLen == 0) ? (ItRtCtx *)NULLP : rCtx,
                               rCtxLen)) != ROK)
         {
            RETVALUE(ret);
         }
         break;
      }
      case IT_ASPM_ASPAC_ACK:
      {
         U8 trafMode;    /* Traffic handling Mode */

         IT_STS_INC_M3UA_RX(assocCb, aspAcAck);
         if (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_ASP)
         {
            /* message not expected from ASP */
            RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNEXP_MSG,
                                mBuf, 0, (ItM3uaTag *) NULLP, 
                                      rCtx, rCtxLen, IT_M3UA_DFLT));
         }
         if (tag[IT_M3UA_TAG_IDX_TRAFMODE].pres == FALSE)
         {
            trafMode = IT_M3UA_DFLT;
         }
         else
         {
            trafMode = (U8)(tag[IT_M3UA_TAG_IDX_TRAFMODE].u.trafmode);
         }
         if ((ret = itPsmAspAc(assocCb,
                               TRUE,
                               (U8)trafMode,
                               info,
                               (rCtxLen == 0) ? (ItRtCtx *)NULLP : rCtx,
                               rCtxLen)) != ROK)
         {
            RETVALUE(ret);
         }
         break;
      }
      case IT_ASPM_ASPIA:
      {
         IT_STS_INC_M3UA_RX(assocCb, aspIa);
         if (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_SGP)
         {
            /* message not expected from SGP */
            RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNEXP_MSG,
                                mBuf, 0, (ItM3uaTag *) NULLP, 
                                      rCtx, rCtxLen, IT_M3UA_DFLT));
         } 
         if ((ret = itPsmAspIa(assocCb,
                               FALSE,
                               info,
                               (rCtxLen == 0) ? (ItRtCtx *)NULLP : rCtx,
                               rCtxLen)) != ROK)
         {
            RETVALUE(ret);
         }
         break;
      }
      case IT_ASPM_ASPIA_ACK:
      {
         IT_STS_INC_M3UA_RX(assocCb, aspIaAck);
         if (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_ASP)
         {
            /* message not expected from ASP */
            RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNEXP_MSG,
                                mBuf, 0, (ItM3uaTag *) NULLP, 
                                      rCtx, rCtxLen, IT_M3UA_DFLT));
         } 
         if ((ret = itPsmAspIa(assocCb,
                               TRUE,
                               info,
                               (rCtxLen == 0) ? (ItRtCtx *)NULLP : rCtx,
                               rCtxLen)) != ROK)
         {
            RETVALUE(ret);
         }
         break;
      }
      case IT_ASPM_BEAT:
      {
         IT_STS_INC_M3UA_RX(assocCb, hBeat);
         if ((ret = itMmhHBeat(assocCb, TRUE, mBuf,
                               &tag[IT_M3UA_TAG_IDX_HBEATDATA])) != ROK)
         {
            RETVALUE(ret);
         }
         break;
      }
      case IT_ASPM_BEAT_ACK:
      {
         IT_STS_INC_M3UA_RX(assocCb, hBeatAck);
         break;
      }

      case IT_RKM_DREGREQ:
      {
         if (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_SGP)
         {
            /* message not expected from SGP */
            RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNEXP_MSG,
                                mBuf, 0, (ItM3uaTag *) NULLP, 
                                      rCtx, rCtxLen, IT_M3UA_DFLT));
         } 

         IT_STS_INC_M3UA_RX(assocCb, deRegReq);

         if ((ret = itAtDeRegReq(assocCb, rCtx, rCtxLen, IT_EVT_DREGREQ)) 
                                                                      != ROK)
         {
             RETVALUE(ret);
         }

         break;
      }

      default:
         /* Message type has already been checked, so shouldn't get here */
         RETVALUE(RFAILED);
   }
   /* Reset receive heartbeat timer if running */
   if (assocCb->tmrHBeatRX.tmrEvnt != TMR_NONE)
   {
      TmrCfg tmpTmr;          /* temp timer for initialization */
      tmpTmr.enb = itGlobalCb.genCfg.tmr.tmrHeartbeat.enb;
      tmpTmr.val = (U16)(2 * itGlobalCb.genCfg.tmr.tmrHeartbeat.val);
      itTcStartTimer(&assocCb->tmrHBeatRX, (PTR) assocCb,
                     IT_TMR_HBEAT_RX, &tmpTmr);
   }
   /* Drop message if it's not being used */
   if ((msgType != IT_M3UA_DATA) && (msgType != IT_M3UA_ERROR) &&
       (msgType != IT_ASPM_BEAT))
   {
      IT_DROPDATA(*mBuf)
   }
   RETVALUE(ROK);
} /* end of itMmhDatInd */


/*
*
*       Fun:   itMmhSsnm
*
*       Desc:  Called by MIF to send an M3UA SS7 NM message to the peer
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*              ROUTRES - failed, out of resources
*              RNA     - failed, not available
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhSsnm
(
ItAssocCb   *assocCb,         /* association CB */
U16         msgType,          /* M3UA message type */
U8          nwkId,            /* network ID */
Dpc         dpc,              /* affected DPC */
U8          mask,             /* DPC mask */
Txt         *info,            /* extra info */
U16         xtraParam1,       /* extra parameter value 1 */
U16         xtraParam2        /* extra parameter value 2 */
)
#else
PUBLIC S16 itMmhSsnm(assocCb, msgType, nwkId, dpc, mask, info, xtraParam1,
                     xtraParam2)
ItAssocCb   *assocCb;         /* association CB */
U16         msgType;          /* M3UA message type */
U8          nwkId;            /* network ID */
Dpc         dpc;              /* affected DPC */
U8          mask;             /* DPC mask */
Txt         *info;            /* extra info */
U16         xtraParam1;       /* extra parameter value 1 */
U16         xtraParam2;       /* extra parameter value 2 */
#endif
{
   S16      ret;              /* return value */
   Buffer   *mBuf;            /* message buffer */
   ItNwkApp nwkAppVal;        /* network appearance value */
   ItPspId  pspId;            /* PSP ID */

   ItPsCb   *psCb;            /* PS CB      */
   ItPspCb  *pspCb;           /* PSP CB     */
   U16      i;                /* loop index */
   U16      rtCtxLen;         /* Number of Routing Contexts */
   U32      rtCtx[LIT_MAX_PSID];  /* Routing Context list */


   TRC2(itMmhSsnm)

   ret = ROK;

   pspId = assocCb->owner->pspCfg.pspId;
   nwkAppVal = itGlobalCb.nwk[nwkId]->nwkCfg.nwkApp[pspId];

   if ((ret = SGetMsg(assocCb->sctSap->sctCfg.mem.region,
            assocCb->sctSap->sctCfg.mem.pool, &mBuf)) != ROK)
   {
      itMiStaInd(STITGEN, LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                 LCM_CAUSE_MEM_ALLOC_FAIL, 0);
      RETVALUE(ret);
   }

   /* Optional: add network appearance */
   if (assocCb->owner->pspCfg.nwkAppIncl == TRUE)
   {
      IT_MMH_PK_NWK_APP(mBuf, nwkAppVal, ret)
   }
   IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_ADPC, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT208)
   IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(sizeof(U32)), ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT209)
   IT_MMH_PK_U8(mBuf, mask, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT210)
   IT_MMH_PK_DPC(mBuf, dpc, itGlobalCb.nwk[nwkId]->nwkCfg.dpcLen, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT211)

   pspCb = (ItPspCb *)assocCb->owner;
   /* Initialize PS Cb */
   psCb = (ItPsCb *)NULLP;
   /* Pack the RC in SSNM msgs */
   if (assocCb->assocSta->nmbAct > 0)
   {
      rtCtxLen = 0;
      for (i = 0; i < assocCb->assocSta->nmbAct; i++)
      {
         psCb = itPsmFindPs(assocCb->assocSta->actPs[i]);
         if (psCb != NULLP)
         {
            if (itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP)
            {
               if (psCb->psCfg.lclFlag == FALSE)
               {
                  rtCtx[rtCtxLen++] = psCb->psSta.psStaEndp[IT_ASSOC2SUID
                                         (assocCb->assocId)].rteCtx[pspId].rCtx;
               }
            }
            else /* nodeType is ASP */
            {
               if (psCb->psCfg.lclFlag == TRUE)
               {
                  rtCtx[rtCtxLen++] = psCb->psSta.psStaEndp[IT_ASSOC2SUID
                                         (assocCb->assocId)].rteCtx[pspId].rCtx;
               }
            }
         } /* psCb is not NULLP */
      } /* end of loop on Active PS */

      if (rtCtxLen > 0)
      {
         IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_RCTX, ret)
         IT_MMH_CHKLOG(mBuf, ret, EIT212)
         IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(rtCtxLen * sizeof(U32)),
                          ret)
         IT_MMH_CHKLOG(mBuf, ret, EIT213)
         for (i = 0; i < rtCtxLen; i++)
         {
            IT_MMH_PK_U32(mBuf, rtCtx[i], ret)
            IT_MMH_CHKLOG(mBuf, ret, EIT214)
         }
      }
   }

   switch (msgType)
   {
      case IT_SSNM_SCON:
         if ((itGlobalCb.nwk[nwkId]->nwkCfg.ssf == SSF_NAT) ||
             (itGlobalCb.nwk[nwkId]->nwkCfg.dpcLen == DPC16))
         {
            /* Include congestion level for national method */
            IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_CONGLEVEL, ret)
            IT_MMH_CHKLOG(mBuf, ret, EIT215)
            IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(sizeof(U32)), ret)
            IT_MMH_CHKLOG(mBuf, ret, EIT216)
            IT_MMH_PK_U16(mBuf, 0, ret)
            IT_MMH_CHKLOG(mBuf, ret, EIT217)
            IT_MMH_PK_U8(mBuf, 0, ret)
            IT_MMH_CHKLOG(mBuf, ret, EIT218)
            IT_MMH_PK_U8(mBuf, (U8)xtraParam1, ret)
            IT_MMH_CHKLOG(mBuf, ret, EIT219)
         }
         break;

      case IT_SSNM_DUPU:
         /* Include cause and user */
         IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_CAUSEUSER, ret)
         IT_MMH_CHKLOG(mBuf, ret, EIT220)
         IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(sizeof(U32)), ret)
         IT_MMH_CHKLOG(mBuf, ret, EIT221)
         IT_MMH_PK_U16(mBuf, xtraParam1, ret)
         IT_MMH_CHKLOG(mBuf, ret, EIT222)
         IT_MMH_PK_U16(mBuf, xtraParam2, ret)
         IT_MMH_CHKLOG(mBuf, ret, EIT223)
         break;

      default:
         break;
   }

   UNUSED(info);

   if ((ret = itMmhHdrSend(assocCb, &mBuf, msgType, IT_M3UA_MGMT_STREAM))
      != ROK)
   {
      IT_DROPDATA(mBuf);
      RETVALUE(ret);
   }

   IT_STS_INC_M3UA_TX_SSNM(assocCb, msgType);

   RETVALUE(ROK);
} /* end of itMmhSsnm */


/*
*
*       Fun:   itMmhAspUp
*
*       Desc:  Assembles and sends an ASPUP message
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*              ROUTRES - failed, out of resources
*              RNA     - failed, not available
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhAspUp
(
ItAssocCb *assocCb,           /* association CB */
Bool      ackFlag,            /* TRUE to send acknowledge */
Txt       *info               /* optional INFO parameter */
)
#else
PUBLIC S16 itMmhAspUp(assocCb, ackFlag, info)
ItAssocCb *assocCb;           /* association CB */
Bool      ackFlag;            /* TRUE to send acknowledge */
Txt       *info;              /* optional INFO parameter */
#endif
{
   Buffer   *mBuf;            /* message buffer */
   S16      ret;              /* return value */

   TRC2(itMmhAspUp)

   if ((ret = SGetMsg(assocCb->sctSap->sctCfg.mem.region,
            assocCb->sctSap->sctCfg.mem.pool, &mBuf)) != ROK)
   {
      itMiStaInd(STITGEN, LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
           LCM_CAUSE_MEM_ALLOC_FAIL, 0);
      RETVALUE(ret);
   }
   if ((assocCb->owner->pspCfg.rxTxAspId == TRUE) && (ackFlag == FALSE))
   {
      IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_ASPID, ret)
      IT_MMH_CHKLOG(mBuf, ret, EIT224)
      IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(sizeof(U32)), ret)
      IT_MMH_CHKLOG(mBuf, ret, EIT225)
      IT_MMH_PK_U32(mBuf, assocCb->owner->pspCfg.selfAspId, ret)
      IT_MMH_CHKLOG(mBuf, ret, EIT226)      
   }

   if (info != (Txt *) NULLP)
   {
      if (cmStrlen((U8 *)info) > 0)
      {
         ret = itMmhPkString(&mBuf, info, IT_M3UA_TAG_INFO);
         if (ret != ROK)
         {
            RETVALUE(ret);
         }
      }
   }

   if ((ret = itMmhHdrSend(assocCb, &mBuf,
                           (U16)(ackFlag == TRUE ? 
                           IT_ASPM_ASPUP_ACK : IT_ASPM_ASPUP),
                           IT_M3UA_MGMT_STREAM)) != ROK)
   {
      IT_DROPDATA(mBuf);
      RETVALUE(ret);
   }

   if (ackFlag == TRUE)
   {
      IT_STS_INC_M3UA_TX(assocCb, aspUpAck)
   }
   else
   {
      IT_STS_INC_M3UA_TX(assocCb, aspUp)
   }

   RETVALUE(ROK);
} /* end of itMmhAspUp */


/*
*
*       Fun:   itMmhAspDn
*
*       Desc:  Assembles and sends an ASPDN mesasge.
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*              ROUTRES - failed, out of resources
*              RNA     - failed, not available
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhAspDn
(
ItAssocCb *assocCb,           /* association CB */
Bool      ackFlag,            /* TRUE to send acknowledge */
Txt       *info               /* optional INFO parameter */
)
#else
PUBLIC S16 itMmhAspDn(assocCb, ackFlag, info)
ItAssocCb *assocCb;           /* association CB */
Bool      ackFlag;            /* TRUE to send acknowledge */
Txt       *info;              /* optional INFO parameter */
#endif
{
   Buffer   *mBuf;            /* message buffer */
   S16      ret;              /* return value */

   TRC2(itMmhAspDn)

   if ((ret = SGetMsg(assocCb->sctSap->sctCfg.mem.region,
            assocCb->sctSap->sctCfg.mem.pool, &mBuf)) != ROK)
   {
      itMiStaInd(STITGEN, LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
           LCM_CAUSE_MEM_ALLOC_FAIL, 0);
      RETVALUE(ret);
   }

   if (info != (Txt *) NULLP)
   {
      if (cmStrlen((U8 *)info) > 0)
      {
         ret = itMmhPkString(&mBuf, info, IT_M3UA_TAG_INFO);
         if (ret != ROK)
         {
            RETVALUE(ret);
         }
      }
   }

   if ((ret = itMmhHdrSend(assocCb, &mBuf,
                           (U16)(ackFlag == TRUE ? 
                           IT_ASPM_ASPDN_ACK : IT_ASPM_ASPDN),
                           IT_M3UA_MGMT_STREAM)) != ROK)
   {
      IT_DROPDATA(mBuf);
      RETVALUE(ret);
   }

   if (ackFlag == TRUE)
   {
      IT_STS_INC_M3UA_TX(assocCb, aspDnAck)
   }
   else
   {
      IT_STS_INC_M3UA_TX(assocCb, aspDn)
   }

   RETVALUE(ROK);
} /* end of itMmhAspDn */


/*
*
*       Fun:   itMmhAspAc
*
*       Desc:  Assembles and sends and ASPAC message.
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*              ROUTRES - failed, out of resources
*              RNA     - failed, not available
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhAspAc
(
ItAssocCb *assocCb,           /* association CB */
Bool      ackFlag,            /* TRUE to send acknowledge */
U32       type,               /* traffic handling type */
Txt       *info,              /* optional INFO parameter */
ItRtCtx   *rCtx,              /* list of routing contexts */
U16       rCtxLen             /* length of list */
)
#else
PUBLIC S16 itMmhAspAc(assocCb, ackFlag, type, info, rCtx, rCtxLen)
ItAssocCb *assocCb;           /* association CB */
Bool      ackFlag;            /* TRUE to send acknowledge */
U32       type;               /* traffic handling type */
Txt       *info;              /* optional INFO parameter */
ItRtCtx   *rCtx;              /* list of routing contexts */
U16       rCtxLen;            /* length of list */
#endif
{
   Buffer   *mBuf;            /* message buffer */
   U16      i;                /* loop index */
   S16      ret;              /* return value */

   TRC2(itMmhAspAc)


   if ((ret = SGetMsg(assocCb->sctSap->sctCfg.mem.region,
            assocCb->sctSap->sctCfg.mem.pool, &mBuf)) != ROK)
   {
      itMiStaInd(STITGEN, LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
           LCM_CAUSE_MEM_ALLOC_FAIL, 0);
      RETVALUE(ret);
   }

   IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_TRAFMODE, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT227)
   IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(sizeof(U32)), ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT228)
   IT_MMH_PK_U32(mBuf, type, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT229)
   if (rCtxLen > 0)
   {
      IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_RCTX, ret)
      IT_MMH_CHKLOG(mBuf, ret, EIT230)
      IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(rCtxLen * sizeof(U32)), ret)
      IT_MMH_CHKLOG(mBuf, ret, EIT231)
      for (i = 0; i < rCtxLen; i++)
      {
         U32    rtCtx;  /* temp storage for Routing Context */

         rtCtx = rCtx[i].rtCtx;

         IT_MMH_PK_U32(mBuf, rtCtx, ret)
         IT_MMH_CHKLOG(mBuf, ret, EIT232)
      }
   }
   if (info != (Txt *) NULLP)
   {
      if (cmStrlen((U8 *)info) > 0)
      {
         ret = itMmhPkString(&mBuf, info, IT_M3UA_TAG_INFO);
         if (ret != ROK)
         {
            RETVALUE(ret);
         }
      }
   }

   if ((ret = itMmhHdrSend(assocCb, &mBuf,
                           (U16)(ackFlag == TRUE ? 
                           IT_ASPM_ASPAC_ACK : IT_ASPM_ASPAC),
                           IT_M3UA_MGMT_STREAM)) != ROK)
   {
      IT_DROPDATA(mBuf);
      RETVALUE(ret);
   }

   if (ackFlag == TRUE)
   {
      IT_STS_INC_M3UA_TX(assocCb, aspAcAck)
   }
   else
   {
      IT_STS_INC_M3UA_TX(assocCb, aspAc)
   }

   RETVALUE(ROK);
} /* end of itMmhAspAc */


/*
*
*       Fun:   itMmhAspIa
*
*       Desc:  Assembles and sends an ASPIA message
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*              ROUTRES - failed, out of resources
*              RNA     - failed, not available
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhAspIa
(
ItAssocCb *assocCb,           /* association CB */
Bool      ackFlag,            /* TRUE to send acknowledge */
Txt       *info,              /* optional INFO parameter */
ItRtCtx   *rCtx,              /* list of routing contexts */
U16       rCtxLen             /* length of list */
)
#else
PUBLIC S16 itMmhAspIa(assocCb, ackFlag, info, rCtx, rCtxLen)
ItAssocCb *assocCb;           /* association CB */
Bool      ackFlag;            /* TRUE to send acknowledge */
Txt       *info;              /* optional INFO parameter */
ItRtCtx   *rCtx;              /* list of routing contexts */
U16       rCtxLen;            /* length of list */
#endif
{
   Buffer   *mBuf;            /* message buffer */
   U16      i;                /* loop index */
   S16      ret;              /* return value */
   TRC2(itMmhAspIa);

   
   if ((ret = SGetMsg(assocCb->sctSap->sctCfg.mem.region,
            assocCb->sctSap->sctCfg.mem.pool, &mBuf)) != ROK)
   {
      itMiStaInd(STITGEN, LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
           LCM_CAUSE_MEM_ALLOC_FAIL, 0);
      RETVALUE(ret);
   }

   if (rCtxLen > 0)
   {
      IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_RCTX, ret)
      IT_MMH_CHKLOG(mBuf, ret, EIT233)
      IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(rCtxLen * sizeof(U32)), ret)
      IT_MMH_CHKLOG(mBuf, ret, EIT234)
      for (i = 0; i < rCtxLen; i++)
      {
         U32    rtCtx;  /* temp storage for Routing Context */

         rtCtx = rCtx[i].rtCtx;

         IT_MMH_PK_U32(mBuf, rtCtx, ret)
         IT_MMH_CHKLOG(mBuf, ret, EIT235)
      }
   }
   if (info != (Txt *) NULLP)
   {
      if (cmStrlen((U8 *)info) > 0)
      {
         ret = itMmhPkString(&mBuf, info, IT_M3UA_TAG_INFO);
         if (ret != ROK)
         {
            RETVALUE(ret);
         }
      }
   }

   if ((ret = itMmhHdrSend(assocCb, &mBuf,
                           (U16)(ackFlag == TRUE ? 
                           IT_ASPM_ASPIA_ACK : IT_ASPM_ASPIA),
                           IT_M3UA_MGMT_STREAM)) != ROK)
   {
      IT_DROPDATA(mBuf);
      RETVALUE(ret);
   }

   if (ackFlag == TRUE)
   {
      IT_STS_INC_M3UA_TX(assocCb, aspIaAck)
   }
   else
   {
      IT_STS_INC_M3UA_TX(assocCb, aspIa)
   }

   RETVALUE(ROK);
} /* end of itMmhAspIa */


/*
*
*       Fun:   itMmhNotify
*
*       Desc:  Called by the PSM to request sending of a protocol message
*              to and M3UA peer. The message is assembled by creating a
*              new data buffer and encoding the supplied parameters. Calls
*              itSmDatReq to perform the stream mapping and final setting.
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*              ROUTRES - failed, out of resources
*              RNA     - failed, not available
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhNotify
(
ItAssocCb *assocCb,           /* association CB */
Txt       *info,              /* optional INFO parameter */
ItRtCtx   *rCtx,              /* list of routing contexts */
U16       rCtxLen,            /* length of list */
U16       staType,            /* notify type */
Bool      aspIdPres,          /* ASP Id Pres Flag*/
U32       aspId               /* ASP Id */
)
#else
PUBLIC S16 itMmhNotify(assocCb, info, rCtx, rCtxLen, staType, aspIdPres, aspId)
ItAssocCb *assocCb;           /* association CB */
Txt       *info;              /* optional INFO parameter */
ItRtCtx   *rCtx;              /* list of routing contexts */
U16       rCtxLen;            /* length of list */
U16       staType;            /* notify type */
Bool      aspIdPres;          /* ASP Id Pres Flag*/
U32       aspId;              /* ASP Id */
#endif
{
   Buffer   *mBuf;            /* message buffer */
   U16      i;                /* loop index */
   S16      ret;              /* return value */
   TRC2(itMmhNotify);

   if ((ret = SGetMsg(assocCb->sctSap->sctCfg.mem.region,
            assocCb->sctSap->sctCfg.mem.pool, &mBuf)) != ROK)
   {
      itMiStaInd(STITGEN, LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
           LCM_CAUSE_MEM_ALLOC_FAIL, 0);
      RETVALUE(ret);
   }

   IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_STATUS, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT236)
   IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(sizeof(U32)), ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT237)
   IT_MMH_PK_U16(mBuf, staType, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT238)
   IT_MMH_PK_U16(mBuf, rCtx->ntfyStaId, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT239)

   if (aspIdPres == TRUE)
   {
      IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_ASPID, ret)
      IT_MMH_CHKLOG(mBuf, ret, EIT240)
      IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(sizeof(U32)), ret)
      IT_MMH_CHKLOG(mBuf, ret, EIT241)

      IT_MMH_PK_U32(mBuf, aspId, ret)
      IT_MMH_CHKLOG(mBuf, ret, EIT242)
   }
   if (rCtxLen > 0)
   {
      IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_RCTX, ret)
      IT_MMH_CHKLOG(mBuf, ret, EIT243)
      IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(rCtxLen * sizeof(U32)), ret)
      IT_MMH_CHKLOG(mBuf, ret, EIT244)
      for (i = 0; i < rCtxLen; i++)
      {
         U32    rtCtx;  /* temp storage for Routing Context */

         rtCtx = rCtx[i].rtCtx;

         IT_MMH_PK_U32(mBuf, rtCtx, ret)
         IT_MMH_CHKLOG(mBuf, ret, EIT245)
      }
   }
   if (info != (Txt *) NULLP)
   {
      if (cmStrlen((U8 *)info) > 0)
      {
         ret = itMmhPkString(&mBuf, info, IT_M3UA_TAG_INFO);
         if (ret != ROK)
         {
            RETVALUE(ret);
         }
      }
   }

   if ((ret = itMmhHdrSend(assocCb, &mBuf, IT_M3UA_NOTIFY, IT_M3UA_MGMT_STREAM))
         != ROK)
   {
      IT_DROPDATA(mBuf);
      RETVALUE(ret);
   }

   IT_STS_INC_M3UA_TX(assocCb, notify);

   RETVALUE(ROK);
} /* end of itMmhNotify */


/*
*
*       Fun:   itMmhError
*
*       Desc:  Called by MMH to request sending of an Error message
*              to an M3UA peer. The message is assembled by creating
*              a new data buffer and encoding the supplied parameter.
*              Calls itSmDatReq to perform stream mapping and final
*              sending.
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*              ROUTRES - failed, out of resources
*              RNA     - failed, not available
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhError
(
ItAssocCb   *assocCb,         /* association CB */
U32         errorCode,        /* error code */
Buffer      **oldBuf,         /* pointer to original message */
U32         invParm,          /* invalid parameter value */
ItM3uaTag   *tag,             /* invalid parameter tag */
ItRtCtx     *rCtx,            /* routing context list */
U16         rCtxLen,          /* routing context list length */
U32         nwkApp            /* Network Appearance */
)
#else
PUBLIC S16 itMmhError(assocCb, errorCode, oldBuf, invParm, tag, rCtx, rCtxLen, 
                      nwkApp)
ItAssocCb   *assocCb;         /* association CB */
U32         errorCode;        /* error code */
Buffer      **oldBuf;         /* pointer to original message */
U32         invParm;          /* invalid parameter value */
ItM3uaTag   *tag;             /* invalid parameter tag */
ItRtCtx     *rCtx;            /* routing context list */
U16         rCtxLen;          /* routing context list length */
U32         nwkApp;           /* Network Appearance */
#endif
{
   Buffer   *mBuf;            /* message buffer */
   S16      ret;              /* return value */
   MsgLen   diagCnt;          /* diagnostic counter */
   U8       tmp8;             /* temporary U8 */
   U8       i;                /* Loop Counter */
   U16      cur;              /* current position */
   MsgLen   len;              /* message length */
   U16      msgType;          /* message type */

   TRC2(itMmhError);
   
   diagCnt = 0;
   len = 0;
   msgType = IT_M3UA_DFLT;

   if ((oldBuf  != (Buffer **)NULLP) && (*oldBuf != (Buffer *)NULLP))
   {
      (Void) SFndLenMsg(*oldBuf, &len);
      if (len >= 4)
      {
         U8  idx;     /* temporary idx */

         idx = 2;
         IT_MMH_EXAM_U16(*oldBuf, msgType, idx, ret)
         IT_MMH_CHKLOG(*oldBuf, ret, EIT246)

         /* If error message is being sent in response of an error message
          * received from the peer node, then don't send the error message */

         if (msgType == IT_M3UA_ERROR)
         {
            IT_DROPDATA(*oldBuf);
            RETVALUE(ROK);
         }
      }
   }

   if ((ret = SGetMsg(assocCb->sctSap->sctCfg.mem.region,
            assocCb->sctSap->sctCfg.mem.pool, &mBuf)) != ROK)
   {
      itMiStaInd(STITGEN, LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
           LCM_CAUSE_MEM_ALLOC_FAIL, 0);
      RETVALUE(ret);
   }
   if (nwkApp != IT_M3UA_DFLT)
   {
      IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_NWKAPP, ret)
      IT_MMH_CHKLOG(mBuf, ret, EIT247)
      IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(sizeof(U32)), ret)
      IT_MMH_CHKLOG(mBuf, ret, EIT248)
      IT_MMH_PK_U32(mBuf, nwkApp, ret)
      IT_MMH_CHKLOG(mBuf, ret, EIT249)
   }
   IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_ERRCODE, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT250)
   IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(sizeof(U32)), ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT251)
   IT_MMH_PK_U32(mBuf, errorCode, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT252)
   
   if (rCtxLen != NULLD)
   {
      IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_RCTX, ret)
      IT_MMH_CHKLOG(mBuf, ret, EIT253)
      IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(rCtxLen * sizeof(U32)), ret)
      IT_MMH_CHKLOG(mBuf, ret, EIT254)

      for (i=0; i<rCtxLen; i++)
      {
         IT_MMH_PK_U32(mBuf, rCtx[i].rtCtx, ret)
         IT_MMH_CHKLOG(mBuf, ret, EIT255)
      }
   }

   switch (errorCode)
   {
      /* the following 5 cases fall through */
      case IT_M3UA_ERROR_INV_VERSION:
      case IT_M3UA_ERROR_UNSUPP_THM:
      case IT_M3UA_ERROR_INV_PARMVAL:
         IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_DIAG, ret)
         IT_MMH_CHKLOG(mBuf, ret, EIT256)
         IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(sizeof(U32)), ret)
         IT_MMH_CHKLOG(mBuf, ret, EIT257)
         IT_MMH_PK_U32(mBuf, invParm, ret)
         IT_MMH_CHKLOG(mBuf, ret, EIT258)
         break;

      default:
      {
         if (tag != (ItM3uaTag *) NULLP)
         {
            /* For invalid parameter value, we return the TLV */
            diagCnt = (S16)MIN(tag->length + 4, IT_M3UA_MAXDIAG);
            cur = (U16)(tag->offset - 4);
            diagCnt = (MsgLen)(diagCnt + cur);
         }
         else
         {
            if ((oldBuf != (Buffer **)NULLP) && (*oldBuf != (Buffer *)NULLP))
            {
               (Void) SFndLenMsg(*oldBuf, &diagCnt);
            }
            if (diagCnt > IT_M3UA_MAXDIAG)
            {
               diagCnt = IT_M3UA_MAXDIAG;
            }
            cur = 0;
         }
         if ((diagCnt > 0) && (oldBuf != (Buffer **) NULLP)) 
         {
            IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_DIAG, ret)
            IT_MMH_CHKLOG(mBuf, ret, EIT259)
            IT_MMH_PK_U16(mBuf, (U16) IT_MMH_LEN_ADJ(diagCnt - cur), ret)
            IT_MMH_CHKLOG(mBuf, ret, EIT260)
            while (cur < diagCnt)
            {
               IT_MMH_EXAM_U8(*oldBuf, tmp8, cur, ret);
               IT_MMH_CHKLOG(*oldBuf, ret, EIT261)
               IT_MMH_PK_U8(mBuf, tmp8, ret)
               IT_MMH_CHKLOG(mBuf, ret, EIT262)
            }
            /* Pad to 32 bits */
            for (cur = 0;
               cur < ((sizeof(U32) - (diagCnt % sizeof(U32))) % sizeof(U32));
               cur++)
            {
               IT_MMH_PK_U8(mBuf, 0, ret);
               IT_MMH_CHKLOG(mBuf, ret, EIT263)
            }
         }
         break;
      }
   }
   if ((ret = itMmhHdrSend(assocCb, &mBuf, IT_M3UA_ERROR, IT_M3UA_MGMT_STREAM))
         != ROK)
   {
      IT_DROPDATA(mBuf);
      RETVALUE(ret);
   }
   if ((oldBuf != (Buffer **)NULLP) && (*oldBuf != (Buffer *) NULLP))
   {
      IT_DROPDATA(*oldBuf);
   }
   IT_STS_INC_M3UA_TX(assocCb, err);

   RETVALUE(ROK);
} /* end of itMmhError */


/*
*
*       Fun:   itMmhHBeat
*
*       Desc:  Called by PSM to request sending of a Heartbeat
*              message to an M3UA peer. The message is assembled
*              by creating a new data buffer and encoding the
*              header. Call itSmDatReq to perform the stream mapping
*              and final sending.
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*              ROUTRES - failed, out of resources
*              RNA     - failed, not available
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhHBeat
(
ItAssocCb   *assocCb,         /* association CB */
Bool        ackFlag,          /* TRUE to send acknowledge */
Buffer      **oldBuf,         /* received heartbeat message */
ItM3uaTag   *tag              /* BEAT DATA tag info */
)
#else
PUBLIC S16 itMmhHBeat(assocCb, ackFlag, oldBuf, tag)
ItAssocCb   *assocCb;         /* association CB */
Bool        ackFlag;          /* TRUE to send acknowledge */
Buffer      **oldBuf;         /* received heartbeat message */
ItM3uaTag   *tag;             /* BEAT DATA tag info */
#endif
{
   Buffer   **mBufPtr;            /* message buffer pointer */
   Buffer   *mBuf;                /* message buffer */
   S16      ret;              /* return value */

   TRC2(itMmhHBeat);

   mBufPtr = &mBuf;

   if (ackFlag == FALSE)
   {
      if ((ret = SGetMsg(assocCb->sctSap->sctCfg.mem.region,
               assocCb->sctSap->sctCfg.mem.pool, mBufPtr)) != ROK)
      {
         itMiStaInd(STITGEN, LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
              LCM_CAUSE_MEM_ALLOC_FAIL, 0);
         RETVALUE(ret);
      }
   }
   else
   {
      if (oldBuf == (Buffer **)NULLP)
      {
         RETVALUE(RFAILED);
      }
      {
        /* BEAT ACK: use oldBuf */
        Data     tmp[IT_M3UA_MAXHDR]; /* temp buffer for stripping header */
        MsgLen   len;                 /* message length */
        mBufPtr = oldBuf;
        SFndLenMsg(*mBufPtr, &len);
        if (tag->pres == TRUE)
        {
           if (tag->offset < len)
           {
              /* strip message header, but not parameter tag */
              len = (S16)(tag->offset - sizeof(U32));
           }
        }
        /* Strip header, leaving parameter (if any) */
        SRemPreMsgMult(tmp, len, *mBufPtr);
      }
   }

   if ((ret = itMmhHdrSend(assocCb, mBufPtr,
                           (U16)(ackFlag == TRUE ? IT_ASPM_BEAT_ACK : 
                                                   IT_ASPM_BEAT),
                           IT_M3UA_MGMT_STREAM)) != ROK)
   {
      IT_DROPDATA(*mBufPtr);
      RETVALUE(ret);
   }

   if (ackFlag == TRUE)
   {
      IT_STS_INC_M3UA_TX(assocCb, hBeatAck);
   }
   else
   {
      IT_STS_INC_M3UA_TX(assocCb, hBeat);
   }

   RETVALUE(ROK);
} /* end of itMmhHBeat */

#ifdef ITASP
/*
*
*       Fun:   itMmhRegReq
*
*       Desc:  Assembles and sends an REG REQ message
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*              ROUTRES - failed, out of resources
*              RNA     - failed, not available
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhRegReq
(
ItCntrl     *cntrl,            /* Contrl request received from LM */
ItAssocCb   *assocCb           /* Assoc CB to which REG REQ is to be sent */
)
#else
PUBLIC S16 itMmhRegReq(cntrl, assocCb)
ItCntrl     *cntrl;            /* Contrl request received from LM */
ItAssocCb   *assocCb;          /* Assoc CB to which REG REQ is to be sent */
#endif
{
   Buffer      *mBuf;            /* message buffer */
   U16         i;                /* loop index */
   S16         ret;              /* return value */
   Buffer      *tmpMBuf;         /* Temp message Buffer */ 

   
   TRC2(itMmhRegReq)


   if ((ret = SGetMsg(assocCb->sctSap->sctCfg.mem.region,
            assocCb->sctSap->sctCfg.mem.pool, &mBuf)) != ROK)
   {
      itMiStaInd(STITGEN, LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
           LCM_CAUSE_MEM_ALLOC_FAIL, 0);
      RETVALUE(ret);
   }
   if ((ret = SGetMsg(assocCb->sctSap->sctCfg.mem.region,
        assocCb->sctSap->sctCfg.mem.pool, &tmpMBuf)) != ROK)
   {
      itMiStaInd(STITGEN, LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
       LCM_CAUSE_MEM_ALLOC_FAIL, 0);
      RETVALUE(ret);
   }

   /* Pack each of the rtFilter in the REG REQ message */
   for (i = 0; i < (cntrl->t.dynRteKey.rkm.rK.nmbRk); i++)
   {
       S16    tag;
       U16    tmp16;
       U8     hdr[4];
       MsgLen len;
       ItPsCb *psCb = (ItPsCb *)NULLP; /* PScb to get the nwkCb */
       ItNwkCb     *nwkCb;           /* Network Control Block */

       psCb  = itPsmFindPs(cntrl->t.dynRteKey.rkm.rK.routKey[i].psId);
       /* psCb will not be NULLP as it has been checked earlier */
       nwkCb = itGlobalCb.nwk[psCb->psCfg.nwkId];
       ret = itMmhCodeRk(assocCb, 
                  assocCb->regReqTmrCb[0].req.regReq.localRkId[i],
                  cntrl->t.dynRteKey.rkm.rK.routKey[i].mode,
                  &cntrl->t.dynRteKey.rkm.rK.routKey[i].rtKey,
                  nwkCb->nwkCfg.nwkId,
                  &tmpMBuf);  
       if (ret != ROK)
       {
          IT_DROPDATA(tmpMBuf);
          IT_DROPDATA(mBuf);
          RETVALUE(ret);
       }

  

       /* SAddPreMsgMult works in reverse, so build the tag backward */
       (Void) SFndLenMsg(tmpMBuf, &len);
       tag      = IT_M3UA_TAG_RK;
       hdr[3]   = (U8) GetHiByte(tag); /* RK Tag */
       hdr[2]   = (U8) GetLoByte(tag); /* RK Tag */

       tmp16    = (U16)((U16)len + 4); 
       hdr[1]   = (U8) GetHiByte(tmp16);
       hdr[0]   = (U8) GetLoByte(tmp16);
       if ((ret = SAddPreMsgMult((Data *)hdr, 4, tmpMBuf)) != ROK)
       {
          IT_DROPDATA(mBuf);
          IT_DROPDATA(tmpMBuf);
          RETVALUE(ret);
       }
       SCatMsg(mBuf, tmpMBuf, M1M2);
   }

   IT_DROPDATA(tmpMBuf);
   
   if ((ret = itMmhHdrSend(assocCb, &mBuf,
                           IT_RKM_REGREQ,
                           IT_M3UA_MGMT_STREAM)) != ROK)
   {
      IT_DROPDATA(mBuf);
      RETVALUE(ret);
   }

   IT_STS_INC_M3UA_TX(assocCb, regReq)
   RETVALUE(ROK);

} /* end of itMmhRegReq */

/*
*
*       Fun:   itMmhDeRegReq
*
*       Desc:  Assembles and sends an DEREG REQ message
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*              ROUTRES - failed, out of resources
*              RNA     - failed, not available
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhDeRegReq
(
ItAssocCb     *assocCb,       /* association CB */
ItRegReqTmrCb *deregTmrCb     /* routing filter */
)
#else
PUBLIC S16 itMmhDeRegReq(assocCb, deregTmrCb)
ItAssocCb     *assocCb;       /* association CB */
ItRegReqTmrCb *deregTmrCb;    /* routing filter */
#endif
{
   Buffer   *mBuf;            /* message buffer */
   U16      i;                /* loop index */
   S16      ret;              /* return value */

   TRC2(itMmhDeRegReq)

   if ((ret = SGetMsg(assocCb->sctSap->sctCfg.mem.region,
            assocCb->sctSap->sctCfg.mem.pool, &mBuf)) != ROK)
   {
      itMiStaInd(STITGEN, LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
           LCM_CAUSE_MEM_ALLOC_FAIL, 0);
      RETVALUE(ret);
   }

   /* Pack RC tag */
   IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_RCTX, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT264)

   IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(deregTmrCb->req.deRegReq.nmbRctx * 
                    sizeof(U32)), ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT265)

   /* For each of the RC in RKRTCB */
   for (i = 0; i < (deregTmrCb->req.deRegReq.nmbRctx); i++)
   {
      /* Routing Contexts */
      IT_MMH_PK_U32(mBuf, deregTmrCb->req.deRegReq.rCtx[i].routCntx, ret)
      IT_MMH_CHKLOG(mBuf, ret, EIT266)
   }

   if ((ret = itMmhHdrSend(assocCb, &mBuf,
                           IT_RKM_DREGREQ,
                           IT_M3UA_MGMT_STREAM)) != ROK)
   {
      IT_DROPDATA(mBuf);
      RETVALUE(ret);
   }
   IT_STS_INC_M3UA_TX(assocCb, deRegReq)
   RETVALUE(ROK);
} /* end of itMmhDeRegReq */
#endif /*  ITASP */


/*
*
*       Fun:   itMmhDeRegRsp
*
*       Desc:  Assembles and sends an DEREG RSP message
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*              ROUTRES - failed, out of resources
*              RNA     - failed, not available
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhDeRegRsp
(
ItAssocCb     *assocCb,       /* association CB */
U8             dregSta,        /* De-registration status */
U32            rCtx          /* Routing Context */
)
#else
PUBLIC S16 itMmhDeRegRsp(assocCb, dregSta, rCtx)
ItAssocCb     *assocCb;       /* association CB */
U8             dregSta;       /* De-registration status */
U32            rCtx;          /* Routing Context */
#endif
{
   Buffer   *mBuf;            /* message buffer */
   S16      ret;              /* return value */

   TRC2(itMmhDeRegRsp)

   if ((ret = SGetMsg(assocCb->sctSap->sctCfg.mem.region,
            assocCb->sctSap->sctCfg.mem.pool, &mBuf)) != ROK)
   {
      itMiStaInd(STITGEN, LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
           LCM_CAUSE_MEM_ALLOC_FAIL, 0);
      RETVALUE(ret);
   }

   /* Pack DeReg Rslts tag */
   IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_DREGRSLT, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT267)

   IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(4 * sizeof(U32)), ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT268)

   /* Routing Context */
   IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_RCTX, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT269)
   IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(sizeof(U32)), ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT270)
   IT_MMH_PK_U32(mBuf, rCtx, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT271)
   /* De-registration Status */
   IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_DREGSTA, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT272)
   IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(sizeof(U32)), ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT273)
   IT_MMH_PK_U32(mBuf, dregSta, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT274)

   if ((ret = itMmhHdrSend(assocCb, &mBuf,
                           IT_RKM_DREGRSP,
                           IT_M3UA_MGMT_STREAM)) != ROK)
   {
      IT_DROPDATA(mBuf);
      RETVALUE(ret);
   }
   IT_STS_INC_M3UA_TX(assocCb, deRegRsp)
   /* decrement the number of rk registered */
   itGlobalCb.addrTrn.rkSta.nmbRkReg--;
   RETVALUE(ROK);
} /* end of itMmhDeRegRsp */

/*
*
*       Fun:   itMmhRegRsp
*
*       Desc:  This function is called by AT to send REG RSP to peer.
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhRegRsp
(
ItAssocCb *assocCb,        /* Assoc CB            */
U8        regStat,         /* Registration Status */
U32       rCtx,            /* Routing Context     */
U32       lclRkId          /* Local RK ID         */
)
#else
PUBLIC S16 itMmhRegRsp(assocCb, regStat, rCtx , lclRkId)
ItAssocCb *assocCb;        /* Assoc CB            */
U8        regStat;         /* Registration Status */
U32       rCtx;            /* Routing Context     */
U32       lclRkId;         /* Local RK ID         */
#endif
{
   Buffer      *mBuf;            /* message buffer */
   S16          ret;              /* return value */

   TRC2(itMmhRegRsp)

   if ((ret = SGetMsg(assocCb->sctSap->sctCfg.mem.region,
            assocCb->sctSap->sctCfg.mem.pool, &mBuf)) != ROK)
   {
      itMiStaInd(STITGEN, LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
           LCM_CAUSE_MEM_ALLOC_FAIL, 0);
      RETVALUE(ret);
   }
   /* Registration Results */
   IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_REGRSLT, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT275)
   IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(6 * sizeof(U32)), ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT276)
   /* Local RK id */
   IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_LCLRKID, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT277)
   IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(sizeof(U32)), ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT278)
   IT_MMH_PK_U32(mBuf, lclRkId, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT279)
   /* Registration Status */
   IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_REGSTA, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT280)
   IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(sizeof(U32)), ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT281)
   IT_MMH_PK_U32(mBuf, regStat, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT282)
   /* Routing Context */
   IT_MMH_PK_U16(mBuf, IT_M3UA_TAG_RCTX, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT283)
   IT_MMH_PK_U16(mBuf, IT_MMH_LEN_ADJ(sizeof(U32)), ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT284)
   IT_MMH_PK_U32(mBuf, rCtx, ret)
   IT_MMH_CHKLOG(mBuf, ret, EIT285)

   if ((ret = itMmhHdrSend(assocCb, &mBuf,
                           IT_RKM_REGRSP,
                           IT_M3UA_MGMT_STREAM)) != ROK)
   {
      IT_DROPDATA(mBuf);
      RETVALUE(ret);
   }

   IT_STS_INC_M3UA_TX(assocCb, regRsp)
   /* increment the number of rk registered */
   if (regStat == IT_RK_SUCC_REGD) 
   {
      itGlobalCb.addrTrn.rkSta.nmbRkReg++;
   }
   
   RETVALUE(ROK);
   
} /* end of itMmhRegRsp */

#ifdef ITASP
/*
*
*       Fun:   itMmhCodeRk
*
*       Desc:  Assembles a single RK to be send in REG REQ message
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*              ROUTRES - failed, out of resources
*              RNA     - failed, not available
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhCodeRk
(
ItAssocCb   *assocCb,       /* Assoc Control Block */
U32         lclRkId,        /* Local RK id */
U8          mode,           /* THM */
ItRoutKey  *rtKey,          /* Routing Key */
U8          nwkId,          /* Network Id */
Buffer      **mBuf          /* pointer to Message Buffer */
)
#else
PUBLIC S16 itMmhCodeRk(assocCb, lclRkId, mode, rtKey, nwkId, mBuf)
ItAssocCb   *assocCb;       /* Assoc Control Block */
U32         lclRkId;         /* Local RK id */
U8          mode;            /* THM */       
ItRoutKey  *rtKey;          /* Routing Key */
U8          nwkId;          /* Network Id */
Buffer      **mBuf;          /* pointer to Message Buffer */
#endif
{
   S16      ret;              /* return value */
   S16      i;                /* Loop Index */
   ItNwkCb *nwkCb;            /* Network Control Block */
   U32      nwkAppVal;        /* Network Appearance Value */
   U8       dpcLen;           /* DPC length */

   TRC2(itMmhCodeRk)

   if (mBuf == (Buffer **)NULLP)
   {
      RETVALUE(RFAILED);
   }
   nwkCb = itGlobalCb.nwk[nwkId];

   /* Optional Network Appearance */
   nwkAppVal = nwkCb->nwkCfg.nwkApp[assocCb->owner->pspCfg.pspId];
   dpcLen    = nwkCb->nwkCfg.dpcLen;

   if (assocCb->owner->pspCfg.nwkAppIncl == TRUE)
   {
      IT_MMH_PK_NWK_APP(*mBuf, nwkAppVal, ret)
   }
   /* Local RK id for REG REQ */
   IT_MMH_PK_U16(*mBuf, IT_M3UA_TAG_LCLRKID, ret)
   IT_MMH_CHKLOG(*mBuf, ret, EIT286)
   IT_MMH_PK_U16(*mBuf, IT_MMH_LEN_ADJ(sizeof(U32)), ret)
   IT_MMH_CHKLOG(*mBuf, ret, EIT287)
   IT_MMH_PK_U32(*mBuf, lclRkId, ret)
   IT_MMH_CHKLOG(*mBuf, ret, EIT288)

   /* Traffic mode */
   IT_MMH_PK_U16(*mBuf, IT_M3UA_TAG_TRAFMODE, ret)
   IT_MMH_CHKLOG(*mBuf, ret, EIT289)
   IT_MMH_PK_U16(*mBuf, IT_MMH_LEN_ADJ(sizeof(U32)), ret)
   IT_MMH_CHKLOG(*mBuf, ret, EIT290)
   IT_MMH_PK_U32(*mBuf, mode, ret)
   IT_MMH_CHKLOG(*mBuf, ret, EIT291)


   /* Destination Point Code */
   IT_MMH_PK_U16(*mBuf, IT_M3UA_TAG_DPC, ret)
   IT_MMH_CHKLOG(*mBuf, ret, EIT292)
   IT_MMH_PK_U16(*mBuf, IT_MMH_LEN_ADJ(sizeof(U32)), ret)
   IT_MMH_CHKLOG(*mBuf, ret, EIT293)
   /* mask as 0 */
   IT_MMH_PK_U8(*mBuf, 0, ret)
   IT_MMH_CHKLOG(*mBuf, ret, EIT294)
   IT_MMH_PK_DPC(*mBuf, rtKey->dpc, dpcLen, ret)
   IT_MMH_CHKLOG(*mBuf, ret, EIT295)

   /* Optional Service Indicators Code List */
   if (rtKey->nmbSio > 0)
   {
      IT_MMH_PK_U16(*mBuf, IT_M3UA_TAG_SI, ret)
      IT_MMH_CHKLOG(*mBuf, ret, EIT296)
      IT_MMH_PK_U16(*mBuf, IT_MMH_LEN_ADJ(rtKey->nmbSio * sizeof(SrvInfo)), ret)
      IT_MMH_CHKLOG(*mBuf, ret, EIT297)
      for (i = 0; i < rtKey->nmbSio; i++)
      {
         IT_MMH_PK_U8(*mBuf, rtKey->sio[i], ret);
         IT_MMH_CHKLOG(*mBuf, ret, EIT298)
      }
      /* Pad to 32 bits */
      IT_PK_PAD32(rtKey->nmbSio, *mBuf)
   }
   /* Optional OPC List */
   /* Pack OPCs, if present in rtFilter */
   if (rtKey->nmbOpc > 0)
   {
      IT_MMH_PK_U16(*mBuf, IT_M3UA_TAG_OPC, ret)
      IT_MMH_CHKLOG(*mBuf, ret, EIT299)
      IT_MMH_PK_U16(*mBuf, IT_MMH_LEN_ADJ(rtKey->nmbOpc * sizeof(Dpc)), ret)
      IT_MMH_CHKLOG(*mBuf, ret, EIT300)

      for (i = 0; i < rtKey->nmbOpc; i++)
      {
         /* Mask as 0 */
         IT_MMH_PK_U8(*mBuf, 0, ret)
         IT_MMH_CHKLOG(*mBuf, ret, EIT301)
         IT_MMH_PK_DPC(*mBuf, rtKey->opc[i], dpcLen, ret)
         IT_MMH_CHKLOG(*mBuf, ret, EIT302)
      }
   }

   /* Optional CIC-Range List */
   if (rtKey->nmbCic > 0)
   {
      IT_MMH_PK_U16(*mBuf, IT_M3UA_TAG_CICRNG, ret)
      IT_MMH_CHKLOG(*mBuf, ret, EIT303)
      IT_MMH_PK_U16(*mBuf, 
      IT_MMH_LEN_ADJ(rtKey->nmbCic * (2 * sizeof(Cic) + sizeof(Dpc))),
                       ret)
      IT_MMH_CHKLOG(*mBuf, ret, EIT304)

      for (i = 0; i < rtKey->nmbCic; i++)
      {
         /* Mask as 0 */
         IT_MMH_PK_U8(*mBuf, 0, ret)
         IT_MMH_CHKLOG(*mBuf, ret, EIT305)
         IT_MMH_PK_DPC(*mBuf, rtKey->cicRange[i].opc, dpcLen, ret)
         IT_MMH_CHKLOG(*mBuf, ret, EIT306)
         IT_MMH_PK_U16(*mBuf, rtKey->cicRange[i].cicStart, ret)
         IT_MMH_CHKLOG(*mBuf, ret, EIT307)
         IT_MMH_PK_U16(*mBuf, rtKey->cicRange[i].cicEnd, ret)
         IT_MMH_CHKLOG(*mBuf, ret, EIT308)
      }
   }
   RETVALUE(ROK);
} /* End of itMmhCodeRk */
#endif /* ITASP */


/*
*
*       Fun:   itMmhVerifyRkm
*
*       Desc:  This function verifies all the tag values present in RKM
*              messages
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhVerifyRkm
(
ItAssocCb     *assocCb,       /* association CB */
U16            msgType,       /* M3UA message type */
Buffer        **mBuf,         /* pointer to message */
MsgLen         len,           /* message len */
MsgLen         cur,           /* current message offset */
ItM3uaTag     *tag            /* parameter state array */
)
#else
PUBLIC S16 itMmhVerifyRkm(assocCb, msgType, mBuf, len, cur, tag) 
ItAssocCb     *assocCb;       /* association CB */
U16            msgType;       /* M3UA message type */
Buffer        **mBuf;         /* pointer to message */
MsgLen         len;           /* message len */
MsgLen         cur;           /* current message offset */
ItM3uaTag      *tag;          /* parameter state array */
#endif
{
   U8          i;             /* Loop Counter */

   TRC2(itMmhVerifyRkm)

   if (mBuf == (Buffer **)NULLP)
   {
      RETVALUE(RFAILED);
   }

   while (cur <= (len - (MsgLen) sizeof(U32)))
   {
      U16 tagId;           /* tag identifier */
      U16 tagLen;          /* parameter length */
      S16 curIdx;          /* temporary storage of current msg offset "cur" */
      S16 ret;             /* Return Value */

      /* Extract IT_M3UA_TAG_RK, IT_M3UA_TAG_REGRSLT, IT_M3UA_TAG_DREGRSLT */

      IT_MMH_EXAM_U16(*mBuf, tagId, cur, ret)
      IT_MMH_CHKLOG(*mBuf, ret, EIT309)
      IT_MMH_EXAM_U16(*mBuf, tagLen, cur, ret)
      IT_MMH_CHKLOG(*mBuf, ret, EIT310)

      tagLen = (U16)IT_MMH_LEN_UNADJ(tagLen);

      if (!((tagId == IT_M3UA_TAG_RK) || (tagId == IT_M3UA_TAG_REGRSLT) ||
            (tagId == IT_M3UA_TAG_DREGRSLT))) 
      {
          /* Invalid tag/taglength */
         ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
  "itMmhVerifyRkm(): Invalid M3UA parameter (msg = %04X tag = %02X len = %d)\n",
            msgType, tagId, IT_MMH_LEN_ADJ(tagLen)))
         itMmhError(assocCb, IT_M3UA_ERROR_PROTO_ERR, mBuf, 0,
                             (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT); 
         RETVALUE(RFAILED); 
      }

      if ((tagLen <= 0) || (tagLen > (len - cur)))
      {
          /* Invalid tag/taglength */
         ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
  "itMmhVerifyRkm(): Invalid M3UA parameter (msg = %04X tag = %02X len = %d)\n",
            msgType, tagId, IT_MMH_LEN_ADJ(tagLen)))
         itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR, mBuf, 0,
                             (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT); 
         RETVALUE(RFAILED); 
      }

      for (i=0; i < IT_M3UA_TAGARRAYSIZE; i++)
      {
         tag[i].pres = FALSE;
         if (tag[i].tag == tagId)
         {
            tag[i].pres = TRUE;
            break;
         }
      }
      if (i == IT_M3UA_TAGARRAYSIZE)
      {
         itMmhError(assocCb, IT_M3UA_ERROR_UNEXPECTED_PARAM, mBuf, 0,
                             (ItM3uaTag *) NULLP, (ItRtCtx *) NULLP, 0,
                             IT_M3UA_DFLT);
         RETVALUE(RFAILED);
      }
            
      curIdx = (S16)cur;
      while ( cur <= (curIdx + tagLen - (MsgLen) sizeof(U32)))
      {
         U16 subTagId;       /* tag identifier of sub parameters */
         U16 subTagLen;      /* tag length of sub parameters */
         U8  subTagIdx;      /* tag Index of sub parameters */

         IT_MMH_EXAM_U16(*mBuf, subTagId, cur, ret)
         IT_MMH_CHKLOG(*mBuf, ret, EIT311)
         IT_MMH_EXAM_U16(*mBuf, subTagLen, cur, ret)
         IT_MMH_CHKLOG(*mBuf, ret, EIT312) 
      
         subTagLen = (U16)IT_MMH_LEN_UNADJ(subTagLen);
        

         /* Convert the parameter id received in the msg to a tag index */
         for (subTagIdx = 0; subTagIdx < IT_M3UA_TAGARRAYSIZE; subTagIdx++)
         {
            if (tag[subTagIdx].tag == subTagId)
            {
               break;
            }
         }
         if (subTagIdx == IT_M3UA_TAGARRAYSIZE)                                       
         {                                                                      
            itMmhError(assocCb, IT_M3UA_ERROR_UNEXPECTED_PARAM, mBuf, 
                                0, (ItM3uaTag *) NULLP, (ItRtCtx *) NULLP, 0,
                                IT_M3UA_DFLT);   
            RETVALUE(RFAILED);
         }                                                                       
         tag[subTagIdx].pres = TRUE;
         cur = (S16)(cur + subTagLen);
         cur = (S16) (cur + (sizeof(U32) - 
                             (subTagLen % sizeof(U32))) % sizeof(U32));

      }

      for (i=0; i < IT_M3UA_TAGARRAYSIZE; i++)
      {
         /* Check actual parameters against expected parameters */
         if ((tag[i].mand == TRUE) && (tag[i].pres == FALSE))
         {
            /* Mandatory parameter is not present */
            ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
      "itMmhVerifyRkm(): Mandatory parameter missing (msg = %04X tag = %02X)\n",
            msgType, i))

            itMmhError(assocCb, IT_M3UA_ERROR_MISSING_PARAM, mBuf, 0,
                             (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT); 
            RETVALUE(RFAILED); 
         }
         if (tag[i].pres == TRUE)
         {
            if ((tag[i].mand == FALSE) && (tag[i].opt == FALSE))
            {
                /* Parameter is not allowed for this message type */
                ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
      "itMmhVerifyRkm(): Invalid parameter for message (msg = %04X tag = %02X)\n",
                msgType, i))

                itMmhError(assocCb, IT_M3UA_ERROR_PROTO_ERR, mBuf, 0,
                             (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT); 
                RETVALUE(RFAILED); 
            }
         }
      } /* end for loop */
   }/* end of while loop */
   RETVALUE(ROK);
} /* end of itMmhVerifyRkm */
    


/*
*
*       Fun:   itMmhProcRkm
*
*       Desc:  This Function verifies the parameter values present in RKM
*              messages and if all the parameters are found to be correct
*              then calls the appropraite function for processing of message.
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhProcRkm
(
ItAssocCb     *assocCb,       /* association CB */
U16            msgType,       /* M3UA message type */
Buffer        **mBuf,         /* pointer to message */
MsgLen         len,           /* message len */
MsgLen         cur,           /* current message offset */
ItM3uaTag     *tag            /* parameter state array */
)
#else
PUBLIC S16 itMmhProcRkm(assocCb, msgType, mBuf, len, cur, tag) 
ItAssocCb     *assocCb;       /* association CB */
U16            msgType;       /* M3UA message type */
Buffer        **mBuf;         /* pointer to message */
MsgLen         len;           /* message len */
MsgLen         cur;           /* current message offset */
ItM3uaTag      *tag;          /* parameter state array */
#endif
{

   TRC2(itMmhProcRkm)

   while (cur <= (len - (MsgLen) sizeof(U32)))
   {
      U16   tagId;           /* tag identifier */
      U16   tagLen;          /* parameter length */
      U8    tagIdx;          /* Tag Index */
      U8    subTagIdx        /* Sub Tag Index */;
      S16   curIdx;          /* temporary storage of current msg offset "cur" */
      Bool  nwkAppPres;      /* nwkAppPres */
      U8    nwkId;           /* Network Id */
      Dpc   dpc;             /* Destination Point Code */
      U32   trafMode;        /* Traffic handling mode */
      U32   routCtx;         /* Routing Context */
      U32   regSta;          /* Routing Key registration status */
      U32   deRegSta;        /* Routing Key de-registration status */
      S16   ret;             /* Return Value */
      Bool  errFlag;         /* To check if an error has been detected
                                while parsing the message */
      U16   errType;         /* Type of error reported in registration
                                response message */
      Bool lclRkFound;       /* Indicates that Local Rk Id has been extracted */
      Bool fstPrmtDecd;      /* First parameter decoded */


      ItRoutKey     rtKey;         /* Routing Key */
      U32           lclRkId;       /* Local RK ID */
      Bool          thmPres;       /* Indicates THM is present */
      Bool          dpcFound;      /* Indicates DPC is already found in RK */
      Bool          sioFound;      /* Indicates SIO is already found in RK */ 
      Bool          opcFound;      /* Indicates OPC is already found in RK */ 
      Bool          cicFound;      /* Indicates CIC is already found in RK */ 
      Bool          rctxFound;     /* Indicates RCTX is already found in RK */ 
      Bool          regStaFound;   /* Indicates REG STA is already found in 
                                      response */ 
      Bool          dregStaFound;  /* Indicates DE-REG STA is already found in 
                                      response */ 

      nwkId = 0;
      dpc = 0;
      trafMode = 0;
      routCtx = 0;
      regSta = 0;
      deRegSta = 0;
      lclRkId = 0;
      errType = 0;
      errFlag = FALSE;
      lclRkFound = FALSE;
      thmPres = FALSE;
      dpcFound = FALSE;
      sioFound = FALSE;      
      opcFound = FALSE;      
      cicFound = FALSE;      
      rctxFound = FALSE;     
      regStaFound = FALSE;   
      dregStaFound = FALSE;  
      
      /* memset */ 
      cmMemset((U8 *)&rtKey, 0, sizeof(ItRoutKey));

      /* Skip IT_M3UA_TAG_RK, IT_M3UA_TAG_REGRSLT, IT_M3UA_TAG_DREGRSLT */

      IT_MMH_EXAM_U16(*mBuf, tagId, cur, ret)
      IT_MMH_CHKLOG(*mBuf, ret, EIT313)
      IT_MMH_EXAM_U16(*mBuf, tagLen, cur, ret)
      IT_MMH_CHKLOG(*mBuf, ret, EIT314)

      tagLen = (U16)IT_MMH_LEN_UNADJ(tagLen);
      curIdx = (S16) cur;
      nwkAppPres = FALSE;
      fstPrmtDecd = FALSE;
      if (tagLen == 0)
      {
         for (tagIdx = 0; tagIdx < IT_M3UA_TAGARRAYSIZE; tagIdx++)
         {
            if ((tag[tagIdx].tag == tagId) && (tag[tagIdx].mand == TRUE))
            {
               /* Invalid tag/length */
               ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
               "Invalid M3UA parameter (msg = %04X tag = %02X len = %d)\n",
               msgType, tagId, IT_MMH_LEN_ADJ(tagLen)))
               RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR,
                                   mBuf, 0, (ItM3uaTag *) NULLP, 
                                   (ItRtCtx *) NULLP, 0, IT_M3UA_DFLT));
               break;
            }
         }
      }
      
      while ( cur <= (curIdx + tagLen - (MsgLen) sizeof(U32)))
      {
         U16 subTagId;       /* tag identifier of sub parameters */
         U16 subTagLen;      /* tag length of sub parameters */
         S16  subCurIdx;       /* temporary storage of current sub parameter 
                                tag offset */

         IT_MMH_EXAM_U16(*mBuf, subTagId, cur, ret)
         IT_MMH_CHKLOG(*mBuf, ret, EIT315)
         IT_MMH_EXAM_U16(*mBuf, subTagLen, cur, ret)
         IT_MMH_CHKLOG(*mBuf, ret, EIT316) 
      
         subTagLen = (U16)IT_MMH_LEN_UNADJ(subTagLen);
         subCurIdx = (S16) cur;

         if (subTagLen == 0)
         {
            for (subTagIdx = 0; subTagIdx < IT_M3UA_TAGARRAYSIZE; subTagIdx++)
            {
               if ((tag[subTagIdx].tag == tagId) && 
                   (tag[subTagIdx].mand == TRUE))
               {
                  /* Invalid tag/length */
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
                  "Invalid M3UA parameter (msg = %04X tag = %02X len = %d)\n",
                  msgType, tagId, IT_MMH_LEN_ADJ(subTagLen)))
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR,
                                      mBuf, 0, (ItM3uaTag *) NULLP, 
                                      (ItRtCtx *) NULLP, 0, IT_M3UA_DFLT));
                  break;
               }
            }
         } 
      
         switch (subTagId)                                             
         {                                                        
                                                                   
            case IT_M3UA_TAG_NWKAPP:                              
            {                                                     
               if (fstPrmtDecd == TRUE)
               {
                  if (lclRkFound == TRUE)
                  {
                     /* Network Appearance is not the first paramter in the
                      * routiing key */
                     
                     ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf, 
                            "itMmhProcRkm(): Network Appearance is not first"
                            " parameter in the routing key" 
                            " (msg = %04X len = %d) \n", msgType,
                            IT_MMH_LEN_ADJ(subTagLen)))
                     itMmhRegRsp(assocCb, (U8) IT_INV_RK, 0, lclRkId);
                     
                     /* Read next routing key */
                     cur = (S16)(curIdx + tagLen);
                     break;
                  }
                  else
                  {
                     errFlag = TRUE;
                     errType = IT_INV_RK;
                     /* Read next sub parameter */
                     cur = (S16)(subCurIdx + subTagLen);
                     break;
                  }
               }
               if (subTagLen == sizeof(U32))                         
               {                                                  
                  U32   nwkAppVal;  /* network appearance value */
                  U16   j;          /* loop index */              
                  ItPspId pspId;    /* PSP id */                  


                  IT_MMH_EXAM_U32(*mBuf, nwkAppVal, cur, ret)                  
                  IT_MMH_CHKLOG(*mBuf, ret, EIT317)                          
                  /* search nwkCbs for network appearance */                
                  pspId = assocCb->owner->pspCfg.pspId;                     
                                                                             
                  for (j = 0; (j < itGlobalCb.genCfg.maxNmbNwk) &&          
                     (nwkAppPres == FALSE); j++)                                  
                  {                                                         
                     if (itGlobalCb.nwk[j] != (ItNwkCb *)NULLP)             
                     {                                                      
                        if (itGlobalCb.nwk[j]->nwkCfg.nwkApp[pspId]         
                                                               == nwkAppVal)
                        {                                                   
                           nwkId          = (U8)j;                          
                           nwkAppPres     = TRUE;                           
                        }                                                   
                     }                                                      
                  }                                                         
              /* error should only be sent if network appearance is configured
                 for this PSP */
                  if ((nwkAppPres == FALSE) &&
                      (assocCb->owner->pspCfg.nwkAppIncl == TRUE))
                  {                                                             
                     errFlag = TRUE;
                     errType = IT_RK_INV_NWK_APP;
                  }
               }
               else                                                           
               {                                                            
                  /* Invalid network appearance length */                   
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,        
                         "itMmhProcRkm(): Invalid network appearance length "
                         "(msg = %04X len = %d)\n",                         
                         msgType, IT_MMH_LEN_ADJ(subTagLen)))                  
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR, 
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));       
               }                                                            
               break;                                                       
            }
         
            case IT_M3UA_TAG_SI:                                               
            {                                                                 

               /* if error has been detected already then 
                * skip all the parameters until local RK ID paramter is found */
               if (errFlag == TRUE)
               {
                  cur = (S16)(subCurIdx + subTagLen);
                  break;
               }
               if (sioFound == TRUE)
               {
                  if (lclRkFound == TRUE)
                  {
                     itMmhRegRsp(assocCb, (U8) IT_RK_UNSPP_PRMTR, 0, lclRkId);
                     /* read next routing key */
                     cur = (S16)(curIdx + tagLen); 
                     break;
                  }
                  else
                  {
                     errFlag = TRUE;
                     errType = IT_RK_UNSPP_PRMTR;
                     cur = (S16)(subCurIdx + subTagLen);
                     break;
                  }
               }
               sioFound = TRUE;
               rtKey.nmbSio = 0;                                              
               while ((cur - subCurIdx) <= (subTagLen - 
                                                     (MsgLen) sizeof(SrvInfo))) 
               {                                                              
                  if (rtKey.nmbSio >=  LIT_MAX_SIO_IN_DRKM)        
                  {                                                            
                     if (lclRkFound == TRUE)
                     {
                        /* Invalid number of SIO present in the message */    
                        ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,   
                               "itMmhProcRkm(): Invalid no of SIO present "  
                               "(msg = %04X len = %d)\n",                    
                               msgType, IT_MMH_LEN_ADJ(subTagLen)))          
                        itMmhRegRsp(assocCb, (U8) IT_INV_RK, 0, lclRkId);      
                        errFlag = TRUE;
                        /* Read next routing key */
                        cur = (S16)(curIdx + tagLen);
                        break;
                     }
                     else
                     {
                        errFlag = TRUE;
                        errType = IT_INV_RK;              
                        cur = (S16)(subCurIdx + subTagLen);
                        /* Skip padding bytes */
                        break;
                     }
                  }                                                            
                  IT_MMH_EXAM_U8(*mBuf, rtKey.sio[rtKey.nmbSio], cur, ret)     
                  IT_MMH_CHKLOG(*mBuf, ret, EIT318)                            
                  rtKey.nmbSio++;                                             
               }                                                              
                break;                                                        
            }                                                                 
            case IT_M3UA_TAG_OPC:                                          
            {                                                             
               U8 mask;
               /* if error has been detected already then 
                * skip all the parameters until local RK ID paramter is found */
               if (errFlag == TRUE)
               {
                  cur = (S16)(subCurIdx + subTagLen);
                  break;
               }
               if (opcFound == TRUE)
               {
                  if (lclRkFound == TRUE)
                  {
                     itMmhRegRsp(assocCb, (U8) IT_RK_UNSPP_PRMTR, 0, lclRkId);
                     /* read next routing key */
                     cur = (S16)(curIdx + tagLen); 
                     break;
                  }
                  else
                  {
                     errFlag = TRUE;
                     errType = IT_RK_UNSPP_PRMTR;
                     cur = (S16)(subCurIdx + subTagLen);
                     break;
                  }
               }
               opcFound = TRUE;
               rtKey.nmbOpc = 0;                                          
               while ((cur - subCurIdx) <= (subTagLen - (MsgLen) sizeof(Dpc))) 
               {                                                          
                  if (rtKey.nmbOpc >=  LIT_MAX_OPC_IN_DRKM)        
                  {                                                            
                     if (lclRkFound == TRUE)
                     {
                        /* Invalid number of OPC present in the message */    
                        ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,   
                               "itMmhProcRkm(): Invalid no of OPC present "  
                               "(msg = %04X len = %d)\n",                    
                               msgType, IT_MMH_LEN_ADJ(subTagLen)))          
                        itMmhRegRsp(assocCb, (U8) IT_INV_RK, 0, lclRkId);       
                        errFlag = TRUE;
                        /* Read next routing key */
                        cur = (S16)(curIdx + tagLen);
                        break;
                     }                                                  
                     else
                     {
                        errFlag = TRUE;
                        errType = IT_INV_RK;              
                        cur     = (S16)(subCurIdx + subTagLen);
                        break;
                     }
                  } 
                  if (nwkAppPres == FALSE)
                  {
                    /* default network ID from PSP config */
                    nwkId = assocCb->owner->pspCfg.nwkId;
                  }

                  IT_MMH_EXAM_U8(*mBuf, mask, cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT319)
                  if (mask != 0)
                  {
                     if (lclRkFound == TRUE)
                     {
                        /* Invalid dpcMask value */                   
                        ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,   
                         "itMmhProcRkm(): Invalid opc mask value "
                         "(msg = %04X mask = %d)\n", msgType, mask))  

                        itMmhRegRsp(assocCb, (U8) IT_INV_RK, 0, lclRkId);   
                        /* Read next routing key */
                        cur = (S16)(curIdx + tagLen);
                        break;
                     }                                                  
                     else
                     {
                        errFlag = TRUE;
                        errType = IT_INV_RK;              
                        cur = (S16)(subCurIdx + subTagLen);
                        break;
                     }
                  }
                  IT_MMH_EXAM_DPC(*mBuf, rtKey.opc[rtKey.nmbOpc], 
                                 itGlobalCb.nwk[nwkId]->nwkCfg.dpcLen,cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT320)
                  rtKey.nmbOpc++;                                         
               }                                                          
               break;                                                     
            }                                                             
            case IT_M3UA_TAG_DPC:
            {
               U8 mask;
               /* if error has been detected already then 
                * skip all the parameters until local RK ID paramter is found */
               if (errFlag == TRUE)
               {

                  cur = (S16)(subCurIdx + subTagLen);

                  break;
               }
               if (dpcFound == TRUE)
               {
                  if (lclRkFound == TRUE)
                  {
                     itMmhRegRsp(assocCb, (U8) IT_RK_UNSPP_PRMTR, 0, lclRkId);
                     /* read next routing key */
                     cur = (S16)(curIdx + tagLen); 
                     break;
                  }
                  else
                  {
                     errFlag = TRUE;
                     errType = IT_RK_UNSPP_PRMTR;
                     cur = (S16)(subCurIdx + subTagLen);
                     break;
                  }
               }
               dpcFound = TRUE;
                     
               if (subTagLen == sizeof(U32))  
               {
                  
                  if (nwkAppPres == FALSE)
                  {
                    /* default network ID from PSP config */
                    nwkId = assocCb->owner->pspCfg.nwkId;
                  }

                  IT_MMH_EXAM_U8(*mBuf, mask, cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT321)
                  if (mask != 0)
                  {
                     if (lclRkFound == TRUE)
                     {
                        /* Invalid dpcMask value */                   
                        ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,   
                         "itMmhProcRkm(): Invalid dpc mask value "
                         "(msg = %04X mask = %d)\n", msgType, mask))  

                        itMmhRegRsp(assocCb, (U8) IT_RK_INV_DPC, 0, lclRkId);   
                        errFlag = TRUE;
                        /* Read next routing key */
                        cur = (S16)(curIdx + tagLen);
                        break;
                     }                                                  
                     else
                     {
                        errFlag = TRUE;
                        errType = IT_RK_INV_DPC;              
                        cur = (S16)(subCurIdx + subTagLen);
                        break;
                     }
                  }
                  IT_MMH_EXAM_DPC(*mBuf, dpc, 
                                 itGlobalCb.nwk[nwkId]->nwkCfg.dpcLen,cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT322)
                  rtKey.dpc = dpc;

               }
               else                                                           
               {                                                            
                  /* Invalid dpc length */                   
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,        
                         "itMmhProcRkm(): Invalid dpc length "
                         "(msg = %04X len = %d)\n",                         
                         msgType, IT_MMH_LEN_ADJ(subTagLen)))                  
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR, 
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));       
               }                                                            
               break;
            }
            case IT_M3UA_TAG_CICRNG: 
            {                       
               U8 mask;             
               rtKey.nmbCic = 0;      

               /* if error has been detected already then 
                * skip all the parameters until local RK ID paramter is found */
               if (errFlag == TRUE)
               {
                  cur = (S16)(subCurIdx + subTagLen);
                  break;
               }

               if (cicFound == TRUE)
               {
                  if (lclRkFound == TRUE)
                  {
                     itMmhRegRsp(assocCb, (U8) IT_RK_UNSPP_PRMTR, 0, lclRkId);
                     /* read next routing key */
                     cur = (S16)(curIdx + tagLen); 
                     break;
                  }
                  else
                  {
                     errFlag = TRUE;
                     errType = IT_RK_UNSPP_PRMTR;
                     cur = (S16)(subCurIdx + subTagLen);
                     break;
                  }
               }
               cicFound = TRUE;
               if (nwkAppPres == FALSE)
               {
                 /* default network ID from PSP config */
                 nwkId = assocCb->owner->pspCfg.nwkId;
               }
               while ((cur - subCurIdx) <= (subTagLen - (MsgLen) (sizeof(Dpc) +  
                     2 * sizeof(Cic)))) 
               {
                  if (rtKey.nmbCic >=  LIT_MAX_CIC_IN_DRKM)        
                  {                                                            
                     if (lclRkFound == TRUE)
                     {
                        /* Invalid number of OPC present in the message */    
                        ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,   
                               "itMmhProcRkm(): Invalid no of OPC present "  
                               "(msg = %04X len = %d)\n",                    
                               msgType, IT_MMH_LEN_ADJ(subTagLen)))          
                        itMmhRegRsp(assocCb, (U8) IT_INV_RK, 0, lclRkId);       
                        errFlag = TRUE;
                        /* Read next routing key */
                        cur = (S16)(curIdx + tagLen);
                        break;
                     }                                                  
                     else
                     {
                        errFlag = TRUE;
                        errType = IT_INV_RK;              
                        cur = (S16)(subCurIdx + subTagLen);
                        break;
                     }
                  }                   
                  IT_MMH_EXAM_U8(*mBuf, mask, cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT323)
                  IT_MMH_EXAM_DPC(*mBuf, rtKey.cicRange[rtKey.nmbCic].opc,
                            itGlobalCb.nwk[nwkId]->nwkCfg.dpcLen, cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT324)
                  IT_MMH_EXAM_U16(*mBuf, rtKey.cicRange[rtKey.nmbCic].cicStart,
                               cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT325)
                  IT_MMH_EXAM_U16(*mBuf, rtKey.cicRange[rtKey.nmbCic].cicEnd, 
                               cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT326)
                  rtKey.nmbCic++;
               }
               break;
            }
            case IT_M3UA_TAG_LCLRKID:                                   
            {                                                          
               if (lclRkFound == TRUE)
               {
                  /* Invalid routing Context Parameter */                   
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,        
                         "itMmhProcRkm(): Repeated Local RKID parameter "
                         "(msg = %04X len = %d)\n",                         
                         msgType, IT_MMH_LEN_ADJ(subTagLen)))                  
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PROTO_ERR, 
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));       
               }
               if (subTagLen == sizeof(U32))                              
               {                                                       
                  IT_MMH_EXAM_U32(*mBuf, lclRkId, cur, ret)             
                  IT_MMH_CHKLOG(*mBuf, ret, EIT327)                     
                  lclRkFound = TRUE;
               }                                                       
               else                                                    
               {                                                       
                  /* Invalid local-RK-ID length */                     
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,   
                         "itMmhProcRkm(): Invalid Local RK ID length "  
                         "(msg = %04X len = %d)\n",                    
                         msgType, IT_MMH_LEN_ADJ(subTagLen)))             
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR,
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));  
               }                                                       
               if ( errFlag == TRUE)
               {
                  itMmhRegRsp(assocCb, (U8) errType, 0, lclRkId);  
                  /* Read next routing key */                   
                  cur = (S16)(curIdx + tagLen);                        
                  break;                                                  
               }
               break;
            }                                                          
            case IT_M3UA_TAG_TRAFMODE:
            {
               if (thmPres == TRUE)
               {
                  if (lclRkFound == TRUE)
                  {
                     itMmhRegRsp(assocCb, (U8) IT_RK_UNSPP_PRMTR, 0, lclRkId);
                     /* read next routing key */
                     cur = (S16)(curIdx + tagLen); 
                     break;
                  }
                  else
                  {
                     errFlag = TRUE;
                     errType = IT_RK_UNSPP_PRMTR;
                     cur = (S16)(subCurIdx + subTagLen);
                     break;
                  }
               }
               thmPres = TRUE;
               if (subTagLen == sizeof(U32))
               {
                  IT_MMH_EXAM_U32(*mBuf, trafMode, cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT328)

                  switch (trafMode)
                  {
                     /* the following 4 cases fall through */
                     case IT_M3UA_THM_OVERRIDE:
                     case IT_M3UA_THM_LOADSHARE:
                        break;
                     default:
                     {
                        if (lclRkFound == TRUE)
                        {
                           ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf, 
                                  "itMmhProcRkm(): Invalid THM "  
                                  "(msg = %04X len = %d)\n",                    
                                  msgType, IT_MMH_LEN_ADJ(subTagLen)))          
                           itMmhRegRsp(assocCb, (U8) IT_RK_UNSPP_THM, 0, 
                                                                   lclRkId);  
                           errFlag = TRUE;
                           /* Read next routing key */
                           cur = (S16)(curIdx + tagLen);
                           break;
                        }                                                  
                        else                                    
                        {                                       
                           errFlag = TRUE;                      
                           errType = IT_RK_UNSPP_THM;              
                           break;                               
                        }                                       
                     }/* end default */
                  }/* end Switch */
               }
               else
               {
                  /* Invalid traffic mode length */
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
                  "itMmhProcRkm(): Invalid traffic mode length"
                  "(msg = %04X len = %d)\n",
                     msgType, IT_MMH_LEN_ADJ(subTagLen)))
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR,
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));
               }
               break;
            }
            case IT_M3UA_TAG_RCTX:
            {
               if (rctxFound == TRUE)
               {
                  /* Invalid routing Context Parameter */                   
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,        
                         "itMmhProcRkm(): Repeated routing context parameter "
                         "(msg = %04X len = %d)\n",                         
                         msgType, IT_MMH_LEN_ADJ(subTagLen)))                  
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PROTO_ERR, 
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));       
               }
               rctxFound = TRUE;
               if (subTagLen == sizeof(U32))  
               {
                  
                  IT_MMH_EXAM_U32(*mBuf, routCtx, cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT329)
               }
               else                                                           
               {                                                            
                  /* Invalid routing Context Parameter */                   
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,        
                         "itMmhProcRkm(): Invalid routing context parameter "
                         "(msg = %04X len = %d)\n",                         
                         msgType, IT_MMH_LEN_ADJ(subTagLen)))                  
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR, 
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));       
               }                                                            
               break;
            }
            case IT_M3UA_TAG_REGSTA:
            {
               if (regStaFound == TRUE)
               {
                  /* Invalid routing Context Parameter */                   
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,        
                         "itMmhProcRkm(): Repeated registration status parameter "
                         "(msg = %04X len = %d)\n",                         
                         msgType, IT_MMH_LEN_ADJ(subTagLen)))                  
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PROTO_ERR, 
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));       
               }
               regStaFound = TRUE;
               if (subTagLen == sizeof(U32))  
               {
                  
                  IT_MMH_EXAM_U32(*mBuf, regSta, cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT330)

                  switch (regSta)
                  {
                     case IT_RK_SUCC_REGD:
                     case IT_RK_UNKNOWN:
                     case IT_RK_INV_DPC:
                     case IT_RK_INV_NWK_APP:
                     case IT_INV_RK:
                     case IT_PERM_DENIED:
                     case IT_CANT_SUPP_UNIQ_RK:
                     case IT_RK_NOT_PROVISION:
                     case IT_RK_INSUF_RSRCS:
                     case IT_RK_UNSPP_PRMTR:
                     case IT_RK_UNSPP_THM:
                        break;  
                     default:
                        ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
                        "itMmhProcRkm(): Invalid RK Registration Status type"
                        "(msg = %04X type = %04X)\n",
                           msgType, (S16)regSta))
                        RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_INV_PARMVAL,
                                            mBuf, regSta, (ItM3uaTag *) NULLP, 
                                            (ItRtCtx *) NULLP, 0, 
                                            IT_M3UA_DFLT));
                  }
               }
               else                                                           
               {                                                            
                  /* Invalid Registration Status Parameter */                   
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,        
                        "itMmhProcRkm(): Invalid registration status parameter "
                         "(msg = %04X len = %d)\n",                         
                         msgType, IT_MMH_LEN_ADJ(subTagLen)))                  
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR, 
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));       
               }                                                            
               break;
            }
            case IT_M3UA_TAG_DREGSTA:
            {
               if (dregStaFound == TRUE)
               {
                  /* Invalid routing Context Parameter */                   
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,        
                         "itMmhProcRkm(): Repeated deregistration status parameter "
                         "(msg = %04X len = %d)\n",                         
                         msgType, IT_MMH_LEN_ADJ(subTagLen)))                  
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PROTO_ERR, 
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));       
               }
               dregStaFound = TRUE;
               if (subTagLen == sizeof(U32))  
               {
                  
                  IT_MMH_EXAM_U32(*mBuf, deRegSta, cur, ret)
                  IT_MMH_CHKLOG(*mBuf, ret, EIT331)

                  switch (deRegSta)
                  {
                     case IT_RK_UNKNOWN:
                     case IT_INV_RC:
                     case IT_RC_PERM_DENIED:
                     case IT_RC_NOT_REGD:
                     case IT_RC_CURR_ACTIVE:
                     case IT_RC_SUCC_DREGD:
                        break;
                     default:
                        ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,
                        "itMmhProcRkm(): Invalid RK De-Registration Status type"
                        "(msg = %04X type = %04X)\n",
                           msgType, (S16)deRegSta))
                        RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_INV_PARMVAL,
                                            mBuf, deRegSta,
                                            (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));        
                  }
               }
               else                                                           
               {                                                            
                  /* Invalid De - Registration Status Parameter */                   
                  ITDBGP(IT_DBGMASK_MMH, (itGlobalCb.itInit.prntBuf,        
                  "itMmhProcRkm(): Invalid De - registration status parameter "
                   "(msg = %04X len = %d)\n",                         
                     msgType, IT_MMH_LEN_ADJ(subTagLen)))                  
                  RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_PARAM_FIELD_ERROR, 
                                      mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));       
               }                                                            
               break;
            }
            default:
               /* other cases: do nothing */
               break;
         } /* End Switch Statement */

         /* skip the padding */
         cur = (S16) (cur + (sizeof(U32) - 
                                (subTagLen % sizeof(U32))) % sizeof(U32));

         fstPrmtDecd = TRUE;
      } /* end inner while */


      switch (msgType)
      {
         case IT_RKM_REGREQ:
         {
            if (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_SGP)
            {
               /* message not expected from SGP*/
               RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNEXP_MSG,
                             mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      NULLP, 0, IT_M3UA_DFLT));
            }
            /* Check PSP is allowed to send the RKM msg */
            if (assocCb->owner->pspCfg.dynRegRkallwd != TRUE)
            {
               /* Send response with permission denied */ 
               itMmhRegRsp(assocCb, (U8) IT_PERM_DENIED, 0, lclRkId);
               RETVALUE(RFAILED);
            }

            if (thmPres == FALSE)
            {
               trafMode = IT_M3UA_DFLT;
            }
            if ( errFlag != TRUE )
            {
               itAtRegReq(assocCb, &rtKey, nwkId, lclRkId, trafMode);
            }
            break;
         }
#ifdef ITASP
         case IT_RKM_REGRSP:
         {
            ItRtCtx   rCtx[LIT_MAX_PSID];    /* Routing Context List*/
            U16       rCtxLen;               /* Routing Context List Length */
            
            rCtx[0].rtCtx = routCtx;
            rCtxLen = 0;
            if (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_ASP)
            {
               /* message not expected from ASP */
               RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNEXP_MSG,
                             mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      rCtx, rCtxLen, IT_M3UA_DFLT));
            } 
            if (itAtRegRsp(assocCb, lclRkId, regSta, routCtx) != ROK)
            {
               RETVALUE(RFAILED);
            }
            break;
         }
            
         case IT_RKM_DREGRSP:
         {
            ItRtCtx   rCtx[LIT_MAX_PSID];    /* Routing Context List*/
            U16       rCtxLen;               /* Routing Context List Length */
            
            rCtx[0].rtCtx = routCtx;
            rCtxLen = 0;

            if (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_ASP)
            {
               /* message not expected from ASP */
               RETVALUE(itMmhError(assocCb, IT_M3UA_ERROR_UNEXP_MSG,
                             mBuf, 0, (ItM3uaTag *) NULLP, (ItRtCtx *)
                                      rCtx, rCtxLen, IT_M3UA_DFLT));
            } 
            if (itAtDeRegRsp(assocCb, deRegSta, routCtx) != ROK)
            {
               RETVALUE(RFAILED);
            }
            break;
         }
#endif /*  ITASP */
      } /* end switch msgType */
   } /* end outer while */

   switch(msgType)
   {
      case IT_RKM_REGREQ:
        IT_STS_INC_M3UA_RX(assocCb, regReq);
        break;
      case IT_RKM_REGRSP: 
        IT_STS_INC_M3UA_RX(assocCb, regRsp);
        break;
      case IT_RKM_DREGRSP:
        IT_STS_INC_M3UA_RX(assocCb, deRegRsp);
        break;
      default:
        break;
   }
   
   IT_DROPDATA(*mBuf);

   RETVALUE(ROK);
} /* end itMmhProcRkm */

#ifdef  ITASP

/*
*
*       Fun:   itMmhErrorDpcUnkwn
*
*       Desc:  This Function sends the status indication message to layer 
*              manager on reception of error msg with error code as 
*              "DPC status Unknown". This function also stops any daud
*              timer running for the dpc for which this error message
*              is received.
*
*       Ret:  ROK     -     Ok 
*              
*             RFAILED - Failed 
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhErrorDpcUnkwn
(
ItAssocCb     *assocCb, /* association CB */
ItM3uaTag     *tag,     /* Parameter State Array */
Buffer        **mBuf,   /* pointer to message */
MsgLen        cur       /* current message offset */
)
#else
PUBLIC S16 itMmhErrorDpcUnkwn (assocCb, tag, mBuf, cur)
ItAssocCb     *assocCb; /* association CB */
ItM3uaTag     *tag;     /* Parameter State Array */
Buffer        **mBuf;   /* pointer to message */
MsgLen        cur;      /* current message offset */
#endif
{
   S16       ret;         /* return value */
   U8        mask;            /* Network Mask */
   Dpc       apc;           /* DPC value */
   ItDpcCb   *dpcCb;        /* DPC control Block */
   U8        nwkId;         /* Network Id */
   Dpc       dpcMask;       /* DPC Mask */

   TRC2(itMmhErrorDpcUnkwn)

   dpcCb = (ItDpcCb *)NULLP;

   if (tag[IT_M3UA_TAG_IDX_NWKAPP].valid == TRUE)                 
   {                                                              
      nwkId = tag[IT_M3UA_TAG_IDX_NWKAPP].u.nwkId;                
   }                                                              
   else                                                           
   {                                                              
      /*  default network ID from PSP config */                   
      nwkId = assocCb->owner->pspCfg.nwkId;                       
   }                                                              

   itGlobalCb.mgmt.t.usta.alarm.cause =  LIT_CAUSE_DPC_STATUS_UNKNOWN;
   itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc = NULLD;                   

   if (tag[IT_M3UA_TAG_IDX_ADPC].pres == TRUE)                   
   {                                                             
      cur = tag[IT_M3UA_TAG_IDX_ADPC].offset;                    
      while ((cur - (MsgLen) tag[IT_M3UA_TAG_IDX_ADPC].offset) <=
                             (tag[IT_M3UA_TAG_IDX_ADPC].length -        
                             (MsgLen) sizeof(U32)))                     
      {                                                          
         IT_MMH_EXAM_U8(*mBuf, mask, cur, ret)                    
         IT_MMH_CHKLOG(*mBuf, ret, EIT332)                        
         IT_MMH_EXAM_DPC(*mBuf, apc,                              
                         itGlobalCb.nwk[nwkId]->nwkCfg.dpcLen,          
                         cur, ret)                                      
         IT_MMH_CHKLOG(*mBuf, ret, EIT333)                        
         dpcMask  = (Dpc) MAX32BIT << mask;
         /* DAUD timer for the APC should also be stopped */     
         while (itAtGetDpcs(nwkId, apc, dpcMask, &dpcCb) == ROK)      
         {                                                       
            itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc = dpcCb->dpc;              
            (Void) itMiStaIndM(&itGlobalCb.mgmt);                   

            if (IT_TMRACTIVE(&dpcCb->tmrDaud) == TRUE)           
            {                                                    
                  itTcStopTimer(&dpcCb->tmrDaud);                    
            }                                                    
         }                                                       
      }                                                          
   }                                                             
   else                                                          
   {                                                             
      (Void) itMiStaIndM(&itGlobalCb.mgmt);                      
   }
   RETVALUE(ROK);
} /* end itMmhErrorDpcUnkwn */ 
#endif /* ITASP */


/*
*
*       Fun:   itMmhVerifyAspId
*
*       Desc: This function verifies the value of ASP Id parameter received
*             in the ASPUP message 
*
*       Ret:  ROK     -     Ok 
*              
*             RFAILED - Failed 
*
*       Notes: <none>
*
*       File:  it_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 itMmhVerifyAspId
(
ItAssocCb     *assocCb, /* association CB */
U32            aspId    /* ASP ID */
)
#else
PUBLIC S16  itMmhVerifyAspId(assocCb, aspId)
ItAssocCb     *assocCb; /* association CB */
U32            aspId;    /* ASP ID */
#endif
{
   U8             i;       /* loop counter */
   ItPspId        pspId;   /* PSP Id */
   
   TRC2(itMmhVerifyAspId)

   pspId = assocCb->owner->pspCfg.pspId;
   for (i = 1; i < LIT_MAX_PSP; i++)
   {
      if ((pspId != i) && (itGlobalCb.aspIdCb.aspIdValid[i] == TRUE)
           && (itGlobalCb.aspIdCb.aspIdLst[i] == aspId))
      {
         RETVALUE(RFAILED);
      }
   } /* End for */
   RETVALUE(ROK);
} /* End itMmhVerifyAspId */

#ifdef IT_RUG
/*
 *
 *      Fun:   Get Interface Version Handling
 *
 *      Desc:  Processes system agent control request primitive
 *             to get interface version for all interface implemented
 *             by the protocol.
 *
 *      Ret:   ROK   - ok
 *
 *      Notes: None
 *
 *      File:  it_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 itGetVer
(
ShtGetVerCfm *getVerCfmInfo   /* to return interface version information */
)
#else
PUBLIC S16 itGetVer(getVerCfmInfo)
ShtGetVerCfm *getVerCfmInfo;  /* to return interface version information */
#endif
{
   TRC3 (itGetVer)

   /* Insure Testing */
   IT_ZERO(getVerCfmInfo, sizeof(ShtGetVerCfm))
   /* Insure Testing */

   /* Fill the upper interface IDs and their ver number */
   getVerCfmInfo->numUif = 1;
   getVerCfmInfo->uifList[0].intfId = SNTIF;
   getVerCfmInfo->uifList[0].intfVer = SNTIFVER;

   /* Fill the lower interface IDs and their ver number */
   getVerCfmInfo->numLif = 1;
   getVerCfmInfo->lifList[0].intfId = SCTIF;
   getVerCfmInfo->lifList[0].intfVer = SCTIFVER;

   /* it001.106 - For SG it should put SNT as the lower Interface */
#ifdef ITSG
   if (itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP)
   {
      getVerCfmInfo->numLif = 2;
      getVerCfmInfo->lifList[1].intfId = SNTIF;
      getVerCfmInfo->lifList[1].intfVer = SNTIFVER;
   }
#endif /* ITSG */

   /* it001.106 - Get the Peer Interface information from PSF */
#ifdef ZV
   zvGetVer(&getVerCfmInfo->pif);
#endif

   RETVALUE(ROK);
} /* End of itGetVer */

/*
 *
 *      Fun:   Set Interface Version Handling
 *
 *      Desc:  Processes system agent control request primitive
 *             to set interface version.
 *
 *      Ret:   ROK   - ok
 *
 *      Notes: None
 *
 *      File:  it_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC Void itSetVer
(
ShtVerInfo *setVerInfo,        /* version information to set */
CmStatus   *status             /* status to return */
)
#else
PUBLIC Void itSetVer(setVerInfo, status)
ShtVerInfo *setVerInfo;        /* version information to set */
CmStatus   *status;            /* status to return */
#endif
{
   Bool       found;     /* Flag to indicate if found in the stored structure */
   ShtVerInfo *intfInf;  /* interface version info */
   ItNSapCb   *nSapCb;   /* upper SAP control block */
   ItSctSapCb *sctSapCb; /* lower SAP control block */
   U16        i;         /* index */

   TRC2(itSetVer)
#ifdef ZV
   /* See if this is applicable to PSF       *
    * If PSF says it is not applicable (RNA) *
    * we analyze further                     */

   if (zvSetVer(&setVerInfo->intf, status) != RNA)
      RETVOID;
#endif




   found = FALSE;
   /* Validate Set Version Information */
   switch(setVerInfo->intf.intfId)
   {
      case SNTIF:
         if (setVerInfo->intf.intfVer > SNTIFVER)
            status->reason = LCM_REASON_VERSION_MISMATCH;
         break;

      case SCTIF:
         if (setVerInfo->intf.intfVer > SCTIFVER)
            status->reason = LCM_REASON_VERSION_MISMATCH;
         break;

      default:
         status->reason = LCM_REASON_INVALID_PAR_VAL;
   }
   if (status->reason != LCM_REASON_NOT_APPL )
      RETVOID;

   /* validate grptype */
   if ((setVerInfo->grpType != SHT_GRPTYPE_ALL) &&
       (setVerInfo->grpType != SHT_GRPTYPE_ENT))
   {
      status->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVOID;
   }

   /* See if stored information already exists */
   for(i = 0; i < itGlobalCb.numIntfInfo && found == FALSE; i++)
   {
      intfInf = &itGlobalCb.intfInfo[i];
      if (intfInf->intf.intfId == setVerInfo->intf.intfId)
      {
         if (intfInf->grpType == setVerInfo->grpType)
         {
            /* Stored information found. Replace the information with new *
             * version information specified in this set version request  */
            switch(setVerInfo->grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if (intfInf->dstProcId == setVerInfo->dstProcId &&
                      intfInf->dstEnt.ent == setVerInfo->dstEnt.ent &&
                      intfInf->dstEnt.inst == setVerInfo->dstEnt.inst)
                  {
                     intfInf->intf.intfVer = setVerInfo->intf.intfVer;
                     found = TRUE;
                  }
                  break;

               case SHT_GRPTYPE_ENT:
                  if (intfInf->dstEnt.ent == setVerInfo->dstEnt.ent &&
                      intfInf->dstEnt.inst == setVerInfo->dstEnt.inst )
                  {
                     intfInf->intf.intfVer = setVerInfo->intf.intfVer;
                     found = TRUE;
                  }
                  break;
            }
         }
      }
   }

   /* In the worst case we should be required to store one version *
    * information for every configured sap in the layer.           */
   if (found == FALSE)
   {
      if (itGlobalCb.numIntfInfo <
             (itGlobalCb.genCfg.maxNmbNSap + itGlobalCb.genCfg.maxNmbSctSap))
      {
         cmMemcpy ((U8 *)&itGlobalCb.intfInfo[i], (U8 *)setVerInfo,
                                                  sizeof(ShtVerInfo));
         itGlobalCb.numIntfInfo++;
      }
      else
      {
         status->reason = LCM_REASON_EXCEED_CONF_VAL;
         RETVOID;
      }
   }

   /* Information in set version stored. Now update the SAPs */
   switch (setVerInfo->intf.intfId)
   {
      case SNTIF:
         for (i = 0; i < itGlobalCb.genCfg.maxNmbNSap; i++)
         {
            if ((nSapCb = itGlobalCb.nSap[i]) == NULLP)
              continue;

             /* If it is an unbound SAP then the remote entity, instance
              * and proc ID would not be available and hence we should
              * wait for bind to happen to set the remote interface ver
              */
            if (nSapCb->sntSta.hlSt != LIT_SAP_BOUND)
               continue;
#ifdef DI
            if(nSapCb->pst.dstEnt == ENTSI)
            {
               U8       grp;
               ProcId   procId;
               U8       bndStatus;

               /* If instance not bound to SAP yet then no action on this SAP */
               if(DiDitGetUpSapState(&grp, &procId, setVerInfo->dstEnt.inst,
                                    nSapCb->sntCfg.sapId, &bndStatus) != ROK)
                  continue;
               /* If SAP is in unound state then no action is taken ,the stored*
                * interface version information is used when bind request is   *
                * sent by the service user ISUP having this instance           */

               if(bndStatus != DIT_BND)
                  continue;
               /* Update version information in SAP and continue further       */
               DiDitSetUpIntfVer(setVerInfo->dstEnt.inst, nSapCb->sntCfg.sapId,
                                 setVerInfo->intf.intfVer);
               continue;
            }
#endif  /* DI */


            /* now match on dstproc/ent/inst */
            found = FALSE;
            switch(setVerInfo->grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if (nSapCb->pst.dstProcId == setVerInfo->dstProcId &&
                      nSapCb->pst.dstEnt == setVerInfo->dstEnt.ent &&
                      nSapCb->pst.dstInst == setVerInfo->dstEnt.inst)
                  {
                     found = TRUE;
                  }
                  break;
               case SHT_GRPTYPE_ENT:
                  if (nSapCb->pst.dstEnt == setVerInfo->dstEnt.ent &&
                      nSapCb->pst.dstInst == setVerInfo->dstEnt.inst)
                  {
                     found = TRUE;
                  }
                  break;
               default:
                  /* not possible */
                  break;
            }
            if (found == TRUE)
            {
               nSapCb->pst.intfVer = setVerInfo->intf.intfVer;
               nSapCb->remIntfValid = TRUE;
            }
         }
         break;

      case SCTIF:
        for (i = 0; i < itGlobalCb.genCfg.maxNmbSctSap; i++)
         {
            if ((sctSapCb = itGlobalCb.sctSap[i]) == NULLP)
               continue;

            /* now match on dstproc/ent/inst */
            found = FALSE;
            switch(setVerInfo->grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if (sctSapCb->pst.dstProcId == setVerInfo->dstProcId &&
                      sctSapCb->pst.dstEnt == setVerInfo->dstEnt.ent &&
                      sctSapCb->pst.dstInst == setVerInfo->dstEnt.inst)
                     found = TRUE;
                  break;

               case SHT_GRPTYPE_ENT:
                  if (sctSapCb->pst.dstEnt == setVerInfo->dstEnt.ent &&
                      sctSapCb->pst.dstInst == setVerInfo->dstEnt.inst)
                     found = TRUE;
                  break;

               default:
                  /* not possible */
                  break;
            }
            if (found == TRUE)
            {
               sctSapCb->pst.intfVer = setVerInfo->intf.intfVer;
               sctSapCb->remIntfValid = TRUE;
            }
         }
         break;
   }

   RETVOID;
} /* End of itSetVer */
#endif /* IT_RUG */


/********************************************************************30**

  End of file:     it_bdy2.c@@/main/7 - Thu Apr  1 03:51:22 2004

**********************************************************************31*/
/*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

  Revision history:

*********************************************************************61*/
/********************************************************************70**

    version    initials                   description
  -----------  ---------  ------------------------------------------------

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/3      ---     mrw  1. initial skeleton draft.
/main/3      ---     nt   1. Changes for TCR18,
                             the controlling entity is added at
                             the time of configuring Upper SAP.
                          2. Changes for removing warnings.
                          3. Check added for nwkCb not equal to NULLP.
                          4. Linking error removed for SG without NIF
                             compilation.
                          5. Updated to Release 1.2
/main/4      ---     sg   1. Routing, IPSP and Loadshare changes.
             ---     sg   2. Update to Release 1.3
/main/5      ---     sg   1. Update to Release 1.4
/main/5    it001.104 sg   1. Changed functions itMifStaSet and itMifDpcEvt 
                             to support DPC Mask received in first 8 bits 
                             of aPc in StaApyReq/StaQryRsp from NIF at SGP.
                          2. Changes for Outgoing Message Routing based on
                             Local PS status at ASP/IPSP.
/main/5    it002.104 sg   1. Changes for SG view for DPC status at ASP. 
                          2. All Patches of ver 1.3 propagated.
/main/5    it006.104 an   1. Inclusion of affected DPC in message 
                             transfered to LM. 
                          2. Optimisation of part of code for Huge 
                             configuration.
            it007.104 cg  1. In itMifStaTimeout check for dpcCb 
                              and NSapCb not to be NULL
                          2. In itMifDaudTimeout check for dpcCb
                             not to be NULL
           it008.104  an  1. Accept the message If NA is not configured 
                             for a PSP and in DATA message NA is present. 
/main/5    it011.104  sg  1. Added Case for Extracting Cic from TUP msg. 
/main/5    it012.104  sg  1. Added handling for China TUP.
/main/5    it013.104  vt  1. large configuration handling  
/main/5    it014.104  vt  1. preprocessor directive changed from 
                             ifndef ITSG to ifdef ITASP
/main/5    it016.104  vt  1. initialize statistics
                          2. filter out messages loop backed to SGP
                          3. changes for M3UA stuck in infinite loop
                          4. check added for preventing SIG fault in 
                          5. Changes to put RC parameter before DATA
/main/5    it018.104  vt  1. SIO filter removed
/main/5    it019.104  vt  1. Changes related to Same RC on LPS & RPS
                          2. Changes related to double de-allocation
                             of mbuf.
/main/5    it021.104  vt  1. Changes done for messages types and classes
                             received from a PSP in Down state. 
/main/5    it022.104  uv  1. Added alarms for routes
/main/6      ---      nt   1. Update to Release 1.5
/main/7      ---      rs   1. Update to Release 1.6.
/main/7    it001.106  nt   1. Assoc Id calculation corrected at few places.
                      sg   2. In itGetVer(), added SNT as lower interface 
                              for SG and called zvGetVer for peer interface.
                           3. Changed ItMifSsnm() when DPC learning disabled, 
                              to call itMifPspEvt and itLscSlsDpcEvt only 
                              for matching DPCs.
/main/7    it005.106  sg   1. Added debug print in itMupGetUserInfo() for 
                              unused su2Swtch.
/main/7    it012.106  jc   1. Added support for SS_MULTIPLE_PROCS 
/main/7    it013.106  sg   1. remSapId used in call to ItUiSntStaInd. 
                           2. Change in itMifStaSet function to send SCON with 
                              congestion level SN_PRI0, when SN_RESUME is 
                              received in SntStaQryRsp from MTP3 for a 
                              non-existing fully specified DPC in a National 
                              network.
                           3. Changes in itMifPspEvt to check DPC nwkId for 
                              event IT_MIF_ASP_INACTIVE.
/main/7    it014.106  sg   1. Changes in itMifStaSet and itMifDpcEvt to 
                              forward the SN_RSTBEG/SN_RSTEND received from 
                              MTP3 at SGP to all the local user NSAPs of the 
                              restarting network. 
/main/7    it015.106  sg   1. Verification on MsgLen and tagLen parameters
                              added
/main/7    it016.106  sg   1. Changes for new association congestion and
                              unavailability statistics.
                           2. Changes to make storing of ASPID optional
                              when rxTxAspId is FALSE. So, even if rxTxAspId 
                              is FALSE send ASPID(if available) in Notify.
/main/7    it017.106  sg   1. Changes to fix the function names in some debug
                              prints.
/main/7    it018.106  sb   1. M3UA DFTHA Enhancement.
                           2. Made changes to send runtime update for following 
                              newly added table Types:
                              a.ZV_PS_ENDP_PSPSTA   
                              b.ZV_PS_ENDP_ACTPSP
                              c.ZV_PS_ENDP_RCTX  
                              d.ZV_PSP_ACTPS     
                              e.ZV_PSP_REGPS  
                              f.ZV_DPCSTA       
                              g.ZV_ASPID         
/main/7    it020.106  sg   1. Additional checks added for message length in
                              M3UA message from peer.
                           2. Changes to define updArgs in itMifPspEvt.
/main/7    it023.106  sg   1. Changes to update PS statistics under compilation
                              flag LITV6.
*********************************************************************91*/
