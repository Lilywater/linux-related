/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:    M3UA Layer (M3UA)

     Type:    C source file

     Desc:    Code for Activation and Initialisation of M3UA layer

     File:    it_bdy1.c

     Sid:      it_bdy1.c@@/main/7 - Thu Apr  1 03:51:10 2004

     Prg:     pn

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_ss7.h"        /* common SS7 */
#include "cm_tpt.h"        /* common transport defines */
#include "lit.h"           /* layer management M3UA  */
#include "sct.h"           /* SCT interface */
#include "snt.h"           /* SNT interface */
#ifdef IT_FTHA             
#include "sht.h"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "it.h"            /* M3UA internal defines */
#include "it_err.h"        /* M3UA error */
#ifdef DI
#include "dit.h"
#endif /* DI */
#ifdef ZV
#include "cm_ftha.h"
#include "cm_psfft.h"          /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.h"
#include "cmzvdvlb.h"
#endif /* ZV_DFTHA */
#include "mrs.h"
#include "lzv.h"
#include "zv.h"            /* m3ua  PSF */
#endif /* ZV */

/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_ss7.x"        /* common SS7 */
#include "cm_tpt.x"        /* common transport */
#include "sct.x"           /* SCT interface */
#ifdef IT_FTHA             
#include "sht.x"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "lit.x"           /* layer management M3UA */
#include "snt.x"           /* SNT interface */
#include "it.x"            /* M3UA internal typedefs */
#ifdef DI
#include "dit.x"
#endif /* DI */
#ifdef ZV
#include "cm_ftha.x"
#include "cm_psfft.x"
#ifdef ZV_DFTHA
#include "cmzvdv.x"
#include "cmzvdvlb.x"
#endif
#include "mrs.x"
#include "lzv.x"
#include "zv.x"            /* m3ua PSF */
#endif /* ZV */

#ifdef SSI_WITH_CLI_ENABLED
#include "clishell.h"
#include "it_dbg.h"
#endif
/* Public variable declarations */

#ifdef SS_MULTIPLE_PROCS
PUBLIC ItGlobalCb  itGlobalCbLst[IT_MAX_INSTANCES];  /* Global control block */
PUBLIC ItGlobalCb  *itGlobalCbPtr;
#else
ItGlobalCb                 itGlobalCb;     /* Global control block */
#endif

EXTERN U32 g_itDbgMask;

/* functions */
/*chenning startwork*/
#if (defined ITASP && defined IT_AUTO_START) 
extern S16 StartWork(S16 suId);
#endif
/* ------------------------------------------------------------------*
 * Interface Functions to System Services                            *
 * ------------------------------------------------------------------*/


/*
*
*      Fun:   Activate Task - initialize
*
*      Desc:  Invoked by system services to initialize a task.
*
*      Ret:   ROK
*
*      Notes: None
*
*      File:  it_bdy1.c
*
*/

#ifdef SS_MULTIPLE_PROCS
#ifdef ANSI
PUBLIC S16 itActvInit
(
ProcId   proc,                /* Proc Id */
Ent      entity,              /* entity */
Inst     inst,                /* instance */
Region   region,              /* region */
Reason   reason,               /* reason */
Void**    xxCb                /* Pointer to Control Block */
)
#else 
PUBLIC S16 itActvInit(proc, entity, inst, region, reason, xxCb)
ProcId   proc;                /* Proc Id */
Ent      entity;              /* entity */
Inst     inst;                /* instance */
Region   region;              /* region */
Reason   reason;              /* reason */
Void**    xxCb;                /* Pointer to Control Block */
#endif /* ANSI */
#else /* SS_MULTIPLE_PROCS */
#ifdef ANSI
PUBLIC S16 itActvInit
(
Ent      entity,              /* entity */
Inst     inst,                /* instance */
Region   region,              /* region */
Reason   reason               /* reason */
)
#else
PUBLIC S16 itActvInit(entity, inst, region, reason)
Ent      entity;              /* entity */
Inst     inst;                /* instance */
Region   region;              /* region */
Reason   reason;              /* reason */
#endif /* ANSI */
#endif /* SS_MULTIPLE_PROCS */
{
    U16   idx;                 /* loop index */
    
#ifdef SS_MULTIPLE_PROCS
   PRIVATE U16 itNumInstToInit =  0;
#endif

#ifdef SSI_WITH_CLI_ENABLED
    S32 retPrtl;
    S32 ret;
#endif

	TRC3(itActvInit)

#ifdef SS_MULTIPLE_PROCS
   /* it016.106 - Use ITSHUTDOWN hash define to check if itActvInit is called 
    * from itMiShutdown(). */
   if(reason != ITSHUTDOWN) 
   {    
       if( itNumInstToInit >= IT_MAX_INSTANCES)
	   RETVALUE(FALSE);
       
       IT_ZERO(&itGlobalCbLst[itNumInstToInit], sizeof(ItGlobalCb));
       itGlobalCbPtr =& itGlobalCbLst[itNumInstToInit];
       itGlobalCb.itInit.procId  = proc;
       itGlobalCb.used= TRUE;
       *xxCb = (Void *) itGlobalCbPtr;
       itNumInstToInit++;
   }
#else /* SS_MULTIPLE_PROCS */

   /* Initialize the M3UA control block */
   IT_ZERO(&itGlobalCb, sizeof(ItGlobalCb));
   itGlobalCb.itInit.procId   = SFndProcId();

#endif /* SS_MULTIPLE_PROCS */
   
   itGlobalCb.itInit.ent      = entity;
   itGlobalCb.itInit.inst     = inst;
   itGlobalCb.itInit.region   = region;
   itGlobalCb.itInit.reason   = reason;
   itGlobalCb.itInit.cfgDone  = FALSE;  /* cfgDone gets set in CfgReq */

   /* Pool Id is obtained after SGetSMem in general configuration */
   itGlobalCb.itInit.pool     = 0;
   itGlobalCb.itInit.acnt     = FALSE;
#ifdef IT_USTA
   itGlobalCb.itInit.usta     = TRUE;
#else
   itGlobalCb.itInit.usta     = FALSE;
#endif /* IT_USTA */
   itGlobalCb.itInit.trc      = FALSE;

   itGlobalCb.itTqCp.nxtEnt   = 0;
   itGlobalCb.itTqCp.tmrLen   = IT_TQSIZE;

   for (idx = 0; idx < IT_TQSIZE; idx++)
   {
      itGlobalCb.itTq[idx].first = (CmTimer *)NULLP;
      itGlobalCb.itTq[idx].tail  = (CmTimer *)NULLP;
   } 
   /* initialize the aspIdLst */
   for (idx = 0; idx < LIT_MAX_PSP; idx++)
   {
      itGlobalCb.aspIdCb.aspIdValid[idx] = FALSE;
      itGlobalCb.aspIdCb.aspIdLst[idx] = IT_M3UA_DFLT;
   } 
   /* it017.106 - Initialise the lmPst structure. */
   itGlobalCb.itInit.lmPst.srcProcId = itGlobalCb.itInit.procId;
   itGlobalCb.itInit.lmPst.srcEnt    = itGlobalCb.itInit.ent;
   itGlobalCb.itInit.lmPst.srcInst   = itGlobalCb.itInit.inst;
   itGlobalCb.itInit.lmPst.event     = EVTNONE;
#ifdef DEBUGP
   itGlobalCb.itInit.dbgMask = 0;
#endif /* DEBUGP */

#ifdef IT_DEBUGP
   itGlobalCb.itInit.dbgMask = g_itDbgMask;
#endif /* IT_DEBUGP */

/* DFHTA-hooks */
#ifdef ZV
   if (reason != ITSHUTDOWN)
   {
      /* initialize PSF */
#ifdef SS_MULTIPLE_PROCS
      itGlobalCb.psfCb =(Void *) &zvCbLst[itNumInstToInit-1];
#endif /* SS_MULTIPLE_PROCS */
      zvActvInit(entity, inst, region, reason);
   }
#endif

#ifdef SSI_WITH_CLI_ENABLED
   /* chenning: ���������и�Ϊ��̬ע�ᣬ���������������˶�̬ע��������*/
    retPrtl = XOS_RegistCmdPrompt( SYSTEM_MODE, "prtl",  "Э��ģʽ", "�޲���" );

    ret = XOS_RegistCmdPrompt( retPrtl, "m3ua", "m3ua Э��", "�޲���" );

    XOS_RegistCommand(ret, itDbgShow, "show", "�ò���Ϊ��ӡ�����û�ͳ�ơ�״̬��Ϣ\r\n"
        "                      �ò���������Ϣ������show ?|help����ȡ", 
        "M3UAЭ��show ����֧�������б�:\r\n\r\n"
        "  cbk  ---- �ò���Ϊ��ӡ�����ƿ���Ϣ\r\n"
        "            �ò���������Ϣ������show cbk ? |help����ȡ\r\n\r\n"
        "  cfg  ---- �ò���Ϊ��ӡ��������Ϣ\r\n"
        "            �ò���������Ϣ������show cfg ? |help����ȡ\r\n\r\n"
        "  sts  ---- �ò���Ϊ��ӡ��ͳ����Ϣ\r\n"
        "            �ò���������Ϣ������show sts ?|help ����ȡ\r\n\r\n"
        "  sta  ---- �ò���Ϊ��ӡ��״̬��Ϣ\r\n"
        "            �ò���������Ϣ������shw sta ? |help����ȡ\r\n\r\n"
        "  help ---- �ò���Ϊ��ȡ�������ڲ��������help��?\r\n"
        "            ���ܻ�ȡ�ò����ľ�����Ϣ");
    XOS_RegistCommand(ret, itDbgControl, "ctrl", "�ò���Ϊִ�и�����������ɲ�ͬ�Ĺ���\r\n"
        "                      �ò���������Ϣ������ctrl ?|help����ȡ", 
#ifdef ITASP
#ifndef IT_AUTO_START
        "  auto ---- �ò���Ϊ����M3UA�Զ�������ʱ��\r\n"
        "            �ò���������Ϣ������ctrl auto ?|help ����ȡ\r\n\r\n"
#endif
#endif
        "  mask ---- �ò���Ϊ����M3UAЭ��Ĵ�ӡ����\r\n"
        "            �ò���������Ϣ������ctrl mask ?|help ����ȡ\r\n\r\n"
        "  help ---- �ò���Ϊ��ȡ�������ڲ��������help��?\r\n"
        "            ���ܻ�ȡ�ò����ľ�����Ϣ");
#endif
    XOS_RegistCommand(ret, itDbgSet, "set", "�ò���Ϊ���ø��ֹ��ܲ���\r\n"
        "                      �ò���������Ϣ������set ?|help����ȡ", 
        "M3UAЭ��set ����֧�������б�:\r\n\r\n"
        "  -o   ---- �ò���Ϊ����M3UA��TRACE�ļ���\r\n"
        "            �����ļ�������ܽ�TRACE��¼���ļ���\r\n"
        "            �ò���������Ϣ������set -o ? |help����ȡ\r\n\r\n"
        "  help ---- �ò���Ϊ��ȡ�������ڲ��������help��?\r\n"
        "            ���ܻ�ȡ�ò����ľ�����Ϣ");

   itInitExt();

   RETVALUE(ROK);
} /* end of itActvInit */


/* ---------------------------------------------------------------
 * Layer Management interface LIT primitives
 * ---------------------------------------------------------------
 */


/*
*
*       Fun:   ItMiLitCfgReq
*
*       Desc:  This function is used by the Layer Management to
*              configure the layer. The M3UA layer responds with a
*              Configuration Confirm to the layer manager. This primitive
*              can also be used to reconfigure the layer.
*
*       Ret:   Success: ROK
*              Failure: RFAILED
*
*       Notes: Configuration must be performed in the following
*              sequence:
*              1) general configuration (STITGEN);
*              2) sap configuration (STITSCTSAP and/or STITNSAP).
*
*       File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItMiLitCfgReq
(
Pst      *pst,                /* post structure */
ItMgmt   *cfg                 /* configuration structure */
)
#else
PUBLIC S16 ItMiLitCfgReq(pst, cfg)
Pst      *pst;                /* post structure */
ItMgmt   *cfg;                /* configuration structure */
#endif                        
{                             
   Header      *hdr;          /* Header structure */
   S16         ret;           /* return code */
   CmStatus    sta;           /* status */

   TRC3(ItMiLitCfgReq)

#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItMiLitCfgReq() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_MI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#endif /* SS_MULTIPLE_PROCS */


   ITADDZVUPDPEERCTR()
   
   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
                       "ItMiLitCfgReq(pst, elmnt(%d))\n",
                       cfg->hdr.elmId.elmnt));

   /* obtain the header structure from the configuration */
   hdr = &(cfg->hdr);

   /* zero out the confirm structure */
   IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt));


   if ( (itGlobalCb.itInit.cfgDone != TRUE) &&
        (hdr->elmId.elmnt != STITGEN) )
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_DEBUG, EIT005, (ErrVal) NULLD,
                 "ItMiLitCfgReq: General Configuration not done");
#endif /* ERRCLS_INT_PAR */
      itMiSendLmCfm(pst, TCFG, hdr, LCM_PRIM_NOK, 
                    LCM_REASON_GENCFG_NOT_DONE);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }


   /* choose the element (ie. which type of configuration) */
   switch (hdr->elmId.elmnt)
   {
      case STITGEN:               /* general configuration */
         /* note: param checks gets done in itMiCfgGen */
         ret = itMiCfgGen(&(cfg->t.cfg.s.genCfg), &sta);
         break;

      case STITNWK:
         /* do a range check */
         if (cfg->t.cfg.s.nwkCfg.nwkId >= itGlobalCb.genCfg.maxNmbNwk)
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            ITLOGERROR(ERRCLS_INT_PAR, EIT006, 
                       (ErrVal) cfg->t.cfg.s.nwkCfg.nwkId,
                       "ItMiLitCfgReq: invalid nwkId in case STITNWK");
#endif /* ERRCLS_INT_PAR */
            itMiSendLmCfm(pst, TCFG, hdr, LCM_PRIM_NOK, 
                          LIT_REASON_INVALID_NWKID);
            ITZVUPDPEER();
            RETVALUE(RFAILED);
         }
         /* network configuration */
         ret = itAtCfgNwk(&(cfg->t.cfg.s.nwkCfg), &sta);
         break;

      case STITNSAP:              /* upper SNT SAP configuration */
         if ((cfg->t.cfg.s.nSapCfg.sapId >= itGlobalCb.genCfg.maxNmbNSap) ||
             (cfg->t.cfg.s.nSapCfg.sapId < 0))
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            ITLOGERROR(ERRCLS_INT_PAR, EIT007, (ErrVal) hdr->elmId.elmnt,
                       "ItMiLitCfgReq: invalid sapId in case STITNSAP");
#endif /* ERRCLS_INT_PAR */
            itMiSendLmCfm(pst, TCFG, hdr, LCM_PRIM_NOK, LCM_REASON_INVALID_SAP);
            ITZVUPDPEER();
            RETVALUE(RFAILED);
         }
         ret = itUiCfgSap(&(cfg->t.cfg.s.nSapCfg), &sta);
         break;

      case STITSCTSAP:            /* lower SCT SAP configuration */
         if (cfg->t.cfg.s.sctSapCfg.suId >= itGlobalCb.genCfg.maxNmbSctSap)
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            ITLOGERROR(ERRCLS_INT_PAR, EIT008, (ErrVal) hdr->elmId.elmnt,
                       "ItMiLitCfgReq: invalid suId in case STITSCTSAP");
#endif /* ERRCLS_INT_PAR */
            itMiSendLmCfm(pst, TCFG, hdr, LCM_PRIM_NOK, LCM_REASON_INVALID_SAP);
            ITZVUPDPEER();
            RETVALUE(RFAILED);
         }
         ret = itLiCfgSap(&(cfg->t.cfg.s.sctSapCfg), &sta);
         break;

      case STITROUT:              /* route entry config */
         ret = itAtCfgRout(&(cfg->t.cfg.s.rteCfg), &sta, FALSE);
         break;

      case STITPS:                /* peer server configuration */
         ret = itPsmCfgPs(&(cfg->t.cfg.s.psCfg), &sta, IT_PS_CFG_STAT);
         break;

      case STITPSP:               /* peer signalling process config */
         ret = itPsmCfgPsp(&(cfg->t.cfg.s.pspCfg), &sta);
         break;

      default:                    /* invalid */
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT009, (ErrVal) hdr->elmId.elmnt,
              "ItMiLitCfgReq: Bad Element in config request");
#endif /* ERRCLS_INT_PAR */
         sta.reason = LCM_REASON_INVALID_ELMNT;
         sta.status = LCM_PRIM_NOK;
         ret        = RFAILED; /* error code returned */
         break;

   } /* end of switch statement */

   /*
    * In normal cases, RFAILED is returned, in all error
    * cases appropriate reason is returned by the above functions
    */

   /* send the layer manager confirm */
   itMiSendLmCfm(pst, TCFG, hdr, sta.status, sta.reason);

   ITZVUPDPEER();
   
   RETVALUE(ret);
} /* end of ItMiLitCfgReq() */


/*
*
*       Fun:   ItMiLitCntrlReq
*
*       Desc:  This function is used by the Layer Management to
*              send control requests to the M3UA layer general
*              elements (layer, alarms, trace and debug prints),
*              configurable entities (association, PS, PSP)
*              and upper/lower SAP states.
*
*       Ret:   Success: ROK
*              Failure: RFAILED
*
*       Notes: <none>
*
*       File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItMiLitCntrlReq
(
Pst     *pst,                 /* post structure */
ItMgmt  *cntrl                /* pointer to control structure */
)
#else
PUBLIC S16 ItMiLitCntrlReq(pst, cntrl)
Pst     *pst;                 /* post structure */
ItMgmt  *cntrl;               /* pointer to control structure */
#endif
{
   Header      *hdr;          /* Header structure */
   S16         ret;           /* return code */
   Action      action;        /* action field */
   Action      subAction;     /* subaction field */
   CmStatus    sta;           /* status */

   TRC3(ItMiLitCntrlReq)

#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItMiLitCntrlReq() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_MI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#endif /* SS_MULTIPLE_PROCS */

  ITADDZVUPDPEERCTR()

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
        "ItMiLitCntrlReq(pst, elmnt(%d))\n", cntrl->hdr.elmId.elmnt));

   /* obtain the header structure from the configuration */
   hdr = &(cntrl->hdr);

   /* zero out the confirm structure */
   IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt));

   ret         = ROK;
   sta.status  = LCM_PRIM_NOK;
   sta.reason  = LCM_REASON_NOT_APPL;

   ITDBGP(DBGMASK_SI, (itGlobalCb.itInit.prntBuf,
            "SGetDateTime(DateTime(%p))\n", (Void *)&cntrl->t.cntrl.dt));

   SGetDateTime(&(cntrl->t.cntrl.dt));

   /* get the action and subaction fields */
   action      = cntrl->t.cntrl.action;
   subAction   = cntrl->t.cntrl.subAction;
   /* copy the action and subaction accross to the mgmt struct
    * that will be pass to the layer manager confirm function
    */
   itGlobalCb.mgmt.t.cntrl.subAction   = subAction;
   itGlobalCb.mgmt.t.cntrl.action      = action;

   /* check if general configuration done */
#if (ERRCLASS & ERRCLS_DEBUG)
   if (itGlobalCb.itInit.cfgDone != TRUE)
   {
      ITLOGERROR(ERRCLS_DEBUG, EIT010, (ErrVal) NULLD,
                 "ItMiLitCntrlReq: General Configuration not done");
      itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK, 
                    LCM_REASON_GENCFG_NOT_DONE);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_DEBUG */


   /* check element */
   switch (hdr->elmId.elmnt)
   {
      /* General control */
      case STITGEN:
         switch (action)
         {
            case AENA:
               switch (subAction)
               {
                  case SAUSTA:
                     /* enable alarms */
                     itGlobalCb.itInit.usta = TRUE;
                     break;
                  case SATRC:
                     /* enable trace */
                     itGlobalCb.itInit.trc = TRUE;
                     itGlobalCb.trcMask |= cntrl->t.cntrl.t.trc.trcMask;
                     break;
#ifdef DEBUGP
                  case SADBG:
                     /* enable debug printing */
                     itGlobalCb.itInit.dbgMask |= cntrl->t.cntrl.t.dbg.dbgMask;
                     break;
#endif /* #ifdef DEBUGP */
                  default:
#if (ERRCLASS & ERRCLS_INT_PAR)
                     ITLOGERROR(ERRCLS_INT_PAR, EIT011, (ErrVal) subAction,
                                "ItMiLitCntrlReq(): Invalid subaction");
#endif /* ERRCLS_INT_PAR */
                     /* element must be one of the above */
                     ret         = RFAILED;
                     sta.reason  = LCM_REASON_INVALID_SUBACTION;
                     break;
               }
#ifdef ZV
                 /* Update all the subactions from above */
                 zvRTUpd(CMPFTHA_ACTN_MOD, ZV_GENCB,
                         CMPFTHA_UPDTYPE_NORMAL, (Void *) NULLP, NULLP);
#endif
               break;

            case ADISIMM:
               switch (subAction)
               {
                  case SAUSTA:
                     /* disable alarms */
                     itGlobalCb.itInit.usta = FALSE;
                     break;
                  case SATRC:
                     /* disable trace */
                     itGlobalCb.itInit.trc = FALSE;
                     break;
#ifdef DEBUGP
                  case SADBG:
                     /* disable debug printing */
                     itGlobalCb.itInit.dbgMask &= 
                        ~(cntrl->t.cntrl.t.dbg.dbgMask);
                     break;
#endif /* #ifdef DEBUGP */
                  default:
#if (ERRCLASS & ERRCLS_INT_PAR)
                     ITLOGERROR(ERRCLS_INT_PAR, EIT012, (ErrVal) subAction,
                                "ItMiLitCntrlReq(): Invalid subaction");
#endif /* ERRCLS_INT_PAR */
                     /* element must be one of the above */
                     ret         = RFAILED;
                     sta.reason  = LCM_REASON_INVALID_SUBACTION;
                     break;
               }
#ifdef ZV
                /* Update all the subActions from above */
                zvRTUpd(CMPFTHA_ACTN_MOD, ZV_GENCB,
                         CMPFTHA_UPDTYPE_NORMAL, (Void *) NULLP, NULLP);
#endif
               break;

            case ASHUTDOWN:
               /* Shutdown all operations */
               ret = itMiShutdown(&sta);
               break;

            default:
#if (ERRCLASS & ERRCLS_INT_PAR)
               ITLOGERROR(ERRCLS_INT_PAR, EIT013, (ErrVal) action,
                           "ItMiLitCntrlReq(): Invalid action");
#endif /* ERRCLS_INT_PAR */
               ret         = RFAILED;
               sta.reason  = LCM_REASON_INVALID_ACTION;
               break;
         } /* end of case STITGEN */
         break;

      case STITPSP:
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         ItPspCb *pspCb;
         if (cntrl->t.cntrl.s.pspId >= itGlobalCb.genCfg.maxNmbPsp)
         {
            pspCb = (ItPspCb *)NULLP;
            if (action == ADEL)
            {
               ITLOGERROR(ERRCLS_INT_PAR, EIT014, 
                          (ErrVal) cntrl->t.cntrl.s.pspId,
                           "ItMiLitCntrlReq(): Invalid pspId in case STITPSP");
               itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                           LIT_REASON_INVALID_PSPID);
               ITZVUPDPEER();
               RETVALUE(RFAILED);
            }
         }
         else
         {
            pspCb = itGlobalCb.psp[cntrl->t.cntrl.s.pspId];
         }
         if ((pspCb == (ItPspCb *)NULLP) && (action != ADEL))
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT015,
               (ErrVal) cntrl->t.cntrl.s.pspId,
               "ItMiLitCntrlReq(): Invalid pspId in case STITPSP");
            itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                           LIT_REASON_INVALID_PSPID);
            ITZVUPDPEER();
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */
#ifdef ZV
         /* Protocol state is checked so that critical events are not sent
            from standby copies */
#if (ERRCLASS & ERRCLS_INT_PAR)
         if (action != ADEL)
         {
            ITCHKPROTSTATE(EIT016, STITPSP, cntrl->t.cntrl.s.pspId, ret,
                           IT_EVENT_CRIT);
            if (ret != ROK) 
            {
               ITZVUPDPEER();
               RETVALUE(ret);
            }
         }
#endif
#endif
         switch (action)
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            ItSctSapCb *sctSapCb;
#endif
            /* temp variables */
            case AESTABLISH:
               /* range/param checks */
#if (ERRCLASS & ERRCLS_INT_PAR)
               if (cntrl->t.cntrl.s.pspId == LIT_PSPID_LOCAL)
               {
                  ITLOGERROR(ERRCLS_INT_PAR, EIT017,
                     (ErrVal) cntrl->t.cntrl.s.pspId,
               "ItMiLitCntrlReq(): Invalid pspId in case STITPSP(AESTABLISH)");
                  itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                                 LIT_REASON_INVALID_PSPID);
                  ITZVUPDPEER();
                  RETVALUE(RFAILED);
               }
               if ((cntrl->t.cntrl.t.aspm.sctSuId < 0) ||
                   (cntrl->t.cntrl.t.aspm.sctSuId >= 
                                                itGlobalCb.genCfg.maxNmbSctSap))
               {
                  sctSapCb = (ItSctSapCb *)NULLP;
               }
               else
               {
                  sctSapCb = itGlobalCb.sctSap[cntrl->t.cntrl.t.aspm.sctSuId];
               }
               if (sctSapCb == (ItSctSapCb *)NULLP)
               {
                  ITLOGERROR(ERRCLS_INT_PAR, EIT018,
                     (ErrVal) cntrl->t.cntrl.t.aspm.sctSuId,
                 "ItMiLitCntrlReq(): Invalid suId in case STITPSP(AESTABLISH)");
                  itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                                 LCM_REASON_INVALID_SAP);
                  ITZVUPDPEER();
                  RETVALUE(RFAILED);
               }
#endif /* ERRCLS_INT_PAR */
               /* establish the association specified by s.pspId and 
                  t.aspm.sctSuId*/
               ret = itAcEst(IT_PSPnENDP2ASSOC(cntrl->t.cntrl.s.pspId,
                             cntrl->t.cntrl.t.aspm.sctSuId), &sta);
               break;

            case ATERMINATE:
               /* range/param checks */
#if (ERRCLASS & ERRCLS_INT_PAR)
               if (cntrl->t.cntrl.s.pspId == LIT_PSPID_LOCAL)
               {
                  ITLOGERROR(ERRCLS_INT_PAR, EIT019,
                     (ErrVal) cntrl->t.cntrl.s.pspId,
               "ItMiLitCntrlReq(): Invalid pspId in case STITPSP(ATERMINATE)");
                  itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                                 LIT_REASON_INVALID_PSPID);
                  ITZVUPDPEER();
                  RETVALUE(RFAILED);
               }
               if ((cntrl->t.cntrl.t.aspm.sctSuId < 0) ||
                   (cntrl->t.cntrl.t.aspm.sctSuId >= 
                                                itGlobalCb.genCfg.maxNmbSctSap))
               {
                  sctSapCb = (ItSctSapCb *)NULLP;
               }
               else
               {
                  sctSapCb = itGlobalCb.sctSap[cntrl->t.cntrl.t.aspm.sctSuId];
               }
               if (sctSapCb == (ItSctSapCb *)NULLP)
               {
                  ITLOGERROR(ERRCLS_INT_PAR, EIT020,
                     (ErrVal) cntrl->t.cntrl.t.aspm.sctSuId,
                 "ItMiLitCntrlReq(): Invalid suId in case STITPSP(ATERMINATE)");
                  itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                                 LCM_REASON_INVALID_SAP);
                  ITZVUPDPEER();
                  RETVALUE(RFAILED);
               }
#endif /* ERRCLS_INT_PAR */
               /* terminate the assoc specified by s.pspId */
#ifdef IT_ABORT_ASSOC
               ret = itAcTerm(IT_PSPnENDP2ASSOC(cntrl->t.cntrl.s.pspId,
                             cntrl->t.cntrl.t.aspm.sctSuId),
                               &sta, cntrl->t.cntrl.t.aspm.abrtFlag);
#else
               /* it004.106 - abrtFlg param added to itAcTerm, set it 
                * to FALSE for graceful shutdown. */
               ret = itAcTerm(IT_PSPnENDP2ASSOC(cntrl->t.cntrl.s.pspId,
                             cntrl->t.cntrl.t.aspm.sctSuId), &sta, FALSE);
#endif /* IT_ABORT_ASSOC */
               break;

            case AINH:
#if (ERRCLASS & ERRCLS_INT_PAR)
               if ((cntrl->t.cntrl.t.aspm.sctSuId < 0) ||
                   (cntrl->t.cntrl.t.aspm.sctSuId >= 
                                                itGlobalCb.genCfg.maxNmbSctSap))
               {
                  sctSapCb = (ItSctSapCb *)NULLP;
               }
               else
               {
                  sctSapCb = itGlobalCb.sctSap[cntrl->t.cntrl.t.aspm.sctSuId];
               }
               if (sctSapCb == (ItSctSapCb *)NULLP)
               {
                  ITLOGERROR(ERRCLS_INT_PAR, EIT021,
                     (ErrVal) cntrl->t.cntrl.t.aspm.sctSuId,
                 "ItMiLitCntrlReq(): Invalid suId in case STITPSP(AINH)");
                  itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                                 LCM_REASON_INVALID_SAP);
                  ITZVUPDPEER();
                  RETVALUE(RFAILED);
               }
#endif /* ERRCLS_INT_PAR */
               /* management inhibit of the assoc specified by s.pspId and
                  t.aspm.sctSuId */
               ret = itAcInh(IT_PSPnENDP2ASSOC(cntrl->t.cntrl.s.pspId,
                             cntrl->t.cntrl.t.aspm.sctSuId), &sta);
               break;

            case AUNINH:
#if (ERRCLASS & ERRCLS_INT_PAR)
               if ((cntrl->t.cntrl.t.aspm.sctSuId < 0) ||
                   (cntrl->t.cntrl.t.aspm.sctSuId >= 
                                                itGlobalCb.genCfg.maxNmbSctSap))
               {
                  sctSapCb = (ItSctSapCb *)NULLP;
               }
               else
               {
                  sctSapCb = itGlobalCb.sctSap[cntrl->t.cntrl.t.aspm.sctSuId];
               }
               if (sctSapCb == (ItSctSapCb *)NULLP)
               {
                  ITLOGERROR(ERRCLS_INT_PAR, EIT022,
                     (ErrVal) cntrl->t.cntrl.t.aspm.sctSuId,
                 "ItMiLitCntrlReq(): Invalid suId in case STITPSP(AUNINH)");
                  itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                                 LCM_REASON_INVALID_SAP);
                  ITZVUPDPEER();
                  RETVALUE(RFAILED);
               }
#endif /* ERRCLS_INT_PAR */
               /* management uninhibit of the assoc specified by s.pspId and
                  t.aspm.sctSuId */
               ret = itAcUninh(IT_PSPnENDP2ASSOC(cntrl->t.cntrl.s.pspId,
                             cntrl->t.cntrl.t.aspm.sctSuId), &sta);
               break;

            case AASPAC:
#if (ERRCLASS & ERRCLS_INT_PAR)
               if ((cntrl->t.cntrl.t.aspm.sctSuId < 0) ||
                   (cntrl->t.cntrl.t.aspm.sctSuId >= 
                                                itGlobalCb.genCfg.maxNmbSctSap))
               {
                  sctSapCb = (ItSctSapCb *)NULLP;
               }
               else
               {
                  sctSapCb = itGlobalCb.sctSap[cntrl->t.cntrl.t.aspm.sctSuId];
               }
               if (sctSapCb == (ItSctSapCb *)NULLP)
               {
                  ITLOGERROR(ERRCLS_INT_PAR, EIT023,
                     (ErrVal) cntrl->t.cntrl.t.aspm.sctSuId,
                 "ItMiLitCntrlReq(): Invalid suId in case STITPSP(AASPAC)");
                  itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                                 LCM_REASON_INVALID_SAP);
                  ITZVUPDPEER();
                  RETVALUE(RFAILED);
               }
#endif /* ERRCLS_INT_PAR */
               /* Called to initiate activation of an ASP. */
               ret = itPsmSendAspAc(&cntrl->t.cntrl, &sta);
               break;

            case AASPIA:
#if (ERRCLASS & ERRCLS_INT_PAR)
               if ((cntrl->t.cntrl.t.aspm.sctSuId < 0) ||
                   (cntrl->t.cntrl.t.aspm.sctSuId >= 
                                                itGlobalCb.genCfg.maxNmbSctSap))
               {
                  sctSapCb = (ItSctSapCb *)NULLP;
               }
               else
               {
                  sctSapCb = itGlobalCb.sctSap[cntrl->t.cntrl.t.aspm.sctSuId];
               }
               if (sctSapCb == (ItSctSapCb *)NULLP)
               {
                  ITLOGERROR(ERRCLS_INT_PAR, EIT024,
                     (ErrVal) cntrl->t.cntrl.t.aspm.sctSuId,
                 "ItMiLitCntrlReq(): Invalid suId in case STITPSP(AASPIA)");
                  itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                                 LCM_REASON_INVALID_SAP);
                  ITZVUPDPEER();
                  RETVALUE(RFAILED);
               }
#endif /* ERRCLS_INT_PAR */
               /* Called to initiate deactivation of an ASP. */
               ret = itPsmSendAspIa(&cntrl->t.cntrl, &sta);
               break;

            case AASPUP:
#if (ERRCLASS & ERRCLS_INT_PAR)
               if ((cntrl->t.cntrl.t.aspm.sctSuId < 0) ||
                   (cntrl->t.cntrl.t.aspm.sctSuId >= 
                                                itGlobalCb.genCfg.maxNmbSctSap))
               {
                  sctSapCb = (ItSctSapCb *)NULLP;
               }
               else
               {
                  sctSapCb = itGlobalCb.sctSap[cntrl->t.cntrl.t.aspm.sctSuId];
               }
               if (sctSapCb == (ItSctSapCb *)NULLP)
               {
                  ITLOGERROR(ERRCLS_INT_PAR, EIT025,
                     (ErrVal) cntrl->t.cntrl.t.aspm.sctSuId,
                 "ItMiLitCntrlReq(): Invalid suId in case STITPSP(AASPUP)");
                  itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                                 LCM_REASON_INVALID_SAP);
                  ITZVUPDPEER();
                  RETVALUE(RFAILED);
               }
#endif /* ERRCLS_INT_PAR */
               /* Called to initiate generation of ASPUP messages. */
               ret = itPsmSendAspUp(&cntrl->t.cntrl, &sta);
               break;

            case AASPDN:
#if (ERRCLASS & ERRCLS_INT_PAR)
               if ((cntrl->t.cntrl.t.aspm.sctSuId < 0) ||
                   (cntrl->t.cntrl.t.aspm.sctSuId >= 
                                                itGlobalCb.genCfg.maxNmbSctSap))
               {
                  sctSapCb = (ItSctSapCb *)NULLP;
               }
               else
               {
                  sctSapCb = itGlobalCb.sctSap[cntrl->t.cntrl.t.aspm.sctSuId];
               }
               if (sctSapCb == (ItSctSapCb *)NULLP)
               {
                  ITLOGERROR(ERRCLS_INT_PAR, EIT026,
                     (ErrVal) cntrl->t.cntrl.t.aspm.sctSuId,
                 "ItMiLitCntrlReq(): Invalid suId in case STITPSP(AASPDN)");
                  itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                                 LCM_REASON_INVALID_SAP);
                  ITZVUPDPEER();
                  RETVALUE(RFAILED);
               }
#endif /* ERRCLS_INT_PAR */
               /* Called to initiate generation of ASPDN messages. */
               ret = itPsmSendAspDn(&cntrl->t.cntrl, &sta);
               break;


            case ADEL:
               /* delete the PSP specified by s.pspId */
               /* it022.106 - Added usage of abrtFlag. */
               if (cntrl->t.cntrl.s.pspId == LIT_PSPID_LOCAL)
               {
                  ITLOGERROR(ERRCLS_INT_PAR, EITXXX,
                     (ErrVal) cntrl->t.cntrl.s.pspId,
               "ItMiLitCntrlReq(): Invalid pspId in case STITPSP(ADEL)");
                  itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                                 LIT_REASON_INVALID_PSPID);
                  ITZVUPDPEER();
                  RETVALUE(RFAILED);
               }
#ifdef LITV5
#ifdef IT_ABORT_ASSOC
               if (cntrl->t.cntrl.t.aspm.abrtFlag == TRUE)
               {
                  SuId         i;            /* loop index */

#ifdef ZV
                  /* Protocol state is checked so that critical events are not 
                   * sent from standby copies */
#if (ERRCLASS & ERRCLS_INT_PAR)
                  ITCHKPROTSTATE(EITXXX, STITPSP, cntrl->t.cntrl.s.pspId, ret,
                                 IT_EVENT_CRIT);
                  if (ret != ROK) 
                  {
                      itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                                    LCM_REASON_NOT_APPL);
                      ITZVUPDPEER();
                      RETVALUE(ret);
                  }
#endif
#endif
                  /* Add DFTHA hook to check for critical event. */
                  for (i = 0; i < LIT_MAX_SEP; i++)
                  {
                     /* Return valus of itAcTerm not used, because this function
                      * returns RFAILED when either the assocCb is already NULL
                      * or SCT SAP is not in LIT_SAP_READY state. In both these
                      * cases it is fine to go ahead and delete PSP. */
                     (Void) itAcTerm(IT_PSPnENDP2ASSOC(cntrl->t.cntrl.s.pspId,
                                     i), &sta, TRUE);
                  }
               
                  /* DFTHA hook to send RT updates for PSP associations gone 
                   * down because these updates cannot be combined with PSP 
                   * deletion updates. */
                  ITZVUPDPEER();

                  /* Increment the zvUpdPeer counter to proceed with PSP 
                   * deletion updates. */ 
                  ITADDZVUPDPEERCTR()
               }
#endif /* IT_ABORT_ASSOC */
               /* IT_ABORT_ASSOC not defined or Abort flag is FALSE, so delete 
                * PSP in itPsmDelPsp only if associations are down and PSP is 
                * not in use. */
#endif /* LITV5 */
               ret = itPsmDelPsp(cntrl->t.cntrl.s.pspId, &sta, FALSE);
               break;
#ifdef ITASP

            case ASCON:
#if (ERRCLASS & ERRCLS_INT_PAR)
               if ((cntrl->t.cntrl.t.cong.sctSuId < 0) ||
                   (cntrl->t.cntrl.t.cong.sctSuId >= 
                                                itGlobalCb.genCfg.maxNmbSctSap))
               {
                  sctSapCb = (ItSctSapCb *)NULLP;
               }
               else
               {
                  sctSapCb = itGlobalCb.sctSap[cntrl->t.cntrl.t.cong.sctSuId];
               }
               if (sctSapCb == (ItSctSapCb *)NULLP)
               {
                  ITLOGERROR(ERRCLS_INT_PAR, EIT027,
                     (ErrVal) cntrl->t.cntrl.t.aspm.sctSuId,
                 "ItMiLitCntrlReq(): Invalid suId in case STITPSP(ASCON)");
                  itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                                 LCM_REASON_INVALID_SAP);
                  ITZVUPDPEER();
                  RETVALUE(RFAILED);
               }
#endif /* ERRCLS_INT_PAR */
               /* send SCON message to peer */
               ret = itPsmSendScon(&cntrl->t.cntrl, &sta);
               break;


            case ARKREG:
               /* range/param checks */
#if (ERRCLASS & ERRCLS_INT_PAR)
               if (cntrl->t.cntrl.s.pspId == LIT_PSPID_LOCAL)
               {
                  ITLOGERROR(ERRCLS_INT_PAR, EIT028,
                     (ErrVal) cntrl->t.cntrl.s.pspId,
               "ItMiLitCntrlReq(): Invalid pspId in case STITPSP(ARKREG)");
                  itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                                 LIT_REASON_INVALID_PSPID);
                  ITZVUPDPEER();
                  RETVALUE(RFAILED);
               }
               if ((cntrl->t.cntrl.t.dynRteKey.sctSuId < 0) ||
                   (cntrl->t.cntrl.t.dynRteKey.sctSuId >= 
                                                itGlobalCb.genCfg.maxNmbSctSap))
               {
                  sctSapCb = (ItSctSapCb *)NULLP;
               }
               else
               {
                  sctSapCb = itGlobalCb.sctSap[cntrl->t.cntrl.t.dynRteKey.\
                                                                      sctSuId];
               }
               if (sctSapCb == (ItSctSapCb *)NULLP)
               {
                  ITLOGERROR(ERRCLS_INT_PAR, EIT029,
                     (ErrVal) cntrl->t.cntrl.t.aspm.sctSuId,
                 "ItMiLitCntrlReq(): Invalid suId in case STITPSP(ARKREG)");
                  itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                                 LCM_REASON_INVALID_SAP);
                  ITZVUPDPEER();
                  RETVALUE(RFAILED);
               }
#endif /* ERRCLS_INT_PAR */
               /* Register the RK to the peer specified by s.pspId */
               ret = itAtSendRkRegReq(&cntrl->t.cntrl, &sta);
               break;

            case ARKDEREG:
               /* range/param checks */
#if (ERRCLASS & ERRCLS_INT_PAR)
               if (cntrl->t.cntrl.s.pspId == LIT_PSPID_LOCAL)
               {
                  ITLOGERROR(ERRCLS_INT_PAR, EIT030,
                     (ErrVal) cntrl->t.cntrl.s.pspId,
               "ItMiLitCntrlReq(): Invalid pspId in case STITPSP(ARKDEREG)");
                  itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                                 LIT_REASON_INVALID_PSPID);
                  ITZVUPDPEER();
                  RETVALUE(RFAILED);
               }
               if ((cntrl->t.cntrl.t.dynRteKey.sctSuId < 0) ||
                   (cntrl->t.cntrl.t.dynRteKey.sctSuId >= 
                                                itGlobalCb.genCfg.maxNmbSctSap))
               {
                  sctSapCb = (ItSctSapCb *)NULLP;
               }
               else
               {
                  sctSapCb = itGlobalCb.sctSap[cntrl->t.cntrl.t.dynRteKey.\
                                                                      sctSuId];
               }
               if (sctSapCb == (ItSctSapCb *)NULLP)
               {
                  ITLOGERROR(ERRCLS_INT_PAR, EIT031,
                     (ErrVal) cntrl->t.cntrl.t.aspm.sctSuId,
                 "ItMiLitCntrlReq(): Invalid suId in case STITPSP(ARKDEREG)");
                  itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                                 LCM_REASON_INVALID_SAP);
                  ITZVUPDPEER();
                  RETVALUE(RFAILED);
               }
#endif /* ERRCLS_INT_PAR */
               /* De-Register the RC to the peer specified by s.pspId */
               ret = itAtSendRkDeRegReq(&cntrl->t.cntrl, &sta);
               break;
#endif /* ITASP */

            default:
#if (ERRCLASS & ERRCLS_INT_PAR)
               ITLOGERROR(ERRCLS_INT_PAR, EIT032, (ErrVal) action,
                           "ItMiLitCntrlReq(): Invalid action");
#endif /* ERRCLS_INT_PAR */
               ret         = RFAILED;
               sta.reason  = LCM_REASON_INVALID_ACTION;
               break;
         } /* end of case STITPSP */
         break;
      }
      case STITNSAP:
      {
         ItNSapCb *nSapCb;
         if ((cntrl->t.cntrl.s.spId < 0) ||
            (cntrl->t.cntrl.s.spId >= itGlobalCb.genCfg.maxNmbNSap))
         {
            nSapCb = (ItNSapCb *)NULLP;
#if (ERRCLASS & ERRCLS_INT_PAR)
            if (action == ADEL)
            {
               ITLOGERROR(ERRCLS_INT_PAR, EIT033, 
                         (ErrVal) cntrl->t.cntrl.s.spId,
                         "ItMiLitCntrlReq(): Invalid spId in case STITNSAP");
               itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                           LCM_REASON_INVALID_SAP);
               ITZVUPDPEER();
               RETVALUE(RFAILED);
            }
#endif /* ERRCLASS & ERRCLS_INT_PAR */ 
         }
         else
         {
            nSapCb = itGlobalCb.nSap[cntrl->t.cntrl.s.spId];
         }
#if (ERRCLASS & ERRCLS_INT_PAR)
         if ((nSapCb == (ItNSapCb *)NULLP) && (action != ADEL))
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT034,
               (ErrVal) cntrl->t.cntrl.s.spId,
               "ItMiLitCntrlReq(): Invalid spId in case STITNSAP");
            itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK, 
                          LCM_REASON_INVALID_SAP);
            ITZVUPDPEER();
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */
         switch (action)
         {
            case ADEL:
               /* delete NSAP specified by spId */
               ret = itUiDelSap(nSapCb, &sta, FALSE);
               break;

            case AUBND:
               /* unbind NSAP specified by spId */
               ret = itUiUBndSap(nSapCb, &sta);
#ifdef ITSG
#ifdef IT_FTHA
               {
                  /* if its an MTP3 SAP CB */
                  if ((itGlobalCb.nSap[cntrl->t.cntrl.s.spId] !=
                      (ItNSapCb *) NULLP)
                     && (nSapCb->sntCfg.suType == LIT_SP_MTP3))
                  {
                     itGlobalCb.nSap[cntrl->t.cntrl.s.spId]->contEnt = ENTSM;
                  }
               }
#endif /* IT_FTHA */
#endif /* ITSG */
#ifdef ZV
               if (ret == ROK)
               {
                  /* SYNC update needs to be done before confirm can be sent to
                     LM  */

                   zvRTUpd(CMPFTHA_ACTN_MOD, ZV_NSAPCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) nSapCb, NULLP);
               }
#endif
               break;

#ifndef SNT_BACK_COMP_MERGED_NIF
#ifdef ITSG
            case ABND:
               /* bind MTP3 SAP specified by spId */
               /* it015.106 - To avoid confusion, spId should be used
                  instead of suId. Technically it doesn't matter, as 
                  both suId and spId are part of the same union and are
                  of same data type */
               if ((itGlobalCb.nSap[cntrl->t.cntrl.s.spId] !=
                   (ItNSapCb *) NULLP)
                  && (nSapCb->sntCfg.suType == LIT_SP_MTP3))
               {
                  ret = itLiBndMtp3Sap(cntrl->t.cntrl.s.spId, &sta, TRUE);
               }
               else
               {
                  ret = RFAILED;
                  sta.reason  = LIT_REASON_INVALID_NSAPID;
               }
#ifdef IT_FTHA
               {
                  itGlobalCb.nSap[cntrl->t.cntrl.s.spId]->contEnt = ENTNC;
               }
#ifdef ZV
               /* Update the controlling entity */
               {
                  zvRTUpd(CMPFTHA_ACTN_MOD, ZV_NSAPCB,
                        CMPFTHA_UPDTYPE_SYNC, 
                        (Void *) itGlobalCb.nSap[cntrl->t.cntrl.s.spId], NULLP);
               }
#endif
#endif /* IT_FTHA */
               break;

#endif /* ITSG */
#endif /* SNT_BACK_COMP_MERGED_NIF */

            default:
#if (ERRCLASS & ERRCLS_INT_PAR)
               ITLOGERROR(ERRCLS_INT_PAR, EIT035, (ErrVal) action,
                           "ItMiLitCntrlReq(): Invalid action");
#endif /* ERRCLS_INT_PAR */
               ret         = RFAILED;
               sta.reason  = LCM_REASON_INVALID_ACTION;
               break;
         } /* end of case STITNSAP */
         break;
      }
      case STITSCTSAP:
      {
#ifdef ZV
         ItSctSapCb *sctSap;
#endif
         ItSctSapCb *sctSapCb;
         if ((cntrl->t.cntrl.s.suId < 0) ||
            (cntrl->t.cntrl.s.suId >= itGlobalCb.genCfg.maxNmbSctSap))
         {
            sctSapCb = (ItSctSapCb *)NULLP;
            if (action == ADEL)
            {
#if (ERRCLASS & ERRCLS_INT_PAR)
               ITLOGERROR(ERRCLS_INT_PAR, EIT036, 
                         (ErrVal) cntrl->t.cntrl.s.suId,
                         "ItMiLitCntrlReq(): Invalid suId in case STITSCTSAP");
#endif /* ERRCLS_INT_PAR */
               itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                           LCM_REASON_INVALID_SAP);
               ITZVUPDPEER();
               RETVALUE(RFAILED);
            }
         }
         else
         {
            sctSapCb = itGlobalCb.sctSap[cntrl->t.cntrl.s.suId];
         }
         if ((sctSapCb == (ItSctSapCb *)NULLP) && (action != ADEL))
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            ITLOGERROR(ERRCLS_INT_PAR, EIT037,
               (ErrVal) cntrl->t.cntrl.s.suId,
               "ItMiLitCntrlReq(): Invalid suId in case STITSCTSAP");
#endif /* ERRCLS_INT_PAR */
            itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK,
                           LCM_REASON_INVALID_SAP);
            ITZVUPDPEER();
            RETVALUE(RFAILED);
         }
         switch (action)
         {
            case ABND:
#ifdef IT_RUG
               if (sctSapCb->remIntfValid == FALSE)
               {
                  itMiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK, 
                          LCM_REASON_SWVER_NAVAIL);
                  ITZVUPDPEER();
                  RETVALUE(RFAILED);
               }
#endif /* IT_RUG */
               /* bind SCT SAP specified by suId */
               ret = itLiBndSap(cntrl->t.cntrl.s.suId, &sta, TRUE);
#ifdef IT_FTHA
               if (ret == ROK)
               {
                  /* Find the SctSap CB */
                  if (itGlobalCb.sctSap[cntrl->t.cntrl.s.suId] !=
                      (ItSctSapCb *) NULLP)
                  {
                     itGlobalCb.sctSap[cntrl->t.cntrl.s.suId]->contEnt = ENTNC;
                  }
               }
#ifdef ZV
               /* Update the controlling entity */
               if (ret == ROK)
               {
                  sctSap = itGlobalCb.sctSap[cntrl->t.cntrl.s.suId];
                  zvRTUpd(CMPFTHA_ACTN_MOD, ZV_SCTSAPCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) sctSap, NULLP);
               }
#endif
#endif /* IT_FTHA */
               break;

            case AUBND:
               /* unbind SCT SAP specified by suId */
               ret = itLiReleaseSap(cntrl->t.cntrl.s.suId, &sta);
#ifdef IT_FTHA
               if (ret == ROK)
               {
                  /* Find the SctSap CB */
                  if (itGlobalCb.sctSap[cntrl->t.cntrl.s.suId] !=
                      (ItSctSapCb *) NULLP)
                  {
                     itGlobalCb.sctSap[cntrl->t.cntrl.s.suId]->contEnt = ENTSM;
                  }
               }
#endif /* IT_FTHA */
#ifdef ZV
               if (ret == ROK)
               {
                  sctSap = itGlobalCb.sctSap[cntrl->t.cntrl.s.suId];
                  zvRTUpd(CMPFTHA_ACTN_MOD, ZV_SCTSAPCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) sctSap, NULLP);
               }
#endif
               break;

            case AEOPENR:
               /* open the endpoint */
               ret = itLiEndpOpen(cntrl->t.cntrl.s.suId, &sta, TRUE);
               break;
            
            case ADEL:
               /* delete SCT SAP specified by suId */
               ret = itLiDelSap(cntrl->t.cntrl.s.suId, &sta, FALSE);
               break;

            default:
#if (ERRCLASS & ERRCLS_INT_PAR)
               ITLOGERROR(ERRCLS_INT_PAR, EIT038, (ErrVal) action,
                           "ItMiLitCntrlReq(): Invalid action");
#endif /* ERRCLS_INT_PAR */
               ret         = RFAILED;
               sta.reason  = LCM_REASON_INVALID_ACTION;
               break;
         } /* end case STITSCTSAP */
         break;
      }
      case STITROUT:
      {
#ifdef ZV
         ZvUpdSpecParams   updArgs;
#endif
         /* delete routing entry specified by s.rtent */
         ret = itAtDelRout(&cntrl->t.cntrl, &sta);

#ifdef ZV
         if (ret == ROK)
         {
            updArgs.p.rteUpd.indexType = cntrl->t.cntrl.t.rtEnt.indexType;
            switch (cntrl->t.cntrl.t.rtEnt.indexType)
            {
               case LIT_RTINDEX_PSID:
                  updArgs.p.rteUpd.psId = cntrl->t.cntrl.t.rtEnt.u.psId;
                  updArgs.p.rteUpd.nwkId = cntrl->t.cntrl.t.rtEnt.nwkId;
               break;
          
               case LIT_RTINDEX_DPC:
                  updArgs.p.rteUpd.nwkId = cntrl->t.cntrl.t.rtEnt.nwkId;
                  updArgs.p.rteUpd.dpc = cntrl->t.cntrl.t.rtEnt.u.dpc;
               break;

               case LIT_RTINDEX_NWKID:
                  updArgs.p.rteUpd.nwkId = cntrl->t.cntrl.t.rtEnt.nwkId;
               break;
                 
               case LIT_RTINDEX_ROUTECFG:
                  cmMemcpy((U8 *)&updArgs.p.rteUpd.rteCfg, 
                           (U8 *)&cntrl->t.cntrl.t.rtEnt.u.rteCfg,
                           sizeof(ItRteCfg)); 
               break;
           }
           /* Sync the deletion of Route Cb before confirm is sent */
           /* We can call zvRTUpd function here, even after routeCb is deleted
              because logic for RT update of route delete should not be using
              routeCb : All the required params are passed in updArgs argument*/
           zvRTUpd(CMPFTHA_ACTN_DEL, ZV_RTECB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) NULLP, &updArgs);
         } /* End of ret == ROK */
#endif
      }
         break;

      case STITNWK:
         /* range checking */
#if (ERRCLASS & ERRCLS_INT_PAR)
         if (cntrl->t.cntrl.s.nwkId >= itGlobalCb.genCfg.maxNmbNwk)
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT039, (ErrVal) cntrl->t.cntrl.s.nwkId,
                       "ItMiLitCntrlReq(): invalid nwkId, no NwkCb to delete");
            sta.reason  = LIT_REASON_INVALID_NWKID;
            ITZVUPDPEER();
            RETVALUE(RFAILED);
         }
         if ((itGlobalCb.nwk[cntrl->t.cntrl.s.nwkId] == (ItNwkCb *) NULLP) &&
               (action != ADEL))
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT040, (ErrVal) cntrl->t.cntrl.s.nwkId,
                       "ItMiLitCntrlReq(): invalid nwkId, no NwkCb to delete");
            sta.reason  = LIT_REASON_INVALID_NWKID;
            ITZVUPDPEER();
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */
         /* delete network entry specified by s.nwkId */
         ret = itAtDelNwk(cntrl->t.cntrl.s.nwkId, &sta, FALSE);
         break;

      case STITPS:
         /* delete PS specified by s.psId */
         ret = itPsmDelPs(cntrl->t.cntrl.s.psId, &sta, FALSE);
         break;
      case STITGRNSAP:
         {
            ItNSapCb   *sntSapCb;   /* SNT SAP CB */
            U16         i;          /* Index */
            Bool        match;      /* True if sctSap matches */
            ItDpcCb    *prevEnt;    /* previous DPC CB */
            ItDpcCb    *entry;      /* current DPC CB */
            ItRouteCb  *curRouteCb; /* current route CB */

            ret = ROK;
            for (i = 0; i < itGlobalCb.genCfg.maxNmbNSap; i++)
            {
               sntSapCb = itGlobalCb.nSap[i];
               if (sntSapCb != (ItNSapCb *)NULLP)
               {
                  /* Firstly check if this sap matches the groups criteria */
                  match = FALSE;
                  switch (subAction)
                  {
                     case SAGR_DSTPROCID:
                        if ((sntSapCb->pst.dstProcId == 
                             cntrl->t.cntrl.t.grp.dstProcId) &&
                            (sntSapCb->sntSta.hlSt == LIT_SAP_BOUND))
                        {
                           match = TRUE;
                        }
                        break;
                     case SAGR_ROUTE:
                        if (sntSapCb->sntCfg.route == 
                            cntrl->t.cntrl.t.grp.route)
                        {
                           match = TRUE;
                        }
                        break;
                     case SAGR_PRIORITY:
                        if (sntSapCb->sntCfg.prior == 
                            cntrl->t.cntrl.t.grp.priority)
                        {
                           match = TRUE;
                        }
                        break;
                     default:
                        break;
                  }

                  if (match == TRUE)
                  {
                     /* Check if the requested action can be performed       */
                     switch (action)
                     {
                     case ADEL:
                        /* delete NSAP specified by spId */
                        /* Check for dependent routes */
                        prevEnt = (ItDpcCb *)NULLP;
                        while (cmHashListGetNext(&itGlobalCb.addrTrn.dpcList,
                                                 (PTR) prevEnt, 
                                                 (PTR *) &entry) ==  ROK)
                        {
                           if (entry->nSap == sntSapCb)
                           {
                              /* return failed */
                              ITLOGERROR(ERRCLS_INT_PAR, EIT041, 
                                         (ErrVal) entry->dpc,
                                         "STITGRNSAP: SAP in use by route");
                              sta.reason = LIT_REASON_SERVICE_IN_USE;
                              sta.status = LCM_PRIM_NOK;
                              ret = RFAILED;
                           }
                           for (curRouteCb = 
                                (ItRouteCb *)cmLListFirst(&entry->routes);
                                curRouteCb;
                                curRouteCb = 
                                (ItRouteCb *)cmLListNext(&entry->routes))
                           {
                              if ((curRouteCb->rteCfg.nSapIdPres == TRUE) &&
                                  (curRouteCb->rteCfg.nSapId == 
                                   sntSapCb->sntCfg.sapId))
                              {
                                 /* return failed */
                                 ITLOGERROR(ERRCLS_INT_PAR, EIT042, (ErrVal) 0,
                                            "STITGRNSAP: SAP in use by route");
                                 sta.reason = LIT_REASON_SERVICE_IN_USE;
                                 sta.status = LCM_PRIM_NOK;
                                 ret = RFAILED;
                              }
                           }
                           prevEnt = entry;
                        } /* end while */
                     
                        /* search all global routes for nwkId match */
                        for (curRouteCb = 
                             (ItRouteCb *)
                             cmLListFirst(&itGlobalCb.addrTrn.rtList);
                             curRouteCb;
                             curRouteCb = 
                             (ItRouteCb *)
                             cmLListNext(&itGlobalCb.addrTrn.rtList))
                        {
                           if ((curRouteCb->rteCfg.nSapIdPres == TRUE) &&
                               (curRouteCb->rteCfg.nSapId == 
                                                sntSapCb->sntCfg.sapId))
                           {
                              /* return failed */
                              ITLOGERROR(ERRCLS_INT_PAR, EIT043, (ErrVal) 0,
                                         "STITGRNSAP: SAP in use by route");
                              sta.reason = LIT_REASON_SERVICE_IN_USE;
                              sta.status = LCM_PRIM_NOK;
                              ret = RFAILED;
                           }
                        }
                        break;
            
                     case AUBND:
                        break;
            
                     default:
#if (ERRCLASS & ERRCLS_INT_PAR)
                        ITLOGERROR(ERRCLS_INT_PAR, EIT044, (ErrVal) action,
                                       "ItMiLitCntrlReq(): Invalid action");
#endif /* ERRCLS_INT_PAR */
                        ret         = RFAILED;
                        sta.reason  = LCM_REASON_INVALID_ACTION;
                        break;
                     } /* end case STITSCTSAP */
                  }
               }
            }

            /* Now perform the actual action requested */
            for (i = 0; (i < itGlobalCb.genCfg.maxNmbNSap) &&
                        (ret == ROK); i++)
            {
               sntSapCb = itGlobalCb.nSap[i];
               if (sntSapCb != (ItNSapCb *)NULLP)
               {
                  /* Firstly check if this sap matches the groups criteria */
                  match = FALSE;
                  switch (subAction)
                  {
                     case SAGR_DSTPROCID:
                        if ((sntSapCb->pst.dstProcId == 
                             cntrl->t.cntrl.t.grp.dstProcId) &&
                            (sntSapCb->sntSta.hlSt == LIT_SAP_BOUND))
                        {
                           match = TRUE;
                        }
                        break;
                     case SAGR_ROUTE:
                        if (sntSapCb->sntCfg.route == 
                            cntrl->t.cntrl.t.grp.route)
                        {
                           match = TRUE;
                        }
                        break;
                     case SAGR_PRIORITY:
                        if (sntSapCb->sntCfg.prior == 
                            cntrl->t.cntrl.t.grp.priority)
                        {
                           match = TRUE;
                        }
                        break;

                     default:
                        break;
                  }

                  if (match == TRUE)
                  {
                     switch (action)
                     {
                        case ADEL:
                           /* delete NSAP */
                           ret = itUiDelSap(sntSapCb, &sta, FALSE);
                           break;
            
                        case AUBND:
                           /* unbind NSAP */
                           ret = itUiUBndSap(sntSapCb, &sta);
#ifdef ITSG
#ifndef SNT_BACK_COMP_MERGED_NIF
#ifdef IT_FTHA
                           if (ret == ROK)
                           {
                              sntSapCb->contEnt = ENTSM;
                           }
#endif /* IT_FTHA */
#endif /* SNT_BACK_COMP_MERGED_NIF */
#endif /* ITSG */
#ifdef ZV
                           if (ret == ROK)
                           {
                              /* SYNC update needs to be done before confirm can
                                 be sent to LM  */
                  
                               zvRTUpd(CMPFTHA_ACTN_MOD, ZV_NSAPCB,
                                     CMPFTHA_UPDTYPE_SYNC, (Void *) sntSapCb, 
                                       NULLP);
                           }
#endif
                           break;

#ifdef ITSG
#ifndef SNT_BACK_COMP_MERGED_NIF
                        case ABND:
                           /* bind MTP3 SAP */
                           if (sntSapCb->sntCfg.suType == LIT_SP_MTP3)
                           {
                              ret = itLiBndMtp3Sap(sntSapCb->sntCfg.sapId, &sta,
                                                   TRUE);
#ifdef IT_FTHA
                              if (ret == ROK)
                              {
                                 sntSapCb->contEnt = ENTNC;
                              }
#endif /* IT_FTHA */
#ifdef ZV
                              if (ret == ROK)
                              {
                                 /* SYNC update needs to be done before confirm
                                    can be sent to LM  */
                           
                                  zvRTUpd(CMPFTHA_ACTN_MOD, ZV_NSAPCB,
                                        CMPFTHA_UPDTYPE_SYNC, (Void *) sntSapCb,
                                          NULLP);
                              }
#endif
                           }
                           break;
#endif /* SNT_BACK_COMP_MERGED_NIF */
#endif /* ITSG */
                        default:
                           break;
            
                     } /* end case STITSCTSAP */
                  }
               }
            }
         }
         break;

      case STITGRSCTSAP:
         {
            ItSctSapCb *sctSapCb;   /* SCT SAP CB */
            U16         i;          /* Index */
            Bool        match;      /* True if sctSap matches */

            ret = ROK;
            for (i = 0; i < itGlobalCb.genCfg.maxNmbSctSap; i++)
            {
               sctSapCb = itGlobalCb.sctSap[i];
               if (sctSapCb != (ItSctSapCb *)NULLP)
               {
                  /* Firstly check if this sap matches the groups criteria */
                  match = FALSE;
                  switch (subAction)
                  {
                     case SAGR_DSTPROCID:
                        if (sctSapCb->sctCfg.procId == 
                            cntrl->t.cntrl.t.grp.dstProcId)
                        {
                           match = TRUE;
                        }
                        break;
                     case SAGR_ROUTE:
                        if (sctSapCb->sctCfg.route == 
                            cntrl->t.cntrl.t.grp.route)
                        {
                           match = TRUE;
                        }
                        break;
                     case SAGR_PRIORITY:
                        if (sctSapCb->sctCfg.prior == 
                            cntrl->t.cntrl.t.grp.priority)
                        {
                           match = TRUE;
                        }
                        break;
                     default:
                        break;
                  }

                  if (match == TRUE)
                  {
                     /* Check if the requested action can be performed */
                     switch (action)
                     {
                        case ABND:
                           /* No prerequisits for Binding */
                           break;
            
                        case AUBND:
                           /* No prerequisites for unbinding */
                           break;
            
                        case ADEL:
                           /* delete SCT SAP specified by suId */
                           if (sctSapCb->sctSta.hlSt != LIT_SAP_UNBOUND)
                           {
                              sta.status = LCM_PRIM_NOK;
                              sta.reason = LIT_REASON_SERVICE_IN_USE;
                              ret = RFAILED;
                           }
                           break;
            
                        default:
#if (ERRCLASS & ERRCLS_INT_PAR)
                           ITLOGERROR(ERRCLS_INT_PAR, EIT045, (ErrVal) action,
                                       "ItMiLitCntrlReq(): Invalid action");
#endif /* ERRCLS_INT_PAR */
                           ret         = RFAILED;
                           sta.reason  = LCM_REASON_INVALID_ACTION;
                           break;
                     } /* end case STITSCTSAP */
                  }
               }
            }

            /* Now perform the actual action requested */
            for (i = 0; (i < itGlobalCb.genCfg.maxNmbSctSap) &&
                        (ret == ROK); i++)
            {
               sctSapCb = itGlobalCb.sctSap[i];
               if (sctSapCb != (ItSctSapCb *)NULLP)
               {
                  /* Firstly check if this sap matches the groups criteria */
                  match = FALSE;
                  switch (subAction)
                  {
                     case SAGR_DSTPROCID:
                        if (sctSapCb->sctCfg.procId == 
                            cntrl->t.cntrl.t.grp.dstProcId)
                        {
                           match = TRUE;
                        }
                        break;
                     case SAGR_ROUTE:
                        if (sctSapCb->sctCfg.route == 
                            cntrl->t.cntrl.t.grp.route)
                        {
                           match = TRUE;
                        }
                        break;
                     case SAGR_PRIORITY:
                        if (sctSapCb->sctCfg.prior == 
                            cntrl->t.cntrl.t.grp.priority)
                        {
                           match = TRUE;
                        }
                        break;
                     default:
                        break;
                  }

                  if (match == TRUE)
                  {
                     switch (action)
                     {
                        case ABND:
                           /* bind SCT SAP specified by suId */
                           ret = itLiBndSap(i, &sta, TRUE);
#ifdef IT_FTHA           
                           itGlobalCb.sctSap[i]->contEnt = 
                              ENTNC;
#endif /* IT_FTHA */
#ifdef ZV
                           if (ret == ROK)
                           {
                              zvRTUpd(CMPFTHA_ACTN_MOD, ZV_SCTSAPCB,
                                     CMPFTHA_UPDTYPE_SYNC, 
                                     (Void *)itGlobalCb.sctSap[i], NULLP);
                           }
#endif
                           break;
            
                        case AUBND:
                           /* unbind SCT SAP specified by suId */
                           ret = itLiReleaseSap(i, &sta);
#ifdef IT_FTHA    
                           itGlobalCb.sctSap[i]->contEnt = 
                              ENTSM;
#endif /* IT_FTHA */
#ifdef ZV
                           if (ret == ROK)
                           {
                              zvRTUpd(CMPFTHA_ACTN_MOD, ZV_SCTSAPCB,
                                     CMPFTHA_UPDTYPE_SYNC, 
                                     (Void *)itGlobalCb.sctSap[i], NULLP);
                           }
#endif
                           break;
            
                        case ADEL:
                           /* delete SCT SAP specified by suId */
                           ret = itLiDelSap(i, 
                                            &sta, FALSE);
                           break;

                        default:
                           break;
            
                     } /* end case STITSCTSAP */
                  }
               }
            }
         }
         break;
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT046, (ErrVal) hdr->elmId.elmnt,
                    "ItMiLitCntrlReq(): Invalid element");
#endif /* ERRCLS_INT_PAR */
         /* element must be one of the above */
         ret = RFAILED;
         /* force a valid elmnt in order to be able to return status
            and reason */
         cntrl->hdr.elmId.elmnt  = STITGEN;
         sta.reason              = LCM_REASON_INVALID_ELMNT;
         break;
   } /* end switch */

    

   itGlobalCb.mgmt.t.cntrl.subAction = subAction;
   itGlobalCb.mgmt.t.cntrl.action = action;

   /* send control confirm */
   if (ret == ROK)
   {
      sta.status = LCM_PRIM_OK;
      sta.reason = LCM_REASON_NOT_APPL;
   }
   else
   {
      sta.status = LCM_PRIM_NOK;
      /* sta.reason is set above according to the type of failure */
   }
   ITZVUPDPEER();
   itMiSendLmCfm(pst, TCNTRL, hdr, sta.status, sta.reason);

   RETVALUE(ret);
} /* end of ItMiLitCntrlReq */



/*
*
*       Fun:   ItMiLitStaReq
*
*       Desc:  The layer manager sends status requests to the M3UA layer
*              to get the status of protocol elements of the M3UA layer.
*              The protocol element is identified by the hdr.elmId.elmnt
*              parameter.
*
*       Ret:   Success: ROK
*              Failure: RFAILED
*
*       Notes: <none>
*
*       File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItMiLitStaReq
(
Pst      *pst,                /* post structure */
ItMgmt   *sta                 /* status structure */
)
#else
PUBLIC S16 ItMiLitStaReq(pst, sta)
Pst      *pst;                /* post structure */
ItMgmt   *sta;                /* status structure */
#endif
{
   Header       *hdr;                     /* Header structure */
   ItNSapCb     *nSap;                    /* SAP pointer */
   SpId         spId;                     /* spId */
   ItSctSapCb   *sctSap;                  /* SAP pointer */
   SuId         suId;                     /* suId */
   ItPsId       psId;                     /* psId */
   ItPsCb       *psCb = (ItPsCb *)NULLP;  /* psCb pointer */
   ItPspId      pspId;                    /* pspId */
   ItPspCb      *pspCb;                   /* pspCb pointer */
   ItAssocCb    *assocCb;                 /* assocCb pointer */
   CmStatus     status;                   /* Status */


   TRC3(ItMiLitStaReq)

#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItMiLitStaReq() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_MI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#endif /* SS_MULTIPLE_PROCS */


   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
           "ItMiLitStaReq(pst, elmnt(%d))\n", sta->hdr.elmId.elmnt));

   /* obtain the header structure from the configuration */
   hdr = &(sta->hdr);

   /* zero out the confirm structure */
   IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt));

   /* check if general configuration done */
#if (ERRCLASS & ERRCLS_DEBUG)
   if (itGlobalCb.itInit.cfgDone != TRUE)
   {
      ITLOGERROR(ERRCLS_DEBUG, EIT047, (ErrVal) NULLD,
                 "ItMiLitStaReq: General Configuration not done");
      itMiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_NOK, 
                    LCM_REASON_GENCFG_NOT_DONE);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_DEBUG */

   
   switch (hdr->elmId.elmnt)
   {
      case STITSID:
         /* get the system id information */
         (Void) itGetSid(&itGlobalCb.mgmt.t.ssta.s.sysId);
         break;

      case STITGEN:
         /* copy the general status from the control block */
         cmMemcpy((U8 *) &itGlobalCb.mgmt.t.ssta.s.genSta, 
                  (U8 *) &itGlobalCb.genSta, sizeof(ItGenSta));
         break;

      case STITNSAP:
         /* get the spId to look up status for */
         spId = sta->t.ssta.s.nSapSta.lclSapId;

         /* validate the sapId */
#if (ERRCLASS & ERRCLS_INT_PAR)
         if ((spId >= (SpId) itGlobalCb.genCfg.maxNmbNSap) || (spId < 0))
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT048, (ErrVal) spId,
                  "ItMiLitStaReq(): spId out of range");
            itMiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_NOK,
                  LCM_REASON_INVALID_SAP);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */

         /* get the SNT SAP control block */
         nSap = itGlobalCb.nSap[spId];

#if (ERRCLASS & ERRCLS_INT_PAR)
         /* check to see if the SAP exists */
         if (nSap == (ItNSapCb *) NULLP)
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT049, (ErrVal) spId,
                  "ItMiLitStaReq(): Sap not configured");
            itMiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_NOK,
                  LCM_REASON_INVALID_SAP);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */

#ifdef IT_RUG
         nSap->sntSta.selfIntfVer = SNTIFVER;
         nSap->sntSta.remIntfValid = nSap->remIntfValid;
         nSap->sntSta.remIntfVer = nSap->pst.intfVer;
#endif /* IT_RUG */
         /* copy nSapSta across */
         cmMemcpy((U8 *)&itGlobalCb.mgmt.t.ssta.s.nSapSta, 
                  (U8 *) &(nSap->sntSta), sizeof(ItNSapSta));
         break;

      case STITSCTSAP:
         /* get the suId to look up status for */
         suId = sta->t.ssta.s.sctSapSta.suId;

         /* validate the sapId */
#if (ERRCLASS & ERRCLS_INT_PAR)
         if ((suId >= (SuId) itGlobalCb.genCfg.maxNmbSctSap) || (suId < 0))
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT050, (ErrVal) suId,
                  "ItMiLitStaReq(): suId out of range");
            itMiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_NOK,
                  LCM_REASON_INVALID_SAP);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */
         /* get the SCT SAP control block */
         sctSap = itGlobalCb.sctSap[suId];

            /* check to see if the SAP exists */
#if (ERRCLASS & ERRCLS_INT_PAR)
         if (sctSap == (ItSctSapCb *) NULLP)
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT051, (ErrVal) suId,
                  "ItMiLitStaReq(): Sap not configured");
            itMiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_NOK,
                  LCM_REASON_INVALID_SAP);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */
         /* copy sctSapSta across */
         /* it017.106 - Copy srcAddrLst. */
#ifdef LITV4
         cmMemcpy((U8 *)&sctSap->sctSta.srcAddrLst, 
                  (U8 *)&sctSap->sctCfg.srcAddrLst, sizeof(SctNetAddrLst));
#endif /* LITV4 */
#ifdef IT_RUG
         /* it001.106 - SCT SAP version information updated in correct
          * structure */
         sctSap->sctSta.selfIntfVer = SCTIFVER;
         sctSap->sctSta.remIntfValid = sctSap->remIntfValid;
         sctSap->sctSta.remIntfVer = sctSap->pst.intfVer;
#endif /* IT_RUG */
         cmMemcpy((U8 *)&itGlobalCb.mgmt.t.ssta.s.sctSapSta, 
                  (U8 *) &(sctSap->sctSta), sizeof(ItSctSapSta));

         break;

      case STITADRTRAN:
         /* copy the AT status from the control block */
         cmMemcpy((U8 *)&itGlobalCb.mgmt.t.ssta.s.atSta,
               (U8 *) &itGlobalCb.addrTrn.atSta, sizeof(ItAtSta));
         break;

      case STITPS:
         /* get psCb */
         psId = sta->t.ssta.s.psSta.psId;
         /* Initialize psCb */
         if ((psCb = itPsmFindPs(psId)) != (ItPsCb *) NULLP)
         {
            /* found */
            /* it017.106 - Changes to pack ItSstaPs structure
             * under compilaion flag LITV4 */
#ifndef LITV4
            cmMemcpy((U8 *)&itGlobalCb.mgmt.t.ssta.s.psSta, 
                     (U8 *) &(psCb->psSta), sizeof(ItPsSta));
#endif /* LITV4 */
#ifdef LITV4
            {
               ItSstaPs *sstaPs;
               SuId         i;            /* loop index */
               U16          j;            /* loop index */

               sstaPs = &itGlobalCb.mgmt.t.ssta.s.psSta;
               sstaPs->psId = psCb->psSta.psId;
               sstaPs->asSt = psCb->psSta.asSt;
               for (i = 0; i < LIT_MAX_SEP; i++)
               {
                  sstaPs->sstaPsEndp[i].nmbAct = psCb->psSta.psStaEndp[i].nmbAct;
                  sstaPs->sstaPsEndp[i].nmbPspReg = psCb->psSta.psStaEndp[i].nmbPspReg;
                  sstaPs->sstaPsEndp[i].nmbPsp = psCb->psCfg.nmbPsp;
                  for (j = 0; j < psCb->psSta.psStaEndp[i].nmbAct; j++)
                  {
                     sstaPs->sstaPsEndp[i].actPsp[j] = psCb->psSta.psStaEndp[i].actPsp[j];
                  }
                  for (j = 0; j < psCb->psCfg.nmbPsp; j++)
                  {
                     pspId = psCb->psCfg.psp[j];
                     sstaPs->sstaPsEndp[i].pspSt[j].pspId = pspId;
                     sstaPs->sstaPsEndp[i].pspSt[j].aspSt = psCb->psSta.psStaEndp[i].aspSt[pspId];
                     sstaPs->sstaPsEndp[i].pspSt[j].rCtx = psCb->psSta.psStaEndp[i].rteCtx[pspId].rCtx;
                     sstaPs->sstaPsEndp[i].pspSt[j].rcValid = psCb->psSta.psStaEndp[i].rteCtx[pspId].rcValid;
                     /* it019.106 - Update routing context mode in PS status. */
                     sstaPs->sstaPsEndp[i].pspSt[j].mode = psCb->psSta.psStaEndp[i].rteCtx[pspId].mode;
                  }
               } /* for LIT_MAX_SEP */
            }
#endif /* LITV4 */
         }
         else
         {
            /* not found */
#if (ERRCLASS & ERRCLS_INT_PAR)
            ITLOGERROR(ERRCLS_INT_PAR, EIT052, (ErrVal) hdr->elmId.elmnt,
            "ItMiLitStaReq(): Invalid Hashkey in ASSTA req.");
#endif /* ERRCLS_INT_PAR */
            itMiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_NOK,
                   LCM_REASON_HASHING_FAILED);
            RETVALUE(RFAILED);
         } /* end if cmHashListFind */
         break;

      case STITPSP:
         /* get the pspId to look up status for */
         pspId = sta->t.ssta.s.pspSta.pspId;

#if (ERRCLASS & ERRCLS_INT_PAR)
         /* validate the pspId */
         if (pspId >= (ItPspId) itGlobalCb.genCfg.maxNmbPsp)
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT053, (ErrVal) pspId,
                  "ItMiLitStaReq(): pspId out of range");
            itMiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_NOK,
                          LIT_REASON_INVALID_PSPID);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */
         
         /*  Get the PSP CB */
         pspCb = itGlobalCb.psp[pspId];

#if (ERRCLASS & ERRCLS_INT_PAR)
         /* check to see if the PSP exists */
         if (pspCb == (ItPspCb *) NULLP)
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT054, (ErrVal) pspId,
                  "ItMiLitStaReq(): PSP not configured");
            itMiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_NOK,
                          LIT_REASON_INVALID_PSPID);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */
         /* copy status across to itGlobalCb.mgmt */
         cmMemcpy((U8 *) &itGlobalCb.mgmt.t.ssta.s.pspSta, 
                  (U8 *) &(pspCb->pspSta), sizeof(ItPspSta));
         break;
         
      case STITPSPRKID:
      {
         /* get the pspId to look up status for */
         pspId = sta->t.ssta.s.pspRkIdSta.pspId;
         suId  = sta->t.ssta.s.pspRkIdSta.sctSuId;

#if (ERRCLASS & ERRCLS_INT_PAR)
         /* validate the pspId */
         if (pspId >= (ItPspId) itGlobalCb.genCfg.maxNmbPsp)
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT055, (ErrVal) pspId,
                  "ItMiLitStaReq(): pspId out of range");
            itMiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_NOK,
                          LIT_REASON_INVALID_PSPID);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */
         
         /*  Get the PSP CB */
         pspCb = itGlobalCb.psp[pspId];

#if (ERRCLASS & ERRCLS_INT_PAR)
         /* check to see if the PSP exists */
         if (pspCb == (ItPspCb *) NULLP)
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT056, (ErrVal) pspId,
                  "ItMiLitStaReq(): PSP not configured");
            itMiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_NOK,
                          LIT_REASON_INVALID_PSPID);
            RETVALUE(RFAILED);
         }
         /* check to see if the SCT SAP exists */
         if (itGlobalCb.sctSap[suId] == (ItSctSapCb *) NULLP)
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT057, (ErrVal) pspId,
                  "ItMiLitStaReq(): SCT SAP not configured");
            itMiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_NOK,
                          LIT_REASON_INVALID_PSPID);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */
         assocCb = itGlobalCb.assoc[IT_PSPnENDP2ASSOC(pspId, suId)];
         /* copy status across to itGlobalCb.mgmt */
         itGlobalCb.mgmt.t.ssta.s.pspRkIdSta.pspId = pspId;
         /* it002.106 - Copy sctSuId in itGlobalCb.mgmt */
         itGlobalCb.mgmt.t.ssta.s.pspRkIdSta.sctSuId = suId;
         itGlobalCb.mgmt.t.ssta.s.pspRkIdSta.nmbRkReqPend = 
                              assocCb->regReqTmrCb[0].req.regReq.nmbLclRkId;
         cmMemcpy((U8 *) &itGlobalCb.mgmt.t.ssta.s.pspRkIdSta.lclRkId, 
                  (U8 *) &(assocCb->regReqTmrCb[0].req.regReq.localRkId),
                          (sizeof(U32) * LIT_MAX_RK_IN_DRKM));

      }
      break;
      
      case STITRK:
         /* copy the RK status from the addrTrn control block */
         cmMemcpy((U8 *)&itGlobalCb.mgmt.t.ssta.s.rkSta,
               (U8 *) &itGlobalCb.addrTrn.rkSta, sizeof(ItRkSta));
         break;

      case STITAPC:
         /* copy the DPC status from the dpcCb control block */
         {
            U32      tmphlKey;         /* temporary hash list key */
            ItDpcCb  *tmpDpcCb;        /* temporary DPC CB */
            
            tmphlKey = ((U32) sta->t.ssta.s.dpcSta.nwkId << 24) | 
                                  sta->t.ssta.s.dpcSta.dpc;
            if (cmHashListFind(&itGlobalCb.addrTrn.dpcList, (U8 *) &tmphlKey,
                      sizeof(tmphlKey), 0, (PTR *) &tmpDpcCb) != ROK)
            {
               /* if hash key not found return Failure */
               /* it001.106 - Added the error logging. */
            ITLOGERROR(ERRCLS_INT_PAR, EITXXX, 
                  (ErrVal) sta->t.ssta.s.dpcSta.dpc,
                  "ItMiLitStaReq(): Invalid DPC and network ID");
               itMiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_NOK,
                          LIT_REASON_INVALID_DPC);
               RETVALUE(RFAILED);
            }
            else
            {
               /* hash key found */
               switch (tmpDpcCb->dpcSt)
               {
                  case IT_DPC_UNKNOWN:
                     sta->t.ssta.s.dpcSta.dpcSt = LIT_DPC_UNKNOWN;
                     break;
                  case IT_DPC_AVAILABLE:
                     sta->t.ssta.s.dpcSta.dpcSt = LIT_DPC_AVAILABLE;
                     break;
                  /* it001.106 - Removed the case for IT_DPC_CONGESTED 
                   * because DPC status is never marked IT_DPC_CONGESTED. 
                   * In case of Congestion the congLevel field in DPC cb 
                   * is updated */
                  /*
                  case IT_DPC_CONGESTED:
                     sta->t.ssta.s.dpcSta.dpcSt = LIT_DPC_CONGESTED;
                     break;
                  */
                  case IT_DPC_UNAVAILABLE:
                     sta->t.ssta.s.dpcSta.dpcSt = LIT_DPC_UNAVAILABLE;
                     break;
                  case IT_DPC_RESTRICTED:
                     sta->t.ssta.s.dpcSta.dpcSt = LIT_DPC_RESTRICTED;
                     break;
                  default: 
                     break;
               }
               sta->t.ssta.s.dpcSta.congLevel = tmpDpcCb->congLevel;

               /* it001.106 - Update the dpcSt as LIT_DPC_CONGESTED if DPC
                * congestion is greater than SN_PRI0.  */
               if (tmpDpcCb->congLevel > SN_PRI0)
               {
                  sta->t.ssta.s.dpcSta.dpcSt = LIT_DPC_CONGESTED;
               }

               /* it001.106 - Update the itGlobalCb.mgmt structure */
               cmMemcpy((U8 *)&itGlobalCb.mgmt.t.ssta.s.dpcSta, 
                        (U8 *) &(sta->t.ssta.s.dpcSta), sizeof(ItDpcSta));
            } /* end if (cmHashListFind) */
         }
         break;

      case STITNWK:
         /* copy the Network status from the nwk control block */
         if (itGlobalCb.nwk[sta->t.ssta.s.nwkId] == (ItNwkCb *) NULLP)
         {
            itMiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_NOK,
                          LIT_REASON_INVALID_NWKID);
            RETVALUE(RFAILED);
         }
         break;

      case STITROUT:
         if (itAtCfgRout(&sta->t.ssta.s.rteSta, &status, TRUE)  == RFAILED)
         {
            itMiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_NOK,
                          LIT_REASON_INVALID_RTENT);
            RETVALUE(RFAILED);
         }
         break;

      default:

#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT058, (ErrVal) hdr->elmId.elmnt,
               "ItMiLitStaReq(): Invalid Element in Status request");
#endif /* ERRCLS_INT_PAR */
         itMiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_NOK,
               LCM_REASON_INVALID_ELMNT);
         RETVALUE(RFAILED);
      break;
   } /* end switch */

   /* fill the date and time */
   SGetDateTime(&itGlobalCb.mgmt.t.ssta.dt);

   /* issue a status confirm to the Layer Manager */
   itMiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_OK, LCM_REASON_NOT_APPL);

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
                       "ItMiLitStaReq(): after sending LmCfm\n"));

   RETVALUE(ROK);
} /* end of ItMiLitStaReq */


/*
*
*       Fun:   ItMiLitStsReq
*
*       Desc:  The layer manager sends statistics requests to the M3UA
*              layer to dynamically get the statistical information from
*              the M3UA layer.
*
*       Ret:   Success: ROK
*              Failure: RFAILED
*
*       Notes: <none>
*
*       File:  it_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 ItMiLitStsReq
(
Pst      *pst,                /* post structure */
Action   action,              /* action to be taken by M3UA */
ItMgmt   *sts                 /* status structure */
)
#else
PUBLIC S16 ItMiLitStsReq(pst, action, sts)
Pst      *pst;                /* post structure */
Action   action;              /* action to be taken by M3UA */
ItMgmt   *sts;                /* status structure */
#endif
{
   Header       *hdr;         /* Header structure */
   DateTime     currentTime;  /* current date and time*/
   ItNSapCb     *nSap;        /* nSap pointer */
   SpId         spId;         /* spId */
   ItSctSapCb   *sctSap;      /* sctSap pointer */
   SuId         suId;         /* spId */
   ItPspCb      *pspCb;       /* pspCb pointer */
   ItPspId      pspId;        /* pspId */
#if (defined(LITV3) || defined(LITV6))
   S16          ret;          /* return code */
   Ticks        curTime;      /* current timestamp */
   Ticks        dur;          /* time duration */
#endif /* LITV3 || LITV6 */
#ifdef LITV3
   SuId         i;            /* loop index */
   ItAssocCb    *assocCb;     /* assocCb pointer */
#endif /* LITV3 */
#ifdef LITV6
   ItPsId        psId;        /* Peer Server ID */
   ItPsCb       *psCb = (ItPsCb *)NULLP;   /* PS control block */
#endif /* LITV6 */

   TRC3(ItMiLitStsReq)

#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItMiLitStsReq() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_MI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#endif /* SS_MULTIPLE_PROCS */


   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
               "ItMiLitStsReq(pst, action(%d), elmnt(%d))\n",
               action, sts->hdr.elmId.elmnt));

   /* obtain the header structure from the configuration */
   hdr = &(sts->hdr);

   /* zero out the confirm structure */
   IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt));

   /* check if general configuration done */
#if (ERRCLASS & ERRCLS_DEBUG)
   if (itGlobalCb.itInit.cfgDone != TRUE)
   {
      ITLOGERROR(ERRCLS_DEBUG, EIT059, (ErrVal) NULLD,
                 "ItMiLitStsReq: General Configuration not done");
      itMiSendLmCfm(pst, TSTS, hdr, LCM_PRIM_NOK, 
                    LCM_REASON_GENCFG_NOT_DONE);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_DEBUG */
   
   switch (hdr->elmId.elmnt)
   {
      case STITGEN:               /* general statistics */
         /* copy the general statistics from the control block */
         cmMemcpy((U8 *)&itGlobalCb.mgmt.t.sts.u.genSts, 
                  (U8 *) &itGlobalCb.genSts, sizeof(ItGenSts));

         if (action == ZEROSTS)
         {
            /* zero out the stored statistics */
            IT_ZERO(&itGlobalCb.genSts, sizeof(ItGenSts));
            /* set time for zeroing action */
            SGetDateTime(&itGlobalCb.genSts.dt);
         }
         break;

      case STITNSAP:              /* sap statistics */
         /* get spId */
         spId = sts->t.sts.u.sntSts.spId;

#if (ERRCLASS & ERRCLS_INT_PAR)
         if ((spId >= (SpId) itGlobalCb.genCfg.maxNmbNSap) || (spId < 0))
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT060, (ErrVal) spId,
                  "ItMiLitStsReq(): spId out of range");
            itGlobalCb.mgmt.t.sts.u.sntSts.spId = spId;
            itMiSendLmCfm(pst, TSTS, hdr, LCM_PRIM_NOK,
                  LCM_REASON_INVALID_SAP);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */
         /* use spId to find corresponding nSapCb */
         nSap = itGlobalCb.nSap[spId];

#if (ERRCLASS & ERRCLS_INT_PAR)
         if (nSap == (ItNSapCb *) NULLP)
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT061,
                  (ErrVal) sts->t.sts.u.sntSts.spId,
                  "ItMiLitStsReq(): SAP not configured");
            itGlobalCb.mgmt.t.sts.u.sntSts.spId = spId;
            itMiSendLmCfm(pst, TSTS, hdr, LCM_PRIM_NOK,
                  LCM_REASON_INVALID_SAP);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */

         /* copy the statistics from the sap to the management structure */
         cmMemcpy((U8 *) &itGlobalCb.mgmt.t.sts.u.sntSts, (U8 *) &nSap->sntSts,
               sizeof(ItNSapSts));
         if (action == ZEROSTS)
         {
            /* zero out the stored statistics in the sap structure */
            IT_ZERO(&nSap->sntSts, sizeof(ItNSapSts));
            /* set time for zeroing action */
            SGetDateTime(&(nSap->sntSts.dt));
            nSap->sntSts.spId = spId;
         }
         break;

      case STITSCTSAP:
         /* get the suId to look up statistics for */
         suId = sts->t.sts.u.sctSts.suId;

         /* validate the sapId */
#if (ERRCLASS & ERRCLS_INT_PAR)
         if ((suId >= (SuId) itGlobalCb.genCfg.maxNmbSctSap) || (suId < 0))
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT062, (ErrVal) suId,
                  "ItMiLitStsReq(): suId out of range");
            itGlobalCb.mgmt.t.sts.u.sctSts.suId = suId;
            itMiSendLmCfm(pst, TSTS, hdr, LCM_PRIM_NOK,
                  LCM_REASON_INVALID_SAP);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */
         /* get the SCT SAP control block */
         sctSap = itGlobalCb.sctSap[suId];

            /* check to see if the SAP exists */
#if (ERRCLASS & ERRCLS_INT_PAR)
         if (sctSap == (ItSctSapCb *) NULLP)
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT063, (ErrVal) suId,
                  "ItMiLitStsReq(): Sap not configured");
            itGlobalCb.mgmt.t.sts.u.sctSts.suId = suId;
            itMiSendLmCfm(pst, TSTS, hdr, LCM_PRIM_NOK,
                  LCM_REASON_INVALID_SAP);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */
         /* copy the statistics from the sap to the management structure */
         cmMemcpy((U8 *) &itGlobalCb.mgmt.t.sts.u.sctSts, 
                  (U8 *) &sctSap->sctSts, sizeof(ItSctSapSts));
         if (action == ZEROSTS)
         {
            /* zero out the stored statistics in the sap structure */
            IT_ZERO(&sctSap->sctSts, sizeof(ItSctSapSts));
            /* set time for zeroing action */
            SGetDateTime(&(sctSap->sctSts.dt));
            sctSap->sctSts.suId = suId;
         }

         break;

      case STITPSP:                 /* sap statistics */
         /* get pspId */
         pspId = sts->t.sts.u.pspSts.pspId;

#if (ERRCLASS & ERRCLS_INT_PAR)
         /* check if pspId valid */
         if ((U16) pspId >= (U16) itGlobalCb.genCfg.maxNmbPsp)
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT064, (ErrVal) pspId,
                  "ItMiLitStaReq(): pspId out of range");
            itGlobalCb.mgmt.t.sts.u.pspSts.pspId = pspId;
            itMiSendLmCfm(pst, TSTS, hdr, LCM_PRIM_NOK,
                          LIT_REASON_INVALID_PSPID);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */
         
         /*  Get the PSP CB */
         pspCb = itGlobalCb.psp[pspId];

#if (ERRCLASS & ERRCLS_INT_PAR)
         /* check to see if the PSP exists */
         if (pspCb == (ItPspCb *) NULLP)
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT065, (ErrVal) pspId,
                  "ItMiLitStsReq(): PSP not configured");
            itGlobalCb.mgmt.t.sts.u.pspSts.pspId = pspId;
            itMiSendLmCfm(pst, TSTS, hdr, LCM_PRIM_NOK,
                          LIT_REASON_INVALID_PSPID);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */

         /* it016.106 - Extract the durUnav and durCong statistics. */
#ifdef LITV3
         for (i = 0; i < LIT_MAX_SEP; i++)
         {
            assocCb  = &(pspCb->assoc[i]);
            if (assocCb->ticksUnav)
            {
               ret = SGetSysTime(&curTime);
               if (ret != ROK)
               {
#if (ERRCLASS & ERRCLS_DEBUG)
                  ITLOGERROR(ERRCLS_DEBUG, EITXXX, (ErrVal) ret, 
                             "ItMiLitStsReq: SGetSysTime failed");
#endif /* ERRCLS_DEBUG */
                  assocCb->ticksUnav = 0;
               }
               else
               {
                  dur = curTime - assocCb->ticksUnav;
                  IT_STS_UPD_ASSOC_DUR_UNAV(assocCb, dur);
                  assocCb->ticksUnav = curTime;
               }
            }

            if (assocCb->ticksCong)
            {
               ret = SGetSysTime(&curTime);
               if (ret != ROK)
               {
#if (ERRCLASS & ERRCLS_DEBUG)
                  ITLOGERROR(ERRCLS_DEBUG, EITXXX, (ErrVal) ret, 
                             "ItMiLitStsReq: SGetSysTime failed");
#endif /* ERRCLS_DEBUG */
                  assocCb->ticksCong = 0;
               }
               else
               {
                  dur = curTime - assocCb->ticksCong;
                  IT_STS_UPD_ASSOC_DUR_CONG(assocCb, dur);
                  assocCb->ticksCong = curTime;
               }
            }
         } /* end of for */
#endif /* LITV3 */

         /* copy the statistics from the PSP to the management structure */
         cmMemcpy((U8 *) &itGlobalCb.mgmt.t.sts.u.pspSts, 
                  (U8 *) &(pspCb->pspSts), sizeof(ItPspSts));
         if (action == ZEROSTS)
         {
            /* zero out the stored statistics in the PSP structure */
            IT_ZERO(&(pspCb->pspSts), sizeof(ItPspSts));
            /* set time for zeroing action */
            SGetDateTime(&(pspCb->pspSts.dt));
            pspCb->pspSts.pspId = pspId;
         }
         break;

      /* it023.106 - PS statistics */
#ifdef LITV6
      case STITPS:                 /* PS statistics */
         /* get psId */
         psId = sts->t.sts.u.psSts.psId;

         if ((psCb = itPsmFindPs(psId)) == (ItPsCb *) NULLP)
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            ITLOGERROR(ERRCLS_INT_PAR, EITXXX, (ErrVal) psId,
                  "ItMiLitStaReq(): Invalid psId");
#endif /* ERRCLS_INT_PAR */
            itGlobalCb.mgmt.t.sts.u.psSts.psId = psId;
            itMiSendLmCfm(pst, TSTS, hdr, LCM_PRIM_NOK,
                          LIT_REASON_INVALID_PSID);
            RETVALUE(RFAILED);
         }

         /* Extract the durUnav statistics. */
         if (psCb->ticksUnav)
         {
            ret = SGetSysTime(&curTime);
            if (ret != ROK)
            {
#if (ERRCLASS & ERRCLS_DEBUG)
               ITLOGERROR(ERRCLS_DEBUG, EITXXX, (ErrVal) ret, 
                          "ItMiLitStsReq: SGetSysTime failed");
#endif /* ERRCLS_DEBUG */
               psCb->ticksUnav = 0;
            }
            else
            {
               dur = curTime - psCb->ticksUnav;
               IT_STS_UPD_PS_DUR_UNAV(psCb, dur);
               psCb->ticksUnav = curTime;
            }
         }

         /* copy the statistics from the PS to the management structure */
         cmMemcpy((U8 *) &itGlobalCb.mgmt.t.sts.u.psSts, 
                  (U8 *) &(psCb->psSts), sizeof(ItPsSts));
         if (action == ZEROSTS)
         {
            /* zero out the stored statistics in the PS structure */
            IT_ZERO(&(psCb->psSts), sizeof(ItPsSts));
            /* set time for zeroing action */
            SGetDateTime(&(psCb->psSts.dt));
            psCb->psSts.psId = psId;
         }
         break;
#endif /* LITV6 */

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT066, (ErrVal) hdr->elmId.elmnt,
               "ItMiLitStsReq(): Invalid Element in statistics request");
#endif /* ERRCLS_INT_PAR */
         itMiSendLmCfm(pst, TSTS, hdr, LCM_PRIM_NOK,
               LCM_REASON_INVALID_ELMNT);
         RETVALUE(RFAILED);
   } /* end of switch statement */

   /* get the date and time for when the confirm message is generated */
   SGetDateTime(&currentTime);

   /* determine the duration since the last statistics request */
   (Void) itMiDetDuration((DateTime *) &(itGlobalCb.mgmt.t.sts.dt),
            &currentTime, &itGlobalCb.mgmt.t.sts.dura);

   /* set the current date/time */
   cmMemcpy((U8 *) &(itGlobalCb.mgmt.t.sts.dt), (U8 *) &currentTime, 
            sizeof(DateTime));


   /* Issue a statistics confirm */
   itMiSendLmCfm(pst, TSTS, hdr, LCM_PRIM_OK, LCM_REASON_NOT_APPL);

   RETVALUE(ROK);
} /* end of ItMiLitStsReq */


/* ------------------------------------------------------------------*
 * Interface Functions for Upper Interface                           *
 * ------------------------------------------------------------------*/


/*
*
*       Fun:   Bind Request
*
*       Desc:  This function binds the MTP3 user with the M3UA service
*              provider. The MTP software finds the preconfigured
*              Service Access Point (SAP) for this bind. The service
*              user specifies the reference number that will be used
*              for the duration of this bind. The Control Block for
*              the service provider is the NSAP CB
*
*       Ret:   ROK   - ok
*
*       Notes: <None>
*
*       File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItUiSntBndReq
(
Pst       *pst,               /* bind configuration */
SuId      suId,               /* service user id */
SpId      spId,               /* service provider id */
SrvInfo   srvInfo             /* service information */
)                             
#else                         
PUBLIC S16 ItUiSntBndReq(pst, suId, spId, srvInfo)
Pst       *pst;               /* bind configuration */
SuId      suId;               /* service user id */
SpId      spId;               /* service provider id */
SrvInfo   srvInfo;            /* service information */
#endif
{
   ItNSapCb *cb;              /* upper SAP CB */
#ifdef IT_RUG
   Bool found;
   U16 i;
#endif /* IT_RUG */
   S16 ret;

   TRC3(ItUiSntBndReq)
   ret = ROK;

#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItUiSntBndReq() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_UI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#endif /* SS_MULTIPLE_PROCS */

  ITADDZVUPDPEERCTR()

   ITDBGP(DBGMASK_UI, (itGlobalCb.itInit.prntBuf, 
      "ItUiSntBndReq(suId (%d), spId (%d), srvInfo (%d))\n",
      suId, spId, srvInfo));

#if (ERRCLASS & ERRCLS_INT_PAR)
   ITCHKPROTSTATE(EIT067, STITNSAP, spId, ret, IT_EVENT_CRIT);
   if (ret != ROK) 
   {
      ITZVUPDPEER();
      RETVALUE(ret);
   }
   
   if ((spId < 0) || (spId >= (SpId) itGlobalCb.genCfg.maxNmbNSap))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT068, (ErrVal) spId, 
         "ItUiSntBndReq invalid spId");
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
         LCM_CAUSE_INV_SPID, (U32)spId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   /* get Sap control block */
   cb = itGlobalCb.nSap[spId];

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (cb == (ItNSapCb *)NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT069, (ErrVal) spId, 
         "ItUiSntBndReq SAP unconfigured");
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                 LCM_CAUSE_INV_SPID, (U32)spId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (IT_SRVIND(srvInfo) != cb->sntCfg.suType)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT070, (ErrVal) spId, 
         "ItUiSntBndReq invalid srvInfo for SAP configuration");
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                 LCM_CAUSE_INV_PAR_VAL, (U32) srvInfo);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#else
#ifndef DEBUGP
   UNUSED(srvInfo);
#endif
#endif /* ERRCLASS & ERRCLS_INT_PAR */


   
#ifdef DI
   if(pst->srcEnt == ENTSI)
   {
      U8       grp;          /* Grouping on SAP;ent/inst or ent/inst/proc */
      ProcId   dstProcId;    /* Destination procId of queried instance    */
      U8       bndStatus;    /* Bind status as maintained in LDF ISUP     */

      bndStatus  = DIT_UNBND;

      /* Determine if the SAP is already bound  */
      if (DiDitGetUpSapState(&grp, &dstProcId, pst->srcInst,
                            suId, &bndStatus) == ROK)
      {
         if (bndStatus == DIT_BND)
         {
            Pst   localPst;

            ITZVUPDPEER();

            cmMemcpy((U8 *)&localPst, (U8 *)&cb->pst, sizeof(Pst));
            localPst.dstProcId = pst->srcProcId;
            localPst.dstEnt = pst->srcEnt;
            localPst.dstInst = pst->srcInst;

            /* send ACK to the user part */
            ItUiSntBndCfm(&localPst, suId, CM_BND_OK);
            RETVALUE(ROK);
         }
      }
      else
      {
#ifdef IT_RUG
         /* An unbound instance of distributed ISUP is giving the bind request*
          * Mark the remote interface version validity as FALSE since if this *
          * is a new instance we need to find the interface version from store*
          * version data base again for this instance and update in LDF ISUP  */
         cb->remIntfValid = FALSE;
#endif /* IT_RUG */
       }
   }
#endif /* DI */

#ifdef IT_RUG
   found = FALSE;
   if (cb->remIntfValid == FALSE)
   {
      for (i = 0; i < itGlobalCb.numIntfInfo && found == FALSE; i++)
      {
         if (itGlobalCb.intfInfo[i].intf.intfId == SNTIF)
         {
            switch (itGlobalCb.intfInfo[i].grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if (itGlobalCb.intfInfo[i].dstProcId == pst->srcProcId &&
                      itGlobalCb.intfInfo[i].dstEnt.ent == pst->srcEnt &&
                      itGlobalCb.intfInfo[i].dstEnt.inst == pst->srcInst)
                     found = TRUE;
                  break;

               case SHT_GRPTYPE_ENT:
                  if (itGlobalCb.intfInfo[i].dstEnt.ent == pst->srcEnt &&
                      itGlobalCb.intfInfo[i].dstEnt.inst == pst->srcInst)
                     found = TRUE;
                  break;

               default:
                  /* not possible */
                  break;
            }
         }
         if (found == TRUE)
            break;
      }

      if (found == TRUE)
      {
          cb->pst.intfVer = itGlobalCb.intfInfo[i].intf.intfVer;
          cb->remIntfValid = TRUE;
      }
      else
      {
         /* send alarm and return */
         itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_BND_FAIL,
                    LCM_CAUSE_INV_STATE, (U32) suId);
         ITZVUPDPEER();
         RETVALUE(ret);
      }
   }
#endif /* IT_RUG */
   

   cb->sntSta.hlSt = LIT_SAP_BOUND;
   cb->sntSta.remSapId = suId;
#ifdef ZV
   if(cb->pst.route == RTE_PROTO)
   {
      cb->pst.dstProcId = CMFTHA_RES_RSETID;
   }
   else
   {
      cb->pst.dstProcId = pst->srcProcId;
   }
#else
      cb->pst.dstProcId = pst->srcProcId;
#endif
   cb->pst.dstEnt    = pst->srcEnt;
   cb->pst.dstInst   = pst->srcInst;
#ifdef ZV
   /* Update should take place before Bind confirm is sent to user */
   zvRTUpd(CMPFTHA_ACTN_MOD, ZV_NSAPCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) cb, NULLP);
#endif


#ifdef SNT2
   /* send ACK to the user part */
#ifdef DI
   if(pst->srcEnt == ENTSI)
   {
      Pst   localPst;

#ifdef IT_RUG
      DiDitSetUpIntfVer(pst->srcInst, suId, cb->pst.intfVer);
#endif /* IT_RUG */
      /* If ISUP instances are conventional (RTE_SPEC) procId is valid *
       * and is provided to LDF ISUP else only instance is valid       */
      if(cb->pst.route == RTESPEC)
         DiDitSetUpSapState(DIT_PROCID_BNDSTA, pst->srcProcId, pst->srcInst,
                         suId, DIT_BND);
      else
         DiDitSetUpSapState(DIT_BNDSTA, PROCIDNC, pst->srcInst, suId, DIT_BND);

      cmMemcpy((U8 *)&localPst, (U8 *)&cb->pst, sizeof(Pst));
      localPst.dstProcId = pst->srcProcId;
      localPst.dstEnt = pst->srcEnt;
      localPst.dstInst = pst->srcInst;

      ItUiSntBndCfm(&localPst, suId, CM_BND_OK);
   }
   else
#endif /* DI */
   ItUiSntBndCfm(&cb->pst, suId, CM_BND_OK);
#endif /* SNT2 */

#ifdef ITSG
   /* Signal restart to management interworking for Nodal IWF SAP */
   if (cb->sntCfg.suType == LIT_SP_MTP3)
   {
      (Void) itMifRestart(cb->sntCfg.nwkId);
   }
#endif /* ITSG */
   /* Signal event to MIF */
   (Void) itMifUserEvt(IT_MIF_USER_UP, cb);
   /* Update should be sent before bind confirm to the user */
   ITZVUPDPEER();

   RETVALUE(ROK);
} /* end of ItUiSntBndReq */


/*
*
*      Fun:   Unit Data request
*
*      Desc:  This function is called by the service user to send
*             data units to a peer
*
*      Ret:   ROK   - ok
*
*      Notes: <None>
*
*      File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItUiSntUDatReq
(
Pst      *pst,                /* post structure */
SpId     spId,                /* service provider id */
Dpc      cgAdr,               /* calling address */
Dpc      cdAdr,               /* called address */
SrvInfo  srvInfo,             /* service information */
LnkSel   lnkSel,              /* link selection */
Priority prior,               /* congestion priority */
Buffer   *mBuf                /* data buffer */
)
#else
PUBLIC S16 ItUiSntUDatReq(pst, spId, cgAdr, cdAdr, srvInfo, lnkSel, prior, mBuf)
Pst      *pst;                /* post structure */     
SpId     spId;                /* service provider id */
Dpc      cgAdr;               /* calling address */    
Dpc      cdAdr;               /* called address */     
SrvInfo  srvInfo;             /* service information */
LnkSel   lnkSel;              /* link selection */     
Priority prior;               /* congestion priority */
Buffer   *mBuf;               /* data buffer */        
#endif
{
   ItNSapCb *cb;              /* Upper SAP CB */
   S16      ret;              /* Return Value */

   TRC3(ItUiSntUDatReq)
#ifdef MEM_STS   	
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Entered ItUiSntUDatReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif

   ret = ROK;
#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItUiSntUDatReq() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_UI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#endif /* SS_MULTIPLE_PROCS */

  ITADDZVUPDPEERCTR()


#ifdef BIT_64
   ITDBGP(DBGMASK_UI|IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf, 
     "ItUiSntUDatReq(spId (%d), cgAdr (%d), cdAdr (%d), " 
     "srvInfo (%d), lnkSel (%d), prior (%d))\n", 
     spId, cgAdr, cdAdr, srvInfo, lnkSel, prior));
#else
   ITDBGP(DBGMASK_UI|IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf, 
     "ItUiSntUDatReq(spId (%d), cgAdr (%ld), cdAdr (%ld), " 
     "srvInfo (%d), lnkSel (%d), prior (%d))\n", 
     spId, cgAdr, cdAdr, srvInfo, lnkSel, prior));
#endif
#if (ERRCLASS & ERRCLS_INT_PAR)
   ITCHKPROTSTATE(EIT071, STITNSAP, spId, ret, IT_EVENT_NON_CRIT);
   if (ret != ROK) 
   {
      IT_DROPDATA(mBuf);
      ITZVUPDPEER();
      RETVALUE(ret);
   }

   if ((spId < 0) || (spId >= (SpId) itGlobalCb.genCfg.maxNmbNSap))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT072, (ErrVal) spId, 
         "ItUiSntUDatReq invalid spId");
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, 
                   (U16)((pst->srcEnt == ENTSN) ? LCM_EVENT_LI_INV_EVT :
                   LCM_EVENT_UI_INV_EVT),
                   (U16)((pst->srcEnt == ENTSN) ? LCM_CAUSE_INV_SUID :
                   LCM_CAUSE_INV_SPID),
                   (U32)spId);
      IT_DROPDATA(mBuf);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#else
   UNUSED(pst);
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   /* get Sap control block */
   cb = itGlobalCb.nSap[spId];

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (cb == (ItNSapCb *)NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT073, (ErrVal) spId, 
         "ItUiSntUDatReq SAP unconfigured");
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, 
                   (U16)((pst->srcEnt == ENTSN) ? LCM_EVENT_LI_INV_EVT
                   : LCM_EVENT_UI_INV_EVT),
                   (U16)((pst->srcEnt == ENTSN) ? LCM_CAUSE_INV_SUID :
                   LCM_CAUSE_INV_SPID),
                   (U32)spId);
      IT_DROPDATA(mBuf);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   /* validate priority */
   if (prior > SN_PRI3)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT074, (ErrVal) prior, 
         "ItUiSntUDatReq invalid prior");
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, 
               (U16)((cb->sntCfg.suType == LIT_SP_MTP3) ? LCM_EVENT_LI_INV_EVT
               : LCM_EVENT_UI_INV_EVT),
                LCM_CAUSE_INV_PAR_VAL, (U32)spId);
      IT_DROPDATA(mBuf);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   /* validate link selector */

   switch (cb->nwk->nwkCfg.slsLen)
   {
      case LIT_SLS4:
         if ((U16) lnkSel > IT_MAX_SLS4)
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT075, (ErrVal) lnkSel, 
               "ItUiSntUDatReq invalid sls");
            /* inform layer manager */
            itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, 
                      (U16)((cb->sntCfg.suType == LIT_SP_MTP3) ? LCM_EVENT_LI_INV_EVT
                       : LCM_EVENT_UI_INV_EVT),
                         LCM_CAUSE_INV_PAR_VAL, (U32)spId);
            IT_DROPDATA(mBuf);
            ITZVUPDPEER();
            RETVALUE(RFAILED);
         }
         break;
      case LIT_SLS5:
         if ((U16) lnkSel > IT_MAX_SLS5)
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT076, (ErrVal) lnkSel, 
               "ItUiSntUDatReq invalid sls");
            /* inform layer manager */
            itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, 
               (U16)((cb->sntCfg.suType == LIT_SP_MTP3) ? LCM_EVENT_LI_INV_EVT
               : LCM_EVENT_UI_INV_EVT),
               LCM_CAUSE_INV_PAR_VAL, (U32)spId);
            IT_DROPDATA(mBuf);
            ITZVUPDPEER();
            RETVALUE(RFAILED);
         }
         break;
  
        /* it013.106 - Removed the check for lnkSel > IT_MAX_SLS8 to remove a 
         * warning. This check is not required because lnkSel is of size U8. */

        /* it016.106 - Added case for LIT_SLS8 so that it does not fall through
         * to default leg. */
      case LIT_SLS8:
         break;
  
      default:
         /* should not get here */
         IT_DROPDATA(mBuf);
         ITZVUPDPEER();
         RETVALUE(RFAILED);
         break;
   }
   /* validate mBuf */
   if (mBuf == (Buffer *) NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT078, (ErrVal) 0, 
         "ItUiSntUDatReq NULL mBuf");
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, 
               (U16)((cb->sntCfg.suType == LIT_SP_MTP3) ? LCM_EVENT_LI_INV_EVT
               : LCM_EVENT_UI_INV_EVT),
         LCM_CAUSE_INV_PAR_VAL, (U32)spId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   else
   {
      MsgLen msgLen;          /* message length */
      msgLen = 0;
      (Void) SFndLenMsg(mBuf, &msgLen);
      if (msgLen == 0)
      {
         ITLOGERROR(ERRCLS_INT_PAR, EIT079, (ErrVal) 0, 
            "ItUiSntUDatReq zero-length mBuf");
         /* inform layer manager */
         itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, 
               (U16)((cb->sntCfg.suType == LIT_SP_MTP3) ? LCM_EVENT_LI_INV_EVT
               : LCM_EVENT_UI_INV_EVT),
            LCM_CAUSE_INV_MSG_LENGTH, (U32)spId);
         IT_DROPDATA(mBuf);
         ITZVUPDPEER();
         RETVALUE(RFAILED);
      }
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   if (cb->sntSta.hlSt != LIT_SAP_BOUND)
   {
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, 
               (U16)((cb->sntCfg.suType == LIT_SP_MTP3) ? LCM_EVENT_LI_INV_EVT
               : LCM_EVENT_UI_INV_EVT),
         LCM_CAUSE_INV_STATE, (U32)spId);
      IT_DROPDATA(mBuf);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   /* send data to MTP3-User Message Parser */
   if (itMupUDatReq(cb, cgAdr, cdAdr, srvInfo, lnkSel, prior, &mBuf)
      == RFAILED)
   {
      /* itMupUDatReq will SPutMsg the mBuf if it fails */
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_MSG_FAIL,
         LCM_CAUSE_UNKNOWN, (U32)spId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }

   /* if there are any queued primitives then they will be released in following
      zvUpdPeer function */
   ITZVUPDPEER();
#ifdef MEM_STS   
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Leaving ItUiSntUDatReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif

   RETVALUE(ROK);
} /* end of ItUiSntUDatReq */

#ifdef SNT2

/*
*
*      Fun:   Status Request
*
*      Desc:  This function is called by the service user to get the
*             status of a pointcode from M3UA
*
*      Ret:   ROK   - ok
*
*      Notes: <None>
*
*      File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItUiSntStaReq
(
Pst   *pst,                   /* post structure */
SpId  spId,                   /* service provider id */
Dpc   dpc                     /* destination pointcode */
)
#else
PUBLIC S16 ItUiSntStaReq(pst, spId, dpc)
Pst   *pst;                   /* post structure */
SpId  spId;                   /* service provider id */
Dpc   dpc;                    /* destination pointcode */
#endif
{
   ItNSapCb *cb;              /* Upper SAP CB */
#if (ERRCLASS & ERRCLS_INT_PAR)
   S16      ret;              /* Return Value */
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   TRC3(ItUiSntStaReq)

#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItUiSntStaReq() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_UI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#else
   UNUSED(pst);
#endif /* SS_MULTIPLE_PROCS */



#ifdef BIT_64
   ITDBGP(DBGMASK_UI, (itGlobalCb.itInit.prntBuf, 
     "ItUiSntStaReq(spId (%d), dpc (%d))\n", spId, dpc))
#else
   ITDBGP(DBGMASK_UI, (itGlobalCb.itInit.prntBuf, 
     "ItUiSntStaReq(spId (%d), dpc (%ld))\n", spId, dpc))
#endif
#if (ERRCLASS & ERRCLS_INT_PAR)
   ITCHKPROTSTATE(EIT080, STITNSAP, spId, ret, IT_EVENT_CRIT);
   if (ret != ROK) 
   {
      ITZVUPDPEER();
      RETVALUE(ret);
   }
   if ((spId < 0) || (spId >= (SpId) itGlobalCb.genCfg.maxNmbNSap))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT081, (ErrVal) spId, 
         "ItUiSntStaReq invalid spId");
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
         LCM_CAUSE_INV_SPID, (U32)spId);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   /* get Sap control block */
   cb = itGlobalCb.nSap[spId];

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (cb == (ItNSapCb *)NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT082, (ErrVal) spId, 
         "ItUiSntStaReq SAP unconfigured");
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
         LCM_CAUSE_INV_SPID, (U32)spId);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */
   
   if (cb->sntSta.hlSt != LIT_SAP_BOUND)
   {
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
         LCM_CAUSE_INV_STATE, (U32)spId);
      RETVALUE(RFAILED);
   }
   /* Get DPC status from management interworking function */
   if (itMifStaGet(cb, dpc, (Dpc)0) != ROK)
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of ItUiSntStaReq */
#endif /* SNT2 */

/* #ifndef SNT_BACK_COMP_MERGED_NIF */
#ifdef ITSG
#ifdef SNTIWF

/*
*
*      Fun:   Status Query Indication
*
*      Desc:  This function is called by the nodal interworking function
*             to get the status of a pointcode from M3UA
*
*      Ret:   ROK   - ok
*
*      Notes: <None>
*
*      File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSntStaQryInd
(
Pst   *pst,                   /* post structure */
SpId  spId,                   /* service provider id */
Dpc   aPc,                    /* affected pointcode */
Dpc   opc                     /* originator pointcode */
)
#else
PUBLIC S16 ItLiSntStaQryInd(pst, spId, aPc, opc)
Pst   *pst;                   /* post structure */
SpId  spId;                   /* service provider id */
Dpc   aPc;                    /* affected pointcode */
Dpc   opc;                    /* originator pointcode */
#endif
{
   ItNSapCb *cb;              /* Upper SAP CB */
#if (ERRCLASS & ERRCLS_INT_PAR)
   S16      ret;              /* Return Value */
#endif

   TRC3(ItLiSntStaQryInd)

#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItLiSntStaQryInd() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_LI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#else
   UNUSED(pst);
#endif /* SS_MULTIPLE_PROCS */


#ifdef BIT_64
   ITDBGP(DBGMASK_UI, (itGlobalCb.itInit.prntBuf, 
     "ItLiSntStaQryInd(spId (%d), aPc (%d), opc (%d))\n", spId, aPc, opc))
#else
   ITDBGP(DBGMASK_UI, (itGlobalCb.itInit.prntBuf, 
     "ItLiSntStaQryInd(spId (%d), aPc (%ld), opc (%ld))\n", spId, aPc, opc))
#endif
#if (ERRCLASS & ERRCLS_INT_PAR)
   ITCHKPROTSTATE(EIT083, STITNSAP, spId, ret, IT_EVENT_CRIT);
   if (ret != ROK) 
   {
      ITZVUPDPEER();
      RETVALUE(ret);
   }
   if ((spId < 0) || (spId >= (SpId) itGlobalCb.genCfg.maxNmbNSap))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT084, (ErrVal) spId, 
         "ItLiSntStaQryInd invalid spId");
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
         LCM_CAUSE_INV_SUID, (U32)spId);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   /* get Sap control block */
   cb = itGlobalCb.nSap[spId];

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (cb == (ItNSapCb *)NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT085, (ErrVal) spId, 
         "ItLiSntStaQryInd SAP unconfigured");
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
         LCM_CAUSE_INV_SUID, (U32)spId);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */
   
   if (cb->sntSta.hlSt != LIT_SAP_BOUND)
   {
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
         LCM_CAUSE_INV_STATE, (U32)spId);
      RETVALUE(RFAILED);
   }
   /* Get DPC status from management interworking function */
   if (itMifStaGet(cb, aPc, opc) != ROK)
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of ItLiSntStaQryInd */


/*
*
*      Fun:   Status Apply Indication
*
*      Desc:  This function is called by the nodal interworking function
*             to set the status of a pointcode in M3UA
*
*      Ret:   ROK   - ok
*
*      Notes: <None>
*
*      File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSntStaApyInd
(
Pst      *pst,                /* post structure */
SpId     spId,                /* service provider id */
Dpc      aPc,                 /* affected pointcode */
Dpc      dpc,                 /* destination pointcode */
SrvInfo  srvInfo,             /* service information */
Status   status,              /* status of pointcode */
Priority congLevel            /* congestion level of pointcode */
)
#else
PUBLIC S16 ItLiSntStaApyInd(pst, spId, aPc, dpc, srvInfo, status, congLevel)
Pst      *pst;                /* post structure */                
SpId     spId;                /* service provider id */           
Dpc      aPc;                 /* affected pointcode */            
Dpc      dpc;                 /* originator pointcode */          
SrvInfo  srvInfo;             /* service information */           
Status   status;              /* status of pointcode */           
Priority congLevel;           /* congestion level of pointcode */ 
#endif
{
   ItNSapCb *cb;              /* Upper SAP CB */
   S16      ret;              /* Return Value */

   TRC3(ItLiSntStaApyInd)
   ret = ROK;

#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItLiSntStaApyInd() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_LI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#else
   UNUSED(pst);
#endif /* SS_MULTIPLE_PROCS */

  ITADDZVUPDPEERCTR()


#ifdef BIT_64
   ITDBGP(DBGMASK_UI, (itGlobalCb.itInit.prntBuf, 
     "ItLiSntStaApyInd(spId (%d), aPc (%d), dpc (%d), srvInfo(%d), " 
     "status (%d), congLevel(%d))\n", 
                       spId, aPc, dpc, srvInfo, status, congLevel))
#else
   ITDBGP(DBGMASK_UI, (itGlobalCb.itInit.prntBuf, 
     "ItLiSntStaApyInd(spId (%d), aPc (%ld), dpc (%ld), srvInfo(%d), " 
     "status (%d), congLevel(%d))\n", 
                       spId, aPc, dpc, srvInfo, status, congLevel))
#endif
#if (ERRCLASS & ERRCLS_INT_PAR)
   ITCHKPROTSTATE(EIT086, STITNSAP, spId, ret, IT_EVENT_CRIT);
   if (ret != ROK) 
   {
      ITZVUPDPEER();
      RETVALUE(ret);
   }
   if ((spId < 0) || (spId >= (SpId) itGlobalCb.genCfg.maxNmbNSap))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT087, (ErrVal) spId, 
         "ItLiSntStaApyInd invalid spId");
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
         LCM_CAUSE_INV_SUID, (U32)spId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   /* get Sap control block */
   cb = itGlobalCb.nSap[spId];

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (cb == (ItNSapCb *)NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT088, (ErrVal) spId, 
         "ItLiSntStaApyInd SAP unconfigured");
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
         LCM_CAUSE_INV_SUID, (U32)spId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   
   if (status != SN_RMTUSRUNAV)
   {
      /* validate congLevel */
      if (congLevel > SN_PRI3)
      {
         ITLOGERROR(ERRCLS_INT_PAR, EIT089, (ErrVal) congLevel, 
            "ItLiSntStaApyInd invalid congLevel");
         /* inform layer manager */
         itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
            LCM_CAUSE_INV_PAR_VAL, (U32)spId);
      ITZVUPDPEER();
         RETVALUE(RFAILED);
      }
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */
   
   if (cb->sntSta.hlSt != LIT_SAP_BOUND)
   {
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
         LCM_CAUSE_INV_STATE, (U32)spId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   /* Set DPC status in management interworking function */
   if (itMifStaSet(cb, aPc, dpc, status, congLevel, srvInfo, FALSE)
      != ROK)
   {
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
      ITZVUPDPEER();

   RETVALUE(ROK);
} /* end of ItLiSntStaApyInd */


/*
*
*      Fun:   Status Query Confirm
*
*      Desc:  This function is called by the nodal interworking function
*             to set the status of a pointcode in M3UA
*
*      Ret:   ROK   - ok
*
*      Notes: <None>
*
*      File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSntStaQryCfm
(
Pst      *pst,                /* post structure */
SpId     spId,                /* service provider id */
Dpc      aPc,                 /* affected pointcode */
Dpc      opc,                 /* originator pointcode */
Status   status,              /* status of pointcode */
Priority congLevel            /* congestion level of pointcode */
)
#else
PUBLIC S16 ItLiSntStaQryCfm(pst, spId, aPc, opc, status, congLevel)
Pst      *pst;                /* post structure */                    
SpId     spId;                /* service provider id */               
Dpc      aPc;                 /* affected pointcode */                
Dpc      opc;                 /* originator pointcode */              
Status   status;              /* status of pointcode */               
Priority congLevel;           /* congestion level of pointcode */     
#endif
{
   ItNSapCb *cb;              /* Upper SAP CB */
#if (ERRCLASS & ERRCLS_INT_PAR)
   S16      ret;              /* Return Value */
#endif

   TRC3(ItLiSntStaQryCfm)

#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItLiSntStaQryCfm() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_LI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#else
   UNUSED(pst);
#endif /* SS_MULTIPLE_PROCS */

  /* it022.106 - DFTHA-hook */
  ITADDZVUPDPEERCTR()

#ifdef BIT_64
   ITDBGP(DBGMASK_UI, (itGlobalCb.itInit.prntBuf, 
     "ItLiSntStaQryCfm(spId (%d), aPc (%d), opc (%d), status (%d), " 
     "congLevel(%d))\n", spId, aPc, opc, status, congLevel))
#else
   ITDBGP(DBGMASK_UI, (itGlobalCb.itInit.prntBuf, 
     "ItLiSntStaQryCfm(spId (%d), aPc (%ld), opc (%ld), status (%d), " 
     "congLevel(%d))\n", spId, aPc, opc, status, congLevel))
#endif
#if (ERRCLASS & ERRCLS_INT_PAR)
   ITCHKPROTSTATE(EIT090, STITNSAP, spId, ret, IT_EVENT_CRIT);
   if (ret != ROK) 
   {
      ITZVUPDPEER();
      RETVALUE(ret);
   }
   if ((spId < 0) || (spId >= (SpId) itGlobalCb.genCfg.maxNmbNSap))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT091, (ErrVal) spId, 
         "ItLiSntStaQryCfm invalid spId");
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
         LCM_CAUSE_INV_SUID, (U32)spId);
      /* it022.106 - DFTHA-hook */
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   /* get Sap control block */
   cb = itGlobalCb.nSap[spId];

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (cb == (ItNSapCb *)NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT092, (ErrVal) spId, 
         "ItLiSntStaQryCfm SAP unconfigured");
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
         LCM_CAUSE_INV_SUID, (U32)spId);
      /* it022.106 - DFTHA-hook */
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   /* validate congLevel */
   if (congLevel > SN_PRI3)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT093, (ErrVal) congLevel, 
         "ItLiSntStaQryCfm invalid congLevel");
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
         LCM_CAUSE_INV_PAR_VAL, (U32)spId);
      /* it022.106 - DFTHA-hook */
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */
   
   if (cb->sntSta.hlSt != LIT_SAP_BOUND)
   {
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
         LCM_CAUSE_INV_STATE, (U32)spId);
      /* it022.106 - DFTHA-hook */
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   /* Set DPC status in management interworking function */
   if (itMifStaSet(cb, aPc, opc, status, congLevel, (SrvInfo)0, TRUE)
      != ROK)
   {
      /* it022.106 - DFTHA-hook */
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }

   /* it022.106 - DFTHA-hook */
   ITZVUPDPEER();

   RETVALUE(ROK);
} /* end of ItLiSntStaQryCfm */

#endif /* SNTIWF */
#endif /* ITSG */


/* ------------------------------------------------------------------*
 * Interface Functions for Lower Interface                           *
 * ------------------------------------------------------------------*/



/*
*
*       Fun:   ItLiSctBndCfm
*
*       Desc:  Confirms a bind request.
*
*       Ret:   Failure:     RFAILED
*
*              Success:     ROK
*
*       Notes: <none>
*
*       File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSctBndCfm
(
Pst         *pst,             /* post structure */
SuId        suId,             /* service user SAP identifier */
SctResult   result            /* bind result */
)
#else
PUBLIC S16 ItLiSctBndCfm(pst, suId, result)
Pst         *pst;             /* post structure */
SuId        suId;             /* service user SAP identifier */
SctResult   result;           /* bind result */
#endif
{
   ItSctSapCb  *sapCb;        /* Lower SAP CB */
   S16      ret;              /* Return Value */

   TRC3(ItLiSctBndCfm)
   ret = ROK;
   
#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItLiSctBndCfm() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_LI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#else 
   UNUSED(pst);
#endif /* SS_MULTIPLE_PROCS */

   
   ITADDZVUPDPEERCTR()

   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
      "ItLiSctBndCfm(pst, suId(%d), result(%d))\n", suId, result));


#if (ERRCLASS & ERRCLS_INT_PAR)
   ITCHKPROTSTATE(EIT094, STITSCTSAP, suId, ret, IT_EVENT_CRIT);
   if (ret != ROK) 
   {
      ITZVUPDPEER();
      RETVALUE(ret);
   }
   if ((suId < 0) || (suId >= itGlobalCb.genCfg.maxNmbSctSap))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT095, (ErrVal) suId,
         "ItLiSctBndCfm: Invalid suId");
      itMiStaInd (STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_SUID, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   sapCb = itGlobalCb.sctSap[suId];

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sapCb == (ItSctSapCb *)NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT096, (ErrVal) suId,
         "ItLiSctBndCfm: Null SCTSAP control block");
      itMiStaInd (STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_STATE, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   switch (sapCb->sctSta.hlSt)
   {
      case LIT_SAP_WAIT_BNDCFM:
         if (result == CM_BND_OK)
         {
            /* Stop bind_wait_cfm timer */
            (Void) itTcStopTimer(&sapCb->tmrPrim);
            sapCb->sctSta.hlSt = LIT_SAP_BOUND;
            itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_BND_OK,
                       LCM_CAUSE_UNKNOWN, (U32) suId);
#ifdef ZV
            /* Update bnd state */
            zvRTUpd(CMPFTHA_ACTN_MOD, ZV_SCTSAPCB,
                    CMPFTHA_UPDTYPE_NORMAL, (Void *) sapCb, NULLP);
#endif
 /* it015.106: Changes to open an endpoint also, if 
    SHT control request was received for binding an SCT SAP */
#ifdef IT_FTHA  
#ifdef IT_ENDPOPEN_ON_BNDENA
            if (sapCb->bndEnaReq == TRUE)
            {
               sapCb->bndEnaReq = FALSE;

               ret = itLiEndpOpen(sapCb->sctCfg.suId, (CmStatus*)NULLP, TRUE);
               if (ret != ROK)
               {
                  ITZVUPDPEER();
                  RETVALUE(RFAILED);
               }
            }
#endif
#endif
			/*chenning startwork*/
#if (defined ITASP && defined IT_AUTO_START) 
    		StartWork(sapCb->sctCfg.suId);
#endif      
         }
         /* it021.106 - Add the handling for result as CM_BND_NOK. */
         else
         {
            /* Stop bind_wait_cfm timer */
            (Void) itTcStopTimer(&sapCb->tmrPrim);
            sapCb->sctSta.hlSt = LIT_SAP_UNBOUND;
#ifdef IT_FTHA  
#ifdef IT_ENDPOPEN_ON_BNDENA
            sapCb->bndEnaReq = FALSE;
#endif
#endif

            itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_BND_FAIL,
                       LCM_CAUSE_UNKNOWN, (U32) suId);
#ifdef ZV
            /* Update bnd state */
            zvRTUpd(CMPFTHA_ACTN_MOD, ZV_SCTSAPCB,
                    CMPFTHA_UPDTYPE_NORMAL, (Void *) sapCb, NULLP);
#endif
         }
         break;
      case LIT_SAP_UNBOUND:
#if (ERRCLASS & ERRCLS_DEBUG)
         ITLOGERROR(ERRCLS_DEBUG, EIT097, (ErrVal) suId,
                    "ItLiSctBndCfm: SCT SAP not in WAIT_BNDCFM state");
         itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_BND_FAIL,
                    LCM_CAUSE_INV_STATE, (U32) suId);
      ITZVUPDPEER();
         RETVALUE(RFAILED);
#endif /* ERRCLASS & ERRCLS_DEBUG */
         break;   
      case LIT_SAP_WAIT_OPENCFM:
         /* fall through */
      case LIT_SAP_READY:
         /* fall through */
      case LIT_SAP_BOUND:
         break;
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         ITLOGERROR(ERRCLS_DEBUG, EIT098, (ErrVal) suId,
                    "ItLiSctBndCfm: Invalid SCT SAP state");
         itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_BND_FAIL,
                    LCM_CAUSE_INV_STATE, (U32) suId);
      ITZVUPDPEER();
         RETVALUE(RFAILED);
#endif /* ERRCLASS & ERRCLS_DEBUG */
         break;   
   }
      ITZVUPDPEER();
   RETVALUE(ROK);         
} /* end of ItLiSctBndCfm */


/*
*
*       Fun:   ItLiSctEndpOpenCfm
*
*       Desc:  Confirms an endpoint open request.
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSctEndpOpenCfm
(
Pst         *pst,             /* post structure */
SuId        suId,             /* service user SAP identifier */
UConnId     suEndpId,         /* service user endpoint identifier */
UConnId     spEndpId,         /* service provider endpoint identifier */
SctResult   result,           /* endpoint open result */
SctCause    cause             /* cause of failure */
)
#else
PUBLIC S16 ItLiSctEndpOpenCfm(pst, suId, suEndpId, spEndpId, result, cause)
Pst         *pst;             /* post structure */
SuId        suId;             /* service user SAP identifier */
UConnId     suEndpId;         /* service user endpoint identifier */
UConnId     spEndpId;         /* service provider endpoint identifier */
SctResult   result;           /* endpoint open result */
SctCause    cause;            /* cause of failure */
#endif
{
   ItSctSapCb *sapCb;         /* Lower SAP CB */
   S16      ret;              /* Return Value */

   TRC3(ItLiSctEndpOpenCfm)
   ret = ROK;
   
#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItLiSctEndpOpenCfm() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_LI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#else	   
   UNUSED(pst);
#endif /* SS_MULTIPLE_PROCS */

  ITADDZVUPDPEERCTR()

#ifdef BIT_64
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "ItLiSctEndpOpenCfm(pst, suId(%d), suEndpId(%d), spEndpId(%d), "
          "result(%d)\n", suId, suEndpId, spEndpId, result));
#else
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "ItLiSctEndpOpenCfm(pst, suId(%d), suEndpId(%ld), spEndpId(%ld), "
          "result(%d)\n", suId, suEndpId, spEndpId, result));
#endif
   UNUSED(cause);

#if (ERRCLASS & ERRCLS_INT_PAR)
   ITCHKPROTSTATE(EIT099, STITSCTSAP, suId, ret, IT_EVENT_CRIT);
   if (ret != ROK) 
   {
      ITZVUPDPEER();
      RETVALUE(ret);
   }
   if ((suId < 0) || (suId >= itGlobalCb.genCfg.maxNmbSctSap))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT100, (ErrVal) suId,
         "ItLiSctEndOpenCfm: Invalid suId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_SUID, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (suEndpId !=  (UConnId) suId)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT101, (ErrVal) suId,
         "ItLiSctEndpOpenCfm: Invalid suEndpId");
      itMiStaInd (STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#else
#ifndef DEBUGP
   UNUSED(suEndpId);
#endif
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   sapCb = itGlobalCb.sctSap[suId];

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sapCb == (ItSctSapCb *)NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT102, (ErrVal) suId,
         "ItLiSctEndpOpenCfm: Null SCTSAP control block");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_STATE, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   switch (sapCb->sctSta.hlSt)
   {
      case LIT_SAP_READY:
         /* fall through */
      case LIT_SAP_WAIT_OPENCFM:
         if (result == SCT_OK)
         {
            /* Stop retry timer */
            (Void) itTcStopTimer(&sapCb->tmrPrim);

            sapCb->sctSta.spEndpId = spEndpId;
            sapCb->sctSta.hlSt     = LIT_SAP_READY;
            itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, 
                      LIT_EVENT_EOPEN_OK, LCM_CAUSE_UNKNOWN, (U32)suId);
#ifdef ZV
            /* Update spEndpId */
            zvRTUpd(CMPFTHA_ACTN_MOD, ZV_SCTSAPCB,
                    CMPFTHA_UPDTYPE_NORMAL, (Void *) sapCb, NULLP);
#endif
         }
         /* it021.106 - Add the handling for result as SCT_NOK. */
         else 
         {
            /* Stop retry timer */
            (Void) itTcStopTimer(&sapCb->tmrPrim);

            /* Roll back to the earlier state */
            sapCb->sctSta.hlSt     = LIT_SAP_BOUND;

            itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_EOPEN_FAIL,
               cause, (U32) suId);
         }
         break;
      case LIT_SAP_UNBOUND:
         /* fall through */
      case LIT_SAP_WAIT_BNDCFM:
         /* fall through */
      case LIT_SAP_BOUND:
         /* fall through */
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT103, (ErrVal) suId,
            "ItLiSctEndOpenCfm: SCT SAP in invalid state");
         itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_EOPEN_FAIL,
            LCM_CAUSE_INV_STATE, (U32) suId);
      ITZVUPDPEER();
         RETVALUE(RFAILED);
#endif /* ERRCLASS & ERRCLS_INT_PAR */
         break;   
   }
      ITZVUPDPEER();
   RETVALUE(ROK);         

} /* end of ItLiSctEndpOpenCfm */


/*
*
*       Fun:   ItLiSctEndpCloseCfm
*
*       Desc:  Confirms an endpoint close request.
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSctEndpCloseCfm
(
Pst         *pst,             /* post structure */
SuId        suId,             /* service user SAP identifier */
UConnId     suEndpId,         /* service user endpoint identifier */
SctResult   result,           /* endpoint close result */
SctCause    cause             /* cause of failure */
)
#else
PUBLIC S16 ItLiSctEndpCloseCfm(pst, suId, suEndpId, result, cause)
Pst         *pst;             /* post structure */
SuId        suId;             /* service user SAP identifier */
UConnId     suEndpId;         /* service user endpoint identifier */
SctResult   result;           /* endpoint close result */
SctCause    cause;            /* cause of failure */
#endif
{
   ItSctSapCb *sapCb;         /* Lower SAP CB */
   S16      ret;              /* Return Value */

   TRC3(ItLiSctEndpCloseCfm)
   ret = ROK;
#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItLiSctEndpCloseCfm() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_LI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#else
   UNUSED(pst);
#endif /* SS_MULTIPLE_PROCS */

  ITADDZVUPDPEERCTR()

#ifdef BIT_64
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
   "ItLiSctEndpCloseCfm(pst, suId(%d), suEndpId(%d), result(%d), cause(%d))\n",
                       suId, suEndpId, result, cause));
#else
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
   "ItLiSctEndpCloseCfm(pst, suId(%d), suEndpId(%ld), result(%d), cause(%d))\n",
                       suId, suEndpId, result, cause));
#endif
#ifndef DEBUGP
   UNUSED(cause);
   UNUSED(result);
#endif

#if (ERRCLASS & ERRCLS_INT_PAR)
   ITCHKPROTSTATE(EIT104, STITSCTSAP, suId, ret, IT_EVENT_CRIT);
   if (ret != ROK) 
   {
      ITZVUPDPEER();
      RETVALUE(ret);
   }
   if ((suId < 0) || (suId >= itGlobalCb.genCfg.maxNmbSctSap))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT105, (ErrVal) suId,
         "ItLiSctEndpCloseCfm: Invalid suId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_SUID, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (suEndpId !=  (UConnId) suId)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT106, (ErrVal) suId,
         "ItLiSctEndpCloseCfm: Invalid suEndpId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }

#else
#ifndef DEBUGP
   UNUSED(suEndpId);
#endif
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   sapCb = itGlobalCb.sctSap[suId];

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sapCb == (ItSctSapCb *)NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT107, (ErrVal) suId,
         "ItLiSctEndpCloseCfm: Null SCTSAP control block");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_STATE, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   /* it006.106 - New status indications added */
   if (result == SCT_OK)
   {
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, 
                 LIT_EVENT_ECLOSE_OK, LCM_CAUSE_UNKNOWN, (U32)suId);
   }
   else
   {
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, 
                 LIT_EVENT_ECLOSE_NOK, LCM_CAUSE_UNKNOWN, (U32)suId);
   }

      ITZVUPDPEER();
   RETVALUE(ROK);
} /* end of ItLiSctEndpCloseCfm */


/*
*
*       Fun:   ItLiSctAssocInd
*
*       Desc:  Indicates a request for association from a peer SCTP user
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSctAssocInd
(
Pst                  *pst,          /* post structure */
SuId                 suId,          /* service user SAP identifier */
UConnId              suEndpId,      /* service user endpoint identifier */
SctAssocIndParams    *assocParams,  /* prmt to the association indication */
Buffer               *vsInfo        /* vendor-specific information */
)
#else
PUBLIC S16 ItLiSctAssocInd (pst, suId, suEndpId, assocParams, vsInfo)
Pst                  *pst;          /* post structure */
SuId                 suId;          /* service user SAP identifier */
UConnId              suEndpId;      /* service user endpoint identifier */
SctAssocIndParams    *assocParams;  /* prmt to the association indication */
Buffer               *vsInfo;       /* vendor-specific information */
#endif
{
   S16      ret;              /* Return Value */
   TRC3(ItLiSctAssocInd)

   ret = ROK;
#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItLiSctAssocInd() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_LI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#else
   UNUSED(pst);
#endif /* SS_MULTIPLE_PROCS */

  ITADDZVUPDPEERCTR()
#ifdef BIT_64
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
      "ItLiSctAssocInd(pst, suId(%d), suEndpId(%d), assocParams)\n", 
      suId, suEndpId));
#else
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
      "ItLiSctAssocInd(pst, suId(%d), suEndpId(%ld), assocParams)\n", 
      suId, suEndpId));
#endif
   /* vsInfo not used */
   IT_DROPDATA(vsInfo);

#if (ERRCLASS & ERRCLS_INT_PAR)
   ITCHKPROTSTATE(EIT108, STITSCTSAP, suId, ret, IT_EVENT_CRIT);
   if (ret != ROK) 
   {
      ITZVUPDPEER();
      RETVALUE(ret);
   }
   if ((suId < 0) || (suId >= itGlobalCb.genCfg.maxNmbSctSap))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT109, (ErrVal) suId,
         "ItLiSctAssocInd: Invalid suId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_SUID, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (suEndpId !=  (UConnId) suId)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT110, (ErrVal) suId,
         "ItLiSctAssocInd: Invalid suEndpId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.sctSap[suId] == (ItSctSapCb *)NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT111, (ErrVal) suId,
         "ItLiSctAssocInd: Null SCTSAP control block");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_STATE, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.sctSap[suId]->sctSta.hlSt == LIT_SAP_UNBOUND)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT112, (ErrVal) suId,
         "ItLiSctStaCfm: SCT SAP not bound");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   } 
#else
#ifndef DEBUGP
   UNUSED(suEndpId);
#endif
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   (Void) itAcAssocInd(suId, assocParams);

   ITZVUPDPEER();
   RETVALUE(ROK);
} /* end of ItLiSctAssocInd */


/*
*
*       Fun:   ItLiSctAssocCfm
*
*       Desc:  Confirms a local request for association establishment
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSctAssocCfm
(
Pst           *pst,           /* post structure */
SuId          suId,           /* service user SAP identifier */
UConnId       suAssocId,      /* service user assoc identifier */
UConnId       spAssocId,      /* service provider assoc identifier */
SctNetAddrLst *dstNAddrLst,   /* destination net address list */
SctPort       dstPort,        /* destination port */
SctStrmId     outStrms,       /* outgoing streams */
Buffer        *vsInfo         /* vendor-specific information */
)
#else
PUBLIC S16 ItLiSctAssocCfm (pst, suId, suAssocId, spAssocId, dstNAddrLst, 
                            dstPort, outStrms, vsInfo)
Pst           *pst;           /* post structure */
SuId          suId;           /* service user SAP identifier */
UConnId       suAssocId;      /* service user assoc identifier */
UConnId       spAssocId;      /* service provider assoc identifier */
SctNetAddrLst *dstNAddrLst;   /* destination net address list */
SctPort       dstPort;        /* destination port */
SctStrmId     outStrms;       /* outgoing streams */
Buffer        *vsInfo;        /* vendor-specific information */
#endif
{
   S16      ret;              /* Return Value */

   TRC3(ItLiSctAssocCfm)

#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItLiSctAssocCfm() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_LI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#else
   UNUSED(pst);
#endif /* SS_MULTIPLE_PROCS */

  ret = ROK;
   ITADDZVUPDPEERCTR()

#ifdef BIT_64
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf,
      "ItLiSctAssocCfm(pst, suId(%d), suAssocId(%d), spAssocId(%d), "
      "dstNAddrLst(%p), dstPort(%d), outStrms(%d), vsInfo(%p))\n",
      suId, suAssocId, spAssocId, (Void *)dstNAddrLst, dstPort, outStrms, (Void *)vsInfo));
#else
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf,
      "ItLiSctAssocCfm(pst, suId(%d), suAssocId(%ld), spAssocId(%ld), "
      "dstNAddrLst(%p), dstPort(%d), outStrms(%d), vsInfo(%p))\n",
      suId, suAssocId, spAssocId, (Void *)dstNAddrLst, dstPort, outStrms, 
      (Void *)vsInfo));
#endif

   /* vsInfo not used */
   IT_DROPDATA(vsInfo);

#if (ERRCLASS & ERRCLS_INT_PAR)
   ITCHKPROTSTATE(EIT113, STITSCTSAP, suId, ret, IT_EVENT_CRIT);
   if (ret != ROK) 
   {
      ITZVUPDPEER();
      RETVALUE(ret);
   }
   if ((suId < 0) || (suId >= itGlobalCb.genCfg.maxNmbSctSap))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT114, (ErrVal) suId,
         "ItLiSctAssocCfm: Invalid suId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_SUID, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.sctSap[suId] == (ItSctSapCb *)NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT115, (ErrVal) suId,
         "ItLiSctAssocCfm: Null SCTSAP control block");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_STATE, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (suAssocId >= itGlobalCb.maxNmbAssoc)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT116, (ErrVal) suId,
         "ItLiSctAssocCfm: Invalid suAssocId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.sctSap[suId]->sctSta.hlSt == LIT_SAP_UNBOUND)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT117, (ErrVal) suId,
         "ItLiSctStaCfm: SCT SAP not bound");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.assoc[suAssocId] == (ItAssocCb *) NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT118, (ErrVal) suAssocId,
         "ItLiSctAssocCfm: NULL association control block");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#else
#ifndef DEBUGP
   UNUSED(suId);
#endif
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   itAcAssocCfm(suAssocId, spAssocId, dstNAddrLst, 
                dstPort, outStrms);

   ITZVUPDPEER();
   RETVALUE(ROK);
} /* end of ItLiSctAssocCfm */


/*
*
*       Fun:   ItLiSctTermInd
*
*       Desc:  Indicates that an association has been terminated
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSctTermInd
(
Pst           *pst,           /* post structure */
SuId          suId,           /* service user SAP identifier */
UConnId       assocId,        /* service user assoc identifier */
U8            assocIdType,    /* association identifier type */
SctStatus     status,         /* SCT SAP status */
SctCause      cause,          /* reason for assoc termination */
SctRtrvInfo   *rtrvInfo       /* retrieval information */
)                             
#else
PUBLIC S16 ItLiSctTermInd (pst, suId, assocId, assocIdType, 
                           status, cause, rtrvInfo)
Pst           *pst;           /* post structure */
SuId          suId;           /* service user SAP identifier */
UConnId       assocId;        /* service user assoc identifier */
U8            assocIdType;    /* association identifier type */
SctStatus     status;         /* SCT SAP status */
SctCause      cause;          /* reason for assoc termination */
SctRtrvInfo   *rtrvInfo;      /* retrieval information */
#endif
{
   UConnId    suAssocId;      /* SU association ID */
   S16      ret;              /* Return Value */
   
   TRC3(ItLiSctTermInd)
   ret = ROK;
#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItLiSctTermInd() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_LI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#else
   UNUSED(pst);
#endif /* SS_MULTIPLE_PROCS */

  ITADDZVUPDPEERCTR()

#ifdef BIT_64
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "ItLiSctTermInd(pst, suid(%d), assocId(%d), assocIdType(%d), "
          "status(%d), cause(%d), rtrvInfo(%p)\n", suId, assocId, 
          assocIdType, status, cause, (Void *)rtrvInfo));
#else
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "ItLiSctTermInd(pst, suid(%d), assocId(%ld), assocIdType(%d), "
          "status(%d), cause(%d), rtrvInfo(%p)\n", suId, assocId, 
          assocIdType, status, cause, (Void *)rtrvInfo));
#endif

#ifndef DBGP
   UNUSED(cause);
   UNUSED(rtrvInfo);
#endif

   suAssocId = (UConnId) 0;

#if (ERRCLASS & ERRCLS_INT_PAR)
   ITCHKPROTSTATE(EIT119, STITSCTSAP, suId, ret, IT_EVENT_CRIT);
   if (ret != ROK) 
   {
      ITZVUPDPEER();
      RETVALUE(ret);
   }
   if ((suId < 0) || (suId >= itGlobalCb.genCfg.maxNmbSctSap))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT120, (ErrVal) suId,
         "ItLiSctTermInd: Invalid suId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_SUID, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.sctSap[suId] == (ItSctSapCb *)NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT121, (ErrVal) suId,
         "ItLiSctTermInd: Null SCTSAP control block");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_STATE, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.sctSap[suId]->sctSta.hlSt == LIT_SAP_UNBOUND)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT122, (ErrVal) suId,
         "ItLiSctStaCfm: SCT SAP not bound");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#else
#ifndef DEBUGP
   UNUSED(suId);
#endif
#endif /* ERRCLASS & ERRCLS_INT_PAR */
   
   switch (assocIdType)
   {
      case SCT_ASSOCID_SU:
      {
         suAssocId = assocId;
#if (ERRCLASS & ERRCLS_INT_PAR)
         if (suAssocId >= itGlobalCb.maxNmbAssoc)
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT123, (ErrVal) suAssocId,
               "ItLiSctTermInd: Invalid assocId (SU)");
            itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
               LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      ITZVUPDPEER();
            RETVALUE(RFAILED);
         }
#endif /* ERRCLASS & ERRCLS_INT_PAR */
         break;
      }
      case SCT_ASSOCID_SP:
      {
         U16 i;               /* loop index */
         for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)
         {
            if ((itGlobalCb.assoc[i] != (ItAssocCb *)NULLP) && 
                (itGlobalCb.assoc[i]->owner != (ItPspCb *)NULLP) &&
                (itGlobalCb.assoc[i]->owner->pspCfg.pspId != IT_LOCAL_PSPID) &&
                (itGlobalCb.assoc[i]->assocSta->spAssocId == assocId))
            {
               suAssocId = i;
               break;
            }
         }
#if (ERRCLASS & ERRCLS_INT_PAR)
         if (i == itGlobalCb.maxNmbAssoc)
         {
            ITLOGERROR(ERRCLS_INT_PAR, EIT124, (ErrVal) assocId,
               "ItLiSctTermInd: assocId (SP) not found");
            itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
               LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      ITZVUPDPEER();
            RETVALUE(RFAILED);
         }
#endif /* ERRCLASS & ERRCLS_INT_PAR */
         break;
      }
      default:
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT125, (ErrVal) assocIdType,
            "ItLiSctTermInd: invalid assocIdType");
         itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
            LCM_CAUSE_INV_PAR_VAL, (U32) suId);
#endif /* ERRCLASS & ERRCLS_INT_PAR */
      ITZVUPDPEER();
         RETVALUE(RFAILED);
      }
   }

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (itGlobalCb.assoc[suAssocId] == (ItAssocCb *) NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT126, (ErrVal) assocId,
         "ItLiSctTermInd: invalid assocId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */
   itAcTermInd(suAssocId, status);

   ITZVUPDPEER();
   RETVALUE(ROK);
} /* end of ItLiSctTermInd */


/*
*
*       Fun:   ItLiSctTermCfm
*
*       Desc:  Confirms a local request for association termination
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSctTermCfm
(
Pst           *pst,           /* post structure */
SuId          suId,           /* service user SAP identifier */
UConnId       suAssocId,      /* service user assoc identifier */
SctResult     result,         /* result */
SctCause      cause           /* reason for assoc termination */
)
#else
PUBLIC S16 ItLiSctTermCfm (pst, suId, suAssocId, result, cause)
Pst           *pst;           /* post structure */
SuId          suId;           /* service user SAP identifier */
UConnId       suAssocId;      /* service user assoc identifier */
SctResult     result;         /* result */
SctCause      cause;          /* reason for assoc termination */
#endif
{
   S16      ret;              /* Return Value */
   TRC3(ItLiSctTermCfm)
#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItLiSctTermCfm() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_LI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#else
   UNUSED(pst);
#endif /* SS_MULTIPLE_PROCS */

  ret = ROK;
   ITADDZVUPDPEERCTR()

#ifdef BIT_64
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
      "ItLiSctTermCfm(pst, suId(%d), suAssocId(%d), result(%d), cause(%d))\n", 
      suId, suAssocId, result, cause));
#else
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
      "ItLiSctTermCfm(pst, suId(%d), suAssocId(%ld), result(%d), cause(%d))\n", 
      suId, suAssocId, result, cause));
#endif

#ifndef DBGP
   UNUSED(result);
   UNUSED(cause);
#endif

#if (ERRCLASS & ERRCLS_INT_PAR)
   ITCHKPROTSTATE(EIT127, STITSCTSAP, suId, ret, IT_EVENT_CRIT);
   if (ret != ROK) 
   {
      ITZVUPDPEER();
      RETVALUE(ret);
   }
   if ((suId < 0) || (suId >= itGlobalCb.genCfg.maxNmbSctSap))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT128, (ErrVal) suId,
         "ItLiSctTermCfm: Invalid suId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_SUID, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (suAssocId >= itGlobalCb.maxNmbAssoc)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT129, (ErrVal) suId,
         "ItLiSctTermCfm: Invalid assocId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.sctSap[suId] == (ItSctSapCb *)NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT130, (ErrVal) suId,
         "ItLiSctTermCfm: Null SCTSAP control block");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_STATE, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.sctSap[suId]->sctSta.hlSt == LIT_SAP_UNBOUND)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT131, (ErrVal) suId,
         "ItLiSctStaCfm: SCT SAP not bound");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#else
#ifndef DEBUGP
   UNUSED(suId);
#endif
#endif /* ERRCLASS & ERRCLS_INT_PAR */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (itGlobalCb.assoc[suAssocId] == (ItAssocCb *) NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT132, (ErrVal) suAssocId,
         "ItLiSctTermCfm: invalid suAssocId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */
   
   itAcTermCfm(suAssocId);

      ITZVUPDPEER();
   RETVALUE(ROK);
} /* end of ItLiSctTermCfm */



/*
*
*       Fun:   ItLiSctDatInd
*
*       Desc:  Indicates receipt of data from peer SCTP user
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSctDatInd
(
Pst           *pst,           /* post structure */
SuId          suId,           /* service user SAP identifier */
UConnId       suAssocId,      /* service user assoc identifier */
SctStrmId     strmId,         /* SCTP stream identifier */
SctDatIndType *indType,       /* data indication type */
U32           protId,         /* protocol ID */
Buffer        *mBuf           /* message buffer */
)
#else
PUBLIC S16 ItLiSctDatInd (pst, suId, suAssocId, strmId, indType, protId, mBuf)
Pst           *pst;           /* post structure */
SuId          suId;           /* service user SAP identifier */
UConnId       suAssocId;      /* service user assoc identifier */
SctStrmId     strmId;         /* SCTP stream identifier */
SctDatIndType *indType;       /* data indication type */
U32           protId;         /* protocol ID */
Buffer        *mBuf;          /* message buffer */
#endif
{
   S16      ret;              /* Return Value */
   TRC3(ItLiSctDatInd)
   ret = ROK;
#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItLiSctDatInd() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_LI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#else
   UNUSED(pst);
#endif /* SS_MULTIPLE_PROCS */

/* DFTHA-hook */
  ITADDZVUPDPEERCTR()

#ifdef BIT_64
   ITDBGP(DBGMASK_LI | IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf, 
          "ItLiSctDatInd(pst, suId(%d), suAssocId(%d), strmId(%d), "
          "indType(%p), protId(%d), mBuf(%p))\n", suId, suAssocId, strmId,
          (Void *)indType, protId, (Void *)mBuf));
#else
   ITDBGP(DBGMASK_LI | IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf, 
          "ItLiSctDatInd(pst, suId(%d), suAssocId(%ld), strmId(%d), "
          "indType(%p), protId(%ld), mBuf(%p))\n", suId, suAssocId, strmId,
          (Void *)indType, protId, (Void *)mBuf));
#endif
   /* No zv function is called in this primitive, it is handled in itMmhdatInd
      function */ 
#if (ERRCLASS & ERRCLS_INT_PAR)
   ITCHKPROTSTATE(EIT133, STITSCTSAP, suId, ret, IT_EVENT_NON_CRIT);
   if (ret != ROK) 
   {
      IT_DROPDATA(mBuf);
      ITZVUPDPEER();
      RETVALUE(ret);
   }
   if ((suId < 0) || (suId >= itGlobalCb.genCfg.maxNmbSctSap))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT134, (ErrVal) suId,
         "ItLiSctDatInd: Invalid suId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_SUID, (U32) suId);
      IT_DROPDATA(mBuf);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.sctSap[suId] == (ItSctSapCb *)NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT135, (ErrVal) suId,
         "ItLiSctDatInd: Null SCTSAP control block");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_STATE, (U32) suId);
      IT_DROPDATA(mBuf);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (suAssocId >= itGlobalCb.maxNmbAssoc)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT136, (ErrVal) suAssocId,
         "ItLiSctDatInd: Invalid suAssocId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      IT_DROPDATA(mBuf);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.assoc[suAssocId] == (ItAssocCb *) NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT137, (ErrVal) suAssocId,
         "ItLiSctDatInd: NULL association control block");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      IT_DROPDATA(mBuf);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.sctSap[suId]->sctSta.hlSt == LIT_SAP_UNBOUND)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT138, (ErrVal) suId,
         "ItLiSctStaCfm: SCT SAP not bound");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      IT_DROPDATA(mBuf);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if ((protId != SCT_PROTID_M3UA) && (protId != SCT_PROTID_NONE))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT139, (ErrVal) protId,
         "ItLiSctDatInd: invalid protId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      IT_DROPDATA(mBuf);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#else
#ifndef DEBUGP
   UNUSED(protId);
#endif
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   /* it013.106 - Accept the Indication type SCT_UNORDER_DAT. */
   if ((indType->type != SCT_PEER_DAT) && (indType->type != SCT_UNORDER_DAT))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT140, (ErrVal) indType->type,
         "ItLiSctDatInd: invalid indType->type");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
#endif /* ERRCLASS & ERRCLS_INT_PAR */
      IT_DROPDATA(mBuf);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   /* SCTP may send NULL mBuf - check for this */
   if (mBuf == (Buffer *) NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT141, (ErrVal) indType->type,
         "ItLiSctDatInd: mBuf is NULLP");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
#endif /* ERRCLASS & ERRCLS_INT_PAR */
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }


   /* Send to Stream Mapper. Drop mBuf if operation fails */
   if (itSmDatInd(suAssocId, &mBuf, strmId) != ROK)
   {
      IT_DROPDATA(mBuf);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }

   ITZVUPDPEER();

   RETVALUE(ROK);
} /* end of ItLiSctDatInd */


/*
*
*       Fun:   ItLiSctStaCfm
*
*       Desc:  Confirms a status report
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSctStaCfm
(
Pst           *pst,           /* post structure */
SuId          suId,           /* service user SAP identifier */
UConnId       suAssocId,      /* service user assoc identifier */
CmNetAddr     *dstNAddr,      /* destination network address */
SctResult     result,         /* result */
SctCause      cause,          /* cause */
SctStaInfo    *staInfo        /* status information */
)
#else
PUBLIC S16 ItLiSctStaCfm (pst, suId, suAssocId, dstNAddr,
                          result, cause, staInfo)
Pst           *pst;           /* post structure */
SuId          suId;           /* service user SAP identifier */
UConnId       suAssocId;      /* service user assoc identifier */
CmNetAddr     *dstNAddr;      /* destination network address */
SctResult     result;         /* result */
SctCause      cause;          /* cause */
SctStaInfo    *staInfo;       /* status information */
#endif
{
   S16      ret;              /* Return Value */
   TRC3(ItLiSctStaCfm)

   ret = ROK;
#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItLiSctStaCfm() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_LI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#else
   UNUSED(pst);
#endif /* SS_MULTIPLE_PROCS */

  ITADDZVUPDPEERCTR()
#ifdef BIT_64
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "ItLiSctStaCfm(pst, suId(%d), suAssocId(%d), dstNAddr(%p), "
          "result(%d), cause(%d), staInfo(%p))\n", suId, suAssocId,
          (Void *)dstNAddr, result, cause, (Void *)staInfo));
#else
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "ItLiSctStaCfm(pst, suId(%d), suAssocId(%ld), dstNAddr(%p), "
          "result(%d), cause(%d), staInfo(%p))\n", suId, suAssocId, 
          (Void *)dstNAddr, result, cause, (Void *)staInfo));
#endif

#ifndef DEBUGP
   UNUSED(staInfo);
   UNUSED(cause);
   UNUSED(result);
   UNUSED(dstNAddr);
#endif

#if (ERRCLASS & ERRCLS_INT_PAR)
   ITCHKPROTSTATE(EIT142, STITSCTSAP, suId, ret, IT_EVENT_CRIT);
   if (ret != ROK) 
   {
      ITZVUPDPEER();
      RETVALUE(ret);
   }
   if ((suId < 0) || (suId >= itGlobalCb.genCfg.maxNmbSctSap))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT143, (ErrVal) suId,
         "ItLiSctStaCfm: Invalid suId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_SUID, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.sctSap[suId] == (ItSctSapCb *)NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT144, (ErrVal) suId,
         "ItLiSctStaCfm: Null SCTSAP control block");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_STATE, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (suAssocId >= itGlobalCb.maxNmbAssoc)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT145, (ErrVal) suAssocId,
         "ItLiSctStaCfm: Invalid suAssocId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.assoc[suAssocId] == (ItAssocCb *) NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT146, (ErrVal) suAssocId,
         "ItLiSctStaCfm: NULL association control block");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

      ITZVUPDPEER();
   RETVALUE(ROK);
} /* end of ItLiSctStaCfm */


/*
*
*       Fun:   ItLiSctStaInd
*
*       Desc:  Indicates change of status of an SCTP association
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSctStaInd
(
Pst           *pst,           /* post structure */
SuId          suId,           /* service user SAP identifier */
UConnId       suAssocId,      /* service user assoc identifier */
UConnId       spAssocId,      /* service provider assoc identifier */
CmNetAddr     *dstNAddr,      /* destination network address */
SctStatus     status,         /* status */
SctCause      cause,          /* cause */
Buffer        *mBuf           /* message buffer */
)
#else
PUBLIC S16 ItLiSctStaInd (pst, suId, suAssocId, spAssocId, dstNAddr,
                          status, cause, mBuf)
Pst           *pst;           /* post structure */
SuId          suId;           /* service user SAP identifier */
UConnId       suAssocId;      /* service user assoc identifier */
UConnId       spAssocId;      /* service provider assoc identifier */
CmNetAddr     *dstNAddr;      /* destination network address */
SctStatus     status;         /* status */
SctCause      cause;          /* cause */
Buffer        *mBuf;          /* message buffer */
#endif
{
   S16      ret;              /* Return Value */
   TRC3(ItLiSctStaInd)

   ret = ROK;
#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItLiSctStaInd() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_LI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#else
  UNUSED(pst);
#endif /* SS_MULTIPLE_PROCS */

   ITADDZVUPDPEERCTR()
#ifdef BIT_64
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "ItLiSctStaInd(pst, suId(%d), suAssocId(%d), spAssocId(%d), "
          "dstNAddr(%p), status(%d), cause(%d), mBuf(%p))\n", 
          suId, suAssocId, spAssocId, (Void *)dstNAddr, status, cause,
         (Void *)mBuf));
#else
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "ItLiSctStaInd(pst, suId(%d), suAssocId(%ld), spAssocId(%ld), "
          "dstNAddr(%p), status(%d), cause(%d), mBuf(%p))\n", 
          suId, suAssocId, spAssocId, (Void *)dstNAddr, status, cause, 
          (Void *)mBuf));
#endif
#ifndef DEBUGP
   UNUSED(dstNAddr);
#endif

#if (ERRCLASS & ERRCLS_INT_PAR)
   ITCHKPROTSTATE(EIT147, STITSCTSAP, suId, ret, IT_EVENT_CRIT);
   if (ret != ROK) 
   {
      ITZVUPDPEER();
      RETVALUE(ret);
   }
   if ((suId < 0) || (suId >= itGlobalCb.genCfg.maxNmbSctSap))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT148, (ErrVal) suId,
         "ItLiSctStaInd: Invalid suId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_SUID, (U32) suId);
      IT_DROPDATA(mBuf);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.sctSap[suId] == (ItSctSapCb *)NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT149, (ErrVal) suId,
         "ItLiSctStaInd: Null SCTSAP control block");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_STATE, (U32) suId);
      IT_DROPDATA(mBuf);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (suAssocId >= itGlobalCb.maxNmbAssoc)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT150, (ErrVal) suAssocId,
         "ItLiSctStaInd: Invalid suAssocId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      IT_DROPDATA(mBuf);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.sctSap[suId]->sctSta.hlSt == LIT_SAP_UNBOUND)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT151, (ErrVal) suId,
         "ItLiSctStaInd: SCT SAP not bound");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      IT_DROPDATA(mBuf);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.assoc[suAssocId] == (ItAssocCb *) NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT152, (ErrVal) suAssocId,
         "ItLiSctStaInd: NULL association control block");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      IT_DROPDATA(mBuf);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#else
#ifndef DEBUGP
   UNUSED(suId);
#endif
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   /* Parameter spAssocID added for cleaning up the Association
      after deactivation */
   itAcStaInd(suAssocId, spAssocId, status, cause, &mBuf);

   RETVALUE(ROK);
} /* end of ItLiSctStaInd */


/*
*
*       Fun:   ItLiSctFlcInd
*
*       Desc:  Indicates change of flow control status
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSctFlcInd
(
Pst        *pst,              /* post structure */
SuId       suId,              /* service user SAP identifier */
UConnId    suAssocId,         /* service user association ID */
Reason     reason             /* reason for flow control indication */
)
#else
PUBLIC S16 ItLiSctFlcInd (pst, suId, suAssocId, reason)
Pst        *pst;              /* post structure */
SuId       suId;              /* service user SAP identifier */
UConnId    suAssocId;         /* service user association ID */        
Reason     reason;            /* reason for flow control indication */ 
#endif
{
   S16      ret;              /* Return Value */
   TRC3(ItLiSctFlcInd)
#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItLiSctFlcInd() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_LI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#else
   UNUSED(pst);
#endif /* SS_MULTIPLE_PROCS */

  ret = ROK;
   ITADDZVUPDPEERCTR()

#ifdef BIT_64
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "ItLiSctFlcInd(pst, suId(%d), suAssocId(%d), reason(%d))\n",
          suId, suAssocId, reason));
#else
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "ItLiSctFlcInd(pst, suId(%d), suAssocId(%ld), reason(%d))\n",
          suId, suAssocId, reason));
#endif

#if (ERRCLASS & ERRCLS_INT_PAR)
   ITCHKPROTSTATE(EIT153, STITSCTSAP, suId, ret, IT_EVENT_CRIT);
   if (ret != ROK) 
   {
      ITZVUPDPEER();
      RETVALUE(ret);
   }
   if ((suId < 0) || (suId >= itGlobalCb.genCfg.maxNmbSctSap))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT154, (ErrVal) suId,
         "ItLiSctFlcInd: Invalid suId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_SUID, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.sctSap[suId] == (ItSctSapCb *)NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT155, (ErrVal) suId,
         "ItLiSctFlcInd: Null SCTSAP control block");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_STATE, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (suAssocId >= itGlobalCb.maxNmbAssoc)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT156, (ErrVal) suAssocId,
         "ItLiSctFlcInd: Invalid suAssocId");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);         
   }
   if (itGlobalCb.assoc[suAssocId] == (ItAssocCb *) NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT157, (ErrVal) suAssocId,
         "ItLiSctStaCfm: NULL association control block");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         (U16)LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.sctSap[suId]->sctSta.hlSt == LIT_SAP_UNBOUND)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT158, (ErrVal) suId,
         "ItLiSctStaCfm: SCT SAP not bound");
      itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_PAR_VAL, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#else
#ifndef DEBUGP
   UNUSED(suId);
#endif
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   itAcFlcInd(suAssocId, reason);

      ITZVUPDPEER();
   RETVALUE(ROK);
} /* end of ItLiSctFlcInd */



/*
 *
 *       Fun:   ItLiSctSetPriCfm
 *
 *       Desc:  Confirms a request for setting the primary destination address
 *
 *       Ret:   Failure:
 *
 *              Success:
 *
 *       Notes: <none>
 *
 *       File:  it_bdy1.c
 *
 */

#ifdef ANSI
PUBLIC S16 ItLiSctSetPriCfm
(
Pst           *pst,           /* post structure */
SuId          suId,           /* service user SAP identifier */
UConnId       suAssocId,      /* service user assoc identifier */
SctResult     result,         /* result */
SctCause      cause           /* cause */
)
#else
PUBLIC S16 ItLiSctSetPriCfm (pst, suId, suAssocId, result, cause)
Pst           *pst;           /* post structure */
SuId          suId;           /* service user SAP identifier */
UConnId       suAssocId;      /* service user assoc identifier */
SctResult     result;         /* result */
SctCause      cause;          /* cause */
#endif
{
   TRC3(ItLiSctSetPriCfm)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suAssocId);
   UNUSED(result);
   UNUSED(cause);

   RETVALUE(ROK);
} /* end of ItLiSctSetPriCfm */


/*
 *
 *       Fun:   ItLiSctHBeatCfm
 *
 *       Desc:  Confirms a heartbeat request
 *
 *       Ret:   Failure:
 *
 *              Success:
 *
 *       Notes: <none>
 *
 *       File:  it_bdy1.c
 *
 */

#ifdef ANSI
PUBLIC S16 ItLiSctHBeatCfm
(
Pst           *pst,           /* post structure */
SuId          suId,           /* service user SAP identifier */
UConnId       suAssocId,      /* service user assoc identifier */
CmNetAddr     *dstNAddr,      /* destination net address */
SctStatus     status,         /* status */
SctResult     result,         /* result */
SctCause      cause           /* cause */
)
#else
PUBLIC S16 ItLiSctHBeatCfm (pst, suId, suAssocId, dstNAddr, 
                            status, result, cause)
Pst           *pst;           /* post structure */
SuId          suId;           /* service user SAP identifier */
UConnId       suAssocId;      /* service user assoc identifier */
CmNetAddr     *dstNAddr;      /* destination net address */
SctStatus     status;         /* status */
SctResult     result;         /* result */
SctCause      cause;          /* cause */
#endif
{
   TRC3(ItLiSctHBeatCfm)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suAssocId);
   UNUSED(dstNAddr);
   UNUSED(status);
   UNUSED(result);
   UNUSED(cause);

   RETVALUE(ROK);
} /* end of ItLiSctHBeatCfm */


#ifdef ITSG
#ifdef SNTIWF
#ifndef SNT_BACK_COMP_MERGED_NIF
/*
*
*       Fun:   ItLiSntBndCfm
*
*       Desc:  Confirms a bind request.
*
*       Ret:   Failure:     RFAILED
*
*              Success:     ROK
*
*       Notes: <none>
*
*       File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSntBndCfm
(
Pst         *pst,             /* post structure */
SuId        suId,             /* service user SAP identifier */
U8          result            /* bind result */
)
#else
PUBLIC S16 ItLiSntBndCfm(pst, suId, result)
Pst         *pst;             /* post structure */
SuId        suId;             /* service user SAP identifier */
U8          result;           /* bind result */
#endif
{
   ItNSapCb  *sapCb;          /* MTP3 SAP CB */
   S16         ret;           /* return value*/

   TRC3(ItLiSntBndCfm)

#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItLiSntBndCfm() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_LI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#else
   UNUSED(pst);
#endif /* SS_MULTIPLE_PROCS */

  ret = ROK;
   ITADDZVUPDPEERCTR()

   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
      "ItLiSntBndCfm(pst, suId(%d), result(%d))\n", suId, result));


#if (ERRCLASS & ERRCLS_INT_PAR)
   ITCHKPROTSTATE(EIT159, STITNSAP, suId, ret, IT_EVENT_CRIT);
   if (ret != ROK) 
   {
      ITZVUPDPEER();
      RETVALUE(ret);
   }
   if ((suId < 0) || (suId >= itGlobalCb.genCfg.maxNmbNSap))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT160, (ErrVal) suId,
         "ItLiSntBndCfm: Invalid suId(MTP3)");
      itMiStaInd (STITNSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_SUID, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   sapCb = itGlobalCb.nSap[suId];

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sapCb == (ItNSapCb *)NULLP)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT161, (ErrVal) suId,
         "ItLiSntBndCfm: Null SNTSAP(MTP3) control block");
      itMiStaInd (STITNSAP, LCM_CATEGORY_INTERFACE, LIT_EVENT_LI_INV_PAR,
         LCM_CAUSE_INV_STATE, (U32) suId);
      ITZVUPDPEER();
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   switch (sapCb->sntSta.hlSt)
   {
      case LIT_SAP_WAIT_BNDCFM:
         if (result == CM_BND_OK)
         {
            /* Stop bind_wait_cfm timer */
            (Void) itTcStopTimer(&sapCb->tmrPrim);
            sapCb->sntSta.hlSt = LIT_SAP_BOUND;
            itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_BND_OK,
                       LCM_CAUSE_UNKNOWN, (U32) suId);
#ifdef ZV
            /* Update Bnd state */
            zvRTUpd(CMPFTHA_ACTN_MOD, ZV_NSAPCB,
                    CMPFTHA_UPDTYPE_SYNC, (Void *) sapCb, NULLP);
#endif
         }
         /* it021.106 - Add the handling for result as CM_BND_NOK. */
         else
         {
            /* Stop bind_wait_cfm timer */
            (Void) itTcStopTimer(&sapCb->tmrPrim);
            sapCb->sntSta.hlSt = LIT_SAP_UNBOUND;
            itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_BND_FAIL,
                       LCM_CAUSE_UNKNOWN, (U32) suId);
#ifdef ZV
            /* Update Bnd state */
            zvRTUpd(CMPFTHA_ACTN_MOD, ZV_NSAPCB,
                    CMPFTHA_UPDTYPE_SYNC, (Void *) sapCb, NULLP);
#endif
         }
         break;
      case LIT_SAP_UNBOUND:
#if (ERRCLASS & ERRCLS_DEBUG)
         ITLOGERROR(ERRCLS_DEBUG, EIT162, (ErrVal) suId,
                    "ItLiSntBndCfm: SNT(MTP3) SAP not in WAIT_BNDCFM state");
         itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_BND_FAIL,
                    LCM_CAUSE_INV_STATE, (U32) suId);
      ITZVUPDPEER();
         RETVALUE(RFAILED);
#endif /* ERRCLASS & ERRCLS_DEBUG */
         break;   
      case LIT_SAP_WAIT_OPENCFM:
         /* fall through */
      case LIT_SAP_BOUND:
         break;
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         ITLOGERROR(ERRCLS_DEBUG, EIT163, (ErrVal) suId,
                    "ItLiSntBndCfm: Invalid SNT(MTP3) SAP state");
         itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_BND_FAIL,
                    LCM_CAUSE_INV_STATE, (U32) suId);
      ITZVUPDPEER();
         RETVALUE(RFAILED);
#endif /* ERRCLASS & ERRCLS_DEBUG */
         break;   
   }
   /* Signal restart to management interworking for Nodal IWF SAP */
   (Void) itMifRestart(sapCb->sntCfg.nwkId);

   /* Signal event to MIF */
   (Void) itMifUserEvt(IT_MIF_USER_UP, sapCb);
 
      ITZVUPDPEER();
   RETVALUE(ROK);         
} /* end of ItLiSntBndCfm */
/*
*
*       Fun:   ItLiSntUDatInd
*
*       Desc:  Unit Data Indication on SNT interface from MTP3 .
*
*       Ret:   Failure:     RFAILED
*
*              Success:     ROK
*
*       Notes: <none>
*
*       File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSntUDatInd
(
Pst          *pst,              /* post structure */
SpId         spId,              /* service provider id */
Dpc          cgAdr,             /* calling address */
Dpc          cdAdr,             /* called address */
SrvInfo      srvInfo,           /* service information */
LnkSel       lnkSel,            /* link selection */
Buffer       *mBuf              /* data buffer */
)
#else
PUBLIC S16 ItLiSntUDatInd(pst, spId, cgAdr, cdAdr, srvInfo, lnkSel, mBuf)
Pst          *pst;              /* post structure */
SpId         spId;              /* service provider id */
Dpc          cgAdr;             /* calling address */
Dpc          cdAdr;             /* called address */
SrvInfo      srvInfo;           /* service information */
LnkSel       lnkSel;            /* link selection */
Buffer       *mBuf;             /* data buffer */
#endif
{
   S16         ret;           /* return code */
#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItLiSntUDatInd() failed, cannot derive itGlobalCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_LI,(itGlobalCb.itInit.prntBuf,
	       "---------------M3UA--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#else
   UNUSED(pst);
#endif /* SS_MULTIPLE_PROCS */

#ifdef BIT_64
   ITDBGP(DBGMASK_UI|IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf, 
     "ItLiSntUDatInd(spId (%d), cgAdr (%d), cdAdr (%d), " 
     "srvInfo (%d), lnkSel (%d))\n", 
     spId, cgAdr, cdAdr, srvInfo, lnkSel));
#else
   ITDBGP(DBGMASK_UI|IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf, 
     "ItLiSntUDatInd(spId (%d), cgAdr (%ld), cdAdr (%ld), " 
     "srvInfo (%d), lnkSel (%d))\n", 
     spId, cgAdr, cdAdr, srvInfo, lnkSel));
#endif
   /* Following function is called as it handles data from MTP3 as well  */

   ret = ItUiSntUDatReq(pst, spId, cgAdr, cdAdr, srvInfo, lnkSel, 
                                           (U8)((srvInfo >> 4) & 0x03), mBuf);

   RETVALUE(ret);         
} /* end of ItLiSntUDatInd */
#endif /* SNT_BACK_COMP_MERGED_NIF */
#endif /* SNTIWF */
#endif /* ITSG */


/* ------------------------------------------------------------------*
 * Interface Functions for SHT Interface                           *
 * ------------------------------------------------------------------*/

#ifdef IT_FTHA  

/*
*
*       Fun  :  System agent control Request 
*
*       Desc :  Processes system agent control request primitive
*
*       Ret  :  ROK  - ok
*
*       Notes:  <None>
*
*       File :  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItMiShtCntrlReq
(
Pst               *pst,       /* post structure          */
ShtCntrlReqEvnt   *reqInfo    /* system agent control request event */
)
#else
PUBLIC S16 ItMiShtCntrlReq(pst, reqInfo)
Pst               *pst;       /* post structure          */
ShtCntrlReqEvnt   *reqInfo;   /* system agent control request event */
#endif
{
   Pst               repPst;  /* reply post structure */
   ShtCntrlCfmEvnt   cfmInfo; /* system agent control confirm event */
   ItSctSapCb        *sctSap = (ItSctSapCb *) NULLP; /* SCT Sap control Block */
   ItNSapCb          *nSap;   /* SNT Sap control Block */
#ifdef IT_RUG
   S16               j;       /* Local Variable */
#endif /* IT_RUG */
   S16         ret;           /* return value*/

   ret = ROK;

#ifdef SS_MULTIPLE_PROCS
   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst, (Void **) &itGlobalCbPtr)!= ROK)
   {
       ITLOGERROR(ERRCLS_DEBUG, EITXXX,0,
	       "ItMiShtCntrlReq() failed, cannot derive zvCb");
       RETVALUE(FALSE);
   }

   ITDBGP(DBGMASK_MI,(zvCb.init.prntBuf,
	       "------------M3UA-PSF--------(procId(%d), entt(%d), inst(%d))------------\n",
	       pst->dstProcId, pst->dstEnt, pst->dstInst));
#endif /* SS_MULTIPLE_PROCS */

   ITADDZVUPDPEERCTR()

   TRC3(ItMiShtCntrlReq)



   /* zero out the confirm structure */
   IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt));

#if (ERRCLASS & ERRCLS_INT_PAR)
   ITCHKPROTSTATE(EIT164, STITGEN, NULLD, ret, IT_EVENT_CRIT);
   if (ret != ROK) 
   {
      ITZVUPDPEER();
      RETVALUE(ret);
   }
#endif

   /* fill reply pst structure */
   repPst.dstProcId = pst->srcProcId;
   repPst.dstEnt    = pst->srcEnt;
   repPst.dstInst   = pst->srcInst;
   repPst.prior     = reqInfo->hdr.response.prior;
   repPst.route     = reqInfo->hdr.response.route;
   repPst.selector  = reqInfo->hdr.response.selector;
   repPst.event     = EVTNONE;
   /* it017.106 - Update the source procId and instance from
    * lmPst structure. lmPst is now initialised in itActvInit. */
   repPst.srcProcId = itGlobalCb.itInit.lmPst.srcProcId;
   repPst.srcEnt    = ENTIT;
   repPst.srcInst   = itGlobalCb.itInit.lmPst.srcInst;
   repPst.region    = reqInfo->hdr.response.mem.region; 
   repPst.pool      = reqInfo->hdr.response.mem.pool; 

   /* fill reply transaction Id */
   cfmInfo.transId = reqInfo->hdr.transId;

   /* fill request type in reply */
#ifdef IT_RUG
   cfmInfo.reqType = reqInfo->reqType;
#endif /* IT_RUG */

   /* check if general configuration done */
   if (itGlobalCb.itInit.cfgDone != TRUE)
   {
      cfmInfo.status.status = LCM_PRIM_NOK;
      cfmInfo.status.reason = LCM_REASON_GENCFG_NOT_DONE;

      ItMiShtCntrlCfm(&repPst, &cfmInfo);
      ITZVUPDPEER();
      RETVALUE(ROK); 
   }

   /* fill status value */
   cfmInfo.status.reason = LCM_REASON_NOT_APPL;
   
   switch (reqInfo->reqType)
   {
      case SHT_REQTYPE_BND_ENA:   /* system agent control bind enable */
         switch (reqInfo->s.bndEna.grpType)
         {
            S16 i;
            case SHT_GRPTYPE_ALL:
               /* 
                * go through all the sap control blocks and start bind  
                * enable procedure on those SAPs for which              
                * (pst->dstProcId == reqInfo->s.bndEna.dstProcId) && 
                * (pst->dstEnt == reqInfo->s.bndEna.dstEnt) &&       
                * (pst->dstInst == reqInfo->s.bndEna.dstInst)        
                */
                
                /* call function for all SAPs */
                for (i = 0; i < itGlobalCb.genCfg.maxNmbSctSap; i++)
                {
                   sctSap = itGlobalCb.sctSap[i];
                   if (sctSap != (ItSctSapCb *) NULLP)
                   {
                      if ((sctSap->pst.dstProcId == reqInfo->s.bndEna.dstProcId)
                         && (sctSap->pst.dstEnt == reqInfo->s.bndEna.dstEnt.ent)
                         && (sctSap->pst.dstInst == 
                             reqInfo->s.bndEna.dstEnt.inst))
                      {
                         /* sctSap found, bind it */
                         if (sctSap->contEnt != ENTSM)
                         {
#ifdef IT_ENDPOPEN_ON_BNDENA
                            /* it015.106: Changes to open an endpoint also, 
                               if SHT control request was received for binding
                               a sap */
                            sctSap->bndEnaReq = TRUE;
#endif

                            ret = itLiBndSap(sctSap->sctCfg.suId, 
                                               &(cfmInfo.status), TRUE);
#ifdef ZV
                            if (ret == ROK)
                            {
                               zvRTUpd(CMPFTHA_ACTN_MOD, ZV_SCTSAPCB,
                                      CMPFTHA_UPDTYPE_SYNC, 
                                      (Void *)itGlobalCb.sctSap[i], NULLP);
                            }
#endif
                         }
                      }
                   }
                }
#ifdef ITSG
#ifndef SNT_BACK_COMP_MERGED_NIF
                /* call function for all MTP3-NSAPs */
                for (i = 0; i < itGlobalCb.genCfg.maxNmbNSap; i++)
                {
                   nSap = itGlobalCb.nSap[i];
                   if ((nSap != (ItNSapCb *) NULLP)
                      && (nSap->sntCfg.suType == LIT_SP_MTP3))
                   {
#ifdef IT_RUG
                      if ((nSap->pst.dstProcId == reqInfo->s.bndEna.dstProcId)
                         && (nSap->pst.dstEnt == reqInfo->s.bndEna.dstEnt.ent) 
                         && (nSap->pst.dstInst == 
                             reqInfo->s.bndEna.dstEnt.inst))
                      {
                         cfmInfo.status.reason = LCM_REASON_NOT_APPL;
                         break;
                      }
#endif /* IT_RUG */
                      if ((nSap->pst.dstProcId == reqInfo->s.bndEna.dstProcId)
                         && (nSap->pst.dstEnt == reqInfo->s.bndEna.dstEnt.ent) 
                         && (nSap->pst.dstInst == 
                             reqInfo->s.bndEna.dstEnt.inst))
                      {
                         if (nSap->contEnt != ENTSM)
                         {
                            ret = itLiBndMtp3Sap(nSap->sntCfg.sapId, 
                                                   &(cfmInfo.status), TRUE);
#ifdef ZV
               /* Update the controlling entity */
                            if (ret == ROK)
                            {
                               zvRTUpd(CMPFTHA_ACTN_MOD, ZV_NSAPCB,
                                       CMPFTHA_UPDTYPE_SYNC, 
                                      (Void *) itGlobalCb.nSap[i], NULLP);
                            }
#endif
                         }
                      }
                   }
                }
#endif
#endif /* ITSG */
                break;

             case SHT_GRPTYPE_ENT:
                /* 
                 * go through all the sap control blocks and start bind  
                 * enable procedure on those SAPs for which              
                 * (pst->dstEnt == reqInfo->s.bndEna.dstEnt) &&       
                 * (pst->dstInst == reqInfo->s.bndEna.dstInst)        
                 */
                
                /* call function for all SAPs */
                for (i = 0; i < itGlobalCb.genCfg.maxNmbSctSap; i++)
                {
                   sctSap = itGlobalCb.sctSap[i];
                   if (sctSap != (ItSctSapCb *) NULLP)
                   {
#ifdef IT_RUG
                      if ((sctSap->pst.dstEnt == reqInfo->s.bndEna.dstEnt.ent) 
                         && (sctSap->pst.dstInst == reqInfo->s.bndEna.dstEnt.inst)
                         && (sctSap->remIntfValid == FALSE))
                      {
                         cfmInfo.status.reason = LCM_REASON_SWVER_NAVAIL;
                         break;
                      }
#endif /* IT_RUG */
                      if ((sctSap->pst.dstEnt == reqInfo->s.bndEna.dstEnt.ent) 
                         && (sctSap->pst.dstInst == 
                             reqInfo->s.bndEna.dstEnt.inst))
                      {
                         /* sctSap found, bind it */
                         if (sctSap->contEnt != ENTSM)
                         {
#ifdef IT_ENDPOPEN_ON_BNDENA
                            /* it015.106: Changes to open an endpoint also, 
                               if SHT control request was received for binding
                               a sap */
                            sctSap->bndEnaReq = TRUE;
#endif

                            ret = itLiBndSap(sctSap->sctCfg.suId, 
                                             &(cfmInfo.status), TRUE);
#ifdef ZV
                            if (ret == ROK)
                            {
                               zvRTUpd(CMPFTHA_ACTN_MOD, ZV_SCTSAPCB,
                                      CMPFTHA_UPDTYPE_SYNC, 
                                      (Void *)itGlobalCb.sctSap[i], NULLP);
                            }
#endif
                         }
                      }
                   }
                }
#ifdef ITSG
#ifndef SNT_BACK_COMP_MERGED_NIF
                /* call function for all MTP3-NSAPs */
                for (i = 0; i < itGlobalCb.genCfg.maxNmbNSap; i++)
                {
                   nSap = itGlobalCb.nSap[i];
                   if ((nSap != (ItNSapCb *) NULLP)
                      && (nSap->sntCfg.suType == LIT_SP_MTP3))
                   {
#ifdef IT_RUG
                      if ((nSap->pst.dstEnt == reqInfo->s.bndEna.dstEnt.ent) 
                         && (nSap->pst.dstInst == reqInfo->s.bndEna.dstEnt.inst)
                         && (sctSap->remIntfValid == FALSE))
                      {
                         cfmInfo.status.reason = LCM_REASON_SWVER_NAVAIL;
                         break;
                      }
#endif /* IT_RUG */
                      if ((nSap->pst.dstEnt == reqInfo->s.bndEna.dstEnt.ent) 
                         && (nSap->pst.dstInst == 
                             reqInfo->s.bndEna.dstEnt.inst))
                      {
                         if (nSap->contEnt != ENTSM)
                         {
                            ret = itLiBndMtp3Sap(nSap->sntCfg.sapId, 
                                                   &(cfmInfo.status), TRUE);
#ifdef ZV
               /* Update the controlling entity */
                            if (ret == ROK)
                            {
                               zvRTUpd(CMPFTHA_ACTN_MOD, ZV_NSAPCB,
                                       CMPFTHA_UPDTYPE_SYNC, 
                                      (Void *) itGlobalCb.nSap[i], NULLP);
                            }
#endif
                         }
                      }
                   }
                }
#endif
#endif /* ITSG */
                break;
             default:
                cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
                break;
          }
          break;

       case SHT_REQTYPE_UBND_DIS:  /* system agent control unbind disable */
#ifdef IT_RUG
         /* Delete the stored version information for that SAP */
         for(j = itGlobalCb.numIntfInfo - 1; j >= 0; j--)
         {
            if(itGlobalCb.intfInfo[j].grpType == reqInfo->s.ubndDis.grpType)
            {
               switch(itGlobalCb.intfInfo[j].grpType)
               {
                  case SHT_GRPTYPE_ALL:
                     if(itGlobalCb.intfInfo[j].dstProcId ==
                                        reqInfo->s.ubndDis.dstProcId &&
                        itGlobalCb.intfInfo[j].dstEnt.ent ==
                                        reqInfo->s.ubndDis.dstEnt.ent &&
                        itGlobalCb.intfInfo[j].dstEnt.inst ==
                                        reqInfo->s.ubndDis.dstEnt.inst)
                     {
#ifdef ZV
                        /* Delete The interface version at standby/shadows */
                         zvRTUpd(CMPFTHA_ACTN_DEL, ZV_VERINFOCB,
                                      CMPFTHA_UPDTYPE_SYNC,
                                      (Void *) &itGlobalCb.intfInfo[j], NULLP);
#endif /* ZV */

                        /* delete the version information by copying the
                         * last version info into current location */
                        cmMemcpy((U8*) &itGlobalCb.intfInfo[j],
                                 (U8*) &itGlobalCb.intfInfo[itGlobalCb.numIntfInfo-1],
                                 sizeof(ShtVerInfo));
                        itGlobalCb.numIntfInfo--;
                     }
                     break;

                  case SHT_GRPTYPE_ENT:
                     if(itGlobalCb.intfInfo[j].dstEnt.ent ==
                                        reqInfo->s.ubndDis.dstEnt.ent &&
                        itGlobalCb.intfInfo[j].dstEnt.inst ==
                                        reqInfo->s.ubndDis.dstEnt.inst)
                     {
#ifdef ZV
                        /* Delete The interface version at standby/shadows */
                         zvRTUpd(CMPFTHA_ACTN_DEL, ZV_VERINFOCB,
                                      CMPFTHA_UPDTYPE_SYNC,
                                      (Void *) &itGlobalCb.intfInfo[j], NULLP);
#endif /* ZV */
                        /* delete the version information by copying the
                         * last version info into current location */
                        cmMemcpy((U8*) &itGlobalCb.intfInfo[j],
                                 (U8*) &itGlobalCb.intfInfo[itGlobalCb.numIntfInfo-1],
                                 sizeof(ShtVerInfo));
                        itGlobalCb.numIntfInfo--;
                     }
                     break;
               } /* switch itGlobalCb.numIntfInfo */
            } /* if itGlobalCb.numIntfInfo */
         } /* for (j = itGlobalCb.numIntfInfo) */
#endif /* IT_RUG */

          switch (reqInfo->s.ubndDis.grpType)
          {
             S16 i;
             case SHT_GRPTYPE_ALL:
                /* 
                 * go through all the sap control blocks and start unbind 
                 * disable procedure on those SAPs for which              
                 * (pst->dstProcId == reqInfo->s.ubndDis.dstProcId) && 
                 * (pst->dstEnt == reqInfo->s.ubndDis.dstEnt) &&       
                 * (pst->dstInst == reqInfo-.s.ubndDis.dstInst)        
                 */
                
                /* call function for all SCT SAPs */
                for (i = 0; i < itGlobalCb.genCfg.maxNmbSctSap; i++)
                {
                   sctSap = itGlobalCb.sctSap[i];
                   if (sctSap != (ItSctSapCb *) NULLP)
                   {
                      if ((sctSap->pst.dstProcId ==
                                                reqInfo->s.ubndDis.dstProcId)
                        && (sctSap->pst.dstEnt == reqInfo->s.ubndDis.dstEnt.ent)
                         && (sctSap->pst.dstInst == 
                             reqInfo->s.ubndDis.dstEnt.inst))
                      {
                         if (sctSap->sctSta.hlSt != LIT_SAP_UNBOUND)
                         {
                            (Void ) itLiReleaseSap(sctSap->sctCfg.suId, 
                                                   &(cfmInfo.status));
#ifdef ZV
                             {
                                zvRTUpd(CMPFTHA_ACTN_MOD, ZV_SCTSAPCB,
                                CMPFTHA_UPDTYPE_SYNC, (Void *) sctSap, NULLP);
                             }
#endif
                         }
                      }
                   }
                }


                /* call function for all NSAPs */
                for (i = 0; i < itGlobalCb.genCfg.maxNmbNSap; i++)
                {
                   nSap = itGlobalCb.nSap[i];
#ifdef DI
                   if ((nSap != NULLP) &&
                      (reqInfo->s.ubndDis.dstEnt.ent == ENTSI) &&
                      (nSap->sntCfg.suType == SI_ISUP))
                   {
                      U8     sapBndState;
                      sapBndState = DiDitSetUpSapState(DIT_PROCID_BNDSTA,
                                           reqInfo->s.ubndDis.dstProcId,
                                           reqInfo->s.ubndDis.dstEnt.inst,
                                           nSap->sntCfg.sapId, DIT_UNBND);

                      /* Temporarily mark SAP as unbound to do peer upd  *
                       * SAP is updated with unbind information as recvd *
                       * in the unbind request from SH                   */
                      nSap->sntSta.hlSt = LIT_SAP_UNBOUND;
                      nSap->pst.dstProcId = reqInfo->s.ubndDis.dstProcId;
                      nSap->pst.dstInst = reqInfo->s.ubndDis.dstEnt.inst;
#ifdef ZV
                      zvRTUpd(CMPFTHA_ACTN_MOD, ZV_NSAPCB,
                      CMPFTHA_UPDTYPE_SYNC, (Void *) nSap, NULLP);
#endif
                      /* If all instances have unbound mark SAP unbound */
                      if(sapBndState != DIT_SAP_UNBOUND)
                        nSap->sntSta.hlSt = LIT_SAP_BOUND;
                      /* An update to the peer was generated. The counter *
                      * is incremented again since the loop has to move  *
                      * onto the next SAP and generate updates for it    */
                     ITADDZVUPDPEERCTR()
                   }
                   else
#endif /* DI */
                   if (nSap != (ItNSapCb *) NULLP)
                   {
                      if ((nSap->pst.dstProcId == reqInfo->s.ubndDis.dstProcId)
                         && (nSap->pst.dstEnt == reqInfo->s.ubndDis.dstEnt.ent) 
                         && (nSap->pst.dstInst == 
                             reqInfo->s.ubndDis.dstEnt.inst))
                      {
                         if (nSap->sntSta.hlSt == LIT_SAP_BOUND)
                         {
#ifdef IT_RUG
                            nSap->remIntfValid = FALSE;
#endif /* IT_RUG */

                            (Void) itUiUBndSap(nSap, &(cfmInfo.status));
#ifdef ZV
                  /* SYNC update needs to be done before confirm can be sent to
                     LM  */

                   zvRTUpd(CMPFTHA_ACTN_MOD, ZV_NSAPCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) nSap, NULLP);
#endif
                         }
                      }
                   }
                }

                break;

             case SHT_GRPTYPE_ENT:
                /* 
                 * go through all the sap control blocks and start unbind 
                 * disable procedure on those SAPs for which              
                 * (pst->dstEnt == reqInfo->s.ubndDis.dstEnt) &&       
                 * (pst->dstInst == reqInfo->s.ubndDis.dstInst)        
                 */
                
                /* call function for all SCT SAPs */
                for (i = 0; i < itGlobalCb.genCfg.maxNmbSctSap; i++)
                {
                   sctSap = itGlobalCb.sctSap[i];
                   if (sctSap != (ItSctSapCb *) NULLP)
                   {
                      if ((sctSap->pst.dstEnt == reqInfo->s.ubndDis.dstEnt.ent) 
                         && (sctSap->pst.dstInst == 
                             reqInfo->s.ubndDis.dstEnt.inst))
                      {
                         (Void ) itLiReleaseSap(sctSap->sctCfg.suId, 
                                         &(cfmInfo.status));
#ifdef ZV
                         {
                            zvRTUpd(CMPFTHA_ACTN_MOD, ZV_SCTSAPCB,
                                   CMPFTHA_UPDTYPE_SYNC, (Void *)sctSap, NULLP);
                         }
#endif
                      }
                   }
                }

                /* call function for all NSAPs */
                for (i = 0; i < itGlobalCb.genCfg.maxNmbNSap; i++)
                {
                   nSap = itGlobalCb.nSap[i];
#ifdef DI
                  if ((nSap != NULLP) &&
                      (reqInfo->s.ubndDis.dstEnt.ent == ENTSI) &&
                      (nSap->sntCfg.suType == SI_ISUP))
                  {
                      U8     sapBndState;
                      sapBndState = DiDitSetUpSapState(DIT_BNDSTA, PROCIDNC,
                                           reqInfo->s.ubndDis.dstEnt.inst,
                                           nSap->sntCfg.sapId, DIT_UNBND);
                      /* Temporarily mark SAP as unbound and update instance *
                       * to be unbound in the SAP. The bind state will be    *
                       * put back to bound if there as more instance on SAP  */
                      nSap->sntSta.hlSt = LIT_SAP_UNBOUND;
                      nSap->pst.dstInst = reqInfo->s.ubndDis.dstEnt.inst;
#ifdef ZV
                      zvRTUpd(CMPFTHA_ACTN_MOD, ZV_NSAPCB,
                             CMPFTHA_UPDTYPE_SYNC, (Void *)nSap, NULLP);
#endif
                      /* Send update to peer to mark instance as unboud */
                      ITZVUPDPEER()

                      /* SAP is unbound after all instances are unbound */
                      if(sapBndState != DIT_SAP_UNBOUND)
                         nSap->sntSta.hlSt = LIT_SAP_BOUND;
                      /* An update to the peer was generated. The counter *
                      * is incremented again since the loop has to move  *
                      * onto the next SAP and generate updates for it    */
                     ITADDZVUPDPEERCTR()
                  }
                  else
#endif/* DI */

                   if (nSap != (ItNSapCb *) NULLP)
                   {
                      if ((nSap->pst.dstEnt == reqInfo->s.ubndDis.dstEnt.ent) 
                         && (nSap->pst.dstInst == 
                             reqInfo->s.ubndDis.dstEnt.inst))
                      {
#ifdef IT_RUG
                         nSap->remIntfValid = FALSE;
#endif /* IT_RUG */
                         (Void) itUiUBndSap(nSap, &(cfmInfo.status));
#ifdef ZV
                  /* SYNC update needs to be done before confirm can be sent to
                     LM  */

                   zvRTUpd(CMPFTHA_ACTN_MOD, ZV_NSAPCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) nSap, NULLP);
#endif
                      }
                   }
                }

                break;

             default:
                cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
                break;
           }
           break;

#ifdef IT_RUG
       case SHT_REQTYPE_GETVER:      /* system agent get version */
          itGetVer(&cfmInfo.t.gvCfm);
          break;

       case SHT_REQTYPE_SETVER:      /* system agent set version */
          itSetVer(&reqInfo->s.svReq, &cfmInfo.status);
#ifdef ZV
          /* Update verinfo */
          zvRTUpd(CMPFTHA_ACTN_MOD, ZV_VERINFOCB,
                  CMPFTHA_UPDTYPE_NORMAL, (Void *) &reqInfo->s.svReq, NULLP);

#endif
          break;
#endif /* IT_RUG */

       default:
          cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
          break;
   }

   if (cfmInfo.status.reason != LCM_REASON_NOT_APPL)
   {
      cfmInfo.status.status = LCM_PRIM_NOK;
   }
   else
   {
      cfmInfo.status.status = LCM_PRIM_OK;
   }
   
   ITZVUPDPEER();
   /* send the response */
   ItMiShtCntrlCfm(&repPst, &cfmInfo);
      
   RETVALUE(ROK);
} /* end ItMiShtCntrlReq */
#endif /* IT_FTHA */

#ifdef DI
/*
*
*      Fun:   Generate UPU
*
*      Desc:  This function is provided for generating UPU from ISUP LDF
*
*      Ret:   ROK       - ok
*             RFAILED   - failure
*
*      Notes: None
*
*      File:  it_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ItDitSndUPU
(
Dpc  dpc,                   /* destination point code */
Dpc  opc,                   /* originating point code */
SpId spId,                  /* spId */
U8   cause                  /* Cause for UPU generation */
)
#else
PUBLIC S16 ItDitSndUPU(dpc, opc, spId, cause)
Dpc  dpc;                   /* destination point code */
Dpc  opc;                   /* originating point code */
SpId spId;                  /* spId */
U8   cause;                 /* Cause for UPU generation */
#endif
{

   ItNSapCb *cb;            /* Sap Control block */
   ItDpcCb  *dpcCb;         /* DPC Control block */
   ItNwkCb  *nwkCb;         /* Network Control Block */

   TRC3(ItDitSndUPU)

   UNUSED(cause);


#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((spId < 0) || (spId >= (SpId) itGlobalCb.genCfg.maxNmbNSap))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT165, (ErrVal) spId,
         "ItDitSndUPU invalid spId");
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
         LCM_CAUSE_INV_SPID, (U32)spId);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((cb = itGlobalCb.nSap[spId]) == (ItNSapCb *)NULLP) 
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT166, (ErrVal) spId,
         "ItDitSndUPU SAP unconfigured");
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
         LCM_CAUSE_INV_SPID, (U32)spId);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   if (cb->sntSta.hlSt != LIT_SAP_BOUND)
   {
      /* inform layer manager */
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
         LCM_CAUSE_INV_STATE, (U32)spId);
      RETVALUE(RFAILED);
   }

   if (itGlobalCb.genCfg.nodeType == LIT_TYPE_ASP)
   {
      itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
         LCM_CAUSE_INV_STATE, (U32)spId);
      RETVALUE(RFAILED);
   }

   nwkCb = itGlobalCb.nwk[cb->sntCfg.nwkId];
   if (itAtGetDpc(cb->sntCfg.nwkId, dpc, &dpcCb) == ROK)
   {
         (Void) itMifDpcEvt(FALSE, (UConnId) NULLD, IT_MIF_DATAREQ,
                          IT_MIF_PC_UPU, cb->sntCfg.nwkId, dpc,
                          opc, 0x80, LIT_SU_ISUP, (ItDpcCb *) NULLP);
   }
   RETVALUE(ROK);
}
#endif /* DI */


/********************************************************************30**

  End of file:     it_bdy1.c@@/main/starent_rel_1.1_dev/5 - Fri Sep 16 17:36:56 2005

**********************************************************************31*/

/********************************************************************40**

Notes:

**********************************************************************41*/

/********************************************************************50**

**********************************************************************51*/

/********************************************************************60**

  Revision history:

**********************************************************************61*/
/********************************************************************70**

  version    initials                   description
  -----------  ---------  ------------------------------------------------

**********************************************************************71*/

/********************************************************************80**

**********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/3      ---      pn   1. initial release.
             
/main/3      ---      nt   1. Changes for TCR18,
                              the controlling entity is added as part
                              of Upper and Lower SAPs unbind and bind 
                              operations.
                           2. Extern definition of ItMiShtCntrlReq and 
                              ItMiShtCntrlCfm added
                           3. System agent cntrl Rqst function added.
                           4. Changes for removing warnings.
                           5. Updates to Release 1.2
/main/4      ---      sg   1. Used SLS hash defines.
             ---      sg   2. Changes for additional features.
             ---      sg   3. Update to Release 1.3.
/main/5      ---      sg   1. Update to Release 1.4
 
            it007.104 cg   1. action, subAction field are copied in
                              CntrlCfm
/main/5     it014.104 vt   1. To rectify the incorrect debug Print. 
/main/5     it015.104 vt   1. Parameter spAssocID added for cleaning 
                              up the Association
/main/5     it016.104 vt   1. Proper IDs in statistics indications to LM 
                           2. Status indications detailed for Assoc Term 
/main/5     it018.104 vt   1. Assocation Abort Handling 
/main/6      ---      nt   1. Update to Release 1.5
/main/7      ---      rs   1. Update to Release 1.6.
/main/7    it001.106  sg   1. Changes in ItLiMitStaReq to update 
                              itGlobalCb.mgmt structure for the DPC status 
                              and SCT SAP version information.
                           2. Changes in ItLiMitStaReq to update the DPC status
                              to LIT_DPC_CONGESTED based on congLevel.
/main/7    it002.106  sg   1. Changes in ItLiMitStaReq to update sctSuId in
                              itGlobalCb.mgmt structure for STITPSPRKID.
/main/7    it004.106  sg   1. Changes in ItMiLitCntrlReq for Terminate assoc,
                              to pass abrtFlg as FALSE in itAcTerm() for 
                              graceful shutdown.
/main/7    it006.106  sg   1. Status indications added in ItLiSctEndpCloseCfm().
/main/7    it012.106  jc   1. Added support for SS_MULTIPLE_PROCS
/main/7    it013.106  sg   1. In ItUiSntUDatReq, removed the validation of 
                              lnkSel when slsLen is LIT_SLS8 to remove warning.
                           2. Change in ItLiSctDatInd to accept data with
                              indication type set as SCT_UNORDER_DAT.
/main/7    it015.106  sg   1. Changes to open an endpoint also, on
                              receiving SHT control request for Binding
                              the SCT SAP through system agent. 
                              Changes are under new compile time flag
                              "IT_ENDPOPEN_ON_BNDENA"
                           2. SuId replaced with SpId, for bind request
                              towards MTP3. 
/main/7    it016.106  sg   1. Changes for new association congestion and
                              unavailability statistics.
                           2. In ItUiSntUDatReq added case for slsLen of
                              LIT_SLS8 to prevent fall through to default 
                              leg.
                           3. Change in itActvInit, when SS_MULTIPLE_PROCS 
                              is defined, to use ITSHUTDOWN to check if this 
                              function is called from itMiShutdown.
/main/7    it017.106  sg   1. Changes under LITV4 flag in ItMiLitStaReq to
                              update srcAddrLst in SCT SAP status structure
                              and ItSstaPs structure for PS status.
                           2. Change in itActvInit to initialise the lmPst
                              structure with srcProcId, entity and instance.
                           3. Change in ItMiShtCntrlReq to set reply post with
                              srcProcId and instance using lmPst.
/main/7    it019.106  sg   1. Changes under LITV4 flag in ItMiLitStaReq to
                              update routing context mode in PS status.
/main/7    it021.106  sg   1. Change in ItLiSctEndpOpenCfm to add the handling
                              for result as SCT_NOK.
                           2. Changes in ItLiSctBndCfm and ItLiSntBndCfm to add
                              handling for result as CM_BND_NOK.
/main/7    it022.106  sg   1. Added usage of abrtFlag for PSP Deletion cntrlReq.
/main/7    it022.106  sg   1. Added DFTHA-hooks in ItLiSntStaQryCfm.
/main/7    it023.106  sg   1. Changes in ItMiLitStsReq to update PS statistics
                              under compilation flag LITV6.
*********************************************************************91*/
