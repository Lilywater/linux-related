/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_ss7.h"        /* common SS7 */
#include "cm_tpt.h"        /* common transport defines */
#include "lit.h"           /* layer management M3UA  */
#include "sct.h"           /* SCT interface */
#include "snt.h"           /* SNT interface */
#ifdef IT_FTHA             
#include "sht.h"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "it.h"            /* M3UA internal defines */
#include "it_err.h"        /* M3UA error */
#ifdef DI
#include "dit.h"
#endif /* DI */
#ifdef ZV
#include "cm_ftha.h"
#include "cm_psfft.h"          /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.h"
#include "cmzvdvlb.h"
#endif /* ZV_DFTHA */
#include "mrs.h"
#include "lzv.h"
#include "zv.h"            /* m3ua  PSF */
#endif /* ZV */

/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_ss7.x"        /* common SS7 */
#include "cm_tpt.x"        /* common transport */
#include "sct.x"           /* SCT interface */
#ifdef IT_FTHA             
#include "sht.x"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "lit.x"           /* layer management M3UA */
#include "snt.x"           /* SNT interface */
#include "it.x"            /* M3UA internal typedefs */
#ifdef DI
#include "dit.x"
#endif /* DI */
#ifdef ZV
#include "cm_ftha.x"
#include "cm_psfft.x"
#ifdef ZV_DFTHA
#include "cmzvdv.x"
#include "cmzvdvlb.x"
#endif
#include "mrs.x"
#include "lzv.x"
#include "zv.x"            /* m3ua PSF */
#endif /* ZV */
#ifdef CP_OAM_SUPPORT
#include "it_nms.h"
#include "it_cfg.h"
#include "sm.h"
#include "sm.x"
#endif
#include "it_star.h"

ItSmCb  itSmCb;
Pst     gstSmPst;

#ifdef ITASP
PUBLIC VOID itSgReconnect(ItPspId pspId)
{
    ItPspCb*   pPspCb = NULLP;

    TRC2(itSgReconnect);
    pPspCb = itGlobalCb.psp[pspId];
    if (pPspCb != (ItPspCb *) NULLP)
    {
        itTcStartTimer(&(pPspCb->assoc[0].tmrReconnect), (PTR)pPspCb,
        	   IT_SG_TMR_RECONNECT, &(itSmCb.tmr.tmrReconnect));
        /*2006/8/16 chenning �޸�Ϊ���ܴ�ӡ���Զ�������ʱ��״̬*/   
        if ( FALSE == pPspCb->pspCfg.autostartstatus )
        {
            pPspCb->pspCfg.autostartstatus = TRUE;
        }
    }
}

PUBLIC VOID itAspReconnectTimeout(ItPspCb * pspCb)
{
    ItMgmt	itMgmt;
    ItCntrl	*     itCntrl;
    U16		cAsNum=0;
    U16 		idx=0;
    U16           ii=0;
    S16           ret = 0;
    
    TRC2(itAspReconnectTimeout);
    
    cmMemset((U8*)&itMgmt, 0, sizeof(ItMgmt));
    itMgmt.hdr.response.selector = 0;	/* Loosely */
    itMgmt.hdr.response.prior = 0;	/* 0 */
    itMgmt.hdr.response.route = 0;	/* 0 */
    itMgmt.hdr.response.mem.region  = DFLT_REGION;
    itMgmt.hdr.response.mem.pool = DFLT_POOL;

    itCntrl = &itMgmt.t.cntrl;


    gstSmPst.selector 	= 0;               	/* selector,loose coupled */
    gstSmPst.region 	= DFLT_REGION;     	/* region */
    gstSmPst.pool 	= DFLT_POOL;        /* pool */
    gstSmPst.prior 	= 0;                /* priority */
    gstSmPst.route 	= 0;                /* route */
    gstSmPst.dstProcId= SFndProcId();  	/* destination processor id */
    gstSmPst.dstEnt 	= ENTIT;            /* destination entity*/
    gstSmPst.dstInst 	= 0;        /* destination instance */
    gstSmPst.srcProcId= SFndProcId();   	/* source processor id */
    gstSmPst.srcEnt 	= ENTSM;            /* source entity */
    gstSmPst.srcInst 	= 0;        /* source instance */

    switch (pspCb->pspSta.assocSta[0].aspSt) 
    {
        case LIT_ASP_DOWN:
        { 
            if ( pspCb->pspSta.assocSta[0].hlSt == LIT_ASSOC_DOWN )
            {
/*chenning ���Ӳ�Ʒ��������M3UA��ʼ��ʱ����������2006 9 18*/
                if ( LIT_RDST_DEFAULT == pspCb->pspSta.assocSta[0].readySetupSt )
                {
                    pspCb->pspSta.assocSta[0].readySetupSt = LIT_RDST_ASPUP;
                    if(IT_AUTO_CLIENTSIDE)
                    {
                        itMgmt.hdr.elmId.elmnt = STITPSP;    
                        itCntrl->s.pspId = pspCb->pspCfg.pspId;
                        itCntrl->action     =  AESTABLISH;
                        itCntrl->subAction  =  SAELMNT;                   
                        if ( ROK != ItMiLitCntrlReq(&gstSmPst, &itMgmt) )
                        {
                            pspCb->pspSta.assocSta[0].readySetupSt = LIT_RDST_DEFAULT;
                        }
                    }
                }
                
            }
            else
            {
                if ( LIT_RDST_ASPUP == pspCb->pspSta.assocSta[0].readySetupSt )
                {
                    pspCb->pspSta.assocSta[0].readySetupSt = LIT_RDST_DEFAULT;
                    itMgmt.hdr.elmId.elmnt = STITPSP;    
                    itCntrl->s.pspId = pspCb->pspCfg.pspId;
                    itCntrl->action     =  AASPUP;
                    itCntrl->subAction  =  SAELMNT;

                    itCntrl->t.aspm.nmbPs = (U8)pspCb->assoc[0].nmbPs;
                    itCntrl->t.aspm.info[0] = '\0';

                    if ( ROK != ItMiLitCntrlReq(&gstSmPst, &itMgmt) )
                    {
                        pspCb->pspSta.assocSta[0].readySetupSt = LIT_RDST_ASPUP;
                    }
                }
            }
            break;
        }
	
        case LIT_ASP_INACTIVE:
        {
            itMgmt.hdr.elmId.elmnt = STITPSP;    
            itCntrl->s.pspId = pspCb->pspCfg.pspId;
            itCntrl->action     =  AASPAC;
            itCntrl->subAction  =  SAELMNT;
            itMgmt.t.cntrl.t.aspm.autoCtx = FALSE;
            cAsNum = pspCb->assoc[0].nmbPs;


            if( pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP && pspCb->pspCfg.ipspMode == LIT_IPSPMODE_DE )
            {
                for( ii=0; ii<cAsNum; ii++ )
                {
                    if ( (pspCb->assoc[0].ps[ii] != (ItPsCb *)NULLP) && (pspCb->assoc[0].ps[ii]->psCfg.lclFlag) )
                    {
                        itCntrl->t.aspm.psLst[idx] = pspCb->assoc[0].ps[ii]->psCfg.psId;
                        idx++;
                    }
                }
                cAsNum = idx;
            }
            else
            {
                for( ii=0; ii<cAsNum; ii++ )
                {
                    if ( (pspCb->assoc[0].ps[ii] != (ItPsCb *)NULLP) && !(pspCb->assoc[0].ps[ii]->psCfg.lclFlag ))
                    {
                        itCntrl->t.aspm.psLst[idx] = pspCb->assoc[0].ps[ii]->psCfg.psId;
                        idx++;
                    }
                }
                cAsNum = idx;
            }

            itCntrl->t.aspm.nmbPs = (U8)cAsNum;
            itCntrl->t.aspm.info[0] = '\0';       

            (VOID)ItMiLitCntrlReq(&gstSmPst, &itMgmt);
            break;
        }

        case  LIT_ASP_ACTIVE:
        {
            if(pspCb->pspCfg.pspType ==LIT_PSPTYPE_IPSP && pspCb->pspCfg.ipspMode == LIT_IPSPMODE_DE )
            {
                itMgmt.hdr.elmId.elmnt = STITPSP;    
                itCntrl->s.pspId = pspCb->pspCfg.pspId;
                itCntrl->action     =  AASPAC;
                itCntrl->subAction  =  SAELMNT;
                itMgmt.t.cntrl.t.aspm.autoCtx = FALSE;
                cAsNum = pspCb->assoc[0].nmbPs;

                for(ii=0; ii<cAsNum; ii++)
                {
                    if ( (pspCb->assoc[0].ps[ii] != (ItPsCb *)NULLP) && (pspCb->assoc[0].ps[ii]->psCfg.lclFlag) )
                    {
                        itCntrl->t.aspm.psLst[idx] = pspCb->assoc[0].ps[ii]->psCfg.psId;
                        idx++;
                    }
                }
                cAsNum = idx;
                itCntrl->t.aspm.nmbPs = (U8)cAsNum;
                itCntrl->t.aspm.info[0] = '\0';

                (VOID)ItMiLitCntrlReq(&gstSmPst, &itMgmt);
                break;
            }
            else
            {
                return;
            }
            break;
        }
        default:
        {
            return;
        }
    }
    itSgReconnect(pspCb->pspCfg.pspId);
}


PUBLIC S16 StartWork(S16 suId)
{
    U32  i;
    ItPspCb* pspCb;

    TRC2(StartWork);

    itLiEndpOpen(suId, NULLP,TRUE);
#ifdef VXWORKS
    taskDelay(sysClkRateGet()*2);
#endif
    
    for (i=1; i<itGlobalCb.genCfg.maxNmbPsp; i++)
    {
        if (itGlobalCb.psp[i] != (ItPspCb *)NULLP)
        {
            pspCb = itGlobalCb.psp[i];
            itAspReconnectTimeout(pspCb);
#ifdef VXWORKS
            taskDelay(sysClkRateGet()*2);
#endif /* end of VXWORKS */
        }
    }

    RETVALUE(ROK);
}           

PUBLIC VOID itTerminateAssoc(ItAssocCb   *assocCb)
{
    ItMgmt	itMgmt;
    ItCntrl	*     itCntrl;

    TRC2(itTerminateAssoc);
    
    cmMemset((U8*)&itMgmt, 0, sizeof(ItMgmt));
    itMgmt.hdr.response.selector = 0;	/* Loosely */
    itMgmt.hdr.response.prior = 0;	/* 0 */
    itMgmt.hdr.response.route = 0;	/* 0 */
    itMgmt.hdr.response.mem.region  = DFLT_REGION;
    itMgmt.hdr.response.mem.pool = DFLT_POOL;

    itCntrl = &itMgmt.t.cntrl;

    gstSmPst.selector 	= 0;               	/* selector,loose coupled */
    gstSmPst.region 	= DFLT_REGION;     	/* region */
    gstSmPst.pool 	= DFLT_POOL;        /* pool */
    gstSmPst.prior 	= 0;                /* priority */
    gstSmPst.route 	= 0;                /* route */
    gstSmPst.dstProcId= SFndProcId();  	/* destination processor id */
    gstSmPst.dstEnt 	= ENTIT;            /* destination entity*/
    gstSmPst.dstInst 	= 0;        /* destination instance */
    gstSmPst.srcProcId= SFndProcId();   	/* source processor id */
    gstSmPst.srcEnt 	= ENTSM;            /* source entity */
    gstSmPst.srcInst 	= 0;        /* source instance */

    itMgmt.hdr.elmId.elmnt = STITPSP;    
    itCntrl->s.pspId = assocCb->owner->pspCfg.pspId;
    itCntrl->action     =  ATERMINATE;
    itCntrl->subAction  =  SAELMNT;                   
    (Void)ItMiLitCntrlReq(&gstSmPst, &itMgmt);  
        
}

#endif

