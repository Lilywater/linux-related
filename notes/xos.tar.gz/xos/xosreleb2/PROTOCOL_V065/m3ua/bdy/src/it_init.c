/******************************************

******************************************/
/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#ifdef ZV
#include "cm_ftha.h"       /* common PSF */
#include "cm_psfft.h"          /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.h"       /* The common LDF defines */
#include "cmzvdvlb.h"       /* The common LDF defines */
#endif
#endif
#include "cm5.h"           /* common timer */
#include "cm_ss7.h"        /* common SS7 */
#include "cm_tpt.h"        /* common transport defines */
#include "sct.h"           /* SCT interface */
#ifdef IT_FTHA             
#include "sht.h"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "lit.h"           /* layer management M3UA  */
#include "snt.h"           /* SNT interface */
#include "it.h"            /* M3UA internal defines */
#include "it_err.h"        /* M3UA error */
#ifdef ZV
#include "mrs.h"           /* Message Router common define */
#include "lzv.h"           /* common PSF */
#include "zv.h"            /* common PSF */
#include "zv_err.h"        /* m3ua PSF error codes */
#endif

#ifdef IT_ACC
#include "it_acc.h"        /* acceptance test */
#ifdef ZV
#include "zv_acc.h"        /* acceptance test */
#endif
#endif


/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_ss7.x"        /* common SS7 */
#include "cm_tpt.x"        /* common transport */
#include "sct.x"           /* SCT interface */
#include "snt.x"           /* SNT interface */
#ifdef IT_FTHA             
#include "sht.x"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "lit.x"           /* layer management M3UA */
#include "it.x"            /* M3UA internal typedefs */
#ifdef ZV
#include "cm_ftha.x"          /* common PSF */
#include "cm_psfft.x"          /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.x"       /* The LDF common data structs */
#include "cmzvdvlb.x"       /* The LDF common data structs */
#endif
#include "mrs.x"       /* The LDF common data structs */
#include "lzv.x"           /* common PSF */
#include "zv.x"            /* common PSF */
#endif

#ifdef IT_ACC
#include "it_acc.x"        /* acceptance test */
#ifdef ZV
#include "zv_acc.x"        /* acceptance test */
#endif
#endif

#include "it_init.h"
#ifdef SSI_WITH_CLI_ENABLED /* xingzhou.xu: added for using cli --2006/09/05 */
#include "xosshell.h"
#endif

#ifdef CP_OAM_SUPPORT
#include "it_nms.h"
#include "it_cfg.h"
#include "sm.h"
#include "sm.x"
#include "cp_tab_def.h"
#include "oam_tab_def.h"
#include "cp_oam_stru.x"
#include "it_oam.x"
#endif

/* Function definition */
#ifdef ANSI
PUBLIC S16 it_init_fun
(
SSTskId tskId
)
#else 
PUBLIC S16 it_init_fun(tskId)
SSTskId tskId;
#endif
{
#ifdef SS_MULTIPLE_PROCS
    ProcId     procs[]={ PROC1 };
#endif
    t_XOSMUTEXID *plock = NULL;

    TRC3(it_init_fun)
    
    if(tskId == 0)
    {
    /* Create Test Code System Task */
        if (SCreateSTsk(PRIOR0, &tskId) != ROK)
        {
            RETVALUE(RFAILED);
        }
    }

    /* Register M3UA TAPA Task */
    if (SRegTTsk(ENTIT, ITINITINST_0, TTNORM, PRIOR0, itActvInit, itActvTsk) != ROK)
    {
        RETVALUE(RFAILED);
    }

    /* Attach M3UA TAPA Task to its own thread (LC) or the test thread (TC) */
    if (SAttachTTsk(ENTIT, ITINITINST_0, tskId) != ROK)
    {
        RETVALUE(RFAILED);
    }
    
#ifdef CP_OAM_SUPPORT
    itInitCfgData();

    if( ROK != smRegCb((Ent)ENTIT, itGlobalSmQ, EN_IT_CFG_Q_MAX_NUM, smItSendReqQ,itResetCfgData))
    {
        RETVALUE(RFAILED);
    }

    if( OAM_CALL_SUCC != register_msg_proc(CP_MODULE_ID_SS7_M3UA,  APP_SYNC_MSG,  itInitCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 	

    if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_M3UA, APP_TABLE_ID_SS7_M3UA_PSP, SA_INSERT_MSG,  itDynCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 
    
    if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_M3UA, APP_TABLE_ID_SS7_M3UA_PSP, SA_DELETE_MSG,  itDynCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 

    if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_M3UA, APP_TABLE_ID_SS7_M3UA_PS, SA_INSERT_MSG,  itDynCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 

    if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_M3UA, APP_TABLE_ID_SS7_M3UA_PS, SA_DELETE_MSG,  itDynCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 

    if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_M3UA, APP_TABLE_ID_SS7_M3UA_ROUTE, SA_INSERT_MSG,  itDynCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 

    if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_M3UA, APP_TABLE_ID_SS7_M3UA_ROUTE, SA_DELETE_MSG,  itDynCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 

   (unsigned char)get_resource(xwCpSS7NwkTable, sizeof(CP_OAM_SS7_NETWORK_TAB), xwCpSS7NwkTable_ROW_NUM);
   (unsigned char)get_resource(xwCpSS7UpTable, sizeof(CP_OAM_SS7_UP_TAB), xwCpSS7UpTable_ROW_NUM);
   (unsigned char)get_resource(xwCpSS7SpcTable, sizeof(CP_OAM_SS7_SPC_TAB), xwCpSS7SpcTable_ROW_NUM);
   (unsigned char)get_resource(xwCpComIpTable, sizeof(CP_OAM_COM_IP_TAB), xwCpComIpTable_ROW_NUM);
   
   (unsigned char)get_resource(xwCpM3uaGenCfg, sizeof(ItOamM3uaGenTab), xwCpM3uaGenCfg_ROW_NUM);
   (unsigned char)get_resource(xwCpM3uaNodeCfg, sizeof(ItOamM3uaNodeTypeTab), xwCpM3uaNodeCfg_ROW_NUM);
   (unsigned char)get_resource(xwCpM3uaPspTable, sizeof(ItOamM3uaPspTab), xwCpM3uaPspTable_ROW_NUM);
   (unsigned char)get_resource(xwCpM3uaPsTable, sizeof(ItOamM3uaPsTab), xwCpM3uaPsTable_ROW_NUM);
   (unsigned char)get_resource(xwCpM3uaRouteTable, sizeof(ItOamM3uaRouteTab), xwCpM3uaRouteTable_ROW_NUM);
    
    if( OAM_CALL_SUCC != app_register(CP_MODULE_ID_SS7_M3UA, &(itCfgTbl[0]), SM_M3UA_TAB_NUM))
    {
        RETVALUE(RFAILED);
    }
#endif
    RETVALUE(ROK);
}



/* Function definition */
#ifdef ANSI
PUBLIC S16 itTst
(
Void
)
#else 
PUBLIC S16 itTst(Void)
#endif
{
#ifdef SS_MULTIPLE_PROCS
    ProcId     procs[]={ PROC1 };
#endif
	SSTskId tskId;
	
    TRC3(accRegTTsk)

   
   /* Create Test Code System Task */

   if (SCreateSTsk(PRIOR0, &tskId) != ROK)
   {
        RETVALUE(RFAILED);
   }
  
   /* Register M3UA TAPA Task */
   if (SRegTTsk(ENTIT, ITINITINST_0, TTNORM, PRIOR0, itActvInit, itActvTsk) != ROK)
   {
        RETVALUE(RFAILED);
   }

   /* Attach M3UA TAPA Task to its own thread (LC) or the test thread (TC) */
   if (SAttachTTsk(ENTIT, ITINITINST_0, tskId) != ROK)
   {
        RETVALUE(RFAILED);
   }
   

    RETVALUE(ROK);
}


