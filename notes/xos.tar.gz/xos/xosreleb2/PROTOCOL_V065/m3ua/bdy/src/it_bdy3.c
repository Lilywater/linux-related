/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:    M3UA Layer (M3UA)

     Type:    C source file

     Desc:    Magement Interface support functions, Address Translation
              and Stream Mapping supplied by TRILLIUM

     File:    it_bdy3.c

     Sid:      it_bdy3.c@@/main/7 - Thu Apr  1 03:51:36 2004

     Prg:     pn

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_ss7.h"        /* common SS7 */
#include "cm_tpt.h"        /* common transport defines */
#include "lit.h"           /* layer management M3UA  */
#include "sct.h"           /* SCT interface */
#include "snt.h"           /* SNT interface */
#include "it.h"            /* M3UA internal defines */
#include "it_err.h"        /* M3UA error */
#ifdef ZV
#include "cm_ftha.h"
#include "cm_psfft.h"          /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.h"
#include "cmzvdvlb.h"
#endif /* ZV_DFTHA */
#include "mrs.h"
#include "lzv.h"
#include "zv.h"            /* m3ua  PSF */
#endif /* ZV */

/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_ss7.x"        /* common SS7 */
#include "cm_tpt.x"        /* common transport */
#include "sct.x"           /* SCT interface */
#ifdef IT_FTHA             
#include "sht.x"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "lit.x"           /* layer management M3UA */
#include "snt.x"           /* SNT interface */
#include "it.x"            /* M3UA internal typedefs */
#ifdef ZV
#include "cm_ftha.x"
#include "cm_psfft.x"
#ifdef ZV_DFTHA
#include "cmzvdv.x"
#include "cmzvdvlb.x"
#endif
#include "mrs.x"
#include "lzv.x"
#include "zv.x"            /* m3ua PSF */
#endif /* ZV */

/* Public variable declarations */
/*chenning startwork*/
#include "it_cfg.h"
extern ItSmCb  itSmCb;
/* functions */

/****************************************************************************
 *    functions used with Layer Management Configuration                    *
 ****************************************************************************/

/*
*
*       Fun:   itMiCfgGen
*
*       Desc:  This function is used for the general configuration
*              of the M3UA Layer.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itMiCfgGen
(
ItGenCfg *genCfg,             /* configuration parameters */
CmStatus *sta                 /* return status */
)
#else
PUBLIC S16 itMiCfgGen(genCfg, sta)
ItGenCfg *genCfg;             /* configuration parameters */ 
CmStatus *sta;                /* return status */            
#endif
{
   Size      sMemSize;        /* memory size */
   S16       ret;             /* return value */
   U16       undolevel;       /* undo level */
   TskInit   tmpInit;         /* temporary init */
   U16       idx;             /* Loop Index */
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   U16       totalNmbRemotePs; /* Total number of Remote PS */
   U16       totalNmbChldPs;   /* Total number of Child PS */
#endif
   Pst       tmpLmPst;         /* temporary lmPst */

   TRC2(itMiCfgGen)

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf, "itMiCfgGen(genCfg)\n"));

   /* check if general configuration was done, if so then return now */
   if (itGlobalCb.itInit.cfgDone == TRUE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
             "itMiCfgGen: genCfg already done .. now reconfiguring.. \n"));
#endif /* ERRCLS_DEBUG */

      /* check genCfg struct */
      if (itMiVerifyGenCfg(genCfg, sta) != ROK)
      {
         RETVALUE(RFAILED);
      }
      
      if (itMiChkGenReConfig(genCfg, &itGlobalCb.genCfg) == ROK)
      {
         /* it001.106 - Patch propagation from previous release. lmPst 
          * structure is made reconfigurable as LM might want to change 
          * its procId etc. */
 
         /* it017.106 - Save lmPst structure to copy back the srcProcId, 
          * entity and instance. */
         cmMemcpy((U8 *)&tmpLmPst, (U8 *)&itGlobalCb.itInit.lmPst, sizeof(Pst));

         /* initialize layer manager post structure */
         cmMemcpy((U8 *)&itGlobalCb.itInit.lmPst, 
                  (U8 *)&genCfg->smPst, sizeof(Pst));
         /* update the source processor id, entity and instance */
         /* it017.106 - Copy back the srcProcId, entity and instance
          * from tmpLmPst. */
         itGlobalCb.itInit.lmPst.srcProcId = tmpLmPst.srcProcId;
         itGlobalCb.itInit.lmPst.srcEnt    = tmpLmPst.srcEnt;
         itGlobalCb.itInit.lmPst.srcInst   = tmpLmPst.srcInst;
         itGlobalCb.itInit.lmPst.event     = EVTNONE;

         sta->status = LCM_PRIM_OK;
         sta->reason = LCM_REASON_NOT_APPL;
         RETVALUE(ROK);
      }
      else
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT334, (ErrVal) 0,
                    "itMiCfgGen: reconfiguration failed");
#endif /* ERRCLAS_INT_PAR */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_RECONFIG_FAIL;
         RETVALUE(RFAILED);
      }
   }
   else
   {
      /* Save PSF CB structure */
#if ((defined SS_MULTIPLE_PROCS) && (defined ZV))
      Void * psfCb = itGlobalCb.psfCb;
#endif
      /* Save Init structure */
      cmMemcpy((U8 *) &tmpInit, (U8 *) &itGlobalCb.itInit, sizeof(TskInit));
      /* Zero the global CB */
      IT_ZERO(&itGlobalCb, sizeof(ItGlobalCb));
      /* Restore Init structure */
      cmMemcpy((U8 *) &itGlobalCb.itInit, (U8 *) &tmpInit, sizeof(TskInit));

      /* Restore PSF CB structure */
#if ((defined SS_MULTIPLE_PROCS) && (defined ZV))
      itGlobalCb.psfCb = psfCb;
#endif
   }

      /* check genCfg struct */
      if (itMiVerifyGenCfg(genCfg, sta) != ROK)
      {
         RETVALUE(RFAILED);
      }
   /* copy the general configuration */
   cmMemcpy((U8 *) &itGlobalCb.genCfg, (U8 *) genCfg, sizeof(ItGenCfg));

   /* Initialize all the PSIDs to be free for use */
   for (idx = 0; idx < LIT_MAX_PSID; idx++)
   {
      itGlobalCb.psLstCb.psIdFree[idx] = TRUE;
   }

   itGlobalCb.timerFreezeFlg = FALSE;

   /* compute the value of globalCb.maxNmbAssoc from maxNmbPsp + maxNmbSctSap */
   itGlobalCb.maxNmbAssoc = LIT_MAX_PSP * LIT_MAX_SEP;

   /* compute memory necessary for Network Context CBs */
   sMemSize = (itGlobalCb.genCfg.maxNmbNwk *
               (sizeof(ItNwkCb) + sizeof(ItNwkCb *)));

   /* each nwkCb has an array of PS CBs */
   sMemSize += (itGlobalCb.genCfg.maxNmbNwk * itGlobalCb.genCfg.maxNmbPs *
                sizeof(ItPsCb *));

   /* compute memory necessary for Upper SAP CBs */
   sMemSize += (itGlobalCb.genCfg.maxNmbNSap *
                (sizeof(ItNSapCb) + sizeof(ItNSapCb *)));

   /* compute memory necessary for Route Entry CBs */
   sMemSize += (itGlobalCb.genCfg.maxNmbRtEnt * sizeof(ItRouteCb));

   /* compute memory necessary for Peer Server CBs */
   sMemSize += (itGlobalCb.genCfg.maxNmbPs * sizeof(ItPsCb));

#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   /* compute memory necessary for Child PS CBs */
   totalNmbRemotePs = 
       (U16)(itGlobalCb.genCfg.maxNmbPs - itGlobalCb.genCfg.maxNmbLps);
   totalNmbChldPs   = (U16)(totalNmbRemotePs * itGlobalCb.genCfg.maxNmbLps);

   sMemSize += (totalNmbChldPs * sizeof(ItChldPsCb));

   /* compute memory necessary for Pointers to Child PS CBs */
   sMemSize += (totalNmbChldPs * sizeof(ItChldPsCb *));
#endif /* ITASP && OG_RTE_ON_LPS_STA */

   /* compute memory necessary for Peer Signalling Process CBs */
   sMemSize += (LIT_MAX_PSP * (sizeof(ItPspCb) + sizeof(ItPspCb *)));
   /* each assocCb has an array of PS CBs */
   sMemSize += (itGlobalCb.maxNmbAssoc * itGlobalCb.genCfg.maxNmbPs *
                sizeof(ItPsCb *));
   /* each PSPCB has an array of RKRTCB  Ptrs */
   sMemSize += (itGlobalCb.maxNmbAssoc * IT_MAX_REG_TMR * 
                sizeof(ItRegReqTmrCb *));
   /* compute memory necessary for Lower SAP CBs */
   sMemSize += (LIT_MAX_SEP * (sizeof(ItSctSapCb) + sizeof(ItSctSapCb *)));

   /* compute memory necessary for DPC CBs */
   sMemSize += (itGlobalCb.genCfg.maxNmbDpcEnt * sizeof(ItDpcCb));

   /* compute memory necessary for AssocCBs */
   sMemSize += (itGlobalCb.maxNmbAssoc * (sizeof(ItAssocCb *)));
   /* compute the worst case memory required for hash list bins */
   sMemSize += itGlobalCb.genCfg.maxNmbDpcEnt * CM_HASH_BINSIZE;
   sMemSize += itGlobalCb.genCfg.maxNmbPs * CM_HASH_BINSIZE;

   /* compute memory necessary for messages in transit */
   sMemSize += (itGlobalCb.genCfg.maxNmbMsg * sizeof(ItMupMsg));
   
    /* calculate memory required for Child PS CBs */
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   /* compute memory necessary for Round Robin load sharing */
   sMemSize += (itGlobalCb.genCfg.maxNmbRndRbnLs * itGlobalCb.genCfg.maxNmbLps 
                *sizeof(ItLscRndRbnCb));
   sMemSize += (itGlobalCb.genCfg.maxNmbRndRbnLs * itGlobalCb.genCfg.maxNmbLps 
                *IT_MAX_XUDT_CTX * (sizeof(ItLscXudtCtx) + CM_HASH_BINSIZE));

   /* compute memory necessary for SLS based load sharing */
   sMemSize += (itGlobalCb.genCfg.maxNmbSlsLs * itGlobalCb.genCfg.maxNmbLps 
                *sizeof(ItLscSlsCb));
   sMemSize += (itGlobalCb.genCfg.maxNmbSls * itGlobalCb.genCfg.maxNmbLps
                *sizeof(ItLscSlsCtx));
#else /* !(ITASP && OG_RTE_ON_LPS_STA) */
   /* compute memory necessary for Round Robin load sharing */
   sMemSize += (itGlobalCb.genCfg.maxNmbRndRbnLs * sizeof(ItLscRndRbnCb));
   sMemSize += (itGlobalCb.genCfg.maxNmbRndRbnLs * IT_MAX_XUDT_CTX *
                (sizeof(ItLscXudtCtx) + CM_HASH_BINSIZE));

   /* compute memory necessary for SLS based load sharing */
   sMemSize += (itGlobalCb.genCfg.maxNmbSlsLs * sizeof(ItLscSlsCb));
   sMemSize += (itGlobalCb.genCfg.maxNmbSls * sizeof(ItLscSlsCtx));
#endif /* ITASP && OG_RTE_ON_LPS_STA */

#ifdef ZV_DFTHA
   /* Memory calculation for primitive queuing in case of DFTHA */
   sMemSize += (itGlobalCb.genCfg.maxNmbSctSap *
                itGlobalCb.genCfg.maxNmbDpcEnt *
                itGlobalCb.genCfg.maxNmbPs *
                itGlobalCb.genCfg.maxNmbPsp * (sizeof(ItL2Evt)));

   sMemSize += (itGlobalCb.genCfg.maxNmbDpcEnt * itGlobalCb.genCfg.maxNmbNSap * 
                (sizeof(ItL4Evt)));
#endif
   /* sMemSize += (sizeof(ItLscAllCb));*/

#ifdef IT_RUG
   /* compute memory necessary for interface information  */
   sMemSize += ((itGlobalCb.genCfg.maxNmbNSap +
                 itGlobalCb.genCfg.maxNmbSctSap) * SBUFSIZE(sizeof(ShtVerInfo)));
#endif /* IT_RUG */

   /* reserve static memory */
   ret = SGetSMem(itGlobalCb.itInit.region,(Size) sMemSize,
                  &itGlobalCb.itInit.pool);
   /* add to the general status field */
   if (ret != ROK)
   {
#if (ERRCLASS & ERRCLS_ADD_RES)
      ITLOGERROR(ERRCLS_ADD_RES, EIT335, (ErrVal)sMemSize,
                 "itMiCfgGen(): could not reserve static memory\n");
#endif /* ERRCLS_ADD_RES */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_MEM_NOAVAIL;
      RETVALUE(RFAILED);
   }
   
   /* write the reserved mem size into the general status structure */
   itGlobalCb.genSta.memSize = sMemSize;
   
   undolevel = 1;

   /* allocate the Upper SAP (NSAP) list */
   if (itGlobalCb.genCfg.maxNmbNSap > 0)
   {
      IT_ALLOC((genCfg->maxNmbNSap * sizeof(ItNSapCb *)), itGlobalCb.nSap)
      if (itGlobalCb.nSap == (ItNSapCb **) NULLP)
      {
         /* undolevel 1 if failed */
#if (ERRCLASS & ERRCLS_ADD_RES)
         ITLOGERROR(ERRCLS_ADD_RES, EIT336, (ErrVal) 0,
                    "itMiCfgGen(): could not allocate NSap list\n");
#endif /* ERRCLS_ADD_RES */
         itMiDelGen(genCfg, undolevel);
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_CAUSE_MEM_ALLOC_FAIL;
         RETVALUE(RFAILED);
      }
   } /* end if maxNmbNSap > 0 */
   undolevel = 2;

   if (itGlobalCb.genCfg.maxNmbSctSap > 0)
   {
      /* allocate the SCT SAP list */
      IT_ALLOC((LIT_MAX_SEP * sizeof(ItSctSapCb *)), itGlobalCb.sctSap)
      if (itGlobalCb.sctSap == (ItSctSapCb **) NULLP)
      {
#if (ERRCLASS & ERRCLS_ADD_RES)
         ITLOGERROR(ERRCLS_ADD_RES, EIT337, (ErrVal) 0,
                    "itMiCfgGen(): could not allocate SctSap list\n");
#endif /* ERRCLS_ADD_RES */
         itMiDelGen(genCfg, undolevel);
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_CAUSE_MEM_ALLOC_FAIL;
         RETVALUE(RFAILED);
      }
   } /* end if maxNmbSctSap > 0 */
   undolevel = 3;

   /* init Peer Server hash list */
   /* it001.106 - Changed the Hash key type to CM_HASH_KEYTYPE_U32MOD from 
    * CM_HASH_KEYTYPE_DEF for performance improvement. */
   ret = cmHashListInit(&itGlobalCb.ps, itGlobalCb.genCfg.maxNmbPs, 0x0, FALSE,
                        CM_HASH_KEYTYPE_U32MOD, itGlobalCb.itInit.region, 
                        itGlobalCb.itInit.pool);

   if (ret != ROK)
   {
#if (ERRCLASS & ERRCLS_ADD_RES)
      ITLOGERROR(ERRCLS_ADD_RES, EIT338, (ErrVal) 0,
                 "itMiCfgGen(): could not initialize PS hashlist\n");
#endif /* ERRCLS_ADD_RES */
      itMiDelGen(genCfg, undolevel);
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_HASHING_FAILED;
      RETVALUE(RFAILED);
   }
   undolevel = 4;

   /* init the DPC CB hash list in the AT CB */
   /* it001.106 - Changed the Hash key type to CM_HASH_KEYTYPE_U32MOD from 
    * CM_HASH_KEYTYPE_DEF for performance improvement. */
   ret = cmHashListInit(&itGlobalCb.addrTrn.dpcList,
      itGlobalCb.genCfg.maxNmbDpcEnt, 0x0, FALSE, CM_HASH_KEYTYPE_U32MOD,
      itGlobalCb.itInit.region, itGlobalCb.itInit.pool);

   if (ret != ROK)
   {
#if (ERRCLASS & ERRCLS_ADD_RES)
      ITLOGERROR(ERRCLS_ADD_RES, EIT339, (ErrVal) 0,
                 "itMiCfgGen(): could not initialize dpc hashlist\n");
#endif /* ERRCLS_ADD_RES */
      itMiDelGen(genCfg, undolevel);
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_HASHING_FAILED;
      RETVALUE(RFAILED);
   }
   undolevel = 5;

   /* allocate the Association list */
   IT_ALLOC((itGlobalCb.maxNmbAssoc * sizeof(ItAssocCb *)), itGlobalCb.assoc)
   if (itGlobalCb.assoc == (ItAssocCb **) NULLP)
   {
#if (ERRCLASS & ERRCLS_ADD_RES)
      ITLOGERROR(ERRCLS_ADD_RES, EIT340, (ErrVal) 0,
                 "itMiCfgGen(): could not allocate Assoc list\n");
#endif /* ERRCLS_ADD_RES */
      itMiDelGen(genCfg, undolevel);
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_MEM_NOAVAIL;
      RETVALUE(RFAILED);
   }
   undolevel = 6;

   /* allocate the Peer Signalling Process list */
   IT_ALLOC((LIT_MAX_PSP * sizeof(ItPspCb *)), itGlobalCb.psp)
   if (itGlobalCb.psp == (ItPspCb **) NULLP)
   {
#if (ERRCLASS & ERRCLS_ADD_RES)
      ITLOGERROR(ERRCLS_ADD_RES, EIT341, (ErrVal) 0,
                 "itMiCfgGen(): could not allocate psp list\n");
#endif /* ERRCLS_ADD_RES */
      itMiDelGen(genCfg, undolevel);
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_MEM_NOAVAIL;
      RETVALUE(RFAILED);
   }
   if ((ret = itPsmCfgPsp((ItPspCfg *)NULLP, sta)) != ROK)
   {
      RETVALUE(ret);
   }
   undolevel = 7;

   /* allocate the Network contexts list */
   IT_ALLOC((genCfg->maxNmbNwk * sizeof(ItNwkCb *)), itGlobalCb.nwk)
   if (itGlobalCb.nwk == (ItNwkCb **) NULLP)
   {
#if (ERRCLASS & ERRCLS_ADD_RES)
      ITLOGERROR(ERRCLS_ADD_RES, EIT342, (ErrVal) 0,
                 "itMiCfgGen(): could not allocate NwkCb list\n");
#endif /* ERRCLS_ADD_RES */
      itMiDelGen(genCfg, undolevel);
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_MEM_NOAVAIL;
      RETVALUE(RFAILED);
   }
   /* initialize addrTrn global route list */
   cmLListInit(&itGlobalCb.addrTrn.rtList);

   undolevel = 8;

#ifdef ZV_DFTHA
   itGlobalCb.l2Lst.evt = (ItL2Evt *)NULLP;
   /* Allocate memory for L2 primitives to be queued */ 
   IT_ALLOC((genCfg->maxNmbDpcEnt * genCfg->maxNmbPs * genCfg->maxNmbPsp * genCfg->maxNmbSctSap * sizeof(ItL2Evt)), itGlobalCb.l2Lst.evt);
   if (itGlobalCb.l2Lst.evt == (ItL2Evt *) NULLP)
   {
#if (ERRCLASS & ERRCLS_ADD_RES)
      ITLOGERROR(ERRCLS_ADD_RES, EIT343, (ErrVal) 0,
                 "itMiCfgGen(): could not allocate ItL2Lst list for queuing\n");
#endif /* ERRCLS_ADD_RES */
      itMiDelGen(genCfg, undolevel);
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_MEM_NOAVAIL;
      ITZVUPDPEER()
      RETVALUE(RFAILED);
   }

   undolevel = 9;

   /* Allocate memory for L4 primitives to be queued */ 
   itGlobalCb.l4Lst.lst = (ItL4Evt *) NULLP;
   IT_ALLOC((genCfg->maxNmbDpcEnt * genCfg->maxNmbNSap * \
          sizeof(ItL4Evt)), itGlobalCb.l4Lst.lst);
   if (itGlobalCb.l4Lst.lst == (ItL4Evt *) NULLP)
   {
#if (ERRCLASS & ERRCLS_ADD_RES)
      ITLOGERROR(ERRCLS_ADD_RES, EIT344, (ErrVal) 0,
                 "itMiCfgGen(): could not allocate L4Lst list for queuing\n");
#endif /* ERRCLS_ADD_RES */
      itMiDelGen(genCfg, undolevel);
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_MEM_NOAVAIL;
      ITZVUPDPEER()
      RETVALUE(RFAILED);
   }

   undolevel = 10;
#endif /* ZV_DFTHA */


   /* it017.106 - Save lmPst structure to copy back the srcProcId, 
    * entity and instance. */
   cmMemcpy((U8 *)&tmpLmPst, (U8 *)&itGlobalCb.itInit.lmPst, sizeof(Pst));

   /* initialize layer manager post structure */
   cmMemcpy((U8 *)&itGlobalCb.itInit.lmPst, (U8 *)&genCfg->smPst, sizeof(Pst));

   /* Initialize the Routing Context generation starting from IT_MAX_PSID */
   /* Further assignment of RCs will not over-lap with PSIDs */
   itGlobalCb.rCtx = LIT_MAX_PSID;

   /* update the source processor id, entity and instance */
   /* it017.106 - Copy back the srcProcId, entity and instance
    * from tmpLmPst. */
   itGlobalCb.itInit.lmPst.srcProcId = tmpLmPst.srcProcId;
   itGlobalCb.itInit.lmPst.srcEnt    = tmpLmPst.srcEnt;
   itGlobalCb.itInit.lmPst.srcInst   = tmpLmPst.srcInst;
   itGlobalCb.itInit.lmPst.event     = EVTNONE;

   /* Initialize the timers */
   ret = itTcInit();

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
                       "itMiCfgGen: timer return(%d)\n", ret));

   if (ret != ROK)                                  /* recovery code */
   {

      /* free all memory that has been configured up to undolevel */
      itMiDelGen(genCfg, undolevel);
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_REGTMR_FAIL;
      RETVALUE(RFAILED);
   }

#ifdef IT_RUG
   itGlobalCb.numIntfInfo = 0;
   IT_ALLOC((itGlobalCb.genCfg.maxNmbNSap + itGlobalCb.genCfg.maxNmbSctSap) * sizeof(ShtVerInfo), itGlobalCb.intfInfo);
   if (itGlobalCb.intfInfo == (ShtVerInfo *) NULLP)
   {
      undolevel = 11;
      itMiDelGen(genCfg, undolevel);
      RETVALUE(LCM_REASON_MEM_NOAVAIL);
   }
   undolevel++;
#endif /* IT_RUG */


   /* Initialize the statistics */
   (Void) SGetDateTime(&(itGlobalCb.genSts.dt));
   /* set the general configuration done flag */
   itGlobalCb.itInit.cfgDone = TRUE;
   
   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
          "itMiCfgGen: general config done, sta: (%d) res: (%d)\n", 
          sta->status, sta->reason));
/*chenning startwork*/
    IT_INITTIMER(&itSmCb.tmrReconnect);
    itSmCb.tmr.tmrReconnect.enb = TRUE;
    itSmCb.tmr.tmrReconnect.val = IT_TMR_TM_AUTOSTRRT* SS_TICKS_SEC/IT_TMR_RES;
    
   RETVALUE(ROK);
} /* end of itMiCfgGen */


/*
*
*       Fun:   itMiDelGen
*
*       Desc:  This function is used with the general configuration
*              of the M3UA Layer (itMiCfgGen) to delete any memory
*              in case of failure.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itMiDelGen
(
ItGenCfg    *genCfg,          /* general configuration structure */
S16         undolevel         /* undo level */
)
#else
PUBLIC S16 itMiDelGen(genCfg, undolevel)
ItGenCfg    *genCfg;          /* general configuration structure */
S16         undolevel;        /* undo level */                     
#endif
{
   TRC2(itMiDelGen)

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
            "itMiDelGen(genCfg, undolevel(%d))\n", undolevel));

   switch (undolevel)
   {

   
      /* following cases fall through */
#ifdef IT_RUG
      case 11:
         if (itGlobalCb.genCfg.maxNmbNSap > 0)
         {
            IT_FREE((itGlobalCb.genCfg.maxNmbNSap + itGlobalCb.genCfg.maxNmbSctSap) * sizeof(ShtVerInfo), 
                             itGlobalCb.intfInfo);
         }
#endif /* IT_RUG */
#ifdef ZV_DFTHA
      case 10:
         if (itGlobalCb.genCfg.maxNmbDpcEnt > 0)
         {
            /* Free memory allocated for L4 primitive list */
            IT_FREE((itGlobalCb.genCfg.maxNmbDpcEnt *\
                     itGlobalCb.genCfg.maxNmbNSap *\
                     sizeof(ItL4Evt)), itGlobalCb.l4Lst.lst);
         }
      case 9:
         if (itGlobalCb.genCfg.maxNmbSctSap > 0)
         {
            /* Free memory allocated for L2 primitive list */
            IT_FREE((itGlobalCb.genCfg.maxNmbSctSap *\
                     itGlobalCb.genCfg.maxNmbDpcEnt *\
                     itGlobalCb.genCfg.maxNmbPs *\
                     itGlobalCb.genCfg.maxNmbPsp * sizeof(ItL2Evt)),\
                     itGlobalCb.l2Lst.evt);
         }
#endif
      /* following cases fall through */
      case 8:
         if (itGlobalCb.genCfg.maxNmbNwk > 0)
         {
            /* Free the Network contexts list */
            IT_FREE((genCfg->maxNmbNwk * sizeof(ItNwkCb *)), itGlobalCb.nwk);
         }
      case 7:
         if (itGlobalCb.genCfg.maxNmbPsp > 0)
         {
            /* Free the Peer Signalling Process list */
            IT_FREE((LIT_MAX_PSP * sizeof(ItPspCb *)), itGlobalCb.psp);
         }
      case 6:
         if (itGlobalCb.maxNmbAssoc > 0)
         {
            /* Free the Association list */
            IT_FREE((itGlobalCb.maxNmbAssoc * sizeof(ItAssocCb *)), 
                    itGlobalCb.assoc);
         }
      case 5:
         /* Deinitialize the dpc hash list hash list */
         (Void) cmHashListDeinit(&itGlobalCb.addrTrn.dpcList);

      case 4:
         /* Deinitialize the Peer Server hash list */
         (Void) cmHashListDeinit(&itGlobalCb.ps);

      case 3:
         if (itGlobalCb.genCfg.maxNmbSctSap > 0)
         {
            /* Free the Lower SAP list */
            IT_FREE((LIT_MAX_SEP * sizeof(ItSctSapCb *)), 
                    itGlobalCb.sctSap);
         }
      case 2:
         if (itGlobalCb.genCfg.maxNmbNSap > 0)
         {
            /* Free the Upper SAP list */
            IT_FREE((genCfg->maxNmbNSap * sizeof(ItNSapCb *)), itGlobalCb.nSap);
         }
      case 1:
         (Void) SPutSMem(itGlobalCb.itInit.region, itGlobalCb.itInit.pool);
         break;
      default:
         break;
   } /* end of switch undolevel */
   RETVALUE(ROK);
} /* end of itMiDelGen */


/*
*
*       Fun:   itMiVerifyGenCfg
*
*       Desc:  This function is used with the general configuration
*              of the M3UA Layer (itMiCfgGen) to verify that the values
*              in the genCfg are valid
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: Returns the following in the status struct when an
*              invalid element is encountered:
*
*              status: LCM_PRIM_NOK
*              reason: LCM_REASON_INVALID_PAR_VAL
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itMiVerifyGenCfg
(
ItGenCfg *genCfg,             /* configuration parameters */ 
CmStatus *sta                 /* return status */            
)
#else
PUBLIC S16 itMiVerifyGenCfg(genCfg, sta)
ItGenCfg *genCfg;             /* configuration parameters */ 
CmStatus *sta;                /* return status */            
#endif
{
   TRC2(itMiVerifyGenCfg)

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
                       "itMiVerifyGenCfg(genCfg, sta)\n"));

   switch (genCfg->nodeType)
   {
      case LIT_TYPE_SGP:
         break;
      case LIT_TYPE_ASP:
         break;
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT345,
                    (ErrVal) genCfg->nodeType,
                    "itMiVerifyGenCfg: Invalid nodeType in genCfg");
#endif /* ERRCLASS & ERRCLS_INT_PAR */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
   }

   switch (genCfg->dpcLrnFlag)
   {
      /* following 2 cases fall through */
      case TRUE:
      case FALSE:
         break;
      default:
         ITLOGERROR(ERRCLS_INT_PAR, EIT346,
                    (ErrVal) genCfg->dpcLrnFlag,
                    "itMiVerifyGenCfg: Invalid dpcLrnFlag in genCfg");
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
   }

   switch (genCfg->drstSupp)
   {
      /* following 2 cases fall through */
      case TRUE:
      case FALSE:
         break;
      default:
         ITLOGERROR(ERRCLS_INT_PAR, EIT347,
                    (ErrVal) genCfg->drstSupp,
                    "itMiVerifyGenCfg: Invalid  drstSupp in genCfg");
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
   }
   if (genCfg->maxNmbNSap == 0)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT348,
                 (ErrVal) genCfg->maxNmbNSap,
                 "itMiVerifyGenCfg: maxNmbNSap set to 0");
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   if ((genCfg->maxNmbSctSap == 0) || (genCfg->maxNmbSctSap > LIT_MAX_SEP))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT349,
                 (ErrVal) genCfg->maxNmbSctSap,
                 "itMiVerifyGenCfg: maxNmbSctSap set to 0");
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   if ((genCfg->maxNmbNwk == 0) || (genCfg->maxNmbNwk > IT_MAX_NWK))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT350,
                 (ErrVal) genCfg->maxNmbNwk,
                 "itMiVerifyGenCfg: maxNmbNwk == 0 or > IT_MAX_NWK");
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   if (genCfg->maxNmbRtEnt == 0)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT351,
                 (ErrVal) genCfg->maxNmbRtEnt,
                 "itMiVerifyGenCfg: maxNmbRtEnt set to 0");
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   if (genCfg->maxNmbDpcEnt == 0)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT352,
                 (ErrVal) genCfg->maxNmbDpcEnt,
                 "itMiVerifyGenCfg: maxNmbDpcEnt set to 0");
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   if ((genCfg->maxNmbPs == 0) || (genCfg->maxNmbPs > LIT_MAX_PSID))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT353,
                 (ErrVal) genCfg->maxNmbPs,
                 "itMiVerifyGenCfg: maxNmbPs set to 0");
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   if ((genCfg->maxNmbPsp == 0) || (genCfg->maxNmbPsp > LIT_MAX_PSP))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT354,
                 (ErrVal) genCfg->maxNmbPsp,
                 "itMiVerifyGenCfg: maxNmbPsp == 0 or > LIT_MAX_PSP");
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   if (genCfg->maxNmbMsg == 0)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT355,
                 (ErrVal) genCfg->maxNmbMsg,
                 "itMiVerifyGenCfg: maxNmbMsg == 0");
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }
   
   if ((genCfg->congLevel3 > genCfg->qSize) || 
       (genCfg->congLevel2 > genCfg->congLevel3) ||
       (genCfg->congLevel1 > genCfg->congLevel2))
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT356,
                 (ErrVal) NULLD,
 "itMiVerifyGenCfg: require congLevel1 <= congLevel2 <= congLevel3 <= qSize");
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   if (genCfg->tmr.tmrAsPend.enb == TRUE)
   {
      if (genCfg->tmr.tmrAsPend.val == 0)
      {
         ITLOGERROR(ERRCLS_INT_PAR, EIT357,
                    (ErrVal) genCfg->tmr.tmrAsPend.val,
                    "itMiVerifyGenCfg: tmrAsPend enabled but set to 0");
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
      }
   }

   if (genCfg->tmr.tmrHeartbeat.enb == TRUE)
   {
      if (genCfg->tmr.tmrHeartbeat.val == 0)
      {
         ITLOGERROR(ERRCLS_INT_PAR, EIT358,
                    (ErrVal) genCfg->tmr.tmrHeartbeat.val,
                    "itMiVerifyGenCfg: tmrHeartbeat enabled but set to 0");
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
      }
   }

   if (genCfg->tmr.tmrMtp3Sta.enb == TRUE)
   {
      if (genCfg->tmr.tmrMtp3Sta.val == 0)
      {
         ITLOGERROR(ERRCLS_INT_PAR, EIT359,
                    (ErrVal) genCfg->tmr.tmrMtp3Sta.val,
                    "itMiVerifyGenCfg: tmrMtp3Sta enabled but set to 0");
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
      }
   }

   if (genCfg->tmr.tmrAspUp1.enb == TRUE)
   {
      if (genCfg->tmr.tmrAspUp1.val == 0)
      {
         ITLOGERROR(ERRCLS_INT_PAR, EIT360,
                    (ErrVal) genCfg->tmr.tmrAspUp1.val,
                    "itMiVerifyGenCfg: tmrAspUp1 enabled but set to 0");
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
      }
   }

   if (genCfg->tmr.tmrAspUp2.enb == TRUE)
   {
      if (genCfg->tmr.tmrAspUp2.val == 0)
      {
         ITLOGERROR(ERRCLS_INT_PAR, EIT361,
                    (ErrVal) genCfg->tmr.tmrAspUp2.val,
                    "itMiVerifyGenCfg: tmrAspUp2 enabled but set to 0");
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
      }
   }

   if (genCfg->tmr.nmbAspUp1 == 0)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT362,
                    (ErrVal) genCfg->tmr.nmbAspUp1,
                    "itMiVerifyGenCfg: nmbAspUp1 set to 0");
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   if (genCfg->tmr.tmrAspDn.enb == TRUE)
   {
      if (genCfg->tmr.tmrAspDn.val == 0)
      {
         ITLOGERROR(ERRCLS_INT_PAR, EIT363,
                    (ErrVal) genCfg->tmr.tmrAspDn.val,
                    "itMiVerifyGenCfg: tmrAspDn enabled but set to 0");
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
      }
   }

   if (genCfg->tmr.tmrAspM.enb == TRUE)
   {
      if (genCfg->tmr.tmrAspM.val == 0)
      {
         ITLOGERROR(ERRCLS_INT_PAR, EIT364,
                    (ErrVal) genCfg->tmr.tmrAspDn.val,
                    "itMiVerifyGenCfg: tmrAspDn enabled but set to 0");
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
      }
   }

   if (genCfg->tmr.tmrDaud.enb == TRUE)
   {
      if (genCfg->tmr.tmrDaud.val == 0)
      {
         ITLOGERROR(ERRCLS_INT_PAR, EIT365,
                    (ErrVal) genCfg->tmr.tmrDaud.val,
                    "itMiVerifyGenCfg: tmrDaud enabled but set to 0");
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
      }
   }

   if (genCfg->tmr.tmrSeqCntrl.enb == TRUE)
   {
      if (genCfg->tmr.tmrSeqCntrl.val == 0)
      {
         ITLOGERROR(ERRCLS_INT_PAR, EIT366,
                    (ErrVal) genCfg->tmr.tmrSeqCntrl.val,
                    "itMiVerifyGenCfg: tmrSeqCntrl enabled but set to 0");
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
      }
   }

   if (genCfg->timeRes == 0)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT367,
                 (ErrVal) genCfg->timeRes,
                 "itMiVerifyGenCfg: timeRes set to 0");
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   RETVALUE(ROK);
} /* end of itMiVerifyGenCfg */


/*
*
*       Fun:   itMiChkGenReConfig
*
*       Desc:  This function is used to check the validity of the genCfg
*              struct when trying to reconfigure general configuration.
*              When valid, it copies the new genCfg struct over the old
*              one and exits with ROK.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itMiChkGenReConfig
(
ItGenCfg *genCfg,             /* configuration parameters */
ItGenCfg *oldCfg              /* old configuration */
)
#else
PUBLIC S16 itMiChkGenReConfig(genCfg, oldCfg)
ItGenCfg *genCfg;             /* configuration parameters */  
ItGenCfg *oldCfg;             /* old configuration */         
#endif
{
   TRC2(itMiChkGenReConfig)

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
                          "itMiChkGenReConfig(genCfg, oldCfg)\n"));

   /*
    *  check if parameters that are NOT reconfigurable are equal and fail
    *  if they are not
    */
   if ((genCfg->nodeType != oldCfg->nodeType) ||
       (genCfg->maxNmbNSap != oldCfg->maxNmbNSap) ||
       (genCfg->maxNmbSctSap != oldCfg->maxNmbSctSap) ||
       (genCfg->maxNmbNwk != oldCfg->maxNmbNwk) ||
       (genCfg->maxNmbRtEnt != oldCfg->maxNmbRtEnt) ||
       (genCfg->maxNmbDpcEnt != oldCfg->maxNmbDpcEnt) ||
       (genCfg->maxNmbPs != oldCfg->maxNmbPs) ||
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
       (genCfg->maxNmbLps != oldCfg->maxNmbLps) ||
#endif /* ITASP && OG_RTE_ON_LPS_STA */
       (genCfg->maxNmbPsp != oldCfg->maxNmbPsp) ||
       (genCfg->maxNmbMsg != oldCfg->maxNmbMsg) ||
       (genCfg->timeRes != oldCfg->timeRes) ||
       (genCfg->drstSupp != oldCfg->drstSupp))
   {
      RETVALUE(RFAILED);
   }
   else
   {
      /* copy genCfg to itGlobalCb */
      cmMemcpy((U8 *) &itGlobalCb.genCfg, (U8 *) genCfg, sizeof(ItGenCfg));
      RETVALUE(ROK);
   }
      
} /* end itMiChkGenReConfig */


/*
*
*       Fun:   itMiSendLmCfm
*
*       Desc:  This function is used to set up and send configuration
*              control, status and statistics confirms to layer manage-
*              ment.
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC Void itMiSendLmCfm
(
Pst     *pst,                 /* post */
U8      cfmType,              /* confirm type */
Header  *hdr,                 /* header */
U16     status,               /* confirm status */
U16     reason                /* failure reason */
)
#else
PUBLIC Void itMiSendLmCfm(pst, cfmType, hdr, status, reason)
Pst     *pst;                 /* post */
U8      cfmType;              /* confirm type */
Header  *hdr;                 /* header */
U16     status;               /* confirm status */
U16     reason;               /* failure reason */
#endif
{
   Pst      cfmPst;           /* Post structure for confimation */
   ItMgmt   *cfm;             /* temporary pointer to mgmt */  

   TRC2(itMiSendLmCfm)


   cfm = &itGlobalCb.mgmt;

   /* Fill up the header in the confirm structure */
   cfm->hdr.elmId.elmnt = hdr->elmId.elmnt;
   cfm->hdr.transId     = hdr->transId;
   cfm->hdr.msgType     = cfmType;
   cfm->cfm.status      = status;
   cfm->cfm.reason      = reason;

   /* Fill up the post struct for comfirm */
   /* it017.106 - Update the source entity, instance and procId from
    * lmPst structure. lmPst is now initialised in itActvInit. */
   cfmPst.srcEnt        = itGlobalCb.itInit.lmPst.srcEnt;
   cfmPst.srcInst       = itGlobalCb.itInit.lmPst.srcInst;
   cfmPst.srcProcId     = itGlobalCb.itInit.lmPst.srcProcId;
   cfmPst.dstEnt        = pst->srcEnt;
   cfmPst.dstInst       = pst->srcInst;
   cfmPst.dstProcId     = pst->srcProcId;
   cfmPst.selector      = hdr->response.selector;
   cfmPst.prior         = hdr->response.prior;
   cfmPst.route         = hdr->response.route;
   cfmPst.region        = hdr->response.mem.region;
   cfmPst.pool          = hdr->response.mem.pool;

   /* it011.106 - Send the cfm to LM using the same interface version as the 
    * one used by LM */
#ifdef IT_RUG
   cfmPst.intfVer       = pst->intfVer;
#endif

   switch (cfmType)
   {
      case TCFG:
         /* send configuration confirm */
         ItMiLitCfgCfm(&cfmPst, cfm);

         ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
                "in bdy3: after sending ItMiLitCfgCfm with cfmType: (%d) \n", 
                cfmType));

         break;

      case TSTS:
         /* send Statistics confirm */
         ItMiLitStsCfm(&cfmPst, cfm);

         ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
                "in bdy3: after sending ItMiLitStsCfm with cfmType: (%d) \n", 
                cfmType));

         break;

      case TCNTRL:
         /* send control confirm */
         ItMiLitCntrlCfm(&cfmPst, cfm);


         ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
                "in bdy3: after sending ItMiLitCntrlCfm with cfmType: (%d) \n", 
                cfmType));

         break;

      case TSSTA:
         /* send solicited status confirm */
         ItMiLitStaCfm(&cfmPst, cfm);

         ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
                "in bdy3: after sending ItMiLitStaCfm with cfmType: (%d) \n", 
                cfmType));

         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         ITLOGERROR(ERRCLS_DEBUG, EIT368, (ErrVal)cfmType,
                    "itMiSendLmCfm(): unknown parameter cfmType passed\n");
#endif /* ERRCLS_DEBUG */
         RETVOID;
   } /* end of switch statement */

   RETVOID;
}/* end of itMiSendLmCfm() */


/*
*
*       Fun:   itMiStaInd
*
*       Desc:  This function is used to generate an unsolicited status
*              indication to the layer manager.  The calling module specifies
*              the category, event, cause and ID information.  The layer
*              management module creates the unsolicited status indication
*              structure, adds the date stamp, and sends the alarm to the
*              layer manager.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itMiStaInd
(
Elmnt    elmnt,               /* element token */         
U16      category,            /* alarm category */
U16      event,               /* alarm event */
U16      cause,               /* alarm cause */
U32      id                   /* entity ID */
)
#else
PUBLIC S16 itMiStaInd(elmnt, category, event, cause, id)
Elmnt    elmnt;               /* element token */  
U16      category;            /* alarm category */ 
U16      event;               /* alarm event */    
U16      cause;               /* alarm cause */    
U32      id;                  /* entity ID */      
#endif
{
   S16    ret;                /* return value */

   TRC2(itMiStaInd)
#ifdef BIT_64                                                       
   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
            "itMiStaInd(elmnt(%d), category(%d), event(%d), \
                       cause(%d), id(%d))\n",elmnt, category, \
                       event, cause, id));
#else                                                       
   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
            "itMiStaInd(elmnt(%d), category(%d), event(%d), \
                       cause(%d), id(%ld))\n",elmnt, category, \
                       event, cause, id));
#endif
   itGlobalCb.mgmt.hdr.elmId.elmnt        = elmnt;
   itGlobalCb.mgmt.hdr.msgType            = TUSTA;
   itGlobalCb.mgmt.t.usta.alarm.category  = category;
   itGlobalCb.mgmt.t.usta.alarm.event     = event;
   itGlobalCb.mgmt.t.usta.alarm.cause     = cause;
   switch (elmnt)
   {
      case STITPSP:
         itGlobalCb.mgmt.t.usta.s.pspId   = (ItPspId) id;
         break;
      case STITSCTSAP:
         itGlobalCb.mgmt.t.usta.s.suId    = (SuId) id;
         break;
      case STITNSAP:
         itGlobalCb.mgmt.t.usta.s.spId    = (SpId) id;
         break;
      case STITPS:
         itGlobalCb.mgmt.t.usta.s.psId    = (ItPsId) id;
         break;
      case STITGEN:
      default:
         break;
   } /* end of switch */
   /* call itMiStaIndM to add timestamp and call ItLitMiStaInd */
   ret = itMiStaIndM(&itGlobalCb.mgmt);

   RETVALUE(ret);
} /* end of itMiStaInd */


/*
*
*       fun:   itMiStaIndM
*
*       Desc:  This function is used to generate an unsolicited status
*              indication to the layer manager.  The calling module in this
*              version fills in the ItMgmt management struct and passes
*              it to the layer management module which adds the date stamp,
*              and sends the alarm to the layer manager.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itMiStaIndM
(
ItMgmt *sta                   /* status parameters */
)
#else
PUBLIC S16 itMiStaIndM(sta)
ItMgmt *sta;                  /* status parameters */ 
#endif                        
{
   TRC2(itMiStaInd)

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
                       "itMiStaInd(event: (%d) cause: (%d))\n",
                       sta->t.usta.alarm.event, sta->t.usta.alarm.cause));

   /* check if alarms are enabled */
   if (itGlobalCb.itInit.usta == TRUE)
   {
      sta->hdr.msgType = TUSTA;

      /* fill in date stamp */
      (Void) SGetDateTime(&(sta->t.usta.alarm.dt));
      (Void) ItMiLitStaInd(&(itGlobalCb.itInit.lmPst), sta);
   } /* end if itInit.usta */
   RETVALUE(ROK);
} /* end of itMiStaIndM */


/*
*
*       Fun:   itMiTrcInd
*
*       Desc:  This function is called from the lower interface module to
*              generate a trace indication to the layer manager. The trcinfo
*              structure contains all the trace information.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itMiTrcInd
(
SuId     suId,                /* service user ID */
U16      evnt,                /* trace event */
Buffer   *mBuf               /*  message buffer */
)
#else
PUBLIC S16 itMiTrcInd(suId, evnt, mBuf)
SuId     suId;                /* service user ID */
U16      evnt;                /* trace event */    
Buffer   *mBuf;              /* message buffer */ 
#endif
{
   MsgLen      mLen;          /* message length */
   MsgLen      mLen2;         /* message length */
   S16         ret;           /* return value */
   U16         msgType;       /* message type, used for trace */
   U8          msgClass;      /* message type, used for trace */
   U8          msgTypeHi;     /* msg type High Byte */
   U8          msgTypeLo;     /* msg type Low Byte */
   Bool        trcFlg;        /* trace flag */

   TRC2(itMiTrcInd)

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
            "itMiTrcInd(suId(%d), evnt(%d), mBuf)\n",suId, evnt));

   ret = ROK;

   /* Get the Message Type at 3rd offset in M3UA hdr */
   SExamMsg((Data *)&msgTypeHi, mBuf, 2); 
   SExamMsg((Data *)&msgTypeLo, mBuf, 3); 

   msgType = (U16)(((((U16)(msgTypeHi)) << 8) + (U16)(msgTypeLo))); 

   msgClass = (U8) IT_MMH_MSGCLASS(msgType);

   if (evnt == LIT_MSG_RX)
   {
      evnt = IT_MSGT2TRCEVNT(msgClass);
   }
   else if (evnt == LIT_MSG_TX)
   {
      evnt = IT_MSGT2TXRCEVNT(msgClass);
   }

   trcFlg = FALSE;
   if (itGlobalCb.itInit.trc == TRUE)
   {
      if ((itGlobalCb.trcMask & LIT_TRC_ALL) == LIT_TRC_ALL)
      {
         trcFlg = TRUE;
      }
      else
      {
         switch(evnt)
         {
            case LIT_MGMT_RX:
            case LIT_MGMT_TX:
               if ((itGlobalCb.trcMask & LIT_TRC_MGMT) != 0)
                  trcFlg = TRUE;
               break;
            case LIT_DATA_RX:
            case LIT_DATA_TX:
               if ((itGlobalCb.trcMask & LIT_TRC_M3UA_XFER) != 0)
                  trcFlg = TRUE;
               break;
            case LIT_SSNM_RX:
            case LIT_SSNM_TX:
               if ((itGlobalCb.trcMask & LIT_TRC_SSNM) != 0)
                  trcFlg = TRUE;
               break;
            case LIT_ASPSM_RX:
            case LIT_ASPSM_TX:
               if ((itGlobalCb.trcMask & LIT_TRC_ASPSM) != 0)
                  trcFlg = TRUE;
               break;
            case LIT_ASPTM_RX:
            case LIT_ASPTM_TX:
               if ((itGlobalCb.trcMask & LIT_TRC_ASPTM) != 0)
                  trcFlg = TRUE;
               break;
            case LIT_RKM_RX:
            case LIT_RKM_TX:
               if ((itGlobalCb.trcMask & LIT_TRC_RKM) != 0)
                  trcFlg = TRUE;
            default:
                  trcFlg = FALSE;
                  break;
         } /* End of switch */
      }
      if (trcFlg == FALSE)
      {
         RETVALUE(ROK);
      }
      /* zero out the management structure */
      IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt));

      (Void) SGetDateTime(&itGlobalCb.mgmt.t.trc.dt);

      SFndLenMsg(mBuf, &mLen);

      if (mLen > LIT_MAX_TRC_LEN)
      {
         mLen = LIT_MAX_TRC_LEN;
      }

      ret = SCpyMsgFix(mBuf, 0, mLen, &(itGlobalCb.mgmt.t.trc.evntParm[0]), 
                       &mLen2);

#if (ERRCLASS & ERRCLS_ADD_RES)
      if ((ret != ROK) || (mLen2 != mLen))
      {
         ITLOGERROR( ERRCLS_ADD_RES, EIT369, (ErrVal) ret,
                     "itMiTrcInd: Failed to create a copy of the mBuf");
      }
#endif /* ERRCLS_ADD_RES */

      /* fill in the event */
      itGlobalCb.mgmt.hdr.elmId.elmnt  = STITSCTSAP;
      itGlobalCb.mgmt.t.trc.evnt       = evnt;
      itGlobalCb.mgmt.t.trc.suId       = suId;
      itGlobalCb.mgmt.t.trc.len        = mLen2;
      itGlobalCb.mgmt.t.trc.msgType    = msgType;
      itGlobalCb.mgmt.hdr.msgType      = TTRC;

      ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
                          "itMiTrcInd, calling ItMiLitTrcInd (len(%d))\n",
                          mLen2));

      (Void) ItMiLitTrcInd(&(itGlobalCb.itInit.lmPst), &itGlobalCb.mgmt);
   } /* End of init.trc == TRUE */
   RETVALUE(ret);
} /* end of itMiTrcInd */


/*
*
*       Fun:   itMiShutdown
*
*       Desc:  Called by LMI to shut down the layer.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itMiShutdown
(
CmStatus *sta                 /* return status */
)
#else
PUBLIC S16 itMiShutdown(sta)
CmStatus *sta;                /* return status */
#endif
{
   U16         i;             /* loop index */
   ItNSapCb    *nSapCb;       /* SNT SAP CB */  
   ItSctSapCb  *sctSapCb;     /* SCT SAP CB */
   ItNwkCb     *nwkCb;        /* network CB */
   ItPsCb      *psCb;         /* PS CB */
   ItPspCb     *pspCb;        /* PSP CB */

   TRC3(itMiShutdown)

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf, "itMiShutdown(sta)\n"));

   if (itGlobalCb.itInit.cfgDone == FALSE)
   {
      ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
                       "itMiShutdown: General Configuration not done\n"));

      sta->status = LCM_PRIM_OK;
      sta->reason = LCM_REASON_NOT_APPL;
      RETVALUE(ROK);
   }

   /* deregister the timer function */
#ifdef SS_MULTIPLE_PROCS
   (Void) SDeregTmr(itGlobalCb.itInit.procId ,itGlobalCb.itInit.ent, itGlobalCb.itInit.inst,
                   itGlobalCb.genCfg.timeRes, itActvTmr);
#else
   (Void) SDeregTmr(itGlobalCb.itInit.ent, itGlobalCb.itInit.inst,
                    itGlobalCb.genCfg.timeRes, itActvTmr);
#endif

   /* remove all nsaps */
   for (i = 0; i < itGlobalCb.genCfg.maxNmbNSap; i++)
   {
      nSapCb = itGlobalCb.nSap[i];
      if (nSapCb != (ItNSapCb *) NULLP)
      {
         /* nSapCb found, unbind and delete */
         itUiDelSap(nSapCb, sta, TRUE);
      }
   }


   /* delete all routes */
   itAtDelRout((ItCntrl *)NULLP, sta);

   while (cmHashListGetNext(&itGlobalCb.ps, (PTR) NULLP, (PTR *) &psCb) ==  ROK)
   {
      itPsmDelPs(psCb->psCfg.psId, sta, TRUE);
   } /* end while */

   /* remove all PSPs */
   for (i = 0; i < itGlobalCb.genCfg.maxNmbPsp; i++)
   {
      pspCb = itGlobalCb.psp[i];
      if (pspCb != (ItPspCb *) NULLP)
      {
         /* asp found, delete */
         itPsmDelPsp(pspCb->pspCfg.pspId, sta, TRUE);
      } /* end if */
   } /* end for */

   /* remove all lower saps */
   for (i = 0; i < itGlobalCb.genCfg.maxNmbSctSap; i++)
   {
      sctSapCb = itGlobalCb.sctSap[i];
      if (sctSapCb != (ItSctSapCb *) NULLP)
      {
         /* sctSapCb found, unbind and delete */
         itLiDelSap(sctSapCb->sctCfg.suId, sta, TRUE);
         /* IT_FREE gets done in itLiDelSap */
      }
   }
   
   /* remove all NwkCbs */
   for (i = 0; i < itGlobalCb.genCfg.maxNmbNwk; i++)
   {
      nwkCb = itGlobalCb.nwk[i];
      if (nwkCb != (ItNwkCb *) NULLP)
      {
         /* NWK CB found, delete */
         itAtDelNwk((U8)i, sta, TRUE);
      }
   }
#ifdef ZV_DFTHA
   /* Undo remaining general config */
   itMiDelGen(&itGlobalCb.genCfg, 10);
#else
   /* Undo remaining general config */
   itMiDelGen(&itGlobalCb.genCfg, 8);
#endif
   /* clear cfgDone flag to allow reconfiguration */
   itGlobalCb.itInit.cfgDone = FALSE;

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
                       "itMiShutdown: LAYER SHUT DOWN SUCCESSFULLY\n"));

   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
#ifdef SS_MULTIPLE_PROCS
   (Void) itActvInit(itGlobalCb.itInit.procId, itGlobalCb.itInit.ent, itGlobalCb.itInit.inst, 
              itGlobalCb.itInit.region, ITSHUTDOWN, (Void**) NULL);
#else
   (Void) itActvInit(itGlobalCb.itInit.ent, itGlobalCb.itInit.inst, 
              itGlobalCb.itInit.region, ITSHUTDOWN);
#endif /* SS_MULTIPLE_PROCS */

   RETVALUE(ROK);
} /* end of itMiShutdown */


/*
*
*       Fun:   itMiDetDuration
*
*       Desc:  This function determines the difference in time between two
*              DateTime structures. The difference is returned in a Duration
*              structure.
*
*       Ret:   ROK
*
*       Notes: <None>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itMiDetDuration
(
DateTime            *st,      /* starting time */
DateTime            *et,      /* end time */
Duration            *dura     /* duration */
)
#else
PUBLIC S16 itMiDetDuration(st, et, dura)
DateTime            *st;      /* starting time */
DateTime            *et;      /* end time */
Duration            *dura;    /* duration */
#endif
{
   U32              start;    /* Start time in seconds */
   U32              end;      /* End time in seconds */
   U32              dur;      /* duration in seonds */

   TRC2(suMiDetDuration)

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
          "itMiDetDuration(st, et, dura)\n"));

   start = st->day * 24 * 3600 + st->hour * 3600 + st->min * 60 + st->sec;
   end   = et->day * 24 * 3600 + et->hour * 3600 + et->min * 60 + et->sec;

   IT_ZERO(dura, sizeof(Duration));

   if (start < end)
   {
      dur         = end - start;
      dura->secs  = (U8)(dur % 60);
      dura->mins  = (U8)((dur / 60) % 60);
      dura->hours = (U8)((dur / 3600) % 24);
      dura->days  = (U8)(dur / 3600 / 24);
   }

   RETVALUE(ROK);
}/* end of itMiDetDuration() */


/************************************************************************
 * ADDRESS TRANSLATION BLOCK
 ************************************************************************/


/*
*
*       Fun:   itAtCfgNwk
*
*       Desc:  This function is used for the network configuration
*              of the M3UA Layer.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtCfgNwk
(
ItNwkCfg *nwkCfg,             /* configuration parameters */
CmStatus *sta                 /* return status */
)
#else
PUBLIC S16 itAtCfgNwk(nwkCfg, sta)
ItNwkCfg *nwkCfg;             /* configuration parameters */ 
CmStatus *sta;                /* return status */            
#endif
{
   ItNwkCb *newNwkCb;         /* new network CB */
   ItNwkCb *nwkCb;            /* existing network CB */
   ItPspCb *pspCb;            /* existing network CB */
   U16     j;                 /* loop index */
   U16     i;                 /* loop index */
   U16     k;                 /* loop index */

   TRC2(itAtCfgNwk)

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
          "itAtCfgNwk(nwkCfg, sta)\n"));

   if (itAtVerifyNwkCfg(nwkCfg, sta) != ROK)
   {
      RETVALUE(RFAILED);
   }

   if (itGlobalCb.nwk[nwkCfg->nwkId] == (ItNwkCb *) NULLP)
   {
      /* allocate new NwkCb */
      IT_ALLOC(sizeof(ItNwkCb), newNwkCb);
      /* allocate list of ASs inside new NwkCB */
      IT_ALLOC(((sizeof(ItPsCb *)) * itGlobalCb.genCfg.maxNmbPs), newNwkCb->ps);
      /* copy the network context configuration */
      cmMemcpy((U8 *) &(newNwkCb->nwkCfg), (U8 *) nwkCfg, sizeof(ItNwkCfg));
      newNwkCb->restart = FALSE;
      for (i = 0; i < LIT_MAX_PSP; i++)
      {
         newNwkCb->sgpRst[i] = FALSE;
      }
      IT_INITTIMER(&newNwkCb->tmrRestart);
      itGlobalCb.nwk[newNwkCb->nwkCfg.nwkId] = (ItNwkCb *) newNwkCb;
   }
   /* if nwkCb already exists - fail, no reconfig allowed */
   else
   {
      nwkCb = (ItNwkCb *)itGlobalCb.nwk[nwkCfg->nwkId];

      if (nwkCfg->nwkId != nwkCb->nwkCfg.nwkId)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_RECONFIG_FAIL;
         RETVALUE(RFAILED);
      }

      /* it013.106 - SSF being made reconfigurable. */

      if (nwkCfg->dpcLen != nwkCb->nwkCfg.dpcLen)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_RECONFIG_FAIL;
         RETVALUE(RFAILED);
      }

      if (nwkCfg->slsLen != nwkCb->nwkCfg.slsLen)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_RECONFIG_FAIL;
         RETVALUE(RFAILED);
      }

      if (nwkCfg->suSwtch != nwkCb->nwkCfg.suSwtch)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_RECONFIG_FAIL;
         RETVALUE(RFAILED);
      }

      if (nwkCfg->su2Swtch != nwkCb->nwkCfg.su2Swtch)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_RECONFIG_FAIL;
         RETVALUE(RFAILED);
      }
      for (i = 1; i < LIT_MAX_PSP; i++)
      {
         if (nwkCfg->nwkApp[i] != nwkCb->nwkCfg.nwkApp[i])
         {
            ItAssocCb   *assocCb;      /* association CB */
   
            assocCb = (ItAssocCb *)NULLP;
            pspCb = (ItPspCb *)itGlobalCb.psp[i]; 

            /* if No PSP exist then Re-configuration is Valid */
            if (pspCb == (ItPspCb *)NULLP)
            {
               continue;
            }

            /* All the PS of which this PSP is a Part */
            for (j = 0; j < LIT_MAX_SEP; j++)
            {
               assocCb = itGlobalCb.assoc[IT_PSPnENDP2ASSOC(i, j)];

               for (k = 0; k < assocCb->nmbPs; k++)
               {
                  /* If any PS belonging to same Network is Active
                   * then fail the Network appearance re-configuration */
                  if ((assocCb->ps[k]->psSta.psStaEndp[j].aspSt[i] 
                                                          == LIT_ASP_ACTIVE) &&
                      (assocCb->ps[k]->psCfg.nwkId == nwkCfg->nwkId))
                  {
                     sta->status = LCM_PRIM_NOK;
                     sta->reason = LCM_REASON_RECONFIG_FAIL;
                     RETVALUE(RFAILED);
                  }
               }
            }
         }
      }

      /* it013.106 - SSF being made reconfigurable. */
      if (nwkCfg->ssf != nwkCb->nwkCfg.ssf)
      {
         /* If the old ssf was SSF_NAT and dpcLen is not DPC16, then reset 
          * the congestion level stored for DPC and PS in this network. 
          * This is because the congestion level is stored either when ssf
          * is SSF_NAT or dpcLen is DPC16. */
         if ((nwkCb->nwkCfg.ssf == SSF_NAT) &&
             (nwkCb->nwkCfg.dpcLen != DPC16))
         {
            ItDpcCb  *dpcCb;              /* DPC control block */
            UConnId     assocId;       /* Assoc ID */
            ItPsCb      *psCb;         /* PS control block  */

            psCb = NULLP;
            while (cmHashListGetNext(&itGlobalCb.ps, (PTR) psCb,
                               (PTR *) &psCb) ==  ROK)
            {
               /* Check if PS belongs to same network being reconfigured */
               if (psCb->nwk->nwkCfg.nwkId == nwkCfg->nwkId)
               {
                  /* Reset the PS congLevel to SN_PRI0. */
                  psCb->congLevel = SN_PRI0;
               } /* end of if PS belongs to same network */
            } /* end of while on PSs */

            dpcCb = NULLP;
            while (cmHashListGetNext(&itGlobalCb.addrTrn.dpcList, (PTR) dpcCb,
            (PTR *)&dpcCb) == ROK)
            {
               /* Check if DPC belongs to same network being reconfigured */
               if (dpcCb->nwk->nwkCfg.nwkId == nwkCfg->nwkId)
               {
                  /* if DPC congLevel is greater than SN_PRI0, then reset the
                   * congestion level for all the PSPs in this DPC CB. Then
                   * recalculate the DPC congestion level. */
                  if (dpcCb->congLevel > SN_PRI0)
                  {
                     for (assocId = 0; assocId < itGlobalCb.maxNmbAssoc; assocId++)
                     {
                        dpcCb->pspDpcCong[assocId]   = SN_PRI0;
                     }
                     dpcCb->congLevel = SN_PRI0;
                  }
               } /* end of if DPC belongs to same network */
            } /* end of while on DPCs */

         } /* if old SSF was SSF_NAT */
      } /* ssf being changed */

      /* copy the network context configuration */
      cmMemcpy((U8 *) &(nwkCb->nwkCfg), (U8 *) nwkCfg, sizeof(ItNwkCfg));
   }
      
   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;

   RETVALUE(ROK);
} /* end of itAtCfgNwk */


/*
*
*       Fun:   itAtVerifyNwkCfg
*
*       Desc:  This function is used to check the validity of the ItNwkCfg
*              struct being passed to itAtCfgNwk.
*
*       Ret:   Failure:           RFAILED
*                                 status = LCM_PRIM_NOK
*                                 reason = LCM_INVALID_PAR_VAL
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtVerifyNwkCfg
(
ItNwkCfg *nwkCfg,             /* configuration parameters */ 
CmStatus *sta                 /* return status */            
)
#else
PUBLIC S16 itAtVerifyNwkCfg(nwkCfg, sta)
ItNwkCfg *nwkCfg;             /* configuration parameters */ 
CmStatus *sta;                /* return status */            
#endif
{
   TRC2(itAtVerifyNwkCfg)

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf, "itAtVerifyNwkCfg\n"));

   switch (nwkCfg->ssf)
   {
      /* following 4 cases fall through */
      case SSF_INTL:
      case SSF_NAT:
      /* Addition: Spare and reserved SSF included */
      case SSF_SPARE:
      case SSF_RES:
         break;
      
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT370,
                    (ErrVal) nwkCfg->ssf,
                    "itAtVerifyNwkCfg(nwkCfg, sta): Invalid ssf in nwkCfg");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
   }

   switch (nwkCfg->dpcLen)
   {
      /* following 3 cases fall through */
      case DPC24:
      case DPC16:
      case DPC14:
         break;
      
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT371,
               (ErrVal) nwkCfg->dpcLen,
               "ItAtVerifyNwkCfg(nwkCfg, sta): Invalid dpcLen in nwkCfg");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
   }

   switch (nwkCfg->slsLen)
   {
      /* following 3 cases fall through */
      case LIT_SLS4:
      case LIT_SLS5:
      case LIT_SLS8:
         break;
      
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT372,
                    (ErrVal) nwkCfg->slsLen,
                    "ItAtVerifyNwkCfg(nwkCfg, sta): Invalid slsLen in nwkCfg");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
   }
   
   switch (nwkCfg->suSwtch)
   {
      /* the following 3 cases fall through */
      case LIT_SW_ANS:
      case LIT_SW_ANS96:
      case LIT_SW_ITU:
      case LIT_SW_TTC:
      case LIT_SW_NTT:
      case LIT_SW_CHINA:
         break;
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT373,
                    (ErrVal) nwkCfg->suSwtch,
                    "itAtVerifyNwkCfg: invalid or unsupported suSwtch");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
   }
   
   switch (nwkCfg->su2Swtch)
   {
      /* the following 3 cases fall through */
      case LIT_SW2_ITU:
      case LIT_SW2_ETS:
      case LIT_SW2_ANS:
      case LIT_SW2_TTC:
      /* it005.106 - Allow su2Swtch to be set as LIT_SW2_UNUSED if it is 
       * unused */
      case LIT_SW2_UNUSED:
         break;
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT374,
                    (ErrVal) nwkCfg->su2Swtch,
                    "itAtVerifyNwkCfg: invalid su2Swtch");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
   }

   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   
   RETVALUE(ROK);
} /* end of itAtVerifyNwkCfg */


/*
*
*       Fun:   itAtDelNwk
*
*       Desc:  This function is used to delete a network entity in 
*              the M3UA Layer.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtDelNwk
(
U8       nwkId,               /* Network ID */
CmStatus *sta,                /* return status */
Bool     itabort              /* TRUE if forced delete */
)
#else
PUBLIC S16 itAtDelNwk(nwkId, sta, itabort)
U8       nwkId;               /* Network ID */
CmStatus *sta;                /* return status */      
Bool     itabort;             /* TRUE if forced delete */
#endif
{
   U16         i;             /* loop index */
   ItPsCb      *tmpPsCbPtr;   /* temp PS CB */
   ItDpcCb     *prevEnt;      /* previous DPC entry */
   ItDpcCb     *entry;        /* current DPC entry */
   ItPsCb      *prevPsEnt;    /* previous PS entry */
   ItPsCb      *psCb;         /* current PS entry */
   ItRouteCb   *curRouteCb;   /* current route CB */
   ItNwkCb     *nwkCb;        /* Network CB */
   
   TRC2(itAtDelNwk)

   ITDBGP(DBGMASK_MI|IT_DBGMASK_AT, (itGlobalCb.itInit.prntBuf,
          "itAtDelNwk nwkId: (%d)\n", nwkId));

   nwkCb = itGlobalCb.nwk[nwkId];
   if (nwkCb == (ItNwkCb *) NULLP)
   {
      sta->reason = LCM_REASON_NOT_APPL;
      sta->status = LCM_PRIM_OK;
      RETVALUE(ROK);
   }

   tmpPsCbPtr  = (ItPsCb *) NULLP;
   prevEnt     = (ItDpcCb *) NULLP;
   entry       = (ItDpcCb *) NULLP;

   if (itabort == FALSE)
   {
      /* search all dpcCbs for nwkId match */
      while (cmHashListGetNext(&itGlobalCb.addrTrn.dpcList,
                               (PTR) prevEnt, (PTR *) &entry) ==  ROK)
      {
         /* search for nwkId match  */
         if (entry->nwk->nwkCfg.nwkId  == nwkId)
         {
            /* return failed */
#if (ERRCLASS & ERRCLS_INT_PAR)
            ITLOGERROR(ERRCLS_INT_PAR, EIT375, (ErrVal) entry->dpc, 
                       "ItAtDelNwk(): DPC entry still using nwkId");
#endif /* ERRCLS_INT_PAR */
            sta->reason = LIT_REASON_SERVICE_IN_USE;
            sta->status = LCM_PRIM_NOK;
            RETVALUE(RFAILED);
         }
         prevEnt = entry;
      } /* end while */
   
      /* search all global routes for nwkId match */
      for (curRouteCb = (ItRouteCb *)cmLListFirst(&itGlobalCb.addrTrn.rtList); 
           curRouteCb;
           curRouteCb = (ItRouteCb *)cmLListNext(&itGlobalCb.addrTrn.rtList))
      {
         if (curRouteCb->rteCfg.nwkId == nwkId)
         {
            /* return failed */
#if (ERRCLASS & ERRCLS_INT_PAR)
            ITLOGERROR(ERRCLS_INT_PAR, EIT376, (ErrVal) 0, 
                       "ItAtDelNwk(): Route entry still using nwkId");
#endif /* ERRCLS_INT_PAR */
            sta->reason = LIT_REASON_SERVICE_IN_USE;
            sta->status = LCM_PRIM_NOK;
            RETVALUE(RFAILED);
         }
      }
   
      /* search all psCbs for nwkId match */
      prevPsEnt = (ItPsCb *) NULLP;
      while (cmHashListGetNext(&itGlobalCb.ps, (PTR) prevPsEnt,
                               (PTR *) &psCb) ==  ROK)
      {
         /* search for nwkId match  */
         if (psCb->nwk->nwkCfg.nwkId  == nwkId)
         {
            /* return failed */
#if (ERRCLASS & ERRCLS_INT_PAR)
            ITLOGERROR(ERRCLS_INT_PAR, EIT377, (ErrVal) psCb->psCfg.psId, 
                       "ItAtDelNwk(): PS still using nwkId");
#endif /* ERRCLS_INT_PAR */
            sta->reason = LIT_REASON_INVALID_NWKID;
            sta->status = LCM_PRIM_NOK;
            RETVALUE(RFAILED);
         }
         prevPsEnt = psCb;
      } /* end while */
   
      /* search all nSapCbs for nwkId match */
      for (i = 0; i < itGlobalCb.genCfg.maxNmbNSap; i++)
      {
         /* look for nwkId */
         if (itGlobalCb.nSap[i] != (ItNSapCb *) NULLP)
         {
            if (itGlobalCb.nSap[i]->nwk->nwkCfg.nwkId == nwkId)
            {
               /* return failed */
#if (ERRCLASS & ERRCLS_INT_PAR)
               ITLOGERROR(ERRCLS_INT_PAR, EIT378,
                          (ErrVal) itGlobalCb.nSap[i]->sntCfg.sapId, 
                          "ItAtDelNwk(): NSAP still using nwkId");
#endif /* ERRCLS_INT_PAR */
               sta->reason = LIT_REASON_INVALID_NWKID;
               sta->status = LCM_PRIM_NOK;
               RETVALUE(RFAILED);
            }
         }
      } /* end for loop */
      
      /* search all PSPs for nwkId match */
      /* PSP ID 0 is always local PSP so skip that */
      for (i = 1; i < itGlobalCb.genCfg.maxNmbPsp; i++)
      {
         if (itGlobalCb.psp[i] != (ItPspCb *) NULLP)
         {
            /* look for nwkId */
            if (itGlobalCb.psp[i]->pspCfg.nwkId == nwkId)
            {
               /* return failed */
#if (ERRCLASS & ERRCLS_INT_PAR)
               ITLOGERROR(ERRCLS_INT_PAR, EIT379,
                          (ErrVal) itGlobalCb.psp[i]->pspCfg.pspId,
                          "ItAtDelNwk(): PSP still using nwkId");
#endif /* ERRCLS_INT_PAR */
               sta->reason = LIT_REASON_INVALID_NWKID;
               sta->status = LCM_PRIM_NOK;
               RETVALUE(RFAILED);
            }
         }
      } /* end for loop */
   }
      
#ifdef ZV
   zvRTUpd(CMPFTHA_ACTN_DEL, ZV_NWKCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) itGlobalCb.nwk[nwkId],
                         NULLP);
#endif
   /* find nwkCb according to tmpnwkId, remove it, return memory, remove
    * from list of pointers in globalCb */
   IT_FREE(itGlobalCb.genCfg.maxNmbPs * sizeof(ItPsCb *), 
           itGlobalCb.nwk[nwkId]->ps);
   IT_FREE(sizeof(ItNwkCb), itGlobalCb.nwk[nwkId]);
   itGlobalCb.nwk[nwkId] = (ItNwkCb *) NULLP;
   
   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;

   RETVALUE(ROK);
} /* end of itAtDelNwk */


/*
*
*       Fun:   itAtCfgRout
*
*       Desc:  This function is used for the route entry configuration
*              of the M3UA Layer.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*               A new argument is added to this function as a part of
*               phase 2 release of M3UA1.5. This new argument will
*                allow this function to cover status request for
*                routs. It will find whether the rout exist. If the
*                chkRout flag is TRUE then this function will be used 
*                for status request function
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtCfgRout
(
ItRteCfg *cfg,                /* configuration parameters */
CmStatus *sta,                /* return status */
Bool      chkRout             /* Whether just want to see the rout exists */
)
#else
PUBLIC S16 itAtCfgRout(cfg, sta, chkRout)
ItRteCfg *cfg;                /* configuration parameters */
CmStatus *sta;                /* return status */           
Bool      chkRout;            /* Whether just want to see the rout exists */
#endif
{
   ItRouteCb   *newRouteCb;   /* new route CB */
   ItRouteCb   *cloneRouteCb; /* clone route CB */
   S16         ret;           /* return value */
   ItDpcCb     *dpcCb;        /* DPC control block */
   U32         tmpDpcMaskTest; /* temp DPC mask test */
   U16         dpcLen;        /* DPC length */
   Bool        dpcSpecified;  /* TRUE if DPC fully specified */
   ItPsCb      *psCb;         /* PS control block */
   Bool        routingDpc;    /* TRUE if routing DPC */
   ItPsId      dummyPsId;     /* PsId to pass AtAddNewRouteCb */

   TRC2(itAtCfgRout)

   ITDBGP(DBGMASK_MI|IT_DBGMASK_AT, (itGlobalCb.itInit.prntBuf,
               "itAtCfgRout(cfg)\n"));

   if (itAtVerifyRoutCfg(cfg, sta, FALSE) != ROK)
   {
      RETVALUE(RFAILED);
   }
   /* Initialize psCb */
   psCb = (ItPsCb *)NULLP;

   dpcLen         = itGlobalCb.nwk[cfg->nwkId]->nwkCfg.dpcLen;
   tmpDpcMaskTest = (dpcLen == DPC14) ? 0x3fff :
                    (dpcLen == DPC16) ? 0xffff : 0xffffff;
   routingDpc     = FALSE;

   /* it007.106 - The dpcMask can be set to LIT_DPC_SPECIFIED to specify a 
    * complete DPC for dpcLen of DPC14 and DPC16. */
   /* it009.106 - Simplified the check to compare dpcMask */
   if ((cfg->rtFilter.dpcMask == tmpDpcMaskTest) ||
       (cfg->rtFilter.dpcMask == LIT_DPC_SPECIFIED))
   {
      dpcSpecified            = TRUE;
      cfg->rtFilter.dpcMask   = LIT_DPC_SPECIFIED;
   }
   else
   {
      dpcSpecified = FALSE;
   }

   /* Normalize OPC mask as well */
   if (cfg->rtFilter.opcMask == tmpDpcMaskTest)
   {
      cfg->rtFilter.opcMask   = LIT_DPC_SPECIFIED;
   }

   if (cfg->rtType == LIT_RTTYPE_PS)
   {
      psCb = itPsmFindPs(cfg->psId);
   }
   else
   {
      psCb = (ItPsCb *)NULLP;
   }

   if (dpcSpecified == TRUE)
   {
      /* fully specd dpc */
      /* search hash list using these 2 values */
      if (itAtGetDpc(cfg->nwkId, cfg->rtFilter.dpc, &dpcCb) == ROK)
      {
         if (cfg->rtType == LIT_RTTYPE_PS)
         {                                                             
            if (cfg->noStatus != dpcCb->noStatus)
            {
#if (ERRCLASS & ERRCLS_INT_PAR)
               ITLOGERROR(ERRCLS_INT_PAR, EIT380, (ErrVal) cfg->noStatus,
                          "itAtCfgRout: noStatus not matching rest of SPMC");
#endif /* ERRCLS_INT_PAR */
               sta->status = LCM_PRIM_NOK;
               sta->reason = LIT_REASON_INVALID_RTENT;
               RETVALUE(RFAILED);
            }
            if (psCb->spmc != (ItDpcCb *) NULLP)
            {
               if (psCb->spmc != dpcCb)
               {
#if (ERRCLASS & ERRCLS_INT_PAR)
                  ITLOGERROR(ERRCLS_INT_PAR, EIT381, (ErrVal) cfg->psId,
                             "itAtCfgRout: PS belongs to a different SPMC");
#endif /* ERRCLS_INT_PAR */
                  sta->status = LCM_PRIM_NOK;
                  sta->reason = LIT_REASON_INVALID_RTENT;
                  RETVALUE(RFAILED);
               }
            }
         }

         /* clone routing DPC CB if required */

         /* for non routing DPC formed as a result of
          * DPC learning there is no route present in DPC
          * also it cannot be used as a routing DPC so for
          * NON Routing DPCs route is configured later in 
          * this function.  */
         if ((cmLListLen(&dpcCb->routes) == 0) &&
             (dpcCb->type != IT_DPCCB_NONROUTE)) 
         {
            /* cluster list empty - this was a routing DPC CB */
            /* clone DPC CB to form new RCB */
            IT_ALLOC(sizeof(ItRouteCb), cloneRouteCb);
            /* 
             * starting from a zero'd out cloneRouteCb, the following have to 
             * be set up:
             */
            cloneRouteCb->rteCfg.rtFilter.includeCic  = FALSE;
            cloneRouteCb->rteCfg.rtFilter.includeSsn  = FALSE;
            cloneRouteCb->rteCfg.rtFilter.includeTrid = FALSE;
            cloneRouteCb->rteCfg.rtFilter.dpc      = dpcCb->dpc;
            cloneRouteCb->rteCfg.rtFilter.dpcMask  = LIT_DPC_SPECIFIED;
            cloneRouteCb->rteCfg.rtType            = IT_DPC2RTTYPE(dpcCb->type);
            cloneRouteCb->rteCfg.nwkId             = dpcCb->nwk->nwkCfg.nwkId;
            cloneRouteCb->owner                    = dpcCb->owner;
            if (cloneRouteCb->owner != (ItPsCb *) NULLP)
            {
               cloneRouteCb->rteCfg.psId = cloneRouteCb->owner->psCfg.psId;
            }
            if (dpcCb->nSap != (ItNSapCb *) NULLP)
            {
               cloneRouteCb->rteCfg.nSapId         = dpcCb->nSap->sntCfg.sapId;
               cloneRouteCb->rteCfg.nSapIdPres     = TRUE;
            }
            else
            {
               cloneRouteCb->rteCfg.nSapIdPres     = FALSE;
            }
            if (dpcCb->type == IT_DPCCB_SPMC)
            {
               cloneRouteCb->rteCfg.noStatus       = dpcCb->noStatus;
            }
            /* 
             * create new rcb's filter and mask from rteCfg and put
             * resulting arrays in rtFilter and rtMask 
             */
            (Void) itAtCreatertFilter(cloneRouteCb);
            /* insert new RouteCb in DPC cluster chain */
            ret = itAtAddnewRouteCb(cloneRouteCb, dpcCb, TRUE, &dummyPsId);
            if (ret != ROK)
            {
               sta->status = LCM_PRIM_NOK;
               sta->reason = LIT_REASON_INVALID_RTENT;
               RETVALUE(ret);
            }
            /* Clear dpcCb as Owner and NSAP has been marked NULL */
            dpcCb->owner = (ItPsCb *) NULLP;
            dpcCb->nSap  = (ItNSapCb *) NULLP;
         }
         /* when a DPC only route is added to a 
            Non Routing DPC then we need to add all the parameters
            in the DPC itself so that a notification could be 
            sent to the user on the reception of SSNM message from 
            a peer for this DPC */ 
         else if (dpcCb->type == IT_DPCCB_NONROUTE) 
         {
            dpcCb->owner = (PTR) NULLP;
            
            if ((cfg->rtFilter.opcMask == 0) &&
                (cfg->rtFilter.slsMask == 0) &&
                (cfg->rtFilter.sioMask == 0) &&
                (cfg->rtFilter.includeCic == FALSE) &&
                (cfg->rtFilter.includeSsn == FALSE) &&
                (cfg->rtFilter.includeTrid == FALSE))
            {
               /* special case - this will be a routing DPC CB */
               routingDpc = TRUE;
               /* fill in owner */
               if (cfg->rtType == LIT_RTTYPE_PS)
               {
                  dpcCb->owner      = psCb;
                  dpcCb->noStatus   = cfg->noStatus;
                  psCb->spmc        = dpcCb;
                  dpcCb->type       = IT_DPCCB_SPMC;
               }
               /* fill in nSap */
               if (cfg->nSapIdPres == TRUE)
               {
                  dpcCb->nSap       = itGlobalCb.nSap[cfg->nSapId];
               }
               else
               {
                  dpcCb->nSap       = (ItNSapCb *) NULLP;
               }
            }
         }
      }
      else
      {
         /* if hash key not found */
         if (cfg->rtType == LIT_RTTYPE_PS)
         {                                                             
            if (psCb->spmc != (ItDpcCb *) NULLP)
            {
#if (ERRCLASS & ERRCLS_INT_PAR)
               ITLOGERROR(ERRCLS_INT_PAR, EIT382, (ErrVal) cfg->psId,
                          "itAtCfgRout: PS belongs to a different SPMC");
#endif /* ERRCLS_INT_PAR */
               sta->status = LCM_PRIM_NOK;
               sta->reason = LIT_REASON_INVALID_RTENT;
               RETVALUE(RFAILED);
            }
         }
         
         /* create new DPC CB */
         if ((ret = itAtAddDpc(cfg->nwkId, cfg->rtFilter.dpc, &dpcCb, 
                               IT_RTTYPE2DPC(cfg->rtType))) != ROK)
         {
            RETVALUE(ret);
         }
         dpcCb->owner = (PTR) NULLP;

         if ((cfg->rtFilter.opcMask == 0) &&
             (cfg->rtFilter.slsMask == 0) &&
             (cfg->rtFilter.sioMask == 0) &&
             (cfg->rtFilter.includeCic == FALSE) &&
             (cfg->rtFilter.includeSsn == FALSE) &&
             (cfg->rtFilter.includeTrid == FALSE))
         {
            /* special case - this will be a routing DPC CB */
            routingDpc = TRUE;
            /* fill in owner */
            if (cfg->rtType == LIT_RTTYPE_PS)
            {
               dpcCb->owner      = psCb;
               dpcCb->noStatus   = cfg->noStatus;
               psCb->spmc        = dpcCb;
            }
            /* fill in nSap */
            if (cfg->nSapIdPres == TRUE)
            {
               dpcCb->nSap       = itGlobalCb.nSap[cfg->nSapId];
            }
            else
            {
               dpcCb->nSap       = (ItNSapCb *) NULLP;
            }
         }
      } /* end if (cmHashListFind) */
   }
   else
   {
      /* Non-fully specified DPC - no DPC hash list entry associated */
      dpcCb = (ItDpcCb *) NULLP;
      if (cfg->rtType == LIT_RTTYPE_PS)
      {                                                             
         if (psCb->spmc != (ItDpcCb *) NULLP)
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            ITLOGERROR(ERRCLS_INT_PAR, EIT383, (ErrVal) cfg->psId,
                       "itAtCfgRout: PS belongs to a different SPMC");
#endif /* ERRCLS_INT_PAR */
            sta->status = LCM_PRIM_NOK;
            sta->reason = LIT_REASON_INVALID_RTENT;
            RETVALUE(RFAILED);
         }
      }
   }

   if (routingDpc == FALSE)
   {
      /* create new RCB */
      IT_ALLOC(sizeof(ItRouteCb), newRouteCb);
      /* copy cfg to new RouteCb */
      cmMemcpy((U8 *) &(newRouteCb->rteCfg), (U8 *) cfg, sizeof(ItRteCfg));
      /* create the routing filter for this RouteCb */
      (Void) itAtCreatertFilter(newRouteCb);
      newRouteCb->owner = (PTR) NULLP;
      if (cfg->rtType == LIT_RTTYPE_PS)
      {
         /* spmc will be NULLP for non-fully spec'd DPC */
         psCb->spmc        = dpcCb;
         newRouteCb->owner = psCb;
         if (dpcCb != (ItDpcCb *)NULLP)
         {
            dpcCb->noStatus = cfg->noStatus;
            /* when a  route is added for a
               PS then set DPC type to SPMC */ 
            dpcCb->type       = IT_DPCCB_SPMC;
         }
      }
      
      /* insert new RouteCb in order in DPC cluster chain or global list */
      if ((ret = itAtAddnewRouteCb(newRouteCb, dpcCb, TRUE, &dummyPsId)) != ROK)
      {
         if (chkRout == TRUE)
         {
            if (ret == ROKDUP)
            {
               /* undo */
               IT_FREE(sizeof(ItRouteCb), newRouteCb);
               RETVALUE(ROK);
            }
            else
            {
               /* undo */
               IT_FREE(sizeof(ItRouteCb), newRouteCb);
               RETVALUE(RFAILED);
            }
         } 
         if (ret == ROKDUP)
         {
            /* it013.106 - Return RFAILED if the route completely matches an 
             * existing routing entry except the PS id. If PS id is also same 
             * return ROK. */
            if ((newRouteCb->owner != (PTR) NULLP) &&
                (newRouteCb->owner->psCfg.psId != dummyPsId))
            {
               IT_FREE(sizeof(ItRouteCb), newRouteCb);
               sta->reason = LIT_REASON_INVALID_RTENT;
               sta->status = LCM_PRIM_NOK;
               RETVALUE(RFAILED);
            }
            else
            {
               IT_FREE(sizeof(ItRouteCb), newRouteCb);
               sta->reason = LCM_REASON_NOT_APPL;
               sta->status = LCM_PRIM_OK;
               RETVALUE(ROK);
            }
         }
         else
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            ITLOGERROR(ERRCLS_INT_PAR, EIT384, (ErrVal) 0,
                    "itAtCfgRout: OverLap route configuration");
#endif /* ERRCLS_INT_PAR */
         }
         /* undo */
         IT_FREE(sizeof(ItRouteCb), newRouteCb);
         sta->reason = LIT_REASON_INVALID_RTENT;
         sta->status = LCM_PRIM_NOK;
         RETVALUE(RFAILED);
      }
   }

   if (dpcSpecified == TRUE)
   {
      /* changes done for sending a DPC available notification 
         to LM as well as the users of M3UA if a DPC becomes available
         after configuring a Route. */ 

      U8 oldDpcSt;         /* old DPC state */
      U8 oldDpcCong;       /* old DPC congestion level */
      oldDpcSt    = dpcCb->dpcSt;
      oldDpcCong  = dpcCb->congLevel;
      if ((ret = itMifCalcDpcStatus(dpcCb, IT_MIF_PC_CHANGED, 0)) != ROK)
      {
         RETVALUE(ret);
      }
      /*  As a route can be added to a previously active PS.
          Then in this case DPC may become available as soon as its 
          configured. Or if a new route has been added to the DPC and 
          an already existing DPC becomes available through that route.
          An available DPC wll never become Unavailable by configuring
          a route */
      if (((oldDpcSt == IT_DPC_UNKNOWN) || (oldDpcSt == IT_DPC_UNAVAILABLE)) &&
          (dpcCb->dpcSt == IT_DPC_AVAILABLE) &&
          (dpcCb->type == IT_DPCCB_SPMC) &&
          (dpcCb->owner != NULL) && (dpcCb->owner->psCfg.lclFlag != TRUE))
      {
         if ((ret = itMifDpcEvt(FALSE, (UConnId) NULL, IT_MIF_SPMC, 
             IT_MIF_PC_AVA, dpcCb->nwk->nwkCfg.nwkId, dpcCb->dpc, 
             (Dpc)NULL, 0, (SrvInfo)0, dpcCb)) != ROK)
         {
            RETVALUE(ret);
         }
      }

   }

#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   if (itGlobalCb.genCfg.nodeType == LIT_TYPE_ASP)
   {
      if ((cfg->rtType == LIT_RTTYPE_PS) && 
          (psCb->psCfg.lclFlag == TRUE)  && 
          (cfg->nSapIdPres == TRUE))
      {
         itGlobalCb.nSap[cfg->nSapId]->lpsId = psCb->psCfg.psId;
      }
   } /* end of if nodeType is LIT_TYPE_ASP */
#endif /* ITASP && OG_RTE_ON_LPS_STA */

   /* update the atSta entry to reflect no of routes */
   itGlobalCb.addrTrn.atSta.nmbRout++;

   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;

   RETVALUE(ROK);
} /* end of itAtCfgRout */


/*
*
*       Fun:   itAtVerifyRoutCfg
*
*       Desc:  This function verifies the RteCfg struct passed
*              to itAtCfgRout
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtVerifyRoutCfg
(
ItRteCfg *cfg,                /* configuration parameters */ 
CmStatus *sta,                /* return status */            
Bool      deleteFlag          /* TRUE if this function is called for route deletion */
)
#else
PUBLIC S16 itAtVerifyRoutCfg(cfg, sta, deleteFlag)
ItRteCfg *cfg;                /* configuration parameters */ 
CmStatus *sta;                /* return status */            
Bool      deleteFlag;         /* TRUE if this function is called for route deletion */
#endif
{
   ItPsCb *psCb = (ItPsCb *)NULLP; /* temporary PS CB */
   U32    tmpDpcMaskTest;          /* temp DPC mask test */
   U16    dpcLen;                  /* DPC length */
   U8     tmpSlsMaskTest;          /* temp SLS mask test */
   U8     slsLen;                  /* SLS length */
   ItRouteCb   *curRouteCb;        /* current route CB */

   TRC2(itAtVerifyRoutCfg)

   ITDBGP(DBGMASK_MI|IT_DBGMASK_AT, (itGlobalCb.itInit.prntBuf,
                                     "itAtVerifyRoutCfg(cfg, sta)\n"));
   /* Initialize psCb */
   psCb = (ItPsCb *)NULLP;
   if (itGlobalCb.addrTrn.atSta.nmbRout >= itGlobalCb.genCfg.maxNmbRtEnt)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT385,
                 (ErrVal) itGlobalCb.addrTrn.atSta.nmbRout,
                 "itAtVerifyRoutCfg: max no. routeEnt exceeded");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_INVALID_RTENT;
      RETVALUE(RFAILED);
   }

   if (cfg->nwkId >= itGlobalCb.genCfg.maxNmbNwk)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT386, (ErrVal) cfg->nwkId,
                 "itAtVerifyRoutCfg: nwkId out of range");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_INVALID_NWKID;
      RETVALUE(RFAILED);
   }
   
   if ((itGlobalCb.nwk[cfg->nwkId]) == ((ItNwkCb *) NULLP))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT387, (ErrVal) cfg->nwkId,
                 "itAtVerifyRoutCfg: unconfigured nwkId");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_INVALID_NWKID;
      RETVALUE(RFAILED);
   }

   switch (cfg->nSapIdPres)
   {
      case TRUE:
         if ((cfg->nSapId >= itGlobalCb.genCfg.maxNmbNSap) ||
             (itGlobalCb.nSap[cfg->nSapId] == (ItNSapCb *)NULLP))
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            ITLOGERROR(ERRCLS_INT_PAR, EIT388,
                       (ErrVal) cfg->nSapId,
                       "itAtVerifyRoutCfg: invalid nSapId");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
            sta->status = LCM_PRIM_NOK;
            sta->reason = LIT_REASON_INVALID_NSAPID;
            RETVALUE(RFAILED);
         }
         break;
      case FALSE:
         break;
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT389, (ErrVal) cfg->nSapIdPres,
                    "itAtVerifyRoutCfg: invalid nSapIdPres");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
   }

   switch (cfg->rtType)
   {
      case LIT_RTTYPE_LOCAL:
         break;
#ifdef ITSG
      case LIT_RTTYPE_MTP3:
         break;
#endif /* ITSG */
      case LIT_RTTYPE_PS:
         if ((psCb = itPsmFindPs(cfg->psId)) == (ItPsCb *) NULLP)
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            ITLOGERROR(ERRCLS_INT_PAR, EIT390,
                       (ErrVal) cfg->psId,
                       "itAtVerifyRoutCfg: unconfigured psId");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
            sta->status = LCM_PRIM_NOK;
            sta->reason = LCM_REASON_INVALID_PAR_VAL;
            RETVALUE(RFAILED);
         }
         /* Don't test the following if the function is called to delete 
          * an existing route */
         if (!deleteFlag)
         {
         /* Search through all Wildcarded routes to ensure that no other route
            points to the same psId */
            cmLListFirst(&(itGlobalCb.addrTrn.rtList));
            
            while (cmLListCrnt(&(itGlobalCb.addrTrn.rtList)))
            {
               curRouteCb = (ItRouteCb *)cmLListCrnt(&(itGlobalCb.addrTrn.rtList));
            
               if ((curRouteCb->rteCfg.psId == cfg->psId) &&
                   (curRouteCb->rteCfg.rtType == cfg->rtType))
               {
#if (ERRCLASS & ERRCLS_INT_PAR)
                  ITLOGERROR(ERRCLS_INT_PAR, EIT391,
                             (ErrVal) cfg->psId,
                             "itAtVerifyRoutCfg: psId used by another route");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
                  sta->status = LCM_PRIM_NOK;
                  sta->reason = LCM_REASON_INVALID_PAR_VAL;
                  RETVALUE(RFAILED);
               }
            
               cmLListNext(&(itGlobalCb.addrTrn.rtList));
            }

            /* - If this is a local route at ASP/IPSP-SE, the NSAP
             * Id should be present */
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
            if (itGlobalCb.genCfg.nodeType == LIT_TYPE_ASP)
            {
               if (psCb->psCfg.lclFlag == TRUE)
               {
                  if (cfg->nSapIdPres == FALSE)
                  {
#if (ERRCLASS & ERRCLS_INT_PAR)
                     ITLOGERROR(ERRCLS_INT_PAR, EIT392,
                             (ErrVal) cfg->nSapIdPres,
                            "itAtVerifyRoutCfg: nSapId absent for Local Route");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
                     sta->status = LCM_PRIM_NOK;
                     sta->reason = LIT_REASON_INVALID_RTENT;
                     RETVALUE(RFAILED);
                  }
                  else
                  {
                     if ((itGlobalCb.nSap[cfg->nSapId]->lpsId != 
                                                          IT_INVALID_PS_ID) &&
                         (itGlobalCb.nSap[cfg->nSapId]->lpsId != 
                                                          psCb->psCfg.psId))
                     {
#if (ERRCLASS & ERRCLS_INT_PAR)
                        ITLOGERROR(ERRCLS_INT_PAR, EIT393,
                                (ErrVal) cfg->nSapId,
                                "itAtVerifyRoutCfg: NSAP configured for another Local PS.");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
                        sta->status = LCM_PRIM_NOK;
                        sta->reason = LIT_REASON_NSAP_CFGED_LPS;
                        RETVALUE(RFAILED);
                     }
                  }
               } /* end of if Local PS */
            } /* end of if nodeType LIT_TYPE_ASP */
#endif /* ITASP && OG_RTE_ON_LPS_STA */

         }
         break;
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT394,
                    (ErrVal) cfg->rtType,
                    "itAtVerifyRoutCfg: invalid value for rtType");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
   }

   dpcLen         = itGlobalCb.nwk[cfg->nwkId]->nwkCfg.dpcLen;
   tmpDpcMaskTest = (dpcLen == DPC14) ? 0x3fff :
                    (dpcLen == DPC16) ? 0xffff : 0xffffff;

   /* it009.106 - Check added for LIT_DPC_SPECIFIED */
   if ((cfg->rtFilter.dpcMask > tmpDpcMaskTest) &&
       (cfg->rtFilter.dpcMask != LIT_DPC_SPECIFIED))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT395,
                 (ErrVal) cfg->rtFilter.dpcMask,
                 "itAtVerifyRoutCfg: dpcMask out of range");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }
   if (cfg->rtFilter.dpc > tmpDpcMaskTest)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT396,
                 (ErrVal) cfg->rtFilter.dpc,
                 "itAtVerifyRoutCfg: dpc out of range");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }
   if (cfg->rtFilter.opcMask > tmpDpcMaskTest)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT397,
                 (ErrVal) cfg->rtFilter.opcMask,
                 "itAtVerifyRoutCfg: opcMask out of range");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }
   if (cfg->rtFilter.opc > tmpDpcMaskTest)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT398,
                 (ErrVal) cfg->rtFilter.opc,
                 "itAtVerifyRoutCfg: opc out of range");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }
   
   switch (cfg->rtFilter.includeCic)
   {
      case TRUE:
         if (cfg->rtFilter.cicStart > cfg->rtFilter.cicEnd)
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            ITLOGERROR(ERRCLS_INT_PAR, EIT399,
                       (ErrVal) NULLD,
                       "ItAtVerifyRoutCfg: Invalid cic range");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
            sta->status = LCM_PRIM_NOK;
            sta->reason = LCM_REASON_INVALID_PAR_VAL;
            RETVALUE(RFAILED);
         }
         break;
      case FALSE:
         break;
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT400,
                    (ErrVal) cfg->rtFilter.includeCic,
                    "ItAtVerifyRoutCfg: Invalid includeCic value");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
   }

   switch (cfg->rtFilter.includeSsn)
   {
      /* following 2 cases fall through */
      case TRUE:
      case FALSE:
         break;
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT401,
                    (ErrVal) cfg->rtFilter.includeSsn,
                    "ItAtVerifyRoutCfg: Invalid includeSsn value");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
   }
   
   switch (cfg->rtFilter.includeTrid)
   {
      case TRUE:
         if (cfg->rtFilter.tridStart > cfg->rtFilter.tridEnd)
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            ITLOGERROR(ERRCLS_INT_PAR, EIT402,
                       (ErrVal) NULLD,
                       "ItAtVerifyRoutCfg: Invalid trid range");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
            sta->status = LCM_PRIM_NOK;
            sta->reason = LCM_REASON_INVALID_PAR_VAL;
            RETVALUE(RFAILED);
         }
         break;
      case FALSE:
         break;
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT403,
                    (ErrVal) cfg->rtFilter.includeTrid,
                    "ItAtVerifyRoutCfg: Invalid includeTrid value");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
   }

   slsLen = itGlobalCb.nwk[cfg->nwkId]->nwkCfg.slsLen;

   tmpSlsMaskTest = (U8)((slsLen == LIT_SLS4) ? IT_MAX_SLS4 : 
                         ((slsLen == LIT_SLS5) ? IT_MAX_SLS5 : IT_MAX_SLS8));
                      

   if (cfg->rtFilter.sls > tmpSlsMaskTest)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT404,
                 (ErrVal) cfg->rtFilter.sls,
                 "ItAtVerifyRoutCfg: Invalid sls value");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }
   if (cfg->rtFilter.slsMask > tmpSlsMaskTest)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT405,
                 (ErrVal) cfg->rtFilter.slsMask,
                 "ItAtVerifyRoutCfg: Invalid slsMask value");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }
   
   if (cfg->rtFilter.sio > IT_MAX_SIO)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT406,
                 (ErrVal) cfg->rtFilter.sio,
                 "ItAtVerifyRoutCfg: sio > 0x0f");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   if (cfg->rtFilter.sioMask > IT_MAX_SIO)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT407,
                 (ErrVal) cfg->rtFilter.sioMask,
                 "ItAtVerifyRoutCfg: sioMask > 0x0f");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   if ((cfg->noStatus != TRUE) && (cfg->noStatus != FALSE))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT408,
                 (ErrVal) cfg->noStatus,
                 "ItAtVerifyRoutCfg: Invalid noStatus value");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }
   
   /* Check for range type parameters  */
   if ((cfg->rtFilter.includeCic == TRUE) &&
           (cfg->rtFilter.cicStart > cfg->rtFilter.cicEnd))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT409,
                 (ErrVal) cfg->rtFilter.cicStart,
                 "ItAtVerifyRoutCfg: Invalid cic range value");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   if ((cfg->rtFilter.includeTrid == TRUE) &&
           (cfg->rtFilter.tridStart > cfg->rtFilter.tridEnd))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT410,
                 (ErrVal) cfg->rtFilter.tridStart,
                 "ItAtVerifyRoutCfg: Invalid trid range value");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   /* the check for duplicate route configuration is done in itAtCfgRout */
   /* check for noStatus mismatch is done in itAtCfgRout */
   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   
   RETVALUE(ROK);
} /* end of itAtVerifyRoutCfg */


/*
*
*       Fun:   itAtDelRout
*
*       Desc:  Called by LMI to delete a routing entry from the DPC
*              table or routing table.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtDelRout
(
ItCntrl    *cntrl,            /* control parameters */
CmStatus   *sta               /* return status */
)
#else
PUBLIC S16 itAtDelRout(cntrl, sta)
ItCntrl    *cntrl;            /* control parameters */   
CmStatus   *sta;              /* return status */        
#endif
{
   ItDpcCb    *prevEnt;                /* previous DPC CB */
   ItDpcCb    *dpcCb;                  /* current DPC CB */
   ItRouteCb  *curRouteCb;             /* current route CB */
   Bool       deletedRouteCb;          /* TRUE if route CB deleted */
   ItPsCb     *psCb = (ItPsCb *)NULLP; /* route owner */
   U8         nwkId;          /* network ID */
   Bool       matchNwk;       /* TRUE if matched by nwkId */
   Bool       matchDpc;       /* TRUE if matched by DPC */
   Bool       matchAll;       /* TRUE if delete all */
   U16        ret;            /* return value */
   Bool       matchRteCfg;    /* TRUE if matched by rteCfg */
   ItRouteCb  *testRouteCb;   /* test route CB */
   U32        tmpDpcMaskTest; /* temp DPC mask test */
   U16        dpcLen;         /* DPC length */
   Bool       dpcSpecified;   /* TRUE if DPC fully specified */
   CmLListCp  *list;          /* current route list */
   Bool       done;           /* TRUE when searching is completed */
   
   TRC2(itAtDelRout)

   ITDBGP(DBGMASK_MI|IT_DBGMASK_AT, (itGlobalCb.itInit.prntBuf,
                                     "itAtDelRout()\n"));

   matchNwk = FALSE;
   matchDpc = FALSE;
   matchRteCfg = FALSE;
   matchAll = FALSE;
   nwkId    = 0;
   psCb     = (ItPsCb *) NULLP;
   dpcCb    = (ItDpcCb *) NULLP;

   if (cntrl == (ItCntrl *)NULLP)
   {
      matchAll = TRUE;
   }
   else
   {
      if(cntrl->t.rtEnt.indexType != LIT_RTINDEX_ROUTECFG)
      {
         /* - Get nwkId from rtEnt.nwkId only other cases. 
                        matchRteCfg case will have nwkId in rteCfg 
                        which will not be packed in rtEnt.nwkId */         
         nwkId = cntrl->t.rtEnt.nwkId;
         if ((nwkId >= itGlobalCb.genCfg.maxNmbNwk) ||
             (itGlobalCb.nwk[nwkId] == (ItNwkCb *) NULLP))
         {
            sta->reason = LIT_REASON_INVALID_NWKID;
            RETVALUE(RFAILED);
         }
      }

      switch (cntrl->t.rtEnt.indexType)
      {
         case LIT_RTINDEX_PSID:
            /* Search hash list for Peer Server control block */
            if ((psCb = itPsmFindPs(cntrl->t.rtEnt.u.psId)) == (ItPsCb *) NULLP)
            {
               sta->reason = LIT_REASON_INVALID_PSID;
               RETVALUE(RFAILED);
            }
            break;

         case LIT_RTINDEX_NWKID:
            matchNwk = TRUE;
            break;

         case LIT_RTINDEX_ROUTECFG:
            matchRteCfg = TRUE;
            break;

         case LIT_RTINDEX_DPC:
            matchDpc = TRUE;
            break;

         default:
            sta->reason = LIT_REASON_INVALID_RTINDEX;
            RETVALUE(RFAILED);
            break;
            
      }
   }
   if (matchRteCfg)
   {

#if (ERRCLASS & ERRCLS_INT_PAR)
      if (itAtVerifyRoutCfg(&(cntrl->t.rtEnt.u.rteCfg), sta, TRUE) != ROK)
      {
         RETVALUE(RFAILED);
      }
#endif /* ERRCLS_INT_PAR */

      IT_ALLOC(sizeof(ItRouteCb), testRouteCb);
      cmMemcpy((U8 *) &(testRouteCb->rteCfg),
               (U8 *) &(cntrl->t.rtEnt.u.rteCfg), sizeof(ItRteCfg));

      dpcLen      = itGlobalCb.nwk[testRouteCb->rteCfg.nwkId]->nwkCfg.dpcLen;
      tmpDpcMaskTest = (dpcLen == DPC14) ? 0x3fff :
                       (dpcLen == DPC16) ? 0xffff : 0xffffff;

      done = FALSE;
      deletedRouteCb = FALSE;

      /* - There are three cases in two categories for 
                     particular routing entry deletion feature
 
         [1]. DPC specified: In this case, we expected the RCB is in dpcCb or 
                           it is the special case 'routing DPC'
 
          case [1.1] Routing DPC (dpcCb->routes = 0)
            In this case, there is no RCB in this DPC. The routing information
            will be in the dpcCb itself. If we found exact match in this case, 
            we will mark deletedRouteCb flag.

          case [1.2] Multiple RCB in dpcCb (dpcCb->routes > 0) 
            In this case, there are multiple RCB in this dpcCb. If we found 
            exact match in this case, we will delete the RCB and mark 
            deletedRouteCb flag.

          case [1.1] & [1.2] DPC CB post-processing
          =========================================
          After successful deletion from case 1.1 or 1.2, there are several 
          cases post-processing for the remaining DPC CB, based on its 
          dpcCb->routes.

          case [1a] #: dpcCb->routes = 0
            In this case, the dpcCb is not the 'routing DPC' anymore because 
            it will not be used for routing. We will delete the dpcCb.

          case [1b] #: dpcCb->routes = 1
            In this case, there is single RCB in the dpcCb. We will check 
            that we can convert it to routing DPC or not, if so we will 
            convert it to routing DPC (dpcCb->routes = 0), if not, we will 
            leave it as it is.

          case [1c] #: dpcCb->routes > 1
            No post-processing is required in this case.
         [2]. DPC not specified: In this case, we expected the RCB 
                                 in global translation table

         case [2]: In this case, we should search for exact match in global 
           translation table on the filter and other parameters. 
           Then, delete the route when it is exact match.

      */

      dpcSpecified = FALSE;
      /* it009.106 - The dpcMask can be set to LIT_DPC_SPECIFIED to specify a 
       * complete DPC for dpcLen of DPC14 and DPC16. Added check for same. */
      if ((testRouteCb->rteCfg.rtFilter.dpcMask == tmpDpcMaskTest) ||
          (testRouteCb->rteCfg.rtFilter.dpcMask == LIT_DPC_SPECIFIED))
      {
         dpcSpecified            = TRUE;
         testRouteCb->rteCfg.rtFilter.dpcMask   = LIT_DPC_SPECIFIED;
      }

      if (dpcSpecified)
      {
         if (itAtGetDpc(testRouteCb->rteCfg.nwkId, 
                       testRouteCb->rteCfg.rtFilter.dpc, &dpcCb) == ROK)
         {
            list = &dpcCb->routes;
            if (cmLListLen(&dpcCb->routes) == 0)
            {
               /* case [1.1] routing DPC */
               if ((dpcCb->type == IT_RTTYPE2DPC(testRouteCb->rteCfg.rtType)) &&
                   (testRouteCb->rteCfg.rtFilter.opcMask == 0) &&
                   (testRouteCb->rteCfg.rtFilter.slsMask == 0) &&
                   (testRouteCb->rteCfg.rtFilter.sioMask == 0) &&
                   (testRouteCb->rteCfg.rtFilter.includeCic == FALSE) &&
                   (testRouteCb->rteCfg.rtFilter.includeSsn == FALSE) &&
                   (testRouteCb->rteCfg.rtFilter.includeTrid == FALSE))
               {
                  /* Verify PS if rtType is LIT_RTTYPE_PS */
                  if ((testRouteCb->rteCfg.rtType == LIT_RTTYPE_PS) &&
                     ((psCb = itPsmFindPs(testRouteCb->rteCfg.psId)) != 
                      (ItPsCb *) NULLP))
                  {
                     if ((dpcCb->owner == psCb) &&
                         (dpcCb->noStatus == testRouteCb->rteCfg.noStatus) &&
                         (psCb->spmc == dpcCb))
                     {
                        /* PS matched, delete the route */
                        deletedRouteCb = TRUE;
                     }
                     else
                     {
                        /* not match, prepare to fail */
                        /* deletedRouteCb is already FALSE from initialization */
                        sta->reason = LIT_REASON_INVALID_PSID;
                     }
                  }

                  /* Verify nSapIdPres */
                  if (testRouteCb->rteCfg.nSapIdPres == TRUE)
                  {
                     /* TRUE :  nSap must be matched */
                     if ((dpcCb->nSap != (ItNSapCb *) NULLP) && 
                         (dpcCb->nSap == itGlobalCb.nSap[testRouteCb->rteCfg.nSapId]))
                     {
                        /* nSap match, delete the route */
                        deletedRouteCb = TRUE;
                     }
                     else
                     {
                        /* nSap not match, do nothing & prepare to fail */
                        sta->reason = LIT_REASON_UNMATCH_NSAP;
                        deletedRouteCb = FALSE;
                     }
                  }
                  else
                  {
                     /* FALSE :  nSap must be NULLP */ 
                           if (dpcCb->nSap == (ItNSapCb *) NULLP)
                     {
                        /* nSap is NULLD, delete the route */
                        deletedRouteCb = TRUE;
                     }
                     else
                     {
                        /* nSap is not NULLD, do nothing & prepare to fail */
                        sta->reason = LIT_REASON_UNMATCH_NSAP;
                        deletedRouteCb = FALSE;
                     }
                  }
               }
               /* - There's no need to search matching filter 
                              in case [1.1], but the deleting route 
                              should match by now if LM specify
                              every parameter correctly */
               if (!deletedRouteCb)
               {
                  IT_FREE(sizeof(ItRouteCb), testRouteCb);
                  RETVALUE(RFAILED);
               }
               else
               {
                  itGlobalCb.addrTrn.atSta.nmbRout--;
               }

               done = TRUE;
            } /* end if Case [1.1] */
         }
         else
         {
            /* Can't get DPC that specified */
            IT_FREE(sizeof(ItRouteCb), testRouteCb);
            sta->status = LCM_PRIM_OK;
            sta->reason = LCM_REASON_NOT_APPL;
            RETVALUE(ROK);
         }
      } /* end of case [1] */
      else
      {
         /* Case [2] DPC is not specified */
         /* Use global list if DPC is not specified */
         list = &itGlobalCb.addrTrn.rtList;
      }

      /* - Perform search and delete in route list 
                     Search only case [1.2] and [2] because
                     case [1.1] is done above */

      /* Init list to first element */
      cmLListFirst(list);

      (Void) itAtCreatertFilter(testRouteCb);

   
      while (cmLListCrnt(list) && (done == FALSE))
      {
         curRouteCb = (ItRouteCb *)cmLListCrnt(list);
         if ((testRouteCb->rtMask[0] == curRouteCb->rtMask[0]) && 
             (testRouteCb->rtMask[1] == curRouteCb->rtMask[1]))
         {
            /* rtMask matched, verify the whole filter for exact match */ 
            Bool identical = TRUE;
            if (testRouteCb->rteCfg.nwkId != curRouteCb->rteCfg.nwkId)
            {
                     /* differenet network, we will look at the next one */
               identical = FALSE;
            }
            else
            {
               /* rtMask are all matched, verify the match from filters */
               ItRtFilter *rt1;  /* temp route filter 1 */
               ItRtFilter *rt2;  /* temp route filter 2 */
               rt1 = &curRouteCb->rteCfg.rtFilter;
               rt2 = &testRouteCb->rteCfg.rtFilter;
               if (((rt1->dpc & rt1->dpcMask) != (rt2->dpc & rt2->dpcMask)) ||
                     ((rt1->opc & rt1->opcMask) != (rt2->opc & rt2->opcMask)))
               {
                  identical = FALSE;
               }
               else if (((rt1->sls & rt1->slsMask) != 
                               (rt2->sls & rt2->slsMask)) ||
                        ((rt1->sio & rt1->sioMask) != 
                                (rt2->sio & rt2->sioMask)))
               {
                  identical = FALSE;
               }
               else if ((rt1->includeCic != rt2->includeCic) ||
                        (rt1->includeSsn != rt2->includeSsn) ||
                        (rt1->includeTrid != rt2->includeTrid))
               {
                  identical = FALSE;
               }
               else 
               {                  
                  if (rt1->includeCic == TRUE)
                  {
                            if (!((rt1->cicStart == rt2->cicStart) &&
                           (rt1->cicEnd == rt2->cicEnd)))
                     {
                        identical = FALSE;
                     }
                  }                  
                  if (rt1->includeSsn == TRUE)
                  {
                     if (rt1->ssn != rt2->ssn)
                     {
                        identical = FALSE;
                     }
                  }
                  if (rt1->includeTrid == TRUE)
                  {
                            if (!((rt1->tridStart == rt2->tridStart) && 
                           (rt1->tridEnd == rt2->tridEnd)))
                     {
                        identical = FALSE;
                     }
                  }
               }
            }
            if (identical == TRUE)
            {
               done = TRUE;
 
               deletedRouteCb = FALSE;

               /* Verify for exact match */
               if (testRouteCb->rteCfg.rtType != curRouteCb->rteCfg.rtType)
               {
                  /* rtType not match, do nothing & prepare to fail */
                  sta->reason = LIT_REASON_UNMATCH_RTTYPE;
               }
               else
               {
                  /* Verify parameter on rtType basis */
                  switch (curRouteCb->rteCfg.rtType)
                  {
                     case LIT_RTTYPE_PS:
                        if(testRouteCb->rteCfg.psId == curRouteCb->rteCfg.psId)
                        {
                           /* psId match, prepare to delete */
                           deletedRouteCb = TRUE;
                        }

                        if (dpcSpecified)
                        {
                           if (testRouteCb->rteCfg.noStatus != 
                                curRouteCb->rteCfg.noStatus)
                           {
                              /* noStatus not match, do nothing & prepare to fail */
                              sta->reason = LIT_REASON_UNMATCH_NOSTATUS;
                              deletedRouteCb = FALSE;
                              break;
                           }
                        }                  
                        /* no break, fall through */

                      case LIT_RTTYPE_LOCAL:
                      case LIT_RTTYPE_MTP3:
                         if(testRouteCb->rteCfg.nSapIdPres == 
                            curRouteCb->rteCfg.nSapIdPres)
                               {
                            if (testRouteCb->rteCfg.nSapIdPres)
                            {
                               if(testRouteCb->rteCfg.nSapId == 
                                  curRouteCb->rteCfg.nSapId)
                               {
                                  /* nSap match, prepare to delete */
                                  deletedRouteCb = TRUE;
                               }
                               else
                               {
                                  /* nSap not match, prepare to fail */
                                  sta->reason = LIT_REASON_UNMATCH_NSAP;
                                  deletedRouteCb = FALSE;
                               }
                            }
                            else
                            {
                                /* nSap match, prepare to delete */
                               deletedRouteCb = TRUE;
                            }
                         }
                         else
                         {
                            /* nSap not match, prepare to fail */
                            sta->reason = LIT_REASON_UNMATCH_NSAP;
                            deletedRouteCb = FALSE;
                         }  
                         break;
                  }
               }

               /* if matching found, we delete the RCB now */
               if (deletedRouteCb)
               {
                  if (dpcSpecified)
                  {
                           /* case [1.2] - Deleting route is at the dpcCb */ 
                     CmLList *tmp = cmLListPrev(&dpcCb->routes);
                     /* delist and delete RCB */
                     cmLListDelFrm(&dpcCb->routes, &curRouteCb->node);
                     cmLListCrnt(&dpcCb->routes) = tmp;
                     IT_FREE(sizeof(ItRouteCb), curRouteCb);
                     itGlobalCb.addrTrn.atSta.nmbRout--;                  
                  }
                  else
                  {
                           /* case [2] - Deleting route is at the global translation table */ 
                     CmLList *tmp = cmLListPrev(&itGlobalCb.addrTrn.rtList);
                     /* delist and delete RCB */
                     cmLListDelFrm(&itGlobalCb.addrTrn.rtList, 
                                         &curRouteCb->node);
                     cmLListCrnt(&itGlobalCb.addrTrn.rtList) = tmp;
                     IT_FREE(sizeof(ItRouteCb), curRouteCb);
                     itGlobalCb.addrTrn.atSta.nmbRout--;                  
                  }
               } /* end of if deletedRouteCb = TRUE */
            } /* end if rtFilter are identical */
         } /* end if matching rtMask */

         if (done == FALSE)
         {
            cmLListNext(list);
         }
      } /* end while */

      IT_FREE(sizeof(ItRouteCb), testRouteCb);

      if (!deletedRouteCb)
      {
         sta->status = LCM_PRIM_OK;
         sta->reason = LCM_REASON_NOT_APPL;
         RETVALUE(ROK);
      }

      if (dpcSpecified)
      {
         /* Get PS CB and mark its SPMC field to NULL so that other route
          * may be created for this PS in future */
         /* This leg is hit only if the route is deleted successfully. So 
          * the SPMC of the PS should also be made null as we can have only
               * one route per PS */
         psCb = itPsmFindPs(cntrl->t.rtEnt.u.rteCfg.psId);
         if (psCb != (ItPsCb *) NULLP)
         {
            if (psCb->spmc == dpcCb)
            {
               psCb->spmc = (ItDpcCb *) NULLP;
                 }
         }
         if (cmLListLen(&(dpcCb->routes)) == 0)
         {
            /* case [1a] */
            /* this wasn't a routing DPC, so it's now redundant */ 
            /* delist and delete DPC CB */
            itTcStopTimer(&dpcCb->tmrPoll);
            itTcStopTimer(&dpcCb->tmrDaud);
            cmHashListDelete(&itGlobalCb.addrTrn.dpcList,
                              (PTR) dpcCb);
            IT_FREE(sizeof(ItDpcCb), dpcCb);
          
         }
         else if (cmLListLen(&dpcCb->routes) == 1)
         {
            /* case [1b] */
            /* check if we can convert to routing DPC CB */
            curRouteCb = (ItRouteCb *)cmLListFirst(&dpcCb->routes);
            if ((curRouteCb->rteCfg.rtFilter.opcMask == 0) &&
                (curRouteCb->rteCfg.rtFilter.slsMask == 0) &&
                (curRouteCb->rteCfg.rtFilter.sioMask == 0) &&
                (curRouteCb->rteCfg.rtFilter.includeCic == FALSE) &&
                (curRouteCb->rteCfg.rtFilter.includeSsn == FALSE) &&
                (curRouteCb->rteCfg.rtFilter.includeTrid == FALSE))
            {
               /* DPC-only route, clone back to a standalone routing DPC CB */
               dpcCb->type    = IT_RTTYPE2DPC(curRouteCb->rteCfg.rtType);
               dpcCb->owner   = curRouteCb->owner;
               if (curRouteCb->rteCfg.nSapIdPres == TRUE)
               {
                  dpcCb->nSap = itGlobalCb.nSap[curRouteCb->rteCfg.nSapId];
               }
               else
               {
                  dpcCb->nSap = (ItNSapCb *) NULLP;
               }
               if (dpcCb->type == IT_DPCCB_SPMC)
               {
                  dpcCb->noStatus = curRouteCb->rteCfg.noStatus;
               }
               /* delist and delete cloned RCB */
               cmLListDelFrm(&dpcCb->routes, &curRouteCb->node);
               IT_FREE(sizeof(ItRouteCb), curRouteCb);
            }
         }

         if (dpcCb != NULLP)
         {
            /* if the DPC CB still exists, recalculate its state */
            if ((ret = itMifCalcDpcStatus(dpcCb, IT_MIF_PC_CHANGED, 0)) != ROK)
            {
               RETVALUE(ret);
            }
         }
      } /* end post-processing of case [1] */

      (Void) cmHashListQuery(&itGlobalCb.addrTrn.dpcList,
                          CM_HASH_QUERYTYPE_ENTRIES, 
                          &itGlobalCb.addrTrn.atSta.nmbDpc);
   
      sta->status = LCM_PRIM_OK;
      sta->reason = LCM_REASON_NOT_APPL;

      RETVALUE(ROK);

   } /* end matchRteCfg processing */


   prevEnt = (ItDpcCb *) NULLP;
   while (cmHashListGetNext(&itGlobalCb.addrTrn.dpcList,
                            (PTR) prevEnt, (PTR *) &dpcCb) ==  ROK)
   {
      if (matchAll == TRUE || (nwkId == dpcCb->nwk->nwkCfg.nwkId))
      {
         deletedRouteCb = FALSE;
         /* search cluster chain for matches */
         for (curRouteCb = (ItRouteCb *)cmLListFirst(&dpcCb->routes); 
              curRouteCb;
              curRouteCb = (ItRouteCb *)cmLListNext(&dpcCb->routes))
         {
            Bool delFlag = FALSE;
            if ((matchAll == TRUE) || (matchNwk == TRUE))
            {
               delFlag = TRUE;
            }
            else if (matchDpc == TRUE)
            {
               if (dpcCb->dpc == cntrl->t.rtEnt.u.dpc)
               {
                  delFlag = TRUE;
               }
            }
            else if (curRouteCb->owner == psCb)
            {
               delFlag = TRUE;
            }
            if (delFlag == TRUE)
            {
               CmLList *tmp = cmLListPrev(&dpcCb->routes);
               /* delist and delete RCB */
               cmLListDelFrm(&dpcCb->routes, &curRouteCb->node);
               IT_FREE(sizeof(ItRouteCb), curRouteCb);
               itGlobalCb.addrTrn.atSta.nmbRout--;
               deletedRouteCb = TRUE;
               cmLListCrnt(&dpcCb->routes) = tmp;
            }
         }
         if (cmLListLen(&dpcCb->routes) == 0)
         {
            Bool delFlag = FALSE;
            if ((matchAll == TRUE) || (matchNwk == TRUE))
            {
               delFlag = TRUE;
            }
            else if (matchDpc == TRUE)
            {
               if (dpcCb->dpc == cntrl->t.rtEnt.u.dpc)
               {
                  delFlag = TRUE;
               }
            }
            else if (dpcCb->owner == psCb)
            {
               delFlag = TRUE;
            }
            else if (deletedRouteCb == TRUE)
            {
               /* this wasn't a routing DPC, so it's now redundant */ 
               delFlag = TRUE;
            }
            if (delFlag == TRUE)
            {
               if (psCb != (ItPsCb *) NULLP)
               {
                  if (psCb->spmc == dpcCb)
                  {
                     psCb->spmc = (ItDpcCb *) NULLP;
                  }
               }
               /* to take care for clearing up of
                * spmcs fields of all the PS of which this DPC 
                * was a part */ 
                
               /* If all the route are being deleted from the DPC then
                * there may be route which belong to the same DPC but
                * point to a different PS. In this case Multiple PS 
                * may be having the same point code as thier SPMC */
               if ((matchDpc == TRUE) || (matchNwk == TRUE))
               {
                  ItPsCb *prevPsEnt;     

                  prevPsEnt = (ItPsCb *) NULLP;
                  while (cmHashListGetNext(&itGlobalCb.ps, (PTR) prevPsEnt, 
                                                     (PTR *) &psCb) ==  ROK)
                  {
                     if (psCb != (ItPsCb *) NULLP)
                     {
                        if (psCb->spmc == dpcCb)
                        {
                           psCb->spmc = (ItDpcCb *) NULLP;
                        }
                     }
                     prevPsEnt = psCb;
                  } /* end while */
               }
               itTcStopTimer(&dpcCb->tmrPoll);
               itTcStopTimer(&dpcCb->tmrDaud);
               /* delist and delete DPC CB */
               cmHashListDelete(&itGlobalCb.addrTrn.dpcList,
                                (PTR) dpcCb);
               IT_FREE(sizeof(ItDpcCb), dpcCb);
               dpcCb = prevEnt;

               /* it013.106 - If deletedRouteCb is not TRUE, it means that 
                * DPC route list was empty. And since this DPC is being deleted
                * now, decrement the nmbRout. 
                * If deletedRouteCb is TRUE, this means that all the routes in 
                * DPC route list are deleted including the first cloned route, 
                * so nmbRout is already decremented. */
               if (deletedRouteCb != TRUE)
               {
                  itGlobalCb.addrTrn.atSta.nmbRout--;
               }
            }
         }
         else if ((deletedRouteCb == TRUE) && (cmLListLen(&dpcCb->routes) == 1))
         {
            /* Won't happen in the matchAll case */
            /* check if we can convert to routing DPC CB */
            curRouteCb = (ItRouteCb *)cmLListFirst(&dpcCb->routes);
            if ((curRouteCb->rteCfg.rtFilter.opcMask == 0) &&
                (curRouteCb->rteCfg.rtFilter.slsMask == 0) &&
                (curRouteCb->rteCfg.rtFilter.sioMask == 0) &&
                (curRouteCb->rteCfg.rtFilter.includeCic == FALSE) &&
                (curRouteCb->rteCfg.rtFilter.includeSsn == FALSE) &&
                (curRouteCb->rteCfg.rtFilter.includeTrid == FALSE))
            {
               /* DPC-only route, clone back to a standalone routing DPC CB */
               dpcCb->type    = IT_RTTYPE2DPC(curRouteCb->rteCfg.rtType);
               dpcCb->owner   = curRouteCb->owner;
               if (curRouteCb->rteCfg.nSapIdPres == TRUE)
               {
                  dpcCb->nSap = itGlobalCb.nSap[curRouteCb->rteCfg.nSapId];
               }
               else
               {
                  dpcCb->nSap = (ItNSapCb *) NULLP;
               }
               if (dpcCb->type == IT_DPCCB_SPMC)
               {
                  dpcCb->noStatus = curRouteCb->rteCfg.noStatus;
               }
               /* delist and delete cloned RCB */
               cmLListDelFrm(&dpcCb->routes, &curRouteCb->node);
               IT_FREE(sizeof(ItRouteCb), curRouteCb);
               /* don't decrement number of routes - we have a clone */
            }
         }
      }
      if (dpcCb != prevEnt)
      {
         /* if the DPC CB still exists, recalculate its state */
         if ((ret = itMifCalcDpcStatus(dpcCb, IT_MIF_PC_CHANGED, 0)) != ROK)
         {
            RETVALUE(ret);
         }
         prevEnt = dpcCb;
      }
   }

   if ((matchAll == TRUE) || (matchDpc == FALSE))
   {
      /* search global route list for PS matches */
      for (curRouteCb = (ItRouteCb *)cmLListFirst(&itGlobalCb.addrTrn.rtList); 
           curRouteCb;
           curRouteCb = (ItRouteCb *)cmLListNext(&itGlobalCb.addrTrn.rtList))
      {
         if ((matchAll == TRUE) || 
             ((matchDpc == FALSE) && (curRouteCb->owner == psCb) 
                                  && (curRouteCb->owner != (ItPsCb *)NULLP)) ||
             ((matchNwk == TRUE)  && (curRouteCb->rteCfg.nwkId == nwkId)))
         {
            CmLList *tmp = cmLListPrev(&itGlobalCb.addrTrn.rtList);
            /* delist and delete RCB */
            cmLListDelFrm(&itGlobalCb.addrTrn.rtList, &curRouteCb->node);
            IT_FREE(sizeof(ItRouteCb), curRouteCb);
            itGlobalCb.addrTrn.atSta.nmbRout--;
            cmLListCrnt(&itGlobalCb.addrTrn.rtList) = tmp;
         }
      }
   }
   
   (Void) cmHashListQuery(&itGlobalCb.addrTrn.dpcList,
                          CM_HASH_QUERYTYPE_ENTRIES, 
                          &itGlobalCb.addrTrn.atSta.nmbDpc);
   
   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   RETVALUE(ROK);
} /* end of itAtDelRout */


/*
*
*       Fun:   itAtAddDpc
*
*       Desc:  Called by AT/MIF when information becomes available regarding
*              a previously unknown DPC. Adds new DPC CB to the hash list
*
*       Ret:
*
*       Notes: None
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtAddDpc
(
U8       nwkId,               /* Network context ID */
Dpc      dpc,                 /* Destination point code */
ItDpcCb  **dpcCbPtr,          /* DPC control block */
U8       dpcType              /* type of DPC */
)
#else
PUBLIC S16 itAtAddDpc(nwkId, dpc, dpcCbPtr, dpcType)
U8       nwkId;               /* Network context ID */
Dpc      dpc;                 /* Destination point code */
ItDpcCb  **dpcCbPtr;          /* DPC control block */
U8       dpcType;             /* type of DPC */
#endif
{
   ItDpcCb     *dpcCb;        /* DPC control block */
   S16         ret;           /* return value */
   UConnId     assocId;       /* Assoc ID */

   TRC2(itAtAddDpc)

   /* create new DPC CB */
   IT_ALLOC(sizeof(ItDpcCb), dpcCb);

   *dpcCbPtr = dpcCb;

   if (dpcCb == (ItDpcCb *) NULLP)
   {
      RETVALUE(ROUTRES);
   }

   dpcCb->dpc        = dpc;
   dpcCb->nwk        = itGlobalCb.nwk[nwkId];
   dpcCb->type       = dpcType;
   dpcCb->noStatus   = FALSE;
   dpcCb->nSap       = (ItNSapCb *) NULLP;
   /* Initialize DPC state to be unavailable */
   dpcCb->dpcSt      = IT_DPC_UNKNOWN;
   cmLListInit(&dpcCb->routes);
   IT_INITTIMER(&dpcCb->tmrPoll);
   IT_INITTIMER(&dpcCb->tmrDaud);

   /* Initialize DPC per-PSP context */
   for (assocId = 0; assocId < itGlobalCb.maxNmbAssoc; assocId++)
   {
      dpcCb->pspDpcSt[assocId]     = IT_DPC_AVAILABLE;
      dpcCb->pspDpcCong[assocId]   = SN_PRI0;
   }

   dpcCb->hlKey = ((U32) nwkId << 24) | ((U32) dpc);
   /* add to hash list */
   if ((ret = cmHashListInsert(&itGlobalCb.addrTrn.dpcList, (PTR) dpcCb,
      (U8 *)&dpcCb->hlKey, sizeof(dpcCb->hlKey))) != ROK)
   {
      IT_FREE(sizeof(ItDpcCb), dpcCb);
      RETVALUE(ret);
   }

   (Void) cmHashListQuery(&itGlobalCb.addrTrn.dpcList,
                          CM_HASH_QUERYTYPE_ENTRIES, 
                          &itGlobalCb.addrTrn.atSta.nmbDpc);
   
   RETVALUE(ROK);
} /* end of itAtAddDpc */


/*
*
*       Fun:   itAtTranslate
*
*       Desc:  Called by MUP to translate SS7 routing information.
*              Translation is initially based on a simple DPC hash
*              table lookup, proceeds to a linear search of 
*              the DPC cluster chain and finally to a search of the global
*              route table.
*
*       Ret:   Failure:           RNA
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtTranslate
(
ItMupMsg *msg                 /* MUP message */
)
#else
PUBLIC S16 itAtTranslate(msg)
ItMupMsg *msg;                /* MUP message */
#endif
{
   ItDpcCb      *dpcCb;       /* DPC control block */
   Bool         done;         /* TRUE when done */

   TRC2(itAtTranslate)
   ITDBGP(DBGMASK_MI|IT_DBGMASK_AT|IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf,
          "itAtTranslate()\n"));

   done = FALSE;
   /* search DPC hash list for a match */
   if (itAtGetDpc(msg->nwkId, msg->dpc, &dpcCb) == ROK)
   {
      if (dpcCb->type != IT_DPCCB_NONROUTE)
      {
         if (cmLListLen(&dpcCb->routes) == 0)
         {
            /* Routing DPC CB - we have a match */
            msg->dpcCb     = dpcCb;
            msg->routeTgt1 = dpcCb->owner;
            msg->nSap      = dpcCb->nSap;
            msg->routeType = IT_DPC2RTTYPE(dpcCb->type);
            msg->msgState  = IT_MSG_ROUTED_ONE;
            done           = TRUE;
         }
         else
         {
            /* search DPC cluster chain for an exact match */
            if (itAtSearch(msg, &dpcCb->routes) == ROK)
            {
               msg->dpcCb  = dpcCb;
               done        = TRUE;
            }
         }
#ifdef ITASP
         if ((msg->dir == IT_MSG_DOWN) && (done == FALSE) && 
             (itGlobalCb.genCfg.nodeType == LIT_TYPE_ASP))
         {
            if (dpcCb->dpcSt == IT_DPC_AVAILABLE)
            {
               /* Dpc is available but route corresponding to msg is not 
                  found, send UPU to the message originating NSAP */
                   if (msg->nSap->sntSta.hlSt == LIT_SAP_BOUND)
                   {
      /* Note: we do not need to Queue this UPU status ind to m3ua user because
              this function returns from here and its calling function itMupData
              also returns to ItUiSntUDatReq function after sending an status
              indication to LM */
                       (Void) ItUiSntStaInd(&msg->nSap->pst,
                                      msg->nSap->sntSta.remSapId, msg->dpc, 
                                      SN_RMTUSRUNAV, (Priority)0);
                       done = TRUE;
                   }
            }
         }
#endif
      }
      else
      {
         /* 
          * MIF can use this DPC for interworking, but it's no use
          * for routing, so we will look in the global list 
          */
         msg->dpcCb = dpcCb;
      }
   }

   if (done == FALSE)
   {
      /* search global address list for a match */
      if (itAtSearch(msg, &itGlobalCb.addrTrn.rtList) == ROK)
      {
         done = TRUE;
      }
   }

#ifdef ITSG
   /* On SGP, we have a last resort for upward messages: route to MTP3 */
   if ((itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP) && 
       (msg->dir == IT_MSG_UP) && (done == FALSE))
   {
      msg->routeTgt1 = (ItPsCb *) NULLP;
      msg->nSap      = (ItNSapCb *) NULLP;
      msg->routeType = LIT_RTTYPE_MTP3;
      msg->msgState  = IT_MSG_ROUTED_ONE;
      done = TRUE;
   }
#endif /* ITSG */
   
   if (done == FALSE)
   {
      /* No route found */
      msg->routeTgt1 = (ItPsCb *) NULLP;
      msg->nSap      = (ItNSapCb *) NULLP;
      msg->routeType = LIT_RTTYPE_NOTFOUND;
      msg->msgState  = IT_MSG_REJECTED;
      RETVALUE(RNA);
   }

   RETVALUE(ROK);
} /* end of itAtTranslate */


/*
*
*       Fun:   itAtGetDpc
*
*       Desc:  This function is called by MIF to get the DPC CB
*              for a given network context and DPC.
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtGetDpc
(
U8       nwkId,               /* network ID */
Dpc      dpc,                 /* DPC value */
ItDpcCb  **dpcCb              /* DPC control block */
)
#else
PUBLIC S16 itAtGetDpc(nwkId, dpc, dpcCb)
U8       nwkId;               /* network ID */       
Dpc      dpc;                 /* DPC value */        
ItDpcCb  **dpcCb;             /* DPC control block */
#endif
{
   U32      tmphlKey;         /* temporary hash list key */
   ItDpcCb  *tmpDpcCb;        /* temporary DPC CB */

   TRC2(itAtGetDpc)
#ifdef BIT_64
   ITDBGP(DBGMASK_MI|IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf,
            "itAtGetDpc(nwkId: (%d), dpc (%d), **dpcCb)\n", nwkId, dpc));
#else
   ITDBGP(DBGMASK_MI|IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf,
            "itAtGetDpc(nwkId: (%d), dpc (%ld), **dpcCb)\n", nwkId, dpc));
#endif
   /* create key to search HL by concatenating nwkId and Dpc */
   tmphlKey = ((U32) nwkId << 24) | dpc;

   if (cmHashListFind(&itGlobalCb.addrTrn.dpcList, (U8 *) &tmphlKey,
                      sizeof(tmphlKey), 0, (PTR *) &tmpDpcCb) == ROK)
   {
      /* if hash key found */
      /* set *dpcCb to the DPC CB */
      *dpcCb = tmpDpcCb;
      RETVALUE(ROK);
   }
   else
   {
      /* hash key not found */
      *dpcCb = (ItDpcCb *) NULLP;
      RETVALUE(RFAILED);
   } /* end if (cmHashListFind) */
} /* end of itAtGetDpc */


/*
*
*       Fun:   itAtGetDpcs
*
*       Desc:  This function is called by MIF to get multiple DPC CBs
*              for a given network context and wildcard DPC.
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtGetDpcs
(
U8       nwkId,               /* network ID */
Dpc      dpc,                 /* DPC key */
Dpc      dpcMask,             /* DPC mask */
ItDpcCb  **dpcCb              /* returned DPC CB */
)
#else
PUBLIC S16 itAtGetDpcs(nwkId, dpc, dpcMask, dpcCb)
U8       nwkId;               /* network ID */
Dpc      dpc;                 /* DPC key */
Dpc      dpcMask;             /* DPC mask */
ItDpcCb  **dpcCb;             /* returned DPC CB */
#endif
{
   ItDpcCb *tmpDpcCb;         /* temporary DPC CB */

   TRC2(itAtGetDpcs)
#ifdef BIT_64
   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf, 
            "itAtGetDpcs(dpc(%d), dpcMask(%d))\n",dpc, dpcMask));
#else
   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf, 
            "itAtGetDpcs(dpc(%ld), dpcMask(%ld))\n",dpc, dpcMask));
#endif
   while (cmHashListGetNext(&itGlobalCb.addrTrn.dpcList, (PTR) *dpcCb, 
          (PTR *) &tmpDpcCb) == ROK)
   {
      *dpcCb = tmpDpcCb;
      if (((tmpDpcCb->dpc & dpcMask) == (dpc & dpcMask)) && 
          tmpDpcCb->nwk->nwkCfg.nwkId == nwkId)
      {
         RETVALUE(ROK);
      }
   }

   *dpcCb = (ItDpcCb *) NULLP;
   RETVALUE(RNA);
} /* end of itAtGetDpcs */


/*
*
*       Fun:   itAtSearch
*
*       Desc:  Search a DPC cluster chain or the global list
*              for a match with the message routing key
*
*       Ret:   Failure:   RFAILED
*              Not found: ROKDNA
*              Success:   ROK
*
*       Notes: <none>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtSearch
(
ItMupMsg    *msg,             /* MUP message */
CmLListCp   *list             /* route list to search */
)
#else
PUBLIC S16 itAtSearch(msg, list)
ItMupMsg    *msg;             /* MUP message */          
CmLListCp   *list;            /* route list to search */ 
#endif
{
   ItRouteCb   *curRouteCb;   /* current route CB */
   U32         tmpfilter1;    /* temp filter MSBs */
   U32         tmpfilter2;    /* temp filter LSBs */
   Bool        haveCic;       /* TRUE if have CIC */
   Bool        haveSsn;       /* TRUE if have SSN */
   Bool        haveTrid;      /* TRUE if have TRID */
   Bool        match;         /* TRUE if matched */
   Cic         cic;           /* CIC value */
   Ssn         ssn;           /* SSN value */
   Trid        trid;          /* TRID value */

   TRC2(itAtSearch)

   ITDBGP(DBGMASK_MI|IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf,
            "itAtSearch()\n"));
   
   haveCic  = FALSE;
   haveSsn  = FALSE;
   haveTrid = FALSE;
   match    = FALSE;
   cic      = 0;
   ssn      = 0;
   trid     = 0;

   tmpfilter1 = (
      ((U32) msg->nwkId << 26) |
      ((U32) msg->dpc << 2) |
      ((U32) msg->opc >> 22));
   tmpfilter2 = (
      ((U32) msg->opc << 10) |
      ((U32) (msg->lnkSel & 0x3F) << 4) |
      ((U32) (msg->srvInfo & 0x0F)));
   
   /* search list for matches */
   for (curRouteCb = (ItRouteCb *)cmLListFirst(list); 
        curRouteCb;
        curRouteCb = (ItRouteCb *)cmLListNext(list))
   {
      match = FALSE;
      if ((tmpfilter1 & curRouteCb->rtMask[0]) == curRouteCb->rtFilter[0])
      {
         if ((tmpfilter2 & curRouteCb->rtMask[1]) == curRouteCb->rtFilter[1])
         {
            match = TRUE;
            if (curRouteCb->rteCfg.rtFilter.includeCic == TRUE)
            {

               int servInfo;
               servInfo = IT_SRVIND(msg->srvInfo);
               if ((servInfo == SI_ISUP)|| (servInfo == SI_TUP))
               {
                  if (haveCic == FALSE)
                  {
                     itMupGetUserInfo(msg, IT_USER_GEN);
                     if (msg->userInfoLen == 2)
                     {
                        cic      = PutLoByte(cic, msg->userInfo[0]);
                        cic      = PutHiByte(cic, msg->userInfo[1]);
                        haveCic  = TRUE;
                     }
                  }
                  if ((haveCic == FALSE) ||
                      (cic < curRouteCb->rteCfg.rtFilter.cicStart) ||
                      (cic > curRouteCb->rteCfg.rtFilter.cicEnd))
                  {
                     match = FALSE;
                  }
               }
               else
               {
                  match = FALSE;
               }
            }
            if (curRouteCb->rteCfg.rtFilter.includeSsn == TRUE)
            {
               if (IT_SRVIND(msg->srvInfo) == SI_SCCP)
               {
                  if (haveSsn == FALSE)
                  {
                     itMupGetUserInfo(msg, IT_USER_GEN);
                     if (msg->userInfoLen == 1)
                     {
                        ssn      = msg->userInfo[0];
                        haveSsn  = TRUE;
                     }
                  }
                  if ((haveSsn == FALSE) || 
                      (ssn != curRouteCb->rteCfg.rtFilter.ssn))
                  {
                     match = FALSE;
                  }
               }
               else
               {
                  match = FALSE;
               }
            }
            if (curRouteCb->rteCfg.rtFilter.includeTrid == TRUE)
            {
               if (IT_SRVIND(msg->srvInfo) == SI_SCCP)
               {
                  if (haveTrid == FALSE)
                  {
                     itMupGetUserInfo(msg, IT_USER_TCAP);
                     if (msg->userInfoLen > 1)
                     {
                        U16 i;   /* loop index */
                        ssn      = msg->userInfo[0];
                        haveSsn  = TRUE;
                        /* highest order octet presented first */
                        trid = 0;
                        /* shift in the bytes */
                        for (i = 1; i < msg->userInfoLen; i++)
                        {
                           trid = (trid << 8) | ((U32) msg->userInfo[i]);
                        }
                        haveTrid = TRUE;
                     }
                     if ((haveTrid == FALSE) || 
                         (trid < curRouteCb->rteCfg.rtFilter.tridStart) ||
                         (trid > curRouteCb->rteCfg.rtFilter.tridEnd))
                     {
                        match = FALSE;
                     }
                  }
               }
               else
               {
                  match = FALSE;
               }
            }
         }
      }
      if (match == TRUE)
      {
         msg->routeTgt1 = curRouteCb->owner;
         msg->routeType = curRouteCb->rteCfg.rtType;
         if (curRouteCb->rteCfg.nSapIdPres == TRUE)
         {
            msg->nSap = itGlobalCb.nSap[curRouteCb->rteCfg.nSapId];
         }
         else
         {
            msg->nSap = (ItNSapCb *) NULLP;
         }
         msg->msgState = IT_MSG_ROUTED_ONE;
         RETVALUE(ROK);
      }
   }

   RETVALUE(ROKDNA);
}  /* end of itAtSearch() */


/*
*
*       Fun:   itAtCreatertFilter
*
*       Desc:  This function takes a ItRteCfg struct and returns
*              the rtFilter array and rtMask array.
*
*       Ret:   Failure:
*
*              Success: ROK
*
*       Notes: The filter is split over 2 U32 entries in an array in the
*              following way:
*              Entry [0]:  |nwkId(6)|dpc(24)|opc(2MSBs)|
*              Entry [1]:  |opc(22LSBs)|sls(6)|sio(4)|
*
*              The filter mask is created in the same way and then logically
*              &-ded with the filter before returning both the filter array
*              and the mask array.
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
S16 itAtCreatertFilter
(
ItRouteCb *routeCb            /* route control block */
)
#else
S16 itAtCreatertFilter(routeCb)
ItRouteCb *routeCb;           /* route control block */
#endif
{
   ItRteCfg    *rteCfg;       /* Route Config Struct */

   TRC2(itAtCreatertFilter);

   ITDBGP(IT_DBGMASK_AT, (itGlobalCb.itInit.prntBuf,
          "itAtCreatertFilter(routeCb)\n"));

   rteCfg = &routeCb->rteCfg;

   routeCb->rtFilter[0] = (
      ((U32) rteCfg->nwkId << 26) |
      ((U32) rteCfg->rtFilter.dpc << 2) |
      ((U32) rteCfg->rtFilter.opc >> 22));
   routeCb->rtFilter[1] = (
      ((U32) rteCfg->rtFilter.opc << 10) |
      ((U32) (rteCfg->rtFilter.sls & 0x3F) << 4) |
      ((U32) (rteCfg->rtFilter.sio & 0x0F)));
   routeCb->rtMask[0] = (
      ((U32) 0x3F << 26) |
      ((U32) rteCfg->rtFilter.dpcMask << 2) |
      ((U32) rteCfg->rtFilter.opcMask >> 22));
   routeCb->rtMask[1] = (
      ((U32) rteCfg->rtFilter.opcMask << 10) |
      ((U32) (rteCfg->rtFilter.slsMask & 0x3F) << 4) |
      ((U32) (rteCfg->rtFilter.sioMask & 0x0F)));

   /* filter with mask and put result in filter */
   routeCb->rtFilter[0] = routeCb->rtFilter[0] & routeCb->rtMask[0];
   routeCb->rtFilter[1] = routeCb->rtFilter[1] & routeCb->rtMask[1];

   RETVALUE(ROK);
} /* end of itAtCreatertFilter */


/*
*
*       Fun:   itAtAddnewRouteCb
*
*       Desc:  This function takes a pointer to a newly created RouteCb
*              and adds it in the correct place in the global RouteCb
*              array.
*
*       Ret:   <Void>
*
*       Notes: If the key of the RouteCb to be added matches an already
*              existing one, the new RouteCb is inserted after all the
*              previous ones who's keys match and before the next bigger
*              one.
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
S16 itAtAddnewRouteCb
(
ItRouteCb *newRouteCb,        /* new route CB */
ItDpcCb   *dpcCb,             /* DPC CB */
Bool      addInLst,           /* Addition is required or not in the LList */
ItPsId    *psId
)
#else
S16 itAtAddnewRouteCb(newRouteCb, dpcCb, addInLst, psId)
ItRouteCb *newRouteCb;        /* new route CB */  
ItDpcCb   *dpcCb;             /* DPC CB */        
Bool      addInLst;           /* Addition is required or not in the LList */
ItPsId    *psId;
#endif
{
   Bool        done;          /* TRUE if done */
   CmLListCp   *list;         /* current route list */
   ItRouteCb   *curRouteCb;   /* current route CB */

   TRC2(itAtAddnewRouteCb)
   curRouteCb = (ItRouteCb *) NULLP;
   
   ITDBGP(IT_DBGMASK_AT, (itGlobalCb.itInit.prntBuf, "itAtAddnewRouteCb\n"));

   /* If dpcCb is specified, add to the DPC cluster chain */
   if (dpcCb != (ItDpcCb *) NULLP)
   {
      list = &dpcCb->routes;
   }
   /* If dpcCb not specified, add to the global route list */
   else
   {
      list = &itGlobalCb.addrTrn.rtList;
   }
   
   /* Init list to first element */
   cmLListFirst(list);
   done = FALSE;

   /* Initialize the psId, if route is not found then it is checked outside */
   *psId = 0;
  
        
   curRouteCb = (ItRouteCb *)cmLListCrnt(list);
   while ((curRouteCb != (ItRouteCb *)NULLP) && (done == FALSE))
   /* while (done == FALSE) */
   {
      if (newRouteCb->rtMask[0] > curRouteCb->rtMask[0])
      {
         done = TRUE;
      }
      else if (newRouteCb->rtMask[0] == curRouteCb->rtMask[0])
      {
         if (newRouteCb->rtMask[1] > curRouteCb->rtMask[1])
         {
            done = TRUE;
         }
         else if (newRouteCb->rtMask[1] == curRouteCb->rtMask[1])
         {
            Bool identical = TRUE;
            U32 myScore     = 0;
            U32 yrScore     = 0;
            if (newRouteCb->rteCfg.nwkId != curRouteCb->rteCfg.nwkId)
            {
               identical = FALSE;
            }
            else
            {
               ItRtFilter *rt1;  /* temp route filter 1 */
               ItRtFilter *rt2;  /* temp route filter 2 */
               rt1 = &curRouteCb->rteCfg.rtFilter;
               rt2 = &newRouteCb->rteCfg.rtFilter;
               if (((rt1->dpc & rt1->dpcMask) != (rt2->dpc & rt2->dpcMask)) ||
                   ((rt1->opc & rt1->opcMask) != (rt2->opc & rt2->opcMask)))
               {
                  identical = FALSE;
               }
               else if (((rt1->sls & rt1->slsMask) != 
                         (rt2->sls & rt2->slsMask)) ||
                        ((rt1->sio & rt1->sioMask) != 
                         (rt2->sio & rt2->sioMask)))
               {
                  identical = FALSE;
               }
               else if ((rt1->includeCic != rt2->includeCic) ||
                        (rt1->includeSsn != rt2->includeSsn) ||
                        (rt1->includeTrid != rt2->includeTrid))
               {
                  identical = FALSE;
               }
               else 
               {
                  /* This func will return 3 values for CIC range
                   * checks 1. Over-lapping, 2.exact match or
                   * 3.new CIC - range */
                  if (rt1->includeCic == TRUE)
                  {
                     if ((rt1->cicStart == rt2->cicStart) &&
                        (rt1->cicEnd == rt2->cicEnd))
                     {
                        identical = TRUE;
                     }
                     else if ((rt1->cicStart < rt2->cicStart)
                        && (rt1->cicEnd > rt2->cicStart))
                     {
                        identical = FALSE;
                        if (addInLst != TRUE)
                        {
                           RETVALUE(LIT_OVERLAP);
                        }
                     }
                     else if ((rt1->cicStart < rt2->cicEnd) &&
                           (rt1->cicEnd > rt2->cicStart))
                     {
                        identical = FALSE;
                        if (addInLst != TRUE)
                        {
                           RETVALUE(LIT_OVERLAP);
                        }
                     }
                     else
                        identical = FALSE;
                  }
                  
                  if (rt1->includeSsn == TRUE)
                  {
                     if (rt1->ssn != rt2->ssn)
                     {
                        identical = FALSE;
                     }
                  }
                  if (rt1->includeTrid == TRUE)
                  {
                     if (((rt1->tridStart < rt2->tridStart) || 
                       (rt1->tridStart > rt2->tridEnd)) &&
                      ((rt1->tridEnd < rt2->tridStart) ||
                       (rt1->tridEnd > rt2->tridEnd)))
                     {
                        identical = FALSE;
                     }
                  }
               }
            }
            if (identical == TRUE)
            {
               /* Get the psId for the route */
               if (curRouteCb->owner != NULLP)
               {
                  *psId = curRouteCb->owner->psCfg.psId;
               }
               RETVALUE(ROKDUP);
            }
            /* 
             * Score the route based on importance SSN > TRID > CIC. 
             * In reality, a route would not normally have CIC and SSN/TRID
             * included.
             */
            myScore += 
               (newRouteCb->rteCfg.rtFilter.includeCic == TRUE) ? 1 : 0;
            myScore += 
               (newRouteCb->rteCfg.rtFilter.includeSsn == TRUE) ? 4 : 0;
            myScore += 
               (newRouteCb->rteCfg.rtFilter.includeTrid == TRUE) ? 2 : 0;
            yrScore += 
               (curRouteCb->rteCfg.rtFilter.includeCic == TRUE) ? 1 : 0;
            yrScore += 
               (curRouteCb->rteCfg.rtFilter.includeSsn == TRUE) ? 4 : 0;
            yrScore += 
               (curRouteCb->rteCfg.rtFilter.includeTrid == TRUE) ? 2 : 0;
            if (myScore > yrScore)
            {
               done = TRUE;
            }
         }
      }

      if (done == FALSE)
      {
         cmLListNext(list);
      }
      curRouteCb = (ItRouteCb *)cmLListCrnt(list);
   }
   if (addInLst == TRUE)
   {
      /* add before current */
      newRouteCb->node.next = newRouteCb->node.prev = (CmLList *) NULLP;
      if (cmLListCrnt(list))
      {
         cmLListInsCrnt(list, &newRouteCb->node);
      }
      else
      {
         /* fallen off end of list: insert at tail */
         cmLListAdd2Tail(list, &newRouteCb->node);
      }
   }
   else if ((curRouteCb != NULL) && 
            ((newRouteCb->rtMask[0] != curRouteCb->rtMask[0]) ||
             (newRouteCb->rtMask[1] != curRouteCb->rtMask[1])))
   {
      RETVALUE(LIT_OVERLAP);
   }
   /* The below check is added if The Route is present in DPCCB 
    * itself then also the route may be a perfect match and
    * and in that case we can get the PS ID from DPCCB itself
    * Mask = 0xfffffffc as the last 2 bits are from opc mask
    * and we are looking for DPC route only */
   else if ((curRouteCb == NULL) &&
            (newRouteCb->rtMask[0] == 0xfffffffc) &&
            (newRouteCb->rtMask[1] == 0x00))
   {
      if (dpcCb->owner != NULLP)
      {
          *psId = dpcCb->owner->psCfg.psId;
      }
      RETVALUE(ROKDUP);
   }           
   RETVALUE(ROK);
} /* end of itAtAddnewRouteCb */


/*
*
*       Fun:   itAtChkPsDeps
*
*       Desc:  This function checks whether any routes are routing to
*              the PSCBthat was passed to it.  It is used from 
*              itPsmDelPs to check that no routes still
*              reference the PSCB before deleting it.
*
*       Ret:   Failure:  RFAILED - indicates that there are routes referencing
*                                  this PS
*
*              Success:  ROK     - no routes referencing this PS
*
*       Notes: <none>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtChkPsDeps
(
ItPsCb   *cb                  /* PS CB */
)
#else
PUBLIC S16 itAtChkPsDeps(cb)
ItPsCb   *cb;                 /* PS CB */
#endif
{
   ItDpcCb   *prevEnt;        /* previous DPC CB */
   ItDpcCb   *entry;          /* current DPC CB */
   ItRouteCb *curRouteCb;     /* current route CB */

   TRC2(itAtChkPsDeps)
   
   ITDBGP(IT_DBGMASK_AT, (itGlobalCb.itInit.prntBuf, "itAtChkPsDeps\n"));

   /* search all DPC cluster chains for PS match */
   prevEnt = (ItDpcCb *) NULLP;
   while (cmHashListGetNext(&itGlobalCb.addrTrn.dpcList,
                            (PTR) prevEnt, (PTR *) &entry) ==  ROK)
   {
      if (cmLListLen(&entry->routes) == 0)
      {
         if (entry->owner == cb)
         {
            RETVALUE(RFAILED);
         }
      }
      else
      {
         for (curRouteCb = (ItRouteCb *)cmLListFirst(&entry->routes); 
              curRouteCb;
              curRouteCb = (ItRouteCb *)cmLListNext(&entry->routes))
         {
            if (curRouteCb->owner == cb)
            {
               RETVALUE(RFAILED);
            }
         }
      }
      prevEnt = entry;
   } /* end while */

   /* search all global routes for PS match */
   for (curRouteCb = (ItRouteCb *)cmLListFirst(&itGlobalCb.addrTrn.rtList); 
        curRouteCb;
        curRouteCb = (ItRouteCb *)cmLListNext(&itGlobalCb.addrTrn.rtList))
   {
      if (curRouteCb->owner == cb)
      {
         RETVALUE(RFAILED);
      }
   }

   RETVALUE(ROK);
} /* itAtChkPsDeps */


/************************ END OF ADDRESS TRANSLATION *********************/


/**************************************************************************
 *                  STREAM MAPPER
 **************************************************************************/

/*
*
*       Fun:   itSmDatInd
*
*       Desc:  Called by LI to indicate receipt of data from the peer SCTP
*              user Fetches the ACB and passes the incoming data to the
*              MMH block by calling itMmhDatInd.
*
*       Ret:   ROK
*
*       Notes: <None>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itSmDatInd
(
UConnId        suAssocId,     /* association ID */
Buffer         **mBuf,         /* pointer to message */
SctStrmId      strmId         /* Stream Id */
)
#else
PUBLIC S16 itSmDatInd(suAssocId, mBuf, strmId)
UConnId        suAssocId;     /* association ID */
Buffer         **mBuf;         /* pointer to message */
SctStrmId      strmId;        /* Stream Id */
#endif
{
   ItAssocCb   *assocCb;      /* association CB */

   TRC2(itSmDatInd)
#ifdef BIT_64
   ITDBGP(IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf, 
            "itSmDatInd(suAssocId(%d), strmId, indType, mBuf)\n",suAssocId));
#else
   ITDBGP(IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf, 
            "itSmDatInd(suAssocId(%ld), strmId, indType, mBuf)\n",suAssocId));
#endif

   if (mBuf == (Buffer **)NULLP)
   {
      RETVALUE(RFAILED);
   }
           
   assocCb = itGlobalCb.assoc[suAssocId];

   IT_STS_INC_DATA_RX_SCT(assocCb, *mBuf);

   RETVALUE(itMmhDatInd(assocCb, mBuf, strmId));
} /* end of itSmDatInd */


/*
*
*       Fun:   itSmDatReq
*
*       Desc:  Called by MMH to send data to an M3UA peer on the selected
*              association.  If dataMsg flag is FALSE, indicating a manage-
*              ment message, stream 0 is always used.  If dataMsg is TRUE,
*              the stream number is determined as follows:
*              ((link selector)%(number of provisioned streams-1))+1
*
*       Ret:   ROK
*
*       Notes: <None>
*
*       File:  it_bdy3.c
*
*/

#ifdef ANSI
PUBLIC S16 itSmDatReq
(
ItAssocCb   *assocCb,         /* association CB */
Buffer      **mBuf,           /* pointer to message */
Bool        dataMsg,          /* TRUE if data message */
LnkSel      sls               /* link selector */
)
#else
PUBLIC S16 itSmDatReq(assocCb, mBuf, dataMsg, sls)
ItAssocCb   *assocCb;         /* association CB */
Buffer      **mBuf;           /* pointer to message */
Bool        dataMsg;          /* TRUE if data message */
LnkSel      sls;              /* link selector */
#endif
{
   SctStrmId   strmNo;        /* stream number */

   TRC2(itSmDatReq)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
            "itSmDatReq(assocCb, mBuf, dataMsg, sls)\n"));

   if (mBuf == (Buffer **)NULLP)
   {
      RETVALUE(RFAILED);
   }

   if (dataMsg == FALSE) 
   {
      strmNo = 0;
   }
   else                        /* if dataMsg == TRUE */
   {
      strmNo = (SctStrmId) ((sls % (assocCb->outStrms - 1)) + 1);
   }

   if (itLiDatReq(assocCb, strmNo, *mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of itSmDatReq */

/*********************** END OF CONGESTION CONTROLLER **********/


/********************************************************************30**

  End of file:     it_bdy3.c@@/main/7 - Thu Apr  1 03:51:36 2004

**********************************************************************31*/

/********************************************************************40**

  Notes:

**********************************************************************41*/

/********************************************************************50**

**********************************************************************51*/

/********************************************************************60**

  Revision history:

**********************************************************************61*/
/********************************************************************70**

  version    initials                   description
  -----------  ---------  ------------------------------------------------

**********************************************************************71*/

/********************************************************************80**

**********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/3      ---      pn   1. initial release.
/main/3      ---      nt   1. Check added for maxNmbSg and maxNmbPsp is to be
                              less than LIT_MAX_SG and LIT_MAX_ASP 
                              respectively.
             ---      mrw  2. Updates to Release 1.2
             ---      pn   3. Removed check for valid DPC length in 
                              itAtVerifyRoutCfg - this is done in 
                              itAtVerifyNwkCfg already.      
/main/4      ---      sg   1. Bakeoff Fixes.
             ---      sg   2. Routing and Loadshare Changes.
             ---      sg   3. Update to Release 1.3
/main/5      ---      sg   1. Update to Release 1.4
/main/5    it001.104  sg   1. Changes for Outgoing Message Routing based on
                              Local PS status at ASP/IPSP.
           it001.104  vt   2. Changes for Network Appearance reconfiguration.
/main/5    it002.104  sg   1. Change to not allow reconfiguration of maxNmbLps.
                           2. All patches of ver 1.3 has been propagated.

/main/5    it011.104  sg   1. Change in itAtSearch for SI_TUP supprt.
/main/5    it015.104  vt   1. Changes done for sending a DPC available
                              notification to LM as well as the users 
                              of M3UA if a DPC becomes available after 
                              configuring a Route.
/main/5    it016.104  vt   1. changes for route not getting configured
                              on DPC created through DPC learning
                           2. changes for clearing up the routing DPC
                           3. changes to take care for clearing up of
                              spmcs fileds of all the PS of which this DPC 
                              was a part 
/main/5    it017.104  vt   1. changes for indication not going to USER
                              for the non route DPC when a dpc only route
                              is created on that. 
/main/5    it018.104  vt   1. changes for initializing statistics
                              and indications sent to Layer Manager
/main/6      ---      nt   1. Update to Release 1.5
/main/7      ---      rs   1. Update to Release 1.6.
/main/7    it001.106  sg   1. LmPst Structure is made reconfigurable.
                           2. Hash key type changed to CM_HASH_KEYTYPE_U32MOD
/main/7    it005.106  sg   1. Allow su2Swtch to be set as LIT_SW2_UNUSED.
/main/7    it007.106  sg   1. Change in itAtCfgRout for dpcMask check.
/main/7    it009.106  sg   1. Change in itAtVerifyRoutCfg to check dpcMask 
                              against LIT_DPC_SPECIFIED.
                           2. Change in itAtDelRout for dpcMask check.
/main/7    it011.106  sg   1. Change in itMiSendLmCfm to update intfVer in 
                              pst struccture.
/main/7    it012.106  jc   1. Added support for SS_MULTIPLE_PROCS 
/main/7    it013.106  sg   1. Change in itAtCfgNwk to make SSF reconfigurable.
                           2. Change in itAtCfgRout to return RFAILED if route 
                              completely matches an existing routing entry 
                              except PS id.
                           3. Change in itAtDelRout for proper decrement of 
                              nmbRout.
/main/7    it017.106  sg   1. Change in itMiCfgGen to reset the srcProcId,
                              entity and instance in lmPst to the values
                              set in itActvInit.
                           2. Change in itMiSendLmCfm to set source procId,
                              entity and instance using lmPst.
*********************************************************************91*/
