/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/


/********************************************************************20**

     Name:     M3UA - portable upper interface

     Type:     C source file

     Desc:     C source code for the M3UA upper interface
               primitives

     File:     it_ptui.c

     Sid:      it_ptui.c@@/main/7 - Thu Apr  1 03:53:00 2004

     Prg:      na

*********************************************************************21*/


/*

The following functions are provided in this file:

     ItUiSntUDatInd   upper interface - Data Indication
     ItUiSntStaInd    upper interface - Call Status Enquiry Indication
     ItUiSntStaCfm    upper interface - Status Confirmation
     ItUiSntBndCfm    upper interface - Bind Confirmation
     ItUiSntStaApyInd upper interface - Status Apply Indication
     ItUiSntStaQryInd upper interface - Status Query Indication
     ItUiSntStaQryCfm upper interface - Status Query Confirm

It should be noted that not all of these functions may be required
by a particular network layer service user.

It is assumed that the following functions are provided in it_bdy1.c:

     ItUiSntBndReq    upper interface - Bind Request
     ItUiSntDatReq    upper interface - Data Request
     ItUiSntFlcReq    upper interface - Flow Control Request
     ItUiSntStaReq    upper interface - Status Request
     ItUiSntStaApyReq upper interface - Status Apply Request
     ItUiSntStaQryReq upper interface - Status Query Request
     ItUiSntStaQryRsp upper interface - Status Query Response

*/


/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*    
*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_ss7.h"        /* common SS7 */
#include "cm_tpt.h"        /* common transport defines */
#include "lit.h"           /* layer management M3UA  */
#include "sct.h"           /* SCT interface */
#include "snt.h"           /* SNT interface */
#include "it.h"            /* M3UA internal defines */
#include "it_err.h"        /* M3UA error */

/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_ss7.x"        /* common SS7 */
#include "cm_tpt.x"        /* common transport */
#include "sct.x"           /* SCT interface */
#ifdef IT_FTHA            
#include "sht.x"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "lit.x"           /* layer management M3UA */
#include "snt.x"           /* SNT interface */
#include "it.x"            /* M3UA internal typedefs */
#ifdef LCITUISNT_XOS
#include "xosshell.h"
#include "it_adtr.h"
#endif

/* local defines */
#define IT_SNT_MAX_SEL     9

/* forward references */

PRIVATE S16 PtUiSntUDatInd ARGS((Pst *pst, SuId suId,
            Dpc cgAdr, Dpc cdAdr, SrvInfo srvInfo, LnkSel lnkSel,
            Buffer *mBuf));
PRIVATE S16 PtUiSntStaInd ARGS((Pst *pst, SuId suId, Dpc adr, Status status,
            Priority prior));
#ifdef SNT2
PRIVATE S16 PtUiSntStaCfm ARGS((Pst *pst, SuId suId, Dpc adr, Status status,
            Priority congLevel));
PRIVATE S16 PtUiSntBndCfm ARGS((Pst *pst, SuId suId, U8 status));
#endif
#ifdef SNT_BACK_COMP_MERGED_NIF
#ifdef SNTIWF
PRIVATE S16 PtUiSntStaApyInd ARGS((Pst *pst, SuId suId, Dpc aPc, Dpc opc, 
                                   SrvInfo srvInfo, Status status, 
                                   Priority congLevel));
PRIVATE S16 PtUiSntStaQryInd ARGS((Pst *pst, SuId suId, Dpc aPc, Dpc opc));
PRIVATE S16 PtUiSntStaQryCfm ARGS((Pst *pst, SuId suId, Dpc aPc, Dpc opc, 
                                   Status status, Priority congLevel));
#endif
#endif

/* public variable declarations */

/*

The following matrices define the mapping between the primitives
called by the upper interface of M3UA and the corresponding
primitives of the M3UA service user(s).

The parameter MAXITUI defines the maximum number of service users on
top of M3UA. There is an array of functions per primitive
invoked by M3UA. Every array is MAXITUI long (i.e. there
are as many functions as the number of service users).

The dispatching is performed by the configurable variable: selector.
The selector is configured on a per SAP basis.

The selectors are:

   0 - loosely coupled (#define LCITUISNT)
   1 - SCCP (#define SP)
   2 - ISUP (#define SI)
   3 - TUP (#define TP)
   4 - BISUP (#define BI)
   5 - NIF (#define NF)
   6 - AAL2 (#define AL)
   7 - GCP  
   8 - BICC

*/


/* Data Indication primitive */

PUBLIC SntUDatInd ItUiSntUDatIndMt[IT_SNT_MAX_SEL] =
{
#ifdef LCITUISNT
   cmPkSntUDatInd,         /* 0 - loosely coupled */
#else
   PtUiSntUDatInd,         /* 0 - tightly coupled, portable */
#endif
#ifdef SP
   SpLiSntUDatInd,         /* 1 - tightly coupled, SCCP */
#else
   PtUiSntUDatInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef SI
   SiLiSntUDatInd,         /* 2 - tightly coupled, ISUP */
#else
   PtUiSntUDatInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef TP
   TpLiSntUDatInd,         /* 3 - tightly coupled, TUP */
#else
   PtUiSntUDatInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef BI
   BiLiSntUDatInd,         /* 4 - tightly coupled, BISUP */
#else
   PtUiSntUDatInd,         /* 4 - tightly coupled, portable */
#endif
#ifdef AL
   AlLiSntUDatInd,         /* 5 - tightly coupled, AAL2 */
#else
   PtUiSntUDatInd,         /* 5 - tightly coupled, portable */
#endif
/* it013.106 - addition - support for GCP */
#ifdef M3UA_MG     /*chendh modify*/
   MgLiSntUDatInd,          /* 6 - tightly coupled, GCP */
#else   
   PtUiSntUDatInd,         /* 6 - tightly coupled, portable GCP */
#endif   
   PtUiSntUDatInd,         /* 7 - tightly coupled, portable BICC */

#ifdef LCITUISNT_XOS
   ItPkSntUDatInd,         /* 8 - loosely coupled */
#else
   PtUiSntUDatInd,         /* 8 - tightly coupled, portable */
#endif
};


/* Status Indication primitive */

PUBLIC SntStaInd ItUiSntStaIndMt[IT_SNT_MAX_SEL] =
{
#ifdef LCITUISNT
   cmPkSntStaInd,          /* 0 - loosely coupled */
#else
   PtUiSntStaInd,          /* 0 - tightly coupled, portable */
#endif
#ifdef SP
   SpLiSntStaInd,          /* 1 - tightly coupled, SCCP */
#else
   PtUiSntStaInd,          /* 1 - tightly coupled, portable */
#endif
#ifdef SI
   SiLiSntStaInd,          /* 2 - tightly coupled, ISUP */
#else
   PtUiSntStaInd,          /* 2 - tightly coupled, portable */
#endif
#ifdef TP
   TpLiSntStaInd,          /* 3 - tightly coupled, TUP */
#else
   PtUiSntStaInd,          /* 3 - tightly coupled, portable */
#endif
#ifdef BI
   BiLiSntStaInd,          /* 4 - tightly coupled, BISUP */
#else
   PtUiSntStaInd,          /* 4 - tightly coupled, portable */
#endif
#ifdef AL
   AlLiSntStaInd,          /* 5 - tightly coupled, AAL2 */
#else
   PtUiSntStaInd,          /* 5 - tightly coupled, portable */
#endif
/* it013.106 - addition - support for GCP */   
#ifdef M3UA_MG     /*chendh modify*/
   MgLiSntStaInd,          /* 6 - tightly coupled, GCP */
#else
   PtUiSntStaInd,          /* 6 - tightly coupled, portable GCP */
#endif   
   PtUiSntStaInd,          /* 7 - tightly coupled, portable BICC */

#ifdef LCITUISNT_XOS
   cmPkSntStaInd,          /* 8 - loosely coupled */
#else
   PtUiSntStaInd,          /* 8 - tightly coupled, portable */
#endif
};

#ifdef SNT2
/* Status confirmation primitive */

PUBLIC SntStaCfm ItUiSntStaCfmMt[IT_SNT_MAX_SEL] =
{
#ifdef LCITUISNT
   cmPkSntStaCfm,          /* 0 - loosely coupled */
#else
   PtUiSntStaCfm,          /* 0 - tightly coupled, portable */
#endif
#ifdef SP
   SpLiSntStaCfm,          /* 1 - tightly coupled, SCCP */
#else
   PtUiSntStaCfm,          /* 1 - tightly coupled, portable */
#endif
#ifdef SI
   SiLiSntStaCfm,          /* 2 - tightly coupled, ISUP */
#else
   PtUiSntStaCfm,          /* 2 - tightly coupled, portable */
#endif
#ifdef TP
   TpLiSntStaCfm,          /* 3 - tightly coupled, TUP */
#else
   PtUiSntStaCfm,          /* 3 - tightly coupled, portable */
#endif
#ifdef BI
   BiLiSntStaCfm,          /* 4 - tightly coupled, BISUP */
#else
   PtUiSntStaCfm,          /* 4 - tightly coupled, portable */
#endif
#ifdef AL
   AlLiSntStaCfm,          /* 5 - tightly coupled, AAL2 */
#else
   PtUiSntStaCfm,          /* 5 - tightly coupled, portable */
#endif
/* it013.106 - addition - support for GCP */   
#ifdef M3UA_MG     /*chendh modify*/
   MgLiSntStaCfm,          /* 6 - tightly coupled, GCP */
#else
   PtUiSntStaCfm,          /* 6 - tightly coupled, portable GCP */
#endif   
   PtUiSntStaCfm,          /* 7 - tightly coupled, portable BICC */

#ifdef LCITUISNT_XOS
   cmPkSntStaCfm,          /* 0 - loosely coupled */
#else
   PtUiSntStaCfm,          /* 0 - tightly coupled, portable */
#endif
};

/* Bind confirmation primitive */

PUBLIC SntBndCfm ItUiSntBndCfmMt[IT_SNT_MAX_SEL] =
{
#ifdef LCITUISNT
   cmPkSntBndCfm,          /* 0 - loosely coupled */
#else
   PtUiSntBndCfm,          /* 0 - tightly coupled, portable */
#endif
#ifdef SP
   SpLiSntBndCfm,          /* 1 - tightly coupled, SCCP */
#else
   PtUiSntBndCfm,          /* 1 - tightly coupled, portable */
#endif
#ifdef SI
   SiLiSntBndCfm,          /* 2 - tightly coupled, ISUP */
#else
   PtUiSntBndCfm,          /* 2 - tightly coupled, portable */
#endif
#ifdef TP
   TpLiSntBndCfm,          /* 3 - tightly coupled, TUP */
#else
   PtUiSntBndCfm,          /* 3 - tightly coupled, portable */
#endif
#ifdef BI
   BiLiSntBndCfm,          /* 4 - tightly coupled, BISUP */
#else
   PtUiSntBndCfm,          /* 4 - tightly coupled, portable */
#endif
#ifdef AL
   AlLiSntBndCfm,          /* 5 - tightly coupled, AAL2 */
#else
   PtUiSntBndCfm,          /* 5 - tightly coupled, portable */
#endif
/* it013.106 - addition - support for GCP */   
#ifdef M3UA_MG     /*chendh modify*/
   MgLiSntBndCfm,          /* 6 - tightly coupled, GCP */
#else
   PtUiSntBndCfm,          /* 6 - tightly coupled, portable GCP */
#endif   
   PtUiSntBndCfm,          /* 7 - tightly coupled, portable BICC */

#ifdef LCITUISNT_XOS
   cmPkSntBndCfm,          /* 0 - loosely coupled */
#else
   PtUiSntBndCfm,          /* 0 - tightly coupled, portable */
#endif
};

#endif /* SNT2 */

#ifdef SNT_BACK_COMP_MERGED_NIF
#ifdef SNTIWF
/* Status Apply Indication primitive */

PUBLIC SntStaApyInd ItUiSntStaApyIndMt[IT_SNT_MAX_SEL] =
{
#ifdef LCITUISNT
   cmPkSntStaApyInd,          /* 0 - loosely coupled */
#else
   PtUiSntStaApyInd,          /* 0 - tightly coupled, portable */
#endif
   PtUiSntStaApyInd,          /* 1 - tightly coupled, portable */
   PtUiSntStaApyInd,          /* 2 - tightly coupled, portable */
   PtUiSntStaApyInd,          /* 3 - tightly coupled, portable */
   PtUiSntStaApyInd,          /* 4 - tightly coupled, portable */
   PtUiSntStaApyInd,          /* 5 - tightly coupled, portable */
   PtUiSntStaApyInd,          /* 6 - tightly coupled, portable */
   PtUiSntStaApyInd,          /* 7 - tightly coupled, portable */

};

/* Status Query Indication primitive */

PUBLIC SntStaQryInd ItUiSntStaQryIndMt[IT_SNT_MAX_SEL] =
{
#ifdef LCITUISNT
   cmPkSntStaQryInd,          /* 0 - loosely coupled */
#else
   PtUiSntStaQryInd,          /* 0 - tightly coupled, portable */
#endif
   PtUiSntStaQryInd,          /* 1 - tightly coupled, portable */
   PtUiSntStaQryInd,          /* 2 - tightly coupled, portable */
   PtUiSntStaQryInd,          /* 3 - tightly coupled, portable */
   PtUiSntStaQryInd,          /* 4 - tightly coupled, portable */
   PtUiSntStaQryInd,          /* 5 - tightly coupled, portable */
   PtUiSntStaQryInd,          /* 6 - tightly coupled, portable */
   PtUiSntStaQryInd,          /* 7 - tightly coupled, portable */
};

/* Status Query Confirm primitive */

PUBLIC SntStaQryCfm ItUiSntStaQryCfmMt[IT_SNT_MAX_SEL] =
{
#ifdef LCITUISNT
   cmPkSntStaQryCfm,          /* 0 - loosely coupled */
#else
   PtUiSntStaQryCfm,          /* 0 - tightly coupled, portable */
#endif
   PtUiSntStaQryCfm,          /* 1 - tightly coupled, portable */
   PtUiSntStaQryCfm,          /* 2 - tightly coupled, portable */
   PtUiSntStaQryCfm,          /* 3 - tightly coupled, portable */
   PtUiSntStaQryCfm,          /* 4 - tightly coupled, portable */
   PtUiSntStaQryCfm,          /* 5 - tightly coupled, portable */
   PtUiSntStaQryCfm,          /* 6 - tightly coupled, portable */
   PtUiSntStaQryCfm,          /* 7 - tightly coupled, portable */
};
#endif /* SNTIWF */
#endif /* SNT_BACK_COMP_MERGED_NIF */


/*
*     upper interface functions
*/


/*
*
*       Fun:   Network Data Indication
*
*       Desc:  This function provides for an exchange of user
*              data units.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 ItUiSntUDatInd
(
Pst *pst,                   /* post structure */
SuId suId,                  /* Service User Id */
Dpc cgAdr,                  /* Calling Address */
Dpc cdAdr,                  /* Called Address */
SrvInfo srvInfo,            /* Service Information Octet */
LnkSel lnkSel,              /* signalling Link Selection */
Buffer *mBuf                /* Pointer to the Buffer */
)
#else
PUBLIC S16 ItUiSntUDatInd(pst, suId, cgAdr, cdAdr, srvInfo, lnkSel, mBuf)
Pst *pst;                   /* post structure */
SuId suId;                  /* Service User Id */
Dpc cgAdr;                  /* Calling Address */
Dpc cdAdr;                  /* Called Address */
SrvInfo srvInfo;            /* Service Information Octet */
LnkSel lnkSel;              /* signalling Link Selection */
Buffer *mBuf;               /* Pointer to the Buffer */
#endif
{
   TRC3(ItUiSntUDatInd)
#ifdef PERF_TEST
   static int count;
#endif /* PERF_TEST */
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_SNT_MAX_SEL)
   {
      if (mBuf != (Buffer *)NULLP)
      {
         SPutMsg(mBuf);
      }
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

#ifdef PERF_TEST  /* M3UA PERFORMANCE TESTING */
   if (timeStmpFlg == TRUE)
           /* Tightly coupled case */
   {
      gettimeofday(&time2, NULL);
       timeA.tv_usec += (time2.tv_usec - time1.tv_usec);
       if (time2.tv_usec < time1.tv_usec)
       {
               timeA.tv_usec += 1000000;
               time2.tv_sec--;
       }
       timeA.tv_sec += (time2.tv_sec - time1.tv_sec);
       if (timeA.tv_usec >= 1000000)
       {
               timeA.tv_usec -= 1000000;
               timeA.tv_sec++;
       }
   }
#endif  /* M3UA PERFORMANCE TESTING */

   switch (pst->dstEnt)
   {   
#ifdef DI
      /* If distributed ISUP LDF is compiled in the LDF is always invoked *
       * irrespective of the route since LDF ISUP is different from CORE 2*
       * architecture as pure distributed is multiple conventional entity *
       * and distributed fault tolerance is multiple FT/HA entities       */
      case ENTSI:
         DiLiSntUDatInd(pst, suId, cgAdr, cdAdr, srvInfo, lnkSel, mBuf);
         break;
#endif
#ifdef DP
      case ENTSP:
         if (pst->route != RTE_PROTO)
         {
            DpLiSntUDatInd(pst, suId, cgAdr, cdAdr, srvInfo, lnkSel, mBuf);
            break;
         }
         /* FALL THROUGH */
#endif /* DP */
      default:
         /* jump to specific primitive depending on configured selector */
         (*ItUiSntUDatIndMt[pst->selector])(pst, suId, cgAdr, cdAdr, srvInfo,
                                               lnkSel, mBuf);
      break;
   }
   RETVALUE(ROK);
} /* end of ItUiSntUDatInd */


/*
*
*       Fun:   Status Indication
*
*       Desc:  This function is used to Indicate Signalling Point status.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 ItUiSntStaInd
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
Dpc adr,                      /* Address */
Status status,                /* Status */
Priority prior                /* priority */
)
#else
PUBLIC S16 ItUiSntStaInd(pst, suId, adr, status, prior)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
Dpc adr;                      /* Address */
Status status;                /* Status */
Priority prior;               /* priority */
#endif
{
   TRC3(ItUiSntStaInd)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_SNT_MAX_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   switch (pst->dstEnt)
   {
#ifdef DI
      /* If distributed ISUP LDF is compiled in the LDF is always invoked *
       * irrespective of the route since LDF ISUP is different from CORE 2*
       * architecture as pure distributed is multiple conventional entity *
       * and distributed fault tolerance is multiple FT/HA entities       */
      case ENTSI:
         DiLiSntStaInd(pst, suId,  adr, status, prior);
         break;
#endif
#ifdef DP
      case ENTSP:
         if (pst->route != RTE_PROTO)
         {
            DpLiSntStaInd(pst, suId,  adr, status, prior);
            break;
         }
         /* FALL THROUGH */
#endif
      default:
         /* jump to specific primitive depending on configured selector */
         ((*ItUiSntStaIndMt[pst->selector])(pst, suId,  adr, status, prior));
         break;
   }
   RETVALUE(ROK);
} /* end of ItUiSntStaInd */


#ifdef SNT2
/*
*
*       Fun:   Status Confirmation
*
*       Desc:  This function is used to confirm Signalling Point status when
*              requested in the status request from the user part.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 ItUiSntStaCfm
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
Dpc adr,                      /* Address */
Status status,                /* Status */
Priority congLevel            /* congestion level */
)
#else
PUBLIC S16 ItUiSntStaCfm(pst, suId, adr, status, congLevel)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
Dpc adr;                      /* Address */
Status status;                /* Status */
Priority congLevel;           /* congestion level */
#endif
{
   TRC3(ItUiSntStaCfm)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_SNT_MAX_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   switch (pst->dstEnt)
   {
#ifdef DI
      /* If distributed ISUP LDF is compiled in the LDF is always invoked *
       * irrespective of the route since LDF ISUP is different from CORE 2*
       * architecture as pure distributed is multiple conventional entity *
       * and distributed fault tolerance is multiple FT/HA entities       */
      case ENTSI:
         DiLiSntStaCfm(pst, suId,  adr, status, congLevel);
         break;
#endif
#ifdef DP
      case ENTSP:
         if (pst->route != RTE_PROTO)
         {
            DpLiSntStaCfm(pst, suId,  adr, status, congLevel);
            break;
         }
         /* FALL THROUGH */
#endif
      default:
        /* jump to specific primitive depending on configured selector */
        ((*ItUiSntStaCfmMt[pst->selector])(pst, suId,  adr, status, 
                                              congLevel));
         break;
   }
   RETVALUE(ROK);
} /* end of ItUiSntStaCfm */


/*
*
*       Fun:   portable - Bind Confirmation
*
*       Desc:  This function is used to confirm the bind request.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 ItUiSntBndCfm
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
U8 status                     /* Status */
)
#else
PUBLIC S16 ItUiSntBndCfm(pst, suId, status)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
U8 status;                    /* Status */
#endif
{
   TRC3(ItUiSntBndCfm)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_SNT_MAX_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   switch (pst->dstEnt)
   {
#ifdef DI
      /* If distributed ISUP LDF is compiled in the LDF is always invoked *
       * irrespective of the route since LDF ISUP is different from CORE 2*
       * architecture as pure distributed is multiple conventional entity *
       * and distributed fault tolerance is multiple FT/HA entities       */
      case ENTSI:
         DiLiSntBndCfm(pst, suId, status);
         break;
#endif
#ifdef DP
      case ENTSP:
         if (pst->route != RTE_PROTO)
         {
            DpLiSntBndCfm(pst, suId, status);
            break;
         }
         /* FALL THROUGH */
#endif
      default:
      /* jump to specific primitive depending on configured selector */
      ((*ItUiSntBndCfmMt[pst->selector])(pst, suId, status));
      break;
   }
   RETVALUE(ROK);
} /* end of ItUiSntBndCfm */
#endif /* SNT2 */

#ifdef SNT_BACK_COMP_MERGED_NIF
#ifdef SNTIWF

/*
*
*       Fun:   Status Apply Indication
*
*       Desc:  This function is used to set Signalling Point status.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 ItUiSntStaApyInd
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
Dpc aPc,                      /* affected Point Code */
Dpc opc,                      /* originator Point Code */
SrvInfo srvInfo,              /* service information octet */
Status status,                /* status */
Priority congLevel            /* congestion level */
)
#else
PUBLIC S16 ItUiSntStaApyInd(pst, suId, aPc, opc, srvInfo, status, congLevel)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
Dpc aPc;                      /* affected Point Code */
Dpc opc;                      /* originator Point Code */
SrvInfo srvInfo;              /* service information octet */
Status status;                /* status */
Priority congLevel;           /* congestion level */
#endif
{
   TRC3(ItUiSntStaApyInd)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_SNT_MAX_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   /* jump to specific primitive depending on configured selector */
   RETVALUE((*ItUiSntStaApyIndMt[pst->selector])(pst, suId,  aPc, opc, srvInfo, 
                                                 status, congLevel));
} /* end of ItUiSntStaApyInd */

/*
*
*       Fun:   Status Query Indication
*
*       Desc:  This function is used to query Signalling Point status.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 ItUiSntStaQryInd
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
Dpc aPc,                      /* affected Point Code */
Dpc opc                      /* originator Point Code */
)
#else
PUBLIC S16 ItUiSntStaQryInd(pst, suId, aPc, opc)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
Dpc aPc;                      /* affected Point Code */
Dpc opc;                      /* originator Point Code */
#endif
{
   TRC3(ItUiSntStaQryInd)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_SNT_MAX_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   /* jump to specific primitive depending on configured selector */
   RETVALUE((*ItUiSntStaQryIndMt[pst->selector])(pst, suId,  aPc, opc));
} /* end of ItUiSntStaQryInd */

/*
*
*       Fun:   Status Query Confirm
*
*       Desc:  This function is used to confirm Signalling Point status.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 ItUiSntStaQryCfm
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
Dpc aPc,                      /* affected Point Code */
Dpc opc,                      /* originator Point Code */
Status status,                /* status */
Priority congLevel            /* congestion level */
)
#else
PUBLIC S16 ItUiSntStaQryCfm(pst, suId, aPc, opc, status, congLevel)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
Dpc aPc;                      /* affected Point Code */
Dpc opc;                      /* originator Point Code */
Status status;                /* status */
Priority congLevel;           /* congestion level */
#endif
{
   TRC3(ItUiSntStaQryCfm)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_SNT_MAX_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   /* jump to specific primitive depending on configured selector */
   RETVALUE((*ItUiSntStaQryCfmMt[pst->selector])(pst, suId,  aPc, opc, status,
                                                 congLevel));
} /* end of ItUiSntStaQryCfm */

#endif /* SNTIWF */
#endif /* SNT_BACK_COMP_MERGED_NIF */


/*
*     upper interface portable functions
*/


/*
*
*       Fun:   portable - Network Data Indication
*
*       Desc:  This function provides for an exchange of user
*              data units.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtUiSntUDatInd
(
Pst *pst,                   /* post structure */
SuId suId,                  /* Service User Id */
Dpc cgAdr,                  /* Calling Address */
Dpc cdAdr,                  /* Called Address */
SrvInfo srvInfo,            /* Service Information Octet */
LnkSel lnkSel,              /* signalling Link Selection */
Buffer *mBuf                /* Pointer to the Buffer */
)
#else
PRIVATE S16 PtUiSntUDatInd(pst, suId, cgAdr, cdAdr, srvInfo, lnkSel, mBuf)
Pst *pst;                   /* post structure */
SuId suId;                  /* Service User Id */
Dpc cgAdr;                  /* Calling Address */
Dpc cdAdr;                  /* Called Address */
SrvInfo srvInfo;            /* Service Information Octet */
LnkSel lnkSel;              /* signalling Link Selection */
Buffer *mBuf;               /* Pointer to the Buffer */
#endif
{
   TRC3(PtUiSntUDatInd)
#if (ERRCLASS & ERRCLS_DEBUG)
   ITLOGERROR(ERRCLS_DEBUG, EIT453, (ErrVal) ERRZERO, "PtUiSntUDatInd");
#endif
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(cgAdr);
   UNUSED(cdAdr);
   UNUSED(srvInfo);
   UNUSED(lnkSel);
   if (mBuf != (Buffer *)NULLP)
   {
      SPutMsg(mBuf);
   }

   RETVALUE(ROK);
} /* end of PtUiSntUDatInd */


/*
*
*       Fun:   portable - Status Indication
*
*       Desc:  This function is used to Indicate Signalling Point status.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtUiSntStaInd
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
Dpc adr,                      /* Address */
Status status,                /* Status */
Priority prior                /* priority */
)
#else
PRIVATE S16 PtUiSntStaInd(pst, suId, adr, status, prior)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
Dpc adr;                      /* Address */
Status status;                /* Status */
Priority prior;               /* priority */
#endif
{
   TRC3(PtUiSntStaInd)
#if (ERRCLASS & ERRCLS_DEBUG)
   ITLOGERROR(ERRCLS_DEBUG, EIT454, (ErrVal) ERRZERO, "PtUiSntStaInd");
#endif
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(adr);
   UNUSED(status);
   UNUSED(prior);
   RETVALUE(ROK);
} /* end of PtUiSntStaInd */

#ifdef SNT2

/*
*
*       Fun:   portable - Status confirmation
*
*       Desc:  This function is used to confirm Signalling Point status.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtUiSntStaCfm
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
Dpc adr,                      /* Address */
Status status,                /* Status */
Priority congLevel            /* Congestion level */
)
#else
PRIVATE S16 PtUiSntStaCfm(pst, suId, adr, status, congLevel)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
Dpc adr;                      /* Address */
Status status;                /* Status */
Priority congLevel;           /* congestion level */
#endif
{
   TRC3(PtUiSntStaCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
   ITLOGERROR(ERRCLS_DEBUG, EIT455, (ErrVal) ERRZERO, "PtUiSntStaCfm");
#endif
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(adr);
   UNUSED(status);
   UNUSED(congLevel);
   RETVALUE(ROK);
} /* end of PtUiSntStaCfm */


/*
*
*       Fun:   portable - Bind confirmation
*
*       Desc:  This function is used to confirm the bind request.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtUiSntBndCfm
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
U8 status                     /* Status */
)
#else
PRIVATE S16 PtUiSntBndCfm(pst, suId, status)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
U8 status;                    /* Status */
#endif
{
   TRC3(PtUiSntBndCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
   ITLOGERROR(ERRCLS_DEBUG, EIT456, (ErrVal) ERRZERO, "PtUiSntBndCfm");
#endif
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(status);
   RETVALUE(ROK);
} /* end of PtUiSntBndCfm */

#endif /* SNT2 */

#ifdef SNT_BACK_COMP_MERGED_NIF
#ifdef SNTIWF

/*
*
*       Fun:   portable - Status Apply Indication
*
*       Desc:  This function is used to set Signalling Point status.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtUiSntStaApyInd
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
Dpc aPc,                      /* affected Point Code */
Dpc opc,                      /* originator Point Code */
SrvInfo srvInfo,              /* service information octet */
Status status,                /* status */
Priority congLevel            /* congestion level */
)
#else
PRIVATE S16 PtUiSntStaApyInd(pst, suId, aPc, opc, srvInfo, status, congLevel)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
Dpc aPc;                      /* affected Point Code */
Dpc opc;                      /* originator Point Code */
SrvInfo srvInfo;              /* service information octet */
Status status;                /* status */
Priority congLevel;           /* congestion level */
#endif
{
   TRC3(PtUiSntStaApyInd)
#if (ERRCLASS & ERRCLS_DEBUG)
   ITLOGERROR(ERRCLS_DEBUG, EIT457, (ErrVal) ERRZERO, "PtUiSntStaApyInd");
#endif
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(aPc);
   UNUSED(opc);
   UNUSED(status);
   UNUSED(congLevel);
   UNUSED(srvInfo);
   RETVALUE(ROK);
} /* end of PtUiSntStaApyInd */

/*
*
*       Fun:   portable - Status Query Indication
*
*       Desc:  This function is used to query Signalling Point status.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtUiSntStaQryInd
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
Dpc aPc,                      /* affected Point Code */
Dpc opc                       /* originator Point Code */
)
#else
PRIVATE S16 PtUiSntStaQryInd(pst, suId, aPc, opc)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
Dpc aPc;                      /* affected Point Code */
Dpc opc;                      /* originator Point Code */
#endif
{
   TRC3(PtUiSntStaQryInd)
#if (ERRCLASS & ERRCLS_DEBUG)
   ITLOGERROR(ERRCLS_DEBUG, EIT458, (ErrVal) ERRZERO, "PtUiSntStaQryInd");
#endif
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(aPc);
   UNUSED(opc);
   RETVALUE(ROK);
} /* end of PtUiSntStaQryInd */

/*
*
*       Fun:   portable - Status Query Confirm
*
*       Desc:  This function is used to confirm Signalling Point status.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtUiSntStaQryCfm
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
Dpc aPc,                      /* affected Point Code */
Dpc opc,                      /* originator Point Code */
Status status,                /* status */
Priority congLevel            /* congestion level */
)
#else
PRIVATE S16 PtUiSntStaQryCfm(pst, suId, aPc, opc, status, congLevel)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
Dpc aPc;                      /* affected Point Code */
Dpc opc;                      /* originator Point Code */
Status status;                /* status */
Priority congLevel;           /* congestion level */
#endif
{
   TRC3(PtUiSntStaQryCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
   ITLOGERROR(ERRCLS_DEBUG, EIT459, (ErrVal) ERRZERO, "PtUiSntStaQryCfm");
#endif
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(aPc);
   UNUSED(opc);
   UNUSED(status);
   UNUSED(congLevel);
   RETVALUE(ROK);
} /* end of PtUiSntStaQryCfm */

#endif /* SNTIWF */
#endif /* SNT_BACK_COMP_MERGED_NIF */

/********************************************************************30**

         End of file:     it_ptui.c@@/main/7 - Thu Apr  1 03:53:00 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************70**

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/3      ---      mrw  1. initial release.
/main/3      ---      as   1. Updates to Release 1.2        
/main/4      ---      sg   1. Updates to Release 1.3
/main/5      ---      sg   1. Update to Release 1.4
/main/6      ---      nt   1. Update to Release 1.5
/main/7      ---      rs   1. Update to release 1.6.
/main/7    it013.106  sg   1. Support for GCP added.
*********************************************************************91*/
