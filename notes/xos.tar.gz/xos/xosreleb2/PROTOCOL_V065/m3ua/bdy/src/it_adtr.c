/*************************************************
  Copyright (C), 1995-2006, XinWei Tech. Co., Ltd.
  
  File name:    it_adtr.c
  
  Subsystem   : it
  
  Description: ����ISUP����ʱ��M3UAֱ��ͨ��XOS�������ݸ�ATT
  
  Others:         

  History: 
  Programmer  Date         Rev    Description
  --------------- ---------- -------- ------------------------------
  chenning   7/13/2006    1.0        created 
*************************************************/ 

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_ss7.h"        /* common SS7 */
#include "cm_tpt.h"        /* common transport defines */
#include "lit.h"           /* layer management M3UA  */
#include "sct.h"           /* SCT interface */
#include "snt.h"           /* SNT interface */
#ifdef IT_FTHA             
#include "sht.h"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "it.h"            /* M3UA internal defines */
#include "it_err.h"        /* M3UA error */
#ifdef ZV
#include "cm_ftha.h"
#include "cm_psfft.h"          /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.h"
#include "cmzvdvlb.h"
#endif /* ZV_DFTHA */
#include "mrs.h"
#include "lzv.h"
#include "zv.h"            /* m3ua  PSF */
#endif /* ZV */

/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_ss7.x"        /* common SS7 */
#include "cm_tpt.x"        /* common transport */
#include "sct.x"           /* SCT interface */
#ifdef IT_FTHA            
#include "sht.x"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "lit.x"           /* layer management M3UA */
#include "snt.x"           /* SNT interface */
#include "it.x"            /* M3UA internal typedefs */
#ifdef ZV
#include "cm_ftha.x"
#include "cm_psfft.x"
#ifdef ZV_DFTHA
#include "cmzvdv.x"
#include "cmzvdvlb.x"
#endif
#include "mrs.x"
#include "lzv.x"
#include "zv.x"            /* m3ua PSF */
#endif /* ZV */

#ifdef LCITUISNT_XOS
#include "xosshell.h"
#include "it_adtr.h"
#endif

#ifdef LCITUISNT_XOS
PUBLIC S16 ItPkSntUDatInd
(
Pst *pst,                   /* post structure */
SuId suId,                  /* Service User Id */
Dpc cgAdr,                  /* Calling Address */
Dpc cdAdr,                  /* Called Address */
SrvInfo srvInfo,            /* Service Information Octet */
LnkSel lnkSel,              /* signalling Link Selection */
Buffer *mBuf                /* Pointer to the Buffer */
)
{
    S16 msgLen,len;
    S16 ret;
    t_XOSCOMMHEAD *pXosMsg;
    ItATTTest*pAttMsg;

    ret = SFndLenMsg(mBuf, &msgLen);

    if (ret != ROK || msgLen == 0)
    {
        SPutMsg(mBuf);
        mBuf = NULLP;
        RETVALUE(ROK);
    }

    pXosMsg = XOS_MsgMemMalloc(80, (msgLen+2*sizeof(Dpc)));
    if(NULL== pXosMsg)
    {
        RETVALUE(RFAILED);
    }

    pXosMsg->datadest.FID = 80;
    pXosMsg->datadest.PID = XNULL;

    pXosMsg->datasrc.FID  = 65;
    pXosMsg->datasrc.PID  = XNULL;

    pAttMsg= (ItATTTest  *)pXosMsg;
    pAttMsg->opc = cgAdr;
    pAttMsg->dpc = cdAdr;

    SCpyMsgFix(mBuf, 0, msgLen, pAttMsg->buf, &len);

    if(XSUCC != XOS_MsgSend(pXosMsg))
   {
       XOS_MsgMemFree(80, pXosMsg);
       RETVALUE(RFAILED);
   }   

    RETVALUE(ROK);
}
#endif

