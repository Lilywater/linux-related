/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:    M3UA Layer (M3UA)

     Type:    C source file

     Desc:    Magement Interface support functions, Address Translation
              and Stream Mapping supplied by TRILLIUM

     File:    it_bdy5.c

     Sid:      it_bdy5.c@@/main/5 - Thu Apr  1 03:52:01 2004

     Prg:     pn

*********************************************************************21*/

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_ss7.h"        /* common SS7 */
#include "cm_tpt.h"        /* common transport defines */
#include "lit.h"           /* layer management M3UA  */
#include "sct.h"           /* SCT interface */
#include "snt.h"           /* SNT interface */
#include "it_err.h"        /* M3UA error */
#ifdef IT_FTHA
#include "sht.h"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "it.h"            /* M3UA internal defines */
#ifdef ZV
#include "cm_ftha.h"
#include "cm_psfft.h"          /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.h"
#include "cmzvdvlb.h"
#endif /* ZV_DFTHA */
#include "mrs.h"
#include "lzv.h"
#include "zv.h"            /* m3ua  PSF */
#endif /* ZV */

/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_ss7.x"        /* common SS7 */
#include "cm_tpt.x"        /* common transport */
#include "sct.x"           /* SCT interface */
#ifdef IT_FTHA
#include "sht.x"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "lit.x"           /* layer management M3UA */
#include "snt.x"           /* SNT interface */
#include "it.x"            /* M3UA internal typedefs */
#ifdef ZV
#include "cm_ftha.x"
#include "cm_psfft.x"
#ifdef ZV_DFTHA
#include "cmzvdv.x"
#include "cmzvdvlb.x"
#endif
#include "mrs.x"
#include "lzv.x"
#include "zv.x"            /* m3ua PSF */
#endif /* ZV */


PRIVATE S16 itAtCompareRk ARGS((ItAssocCb *assocCb, ItRouteCb *routeCb, 
                                ItRoutKey *rtKey, ItDpcCb
                               *dpcCb, Dpc dpcMask, U8 *rkNotMatchCnt, ItPsId 
                               *frstPsId, U32 localRkId));
PRIVATE S16 itAtChkCompRkRetVal ARGS((ItAssocCb *assocCb, U16 ret, 
                                      U8 rkNotMatchCnt, U32
                                     totalRkComb, U32 localRkId,
                                     ItPsId psId, ItDpcCb *dpcCb));
#ifdef ITASP
PRIVATE S16 itAtDelRkrNRkrtcb ARGS((ItRegReqTmrCb *regReqTmrCb, 
                                    Bool delAll, U32 lclRkId));
#endif  /* ITASP */
PRIVATE S16 itAtCreateNewRk ARGS((ItAssocCb *assocCb, ItRoutKey *rtKey, ItDpcCb
                                 *dpcCb, U32 localRkId, U32 thmMode, U8 nwkId));
PRIVATE S16 itAtCreateNewPsInfo ARGS((ItAssocCb *assocCb, ItPsCfg *psCfg, 
                                ItPsId psId, U8 nwkId, U32 mode));
#ifdef ITASP
PRIVATE S16 itAtFindRkrCb ARGS((ItAssocCb *assocCb, U32 lclRkId,
                                          ItRegReqCb **regReqCb));
#endif  /* ITASP */
PRIVATE Void itAtGetNewRctx ARGS((U32 *rCtx, UConnId assocId));
PRIVATE Void itAtCompRkMultiSi ARGS(( ItRoutKey    *rtKey, U32 *totalRkComb,
                                      ItRouteCb    *routeCb, U8 nwkId, 
                                      Dpc          dpcMask, ItAssocCb *assocCb,
                                      ItDpcCb      *dpcCb, ItPsId  *firstPsId,
                                      U32  localRkId, U8  *rkNotMatchCnt, 
                                      S16  *retVal, S16 *compRkRetVal));
PRIVATE Void itAtCompRkSingleSi ARGS(( ItRoutKey    *rtKey, U32 *totalRkComb,
                                      ItRouteCb    *routeCb, U8 nwkId, 
                                      Dpc          dpcMask, ItAssocCb *assocCb,
                                      ItDpcCb      *dpcCb, ItPsId  *firstPsId,
                                      U32  localRkId, U8  *rkNotMatchCnt, 
                                      S16  *retVal, S16 *compRkRetVal));
#ifdef ITASP
PRIVATE S16 itAtVerifyInterRegReq ARGS((ItCntrl *cntrl, CmStatus *sta));
#endif /* ITASP */

/*
*
*       Fun:   itAtSendRkRegReq
*
*       Desc:  This function is called by MIF to send the REG REQ
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/

#ifdef ITASP
#ifdef ANSI
PUBLIC S16 itAtSendRkRegReq
(
ItCntrl  *cntrl,        /* Control */
CmStatus *sta           /* Status  */
)
#else
PUBLIC S16 itAtSendRkRegReq(cntrl, sta)
ItCntrl  *cntrl;        /* Control */
CmStatus *sta;          /* Status  */
#endif
{
   ItPspCb     *pspCb;                         /* PSP Control Block */
   ItPsCb      *psCb = (ItPsCb *) NULLP;       /* PS Control Block */
   ItRegReqCb  *regReqCb;                      /* RK registration request */
   ItRegReqCb  *regReqLst[LIT_MAX_RK_IN_DRKM]; /* List of RegReqCb, used for
                                                  deallocation */
   U16          lstCnt;                        /* Counter for no of RegReqCb 
                                                  allocations */

   U32          localRkId[LIT_MAX_RK_IN_DRKM]; /* Local RK id array */
   U16          i;                             /* loop counter */
   U16          j;                             /* loop counter */
   S16          ret;                           /* return value */
   ItAssocCb    *assocCb;                      /* Assoc Cb */

   TRC2(itAtSendRkRegReq)

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
            "itAtSendRkRegReq()\n"));

   lstCnt = 0;

   /* Get the PeerCb */
   pspCb = itGlobalCb.psp[cntrl->s.pspId];

   if (pspCb == (ItPspCb *) NULLP)
   {
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_INVALID_PSPID;
      RETVALUE(RFAILED);
   }
   
   if (itGlobalCb.genCfg.drkmSupp == FALSE)
   {
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_DRKM_NOT_SUPP;
      RETVALUE(RFAILED);
   }

   if (pspCb->pspCfg.pspType == LIT_PSPTYPE_ASP)
   {
      /* wrong pspType */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_INV_PEERTYPE;
      RETVALUE(RFAILED);
   }

   /* Verify the inter parameter checks for received RKs */
   if ((ret = itAtVerifyInterRegReq(cntrl, sta)) != ROK)
      RETVALUE(ret);

   /* Get the assoc cb */
   assocCb = itGlobalCb.assoc[IT_PSPnENDP2ASSOC(cntrl->s.pspId, 
                                                cntrl->t.dynRteKey.sctSuId)];
   for (i = 0; i < cntrl->t.dynRteKey.rkm.rK.nmbRk; i++)
   {
      /* verify RK */
       if ((cntrl->t.dynRteKey.rkm.rK.routKey[i].mode != LIT_MODE_ACTSTANDBY) &&           (cntrl->t.dynRteKey.rkm.rK.routKey[i].mode != LIT_MODE_LOADSHARE))
       {
          sta->status = LCM_PRIM_NOK;         
          sta->reason = LIT_REASON_INVALID_THM;
          RETVALUE(RFAILED);
       }     
      if (itAtVerifyRk(&cntrl->t.dynRteKey.rkm.rK.routKey[i].rtKey) != ROK)
      {                                      
         sta->status = LCM_PRIM_NOK;         
         sta->reason = LIT_REASON_INVALID_RK;
         RETVALUE(RFAILED);                  
      }                                      
      psCb =  itPsmFindPs(cntrl->t.dynRteKey.rkm.rK.routKey[i].psId);
      if (psCb == (ItPsCb *) NULLP)            
      {                                        
         sta->status = LCM_PRIM_NOK;           
         sta->reason = LIT_REASON_INVALID_PSID;
         RETVALUE(RFAILED);                    
      }                                        
      /* Only Local PS is allowed in Cntrl Req */
      if (psCb->psCfg.lclFlag != TRUE)
      {                                        
         sta->status = LCM_PRIM_NOK;           
         sta->reason = LIT_REASON_PS_NOT_LOCAL;
         RETVALUE(RFAILED);                    
      }                                        
      /* Validate that the specified PS is not storing RC for previously
       *  registered RK for the same Self End Point */
      if (psCb->psSta.psStaEndp[cntrl->t.dynRteKey.sctSuId].\
                     rteCtx[cntrl->s.pspId].rcValid == TRUE)
      {
         sta->status = LCM_PRIM_NOK;           
         sta->reason = LIT_REASON_PSID_ALREADY_USED;
         RETVALUE(RFAILED);                    
      }
   }
    
   /* Assoc's state */
   if ((assocCb->assocSta->aspSt != LIT_ASP_INACTIVE) &&
       (assocCb->assocSta->aspSt != LIT_ASP_ACTIVE))
   {
      /*  cannot send REG REQ in DOWN state */
      sta->reason = LIT_REASON_INV_PEER_STATE;
      RETVALUE(RFAILED);
   }
   
   
   for (i = 0; i < cntrl->t.dynRteKey.rkm.rK.nmbRk; i++)
   {
      /* Create RKRCBs */
      IT_ALLOC(sizeof(ItRegReqCb), regReqCb)
      if (regReqCb != NULLP)
      {
         regReqLst[lstCnt++] = regReqCb;
      }
      else
      {
         for (j = 0; j < lstCnt; j++)
         {
            cmLListDelFrm(&assocCb->regReq, &regReqLst[j]->node);
            IT_FREE(sizeof(ItRegReqCb), regReqLst[j])
         }
            sta->reason = LCM_CAUSE_MEM_ALLOC_FAIL;
            RETVALUE(RFAILED);
      }                 
      /* fill the contents */
      /* Generate Local-Rk-Id */
      localRkId[i] = itGlobalCb.lclRkId++;
      regReqCb->localRkId = localRkId[i];
      regReqCb->psId      = cntrl->t.dynRteKey.rkm.rK.routKey[i].psId;
      regReqCb->mode      = cntrl->t.dynRteKey.rkm.rK.routKey[i].mode;
      cmMemcpy((U8 *) &regReqCb->rtKey, 
                      (U8 *) &cntrl->t.dynRteKey.rkm.rK.routKey[i].rtKey,
                      sizeof(ItRoutKey));
      cmLListAdd2Tail(&assocCb->regReq, &regReqCb->node);

   }
   
   /* Create RKRTCB */
   ret = itAtCreateRkrtCb(cntrl, assocCb, localRkId, LIT_REG_REQ);
   if (ret != ROK)
   {
      for (i = 0; i < lstCnt; i++)
      {
         cmLListDelFrm(&assocCb->regReq, &regReqLst[i]->node);
         IT_FREE(sizeof(ItRegReqCb), regReqLst[i])
      }
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_RKREGREQ_PEND;
      RETVALUE(RFAILED);
   }
   
   /* send REG REQ to peer */
   ret = itMmhRegReq(cntrl, assocCb); 
   
   if (ret != ROK)
   {
      assocCb->regReqTmrCb[0].req.regReq.nmbLclRkId = 0;
      cmMemset((U8 *)assocCb->regReqTmrCb[0].req.regReq.localRkId, 0, 
                         (sizeof(U32) * LIT_MAX_RK_IN_DRKM));

      for (i = 0; i < lstCnt; i++)
      {
         cmLListDelFrm(&assocCb->regReq, &regReqLst[i]->node);
         IT_FREE(sizeof(ItRegReqCb), regReqLst[i])
      }
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_MSG_NOT_SENT;
      RETVALUE(RFAILED);
   }
   else
   {

      /* Prepare the rkResp to be sent in control Cfm to LM */
      /* itGlobalCb.mgmt.t.cntrl.t.rkResp.rk.nmbRtKey is filled outside the
       * loop */ 

      for (i = 0; i < cntrl->t.dynRteKey.rkm.rK.nmbRk; i++)
      {
         itGlobalCb.mgmt.t.cntrl.t.rkResp.rk[i].localRkId =  localRkId[i];
         cmMemcpy((U8 *) &itGlobalCb.mgmt.t.cntrl.t.rkResp.rk[i].rtKey,
                  (U8 *) &cntrl->t.dynRteKey.rkm.rK.routKey[i].rtKey, 
                  sizeof(ItRoutKey));
      }


      itGlobalCb.mgmt.t.cntrl.t.rkResp.nmbRtKey = 
                                         cntrl->t.dynRteKey.rkm.rK.nmbRk;
 
      /* Start the timer */
      itTcStartTimer(&assocCb->regReqTmrCb[0].tmrRegReq, 
                           (PTR) &(assocCb->regReqTmrCb[0]),
                           IT_TMR_RKM,
                           &itGlobalCb.genCfg.tmr.tmrDrkm);
      sta->status = LCM_PRIM_OK;
      sta->reason = LCM_REASON_NOT_APPL;
      RETVALUE(ROK);
   }
} /* end of itAtSendRkRegReq */


/*
*
*       Fun:   itAtCreateRkrtCb
*
*       Desc:  This function is called to create RKRTCB.
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtCreateRkrtCb
(
ItCntrl  *cntrl,            /* Control      */
ItAssocCb  *assocCb,        /* Assoc CB       */
U32      *lclRkId,          /* Local Rk Id  */
U8       reqType            /* Request Type */
)
#else
PUBLIC S16 itAtCreateRkrtCb(cntrl, assocCb, lclRkId, reqType)
ItCntrl  *cntrl;          /* Control      */
ItAssocCb  *assocCb;      /* Assoc CB       */
U32      *lclRkId;        /* Local Rk Id  */
U8       reqType;         /* Request Type */
#endif
{
   U16           regReqTmrId; /* Reg Req Tmr CB id */
   U16           i;           /* index */
   ItPsCb        *psCb = (ItPsCb *)NULLP; /* PS CB       */


   TRC2(itAtCreateRkrtCb)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
            "itAtCreateRkrtCb()\n"));

   /* The index will be 0 for REG REQ and 1 for REG RSP */

   if (reqType == LIT_REG_REQ)
   {
      if (assocCb->regReqTmrCb[0].req.regReq.nmbLclRkId != 0)
      {
         /* One Registration request already issued for the peer */
         RETVALUE(RFAILED);
      }
      else
         regReqTmrId = 0;
   }
   else /* regType is LIT_DEREG_REQ */
   {
      if (assocCb->regReqTmrCb[1].req.deRegReq.nmbRctx != 0)
      {
         /* One De-Registration request already issued for the peer */
         RETVALUE(RFAILED);
      }
      else
         regReqTmrId = 1;
   }
   assocCb->regReqTmrCb[regReqTmrId].reqType     = cntrl->t.dynRteKey.reqType;
   if (assocCb->regReqTmrCb[regReqTmrId].reqType == LIT_REG_REQ)
   {
      assocCb->regReqTmrCb[regReqTmrId].req.regReq.nmbLclRkId  = 
                                  cntrl->t.dynRteKey.rkm.rK.nmbRk;
      for(i = 0; i < cntrl->t.dynRteKey.rkm.rK.nmbRk; i++)
      {
         assocCb->regReqTmrCb[regReqTmrId].req.regReq.localRkId[i] 
                                  = lclRkId[i];
      }
   }
   else if (assocCb->regReqTmrCb[regReqTmrId].reqType == LIT_DEREG_REQ)
   {
      assocCb->regReqTmrCb[regReqTmrId].req.deRegReq.nmbRctx  = 
          cntrl->t.dynRteKey.rkm.rC.nmbRCtx;
      for (i = 0; i < cntrl->t.dynRteKey.rkm.rC.nmbRCtx; i++)
      {
         assocCb->regReqTmrCb[regReqTmrId].req.deRegReq.rCtx[i].psId  = 
            cntrl->t.dynRteKey.rkm.rC.rteCtxLst[i].psId;
         /* This psCb should never be NULLP as it is checked in previous
          * function */
         psCb = itPsmFindPs(cntrl->t.dynRteKey.rkm.rC.rteCtxLst[i].psId);
         assocCb->regReqTmrCb[regReqTmrId].req.deRegReq.rCtx[i].routCntx  = 
          psCb->psSta.psStaEndp[IT_ASSOC2SUID(assocCb->assocId)].\
          rteCtx[assocCb->owner->pspCfg.pspId].rCtx;
      }
   }
   
   /* Init Timer */
   IT_INITTIMER(&assocCb->regReqTmrCb[regReqTmrId].tmrRegReq);
   assocCb->regReqTmrCb[regReqTmrId].reqCntr  =  0;
   assocCb->regReqTmrCb[regReqTmrId].rspPend  =  TRUE;
   RETVALUE(ROK);

} /* end of itAtCreateRkrtCb */
#endif /* ITASP */

/*
*
*       Fun:   itAtRegReq
*
*       Desc:  This function is called by MMH on receiving REG REQ from peer
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtRegReq
(
ItAssocCb  *assocCb,            /* Assoc CB     */
ItRoutKey  *rtKey,              /* Routkey      */
U8         nwkId,               /* Network id   */
U32        localRkId,           /* Local RK id  */
U32        trafmode             /* Traffic mode */
)
#else
PUBLIC S16 itAtRegReq(assocCb, rtKey, nwkId, localRkId, trafmode)
ItAssocCb  *assocCb;           /* Assoc CB     */
ItRoutKey  *rtKey;             /* Routkey      */
U8         nwkId;              /* Network id   */
U32        localRkId;          /* Local RK id  */
U32        trafmode;           /* Traffic mode */
#endif
{
   ItDpcCb    *dpcCb;           /* DPC control Block */
   ItRouteCb  routeCb;          /* Route control block */
   Dpc        dpcMask;          /* DPC Mask to be filled in rtFilter */
   ItPsCb     *psCb;            /* PSP Control Block corresponding to RK */
   U8         rkNotMatchCnt;    /* Comb of RK elmnts which does not matched */
   S16        ret;              /* Return value */
   S16        ret1;             /* Return value */
   S16        compRkRetVal;     /* RK compare Return value */
   ItPspId    pspId;            /* PSP ID */
   Bool       thmPres;          /* Indicates that THM is present */

#ifdef ZV
   /* it018.106 - addition - DFTHA Enhancement */
   ZvUpdSpecParams updArgs;
#endif /* ZV */

   dpcMask = 0;
   ret1 = 0;
   compRkRetVal = 0;
   rkNotMatchCnt = 0;
   thmPres = TRUE;
   pspId = assocCb->owner->pspCfg.pspId;

   TRC2(itAtRegReq)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
            "itAtRegReq()\n"));
   cmMemset((U8 *)&routeCb, 0, sizeof(ItRouteCb));
   /* Verify the received RK */ 
   if (itGlobalCb.addrTrn.atSta.nmbRout >= itGlobalCb.genCfg.maxNmbRtEnt)
   {
      ITLOGERROR(ERRCLS_INT_PAR, EIT442,
                 (ErrVal) itGlobalCb.addrTrn.rkSta.nmbRkReg,
                 "itAtRegReq: max no. Dyn RK  exceeded");
      itMmhRegRsp(assocCb, IT_RK_INSUF_RSRCS, 0, localRkId);
      RETVALUE(ROK);
   }
   if ((ret = itAtVerifyRk(rtKey)) != ROK)
   {
      itMmhRegRsp(assocCb, IT_INV_RK, 0, localRkId);
      RETVALUE(ROK);
   }
   dpcMask = 0xffffffff;
   if (trafmode == IT_M3UA_DFLT)
   { 
      thmPres = FALSE;
      trafmode = IT_M3UA_DFLT_THM;
   }
   if (itAtGetDpc(nwkId, rtKey->dpc, &dpcCb) == ROK)
   {
      ItPsId   firstPsId;
      U32       totalRkComb;
      S16      retVal;
      SuId     suId;          /* SCT SAP id of association */

      firstPsId = 0;
      totalRkComb = 0;
      retVal = 0;
      suId   = IT_ASSOC2SUID(assocCb->assocId);
      /* Valid combinations of elemnts in a RK  are -
       * If more than 1 SIO - take each sio one by one with combination of OPCs
       * if single SIO (plus 1 OPC at a time), then take each of the SSNs one
       * by one, 
       * if single SIO then take each of the CICs-Range one by one  */
      if (rtKey->nmbSio > 1)
      {
          itAtCompRkMultiSi(rtKey, &totalRkComb, &routeCb, nwkId, dpcMask, 
                         assocCb, dpcCb, &firstPsId, localRkId, &rkNotMatchCnt,
                         &retVal, &compRkRetVal);
          if (retVal == RFAILED)
          {
             RETVALUE(RFAILED);
          }
          /* All the combinations of dpc, SI and OPCs are searched in the
           * route List, if not a single match is found then its a new 
           * RK */
          ret1 = itAtChkCompRkRetVal(assocCb, compRkRetVal, rkNotMatchCnt, 
                                     totalRkComb, localRkId, firstPsId, dpcCb);
      } /* End of SI > 1 */
      if (rtKey->nmbSio == 1)
      {
         itAtCompRkSingleSi(rtKey, &totalRkComb, &routeCb, nwkId, dpcMask,
                         assocCb, dpcCb, &firstPsId, localRkId, &rkNotMatchCnt,
                         &retVal, &compRkRetVal);
         ret1 = itAtChkCompRkRetVal(assocCb, compRkRetVal, rkNotMatchCnt,
                                   totalRkComb, localRkId, firstPsId, dpcCb);
      } /* End of nmbSio == 1 */

      if (rtKey->nmbSio == 0)
      {
         IT_SET_FIXED_RK_PRMTR((&routeCb), nwkId, rtKey->dpc, dpcMask);
         totalRkComb = (rtKey->nmbOpc == 0) ? 1 : rtKey->nmbOpc;     
         /* Only combination of dpc and OPCs is expected */
         compRkRetVal = itAtCompareRk(assocCb, &routeCb, rtKey, dpcCb, dpcMask,
                                   &rkNotMatchCnt, &firstPsId, localRkId);
         ret1 = itAtChkCompRkRetVal(assocCb, compRkRetVal, rkNotMatchCnt,
                                   totalRkComb, localRkId, firstPsId, dpcCb);
      } /* End of nmbSio == 0 */

      /* take action depending upon ret1 value */
      if (ret1 == RFAILED)
      {
         RETVALUE(RFAILED);
      }
      else if (ret1 == LIT_CREATE)
      {
         /* Create a new ps */
         itAtCreateNewRk(assocCb, rtKey, dpcCb, localRkId, trafmode, nwkId);
      }
      else if (ret1 == LIT_EXACTMATCH)
      {
         U8      idx;    /* loop Counter */
         
         idx = 0;
         /* firstPsId is the exact match */
         /* Add the PSP into the psCb */
         psCb = itPsmFindPs(firstPsId); 
         if (psCb != NULLP)
         {
            U32   rCtx;  /* Routing Context */

            rCtx = 0;
            /* Check the THM received */
            if ((thmPres == TRUE) && (psCb->psCfg.mode != trafmode))
            {
               /* Return the rCtx in REG RSP to the sending peer */
               RETVALUE(itMmhRegRsp(assocCb, IT_RK_UNSPP_THM, 0, localRkId));
            }

            /* Search the pspReg List, add it, if its not already registered */
            if (psCb->psSta.psStaEndp[suId].rteCtx[pspId].rcValid ==                                                                            TRUE)
            {
               /* If PSP is already registered, response with the current rCtx
                * stored in psCb */
               if ((psCb->psSta.psStaEndp[suId].aspSt[pspId] == 
                                                          LIT_ASP_INACTIVE) && 
                   (psCb->psSta.psStaEndp[suId].rteCtx[pspId].mode ==  
                                                          IT_RC_STATIC_REGD))
               {
                  rCtx = psCb->psSta.psStaEndp[suId].rteCtx[pspId].rCtx;
                  /* If currently it is statically registered then mark it 
                   * dynamically registered */
                  psCb->psSta.psStaEndp[suId].rteCtx[pspId].mode 
                                                      |= IT_RC_DYNAMIC_REGD;
                  itMmhRegRsp(assocCb, IT_RK_SUCC_REGD, rCtx, localRkId);
                  psCb->psSta.psStaEndp[suId].nmbPspReg++;
  
#ifdef ZV
                  updArgs.p.psEndpUpd.endp = suId;
                  updArgs.p.psEndpUpd.slno = pspId;
                  zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PS_ENDP_RCTX,
                          CMPFTHA_UPDTYPE_SYNC, (Void *) psCb, &updArgs);

                  /* Update psStaEndp fields to standby(shadows)*/
                  zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSCB,
                            CMPFTHA_UPDTYPE_SYNC, (Void *)psCb, NULLP);
#endif
                  RETVALUE(ROK);
                  
               }
               itMmhRegRsp(assocCb, IT_CANT_SUPP_UNIQ_RK, 0, localRkId);
               RETVALUE(RFAILED);
            }

            else /* new rCtx */
            {

               ItPsCfg  psCfg;  /* PS Cfg info */
               CmStatus sta;    /* Return status used for itPsmCfgPs */
               U16      i;      /* Loop index */

               /* If PSP is already registered to the PS for another EndP then
                  add only the routCtx info and not the PSP.
                */ 
               /* search the currently configured pspId list of this PS */
               for (i = 0; i < psCb->psCfg.nmbPsp; i++)
               {
                  if (psCb->psCfg.psp[i] == assocCb->owner->pspCfg.pspId)
                  {
                     break; 
                  }
               }
               /* Add the PSP only if it's not in the list */
               if (i == psCb->psCfg.nmbPsp)
               {
                  psCb->psCfg.psp[psCb->psCfg.nmbPsp] = 
                                                 assocCb->owner->pspCfg.pspId;
                  psCb->psCfg.nmbPsp++;
               }
               
               /* Send an indication to the LM that PS has now become part
                * of a new PSP */
               IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
               itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
               itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_CNTRL; 
               itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_PSP_REGD; 
               itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_RK_REGISTERED;
               itGlobalCb.mgmt.t.usta.s.pspId         = 
                                              assocCb->owner->pspCfg.pspId;
               itGlobalCb.mgmt.t.usta.t.drkmEvt.psId  = psCb->psCfg.psId;
               itGlobalCb.mgmt.t.usta.t.drkmEvt.sctSuId  = 
                                               IT_ASSOC2SUID(assocCb->assocId);
   
               (Void) itMiStaIndM(&itGlobalCb.mgmt); 

               cmMemcpy((U8 *)&psCfg,(U8 *)&(psCb->psCfg), sizeof(ItPsCfg));
               /* This is a similar case to reconf of PS */
               (Void) itPsmCfgPs(&psCfg, &sta, IT_PS_CFG_DYN);

               /* Add assocId into the registered list */
               psCb->psSta.psStaEndp[suId].rteCtx[pspId].rcValid = TRUE;
               psCb->psSta.psStaEndp[suId].rteCtx[pspId].mode |= 
                                                           IT_RC_DYNAMIC_REGD;
               /* Allocate the new rCtx from the free list */
               (Void ) itAtGetNewRctx(&rCtx, assocCb->assocId);
               /* itGlobalCb.rCtx is sync'ed inside itAtGetNewRctx to reduce
               chances of skipping it's update to shadow (standbys) */
               psCb->psSta.psStaEndp[suId].rteCtx[pspId].rCtx = rCtx;

               /* increment the number of PSs registered dynamically for this
               * ASSOC */

               assocCb->assocSta->regPs[assocCb->assocSta->nmbRegPs] = 
                                                           psCb->psCfg.psId;
#ifdef ZV
               /* it018.106 - addition - updating table type ZV_PSP_REGPS */
               updArgs.p.pspPsUpd.pspIdx = IT_ASSOC2PSPID(assocCb->assocId);
               updArgs.p.pspPsUpd.endp = IT_ASSOC2SUID(assocCb->assocId);
               updArgs.p.pspPsUpd.slNo = assocCb->assocSta->nmbRegPs;
               
               zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSP_REGPS,
                       CMPFTHA_UPDTYPE_SYNC, (Void *) NULLP, &updArgs);
               /* it018.106 - addition - updating table type ZV_PS_CFGCB */
               zvRTUpd(CMPFTHA_ACTN_ADD, ZV_PS_CFGCB,
                       CMPFTHA_UPDTYPE_SYNC, (Void *) psCb, NULLP);
               
               updArgs.p.psEndpUpd.endp = suId;
               updArgs.p.psEndpUpd.slno = pspId;
               zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PS_ENDP_RCTX,
                       CMPFTHA_UPDTYPE_SYNC, (Void *) psCb, &updArgs);
#endif
               assocCb->assocSta->nmbRegPs++;
               psCb->psSta.psStaEndp[suId].nmbPspReg++;
            } /* End of new rCtx */

#ifdef ZV
            /* sync assocSta change to standby(shadows)*/
            zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSPCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *)assocCb->owner, NULLP);
            /* PS state is sync'ed inside itPsmCfgPs function */
            
#endif

            /* Return the rCtx in REG RSP to the sending peer */
            RETVALUE(itMmhRegRsp(assocCb, IT_RK_SUCC_REGD, rCtx, localRkId));

         } /* End of psCb != NULLP */
      } /* End of ret1 == LIT_REXACTMATCH */
   } /* End of itAtGetDpc == ROK */
   else /* New PS */
   {
       /* There will not be any Search is done in global list */   
       /* Get a new PSID, create it and get a new RC */
       itAtCreateNewRk(assocCb, rtKey, (ItDpcCb *)NULLP, localRkId, trafmode, 
                       nwkId);
   }
   RETVALUE(ROK);
} /* end of itAtRegReq */

/*
*
*       Fun:   itAtVerifyRk
*
*       Desc:  This function is called to validate the RK received in REG REQ
*    
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtVerifyRk
(
ItRoutKey  *rtKey        /* Route Key */
)
#else
PUBLIC S16 itAtVerifyRk(rtKey)
ItRoutKey  *rtKey;       /* Route Key */
#endif
{
   U8        idx;        /* Loop index */
   Bool      cicPres;    /* Cic Range Present */

   TRC2(itAtVerifyRk)


   cicPres = FALSE;

   /* If more than one SIs are present then SSNs and CICs should not be
    * present */
   if ((rtKey->nmbSio > LIT_MAX_SIO_IN_DRKM) ||
       (rtKey->nmbCic > LIT_MAX_CIC_IN_DRKM) ||
       (rtKey->nmbOpc > LIT_MAX_OPC_IN_DRKM))           
   {
      RETVALUE(RFAILED);
   }

   if ((rtKey->nmbSio > 1) && (rtKey->nmbCic != 0 ))
   {
      RETVALUE(RFAILED);
   }

   if (rtKey->nmbCic != 0)
   {
     /* Valid value of SI is ISUP */
     cicPres = TRUE;


     if ((rtKey->sio[0] != SI_ISUP) && (rtKey->sio[0] != SI_TUP))
        RETVALUE(RFAILED);
   }
   idx = 0;
   /* Range of CICs should be proper */
   if (cicPres == TRUE)
   {
      while (idx < rtKey->nmbCic)
      {
         if (rtKey->cicRange[idx].cicEnd <= rtKey->cicRange[idx].cicStart)
         {
            RETVALUE(RFAILED);
         }
      idx++;
      }
   }
   if ((rtKey->nmbOpc != NULLD) && (rtKey->opc[0] == NULLD))
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of itAtVerifyRk */

/*
*
*       Fun:   itAtCompareRk
*
*       Desc:  This function is called to compare the passed RK to existing
*       RKs
*    
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/
#ifdef ANSI
PRIVATE S16 itAtCompareRk
(
ItAssocCb  *assocCb,             /* Assoc CB      */
ItRouteCb  *routeCb,             /* Route CB      */
ItRoutKey  *rtKey,               /* Route Key     */     
ItDpcCb    *dpcCb,               /* DPC CB        */
Dpc        dpcMask,              /* DPC Mask      */
U8         *rkNotMatchCnt,       /* RK not match count */
ItPsId     *frstPsId,            /* First PS ID   */
U32        localRkId             /* Local RK ID   */
)
#else
PRIVATE S16 itAtCompareRk(assocCb, routeCb, rtKey, dpcCb, dpcMask, 
                                   rkNotMatchCnt, frstPsId, localRkId)
ItAssocCb  *assocCb;             /* Assoc CB      */
ItRouteCb  *routeCb;             /* Route CB      */
ItRoutKey *rtKey;                /* Route Key     */
ItDpcCb   *dpcCb;                /* DPC CB        */
Dpc        dpcMask;              /* DPC Mask      */
U8         *rkNotMatchCnt;       /* RK not match count */
ItPsId    *frstPsId;             /* First PS ID   */
U32       localRkId;             /* Local RK ID   */
#endif
{
   ItPsId    lclPsId;

   U8        j;           /* loop counter */
   S16       ret;         /* return value */
   Bool      loopFlag;    /* Flag used for execution of loop */

   TRC2(itAtCompareRk)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
            "itAtCompareRk()\n"));

   lclPsId = 0;
   loopFlag = TRUE;
   for (j = 0; ((j < rtKey->nmbOpc) || (loopFlag == TRUE)); j++)
   { 
      if ((j < rtKey->nmbCic) || (j < rtKey->nmbOpc))
      {
         routeCb->rteCfg.rtFilter.opc = 
                 ((rtKey->nmbOpc > 0) ? rtKey->opc[j] : rtKey->cicRange[j].opc);
         routeCb->rteCfg.rtFilter.opcMask = dpcMask;
      }

      /* Create the routeCb->filter */
      (Void) itAtCreatertFilter(routeCb);

      /* Search the duplicate RouteCb in DPC cluster chain */
      ret = itAtAddnewRouteCb(routeCb, dpcCb, FALSE, &lclPsId);

      /* get the frstPsId if route already exist */
      if (ret == ROKDUP)
      {
         if (*frstPsId == 0)
         {
            *frstPsId = lclPsId;
         }
         else if (*frstPsId != lclPsId)
         {
            /* Entries in RouteCb List corresponds to different PSs */
            /* Send error to the peer for sending erroneous RK */
            itMmhRegRsp(assocCb, IT_CANT_SUPP_UNIQ_RK, 0, localRkId);
            RETVALUE(RFAILED);
         }
      }
      else if (ret == LIT_OVERLAP) /* Error cannot proceed further */
      {
         /* CIC-range is overlapping */
         /* send REG RSP with cause as over-lapping RK */
         itMmhRegRsp(assocCb, IT_CANT_SUPP_UNIQ_RK, 0 , localRkId);
         RETVALUE(RFAILED);
      }
      else if (ret == ROK)
      {
         /* DPC entry is there but its mask[0] or mask[1] does not 
          * matches */
         (*rkNotMatchCnt)++;
      }
      if ((rtKey->nmbOpc == 0) || (j == (rtKey->nmbOpc - 1)))
      {
         loopFlag = FALSE; 
      }
   } /* End of for-loop on OPCs */
   RETVALUE(ROK);
} /* End of itAtCompareRk */

/*
*
*       Fun:   itAtChkCompRkRetVal
*
*       Desc:  This function is called to check the return value of
*       itAtcompare
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/
#ifdef ANSI
PRIVATE S16 itAtChkCompRkRetVal
(
ItAssocCb *assocCb,             /* Assoc CB             */
U16        ret,                 /* Return Value         */
U8         rkNotMatchCnt,       /* Rk not match count   */ 
U32        totalRkComb,         /* Total RK combination */
U32        localRkId,           /* Local RK id          */
ItPsId     psId,                /* PS ID                */
ItDpcCb    *dpcCb               /* DPC CB               */
)
#else
PRIVATE S16 itAtChkCompRkRetVal(assocCb, ret, rkNotMatchCnt, totalRkComb, 
                                localRkId, psId, dpcCb)
ItAssocCb  *assocCb;            /* Assoc CB             */
U16        ret;                 /* Return Value         */
U8         rkNotMatchCnt;       /* Rk not match count   */
U32         totalRkComb;         /* Total RK combination */
U32        localRkId;           /* Local RK id          */
ItPsId     psId;                /* PS ID                */
ItDpcCb    *dpcCb;              /* DPC CB               */
#endif
{
   ItRouteCb  *curRouteCb;  /* Route CB */
   U16         psBsdRteCnt; /* PS based route counts in DPCCB */

   TRC2(itAtChkCompRkRetVal)
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
            "itAtChkCompRkRetVal()\n"));
 
   psBsdRteCnt = 0;
   if (ret == ROK)
   {
      if (rkNotMatchCnt == totalRkComb)
      {
         /* Its a case of creating new psId for the route for
         *  the same * dpcCb */
         RETVALUE(LIT_CREATE);
      }
      else if ((rkNotMatchCnt > 0) && (rkNotMatchCnt < totalRkComb))
      {
         /* Few RCBs matched but not all, hence its a Overlapped RK */
         itMmhRegRsp(assocCb, IT_CANT_SUPP_UNIQ_RK, 0 , localRkId);
         RETVALUE(RFAILED);
      }
      else if (rkNotMatchCnt == 0)
      {
         /* Search is made in the RCB's to look for any RCB exist in the
          * list which has the routing based on the psId */
         ItPsCb   *psCb;
         if ((psCb = itPsmFindPs(psId)) == (ItPsCb *) NULLP)
         {
            RETVALUE(RFAILED);
         }
         
         for (curRouteCb = (ItRouteCb *)cmLListFirst(&dpcCb->routes); 
              curRouteCb;
              curRouteCb = (ItRouteCb *)cmLListNext(&dpcCb->routes))
         {
            if (curRouteCb->owner == psCb)
            {
               psBsdRteCnt++;
            }
         }
         if (curRouteCb == NULL)
         {
            if (dpcCb->owner == psCb)
            {
               psBsdRteCnt++;
            }
         }
         if (psBsdRteCnt == totalRkComb)
         {
            RETVALUE(LIT_EXACTMATCH);
         }
         else 
         {
            itMmhRegRsp(assocCb, IT_CANT_SUPP_UNIQ_RK, 0, localRkId);
            RETVALUE(RFAILED);
         }
      } /* rkNotMatchCnt == 0 */ 
   } /* End of ret == ROK */
   RETVALUE(ret);   
} /* End of itAtChkCompRkRetVal */

/*
*
*       Fun:   itAtCreateNewRk
*
*       Desc:  This function is called to create the New RCB and PS
*    
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/
#ifdef ANSI
PRIVATE S16 itAtCreateNewRk
(
ItAssocCb  *assocCb,          /* Assoc CB    */
ItRoutKey  *rtKey,            /* Route Key   */
ItDpcCb    *dpcCb,            /* DPC CB      */
U32        localRkId,         /* Local RK ID */
U32        thmMode,           /* THM         */
U8         nwkId              /* Network Id  */
)
#else
PRIVATE S16 itAtCreateNewRk(assocCb, rtKey, dpcCb, localRkId, thmMode, nwkId)
ItAssocCb   *assocCb;         /* Assoc CB    */
ItRoutKey   *rtKey;           /* Route Key   */
ItDpcCb     *dpcCb;           /* DPC CB      */
U32         localRkId;        /* Local RK ID */
U32         thmMode;          /* THM         */
U8         nwkId;             /* Network Id  */
#endif
{
   ItPsCfg   psCfg;           /* PS Config struct */
   CmStatus  sta;             /* Status */
   U32       dpcMask;         /* DPC Mask value */
   U8        i;               /* index */
   U8        j;               /* index */
   U8        k;               /* index */
   ItPsCb    *psCb;            /* PS CB */
   ItRteCfg  cfg;             /* Route Cfg */
   S16       ret;             /* Return Value */
   ItPsId    psId;            /* psId */
   U32       rCtx;            /* routing context */
   Bool      done;            /* Flag to take care of cfgRout calls */
   SuId      suId;            /* SCT SAP id of association */
   ItPspId   pspId;           /* PSP Id of the association */
   ItRtCtx   locRtCtx;        /* Temporary storage for routing ctx */
   Bool      aspIdPres;       /* ASP Identifier Present */
   U32       aspId;           /* ASP Identifier */
#ifdef ZV
   ZvUpdSpecParams   updArgs;  /* Update specific params */
#endif


   TRC2(itAtCreateNewRk)
   UNUSED(dpcCb);

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
            "itAtCreateNewRk()\n"));

   cmMemset((U8 *)&psCfg, 0, sizeof(ItPsCfg));
   cmMemset((U8 *)&cfg, 0, sizeof(ItRteCfg));
   /* Get The New PsId */
   if (itGlobalCb.psLstCb.nmbPsCfged == LIT_MAX_PSID)
   {
      /* Send Reg Rsp with insuf rsrc */
      itMmhRegRsp(assocCb, IT_RK_INSUF_RSRCS, 0 , localRkId);
      RETVALUE(RFAILED);
   }
   if (itAtGetNewPsId(&psId) != ROK)
   {
      /* Send REG RSP with registration status as insf resources */
      itMmhRegRsp(assocCb, IT_RK_INSUF_RSRCS, 0 , localRkId);
      RETVALUE(RFAILED);
   }

   if (itAtCreateNewPsInfo(assocCb, &psCfg, psId, nwkId, thmMode) != ROK)
   {
      RETVALUE(RFAILED);
   }
   ret = itPsmCfgPs(&psCfg, &sta, IT_PS_CFG_DYN);
/* DFHTA-hook: Only Comment added */
   /* PS creation is not updated here, its done towards the end of
   this function */

   if (ret == RFAILED)
   {
      if ((sta.status == LCM_PRIM_NOK) &&
         ((sta.reason == LCM_REASON_EXCEED_CONF_VAL) ||
         (sta.reason == LCM_REASON_MEM_NOAVAIL) ||
         (sta.reason == LCM_REASON_INVALID_PAR_VAL)))
      {
         /* Send REG RSP with registration status as insf resources */
         itMmhRegRsp(assocCb, IT_RK_INSUF_RSRCS, 0 , localRkId);
      }
      /* In case of a failure scenario, psId assigned by this function 
         is to be freed */
      itGlobalCb.psLstCb.psIdFree[psId] = TRUE;                  
      RETVALUE(RFAILED);
   }

   /* Get the suid and pspId of association */
   suId  = IT_ASSOC2SUID(assocCb->assocId);
   pspId = IT_ASSOC2PSPID(assocCb->assocId);

   psCb = itPsmFindPs(psId);
      
   /* Fill the psSta.asSt and aspSt */
   psCb->psSta.asSt = LIT_AS_INACTIVE;
   psCb->psSta.psStaEndp[suId].aspSt[pspId] = LIT_ASP_INACTIVE;

#ifdef ZV
   /* it018.106 - addition - updating table type ZV_PS_CFGCB */
   zvRTUpd(CMPFTHA_ACTN_ADD, ZV_PS_CFGCB,
           CMPFTHA_UPDTYPE_SYNC, (Void *) psCb, NULLP);
   
   /* it018.106 - addition - updating table type ZV_PSP_ACTPS */
   updArgs.p.psEndpUpd.endp = suId;
   updArgs.p.psEndpUpd.slno = pspId;
   zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PS_ENDP_PSPSTA,
           CMPFTHA_UPDTYPE_SYNC, (Void *) psCb, &updArgs);
    zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSCB,
              CMPFTHA_UPDTYPE_SYNC, (Void *)psCb, NULLP);
#endif

   if (itGlobalCb.nwk[nwkId]->nwkCfg.dpcLen == DPC14)
   {
      dpcMask = 0x3FFF;
   }
   else if (itGlobalCb.nwk[nwkId]->nwkCfg.dpcLen == DPC16) 
   {
      dpcMask = 0xFFFF;
   }
   else
   {
      dpcMask = 0xFFFFFF;
   }
                
   cfg.nwkId      = nwkId;
   cfg.rtType     = LIT_RTTYPE_PS;
   cfg.psId       = psId;
   cfg.noStatus   = FALSE;
   cfg.nSapIdPres = FALSE;

   /* For all the routes Combinations */
   /* Add the RCB to dpcCb->routes */
   /* If number of SI is 0, only combination of dpc and OPC is present */
   if (rtKey->nmbSio == 0)
   {
      if (rtKey->nmbOpc > 0)
      {
         for (j = 0; j < rtKey->nmbOpc; j++)
         {
            cmMemset((U8 *)&cfg.rtFilter, 0, sizeof(ItRtFilter)); 
            cfg.rtFilter.dpc     = rtKey->dpc;
            cfg.rtFilter.dpcMask = dpcMask;
            cfg.rtFilter.opcMask = dpcMask;
            cfg.rtFilter.opc     = rtKey->opc[j];

            /* If  nmbCic == 0 then cfgRout is called for 
             * DPC and OPC */
            (Void) itAtCfgRout(&cfg, &sta, FALSE);
   /* Route creation updated at standby nodes */   
   /* Original Function (itLiSctDatInd) from where this function is called is
      taking care of ITZVUPDPEER etc macros */
#ifdef ZV
             cmMemcpy((U8 *)&updArgs.p.rteUpd.rteCfg,
                                         (U8 *)&cfg, sizeof(ItRteCfg));
             zvRTUpd(CMPFTHA_ACTN_ADD, ZV_RTECB,
                       CMPFTHA_UPDTYPE_SYNC, (Void *) NULLP, &updArgs);
#endif
         } /* End of loop on nmbOpc */
      }
      else /* No OPC */
      {
         cfg.rtFilter.dpc     = rtKey->dpc;
         cfg.rtFilter.dpcMask = dpcMask;
         (Void) itAtCfgRout(&cfg, &sta, FALSE);
   /* Route creation updated at standby nodes */   
   /* Original Function (itLiSctDatInd) from where this function is called is
      taking care of ITZVUPDPEER etc macros */
#ifdef ZV
          cmMemcpy((U8 *)&updArgs.p.rteUpd.rteCfg,
                                      (U8 *)&cfg, sizeof(ItRteCfg));
          zvRTUpd(CMPFTHA_ACTN_ADD, ZV_RTECB,
                    CMPFTHA_UPDTYPE_SYNC, (Void *) NULLP, &updArgs);
#endif
      }
   } /* End of nmbSi = 0 */

   done = FALSE;
   /* nmbSi >= 1 */
   for (i = 0; i < rtKey->nmbSio; i++)
   {
      cmMemset((U8 *)&cfg.rtFilter, 0, sizeof(ItRtFilter)); 
      cfg.rtFilter.dpc     = rtKey->dpc;
      cfg.rtFilter.dpcMask = dpcMask;
      cfg.rtFilter.sioMask = 0x0F;
      cfg.rtFilter.sio     = rtKey->sio[i];

      for (j = 0; j < rtKey->nmbOpc; j++)
      {
         cfg.rtFilter.opcMask = dpcMask;
         cfg.rtFilter.opc     = rtKey->opc[j];
         cfg.rtFilter.includeSsn = FALSE;

         cfg.rtFilter.includeCic = FALSE;
         for (k = 0; k < rtKey->nmbCic; k++)
         {
            cfg.rtFilter.opc      = rtKey->cicRange[k].opc;
            cfg.rtFilter.opcMask  = dpcMask;
            cfg.rtFilter.includeCic = TRUE;
            cfg.rtFilter.cicStart = rtKey->cicRange[k].cicStart;
            cfg.rtFilter.cicEnd   = rtKey->cicRange[k].cicEnd;
            (Void) itAtCfgRout(&cfg, &sta, FALSE);
   /* Route creation updated at standby nodes */   
#ifdef ZV
            cmMemcpy((U8 *)&updArgs.p.rteUpd.rteCfg, (U8 *)&cfg, 
                                                   sizeof(ItRteCfg));
            zvRTUpd(CMPFTHA_ACTN_ADD, ZV_RTECB,
                    CMPFTHA_UPDTYPE_SYNC, (Void *) NULLP, &updArgs);
#endif
            done = TRUE;
         } /* End of cicRngLst */

         /* The case when nmbCic = 0,  and nmbSio = 1, is
          *  handled here */
         if (done == FALSE)
         {
            (Void) itAtCfgRout(&cfg, &sta, FALSE);
   /* Route creation updated at standby nodes */   
#ifdef ZV
            cmMemcpy((U8 *)&updArgs.p.rteUpd.rteCfg, (U8 *)&cfg, 
                                                   sizeof(ItRteCfg));
            zvRTUpd(CMPFTHA_ACTN_ADD, ZV_RTECB,
                    CMPFTHA_UPDTYPE_SYNC, (Void *) NULLP, &updArgs);
#endif
            done = TRUE;
         }
      } /* End of OPC */
      
      /* nmbOpc == 0 case is handled here */
      if (done == FALSE)
      {
          /*  changes done for avoiding CIC
             overlap issue while configuring 2nd route
             with same CICs */
          cfg.rtFilter.includeCic = FALSE;
          cfg.rtFilter.includeSsn = FALSE;
          for (k = 0; k < rtKey->nmbCic; k++)
          {
             cfg.rtFilter.opc      = rtKey->cicRange[k].opc;
             cfg.rtFilter.opcMask  = dpcMask;
             cfg.rtFilter.dpcMask  = dpcMask;
             cfg.rtFilter.includeCic = TRUE;
             cfg.rtFilter.cicStart = rtKey->cicRange[k].cicStart;
             cfg.rtFilter.cicEnd   = rtKey->cicRange[k].cicEnd;
             (Void) itAtCfgRout(&cfg, &sta, FALSE);
   /* Route creation updated at standby nodes */   
#ifdef ZV
            cmMemcpy((U8 *)&updArgs.p.rteUpd.rteCfg, (U8 *)&cfg, 
                                                   sizeof(ItRteCfg));
            zvRTUpd(CMPFTHA_ACTN_ADD, ZV_RTECB,
                    CMPFTHA_UPDTYPE_SYNC, (Void *) NULLP, &updArgs);
#endif
             done = TRUE;
          } /* End of cicRngLst */
          if (done == FALSE)
          {
   /* Route creation updated at standby nodes */   
#ifdef ZV
            cmMemcpy((U8 *)&updArgs.p.rteUpd.rteCfg, (U8 *)&cfg, 
                                                   sizeof(ItRteCfg));
            zvRTUpd(CMPFTHA_ACTN_ADD, ZV_RTECB,
                    CMPFTHA_UPDTYPE_SYNC, (Void *) NULLP, &updArgs);
#endif
            (Void) itAtCfgRout(&cfg, &sta, FALSE);
          }
      }
   } /* End of SI */


   /* Get the new Routing Context and update it in psCb */

   psCb->psSta.psStaEndp[suId].nmbPspReg++;
   psCb->psSta.psStaEndp[suId].rteCtx[pspId].rcValid = TRUE;
   psCb->psSta.psStaEndp[suId].rteCtx[pspId].mode |= IT_RC_DYNAMIC_REGD;
   /* Allocate the new rCtx from the free list */
   (Void ) itAtGetNewRctx(&rCtx, assocCb->assocId);
   /* itGlobalCb.rCtx is sync'ed inside itAtGetNewRctx to reduce
   chances of skipping it's update to shadow (standbys) */

   psCb->psSta.psStaEndp[suId].rteCtx[pspId].rCtx = rCtx;

   /* Increment the number of PSs registered with the assoc */
   assocCb->assocSta->regPs[assocCb->assocSta->nmbRegPs] = psCb->psCfg.psId;
   assocCb->assocSta->nmbRegPs++;

#ifdef ZV
   /* it018.106 - addition - updating table type ZV_PSP_REGPS */
   {
      updArgs.p.pspPsUpd.pspIdx = IT_ASSOC2PSPID(assocCb->assocId);
      updArgs.p.pspPsUpd.endp = IT_ASSOC2SUID(assocCb->assocId);
      updArgs.p.pspPsUpd.slNo = assocCb->assocSta->nmbRegPs - 1;
      
      zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSP_REGPS,
              CMPFTHA_UPDTYPE_SYNC, (Void *) NULLP, &updArgs);

      zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSPCB,
              CMPFTHA_UPDTYPE_SYNC, (Void *)assocCb->owner, NULLP);
      zvRTUpd(CMPFTHA_ACTN_ADD, ZV_PSCB,
              CMPFTHA_UPDTYPE_SYNC, (Void *)psCb, NULLP);
      
      updArgs.p.psEndpUpd.endp = suId;
      updArgs.p.psEndpUpd.slno = pspId;
      zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PS_ENDP_RCTX,
              CMPFTHA_UPDTYPE_SYNC, (Void *) psCb, &updArgs);
   }
#endif
  /* Indicate it to LM */
   IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))                           
   itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP;             
   itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_CNTRL;
   itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_RK_REGISTERED;  
   itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_MSG_RECEIVED;
   itGlobalCb.mgmt.t.usta.t.drkmEvt.rteCtx = rCtx;
   itGlobalCb.mgmt.t.usta.t.drkmEvt.lclRkId = localRkId; 
   itGlobalCb.mgmt.t.usta.t.drkmEvt.psId    = psCb->psCfg.psId;
   itGlobalCb.mgmt.t.usta.t.drkmEvt.sctSuId  = IT_ASSOC2SUID(assocCb->assocId);
   cmMemcpy((U8 *) &itGlobalCb.mgmt.t.usta.t.drkmEvt.rtKey, 
                   (U8 *)rtKey, sizeof(ItRoutKey));
   itGlobalCb.mgmt.t.usta.s.pspId         = assocCb->owner->pspCfg.pspId;

   (Void) itMiStaIndM(&itGlobalCb.mgmt);                      
   /* Since PS has become inactive, a notify message is sent to peer */
   locRtCtx.rtCtx     = rCtx;
   locRtCtx.ntfySend  = TRUE;
   locRtCtx.ntfyStaId = IT_M3UA_NTFY_INFO_AS_INACTIVE;
   /* Initialize aspIdPres and aspId */
   aspIdPres = FALSE;
   aspId     = 0;
   /* it016.106 - Changes to make storing of ASPID optional
    * when rxTxAspId is FALSE. So, even if rxTxAspId is FALSE 
    * send ASPID, if available. */
   if (itGlobalCb.aspIdCb.aspIdValid[pspId] == TRUE)
   {
      aspId = itGlobalCb.aspIdCb.aspIdLst[pspId];
      aspIdPres = TRUE;
   }
   /* it001.106 : modifications : NTFY is sent after Reg Rsp message */
   if ((ret = itMmhRegRsp(assocCb, IT_RK_SUCC_REGD, rCtx, localRkId)) != ROK)
   {
      RETVALUE(ret);
   }
   (Void) itMmhNotify(assocCb,
                      (Txt *)NULLP, 
                      &locRtCtx, 1, 
                      IT_M3UA_NTFY_TYPE_ASCHG, aspIdPres, aspId);
   
   /* Send the successful REG RSP */
   RETVALUE(ROK);
} /* End of itAtCreateNewRk */

/*
*
*       Fun:   itAtCreateNewPsInfo
*
*       Desc:  This function is called to fill the PS related info for
*       dynamically created PS.
*    
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/

#ifdef ANSI
PRIVATE S16 itAtCreateNewPsInfo
(
ItAssocCb *assocCb,        /* Assoc CB     */
ItPsCfg   *psCfg,          /* PS Config    */
ItPsId    psId,            /* PS ID        */
U8        nwkId,           /* Nwk Id       */
U32       mode             /* mode         */
)
#else
PRIVATE S16 itAtCreateNewPsInfo(assocCb, psCfg, psId, nwkId, mode)
ItAssocCb *assocCb;        /* Assoc CB     */
ItPsCfg   *psCfg;          /* PS Config    */
ItPsId    psId;            /* PS ID        */
U8        nwkId;           /* Nwk Id       */
U32       mode;            /* mode         */
#endif
{
   TRC2(itAtCreateNewPsInfo)
   
   psCfg->nwkId        = nwkId;
   psCfg->psId         = psId;
   psCfg->mode         = (U8)mode;
   if (psCfg->mode == LIT_MODE_LOADSHARE)
   {
      psCfg->loadShareMode = assocCb->owner->pspCfg.dfltLshareMode;
   }
   /* This PS will not determine the overall state of the dpc */
   psCfg->reqAvail = FALSE;
   psCfg->nmbActPspReqd = 1;
   psCfg->nmbPsp  = 1;
   psCfg->lclFlag = FALSE;
   psCfg->psp[0] = assocCb->owner->pspCfg.pspId;
   RETVALUE(ROK);
} /* End of itAtCreateNewPsInfo */

#ifdef ITASP
/*
*
*       Fun:   itAtRegRsp
*
*       Desc:  This function is called by MMH on receiving REG RSP from peer
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtRegRsp
(
ItAssocCb  *assocCb,          /* Assoc CB            */
U32        localRkId,         /* Local RK id         */
U32        regStat,           /* Registration Status */
U32        routeCtx           /* Routing Context     */
)
#else
PUBLIC S16 itAtRegRsp(assocCb, localRkId, regStat, routeCtx)
ItAssocCb  *assocCb;         /* Assoc CB            */
U32        localRkId;        /* Local RK id         */
U32        regStat;          /* Registration Status */
U32        routeCtx;         /* Routing Context     */
#endif
{
   ItPsCb        *psCb = (ItPsCb *)NULLP;  /* PS control block */ 
   ItPspCb       *pspCb;      /* psp control Block */
   ItRegReqCb    *curRkrCb;    /* RKR control block */
   ItRegReqTmrCb *regReqTmrCb;   /* RKRTCB ptr */
   Bool          done;        /* Boolean Flag */
   U16           cause;       /* Reg Rsp Failure/Success Cause */
   SuId          suId;        /* SCT SAP id of association */
#ifdef ZV
   /* it018.106 - addition - DFTHA Enhancement */
   ZvUpdSpecParams updArgs;
#endif /* ZV */

   TRC2(itAtRegRsp)

   cause = LCM_CAUSE_UNKNOWN;
   curRkrCb = (ItRegReqCb *) NULLP;
   /* if regStat is not- successful then indicate to LM */
   pspCb = assocCb->owner;
   /* Search the PRKTCB, if not found no action is taken */
   suId = IT_ASSOC2SUID(assocCb->assocId);
   if (assocCb->regReqTmrCb[0].req.regReq.nmbLclRkId == 0)
   {
      /* Send an indication to LM that unexpected msg received */
      IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
      itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
      itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_CNTRL; 
      itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_REG_FAILURE; 
      itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_UNEXP_MSG;
      itGlobalCb.mgmt.t.usta.t.drkmEvt.lclRkId = localRkId;
      itGlobalCb.mgmt.t.usta.t.drkmEvt.sctSuId = suId;
      itGlobalCb.mgmt.t.usta.s.pspId         = pspCb->pspCfg.pspId;
   
      (Void) itMiStaIndM(&itGlobalCb.mgmt); 
      RETVALUE(RFAILED);
   }
   else
   {
      regReqTmrCb = (ItRegReqTmrCb *)&assocCb->regReqTmrCb[0];
   }
   if (regStat != IT_RK_SUCC_REGD)
   {
      /* indicate to LM */
      switch (regStat)
      {
         case IT_RK_UNKNOWN:
            cause = LCM_CAUSE_UNKNOWN;
            break;
         case IT_RK_INV_DPC:
            cause = LIT_CAUSE_INV_DPC;
            break;
         case IT_RK_INV_NWK_APP:
            cause = LIT_CAUSE_INV_NWK_APP;
            break;
         case IT_INV_RK:
            cause = LIT_CAUSE_INV_RK;
            break;
         case IT_PERM_DENIED:
            cause = LIT_CAUSE_RKM_PER_DENIED;
            break;
         case IT_CANT_SUPP_UNIQ_RK:
            cause = LIT_CAUSE_OVERLAP_RK;
            break;
         case IT_RK_NOT_PROVISION:
            cause = LIT_CAUSE_RK_NOT_PRVISONED;
            break;
         case IT_RK_INSUF_RSRCS:
            cause = LIT_CAUSE_INSF_RSRC;
            break;
         case IT_RK_UNSPP_PRMTR:
            cause = LIT_CAUSE_UNSUPP_RK_PRMTR;
            break;
         case IT_RK_UNSPP_THM:
            cause = LIT_CAUSE_INV_TRAFFIC_MODE;
            break;

         default:
            break;
      }
      /* Send Status Indication to Layer Management */                    
      IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))                          
      itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP;                  
      itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_CNTRL;      
      itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_REG_FAILURE;        
      itGlobalCb.mgmt.t.usta.alarm.cause     = cause;   
      itGlobalCb.mgmt.t.usta.t.drkmEvt.lclRkId = localRkId;
      itGlobalCb.mgmt.t.usta.t.drkmEvt.sctSuId =  suId;
      itGlobalCb.mgmt.t.usta.s.pspId         = pspCb->pspCfg.pspId;

      (Void) itMiStaIndM(&itGlobalCb.mgmt);                            

      /* Delete the RKRKTCB & corresponding RKRCB */ 
      regReqTmrCb->rspPend = FALSE;
      /* return value is RFAILED in case of rkrcb is not found */
      RETVALUE(itAtDelRkrNRkrtcb(regReqTmrCb, FALSE, localRkId));
   }
   /* Search the RKRCB list of PSP */
   /* Init list to first element */

   cmLListFirst(&(assocCb->regReq));
   done = FALSE;
   /* search all RKRCB for localRkId match */
   while (((curRkrCb = (ItRegReqCb *)cmLListCrnt(&(assocCb->regReq))) != NULLP)
                   && (done == FALSE))
   {
      if (curRkrCb->localRkId == localRkId)
      {
         done = TRUE;
      }
      if (done == FALSE)
      {
         cmLListNext(&(assocCb->regReq));
      }
   }
   if (done != TRUE)
   {
      /* LocalRkId received in REG RSP is not found in RKRCB */
      IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))                          
      itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP;                  
      itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_CNTRL;      
      itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_INV_LCLRKID;        
      itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_MSG_RECEIVED;
      itGlobalCb.mgmt.t.usta.t.drkmEvt.rteCtx = routeCtx;
      itGlobalCb.mgmt.t.usta.t.drkmEvt.lclRkId = localRkId;
      itGlobalCb.mgmt.t.usta.t.drkmEvt.sctSuId = suId;
      itGlobalCb.mgmt.t.usta.s.pspId         = pspCb->pspCfg.pspId;

      (Void) itMiStaIndM(&itGlobalCb.mgmt);                 

      RETVALUE(RFAILED);
   }
   else
   {
      /* Update the PSCB */
      if ((psCb = itPsmFindPs(curRkrCb->psId)) != (ItPsCb *) NULLP)
      {
         ItPsCfg  psCfg;  /* PS Cfg info */
         CmStatus sta;    /* Return status used for itPsmCfgPs */
         U16      j;      /* Loop Index */
        
         psCb->psSta.psStaEndp[suId].nmbPspReg++;
         psCb->psSta.psStaEndp[suId].rteCtx[pspCb->pspCfg.pspId].rCtx =
                                                                       routeCtx;
         psCb->psSta.psStaEndp[suId].rteCtx[pspCb->pspCfg.pspId].mode |= 
                                                       IT_RC_DYNAMIC_REGD;
         psCb->psSta.psStaEndp[suId].rteCtx[pspCb->pspCfg.pspId].rcValid = TRUE;

#ifdef ZV
         /* it018.106 - addition - DFTHA Enhancement Updating tabletype 
            ZV_PS_ENDP_RCTX*/
         updArgs.p.psEndpUpd.endp = suId;
         updArgs.p.psEndpUpd.slno = pspCb->pspCfg.pspId;
         zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PS_ENDP_RCTX,
                 CMPFTHA_UPDTYPE_SYNC, (Void *) psCb, &updArgs);
#endif /* ZV */

         /* Update the psCb->psCfg and psCb->psSta.asSt on receiving the 
          * REG RSP from server */
         /* PSP is added only if its not already part of ps list */
         for (j = 0; j < psCb->psCfg.nmbPsp; j++)
         {
           if (psCb->psCfg.psp[j] == assocCb->owner->pspCfg.pspId)
           {
              break;
           }
         }
         if (j == psCb->psCfg.nmbPsp)
         {
            psCb->psCfg.psp[psCb->psCfg.nmbPsp] = 
                                        assocCb->owner->pspCfg.pspId;
            psCb->psCfg.nmbPsp++;
         }
               
         cmMemcpy((U8 *)&psCfg,(U8 *)&(psCb->psCfg), sizeof(ItPsCfg));
         /* This is a similar case to reconf of PS */
         (Void) itPsmCfgPs(&psCfg, &sta, IT_PS_CFG_DYN);
         /* Indicate it to LM */
         IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))                           
         itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP;             
         itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_CNTRL;
         itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_RK_REGISTERED;  
         itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_MSG_RECEIVED;
         itGlobalCb.mgmt.t.usta.t.drkmEvt.rteCtx = routeCtx;
         itGlobalCb.mgmt.t.usta.t.drkmEvt.lclRkId = localRkId; 
         itGlobalCb.mgmt.t.usta.t.drkmEvt.sctSuId = suId;
         itGlobalCb.mgmt.t.usta.t.drkmEvt.psId    = psCb->psCfg.psId;
         cmMemcpy((U8 *) &itGlobalCb.mgmt.t.usta.t.drkmEvt.rtKey, 
                      (U8 *)&curRkrCb->rtKey, 
                      sizeof(ItRoutKey));
         itGlobalCb.mgmt.t.usta.s.pspId         = pspCb->pspCfg.pspId;
                                                                      
         (Void) itMiStaIndM(&itGlobalCb.mgmt);                      


         /* increment no of PSs registered dynamically to this PSP */
         assocCb->assocSta->regPs[assocCb->assocSta->nmbRegPs] = curRkrCb->psId;
         assocCb->assocSta->nmbRegPs++;

         /* Update RKRTCB and RKRCB */
         if (regReqTmrCb->req.regReq.nmbLclRkId == 0)
         {
            /*  this is an unexpected event */
            /* Delete the RKRCB */
            itAtDelRkrNRkrtcb(regReqTmrCb, FALSE, localRkId);
            RETVALUE(RFAILED);
         }
         regReqTmrCb->rspPend = FALSE;

         /* Delete the RKRCB */
         itAtDelRkrNRkrtcb(regReqTmrCb, FALSE, localRkId);

#ifdef ZV
         /* it018.106 - addition - updating table type ZV_PSP_REGPS */
         updArgs.p.pspPsUpd.pspIdx = IT_ASSOC2PSPID(assocCb->assocId);
         updArgs.p.pspPsUpd.endp = IT_ASSOC2SUID(assocCb->assocId);
         updArgs.p.pspPsUpd.slNo = assocCb->assocSta->nmbRegPs - 1;
         
         zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSP_REGPS,
                 CMPFTHA_UPDTYPE_SYNC, (Void *) NULLP, &updArgs);
         
         zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSPCB,
                 CMPFTHA_UPDTYPE_SYNC, (Void *)assocCb->owner, NULLP);
         
         /* it018.106 - addition - updating table type ZV_PS_CFGCB */
         zvRTUpd(CMPFTHA_ACTN_ADD, ZV_PS_CFGCB,
                 CMPFTHA_UPDTYPE_SYNC, (Void *) psCb, NULLP);
         
         zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSCB,
                   CMPFTHA_UPDTYPE_SYNC, (Void *)psCb, NULLP);
#endif

      }  /* End of PSCB != NULLP */
      else  /* PSCB is not found */
      {
         IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))                           
         /* Send status indication to notify LM that PS is deleted before
          * waiting for REG RSP */
         itMiStaInd(STITPS, LIT_CATEGORY_STATUS, LIT_EVENT_PS_DELETED,
                    LIT_CAUSE_PS_DELETED, (U32)curRkrCb->psId);
         /* Delete the RKRCB */
         itAtDelRkrNRkrtcb(regReqTmrCb, FALSE, localRkId);

         RETVALUE(RFAILED);
      } /* End of PSCB == NULLP */ 
   } /* End of done == TRUE */
   /* increment the number of rk registered */
   itGlobalCb.addrTrn.rkSta.nmbRkReg++;
   RETVALUE(ROK);
} /* End of itAtRegRsp */

/*
*
*       Fun:   itAtRkmTimeout
*
*       Desc:  This function is called on expiry of RKM timer.
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtRkmTimeout
(
ItRegReqTmrCb     *regReqTmrCb       /* Registration Request CB */
)
#else
PUBLIC S16 itAtRkmTimeout(regReqTmrCb)
ItRegReqTmrCb     *regReqTmrCb;       /* Registration Request CB */
#endif
{
   Buffer     *mBuf;      /* message buffer */
   Buffer     *tmpMBuf;    /* message buffer */
   ItAssocCb  *assocCb;   /* assoc CB */
   UConnId     assocId;   /* Assoc Id */
   ItRegReqCb *regReqCb;  /* Reg Req control block */
   S16         ret;       /* Return Value */

   TRC2(itAtRkmTimeout)
   
   assocId = regReqTmrCb->assocId;
   assocCb = itGlobalCb.assoc[assocId];

   if ((ret = SGetMsg(assocCb->sctSap->sctCfg.mem.region,
            assocCb->sctSap->sctCfg.mem.pool, &mBuf)) != ROK)
   {
      itMiStaInd(STITGEN, LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
           LCM_CAUSE_MEM_ALLOC_FAIL, 0);
      itAtDelRkrNRkrtcb(regReqTmrCb, TRUE, (U32)0); 
      RETVALUE(ret);
   }

   if ((ret = SGetMsg(assocCb->sctSap->sctCfg.mem.region,
            assocCb->sctSap->sctCfg.mem.pool, &tmpMBuf)) != ROK)
   {
       IT_DROPDATA(mBuf);
       itMiStaInd(STITGEN, LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                  LCM_CAUSE_MEM_ALLOC_FAIL, 0);
       itAtDelRkrNRkrtcb(regReqTmrCb, TRUE, (U32)0); 
       RETVALUE(ret);
   }
   regReqTmrCb->reqCntr++;
   if (regReqTmrCb->reqCntr < itGlobalCb.genCfg.tmr.maxNmbRkTry)
   {
         /* Send the msg again to the peer */
      if (regReqTmrCb->rspPend == TRUE)  
      {
         if (regReqTmrCb->reqType == LIT_REG_REQ)                               
         {                                                                     
            ItPsCb *tmpPsCb = (ItPsCb *)NULLP; /* Temp PS CB to access nwkId */
            /* send REG REQ to peer */                                     
            for (regReqCb = (ItRegReqCb *)cmLListFirst((&assocCb->regReq));   
                 regReqCb != NULLP;                                            
                 regReqCb = (ItRegReqCb *)cmLListNext(&(assocCb->regReq)))  
            {                                                                  
               S16    tag;
               U16    tmp16;
               U8     hdr[4];
               MsgLen len;
               len = 0;

               tmpPsCb = itPsmFindPs(regReqCb->psId);
              
               ret = itMmhCodeRk(assocCb, regReqCb->localRkId, regReqCb->mode,
                               &regReqCb->rtKey, 
                               tmpPsCb->nwk->nwkCfg.nwkId,
                               &tmpMBuf);  
              if (ret != ROK)
              {
                 IT_DROPDATA(tmpMBuf);
                 IT_DROPDATA(mBuf);
                 itAtDelRkrNRkrtcb(regReqTmrCb, TRUE, (U32)0); 
                 RETVALUE(ret);
              }
              /* SAddPreMsgMult works in reverse, so build the tag backward */
              (Void) SFndLenMsg(tmpMBuf, &len);
              tag = IT_M3UA_TAG_RK;
              hdr[3]   = (U8) GetHiByte(tag); /* RK Tag */
              hdr[2]   = (U8) GetLoByte(tag); /* RK Tag */

              tmp16    = (U16)((U16)len + 4); 
              hdr[1]   = (U8) GetHiByte(tmp16);
              hdr[0]   = (U8) GetLoByte(tmp16);
              if ((ret = SAddPreMsgMult((Data *)hdr, 4, tmpMBuf)) != ROK)
              {
                 IT_DROPDATA(tmpMBuf);
                 IT_DROPDATA(mBuf);
                 itAtDelRkrNRkrtcb(regReqTmrCb, TRUE, (U32)0); 
                 RETVALUE(ret);
              }
              SCatMsg(mBuf, tmpMBuf, M1M2);
            }                                                                  
            if ((ret = itMmhHdrSend(assocCb, &mBuf,                        
                                    IT_RKM_REGREQ,                             
                                    IT_M3UA_MGMT_STREAM)) != ROK)              
            {                                                                  
               IT_DROPDATA(mBuf);
               IT_DROPDATA(tmpMBuf);
               itAtDelRkrNRkrtcb(regReqTmrCb, TRUE, (U32)0); 
               RETVALUE(ret);                                                  
            }                                                                  
         } /* reqType is REG REQ */                                            
         else                                                                  
         {                                                                     
            IT_DROPDATA(mBuf);
            IT_DROPDATA(tmpMBuf);
            /* Send DREG REQ again */                                          
            if ((ret = itMmhDeRegReq(assocCb,
                                    &(assocCb->regReqTmrCb[1]))) != ROK); 
            {                                                                  
               RETVALUE(ret);                                                  
            }                                                                  
         }                                                                     
      }
      itTcStartTimer(&(regReqTmrCb->tmrRegReq), 
                        (PTR) (regReqTmrCb),
                        IT_TMR_RKM,
                        &itGlobalCb.genCfg.tmr.tmrDrkm);
   }
   else
   {
      if (regReqTmrCb->rspPend == TRUE)
      {
        /* Indicate to layer manager that no response has been 
         * received */
         IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
         itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
         itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_CNTRL; 
 
         if (regReqTmrCb->reqType == LIT_REG_REQ)
         {
            itGlobalCb.mgmt.t.usta.alarm.cause    =  LIT_CAUSE_RK_REG_NO_RESP; 
            itGlobalCb.mgmt.t.usta.alarm.event    =  LIT_EVENT_RK_TMOUT;
         }
         else
         {
           itGlobalCb.mgmt.t.usta.alarm.cause    =  LIT_CAUSE_RK_DEREG_NO_RESP; 
           itGlobalCb.mgmt.t.usta.alarm.event    =  LIT_EVENT_RK_TMOUT; 
         }
         itGlobalCb.mgmt.t.usta.s.pspId       = assocCb->owner->pspCfg.pspId;
         itGlobalCb.mgmt.t.usta.t.drkmEvt.sctSuId = IT_ASSOC2SUID(assocId);

         (Void) itMiStaIndM(&itGlobalCb.mgmt);
      }
      else
      {
         /* Indicate to layer manager that response has not been 
          * received for all the request messages */

         IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
         itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
         itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_CNTRL; 

         if (regReqTmrCb->reqType == LIT_REG_REQ)
         {
            itGlobalCb.mgmt.t.usta.alarm.cause =  LIT_CAUSE_RK_REG_PARTIAL_RESP;
            itGlobalCb.mgmt.t.usta.alarm.event =  LIT_EVENT_RK_TMOUT;
         }
         else
         {
            itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_RK_DEREG_PARTIAL_RESP;
            itGlobalCb.mgmt.t.usta.alarm.event = LIT_EVENT_RK_TMOUT; 
         }
         itGlobalCb.mgmt.t.usta.s.pspId       = assocCb->owner->pspCfg.pspId;
         itGlobalCb.mgmt.t.usta.t.drkmEvt.sctSuId = IT_ASSOC2SUID(assocId);

         (Void) itMiStaIndM(&itGlobalCb.mgmt);
      }
      itAtDelRkrNRkrtcb(regReqTmrCb, TRUE, (U32)0); 
      IT_DROPDATA(mBuf);
      IT_DROPDATA(tmpMBuf);
      RETVALUE(ROK);
   } 

   IT_DROPDATA(tmpMBuf);
   RETVALUE(ROK);
} /* End of itAtRkmTimeout */

/*
*
*       Fun:   itAtDelRkrNRkrtCb
*
*       Desc:  This function is called to delete the entries of RKRCB and
*       update the RKRTCB also stop the RK-timer if all requests has been
*       received.
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/

#ifdef ANSI
PRIVATE S16 itAtDelRkrNRkrtcb
(
ItRegReqTmrCb     *regReqTmrCb, /* Registration Timer CB */
Bool               delAll,      /* Delete All entries    */
U32                searchId     /* Id to be deleted      */
)
#else
PRIVATE S16 itAtDelRkrNRkrtcb(regReqTmrCb, delAll, searchId)
ItRegReqTmrCb     *regReqTmrCb; /* Registration Timer CB */
Bool               delAll;      /* Delete All entries    */
U32                searchId;    /* Id to be deleted      */
#endif
{
   U32        lclRkId;          /* local RK Identifier */
   ItRegReqCb *regReqCb;        /* Registration request control block */
   U32        i;                /* loop Counter */
   U32        k;                /* loop Index */
   U32        j;                /* loop Index */
   ItAssocCb  *assocCb;         /* assoc control block ptr */

   TRC2(itAtDelRkrNRkrtcb)
   
   assocCb = itGlobalCb.assoc[regReqTmrCb->assocId];
   regReqCb = (ItRegReqCb *) NULLP;

   if (regReqTmrCb->reqType == LIT_REG_REQ)
   {
      if (delAll == FALSE)
      {
         if (itAtFindRkrCb(assocCb, searchId, &regReqCb) == ROK)
         {
            cmLListDelFrm(&assocCb->regReq, &regReqCb->node);
            IT_FREE(sizeof(ItRegReqCb), regReqCb);
            /* update the RKRTCB */
            /* Delete the localRkId from the list */
            for (j = 0; j < regReqTmrCb->req.regReq.nmbLclRkId; j++)
            {
               if (regReqTmrCb->req.regReq.localRkId[j] == searchId)
               {
                  for (k = j; k < (regReqTmrCb->req.regReq.nmbLclRkId - 1); k++)
                  {
                     regReqTmrCb->req.regReq.localRkId[k] = 
                                   regReqTmrCb->req.regReq.localRkId[k+1];
                  }
                  break;
               }
            }
            regReqTmrCb->req.regReq.nmbLclRkId--; 
            if (regReqTmrCb->req.regReq.nmbLclRkId == 0)
            {
               /* intialize all localRkId value to zero */
               cmMemset((U8 *)regReqTmrCb->req.regReq.localRkId, 0, 
                         (sizeof(U32) * LIT_MAX_RK_IN_DRKM));
            
               /* Stop the timer */
               itTcStopTimer(&regReqTmrCb->tmrRegReq);
            }
         }
         else
         {
            /* Stop the timer */
            itTcStopTimer(&regReqTmrCb->tmrRegReq);
            RETVALUE(RFAILED); 
         }
      }
      else /* delAll == TRUE */
      {
         for (i = 0; i < regReqTmrCb->req.regReq.nmbLclRkId; i++)
         {
            lclRkId  = regReqTmrCb->req.regReq.localRkId[i];
            if (itAtFindRkrCb(assocCb, lclRkId, &regReqCb) != ROK)
            {
               continue;
            }
            else
            {
               cmLListDelFrm(&assocCb->regReq, &regReqCb->node);
               IT_FREE(sizeof(ItRegReqCb), regReqCb);
            }
         } 
         cmMemset((U8 *)regReqTmrCb->req.regReq.localRkId, 0, 
                         (sizeof(U32) * LIT_MAX_RK_IN_DRKM));
         regReqTmrCb->req.regReq.nmbLclRkId = 0;
         /* Stop the timer */
         itTcStopTimer(&regReqTmrCb->tmrRegReq);
      } /* End of delAll == TRUE */
   } /* End of reqType == REG REQ */
   else /* reqType is DEREG REQ */
   { 
      if (delAll == FALSE)
      {
         /* update the RKRTCB */
         /* Delete the routCtx from the list */
         for (j = 0; j < regReqTmrCb->req.deRegReq.nmbRctx; j++)
         {
            if (regReqTmrCb->req.deRegReq.rCtx[j].routCntx == searchId)
            {
               for (k = j; k < (regReqTmrCb->req.deRegReq.nmbRctx - 1); k++)
               {
                  regReqTmrCb->req.deRegReq.rCtx[k].routCntx = 
                                   regReqTmrCb->req.deRegReq.rCtx[k+1].routCntx;
                  regReqTmrCb->req.deRegReq.rCtx[k].psId = 
                                   regReqTmrCb->req.deRegReq.rCtx[k+1].psId;
               }
               break;
            }
         }
         regReqTmrCb->req.deRegReq.nmbRctx--; 
      }
      if ((regReqTmrCb->req.deRegReq.nmbRctx == 0) || (delAll == TRUE))
      {
         for (i = 0; i < LIT_MAX_RC_IN_DRKM; i++)
         {
            regReqTmrCb->req.deRegReq.rCtx[i].psId     = 0; 
            regReqTmrCb->req.deRegReq.rCtx[i].routCntx = 0; 
         } 
         /* Stop the timer */
         itTcStopTimer(&regReqTmrCb->tmrRegReq);
         regReqTmrCb->req.deRegReq.nmbRctx = 0;
      } /* End of delAll == TRUE OR nmbRctx == 0 */
   } /* DEREG REQ */
   RETVALUE(ROK);
} /* End of itAtDelRkrNRkrtcb */

/*
*
*       Fun:   itAtSendRkDeRegReq
*
*       Desc:  This function is called by MIF to send the REG REQ
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtSendRkDeRegReq
(
ItCntrl  *cntrl,              /* Control  */
CmStatus *sta                 /* Status   */
)
#else
PUBLIC S16 itAtSendRkDeRegReq(cntrl, sta)
ItCntrl  *cntrl;              /* Control  */
CmStatus *sta;                /* Status   */
#endif
{
   ItPspCb     *pspCb;        /* PSP to which message is to be sent */
   ItPsCb      *psCb = (ItPsCb *)NULLP; /* PS control block */
   S16          ret;          /* Return value */
   U16          i;            /* loop Counter */
   ItAssocCb    *assocCb;     /* Association control block */

   TRC2(itAtSendRkDeRegReq)

   ret = RFAILED;

   pspCb = itGlobalCb.psp[cntrl->s.pspId];
   if (pspCb == (ItPspCb *) NULLP)
   {
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_INVALID_PSPID;
      RETVALUE(RFAILED);
   }

   if (pspCb->pspCfg.pspType == LIT_PSPTYPE_ASP)
   {
      /* wrong pspType */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_INV_PEERTYPE;
      RETVALUE(RFAILED);
   }
   assocCb = itGlobalCb.assoc[IT_PSPnENDP2ASSOC(pspCb->pspCfg.pspId, 
                                   cntrl->t.dynRteKey.sctSuId)];

   /* Verify PsId and RCtx Received in control request */
   for (i = 0; i < cntrl->t.dynRteKey.rkm.rC.nmbRCtx; i++)
   {
      if ((psCb = itPsmFindPs(cntrl->t.dynRteKey.rkm.rC.rteCtxLst[i].psId))
                  == NULLP)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LIT_REASON_INVALID_PSID;
         RETVALUE(RFAILED);
      }
      /* The rcValid should be TRUE and match with stored rCtx */
      if (psCb->psSta.psStaEndp[cntrl->t.dynRteKey.sctSuId].\
                              rteCtx[pspCb->pspCfg.pspId].rcValid != TRUE) 
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LIT_REASON_INVALID_RC;
         RETVALUE(RFAILED);
      }
      if (psCb->psSta.psStaEndp[cntrl->t.dynRteKey.sctSuId].\
                                aspSt[pspCb->pspCfg.pspId] != LIT_ASP_INACTIVE) 
      {
         /*  cannot send REG REQ in DOWN state */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LIT_REASON_INV_PEER_STATE;
         RETVALUE(RFAILED);
      }
   }
   /* Create RKRTCB */
   if ((ret == itAtCreateRkrtCb(cntrl, assocCb,(U32 *) NULLP, LIT_DEREG_REQ))
                                                                  != ROK)
   {
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_RKDEREGREQ_PEND;
      RETVALUE(RFAILED); 
   }
   
   /* send DEREG REQ to peer */
   ret = itMmhDeRegReq(assocCb, (ItRegReqTmrCb *)&(assocCb->regReqTmrCb[1]));
  
   if (ret != ROK)
   {
      assocCb->regReqTmrCb[1].req.deRegReq.nmbRctx = 0;
      /* set the values to 0 */
      for (i = 0; i < LIT_MAX_RC_IN_DRKM; i++)
      {
         assocCb->regReqTmrCb[1].req.deRegReq.rCtx[i].psId = 0;
         assocCb->regReqTmrCb[1].req.deRegReq.rCtx[i].routCntx = 0;
      }
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_MSG_NOT_SENT;
      RETVALUE(RFAILED);
   }
   else
   {
      /* Start the timer */
      itTcStartTimer(&assocCb->regReqTmrCb[1].tmrRegReq, 
                           (PTR) &(assocCb->regReqTmrCb[1]),
                           IT_TMR_RKM,
                           &itGlobalCb.genCfg.tmr.tmrDrkm);

      sta->status = LCM_PRIM_OK;
      sta->reason = LCM_REASON_NOT_APPL;
      RETVALUE(ROK);
   }

} /* End of itAtSendRkDeRegReq */
#endif /*  ITASP */

/*
*
*       Fun:   itAtVerifyRc
*
*       Desc:  This function is called to validate the RC received in DEREG REQ
*    
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtVerifyRc
(
ItRtCtx  *rCtx,        /* Route Cntx       */
U16      *rCtxLen,     /* RouteCntx Length */
ItPsId   *psLst,       /* PS List          */
ItAssocCb  *assocCb      /* Assoc CB         */
)
#else
PUBLIC S16 itAtVerifyRc(rCtx, rCtxLen, psLst, assocCb)
ItRtCtx  *rCtx;        /* Route Cntx       */
U16      *rCtxLen;     /* RouteCntx Length */
ItPsId   *psLst;       /* PS List          */
ItAssocCb  *assocCb;     /* Assoc CB         */
#endif
{
   U8             j;                  /* loop Counter*/
   U16            i;                  /* Index used for rCtx */
   U16            k;                  /* Index used for rCtx */
   U16            idx;                /* Index */
   ItPsCb        *psCb;               /* PS CB */
   ItRtCtx        nrCtx[LIT_MAX_PSID];/* valid routing context's list */
   U16            nrCtxLen;           /* length of list */              
   ItRtCtx        irCtx[LIT_MAX_PSID];/* invalid routing context's list */
   U16            irCtxLen;           /* length of list */         
   Bool           shftFlag;           /* To shift the RC array or not */
   SuId           suId;               /* SCT SAP id of association */
   ItPspId        pspId;              /* PSP id of association */

   TRC2(itAtVerifyRc)

   nrCtxLen = *rCtxLen;
   irCtxLen = 0;
   idx      = 0;

   (Void) cmMemcpy((U8 *)nrCtx, (U8 *)rCtx, sizeof(ItRtCtx) * (*rCtxLen));

   /* Ack Flag should be FALSE here as we need to map only Remote PS
      in case of IPSP DE */
   itAtMapRcToPs(assocCb, nrCtx, &nrCtxLen, irCtx, &irCtxLen, FALSE);

   /* At this point nrCtx contains PS list and rCtx contains original RCs
    * received and irCtx contains invalid routing context values */

   for (j = 0; j < irCtxLen; j++)
   {
      itMmhDeRegRsp(assocCb, IT_INV_RC, irCtx[j].rtCtx);
   }

   /* Delete the invalid RC (irCtx) from original list (rCtx) */
   for (j = 0; j < *rCtxLen; j++)
   {
      for (k = 0; k < irCtxLen; k++)
      {
         if (rCtx[j].rtCtx == irCtx[k].rtCtx)
         {
            for(i = j; i < (*rCtxLen - 1); i++)
            {
               rCtx[i].rtCtx = rCtx[i+1].rtCtx;
            }
         }
      }
   }
   *rCtxLen = (U16)(*rCtxLen - irCtxLen);
   
   /* rCtx now has original RC list without invalid RCs */
   /* And nrCtx at "i" index is having the corresponding PSIDs for RCs in
    * "i" index of rCtx */

   shftFlag = FALSE;
   suId  = IT_ASSOC2SUID(assocCb->assocId);
   pspId = IT_ASSOC2PSPID(assocCb->assocId);

   for (j = 0; j < nrCtxLen; j++)
   {
      psCb = itPsmFindPs(nrCtx[j].rtCtx);

      if (assocCb->owner->pspCfg.dynRegRkallwd != TRUE)
      {
         /* send DEREG RSP with cause as Permission Denied  */
         itMmhDeRegRsp(assocCb, IT_RC_PERM_DENIED, 
                       psCb->psSta.psStaEndp[suId].rteCtx[pspId].rCtx);
         shftFlag = TRUE;
      } 
      if (psCb->psSta.psStaEndp[suId].aspSt[pspId] != LIT_ASP_INACTIVE)
      {
         /* send DEREG RSP with cause as ASP not currently active */
         itMmhDeRegRsp(assocCb, IT_RC_CURR_ACTIVE, 
                             psCb->psSta.psStaEndp[suId].rteCtx[pspId].rCtx);
         shftFlag = TRUE;
      }                 
      else if (psCb->psSta.psStaEndp[suId].rteCtx[pspId].rcValid != TRUE)
      {
         /* send DEREG RSP with cause as NOT Registered */
         itMmhDeRegRsp(assocCb, IT_RC_NOT_REGD, rCtx[j].rtCtx);
         shftFlag = TRUE;
      }                 
      else if ((psCb->psSta.psStaEndp[suId].rteCtx[pspId].rcValid == TRUE) &&
              ((psCb->psSta.psStaEndp[suId].rteCtx[pspId].mode & 
                                     IT_RC_DYNAMIC_REGD) != IT_RC_DYNAMIC_REGD))
      {
         /* send DEREG RSP with cause as NOT Registered */
         itMmhDeRegRsp(assocCb, IT_RC_NOT_REGD, rCtx[j].rtCtx);
         shftFlag = TRUE;
      }
      else
      {
         /* Copy the PSID list (nrCtx) to rCtx */
         psLst[idx++] = nrCtx[j].rtCtx; 
         shftFlag = FALSE;
      }

      if (shftFlag == TRUE)
      {
         for(i = j; i < (*rCtxLen - 1); i++)
         {
            rCtx[i].rtCtx = rCtx[i+1].rtCtx;
         }
      }
   } /* End of for on nrCtxLen */
   if (idx == 0)
   {
      RETVALUE(RFAILED);
   }
   else
   {
      *rCtxLen = idx; 
   }
   RETVALUE(ROK);
} /* end of itAtVerifyRc */


/*
*
*       Fun:   itAtDeRegReq
*
*       Desc:  This function is called by MMH on receiving DEREG REQ from peer
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtDeRegReq
(
ItAssocCb  *assocCb,      /* Assoc CB       */
ItRtCtx    *rCtx,         /* list of routing contexts */      
U16        rCtxLen,       /* length of list */                
U16        event          /* event */            
)
#else
PUBLIC S16 itAtDeRegReq(assocCb, rCtx, rCtxLen, event)
ItAssocCb  *assocCb;      /* Assoc CB       */
ItRtCtx    *rCtx;         /* list of routing contexts */      
U16        rCtxLen;       /* length of list */                
U16        event;         /* event */             
#endif
{
   S16       ret;         /* Return Value */
   U8        i;           /* Loop Index */
   ItCntrl   cntrl;       /* Control Request, used for deletion of route */
   CmStatus  sta;         /* Return status, used for deletion of route & ps */
   ItPspId   pspId;       /* PSP ID */
   ItPsCb    *psCb;       /* PS CB */
   U32       j;           /* Loop Index */
   U16       k;           /* Loop Index */
   U16       idx;         /* loop Index */
   U16       indx;        /* loop Index */
   ItPsId    psLst[LIT_MAX_PSID];  /* Ps List */
   Bool      staticRegd;  /* Routing Key Statically Registered */
   Bool      itAbort;  
   U32       nmbPspReg;
   SuId      suId;        /* SCT SAP id of association */

#ifdef ZV
   /* it018.106 - addition - DFTHA Enhancement */
   ZvUpdSpecParams   updArgs;
#endif

   TRC2(itAtDeRegReq)
   /* Initialize psCb */
   psCb = (ItPsCb *)NULLP;
   itAbort = FALSE;
   pspId = assocCb->owner->pspCfg.pspId;
   
   suId  = IT_ASSOC2SUID(assocCb->assocId);

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
            "itAtDeRegReq()\n"));

   staticRegd = FALSE;
   nmbPspReg  = 0;

   /* Verify the received RC if event is Deregistration */ 

   if ((event == IT_EVT_DREGREQ) &&
       ((ret = itAtVerifyRc(rCtx, &rCtxLen, psLst, assocCb)) != ROK))
   {
      /* REG RSP is sent from itAtVerifyRc function for erroneous cases */
      RETVALUE(ret);
   }

   /* Updated rCtx List (i.e., not containing the invalid RCs) - is received 
    * from the itAtVerifyRc function */

   /* Update the PSCB */
   for (i = 0; i < rCtxLen; i++)
   {
      ItPsCfg  psCfg;  /* PS Cfg info */
      itAbort = FALSE;

      if (event == IT_EVT_DREGREQ)
      {
         psCb = itPsmFindPs(psLst[i]);
      }
      else
      {
         /* If event is IT_EVT_ASP_DN, the rCtx contains PS Ids */
         psCb = itPsmFindPs(rCtx[i].rtCtx);
      }
      if (psCb != (ItPsCb *)NULLP)
      {
         U16   pspIndx;  /*  loop index on regd assocs */
         /* Invalidate the rCtx stored for sending assoc for this PS */
         if ((psCb->psSta.psStaEndp[suId].rteCtx[pspId].rcValid == TRUE) 
              &&
             ((psCb->psSta.psStaEndp[suId].rteCtx[pspId].mode &
                                     IT_RC_DYNAMIC_REGD) == IT_RC_DYNAMIC_REGD))
         {
            U16    assocRegdcount;    /* Number of assocs regd for this PSP */
            U16    endPnts;     /* loop index on Number of assocs regd */
            /* If the RC is statically registered as well then do not
             * overwrite the previous RC value */
            if ((psCb->psSta.psStaEndp[suId].rteCtx[pspId].mode & 
                                        IT_RC_STATIC_REGD) != IT_RC_STATIC_REGD)
            {
               /* indicate to LM */
               IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
               itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
               /* If Degistration Request/ASP has gone down, send appropriate
                * indications */
               if (event == IT_EVT_DREGREQ)
               {
                  itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS; 
                  itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_RC_DELETED;
                  itGlobalCb.mgmt.t.usta.alarm.cause     = 
                                                    LIT_CAUSE_RK_DEREGISTERED;
               }
               else
               {
                  itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_CNTRL; 
                  itGlobalCb.mgmt.t.usta.alarm.event     = 
                                                      LIT_EVENT_RK_DEREGISTERED;
                  itGlobalCb.mgmt.t.usta.alarm.cause  = LIT_CAUSE_SCT_TERM_IND;
               }
         
               itGlobalCb.mgmt.t.usta.s.pspId          = pspId;
               itGlobalCb.mgmt.t.usta.t.drkmEvt.rteCtx = 
                                 psCb->psSta.psStaEndp[suId].rteCtx[pspId].rCtx;
               itGlobalCb.mgmt.t.usta.t.drkmEvt.sctSuId  = suId;
         
               (Void) itMiStaIndM(&itGlobalCb.mgmt); 
               psCb->psSta.psStaEndp[suId].rteCtx[pspId].rCtx    = 0xffffffff;
               psCb->psSta.psStaEndp[suId].rteCtx[pspId].rcValid = FALSE; 
            }
            else
            {
               /* Remove the dynamic_regd mode */
               psCb->psSta.psStaEndp[suId].rteCtx[pspId].mode 
                                                      &= ~(IT_RC_DYNAMIC_REGD); 
               staticRegd = TRUE;
            }
#ifdef ZV
            /* it018.106 - addition - DFTHA Enhancement Updating tabType 
               ZV_PS_ENDP_RCTX*/
            updArgs.p.psEndpUpd.endp = suId;
            updArgs.p.psEndpUpd.slno = pspId;
            zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PS_ENDP_RCTX,
                    CMPFTHA_UPDTYPE_SYNC, (Void *) psCb, &updArgs);
#endif /* ZV */
         
            psCb->psSta.psStaEndp[suId].nmbPspReg--;
            /* A PSP is deleted from a PS only if there is no more association
               of this PSP which are still registered (or statically cfged) */
            endPnts = 0;
            assocRegdcount = 0;
            for (endPnts = 0; endPnts < LIT_MAX_SEP; endPnts++)
            {
               for (pspIndx = 0; 
                            pspIndx < psCb->psSta.psStaEndp[endPnts].nmbPspReg;
                                                                      pspIndx++)
               {
                  if ((psCb->psSta.psStaEndp[endPnts].rteCtx[pspIndx].rcValid ==
                       TRUE))
                  {
                     assocRegdcount++;
                  }
               } /* End of Loop on PSPs */
            } /* End of loop on endPnts */
            /* Delete the PSP from the PS list if it was not statically
             * registered */
            if ((staticRegd == FALSE) && 
                               (assocRegdcount == 0))
            {
               for (j = 0; j < psCb->psCfg.nmbPsp; j++)
               {
                  if (psCb->psCfg.psp[j] == pspId)
                  {
                     /* Delete the pspId from the list */
                     for (k = (U16)j; k < (U16)((psCb->psCfg.nmbPsp - 1)); k++)
                     {
                        psCb->psCfg.psp[k] = psCb->psCfg.psp[k+1]; 
                     }
                     psCb->psCfg.nmbPsp--;
                     break;
                  }
               }
            }
         
         /* Update the pspCb.psSta count related to deletion of PS */
         for (idx = 0; idx < assocCb->assocSta->nmbRegPs; idx++)
         {
            if (assocCb->assocSta->regPs[idx] == psCb->psCfg.psId)
            {
               /* Shift the list and break frm the loop */
               for (indx = idx; indx < (assocCb->assocSta->nmbRegPs - 1); 
                                                                        indx++)
               {
                  assocCb->assocSta->regPs[indx] = 
                                             assocCb->assocSta->regPs[indx + 1];
#ifdef ZV
                  /* it018.106 - addition - updating table type 
                     ZV_PSP_REGPS */
                  updArgs.p.pspPsUpd.pspIdx = 
                     IT_ASSOC2PSPID(assocCb->assocId);
                  updArgs.p.pspPsUpd.endp = IT_ASSOC2SUID(assocCb->assocId);
                  updArgs.p.pspPsUpd.slNo = indx;
                  
                  zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSP_REGPS,
                          CMPFTHA_UPDTYPE_SYNC, (Void *) NULLP, &updArgs);
#endif
               } 
               break;
            }
         }
         assocCb->assocSta->nmbRegPs--;
                  
         if (psCb->psCfg.nmbPsp != 0)
         {
            cmMemcpy((U8 *)&psCfg,(U8 *)&(psCb->psCfg), sizeof(ItPsCfg));
            /* This is a similar case to reconf of PS with one PSP deleted from
             * original PSP list */
            (Void) itPsmCfgPs(&psCfg, &sta, IT_PS_CFG_DYN);
            /* In case of reconfiguration, psCb is sync'ed from itPsmCfgPs */
         }
         /* get the total nmbPspReg for all EndPoints */
         nmbPspReg  = 0;
         for (k = 0; k < LIT_MAX_SEP; k++)
         {
            nmbPspReg += psCb->psSta.psStaEndp[k].nmbPspReg;
         }
#ifdef ZV
         zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSPCB,
           CMPFTHA_UPDTYPE_SYNC, (Void *)assocCb->owner, NULLP);

         /* it018.106 - addition - updating table type ZV_PS_CFGCB */
         zvRTUpd(CMPFTHA_ACTN_ADD, ZV_PS_CFGCB,
                 CMPFTHA_UPDTYPE_SYNC, (Void *) psCb, NULLP);

         zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSCB,
           CMPFTHA_UPDTYPE_SYNC, (Void *)psCb, NULLP);
#endif
        
            if (psCb->psSta.asSt == LIT_AS_PENDING)
            {
              /* changed the first argument passing to 
                itPsmPsEvt */
               ItRtCtx psIdRtCtx;
               
                 /* psLst has correct values  only in
                  IT_EVT_DREGREQ event */
               if (event == IT_EVT_DREGREQ)
               {
                  psIdRtCtx.rtCtx = psLst[i];
               }
               else
               {
                  /* If event is IT_EVT_ASP_DN, the rCtx contains PS Ids */
                  psIdRtCtx.rtCtx = rCtx[i].rtCtx;
               }
         
               itPsmPsEvt(&psIdRtCtx,               /* Routing Context */
                           assocCb->assocId,        /* assocId */
                           IT_EVT_AS_PEND_TIMEOUT,/* Event */ 
                           psCb->psCfg.mode);     /* type of mode */
               itAbort = TRUE;
            }  
            if ((psCb->staticCfg == FALSE) && 
                (nmbPspReg == 0) && (psCb->psCfg.nmbPsp == 0))
            {
               /* it018.106 - deletion - Local defination of updArgs moved up */

              /* This PS is not registered by any PSP and it is not statically
               * cfged for any of the PSP, hence delete the routes
               * corresponding to this PS as well as the PS */
         
              cntrl.t.rtEnt.nwkId     = psCb->psCfg.nwkId;
              cntrl.t.rtEnt.indexType = LIT_RTINDEX_PSID;
              cntrl.t.rtEnt.u.psId    = psCb->psCfg.psId;
              /* Assumption is itAtDelRout will not fail in this specific case*/
              (Void) itAtDelRout(&cntrl, &sta);
#ifdef ZV
              
              updArgs.p.rteUpd.indexType = LIT_RTINDEX_PSID;
              updArgs.p.rteUpd.psId = psCb->psCfg.psId;
              updArgs.p.rteUpd.nwkId = psCb->psCfg.nwkId;
              /* Sync the deletion of Route Cb before confirm is sent */
              /* We can call zvRTUpd function here, even after routeCb is
                deleted because logic for RT update of route delete should 
                 not be using routeCb : All the required params are passed in
                 updArgs argument*/
              zvRTUpd(CMPFTHA_ACTN_DEL, ZV_RTECB,
                        CMPFTHA_UPDTYPE_SYNC, (Void *) NULLP, &updArgs);
               
#endif
         
              /* This update is required as Route deletion must be done before
                 Ps deletion so these 2 should not be tagged in the same RT 
                 update message */
              ITZVUPDPEER()
              
              /* An update to the peer was generated. The counter *
               * is incremented again */ 
              ITADDZVUPDPEERCTR()

              /* Send an indication to the LM */
              IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))                           
              itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPS;             
              itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS;
              itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_PS_DELETED;  
              if (event == IT_EVT_DREGREQ)
              {
                 itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_RCTX_UNREG;
              }
              else
              {
                 itGlobalCb.mgmt.t.usta.alarm.cause    = LIT_CAUSE_SCT_TERM_IND;
              }
              itGlobalCb.mgmt.t.usta.s.psId           = psCb->psCfg.psId;
         
         
              /* Delete the PS */
              (Void) itPsmDelPs(psCb->psCfg.psId, &sta, itAbort);
                                                                         
              (Void) itMiStaIndM(&itGlobalCb.mgmt);                      
            } /* End of if */
         
            /* If De-Registration Req is recvd, then send the de-reg rsp 
             * message to peer */
            if (event == IT_EVT_DREGREQ)
            {
               itMmhDeRegRsp(assocCb, IT_RC_SUCC_DREGD, rCtx[i].rtCtx);
            }
            else
            {
                /* Decrement the number of Dynamic Key registered with the PSP*/
                itGlobalCb.addrTrn.rkSta.nmbRkReg--;
            }
         
         } /* End of rcValid == TRUE */
         else if (event == IT_EVT_DREGREQ)
         {
            if (psCb->psSta.psStaEndp[suId].rteCtx[pspId].rcValid == TRUE)
            { 
               /* If control reaches here that mean the RC is not dynamically
                * registered but contains the valid value */
               /* Send the de-reg rsp message with cause as not registered  */
               itMmhDeRegRsp(assocCb, IT_RC_NOT_REGD, rCtx[i].rtCtx);
            }
            else
            {
               /* If control reaches here that mean the RC is not Valid
                * and is no longer registered Send the de-reg rsp message
                  with cause as not Valid  */

               /* The control will reach here only if identical RCs have
                   been sent in the same De-registration request and is
                  already de-registered once */
               itMmhDeRegRsp(assocCb, IT_INV_RC, rCtx[i].rtCtx);
            }
         }
      } /* psCb != NULLP */
      else
      {
           /* If control reaches here that mean the RC is not Valid
            * and is no longer registered  also the ps associated has been
            * deleted */  

           /* The control will reach here only if identical RCs have
               been sent in the same De-registration request and is
              already de-registered once */
           itMmhDeRegRsp(assocCb, IT_INV_RC, rCtx[i].rtCtx);
      }

   } /* End of loop on rCtxLen */
   
   RETVALUE(ROK);
} /* End of itAtDeRegReq */

#ifdef ITASP

/*
*
*       Fun:   itAtDeRegRsp
*
*       Desc:  This function is called by MMH on receiving DEREG RSP from peer
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtDeRegRsp
(
ItAssocCb  *assocCb,        /* Assoc CB      */
U32        dregSta,         /* Deregistration Status */
U32        routCtx          /* Route Context */
)
#else
PUBLIC S16 itAtDeRegRsp(assocCb, dregSta, routCtx)
ItAssocCb  *assocCb;        /* Assoc CB      */
U32        dregSta;         /* Deregistration Status */
U32        routCtx;         /* Route Context */
#endif
{
   U8            rCtxInd;      /* routing context index */
   ItRegReqTmrCb *regReqTmrCb;  /* REG REQ Timer CB */
   ItPsCb        *psCb = (ItPsCb *)NULLP; /* PS Control Block */
   U16           cause;       /* Reg Rsp Failure/Success Cause */
   U16           idx;         /* loop index */
   U16           indx;        /* loop index */
   SuId          suId;        /* SCT SAP id of association */
   ItPspId       pspId;       /* PSP  id of association */

#ifdef ZV
   /* it018.106 - addition - DFTHA Enhancement */
   ZvUpdSpecParams updArgs;
#endif /* ZV */

   TRC2(itAtDeRegRsp)

   cause = LCM_CAUSE_UNKNOWN;
   regReqTmrCb = (ItRegReqTmrCb *)NULLP;

   suId  = IT_ASSOC2SUID(assocCb->assocId);
   pspId = assocCb->owner->pspCfg.pspId;

   /* Search the PRKTCB, if not found no action is taken */
   if (assocCb->regReqTmrCb[1].req.deRegReq.nmbRctx == 0)
   {
      /* Send an indication to LM that unexpected msg received */
      IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
      itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
      itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_CNTRL; 
      itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_DEREG_FAILURE; 
      itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_UNEXP_MSG;
      itGlobalCb.mgmt.t.usta.t.drkmEvt.rteCtx = routCtx;
      itGlobalCb.mgmt.t.usta.t.drkmEvt.sctSuId = suId;
      itGlobalCb.mgmt.t.usta.s.pspId         = pspId;
   
      (Void) itMiStaIndM(&itGlobalCb.mgmt); 
      RETVALUE(RFAILED);
   }
   else
   {
      regReqTmrCb = &(assocCb->regReqTmrCb[1]); 
   }
   if ((dregSta != IT_RC_SUCC_DREGD) && (dregSta != IT_INV_RC) && 
                   (dregSta != IT_RC_NOT_REGD)) 
   {
      switch(dregSta)
      {
         case IT_RK_UNKNOWN:      
           cause = LCM_CAUSE_UNKNOWN;
           break;
         case IT_RC_PERM_DENIED: 
            cause = LIT_CAUSE_RKM_PER_DENIED;
            break;                 
         case IT_RC_CURR_ACTIVE:
            cause = LIT_CAUSE_PSP_ACTIVE;
            break;
      }

      IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
      itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
      itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_CNTRL; 
      itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_DEREG_FAILURE; 
      itGlobalCb.mgmt.t.usta.alarm.cause     = cause;
      itGlobalCb.mgmt.t.usta.s.pspId         = pspId;
      itGlobalCb.mgmt.t.usta.t.drkmEvt.rteCtx = routCtx;
      itGlobalCb.mgmt.t.usta.t.drkmEvt.sctSuId = suId;
   
      (Void) itMiStaIndM(&itGlobalCb.mgmt); 

      regReqTmrCb->rspPend = FALSE;

      itAtDelRkrNRkrtcb(regReqTmrCb, FALSE, (U32)routCtx); 

   }
   else
   {
      /* Special case for deregistration status as IT_INV_RC 
       * Since the peer node does not have any info related to the RC, hence 
       * consider it de-registered but indicate it to LM */
      if ((dregSta == IT_INV_RC) || (dregSta == IT_RC_NOT_REGD))
      {
         IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
         itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
         itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_CNTRL; 
         itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_DEREG_FAILURE; 
         itGlobalCb.mgmt.t.usta.alarm.cause     = (U16)((dregSta == IT_RC_NOT_REGD) ? 
                                  LIT_CAUSE_RCTX_UNREG : LIT_CAUSE_INV_RCTX);
         itGlobalCb.mgmt.t.usta.s.pspId         =  pspId;
         itGlobalCb.mgmt.t.usta.t.drkmEvt.rteCtx = routCtx;
         itGlobalCb.mgmt.t.usta.t.drkmEvt.sctSuId = suId;
   
         (Void) itMiStaIndM(&itGlobalCb.mgmt); 
      }
      /* rCtxInd is the index in regReqTmrCb->req.deRegReq.rCtx array */
      for (rCtxInd = 0; rCtxInd < LIT_MAX_RC_IN_DRKM; rCtxInd++)
      {
         if (regReqTmrCb->req.deRegReq.rCtx[rCtxInd].routCntx == routCtx)
            break;
      }
      if (rCtxInd == LIT_MAX_RC_IN_DRKM)
      {
         RETVALUE(RFAILED);
      }
      psCb = itPsmFindPs(regReqTmrCb->req.deRegReq.rCtx[rCtxInd].psId);
      if (psCb != NULLP)
      {
         U16   i;   /* loop Index */
         U16   j;   /* loop Index */
         U32   assocRegdcount; /* num of assocs regd */
      
         psCb->psSta.psStaEndp[suId].rteCtx[pspId].rcValid = FALSE;
         psCb->psSta.psStaEndp[suId].rteCtx[pspId].rCtx = 0xffffffff;
         psCb->psSta.psStaEndp[suId].nmbPspReg--;

#ifdef ZV
         /* it018.106 - addition - DFTHA Enhancement. Updating tabType 
            ZV_PS_ENDP_RCTX */
         updArgs.p.psEndpUpd.endp = suId;
         updArgs.p.psEndpUpd.slno = pspId;
         zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PS_ENDP_RCTX,
                 CMPFTHA_UPDTYPE_SYNC, (Void *) psCb, &updArgs);
#endif /* ZV */
         
         /* A PSP is deleted from a PS only if this is the last association
            of this PSP which got deregistered */
         assocRegdcount = 0;
         for (i = 0; i < LIT_MAX_SEP; i++)
         {
            if (psCb->psSta.psStaEndp[i].rteCtx[pspId].rcValid == TRUE)
            {
               assocRegdcount++;
            }
         } /* end of for (i = 0; i < LIT_MAX_SEP; i++) */
         /* Remove the PSP from the psCb->psCfg list only if assocRegdcount is 
            0 */
         if (assocRegdcount == 0)
         {
            for (i = 0; i < psCb->psCfg.nmbPsp; i++)
            {
                if (psCb->psCfg.psp[i] == assocCb->owner->pspCfg.pspId)
                {
                   for (j = i; j < (psCb->psCfg.nmbPsp - 1); j++)
                   {
                      psCb->psCfg.psp[j] = psCb->psCfg.psp[j+1]; 
                   }
          
                   /* To mark the last psp in pspList as 0 */
                   /* Index j will be equal to psCb->psCfg.nmbPsp */
                   psCb->psCfg.psp[j] = 0;
                }
            } /* End of for on psCfg.nmbPsp */
            if (psCb->psCfg.nmbPsp != 0)
            {
               psCb->psCfg.nmbPsp--;
            }
         } /* end of if (assocRegdcount == 0) */
         /* Send an indication to the LM for Successful RC de-registration */
         IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
         itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
         itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_CNTRL; 
         itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_RK_DEREGISTERED; 
         itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_MSG_RECEIVED;
         itGlobalCb.mgmt.t.usta.s.pspId         = assocCb->owner->pspCfg.pspId;
         itGlobalCb.mgmt.t.usta.t.drkmEvt.psId  = psCb->psCfg.psId;
         itGlobalCb.mgmt.t.usta.t.drkmEvt.rteCtx = routCtx;
         itGlobalCb.mgmt.t.usta.t.drkmEvt.sctSuId = 
                                            IT_ASSOC2SUID(assocCb->assocId);
   
         (Void) itMiStaIndM(&itGlobalCb.mgmt); 

         /* Update RKRTCB */
         if (regReqTmrCb->req.deRegReq.nmbRctx == 0)
         {
            /*  this is an unexpected event */
            RETVALUE(RFAILED);
         }
         regReqTmrCb->rspPend = FALSE;

         /* Delete the RKRCB */
         itAtDelRkrNRkrtcb(regReqTmrCb, FALSE, routCtx);

         /* Update the assocCb.assocSta count related to deregistration of 
            RK(PS)*/
         for (idx = 0; idx < assocCb->assocSta->nmbRegPs; idx++)
         {
            if (assocCb->assocSta->regPs[idx] == psCb->psCfg.psId)
            {
               /* Shift the list and break frm the loop */
               for (indx = idx; indx < (assocCb->assocSta->nmbRegPs - 1); 
                                                                        indx++)
               {
                  assocCb->assocSta->regPs[indx] = 
                                            assocCb->assocSta->regPs[indx + 1];

#ifdef ZV
                  /* it018.106 - addition - updating table type ZV_PSP_REGPS */
                  updArgs.p.pspPsUpd.pspIdx =
                     IT_ASSOC2PSPID(assocCb->assocId);
                  updArgs.p.pspPsUpd.endp = IT_ASSOC2SUID(assocCb->assocId);
                  updArgs.p.pspPsUpd.slNo = indx;
                  
                  zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSP_REGPS,
                          CMPFTHA_UPDTYPE_SYNC, (Void *) NULLP, &updArgs);
#endif
               } 
               break;
            }
         }
         assocCb->assocSta->nmbRegPs--;
         /* decrement the number of rk registered */
         itGlobalCb.addrTrn.rkSta.nmbRkReg--;
#ifdef ZV
         zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSCB,
           CMPFTHA_UPDTYPE_SYNC, (Void *)psCb, NULLP);
         zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSPCB,
           CMPFTHA_UPDTYPE_SYNC, (Void *)assocCb->owner, NULLP);
#endif
      }
#if (ERRCLASS & ERRCLS_DEBUG)
      else
      {
         IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))                           
         /* Send status indication to notify LM that PS is deleted before
          * waiting for DEREG RSP */
         itMiStaInd(STITPS, LIT_CATEGORY_STATUS, LIT_EVENT_PS_DELETED,
                    LIT_CAUSE_PS_DELETED, 
                    (U32)regReqTmrCb->req.deRegReq.rCtx[rCtxInd].psId);

         RETVALUE(RFAILED);
      }
#endif /* ERRCLS_DEBUG */
   } /* End of dregSta as SUCC, INV_RC and RC_NOT_REGD */
   RETVALUE(ROK);
} /* End of itAtDeRegRsp */




/*
*
*       Fun:   itAtFindRkrCb
*
*       Desc:  This function is the function used for searching RKRCB
*              whenever registration response message is received from SGP.
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/

#ifdef ANSI
PRIVATE S16 itAtFindRkrCb
(
ItAssocCb  *assocCb,        /* assoc CB      */
U32        lclRkId,         /* Local RK Id */
ItRegReqCb **regReqCb        /* RKRKCB      */
)
#else
PRIVATE S16 itAtFindRkrCb(assocCb, lclRkId, regReqCb)
ItAssocCb  *assocCb;        /* assoc CB      */
U32        lclRkId;         /* Local RK Id */
ItRegReqCb **regReqCb;       /* RKRKCB      */
#endif
{
   ItRegReqCb   *curRkrCb;    /* Temp storage for RKRCB storage */
   Bool         done;        /* Boolean Flag */

   TRC2(itAtFindRkrCb)

   cmLListFirst(&(assocCb->regReq));
   done = FALSE;
   /* search all RKRCB for lclRkId match */
   while (((curRkrCb = (ItRegReqCb *) cmLListCrnt(&(assocCb->regReq))) != NULLP)
                   && (done == FALSE))
   {
      if (curRkrCb->localRkId == lclRkId)
      {
         done = TRUE;
      }
      if (done == FALSE)
      {
         cmLListNext(&(assocCb->regReq));
      }
   }
   if (done != TRUE)
   {
      RETVALUE(RFAILED);
   }
   *regReqCb = curRkrCb;
   RETVALUE(ROK);
} /* End of itAtFindRkrCb */

#endif /*  ITASP */

/*
*
*       Fun:   itAtMapRcToPs
*
*       Desc:  This function is used for mapping Routing Context 
*              to corresponding Ps Associated.
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtMapRcToPs
(
ItAssocCb  *assocCb,       /* Assoc Control Block */
ItRtCtx    *nrCtx,         /* routing Context */
U16        *nrCtxLen,      /* Loop bound */
ItRtCtx    *irCtx,         /* routing Context */
U16        *irCtxLen,      /* Loop bound */
Bool       ackFlag         /* Ack Flag */
)
#else
PUBLIC S16 itAtMapRcToPs(assocCb, nrCtx, nrCtxLen, irCtx, irCtxLen, ackFlag)
ItAssocCb  *assocCb;       /* Assoc Control Block */
ItRtCtx    *nrCtx;         /* routing Context */
U16        *nrCtxLen;      /* Loop bound */
ItRtCtx    *irCtx;         /* routing Context */
U16        *irCtxLen;      /* Loop bound */
Bool       ackFlag;        /* Ack Flag */
#endif
{
   UConnId  assocId;       /* Assoc ID */
   ItPsId   psId;          /* Peer Server ID */
   U16      j;             /* loop Counter */
   U16      idx;           /* Routing context index */
   U16      nmbRtCtx;       /* Temporary Storage for routing context Len */

   TRC2(itAtMapRcToPs)

   assocId = assocCb->assocId;
   nmbRtCtx = *nrCtxLen;
   idx = 0;

   for (j = 0; j < nmbRtCtx; j++)
   {
      /* Changes done to allow same RC on LPS and 
         RPS for IPSP DE. Ack Flag Added */
      if (itAtFindPsId(assocId, nrCtx[j].rtCtx, &psId, ackFlag) == ROK)
      {
         nrCtx[idx++].rtCtx = psId;
      }
      else
      {
         irCtx[(*irCtxLen)++].rtCtx = nrCtx[j].rtCtx;
      }
   }
   *nrCtxLen = idx;
   RETVALUE(ROK);
}  /* End of itAtMapRcToPs */


/*
*
*       Fun:   itAtFindPsId
*
*       Desc:  This function is used for finding PS ID corresponding
*              to a particular PSP & routing context.
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/
#ifdef ANSI
PUBLIC S16 itAtFindPsId
(
UConnId      assocId,     /* Assoc Id */
U32          rtCtx,       /* Routing Context */
ItPsId       *psId,       /* Peer Server Id */
Bool         ackFlag      /* ackFlag */
)
#else
PUBLIC S16 itAtFindPsId(assocId, rtCtx, psId, ackFlag)
UConnId      assocId;     /* Assoc Id */
U32          rtCtx;       /* Routing Context */
ItPsId       *psId;       /* Peer Server Id */
Bool         ackFlag;     /* ackFlag */
#endif
{
   Bool      done;        /* Flag to indicate that PS is found */
   ItPsCb    *psCb;       /* Ps Control Block PTR */
   ItPsCb    *prevEnt;    /* Ps Control Block PTR */
   /* PspCb added to allow Same RC on both 
      RPS and LPS for IPSP DE */
   ItPspCb   *pspCb;      /* PSP Control Block PTR */
   ItAssocCb *assocCb;    /* Assoc Control Block PTR */
  
   TRC2(itAtFindPsId)

   psCb = (ItPsCb *) NULLP;
   prevEnt = (ItPsCb *)NULLP;
   done = FALSE;

   /* PspCb added to allow Same RC on both 
      RPS and LPS for IPSP DE */
   assocCb = itGlobalCb.assoc[assocId];
   pspCb   = assocCb->owner;
   while (cmHashListGetNext(&itGlobalCb.ps, (PTR) prevEnt, (PTR *) &psCb) 
              ==  ROK) 
   {
      if ((psCb->psSta.psStaEndp[IT_ASSOC2SUID(assocId)].rteCtx[pspCb->pspCfg.\
                                pspId].rcValid == TRUE) &&
         (psCb->psSta.psStaEndp[IT_ASSOC2SUID(assocId)].rteCtx[pspCb->pspCfg.\
                                pspId].rCtx == rtCtx))
      {
        /* Changes done to allow Same RC on both 
            RPS and LPS for IPSP DE */
        if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) &&
            (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_DE))
         {
            if (ackFlag == TRUE)
            {
               if (psCb->psCfg.lclFlag == TRUE)
               {
                  done = TRUE;
                  break;
               }
            }
            else
            {
               if (psCb->psCfg.lclFlag == FALSE)
               {
                  done = TRUE;
                  break;
               }
            }
         }
         else
         {
            done = TRUE;
            break;
         }
      }
      prevEnt = psCb;
   }   /* end of While loop on psCb */
   if (done == TRUE)
   {
      *psId = psCb->psSta.psId;
       RETVALUE(ROK);
   }
   RETVALUE(RFAILED);
} /* End of itAtFindPsId */


/*
*
*       Fun:   itAtMapPsToRc
*
*       Desc:  This function is used for mapping PS and PSP 
*              to corresponding RC Associated.
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 itAtMapPsToRc
(
ItAssocCb  *assocCb,       /* Assoc Control Block */
ItRtCtx    *nrCtx,         /* routing Context */
U16        *nrCtxLen,      /* Loop bound */
ItRtCtx    *irCtx,         /* routing Context */
U16        *irCtxLen       /* Loop bound */
)
#else
PUBLIC S16 itAtMapPsToRc(assocCb, nrCtx, nrCtxLen, irCtx, irCtxLen) 
ItAssocCb  *assocCb;       /* Assoc Control Block */
ItRtCtx    *nrCtx;         /* routing Context */
U16        *nrCtxLen;      /* Loop bound */
ItRtCtx    *irCtx;         /* routing Context */
U16        *irCtxLen;      /* Loop bound */
#endif
{
   UConnId  assocId;       /* Peer Server Process ID */
   ItPsCb  *psCb;          /* Peer Server Control Block */
   U16      i;             /* loop Counter */
   U16      idx;           /* index for routing context array */


   TRC2(itAtMapPsToRc)

   assocId = assocCb->assocId;
   idx = 0;
   /* Initialize psCb */
   psCb = (ItPsCb *) NULLP;

   for (i = 0; i < *nrCtxLen; i++)
   {
      psCb = itPsmFindPs(nrCtx[i].rtCtx);
      if ((psCb != (ItPsCb *) NULLP) &&
           (psCb->psSta.psStaEndp[IT_ASSOC2SUID(assocId)].
                      rteCtx[IT_ASSOC2PSPID(assocId)].rcValid == TRUE))
      {
         nrCtx[idx].rtCtx = psCb->psSta.psStaEndp[IT_ASSOC2SUID(assocId)].\
                                     rteCtx[IT_ASSOC2PSPID(assocId)].rCtx;
         nrCtx[idx++].ntfySend = FALSE;
      }
      else
      {
         irCtx[*irCtxLen].rtCtx = nrCtx[i].rtCtx;
         (*irCtxLen)++;
      }
   }
   *nrCtxLen  = idx;
   RETVALUE(ROK);
}  /* End of itAtMapPsToRc */

/*
*
*       Fun:   itAtGetNewRctx
*
*       Desc:  This function is used for getting a new unused RC value
*              from the global counter of Routing context value.
*
*       Ret:   NONE
*
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/
#ifdef ANSI   
PRIVATE Void itAtGetNewRctx
(
U32       *rCtx,      /* Routing Context */
UConnId   assocId     /* Assoc Id */
)
#else
PRIVATE Void itAtGetNewRctx(rCtx, assocId)
U32       *rCtx;      /* Routing Context */
UConnId   assocId;    /* Assoc Id */
#endif
{
   ItPsId psId;        /* PS id */
   Bool   done;        /* While flag */

   TRC2(itAtGetNewRctx)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
            "itAtGetNewRctx()\n"));

   done = FALSE;
   while (done == FALSE)
   {
      *rCtx = itGlobalCb.rCtx++;
      /* Search the whole list, whether any overflown of this counter has
       * occured */
      if (*rCtx < LIT_MAX_PSID)
      {
         itGlobalCb.rCtx = LIT_MAX_PSID + 1;
      }
      /* Search all RCs in the layer and it should not be the existing one */
      /* Search all PSCBs to locate the RCs */
      /* change to allow same RC on LPS and RPS for IPSP
         DE. Ack Flag is false here as we have to search only RPS
         in case of IPSP DE */
      if (itAtFindPsId(assocId, *rCtx, &psId, FALSE) != ROK)
      {
         /* A unique routing context has been found */
         done = TRUE; 
      }

   } /* End of while */

#ifdef ZV
    /* Update change in itGlobalCb.rCtx value to standby(shadows)*/
    zvRTUpd(CMPFTHA_ACTN_MOD, ZV_GENCB,
                            CMPFTHA_UPDTYPE_SYNC, (Void *)NULLP, NULLP);
#endif

   /* Send an indication to the layer that a new Routing Context is
    * generated */
   IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
   itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
   itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_CNTRL; 
   itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_RC_GENERATED; 
   itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_RK_REGISTERED;
   itGlobalCb.mgmt.t.usta.s.pspId         = IT_ASSOC2PSPID(assocId);
   itGlobalCb.mgmt.t.usta.t.drkmEvt.sctSuId = IT_ASSOC2SUID(assocId);
   itGlobalCb.mgmt.t.usta.t.drkmEvt.rteCtx = *rCtx;
   
   (Void) itMiStaIndM(&itGlobalCb.mgmt); 
   RETVOID;
} /* End of itAtGetNewRctx */


/*
*
*       Fun:   itAtCompRkMultiSi
*
*       Desc:  This function is used for comparing RCBs in case of multiple
*              SIs received in a single RK.
*
*       Ret:   NONE
*
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void itAtCompRkMultiSi
(
ItRoutKey    *rtKey,            /* Route CB        */
U32          *totalRkComb,      /* Total RK comb   */
ItRouteCb    *routeCb,           /* Route CB        */
U8           nwkId,             /* Nwk ID          */
Dpc          dpcMask,           /* DPC Mask        */
ItAssocCb    *assocCb,          /* Assoc Cb        */
ItDpcCb      *dpcCb,            /* DPC CB          */
ItPsId       *firstPsId,         /* First PSID      */
U32          localRkId,         /* Local RK ID     */
U8           *rkNotMatchCnt,     /* RK not match Cnt*/
S16          *retVal,            /* Return Value    */
S16          *compRkRetVal       /* Compare Ret Val */
)
#else
PRIVATE Void itAtCompRkMultiSi(rtKey, totalRkComb, routeCb, nwkId, dpcMask,
                assocCb, dpcCb, firstPsId, localRkId, rkNotMatchCnt, retVal,
                compRkRetVal)
ItRoutKey    *rtKey;           /* Route CB        */ 
U32          *totalRkComb;     /* Total RK comb   */
ItRouteCb    *routeCb;          /* Route CB        */
U8           nwkId;            /* Nwk ID          */
Dpc          dpcMask;          /* DPC Mask        */
ItAssocCb    *assocCb;         /* Assoc Cb        */
ItDpcCb      *dpcCb;           /* DPC CB          */
ItPsId       *firstPsId;        /* First PSID      */
U32          localRkId;        /* Local RK ID     */
U8           *rkNotMatchCnt;    /* RK not match Cnt*/ 
S16          *retVal;           /* Return Value    */
S16          *compRkRetVal;     /* Compare Ret Val */
#endif
{                                                                        
    U8   idx;  /* Index */ 
                                                                         
    TRC2(itAtCompRkMultiSi)

    ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
            "itAtCompRkMultiSi()\n"));

    /* Total number of RCBs expected to match */                         
    *totalRkComb = rtKey->nmbSio * ((rtKey->nmbOpc == 0) ? 1 :         
                    rtKey->nmbOpc);                                     
    *rkNotMatchCnt = 0;                                                  
    for (idx = 0; idx < rtKey->nmbSio; idx++)                           
    {                                                                    
       /* Zero the rtFilter and fill default prmt for next iteration  */ 
       IT_SET_FIXED_RK_PRMTR(routeCb, nwkId, rtKey->dpc, dpcMask);   

       routeCb->rteCfg.rtFilter.sioMask = 0x0F;
       routeCb->rteCfg.rtFilter.sio     = rtKey->sio[idx];                  

       /* Compare the RouteCb with existing Routes */                    
       /* With dpc+SI+OPC in rtFilter */                                 
       *compRkRetVal = itAtCompareRk(assocCb, routeCb, rtKey, dpcCb,
                      dpcMask, rkNotMatchCnt, firstPsId, localRkId); 
       if (*compRkRetVal != ROK)                                           
       {                                                                 
          *retVal = RFAILED;                                             
          break;                                                         
       }                                                                 
    } /* End of for-loop on SIs */                                       
} /* End of itAtCompRkMultiSi */

/*
*
*       Fun:   itAtCompRkSingleSi
*
*       Desc:  This function is used for comparing RCBs in case of a single
*              SI is received in a single RK.
*
*       Ret:   NONE
*
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void itAtCompRkSingleSi
(
ItRoutKey  *rtKey,          /* Route CB        */
U32        *totalRkComb,    /* Total RK comb   */ 
ItRouteCb  *routeCb,         /* Route CB        */
U8         nwkId,           /* Nwk ID          */
Dpc        dpcMask,         /* DPC Mask        */
ItAssocCb  *assocCb,        /* Assoc Cb        */
ItDpcCb    *dpcCb,          /* DPC CB          */
ItPsId     *firstPsId,       /* First PSID      */
U32        localRkId,       /* Local RK ID     */
U8         *rkNotMatchCnt,   /* RK not match Cnt*/
S16        *retVal,          /* Return Value    */
S16        *compRkRetVal     /* Compare Ret Val */
)
#else
PRIVATE Void itAtCompRkSingleSi(rtKey, totalRkComb, routeCb, nwkId, dpcMask,
              assocCb, dpcCb, firstPsId, localRkId, rkNotMatchCnt,
              retVal, compRkRetVal)
ItRoutKey  *rtKey;          /* Route CB        */
U32        *totalRkComb;    /* Total RK comb   */
ItRouteCb  *routeCb;         /* Route CB        */
U8         nwkId;           /* Nwk ID          */
Dpc        dpcMask;         /* DPC Mask        */
ItAssocCb  *assocCb;        /* Assoc Cb        */
ItDpcCb    *dpcCb;          /* DPC CB          */
ItPsId     *firstPsId;       /* First PSID      */
U32        localRkId;       /* Local RK ID     */
U8         *rkNotMatchCnt;   /* RK not match Cnt*/
S16        *retVal;          /* Return Value    */
S16        *compRkRetVal;    /* Compare Ret Val */
#endif
{
    U8   idx; /* loop index */
    Bool ssnDone; /* SSN processing is done */

    TRC2(itAtCompRkSingleSi)

    ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
            "itAtCompRkSingleSi()\n"));

    
    ssnDone      = FALSE;
    *totalRkComb =  (rtKey->nmbOpc == 0) ? 1 : rtKey->nmbOpc;     
                                                                         
    /* If CIC-range is not present then the following block  
     * of code will get execute for RCBs with dpc+SI+OPC only */ 
    if (rtKey->nmbCic == 0)   
    {
       IT_SET_FIXED_RK_PRMTR(routeCb, nwkId, rtKey->dpc, dpcMask);   
       routeCb->rteCfg.rtFilter.sioMask = 0x0F;
       routeCb->rteCfg.rtFilter.sio     = rtKey->sio[0];

       *compRkRetVal = itAtCompareRk(assocCb, routeCb, rtKey, dpcCb,
                        dpcMask, rkNotMatchCnt, firstPsId, localRkId);
       if (*compRkRetVal != ROK)                                         
       {                                                                
          *retVal = RFAILED;                                         
       }                                                                 
       RETVOID;
    } /* End of nmbCic == 0 */

    *totalRkComb = rtKey->nmbCic * ((rtKey->nmbOpc == 0) ? 1 : rtKey->nmbOpc);          
    for(idx = 0; idx < rtKey->nmbCic; idx++)                               
    {                                                                 
       /* Zero the rtFilter and fill default prmt for next iteration */
       IT_SET_FIXED_RK_PRMTR(routeCb, nwkId, rtKey->dpc, dpcMask); 
       /* Compare the RouteCb with existing Routes */                  
       /* With dpc+SI+OPCs+CIC-ranges in rtFilter */                   
       routeCb->rteCfg.rtFilter.sioMask  = 0x0F;
       routeCb->rteCfg.rtFilter.sio      = rtKey->sio[0];
       routeCb->rteCfg.rtFilter.opc      = rtKey->cicRange[idx].opc;      
       routeCb->rteCfg.rtFilter.opcMask  = 0xffffffff;
       routeCb->rteCfg.rtFilter.includeCic = TRUE;
       routeCb->rteCfg.rtFilter.cicStart = rtKey->cicRange[idx].cicStart;
       routeCb->rteCfg.rtFilter.cicEnd   = rtKey->cicRange[idx].cicEnd;
       /* OPCs will be used from the CIC-range list, hence nmbOpc is   
       * passed as 0 */                                                
       *compRkRetVal = itAtCompareRk(assocCb, routeCb, rtKey, dpcCb, 
                          dpcMask, rkNotMatchCnt, firstPsId, localRkId);
       if (*compRkRetVal != ROK)                                      
       {                                                              
          *retVal = RFAILED;                                          
          break;                                                      
       }                                                              
    } /* End of loop on CIC-range */                                 
    RETVOID;
} /* End of itAtCompRkSingleSi */

/*
*
*       Fun:   itAtGetNewPsId
*
*       Desc:  This function is used for finding an unused PS ID 
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/
#ifdef ANSI
PUBLIC S16 itAtGetNewPsId
(
ItPsId       *psId           /* Peer Server Id PTR */
)
#else
PUBLIC S16 itAtGetNewPsId(psId)
ItPsId       *psId;          /* Peer Server Id PTR */
#endif
{
   U16        idx;           /* loop counter */

   TRC2(itAtGetNewPsId)

   for (idx = LIT_MAX_STATIC_PSID; idx < LIT_MAX_PSID; idx++)        
   {                                                                   
      if (itGlobalCb.psLstCb.psIdFree[idx] == TRUE)                          
         break;                                                        
   }                                                                   
   if (idx < LIT_MAX_PSID)
   {
      *psId = idx;
      RETVALUE(ROK);
   }
   RETVALUE(RFAILED);
}  /* End of itAtGetNewPsId */
 


#ifdef ITASP
/*
*
*       Fun:   itAtVerifyInterRegReq
*
*       Desc:  This function verifies the inter parameters within Reg request
*
*
*       Ret:   Void          
*
*
*       Notes: <none>
*
*       File:  it_bdy5.c
*
*/

#ifdef ANSI
PRIVATE S16 itAtVerifyInterRegReq
(
ItCntrl    *cntrl,     /* Contrl Request */
CmStatus   *sta        /* Status */
)
#else
PRIVATE S16 itAtVerifyInterRegReq(cntrl, sta)
ItCntrl    *cntrl;     /* Contrl Request */
CmStatus   *sta;       /* Status */
#endif
{
   U16     i;      /* index */
   U16     j;      /* index */
   ItPsId  psId;   /* Ps ID */

   TRC2(itAtVerifyInterRegReq)
   for (i = 0; i < cntrl->t.dynRteKey.rkm.rK.nmbRk; i++)
   {
       psId = cntrl->t.dynRteKey.rkm.rK.routKey[i].psId; 
       /* Check whether this PSID is specified in any other RK */
       for (j = (U16)(i+1); j < (U16)(cntrl->t.dynRteKey.rkm.rK.nmbRk); j++)
       {
          if (psId == cntrl->t.dynRteKey.rkm.rK.routKey[j].psId)
          {
             sta->status = LCM_PRIM_NOK;           
             sta->reason = LIT_REASON_PSID_ALREADY_USED;
             RETVALUE(RFAILED);                    
          }
       } /* End of loop on j */
   } /* End of loop on nmb of rks */
   RETVALUE(ROK);
} /* End of itAtVerifyInterRegReq */
#endif /* ITASP */

/********************************************************************30**

  End of file:     it_bdy5.c@@/main/5 - Thu Apr  1 03:52:01 2004

**********************************************************************31*/

/********************************************************************40**

Notes:

**********************************************************************41*/

/********************************************************************50**

**********************************************************************51*/

/********************************************************************60**

  Revision history:

**********************************************************************61*/
/********************************************************************70**

  version    initials                   description
  -----------  ---------  ------------------------------------------------

**********************************************************************71*/

/********************************************************************80**

**********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/1      ---     nt   1. initial release.
/main/2      ---     sg   1. Routing changes and Bakeoff fixes.
             ---     sg   2. Update to Release 1.3
/main/3      ---     sg   1. Update to Release 1.4
/main/5              an   1. All patches has been propagatedfrom ver 1.3. 
/main/5              cg   1. In function itAtDeRegReq illigal access of 
                             psCb is removed.
            it005.104 cg  1. Start range of Dyanamic PsId is Changed 
                             to LIT_MAX_STATIC_PSID from 0
/main/5     it006.104 an  1. check for mismatch of OPC list and OPC nmb.
            it007.104 an  1. Check PSP state for this PS.
            it007.104 cg  1. moved code fragment to avoid curruption by trace 
/main/5     it011.104 sg  1. Change in itAtVerifyRk for SI_TUP support.
/main/5     it013.104 vt  1. itAbort initialized for every routing context
                          2. psLst undefined values. Logic corrected. 
/main/5     it014.104 vt  1. To correct  the problem of wrong RESPONSE going
                             in Registration Response message.
/main/5     it015.104 vt  1. changes done for avioding CIC overlap issue 
                             while configuring 2nd route with same CICs
/main/5     it019.104 vt  1. changes done to allow same RC on both RPS 
                             and LPS in case of IPSP DE
                          2. Canges done to resolve double de-allocation of 
                             message buffer 
/main/4      ---      nt   1. Update to Release 1.5
/main/5      ---      rs   1. Update to Release 1.6.
/main/5     it001.106 nt   1. NTFY is sent after Reg Rsp message.
/main/5     it016.106 sg   1. Changes to make storing of ASPID optional
                              when rxTxAspId is FALSE. So, even if rxTxAspId 
                              is FALSE send ASPID(if available) in Notify.
/main/5     it018.106 sb   1. M3UA DFTHA Enhancement.
                           2. Made changes to send runtime update for following 
                              newly added table Types:
                              a.ZV_PS_ENDP_PSPSTA   
                              b.ZV_PS_ENDP_ACTPSP
                              c.ZV_PS_ENDP_RCTX  
                              d.ZV_PSP_ACTPS     
                              e.ZV_PSP_REGPS  
                              f.ZV_DPCSTA       
                              g.ZV_ASPID            
*********************************************************************91*/
