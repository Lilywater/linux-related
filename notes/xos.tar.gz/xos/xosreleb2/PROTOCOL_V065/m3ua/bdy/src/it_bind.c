
/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "ss_gen.h"
#ifdef ZV
#include "cm_ftha.h"       /* common PSF */
#include "cm_psfft.h"          /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.h"       /* The common LDF defines */
#include "cmzvdvlb.h"       /* The common LDF defines */
#endif
#endif
#include "cm5.h"           /* common timer */
#include "cm_ss7.h"        /* common SS7 */
#include "cm_tpt.h"        /* common transport defines */
#include "sct.h"           /* SCT interface */
#ifdef IT_FTHA             
#include "sht.h"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "lit.h"           /* layer management M3UA  */
#include "snt.h"           /* SNT interface */
#include "it.h"            /* M3UA internal defines */
#include "it_err.h"        /* M3UA error */
#ifdef ZV
#include "mrs.h"           /* Message Router common define */
#include "lzv.h"           /* common PSF */
#include "zv.h"            /* common PSF */
#include "zv_err.h"        /* m3ua PSF error codes */
#endif

#ifdef IT_ACC
#include "it_acc.h"        /* acceptance test */
#ifdef ZV
#include "zv_acc.h"        /* acceptance test */
#endif
#endif

/* header include files (.h) */



#include "cm_inet.h"       /* common network address */
#include "cm_tpt.h"        /* common transport defines */
#include "cm_dns.h"      /* common DNS library */
#ifdef SB_FTHA
#include "sht.h"           /* SHT Interface header file */
#endif /* SB_FTHA */
#include "lsb.h"           /* layer management, SCTP  */

#include "hit.h"           /* HIT interface */
#include "sb.h"            /* SCTP internal defines */
#include "sb_err.h"        /* SCTP error */


/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_ss7.x"        /* common SS7 */

#include "cm_tpt.x"        /* common transport */
#include "sct.x"           /* SCT interface */
#include "snt.x"           /* SNT interface */
#ifdef IT_FTHA             
#include "sht.x"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "lit.x"           /* layer management M3UA */
#include "it.x"            /* M3UA internal typedefs */
#ifdef ZV
#include "cm_ftha.x"          /* common PSF */
#include "cm_psfft.x"          /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.x"       /* The LDF common data structs */
#include "cmzvdvlb.x"       /* The LDF common data structs */
#endif
#include "mrs.x"       /* The LDF common data structs */
#include "lzv.x"           /* common PSF */
#include "zv.x"            /* common PSF */
#endif

#ifdef IT_ACC
#include "it_acc.x"        /* acceptance test */
#ifdef ZV
#include "zv_acc.x"        /* acceptance test */
#endif
#endif

// #include "ss_gen.x"
#include "it_init.h"


/* header/extern include files (.x) */
/* header/extern include files (.x) */


#include "cm_inet.x"       /* common network address */

#include "cm_dns.x"        /* common DNS */
#include "sb_mtu.h"        /* mtu defines */
#include "sb_mtu.x"        /* mtu typedefs */
#include "sb_port.x"       /* sb_port typedefs */

#include "lsb.x"           /* layer management SCTP */
#include "hit.x"           /* HIT interface */
#include "sb.x"            /* sctp layer typedefs */
/* local includes */
#include <signal.h>
#include "it_cfg.h"

extern PUBLIC CmIpv4NetAddr localNAddrLst_1V[5];
EXTERN ItCfgGlobal itGlobalTabCfg;

PUBLIC Void SmItPstInit(Pst *smItPst)
{
	/* smsnPst */
	smItPst->selector   = 0;	        /* selector,loose coupled */
	smItPst->region 	= DFLT_REGION;	/* region */
	smItPst->pool 	    = DFLT_POOL;	/* pool */
	smItPst->prior 	    = PRIOR0;	/* priority */
	smItPst->route 	    = 0;	/* route */
	smItPst->dstEnt 	= ENTIT;	/* destination entity*/

	smItPst->dstInst 	= 0;	/* destination instance */

	smItPst->srcEnt 	= ENTSM;	/* source entity */
	smItPst->srcInst 	= 0;	/* source instance */
	smItPst->dstProcId  = SFndProcId();	/* destination processor id */
	smItPst->srcProcId  = SFndProcId();	/* source processor id */
	
} /* end of SmItCliPstInit */

PUBLIC Void ItPstInit(Pst *ItPst)
{
	/* smsnPst */
	ItPst->selector   = 0;	        /* selector,loose coupled */
	ItPst->region 	= DFLT_REGION;	/* region */
	ItPst->pool 	    = DFLT_POOL;	/* pool */
	ItPst->prior 	    = PRIOR0;	/* priority */
	ItPst->route 	    = 0;	/* route */
	ItPst->dstEnt 	= ENTSB;	/* destination entity*/

	ItPst->dstInst 	= 0;	/* destination instance */

	ItPst->srcEnt 	= ENTIT;	/* source entity */
	ItPst->srcInst 	= 0;	/* source instance */
	ItPst->dstProcId  = SFndProcId();	/* destination processor id */
	ItPst->srcProcId  = SFndProcId();	/* source processor id */
	
} /* end of SmItCliPstInit */


PUBLIC Void ItSbPstInit(Pst *smItPst)
{
	/* smsnPst */
	smItPst->selector   = 0;	        /* selector,loose coupled */
	smItPst->region 	= DFLT_REGION;	/* region */
	smItPst->pool 	    = DFLT_POOL;	/* pool */
	smItPst->prior 	    = PRIOR0;	/* priority */
	smItPst->route 	    = 0;	/* route */
	smItPst->dstEnt 	= ENTIT;	/* destination entity*/

	smItPst->dstInst 	= 0;	/* destination instance */

	smItPst->srcEnt 	= ENTSM;	/* source entity */
	smItPst->srcInst 	= 0;	/* source instance */
	smItPst->dstProcId  = SFndProcId();	/* destination processor id */
	smItPst->srcProcId  = SFndProcId();	/* source processor id */
	
} /* end of SmItCliPstInit */





PUBLIC S16 ItLSapBindSb(SuId suId)
{
	
	ItMgmt	itMgmt;
	Pst     smItPst;

	SPrint("[SMIT_OAM_IF]: itLSapBind, \n");
	
	/* Initail stack manager pst */	
	SmItPstInit(&smItPst);
	
	/* Initail control strcture */
	cmMemset((U8*)&itMgmt, 0, sizeof(ItMgmt));

	itMgmt.hdr.elmId.elmnt 		= STITSCTSAP;
	itMgmt.t.cntrl.action		= ABND;
	itMgmt.t.cntrl.subAction 	= SAELMNT;
	itMgmt.t.cntrl.s.suId		= suId;
	
	/* Send control request to m3ua */	
	(Void)SmMiLitCntrlReq(&smItPst, &itMgmt);   

	RETVALUE(ROK);
	
} /* end of itLSapBind */



PUBLIC Void ItBindSctSap(SuId suId,SpId spId)
{
    Pst pst;
    
   pst.dstProcId = SFndProcId();
   pst.srcProcId = SFndProcId();
   pst.dstEnt    =  ENTSB;
   pst.dstInst   = 0;
   pst.srcEnt    =  ENTIT;
   pst.srcInst   = 0;
   pst.prior     = 0;
   pst.route     = 0;
   pst.event     = 0;
   pst.region    = DFLT_REGION;
   pst.pool      = DFLT_POOL;
   pst.selector  = 0;
   pst.intfVer    = LITIFVER;
   SbUiSctBndReq(&pst, suId, spId);
}

PUBLIC Void ItBindNSap(SuId suId,SpId spId)
{
    Pst pst;
    
   pst.dstProcId = SFndProcId();
   pst.srcProcId = SFndProcId();
   pst.dstEnt    = ENTIT;
   pst.dstInst   = 0;
   pst.srcEnt    = ENTSP;
   pst.srcInst   = 0;
   pst.prior     = 0;
   pst.route     = 0;
   pst.event     = 0;
   pst.region    = DFLT_REGION;
   pst.pool      = DFLT_POOL;
   pst.selector  = 0;
   pst.intfVer    = 3;

   ItUiSntBndReq(&pst, suId, spId,(SrvInfo)3);

}





 
PUBLIC Void ItOpenEndpReq(void)
{
#if 0
   Pst           smItPst;
   SpId          spId;
   UConnId       suEndpId;
   U16           localPort;
#ifdef SCT_ENDP_MULTI_IPADDR   
   SctNetAddrLst localNAddrLst;
#else
   CmNetAddr     localNAddr;
#endif
   
#ifdef LCITMILIT
    smItPst.selector = 0;               /* selector,loose coupled */
#else
    smItPst.selector = 1;               /* selector,loose coupled */
#endif
    smItPst.region = 0;            /* region */
    smItPst.pool = 0;             /* pool */
    smItPst.prior = PRIOR0;                  /* priority */
    smItPst.route = 0;                  /* route */
    smItPst.dstProcId = SFndProcId();   /* destination processor id */
    smItPst.dstEnt = ENTSB;             /* destination entity*/
    smItPst.dstInst = 0;          /* destination instance */
    smItPst.srcProcId = SFndProcId();   /* source processor id */
    smItPst.srcEnt = ENTIT;             /* source entity */
    smItPst.srcInst = 0;          /* source instance */	

	spId = 0;
	suEndpId = 0;
    localPort = 2905;

#ifdef SCT_ENDP_MULTI_IPADDR  
	localNAddrLst.nmb = 1;
	localNAddrLst.nAddr[0].type = CM_NETADDR_IPV4;
	localNAddrLst.nAddr[0].u.ipv4NetAddr = 0xa80002a9;
   (void) ItLiSctEndpOpenReq(&smItPst,spId,suEndpId,localPort,&localNAddrLst);	
#else
	localNAddr.type = CM_NETADDR_IPV4;
	localNAddr.u.ipv4NetAddr = 0xa80002a9;
   (void) ItLiSctEndpOpenReq(&smItPst,spId,suEndpId,localPort,&localNAddr);
#endif
	
#endif

   
}







PUBLIC Void ItSetupAssReq(UConnId  assocId)
{

#if 0
	Pst           smItPst;
	SpId          spId;
	UConnId       spEndpId;
	UConnId       cassocId;
	
	CmNetAddr     priDstAddr;
	U16           dstPort;
	SctStrmId     locOutStrms;
	SctNetAddrLst dstAddrLst;
	SctNetAddrLst srcAddrLst;
	S16           ret = ROK;
	

#ifdef LCITMILIT
    smItPst.selector = 0;               /* selector,loose coupled */
#else
    smItPst.selector = 1;               /* selector,loose coupled */
#endif
    smItPst.region = 0;            /* region */
    smItPst.pool = 0;             /* pool */
    smItPst.prior = PRIOR0;                  /* priority */
    smItPst.route = 0;                  /* route */
    smItPst.dstProcId = SFndProcId();   /* destination processor id */
    smItPst.dstEnt = ENTSB;             /* destination entity*/
    smItPst.dstInst = 0;          /* destination instance */
    smItPst.srcProcId = SFndProcId();   /* source processor id */
    smItPst.srcEnt = ENTIT;             /* source entity */
    smItPst.srcInst = 0;          /* source instance */	
	

	
	spId = 0;
	spEndpId = 0;
	cassocId = assocId;
    priDstAddr.u.ipv4NetAddr = itGlobalTabCfg.PspTab[0].DestAddr1;
	priDstAddr.type = CM_NETADDR_IPV4;
    dstPort= 2905;
    locOutStrms= 2;
    dstAddrLst.nmb = 1 ;
	dstAddrLst.nAddr[0].type = CM_NETADDR_IPV4;
	dstAddrLst.nAddr[0].u.ipv4NetAddr = 	itGlobalTabCfg.PspTab[0].DestAddr1;
    printf("dst addr = %x\n\n",itGlobalTabCfg.PspTab[0].DestAddr1);

	srcAddrLst.nmb = 1;
	srcAddrLst.nAddr[0].type= CM_NETADDR_IPV4;
	srcAddrLst.nAddr[1].type= CM_NETADDR_IPV4;
	srcAddrLst.nAddr[2].type= CM_NETADDR_IPV4;
	srcAddrLst.nAddr[0].u.ipv4NetAddr	= localNAddrLst_1V[0];;
    srcAddrLst.nAddr[1].u.ipv4NetAddr	= 0xa80002a9;
	srcAddrLst.nAddr[2].u.ipv4NetAddr	= 0xa80002a9;
	

   (Void) ItLiSctAssocReq(&smItPst, \
   	                        spId, \
                            spEndpId,\
                            cassocId, \
                            &priDstAddr, \
                            dstPort, \
                            locOutStrms, \
                            &dstAddrLst, \
                            &srcAddrLst,\
                            (Buffer *)NULLP\
                       );
                       

#endif 

#if 1   
	ItMgmt	itMgmt;
	Pst     smItPst;
    SuId    suId;

	SPrint("[SMIT_OAM_IF]: itLSapBind, \n");
	
	/* Initail stack manager pst */	
	SmItPstInit(&smItPst);
	suId = 0; 
	/* Initail control strcture */
	cmMemset((U8*)&itMgmt, 0, sizeof(ItMgmt));

	itMgmt.hdr.elmId.elmnt 		= STITPSP;
	itMgmt.t.cntrl.action		= AESTABLISH;
	itMgmt.t.cntrl.subAction 	= SAELMNT;
	itMgmt.t.cntrl.s.suId		= suId;
	
	itMgmt.t.cntrl.s.pspId = 1;
	itMgmt.t.cntrl.t.aspm.sctSuId = 0 ;


	/* Send control request to m3ua */	
	(Void)ItMiLitCntrlReq(&smItPst, &itMgmt);   

	return;
#endif

}


void ItSendPspUpPkt(void)
{
	ItMgmt	itMgmt;
	Pst     smItPst;
    SuId    suId;

	/* Initail stack manager pst */	
	SmItPstInit(&smItPst);
	suId = 0; 
	/* Initail control strcture */
	cmMemset((U8*)&itMgmt, 0, sizeof(ItMgmt));

	itMgmt.hdr.elmId.elmnt 		= STITPSP;
	itMgmt.t.cntrl.action		= AASPUP;
	itMgmt.t.cntrl.subAction 	= SAELMNT;
	itMgmt.t.cntrl.s.suId		= suId;
	
	itMgmt.t.cntrl.s.pspId = 1;
	itMgmt.t.cntrl.t.aspm.sctSuId = 0 ;
	/* Send control request to m3ua */	
	(Void)ItMiLitCntrlReq(&smItPst, &itMgmt);  
}