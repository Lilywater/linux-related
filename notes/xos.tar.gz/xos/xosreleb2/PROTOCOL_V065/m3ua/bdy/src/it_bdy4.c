/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:    M3UA Layer (M3UA)

     Type:    C source file

     Desc:    Code for Upper Interface and Management Interface
              primitives supplied by TRILLIUM

     File:    it_bdy4.c

     Sid:      it_bdy4.c@@/main/7 - Thu Apr  1 03:51:48 2004

     Prg:     pn, jjb, mrw

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_ss7.h"        /* common SS7 */
#include "cm_tpt.h"        /* common transport defines */
#include "lit.h"           /* layer management M3UA  */
#include "sct.h"           /* SCT interface */
#include "snt.h"           /* SNT interface */
#ifdef IT_FTHA             
#include "sht.h"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "it.h"            /* M3UA internal defines */
#include "it_err.h"        /* M3UA error */
#ifdef ZV
#include "cm_ftha.h"
#include "cm_psfft.h"          /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.h"
#include "cmzvdvlb.h"
#endif /* ZV_DFTHA */
#include "mrs.h"
#include "lzv.h"
#include "zv.h"            /* m3ua  PSF */
#endif /* ZV */

/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_ss7.x"        /* common SS7 */
#include "cm_tpt.x"        /* common transport */
#include "sct.x"           /* SCT interface */
#ifdef IT_FTHA             
#include "sht.x"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "lit.x"           /* layer management M3UA */
#include "snt.x"           /* SNT interface */
#include "it.x"            /* M3UA internal typedefs */
#ifdef ZV
#include "cm_ftha.x"
#include "cm_psfft.x"
#ifdef ZV_DFTHA
#include "cmzvdv.x"
#include "cmzvdvlb.x"
#endif
#include "mrs.x"
#include "lzv.x"
#include "zv.x"            /* m3ua PSF */
#endif /* ZV */

#include "it_star.h"

/* functions */
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
PRIVATE Void itPsmChkRcRdyRcvTraf ARGS((ItRtCtx *nrCtx, U16 *nrCtxLen, 
                                         ItRtCtx *irCtx, U16 *irCtxLen));
#endif

/*
*
*       Fun:      itLiCfgSap
*
*       Desc:     Create an SCTSAP and configure with the values specified.
*                 The initial state is "unbound".
*
*       Ret:      Failure:    RFAILED
*
*                 Success:    ROK
*
*       Notes:    Called by LMI(config)
*
*       File:     it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLiCfgSap
(
ItSctSapCfg      *cfg,        /* pointer to SCT SAP configuration */
CmStatus         *sta         /* returned status */
)
#else
PUBLIC S16 itLiCfgSap(cfg, sta)
ItSctSapCfg      *cfg;        /* pointer to SCT SAP configuration */
CmStatus         *sta;        /* returned status */
#endif
{
   ItSctSapCb    *sapCb;      /* SCT SAP */
   Bool          errFlag;     /* error flag */
   U32           i;           /* loop index */
   U32           j;           /* loop index */
   ItAssocCb     *tmpAssocCb; /* Temp assoc Cb */
#ifdef IT_RUG
   Bool          found;       /* flag to indicate if the version info is in the
                              * stored version structure */
#endif /* IT_RUG */

   TRC2(itLiCfgSap)

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf, "itLiCfgSap(cfg, sta)\n"));

   if (itLiVerifySctSapCfg(cfg, sta) != ROK)
   {
      RETVALUE(RFAILED);
   }

   if ((sapCb = itGlobalCb.sctSap[cfg->suId]) == (ItSctSapCb *)NULLP)
   {
      /* allocate memory for the sapCb */
      IT_ALLOC(sizeof(ItSctSapCb), sapCb)
      if (sapCb == (ItSctSapCb *)NULLP)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_MEM_NOAVAIL;
         RETVALUE(RFAILED);
      }


      /* update the pointer to the SAP in the table of SAPs */
      itGlobalCb.sctSap[cfg->suId] = sapCb;

      /* initialize Status struct of new SCT SAP */
      sapCb->sctSta.hlSt        = LIT_SAP_UNBOUND; /* state unbound */
      sapCb->sctSta.spEndpId    = 0;
      sapCb->sctSta.nmbActAssoc = 0;
      sapCb->sctSta.suId        = cfg->suId;

#ifdef IT_RUG
      sapCb->remIntfValid = FALSE;

      if (cfg->remIntfValid == TRUE)
      {
         sapCb->remIntfValid = TRUE;
         sapCb->pst.intfVer = cfg->remIntfVer;
      }
      else
      {
         found = FALSE;
         for (i = 0; i < itGlobalCb.numIntfInfo && found == FALSE; i++)
         {
            /* it011.106 - The intfId corrected to SCTIF */
            if (itGlobalCb.intfInfo[i].intf.intfId == SCTIF)
            {
               switch (itGlobalCb.intfInfo[i].grpType)
               {
                  case SHT_GRPTYPE_ALL:
                     if ((itGlobalCb.intfInfo[i].dstProcId ==
                                              sapCb->sctCfg.procId) &&
                         (itGlobalCb.intfInfo[i].dstEnt.ent ==
                                              sapCb->sctCfg.ent) &&
                         (itGlobalCb.intfInfo[i].dstEnt.inst ==
                                              sapCb->sctCfg.inst))
                        found = TRUE;
                     break;
                  case SHT_GRPTYPE_ENT:
                     if ((itGlobalCb.intfInfo[i].dstEnt.ent ==
                                              sapCb->sctCfg.ent) &&
                         (itGlobalCb.intfInfo[i].dstEnt.inst ==
                                              sapCb->sctCfg.inst))
                        found = TRUE;
                     break;
                default:
                     /* not possible */
                     break;
               }
            }
         }
         if (found == TRUE)
         {
            sapCb->pst.intfVer = itGlobalCb.intfInfo[i-1].intf.intfVer;
            sapCb->remIntfValid = TRUE;
         }
      }
#endif /* IT_RUG */

      
      /* Initialize the statistics */
      sapCb->sctSts.suId = cfg->suId;
      SGetDateTime(&(sapCb->sctSts.dt));
      /* Initialize primitive timer */
      IT_INITTIMER(&sapCb->tmrPrim);
      /* Update all the applicable assoc's sctSap ptrs */ 
      for (i = 0; i < LIT_MAX_PSP; i++)
      {
         tmpAssocCb = itGlobalCb.assoc[IT_PSPnENDP2ASSOC(i, cfg->suId)];
         if (tmpAssocCb != (ItAssocCb *)NULLP)
         {
            tmpAssocCb->sctSap = sapCb;
         }
      }
   }
   else
   {
#ifdef IT_RUG
      sapCb->remIntfValid = FALSE;

      if (cfg->remIntfValid == TRUE)
      {
         sapCb->remIntfValid = TRUE;
         sapCb->pst.intfVer = cfg->remIntfVer;
      }
      else
      {
         found = FALSE;
         for (i = 0; i < itGlobalCb.numIntfInfo && found == FALSE; i++)
         {
            /* it011.106 - The intfId corrected to SCTIF */
            if (itGlobalCb.intfInfo[i].intf.intfId == SCTIF)
            {
               switch (itGlobalCb.intfInfo[i].grpType)
               {
                  case SHT_GRPTYPE_ALL:
                     if ((itGlobalCb.intfInfo[i].dstProcId ==
                                              sapCb->sctCfg.procId) &&
                         (itGlobalCb.intfInfo[i].dstEnt.ent ==
                                              sapCb->sctCfg.ent) &&
                         (itGlobalCb.intfInfo[i].dstEnt.inst ==
                                              sapCb->sctCfg.inst))
                        found = TRUE;
                     break;
                  case SHT_GRPTYPE_ENT:
                     if ((itGlobalCb.intfInfo[i].dstEnt.ent ==
                                              sapCb->sctCfg.ent) &&
                         (itGlobalCb.intfInfo[i].dstEnt.inst ==
                                              sapCb->sctCfg.inst))
                        found = TRUE;
                     break;
                default:
                     /* not possible */
                     break;
               }
            }
         }
         if (found == TRUE)
         {
            sapCb->pst.intfVer = itGlobalCb.intfInfo[i-1].intf.intfVer;
            sapCb->remIntfValid = TRUE;
         }
      }
#endif /* IT_RUG */
      /* reconfig */
      errFlag = FALSE;
      if ((sapCb->sctCfg.srcPort != cfg->srcPort) ||
          (sapCb->sctCfg.spId != cfg->spId) ||
          (sapCb->sctCfg.ent != cfg->ent) ||
          (sapCb->sctCfg.inst != cfg->inst))
      {
         errFlag = TRUE;
      }
      else
      {
         if (sapCb->sctCfg.srcAddrLst.nmb != cfg->srcAddrLst.nmb)
         {
            errFlag = TRUE;
         }
         else
         {
            for (i = 0; i < sapCb->sctCfg.srcAddrLst.nmb; i++)
            {
               if (sapCb->sctCfg.srcAddrLst.nAddr[i].type !=
                   cfg->srcAddrLst.nAddr[i].type)
               {
                  errFlag = TRUE;
               }
               else
               {
                  switch (sapCb->sctCfg.srcAddrLst.nAddr[i].type)
                  {
                     case CM_NETADDR_IPV4:
                        if (sapCb->sctCfg.srcAddrLst.nAddr[i].u.ipv4NetAddr !=
                            cfg->srcAddrLst.nAddr[i].u.ipv4NetAddr)
                        {
                            errFlag = TRUE;
                        }
                        break;
                     case CM_NETADDR_IPV6:
                        for (j = 0; j < CM_IPV6ADDR_SIZE; j++)
                        {
                           if (sapCb->sctCfg.srcAddrLst.nAddr[i].u.\
                               ipv6NetAddr[j] != 
                               cfg->srcAddrLst.nAddr[i].u.ipv6NetAddr[j])
                           {
                              errFlag = TRUE;
                           }
                        }
                        break;
                     default:
                        errFlag = TRUE;
                        break;
                  }
               }
            }
         }
      }

      if (errFlag == TRUE)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_RECONFIG_FAIL;
         RETVALUE(RFAILED);
      }
      itTcStopTimer(&sapCb->tmrPrim);
      /* Copy config to existing control block */
      (Void) cmMemcpy((U8 *)&(sapCb->sctCfg), (U8 *)cfg, sizeof(ItSctSapCfg));
      sapCb->pst.prior          = cfg->prior;
      sapCb->pst.route          = cfg->route;
      sapCb->pst.selector       = cfg->selector;
      sapCb->pst.region         = cfg->mem.region;
      sapCb->pst.pool           = cfg->mem.pool;
      sta->status = LCM_PRIM_OK;
      sta->reason = LCM_REASON_NOT_APPL;
      RETVALUE(ROK);
   }

   /* Copy config to new control block */
   (Void) cmMemcpy((U8 *)&(sapCb->sctCfg), (U8 *)cfg, sizeof(ItSctSapCfg));

   /* fill in Post struct */
   sapCb->pst.srcEnt         = itGlobalCb.itInit.ent;
   sapCb->pst.srcInst        = itGlobalCb.itInit.inst;
 
    /* it004.106 Set the source procId only in case it is not
     * FTHA or DFTHA otherwise use the value CMFTHA_RES_RSETID
     * This is essential, otherwise M3UA will face problems
     * interfacing with lower layer */
#ifndef ZV
   sapCb->pst.srcProcId      = itGlobalCb.itInit.procId;
#else
   sapCb->pst.srcProcId      = CMFTHA_RES_RSETID;
#endif

   sapCb->pst.dstProcId      = cfg->procId;
   sapCb->pst.dstEnt         = cfg->ent;
   sapCb->pst.dstInst        = cfg->inst;
   sapCb->pst.prior          = cfg->prior;
   sapCb->pst.route          = cfg->route;
   sapCb->pst.selector       = cfg->selector;
   sapCb->pst.region         = cfg->mem.region;
   sapCb->pst.pool           = cfg->mem.pool;

#ifdef IT_FTHA   
#ifdef IT_DIS_SAP
   sapCb->contEnt = ENTSM;  /* stack manager controlling entity */
#else
   sapCb->contEnt = ENTNC;  /* unknown controlling entity */
#endif
#endif /* IT_FTHA */

   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   
   RETVALUE(ROK);
} /* end of itLiCfgSap */


/*
*
*       Fun:      itLiVerifySctSapCfg
*
*       Desc:     This function checks the validity of the SctSapCfg struct
*                 passed to itLiCfgsap
*
*       Ret:      Failure:    RFAILED
*
*                 Success:    ROK
*
*       Notes:    <none>
*
*       File:     it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLiVerifySctSapCfg
(
ItSctSapCfg       *cfg,       /* pointer to SCT SAP configuration */
CmStatus          *sta        /* returned status */
)
#else
PUBLIC S16 itLiVerifySctSapCfg(cfg, sta)
ItSctSapCfg       *cfg;       /* pointer to SCT SAP configuration */
CmStatus          *sta;       /* returned status */
#endif
{
   U16        i;               /* loop index */
   U16        j;               /* loop index */
   ItSctSapCb *tmpSctSapCb;    /* SCT SAP CB */
   U32        k;               /* loop index */
   Bool       addrMatch;       /* Address matched? */

   addrMatch = FALSE;

   TRC2(itLiVerifySctSapCfg)

   ITDBGP(DBGMASK_MI, (itGlobalCb.itInit.prntBuf,
          "itLiVerifySctSapCfg(cfg, sta)\n"));

   /* check tmrPrim */
   if (cfg->tmrPrim.enb == TRUE)
   {
      if (cfg->tmrPrim.val == 0)
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT411,
                    (ErrVal) cfg->tmrPrim.val,
                    "itLiVerifySctSapCfg: Invalid value for tmrPrim");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
      }
   } /* end check tmrPrim */

   /* check tmrSta */
   if (cfg->tmrSta.enb == TRUE)
   {
      if (cfg->tmrSta.val == 0)
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT412,
                    (ErrVal) cfg->tmrSta.val,
                    "itLiVerifySctSapCfg: Invalid value for tmrSta");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
      }
   } /* end check tmrSta */


   /* Check for srcAddrList added */
   for (i = 0; i < cfg->srcAddrLst.nmb; i++)
   {
      if ((cfg->srcAddrLst.nAddr[i].type != CM_NETADDR_IPV4) &&
          (cfg->srcAddrLst.nAddr[i].type != CM_NETADDR_IPV6))
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT413,
                   (ErrVal) cfg->srcAddrLst.nAddr[i].type,
                   "itLiVerifySctSapCfg: srcAddrLst.type != CM_NETADDR_IPV4/6");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
      }
   }
   
    /* First try to find whether the address list is IP_ANY   *
    * If the address list is IP_ANY and belongs to different *
    * suId (that means different lower layer), then we will  *
    * allow the configuration to be successful               *
    * For the time being, we will only allow IPv4 IP_ANY     */

   if ((cfg->srcAddrLst.nmb == 1) &&
       (cfg->srcAddrLst.nAddr[0].type == CM_NETADDR_IPV4) &&
       (cfg->srcAddrLst.nAddr[0].u.ipv4NetAddr == 0))
   {
      for (j = 0; j < itGlobalCb.genCfg.maxNmbSctSap; j++)
      {
         tmpSctSapCb = itGlobalCb.sctSap[j];
         if ((tmpSctSapCb != (ItSctSapCb *)NULLP) && 
                     (cfg->suId == tmpSctSapCb->sctCfg.suId)
                  && (tmpSctSapCb->sctCfg.srcPort == cfg->srcPort)) 
         {
            /* check for first address type of a previously configured addr 
               is sufficient */
            if (tmpSctSapCb->sctCfg.srcAddrLst.nAddr[0].type 
                                              == CM_NETADDR_IPV4)
            {
#if (ERRCLASS & ERRCLS_INT_PAR)
               ITLOGERROR(ERRCLS_INT_PAR, EIT414,
                         (ErrVal) cfg->srcAddrLst.nAddr[i].type,
                "itLiVerifySctSapCfg: overlapping srcAddress in same sap");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
               sta->status = LCM_PRIM_NOK;
               sta->reason = LCM_REASON_INVALID_PAR_VAL;
               RETVALUE(RFAILED);
            }
         }
      }
      sta->status = LCM_PRIM_OK;
      sta->reason = LCM_REASON_NOT_APPL;
      RETVALUE(ROK);
   }

   /* overlapping addresses are not allowed to be configured */
   for (i = 0; i < cfg->srcAddrLst.nmb; i++)
   {
      for (j = 0; j < itGlobalCb.genCfg.maxNmbSctSap; j++)
      {
         tmpSctSapCb = itGlobalCb.sctSap[j];
         if ((tmpSctSapCb != (ItSctSapCb *)NULLP) && 
                     (cfg->suId != tmpSctSapCb->sctCfg.suId)
                  && (tmpSctSapCb->sctCfg.srcPort == cfg->srcPort)) 
         {
            /* check for first address type of a previously configured addr 
               is sufficient */
            if ((cfg->srcAddrLst.nAddr[i].type == CM_NETADDR_IPV4)
              && (tmpSctSapCb->sctCfg.srcAddrLst.nAddr[0].type 
                                              == CM_NETADDR_IPV4))
            {
               /* Check IPV4 address */
               for (k = 0; k < tmpSctSapCb->sctCfg.srcAddrLst.nmb; k++)
               {
                  if (cfg->srcAddrLst.nAddr[i].u.ipv4NetAddr == 
                      tmpSctSapCb->sctCfg.srcAddrLst.nAddr[k].u.ipv4NetAddr)
                  {
                     addrMatch = TRUE;
                     break;
                  }
               }
            }
            else /* Check IPV6 address */
            {
               for (k = 0; k < tmpSctSapCb->sctCfg.srcAddrLst.nmb; k++)
               {
                  IT_CMP_IPV6_ADDR(cfg->srcAddrLst.nAddr[i].u.ipv6NetAddr,
                     tmpSctSapCb->sctCfg.srcAddrLst.nAddr[k].u.ipv6NetAddr,
                              addrMatch);
                  if (addrMatch == TRUE)
                  {
                     break;
                  }
               }
            }
         }
         if (addrMatch == TRUE)
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            ITLOGERROR(ERRCLS_INT_PAR, EIT415,
                      (ErrVal) cfg->srcAddrLst.nAddr[i].type,
               "itLiVerifySctSapCfg: overlapping srcAddress with other sap");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
            sta->status = LCM_PRIM_NOK;
            sta->reason = LCM_REASON_INVALID_PAR_VAL;
            RETVALUE(RFAILED);
         }
      } /* end of for (j = 0; j < itGlobalCb.genCfg.maxNmbSctSap; j++) */
   } /* end of for (i = 0; i < cfg->srcAddrLst.nmb; i++) */
   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   
   RETVALUE(ROK);
} /* end of itLiVerifySctSapCfg */


/*
*
*       Fun:   itLiReleaseSap
*
*       Desc:  Unbind an SCTSAP. Close associations and endpoints by
*              calling itAcReleaseSap. Unbind from SCTP service provider,
*              discard all data queued on the SAP.
*
*       Ret:   Failure: RFAILED
*
*              Success: ROK
*
*       Notes: Called by LMI(control)
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLiReleaseSap
(
SuId          suId,           /* service user SAP ID */
CmStatus      *sta            /* returned status */
)
#else
PUBLIC S16 itLiReleaseSap (suId, sta)
SuId          suId;           /* service user SAP ID */
CmStatus      *sta;           /* returned status */
#endif
{
   S16         ret;           /* return value */
   ItSctSapCb  *sctSapCb;     /* SCT SAP CB */

   TRC2(itLiReleaseSap)

   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "itLiReleaseSap(suId(%d), sta)\n", suId));

   sctSapCb = itGlobalCb.sctSap[suId];
   
   if (sctSapCb->sctSta.hlSt == LIT_SAP_UNBOUND)
   {
      (Void) itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_LI_INV_EVT, LCM_CAUSE_INV_STATE, (U32) suId);
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_NOT_APPL;
      RETVALUE(ROK);
   }

   if ((ret = itAcReleaseSap(suId)) == ROK)
   {
      sta->status = LCM_PRIM_OK;
      sta->reason = LCM_REASON_NOT_APPL;
   }
   else
   {
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_MISC_FAILURE;
      RETVALUE(RFAILED);
   }

   if (sctSapCb->sctSta.hlSt == LIT_SAP_READY)
   {
      (Void) ItLiSctEndpCloseReq(&sctSapCb->pst, sctSapCb->sctCfg.spId, 
                                 sctSapCb->sctSta.spEndpId, SCT_ENDPID_SP);
   }

   /* unbind SAP */
   sctSapCb->sctSta.hlSt = LIT_SAP_UNBOUND;

   RETVALUE(ROK);
} /* end of itLiReleaseSap */


/*
*
*       Fun:   itLiDelSap
*
*       Desc:  Delete an SCTSAP. Call itLiReleaseSap, delete SCTSAPCB.
*
*       Ret:   Failure: RFAILED
*
*              Success: ROK
*
*       Notes: Called by LMI(control)
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLiDelSap
(
SuId          suId,           /* service user ID */
CmStatus      *sta,           /* status */
Bool          itAbort         /* abort flag */
)
#else
PUBLIC S16 itLiDelSap (suId, sta, itAbort)
SuId          suId;           /* service user ID */
CmStatus      *sta;           /* status */
Bool          itAbort;        /* abort flag */
#endif
{
   U32        i;              /* loop index */
   ItAssocCb  *assocCb;       /* Assoc control block */
   ItSctSapCb *sapCb;         /* SCT SAP control block */

   TRC2(itLiDelSap)


   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf,
      "itLiDelSap(suId(%d), sta, itAbort(%d))\n", suId, (U8)itAbort));

   sapCb = itGlobalCb.sctSap[suId];
   
   if (sapCb == (ItSctSapCb *)NULLP)
   {
      sta->status = LCM_PRIM_OK;
      sta->reason = LCM_REASON_NOT_APPL;
      RETVALUE(ROK);
   } 

   if (itAbort == FALSE)
   {
      if (sapCb->sctSta.hlSt != LIT_SAP_UNBOUND)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LIT_REASON_SERVICE_IN_USE;
         RETVALUE(RFAILED);
      }
      /* Check for any dependencies */
      for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)
      {
         if (((assocCb = itGlobalCb.assoc[i]) != (ItAssocCb *)NULLP) &&
             (assocCb->owner != (ItPspCb *)NULLP) &&
             (assocCb->owner->pspCfg.pspId != IT_LOCAL_PSPID) && 
             (assocCb->sctSap != (ItSctSapCb *)NULLP))
         {
            if ((assocCb->sctSap->sctCfg.suId == suId)
                && (assocCb->assocSta->hlSt != LIT_ASSOC_DOWN))
            {
               sta->status = LCM_PRIM_NOK;
               sta->reason = LIT_REASON_SERVICE_IN_USE;
               RETVALUE(RFAILED);
            }
         }
      }
   }

   itTcStopTimer(&sapCb->tmrPrim);
   /* Update all the applicable assoc's sctSap ptrs */ 
   for (i = 0; i < LIT_MAX_PSP; i++)
   {
      assocCb = itGlobalCb.assoc[IT_PSPnENDP2ASSOC(i, sapCb->sctCfg.suId)];
      if (assocCb != (ItAssocCb *)NULLP)
      {
         assocCb->sctSap = (ItSctSapCb *)NULLP;
      }
   }
#ifdef ZV
   /* Sync the deletion of SCT SAP */
   zvRTUpd(CMPFTHA_ACTN_DEL, ZV_SCTSAPCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) sapCb, NULLP);
#endif

   /* Free SctSapCb */
   IT_FREE(sizeof(ItSctSapCb), sapCb);

   /* Clear list entry */
   itGlobalCb.sctSap[suId] = (ItSctSapCb *) NULLP;

   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;

   RETVALUE(ROK);
} /* end of itLiDelSap */


/*
*
*       Fun:   itLiBndSap
*
*       Desc:  Bind an SCTSAP. Call ItLiSctBndReq and start a timer.
*
*       Ret:   Failure: RFAILED
*
*              Success: ROK
*
*       Notes: Called by LMI(control)
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLiBndSap
(
SuId          suId,           /* service user ID */
CmStatus      *sta,           /* returned status */
Bool          first           /* TRUE for first try */
)
#else
PUBLIC S16 itLiBndSap (suId, sta, first)
SuId          suId;           /* service user ID */
CmStatus      *sta;           /* returned status */
Bool          first;          /* TRUE for first try */
#endif
{
   ItSctSapCb  *sapCb;        /* SCT SAP control block */

   TRC2(itLiBndSap)

   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "itLiBndSap(suId(%d), sta)\n", suId));

   sapCb = itGlobalCb.sctSap[suId];

   if (first == TRUE)
   {
      sapCb->nmbBndRetry = 0;
   }
   
   switch (sapCb->sctSta.hlSt)
   {
      case LIT_SAP_UNBOUND:
      case LIT_SAP_WAIT_BNDCFM:
         /* Send BndReq */   
         if (sapCb->nmbBndRetry < IT_MAX_SCT_BND_RETRY)
         {
            sapCb->nmbBndRetry++;

            /* Start bind confirm timer */
            itTcStartTimer(&sapCb->tmrPrim, (PTR)sapCb, IT_TMR_SCT_BND, 
                           &sapCb->sctCfg.tmrPrim);
            sapCb->sctSta.hlSt = LIT_SAP_WAIT_BNDCFM;
            (Void) ItLiSctBndReq(&sapCb->pst, suId, sapCb->sctCfg.spId);
            if (sta != (CmStatus *)NULLP)
            {
               sta->status = LCM_PRIM_OK;
               sta->reason = LCM_REASON_NOT_APPL;
            }
            RETVALUE(ROK);
         }
         /* it013.106 - Use correct event define for the call to itMiStaInd. */
         /* If we haven't exited yet, we send status indication */
         (Void) itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_BND_FAIL, LIT_CAUSE_RETRY_EXCEED, 
                           (U32)suId);

         if (sta != (CmStatus *)NULLP)
         {
            sta->status = LCM_PRIM_NOK;
            sta->reason = LCM_REASON_MISC_FAILURE;
         }
         RETVALUE(RFAILED);
         break;      
      case LIT_SAP_BOUND:
         /* fall through */
     case LIT_SAP_WAIT_OPENCFM:
         /* fall through */
      case LIT_SAP_READY:
         /* fall through */
         if (sta != (CmStatus *)NULLP)
         {
            sta->status = LCM_PRIM_OK;
            sta->reason = LCM_REASON_NOT_APPL;
         }
         RETVALUE(ROK);
         break;
      default:
         if (sta != (CmStatus *)NULLP)
         {
            sta->status = LCM_PRIM_NOK;
            sta->reason = LCM_REASON_INVALID_STATE;
         }
         RETVALUE(RFAILED);
         break;

   }
} /* end of itLiBndSap */


/*
*
*       Fun:   itLiEndpOpen
*
*       Desc:  Open the endpoint on an SCTSAP. 
*              Call ItLiSctEndpOpenReq and start a timer.
*
*       Ret:   Failure: RFAILED
*
*              Success: ROK
*
*       Notes: Called by LMI(control)
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLiEndpOpen
(
SuId          suId,           /* service user ID */
CmStatus      *sta,           /* status */
Bool          first           /* TRUE for first retry */
)
#else
PUBLIC S16 itLiEndpOpen (suId, sta, first)
SuId          suId;           /* service user ID */
CmStatus      *sta;           /* status */
Bool          first;        /* TRUE for first retry */
#endif
{
   ItSctSapCb  *sapCb;        /* SCT SAP control block */
#ifndef SCT_ENDP_MULTI_IPADDR
   CmNetAddr   intfAddr;      /* interface address */
#endif

   TRC2(itLiEndpOpen)

   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "itLiEndpOpen(suId(%d))\n", suId));

   sapCb = itGlobalCb.sctSap[suId];

   if (first == TRUE)
   {
      sapCb->nmbBndRetry = 0;
   }
   
   switch (sapCb->sctSta.hlSt)
   {
      case LIT_SAP_BOUND:
         /* fall through */
      case LIT_SAP_WAIT_OPENCFM:
         if (sapCb->nmbBndRetry < IT_MAX_SCT_BND_RETRY)
         {
            sapCb->nmbBndRetry++;

            /* Start endpoint open confirm timer */
            itTcStartTimer(&sapCb->tmrPrim, (PTR)sapCb, IT_TMR_SCT_ENDPOPEN, 
                           &sapCb->sctCfg.tmrPrim);
            sapCb->sctSta.hlSt = LIT_SAP_WAIT_OPENCFM;
#ifdef SCT_ENDP_MULTI_IPADDR
            (Void) ItLiSctEndpOpenReq(&sapCb->pst, sapCb->sctCfg.spId, 
                                    sapCb->sctCfg.suId, sapCb->sctCfg.srcPort, 
                                    &sapCb->sctCfg.srcAddrLst);
#else /* SCT_ENDP_MULTI_IPADDR */
            /* First address is used for backward compatibility */
            intfAddr = sapCb->sctCfg.srcAddrLst.nAddr[0];
            (Void) ItLiSctEndpOpenReq(&sapCb->pst, sapCb->sctCfg.spId, 
                                    sapCb->sctCfg.suId, sapCb->sctCfg.srcPort, 
                                     &intfAddr);
#endif /* SCT_ENDP_MULTI_IPADDR */
            if (sta != (CmStatus*)NULLP)
            { 
              sta->status = LCM_PRIM_OK;
              sta->reason = LCM_REASON_NOT_APPL;
            }

            RETVALUE(ROK);
         }
         /* it013.106 - Use correct event define for the call to itMiStaInd. */
         /* If we haven't exited yet, we send status indication */
         (Void) itMiStaInd(STITSCTSAP, LCM_CATEGORY_INTERFACE, 
                           LIT_EVENT_EOPEN_FAIL, LIT_CAUSE_RETRY_EXCEED, 
                           (U32)suId);

         RETVALUE(RFAILED);
         break;
      case LIT_SAP_READY:
         /* Do nothing */   
         if (sta != (CmStatus *)NULLP)
         {

            sta->status = LCM_PRIM_OK;
            sta->reason = LCM_REASON_NOT_APPL;
         }
         RETVALUE(ROK);
         break;
      case LIT_SAP_UNBOUND:
         /* fall through */
      case LIT_SAP_WAIT_BNDCFM:
         /* fall through */
      default:
         if (sta != (CmStatus *)NULLP)
         {
            sta->status = LCM_PRIM_NOK;
            sta->reason = LCM_REASON_INVALID_STATE;
         }
         RETVALUE(RFAILED);
         break;

   }
} /* end of itLiEndpOpen */



/*
*
*       Fun:   itLiAssocReq
*
*       Desc:  Send Assoc Request primitive
*
*       Ret:   Failure: RFAILED
*
*              Success: ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLiAssocReq
(
ItAssocCb   *assocCb          /* association CB */
)
#else
PUBLIC S16 itLiAssocReq (assocCb)
ItAssocCb   *assocCb;         /* association CB */
#endif
{
   TRC2(itLiAssocReq)

   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, "itLiAssocReq(assocCb)\n"));

   /* Check that SCT SAP has been bound and endpoint(s) opened */
   if ((assocCb->sctSap == (ItSctSapCb *)NULLP) ||
                        (assocCb->sctSap->sctSta.hlSt != LIT_SAP_READY))
   {
      RETVALUE(RNA);
   }
   /* it009.106 - Added the type of service parameter in association request 
    * to SCTP */
   (Void) ItLiSctAssocReq(&assocCb->sctSap->pst, assocCb->sctSap->sctCfg.spId, 
                       assocCb->sctSap->sctSta.spEndpId, assocCb->assocId, 
                       &assocCb->owner->pspCfg.assocCfg.priDstAddr, 
                       assocCb->owner->pspCfg.assocCfg.dstPort, 
                       assocCb->owner->pspCfg.assocCfg.locOutStrms, 
                       &assocCb->owner->pspCfg.assocCfg.dstAddrLst, 
                       &(assocCb->sctSap->sctCfg.srcAddrLst),
#ifdef SCT3
                       assocCb->owner->pspCfg.assocCfg.tos,
#endif /* SCT3 */
                       (Buffer *)NULLP);

   itTcStartTimer(&assocCb->tmrPrim, (PTR)assocCb, IT_TMR_ASSOC_REQ, 
                     &assocCb->sctSap->sctCfg.tmrPrim);
   RETVALUE(ROK);
} /* end of itLiAssocReq */


/*
*
*       Fun:   itLiAssocRsp
*
*       Desc:  Send Assoc Response primitive
*
*       Ret:   Failure: RFAILED
*
*              Success: ROK
*
*       Notes: Called by itAcAssocInd
*
*       File:  it_bdy4.c
*
*/

/* it009.106 - Added type of service param to itLiAssocRsp */
#ifdef SCT3
#ifdef ANSI
PUBLIC S16 itLiAssocRsp
(
SuId               suId,      /* service user ID */
SctAssocIndParams  *indParam, /* indication parameters */
SctTos             tos,       /* type of service */
U8                 result     /* result */
)
#else
PUBLIC S16 itLiAssocRsp (suId, indParam, tos, result)
SuId               suId;      /* service user ID */       
SctAssocIndParams  *indParam; /* indication parameters */ 
SctTos             tos;       /* type of service */
U8                 result;    /* result */                
#endif
#else /* SCT3 */
#ifdef ANSI
PUBLIC S16 itLiAssocRsp
(
SuId               suId,      /* service user ID */
SctAssocIndParams  *indParam, /* indication parameters */
U8                 result     /* result */
)
#else
PUBLIC S16 itLiAssocRsp (suId, indParam, result)
SuId               suId;      /* service user ID */       
SctAssocIndParams  *indParam; /* indication parameters */ 
U8                 result;    /* result */                
#endif
#endif /* SCT3 */
{
   ItSctSapCb   *sapCb;       /* SCT SAP control block */

   TRC2(itLiAssocRsp)

#ifdef SCT3
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "itLiAssocRsp(suId(%d), indParam, tos(%d), result(%d))\n", 
          suId, tos, result))
#else /* SCT3 */
   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "itLiAssocRsp(suId(%d), indParam, result(%d))\n", 
          suId, result))
#endif /* SCT3 */

   sapCb = itGlobalCb.sctSap[suId];

   if (sapCb->sctSta.hlSt != LIT_SAP_READY)
   {
      RETVALUE(RFAILED);
   }

   /* it009.106 - Added type of service param to association response */
   ItLiSctAssocRsp(&sapCb->pst, sapCb->sctCfg.spId, sapCb->sctSta.spEndpId, 
                   indParam, 
#ifdef SCT3
                   tos,
#endif /* SCT3 */
                   result, (Buffer *)NULLP);

   RETVALUE(ROK);

} /* end of itLiAssocRsp */



/*
*
*       Fun:   itLiTermReq
*
*       Desc:  Terminate an SCTP association
*
*       Ret:   Failure: RFAILED
*
*              Success: ROK
*
*       Notes: Called by itAcTerm
*
*       File:  it_bdy4.c
*
*/

/* it004.106 - Added the abrtFlg param unconditionally, even if 
 * IT_ABORT_ASSOC not defined */
#ifdef ANSI
PUBLIC S16 itLiTermReq
(
ItAssocCb     *assocCb,        /* association control block */
Bool          abrtFlg          /* Abort Flag */
)
#else
PUBLIC S16 itLiTermReq (assocCb, abrtFlg)
ItAssocCb     *assocCb;        /* association control block */
Bool          abrtFlg;         /* Abort Flag */
#endif
{
   ItSctSapCb   *sapCb;       /* SCT SAP control block */
   UConnId      assocId;      /* association ID */
   U8           assocIdType;  /* type of ID */

   TRC2(itLiTermReq)

   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, "itLiTermReq(assocCb)\n"));

   sapCb = assocCb->sctSap;

   if (sapCb->sctSta.hlSt != LIT_SAP_READY)
   {
      RETVALUE(RNA);
   }
   
   if (assocCb->assocSta->hlSt == LIT_ASSOC_DOWN)
   {
      assocId     = assocCb->assocId;
      assocIdType = SCT_ASSOCID_SU;
   }
   else
   {
      assocId     = assocCb->assocSta->spAssocId;
      assocIdType = SCT_ASSOCID_SP;
   }

   /* it004.106 - Added the abrtFlg param unconditionally, even if 
    * IT_ABORT_ASSOC not defined */
   (Void) ItLiSctTermReq(&sapCb->pst, sapCb->sctCfg.spId, 
                      assocId, assocIdType, abrtFlg);

   RETVALUE(ROK);
} /* end of itLiTermReq */


/*
*
*       Fun:   itLiDatReq
*
*       Desc:  Invoke data request primitive
*
*       Ret:   Failure: RFAILED
*
*              Success: ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLiDatReq
(
ItAssocCb     *assocCb,       /* association control block */
SctStrmId     strmNo,         /* stream number */
Buffer        *mBuf           /* message buffer */
)
#else
PUBLIC S16 itLiDatReq (assocCb, strmNo, mBuf)
ItAssocCb     *assocCb;       /* association control block */
SctStrmId     strmNo;         /* stream number */            
Buffer        *mBuf;          /* message buffer */           
#endif
{
   CmNetAddr  tmpNetAddr;     /* temp network address */

   TRC2(itLiDatReq)

   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
                       "itLiDatReq(assocCb, strmNo(%d), mBuf)\n",strmNo));

   if ((assocCb->sctSap == (ItSctSapCb *)NULLP) || 
       (assocCb->sctSap->sctSta.hlSt != LIT_SAP_READY) ||
               (assocCb->assocSta->hlSt == LIT_ASSOC_DOWN))
   {
      RETVALUE(RFAILED);
   }

   tmpNetAddr.type = CM_NETADDR_NOTPRSNT;

   IT_STS_INC_DATA_TX_SCT(assocCb, mBuf);


   /* call trace function, trc flag is checked in the function itself */
   (Void) itMiTrcInd(assocCb->sctSap->sctCfg.spId, LIT_MSG_TX,
                     mBuf);
#ifdef ZV_DFTHA
   /* Queue DAVA message */
   if (itGlobalCb.primQueFlg == TRUE)
   {
      itGlobalCb.l2Lst.evt[itGlobalCb.l2Lst.nmbPrims].event = SCT_EVTDATREQ;
      itGlobalCb.l2Lst.evt[itGlobalCb.l2Lst.nmbPrims].dat.suId = 
                                               assocCb->sctSap->sctSta.suId;
      itGlobalCb.l2Lst.evt[itGlobalCb.l2Lst.nmbPrims].dat.mBuf = mBuf;
      itGlobalCb.l2Lst.evt[itGlobalCb.l2Lst.nmbPrims].dat.strmNo = strmNo;
      itGlobalCb.l2Lst.evt[itGlobalCb.l2Lst.nmbPrims].dat.suAssocId = 
                                               assocCb->assocId;
      itGlobalCb.l2Lst.nmbPrims++;
#if (ERRCLASS & ERRCLS_DEBUG)
      if (itGlobalCb.l2Lst.nmbPrims > (itGlobalCb.genCfg.maxNmbDpcEnt * \
                                       itGlobalCb.genCfg.maxNmbPs * \
                                       itGlobalCb.genCfg.maxNmbPsp * \
                                       itGlobalCb.genCfg.maxNmbSctSap))
      {
         ITLOGERROR(ERRCLS_DEBUG, EIT416, 
                   (ErrVal) itGlobalCb.l2Lst.nmbPrims,
          "More primitives to be queued than max allowd. Change logic!");
      }
#endif /* errclass */
   }
   else
#endif /* ZV_DFTHA */
   (Void) ItLiSctDatReq(&assocCb->sctSap->pst, assocCb->sctSap->sctCfg.spId,
                     assocCb->assocSta->spAssocId, &tmpNetAddr,
                     strmNo, FALSE, FALSE, 0, SCT_PROTID_M3UA, mBuf); 
   RETVALUE(ROK);
} /* end of itLiDatReq */


/*
*
*       Fun:   itLiStaReq
*
*       Desc:  Invoke status request primitive
*
*       Ret:   Failure: RFAILED
*
*              Success: ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLiStaReq
(
ItAssocCb     *assocCb,       /* association control block */
U8            staType         /* status type */
)
#else
PUBLIC S16 itLiStaReq (assocCb, staType)
ItAssocCb     *assocCb;       /* association control block */ 
U8            staType;        /* status type */               
#endif
{
   CmNetAddr  tmpNetAddr;     /* temp network address */

   TRC2(itLiStaReq)

   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "itLiStaReq(assocCb, staType(%d))\n",staType));

   if ((assocCb->sctSap == (ItSctSapCb *)NULLP) || 
       (assocCb->sctSap->sctSta.hlSt == LIT_SAP_UNBOUND) ||
       (assocCb->assocSta->hlSt == LIT_ASSOC_DOWN))
   {
      RETVALUE(RFAILED);
   }

   tmpNetAddr.type = CM_NETADDR_NOTPRSNT;

   (Void) ItLiSctStaReq(&assocCb->sctSap->pst, assocCb->sctSap->sctCfg.spId,
                        assocCb->assocSta->spAssocId, &tmpNetAddr,
                        staType);

   RETVALUE(ROK);
} /* end of itLiStaReq */


/*
*
*       Fun:   itLiBndTmrExp
*
*       Desc:  Bind confirm timer expired. Increment retry counter and
*              retry. If counter is greater than the configured maximum,
*              call MI to indicate control failure.
*
*       Ret:   Failure:
*
*              Success: ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLiBndTmrExp
(
ItSctSapCb    *sctSap         /* SCT SAP control block */
)
#else
PUBLIC S16 itLiBndTmrExp (sctSap)
ItSctSapCb    *sctSap;        /* SCT SAP control block */
#endif
{
   TRC2(itLiBndTmrExp)

   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "itLiBndTmrExp(sctSap)\n"));

   /* Send another bind request */
   RETVALUE(itLiBndSap(sctSap->sctCfg.suId, (CmStatus*)NULLP, FALSE));
} /* end of itLiBndTmrExp */


/*
*
*       Fun:   itLiEndpTmrExp
*
*       Desc:  Endpoint open confirm timer expired. 
*
*       Ret:   Failure:
*
*              Success: ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLiEndpTmrExp
(
ItSctSapCb    *sctSap         /* SCT SAP control block */
)
#else
PUBLIC S16 itLiEndpTmrExp (sctSap)
ItSctSapCb    *sctSap;        /* SCT SAP control block */
#endif
{
   TRC2(itLiEndpTmrExp)

   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "itLiEndpTmrExp(sctSap)\n"));

   /* On expiry send the EndpOpenReq */
   RETVALUE(itLiEndpOpen(sctSap->sctCfg.suId, (CmStatus*)NULLP, FALSE));
} /* end of itLiEndpTmrExp */


/*
*
*       Fun:   itPsmCfgPs
*
*       Desc:  Configure a PS. Creates the PSCB and copies
*              the configuration from the PSCFG to the PSCB. Adds the
*              PSCB to the hash list in the GCB, and to the array in
*              the NCB.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: Called by LMI
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmCfgPs
(
ItPsCfg    *cfg,              /* configuration parameters */
CmStatus   *sta,              /* return status */
U8          cfgMode           /* Ps is being configured by LM or by DRKM */
)
#else
PUBLIC S16 itPsmCfgPs(cfg, sta, cfgMode)
ItPsCfg     *cfg;             /* configuration parameters */
CmStatus    *sta;             /* return status */           
U8           cfgMode;         /* Ps is being configured by LM or by DRKM */
#endif
{
   ItPsCb          *psCb = (ItPsCb *)NULLP;  /* PS control block */
#ifdef ITASP
   ItPspCb         *pspCb;    /* PSP control block */
#endif
   ItAssocCb       *assocCb;  /* Assoc control block */
   ItNwkCb         *nwkCb;    /* network control block */
   U32             i;         /* loop index */
   U32             j;         /* loop index */
   U32             k;         /* loop index */
   Bool            reconf;    /* reconfiguration flag */
   Bool            matchFlag;

   TRC2(itPsmCfgPs)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
          "itPsmCfgPs(cfg, sta)\n"));


   /* verify validity of PsCfg struct */
   if (itPsmVerifyPsCfg(cfg, sta) != ROK)
   {
      RETVALUE(RFAILED);
   }

   reconf = TRUE;
   assocCb = (ItAssocCb *)NULLP;
   if ((psCb = itPsmFindPs(cfg->psId)) == (ItPsCb *) NULLP)
   {
      U16 numPs;              /* number of PS in hash list */
      /* check that there is space in the hash list */
      (Void) cmHashListQuery(&itGlobalCb.ps, CM_HASH_QUERYTYPE_ENTRIES, 
                             &numPs);
      if (numPs >= itGlobalCb.genCfg.maxNmbPs)
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT417, (ErrVal) numPs,
                   "ItMiLitCfgReq: hash list full in case STITPS");
#endif /* ERRCLS_INT_PAR */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_EXCEED_CONF_VAL;
         RETVALUE(RFAILED);
      }
      /* Allocate memory for new Peer Server Cb entry */
      IT_ALLOC(sizeof(ItPsCb), psCb)
      if (psCb == (ItPsCb *)NULLP)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_MEM_NOAVAIL;
         RETVALUE(RFAILED);
      }
      reconf = FALSE;

#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
     if (cfg->lclFlag == FALSE)
     {
        IT_ALLOC(itGlobalCb.genCfg.maxNmbLps * sizeof(ItChldPsCb *),
                 psCb->chldPsLst)
     }
     else
     {
        psCb->chldPsLst = NULLP;
     }

     psCb->nmbChldPs = 0;
#endif /* ITASP && OG_RTE_ON_LPS_STA */

      /* Initialize routing context values */                                
      if (cfgMode == IT_PS_CFG_STAT)
      {
         for (j = 0; j < LIT_MAX_SEP; j++)
         {
            /* Update RC for all assocs */
            for (i = 0; i < cfg->nmbPsp; i++)
            {
               psCb->psSta.psStaEndp[j].rteCtx[cfg->psp[i]].rcValid = TRUE;
               /* For All PS(es) routCtx is copied but it is used only based on 
                * the node type at ipsp modes */
               psCb->psSta.psStaEndp[j].rteCtx[cfg->psp[i]].rCtx = cfg->routCtx;
               psCb->psSta.psStaEndp[j].rteCtx[cfg->psp[i]].mode 
                                                           |= IT_RC_STATIC_REGD;
            }
         }
         psCb->staticCfg = TRUE;
      }
      else
      {
         psCb->staticCfg = FALSE;
      }
   }
   else
   {
      if (cfg->nwkId != psCb->nwk->nwkCfg.nwkId)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_RECONFIG_FAIL;
         RETVALUE(RFAILED);
      }
      /* Check that loadShareMode has not changed */
      if ((psCb->psCfg.mode == LIT_MODE_LOADSHARE) &&
            (cfg->mode == LIT_MODE_LOADSHARE) &&  
            (cfg->loadShareMode != psCb->psCfg.loadShareMode))
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_RECONFIG_FAIL;
         RETVALUE(RFAILED);
      }
      /* Transition between Local PS and Remote PS are not allowed */
      if (cfg->lclFlag != psCb->psCfg.lclFlag)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_RECONFIG_FAIL;
         RETVALUE(RFAILED);
      }
      /* 
       * Check if any PSPs that are active w.r.t. this PS are in the list 
       */

      /* - initialize newly added PSP rc parameter
         or update deleted PSP rc parameter */

      if (cfgMode == IT_PS_CFG_STAT)
      {
         for (i = 0; i < psCb->psCfg.nmbPsp; i++)
         {
            matchFlag = FALSE;
            for (j = 0; j < cfg->nmbPsp; j++)
            {
               if (cfg->psp[j] == psCb->psCfg.psp[i])
               {
                  matchFlag = TRUE;
                  break;
               }
            }
            if ((j == cfg->nmbPsp)&&(!matchFlag))
            {
               /* If PSP is active from any one of the SEP then reconfg fails */
               for (k = 0; k < LIT_MAX_SEP; k++)
               {
                  if (psCb->psSta.psStaEndp[k].aspSt[psCb->psCfg.psp[i]] == 
                                                                 LIT_ASP_ACTIVE)
                  {
                     sta->status = LCM_PRIM_NOK;
                     sta->reason = LCM_REASON_RECONFIG_FAIL;
#if (ERRCLASSS && ERRCLS_INT_PAR)
                     ITLOGERROR(ERRCLS_INT_PAR, EIT418, (ErrVal) psCb->psCfg.psp[i],
                     "itPsmCfgPs: static reconfiguration failed - PSP active/inactive but not listed");
#endif /* ERRRCLCLS_INT_PAR */
                     RETVALUE(RFAILED);
                  }
                  else if (psCb->psSta.psStaEndp[k].rteCtx[psCb->psCfg.psp[i]].\
                                                                      rcValid)
                  {
                  /* - make rcValid = FALSE to complete 
                        deletion of this PSP from the configuring PS */
                
                     psCb->psSta.psStaEndp[k].rteCtx[psCb->psCfg.psp[i]].rcValid
                                                                        = FALSE;
                     psCb->psSta.psStaEndp[k].rteCtx[psCb->psCfg.psp[i]].rCtx =
                                                                     0xffffffff;
                  }
               } /* End of for on LIT_MAX_SEP */
            } /* End of if ((j == cfg->nmbPsp)&&(!matchFlag)) */
         } /* End of for on psCb->psCfg.nmbPsp */

         /* for all SEPs */
         for (k = 0; k < LIT_MAX_SEP; k++)
         {
            /* for all PSPs */
            for (i = 0; i < cfg->nmbPsp; i++)
            {
               psCb->psSta.psStaEndp[k].rteCtx[cfg->psp[i]].rcValid = TRUE;
               psCb->psSta.psStaEndp[k].rteCtx[cfg->psp[i]].rCtx = cfg->routCtx;
               psCb->psSta.psStaEndp[k].rteCtx[cfg->psp[i]].mode |= 
                                                              IT_RC_STATIC_REGD;
            }
         } /* End of for (i = 0; i < cfg->nmbPsp; i++) */

      } /* End of if (cfgMode == IT_PS_CFG_STAT) */


#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
      /* If both configured and reconfigured mode is Loadshare on SLS, do
       * not delete lsCb */
      /* if mode is non SLS based LS then loadshare CB is deleted */ 
      if ((psCb->nmbChldPs != 0) &&
            (cfg->mode == LIT_MODE_LOADSHARE) &&
            (cfg->loadShareMode != LIT_LOADSH_SLS))
      {
         for (i = 0; i < psCb->nmbChldPs; i++)
         {
            /* Remove existing loadsharing context blocks */
            itLscDel(psCb->psCfg.loadShareMode, psCb->chldPsLst[i]->lsCb);

            /* Delete Child PS CB */
            IT_FREE(sizeof(ItChldPsCb), psCb->chldPsLst[i])
            psCb->chldPsLst[i] = NULLP;
         }
         psCb->nmbChldPs = 0;
      }
#else /* !(ITASP && OG_RTE_ON_LPS_STA) */
      /* If both configured and reconfigured mode is Loadshare on SLS, do
       * not delete lsCb */

       /* if mode is non SLS based LS then loadshare CB is deleted */ 
      if ((psCb->lsCb != NULLP) &&
             ((cfg->mode == LIT_MODE_LOADSHARE) && 
              (cfg->loadShareMode != LIT_LOADSH_SLS)))
      {
         /* Remove existing loadsharing context blocks */
         itLscDel(psCb->psCfg.loadShareMode, psCb->lsCb);
         psCb->lsCb = NULLP;
      }
#endif

      /* Remove old PS config from assocCbs */
      for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)
      {
         assocCb = itGlobalCb.assoc[i];
         if (assocCb != (ItAssocCb *)NULLP)
         {
            /* Delete PS from assocCb */
            for (j = 0; j < assocCb->nmbPs; j++)
            {
               if (assocCb->ps[j] == psCb)
               {
                  for (k = j; (S32)k < (assocCb->nmbPs - 1); k++)
                  {
                     assocCb->ps[k] = assocCb->ps[k+1];
                  }
                  assocCb->nmbPs--;
                  break;
               }
            }
         }
      }

      if (cfgMode == IT_PS_CFG_STAT)
      {
         psCb->staticCfg = TRUE;
      }
   }

   /* Copy configuration into new/old Peer Server CB */
   (Void) cmMemcpy((U8 *)&(psCb->psCfg), (U8 *)cfg, sizeof(ItPsCfg));

   psCb->psSta.psId        = cfg->psId;
   for (i = 0; i < LIT_MAX_SEP; i++)
   {
      psCb->psSta.psStaEndp[i].nmbAct = 0;
   }


   if (reconf == FALSE)
   {
      /* mark PsId to be used */
      itGlobalCb.psLstCb.nmbPsCfged++;
      itGlobalCb.psLstCb.psIdFree[cfg->psId] = FALSE;
      
      /* Insert new entry into hash list */
      if (cmHashListInsert(&itGlobalCb.ps, (PTR)psCb,
                           (U8 *)&(psCb->psCfg.psId),
                           sizeof(ItPsId)) != ROK)
      {
         /* Deallocate Peer Server control block */
         IT_FREE(sizeof(ItPsCb), psCb)

         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
      }
      /* Initialize AS-PENDING message queue */
      cmLListInit(&psCb->msgQ);
      
      /* Initialize AS pending timer */
      IT_INITTIMER(&psCb->tmrPend);

      /* Add to array in Network Context CB */
      nwkCb                   = itGlobalCb.nwk[cfg->nwkId];
      nwkCb->ps[nwkCb->nmbPs] = psCb;
      nwkCb->nmbPs++;

      /* Initialize pointer to NwkCb */
      psCb->nwk = itGlobalCb.nwk[cfg->nwkId];

      /* it023.106 - Initialize PS statistics. */
#ifdef LITV6
      psCb->psSts.psId     = cfg->psId;
      /* Initialize the stastics date/time */
      SGetDateTime(&(psCb->psSts.dt));
#endif /* LITV6 */
   }

   /* - At ASP/IPSP if OG_RTE_ON_LPS_STA is defined then the 
    * Loadshare CB will be configured in Child PS CBs later, else configure
    * the CB here itself */
#if !(defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   /* Configure Loadshare CB only for remote PS, and
    * Do not reconfigure loadsharing if lsCb is not deleted */
   /* At SG: if the remote ps mode is:
    * Loadshare mode : the traffic is loadshared (based on loadsharemode -
      RndRobin/SLS) on all active associations from all the SEPs.
    * Override mode : the traffic is loadshared on the active associations from
      all the SEPs (based on SLS only) */

   if ((psCb->psCfg.lclFlag == FALSE) &&
       (psCb->lsCb == NULLP))
   {
      U8  lsType; /* Load sharing mode */

      /* For Act/Standby loadsharing is always based on SLS */
      if (psCb->psCfg.mode == LIT_MODE_ACTSTANDBY)
      {
         lsType = LIT_LOADSH_SLS;
      }
      else
      {
         lsType = cfg->loadShareMode;
      }
      /* Configure load sharing */
      /* - New parameters added for Local PS CB and Child PS CB
       * Index, not required for SGP */
      if (itLscCfg(lsType, psCb, NULLP, NULLP) != ROK)
      {
         /* Deallocate Application Server control block */
         IT_FREE(sizeof(ItPsCb), psCb)
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_MEM_NOAVAIL;
         RETVALUE(RFAILED);
      }
   }
#endif /* !(ITASP && OG_RTE_ON_LPS_STA) */
/* Distributed PS, preconfigured PSP list */
   for (i = 0; i < itGlobalCb.genCfg.maxNmbPsp; i++)
   {
      for (j = 0; j < cfg->nmbPsp; j++)
      {
         if (cfg->psp[j] == i)
         {
            break;
         }
      }
      if (j == cfg->nmbPsp)
      {
      /*  Addition, Local PS at ASP will include all PSPs configured
       * for "to be included in LPS by default" i.e., cfgForAllLps == TRUE */
#ifdef ITASP
         if (itGlobalCb.genCfg.nodeType == LIT_TYPE_ASP)
         {
            /* Get the PSP CB, if cfgForAllLps set and this is local PS then add
             * the PSP into PS CB */
            if (psCb->psCfg.lclFlag == TRUE)
            {
               pspCb = itGlobalCb.psp[i];
               if (pspCb != (ItPspCb *)NULLP)
               {
                  ItAssocCb *tmpAssocCb;

                  tmpAssocCb = (ItAssocCb *)NULLP;
                  if (pspCb->pspCfg.cfgForAllLps == TRUE)
                  {

                     /* Add this PSP into the ps list */
                     /* "i" is pspId */ 
                     psCb->psCfg.psp[psCb->psCfg.nmbPsp++] = (ItPspId)i;
                     /* For all SEPs */
                     /* Initialize Routing Context */
                     for (k = 0; k < LIT_MAX_SEP; k++)
                     {
                        if (psCb->psSta.psStaEndp[k].rteCtx[i].rcValid == FALSE)
                        {
                           psCb->psSta.psStaEndp[k].rteCtx[i].rcValid = TRUE;
                           psCb->psSta.psStaEndp[k].rteCtx[i].rCtx = 
                                                            psCb->psCfg.routCtx;
                           psCb->psSta.psStaEndp[k].rteCtx[i].mode |= 
                                                            IT_RC_STATIC_REGD;
                        }
                        /* Initialize PSP state */
                        psCb->psSta.psStaEndp[k].aspSt[i] = LIT_ASP_DOWN;
                        /* assoc CB modifications */
                        tmpAssocCb = itGlobalCb.assoc[IT_PSPnENDP2ASSOC(i, k)];
                        tmpAssocCb->ps[tmpAssocCb->nmbPs] = psCb;
                        tmpAssocCb->nmbPs++;
                     }
                  } /* End of if : cfgForAllLps == TRUE */
                  else
                  {
                     for (k = 0; k < LIT_MAX_SEP; k++)
                     {
                        psCb->psSta.psStaEndp[k].aspSt[i]  = LIT_ASP_UNSUPP;
                        psCb->psSta.psStaEndp[k].rteCtx[i].rcValid = FALSE;
                     }
                  }
               } /* End of pspCb != NULLP */
            } /* End of if : lclFlag == TRUE */
            else
            {
                for (k = 0; k < LIT_MAX_SEP; k++)
                {
                   psCb->psSta.psStaEndp[k].aspSt[i]          = LIT_ASP_UNSUPP;
                   psCb->psSta.psStaEndp[k].rteCtx[i].rcValid = FALSE;
                }
            }
         }
#endif
#ifdef ITSG
         if (itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP)
         {
            for (k = 0; k < LIT_MAX_SEP; k++)
            {
               psCb->psSta.psStaEndp[k].aspSt[i]          = LIT_ASP_UNSUPP;
               psCb->psSta.psStaEndp[k].rteCtx[i].rcValid = FALSE;
            }
         }
#endif
      }
      else
      {
         UConnId assocId;
         
         assocId = 0;
         if (reconf == FALSE)
         {
            /* initialize state */
            if (itGlobalCb.genCfg.nodeType != LIT_TYPE_SGP)
            {
               /* Local PS state will be ASP's state - excluding ACTIVE */
               /* Local PS state will be marked ACTIVE only on receiving
                * ASPAC-ACK message at ASP and ACTIVE/ACT-ACK at IPSP (SE),
                * at IPSP (DE) it will be marked on receiving ACTIVE-ACK only */
               if (psCb->psCfg.lclFlag == TRUE)
               {
                  /* State updated for all assocs of this ("i") psp */
                  for (k = 0; k < LIT_MAX_SEP; k++)
                  {
                     assocId = IT_PSPnENDP2ASSOC(i, k);
                     psCb->psSta.psStaEndp[k].aspSt[i] = 
                     (U8)((itGlobalCb.assoc[assocId]->assocSta->aspSt 
                           == LIT_ASP_DOWN) ?  LIT_ASP_DOWN : LIT_ASP_INACTIVE);
                  }
               }
               else
               {
                  /* State updated for all assocs of this ("i") psp */
                  for (k = 0; k < LIT_MAX_SEP; k++)
                  {
                     assocId = IT_PSPnENDP2ASSOC(i, k);
                     /* Remote PS state will be ASP's state */
                     psCb->psSta.psStaEndp[k].aspSt[i] = 
                            (U8)(itGlobalCb.assoc[assocId]->assocSta->aspSt);
                  }
               }
            }
            else /* Node Type is SGP */
            {
               for (k = 0; k < LIT_MAX_SEP; k++)
               {
                  assocId = IT_PSPnENDP2ASSOC(i, k);
                  psCb->psSta.psStaEndp[k].aspSt[i] = 
                  (U8)((itGlobalCb.assoc[assocId]->assocSta->aspSt 
                       == LIT_ASP_DOWN) ?  LIT_ASP_DOWN : LIT_ASP_INACTIVE);
               }
            } 
         }
         else /* Reconfiguration case */
         {
            /* For all SEPs */
            for (k = 0; k < LIT_MAX_SEP; k++)
            {
               if ((psCb->psSta.psStaEndp[k].aspSt[i] == LIT_ASP_UNSUPP) ||
                   (psCb->psSta.psStaEndp[k].aspSt[i] == LIT_ASP_DOWN))
               {
                  assocId = IT_PSPnENDP2ASSOC(i, k);
                  if (itGlobalCb.genCfg.nodeType != LIT_TYPE_SGP)
                  {
                     /* initialize state */
                     /* Local PS state will be ASP's state - excluding ACTIVE, 
                      as ASPAC message is required to be send to this newly 
                      added PSP */
                     if (psCb->psCfg.lclFlag == TRUE)
                     {
                        psCb->psSta.psStaEndp[k].aspSt[i] =  
                         (U8)((itGlobalCb.assoc[assocId]->assocSta->aspSt
                           == LIT_ASP_DOWN) ?  LIT_ASP_DOWN : LIT_ASP_INACTIVE);
                     }
                     else
                     {
                        /* Remote PS state will be ASP's state */
                        psCb->psSta.psStaEndp[k].aspSt[i] = 
                         (U8)(itGlobalCb.assoc[assocId]->assocSta->aspSt);
                     }
                  }
                  else /* NodeType is SGP */
                  {
                     /* initialize state */
                     psCb->psSta.psStaEndp[k].aspSt[i] =  
                        (U8)((itGlobalCb.assoc[assocId]->assocSta->aspSt 
                         == LIT_ASP_DOWN) ?  LIT_ASP_DOWN : LIT_ASP_INACTIVE);
                  }
               /* - If the cfgMode is IT_PS_CFG_DYN, do 
                   * not set the Roouting Context here, it is done in calling
                   * functions */
                  if ((cfgMode != IT_PS_CFG_DYN) && 
                      (psCb->psSta.psStaEndp[k].rteCtx[i].rcValid == FALSE))
                  {
                     psCb->psSta.psStaEndp[k].rteCtx[i].rcValid = TRUE;
                     psCb->psSta.psStaEndp[k].rteCtx[i].rCtx    = cfg->routCtx;
                     psCb->psSta.psStaEndp[k].rteCtx[i].mode  
                                                          |= IT_RC_STATIC_REGD;
                  }
               }   
            }    /* end of for on (k = 0; k < LIT_MAX_SEP; k++) */
         } /* End of reconfiguration case */
         /* all assocCb of this PSP is updated */
         for (k = 0; k < LIT_MAX_SEP; k++)
         {         
            assocId = IT_PSPnENDP2ASSOC(i, k); /* i is pspId and k is sctSuId */
            itGlobalCb.assoc[assocId]->ps[itGlobalCb.assoc[assocId]->nmbPs] 
                                                                         = psCb;
            itGlobalCb.assoc[assocId]->nmbPs++;
         }
      } /* End of PSP found */
   } /* End of for maxNmbPsp */
   if (reconf == FALSE)
   {
      psCb->psSta.asSt = LIT_AS_DOWN;
   }
   /* At ASP, State is evaluated in all cases, at SGP it is done only if
    * PS is reconfigured */
   if (((itGlobalCb.genCfg.nodeType == LIT_TYPE_ASP) 
          && ((cfgMode == IT_PS_CFG_STAT) || (reconf == TRUE))) ||
       ((itGlobalCb.genCfg.nodeType  == LIT_TYPE_SGP) && (reconf == TRUE)))
   {
      /* Re-evaluate states */
      ItRtCtx  locRtCtx;   /* local route context */
      locRtCtx.rtCtx = psCb->psCfg.psId;
      (Void) itPsmPsEvt(&locRtCtx, (UConnId) 0, IT_EVT_RECONFIG, 0);
   }

   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   
   RETVALUE(ROK);
} /* end of itPsmCfgPs */


/*
*
*       Fun:   itPsmVerifyPsCfg
*
*       Desc:  This function checks the validity of the PsCfg struct passed
*              to itPsmCfgPs to configure an PS
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmVerifyPsCfg
(
ItPsCfg    *cfg,              /* configuration parameters */
CmStatus   *sta               /* return status */
)
#else
PUBLIC S16 itPsmVerifyPsCfg(cfg, sta)
ItPsCfg     *cfg;             /* configuration parameters */
CmStatus    *sta;             /* return status */           
#endif
{

   TRC2(itPsmVerifyPsCfg)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
          "itPsmVerifyPsCfg(psCfg, sta)\n"));

   /* check that nwkId is within range */
   if (cfg->nwkId >= itGlobalCb.genCfg.maxNmbNwk)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT419,
                 (ErrVal) cfg->nwkId,
                 "itPsmVerifyPsCfg: nwkId >= maxNmbNwk");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_INVALID_NWKID;
      RETVALUE(RFAILED);
   }

   /* check that nwkId has been configured */
   if (itGlobalCb.nwk[cfg->nwkId] == (ItNwkCb *) NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT420, (ErrVal) cfg->nwkId,
                 "itPsmVerifyPsCfg: network not configured");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_INVALID_NWKID;
      RETVALUE(RFAILED);
   }
   /* Check:  local ps is not allowed at SGP */
#ifdef ITSG
   if (itGlobalCb.genCfg.nodeType == LIT_TYPE_SGP)
   {
      if (cfg->lclFlag == TRUE)
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT421, (ErrVal) NULLD,
            "itPsmVerifyPsCfg: Local PC configuration not allwd at SGP");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
      }
   }
#endif

   /* check mode */
   switch (cfg->mode)
   {
      case LIT_MODE_ACTSTANDBY:
         if (cfg->nmbActPspReqd != 1)
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            ITLOGERROR(ERRCLS_INT_PAR, EIT422, (ErrVal) NULLD,
               "itPsmVerifyPsCfg: nmbActPspReqd must be 1 for override mode");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
            sta->status = LCM_PRIM_NOK;
            sta->reason = LCM_REASON_INVALID_PAR_VAL;
            RETVALUE(RFAILED);
         }
         break;
      
      case LIT_MODE_LOADSHARE:
         if (cfg->nmbActPspReqd < 1)
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            ITLOGERROR(ERRCLS_INT_PAR, EIT423, (ErrVal) NULLD,
               "itPsmVerifyPsCfg: nmbActPspReqd must be >=1 for load sharing");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
            sta->status = LCM_PRIM_NOK;
            sta->reason = LCM_REASON_INVALID_PAR_VAL;
            RETVALUE(RFAILED);
         }
         switch (cfg->loadShareMode)
         {
            /* following 5 cases fall through */
            case LIT_LOADSH_RNDROBIN:
            case LIT_LOADSH_SLS:
               break;
            default:
#if (ERRCLASS & ERRCLS_INT_PAR)
               ITLOGERROR(ERRCLS_INT_PAR, EIT424, (ErrVal) cfg->loadShareMode,
                  "itPsmVerifyPsCfg: Invalid value for loadShareMode");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
               sta->status = LCM_PRIM_NOK;
               sta->reason = LCM_REASON_INVALID_PAR_VAL;
               RETVALUE(RFAILED);
         }
         /* At SGP, locPs is always FALSE */
         if (cfg->lclFlag == TRUE)
         {
            if (cfg->nmbActPspReqd != 1)
            {
#if (ERRCLASS & ERRCLS_INT_PAR)
               ITLOGERROR(ERRCLS_INT_PAR, EIT425, (ErrVal) NULLD,
                "itPsmVerifyPsCfg: nmbActPspReqd must be 1 for Local PS");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
               sta->status = LCM_PRIM_NOK;
               sta->reason = LCM_REASON_INVALID_PAR_VAL;
               RETVALUE(RFAILED);
            }
         }
         break;
      
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT426, (ErrVal) cfg->mode,
                    "itPsmVerifyPsCfg: invalid mode");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
   }

   /* check nmbPsp, nmbActPspReqd  */
   if (cfg->nmbPsp > LIT_MAX_PSP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT427, (ErrVal) cfg->nmbPsp,
                 "itPsmVerifyPsCfg: invalid nmbPsp Configured");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }
   if (((cfg->nmbPsp > 0 ) && (cfg->nmbActPspReqd > cfg->nmbPsp)) ||
        (cfg->nmbActPspReqd > LIT_MAX_PSP))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT428, (ErrVal) cfg->nmbActPspReqd,
                 "itPsmVerifyPsCfg: nmbActPspReqd > nmbPsp");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   /* Verify Dynamic and Static List of PSP */

   if (itPsmVerifyPspList(cfg, sta) != ROK)
   {
      RETVALUE(RFAILED);
   }

   /* check reqAvail */
   if ((cfg->reqAvail != TRUE) && (cfg->reqAvail != FALSE))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT429,
           (ErrVal) cfg->reqAvail,
           "itPsmVerifyPsCfg: Invalid value for reqAvail");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }
   
   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   
   RETVALUE(ROK);
} /* end of itPsmVerifyPsCfg */


/*
*
*       Fun:   itPsmCfgPsp
*
*       Desc:  Configures a PSP. Creates the PSPCB and ACB,
*              and copies the configuration from CFG. Adds the PSPCB and
*              ACB to the respective lists in the GCB.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: Called by LMI
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmCfgPsp
(
ItPspCfg    *cfg,             /* configuration parameters */
CmStatus    *sta              /* return status */
)
#else
PUBLIC S16 itPsmCfgPsp(cfg, sta)
ItPspCfg    *cfg;             /* configuration parameters */
CmStatus    *sta;             /* return status */           
#endif
{
   ItPspCb     *pspCb;        /* PSP control block */
   ItAssocCb   *assocCb;      /* association control block */
   ItPspId     pspId;         /* PSP ID */
#ifdef ITASP
   ItPsCb      *prevPsEnt;    /* Previous PS entry */
   ItPsCb      *psCb;         /* PS control block  */
#endif
   /* loop index */
   U16         i;             /* loop index */
   U16         j;             /* loop index */

   TRC2(itPsmCfgPsp)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
          "itPsmCfgPsp()\n"));

   if (cfg != (ItPspCfg *)NULLP)
   {
      if (itPsmVerifyPspCfg(cfg, sta) != ROK)
      {
         RETVALUE(RFAILED);
      }
   }

   pspId = (U16)((cfg == (ItPspCfg *)NULL) ? IT_LOCAL_PSPID : cfg->pspId);

   if ((pspId != IT_LOCAL_PSPID) && (itGlobalCb.psp[pspId] != (ItPspCb *)NULLP))
   {
      /* reconfiguration */
      pspCb = itGlobalCb.psp[pspId];

      if (itAcChkReconfig( &(pspCb->pspCfg.assocCfg), &(cfg->assocCfg), pspCb) != 
          ROK)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_RECONFIG_FAIL;
         RETVALUE(RFAILED);
      }
      if (cfg->pspType != pspCb->pspCfg.pspType)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_RECONFIG_FAIL;
         RETVALUE(RFAILED);
      }
      /* Check all assoc's state is DOWN before modifying selfAspId */
      if (cfg->selfAspId != pspCb->pspCfg.selfAspId) 
      {
         for (i = 0; i < LIT_MAX_SEP; i++)
         {
            if (pspCb->assoc[i].assocSta->aspSt != LIT_ASP_DOWN)
            {
               sta->status = LCM_PRIM_NOK;
               sta->reason = LCM_REASON_RECONFIG_FAIL;
               RETVALUE(RFAILED);         
            }
         }
      }
#ifdef ITASP
      if (cfg->cfgForAllLps != pspCb->pspCfg.cfgForAllLps)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_RECONFIG_FAIL;
         RETVALUE(RFAILED);
      }
#ifdef SGVIEW
      /* Check all the assoc's aspSt is LIT_ASP_DOWN */
      if (cfg->sgId != pspCb->pspCfg.sgId) 
      {
         if ((itGlobalCb.genCfg.nodeType == LIT_TYPE_ASP) &&
             (pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP))
         {
            for (i = 0; i < LIT_MAX_SEP; i++)
            {
               if (pspCb->pspSta.assocSta[i].aspSt != LIT_ASP_DOWN)
               {
                  sta->status = LCM_PRIM_NOK;
                  sta->reason = LCM_REASON_RECONFIG_FAIL;
                  RETVALUE(RFAILED);         
               }
            } /* end of for LIT_MAX_SEP */
         } /* End of if nodeType ASP and remote is SGP */
      } /* end of if (cfg->sgId != pspCb->pspCfg.sgId)  */
#endif /* SGVIEW */
#endif
      /* Copy config to new PSP CB */
      (Void) cmMemcpy((U8 *)&(pspCb->pspCfg), (U8 *)cfg, sizeof(ItPspCfg));
   }
   else
   {
      /* Allocate memory for Peer Signalling Process control block */
      IT_ALLOC(sizeof(ItPspCb), pspCb)
      if (pspCb == (ItPspCb *)NULLP)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_MEM_NOAVAIL;
         RETVALUE(RFAILED);
      }

      itGlobalCb.psp[pspId] = pspCb;

      if (pspId == IT_LOCAL_PSPID)
      {
         /* Special init for local SP */
         IT_ZERO(&pspCb->pspCfg, sizeof(ItPspCfg))
         pspCb->pspCfg.pspId           = IT_LOCAL_PSPID;
         pspCb->pspCfg.pspType         = LIT_PSPTYPE_LOCAL;

      }
      /* for all assocCb  */
      for (i = 0; i < LIT_MAX_SEP; i++)
      {
         assocCb  = &(pspCb->assoc[i]);
         assocCb->assocId    = IT_PSPnENDP2ASSOC(pspId, (SuId)i);
         itGlobalCb.assoc[assocCb->assocId]  = assocCb;
         assocCb->assocSta = &(pspCb->pspSta.assocSta[i]); 

         if (pspId != IT_LOCAL_PSPID)
         {
            /* Initialize assoc timers */
            IT_INITTIMER(&assocCb->tmrHBeatRX);
            IT_INITTIMER(&assocCb->tmrAspm);   
            IT_INITTIMER(&assocCb->tmrHBeatTX);
            IT_INITTIMER(&assocCb->tmrDunaSettle);
            IT_INITTIMER(&assocCb->tmrReconnect);

            /* Initialize PSP association status */
            pspCb->pspSta.assocSta[i].hlSt   = LIT_ASSOC_DOWN;
            pspCb->pspSta.assocSta[i].readySetupSt = LIT_RDST_DEFAULT;
         }
         else
         {
            /* Initialize PSP association status */
            pspCb->pspSta.assocSta[i].hlSt   = LIT_ASSOC_ACTIVE;
            pspCb->pspSta.assocSta[i].readySetupSt = LIT_RDST_OK;
         }
         
         /* It015.104 cleanring spAssocId on Association de-activation */
         pspCb->pspSta.assocSta[i].spAssocId = (UConnId)NULLD;
         assocCb->owner                = pspCb;
         /* assocCb->sctSap will be NULLP if SAP is not configured */
         assocCb->sctSap               = itGlobalCb.sctSap[i];
         assocCb->congActive           = FALSE;
         if (pspId != IT_LOCAL_PSPID)
         {
            assocCb->outStrms             = cfg->assocCfg.locOutStrms;
            (Void)cmLListInit(&assocCb->congQ);
         
            IT_INITTIMER(&assocCb->tmrCong);
            IT_INITTIMER(&assocCb->tmrPrim);
            /* RegReqTmrCb assocId's & reqtype initialized here as it will not 
               change */
            /* Only two (index = 0, 1) TmrCbs are used, one each for reg and 
               dereg request */
            assocCb->regReqTmrCb[0].assocId = assocCb->assocId;
            assocCb->regReqTmrCb[0].reqType = LIT_REG_REQ;
            assocCb->regReqTmrCb[1].assocId = assocCb->assocId;
            assocCb->regReqTmrCb[1].reqType = LIT_DEREG_REQ;
         }
         
         pspCb->pspSta.assocSta[i].aspSt = LIT_ASP_DOWN;
         /* Other assocSta params, i.e., inhibited, nmbAct, retryCount
            and regReq list are updated outside this loop */

      } /* end of for on LIT_MAX_SEP */

      if (pspId != IT_LOCAL_PSPID)
      {
         /* Copy config to new PSP CB */
         (Void) cmMemcpy((U8 *)&(pspCb->pspCfg), (U8 *)cfg, sizeof(ItPspCfg));
      }

      /* Initialize the stastics date/time */
      SGetDateTime(&(pspCb->pspSts.dt));
      /* For all the SEPs */
      /* Allocate memory for list of PS pointers */
      for (i = 0; (i < LIT_MAX_SEP); i++)
      {
         IT_ALLOC(itGlobalCb.genCfg.maxNmbPs * sizeof(ItPsCb *), 
                  pspCb->assoc[i].ps)
         if (pspCb->assoc[i].ps == (ItPsCb **)NULLP)
         {
            /* Deallocate all the allocated ps pointers */ 
            for (j = 0; (j < i); j++)
            {
               if (pspCb->assoc[j].ps != (ItPsCb **)NULLP)
               {
                  IT_FREE((itGlobalCb.genCfg.maxNmbPs * sizeof(ItPsCb *)),
                           pspCb->assoc[j].ps)
               }
            }
            sta->status = LCM_PRIM_NOK;
            sta->reason = LCM_REASON_MEM_NOAVAIL;
            RETVALUE(RFAILED);
         }
         pspCb->assoc[i].nmbPs  = 0;
      }
      
      /* Initialize PSP status/statistics */
      pspCb->pspSta.pspId     = pspId;
      pspCb->pspSts.pspId     = pspId;
      /* initialize assocSta for all the associations */
      for (i = 0; i < LIT_MAX_SEP; i++)
      {
         pspCb->pspSta.assocSta[i].inhibited = FALSE;
         pspCb->pspSta.assocSta[i].nmbAct    = 0;
         if (pspId != IT_LOCAL_PSPID)
         {
            (Void)cmLListInit(&pspCb->assoc[i].regReq);
         }
      }

#ifdef ITASP
      if (pspCb->pspCfg.cfgForAllLps == TRUE)
      {
         /* Search all LPS in layer */
         prevPsEnt = (ItPsCb *) NULLP;
         while (cmHashListGetNext(&itGlobalCb.ps, (PTR) prevPsEnt,
                               (PTR *) &psCb) ==  ROK)
         {
            /* check if this PS is local? */
            if (psCb->psCfg.lclFlag  == TRUE)
            {
               /* Reconfigure LPS */
               psCb->psCfg.psp[psCb->psCfg.nmbPsp++] = pspId;
               /* Initialize Routing Context */
               /* RC is initialized for all assocs of this PSP */
               for (i = 0; i < LIT_MAX_SEP; i++)
               {
                  if (psCb->psSta.psStaEndp[i].rteCtx[pspId].rcValid == FALSE)
                  {
                     psCb->psSta.psStaEndp[i].rteCtx[pspId].rcValid = TRUE;
                     psCb->psSta.psStaEndp[i].rteCtx[pspId].rCtx =
                                                           psCb->psCfg.routCtx;
                     psCb->psSta.psStaEndp[i].rteCtx[pspId].mode |= 
                                                             IT_RC_STATIC_REGD;
                  }
                  /* Initialize PSP state */ /* Done for all assocs */
                  psCb->psSta.psStaEndp[i].aspSt[pspId] = LIT_ASP_DOWN;
                  /* PSP CB modifications */
                  pspCb->assoc[i].ps[pspCb->assoc[i].nmbPs] = psCb;
                  pspCb->assoc[i].nmbPs++;
               }
            } /* End of if : lclFlag == TRUE */
            prevPsEnt = psCb;
         } /* end while */
      } /* End of If: cfgForAllLps == TRUE */
#endif /* ITASP */
   }

   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   
   RETVALUE(ROK);
} /* end of itPsmCfgPsp */


/*
*
*       Fun:   itPsmVerifyPspCfg
*
*       Desc:  This function checks the validity of the PspCfg struct
*              passed to itPsmCfgPsp
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmVerifyPspCfg
(
ItPspCfg    *cfg,             /* configuration parameters */ 
CmStatus    *sta              /* return status */            
)
#else
PUBLIC S16 itPsmVerifyPspCfg(cfg, sta)
ItPspCfg    *cfg;             /* configuration parameters */ 
CmStatus    *sta;             /* return status */            
#endif
{
   U16      i;                /* index */

   TRC2(itPsmVerifyPspCfg)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
          "itPsmVerifyPspCfg(pspCfg, sta)\n"));

   /* check pspId in range */
   if (cfg->pspId >= itGlobalCb.genCfg.maxNmbPsp)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
     ITLOGERROR(ERRCLS_INT_PAR, EIT430, (ErrVal) cfg->pspId,
                "itPsmVerifyPspCfg: pspId >= maxNmbPsp");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
     sta->status = LCM_PRIM_NOK;
     sta->reason = LIT_REASON_INVALID_PSPID;
     RETVALUE(RFAILED);
   }
   /* check that nwkId < maxNmbNwk */
   if (cfg->nwkId >= itGlobalCb.genCfg.maxNmbNwk)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT431,
                    (ErrVal) cfg->nwkId,
                    "itPsmVerifyPspCfg: nwkId >= maxNmbNwk");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_INVALID_NWKID;
      RETVALUE(RFAILED);
   }
   /* check valid nwkId */
   if (itGlobalCb.nwk[cfg->nwkId] == (ItNwkCb *) NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT432,
                    (ErrVal) cfg->nwkId,
                    "itPsmVerifyPspCfg: network not configured");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_INVALID_NWKID;
      RETVALUE(RFAILED);
   }

   /* check valid nwkApp */
   if ((cfg->nwkAppIncl != TRUE) && (cfg->nwkAppIncl != FALSE)) 
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT433,
                    (ErrVal) cfg->nwkAppIncl,
                    "itPsmVerifyPspCfg: invalid nwkAppIncl flag value");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   /* check validity of rxTxAspId */
   if ((cfg->rxTxAspId != TRUE) && (cfg->rxTxAspId != FALSE)) 
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT434,
                    (ErrVal) cfg->rxTxAspId,
                    "itPsmVerifyPspCfg: invalid rxTxAspId flag value");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }
   /* check valid pspType */
   switch (cfg->pspType)
   {
      /* following 3 cases fall through */
      case LIT_PSPTYPE_ASP: 
      case LIT_PSPTYPE_SGP:
         break;
      case LIT_PSPTYPE_IPSP:
         switch (cfg->ipspMode)
         {
            case LIT_IPSPMODE_SE:
            case LIT_IPSPMODE_DE:
               break;
            default:
#if (ERRCLASS & ERRCLS_INT_PAR)
               ITLOGERROR(ERRCLS_INT_PAR, EIT435,
                             (ErrVal) cfg->ipspMode,
                             "itPsmVerifyPspCfg: invalid ipspMode");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
               sta->status = LCM_PRIM_NOK;
               sta->reason = LCM_REASON_INVALID_PAR_VAL;
               RETVALUE(RFAILED);
         }
         break;
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT436,
                       (ErrVal) cfg->pspType,
                       "itPsmVerifyPspCfg: invalid pspType value");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
   }
   

   if (cfg->assocCfg.locOutStrms < IT_MIN_STRMS)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT437,
                 (ErrVal) cfg->assocCfg.locOutStrms,
                 "itPsmVerifyPspCfg: locOutStrms < 2");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   if ((cfg->assocCfg.priDstAddr.type != CM_NETADDR_IPV4) &&
       (cfg->assocCfg.priDstAddr.type != CM_NETADDR_IPV6))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      ITLOGERROR(ERRCLS_INT_PAR, EIT438,
                 (ErrVal) cfg->assocCfg.priDstAddr.type,
                 "itPsmVerifyPspCfg: priDstAddr.type != CM_NETADDR_IPV4/6");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      sta->status = LCM_PRIM_NOK;
      sta->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   for (i = 0; i < cfg->assocCfg.dstAddrLst.nmb; i++)
   {
      if ((cfg->assocCfg.dstAddrLst.nAddr[i].type != CM_NETADDR_IPV4) &&
          (cfg->assocCfg.dstAddrLst.nAddr[i].type != CM_NETADDR_IPV6))
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT439,
                    (ErrVal) cfg->assocCfg.dstAddrLst.nAddr[i].type,
                    "itPsmVerifyPspCfg: dstAddrLst.type != CM_NETADDR_IPV4/6");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
      }
   }


   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   
   RETVALUE(ROK);
} /* end of itPsmVerifyPspCfg */


/*
*
*       Fun:   itPsmFindPs
*
*       Desc:  Find the PSCB with the specified ID. Searches the list of
*              PSCBs in the GCB. Returns the NULL pointer if the PSCB
*              does not exist for the specified ID.
*
*       Ret:   Failure:           NULL
*
*              Success:           Pointer to PSCB
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC ItPsCb *itPsmFindPs
(
ItPsId   psId                 /* Application Server ID */
)
#else
PUBLIC ItPsCb *itPsmFindPs(psId)
ItPsId   psId;                /* Application Server ID */
#endif
{
   ItPsCb   *psCb = (ItPsCb *)NULLP;   /* PS control block */

   TRC2(itPsmFindPs)

#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
          "itPsmFindPs(psId(%d))\n", psId));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
          "itPsmFindPs(psId(%ld))\n", psId));
#endif
   /* Search hash list for Application Server control block */
   if (cmHashListFind(&itGlobalCb.ps, (U8 *) &psId, 
                      sizeof(ItPsId), 0, (PTR *) &psCb) != ROK)
   {
      RETVALUE((ItPsCb *)NULLP);
   }

   RETVALUE(psCb);
} /* end of itPsmFindPs */


/*
*
*       Fun:   itPsmDelPs
*
*       Desc:  Call itPsmFindPs to locate the PSCB. Check for remaining
*              dependencies. Return fail status if any remain, else
*              remove from global and network CB lits and destroy.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: Called by LMI
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmDelPs
(
ItPsId     psId,              /* Application Server ID */
CmStatus   *sta,              /* return status */
Bool       itAbort            /* abort flag */
)
#else
PUBLIC S16 itPsmDelPs(psId, sta, itAbort)
ItPsId      psId;             /* Application Server ID */
CmStatus    *sta;             /* return status */        
Bool        itAbort;          /* abort flag */           
#endif
{
   ItPsCb      *psCb;         /* PS control block */
   ItNwkCb     *nwkCb;        /* network control block */
   U32         i;             /* loop index */
   U32         j;             /* loop index */

   TRC2(itPsmDelPs)

#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
          "itPsmDelPs(psId(%d), sta, itAbort(%d))\n", psId, (U8)itAbort));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
          "itPsmDelPs(psId(%ld), sta, itAbort(%d))\n", psId, (U8)itAbort));
#endif
   /* Initialize psCb */
   psCb = (ItPsCb *)NULLP;

   /* Get psCb */
   psCb = itPsmFindPs(psId);

   if (psCb == (ItPsCb *)NULLP)
   {
      sta->status = LCM_PRIM_OK;
      sta->reason = LCM_REASON_NOT_APPL;
      RETVALUE(ROK);
   }

   if ((psCb->psCfg.nmbPsp == 0) && (psCb->psSta.asSt == LIT_AS_ACTIVE))
   {
   /* Ideally this if will never be true as a PS cannot go ACTIVE without
      having any PSPs, but this case has been added to take care of any 
      error situation */
      itAbort = TRUE;
   }
   if (itAbort == FALSE)
   {
      /* changes for deleting a remote PS at ASP in active state
         check for dependencies moved up earlier it was done at the bottom
         this if statement */
      /* check to see if any routes still pointing to this PS */
      if (itAtChkPsDeps(psCb) != ROK)
      {
         /* if so, fail - routes have to be deleted first */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LIT_REASON_SERVICE_IN_USE;
         RETVALUE(RFAILED);
      }

#ifdef ITASP
      /* Special case added to Delete an Active Remote PS at ASP
         this is required as SGP might be serving other PS and
         we want to stop the traffic towards this PS without affecting
         the other PSs. Before deleting the PS make it Inactive.
         So that there is no mismatch of data in different control blocks 
      */
      if (psCb->psSta.asSt == LIT_AS_ACTIVE)
      { 
         ItRtCtx  locRtCtx;   /* local route context */
         U16      k;          /* loop index */
      
         locRtCtx.rtCtx = psCb->psCfg.psId;
         if ((psCb->psCfg.lclFlag != TRUE) &&
             (itGlobalCb.psp[psCb->psCfg.psp[0]] != NULL) &&
             (itGlobalCb.psp[psCb->psCfg.psp[0]]->pspCfg.pspType == 
                                                            LIT_PSPTYPE_SGP)) 
         {
            for (i = 0; i < psCb->psCfg.nmbPsp; i++)
            {
               for (k = 0; k < LIT_MAX_SEP; k++)
               {
                  
                  (Void) itPsmPsEvt(&locRtCtx,
                                     IT_PSPnENDP2ASSOC(psCb->psCfg.psp[i], k),
                                            IT_EVT_ASP_IA_ACK, 0);
               }
            } 
         }
      }
#endif
      
      /* changes for deleting a PS in inactive state 
         earlier PS could only be deleted in Down state */
      if ((psCb->psSta.asSt != LIT_AS_DOWN) &&
          (psCb->psSta.asSt != LIT_AS_INACTIVE))
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LIT_REASON_SERVICE_IN_USE;
         RETVALUE(RFAILED);
      }
   }
   
   /* Stop AS-PENDING timer */
   itTcStopTimer(&psCb->tmrPend);
   
   /* Empty AS-PENDING queue */
   while (cmLListLen(&psCb->msgQ) > 0)
   {
      ItMupMsg *msg;          /* temp message */
      /* remove message from head of list */
      msg = (ItMupMsg *) cmLListDelFrm(&psCb->msgQ,
                         cmLListFirst(&psCb->msgQ));
      IT_DROPDATA(msg->mBuf);
      IT_FREE(sizeof(ItMupMsg), msg);
      itGlobalCb.nmbMsg--;
   }

   /* Remove entry from hash list */
   if (cmHashListDelete(&itGlobalCb.ps, (PTR) psCb) != ROK)
   {
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_INVALID_PSID;
      RETVALUE(RFAILED);
   }

   /* Delete loadsharing context configuration */
   /* - At ASP/IPSP if OG_RTE_ON_LPS_STA is defined delete Child 
    * PS CBs. Else delete Loadshare CB in PS CB */
#if !(defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   if (psCb->lsCb != NULLP)
   {
      /* For a PS in Act/Stndby the ls mode is SLS */
      itLscDel((U8)((psCb->psCfg.mode == LIT_MODE_ACTSTANDBY) ? LIT_LOADSH_SLS 
                                       : psCb->psCfg.loadShareMode), psCb->lsCb);
   }
#else /* ITASP && OG_RTE_ON_LPS_STA */
   /* Check if Child PS List exists */
   if (psCb->chldPsLst != NULLP)
   {
      for (i = 0; i < psCb->nmbChldPs; i++)
      {
         /* Remove loadsharing context block */
         itLscDel((U8)((psCb->psCfg.mode == LIT_MODE_ACTSTANDBY) ? LIT_LOADSH_SLS 
                                       : psCb->psCfg.loadShareMode),
                                       psCb->chldPsLst[i]->lsCb);

         /* Delete Child PS CB */
         IT_FREE(sizeof(ItChldPsCb), psCb->chldPsLst[i])
      }
 
      IT_FREE(itGlobalCb.genCfg.maxNmbLps * sizeof(ItChldPsCb *), 
              psCb->chldPsLst)
   }

   /* If this is a Local PS, check for corresponding Child PS CBs in Remote
    * PSs and delete if present */
   if (psCb->psCfg.lclFlag == TRUE)
   {
      ItPsCb  *prevPsEnt;   /* Pointer to previous PS CB */
      ItPsCb  *rpsCb;       /* Pointer to Remote PS CB */

      prevPsEnt = (ItPsCb *) NULLP;
      while (cmHashListGetNext(&itGlobalCb.ps, (PTR) prevPsEnt,
                               (PTR *) &rpsCb) ==  ROK)
       {
          if ((rpsCb->psCfg.lclFlag == FALSE) && (rpsCb->chldPsLst != NULLP))
          {
             for (i = 0; i < rpsCb->nmbChldPs; i++)
             {
                if ((rpsCb->chldPsLst[i] != NULLP) &&
                    (rpsCb->chldPsLst[i]->lpsId == psCb->psCfg.psId))
                {
                   /* Remove loadsharing context block */
                   itLscDel((U8)((rpsCb->psCfg.mode == LIT_MODE_ACTSTANDBY) 
                             ? LIT_LOADSH_SLS : rpsCb->psCfg.loadShareMode),
                            rpsCb->chldPsLst[i]->lsCb);

                   /* Delete Child PS CB */
                   IT_FREE(sizeof(ItChldPsCb), rpsCb->chldPsLst[i])

                   for (j = i; j < (U32)(rpsCb->nmbChldPs - 1); j++)
                   {
                      rpsCb->chldPsLst[j] = rpsCb->chldPsLst[j+1];
                   }
                   rpsCb->nmbChldPs--;
                   break;
                }
             }
          }
          prevPsEnt = rpsCb;
       } /* end of while */
   } /* if local PS */
#endif /* ITASP && OG_RTE_ON_LPS_STA */

   /* Remove PS from array in Network Context CB */
   nwkCb = itGlobalCb.nwk[psCb->psCfg.nwkId];
   for (i = 0; i < nwkCb->nmbPs; i++)
   {
      if (nwkCb->ps[i] == psCb)
      {
         for (j = i; j < (U32)nwkCb->nmbPs - 1; j++)
         {
            nwkCb->ps[j] = nwkCb->ps[j+1];
         }
         nwkCb->ps[nwkCb->nmbPs - 1] = (ItPsCb *)NULLP;
         nwkCb->nmbPs--;
         break;
      }
   }
   /* Remove PS from array in Assoc CB */
   for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)
   {
      ItAssocCb  *assocCb;      /* Assoc control block */
      Bool       found;         /* found flag */
      assocCb = itGlobalCb.assoc[i];
      if (assocCb != (ItAssocCb *) NULLP)
      {
         found = FALSE;
         for (j = 0; j < assocCb->nmbPs; j++)
         {
            if ((found != TRUE) && (assocCb->ps[j] == psCb))
            {
               found = TRUE;
               /* decreasing the nmbPs will truncate loop as required */
               assocCb->nmbPs--;
            }
            if ((found == TRUE) && (j < assocCb->nmbPs))
            {
               /* close gap */
               assocCb->ps[j] = assocCb->ps[j + 1];
            }
         }
      }
   }

#ifdef ZV
    /* SYNC update needs to be done before psCb is freed */

    zvRTUpd(CMPFTHA_ACTN_DEL, ZV_PSCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) psCb, NULLP);
#endif
   /* Free memory occupied by PSCB */
   IT_FREE(sizeof(ItPsCb), psCb)

   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   
   /* free the PS ID in USE */
   itGlobalCb.psLstCb.nmbPsCfged--;
   itGlobalCb.psLstCb.psIdFree[psId] = TRUE;

   RETVALUE(ROK);
} /* end of itPsmDelPs */


/*
*
*       Fun:   itPsmPspClean
*
*       Desc:  Check to confirm that the specified PSP is not dependent
*              on any PSs
*
*       Ret:   Failure:           FALSE
*
*              Success:           TRUE
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC Bool itPsmPspClean
(
ItPspId     pspId             /* PSP ID */
)
#else
PUBLIC Bool itPsmPspClean(pspId)
ItPspId     pspId;            /* PSP ID */
#endif
{
   U16       i;               /* loop index */
   U16       j;               /* loop index */
   U16       k;               /* loop index */
   U16       nmbPs;           /* No. of PS */
   ItPsCb   **psCb;           /* Pointer to Ps Control Block */
   U16      suId;             /* loop index */

   TRC2(itPsmPspClean)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
          "itPsmPspClean(pspId(%d))\n", pspId));

   if (itGlobalCb.psp[pspId] == (ItPspCb *)NULLP)
   {
      RETVALUE(TRUE);
   }
   
   /* For all assocs */
   for (i = 0; i < LIT_MAX_SEP; i++)
   {
      if ((itGlobalCb.psp[pspId])->pspSta.assocSta[i].aspSt != LIT_ASP_DOWN)
      {
         RETVALUE(FALSE);
      }
   }
   /* For all the assocs of this PSP, their PS list is visited to remove
    * assocs from ps(es) assoc/psp list */

   for (suId = 0; suId < LIT_MAX_SEP; suId++)
   {
     UConnId assocId;      /* assoc Id */
     Bool    pspDeleted;   /* PSP from PS cfg deleted? */

     assocId = IT_PSPnENDP2ASSOC(pspId, suId);
     pspDeleted = FALSE;

     psCb  = (itGlobalCb.assoc[assocId])->ps;
     nmbPs = (itGlobalCb.assoc[assocId])->nmbPs;

     if ((psCb != (ItPsCb **)NULLP) && (nmbPs != 0))
     {
        for (i = 0; i < nmbPs; i++)
        {
           if (psCb[i] != (ItPsCb *)NULLP)
           {
              psCb[i]->psSta.psStaEndp[suId].aspSt[pspId] = LIT_ASP_UNSUPP; 
              psCb[i]->psSta.psStaEndp[suId].rteCtx[pspId].rcValid = FALSE; 

              /* see if the PSP is present in the PS's PSP list 
               * if present then delete this psp from the psp array
               * and decrement the no. of psp present in the PsCb  */
              for (j = 0; ((j < psCb[i]->psCfg.nmbPsp) && 
                           (pspDeleted == FALSE)); j++)
              {
                 if (pspId == psCb[i]->psCfg.psp[j])
                 {
                     break;
                 }
              }
              /* This condition will be TRUE only if psp is present in the
               * psp list of this PS, If TRUE then delete the psp from
               * the psp list in PS control Block and decrement the no.
               * of PSPs present*/
              if ((j != psCb[i]->psCfg.nmbPsp) && (pspDeleted == FALSE))
              {
                 for (k = j; k < (psCb[i]->psCfg.nmbPsp - 1); k++)
                 {
                    psCb[i]->psCfg.psp[k] = psCb[i]->psCfg.psp[k+1];
                 }
                 psCb[i]->psCfg.nmbPsp--;
                 pspDeleted = TRUE;
              }
            } /* if psCb[i] != NULLP */
         } /* End of for (i = 0; i < nmbPs; i++) */
      } /* end of if ((psCb != (ItPsCb **)NULLP) && (nmbPs != 0)) */
   } /* End of for on LIT_MAX_SEP */
   

   RETVALUE(TRUE);
} /* end of itPsmPspClean */


/*
*
*       Fun:   itPsmDelPsp
*
*       Desc:  Check for remaining dependencies. Return fail status if
*              any remain, else delete the PSP CB and ACB.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: Called by LMI
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmDelPsp
(
ItPspId      pspId,           /* PSP ID */
CmStatus     *sta,            /* return status */        
Bool         itAbort          /* abort flag */           
)
#else
PUBLIC S16 itPsmDelPsp(pspId, sta, itAbort)
ItPspId      pspId;           /* PSP ID */        
CmStatus     *sta;            /* return status */ 
Bool         itAbort;         /* abort flag */    
#endif
{
   ItPspCb      *pspCb;       /* PSP control block */
   U16          i;            /* loop index */
   SuId         suId;         /* SCT SAP suId */

   TRC2(itPsmDelPsp)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
          "itPsmDelPsp(pspId(%d), sta, itAbort(%d))\n", pspId, (U8)itAbort));

   pspCb = itGlobalCb.psp[pspId];

   if (pspCb == (ItPspCb *)NULL)
   {
      sta->status = LCM_PRIM_OK;
      sta->reason = LCM_REASON_NOT_APPL;
      RETVALUE(ROK);           
   }
   /* We need to check this in the begining only because after we delete
    * the PSP from the list of PSCbs , it will be difficult to roll back
    * to the same functionality as before if we check the association state
    * afterwards and association deletion fails due to its active state */
   /* Check for all the associations of this PSP */
   if (itAbort == FALSE)
   {
      for (i = 0; i < LIT_MAX_SEP; i++)
      {
         if (pspCb->pspSta.assocSta[i].hlSt != LIT_ASSOC_DOWN)
         {
            sta->status = LCM_PRIM_NOK;
            sta->reason = LIT_REASON_SERVICE_IN_USE;
            RETVALUE(RFAILED);
         }
      } /* End of for (i = 0; i < LIT_MAX_SEP; i++) */
   } /* end of if (itAbort == FALSE) */

   if (itAbort == FALSE)
   {
      /* Check whether PSP is configured to support any PSs 
       * and if it is supported then we need to delete it
       * from all the PS which suport this PSP , after checking
       * that its state is DOWN, if the state of this psp is not
       * down then this function returns FAILED */
           
      if (itPsmPspClean(pspId) == FALSE)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LIT_REASON_SERVICE_IN_USE;
         RETVALUE(RFAILED);
      }
   }

   /* Update state of all the associations for this PSP */
   for (i = 0; i < LIT_MAX_SEP; i++)
   {
      (void) itAcDelAssoc(IT_PSPnENDP2ASSOC(pspId, i),  itAbort);
   } /* End of for (i = 0; i < LIT_MAX_SEP; i++) */

   /* For all assocs, free the list */
   for (suId = 0; (suId < LIT_MAX_SEP); suId++)
   {
      if (pspCb->assoc[suId].ps != (ItPsCb **)NULLP)
      {
         IT_FREE((itGlobalCb.genCfg.maxNmbPs * sizeof(ItPsCb *)), 
                                       pspCb->assoc[suId].ps)
      }
      pspCb->assoc[suId].assocSta = (ItAssocSta *)NULLP;
      pspCb->pspSta.assocSta[suId].hlSt =  LIT_ASSOC_DOWN;
      pspCb->pspSta.assocSta[suId].readySetupSt = LIT_RDST_DEFAULT;
      pspCb->pspSta.assocSta[suId].aspSt =  LIT_ASP_DOWN;
      pspCb->pspSta.assocSta[suId].nmbAct =  0;
      pspCb->pspSta.assocSta[suId].nmbRegPs =  0;
      pspCb->pspSta.assocSta[suId].inhibited =  FALSE;
      pspCb->pspSta.assocSta[suId].spAssocId =  NULLD;
      pspCb->assoc[suId].sctSap = (ItSctSapCb *) NULLP;
      pspCb->assoc[suId].owner  = (ItPspCb *) NULLP;
      pspCb->assoc[suId].congActive  = FALSE;
      if (pspCb->pspCfg.pspId != IT_LOCAL_PSPID)
      {
        pspCb->assoc[suId].outStrms  = NULLD;
      }
      pspCb->assoc[suId].assocId   = NULLD;
   }

#ifdef ZV
    /* SYNC update for PSP deletion */

    zvRTUpd(CMPFTHA_ACTN_DEL, ZV_PSPCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) pspCb, NULLP);
#endif
   /* Delete PSP CB */
   IT_FREE(sizeof(ItPspCb), itGlobalCb.psp[pspId])

   /* Clear entry from Global control block */
   itGlobalCb.psp[pspId] = (ItPspCb *)NULLP;

   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;

   RETVALUE(ROK);
} /* end of itPsmDelPsp */


/*
*
*       Fun:   itPsmAspUp
*
*       Desc:  Call itMiStaInd to cause LMI to generate a status indication.
*              Change the state of the assoc to ASP-INACTIVE. Call itPsmAllPsEvt
*              to distribute the event to the PSs. Call itMmhNotify,
*              passing the ACB, to generate the ASPUP acknowledge. If
*              enabled, start the heartbeat timer in the ACB.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: Called by MMH to indicate reception of an ASPUP message
*              from the M3UA peer.
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmAspUp
(
ItAssocCb     *assocCb,       /* association control block */
Bool          ackFlag,        /* TRUE if acknowledge */
Txt           *info           /* extra information */
)
#else
PUBLIC S16 itPsmAspUp(assocCb, ackFlag, info)
ItAssocCb     *assocCb;       /* association control block */ 
Bool          ackFlag;        /* TRUE if acknowledge */       
Txt           *info;          /* extra information */         
#endif
{
   ItPspCb  *pspCb;           /* PSP control block */
   Bool     localPsp;         /* TRUE if local PSP */
   ItPspId  pspId;            /* PSP ID */
   ItRtCtx  nrCtx[LIT_MAX_PSID]; /* updated routing context list */
   U16      nrCtxLen;            /* length of list */
   U16      i;                 /* loop index */
   U16      j;                 /* loop index */
   ItRtCtx  rpsRCtx[LIT_MAX_PSID]; /* Remote PS list */
   U16      rpsRCtxLen;            /* length of Remote PS list */

   TRC2(itPsmAspUp)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
            "itPsmAspUp(assocCb, ackFlag(%d) info)\n",ackFlag));
   pspCb       = assocCb->owner;
   pspId       = pspCb->pspCfg.pspId;
   localPsp    = (Bool)((pspId == IT_LOCAL_PSPID) ? TRUE : FALSE);

   nrCtxLen = 0;
   cmMemset((U8 *)nrCtx, 0, sizeof(ItRtCtx) * LIT_MAX_PSID);

   if (localPsp == FALSE)
   {
      /* Send Status Indication to Layer Management */
      IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))
      itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP;
      itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS;
      itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_ASPM;
      itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_MSG_RECEIVED;
      itGlobalCb.mgmt.t.usta.s.pspId         = pspCb->pspCfg.pspId;
      itGlobalCb.mgmt.t.usta.t.aspm.msgType  = (U16)((ackFlag == TRUE) ? 
                                                LIT_ASPM_ASPUP_ACK : 
                                                LIT_ASPM_ASPUP);
      itGlobalCb.mgmt.t.usta.t.aspm.sctSuId  = assocCb->sctSap->sctCfg.suId;

      if (info != (Txt *) NULLP)
      {
         cmMemcpy((U8 *)itGlobalCb.mgmt.t.usta.t.aspm.info, (U8 *)info, 
                  MIN(cmStrlen((U8 *)info), LIT_MAX_INFO));
      }
      (Void) itMiStaIndM(&itGlobalCb.mgmt);
   }

   if ((ackFlag == FALSE) && (assocCb != (ItAssocCb *)NULLP) && 
                                       (assocCb->assocSta->inhibited == TRUE))
   {
      if (localPsp == FALSE)
      {
         /* According to Draft 7 an error message with reason "refused
          * management blocking" should be sent. In Previous version we
          * used to send Down Ack message in the same condition */

         itMmhError(assocCb, IT_M3UA_ERROR_RFSD_MGMTBLKD, 
                   (Buffer **)NULLP, 0, (ItM3uaTag *) NULLP, 
                   (ItRtCtx *) NULLP, 0, IT_M3UA_DFLT);
      }
      else
      {
         (Void) itPsmAspDn(assocCb, FALSE, (Txt *)NULLP, FALSE);
      }
      RETVALUE(ROK);
   }

   if (((assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_SGP) || 
       ((assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
        (ackFlag == TRUE))) && (assocCb->aspmType != IT_ASPM_ASPDN))
   {
      itTcStopTimer(&assocCb->tmrAspm);
   }

   if ((assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_ASP) ||
       ((assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_IPSP)&&(ackFlag == FALSE)))
   {
      /* Send ASPUP-ACK message to ASP client or IPSP */
      /* According to Draft 7 we should not send back the INFO in ACK Msg */
      (Void) itMmhAspUp(assocCb, TRUE, (Txt *)NULLP);
   }
   
   /* If ASP UP message is received in ACTIVE  state then
    * also PSP state should be moved to INACTIVE - Draft 7 requirement */
   if ((assocCb->assocSta->aspSt == LIT_ASP_DOWN)
      || (assocCb->assocSta->aspSt == LIT_ASP_ACTIVE) 
      || ((assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_IPSP) &&
          (assocCb->owner->pspCfg.ipspMode == LIT_IPSPMODE_DE) && 
          (assocCb->assocSta->aspSt == LIT_ASP_INACTIVE))) 
       
   {
      /* In IPSP-DE we expect ASPUP in ASP-ACT state too */
      /* it013.106 - For IPSP-DE, if PSP is Active for any Remote PS, this 
       * means this PSP sent ASPAC earlier. Now if ASPUP is received from 
       * this PSP, send Error message. */ 
      if (assocCb->assocSta->aspSt == LIT_ASP_ACTIVE)
      {
         if (!((assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_IPSP) &&
             (assocCb->owner->pspCfg.ipspMode == LIT_IPSPMODE_DE)))
         {
            itMmhError(assocCb, IT_M3UA_ERROR_UNEXP_MSG, (Buffer **)NULLP,
                       0, (ItM3uaTag *) NULLP, (ItRtCtx *) NULLP, 0, 
                       IT_M3UA_DFLT);
         }
         else
         {
            if (ackFlag == FALSE)
            {
               ItPsCb      *psCb;         /* PS control block */

               for (i = 0; i < assocCb->assocSta->nmbAct; i++)
               {
                  psCb = itPsmFindPs(assocCb->assocSta->actPs[i]);
                  /* If Active PS is a Remote PS, send Error. */
                  if (psCb->psCfg.lclFlag != TRUE)
                  {
                     itMmhError(assocCb, IT_M3UA_ERROR_UNEXP_MSG, 
                                (Buffer **)NULLP, 0, (ItM3uaTag *) NULLP, 
                                (ItRtCtx *) NULLP, 0, IT_M3UA_DFLT);
                     break;
                  }
               }
            } /* if ackFlag is FALSE */
         } /* if IPSP-DE */
      } /* end of if aspSt is Active */
      /* Change global PSP State to ASP-INACTIVE */
      assocCb->assocSta->aspSt = LIT_ASP_INACTIVE;
      (Void) itMifPspEvt(IT_MIF_ASP_UP, 0, (Dpc) 0, 0, (SrvInfo) 0, assocCb, 
                         (ItDpcCb *) NULLP);
   
      if (localPsp == FALSE)
      {
         /* start the heart beat timers */
         if (itGlobalCb.genCfg.tmr.tmrHeartbeat.enb == TRUE)
         {
            TmrCfg tmpTmr;    /* temporary timer */
            tmpTmr.enb = TRUE;
            tmpTmr.val = (U16)(2 * itGlobalCb.genCfg.tmr.tmrHeartbeat.val);
            itTcStartTimer(&assocCb->tmrHBeatRX, (PTR)assocCb,
                           IT_TMR_HBEAT_RX, &tmpTmr);
   
            if ((assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_SGP) ||
                (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_IPSP))
            {
               /* peer is a SGP server or IPSP - originate the heartbeat */
               (Void) itMmhHBeat(assocCb, FALSE, (Buffer **)NULLP, 
                                 (ItM3uaTag *)NULLP);
               itTcStartTimer(&assocCb->tmrHBeatTX,
                              (PTR)assocCb,
                              IT_TMR_HBEAT_TX,
                              &itGlobalCb.genCfg.tmr.tmrHeartbeat);
            }
         }
      }
      /* Status indication: PSP state change */
      IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
      itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
      itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS; 
      itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_ASP_INACTIVE;
      itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_STATUS_CHANGE;
      itGlobalCb.mgmt.t.usta.s.pspId         = pspId;
      
      itGlobalCb.mgmt.t.usta.t.aspm.sctSuId  = 
                                 (SuId)((assocCb->sctSap != (ItSctSapCb *)NULLP)? 
                                  assocCb->sctSap->sctCfg.suId : 0);
      (Void) itMiStaIndM(&itGlobalCb.mgmt); 
   
      if ((assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
              (assocCb->owner->pspCfg.ipspMode == LIT_IPSPMODE_DE) &&
              (ackFlag == TRUE))
      {
         /* Build local routing context from configuration */
         (Void) itPsmValidateRCtx(assocCb, nrCtx, &nrCtxLen, 
                               (ItRtCtx *)NULLP, (U16 *)NULLP, 
                               IT_VRCTX_BUILD_DE_ACK);
      }
      else
      {
         /* Build local routing context from configuration */
         (Void) itPsmValidateRCtx(assocCb, nrCtx, &nrCtxLen, 
                               (ItRtCtx *)NULLP, (U16 *)NULLP, IT_VRCTX_BUILD);
      }
      /* nrCtx array currently have 
       * For IPSP SE & at ASP - Local PS ids   *
       * For IPSP DE & at SGP - Remote PS ids  */
      /* Indicate change in PSP state to affected PSs */
      (Void) itPsmAllPsEvt(assocCb, nrCtx, nrCtxLen, 
                           (U16)(ackFlag == TRUE ? 
                                 IT_EVT_ASP_UP_ACK : IT_EVT_ASP_UP), 0);
      /* At IPSP(SE) (on receiving ASPUP as well as ASPUP-ACK) and at 
       * ASP (on receiving ASPUP-ACK msg) Indicate change in PSP
       * state to affected Remote PSs */
      if (localPsp == FALSE)
      {
         if (((pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP) && (ackFlag == TRUE)) 
                   || ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
                    (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_SE)))
         {
            /* Get the RPS-id list for the PSP */
            IT_GET_RPS_FRM_PSP(assocCb, rpsRCtx, rpsRCtxLen);
       
            (Void) itPsmAllPsEvt(assocCb, rpsRCtx, rpsRCtxLen, 
                                (U16)(ackFlag == TRUE ? 
                                    IT_EVT_ASP_UP_ACK : IT_EVT_ASP_UP), 0);
         }
      }
#ifndef IT_OPT_UPDN
      /* For DE When ASP-UP comes previously only Remote PS was updated
         Now local PS also need to updated because of optional ASP-UP
         from other side */

      if (localPsp == FALSE)
      {
         ItRtCtx  nrCtxLps[LIT_MAX_PSID]; /* Remote PS list */
         U16      nrCtxLenLps;            /* length of Remote PS list */

         if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
             (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_DE) &&
             (ackFlag != TRUE))
         {
            /* Build local routing context from configuration */
            (Void) itPsmValidateRCtx(assocCb, nrCtxLps, &nrCtxLenLps, 
                               (ItRtCtx *)NULLP, (U16 *)NULLP, 
                               IT_VRCTX_BUILD_DE_ACK); 
            (Void) itPsmAllPsEvt(assocCb, nrCtxLps, nrCtxLenLps, 
                                 IT_EVT_ASP_UP, 0);
         }
      }

      /* for DE when ASP-UPACK comes previously only local PS was updated
         Now Remote PS also need to updates because of optional ASP-UP-ACk
         from other side */
      if (localPsp == FALSE)
      {
         ItRtCtx  nrCtxRps[LIT_MAX_PSID]; /* Remote PS list */
         U16      nrCtxLenRps;            /* length of Remote PS list */

         if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
             (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_DE) &&
             (ackFlag == TRUE))
         {
            /* Build local routing context from configuration */
            (Void) itPsmValidateRCtx(assocCb, nrCtxRps, &nrCtxLenRps, 
                               (ItRtCtx *)NULLP, (U16 *)NULLP, 
                               IT_VRCTX_BUILD); 
            (Void) itPsmAllPsEvt(assocCb, nrCtxRps, nrCtxLenRps, 
                                 IT_EVT_ASP_UP_ACK, 0);
         }
      }

#endif /* IT_OPT_UPDN */

      /* Sending notifies to psp for routing contexts that are not 
         restarting */
      for (j = 0; j < nrCtxLen; j++)
      {
         ItPsCb *psCb;   /* local PS control block */
         ItRtCtx locRtCtx; /* Temporary storage for routing ctx */
         Bool    aspIdPres;    /* ASP Identifier Present */
         U32     aspId;    /* ASP Identifier */

         aspId = NULLD;
         /* Initialize PS CB */
         psCb = (ItPsCb *)NULLP;

         /* Get PS CB */
         psCb = itPsmFindPs(nrCtx[j].rtCtx);
         if ((psCb->psSta.asSt != LIT_AS_DOWN) && (nrCtx[j].ntfySend == TRUE))
         {
            SuId     suId;     /* SCT SAP id of assoc */
            ItPspId  tmpPspId; /* PSP id of assoc     */
            /* notify client Assocs */
            for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)
            {
               suId  = IT_ASSOC2SUID(i);
               tmpPspId = IT_ASSOC2PSPID(i);
               if ((psCb->psSta.psStaEndp[suId].aspSt[tmpPspId] != LIT_ASP_DOWN)
                    &&
                 (psCb->psSta.psStaEndp[suId].aspSt[tmpPspId] != LIT_ASP_UNSUPP)
                    &&
                   ((itGlobalCb.assoc[i]->owner->pspCfg.pspType ==
                                                           LIT_PSPTYPE_ASP) ||
                    ((itGlobalCb.assoc[i]->owner->pspCfg.pspType ==
                                                          LIT_PSPTYPE_IPSP) &&
                     (ackFlag == FALSE))))
               {
                  if (psCb->psSta.psStaEndp[suId].rteCtx[tmpPspId].rcValid 
                                                                        != TRUE)
                  {
                     continue;
                  }
                  cmMemcpy((U8 *)&locRtCtx, (U8 *)&(nrCtx[j]),
                                                            sizeof(ItRtCtx));
                  locRtCtx.rtCtx = psCb->psSta.psStaEndp[suId].rteCtx[tmpPspId].
                                                                           rCtx;

                  aspIdPres = FALSE;
                  /* it016.106 - Changes to make storing of ASPID optional
                   * when rxTxAspId is FALSE. So, even if rxTxAspId is FALSE 
                   * send ASPID, if available. */
                  if (itGlobalCb.aspIdCb.aspIdValid[pspId] == TRUE)
                  {
                     aspId = itGlobalCb.aspIdCb.aspIdLst[pspId];
                     aspIdPres = TRUE;
                  }
                      
                  (Void) itMmhNotify(itGlobalCb.assoc[i], 
                                     (Txt *)NULLP, 
                                     &locRtCtx, 1, 
                                     IT_M3UA_NTFY_TYPE_ASCHG, aspIdPres, aspId);
               } /* end: if ((psCb's aspSt[i] != LIT_ASP_DOWN) &&*/
            } /* end: for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)*/
         } /* end: if (psCb->psSta.asSt != LIT_AS_DOWN)*/
      } /* end: for (j = 0; j < nrCtxLen; j++) */
   }
   

   RETVALUE(ROK);
} /* end of itPsmAspUp */


/*
*
*       Fun:   itPsmAspDn
*
*       Desc:  Call itMiStaInd to cause LMI to generate a status indication
*              Change the state of the PSP to ASP-DOWN. Call
*              itPsmAllPsEvt to distribute the event to all PSs. Call
*              itMmhNotify, passing the ACB, to generate the ASPDN
*              acknowledge.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: Called by MMH to indicate reception of an ASPDN message from
*              the M3UA peer.
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmAspDn
(
ItAssocCb      *assocCb,      /* association control block */ 
Bool           ackFlag,       /* TRUE if acknowledge */       
Txt            *info,         /* extra information */         
Bool           msgFlag        /* TRUE if this is a real ASPDN */
)
#else
PUBLIC S16 itPsmAspDn(assocCb, ackFlag, info, msgFlag)
ItAssocCb      *assocCb;      /* association control block */ 
Bool           ackFlag;       /* TRUE if acknowledge */       
Txt            *info;         /* extra information */         
Bool           msgFlag;       /* TRUE if this is a real ASPDN */
#endif                                                       
{                                                            
   ItPspCb  *pspCb;           /* PSP control block */        
   Bool     localPsp;         /* TRUE if local PSP */        
   ItPspId  pspId;            /* PSP ID */                   
   ItRtCtx  nrCtx[LIT_MAX_PSID]; /* updated routing context list */
   U16      nrCtxLen;            /* length of list */
   U16      i;                /* loop index */
   U16      j;                /* loop index */
   ItRtCtx  rpsLst[LIT_MAX_PSID]; /* Remote PS-ids */
   U16      rpsLstLen;            /* length of rpsLst length */
   TRC2(itPsmAspDn)

#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
          "itPsmAspDn(assocCb, ackFlag(%d) info)\n", ackFlag));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
          "itPsmAspDn(assocCb, ackFlag(%d) info)\n", ackFlag));
#endif
   pspCb    = assocCb->owner;
   pspId    = pspCb->pspCfg.pspId;
   localPsp = (Bool)((pspId == IT_LOCAL_PSPID) ? TRUE : FALSE);
   nrCtxLen = 0;
   cmMemset((U8 *)nrCtx, 0, sizeof(ItRtCtx) * LIT_MAX_PSID);

   /* it016.106 - If msgFlag is FALSE, stop tmrAspm. */
   if ((localPsp == FALSE) && (msgFlag == FALSE))
   {
      itTcStopTimer(&assocCb->tmrAspm);
   }
   if ((localPsp == FALSE) && (msgFlag == TRUE))
   {
      /* Send Status Indication to Layer Management */
      IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))
      itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP;
      itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS;
      itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_ASPM;
      itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_MSG_RECEIVED;
      itGlobalCb.mgmt.t.usta.s.pspId         = pspCb->pspCfg.pspId;
      itGlobalCb.mgmt.t.usta.t.aspm.msgType  = (U16)((ackFlag == TRUE) ? 
                                                LIT_ASPM_ASPDN_ACK : 
                                                LIT_ASPM_ASPDN);
      itGlobalCb.mgmt.t.usta.t.aspm.sctSuId  = assocCb->sctSap->sctCfg.suId;

      if (info != (Txt *) NULLP)
      {
         cmMemcpy((U8 *)itGlobalCb.mgmt.t.usta.t.aspm.info, (U8 *)info, 
                  MIN(cmStrlen((U8 *)info), LIT_MAX_INFO));
      }
      (Void) itMiStaIndM(&itGlobalCb.mgmt);
      
      if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP) || 
          ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && (ackFlag == TRUE)))
      {
         itTcStopTimer(&assocCb->tmrAspm);
      }
      /* it016.106 - Changes to make storing of ASPID optional
       * when rxTxAspId is FALSE. So, aspIdValid can be TRUE even if 
       * rxTxAspId is FALSE. */
      if ((ackFlag == FALSE) &&
          (itGlobalCb.aspIdCb.aspIdValid[pspId] == TRUE))
      {
         itGlobalCb.aspIdCb.aspIdValid[pspId] = FALSE;
         itGlobalCb.aspIdCb.aspIdLst[pspId] = IT_M3UA_DFLT;
#ifdef ZV
         /* it018.106 - modification - changing table type as ZV_ASPID */
         /* SYNC update for ZV_ASPID for aspIdValid & aspIdLst */
         zvRTUpd(CMPFTHA_ACTN_MOD, ZV_ASPID,
                 CMPFTHA_UPDTYPE_SYNC, (Void *) &pspId, NULLP);
         
#endif
      }

   }
      /* In IPSP DE, DOWN is expected from both ends */
   if ((assocCb->assocSta->aspSt != LIT_ASP_DOWN) ||
       ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) &&
       (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_DE)))
   {
      /* Change global PSP State to ASP-DOWN */
      assocCb->assocSta->aspSt = LIT_ASP_DOWN;

      (Void) itMifPspEvt(IT_MIF_ASP_DOWN, 0, (Dpc) 0, 0, (SrvInfo) 0, assocCb, 
                         (ItDpcCb *) NULLP);
   
      if (localPsp == FALSE)
      {
         /* stop the heart beat timers */
         if (itGlobalCb.genCfg.tmr.tmrHeartbeat.enb == TRUE)
         {
            /* stop the receive heart beat timer */
            itTcStopTimer(&assocCb->tmrHBeatRX);

            if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP) ||
                (pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP))
            {
               /* peer is a SGP server or IPSP, stop heartbeat transmission */
               itTcStopTimer(&assocCb->tmrHBeatTX);
            }
         }
      }
   
      /* Status indication: PSP state change */
      IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
      itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
      itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS; 
      itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_ASP_DOWN;
      itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_STATUS_CHANGE;
      itGlobalCb.mgmt.t.usta.s.pspId         = pspId;
      itGlobalCb.mgmt.t.usta.t.aspm.sctSuId  = 
                                 (SuId)((assocCb->sctSap != (ItSctSapCb *)NULLP)? 
                                  assocCb->sctSap->sctCfg.suId : 0);
              
      (Void) itMiStaIndM(&itGlobalCb.mgmt); 
           
      if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
              (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_DE) &&
              (ackFlag == TRUE))
      {
         /* Build local routing context from configuration */
         (Void) itPsmValidateRCtx(assocCb, nrCtx, &nrCtxLen, 
                               (ItRtCtx *)NULLP, (U16 *)NULLP, 
                               IT_VRCTX_BUILD_DE_ACK);
      }
      else
      {
         /* Build remote routing context from configuration */
         (Void) itPsmValidateRCtx(assocCb, nrCtx, &nrCtxLen, 
                               (ItRtCtx *)NULLP, (U16 *)NULLP, IT_VRCTX_BUILD);
      }
      /* Indicate change in PSP state to affected PSs */
      (Void) itPsmAllPsEvt(assocCb, nrCtx, nrCtxLen, 
                           (U16)(ackFlag == TRUE ? 
                                 IT_EVT_ASP_DN_ACK : IT_EVT_ASP_DN), 0);
      /* nrCtx currently have 
       * For SE & at ASP - LPS 
       * For DE & at SGP - RPS
       */
      /* At ASP in case of IPSP SE - we need to
       * chng the state of RPSs too and make a new list rpsLst, 
       * Call itPsmAllPsEvt with this new list too */
      if (localPsp == FALSE)
      {
       
       /* At IPSP(SE) and at ASP Indicate change in PSP state to affected RPS */
         if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP) ||
                   ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
                    (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_SE)))
         {
            /* Get the RPS list for the PSP */
            IT_GET_RPS_FRM_PSP(assocCb, rpsLst, rpsLstLen);
            (Void) itPsmAllPsEvt(assocCb, rpsLst, rpsLstLen, 
                                 (U16)(ackFlag == TRUE ? 
                                    IT_EVT_ASP_DN_ACK : IT_EVT_ASP_DN), 0);
         }
      }


#ifndef IT_OPT_UPDN
      /* For DE When ASP-DN comes previously only Remote PS was updated
         Now local PS also need to updated because of optional ASP-DN
         from other side */

      if (localPsp == FALSE)
      {
         ItRtCtx  nrCtxLps[LIT_MAX_PSID]; /* Remote PS list */
         U16      nrCtxLenLps;            /* length of Remote PS list */

         if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
             (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_DE) &&
             (ackFlag != TRUE))
         {
            /* Build local routing context from configuration */
            (Void) itPsmValidateRCtx(assocCb, nrCtxLps, &nrCtxLenLps, 
                               (ItRtCtx *)NULLP, (U16 *)NULLP, 
                               IT_VRCTX_BUILD_DE_ACK); 
            (Void) itPsmAllPsEvt(assocCb, nrCtxLps, nrCtxLenLps, 
                                 IT_EVT_ASP_DN, 0);
         }
      }

      /* for DE when ASP-UPACK comes previously only local PS was updated
         Now Remote PS also need to updates because of optional ASP-UP-ACk
         from other side */
      if (localPsp == FALSE)
      {
         ItRtCtx  nrCtxRps[LIT_MAX_PSID]; /* Remote PS list */
         U16      nrCtxLenRps;            /* length of Remote PS list */

         if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
             (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_DE) &&
             (ackFlag == TRUE))
         {
            /* Build local routing context from configuration */
            (Void) itPsmValidateRCtx(assocCb, nrCtxRps, &nrCtxLenRps, 
                               (ItRtCtx *)NULLP, (U16 *)NULLP, 
                               IT_VRCTX_BUILD); 
            (Void) itPsmAllPsEvt(assocCb, nrCtxRps, nrCtxLenRps, 
                                 IT_EVT_ASP_DN_ACK, 0);
         }
      }
#endif 

      if (((pspCb->pspCfg.pspType == LIT_PSPTYPE_ASP) ||
          ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
           (ackFlag == FALSE))) && (msgFlag == TRUE))
      {
         /* Send ASPDN-ACK message to ASP client or IPSP */
         /* According to Draft 7 we should not echo back the INFO in ACK Msg */

         (Void) itMmhAspDn(assocCb, TRUE, (Txt *) NULLP);
      }

      /* Sending notifies to psp for routing contexts that are not 
         restarting */
      for (j = 0; j < nrCtxLen; j++)
      {
         ItPsCb *psCb;   /* local PS control block */
         ItRtCtx locRtCtx; /* Temporary storage for routing ctx */
         Bool    aspIdPres;    /* ASP Identifier Present */
         U32     aspId;    /* ASP Identifier */

         aspId = NULLD;
         /* Initialize psCb */
         psCb = (ItPsCb *) NULLP;
         /* Get PsCb */
         psCb = itPsmFindPs(nrCtx[j].rtCtx);
         if ((psCb->psSta.asSt != LIT_AS_DOWN) && 
              (nrCtx[j].ntfySend == TRUE))
         {
            SuId     suId;     /* SCT SAP id of assoc */
            ItPspId  tmpPspId; /* PSP id of assoc     */
            /* notify client Assocs */
            for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)
            {
               suId  = IT_ASSOC2SUID(i);
               tmpPspId = IT_ASSOC2PSPID(i);

               if ((psCb->psSta.psStaEndp[suId].aspSt[tmpPspId] != LIT_ASP_DOWN)
                    &&
                 (psCb->psSta.psStaEndp[suId].aspSt[tmpPspId] != LIT_ASP_UNSUPP)
                     &&
                   ((itGlobalCb.assoc[i]->owner->pspCfg.pspType == 
                                                             LIT_PSPTYPE_ASP) ||
                    ((itGlobalCb.assoc[i]->owner->pspCfg.pspType == 
                                                            LIT_PSPTYPE_IPSP) &&
                     (ackFlag == FALSE))))
               {
                  if (psCb->psSta.psStaEndp[suId].rteCtx[tmpPspId].rcValid 
                                                                        != TRUE)
                  {
                     continue;
                  }
                  
                  cmMemcpy((U8 *)&locRtCtx, (U8 *)&(nrCtx[j]),
                                                            sizeof(ItRtCtx));
                  locRtCtx.rtCtx = psCb->psSta.psStaEndp[suId].rteCtx[tmpPspId].                                                                           rCtx;
                  aspIdPres = FALSE;
                  /* it016.106 - Changes to make storing of ASPID optional
                   * when rxTxAspId is FALSE. So, even if rxTxAspId is FALSE 
                   * send ASPID, if available. */
                  if (itGlobalCb.aspIdCb.aspIdValid[pspId] == TRUE)
                  {
                     aspId = itGlobalCb.aspIdCb.aspIdLst[pspId];
                     aspIdPres = TRUE;
                  }
                  (Void) itMmhNotify(itGlobalCb.assoc[i],
                                     (Txt *)NULLP, 
                                     &locRtCtx, 1, 
                                     IT_M3UA_NTFY_TYPE_ASCHG, aspIdPres, aspId);
               } /* end if ((psCb->psSta.aspSt[i] != LIT_ASP_DOWN) &&*/
            } /* end for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)*/
         } /* end if (psCb->psSta.asSt != LIT_AS_DOWN)*/
      } /* end for (j = 0; j < nrCtxLen; j++) */
   }
   /* - Send ASPDN Ack if ASPDN received in * Down state */
   else if ((assocCb->assocSta->aspSt == LIT_ASP_DOWN) &&
            ((pspCb->pspCfg.pspType == LIT_PSPTYPE_ASP) ||
            ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
            (ackFlag == FALSE))) && (msgFlag == TRUE))
   {
         /* Send ASPDN-ACK message to ASP client or IPSP */
         /* According to Draft 7 we should not echo back the INFO in ACK Msg */

         (Void) itMmhAspDn(assocCb, TRUE, (Txt *) NULLP);
         RETVALUE(ROK);
   }
   /* - Clear the association congestion queue by 
      re-routing the * messages */
   if (localPsp == FALSE)
   {
      (Void) itCcPspDn(assocCb);
   }
   /* Delete all the dynamically registered routing keys by this PSP */
   
   if (localPsp == FALSE)
   {
      (Void) itAtDeRegReq(assocCb, nrCtx, nrCtxLen, IT_EVT_ASP_DN);
   }
   /* - In case of IPSP-DE we create local PS also 
                 so delete that also */ 
   if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) &&
                (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_DE) && 
                (ackFlag == FALSE))
   {
         /* Build local routing context from configuration */
         /* operation IT_VRCTX_BUILD_DE_ACK  builds local PS 
            that is why it 
          * has been added here */
      (Void) itPsmValidateRCtx(assocCb, nrCtx, &nrCtxLen,
                               (ItRtCtx *)NULLP, (U16 *)NULLP,
                               IT_VRCTX_BUILD_DE_ACK);
      (Void) itAtDeRegReq(assocCb, nrCtx, nrCtxLen, IT_EVT_ASP_DN);

   } 
   RETVALUE(ROK);
} /* end of itPsmAspDn */


/*
*
*       Fun:   itPsmAspAc
*
*       Desc:  Call itMiStaInd to cause LMI to generate a status indication
*              Call itPsmAllPsEvt to distribute the event to all PSs.
*              Call itMmhNotify, passing the ACB and the updated routing
*              context, to generate the ASP_ACTIVE acknowledge.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: Called by MMH to indicate reception of an ASPAC message from
*              the M3UA peer.
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmAspAc
(
ItAssocCb      *assocCb,            /* association control block */
Bool           ackFlag,             /* TRUE if acknowledge */      
U8             type,                /* traffic handling mode */    
Txt            *info,               /* extra information */        
ItRtCtx        *rCtx,               /* list of routing contexts */ 
U16            rCtxLen              /* length of list */           
)
#else
PUBLIC S16 itPsmAspAc(assocCb, ackFlag, type, info, rCtx, rCtxLen)
ItAssocCb      *assocCb;            /* association control block */  
Bool           ackFlag;             /* TRUE if acknowledge */        
U8             type;                /* traffic handling mode */
Txt            *info;               /* extra information */          
ItRtCtx        *rCtx;               /* list of routing contexts */
U16            rCtxLen;             /* length of list */
#endif                                                        
{                                                             
   ItPspCb     *pspCb;              /* PSP control block */         
   Bool        localPsp;            /* TRUE if local PSP */         
   ItPspId     pspId;               /* PSP ID */                    
   U16         i;                   /* loop index */
   U16         j;                   /* loop index */
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   Bool        rcRcvdInMsg;         /* RC received in message or build locally*/
#endif   
   ItRtCtx     nrCtx[LIT_MAX_PSID]; /* updated routing context list */
   ItRtCtx     irCtx[LIT_MAX_PSID]; /* invalid routing context list */
   U16         nrCtxLen;            /* length of list */
   U16         irCtxLen;            /* length of list */

   TRC2(itPsmAspAc)

#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itPsmAspAc(assocCb(%d), type(%d), info(%s), rCtx, rCtxLen(%d))\n", 
          ((assocCb != (ItAssocCb *)NULLP) ? assocCb->assocId : 0xFFFFFFFF), 
          type, info, rCtxLen));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itPsmAspAc(assocCb(%ld), type(%d), info(%s), rCtx, rCtxLen(%d))\n", 
          ((assocCb != (ItAssocCb *)NULLP) ? assocCb->assocId : 0xFFFFFFFF), 
          type, info, rCtxLen));
#endif

#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   rcRcvdInMsg = FALSE;
#endif
   pspCb    =  assocCb->owner;
   pspId    = pspCb->pspCfg.pspId;
   localPsp = (Bool)((pspId == IT_LOCAL_PSPID) ? TRUE : FALSE);
   nrCtxLen = rCtxLen;
   irCtxLen = 0;
   cmMemset((U8 *)nrCtx, 0, sizeof(ItRtCtx) * LIT_MAX_PSID);
   cmMemset((U8 *)irCtx, 0, sizeof(ItRtCtx) * LIT_MAX_PSID);
/*chenning startwork*/
    if(	ackFlag &&
    pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP ||
    pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP)
    {
        itTcStopTimer(&pspCb->assoc->tmrReconnect);
    }
   /* it020.106 -Timer is stopped later when the ASPAC-Ack is considered valid*/
   
   if ((rCtx == (ItRtCtx *) NULLP) || (rCtxLen == 0))
   {
      /* Build PS list (Which corresponds to routCtx) from configured routing */
      if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
              (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_DE) &&
              (ackFlag == TRUE))
      {
         /* Build local routing context from configuration */
         (Void) itPsmValidateRCtx(assocCb, nrCtx, &nrCtxLen, 
                               (ItRtCtx *)NULLP, (U16 *)NULLP, 
                               IT_VRCTX_BUILD_DE_ACK);
      }
      else
      {
         /* Build local routing context from configuration */
         (Void) itPsmValidateRCtx(assocCb, nrCtx, &nrCtxLen, 
                               (ItRtCtx *)NULLP, (U16 *)NULLP, IT_VRCTX_BUILD);
      }

      if (nrCtxLen == 0)
      {
         (Void) itMmhError(assocCb, IT_M3UA_ERROR_NO_AS_FOR_ASP, 
                      (Buffer **)NULLP, 0, (ItM3uaTag *) NULLP, (ItRtCtx *) 
                      NULLP, 0, IT_M3UA_DFLT);
         RETVALUE(RFAILED);
      }
   }
   else
   {
      (Void) cmMemcpy((U8 *)nrCtx, (U8 *)rCtx, sizeof(ItRtCtx) * rCtxLen);
      /* Validate rCtx list according to configured routing */
      nrCtxLen = rCtxLen;

      itAtMapRcToPs(assocCb, nrCtx, &nrCtxLen, irCtx, &irCtxLen, ackFlag);
      if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
              (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_DE) &&
              (ackFlag == TRUE))
      {
          (Void) itPsmValidateRCtx(assocCb, nrCtx, &nrCtxLen, 
                               irCtx, &irCtxLen, IT_VRCTX_RMV_UNSUPP_DE_ACK);
      }
      else
      {
          (Void) itPsmValidateRCtx(assocCb, nrCtx, &nrCtxLen, 
                               irCtx, &irCtxLen, IT_VRCTX_RMV_UNSUPP);
      }
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
      /* flag used for deciding which error code to send 
         later in the function for IPSP-SE */
      rcRcvdInMsg = TRUE;
#endif
   }

   /* Reject routing contexts that are not supported */
   if (irCtxLen != NULLD)
   {
      (Void) itMmhError(assocCb, IT_M3UA_ERROR_INV_RCTX, 
                        (Buffer **)NULLP, 0, 
                        (ItM3uaTag *) NULLP, irCtx, irCtxLen, 
                         IT_M3UA_DFLT);
   }
   if (ackFlag == FALSE)
   {
      /* Validate rCtx list according to configured PS type */
      switch (type)
      {
         case IT_M3UA_THM_OVERRIDE:
            irCtxLen = 0;
            (Void) itPsmValidateRCtx(assocCb, nrCtx, &nrCtxLen, 
                                     irCtx, &irCtxLen, IT_VRCTX_OVERRIDE);
            break;
         case IT_M3UA_THM_LOADSHARE:
            irCtxLen = 0;
            (Void) itPsmValidateRCtx(assocCb, nrCtx, &nrCtxLen, 
                                     irCtx, &irCtxLen, IT_VRCTX_LOADSHARE);
            break;
         case IT_M3UA_DFLT:
            irCtxLen = 0;
              break;
   
         default:
            RETVALUE(RFAILED);
      }
   }

   if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_ASP) ||
       ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && (ackFlag == FALSE)))
   {
      /* Reject routing contexts that are not supported */
      if ( irCtxLen != NULLD )
      {
         (Void) itMmhError(assocCb, IT_M3UA_ERROR_UNSUPP_THM, 
                           (Buffer **)NULLP, type, 
                           (ItM3uaTag *) NULLP, irCtx, irCtxLen, 
                            IT_M3UA_DFLT);
      }
   }

#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   /* In case of IPSP-SE, if the RC is not locally active then reject the
      aspac message with ERROR message */
   if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) &&
       (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_SE) && (ackFlag == FALSE))
   {
      irCtxLen = 0;
      /* If rcRcvdInMsg is FALSE then rCtxLen is not used in this function
         If the rcRcvdInMsg is TRUE then rCtxLen use is done at this point */
      /* Get the number of built up routing contexts in rCtxLen field */
      rCtxLen = nrCtxLen;
      (Void) itPsmChkRcRdyRcvTraf(nrCtx, &nrCtxLen, irCtx, &irCtxLen);

      /* Following cases are required to be handled */      
      /* Case 1: RC is not received in the ASPAC message,  
         A) if no AS is found: then error is returned above in this function 
         with errorCode as NO_AS_FOR_ASP 
         B) if none of the AS is found to be ready then return 
         error with errorCode as NO_AS_FOR_ASP (i.e., rCtxLen == irCtxLen).
         C) if atleast a single AS is found to be ready then no error is 
         sent but for those AS(es) which are not yet ready will be
         dropped here for further processing [Those RCs which are not yet 
         ready are already dropped from nrCtx list in function 
         itPsmChkRcRdyRcvTraf] */

      /* Case 2: For the RC received in the message, 
         A) If AS is not ready then return INV_RCTX */

      /* Case 1A and 1C does not require any handling here, 
         for case 1B handling, following error message is sent  */
      if ((rcRcvdInMsg == FALSE) && (rCtxLen == irCtxLen))
      {
         (Void) itMmhError(assocCb, IT_M3UA_ERROR_NO_AS_FOR_ASP, 
                      (Buffer **)NULLP, 0, (ItM3uaTag *) NULLP, (ItRtCtx *) 
                      NULLP, 0, IT_M3UA_DFLT);
         RETVALUE(RFAILED);
      }

      /* Case 2: */
      if (rcRcvdInMsg == TRUE)
      { 
         /* RCs which are received in ASPAC message but are not 
            ready to receive traffic, will get ERROR in response */ 
         if (irCtxLen != 0)
         {
            ItRtCtx     tmpRCtx[LIT_MAX_PSID]; /* invalid routing context */
            U16         tmpRCtxLen;            /* length of list */

            /* Get the RCs back from corresponding PS-id list */
            itAtMapPsToRc(assocCb, irCtx, &irCtxLen, tmpRCtx, &tmpRCtxLen);

            (Void) itMmhError(assocCb,
                             IT_M3UA_ERROR_INV_RCTX,
                            (Buffer **)NULLP, 0, (ItM3uaTag *) NULLP, 
                            (ItRtCtx *)irCtx, irCtxLen, IT_M3UA_DFLT);
         }
      } /* end of if (rcRcvdInMsg == FALSE) */
   } /* End of IPSP-SE && ackFlag == FALSE */
#endif

   if (localPsp == FALSE)
   {
      ItPsCb *psCb;   /* local PS control block */

      /* Initialize psCb */
      psCb = (ItPsCb *)NULLP;
      /* Send Status Indication to Layer Management */
      IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))
      itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP;
      itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS;
      itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_ASPM;
      itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_MSG_RECEIVED;
      itGlobalCb.mgmt.t.usta.s.pspId         = pspCb->pspCfg.pspId;
      itGlobalCb.mgmt.t.usta.t.aspm.msgType  = (U16)((ackFlag == TRUE) ? 
                                                LIT_ASPM_ASPAC_ACK : 
                                                LIT_ASPM_ASPAC);
      itGlobalCb.mgmt.t.usta.t.aspm.tmType   = type;
      itGlobalCb.mgmt.t.usta.t.aspm.sctSuId  = assocCb->sctSap->sctCfg.suId;

      if (info != (Txt *) NULLP)
      {
         cmMemcpy((U8 *)itGlobalCb.mgmt.t.usta.t.aspm.info, (U8 *)info, 
                  MIN(cmStrlen((U8 *)info), LIT_MAX_INFO));
      }
      itGlobalCb.mgmt.t.usta.t.aspm.nmbPs    = 
                        (U8)((nrCtxLen < LIT_MAX_PSID)? nrCtxLen : LIT_MAX_PSID);
      for (j = 0; ((j < nrCtxLen) && (j < LIT_MAX_PSID)); j++)
      {              
         psCb = itPsmFindPs(nrCtx[j].rtCtx);
         itGlobalCb.mgmt.t.usta.t.aspm.psLst[j]   = psCb->psCfg.psId;

      }
      (Void) itMiStaIndM(&itGlobalCb.mgmt);
   }
   if (nrCtxLen == NULLD)
   {
      RETVALUE(RFAILED);
   }

   /* it020.106 - Timer is stopped when the ASPAC-Ack is considered valid. */
   /* - Stop the ASPM timer if it is not started
    *  for ASPDN/ASPIA */
   if (((pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP) || 
       ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && (ackFlag == TRUE))) &&
        (assocCb->aspmType != IT_ASPM_ASPDN) && 
        (assocCb->aspmType != IT_ASPM_ASPIA))
   {
      /* SGP server or IPSP has responded */
      itTcStopTimer(&assocCb->tmrAspm);
   }

   /* distribute event to all PSs */
   (Void) itPsmAllPsEvt(assocCb, nrCtx, nrCtxLen, 
                        (U16)(ackFlag == TRUE ? 
                              IT_EVT_ASP_AC_ACK : IT_EVT_ASP_AC), type);
   /* In case of receiving Ack at ASP and at IPSP (SE), RPS are
    * additionally required to be marked as ACTIVE  */

    if (((pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP) && (ackFlag == TRUE)) ||
                ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
                 (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_SE)))
    {
       /* Get the RPS list for the PSP */
       IT_GET_RPS_FRM_PSP(assocCb, irCtx, irCtxLen);
       (Void) itPsmAllPsEvt(assocCb, irCtx, irCtxLen, 
                              (U16)(ackFlag == TRUE ? 
                               IT_EVT_ASP_AC_ACK : IT_EVT_ASP_AC), type);
    }
    /* to take care of large configuration problem
       the updation of DPC status is taken out of the itMifPspEvt function
       as this loop need to be called only once per Avtiveor Active
       Ack message.  update the DPC status of Non-routing DPCs (only for ASP) */
   if (pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP)
   {
      Bool dpcDone;
      ItDpcCb  *dpcCb;

      dpcDone = FALSE;
      if (cmHashListGetNext(&itGlobalCb.addrTrn.dpcList, (PTR) NULLP,
         (PTR *)&dpcCb) != ROK)
      {
         dpcDone = TRUE;
      }
      /*
       * For the set of DPCs (one DPC or all DPCs), recalculate the overall
       * accessibility state and report any change of state to rest of system
       */
      while (dpcDone == FALSE)
      {
         /* change done to allow Point code status updation for
            SPMC as well. This is required as there can be DPC event 
            even though there was no PS event. e.g. the only SGP through which
            DPC is available comes active and the Remote PS was already
            active with a different SGP through which the DPC is unavailabe */ 
         if ((dpcCb->type == IT_DPCCB_SPMC) || 
             (dpcCb->type == IT_DPCCB_NONROUTE))
         {
            U8    oldDpcSt;   /* old DPC state */
            U8    oldDpcCong; /* old DPC congestion level */
            U8    dpcEv;      /* DPC related event */
            Bool  dpcFwd;     /* TRUE if event to be forwarded */
            dpcFwd   = FALSE;
            dpcEv    = 0;
            /* Evaluate overall accessibility/congestion of the DPC */
            oldDpcSt    = dpcCb->dpcSt;
            oldDpcCong  = dpcCb->congLevel;
            itMifCalcDpcStatus(dpcCb, IT_MIF_PC_SUM, 0);
      
            if (dpcCb->congLevel != oldDpcCong)
            {
               dpcEv = IT_MIF_PC_CON;
               dpcFwd = TRUE;
            }
            
            else if (dpcCb->dpcSt != oldDpcSt) 
            {
               dpcFwd = TRUE;
               switch (dpcCb->dpcSt)
               {
                  case IT_DPC_AVAILABLE:
                     dpcEv = IT_MIF_PC_AVA;
                     break;
                  case IT_DPC_UNAVAILABLE:
                     dpcEv = IT_MIF_PC_UNA;
                     break;
                  default:
                     dpcFwd = FALSE;
               }
            }
            
            /* if there is information to forward to users, do so */
            if (dpcFwd == TRUE)
            {
               if ((dpcCb->type == IT_DPCCB_NONROUTE) ||
                  ((dpcCb->owner != NULL) && (dpcCb->owner->psCfg.lclFlag != TRUE)))
               {
                   (Void) itMifDpcEvt(TRUE, assocCb->assocId,
                     IT_MIF_SGP, dpcEv, dpcCb->nwk->nwkCfg.nwkId, dpcCb->dpc, (Dpc)0,
                     (U8)((dpcEv == IT_MIF_PC_CON) ? dpcCb->congLevel : 0), 0,
                     dpcCb);
               }
            }
         }
            /* Get next DPC in hash list */
         if (cmHashListGetNext(&itGlobalCb.addrTrn.dpcList, (PTR)dpcCb,
            (PTR *)&dpcCb) != ROK)
         {
            dpcDone = TRUE;
         }
      } /* end while !dpcDone */
   }
   if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_ASP) ||
       ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && (ackFlag == FALSE)))
   {
      ItPsCb *psCb;   /* local PS control block */
      ItRtCtx locRtCtx; /* Temp storage for routing contexts */
      Bool    aspIdPres;    /* ASP Identifier Present */
      U32     aspId;    /* ASP Identifier */

      aspId = NULLD;
      /* Initialize psCb */
      psCb = (ItPsCb *)NULLP;
      /* Sending notifies to psp for routing contexts */
      for (j = 0; j < nrCtxLen; j++)
      {
         psCb = itPsmFindPs(nrCtx[j].rtCtx);
         /* According to Draft 7 we should not send back 
          * the INFO in ACK Msg */
         
         /* Replace PS ID with routing context value - Draft 7 DRKM
          * implementation changes */
         locRtCtx.rtCtx = psCb->psSta.psStaEndp[IT_ASSOC2SUID(assocCb->assocId)]
                                 .rteCtx[IT_ASSOC2PSPID(assocCb->assocId)].rCtx;
         locRtCtx.thmType = nrCtx[j].thmType;

         (Void) itMmhAspAc(assocCb, TRUE, locRtCtx.thmType, (Txt *) NULLP, 
                           &locRtCtx, 1);
         if ((psCb->psSta.asSt != LIT_AS_DOWN) && 
              (nrCtx[j].ntfySend == TRUE))
         {
            SuId     suId;     /* SCT SAP id of assoc */
            ItPspId  tmpPspId; /* PSP id of assoc     */
            /* notify client Assocs */
            for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)
            {
               suId  = IT_ASSOC2SUID(i);
               tmpPspId = IT_ASSOC2PSPID(i);
               if ((psCb->psSta.psStaEndp[suId].aspSt[tmpPspId] != LIT_ASP_DOWN)
                   &&
                 (psCb->psSta.psStaEndp[suId].aspSt[tmpPspId] != LIT_ASP_UNSUPP)
                    &&
                   ((itGlobalCb.assoc[i]->owner->pspCfg.pspType == 
                                                          LIT_PSPTYPE_ASP) ||
                    (itGlobalCb.assoc[i]->owner->pspCfg.pspType == 
                                                         LIT_PSPTYPE_IPSP)))
               {
                  if (psCb->psSta.psStaEndp[suId].rteCtx[tmpPspId].rcValid != 
                                                                           TRUE)
                  {
                     continue;
                  }
                  cmMemcpy((U8 *)&locRtCtx, (U8 *)&(nrCtx[j].rtCtx),
                                                            sizeof(ItRtCtx));
                  locRtCtx.rtCtx = psCb->psSta.psStaEndp[suId].rteCtx[tmpPspId].                                                                           rCtx;
                  
                  aspIdPres = FALSE;
                  /* it016.106 - Changes to make storing of ASPID optional
                   * when rxTxAspId is FALSE. So, even if rxTxAspId is FALSE 
                   * send ASPID, if available. */
                  if (itGlobalCb.aspIdCb.aspIdValid[pspId] == TRUE)
                  {
                     aspId = itGlobalCb.aspIdCb.aspIdLst[pspId];
                     aspIdPres = TRUE;
                  }
                  (Void) itMmhNotify(itGlobalCb.assoc[i], (Txt *)NULLP, 
                                     &locRtCtx, 1, IT_M3UA_NTFY_TYPE_ASCHG, 
                                     aspIdPres, aspId);
               } /* end if ((psCb->psSta.aspSt[i] != LIT_ASP_DOWN) &&*/
            } /* end for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)*/
         } /* end if (psCb->psSta.asSt != LIT_AS_DOWN)*/
      } /* end for (j = 0; j < nrCtxLen; j++) */
   }
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   /* In case of IPSP-DE dynamic registration, if this node has registered 
    * after it's remote PS are activated (i.e., remote node has already
    * registered and activated its PS) then the chldPsLst for RPS got 
    * remained empty, this chldPsLst is being updated now */
   if ((ackFlag == TRUE)
                   && (pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP)
                   && (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_DE))
   {
      /* For all RPS of this assoc which currently have NULL chldPsLst, update
       * their SLS MAPs in chldPsLst */
      for (i=0; i < assocCb->nmbPs; i++)
      {
         if ((assocCb->ps[i]->psCfg.lclFlag == FALSE)
              && (assocCb->ps[i]->psSta.psStaEndp[IT_ASSOC2SUID(
                 assocCb->assocId)].aspSt[pspId] == LIT_ASP_ACTIVE))
         {
            itLscUpd(assocCb->ps[i], assocCb->assocId, IT_EVT_ASP_AC_ACK, 
                     LIT_AS_ACTIVE);
         }
      }
   }
#endif /* ITASP && OG_RTE_ON_LPS_STA */
   
   RETVALUE(ROK);
} /* end of itPsmAspAc */



/*
*
*       Fun:   itPsmAspIa
*
*       Desc:  Call itMiStaInd to cause LMI to generate a status indication
*              Call itPsmAllPsEvt to distribute the event to all PSs.
*              Call itMmhNotify, passing the ACB and the updated routing
*              context, to generate the ASP_INACTIVE acknowledge.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: Called by MMH to indicate reception of an ASPIA message from
*              the M3UA peer.
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmAspIa
(
ItAssocCb      *assocCb,      /* association control block */     
Bool           ackFlag,       /* TRUE if acknowledge */           
Txt            *info,         /* extra information */             
ItRtCtx        *rCtx,         /* list of routing contexts */      
U16            rCtxLen       /* length of list */                
)
#else
PUBLIC S16 itPsmAspIa(assocCb, ackFlag, info, rCtx, rCtxLen)
ItAssocCb      *assocCb;      /* association control block */    
Bool           ackFlag;       /* TRUE if acknowledge */          
Txt            *info;         /* extra information */            
ItRtCtx        *rCtx;         /* list of routing contexts */     
U16            rCtxLen;       /* length of list */               
#endif                                                           
{                                                                
   ItPspCb     *pspCb;        /* PSP control block */            
   Bool        localPsp;      /* TRUE if local PSP */            
   ItPspId     pspId;         /* PSP ID */                       
   U16         i;             /* loop index */
   U16         j;             /* loop index */
   ItRtCtx     nrCtx[LIT_MAX_PSID]; /* updated routing context list */
   ItRtCtx     irCtx[LIT_MAX_PSID]; /* invalid routing context list */
   U16         nrCtxLen;            /* length of list */               
   U16         irCtxLen;            /* length of list */               
   Bool        rPsToInAct;          /* RPS to made Inactive?? */

   TRC2(itPsmAspIa)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itPsmAspIa(assocCb, info(%s), rCtx, rCtxLen(%d))\n", 
          info, rCtxLen));

   rPsToInAct = TRUE; 
   pspCb    = assocCb->owner;
   pspId    = pspCb->pspCfg.pspId;
   localPsp = (Bool)((pspId == IT_LOCAL_PSPID) ? TRUE : FALSE);

   irCtxLen = 0;
   nrCtxLen = 0;
   cmMemset((U8 *)nrCtx, 0, sizeof(ItRtCtx) * LIT_MAX_PSID);
   cmMemset((U8 *)irCtx, 0, sizeof(ItRtCtx) * LIT_MAX_PSID);

   /* code shifted down to send PSIDs in LM notification to ASPIA */

   /* it020.106 -Timer is stopped later when the ASPIA-Ack is considered valid*/
   
   if ((assocCb->assocSta->aspSt == LIT_ASP_DOWN) &&
      ! ((assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_IPSP) &&
        (assocCb->owner->pspCfg.ipspMode == LIT_IPSPMODE_DE)))

   {
      if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_ASP) ||
          ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && (ackFlag == FALSE)))
      {
         /* Send ASPDN ACK message to peer */
         /* According to Draft 7 we should not send back the INFO in ACK Msg */

         (Void) itMmhAspDn(assocCb, TRUE, (Txt *) NULLP);
      }
   }
   else
   {
      nrCtxLen = rCtxLen;
      if ((rCtx == (ItRtCtx *) NULLP) || (rCtxLen == 0))
      {
         if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
                 (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_DE) &&
                 (ackFlag == TRUE))
         {
            /* Build local routing context from configuration */
            (Void) itPsmValidateRCtx(assocCb, nrCtx, &nrCtxLen, 
                                  (ItRtCtx *)NULLP, (U16 *)NULLP, 
                                     IT_VRCTX_BUILD_DE_ACK);
         }
         else
         {
            /* Build local routing context from configuration */
            (Void) itPsmValidateRCtx(assocCb, nrCtx, &nrCtxLen, 
                                (ItRtCtx *)NULLP, (U16 *)NULLP,
                                       IT_VRCTX_BUILD);
         }
         if ( nrCtxLen == 0)
         {
            (Void) itMmhError(assocCb, IT_M3UA_ERROR_NO_AS_FOR_ASP, 
                         (Buffer **)NULLP, 0, (ItM3uaTag *) NULLP, (ItRtCtx *) 
                         NULLP, 0, IT_M3UA_DFLT);
            RETVALUE(RFAILED);
         }
      }
      else
      {
         (Void) cmMemcpy((U8 *)nrCtx, (U8 *)rCtx, sizeof(ItRtCtx) * rCtxLen);
         /* Validate rCtx list according to configured routing */
         nrCtxLen = rCtxLen;
         itAtMapRcToPs(assocCb, nrCtx, &nrCtxLen, irCtx, &irCtxLen, ackFlag);
         if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
                 (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_DE) &&
                 (ackFlag == TRUE))
         {
             (Void) itPsmValidateRCtx(assocCb, nrCtx, &nrCtxLen, 
                                  irCtx, &irCtxLen, IT_VRCTX_RMV_UNSUPP_DE_ACK);
         }
         else
         {
             (Void) itPsmValidateRCtx(assocCb, nrCtx, &nrCtxLen, 
                                  irCtx, &irCtxLen, IT_VRCTX_RMV_UNSUPP);
         }
      }

      /* Reject routing contexts that are not supported */
      if(irCtxLen != NULLD)
      {
         (Void) itMmhError(assocCb, IT_M3UA_ERROR_INV_RCTX, 
                           (Buffer **)NULLP, 0, 
                           (ItM3uaTag *) NULLP, irCtx, irCtxLen, 
                            IT_M3UA_DFLT);
      }
      
      if (nrCtxLen == NULLD)
      {
         RETVALUE(RFAILED);
      }

      /* it020.106 - Timer is stopped when the ASPIA-Ack is considered valid. */
      if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP) || 
          ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && (ackFlag == TRUE)))
      {
         /* SGP server or IPSP has responded */
         itTcStopTimer(&assocCb->tmrAspm);
      }

      if (localPsp == FALSE)
      {
         ItPsCb *psCb;   /* local PS control block */
         /* Initialize psCb */
         psCb = (ItPsCb *)NULLP;
         /* Send Status Indication to Layer Management */
         IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))
         itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP;
         itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS;
         itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_ASPM;
         itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_MSG_RECEIVED;
         itGlobalCb.mgmt.t.usta.s.pspId         = pspCb->pspCfg.pspId;
         itGlobalCb.mgmt.t.usta.t.aspm.msgType  = (U16)((ackFlag == TRUE) ? 
                                                   LIT_ASPM_ASPIA_ACK : 
                                                   LIT_ASPM_ASPIA);
         itGlobalCb.mgmt.t.usta.t.aspm.sctSuId  = assocCb->sctSap->sctCfg.suId;

         if (info != (Txt *) NULLP)
         {
            cmMemcpy((U8 *)itGlobalCb.mgmt.t.usta.t.aspm.info, (U8 *)info, 
                     MIN(cmStrlen((U8 *)info), LIT_MAX_INFO));
         }
         itGlobalCb.mgmt.t.usta.t.aspm.nmbPs    =
                           (U8)((nrCtxLen < LIT_MAX_PSID)? nrCtxLen : LIT_MAX_PSID);
         for (j = 0; ((j < nrCtxLen) && (j < LIT_MAX_PSID)); j++)
         {
            psCb = itPsmFindPs(nrCtx[j].rtCtx);
            itGlobalCb.mgmt.t.usta.t.aspm.psLst[j]   = psCb->psCfg.psId;
         }
         (Void) itMiStaIndM(&itGlobalCb.mgmt);
      }

      /* distribute event to all PSs */
      (Void) itPsmAllPsEvt(assocCb, nrCtx, nrCtxLen, 
                           (U16)(ackFlag == TRUE ? 
                                 IT_EVT_ASP_IA_ACK : IT_EVT_ASP_IA), 
                                 IT_M3UA_DFLT);
      

      for (i = 0; i < assocCb->nmbPs; i++)
      {
         ItPsCb      *psCb;               /* PS CB */
         psCb = assocCb->ps[i];
         if ((psCb->psCfg.lclFlag == TRUE) 
              && (psCb->psSta.psStaEndp[IT_ASSOC2SUID(assocCb->assocId)].\
                 aspSt[IT_ASSOC2PSPID(assocCb->assocId)] == LIT_ASP_ACTIVE))
         {
              rPsToInAct = FALSE;
              break;
         }
      }
      if (rPsToInAct == TRUE)
      {
         /* At IPSP(SE) and at ASP Indicate change in PSP state to affected RPSs
          */
         /* Get the RPS list for the PSP [irCtx and irCtxLen are used ] */
         if (localPsp == FALSE)
         {
            if (((pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP) && 
                      (ackFlag == TRUE))||
                      ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
                       (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_SE)))
            {
               IT_GET_RPS_FRM_PSP(assocCb, irCtx, irCtxLen);
               (Void) itPsmAllPsEvt(assocCb, irCtx, irCtxLen, 
                                    (U16)(ackFlag == TRUE ? 
                                       IT_EVT_ASP_IA_ACK : IT_EVT_ASP_IA), 0);
            }
         }
      }
      if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_ASP) ||
          ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && (ackFlag == FALSE)))
      {
         ItPsCb  *locPsCb;      /* Temp PS CB */
         ItRtCtx  tmpRtCtx[LIT_MAX_PSID]; /* Temp Routing Context storage*/
         /* Initialize psCb */
         locPsCb = (ItPsCb *)NULLP;

         /* Map ps ID to routing context values - Draft 07
          * implementation changes */
         for (i = 0; i < nrCtxLen; i++)
         {
            locPsCb = itPsmFindPs(nrCtx[i].rtCtx);
            tmpRtCtx[i].rtCtx = locPsCb->psSta.psStaEndp[IT_ASSOC2SUID(
            assocCb->assocId)].rteCtx[IT_ASSOC2PSPID(assocCb->assocId)].rCtx;
         }
         /* Send ASPIA-ACK message to client */
         /* According to Draft 7 we should not send back the INFO in ACK Msg */
         (Void) itMmhAspIa(assocCb, TRUE, (Txt *)NULLP, tmpRtCtx, nrCtxLen);
         /* Sending notifies to psp for routing contexts that are not 
            restarting */
         for (j = 0; j < nrCtxLen; j++)
         {
            ItPsCb *psCb;   /* local PS control block */
            ItRtCtx  locRtCtx; /* Temp Routing Context storage*/
            Bool    aspIdPres;    /* ASP Identifier Present */
            U32     aspId;    /* ASP Identifier */

            /* Initialize psCb */
            psCb = (ItPsCb *)NULLP;

            aspId = NULLD;
            psCb = itPsmFindPs(nrCtx[j].rtCtx);
            if ((psCb->psSta.asSt != LIT_AS_DOWN) && 
                 (nrCtx[j].ntfySend == TRUE))
            {
               SuId     suId;     /* SCT SAP id of assoc */
               ItPspId  tmpPspId; /* PSP id of assoc     */
               /* notify client Assocs */
               /* notify client Assocs */
               for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)
               {
                  suId  = IT_ASSOC2SUID(i);
                  tmpPspId = IT_ASSOC2PSPID(i);

                  if ((psCb->psSta.psStaEndp[suId].aspSt[tmpPspId] !=
                                                                LIT_ASP_DOWN) &&
                     (psCb->psSta.psStaEndp[suId].aspSt[tmpPspId] !=
                                                              LIT_ASP_UNSUPP) &&
                      ((itGlobalCb.assoc[i]->owner->pspCfg.pspType == 
                                                          LIT_PSPTYPE_ASP) ||
                       (itGlobalCb.assoc[i]->owner->pspCfg.pspType == 
                                                          LIT_PSPTYPE_IPSP)))
                  {
                     if (psCb->psSta.psStaEndp[suId].rteCtx[tmpPspId].rcValid 
                                                                        != TRUE)
                     {
                        continue;
                     }
                     cmMemcpy((U8 *)&locRtCtx, (U8 *)&(nrCtx[j]),
                                                            sizeof(ItRtCtx));
                     /* Map ps ID to routing context values - Draft 07 */
                     locRtCtx.rtCtx = psCb->psSta.psStaEndp[suId].\
                                                          rteCtx[tmpPspId].rCtx;

                     aspIdPres = FALSE;
                  /* it016.106 - Changes to make storing of ASPID optional
                   * when rxTxAspId is FALSE. So, even if rxTxAspId is FALSE 
                   * send ASPID, if available. */
                     if (itGlobalCb.aspIdCb.aspIdValid[pspId] == TRUE)
                     {
                        aspId = itGlobalCb.aspIdCb.aspIdLst[pspId];
                        aspIdPres = TRUE;
                     }
                     (Void) itMmhNotify(itGlobalCb.assoc[i],
                                        (Txt *)NULLP, 
                                        &locRtCtx, 1, 
                                        IT_M3UA_NTFY_TYPE_ASCHG,
                                        aspIdPres, aspId);
                  } /* end if ((psCb->psSta.aspSt[i] != LIT_ASP_DOWN) &&*/
               } /* end for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)*/
            } /* end if (psCb->psSta.asSt != LIT_AS_DOWN)*/
         } /* end for (j = 0; j < nrCtxLen; j++) */
      }
   }
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   /* In case of inactive-ack, chldPsCb is also required to be updated */
   if (((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
                      (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_SE))
                   || (pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP))
   {
      /* All RPS of this PSP needs update in their SLS MAPs in chldPsLst */
      for (i = 0; i < assocCb->nmbPs; i++)
      {
         if ((assocCb->ps[i]->psCfg.lclFlag == FALSE) &&
              ((assocCb->ps[i]->psSta.psStaEndp[IT_ASSOC2SUID(assocCb->assocId)]
               .aspSt[pspId] == LIT_ASP_INACTIVE)
               || (assocCb->ps[i]->psSta.psStaEndp[IT_ASSOC2SUID(
                      assocCb->assocId)].aspSt[pspId] == LIT_ASP_ACTIVE)))
         {
            itLscUpd(assocCb->ps[i], assocCb->assocId, IT_EVT_ASP_IA_ACK,
                     LIT_AS_INACTIVE);
         }
      }
   }
#endif /* ITASP && OG_RTE_ON_LPS_STA */

   RETVALUE(ROK);
} /* end of itPsmAspIa */


/*
*
*       Fun:   itPsmValidateRCtx
*
*       Desc:  Called by PSM to validate the incoming routing context list
*              according to the configuration
*
*
*       Ret:   Failure:           RFAILED
*              Invalid:           RNA
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 itPsmValidateRCtx
(
ItAssocCb      *assocCb,      /* assoc control block */
ItRtCtx        *nrCtx,        /* routing context list */
U16            *nrCtxLen,     /* length of list */
ItRtCtx        *irCtx,        /* invalid routing context list */
U16            *irCtxLen,     /* length of list */
U8             operation      /* type of validation */
)
#else
PUBLIC S16 itPsmValidateRCtx(assocCb, nrCtx, nrCtxLen, irCtx, irCtxLen, operation)
ItAssocCb      *assocCb;      /* assoc control block */
ItRtCtx        *nrCtx;        /* routing context list */
U16            *nrCtxLen;     /* length of list */              
ItRtCtx        *irCtx;        /* invalid routing context list */
U16            *irCtxLen;     /* length of list */              
U8             operation;     /* type of validation */
#endif
{
   ItPsCb      *psCb;         /* PS control block */
   U16         i;             /* loop index */
   Bool        found;         /* TRUE if routing context valid */
   U16         rCtxLen;       /* loop bound */
   ItPspId     pspId;         /* PSP Id of the association */
   Bool        oprnAtSgpOrDE; /* Operation is at SGP Or IPSP DE node? */
   SuId        suId;          /* SCT SAP id of the association */

   TRC2(itPsmValidateRCtx)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
          "itPsmValidateRCtx()\n"));


   /* Initialize psCb */
   psCb  = (ItPsCb *)NULLP;
   pspId = assocCb->owner->pspCfg.pspId;
   suId  = IT_ASSOC2SUID(assocCb->assocId);

   /* Determine whether operation is at ASP/IPSP(SE) or at SGP/IPSP(DE) */
   /* The behavior for ASPM and ASPM-ACK message will be same at IPSP(DE) */
   oprnAtSgpOrDE = FALSE;
   if ((assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_ASP) || 
                (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_LOCAL) ||
                ((assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
                 (assocCb->owner->pspCfg.ipspMode == LIT_IPSPMODE_DE)))
   {
      oprnAtSgpOrDE = TRUE;
   }
   if ((operation == IT_VRCTX_BUILD) ||
       (operation == IT_VRCTX_BUILD_DE_ACK))
   {
         rCtxLen = assocCb->nmbPs;
   }
   else
   {
      /* use incoming list and filter */
      rCtxLen = *nrCtxLen;
   }
   
   *nrCtxLen   = 0;

   for (i = 0; i < rCtxLen; i++)
   {
      found = FALSE;
      switch (operation)
      {
         case IT_VRCTX_BUILD       :  /* Fall Through */
         case IT_VRCTX_BUILD_DE_ACK:
            /* At IPSP (DE) and at SGP, RC is RPS */
            if (oprnAtSgpOrDE == TRUE)
            {
               if (operation == IT_VRCTX_BUILD)
               {
                  if (assocCb->ps[i]->psCfg.lclFlag != TRUE)
                  {
                     /* build PS-id array (which corresponds to routing context)
                      * from local config */
                     nrCtx[*nrCtxLen].rtCtx     = assocCb->ps[i]->psCfg.psId;
                     nrCtx[*nrCtxLen].ntfySend  = FALSE;
                     nrCtx[*nrCtxLen].ntfyStaId = 0;
                     (*nrCtxLen)++;
                  }
               }
               else 
               {
                  if (assocCb->ps[i]->psCfg.lclFlag == TRUE)
                  {
                     /* At IPSP-DE with ackFlag as TRUE */
                     /* build PS-id array (which corresponds to routing context)
                      * from local config */
                     nrCtx[*nrCtxLen].rtCtx     = assocCb->ps[i]->psCfg.psId;
                     nrCtx[*nrCtxLen].ntfySend  = FALSE;
                     nrCtx[*nrCtxLen].ntfyStaId = 0;
                     (*nrCtxLen)++;
                  }
               }
            }
            else /* At ASP and IPSP (SE) */
            {
               /* build PS-id array (which corresponds to routing context)
                * from local config */
               if (assocCb->ps[i]->psCfg.lclFlag == TRUE)
               {
                  /* At IPSP-DE with ackFlag as TRUE */
                  /* build PS-id array (which corresponds to routing context)
                   * from local config */
                  nrCtx[*nrCtxLen].rtCtx     = assocCb->ps[i]->psCfg.psId;
                  nrCtx[*nrCtxLen].ntfySend  = FALSE;
                  nrCtx[*nrCtxLen].ntfyStaId = 0;
                  (*nrCtxLen)++;
               }
            }
            break;
         case IT_VRCTX_RMV_UNSUPP       :  /* Fall through */
         case IT_VRCTX_RMV_UNSUPP_DE_ACK:
            /* In case of IPSP(SE) and ASP, LPS is the RC
             * And in IPSP(DE) and at SGP, RPS is the RC */
            /* classify into supported and unsupported PSs */
            psCb  = itPsmFindPs(nrCtx[i].rtCtx);
            if (psCb != (ItPsCb *)NULLP)
            {
               /* In IPSP(DE) and at SGP, RC is the RPS */
               if (oprnAtSgpOrDE == TRUE)
               {
                  if (operation == IT_VRCTX_RMV_UNSUPP)
                  {
                     if ((psCb->psSta.psStaEndp[suId].aspSt[pspId] != 
                                                             LIT_ASP_UNSUPP) && 
                        (psCb->psSta.psStaEndp[suId].aspSt[pspId] != 
                                 LIT_ASP_DOWN) && (psCb->psCfg.lclFlag != TRUE))
                     {
                        nrCtx[*nrCtxLen].rtCtx     = nrCtx[i].rtCtx;
                        nrCtx[*nrCtxLen].ntfySend  = nrCtx[i].ntfySend;
                        nrCtx[*nrCtxLen].ntfyStaId = nrCtx[i].ntfyStaId;
                        (*nrCtxLen)++;
                        found = TRUE;
                     }
                  }
                  else /* IPSP-DE, ACK case, RC is LPS  */
                  {
                     if ((psCb->psSta.psStaEndp[suId].aspSt[pspId] != 
                                                             LIT_ASP_UNSUPP) && 
                        (psCb->psSta.psStaEndp[suId].aspSt[pspId] != 
                                 LIT_ASP_DOWN) && (psCb->psCfg.lclFlag == TRUE))
                     {
                        nrCtx[*nrCtxLen].rtCtx     = nrCtx[i].rtCtx;
                        nrCtx[*nrCtxLen].ntfySend  = nrCtx[i].ntfySend;
                        nrCtx[*nrCtxLen].ntfyStaId = nrCtx[i].ntfyStaId;
                        (*nrCtxLen)++;
                        found = TRUE;
                     }
                  }
               }
               else /* In case of IPSP(SE) and at ASP, RC is the LPS */
               {
                  if ((psCb->psSta.psStaEndp[suId].aspSt[pspId] != 
                                                                 LIT_ASP_UNSUPP)
                     && (psCb->psSta.psStaEndp[suId].aspSt[pspId] !=
                                                                   LIT_ASP_DOWN)
                     && (psCb->psCfg.lclFlag == TRUE))
                  {
                     nrCtx[*nrCtxLen].rtCtx     = nrCtx[i].rtCtx;
                     nrCtx[*nrCtxLen].ntfySend  = nrCtx[i].ntfySend;
                     nrCtx[*nrCtxLen].ntfyStaId = nrCtx[i].ntfyStaId;
                     (*nrCtxLen)++;
                     found = TRUE;
                  }
               }
            }  /* end of psCb != NULLP */
            if (found == FALSE)
            {
               irCtx[*irCtxLen].rtCtx     = 
                               psCb->psSta.psStaEndp[suId].rteCtx[pspId].rCtx;
               irCtx[*irCtxLen].ntfySend  = nrCtx[i].ntfySend;
               irCtx[*irCtxLen].ntfyStaId = nrCtx[i].ntfyStaId;
               (*irCtxLen)++;
            }
            break;
         /* next 2 cases fall through */
         case IT_VRCTX_OVERRIDE:
         case IT_VRCTX_LOADSHARE:
            psCb  = itPsmFindPs(nrCtx[i].rtCtx);
            if (psCb != (ItPsCb *)NULLP)
            {
               /* In IPSP(DE) and at SGP, RPS is the RC */
               /* In IPSP(DE) and at SGP, RC is the RPS */
               if (oprnAtSgpOrDE == TRUE)
               {
                  if (psCb->psCfg.lclFlag != TRUE)
                  {
                      if (((psCb->psCfg.mode == LIT_MODE_ACTSTANDBY) &&
                          (operation == IT_VRCTX_OVERRIDE)) ||
                          ((psCb->psCfg.mode == LIT_MODE_LOADSHARE) &&
                          (operation == IT_VRCTX_LOADSHARE)))
                      {
                         nrCtx[*nrCtxLen].rtCtx     = nrCtx[i].rtCtx;
                         nrCtx[*nrCtxLen].ntfySend  = nrCtx[i].ntfySend;
                         nrCtx[*nrCtxLen].ntfyStaId = nrCtx[i].ntfyStaId;
                         (*nrCtxLen)++;
                         found = TRUE;
                      }
                  } /* End of lclFlag != TRUE */
               }
               else /* In case of IPSP(SE) and at ASP, LPS is the RC */
               {
                  if (psCb->psCfg.lclFlag == TRUE) 
                  {
                     if (((psCb->psCfg.mode == LIT_MODE_ACTSTANDBY) &&
                         (operation == IT_VRCTX_OVERRIDE)) ||
                         ((psCb->psCfg.mode == LIT_MODE_LOADSHARE) &&
                         (operation == IT_VRCTX_LOADSHARE)))
                     {
                        nrCtx[*nrCtxLen].rtCtx     = nrCtx[i].rtCtx;
                        nrCtx[*nrCtxLen].ntfySend  = nrCtx[i].ntfySend;
                        nrCtx[*nrCtxLen].ntfyStaId = nrCtx[i].ntfyStaId;
                        (*nrCtxLen)++;
                        found = TRUE;
                     }
                  } /* End of lclFlag == TRUE */
               }
            } /* End: psCb != NULLP */
               if (found == FALSE)
               {
                  irCtx[*irCtxLen].rtCtx     = 
                               psCb->psSta.psStaEndp[suId].rteCtx[pspId].rCtx;
                  irCtx[*irCtxLen].ntfySend  = nrCtx[i].ntfySend;
                  irCtx[*irCtxLen].ntfyStaId = nrCtx[i].ntfyStaId;
                  (*irCtxLen)++;
               }
            break;

         default:
            RETVALUE(RFAILED);
      }
   } /* end for */

   RETVALUE(ROK);
} /* end of itPsmValidateRCtx */



/*
*
*       Fun:   itPsmAllPsEvt
*
*       Desc:  Called by PSM to distribute an PS-related event to
*              multiple PSs
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmAllPsEvt
(
ItAssocCb      *assocCb,      /* assoc contrl block */
ItRtCtx        *rCtx,         /* routing context list */  
U16            rCtxLen,       /* length of list */        
U16            event,         /* PS-related event */      
U8             type           /* traffic handling mode */ 
)
#else
PUBLIC S16 itPsmAllPsEvt(assocCb, rCtx, rCtxLen, event, type)
ItAssocCb      *assocCb;      /* assoc contrl block */
ItRtCtx        *rCtx;         /* routing context list */        
U16            rCtxLen;       /* length of list */              
U16            event;         /* PS-related event */
U8             type;          /* traffic handling mode */              
#endif                                                          
{                                                               
   ItPsCb      *psCb;         /* PS control block */            
   U16         i;             /* loop index */                  
   S16         ret;           /* return value */
                              
   TRC2(itPsmAllPsEvt)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
          "itPsmAllPsEvt(assocCb, rCtx, rCtxLen(%d), event(%d), type(%d))\n",
          rCtxLen, event, type))

   psCb = (ItPsCb *)NULLP;

   /*
    * Note: the rCtx passed to this function is already validated by 
    * itPsmValidateRCtx 
    */

   /* for each routing context, find the PS and forward the event to the PS */
   for (i = 0; i < rCtxLen; i++)
   {
      if ((ret = itPsmPsEvt(&rCtx[i], (UConnId)assocCb->assocId, event, 
                            type)) 
          != ROK)
      {
         RETVALUE(ret);
      }
   }

   RETVALUE(ROK);
} /* end of itPsmAllPsEvt */


/*
*
*       Fun:   itPsmPsEvt
*
*       Desc:  ASP and AS state machines, operating on a PS and PSP instance.
*              Incoming event changes the states.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmPsEvt
(
ItRtCtx        *rCtx,         /* route context */
UConnId        assocId,       /* Assoc Id */
U16            event,         /* PS-related event */
U8             type           /* traffic handling mode */
)
#else
PUBLIC S16 itPsmPsEvt(rCtx, assocId, event, type)
ItRtCtx        *rCtx;         /* route context */
UConnId        assocId;       /* Assoc Id */
U16            event;         /* PS-related event */      
U8             type;          /* traffic handling mode */ 
#endif
{
   Bool        matchFlag;     /* TRUE if match found */
   Bool        updateFlag;     /* TRUE if match found */
   U32         nmbUp;         /* number of "up" PSPs */
   S32         entPos;        /* entity position */
   U32         i;             /* loop index */
   U32         k;             /* loop index */
   S32         j;             /* loop index */
   U8          oldAspSt;      /* old ASP state */
   U8          oldAsSt;       /* old AS state */
   ItPspCb     *pspCb;        /* PSP control block */
   ItPsCb      *psCb;         /* PS control block */
   ItMupMsg    *msg;          /* MUP message */
   Bool        aspEvent;      /* TRUE if sending ASP event to LM */
   U16         lmEvent;       /* Layer manager event code */
#ifdef LIT_RTE_ALARMS
   ItDpcCb     *dpcCb;        /* dpc control block */
#endif /* LIT_RTE_ALARMS */
   ItAssocCb   *assocCb;      /* Association Control block */
   ItPspId      pspId;        /* PSP id */
   U16          actAspCntPerSuId[LIT_MAX_SEP]; /* Active ASP count per SEP */
   U16          actAspCnt;    /* Active ASP count */
   SuId         suId;         /* End point Id of the association */
   U32          nmbAct;       /* number of "active" assocs */

#ifdef ZV
   /* it018.106 - addition - DFTHA Enhancement. */      
   ZvUpdSpecParams updArgs;
#endif


   TRC2(itPsmPsEvt);

#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
          "itPsmPsEvt(psCb, assocId(%d), event(%d), type(%d))\n", 
                        assocId, event, type));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
          "itPsmPsEvt(psCb, assocId(%ld), event(%d), type(%d))\n", 
                        assocId, event, type));
#endif

   entPos      = 0;
   lmEvent     = 0;
   aspEvent    = FALSE;

   /* Initialize psCb */
   psCb  = (ItPsCb *)NULLP;
   /* Get ps Cb */
   psCb = itPsmFindPs(rCtx->rtCtx);
   assocCb = itGlobalCb.assoc[assocId];
   pspCb   = assocCb->owner;
   pspId   = pspCb->pspCfg.pspId;
   suId    = IT_ASSOC2SUID(assocId);

   if (type == IT_M3UA_DFLT)
   {
       type = psCb->psCfg.mode;
   }

   /* ASP state machine */
   oldAspSt = psCb->psSta.psStaEndp[suId].aspSt[pspId];
#ifdef LIT_RTE_ALARMS
   if ((psCb->spmc == NULLP) ||
       (itAtGetDpc(psCb->nwk->nwkCfg.nwkId, psCb->spmc->dpc, &dpcCb) != ROK))
      dpcCb = NULLP;
#endif /* LIT_RTE_ALARMS */

   if (event != IT_EVT_RECONFIG)
   {
      
      switch (event)
      {
         /* following 2 cases fall through */
         case IT_EVT_ASP_UP:
         case IT_EVT_ASP_UP_ACK:
#ifdef LIT_RTE_ALARMS
            /* send alarm on ASP, if DPC state changes for SGP */
            if ((event == IT_EVT_ASP_UP_ACK) && 
                (psCb->psSta.psStaEndp[suId].aspSt[pspId] == LIT_ASP_ACTIVE) &&
                (pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP) &&
                (dpcCb != NULLP) && (dpcCb->dpcSt == IT_DPC_AVAILABLE) &&
                (dpcCb->pspDpcSt[assocId] == IT_DPC_AVAILABLE))
            {
              IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt));
              itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP;
              itGlobalCb.mgmt.hdr.msgType            = TUSTA;
              itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS;
              itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_RTE_UNAVAIL;
              itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_RCV_ASPUPACK;
              itGlobalCb.mgmt.t.usta.s.pspId         = pspId;
              itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc    = psCb->spmc->dpc;

              (Void) itMiStaIndM(&itGlobalCb.mgmt);
            }
#endif /* LIT_RTE_ALARMS */
            if ((psCb->psSta.psStaEndp[suId].aspSt[pspId] == LIT_ASP_DOWN)
/* If ASP UP message is received in ACTIVE or STANDBY state then
 * also PSP state should be moved to INACTIVE - Draft 7 requirement */
                 || (psCb->psSta.psStaEndp[suId].aspSt[pspId] ==
                                                               LIT_ASP_ACTIVE))
            {
               psCb->psSta.psStaEndp[suId].aspSt[pspId] = LIT_ASP_INACTIVE;
            }
            break;
   
         case IT_EVT_ASP_DN:
         {
            /* At SGP and IPSP (DE) only Remote PS's NTFY will be
            * sent, at IPSP SE, the local PS's NTFY will be sent */
            Bool ntfySnd;
            U32  aspId;     /* ASP Id */
            Bool    aspIdPres;    /* ASP Identifier Present */


                    
            aspId = NULLD;
            ntfySnd = FALSE;
            if (psCb->psCfg.lclFlag != TRUE)
            {
               if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_ASP) || 
                   (pspCb->pspCfg.pspType == LIT_PSPTYPE_LOCAL) || 
                    ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
                    (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_DE)))
               {
                  ntfySnd = TRUE;
               }
            }
            else
            {
               /* For Local PS */
               if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
                   (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_SE))
               {
                  ntfySnd = TRUE;
               }
            }
            if (ntfySnd == TRUE)
            {
               ItRtCtx locRtCtx; /* Temp storage for Routing Context */
               ItPspCb *curPspCb; /* Temp storage for PSP Cb */
               ItPspId  tmpPspId;    /* PSP Id */

               /* Initialize pspCb */
               curPspCb = (ItPspCb *)NULLP;

               /* For all associations */
               for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)
               {
                  if (i == assocId)
                  {
                     continue;
                  }
                  tmpPspId = IT_ASSOC2PSPID(i);
                  curPspCb = itGlobalCb.psp[tmpPspId];

                  /* NTFY is to be sent from the SEP on which 
                     message is received */
                  if((psCb->psSta.psStaEndp[IT_ASSOC2SUID(i)].aspSt[tmpPspId]
                                                         != LIT_ASP_DOWN) &&
                     (psCb->psSta.psStaEndp[IT_ASSOC2SUID(i)].aspSt[tmpPspId] 
                                                        != LIT_ASP_UNSUPP) &&
                     (IT_ASSOC2SUID(i) == IT_ASSOC2SUID(assocId)))
                  {
                     if (psCb->psSta.psStaEndp[IT_ASSOC2SUID(i)].\
                                               rteCtx[tmpPspId].rcValid != TRUE)
                     {
                        continue;
                     }
                     cmMemcpy((U8 *)&locRtCtx, (U8 *)rCtx, sizeof(ItRtCtx));
                     locRtCtx.rtCtx = psCb->psSta.psStaEndp[IT_ASSOC2SUID(i)].\
                                                        rteCtx[tmpPspId].rCtx;
                     locRtCtx.ntfyStaId = IT_M3UA_NTFY_INFO_ASP_FLR;

                     aspIdPres = FALSE;
                     /* it016.106 - Changes to make storing of ASPID optional
                      * when rxTxAspId is FALSE. So, even if rxTxAspId is FALSE 
                      * send ASPID, if available. */
                     if (itGlobalCb.aspIdCb.aspIdValid[pspId] == TRUE)
                     {
                        aspId = itGlobalCb.aspIdCb.aspIdLst[pspId];
                        aspIdPres = TRUE;
                     }
                     if (itGlobalCb.assoc[i] != (ItAssocCb *)NULLP)
                     {
                        (Void) itMmhNotify(itGlobalCb.assoc[i],
                                        (Txt *)NULLP, 
                                        &locRtCtx, 1, 
                                        IT_M3UA_NTFY_TYPE_OTHER,
                                        aspIdPres, aspId);
                     }
                  } /* end: if ((psCb->psSta.aspSt[i] != LIT_ASP_DOWN) &&*/
               }
            }
#ifdef LIT_RTE_ALARMS
            /* send alarm on ASP, if DPC state changes for SGP
             * SGP may also reach here. It shouldn't generate alarm
             */
            if ((psCb->psSta.psStaEndp[suId].aspSt[pspId] == LIT_ASP_ACTIVE) &&
                (pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP) && (dpcCb != NULLP) 
                && 
                (dpcCb->pspDpcSt[assocId] == IT_DPC_AVAILABLE) &&
                (dpcCb->dpcSt == IT_DPC_AVAILABLE))
            {
              IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt));
              itGlobalCb.mgmt.hdr.elmId.elmnt         = STITPSP;
              itGlobalCb.mgmt.hdr.msgType             = TUSTA;
              itGlobalCb.mgmt.t.usta.alarm.category   = LIT_CATEGORY_STATUS;
              itGlobalCb.mgmt.t.usta.alarm.event      = LIT_EVENT_RTE_UNAVAIL;
              itGlobalCb.mgmt.t.usta.alarm.cause      = LIT_CAUSE_ASPDOWN;
              itGlobalCb.mgmt.t.usta.s.pspId           = pspId;
              itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc     = psCb->spmc->dpc;

              (Void) itMiStaIndM(&itGlobalCb.mgmt);
            }
#endif /* LIT_RTE_ALARMS */
            psCb->psSta.psStaEndp[suId].aspSt[pspId] = LIT_ASP_DOWN;
            break;
         }
         case IT_EVT_ASP_DN_ACK:
#ifdef LIT_RTE_ALARMS
            /* send alarm on ASP, if DPC state changes for SGP */
            if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP) && 
                (psCb->psSta.psStaEndp[suId].aspSt[pspId] == LIT_ASP_ACTIVE) && 
                (dpcCb != NULLP) && 
                (dpcCb->dpcSt == IT_DPC_AVAILABLE) &&
                (dpcCb->pspDpcSt[assocId] == IT_DPC_AVAILABLE))
            {
              IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt));
              itGlobalCb.mgmt.hdr.elmId.elmnt       = STITPSP;
              itGlobalCb.mgmt.hdr.msgType           = TUSTA;
              itGlobalCb.mgmt.t.usta.alarm.category = LIT_CATEGORY_STATUS;
              itGlobalCb.mgmt.t.usta.alarm.event    = LIT_EVENT_RTE_UNAVAIL;
              itGlobalCb.mgmt.t.usta.alarm.cause    = LIT_CAUSE_RCV_ASPDOWNACK;
              itGlobalCb.mgmt.t.usta.s.pspId        = pspId;
              itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc   = psCb->spmc->dpc;

              (Void) itMiStaIndM(&itGlobalCb.mgmt);
            }
#endif /* LIT_RTE_ALARMS */
            psCb->psSta.psStaEndp[suId].aspSt[pspId] = LIT_ASP_DOWN;
            break;
         case IT_EVT_ASP_AC:
            if ((psCb->psSta.psStaEndp[suId].aspSt[pspId] == LIT_ASP_INACTIVE)
                ||
                (psCb->psSta.psStaEndp[suId].aspSt[pspId] == LIT_ASP_ACTIVE)) 
            {
               rCtx->thmType = type;
               switch (type)
               {
                  case LIT_ASP_TMTYPE_OVERRIDE:
                  {
                        /* At SGP and IPSP (DE) only Remote PS's NTFY will be
                         * sent, at IPSP SE, the local PS's NTFY will be sent */
                     Bool ntfySnd;
                     U32  aspId;     /* ASP Id */
                     Bool aspIdPres; /* ASP Id Present Flag */
                             
                     aspId = NULLD;
                     ntfySnd = FALSE;
                     if (psCb->psCfg.lclFlag != TRUE)
                     {
                        if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_ASP) || 
                            (pspCb->pspCfg.pspType == LIT_PSPTYPE_LOCAL) || 
                             ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
                             (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_DE)))
                        {
                           ntfySnd = TRUE;
                        }
                     }
                     else
                     {
                        /* For Local PS */
                        if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
                            (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_SE))
                        {
                           ntfySnd = TRUE;
                        }
                     }
                     /* De-activate any currently active PSPs */
                     /* Remote ASPs/IPSPs are marked in-active only from the SEP
                        on which original message is received */
                     for (j = 0; j < psCb->psSta.psStaEndp[suId].nmbAct; j++)
                     {
                        UConnId tmpAssocId;  /* Temp Assoc Id */
                        ItPspId tmpPspId;    /* Temp PSP Id */
                        /* "j" is assocId for the "suId" endpoint */
                        ItRtCtx locRtCtx; /* Temp storage for Routing Context */
                        ItAssocCb *curAssocCb; /* Assoc Control Block */

                        if ((psCb->psSta.psStaEndp[suId].actPsp[j]) != 
                                                        IT_ASSOC2PSPID(assocId))
                        {
                           tmpPspId = psCb->psSta.psStaEndp[suId].actPsp[j];
                           tmpAssocId   = IT_PSPnENDP2ASSOC(tmpPspId, suId);
                           
                           psCb->psSta.psStaEndp[suId].aspSt[tmpPspId] 
                                                             = LIT_ASP_INACTIVE;
#ifdef ZV
                           /* it018.106 - addition - updating table type 
                              ZV_PSP_ACTPS */
                           updArgs.p.psEndpUpd.endp = suId;
                           updArgs.p.psEndpUpd.slno = tmpPspId;
                           zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PS_ENDP_PSPSTA,
                                   CMPFTHA_UPDTYPE_SYNC, (Void *) psCb, 
                                   &updArgs);
#endif
                           curAssocCb = itGlobalCb.assoc[tmpAssocId];
                           if (ntfySnd == TRUE)
                           {
                              rCtx->ntfyStaId = IT_M3UA_NTFY_INFO_ALT_ASPACT;
                              /* Notify the peer */
                              if (psCb->psSta.psStaEndp[suId].rteCtx[tmpPspId].\
                                                 rcValid != TRUE)
                              {
                                 continue;
                              }
                              cmMemcpy((U8 *)&locRtCtx, (U8 *)(rCtx), 
                                        sizeof(ItRtCtx));
                              locRtCtx.rtCtx = psCb->psSta.psStaEndp[suId].\
                                                   rteCtx[tmpPspId].rCtx;

                              aspIdPres = FALSE;
                              /* it016.106 - Changes to make storing of ASPID 
                               * optional when rxTxAspId is FALSE. So, even if 
                               * rxTxAspId is FALSE send ASPID, if available. */
                              if (itGlobalCb.aspIdCb.aspIdValid[pspId] == TRUE)
                              {
                                 aspId = itGlobalCb.aspIdCb.aspIdLst[pspId];
                                 aspIdPres = TRUE;
                              }
                              /* Notify is sent to only those remote ASPs/IPSPs 
                                 which has association from the SEP on which
                                 original message is received */
                              (Void) itMmhNotify(curAssocCb,
                                                "Override ASP", &locRtCtx, 1, 
                                                IT_M3UA_NTFY_TYPE_OTHER,
                                                aspIdPres, aspId);
                           } /* End of IF: ntfySnd == TRUE */
                        }
                     } /* end of for on psCb->psSta.psStaEndp[suId].nmbAct; */
                     psCb->psSta.psStaEndp[suId].aspSt[pspId] = LIT_ASP_ACTIVE;
                  }
                     break;
                  case LIT_ASP_TMTYPE_LOADSHARE:
                     psCb->psSta.psStaEndp[suId].aspSt[pspId] = LIT_ASP_ACTIVE;
                     break;
                  default:
                     RETVALUE(RFAILED);
               }
            }
            break;
   
         case IT_EVT_ASP_AC_ACK:
#ifdef LIT_RTE_ALARMS
            /* send alarm on ASP, if DPC state changes for SGP */
            if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP) &&
                (psCb->psSta.psStaEndp[suId].aspSt[pspId] == LIT_ASP_INACTIVE)
                && (dpcCb != NULLP) &&
                (dpcCb->pspDpcSt[assocId] == IT_DPC_AVAILABLE))
            {
              IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt));
              itGlobalCb.mgmt.hdr.elmId.elmnt       = STITPSP;
              itGlobalCb.mgmt.hdr.msgType           = TUSTA;
              itGlobalCb.mgmt.t.usta.alarm.category = LIT_CATEGORY_STATUS;
              itGlobalCb.mgmt.t.usta.alarm.event    = LIT_EVENT_RTE_AVAIL;
              itGlobalCb.mgmt.t.usta.alarm.cause    = LIT_CAUSE_RCV_ASPACTVACK;
              itGlobalCb.mgmt.t.usta.s.pspId        = pspId; 
              itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc = psCb->spmc->dpc;

              (Void) itMiStaIndM(&itGlobalCb.mgmt);
            } 
#endif /* LIT_RTE_ALARMS */
            if (psCb->psSta.psStaEndp[suId].aspSt[pspId] == LIT_ASP_INACTIVE)
            {
               switch (type)
               {
                  /* following 2 cases fall through */
                  case LIT_ASP_TMTYPE_OVERRIDE:
                  case LIT_ASP_TMTYPE_LOADSHARE:
                     psCb->psSta.psStaEndp[suId].aspSt[pspId] = LIT_ASP_ACTIVE;
                     break;
                  default:
                     RETVALUE(RFAILED);
               }
            }
            break;
   
         /* following 2 cases fall through */
         case IT_EVT_ASP_IA:
         case IT_EVT_ASP_IA_ACK:
            if (psCb->psSta.psStaEndp[suId].aspSt[pspId] == LIT_ASP_ACTIVE)
            {
#ifdef LIT_RTE_ALARMS
               /* send alarm on ASP, if DPC state changes for SGP */
               if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP) && 
                   (dpcCb != NULLP) && 
                   (dpcCb->dpcSt == IT_DPC_AVAILABLE) &&
                   (dpcCb->pspDpcSt[assocId] == IT_DPC_AVAILABLE))
               {
                 IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt));
                 itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP;
                 itGlobalCb.mgmt.hdr.msgType            = TUSTA;
                 itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS;
                 itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_RTE_UNAVAIL;
                 itGlobalCb.mgmt.t.usta.alarm.cause = 
                                                     LIT_CAUSE_RCV_ASPINACTVACK;
                 itGlobalCb.mgmt.t.usta.s.psId             = pspId;
                 itGlobalCb.mgmt.t.usta.t.dpcEvt.aPc       = psCb->spmc->dpc;

                 (Void) itMiStaIndM(&itGlobalCb.mgmt);
               }
#endif /* LIT_RTE_ALARMS */
               psCb->psSta.psStaEndp[suId].aspSt[pspId] = LIT_ASP_INACTIVE;
            }
            break;
   
         default:
            /* do nothing - event is unrelated to aspSt */
            break;
      }

#ifdef ZV
      /* it018.106 - addition - updating table type ZV_PSP_ACTPS */
      updArgs.p.psEndpUpd.endp = suId;
      updArgs.p.psEndpUpd.slno = pspId;
      zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PS_ENDP_PSPSTA,
              CMPFTHA_UPDTYPE_SYNC, (Void *) psCb, &updArgs);
#endif
   
      if (psCb->psSta.psStaEndp[suId].aspSt[pspId] != oldAspSt)
      {
         switch (psCb->psSta.psStaEndp[suId].aspSt[pspId])
         {
            case LIT_ASP_DOWN:
               lmEvent     = LIT_EVENT_ASP_DOWN;
               aspEvent    = TRUE;
               break;
            case LIT_ASP_INACTIVE:
               if (oldAspSt == LIT_ASP_ACTIVE) 
               {
                  lmEvent     = LIT_EVENT_ASP_INACTIVE;
                  aspEvent    = TRUE;
               }
               break;
            case LIT_ASP_ACTIVE:
               lmEvent     = LIT_EVENT_ASP_ACTIVE;
               aspEvent    = TRUE;
               break;
            default:
               break;
         }
      }
      if (aspEvent == TRUE)
      {
         itGlobalCb.mgmt.hdr.elmId.elmnt           = STITPS;
         itGlobalCb.mgmt.hdr.msgType               = TUSTA;
         itGlobalCb.mgmt.t.usta.alarm.category     = LIT_CATEGORY_STATUS;
         itGlobalCb.mgmt.t.usta.alarm.cause        = LIT_CAUSE_STATUS_CHANGE;
         itGlobalCb.mgmt.t.usta.alarm.event        = lmEvent;
         itGlobalCb.mgmt.t.usta.s.psId             = psCb->psCfg.psId;
         itGlobalCb.mgmt.t.usta.t.psAspEvt.pspId   = pspId;
         itGlobalCb.mgmt.t.usta.t.psAspEvt.sctSuId = suId;
         (Void) itMiStaIndM(&itGlobalCb.mgmt);
      }
   } /* end if event != IT_EVT_RECONFIG */
   
   /* recalculate active and inactive lists */
   nmbUp   = 0;
   nmbAct  = 0;
   /* initialize the psCb->psSta.nmbAct for all EPs and actAspCntPerSuId */
   for (i = 0; i < LIT_MAX_SEP; i++)
   {
      psCb->psSta.psStaEndp[i].nmbAct = 0;
      actAspCntPerSuId[i] = 0;
   }

   /* Get the number of ASPs which are active */

   for (i = 0; i < LIT_MAX_SEP; i++)
   {
      for (k = 0; k < LIT_MAX_PSP; k++)
      {
         if (psCb->psSta.psStaEndp[i].aspSt[k] == LIT_ASP_ACTIVE)
         {
            psCb->psSta.psStaEndp[i].actPsp[psCb->psSta.psStaEndp[i].nmbAct]
                     = (ItPspId)(k);
            psCb->psSta.psStaEndp[i].nmbAct++;
            nmbUp++;
            nmbAct++;
            actAspCntPerSuId[i]++;
         }
         else if (psCb->psSta.psStaEndp[i].aspSt[k] == LIT_ASP_INACTIVE)
         {
            nmbUp++;
         }
      }
   }

   /* Get the highest value of actAspCntPerSuId array */
   actAspCnt = 0;
   for (i = 0; i < LIT_MAX_SEP; i++)
   {
      if (actAspCnt < actAspCntPerSuId[i])
      {
         actAspCnt = actAspCntPerSuId[i];
      }
   } 

   /* actAspCnt is the highest number of active assocs from any SEP */
   /* nmbAct is the total number of active assocs for this PS from all SEPs */

   /* The logic used for making a loadsharing AS as active is explained 
      below with an example */
   /* Scenario is : at SG two End Pnts (EP-1 and EP-2) 
      are supported  and total number of remote ASPs is 3, 
      also at SG, AS is configured with
      minimum number of required ASP value as 2 (for it be marked as ACTIVE) 
      Following possibilities cover the behavior:
 case a) The ASP-1 and ASP-2 are active for EP-1 and EP-2 respectively.
 case b) The ASP-1 and ASP-2 are active for EP-1 only.
 case c) The ASP-1 and ASP-2 are active for EP-1 only  and ASP-3 is active
         for EP-2 only.
 case d) The ASP-1 and ASP-2 are active for EP-1 only  and ASP-3 is active
         for both EP-1 and EP-2.
 case e) The ASP-1 is active for EP-1 only, the ASP-2 is active for EP-1 as well
         as for EP-2 and ASP-3 is active for EP-2 only.

      The AS will be marked active in : b), c), d) and e) cases. 
      AS state will not be kept per SEP it will be kept SG wide.
      In case of c), d) and e) the outgoing traffic from SG will be routed to
      all the three active ASPs independent of AS state from the SEP.
   */

   /* Logic used for making OVERRIDE AS as active is explained below */
   /* Scenario is same as described above for loadsharing AS example,
      There will be only one ACTIVE AS from each SEP.
      following possibilities cover possible scenarios:
 case a) The ASP-1 is active for EP-1. 
 case b) The ASP-1 is active for both EP-1 and EP-2
 case c) The ASP-1 is active for EP-1 and ASP-2 is active for EP-2.
 case d) The state is at case (c) and ASP-3 sends ACTIVE to EP-1, The SG will
         mark ASP-3 active for EP-1, marks ASP-1 as inactive for EP-1 and will
         send NTFY (ALT-ASP-ACT) to ASP-1 from EP-1,
         and the state will become:
         ASP-3 is active for EP-1 and ASP-2 is active for EP-2.
 case e) Now, ASP-3 sends active for EP-2, SG marks ASP-3 active for EP-3 and
         sends NTFY (ALT-ASP-ACT) to ASP-2 from EP-2, the state will now be:
         ASP-3 is active for EP-1 as well as for EP-2.  

      The AS will be marked active if any one of the ASP is active (irrespective
      of, for which SEP the ASP is active).
      If more than one ASP is active for an AS (case c and d) or a single 
      ASP is active for more than one SG's End Point then the outgoing 
      Data from SG will be loadshared on all the active associations towards 
      ASPs 
   */

   /* AS state machine */
   oldAsSt = psCb->psSta.asSt;
   switch (psCb->psSta.asSt)
   {
      case LIT_AS_DOWN:
         /* this fix is given to fix the problem
            of a dpc staying unavailable even if it was added
            to an active SGP */ 
      
            
         /* it009.106 - If peer is SGP/IPSP-SE, reconfig event of PS will 
          * result Remote PS directly going Active from Down state as the 
          * peer SGP/IPSP-SE may already be active and we do not expect any 
          * active messages for Remote PS in case of SGP/IPSP-SE. */
         if ((event == IT_EVT_RECONFIG) &&
             (psCb->psCfg.lclFlag != TRUE) &&
             (actAspCnt >= psCb->psCfg.nmbActPspReqd) &&
             (itGlobalCb.psp[psCb->psCfg.psp[0]] != NULL) &&  
             ((itGlobalCb.psp[psCb->psCfg.psp[0]]->pspCfg.pspType == 
                                           LIT_PSPTYPE_SGP) ||
              ((itGlobalCb.psp[psCb->psCfg.psp[0]]->pspCfg.pspType == 
                                                     LIT_PSPTYPE_IPSP) &&
               (itGlobalCb.psp[psCb->psCfg.psp[0]]->pspCfg.ipspMode == 
                                                     LIT_IPSPMODE_SE)))) 
         {
            psCb->psSta.asSt = LIT_AS_ACTIVE;
         }
         else if (nmbUp > 0)
         {
            psCb->psSta.asSt = LIT_AS_INACTIVE;
         }
         break;
      case LIT_AS_INACTIVE:
         if (nmbUp == 0)
         {
            psCb->psSta.asSt = LIT_AS_DOWN;
         }
         /* If PS is configured in :
            A) Loadshare mode : The actAspCnt represents the highest number of
            ASPs active for any SEP, hence following check is ok.
            B) ActStandBy mode : nmbActPspReqd is configured as 1, hence 
            following check works fine for this mode as well */ 
         else if (actAspCnt >= psCb->psCfg.nmbActPspReqd)
         {
            psCb->psSta.asSt = LIT_AS_ACTIVE;
         }
         break;
      case LIT_AS_ACTIVE:
         /* psCb->psSta.nmbAct is to be checked against 1  as AS will be
            entered into PENDING state if there is no way to route traffic to
            remote node  */
         if (nmbAct < 1)
         {
            if (psCb->psCfg.lclFlag != TRUE)
            {
               /* At SGP and IPSP(DE) Remote PS may enter into Pending state */
               if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_ASP) ||
                   ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) &&
                   (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_DE)))
               {
                  psCb->psSta.asSt = LIT_AS_PENDING;
                  /* Start recovery timer */
                  itTcStartTimer(&psCb->tmrPend, (PTR)psCb, IT_TMR_AS_PENDING,
                              &itGlobalCb.genCfg.tmr.tmrAsPend);
               }
               /* At IPSP (SE), remote PS shall enter directly into INACTIVE 
                * state */
               if (((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) &&
                    (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_SE)) ||
                    (pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP))
               {
                  psCb->psSta.asSt = LIT_AS_INACTIVE;
                  if (nmbUp == 0)
                  {
                     psCb->psSta.asSt = LIT_AS_DOWN;
                  }
               }
            }
            else
            {
               /* At IPSP (SE), local PS can enter into Pending state */
               if ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) &&
                   (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_SE))
               {
                  if ((event != IT_EVT_ASP_IA_ACK) && 
                                  (event != IT_EVT_ASP_DN_ACK))
                  {
                     psCb->psSta.asSt = LIT_AS_PENDING;
                     /* Start recovery timer */
                     itTcStartTimer(&psCb->tmrPend, (PTR)psCb,IT_TMR_AS_PENDING,
                              &itGlobalCb.genCfg.tmr.tmrAsPend);
                  }
                  else /* on ACK into INACTIVE state */
                  {
                     psCb->psSta.asSt = LIT_AS_INACTIVE;
                     if (nmbUp == 0)
                     {
                         psCb->psSta.asSt = LIT_AS_DOWN;
                     }
                  }
               }
               else /* at ASP */
               {
                  /* For local PS, AS-PENDING state does not make much sense */
                  psCb->psSta.asSt = LIT_AS_INACTIVE;
                  if (nmbUp == 0)
                  {
                     psCb->psSta.asSt = LIT_AS_DOWN;
                  }
               }
            }
         }
         break;
      case LIT_AS_PENDING:
         if (actAspCnt >= psCb->psCfg.nmbActPspReqd)
         {
            psCb->psSta.asSt = LIT_AS_ACTIVE;
            /* stop recovery timer */
            itTcStopTimer(&psCb->tmrPend);
         }
         else if (event == IT_EVT_AS_PEND_TIMEOUT)
         {
            if (nmbUp > 0)
            {
               psCb->psSta.asSt = LIT_AS_INACTIVE;
            }
            else
            {
               psCb->psSta.asSt = LIT_AS_DOWN;
            }
         }
         break;
      default:
         break;
   }

   /* Send NOTIFY(ASCHG) message if required */
   if (psCb->psSta.asSt != oldAsSt)
   {
      U16 ntfyStaId;          /* notify status ID */
      U8 mifEvent;            /* management event */
      ntfyStaId   = 0;
      mifEvent    = IT_MIF_NONE;
      rCtx->ntfySend = FALSE;
      switch (psCb->psSta.asSt)
      {
         case LIT_AS_DOWN:
            lmEvent         = LIT_EVENT_AS_DOWN;
            mifEvent        = IT_MIF_AS_DOWN;
            break;
         case LIT_AS_INACTIVE:
            lmEvent         = LIT_EVENT_AS_INACTIVE;
            mifEvent        = IT_MIF_AS_INACTIVE;
            rCtx->ntfySend  = TRUE;
            rCtx->ntfyStaId = IT_M3UA_NTFY_INFO_AS_INACTIVE;
            break;
         case LIT_AS_ACTIVE:
            lmEvent         = LIT_EVENT_AS_ACTIVE;
            mifEvent        = IT_MIF_AS_ACTIVE;
            rCtx->ntfySend  = TRUE;
            rCtx->ntfyStaId = IT_M3UA_NTFY_INFO_AS_ACTIVE;
            break;
         case LIT_AS_PENDING:
            lmEvent         = LIT_EVENT_AS_PENDING;
            rCtx->ntfySend  = TRUE;
            rCtx->ntfyStaId = IT_M3UA_NTFY_INFO_AS_PENDING;
            break;
         default:
            break;
      }
      /* Send status indication to notify LM of PS state change */
      itMiStaInd(STITPS, LIT_CATEGORY_STATUS, lmEvent,
                 LIT_CAUSE_STATUS_CHANGE, (U32)psCb->psCfg.psId);

      /* it023.106 - Update PS "unav" statistics. */
#ifdef LITV6
      if (((psCb->psSta.asSt == LIT_AS_DOWN) ||
           (psCb->psSta.asSt == LIT_AS_INACTIVE)) &&
          ((oldAsSt == LIT_AS_ACTIVE) ||
           (oldAsSt == LIT_AS_PENDING)))
      {
         /* PS unavailable update unavailablity counter. */
         IT_STS_INC_PS_UNAV(psCb);
   
         /* Take time stamp when PS became unavailable. */
         SGetSysTime(&psCb->ticksUnav);
      }
      else if ((psCb->psSta.asSt == LIT_AS_ACTIVE) &&
               ((oldAsSt == LIT_AS_INACTIVE) ||
                (oldAsSt == LIT_AS_DOWN)))
      {
         if (psCb->ticksUnav)
         {
            S16         ret;      /* return value */
            Ticks       curTime;  /* current timestamp */
            Ticks       dur;      /* time duration */

            ret = SGetSysTime(&curTime);
            if (ret != ROK)
            {
#if (ERRCLASS & ERRCLS_DEBUG)
               ITLOGERROR(ERRCLS_DEBUG, EITXXX, (ErrVal) ret, 
                          "itPsmPsEvt: SGetSysTime failed");
#endif /* ERRCLS_DEBUG */
            }
            else
            {
               dur = curTime - psCb->ticksUnav;
               IT_STS_UPD_PS_DUR_UNAV(psCb, dur);
            }
            psCb->ticksUnav = 0;
         }
      }
#endif /* LITV6 */

      /* condition of non execution in AS DOWN state removed
         as the same function was also being called in this state , but
         in the switch statement above  */
      /* Management interworking */
      if (mifEvent != IT_MIF_NONE)
      {
         (Void) itMifPsEvt(assocId, mifEvent, (Dpc)0, psCb);
      }
   }

   /* Update list of active PSs for all affected assocs */
   for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)
   {
      ItAssocCb   *tmpAssocCb; /* temp assocCb */
      tmpAssocCb  = itGlobalCb.assoc[i];
      matchFlag   = FALSE;
      updateFlag = FALSE;
      if (tmpAssocCb != (ItAssocCb *) NULLP)
      {
         for (j = 0; j < tmpAssocCb->assocSta->nmbAct; j++)
         {
            if (tmpAssocCb->assocSta->actPs[j] == psCb->psCfg.psId)
            {
               matchFlag   = TRUE;
               entPos      = j;
               break;
            }
         }
   
         if ((psCb->psSta.asSt == LIT_AS_ACTIVE) && 
             (psCb->psSta.psStaEndp[IT_ASSOC2SUID(i)].aspSt[IT_ASSOC2PSPID(i)] 
                                                             == LIT_ASP_ACTIVE))
         {
            /* should be in active list for this PSP ... */
            if (matchFlag == FALSE)
            {
               /* ... but isn't, so add it */
               tmpAssocCb->assocSta->actPs[tmpAssocCb->assocSta->nmbAct] = 
                                                              psCb->psCfg.psId;

#ifdef ZV
               /* it018.106 - addition - updating table type ZV_PSP_ACTPS */
               updArgs.p.pspPsUpd.pspIdx = IT_ASSOC2PSPID(i);
               updArgs.p.pspPsUpd.endp = IT_ASSOC2SUID(i);
               updArgs.p.pspPsUpd.slNo = tmpAssocCb->assocSta->nmbAct;
               zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSP_ACTPS,
                       CMPFTHA_UPDTYPE_SYNC, (Void *) NULLP, &updArgs);
#endif
               
               tmpAssocCb->assocSta->nmbAct++;
               /* it018.106 - addition - DFTHA Enhancement. Updated only 
                  when require*/
               updateFlag = TRUE;
               /* 
                * Inform MIF that PSP active list has changed - may need to 
                * download status information 
                */
               itMifPspEvt(IT_MIF_ASP_ACTIVE, psCb->nwk->nwkCfg.nwkId, (Dpc) 0, 
                           0, (SrvInfo) 0, tmpAssocCb, (ItDpcCb *)NULLP);
            }
         }
         else 
         {
            /* shouldn't be in active list for this PSP ... */
            if (matchFlag == TRUE)
            {
               /* ... but is, so remove it */
               for (j = entPos; (S32)j < (tmpAssocCb->assocSta->nmbAct - 1); 
                    j++)
               {
                  tmpAssocCb->assocSta->actPs[j] =
                                              tmpAssocCb->assocSta->actPs[j+1];
#ifdef ZV
                  /* it018.106 - addition - updating table type  ZV_PSP_ACTPS */
                  updArgs.p.pspPsUpd.pspIdx = IT_ASSOC2PSPID(i);
                  updArgs.p.pspPsUpd.endp = IT_ASSOC2SUID(i);
                  updArgs.p.pspPsUpd.slNo = j;
                  zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSP_ACTPS,
                          CMPFTHA_UPDTYPE_SYNC, (Void *) NULLP, &updArgs);
#endif
               }
               tmpAssocCb->assocSta->nmbAct--;
               /* it018.106 - addition - DFTHA Enhancement. Updated only 
                  when require*/
               updateFlag = TRUE;
               itMifPspEvt(IT_MIF_ASP_INACTIVE, psCb->nwk->nwkCfg.nwkId, 
                           (Dpc) 0, 0, (SrvInfo) 0, tmpAssocCb, (ItDpcCb *)NULLP);
            }
         }
         /* Calculate overall ASP state of association */
         switch (tmpAssocCb->assocSta->aspSt)
         {
            case LIT_ASP_INACTIVE:
               if (tmpAssocCb->assocSta->nmbAct > 0)
               {
                  /* it018.106 - addition - DFTHA Enhancement. Updated only 
                     when require*/
                  updateFlag = TRUE;
                  tmpAssocCb->assocSta->aspSt = LIT_ASP_ACTIVE;
               }
               break;

            case LIT_ASP_ACTIVE:
               if (tmpAssocCb->assocSta->nmbAct == 0)
               {
                  /* it018.106 - addition - DFTHA Enhancement. Updated only 
                     when require*/
                  updateFlag = TRUE;
                  tmpAssocCb->assocSta->aspSt = LIT_ASP_INACTIVE;
               }
               break;
            default:
               break;
         }
#ifdef ZV
         /* it018.106 - addition - DFTHA Enhancement. Updated only 
            when require*/
         if ((pspId != IT_LOCAL_PSPID) && (updateFlag == TRUE))  
        {
            /* Sync the state change of assocCb->assocSta */
            /* it018.106 - modification - Bug Fix - we need to change tmpAssoc
               instead of assocCb*/
            zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSPCB,
                    CMPFTHA_UPDTYPE_SYNC, (Void *) tmpAssocCb->owner, NULLP);
         }
#endif
      } /* end if ASSOCCB != NULLP */
   } /* end for */


#ifdef ZV
   /* it018.106 - addition - DFTHA Enhancement. Update assocCb owner */
   if (pspId != IT_LOCAL_PSPID)  
   {
      /* Sync the state change of assocCb->assocSta */
      /* it018.106 - modification - Bug Fix - we need to change tmpAssoc
         instead of assocCb*/
      zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSPCB,
              CMPFTHA_UPDTYPE_SYNC, (Void *) assocCb->owner, NULLP);
   }
#endif


   /* - Separated the updation of Loadshare map when
    * OG_RTE_ON_LPS_STA is defined for ASP/IPSP.
    * If OG_RTE_ON_LPS_STA is defined at ASP/IPSP Child PS CBs have to be
    * updated. Else Loadshare CB present in PS CB will be updated. */
#if !(defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   /* For Loadshare on SLS, if event is Reconfiguration or a PSP state has
    * changed to Active or from Active to Inactive/Down, 
    * then redistribute SLS */
   /* At SG: If PS mode is not loadshare (i.e., override mode) and more
    * than one assoc is active for a PS then also load is distributed across
    * active assocs based on SLS */
   if ((psCb->psCfg.lclFlag == FALSE) && 
        (((psCb->psCfg.mode == LIT_MODE_LOADSHARE) &&
        (psCb->psCfg.loadShareMode == LIT_LOADSH_SLS))
      /* nmbAct check not required as routing will always use sls map for 
         actstandby PS */
      || ((psCb->psCfg.mode == LIT_MODE_ACTSTANDBY))))
   {
      /* - Added a new parameter of pointer to Loadshare CB
       * and changed the pointer to PS CB as local PS CB pointer */
      itLscSlsUpdLst(&psCb->lsCb->sls, NULLP, oldAsSt);
   }
#else /* ITASP && OG_RTE_ON_LPS_STA */
   /* At ASP: If PS mode is not loadshare (i.e., override mode) and more
    * than one assoc is active for a PS then also load is distributed across
    * active assocs based on SLS */
   /* for both loadshare and actstndby lsc is to be Upded  */
   if (psCb->psCfg.lclFlag == FALSE)
   {
      itLscUpd(psCb, assocId, event, oldAsSt);
   }
#endif /* ITASP && OG_RTE_ON_LPS_STA */

#ifdef ZV

   zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSCB,
           CMPFTHA_UPDTYPE_SYNC, (Void *) psCb, NULLP);

   /* it018.106 - addition - DFTHA Enhancement. Update ZV_PS_ENDP_ACTPSP 
      table */
   zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PS_ENDP_ACTPSP,
           CMPFTHA_UPDTYPE_SYNC, (Void *) psCb, NULLP);

#endif
    /* Send update for AS PS-pending state before ACK is sent to peer */
    if (psCb->psSta.asSt == LIT_AS_PENDING) 
    {
       ITZVUPDPEER()

       /* An update to the peer was generated. The counter *
        * is incremented again since the loop has to move  *
        * onto the next SAP and generate updates for it    */
       ITADDZVUPDPEERCTR()
    }
   if ((psCb->psSta.asSt != oldAsSt) && (oldAsSt == LIT_AS_PENDING))
   {
      while (cmLListLen(&psCb->msgQ) > 0)
      {
         /* remove message from head of list */
         msg = (ItMupMsg *) cmLListDelFrm(&psCb->msgQ,
                            cmLListFirst(&psCb->msgQ));
         if (psCb->psSta.asSt == LIT_AS_ACTIVE)
         {
            /* AS is active - resend the messages */
            msg->msgState = IT_MSG_ROUTED_ONE;
            if (itMupData(msg) != ROK)
            {
               IT_DROPDATA(msg->mBuf);
               IT_FREE(sizeof(ItMupMsg), msg);
               itGlobalCb.nmbMsg--;
            }
         }
         else
         {
            /* AS is not active - drop the messages */
            IT_STS_INC_DATERR(msg, dropPcUnavail)
            IT_DROPDATA(msg->mBuf);
            IT_FREE(sizeof(ItMupMsg), msg);
            itGlobalCb.nmbMsg--;
         }
      }
   }

   RETVALUE(ROK);
} /* end of itPsmPsEvt */

/*
*
*       Fun:   itPsmPsPendTimeout
*
*       Desc:  Called on expiry of AS-PENDING timer for a specified PS.
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmPsPendTimeout
(
ItPsCb        *psCb           /* PS control block */
)
#else
PUBLIC S16 itPsmPsPendTimeout(psCb)
ItPsCb        *psCb;          /* PS control block */
#endif
{
   ItRtCtx  locRtCtx;   /* Local route context */
   U16      i;          /* Loop index */
   U16      j;          /* Loop index */

   TRC2(itPsmPsPendTimeout)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
            "itPsmPsPendTimeout(psCb)\n"));

   locRtCtx.rtCtx = psCb->psCfg.psId;

   (Void) itPsmPsEvt(&locRtCtx, 0, IT_EVT_AS_PEND_TIMEOUT, 0);

   if ((psCb->psSta.asSt != LIT_AS_DOWN) && (locRtCtx.ntfySend == TRUE))
   {
      /* notify client PSPs */
      /* Since NTFY (Pending) is sent to all remote assocs (ASP) hence
         new AS is state is also sent to all remote assocs */
      for (i = 0; i < LIT_MAX_SEP; i++)
      {
         for (j = 0; j < LIT_MAX_PSP; j++)
         {
            UConnId assocId;
            assocId = IT_PSPnENDP2ASSOC(j, i);
            
            if ((psCb->psSta.psStaEndp[i].aspSt[j] != LIT_ASP_DOWN) &&
                (psCb->psSta.psStaEndp[i].aspSt[j] != LIT_ASP_UNSUPP) &&
                ((itGlobalCb.assoc[assocId]->owner->pspCfg.pspType == 
                                                      LIT_PSPTYPE_ASP) ||
                 (itGlobalCb.assoc[assocId]->owner->pspCfg.pspType ==
                                                      LIT_PSPTYPE_IPSP)) &&
                 (psCb->psSta.psStaEndp[i].rteCtx[j].rcValid == TRUE))
            {
               /* map psId in locRtCtx to routing Context */
               locRtCtx.rtCtx = psCb->psSta.psStaEndp[i].rteCtx[j].rCtx;
               (Void) itMmhNotify(itGlobalCb.assoc[assocId], 
                                  (Txt *)NULLP, &locRtCtx, 1, 
                                  IT_M3UA_NTFY_TYPE_ASCHG, FALSE, IT_M3UA_DFLT);
            } /* end if ((psCb->psSta.aspSt[i] != LIT_ASP_DOWN) &&*/
         } /* end of for (j = 0; j < LIT_MAX_PSP; j++) */
      } /* end of   for (i = 0; i < LIT_MAX_SEP; i++) */
   } /* end if (psCb->psSta.asSt != LIT_AS_DOWN)*/

   RETVALUE(ROK);
} /* end of itPsmPsPendTimeout */


/*
*
*       Fun:   itPsmHBeatTimeout
*
*       Desc:  Called by TC when the RX heartbeat timer expires
*
*       Ret:   Failure:
*
*              Success:
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmHBeatTimeout
(
ItAssocCb       *assocCb          /* assoc control block */
)
#else
PUBLIC S16 itPsmHBeatTimeout (assocCb)
ItAssocCb       *assocCb;         /* assoc control block */
#endif
{

   TRC2(itPsmHBeatTimeout)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itPsmHBeatTimeout(assocCb)\n"));

   if (assocCb->assocSta->hlSt != LIT_ASSOC_DOWN)
   {
      assocCb->sctSap->sctSta.nmbActAssoc--;
      /*chenning �޸�������ｫ״̬��ΪDOWN��*/
      /*����ĺ����Ͳ����йر�ż��2006 9 8*/
      assocCb->assocSta->hlSt = LIT_ASSOC_DOWN;
      assocCb->assocSta->spAssocId = (UConnId)NULLD;
#ifdef ZV
      /* Update assoc state */
      zvRTUpd(CMPFTHA_ACTN_MOD, ZV_ASSOCCB,
                            CMPFTHA_UPDTYPE_SYNC, (Void *) assocCb, NULLP);
      /* Update sctSap->sctSta.nmActassoc */
      zvRTUpd(CMPFTHA_ACTN_MOD, ZV_SCTSAPCB,
                            CMPFTHA_UPDTYPE_SYNC, (Void *) assocCb->sctSap, 
                            NULLP);
#endif
      /* it016.106 - Update "unav" statistics. */
#ifdef LITV3
      /* Association unavailable update unavailablity counter. */
      IT_STS_INC_ASSOC_UNAV(assocCb);

      /* Take time stamp when association became unavailable. */
      SGetSysTime(&assocCb->ticksUnav);
#endif /* LITV3 */
   }
   if (assocCb->assocSta->aspSt != LIT_ASP_DOWN)
   {
      itTcStopTimer(&assocCb->tmrHBeatTX);
   }

   (Void) itAcAssocEvt(assocCb, LIT_EVENT_HBEAT_LOST);

   RETVALUE(ROK);
} /* end of itPsmHBeatTimeout */


/*
*
*       Fun:   itPsmTxHBeatTimeout
*
*       Desc:  Restart the heartbeat timer in the ACB and call itMmhHBeat.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: Called by TC when the TX heartbeat timer expires
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmTxHBeatTimeout
(
ItAssocCb     *assocCb        /* assoc control block */
)
#else
PUBLIC S16 itPsmTxHBeatTimeout (assocCb)
ItAssocCb     *assocCb;       /* assoc control block */
#endif
{
   TRC2(itPsmTxHBeatTimeout)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
                        "itPsmTxHBeatTimeout(sg)\n"));

   /* Send another heartbeat probe to remote peer */
   (Void) itMmhHBeat(assocCb, FALSE, (Buffer **)NULLP, (ItM3uaTag *)NULLP);

   /* Reset heartbeat timer */
   itTcStartTimer(&assocCb->tmrHBeatTX, (PTR)assocCb, IT_TMR_HBEAT_TX, 
                  &itGlobalCb.genCfg.tmr.tmrHeartbeat);

   RETVALUE(ROK);
} /* end of itPsmTxHBeatTimeout */


/*
*
*       Fun:   itPsmGetAssoc
*
*       Desc:  Called by MUP during stage two routing to select a assoc
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmGetAssoc
(
ItMupMsg       *msg           /* MUP message */
)
#else
PUBLIC S16 itPsmGetAssoc(msg)
ItMupMsg       *msg;          /* MUP message */
#endif
{
   ItPsCb      *psCb;         /* PS control block */

   TRC2(itPsmGetAssoc)

   ITDBGP(DBGMASK_LYR | IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf, 
            "itPsmGetAssoc(msg)\n"));

   if (msg->routeType == LIT_RTTYPE_PS)
   {
      psCb = msg->routeTgt1;
   }
   else
   {
      RETVALUE(RFAILED);
   }

   switch (psCb->psSta.asSt)
   {
      /* following 2 cases fall through */
      case LIT_AS_DOWN:
      case LIT_AS_INACTIVE:
      {
         /* Message is rejected */
         msg->msgState = IT_MSG_REJECTED;
         break;
      }
      case LIT_AS_PENDING:
      {
         /* Add new message to linked list */
         cmLListAdd2Tail(&psCb->msgQ, &msg->llHdr);
         msg->msgState = IT_MSG_QUEUED_PSM;
         break;
      }
      case LIT_AS_ACTIVE:
      {
         break;
      }
      default:
         /* should never get here */
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of itPsmGetAssoc */


/*
*
*       Fun:   itPsmSendAspUp
*
*       Desc:  Get the PSPCB and ACB and call itMmhAspUp to send the ASPUP
*              message. Start the timer with the configured
*              initial ASPUP period.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: Called by LMI to initiate generation of ASPUP messages.
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmSendAspUp
(
ItCntrl  *cntrl,              /* control parameters */
CmStatus *sta                 /* return status */
)
#else
PUBLIC S16 itPsmSendAspUp (cntrl, sta)
ItCntrl  *cntrl;              /* control parameters */
CmStatus *sta;                /* return status */
#endif
{
   ItAssocCb  *assocCb;           /* Assoc control block */
   S16      ret;              /* return value */
   
   ret = ROK;

   TRC2(itPsmSendAspUp)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itPsmSendAspUp(cntrl, sta)\n"));

   /* Get PSP CB */
   assocCb = itGlobalCb.assoc[IT_PSPnENDP2ASSOC(cntrl->s.pspId, 
                                                cntrl->t.aspm.sctSuId)];

   if (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_ASP)
   {
      sta->reason = LIT_REASON_INV_PEERTYPE;
      RETVALUE(RFAILED);
   }

   if (assocCb->assocSta->inhibited == TRUE)
   {
      sta->reason = LIT_REASON_MNGMNT_INHIBIT;
      RETVALUE(RFAILED);
   }
   else
   {
      if (cntrl->s.pspId != IT_LOCAL_PSPID)
      {
         /* Store info string */
         (Void) cmMemcpy((U8 *)assocCb->info, (U8 *)cntrl->t.aspm.info, 
                         LIT_MAX_INFO);

         
         /* Check ASPUP return value */
         /* Prompt MMH to send ASPUP to remote peer */
         if (((ret = itMmhAspUp(assocCb, FALSE, assocCb->info))) != ROK)
         {
            sta->status = LCM_PRIM_NOK;
            sta->reason = LIT_REASON_MSG_NOT_SENT;
            RETVALUE(ret);
         }

         assocCb->aspmType = IT_ASPM_ASPUP;

         /* Start ASPUP timer */
         itTcStartTimer(&assocCb->tmrAspm, (PTR)assocCb, IT_TMR_ASPM,
                        &itGlobalCb.genCfg.tmr.tmrAspUp1);

         assocCb->retryCount = 0;
      }
      else
      {
         /* indicate that the local PSP is going up */
         (Void) itPsmAspUp(assocCb, FALSE, (Txt *)NULLP);
      }
   }

   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   
   RETVALUE(ROK);
} /* end of itPsmSendAspUp */


/*
*
*       Fun:   itPsmSendAspDn
*
*       Desc:  Get the PSPCB and ACB and call itMmhAspDn to send the ASPDN
*              message. Start the timer with the configured
*              ASPDN period.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: Called by LMI to initiate generation of ASPDN messages.
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmSendAspDn
(
ItCntrl  *cntrl,              /* control parameters */
CmStatus *sta                 /* return status */     
)
#else
PUBLIC S16 itPsmSendAspDn (cntrl, sta)
ItCntrl  *cntrl;              /* control parameters */
CmStatus *sta;                /* return status */     
#endif                                                
{                                                     
   ItAssocCb    *assocCb;     /* assoc control block */ 
   /* to allow IPSP to send ASPDN in case
      remote IPSP has not De-Registered its routing keys */
   ItPsCb       *psCb;        /* PS control block */ 
   U8           i;            /* index pointer */ 

   TRC2(itPsmSendAspDn)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
            "itPsmSendAspDn(cntrl, sta)\n"));

   /* Get assoc CB */
   assocCb = itGlobalCb.assoc[IT_PSPnENDP2ASSOC(cntrl->s.pspId,
                                                cntrl->t.aspm.sctSuId)];

   if (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_ASP)
   {
      sta->reason = LIT_REASON_INV_PEERTYPE;
      RETVALUE(RFAILED);
   }

   /* changes done  to allow IPSP to send ASPDN in case
      remote IPSP has not De-Registered its routing keys */
   /* Disable this check for IPSP DE */
   if ((assocCb->assocSta->nmbRegPs != 0) && 
       !((assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_IPSP) &&
         (assocCb->owner->pspCfg.ipspMode == LIT_IPSPMODE_DE)))
   {
      sta->reason = LIT_REASON_UNREG_RK;
      RETVALUE(RFAILED);
   }
   /* Handling Added to allow IPSP to send ASPDN in case
      remote IPSP has not De-Registered its routing keys */
   /* For IPSP DE, LM should be able to send ASP Down even if 
      an RK is not de-registered by the remote IPSP. So for
      IPSP DE mode we should only check that remote IPSP should
      not be registereted to Local PS. In other words Local
      IPSP has de-registered all the routing Keys which it
      registered  */
   else if (assocCb->assocSta->nmbRegPs != 0) 
   {
     for (i = 0; i < assocCb->assocSta->nmbRegPs; i++)
     {
        if (((psCb = itPsmFindPs(assocCb->assocSta->regPs[i]))!= NULLP) &&
            (psCb->psCfg.lclFlag == TRUE))
        {  
           sta->reason = LIT_REASON_UNREG_RK;
           RETVALUE(RFAILED);
        }
     }     
   }

   if (cntrl->s.pspId != IT_LOCAL_PSPID)
   {
      /* Store info string */
      cmMemcpy((U8 *)assocCb->info, (U8 *)cntrl->t.aspm.info, LIT_MAX_INFO);

      /* stop the heart beat timer */
      if (itGlobalCb.genCfg.tmr.tmrHeartbeat.enb == TRUE)
      {
         itTcStopTimer(&assocCb->tmrHBeatRX);
         itTcStopTimer(&assocCb->tmrHBeatTX);
      }

      assocCb->aspmType = IT_ASPM_ASPDN;

      /* Prompt MMH to send ASPDN to remote peer */
      (Void) itMmhAspDn(assocCb, FALSE, assocCb->info);
      
      /* Start ASPDN retry timer */
      itTcStartTimer(&assocCb->tmrAspm, (PTR)assocCb, IT_TMR_ASPM,
                     &itGlobalCb.genCfg.tmr.tmrAspDn);

      assocCb->retryCount = 0;
   }
   else
   {
      (Void) itPsmAspDn(assocCb, FALSE, (Txt *)NULLP, FALSE);
   }

   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   
   RETVALUE(ROK);
} /* end of itPsmSendAspDn */


/*
*
*       Fun:   itPsmSendAspAc
*
*       Desc:  Get the PSP CB and ACB and call itMmhAspAc to send the ASPAC
*              message.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: Called by LMI to initiate activation of an ASP.
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmSendAspAc
(
ItCntrl  *cntrl,                             /* control parameters */
CmStatus *sta                                /* return status */     
)
#else
PUBLIC S16 itPsmSendAspAc (cntrl, sta)
ItCntrl  *cntrl;                             /* control parameters */
CmStatus *sta;                               /* return status */     
#endif                                                      
{                                                           
   ItAssocCb   *assocCb;                     /* PSP control block */ 
   ItRtCtx     rtCtxLst[LIT_MAX_PSID];       /* Route context list */
   U16         nmbRtCtx;                     /* number of route contexts */
   ItRtCtx     irCtx[LIT_MAX_PSID];          /* Route context list */
   U16         irCtxLen;                     /* number of route contexts */
   ItRtCtx     nrCtx[LIT_MAX_PSID];          /* Route context list */
   U16         nrCtxLen;                     /* number of route contexts */
   U16         i;                            /* loop index */
   ItRtCtx     nrCtxOverRide[LIT_MAX_PSID];  /* Route context list */
   U16         nrCtxLenOverRide;             /* number of route contexts */
   ItRtCtx     nrCtxLoadShare[LIT_MAX_PSID]; /* Route context list */
   U16         nrCtxLenLoadShare;            /* number of route contexts */

   TRC2(itPsmSendAspAc)

   irCtxLen = 0;
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf,
            "itPsmSendAspAc(cntrl, sta)\n"));

   /* Get assoc CB */
   assocCb = itGlobalCb.assoc[IT_PSPnENDP2ASSOC(cntrl->s.pspId,
                                                cntrl->t.aspm.sctSuId)];

      
   if (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_ASP)
   {
      /* wrong pspType */
      sta->reason = LIT_REASON_INV_PEERTYPE;
      RETVALUE(RFAILED);
   }
      
   /* it015.106 this check is applicable to IPSP DE also
      so removing the condition for IPSP DE */
   if (assocCb->assocSta->aspSt == LIT_ASP_DOWN)
   {
      /* cannot send ASPAC in down state */
      sta->reason = LIT_REASON_INV_PEER_STATE;
      RETVALUE(RFAILED);
   }

   if (assocCb->assocSta->inhibited == TRUE)
   {
      sta->reason = LIT_REASON_MNGMNT_INHIBIT;
      RETVALUE(RFAILED);
   }

   /* Store info string in PSPCB */
   (Void) cmMemcpy((U8 *)assocCb->info, (U8 *)cntrl->t.aspm.info, LIT_MAX_INFO);

   if (cntrl->t.aspm.autoCtx == TRUE)
   {
      nmbRtCtx = 0;
      for (i = 0; i < assocCb->nmbPs; i++)
      {
         if ((assocCb->ps[i]->psCfg.lclFlag == TRUE) ||
             (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_LOCAL))
         {
            rtCtxLst[nmbRtCtx].rtCtx    = assocCb->ps[i]->psCfg.psId;
            rtCtxLst[nmbRtCtx].ntfySend = FALSE;
            rtCtxLst[nmbRtCtx].ntfyStaId = NULLD;
            nmbRtCtx++;
         }
      } /* End of for on pspCb->nmbPs */
   }
   else
   {
      nmbRtCtx = cntrl->t.aspm.nmbPs;
      for (i = 0; i < nmbRtCtx; i++)
      {
         rtCtxLst[i].rtCtx = cntrl->t.aspm.psLst[i];
         rtCtxLst[i].ntfySend = FALSE;
         rtCtxLst[i].ntfyStaId = NULLD;
      }
   }

   nrCtxLen = nmbRtCtx;

   (Void) cmMemcpy((U8 *)nrCtx, (U8 *)rtCtxLst, sizeof(ItRtCtx) * nmbRtCtx);

    /* Map PS Id's  received in control request to corresponding RC's 
     * before calling  itAtPsmAspAc  */

   /* Get all the PSs configured with THM as Over Ride */
   irCtxLen = 0;
   (Void) itPsmVrfyPsLst(nrCtx, &nrCtxLen, irCtx, &irCtxLen,
                            IT_VRCTX_OVERRIDE);
   (Void) cmMemcpy((U8 *)nrCtxOverRide, (U8 *)nrCtx, sizeof(ItRtCtx) * nrCtxLen);
   nrCtxLenOverRide = nrCtxLen; 

   (Void) cmMemcpy((U8 *)nrCtx, (U8 *)irCtx, sizeof(ItRtCtx) * irCtxLen);
   nrCtxLen = irCtxLen; 

   /* Get all the PSs configured with THM as Load Share */
   irCtxLen = 0;
   (Void) itPsmVrfyPsLst(nrCtx, &nrCtxLen, irCtx, &irCtxLen,
                            IT_VRCTX_LOADSHARE);
   (Void) cmMemcpy((U8 *)nrCtxLoadShare, (U8 *)nrCtx, sizeof(ItRtCtx) * nrCtxLen);
   nrCtxLenLoadShare = nrCtxLen; 

   /* It means that the PS CB was not found corresponding to this PSID 
    * So return an error */
   if (irCtxLen != 0)
   {
      sta->reason = LIT_REASON_INVALID_PSID;
      RETVALUE(RFAILED);    
   }
   /* This check makes sure that the PS specified in the list are not
    * do not have this PSP in override as well as load shared, only one
    * The PSs specified should all have the same THM configured, otherwise 
    * a negative control confirm would be sent to the layer manager */

   if ((nrCtxLenOverRide != 0) && (nrCtxLenLoadShare != 0 ))
   {
      sta->reason = LIT_REASON_OVERLAPPING_THM;
      RETVALUE(RFAILED);    
   }
                   
   if ((nrCtxLenOverRide == 0) && (nrCtxLenLoadShare == 0 ))
   {
      sta->reason = LIT_REASON_INVALID_PSID;
      RETVALUE(RFAILED);    
   }

   if (nrCtxLenOverRide != 0)
   {           
      itAtMapPsToRc(assocCb, nrCtxOverRide, &nrCtxLenOverRide, irCtx, &irCtxLen);
      if (irCtxLen != 0)
      {
         sta->reason = LIT_REASON_INVALID_PSID;
         RETVALUE(RFAILED);    
      }

      /* Prompt MMH to send ASPAC to remote peer */
      if (cntrl->s.pspId != IT_LOCAL_PSPID)
      {
         (Void) itMmhAspAc(assocCb, FALSE, LIT_ASP_TMTYPE_OVERRIDE, 
                           (Txt *)assocCb->info, nrCtxOverRide, 
                           nrCtxLenOverRide);
      
         if (itGlobalCb.genCfg.tmr.tmrAspM.enb == TRUE)
         {
            assocCb->aspmType = IT_ASPM_ASPAC;
            itTcStartTimer(&assocCb->tmrAspm, (PTR)assocCb, IT_TMR_ASPM, 
                           &itGlobalCb.genCfg.tmr.tmrAspM);
         }
      }
      else
      {
         (Void) itPsmAspAc(assocCb, FALSE, LIT_ASP_TMTYPE_OVERRIDE, 
                           "Local PSP active", nrCtx, nrCtxLen);
      }
   }
   else if (nrCtxLenLoadShare != 0)
   {           
      itAtMapPsToRc(assocCb, nrCtxLoadShare, &nrCtxLenLoadShare, irCtx, &irCtxLen);
      if (irCtxLen != 0)
      {
         sta->reason = LIT_REASON_INVALID_PSID;
         RETVALUE(RFAILED);    
      }
      /* Prompt MMH to send ASPAC to remote peer */
      if (cntrl->s.pspId != IT_LOCAL_PSPID)
      {
         (Void) itMmhAspAc(assocCb, FALSE, LIT_ASP_TMTYPE_LOADSHARE, 
                           (Txt *)assocCb->info, nrCtxLoadShare,
                           nrCtxLenLoadShare);
      
         if (itGlobalCb.genCfg.tmr.tmrAspM.enb == TRUE)
         {
            assocCb->aspmType = IT_ASPM_ASPAC;
            itTcStartTimer(&assocCb->tmrAspm, (PTR)assocCb, IT_TMR_ASPM, 
                           &itGlobalCb.genCfg.tmr.tmrAspM);
         }
      }
      else
      {
      
         (Void) itPsmAspAc(assocCb, FALSE, LIT_ASP_TMTYPE_LOADSHARE, 
                           "Local PSP active", nrCtx, nrCtxLen);
      }
   }
  

   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   
   RETVALUE(ROK);
} /* end of itPsmSendAspAc */


/*
*
*       Fun:   itPsmSendAspIa
*
*       Desc:  Get the PSP CB and ACB and call itMmhAspIa to send the ASPIA
*              message.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: Called by LMI to initiate deactivation of an ASP.
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmSendAspIa
(
ItCntrl  *cntrl,              /* control parameters */ 
CmStatus *sta                 /* return status */      
)
#else
PUBLIC S16 itPsmSendAspIa (cntrl, sta)
ItCntrl  *cntrl;              /* control parameters */
CmStatus *sta;                /* return status */     
#endif                                                
{                                                     
   ItAssocCb   *assocCb;            /* Assoc control block */ 
   ItRtCtx     rtCtx[LIT_MAX_PSID]; /* Route context list */     
   U16         nmbRtCtx;      /* number of route contexts */      
   ItRtCtx     irCtx[LIT_MAX_PSID];    /* Route context list */
   U16         irCtxLen;               /* number of route contexts */
   ItRtCtx     nrCtx[LIT_MAX_PSID];    /* Route context list */
   U16         nrCtxLen;               /* number of route contexts */
   U16         i;             /* loop index */        

   TRC2(itPsmSendAspIa)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itPsmSendAspIa(cntrl, sta)\n"));

   irCtxLen = 0;
   /* Get assoc CB */
   assocCb = itGlobalCb.assoc[IT_PSPnENDP2ASSOC(cntrl->s.pspId,
                                                cntrl->t.aspm.sctSuId)];

   if (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_ASP)
   {
      sta->reason = LIT_REASON_INV_PEERTYPE;
      RETVALUE(RFAILED);
   }
   
   /* Store info string */
   (Void) cmMemcpy((U8 *)assocCb->info, (U8 *)cntrl->t.aspm.info, LIT_MAX_INFO);

   if (cntrl->t.aspm.autoCtx == TRUE)
   {

      nmbRtCtx = 0;                                                                  
      for (i = 0; i < assocCb->nmbPs; i++)
      {
         if (assocCb->ps[i]->psCfg.lclFlag == TRUE)
         {
            rtCtx[nmbRtCtx].rtCtx    = assocCb->ps[i]->psCfg.psId;
            rtCtx[nmbRtCtx].ntfySend = FALSE;
            nmbRtCtx++;
         }
      } /* End of for on assocCb->nmbPs */      
   }
   else
   {
      nmbRtCtx = cntrl->t.aspm.nmbPs;
      for (i = 0; i < nmbRtCtx; i++)
      {
         rtCtx[i].rtCtx = cntrl->t.aspm.psLst[i];
      }
   }

   nrCtxLen = nmbRtCtx;

   (Void) cmMemcpy((U8 *)nrCtx, (U8 *)rtCtx, sizeof(ItRtCtx) * nmbRtCtx);

    /* Map PS Id's  received in control request to corresponding RC's 
     * before calling  itAtPsmAspAc  */
   itAtMapPsToRc(assocCb, nrCtx, &nrCtxLen, irCtx, &irCtxLen);

   if (irCtxLen != 0)
   {
      sta->reason = LIT_REASON_INVALID_PSID;
      RETVALUE(RFAILED);    
   }
   /* Prompt MMH to send ASPIA to remote peer */
   if (cntrl->s.pspId != IT_LOCAL_PSPID)
   {
      (Void) itMmhAspIa(assocCb, FALSE, (Txt *)assocCb->info,
                        nrCtx, nmbRtCtx);

      if (itGlobalCb.genCfg.tmr.tmrAspM.enb == TRUE)
      {
         assocCb->aspmType = IT_ASPM_ASPIA;
         itTcStartTimer(&assocCb->tmrAspm, (PTR)assocCb, IT_TMR_ASPM, 
                        &itGlobalCb.genCfg.tmr.tmrAspM);
      }
   }
   else
   {
      (Void) itPsmAspIa(assocCb, FALSE, (Txt *)NULLP,
                         nrCtx, nrCtxLen);
   }

   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   
   RETVALUE(ROK);
} /* end of itPsmSendAspIa */


/*
*
*       Fun:   itPsmSendScon
*
*       Desc:  Get the PSPCB and ACB and call itMmhSsnm to send a SCON
*              message. 
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: Called by LMI to generate SCON message to peer.
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmSendScon
(
ItCntrl  *cntrl,              /* control parameters */
CmStatus *sta                 /* return status */
)
#else
PUBLIC S16 itPsmSendScon (cntrl, sta)
ItCntrl  *cntrl;              /* control parameters */
CmStatus *sta;                /* return status */
#endif
{
   ItAssocCb  *assocCb;       /* assoc control block */
   ItDpcCb  *dpcCb;           /* DPC control block */

   TRC2(itPsmSendScon)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itPsmSendScon(cntrl, sta)\n"));

   /* Get assoc CB */
   assocCb = itGlobalCb.assoc[IT_PSPnENDP2ASSOC(cntrl->s.pspId,
                                                cntrl->t.cong.sctSuId)];

   if (assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_ASP)
   {
      sta->reason = LIT_REASON_INV_PEERTYPE;
      RETVALUE(RFAILED);
   }

   if (assocCb->assocSta->aspSt != LIT_ASP_ACTIVE)
   {
      sta->reason = LCM_REASON_INVALID_STATE;
      RETVALUE(RFAILED);
   }

   if (cntrl->s.pspId == IT_LOCAL_PSPID)
   {
      sta->reason = LIT_REASON_INVALID_PSPID;
      RETVALUE(RFAILED);
   }
   if (itGlobalCb.nwk[cntrl->t.cong.nwkId] == NULL)
   {
      sta->reason = LIT_REASON_INVALID_NWKID;
      RETVALUE(RFAILED);
   }
   if (cntrl->t.cong.congLevel > 3)
   {
      sta->reason = LIT_REASON_INVALID_CONG_LEVEL;
      RETVALUE(RFAILED);
   }

   if (itAtGetDpc(cntrl->t.cong.nwkId, cntrl->t.cong.dpc, &dpcCb) != ROK)
   {
      sta->reason = LIT_REASON_INVALID_DPC;
      RETVALUE(RFAILED);
   }           
   /* Prompt MMH to send SCON to remote peer */
   (Void) itMmhSsnm(assocCb, IT_SSNM_SCON, cntrl->t.cong.nwkId, 
                    cntrl->t.cong.dpc, 0, (Txt *)NULLP, 
                    cntrl->t.cong.congLevel, 0);

   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   
   RETVALUE(ROK);
} /* end of itPsmSendScon */


/*
*
*       Fun:   itPsmNotify
*
*       Desc:  Called by MMH when a Notify message is received from a remote
*              server. Forward to LMI.
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmNotify
(
ItAssocCb      *assocCb,      /* association control block */
Txt            *info,         /* extra information */
ItRtCtx        *rCtx,         /* routing context list */
U16            rCtxLen,       /* list length */
U16            staType,       /* status type */
U16            staId,         /* status info */
Bool           aspIdPres,     /* ASP Id Pres Flag*/
U32            aspId          /* ASP Id */
)
#else
PUBLIC S16 itPsmNotify (assocCb, info, rCtx, rCtxLen, staType, staId,
                        aspIdPres, aspId)
ItAssocCb      *assocCb;      /* association control block */  
Txt            *info;         /* extra information */          
ItRtCtx        *rCtx;         /* routing context list */       
U16            rCtxLen;       /* list length */                
U16            staType;       /* status type */                
U16            staId;         /* status info */                
Bool           aspIdPres;     /* ASP Id Pres Flag*/
U32            aspId;         /* ASP Id */
#endif
{
   S16         i;                   /* loop index */
   U16         itEvent;             /* event for PSM */
   ItRtCtx     nrCtx[LIT_MAX_PSID]; /* updated routing context list */
   ItRtCtx     irCtx[LIT_MAX_PSID]; /* invalid routing context list */
   U16         nrCtxLen;            /* length of list */
   U16         irCtxLen;            /* length of list */
   ItPsCb      *psCb;            /* PS Cb */
   Bool        rPsToAct;            /* Boolean Flag */
   TRC2(itPsmNotify)

   irCtxLen = 0;
   rPsToAct = FALSE;
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
   "itPsmNotify(assocCb, info, rCtx, rCtxLen(%d), staType(%d), staId(%d))\n", 
          rCtxLen, staType, staId));

   itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP;
   itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS;
   itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_NOTIFY;
   itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_CAUSE_MSG_RECEIVED;
   itGlobalCb.mgmt.t.usta.s.pspId         = assocCb->owner->pspCfg.pspId;
   itGlobalCb.mgmt.t.usta.t.ntfy.nmbPs    = (U8)rCtxLen;
   itGlobalCb.mgmt.t.usta.t.ntfy.sctSuId    = IT_ASSOC2SUID(assocCb->assocId);
  
   /* Find PS ID corresponding to Routing context received in the message */
   if ((rCtx == (ItRtCtx *) NULLP) || (rCtxLen == 0))
   {
      /* Build Local PS list from configured routing */
      if ((assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
              (assocCb->owner->pspCfg.ipspMode == LIT_IPSPMODE_DE))
      {
         /* Build local routing context from configuration */
         (Void) itPsmValidateRCtx(assocCb, nrCtx, &nrCtxLen, 
                               (ItRtCtx *)NULLP, (U16 *)NULLP, 
                               IT_VRCTX_BUILD_DE_ACK);
      }
      else
      {
         (Void) itPsmValidateRCtx(assocCb, nrCtx, &nrCtxLen, 
                              (ItRtCtx *) NULLP, (U16 *) NULLP, IT_VRCTX_BUILD);
      }
      if (nrCtxLen == 0)
      {
         (Void) itMmhError(assocCb, IT_M3UA_ERROR_NO_AS_FOR_ASP, 
                         (Buffer **)NULLP, 0, (ItM3uaTag *) NULLP, (ItRtCtx *) 
                         NULLP, 0, IT_M3UA_DFLT);
          RETVALUE(RFAILED);
      }
   }
   else
   {
      (Void) cmMemcpy((U8 *)nrCtx, (U8 *)rCtx, sizeof(ItRtCtx) * rCtxLen);
      nrCtxLen = rCtxLen;
      /* handling  to allow same RC on LPS and RPS 
         for IPSP DE. AckFlag should be TRUE here as we only
         need to search Local PS  in this case of IPSP DE  */
      itAtMapRcToPs(assocCb, nrCtx, &nrCtxLen, irCtx,
                                           &irCtxLen, TRUE);
      /* Validate rCtx list according to configured routing */
      if ((assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_IPSP) && 
              (assocCb->owner->pspCfg.ipspMode == LIT_IPSPMODE_DE))
      {
          (Void) itPsmValidateRCtx(assocCb, nrCtx, &nrCtxLen, 
                               irCtx, &irCtxLen, IT_VRCTX_RMV_UNSUPP_DE_ACK);
      }
      else
      {
          (Void) itPsmValidateRCtx(assocCb, nrCtx, &nrCtxLen, 
                               irCtx, &irCtxLen, IT_VRCTX_RMV_UNSUPP);
      }
   }


   /* Reject routing contexts that are not supported */
   if (irCtxLen != NULLD)
   {
      (Void) itMmhError(assocCb, IT_M3UA_ERROR_INV_RCTX, 
                        (Buffer **)NULLP, 0, 
                        (ItM3uaTag *) NULLP, irCtx, irCtxLen, 
                         IT_M3UA_DFLT);
   }
   if (nrCtxLen == 0)
   {
      RETVALUE(RFAILED);
   }

   for (i = 0; i < nrCtxLen; i++)
   {
      itGlobalCb.mgmt.t.usta.t.ntfy.psLst[i] = nrCtx[i].rtCtx;
   }
      itGlobalCb.mgmt.t.usta.t.ntfy.nmbPs = (U8)nrCtxLen;

   if (info != (Txt *) NULLP)
   {
      cmMemcpy((U8 *)itGlobalCb.mgmt.t.usta.t.ntfy.info, (U8 *)info, 
               MIN(cmStrlen((U8 *)info), LIT_MAX_INFO));
   }
   if (aspIdPres == TRUE)
   {

      itGlobalCb.mgmt.t.usta.t.ntfy.aspIdPres = TRUE; 
      itGlobalCb.mgmt.t.usta.t.ntfy.aspId = aspId;
   }
   else
   { 
      itGlobalCb.mgmt.t.usta.t.ntfy.aspIdPres = FALSE; 
   }
   
   switch (staType)
   {
      case IT_M3UA_NTFY_TYPE_ASCHG:
      {
         itGlobalCb.mgmt.t.usta.t.ntfy.stType = LIT_NTFY_TYPE_ASCHG;
         switch (staId)
         {
            case IT_M3UA_NTFY_INFO_AS_INACTIVE:
               itGlobalCb.mgmt.t.usta.t.ntfy.stInfo = LIT_NTFY_INFO_AS_INACTIVE;
               itEvent                              = IT_EVT_AS_INACTIVE;
               break;
            case IT_M3UA_NTFY_INFO_AS_ACTIVE:
               itGlobalCb.mgmt.t.usta.t.ntfy.stInfo = LIT_NTFY_INFO_AS_ACTIVE;
               itEvent                              = IT_EVT_AS_ACTIVE;
               break;
            case IT_M3UA_NTFY_INFO_AS_PENDING:
               itGlobalCb.mgmt.t.usta.t.ntfy.stInfo = LIT_NTFY_INFO_AS_PENDING;
               itEvent                              = IT_EVT_AS_PENDING;
               break;
            default:
               break;
         }
         break;
      }
      case LIT_NTFY_TYPE_OTHER:
      {
         itGlobalCb.mgmt.t.usta.t.ntfy.stType = LIT_NTFY_TYPE_OTHER;
         switch (staId)
         {
            case IT_M3UA_NTFY_INFO_INSUF_RSRC:
               itGlobalCb.mgmt.t.usta.t.ntfy.stInfo = 
                  LIT_NTFY_INFO_OTHER_INSUF_RSRC;
               break;
            case IT_M3UA_NTFY_INFO_ALT_ASPACT:
               itGlobalCb.mgmt.t.usta.t.ntfy.stInfo = 
                  LIT_NTFY_INFO_OTHER_ALT_ASPACT;
               break;
            case IT_M3UA_NTFY_INFO_ASP_FLR:
               itGlobalCb.mgmt.t.usta.t.ntfy.stInfo = 
                  LIT_NTFY_INFO_OTHER_ASP_FLR;
               break;
            default:
               break;
         }
         break;
      }
      default:
         break;
   }

   (Void) itMiStaIndM(&itGlobalCb.mgmt);

   if ((staType == LIT_NTFY_TYPE_OTHER) && 
       (staId == LIT_NTFY_INFO_OTHER_ALT_ASPACT))
   {
      itEvent = IT_EVT_ASP_IA_ACK;
      /* Report to AS state machine */
      itPsmAllPsEvt(assocCb, nrCtx, nrCtxLen, itEvent, 0);
      for (i = 0; i < assocCb->nmbPs; i++)
      {
         psCb = assocCb->ps[i];
         if ((psCb->psCfg.lclFlag == TRUE) 
              && (psCb->psSta.psStaEndp[IT_ASSOC2SUID(assocCb->assocId)].\
                         aspSt[assocCb->owner->pspCfg.pspId] == LIT_ASP_ACTIVE))
         {
              rPsToAct = TRUE;
              break;
         }
      }
      if (rPsToAct == FALSE)
      {
      
   /* In case of ASP and IPSP(SE), the Lcl PS state is required to be changed */

         if ((assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_SGP) ||
            ((assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_IPSP) &&
             (assocCb->owner->pspCfg.ipspMode == LIT_IPSPMODE_SE)))
         {
            /* Get the Local PS which are part of this remote PSP too */
            IT_GET_RPS_FRM_PSP(assocCb, irCtx, irCtxLen);
            itPsmAllPsEvt(assocCb, irCtx, irCtxLen, itEvent, 0);
         }
      }
   }

   RETVALUE(ROK);
} /* end of itPsmNotify */


/*
*
*       Fun:   itPsmAspTimeout
*
*       Desc:  Send ASPM retries and reset the timer
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: Called by TC when the ASPM period timer expires.
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itPsmAspTimeout
(
ItAssocCb     *assocCb            /* Assoc control block */
)
#else
PUBLIC S16 itPsmAspTimeout (assocCb)
ItAssocCb     *assocCb;           /* Assoc control block */   
#endif
{
   TmrCfg   *tmrAspUp;        /* temp timer config */

   TRC2(itPsmAspTimeout)

#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itPsmAspTimeout(assocCb(%d))\n", 
          (assocCb != (ItAssocCb *)NULLP) ? assocCb->assocId : 0xFFFFFFFF));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itPsmAspTimeout(assocCb(%ld))\n", 
          (assocCb != (ItAssocCb *)NULLP) ? assocCb->assocId : 0xFFFFFFFF));
#endif

   switch (assocCb->aspmType)
   {
      case IT_ASPM_ASPDN:
         /* Send another ASPDN message to remote peer */
         (Void) itMmhAspDn(assocCb, FALSE, assocCb->info);

         assocCb->retryCount++;

         /* Reset retry timer */
         itTcStartTimer(&assocCb->tmrAspm, (PTR)assocCb, IT_TMR_ASPM, 
                        &itGlobalCb.genCfg.tmr.tmrAspDn);
         break;
      case IT_ASPM_ASPUP:
         /* Send another ASPUP message to remote peer */
         (Void) itMmhAspUp(assocCb, FALSE, assocCb->info);

         assocCb->retryCount++;
         
         if (assocCb->retryCount == itGlobalCb.genCfg.tmr.nmbAspUp1)
         {
            
            /* Status indication: PSP state change */
            IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
            itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
            itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS; 
            itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_ASPUP_FAIL;
            itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_REASON_NO_RESPONSE;
            itGlobalCb.mgmt.t.usta.s.pspId       = assocCb->owner->pspCfg.pspId;
            itGlobalCb.mgmt.t.usta.t.aspm.sctSuId = 
                                                   assocCb->sctSap->sctCfg.suId;
                    
            (Void) itMiStaIndM(&itGlobalCb.mgmt); 
         }

         if (assocCb->retryCount >= itGlobalCb.genCfg.tmr.nmbAspUp1)
         {
            tmrAspUp = &itGlobalCb.genCfg.tmr.tmrAspUp2;
         }
         else
         {
            tmrAspUp = &itGlobalCb.genCfg.tmr.tmrAspUp1;
         }

         /* Reset retry timer */
         itTcStartTimer(&assocCb->tmrAspm, (PTR)assocCb, IT_TMR_ASPM, tmrAspUp);
         break;
      case IT_ASPM_ASPAC:
         {
            /* Status indication: PSP state change */
            IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
            itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
            itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS; 
            itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_ASPAC_FAIL;
            itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_REASON_NO_RESPONSE;
            itGlobalCb.mgmt.t.usta.s.pspId       = assocCb->owner->pspCfg.pspId;
            itGlobalCb.mgmt.t.usta.t.aspm.sctSuId = 
                                                   assocCb->sctSap->sctCfg.suId;
                    
            (Void) itMiStaIndM(&itGlobalCb.mgmt); 
         }
         break;
      case IT_ASPM_ASPIA:
         {
            /* Status indication: PSP state change */
            IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
            itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP;
            itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS; 
            itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_ASPIA_FAIL;
            itGlobalCb.mgmt.t.usta.alarm.cause     = LIT_REASON_NO_RESPONSE;
            itGlobalCb.mgmt.t.usta.s.pspId       = assocCb->owner->pspCfg.pspId;
            itGlobalCb.mgmt.t.usta.t.aspm.sctSuId = 
                                                   assocCb->sctSap->sctCfg.suId;
                    
            (Void) itMiStaIndM(&itGlobalCb.mgmt); 
         }
         break;
      default:
         break;
   }

   RETVALUE(ROK);
} /* end of itPsmAspTimeout */


/*
*
*       Fun:   itAcEst
*
*       Desc:  Establish association
*
*       Ret:   Failure: RFAILED
*
*              Success: ROK
*
*       Notes: Called by the LMI to request that the specified association be
*              established. Accesses the ACb to check the current state. If 
*              not already established, calls ItLiSctAssocReq with the 
*              preconfigured parameters.
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itAcEst
(
UConnId       assocId,        /* The SCTP association to establish */
CmStatus      *sta            /* Resulting status */
)
#else
PUBLIC S16 itAcEst (assocId, sta)
UConnId       assocId;        /* The SCTP association to establish */
CmStatus      *sta;           /* Resulting status */
#endif
{
   ItAssocCb  *assocCb;       /* association control block */
   S16        ret;            /* return value */

   TRC2(itAcEst)

#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
            "itAcEst(assocId(%d), sta)\n", assocId));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
            "itAcEst(assocId(%ld), sta)\n", assocId));
#endif
   if ((assocCb = itGlobalCb.assoc[assocId]) == (ItAssocCb *) NULLP)
   {
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_INVALID_ASSOCID;
      RETVALUE(RFAILED);
   }
   if (assocCb->assocSta->hlSt == LIT_ASSOC_DOWN)
   {
      if ((ret = itLiAssocReq(assocCb)) == ROK)
      {
         sta->status = LCM_PRIM_OK;
         sta->reason = LCM_REASON_NOT_APPL;
         RETVALUE(ROK);
      }
      else if (ret == RNA)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_SAP;
         RETVALUE(RFAILED);
      }
      else
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_MISC_FAILURE;
         RETVALUE(RFAILED);
      }
   }
   else
   {
      sta->status = LCM_PRIM_OK;
      sta->reason = LCM_REASON_NOT_APPL;
      RETVALUE(ROK);
   }

} /* end of itAcEst */


/*
*
*       Fun:   itAcTerm
*
*       Desc:  Terminate association
*
*       Ret:   Failure: RFAILED
*
*              Success: ROK
*
*       Notes: Called by the LMI to request that the specified association be
*              terminated. Accesses the ACb to check the current state. If 
*              currently established, calls ItLiSctTermReq with the 
*              preconfigured parameters.
*
*       File:  it_bdy4.c
*
*/
/* it004.106 - Added the abrtFlg param unconditionally, even if IT_ABORT_ASSOC 
 * not defined */
#ifdef ANSI
PUBLIC S16 itAcTerm
(
UConnId        assocId,       /* The SCTP association to establish */
CmStatus       *sta,           /* Resulting status */
Bool           abrtFlg         /* Abort Flag */
)
#else
PUBLIC S16 itAcTerm (assocId, sta, abrtFlg)
UConnId        assocId;       /* The SCTP association to establish */
CmStatus       *sta;          /* Resulting status */
Bool           abrtFlg;       /* Abort Flag */
#endif
{
   ItAssocCb   *assocCb;      /* association control block */
   S16         ret;           /* return value */             

   TRC2(itAcTerm)
   /* it004.106 - Added the abrtFlg param unconditionally, even if 
    * IT_ABORT_ASSOC not defined */
#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
            "itAcTerm(assocId(%d), abrtFlg(%d), sta)\n", assocId, abrtFlg));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
            "itAcTerm(assocId(%ld), abrtFlag(%d), sta)\n", assocId, abrtFlg));
#endif
   if ((assocCb = itGlobalCb.assoc[assocId]) == (ItAssocCb *) NULLP)
   {
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_INVALID_ASSOCID;
      RETVALUE(RFAILED);
   }
/*chenning startwork */
#ifdef ITASP
    if(assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_IPSP ||
    assocCb->owner->pspCfg.pspType == LIT_PSPTYPE_SGP)
    {
        itTcStopTimer(&(assocCb->tmrReconnect));
    }
#endif

    if ( LIT_RDST_DEFAULT != assocCb->assocSta->readySetupSt )
    {
        assocCb->assocSta->readySetupSt = LIT_RDST_DEFAULT;
    }
    
   if (assocCb->assocSta->hlSt != LIT_ASSOC_DOWN)
   {
      /* it004.106 - Added the abrtFlg param in itLiTermReq unconditionally, 
       * even if IT_ABORT_ASSOC not defined */
      if ((ret = itLiTermReq(assocCb, abrtFlg)) == ROK)
      {
         /* it004.106 - The ifdef for IT_ABORT_ASSOC is not needed here, as the 
          * following piecs of code will be executed only if abrtFlg is TRUE */
         /* here re-checking if the association state
          * is down or not is necessary as if the itLiTermReq
          * is called with abrtFlag = TRUE and if SCTP is tightly
          * coupled the as soon as SCTP receives ABORT it calls back
          * itUiSctTermCfm which markes the association state to 
          * Down and also decreases active association count. So there
          * is a possiblity when the above function returns the
          * association state in its control block may already be
          * zero at that time, although the state never changes inside
          * itLiTermReq */
         /* Change state to DOWN */
         if ((assocCb->assocSta->hlSt != LIT_ASSOC_DOWN) &&
             (abrtFlg == TRUE))
         {
            assocCb->sctSap->sctSta.nmbActAssoc--;
            assocCb->assocSta->hlSt = LIT_ASSOC_DOWN;
            
            /* it007.106 to remove warning generated because of
               using NULL in stead of NULLD */ 
            assocCb->assocSta->spAssocId = NULLD;
            /* Stop association-related timers */
            itTcStopTimer(&assocCb->tmrCong);
            itTcStopTimer(&assocCb->tmrPrim);
            if (assocCb->assocSta->aspSt != LIT_ASP_DOWN)
            {
               itTcStopTimer(&assocCb->tmrHBeatRX);
               itTcStopTimer(&assocCb->tmrHBeatTX);
               (Void) itPsmAspDn(assocCb, FALSE, (Txt *)NULLP, FALSE);
            }
/* nmbActAssoc update */
#ifdef ZV
            /* Update sctSta */
            zvRTUpd(CMPFTHA_ACTN_MOD, ZV_SCTSAPCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) assocCb->sctSap,
                         NULLP);
            zvRTUpd(CMPFTHA_ACTN_MOD, ZV_ASSOCCB,
                               CMPFTHA_UPDTYPE_SYNC, (Void *) assocCb, NULLP);
#endif
            /* it016.106 - Update "unav" statistics. */
#ifdef LITV3
            /* Association unavailable update unavailablity counter. */
            IT_STS_INC_ASSOC_UNAV(assocCb);
      
            /* Take time stamp when association became unavailable. */
            SGetSysTime(&assocCb->ticksUnav);
#endif /* LITV3 */
         }
        
         sta->status = LCM_PRIM_OK;
         sta->reason = LCM_REASON_NOT_APPL;
         RETVALUE(ROK);
      }
      else if (ret == RNA)
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_INVALID_SAP;
         RETVALUE(RFAILED);
      }
      else
      {
         sta->status = LCM_PRIM_NOK;
         sta->reason = LCM_REASON_MISC_FAILURE;
         RETVALUE(RFAILED);
      }
   }
   else
   {
      /* it010.106 - Changes done to take care of the scenario when the 
       * association is being established, and Control request is received 
       * to terminate the asssociation. So, check for the timer in 
       * assocCb->tmrPrim because layer starts IT_TMR_ASSOC_REQ after sending 
       * association establishment request, though the association hlSt 
       * remains Down. */
      if (IT_TMRACTIVE(&assocCb->tmrPrim) == TRUE)
      {
         if ((ret = itLiTermReq(assocCb, abrtFlg)) == ROK)
         {
            itTcStopTimer(&assocCb->tmrPrim);

            sta->status = LCM_PRIM_OK;
            sta->reason = LCM_REASON_NOT_APPL;
            RETVALUE(ROK);
         }
         else if (ret == RNA)
         {
            sta->status = LCM_PRIM_NOK;
            sta->reason = LCM_REASON_INVALID_SAP;
            RETVALUE(RFAILED);
         }
         else
         {
            sta->status = LCM_PRIM_NOK;
            sta->reason = LCM_REASON_MISC_FAILURE;
            RETVALUE(RFAILED);
         }
      }
      else
      {
         sta->status = LCM_PRIM_OK;
         sta->reason = LCM_REASON_NOT_APPL;
         RETVALUE(ROK);
      }
   }

} /* end of itAcTerm */


/*
*
*       Fun:   itAcInh
*
*       Desc:  Accesses the ACB to check the current state. If currently
*              established, sets the state of the ACB to LIT_ASSOC_INHIBITED.
*              Calls itPsmAssocEvt and itSgAssocEvt to indicate the change
*              of state.
*
*       Ret:   Failure: RFAILED
*
*              Success: ROK
*
*       Notes: Called by LMI to request that the specified association
*              be inhibited for maintenance purposes.
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itAcInh
(
UConnId        assocId,       /* The SCTP association to establish */
CmStatus       *sta           /* Resulting status */
)
#else
PUBLIC S16 itAcInh (assocId, sta)
UConnId        assocId;       /* The SCTP association to establish */
CmStatus       *sta;          /* Resulting status */
#endif
{
   ItAssocCb   *assocCb;      /* association control block */
   
   TRC2(itAcInh)
#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
            "itAcInh(assocId(%d), sta)\n", assocId));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
            "itAcInh(assocId(%ld), sta)\n", assocId));
#endif
   assocCb = itGlobalCb.assoc[assocId];

   if (assocCb->assocSta->aspSt != LIT_ASP_DOWN)
   {
      sta->status = LCM_PRIM_NOK;
      sta->reason = LIT_REASON_SERVICE_IN_USE;
      /* it013.106 - If asp state is not down, it cannot be inhibited, 
       * so return RFAILED. */
      RETVALUE(RFAILED);
   }

   assocCb->assocSta->inhibited = TRUE;

#ifdef ZV
  /* Sync the state change of assocCb->assocSta, psCb */
    zvRTUpd(CMPFTHA_ACTN_MOD, ZV_ASSOCCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) assocCb, NULLP);
#endif

   (Void) itAcAssocEvt(assocCb, LIT_EVENT_ASSOC_INHIBIT);

   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   
   RETVALUE(ROK);
} /* end of itAcInh */


/*
*
*       Fun:   itAcUninh
*
*       Desc:  Management uninhibit association
*
*       Ret:   Failure: RFAILED
*
*              Success: ROK
*
*       Notes: Called by the LMI to request that the specified association be
*              uninhibited. Accesses the ACB to check the current state. If 
*              currently inhibited or active, sets the state of the ACB to 
*              LIT_ASSOC_ACTIVE and returns with status LCM_PRIM_OK. Calls 
*              itPsmAssocEvt and itPsmAssocEvt to indicate change of state.
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itAcUninh
(
UConnId        assocId,       /* The SCTP association to establish */
CmStatus       *sta           /* Resulting status */
)
#else
PUBLIC S16 itAcUninh (assocId, sta)
UConnId        assocId;       /* The SCTP association to establish */
CmStatus       *sta;          /* Resulting status */
#endif
{
   ItAssocCb   *assocCb;      /* association control block */

   TRC2(itAcUninh)
#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
            "itAcUninh(assocId(%d), sta)\n", assocId));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
            "itAcUninh(assocId(%ld), sta)\n", assocId));
#endif
   assocCb = itGlobalCb.assoc[assocId];
   
   assocCb->assocSta->inhibited = FALSE;

#ifdef ZV
  /* Sync the state change of assocCb->assocSta, psCb */
    zvRTUpd(CMPFTHA_ACTN_MOD, ZV_ASSOCCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) assocCb, NULLP);
#endif
   sta->status = LCM_PRIM_OK;
   sta->reason = LCM_REASON_NOT_APPL;
   
   RETVALUE(ROK);
} /* end of itAcUninh */


/*
*
*       Fun:   itAcCmpNetAddr
*
*       Desc:  Compares two Network Addresses
*
*       Ret:   Failure:
*
*              Success:
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
Bool itAcCmpNetAddr
(
CmNetAddr      *addrA,        /* address A */
CmNetAddr      *addrB         /* address B */
)
#else
Bool itAcCmpNetAddr (addrA, addrB)
CmNetAddr      *addrA;        /* address A */ 
CmNetAddr      *addrB;        /* address B */ 
#endif
{
   Bool     matchFlag;        /* TRUE if match */
   U32      i;                /* loop index */

   TRC2(itAcCmpNetAddr)
   
   if ((addrA)->type == (addrB)->type)
   {
      switch ((addrA)->type)
      {
         case CM_NETADDR_IPV4:
            if ((addrA)->u.ipv4NetAddr == (addrB)->u.ipv4NetAddr)
            {
               matchFlag = TRUE;
            }
            else
            {
               matchFlag = FALSE;
            }
            break;
         case CM_NETADDR_IPV6:
            matchFlag = TRUE;
            for (i = 0; i < CM_IPV6ADDR_SIZE; i++)
            {
               if ((addrA)->u.ipv6NetAddr[i] != (addrB)->u.ipv6NetAddr[i])
               {
                  matchFlag = FALSE;
               }
            }
            break;
         default:
         {
            matchFlag = FALSE;
         }
      }
   }
   else
   {
      matchFlag = FALSE;
   }

   RETVALUE(matchFlag);
} /* end of itAcCmpNetAddr */


/*
*
*       Fun:   itAcAssocInd
*
*       Desc:  Identifies the locally configured ACB by searching for matching
*              addresses in the dstNAddrLst. A single matching address is 
*              sufficient. If a matching ACB is found, the subset of 
*              destination addresses specified in the ACB configuration is
*              substituted into the dstNAddrLst parameter and the function 
*              returns with ROK. The spAssocId is stored in the ACB. If no 
*              matching ACB is found, the function returns with RFAILED.
*
*       Ret:   Failure: RFAILED
*
*              Success: ROK
*
*       Notes: Called by the LI to indicate a new association from an M3UA
*              peer.
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itAcAssocInd
(
SuId                 suId,          /* service user ID */
SctAssocIndParams    *assocParams   /* association indication parameters */
)
#else
PUBLIC S16 itAcAssocInd (suId, assocParams)
SuId                 suId;          /* service user ID */                   
SctAssocIndParams    *assocParams;  /* association indication parameters */ 
#endif
{
   Bool              matchFlag;     /* TRUE if match */
   CmNetAddr         *addrA;        /* address A */
   CmNetAddr         *addrB;        /* address B */
   UConnId           assocIdx;      /* association index */
   SctNetAddrLst     cmAddrLst;     /* address list */
   SctNetAddrLst     *dstNAddrLst;  /* destination addresses */
   SctNetAddrLst     *locAddrLst;   /* local addresses */
   SctNetAddrLst     *remAddrLst;   /* remote addresses */
   ItAssocCb         *assocCb;      /* association CB */
   ItPspCb           *pspCb;        /* PSP CB */
   U32               i;             /* loop index */
   U32               j;             /* loop index */
   U32               k;             /* loop index */
   U16               dstPort;       /* destination port */
   SctAssocIndParams locAssocParm;  /* assocation parameters */
   Bool             chgAddrLst=TRUE;   /* Boolean flag to check address list */

   TRC2(itAcAssocInd)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
                        "itAcAssocInd(suId(%d), assocParams)\n", suId))

   dstNAddrLst = (SctNetAddrLst *)NULLP;
   locAddrLst  = (SctNetAddrLst *)NULLP; 
   remAddrLst  = (SctNetAddrLst *)NULLP;
   assocCb     = (ItAssocCb *) NULLP;
   dstPort     = 0;
   assocIdx    = 0;
   pspCb       = (ItPspCb *)NULLP;

   /* Check that SAP has been bound and endpoint(s) opened */
   if ((itGlobalCb.sctSap[suId])->sctSta.hlSt != LIT_SAP_READY)
   {
      RETVALUE(RFAILED);
   }

   (Void) cmMemcpy((U8 *)&locAssocParm, (U8 *)assocParams, 
                   sizeof(SctAssocIndParams));

   switch (assocParams->type)
   {
      case SCT_ASSOC_IND_INIT:
      {
         dstNAddrLst = &assocParams->t.initParams.peerAddrLst;
         dstPort     = assocParams->t.initParams.peerPort;
         break;
      }
      case SCT_ASSOC_IND_COOKIE:
      {
         dstNAddrLst = &assocParams->t.cookieParams.peerAddrLst;
         dstPort     = assocParams->t.cookieParams.peerPort;
         break;
      }
      default:
         RETVALUE(RFAILED);
   }

   matchFlag = FALSE;

   for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)
   {
      if ((assocCb = itGlobalCb.assoc[i]) != (ItAssocCb *)NULLP)
      {
         pspCb = assocCb->owner;
         if ((pspCb->pspCfg.assocCfg.dstPort == dstPort) &&
             (assocCb->sctSap != (ItSctSapCb *)NULLP) && 
             (assocCb->sctSap->sctCfg.suId == suId))
         {
           /* : First compare with dstAddr, then *
            * compare with dstAddr Lst as dstAddrLst is   *
            * an optional parameter                       */
            for (j = 0; j < dstNAddrLst->nmb; j++)
            {
               addrA = &(dstNAddrLst->nAddr[j]);
               if (itAcCmpNetAddr(addrA, &(pspCb->pspCfg.assocCfg.priDstAddr))
                                                                      == TRUE)
               {
                  matchFlag   = TRUE;
                  assocIdx    = i;
                  break;
               }
               for (k = 0; k < pspCb->pspCfg.assocCfg.dstAddrLst.nmb; k++)
               {
                  addrB = &(pspCb->pspCfg.assocCfg.dstAddrLst.nAddr[k]);
                  if (itAcCmpNetAddr(addrA, addrB) == TRUE)
                  {
                     matchFlag   = TRUE;
                     assocIdx    = i;
                     break;
                  }
               }
               if (matchFlag == TRUE) 
               {
                  break;
               }
            }            
         }
      }
      if (matchFlag == TRUE) 
      {
         break;
      }
   }

   if (matchFlag == TRUE)
   {
      switch (assocParams->type)
      {
         case SCT_ASSOC_IND_INIT:
         {
            /* If no of incoming or outoging streams are found to be less 
             * than 2 then return status as SCT_NOK */

            if ((assocParams->t.initParams.inStrms < IT_MIN_STRMS)
                || (assocParams->t.initParams.outStrms < IT_MIN_STRMS)) 
            {
               /* it009.106 - Added type of service param to itLiAssocRsp */
#ifdef SCT3
               itLiAssocRsp(suId, assocParams, pspCb->pspCfg.assocCfg.tos, 
                            SCT_NOK);
#else
               itLiAssocRsp(suId, assocParams, SCT_NOK);
#endif /* SCT3 */
               RETVALUE(RFAILED);
            }
            locAssocParm.t.initParams.outStrms = 
               (U16)((pspCb->pspCfg.assocCfg.locOutStrms <= 
                assocParams->t.initParams.inStrms) ? 
               pspCb->pspCfg.assocCfg.locOutStrms : 
               assocParams->t.initParams.inStrms);

            if (assocCb != (ItAssocCb *)NULLP)
            {
               assocCb->outStrms = locAssocParm.t.initParams.outStrms;
            }

            locAssocParm.t.initParams.inStrms = 
               assocParams->t.initParams.outStrms;

            remAddrLst = &assocParams->t.initParams.localAddrLst;
            if ((assocCb->sctSap->sctCfg.srcAddrLst.nmb > 0)&&
                (!((assocCb->sctSap->sctCfg.srcAddrLst.nmb == 1)&&
                   (assocCb->sctSap->sctCfg.srcAddrLst.nAddr[0].type ==
                       CM_NETADDR_IPV4)&&
                   (assocCb->sctSap->sctCfg.srcAddrLst.nAddr[0].u.ipv4NetAddr == 0))))
            {
               /* source addresses configured: filter the list from SCTP */
               locAddrLst = &assocCb->sctSap->sctCfg.srcAddrLst;
            }
            else
            {
               /* 
                * source addresses not configured, don't filter the list 
                * from SCTP 
                */
               locAddrLst = remAddrLst;
               chgAddrLst = FALSE; 
            }
            break;
         }
         case SCT_ASSOC_IND_COOKIE:
         {
            /* Copy spAssocId into assocCb */
            assocCb->assocSta->spAssocId = 
               assocParams->t.cookieParams.spAssocId;

            locAssocParm.t.cookieParams.suAssocId = assocIdx;

            locAddrLst = &pspCb->pspCfg.assocCfg.dstAddrLst;
            remAddrLst = &assocParams->t.cookieParams.peerAddrLst;
            break;
         }
         default:
            break;
      }

      cmAddrLst.nmb = 0;
      if (chgAddrLst)
      {
         for (i = 0; i < locAddrLst->nmb; i++)
         {
            addrA = &(locAddrLst->nAddr[i]);
            for (j = 0; j < remAddrLst->nmb; j++)
            {
               addrB = &(remAddrLst->nAddr[j]);
               if (itAcCmpNetAddr(addrA, addrB) == TRUE)
               {
                  (Void) cmMemcpy((U8 *)&(cmAddrLst.nAddr[cmAddrLst.nmb]), 
                                  (U8 *)&(locAddrLst->nAddr[i]), 
                                  sizeof(CmNetAddr));
                  cmAddrLst.nmb++;
               }
            }
         }
      }

      switch (assocParams->type)
      {
         case SCT_ASSOC_IND_INIT:
            /* - update address if necessary 
               use information from LI
            */
            if ((chgAddrLst) && 
               (!((cmAddrLst.nmb == remAddrLst->nmb) && 
               (cmAddrLst.nmb == locAddrLst->nmb))))
            {
                 cmMemcpy((U8 *)&assocCb->sctSap->sctCfg.srcAddrLst, 
                          (U8 *)&locAssocParm.t.initParams.localAddrLst, 
                          sizeof(SctNetAddrLst));
                  
            /* Status indication: PSP state change */
            IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
            itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
            itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS; 
            itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_SRCADDRLST_CHG;
            itGlobalCb.mgmt.t.usta.alarm.cause  = LIT_CAUSE_PEER_ASSOC_PARAMS;
            itGlobalCb.mgmt.t.usta.s.pspId       = assocCb->owner->pspCfg.pspId;
            itGlobalCb.mgmt.t.usta.t.aspm.sctSuId = 
                                                   assocCb->sctSap->sctCfg.suId;
                    
            (Void) itMiStaIndM(&itGlobalCb.mgmt); 
#ifdef ZV
            /* Update sctCfg.srcAddrLst */
            zvRTUpd(CMPFTHA_ACTN_MOD, ZV_SCTSAPCB,
                         CMPFTHA_UPDTYPE_NORMAL, (Void *) assocCb->sctSap,
                         NULLP);
#endif

            }
            break;
         case SCT_ASSOC_IND_COOKIE:
            /* - we should return whatever we received from LI
               In addition, the two lists must be same at this point

               1. assocParams->t.cookieParams.peerAddrLst (from peer)
               2. pspCb->pspCfg.assocCfg.dstAddrLst (local configuration)
            */
            if (!((cmAddrLst.nmb == remAddrLst->nmb) && 
                  (cmAddrLst.nmb == locAddrLst->nmb)))
            {
               cmMemcpy((U8 *)&pspCb->pspCfg.assocCfg.dstAddrLst,
                        (U8 *)remAddrLst, sizeof(SctNetAddrLst));

               /* Status indication: PSP state change */
               IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
               itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
               itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS; 
               itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_DSTADDRLST_CHG;
               itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_PEER_ASSOC_PARAMS;
               itGlobalCb.mgmt.t.usta.s.pspId    = assocCb->owner->pspCfg.pspId;
               itGlobalCb.mgmt.t.usta.t.aspm.sctSuId = 
                                                   assocCb->sctSap->sctCfg.suId;
                       
               (Void) itMiStaIndM(&itGlobalCb.mgmt); 
#ifdef ZV
               /* Sync the dstAddr change */
               zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSPCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) pspCb, NULLP);
#endif
            }
            /* - change the primary address if necessary 
               we always assume that the first address from peer is
               its primary address */
            if (itAcCmpNetAddr(&pspCb->pspCfg.assocCfg.priDstAddr,
                              &(remAddrLst->nAddr[0])) == FALSE)
            {
               cmMemcpy((U8 *)&pspCb->pspCfg.assocCfg.priDstAddr,
                        (U8 *)&(remAddrLst->nAddr[0]), sizeof(CmNetAddr));

               /* Status indication: PSP state change */
               IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
               itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
               itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS; 
               itGlobalCb.mgmt.t.usta.alarm.event  = LIT_EVENT_PRIDSTADDR_CHG;
               itGlobalCb.mgmt.t.usta.alarm.cause = LIT_CAUSE_PEER_ASSOC_PARAMS;
               itGlobalCb.mgmt.t.usta.s.pspId    = assocCb->owner->pspCfg.pspId;
               itGlobalCb.mgmt.t.usta.t.aspm.sctSuId = 
                                                assocCb->sctSap->sctCfg.suId;
                       
               (Void) itMiStaIndM(&itGlobalCb.mgmt); 
#ifdef ZV
               /* Sync the primary dstAddr change */
               zvRTUpd(CMPFTHA_ACTN_MOD, ZV_PSPCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) pspCb, NULLP);
#endif
            }
            break;
         default:
            break;
      }
#ifdef ZV
      /* Sync the assocCb before sending response */
      zvRTUpd(CMPFTHA_ACTN_MOD, ZV_ASSOCCB,
                         CMPFTHA_UPDTYPE_NORMAL, (Void *) assocCb, NULLP);
#endif
      /* it009.106 - Added type of service param to itLiAssocRsp */
#ifdef SCT3
      itLiAssocRsp(suId, &locAssocParm, pspCb->pspCfg.assocCfg.tos, SCT_OK);
#else
      itLiAssocRsp(suId, &locAssocParm, SCT_OK);
#endif /* SCT3 */
   }
   else
   {
      /* it009.106 - Added type of service param to itLiAssocRsp */
#ifdef SCT3
      itLiAssocRsp(suId, assocParams, pspCb->pspCfg.assocCfg.tos, SCT_NOK);
#else
      itLiAssocRsp(suId, assocParams, SCT_NOK);
#endif /* SCT3 */
      RETVALUE(RFAILED);
   }
   
   RETVALUE(ROK);
} /* end of itAcAssocInd */


/*
*
*       Fun:   itAcAssocCfm
*
*       Desc:  Called by LMI to confirm establishment of a new association
*              that was previously requested.
*
*       Ret:   Failure: RFAILED
*
*              Success: ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itAcAssocCfm
(
UConnId           suAssocId,  /* service user association identifier */
UConnId           spAssocId,  /* service provider association identifier */
SctNetAddrLst     *dstNAddrLst,  /* list of destination addresses */
U16               dstPort,    /* destination port */
SctStrmId         outStrms    /* number of out streams */
)
#else
PUBLIC S16 itAcAssocCfm (suAssocId, spAssocId, dstNAddrLst, 
                         dstPort, outStrms)
UConnId           suAssocId;  /* service user association identifier */
UConnId           spAssocId;  /* service provider assoc identifier */
SctNetAddrLst     *dstNAddrLst;  /* list of destination addresses */
U16               dstPort;    /* destination port */
SctStrmId         outStrms;   /* number of out streams */
#endif
{
   ItAssocCb      *assocCb;   /* assocation CB */

   TRC2(itAcAssocCfm)
   UNUSED(dstNAddrLst);

#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
      "itAcAssocCfm(suAssocId(%d),spAssocId(%d),dstNAddrLst,dstPort(%d), "
      "outStrms(%d), vsInfo)\n", suAssocId, spAssocId, dstPort, outStrms));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
      "itAcAssocCfm(suAssocId(%ld),spAssocId(%ld),dstNAddrLst,dstPort(%d), "
      "outStrms(%d), vsInfo)\n", suAssocId, spAssocId, dstPort, outStrms));
#endif
#ifndef DEBUGP
   UNUSED(dstPort);
#endif

   assocCb = itGlobalCb.assoc[suAssocId];

   itTcStopTimer(&assocCb->tmrPrim);
   assocCb->assocSta->spAssocId = spAssocId;
   assocCb->outStrms = outStrms;

   
#ifdef ZV
   /* Update assoc's spAssocId and outStrms */
   zvRTUpd(CMPFTHA_ACTN_MOD, ZV_ASSOCCB,
                         CMPFTHA_UPDTYPE_NORMAL, (Void *) assocCb, NULLP);
#endif
   RETVALUE(ROK);
} /* end of itAcAssocCfm */


/*
*
*       Fun:   itAcTermInd
*
*       Desc:  Called by LI to indicate that an association has been
*              terminated.
*
*       Ret:   Failure: RFAILED
*
*              Success: ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 itAcTermInd
(
UConnId        suAssocId,      /* association ID */
SctStatus      status          /* SCT SAP status */
)
#else
PUBLIC S16 itAcTermInd (suAssocId, status)
UConnId        suAssocId;     /* association ID */        
SctStatus      status;        /* SCT SAP status */
#endif
{
   ItAssocCb   *assocCb;      /* association CB */
   U16 termEvent;
   TRC2(itAcTermInd)

#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itAcTermInd(suAssocId(%d))\n", suAssocId));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itAcTermInd(suAssocId(%ld))\n", suAssocId));
#endif
   assocCb = itGlobalCb.assoc[suAssocId];

   /* Change state to DOWN */
   if (assocCb->assocSta->hlSt != LIT_ASSOC_DOWN)
   {
      assocCb->sctSap->sctSta.nmbActAssoc--;
      assocCb->assocSta->hlSt = LIT_ASSOC_DOWN;
      /* Cleanup the associated Association ID provided 
         by the service provider */
      assocCb->assocSta->spAssocId = (UConnId)NULLD;
      if (assocCb->assocSta->aspSt != LIT_ASP_DOWN)
      {
         itTcStopTimer(&assocCb->tmrHBeatRX);
         itTcStopTimer(&assocCb->tmrHBeatTX);
      }
#ifdef ZV
      /* Update assoc's hlSt and sctSta */
      zvRTUpd(CMPFTHA_ACTN_MOD, ZV_ASSOCCB,
                         CMPFTHA_UPDTYPE_NORMAL, (Void *) assocCb, NULLP);
      zvRTUpd(CMPFTHA_ACTN_MOD, ZV_SCTSAPCB,
                         CMPFTHA_UPDTYPE_NORMAL, (Void *) assocCb->sctSap, 
                         NULLP);
#endif
      /* it016.106 - Update "unav" statistics. */
#ifdef LITV3
      /* Association unavailable update unavailablity counter. */
      IT_STS_INC_ASSOC_UNAV(assocCb);

      /* Take time stamp when association became unavailable. */
      SGetSysTime(&assocCb->ticksUnav);
#endif /* LITV3 */
   }
   /* added to provide proper status indication 
    * to the layer manager */
  switch (status)
  {
     case SCT_STATUS_SHUTDOWN:
        termEvent = LIT_CAUSE_REMOTE_SHUTDOWN;
        break;
     case SCT_STATUS_ABRT:
        termEvent = LIT_CAUSE_REMOTE_ABORT;
        break;
     case SCT_STATUS_COMM_LOST:
        termEvent = LIT_CAUSE_COMM_LOST;
        break;
     case SCT_STATUS_RESTART:
        termEvent = LIT_CAUSE_SCT_RESTART;
        break;
     case SCT_STATUS_SHUTDOWN_CMPLT:
        termEvent = LIT_CAUSE_SHUTDOWN_CMPLT;
        break;
     default:
        termEvent = LIT_CAUSE_LOCAL_SCTP_PROCERR;
  }
   (Void) itAcAssocEvt(assocCb, termEvent);
   
   RETVALUE(ROK);
} /* end of itAcTermInd */


/*
*
*       Fun:   itAcTermCfm
*
*       Desc:  Called by LI to indicate that an earlier association
*              termination request has been completed.
*
*       Ret:   Failure: RFAILED
*
*              Success: ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itAcTermCfm
(
UConnId          suAssocId    /* service user association ID */     
)                                          
#else
PUBLIC S16 itAcTermCfm (suAssocId)
UConnId          suAssocId;   /* service user association ID */ 
#endif
{
   ItAssocCb     *assocCb;    /* association CB */

   TRC2(itAcTermCfm)

#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
      "itAcTermCfm(suAssocId(%d))\n", suAssocId));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
      "itAcTermCfm(suAssocId(%ld))\n", suAssocId));
#endif
   assocCb = itGlobalCb.assoc[suAssocId];
   
   /* Change state to DOWN */
   if (assocCb->assocSta->hlSt != LIT_ASSOC_DOWN)
   {
      assocCb->sctSap->sctSta.nmbActAssoc--;
      assocCb->assocSta->hlSt = LIT_ASSOC_DOWN;
      /* Cleanup the associated Association ID provided 
         by the service provider */
      assocCb->assocSta->spAssocId = (UConnId)NULLD;
      if (assocCb->assocSta->aspSt != LIT_ASP_DOWN)
      {
         itTcStopTimer(&assocCb->tmrHBeatRX);
         itTcStopTimer(&assocCb->tmrHBeatTX);
      }
#ifdef ZV
      /* Update assoc's hlSt and sctSta */
      zvRTUpd(CMPFTHA_ACTN_MOD, ZV_SCTSAPCB,
                   CMPFTHA_UPDTYPE_SYNC, (Void *) assocCb->sctSap,
                   NULLP);
      zvRTUpd(CMPFTHA_ACTN_MOD, ZV_ASSOCCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) assocCb, NULLP);
#endif
      /* it016.106 - Update "unav" statistics. */
#ifdef LITV3
      /* Association unavailable update unavailablity counter. */
      IT_STS_INC_ASSOC_UNAV(assocCb);

      /* Take time stamp when association became unavailable. */
      SGetSysTime(&assocCb->ticksUnav);
#endif /* LITV3 */
   }

   /* Indicate change of state to PSM block */
   (Void) itAcAssocEvt(assocCb, LIT_EVENT_TERM_CONFIRM);
   
   RETVALUE(ROK);
} /* end of itAcTermCfm */


/*
*
*       Fun:   itAcStaInd
*
*       Desc:  Called by LI to indicate change in state of an association.
*
*       Ret:   Failure:
*
*              Success:
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 itAcStaInd
(
UConnId          suAssocId,   /* service user association ID */
UConnId          spAssocId,   /* service Provider association ID */
SctStatus        status,      /* status */                     
SctCause         cause,       /* cause */                      
Buffer           **mBuf       /* pointer to pointer to message */
)
#else
PUBLIC S16 itAcStaInd (suAssocId, spAssocId, status, cause, mBuf)
UConnId          suAssocId;   /* service user association ID */
UConnId          spAssocId;   /* service Provider association ID */
SctStatus        status;      /* status */                     
SctCause         cause;       /* cause */                      
Buffer           **mBuf;      /* pointer to pointer to message */                    
#endif
{
   ItAssocCb     *assocCb;    /* association CB */
 
   TRC2(itAcStaInd)
#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itAcStaInd(suAssocId(%d), spAssocId(%d), status(%d),"
          " cause(%d), mbuf)\n", 
          suAssocId, spAssocId, status, cause));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itAcStaInd(suAssocId(%ld), spAssocId(%ld), status(%d),"
          " cause(%d), mbuf)\n", 
          suAssocId, spAssocId, status, cause));
#endif
   if (mBuf != (Buffer **)NULLP)
   {
      IT_DROPDATA(*mBuf);
   } 

   assocCb = itGlobalCb.assoc[suAssocId];
   
   switch (status)
   {
      /* following 2 cases fall through */
      case SCT_STATUS_COMM_UP:
      case SCT_STATUS_NET_UP:
      {
         if (assocCb->assocSta->hlSt == LIT_ASSOC_DOWN)
         {
            assocCb->sctSap->sctSta.nmbActAssoc++;
            /* Change state to ACTIVE */
            assocCb->assocSta->hlSt = LIT_ASSOC_ACTIVE;
            assocCb->assocSta->spAssocId = spAssocId;

            /* Send alarm to Layer Manager */
            IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
            itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
            itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS; 
            itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_ESTABLISH_OK;
            itGlobalCb.mgmt.t.usta.alarm.cause     = cause;
            itGlobalCb.mgmt.t.usta.s.pspId         = IT_ASSOC2PSPID(suAssocId);
            itGlobalCb.mgmt.t.usta.t.aspm.sctSuId  = 
                                                   assocCb->sctSap->sctCfg.suId;
                    
            (Void) itMiStaIndM(&itGlobalCb.mgmt); 
			
            /* it015.106 - Moved the call to zvRTUpd for assocCb
             * within the switch case handling. Call to itAcAssocEvt is 
             * not required because this function does processing only 
             * when association which is going down. */
/* nmbActAssoc update */
#ifdef ZV
            /* Update sctSta */
            zvRTUpd(CMPFTHA_ACTN_MOD, ZV_SCTSAPCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) assocCb->sctSap,
                         NULLP);
            /* Update assoc's hlSt, spAssocId and sctSta */
            zvRTUpd(CMPFTHA_ACTN_MOD, ZV_ASSOCCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) assocCb, NULLP);
#endif
           
            /* it016.106 - Update "durUnav" statistics. */
#ifdef LITV3
            if (assocCb->ticksUnav)
            {
               S16         ret;      /* return value */
               Ticks       curTime;  /* current timestamp */
               Ticks       dur;      /* time duration */

               ret = SGetSysTime(&curTime);
               if (ret != ROK)
               {
#if (ERRCLASS & ERRCLS_DEBUG)
                  ITLOGERROR(ERRCLS_DEBUG, EITXXX, (ErrVal) ret, 
                             "itAcStaInd: SGetSysTime failed");
#endif /* ERRCLS_DEBUG */
               }
               else
               {
                  dur = curTime - assocCb->ticksUnav;
                  IT_STS_UPD_ASSOC_DUR_UNAV(assocCb, dur);
               }
               assocCb->ticksUnav = 0;
            }
#endif /* LITV3 */

         }
         break;
      }
      /* it015.106 - Deleted the case for SCT_STATUS_COMM_LOST, because this 
       * status is received only when SCTP sends SctTermInd to M3UA. Added 
       * SCT_STATUS_SND_FAIL case as earlier this case was falling through to 
       * default leg. */
      /* it023.106 - Changes to not mark the association as down on receiving
       * SCT_STATUS_SND_FAIL. */
      case SCT_STATUS_SND_FAIL:
      {
         /* Send alarm to Layer Manager */
         /* Send alarm to Layer Manager */
         IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
         itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
         itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS; 
         itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_SCT_SEND_FAIL;
         itGlobalCb.mgmt.t.usta.alarm.cause     = cause;
         itGlobalCb.mgmt.t.usta.s.pspId         = IT_ASSOC2PSPID(suAssocId);
         itGlobalCb.mgmt.t.usta.t.aspm.sctSuId  = 
                                                assocCb->sctSap->sctCfg.suId;
                 
         (Void) itMiStaIndM(&itGlobalCb.mgmt); 

         break;
      }
      default:
      {
         ITZVUPDPEER();
         RETVALUE(RFAILED);
      }
   }

   /* it015.106 - Moved the call to zvRTUpd for assocCb and itAcAssocEvt 
    * within the switch case handling. */
   ITZVUPDPEER();

   RETVALUE(ROK);
} /* end of itAcStaInd */


/*
*
*       Fun:   itAcFlcInd
*
*       Desc:  Called by LI to indicate a change of flow control status of
*              an association.
*
*       Ret:   Failure:
*
*              Success:
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itAcFlcInd
(
UConnId        suAssocId,     /* service user association ID */
Reason         reason         /* reason */
)
#else
PUBLIC S16 itAcFlcInd (suAssocId, reason)
UConnId        suAssocId;     /* service user association ID */ 
Reason         reason;        /* reason */                      
#endif
{
   ItAssocCb   *assocCb;      /* association CB */

   TRC2(itAcFlcInd)

#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
      "itAcFlcInd(suAssocId(%d), reason(%d))\n", suAssocId, reason));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
      "itAcFlcInd(suAssocId(%ld), reason(%d))\n", suAssocId, reason));
#endif
   assocCb = itGlobalCb.assoc[suAssocId];
   
   switch (reason)
   {
      case SCT_FLC_DROP:
         /* Send alarm to Layer Manager */
         IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
         itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
         itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS; 
         itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_FLC_DROP;
         itGlobalCb.mgmt.t.usta.alarm.cause     = reason;
         itGlobalCb.mgmt.t.usta.s.pspId         = assocCb->owner->pspCfg.pspId;
         itGlobalCb.mgmt.t.usta.t.aspm.sctSuId  = assocCb->sctSap->sctCfg.suId;
   
         (Void) itMiStaIndM(&itGlobalCb.mgmt); 
   
         assocCb->assocSta->hlSt = LIT_ASSOC_CONGDROP;
         (Void) itCcCongStart(assocCb);
         break;
      
      /* following 2 cases fall through */
      case SCT_FLC_START:
      case SCT_FLC_ACTIVE:
         assocCb->assocSta->hlSt = LIT_ASSOC_CONGSTART;
         (Void) itCcCongStart(assocCb);
         break;
      
      /* following 2 cases fall through */
      case SCT_FLC_STOP:
      case SCT_FLC_INACTIVE:
         assocCb->assocSta->hlSt = LIT_ASSOC_ACTIVE;
         (Void) itCcCongEnd(assocCb);
         break;
      default:
         break;
   }

   RETVALUE(ROK);
} /* end of itAcFlcInd */


/*
*
*       Fun:   itAcReleaseSap
*
*       Desc:  Searches the list of ACBs in the GCB for all established
*              associations related to the SAP. Calls itLiSctTermReq for
*              these associations.
*
*       Ret:   Failure:
*
*              Success:
*
*       Notes: Called by LI to force termination of all associations on
*              an SCT SAP.
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itAcReleaseSap
(
SuId        suId              /* SAP ID */
)
#else
PUBLIC S16 itAcReleaseSap (suId)
SuId        suId;             /* SAP ID */
#endif
{
   ItAssocCb      *assocCb;   /* association CB */
   U32            i;          /* loop index */
   S16            ret;        /* return value */

   TRC2(itAcReleaseSap)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, "itAcReleaseSap(suId)\n"));

   for (i = 0; i < itGlobalCb.maxNmbAssoc; i++)
   {
      if ((assocCb = itGlobalCb.assoc[i]) != (ItAssocCb *)NULLP)
      {
         if ((assocCb->owner != (ItPspCb *)NULLP) &&
             (assocCb->owner->pspCfg.pspId != IT_LOCAL_PSPID) &&
             (assocCb->sctSap != (ItSctSapCb *) NULLP) && 
                               (assocCb->sctSap->sctCfg.suId == suId))
         {
            if (assocCb->assocSta->hlSt != LIT_ASSOC_DOWN)
            {
               /* Call ItLiSctTermReq */
               /* it004.106 - Added the abrtFlg param in itLiTermReq even if 
                * IT_ABORT_ASSOC not defined, set this param as TRUE always */
               /* Send a Termination request with Abort TRUE */
               if ((ret = itLiTermReq(assocCb, TRUE)) != ROK)
               {
                  RETVALUE(ret);
               }
               /* it004.106 - The ifdef for IT_ABORT_ASSOC not required, as
                * the association is being aborted always. */
               /* it001.106 - Patch propagation from previous release
                * Here re-checking if the association state
                * is down or not is necessary as if the itLiTermReq
                * is called with abrtFlag = TRUE and if SCTP is tightly
                * coupled the as soon as SCTP receives ABORT it calls back
                * itUiSctTermCfm which markes the association state to 
                * Down and also decreases active association count. So there
                * is a possiblity when the above function returns the
                * association state in its control block may already be
                * zero at that time, although the state never changes inside
                * itLiTermReq */
               /* Change state to DOWN */
               else if (assocCb->assocSta->hlSt != LIT_ASSOC_DOWN)
               {
                  assocCb->sctSap->sctSta.nmbActAssoc--;
                  assocCb->assocSta->hlSt = LIT_ASSOC_DOWN;
                  assocCb->assocSta->readySetupSt = LIT_RDST_DEFAULT;
                  /* Cleanup the associated Association ID provided 
                     by the service provider */
                  assocCb->assocSta->spAssocId = (UConnId)NULLD;
                  /* Stop association-related timers */
                  itTcStopTimer(&assocCb->tmrCong);
                  itTcStopTimer(&assocCb->tmrPrim);
                  if (assocCb->assocSta->aspSt != LIT_ASP_DOWN)
                  {
                     itTcStopTimer(&assocCb->tmrHBeatRX);
                     itTcStopTimer(&assocCb->tmrHBeatTX);
                     (Void) itPsmAspDn(assocCb, FALSE, (Txt *)NULLP, FALSE);
                  }
#ifdef ZV
                  /* Update assoc's hlSt */
                  zvRTUpd(CMPFTHA_ACTN_MOD, ZV_ASSOCCB,
                          CMPFTHA_UPDTYPE_NORMAL, (Void *) assocCb, NULLP);
                  /* sctSta is being updated from ItMiLitCntrlReq */
#endif
                  /* it016.106 - Update "unav" statistics. */
#ifdef LITV3
                  /* Association unavailable update unavailablity counter. */
                  IT_STS_INC_ASSOC_UNAV(assocCb);
            
                  /* Take time stamp when association became unavailable. */
                  SGetSysTime(&assocCb->ticksUnav);
#endif /* LITV3 */
               }

            }
         }
      }
   }

   RETVALUE(ROK);
} /* end of itAcReleaseSap */


/*
*
*       Fun:   itAcDelAssoc
*
*       Desc:  Delete association CB
*
*       Ret:   Failure:
*
*              Success:
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 itAcDelAssoc
(
UConnId        assocId,       /* association ID */
Bool           itAbort        /* abort flag */
)
#else
PUBLIC S16 itAcDelAssoc (assocId, itAbort)
UConnId        assocId;       /* association ID */    
Bool           itAbort;       /* abort flag */        
#endif
{
   ItAssocCb      *assocCb;   /* association control block */
   ItMupMsg       *msg;       /* MUP message */
   ItRegReqCb     *regReqCb;  /* Reg req Cb */

   TRC2(itAcDelAssoc)
#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itAcDelAssoc(assocId(%d), itAbort(%d))\n", assocId, (U8)itAbort));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itAcDelAssoc(assocId(%ld), itAbort(%d))\n", assocId, (U8)itAbort));
#endif
   regReqCb = (ItRegReqCb *)NULLP;
   if ((assocCb = itGlobalCb.assoc[assocId]) != (ItAssocCb *)NULLP)
   {
      /* Check the assoc state */
      if ((itAbort == FALSE) && 
          (assocCb->assocSta->hlSt != LIT_ASSOC_DOWN))
      {
         RETVALUE(RFAILED);
      }

      if (IT_ASSOC2PSPID(assocId) != IT_LOCAL_PSPID)
      {
         while (cmLListLen(&assocCb->congQ) > 0)
         {
            /* Remove message from head of queue */
            msg = (ItMupMsg *)cmLListDelFrm(&assocCb->congQ,
                  cmLListFirst(&assocCb->congQ));
            if (msg != (ItMupMsg *)NULLP)
            {
               IT_DROPDATA(msg->mBuf);
               IT_FREE(sizeof(ItMupMsg), msg);
               itGlobalCb.nmbMsg--;
            }
         }

         /* Delete all pending REG-REQs, if any */
         while (cmLListLen(&assocCb->regReq) > 0)
         {
            regReqCb = (ItRegReqCb *)cmLListDelFrm(&assocCb->regReq,
                  cmLListFirst(&assocCb->regReq));
            if (regReqCb != (ItRegReqCb *)NULLP)
            {
               IT_FREE(sizeof(ItRegReqCb), regReqCb);
            }
         }
        
         /* Stop all association-related timers */
         itTcStopTimer(&assocCb->tmrCong);
         itTcStopTimer(&assocCb->tmrPrim);
         itTcStopTimer(&assocCb->tmrAspm);    
         itTcStopTimer(&assocCb->tmrHBeatTX); 
         itTcStopTimer(&assocCb->tmrHBeatRX);
         itTcStopTimer(&assocCb->tmrDunaSettle);
      } /* End of pspId != IT_LOCAL_PSPID */

      itGlobalCb.assoc[assocId] = (ItAssocCb *)NULLP;
   }

   RETVALUE(ROK);
} /* end of itAcDelAssoc */


/*
*
*       Fun:   itAcAssocEvt
*
*       Desc:  Called from itAcStaInd and itAcStaCfm
*
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itAcAssocEvt
(
ItAssocCb   *assocCb,         /* association control block */
U16         event             /* association-related event */
)
#else
PUBLIC S16 itAcAssocEvt(assocCb, event)
ItAssocCb   *assocCb;         /* association control block */ 
U16         event;            /* association-related event */ 
#endif
{
    ItPspCb  *pspCb;           /* PSP control block */
    U16      cause;
#ifdef ITASP
    U32      AspSt = LIT_ASP_UNSUPP;
#endif

    TRC2(itAcAssocEvt)

    ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
      "itAcAssocEvt(assocCb, event(%d))\n", event));

    pspCb = assocCb->owner;
    switch (event)
    {
        case LIT_CAUSE_REMOTE_SHUTDOWN:
        case LIT_CAUSE_REMOTE_ABORT:
        case LIT_CAUSE_COMM_LOST:
        case LIT_CAUSE_SCT_RESTART:
        case LIT_CAUSE_LOCAL_SCTP_PROCERR:
        case LIT_CAUSE_SHUTDOWN_CMPLT:
            cause = event;
            break;
        case LIT_EVENT_ASSOC_INHIBIT:
            cause = LIT_CAUSE_ASSOC_INHIBIT; 
            break;
        case LIT_EVENT_TERM_CONFIRM:
            cause = LIT_CAUSE_LOCAL_SHUTDOWN; 
            break;
        case LIT_EVENT_HBEAT_LOST:
            cause = LIT_CAUSE_M3UA_HBEAT_LOST; 
            break;
        /* it023.106 - Deleted the case of LIT_EVENT_SCT_SEND_FAIL
        * because association is not being marked down in such a case. */
        default:
            cause = LCM_CAUSE_UNKNOWN; 
            break;
    }
    
    if (assocCb->assocSta->hlSt == LIT_ASSOC_DOWN)
    {
        /* Stop association-related timers */
        itTcStopTimer(&assocCb->tmrCong);
        itTcStopTimer(&assocCb->tmrPrim);
        if (cause != LCM_CAUSE_UNKNOWN)
        {
            /* Send Status Indication to Layer Management */
            IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
            itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
            itGlobalCb.mgmt.t.usta.alarm.category  = LCM_CATEGORY_INTERFACE; 
            itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_SCT_COMM_DOWN; 
            itGlobalCb.mgmt.t.usta.alarm.cause     = cause;
            itGlobalCb.mgmt.t.usta.s.pspId         = pspCb->pspCfg.pspId;
            itGlobalCb.mgmt.t.usta.t.aspm.sctSuId  = assocCb->sctSap->sctCfg.suId;

            (Void) itMiStaIndM(&itGlobalCb.mgmt); 
        }

        (Void) itPsmAspDn(assocCb, FALSE, (Txt *)NULLP, FALSE);
    }
    
    itTerminateAssoc(assocCb);
    
#ifdef ITASP
     if ((event == LIT_CAUSE_REMOTE_SHUTDOWN) || (event == LIT_EVENT_HBEAT_LOST)
    	||(event == LIT_CAUSE_REMOTE_ABORT)||(event == LIT_CAUSE_COMM_LOST)
        ||(event == LIT_CAUSE_SCT_RESTART))
   {
        if (IT_AUTO_CLIENTSIDE)
        {
            itSgReconnect(pspCb->pspCfg.pspId);			
        }
   }
#endif
   RETVALUE(ROK);
} /* end of itAcAssocEvt */


/*
*
*       Fun:   itAcChkReconfig
*
*       Desc:  Called by PSM when a PSP is reconfigured. Checks the 
*              association configuration.
*
*       Ret:   Failure:
*
*              Success:
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itAcChkReconfig
(
ItAssocCfg     *oldCfg,       /* old configuration */
ItAssocCfg     *newCfg,       /* new configuration */
ItPspCb        *pspCb         /* pspCB parameter */
)
#else
PUBLIC S16 itAcChkReconfig (oldCfg, newCfg, pspCb)
ItAssocCfg     *oldCfg;       /* old configuration */  
ItAssocCfg     *newCfg;       /* new configuration */  
ItPspCb        *pspCb;        /* PSP Control Block */
#endif
{
   U32         i;             /* loop index */
   U32         j;             /* loop index */
   Bool        allAssocDown;  /* All assocs of this PSP are down or not? */

   TRC2(itAcChkReconfig)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itAcChkReconfig(oldCfg, newCfg)\n"));


      /* Reconfiguration of Destination address when the association is down */

   /* if all assoc is not down then parameters can not be changed */ 
   allAssocDown = TRUE;
   for (j = 0; j < LIT_MAX_SEP; j++)
   {
      if (pspCb->assoc[j].assocSta->hlSt != LIT_ASSOC_DOWN)
      {
         allAssocDown = FALSE;
         break;
      }
   }

   if (allAssocDown == FALSE) /* Reconf of params checked inside is not allwd */
   {
      /* dstPort & priDstAddr.type will be changed only if all assoc are down */
      if (oldCfg->dstPort != newCfg->dstPort)
      {
         RETVALUE(RFAILED);
      }
      
      if (oldCfg->priDstAddr.type != newCfg->priDstAddr.type)
      {
         RETVALUE(RFAILED);
      }
   
      switch (oldCfg->priDstAddr.type)
      {
         case CM_NETADDR_IPV4:
            if (oldCfg->priDstAddr.u.ipv4NetAddr !=
                newCfg->priDstAddr.u.ipv4NetAddr)
            {
               RETVALUE(RFAILED);
            }
            break;
         case CM_NETADDR_IPV6:
            for (i = 0; i < CM_IPV6ADDR_SIZE; i++)
            {
               if (oldCfg->priDstAddr.u.ipv6NetAddr[i] !=
                   newCfg->priDstAddr.u.ipv6NetAddr[i])
               {
                  RETVALUE(RFAILED);
               }
            }
            break;
         default:
            RETVALUE(RFAILED);
      }

      if (oldCfg->dstAddrLst.nmb != newCfg->dstAddrLst.nmb)
      {
         RETVALUE(RFAILED);
      }
   
      for (i = 0; i < oldCfg->dstAddrLst.nmb; i++)
      {
         if (oldCfg->dstAddrLst.nAddr[i].type !=
             newCfg->dstAddrLst.nAddr[i].type)
         {
            RETVALUE(RFAILED);
         }
      /* this check added to allow re-configuration of
            Destination address when the association is down */
         /* if all assoc is not down then dstAddrList can not be changed */ 
         switch (oldCfg->dstAddrLst.nAddr[i].type)
         {
            case CM_NETADDR_IPV4:
               if (oldCfg->dstAddrLst.nAddr[i].u.ipv4NetAddr !=
                   newCfg->dstAddrLst.nAddr[i].u.ipv4NetAddr)
               {
                  RETVALUE(RFAILED);
               }
               break;
            case CM_NETADDR_IPV6:
               for (j = 0; j < CM_IPV6ADDR_SIZE; j++)
               {
                  if (oldCfg->dstAddrLst.nAddr[i].u.ipv6NetAddr[j] !=
                      newCfg->dstAddrLst.nAddr[i].u.ipv6NetAddr[j])
                  {
                     RETVALUE(RFAILED);
                  }
               }
               break;
            default:
               RETVALUE(RFAILED);
            break;
         }
      }
      
      
      if (oldCfg->locOutStrms != newCfg->locOutStrms)
      {
         RETVALUE(RFAILED);
      }

      /* it009.106 - Reconfiguration of Type Of Service not allowed */
#ifdef SCT3
      if (oldCfg->tos != newCfg->tos)
      {
         RETVALUE(RFAILED);
      }
#endif /* SCT3 */
   } /* End of if (all Assocs down == FALSE )  check */

   RETVALUE(ROK);
} /* end of itAcChkReconfig */


/*
*
*       Fun:   itAcPrimTimeout
*
*       Desc:  Called by TC when the primitive timer expires.
*
*       Ret:   Failure:
*
*              Success:
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itAcPrimTimeout
(
ItAssocCb      *assocCb       /* association control block */
)
#else
PUBLIC S16 itAcPrimTimeout (assocCb)
ItAssocCb      *assocCb;      /* association control block */
#endif
{
   TRC2(itAcPrimTimeout)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itAcPrimTimeout(assocCb)\n"));

   /* Send alarm to Layer Manager */
   IT_ZERO(&itGlobalCb.mgmt, sizeof(ItMgmt))   
   itGlobalCb.mgmt.hdr.elmId.elmnt        = STITPSP; 
   itGlobalCb.mgmt.t.usta.alarm.category  = LIT_CATEGORY_STATUS; 
   itGlobalCb.mgmt.t.usta.alarm.event     = LIT_EVENT_ESTABLISH_FAIL;
   itGlobalCb.mgmt.t.usta.alarm.cause     = LCM_CAUSE_TMR_EXPIRED;
   itGlobalCb.mgmt.t.usta.s.pspId         = assocCb->owner->pspCfg.pspId;
   itGlobalCb.mgmt.t.usta.t.aspm.sctSuId  = assocCb->sctSap->sctCfg.suId;
   
   (Void) itMiStaIndM(&itGlobalCb.mgmt); 

   RETVALUE(ROK);
} /* end of itAcPrimTimeout */


/*
*
*       Fun:   itLscCfg
*
*       Desc:  Configure load sharing CB
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLscCfg
(
U8          lsType,           /* load share type */
ItPsCb      *psCb,            /* PS control block */
ItPsCb      *lpsCb,           /* Local PS control block */
U16         *chldIndx         /* Child PS control block index */
)
#else
PUBLIC S16 itLscCfg (lsType, psCb, lpsCb, chldIndx)
U8          lsType;           /* load share type */          
ItPsCb      *psCb;            /* PS control block */ 
ItPsCb      *lpsCb;           /* Local PS control block */
U16         *chldIndx;        /* Child PS control block index */
#endif
{
   S16      ret;              /* return value */

   TRC2(itLscCfg)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
            "itLscCfg(lsType(%d), psCb)\n", lsType));

   ret = ROK;

   switch (lsType)
   {
      case LIT_LOADSH_RNDROBIN:
      {
         /* - Added new input parameters for pointer to Local PS CB
          * and Child PS CB Index, to be used at ASP/IPSP */
         ret = itLscCfgRndRobin(psCb, lpsCb, chldIndx);
         break;
      }
      case LIT_LOADSH_SLS:
      {
         /* - Added new input parameters for pointer to Local PS CB
          * and Child PS CB Index, to be used at ASP/IPSP */
         ret = itLscCfgBySls(psCb, lpsCb, chldIndx);
         break;
      }
      default:
         break;
   }

   RETVALUE(ret);
} /* end of itLscCfg */


/*
*
*       Fun:   itLscCfgRndRobin
*
*       Desc:  Configure load sharing type round robin
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLscCfgRndRobin
(
ItPsCb      *psCb,            /* PS control block */
ItPsCb      *lpsCb,           /* Local PS control block */
U16         *chldIndx         /* Child PS control block index */
)
#else
PUBLIC S16 itLscCfgRndRobin (psCb, lpsCb, chldIndx)
ItPsCb      *psCb;            /* PS control block */ 
ItPsCb      *lpsCb;           /* Local PS control block */
U16         *chldIndx;        /* Child PS control block index */
#endif
{
   ItLscRndRbnCb  *lsCb;      /* load share control block */
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   U16            indx;       /* Child PS CB index */
#endif

   TRC2(itLscCfgRndRobin)
#if !(defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   UNUSED(lpsCb);
   UNUSED(chldIndx);
#endif /* !(defined(ITASP) && defined(OG_RTE_ON_LPS_STA)) */

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
                        "itLscCfgRndRobin(psCb)\n"));
   /* - At ASP/IPSP, a new Child PS has to be allocated for the
    * Loadshare CB if OG_RTE_ON_LPS_STA is defined */
#if !(defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   if (psCb == NULLP)
      RETVALUE(RFAILED);

   /* Allocate memory for new loadsharing context control block */
   IT_ALLOC(sizeof(ItLscRndRbnCb), psCb->lsCb)

   if (psCb->lsCb == (PTR)NULLP)
   {
      RETVALUE(RFAILED);
   }

   lsCb = &psCb->lsCb->rndRbn;
#else /* ITASP && OG_RTE_ON_LPS_STA */
   if ((lpsCb == NULLP) || (psCb == NULLP))
      RETVALUE(RFAILED);

   /* Allocate memory for Child PS CB */
   indx = psCb->nmbChldPs;
   IT_ALLOC(sizeof(ItChldPsCb), psCb->chldPsLst[indx])
   
   if (psCb->chldPsLst[indx] == NULLP)
   {
      RETVALUE(RFAILED);
   }
   psCb->nmbChldPs++;

   psCb->chldPsLst[indx]->lpsId = lpsCb->psCfg.psId;

   /* Allocate memory for loadsharing context block */
   IT_ALLOC(sizeof(ItLscRndRbnCb), psCb->chldPsLst[indx]->lsCb)

   if (psCb->chldPsLst[indx]->lsCb == NULLP)
   {
      /* Delete Child PS CB */
      IT_FREE(sizeof(ItChldPsCb), psCb->chldPsLst[indx])
      RETVALUE(RFAILED);
   }

   lsCb = &psCb->chldPsLst[indx]->lsCb->rndRbn;
   if (chldIndx != NULLP)
   {
      *chldIndx = indx;
   }
#endif /* ITASP && OG_RTE_ON_LPS_STA */

   lsCb->cluster = psCb;

   /* Initialize last peer to one past last available assoc */
   lsCb->lastId = itGlobalCb.maxNmbAssoc;

   /* Initialize hash list of context blocks */
   /* it001.106 - Changed the Hash key type to CM_HASH_KEYTYPE_U32MOD from 
    * CM_HASH_KEYTYPE_DEF for performance improvement. */
   cmHashListInit(&lsCb->xudtLst, IT_MAX_XUDT_CTX, 
                  sizeof(ItLscCtxHdr), FALSE, CM_HASH_KEYTYPE_U32MOD, 
                  itGlobalCb.itInit.region, itGlobalCb.itInit.pool);

   RETVALUE(ROK);
} /* end of itLscCfgRndRobin */


/*
*
*       Fun:   itLscCfgBySls
*
*       Desc:  Configure load sharing type by sls
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLscCfgBySls
(
ItPsCb      *psCb,            /* PS control block */
ItPsCb      *lpsCb,           /* Local PS control block */
U16         *chldIndx         /* Child PS control block index */
)
#else
PUBLIC S16 itLscCfgBySls (psCb, lpsCb, chldIndx)
ItPsCb      *psCb;            /* PS control block */ 
ItPsCb      *lpsCb;           /* Local PS control block */
U16         *chldIndx;        /* Child PS control block index */
#endif
{
   U16          i;            /* loop index */
   ItLscSlsCb  *lsCb;         /* load share control block */
   U16         maxSls;        /* Total number of SLS contexts */
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   U16         indx;          /* Child PS CB index */
#endif

   TRC2(itLscCfgBySls)
#if !(defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   UNUSED(lpsCb);
   UNUSED(chldIndx);
#endif /* !(defined(ITASP) && defined(OG_RTE_ON_LPS_STA)) */

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
                        "itLscCfgBySls(psCb)\n"));

   maxSls = NULLD;

   /* - At ASP/IPSP, a new Child PS has to be allocated for the
    * Loadshare CB if OG_RTE_ON_LPS_STA is defined */
#if !(defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   if (psCb == NULLP)
      RETVALUE(RFAILED);

   /* Allocate memory for loadsharing context block */
   IT_ALLOC(sizeof(ItLscSlsCb), psCb->lsCb)

   if (psCb->lsCb == NULLP)
   {
      RETVALUE(RFAILED);
   }

   lsCb = &psCb->lsCb->sls;
#else /* ITASP && OG_RTE_ON_LPS_STA */
   if ((lpsCb == NULLP) || (psCb == NULLP))
      RETVALUE(RFAILED);

   /* Allocate memory for Child Ps CB */
   indx = psCb->nmbChldPs;
   IT_ALLOC(sizeof(ItChldPsCb), psCb->chldPsLst[indx])
   
   if (psCb->chldPsLst[indx] == NULLP)
   {
      RETVALUE(RFAILED);
   }
   psCb->nmbChldPs++;

   psCb->chldPsLst[indx]->lpsId = lpsCb->psCfg.psId;

   /* Allocate memory for loadsharing context block */
   IT_ALLOC(sizeof(ItLscSlsCb), psCb->chldPsLst[indx]->lsCb)

   if (psCb->chldPsLst[indx]->lsCb == NULLP)
   {
      /* Delete Child PS CB */
      IT_FREE(sizeof(ItChldPsCb), psCb->chldPsLst[indx])
      RETVALUE(RFAILED);
   }

   lsCb = &psCb->chldPsLst[indx]->lsCb->sls;
   if (chldIndx != NULLP)
   {
      *chldIndx = indx;
   }
#endif /* ITASP && OG_RTE_ON_LPS_STA */

   lsCb->cluster = psCb;

   /* Initialise sequence control timer array */
   for (i = 0; i < LIT_MAX_ASSOC; i++)
   {
      lsCb->seqCntrl[i].seqTmrId = i;
      lsCb->seqCntrl[i].lsCb     = lsCb;
      IT_INITTIMER(&lsCb->seqCntrl[i].seqTmr);
   }

   /* Determine total number of SLS contexts for PS network */
   IT_LSC_NUMB_SLS_CTX(psCb, maxSls)

   /* Allocate memory for sls contexts */
   IT_ALLOC((maxSls * sizeof(ItLscSlsCtx)), lsCb->slsLst)

   if (lsCb->slsLst == NULLP)
   {
      /* Delete lsCb */
      /* - At ASP/IPSP, free the Child PS CB if OG_RTE_ON_LPS_STA is
       * defined */
#if !(defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
      IT_FREE(sizeof(ItLscSlsCb), psCb->lsCb)
#else /* ITASP && OG_RTE_ON_LPS_STA */
      IT_FREE(sizeof(ItLscSlsCb), psCb->chldPsLst[indx]->lsCb)
      IT_FREE(sizeof(ItChldPsCb), psCb->chldPsLst[indx])
#endif /* ITASP && OG_RTE_ON_LPS_STA */
      RETVALUE(RFAILED);
   }

   for (i = 0; i < maxSls; i++)
   {
      /* Initialise target Id */
      lsCb->slsLst[i].targetId = LIT_MAX_ASSOC;

      /* Initialise Sequence Control fields */
      lsCb->slsLst[i].seqTmrId = LIT_MAX_ASSOC;
      cmLListInit(&lsCb->slsLst[i].seqMsgQ);
   }

   RETVALUE(ROK);

} /* end of itLscCfgBySls */


/*
*
*       Fun:   itLscDel
*
*       Desc:  Delete load sharing CB
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLscDel
(
U8          lsType,           /* load share type */
ItLscAllCb  *lsCb              /* load share control block */
)
#else
PUBLIC S16 itLscDel (lsType, lsCb)
U8          lsType;           /* load share type */           
ItLscAllCb  *lsCb;             /* load share control block */  
#endif
{
   S16      ret;              /* return value */

   TRC2(itLscDel)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
            "itLscDel(lsType(%d), lsCb)\n", lsType));

   ret = ROK;

   switch (lsType)
   {
      case LIT_LOADSH_RNDROBIN:
      {
         ret = itLscDelRndRobin(&lsCb->rndRbn);
         break;
      }
      case LIT_LOADSH_SLS:
      {
         ret = itLscDelBySls(&lsCb->sls);
         break;
      }
      default:
         break;
   }

   RETVALUE(ret);
} /* end of itLscDel */


/*
*
*       Fun:   itLscDelRndRobin
*
*       Desc:  Delete load sharing CB round robin
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLscDelRndRobin
(                            
ItLscRndRbnCb *lsCb           /* load share control block */  
)
#else
PUBLIC S16 itLscDelRndRobin (lsCb)
ItLscRndRbnCb *lsCb;          /* load share control block */  
#endif
{
   ItLscXudtCtx *xudt;        /* XUDT context */

   TRC2(itLscDelRndRobin)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
            "itLscDelRndRobin(lsCb)\n"));

   /* Empty linked list of xudt contexts */
   while (cmHashListGetNext(&lsCb->xudtLst, 
                            (PTR)NULLP, (PTR *)&xudt) == ROK)
   {
      itTcStopTimer(&xudt->hdr.tmrCtx);

      (Void) cmHashListDelete(&lsCb->xudtLst, (PTR)xudt);

      IT_FREE(sizeof(ItLscXudtCtx), xudt)
   }

   (Void) cmHashListDeinit(&lsCb->xudtLst);

   /* Delete RndRbnCb */
   IT_FREE(sizeof(ItLscRndRbnCb), lsCb)

   RETVALUE(ROK);
} /* end of itLscDelRndRobin */


/*
*
*       Fun:   itLscDelBySls
*
*       Desc:  Delete load sharing CB by SLS
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLscDelBySls
(
ItLscSlsCb  *lsCb             /* load share control block */  
)
#else
PUBLIC S16 itLscDelBySls (lsCb)
ItLscSlsCb  *lsCb;            /* load share control block */  
#endif
{
   U32      i;               /* loop index */
   ItMupMsg *msg;            /* temp message */
   U16      maxSls;          /* Total number of SLS contexts */

   TRC2(itLscDelBySls)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
            "itLscDelBySls(lsCb)\n"));
   
   maxSls = NULLD;
   /* Stop sequence control timers for all PSPs n EndPnts */
   for (i = 0; i < LIT_MAX_ASSOC; i++)
   {
      itTcStopTimer(&lsCb->seqCntrl[i].seqTmr);
   }

   /* Determine total number of SLS contexts for PS network */
   IT_LSC_NUMB_SLS_CTX(lsCb->cluster, maxSls)
   
   /* Empty sequence control message queues */
   for (i = 0; i < maxSls; i++)
   {
      while (cmLListLen(&lsCb->slsLst[i].seqMsgQ) > 0)
      {
         /* remove message from head of list */
         msg = (ItMupMsg *) cmLListDelFrm(&lsCb->slsLst[i].seqMsgQ,
                       cmLListFirst(&lsCb->slsLst[i].seqMsgQ));
         IT_DROPDATA(msg->mBuf);
         IT_FREE(sizeof(ItMupMsg), msg);
         itGlobalCb.nmbMsg--;
      }
   }

   /* Delete slsLst */
   IT_FREE((maxSls * sizeof(ItLscSlsCtx)), lsCb->slsLst)

   /* Delete SlsCb */
   IT_FREE(sizeof(ItLscSlsCb), lsCb)

   RETVALUE(ROK);
} /* end of itLscDelBySls */


/*
*
*       Fun:   itLscExec
*
*       Desc:  Execute load sharing
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLscExec
(
ItMupMsg    *msg              /* MUP message */
)
#else
PUBLIC S16 itLscExec (msg)
ItMupMsg    *msg;             /* MUP message */
#endif
{
   S16         ret;           /* return value */
   U8          lsType;        /* load share type */

   TRC2(itLscExec)

   ITDBGP(DBGMASK_LYR|IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf, 
                     "itLscExec(msg)\n"));

   ret = ROK;
   if (msg->routeTgt1->psCfg.mode != LIT_MODE_LOADSHARE)
   {
      lsType = LIT_LOADSH_SLS;
   }
   else
   {
      lsType = msg->routeTgt1->psCfg.loadShareMode;
   }
   switch (lsType)
   {
      case LIT_LOADSH_RNDROBIN:
      {
         ret = itLscExecRndRobin(msg);
         break;
      }
      case LIT_LOADSH_SLS:
      {
         ret = itLscExecBySls(msg);
         break;
      }
      default:
         break;
   }

   RETVALUE(ret);
} /* end of itLscExec */


/*
*
*       Fun:   itLscChkClusterEnt
*
*       Desc:  Check cluster entity
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC Bool itLscChkClusterEnt
(
U32           entId,          /* entity ID */
ItPsCb        *cluster,       /* parent cluster */
ItPsCb        *lpsCb,         /* Local PS CB */
U8            nwkId,          /* network ID */
Dpc           dpc             /* DPC value */
)
#else
PUBLIC Bool itLscChkClusterEnt (entId, cluster, lpsCb, nwkId, dpc)
U32           entId;          /* entity ID */     
ItPsCb        *cluster;       /* parent cluster */
ItPsCb        *lpsCb;         /* Local PS CB */   
U8            nwkId;          /* network ID */    
Dpc           dpc;            /* DPC value */     
#endif
{
   Bool       ret;            /* return value */
   ItDpcCb    *dpcCb;         /* DPC control block */

   TRC2(itLscChkClusterEnt)

#ifdef BIT_64
   ITDBGP(IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf, 
        "itLscChkClusterEnt(entId(%d), cluster, lpsCb, nwkId(%d), dpc)\n", 
          entId, nwkId));
#else
   ITDBGP(IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf, 
        "itLscChkClusterEnt(entId(%ld), cluster, lpsCb, nwkId(%d), dpc)\n", 
          entId, nwkId));
#endif
#if (!(defined(ITASP) && defined(OG_RTE_ON_LPS_STA)))
   UNUSED(lpsCb);
#endif /* (!(defined(ITASP) && defined(OG_RTE_ON_LPS_STA))) */
   ret = FALSE;

   (Void) itAtGetDpc(nwkId, dpc, &dpcCb);
   if (cluster != (ItPsCb *)NULLP)
   {
      if (dpcCb != (ItDpcCb *)NULLP)
      {
        if ((cluster->psSta.psStaEndp[IT_ASSOC2SUID(entId)].aspSt[IT_ASSOC2PSPID
                                     (entId)] == LIT_ASP_ACTIVE) &&
             (dpcCb->pspDpcSt[entId] != IT_DPC_UNAVAILABLE) &&
             (dpcCb->pspDpcSt[entId] != IT_DPC_RESTRICTED))
         {
            ret = TRUE;
         }
      }
      else
      {
         if (cluster->psSta.psStaEndp[IT_ASSOC2SUID(entId)].aspSt[IT_ASSOC2PSPID
                                     (entId)] == LIT_ASP_ACTIVE)
         {
            ret = TRUE;
         }
      }
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
      /* - Added the check for entId availability in Local 
       * PS CB if it is SGP/IPSP-SE */
      if (ret == TRUE)
      {
          if (((itGlobalCb.assoc[entId]->owner->pspCfg.pspType 
                                                          == LIT_PSPTYPE_SGP) ||
               ((itGlobalCb.assoc[entId]->owner->pspCfg.pspType 
                                                        == LIT_PSPTYPE_IPSP) &&
                (itGlobalCb.assoc[entId]->owner->pspCfg.ipspMode ==
                                                          LIT_IPSPMODE_SE))) &&
              (lpsCb != NULLP) &&
              (lpsCb->psSta.psStaEndp[IT_ASSOC2SUID(entId)].aspSt[IT_ASSOC2PSPID
                                     (entId)] != LIT_ASP_ACTIVE))
          {
             ret = FALSE;
          }
      }
#endif /* ITASP && OG_RTE_ON_LPS_STA */
   }

   RETVALUE(ret);
} /* end of itPsmChkClusterEnt */


/*
*
*       Fun:   itLscChkClusterEntRst
*
*       Desc:  Check if the PSP is in Active state
*              and if dpc is restricted through this
*              PC
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC Bool itLscChkClusterEntRst
(
U32           entId,          /* entity ID */
ItPsCb        *cluster,       /* parent cluster */
ItPsCb        *lpsCb,         /* Local PS CB */
U8            nwkId,          /* network ID */
Dpc           dpc             /* DPC value */
)
#else
PUBLIC Bool itLscChkClusterEntRst (entId, cluster, lpsCb, nwkId, dpc)
U32           entId;          /* entity ID */     
ItPsCb        *cluster;       /* parent cluster */
ItPsCb        *lpsCb;         /* Local PS CB */   
U8            nwkId;          /* network ID */    
Dpc           dpc;            /* DPC value */     
#endif
{
   Bool       ret;            /* return value */
   ItDpcCb    *dpcCb;         /* DPC control block */

   TRC2(itLscChkClusterEntRst)

#ifdef BIT_64
   ITDBGP(IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf, 
        "itLscChkClusterEntRst(entId(%d), cluster, nwkId(%d), dpc)\n", 
          entId, nwkId));
#else
   ITDBGP(IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf, 
        "itLscChkClusterEntRst(entId(%ld), cluster, nwkId(%d), dpc)\n", 
          entId, nwkId));
#endif
#if (!(defined(ITASP) && defined(OG_RTE_ON_LPS_STA)))
   UNUSED(lpsCb);
#endif /* (!(defined(ITASP) && defined(OG_RTE_ON_LPS_STA))) */

   ret = FALSE;

   (Void) itAtGetDpc(nwkId, dpc, &dpcCb);
   if (cluster != (ItPsCb *)NULLP)
   {
      if (dpcCb != (ItDpcCb *)NULLP)
      {
         if ((cluster->psSta.psStaEndp[IT_ASSOC2SUID(entId)].\
                   aspSt[IT_ASSOC2PSPID(entId)] == LIT_ASP_ACTIVE) &&
             (dpcCb->pspDpcSt[entId] == IT_DPC_RESTRICTED))
         {
            ret = TRUE;
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
            /* - Added the check for entId availability in Local 
             * PS CB if it is SGP/IPSP-SE */
            if (((itGlobalCb.assoc[entId]->owner->pspCfg.pspType   
                                                          == LIT_PSPTYPE_SGP) ||
                 ((itGlobalCb.assoc[entId]->owner->pspCfg.pspType  == 
                                                            LIT_PSPTYPE_IPSP) &&
                  (itGlobalCb.assoc[entId]->owner->pspCfg.ipspMode == 
                                                           LIT_IPSPMODE_SE))) &&
                (lpsCb != NULLP) &&
                (lpsCb->psSta.psStaEndp[IT_ASSOC2SUID(entId)].\
                   aspSt[IT_ASSOC2PSPID(entId)] != LIT_ASP_ACTIVE))
            {
               ret = FALSE;
            }
#endif /* ITASP && OG_RTE_ON_LPS_STA */
         }
      }
   }

   RETVALUE(ret);
} /* end of itPsmChkClusterEntRst */


/*
*
*       Fun:   itLscExecRndRobin
*
*       Desc:  Execute load sharing round robin
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLscExecRndRobin
(
ItMupMsg    *msg              /* MUP message */
)
#else
PUBLIC S16 itLscExecRndRobin (msg)
ItMupMsg    *msg;             /* MUP message */
#endif
{
   ItLscRndRbnCb  *lsCb;      /* load share control block */
   ItPsCb         *cluster;   /* cluster */
   U32            entLst[LIT_MAX_ASSOC];    /* entity list */
   S32            nmbEnt;     /* list size */
   U32            lastEnt;    /* last entity */
   U32            entId;      /* entity ID */
   U32            rstEntId;   /* entity ID of restricted psp */
   S32            i;          /* loop index */
   U32            k;          /* loop index */
   U32            z;          /* loop index */
   U32            locRef;     /* local reference */
   U32            cnt;        /* count */
   Bool           xudtFlag;   /* XUDT present flag */
   Bool           routeFlag;  /* route flag */
   Bool           result;     /* result flag */
   Bool           rstFound;   /* restricted psp found */
   ItLscXudtCtx   *xudtCb;    /* XUDT context block */
   ItLscXudtCtx   *prevXudtCb; /* previous XUDT context block */
   S16            ret;        /* return value */
   PTR            xudtPtr;    /* XUDT pointer */
   U16            word;       /* temp word */
   U8             byte;       /* temp byte */
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   ItPsId         lpsId;      /* Local PS Id */
#endif /* ITASP && OG_RTE_ON_LPS_STA */
   ItPsCb         *lpsCb;     /* Local PS CB */

   TRC2(itLscExecRndRobin)
                   
   ITDBGP(IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf, 
            "itLscExecRndRobin(msg)\n"));
   
   nmbEnt   = 0;
   entId    = 0;
   rstEntId = 0;
   cluster  = msg->routeTgt1;
   /* - At ASP/IPSP, if OG_RTE_ON_LPS_STA is defined, determine the 
    * lsCb from the Child Ps List corresponding to the Local PS Id in NSAP CB.
    * Local PS CB pointer will be required at ASP/IPSP in this case to check 
    * the PSP availability in both Remote PS CB and Local PS CB */
#if !(defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   lsCb     = &cluster->lsCb->rndRbn;
   lpsCb    = NULLP;
#else /* ITASP && OG_RTE_ON_LPS_STA */
   if ((cluster->chldPsLst == NULLP) || (msg->originator == NULLP))
   {
      RETVALUE(RFAILED);
   }

   lpsId = ((ItNSapCb *)msg->originator)->lpsId;
   if (lpsId == IT_INVALID_PS_ID)
   {
      RETVALUE(RFAILED);
   }
   lsCb = NULLP;
   for (i = 0; i < cluster->nmbChldPs; i++)
   {
      if ((cluster->chldPsLst[i] != NULLP) && 
          (cluster->chldPsLst[i]->lpsId == lpsId))
      {
         lsCb = &cluster->chldPsLst[i]->lsCb->rndRbn;
         break;
      }
   }
   lpsCb = itPsmFindPs(lpsId);
#endif /* ITASP && OG_RTE_ON_LPS_STA */

   if (lsCb == NULLP)
   {
      RETVALUE(RFAILED);
   }
   locRef   = 0;

   /* Parse message to determine if it is a segmented SCCP message */
   routeFlag   = FALSE;
   xudtFlag    = FALSE;
   rstFound    = FALSE;
   
   if (IT_SRVIND(msg->srvInfo) == SI_SCCP)
   {
      (Void) itMupGetUserInfo(msg, IT_USER_SEGLOCREF);


      if (msg->userInfoLen >= 4)
      {
         /* SCCP message is segmented - Find proper context */
         xudtFlag = TRUE;
   
         /* Strip first octet from user info, retaining only octets 2 to 4 */
         locRef   = 0;
         word     = 0;
         byte     = (U8)*(msg->userInfo + 1);
         word     = PutLoByte(word, byte);
         locRef   = PutHiWord(locRef, word);
         word     = 0;
         byte     = (U8)*(msg->userInfo + 2);
         word     = PutHiByte(word, byte);
         byte     = (U8)*(msg->userInfo + 3);
         word     = PutLoByte(word, byte);
         locRef   = PutLoWord(locRef, word);
         
         /* Search hash list for matching Local Reference */
         ret = cmHashListFind(&lsCb->xudtLst, (U8 *)&locRef, 
                              sizeof(U32), 0, &xudtPtr);
   
         if (ret == ROK)             
         {
            /* Previous XUDT Local Reference entry found */
            prevXudtCb = (ItLscXudtCtx *) xudtPtr;
   
            entId = prevXudtCb->targetId;
            /* - Added a new input parameter to check the 
             * availability of entId (if SGP/IPSP-SE) in Local PS CB also */
            if (itLscChkClusterEnt(entId, cluster, lpsCb, msg->nwkId, msg->dpc)
                == TRUE)
            {
               /* This target is active, routing complete */
               routeFlag = TRUE;
   
               /* (Re)start XUDT Context timer */
               IT_TC_START_TMR(&(prevXudtCb->hdr.tmrCtx), (PTR) prevXudtCb, 
                              IT_TMR_LSC_CTX, IT_VAL_LSC_CTX);
            }
            else 
            {
               /* - Added a new input parameter to check the 
                * availability of entId (if SGP/IPSP-SE) in Local PS CB also */
               if (itLscChkClusterEntRst(entId, cluster, lpsCb, msg->nwkId, 
                                                            msg->dpc) == TRUE)
               {
                  rstFound = TRUE;
                  rstEntId = entId;
               }
               ret = cmHashListDelete(&lsCb->xudtLst, xudtPtr);
               IT_FREE(sizeof(ItLscXudtCtx), xudtPtr);
            }
         }
      }
   }

   if (routeFlag == FALSE)
   {
      /*
       * Message not segmented, no previous XUDT entry found, or last
       * target no longer active.
       */

      
      for (k = 0; k < LIT_MAX_SEP; k++)
      {
         for (z = 0; z < cluster->psSta.psStaEndp[k].nmbAct; z++)
         {
            /* it001.106 : modifications, correct assoc Id is used */
            entLst[nmbEnt++] = (U32) IT_PSPnENDP2ASSOC(cluster->psSta.\
                                     psStaEndp[k].actPsp[z], k);
         }
      }

      /* entLst now contains active entities (assocs) */
      /* Find index of lastId in ordered list of ACTIVE entities */
      for (i = 0; (i < nmbEnt) && (entLst[i] != lsCb->lastId); i++);

      if (i >= nmbEnt)
      {
         lastEnt = (U32)(nmbEnt - 1);
      }
      else
      {
         lastEnt = (U32)i;
      }

      result = FALSE;
      cnt = lastEnt + 1;
      while ((cnt != lastEnt) && (result == FALSE))
      {
         if (cnt >= (U32)nmbEnt)
         {
            cnt = 0;
         }
         else
         {
            /* - Added a new input parameter to check the 
             * availability of entId (if SGP/IPSP-SE) in Local PS CB also */
            if ((result = itLscChkClusterEnt(entLst[cnt], cluster, lpsCb,
                 msg->nwkId, msg->dpc)) == FALSE)
            {
               if (rstFound != TRUE)
               {
                  /* - Added a new input parameter to check the 
                   * availability of entId (if SGP/IPSP-SE) in Local PS CB 
                   * also */
                  if (itLscChkClusterEntRst(entLst[cnt], cluster, lpsCb,
                        msg->nwkId, msg->dpc) == TRUE)
                  {
                     rstFound = TRUE;
                     rstEntId = entLst[cnt];
                     result = FALSE;
                  }
               }
               cnt++;
            }
         }
      }

      if ((cnt >= lastEnt) && (result == FALSE))
      {
         /* As last resort, test previously used entity */
         /* - Added a new input parameter to check the 
          * availability of entId (if SGP/IPSP-SE) in Local PS CB also */
         result = itLscChkClusterEnt(entLst[cnt], cluster, lpsCb, msg->nwkId, 
                                     msg->dpc);
         if (result == FALSE && rstFound != TRUE)
         {
           /* - Added a new input parameter to check the 
            * availability of entId (if SGP/IPSP-SE) in Local PS CB also */
            if (itLscChkClusterEntRst(entLst[cnt], cluster, lpsCb, 
                 msg->nwkId, msg->dpc) == TRUE)
            {
               rstFound = TRUE;
               rstEntId = entLst[cnt];
               result = FALSE;
            }
         }
      }

      if ((result == FALSE) && (rstFound == FALSE))
      {
         /* ABORT: No valid entity found */
         RETVALUE(RFAILED);
      }

      if (result == FALSE)
      {
         entId = rstEntId;
         lsCb->lastId   = entId;
      }
      else
      {
         entId          = entLst[cnt];
         lsCb->lastId   = entId;
      }

      if (xudtFlag == TRUE) 
      {
         /* Add new XudtCb to the list */
         IT_ALLOC(sizeof(ItLscXudtCtx), xudtCb)
         if (xudtCb != (ItLscXudtCtx *)NULLP)
         {
            IT_INITTIMER(&xudtCb->hdr.tmrCtx);
            xudtCb->xudtLocRef   = locRef;
            xudtCb->targetId     = entId;
            xudtCb->hdr.lscType  = LIT_LOADSH_RNDROBIN;
            xudtCb->hdr.owner    = (PTR)msg->routeTgt1;
            xudtCb->cp           = &lsCb->xudtLst;
            
            /* Insert into hash table */
            (Void) cmHashListInsert(&(lsCb->xudtLst), (PTR) xudtCb, 
                                    (U8 *) &xudtCb->xudtLocRef, sizeof(U32));

            /* (Re)start XUDT Context timer */
            IT_TC_START_TMR(&xudtCb->hdr.tmrCtx, (PTR) xudtCb, 
                           IT_TMR_LSC_CTX, IT_VAL_LSC_CTX);
         }
      }
   }

   msg->routeTgt2 = itGlobalCb.assoc[entId];
   msg->msgState  = IT_MSG_ROUTED_TWO;

   RETVALUE(ROK);
} /* end of itLscExecRndRobin */




/*
*
*       Fun:   itLscExecBySls
*
*       Desc:  Execute by-SLS load sharing
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLscExecBySls
(
ItMupMsg       *msg           /* MUP message */
)
#else
PUBLIC S16 itLscExecBySls (msg)
ItMupMsg       *msg;          /* MUP message */
#endif
{
   ItPsCb      *cluster;      /* cluster */
   ItLscSlsCb  *lsCb;         /* load share control block */
   LnkSel      sls;           /* SLS value */
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   ItPsId      lpsId;          /* Local PS Id */
   U32         i;              /* Loop index */
#endif
   U16         maxSls;        /* Total number of SLS contexts */
   

   TRC2(itLscExecBySls)

   ITDBGP(IT_DBGMASK_DATA, (itGlobalCb.itInit.prntBuf,
                     "itLscExecBySls(msg)\n"));

   maxSls   = 0;
   cluster  = msg->routeTgt1;
   /* - At ASP/IPSP, if OG_RTE_ON_LPS_STA is defined, determine 
    * the lsCb from the Child Ps List corresponding to the Local PS Id in 
    * NSAP CB */
#if !(defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   lsCb     = &cluster->lsCb->sls;
#else /* ITASP && OG_RTE_ON_LPS_STA */
   if ((cluster->chldPsLst == NULLP) || (msg->originator == NULLP))
   {
      RETVALUE(RFAILED);
   }

   lpsId = ((ItNSapCb *)msg->originator)->lpsId;
   if (lpsId == IT_INVALID_PS_ID)
   {
      RETVALUE(RFAILED);
   }
   lsCb = NULLP;
   for (i = 0; i < cluster->nmbChldPs; i++)
   {
      if ((cluster->chldPsLst[i] != NULLP) && 
          (cluster->chldPsLst[i]->lpsId == lpsId))
      {
         lsCb = &cluster->chldPsLst[i]->lsCb->sls;
         break;
      }
   }
#endif /* ITASP && OG_RTE_ON_LPS_STA */
   if (lsCb == NULLP)
   {
      RETVALUE(RFAILED);
   }

   sls = msg->lnkSel;
   /* Defensive check introduced */

   /* Determine total number of SLS contexts  */
   IT_LSC_NUMB_SLS_CTX(lsCb->cluster, maxSls)
   if (sls >= maxSls)
   {
      RETVALUE(RFAILED);
   }

   if (lsCb->slsLst[sls].seqTmrId != LIT_MAX_ASSOC)
   {
      /* Sequence control timer running, so message is to be queued */
      cmLListAdd2Tail(&lsCb->slsLst[sls].seqMsgQ, &msg->llHdr);
      msg->msgState  = IT_MSG_QUEUED_LSCSLS;
   }
   else
   {
      if (lsCb->slsLst[sls].targetId != LIT_MAX_ASSOC)
      {
         msg->routeTgt2 = itGlobalCb.assoc[lsCb->slsLst[sls].targetId];
         msg->msgState  = IT_MSG_ROUTED_TWO;
      }
      else
      {
         RETVALUE(RFAILED);
      }
   }

   RETVALUE(ROK);
} /* end of itLscExecBySls */


/*
*
*       Fun:   itLscCtxTmrExp
*
*       Desc:  Load sharing context timer expired
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLscCtxTmrExp
(
ItLscCtxHdr    *ctx              /* load share context */
)
#else
PUBLIC S16 itLscCtxTmrExp (ctx)
ItLscCtxHdr    *ctx;             /* load share context */
#endif
{
   TRC2(itLscCtxTmrExp)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, "itLscCtxTmrExp(ctx)\n"));

   switch (ctx->lscType)
   {
      case LIT_LOADSH_RNDROBIN:
         (Void) itLscRndRbnCtxTmrExp((ItLscXudtCtx *)ctx);
         break;
      default:
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of itLscCtxTmrExp */


/*
*
*       Fun:   itLscRndRbnCtxTmrExp
*
*       Desc:  Load sharing round robin context timer expired
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLscRndRbnCtxTmrExp
(
ItLscXudtCtx   *ctx           /* XUDT context */
)
#else
PUBLIC S16 itLscRndRbnCtxTmrExp (ctx)
ItLscXudtCtx   *ctx;          /* XUDT context */
#endif
{
   TRC2(itLscRndRbnCtxTmrExp)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
                        "itLscRndRbnCtxTmrExp(ctx)\n"));

   /* Remove this context block from hash list */
   (Void) cmHashListDelete(ctx->cp, (PTR)ctx);

   /* Free memory */
   IT_FREE(sizeof(ItLscXudtCtx), ctx)

   RETVALUE(ROK);
} /* end of itLscRndRbnCtxTmrExp */




/*
*
*       Fun:   itPsmVerifyPspList
*
*       Desc:  This function verifies if any duplicate entries are present
*              in the PSP list. It also verifies whether Psp Id are with in
*              valid range
*
*       Ret:   Failure:           RFAILED
*
*              Success:           ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 itPsmVerifyPspList
(
ItPsCfg        *cfg,             /* configuration parameters */
CmStatus       *sta              /* return status */
)
#else
PUBLIC S16 itPsmVerifyPspList(cfg, sta)
ItPsCfg        *cfg;             /* configuration parameters */
CmStatus       *sta;             /* return status */
#endif
{
   U16          i;                        /* loop counter */
   U16          j;                        /* loop counter */
   ItPsCb      *psCb = (ItPsCb *) NULLP;  /* PS Control Block */
   
   TRC2(itPsmVerifyPspList)
   psCb = itPsmFindPs(cfg->psId);

   for (i = 0; i < cfg->nmbPsp; i++)
   {
      if ((cfg->psp[i] >= itGlobalCb.genCfg.maxNmbPsp) ||
          (itGlobalCb.psp[cfg->psp[i]] == (ItPspCb *) NULLP))
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         ITLOGERROR(ERRCLS_INT_PAR, EIT440, (ErrVal) i,
                    "itPsmVerifyPspList: invalid or unconfigured PSP");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         sta->status = LCM_PRIM_NOK;
         sta->reason = LIT_REASON_INVALID_PSPID;
         RETVALUE(RFAILED);
      }
      /* check rest of list for duplicates */
      for (j = (S16)(i + 1); j < cfg->nmbPsp; j++)
      {
         if (cfg->psp[j] == cfg->psp[i])
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            ITLOGERROR(ERRCLS_INT_PAR, EIT441, (ErrVal) cfg->psp[i],
                       "itPsmVerifyPspList: duplicate PSP ID");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
            sta->status = LCM_PRIM_NOK;
            sta->reason = LCM_REASON_INVALID_PAR_VAL;
            RETVALUE(RFAILED);
         }
      }
   }/* end for loop */
   RETVALUE(ROK);
}


/*
*
*       Fun:   itLscSlsDpcEvt
*
*       Desc:  Redistributes the traffic if DUNA/DAVA/DRST messages are
*              received for a DPC with configured route towards a PS in
*              Loadshare mode on SLS.
*
*       Ret:   Void
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC Void itLscSlsDpcEvt
(
U8             dpcEv,         /* DPC related event */
ItDpcCb        *dpcCb,        /* DPC control block */
UConnId        assocId        /* Remote assoc ID */
)
#else
PUBLIC Void itLscSlsDpcEvt (dpcEv, dpcCb, assocId)
U8             dpcEv;         /* DPC related event */
ItDpcCb        *dpcCb;        /* DPC control block */
UConnId        assocId;       /* Remote assoc ID */
#endif
{
   S16         ret;           /* return value */
   U16         idx;           /* cluster index */
   U8          rtType;        /* route type */
   ItPsCb      *psCb;         /* route owner */
   ItRouteCb   *routeCb;      /* route CB */
   ItPspId     pspId;         /* Remote PSP ID */
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   U32         i;             /* loop index */
   ItPsCb      *lpsCb = (ItPsCb *) NULLP; /* Local PS CB */
#endif
   SuId        suId;          /* SCT SAP id of association */
 
   TRC2(itLscSlsDpcEvt)

#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, "itLscSlsDpcEvt(dpcEv(%d), \
          dpc(%d), assocId(%d))\n", dpcEv,
          (dpcCb != (ItDpcCb *)NULLP) ? dpcCb->dpc : 0, assocId));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, "itLscSlsDpcEvt(dpcEv(%d), \
          dpc(%ld), assocId(%ld))\n", dpcEv,
          (dpcCb != (ItDpcCb *)NULLP) ? dpcCb->dpc : 0, assocId));
#endif
   
   pspId = itGlobalCb.assoc[assocId]->owner->pspCfg.pspId;
   suId  = IT_ASSOC2SUID(assocId);

   if (dpcCb == (ItDpcCb *)NULLP)
           RETVOID;

   if ((dpcEv == IT_MIF_PC_UNA) || (dpcEv == IT_MIF_PC_AVA) ||
       (dpcEv == IT_MIF_PC_RST))
   {
      idx = 0;
      
      /* Step through the list of routes associated with this DPC */
      while ((ret = itMifGetNextInCluster(dpcCb, &rtType, &psCb, &idx, 
                                                 &routeCb)) == ROK)
      {
         if (rtType != LIT_RTTYPE_PS)
            continue;
         
         /* If PS is configured in Loadshare mode on SLS, and remote PSP is
          * Active for this PS, redistribute the traffic */
#if (defined(ITASP) && defined(SGVIEW))
         /* - If the dpcEv is triggered by SSNM message from an
          * SGP where ASP is Inactive/Active, then the SLS map should be 
          * updated as this SSNM message affects the DPC status for all 
          * other SGPs in same SG. */
         if ((psCb->psCfg.lclFlag == FALSE) &&
             (psCb->psCfg.mode == LIT_MODE_LOADSHARE) &&
             (psCb->psCfg.loadShareMode == LIT_LOADSH_SLS) &&
             ((psCb->psSta.psStaEndp[suId].aspSt[pspId] == LIT_ASP_ACTIVE) ||
              (psCb->psSta.psStaEndp[suId].aspSt[pspId] == LIT_ASP_INACTIVE)))
#else /* ITASP && SGVIEW */
         if ((psCb->psCfg.lclFlag == FALSE) &&
             (psCb->psCfg.mode == LIT_MODE_LOADSHARE) &&
             (psCb->psCfg.loadShareMode == LIT_LOADSH_SLS) &&
             (psCb->psSta.psStaEndp[suId].aspSt[pspId] == LIT_ASP_ACTIVE))
#endif /* ITASP && SGVIEW */
         {
            /* - If node is ASP/IPSP, and OG_RTE_ON_LPS_STA is 
             * defined, update all the Child PS CBs. Else, update the 
             * Loadshare CB in PS CB. */
#if !(defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
            /* - Added a new parameter of pointer to Loadshare CB
             * and changed the pointer to PS CB as local PS CB pointer */
            itLscSlsUpdLst(&psCb->lsCb->sls, NULLP, psCb->psSta.asSt);
#else /* ITASP && OG_RTE_ON_LPS_STA */
            for (i = 0; i < psCb->nmbChldPs; i++)
            {
               if (psCb->chldPsLst[i] != NULLP)
               {
                  lpsCb = itPsmFindPs(psCb->chldPsLst[i]->lpsId);
                  itLscSlsUpdLst(&psCb->chldPsLst[i]->lsCb->sls, lpsCb, 
                                 psCb->psSta.asSt);
               }
            }
#endif /* ITASP && OG_RTE_ON_LPS_STA */
         }
      }
   }

   RETVOID;
} /* end of itLscSlsDpcEvt */


/*
*
*       Fun:   itLscSlsSeqTmrExp
*
*       Desc:  This function empties the message queues of diverted SLS on
*              sequence control timer expiry.
*
*       Ret:   Void
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC Void itLscSlsSeqTmrExp
(
ItLscSlsSeq    *seq           /* Sequence control timer */
)
#else
PUBLIC Void itLscSlsSeqTmrExp (seq)
ItLscSlsSeq    *seq;          /* Sequence control timer */
#endif
{
   U16         i;             /* loop index */
   ItLscSlsCb  *lsCb;         /* pointer to Loadshare control block */
   ItMupMsg    *msg;          /* temp message */
   U16         maxSls;        /* Total number of SLS contexts */
 
   TRC2(itLscSlsSeqTmrExp)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, "itLscSlsSeqTmrExp(seq)\n"));

   maxSls = NULLD;

   lsCb = seq->lsCb; 
   /* Determine total number of SLS contexts  */
   IT_LSC_NUMB_SLS_CTX(lsCb->cluster, maxSls)

   for (i = 0; i < maxSls; i++)
   {
      if (lsCb->slsLst[i].seqTmrId == seq->seqTmrId)
      {
         /* If there are any messages queued for this SLS, route them to 
          * targetId (if valid) */
         /* Make sequence timer ID invalid for this SLS so that no further
          * messages are queued */
         lsCb->slsLst[i].seqTmrId = LIT_MAX_ASSOC;
         while (cmLListLen(&lsCb->slsLst[i].seqMsgQ) > 0)
         {
            msg = (ItMupMsg *) cmLListDelFrm(&lsCb->slsLst[i].seqMsgQ,
                                       cmLListFirst(&lsCb->slsLst[i].seqMsgQ));

            msg->msgState = IT_MSG_ROUTED_ONE;

            if (itMupData(msg) == ROK)
               continue;

            IT_DROPDATA(msg->mBuf);
            IT_FREE(sizeof(ItMupMsg), msg);
            itGlobalCb.nmbMsg--;

         } /* end of while */
      } /* end of if */
   } /* end of for */
   
   RETVOID;
} /* end of itLscSlsSeqTmrExp */


/*
*
*       Fun:   itLscSlsUpdLst
*
*       Desc:  This function updates the SLS to PSP mapping for a PS
*              configured in SLS based Loadshare mode. It also starts the
*              sequence control timer if required.
*
*       Ret:   Void
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void itLscSlsUpdLst
(
ItLscSlsCb     *lsCb,         /* Loadshare control block */
ItPsCb         *lpsCb,        /* Local PS control block */
U8              oldAsSt       /* old AS state */
)
#else
PUBLIC Void itLscSlsUpdLst (lsCb, lpsCb, oldAsSt)
ItLscSlsCb     *lsCb;         /* Loadshare control block */
ItPsCb         *lpsCb;        /* Local PS control block */
U8              oldAsSt;      /* old AS state */
#endif
{
   U32         i;             /* loop index */
   U32         j;             /* loop index */
   /* ItLscSlsCb  *lsCb;         * pointer to Loadshare control block */
   U32         masterList[LIT_MAX_ASSOC]; /* Assocs for load (re)distribution */
   UConnId     maxList[LIT_MAX_ASSOC]; /* Assocs with max Load */
   U32         maxCnt;        /* Count of Assocs with max load */
   Bool        tmrFlag[LIT_MAX_ASSOC]; /* Sequence control timer flag/Assoc*/
   U16         max;           /* Maximum SLS load Cnt required for some assocs*/
   U32         maxAssoc;      /* Required Count of PSPs with max SLS load */
   U16         maxSls;        /* Total number of SLS contexts */
   UConnId     assocId;       /* Temp Assoc Id */
   UConnId     assocIdNew;    /* Temp Assoc Id */
   U16         minLoad;       /* Minimum Load */ 
   ItPsCb      *rpsCb;        /* Remote PS control block */
#ifdef ZV
   ZvUpdSpecParams updSpec;
#endif
 
   TRC2(itLscSlsUpdLst)

#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itLscSlsUpdLst(lsCb, lpsId (%d), oldAsSt (%d))\n", 
          (lpsCb != (ItPsCb *)NULLP) ? lpsCb->psCfg.psId : 0, oldAsSt));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itLscSlsUpdLst(lsCb, lpsId (%ld), oldAsSt (%d))\n", 
          (lpsCb != (ItPsCb *)NULLP) ? lpsCb->psCfg.psId : 0, oldAsSt));
#endif
   
   if (lsCb == (ItLscSlsCb *)NULLP)
      RETVOID;

   /* - Removed the assignment of lsCb, since it is passed as an
    * input parameter now */
   /* lsCb = &psCb->lsCb->sls; */
   /* - Determine the owner Remote PS CB pointer from the 
    * Loadshare CB */
   rpsCb = lsCb->cluster;

   maxCnt      = 0;
   max         = 0;
   maxAssoc    = 0;
   maxSls      = 0;

   /* Initialise the arrays for each ASSOC */
   for (i = 0; i < LIT_MAX_ASSOC; i++)
   {
      maxList[i] = LIT_MAX_ASSOC;
      tmrFlag[i] = FALSE;
   }

   /* Calculate max Load, No. of Assoc with max Load and initialise masterList*/
   /* - Changed the parameters of itLscSlsCalcLoad. Passed pointer
    * to Remote PS CB and Local PS CB as arguments */
   /* LscSlsCalcLoad function calculates the rpsCb->spmc status from all the 
    * associations
    * and for those associations on which dpc (rpsCb->spmc) is available (or
    * restricted) function marks the masterlist[i] as 0 otherwise it
    * marks it with MAX32BIT value, this function also calculates 
    * the max and min number of sls to be distributed on assocs,
    * maxAssoc is calculated as num of assocs which will have extra sls because
    * the (total_sls% available_assocs) is not zero, if it is zero then
    * maxAssoc is marked as LIT_MAX_ASSOC */ 
   itLscSlsCalcLoad(rpsCb, lpsCb, &max, &maxAssoc, masterList);

   /* Check if there are any available Assocs */
   if (max == 0)
   {
      /* No Assocs Available, so stop the sequence timers and make SLS map
       * invalid */
      itLscSlsNoPspAvail(lsCb);
      RETVOID;

   } /* end of if avlblCnt and restrictCnt both are 0 */

   /* Determine total number of SLS contexts for PS network */
   IT_LSC_NUMB_SLS_CTX(rpsCb, maxSls)

   /* Determine load on each available ASSOCs */
   for (i = 0; i < maxSls; i++)
   {
      assocId = lsCb->slsLst[i].targetId;
      if (assocId != LIT_MAX_ASSOC)
      {
         if (masterList[assocId] != MAX32BIT)
         {
            masterList[assocId]++;
         }
      }
   }
   /* Masterlist now has the count of sls on each associations */

   /* The load is to be redistributed only on those assocs which
    * are active for an ACTIVE AS. */


   /* (Re)Distribute the load for each SLS */
   for (i = 0; i < maxSls; i++)
   {
      assocId = lsCb->slsLst[i].targetId;
      /* Check if AssocId is invalid or failed as per masterList */
      if ((assocId == LIT_MAX_ASSOC) ||
          (masterList[assocId] == MAX32BIT))
      {
         /* Determine a assoc with minimum load */
         assocIdNew = LIT_MAX_ASSOC;
         minLoad  = IT_MAX_SLSCTX;
         for (j = 0; j < LIT_MAX_ASSOC; j++)
         {
            if (masterList[j] < minLoad)
            {
               assocIdNew = j;
               minLoad  = (U16)masterList[j];
            }
         }
         /* assocIDNew is still Invalid (this check should never be true) */
         if (assocIdNew == LIT_MAX_ASSOC)
                 continue;

         /* assocIdNew is the association which has minimum sls */
         /* Assign new Assoc Id to SLS */
         lsCb->slsLst[i].targetId = assocIdNew;
#ifdef ZV
         /* SYNC is done for SLS targetId update */
         updSpec.p.slsUpd.sls = i;
         updSpec.p.slsUpd.rpsId = rpsCb->psCfg.psId;
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
         updSpec.p.slsUpd.lpsId = (lpsCb != (ItPsCb *)NULLP) ? lpsCb->psCfg.psId
                                    : NULLD;
#endif

         zvRTUpd(CMPFTHA_ACTN_MOD, ZV_SLSCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) &lsCb->slsLst[i],
                                                        &updSpec);
#endif
         masterList[assocIdNew]++;
         /* AssocIdNew reaches maximum supported sls limit if following 
          * condition is TRUE */
         /* If SLS(s) supported by assocIdNew is equal or greater than max AND
            assocs which has maximum load is less than
            number of assocs required to support max sls (because of uneven
            distribution)  AND assocIdNew is not included in maxList (list of
            assocs which has reached their maximum capacity.
          */
         /* maxCnt is the number of assocs which has maximum load */
         if ((masterList[assocIdNew] >= max) &&
             (maxList[assocIdNew] != assocIdNew) &&
             (maxCnt < maxAssoc))
         {
            maxList[assocIdNew] = assocIdNew;
            maxCnt++;
         }

         /* Start sequence control timer, if required for failed Assoc */
         if ((itGlobalCb.genCfg.tmr.tmrSeqCntrl.enb == TRUE) &&
             (rpsCb->psSta.asSt == LIT_AS_ACTIVE) &&
             (oldAsSt == LIT_AS_ACTIVE) &&
             (assocId != LIT_MAX_ASSOC) &&
             (lsCb->slsLst[i].seqTmrId == LIT_MAX_ASSOC))
         {
            if (tmrFlag[assocId] == FALSE)
            {
               tmrFlag[assocId] = TRUE;

               /* stop timer if already running */
               itTcStopTimer(&lsCb->seqCntrl[assocId].seqTmr);
            
               /* (re)start timer */
               itTcStartTimer(&lsCb->seqCntrl[assocId].seqTmr, 
                               (PTR)&lsCb->seqCntrl[assocId], IT_TMR_LSCSLS_SEQ,
                              &itGlobalCb.genCfg.tmr.tmrSeqCntrl);
            }

            lsCb->slsLst[i].seqTmrId = assocId;
         }
      } /* end of if assocId is invalid or failed as per masterList */
      else if ((masterList[assocId] == max) &&
               (maxList[assocId] != assocId) &&
               (maxCnt < maxAssoc))
      {
         /* assocId has reached max load and it is not yet updated in maxList */
         maxList[assocId] = assocId;
         maxCnt++;
      }
      else if ((masterList[assocId] > max) ||
               ((masterList[assocId] == max) &&
                (maxList[assocId] != assocId)))
      {
         /* assocId has more than max load or equal to max load but no. of 
          * assocs with max load has already reached the limit */
         /* Determine a assoc with minimum load */
         assocIdNew = LIT_MAX_ASSOC;
         minLoad  = IT_MAX_SLSCTX;
         for (j = 0; j < LIT_MAX_ASSOC; j++)
         {
            if (masterList[j] < minLoad)
            {
               assocIdNew = j;
               minLoad  = (U16)masterList[j];
            }
         }
         /* assocIdNew is still Invalid (this check should never be true) */
         if (assocIdNew == LIT_MAX_ASSOC)
                 continue;

         /* Assign new assoc Id to SLS */
         lsCb->slsLst[i].targetId = assocIdNew;
#ifdef ZV
         /* SYNC is done for SLS targetId update */
         updSpec.p.slsUpd.sls = i;
         updSpec.p.slsUpd.rpsId = rpsCb->psCfg.psId;
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
         updSpec.p.slsUpd.lpsId = (lpsCb != (ItPsCb *)NULLP) ? lpsCb->psCfg.psId
                                    : NULLD;
#endif

         zvRTUpd(CMPFTHA_ACTN_MOD, ZV_SLSCB,
                         CMPFTHA_UPDTYPE_SYNC, (Void *) &lsCb->slsLst[i],
                                                        &updSpec);
#endif
         masterList[assocIdNew]++;
         masterList[assocId]--;
         if ((masterList[assocIdNew] >= max) &&
             (maxList[assocIdNew] != assocIdNew) &&
             (maxCnt < maxAssoc))
         {
            maxList[assocIdNew] = assocIdNew;
            maxCnt++;
         }

         /* Start sequence control timer, if required for new PSP */
         if ((itGlobalCb.genCfg.tmr.tmrSeqCntrl.enb == TRUE) &&
             (rpsCb->psSta.asSt == LIT_AS_ACTIVE) &&
             (oldAsSt == LIT_AS_ACTIVE) &&
             (lsCb->slsLst[i].seqTmrId == LIT_MAX_ASSOC))
         {
            if (tmrFlag[assocIdNew] == FALSE)
            {
               tmrFlag[assocIdNew] = TRUE;

               /* stop timer if already running */
               itTcStopTimer(&lsCb->seqCntrl[assocIdNew].seqTmr);
            
               /* (re)start timer */
               itTcStartTimer(&lsCb->seqCntrl[assocIdNew].seqTmr, 
                                 (PTR)&lsCb->seqCntrl[assocIdNew], 
                              IT_TMR_LSCSLS_SEQ, 
                              &itGlobalCb.genCfg.tmr.tmrSeqCntrl);
            }

            lsCb->slsLst[i].seqTmrId = assocIdNew;
         }
      } /* end of if assocId has more than or equal to max Load */
   } /* end of for on SLS */
   RETVOID;
} /* end of itLscSlsUpdLst */


/*
*
*       Fun:   itLscSlsNoPspAvail
*
*       Desc:  This function makes SLS to PSP map Invalid and stops any
*              sequence control timers if running.
*
*       Ret:   Void
*
*       Notes: This function should be called for a PS in SLS based Loadshare
*              mode, if there is no PSP Active with DPC status as
*              available/restricted.
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC Void itLscSlsNoPspAvail
(
ItLscSlsCb     *lsCb          /* pointer to Loadshare control block */
)
#else
PUBLIC Void itLscSlsNoPspAvail (lsCb)
ItLscSlsCb     *lsCb;         /* pointer to Loadshare control block */
#endif
{
   U16         i;             /* loop index */
   ItMupMsg    *msg;          /* Message pointer */
   U16         maxSls;        /* Total number of SLS contexts */
 
   TRC2(itLscSlsNoPspAvail)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itLscSlsNoPspAvail()\n"));
   
   if (lsCb == (ItLscSlsCb *)NULLP)
           RETVOID;

   maxSls = NULLD;
   /* None of the Assocs is available, stop sequence control timers */
   for (i = 0; i < LIT_MAX_ASSOC; i++)
   {
      itTcStopTimer(&lsCb->seqCntrl[i].seqTmr);
   }

   /* Determine total number of SLS contexts  */
   IT_LSC_NUMB_SLS_CTX(lsCb->cluster, maxSls)
   
   /* None of the PSPs is available, reset map */
   for (i = 0; i < maxSls; i++)
   {
      lsCb->slsLst[i].targetId = LIT_MAX_ASSOC;
      lsCb->slsLst[i].seqTmrId = LIT_MAX_ASSOC;

      /* Empty message queue */
      while (cmLListLen(&lsCb->slsLst[i].seqMsgQ) > 0)
      {
         /* remove message from head of list */
         msg = (ItMupMsg *) cmLListDelFrm(&lsCb->slsLst[i].seqMsgQ,
                    cmLListFirst(&lsCb->slsLst[i].seqMsgQ));
         IT_STS_INC_DATERR(msg, dropNoPspAvail)
         IT_DROPDATA(msg->mBuf);
         IT_FREE(sizeof(ItMupMsg), msg);
         itGlobalCb.nmbMsg--;
      }
   } /* end of for on SLS */

   RETVOID;

} /* end of itLscSlsNoPspAvail */


/*
*
*       Fun:   itLscSlsCalcLoad
*
*       Desc:  This function calculates the SLS load Cnt per PSP for the set
*              of Active PSPs with DPC status as Available/Restricted
*
*       Ret:   Void
*
*       Notes: This function assumes that masterList, maxList and tmrFlag
*              point to Arrays of size LIT_MAX_PSP.
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC Void itLscSlsCalcLoad
(
ItPsCb          *rpsCb,       /* Remote PS control block */
ItPsCb          *lpsCb,       /* Local PS control block */
U16             *max,         /* Maximum SLS load Cnt required for some PSPs */
U32             *maxAssoc,    /* Required Count of Assocs with max SLS load */
U32             *masterList  /* Array of SLS load count per PSP */
)
#else
PUBLIC Void itLscSlsCalcLoad (rpsCb, lpsCb, max, maxAssoc, masterList)
ItPsCb          *rpsCb;       /* Remote PS control block */
ItPsCb          *lpsCb;       /* Local PS control block */
U16             *max;         /* Maximum SLS load Cnt required for some PSPs */
U32             *maxAssoc;    /* Required Count of Assocs with max SLS load */
U32             *masterList;  /* PSPs for load (re)distribution */
#endif
{
   U32         i;             /* loop index */
   U32         avlblList[LIT_MAX_ASSOC]; /* Active ASSOC (DPC status avlbl) */
   U32         restrictList[LIT_MAX_ASSOC]; /* Active ASSOC (DPC status rstr) */
   U32         avlblCnt;      /* Active ASSOC (DPC status avlbl) Count */
   U32         restrictCnt;   /* Active ASSOC (DPC status rstr) Count */
   U16         min;           /* Minimum SLS load Cnt required per PSP */
   U16         maxSls;        /* Total number of SLS contexts */
   ItPspId     pspId;         /* PSP Id of association */
   SuId        suId;          /* SCT SAP id of association */
 
   TRC2(itLscSlsCalcLoad)

   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itLscSlsCalcLoad()\n"));

#if !(defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   UNUSED(lpsCb);
#endif

   avlblCnt    = 0;
   restrictCnt = 0;
   min         = 0;
   maxSls      = 0;
   *max        = 0;
   *maxAssoc     = 0;
   suId        = 0;
   pspId       = 0;

   /* Initialise the arrays for each assoc */
   for (i = 0; i < LIT_MAX_ASSOC; i++)
   {
      suId   = IT_ASSOC2SUID(i);
      pspId  = IT_ASSOC2PSPID(i);

      if (rpsCb->psSta.psStaEndp[suId].aspSt[pspId] == LIT_ASP_ACTIVE)
      {
         /* If this PSP is a SGP/IPSP-SE, then check its 
          * status in Local PS. If not active, make corresponding entries in 
          * avlblList & restrictList invalid and continue to next PSP */
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
         if (((itGlobalCb.assoc[i]->owner->pspCfg.pspType == LIT_PSPTYPE_SGP) ||
              ((itGlobalCb.assoc[i]->owner->pspCfg.pspType == LIT_PSPTYPE_IPSP)
           && (itGlobalCb.assoc[i]->owner->pspCfg.ipspMode == LIT_IPSPMODE_SE)))
           && (lpsCb != NULLP) && (lpsCb->psSta.psStaEndp[suId].aspSt[pspId] != 
                                                                LIT_ASP_ACTIVE))
         {
            avlblList[i]    = MAX32BIT;
            restrictList[i] = MAX32BIT;
            continue;
         }
#endif /* ITASP && OG_RTE_ON_LPS_STA */
         
         if (rpsCb->spmc != (ItDpcCb *)NULLP)
         {
            switch (rpsCb->spmc->pspDpcSt[i])
            {
               case IT_DPC_AVAILABLE  :
                  avlblList[i] = 0;
                  avlblCnt++;
                  restrictList[i] = MAX32BIT;
                  break;
                  
               case IT_DPC_RESTRICTED :
                  restrictList[i] = 0;
                  restrictCnt++;
                  avlblList[i] = MAX32BIT;
                  break;

               default :
                  avlblList[i] = MAX32BIT;
                  restrictList[i] = MAX32BIT;
            } /* end of switch */
         } /* end of if spmc is not NULLP */
         else
         {
            avlblList[i] = 0;
            avlblCnt++;
            restrictList[i] = MAX32BIT;
         }
      } /* end of if PSP is Active */
      else
      {
         avlblList[i]    = MAX32BIT;
         restrictList[i] = MAX32BIT;
      }
   }/* end of for on Assoc Id */

   /* Determine total number of SLS contexts for PS network */
   IT_LSC_NUMB_SLS_CTX(rpsCb, maxSls)

   /* Determine min and max depending on maxSls and available PSPs */
   if (avlblCnt > 0)
   {
      /* Active Assocs (with DPC status available) are present */

      (Void) cmMemcpy((U8 *)masterList, (U8 *)avlblList, 
                      sizeof(avlblList[0]) * LIT_MAX_ASSOC);

      min = (U16)(maxSls/avlblCnt);
      if ((*maxAssoc = maxSls%avlblCnt) == 0)
      {
         *maxAssoc = LIT_MAX_ASSOC;
         *max    = min;
      }
      else
      {
         *max = (U16)(min + 1);
      }
   }
   else if (restrictCnt > 0)
   {
      /* Active PSPs (with DPC status restricted) are present */

      (Void) cmMemcpy((U8 *)masterList, (U8 *)restrictList, 
                      sizeof(restrictList[0]) * LIT_MAX_ASSOC);

      min = (U16)(maxSls/restrictCnt);
      if ((*maxAssoc = maxSls%restrictCnt) == 0)
      {
         *maxAssoc = LIT_MAX_ASSOC;
         *max    = min;
      }
      else
      {
         *max = (U16)(min + 1);
      }
   }

   RETVOID;

} /* end of itLscSlsCalcLoad */


/*
*
*       Fun:   itPsmVrfyPsLst
*
*       Desc:  Called by itPsmSendAspAc to validate the PS list RXED in
*              control request according to the configuration
*
*
*       Ret:  Void 
*             
*            
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void itPsmVrfyPsLst
(
ItRtCtx        *nrCtx,        /* PS list */
U16            *nrCtxLen,     /* length of list */
ItRtCtx        *irCtx,        /* invalid PS list */
U16            *irCtxLen,     /* length of list */
U8              mode          /* Traffic Handling Mode */
)
#else
PUBLIC Void itPsmVrfyPsLst(nrCtx, nrCtxLen, irCtx, irCtxLen, mode)
ItRtCtx        *nrCtx;        /* PS list */
U16            *nrCtxLen;     /* length of list */              
ItRtCtx        *irCtx;        /* invalid PS list */
U16            *irCtxLen;     /* length of list */              
U8              mode;         /* Traffic handling mode */
#endif
{
   ItPsCb      *psCb;         /* PS control block */
   U16         i;             /* loop index */
   Bool        found;         /* TRUE if routing context valid */
   U16         rCtxLen;       /* loop bound */
   
   TRC2(itPsmVrfyPsLst)
   
   rCtxLen = *nrCtxLen;
   *nrCtxLen = 0;
   /* Initialize psCb */
   psCb = (ItPsCb *)NULLP; 

   for (i = 0; i < rCtxLen; i++)
   {
      found = FALSE;
      psCb  = itPsmFindPs(nrCtx[i].rtCtx);

      if ((psCb != (ItPsCb *)NULLP) &&
          (((psCb->psCfg.mode == LIT_MODE_ACTSTANDBY) &&
          (mode == IT_VRCTX_OVERRIDE)) ||
          ((psCb->psCfg.mode == LIT_MODE_LOADSHARE) &&
          (mode == IT_VRCTX_LOADSHARE))))
      {
         nrCtx[*nrCtxLen].rtCtx     = nrCtx[i].rtCtx;
         nrCtx[*nrCtxLen].ntfySend  = nrCtx[i].ntfySend;
         nrCtx[*nrCtxLen].ntfyStaId = nrCtx[i].ntfyStaId;
         (*nrCtxLen)++;
      }
      else
      {
         irCtx[*irCtxLen].rtCtx     = nrCtx[i].rtCtx;
         irCtx[*irCtxLen].ntfySend  = nrCtx[i].ntfySend;
         irCtx[*irCtxLen].ntfyStaId = nrCtx[i].ntfyStaId;
         (*irCtxLen)++;              
      }
   }
} /* End itPsmVrfyPsLst */


#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
/*
*
*       Fun:   itLscUpd
*
*       Desc:  Called by itPsmPsEvt, to update the Loadshare maps in Child PS
*              CBs.
*
*
*       Ret:  Void 
*             
*            
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void itLscUpd
(
ItPsCb         *psCb,         /* PS control block */            
UConnId        assocId,       /* assoc ID */                
U16            event,         /* PS-related event */
U8             oldAsSt        /* old AS state */
)
#else
PUBLIC Void itLscUpd(psCb, assocId, event, oldAsSt)
ItPsCb         *psCb;         /* PS control block */            
UConnId        assocId;       /* assoc ID */                
U16            event;         /* PS-related event */      
U8             oldAsSt;       /* old AS state */
#endif
{
   U16         i;             /* loop index */
   U16         j;             /* loop index */
   U16         k;             /* loop index */
   U16         chldIndx;      /* Index of new Child PS CB added */
   ItPsCb      *tmpPsCb;      /* PS control block */            
   ItPspCb     *pspCb;        /* PSP control block */
   ItAssocCb   *assocCb;      /* Assoc control block */
   UConnId     tmpAssocId;    /* PSP Id */
   U16         nmbAssocs;     /* Number of Assocs */
   Bool        chldFound;     /* Child PS CB found flag */
   U16         nmbLoopIter;   /* Loop iteration */
   U16         z;             /* Loop iteration */
   
   TRC2(itLscUpd)
   
#ifdef BIT_64
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itLscUpd(psId (%d), assocId (%d), event (%d), oldAsSt (%d))\n", 
          (psCb != (ItPsCb *)NULLP) ? psCb->psCfg.psId : 0, (U32)assocId, event, 
          oldAsSt));
#else
   ITDBGP(DBGMASK_LYR, (itGlobalCb.itInit.prntBuf, 
          "itLscUpd(psId (%ld), assocId (%ld), event (%d), oldAsSt (%d))\n", 
          (psCb != (ItPsCb *)NULLP) ? psCb->psCfg.psId : 0, (U32)assocId, event, 
          oldAsSt));
#endif
   pspCb   = (ItPspCb *)NULLP;
   assocCb = (ItAssocCb *)NULLP;
   
   if (psCb == NULLP)
      RETVOID;

  nmbAssocs = 0; 
   if (psCb->chldPsLst == NULLP)
      RETVOID;
   /* if event is not RECONFIG then for all active assocs SLS context is 
      updated else sls context is updated for assoc on which orig msg was rcvd*/ 
   if (event == IT_EVT_RECONFIG)
   {
      nmbLoopIter = LIT_MAX_SEP;
      /* Update all the Child PS corresponding to the Active assocs */
      /* Check if the Child PS are present for each Active assoc.
       *  If not create it */
   }
   else
   {
      nmbLoopIter = 1;
   }
   for (i = 0; i < nmbLoopIter; i++)
   {
      for (z = 0; z < LIT_MAX_PSP; z++)
      {
         if (event == IT_EVT_RECONFIG)
         {
            /* it001.106 : modifications, correct assocId is used */
            tmpAssocId = IT_PSPnENDP2ASSOC(psCb->psSta.psStaEndp[i].actPsp[z],
                                           i);
         }
         else
         {
            tmpAssocId = assocId;
         }
         assocCb = itGlobalCb.assoc[tmpAssocId];
         if (assocCb != (ItAssocCb *)NULLP)
         {
            /* all PS of assoc */ 
            for (j = 0; j < assocCb->nmbPs; j++)
            {
               tmpPsCb = assocCb->ps[j];
               /* If this is a Remote PS, continue */
               if (tmpPsCb->psCfg.lclFlag != TRUE)
                  continue;
          
               chldFound = FALSE;
               for (k = 0; k < psCb->nmbChldPs; k++)
               {
                  if ((psCb->chldPsLst[k] != NULLP) && 
                      (psCb->chldPsLst[k]->lpsId == tmpPsCb->psCfg.psId))
                  {
                     chldFound = TRUE;
                     /* If SLS based loadshare, update the SLS Map */
                     if (psCb->psCfg.loadShareMode == LIT_LOADSH_SLS)
                     {
                        itLscSlsUpdLst(&psCb->chldPsLst[k]->lsCb->sls, tmpPsCb, 
                                       oldAsSt);
                     }
                  }
               }
            
               if (chldFound == FALSE)
               {
                  /* If PSP is SGP/IPSP-SE and it is not Active in this Local PS
                   * then no need to create a ChildPsCb for this Local PS */
                  pspCb = assocCb->owner;
                  if (((pspCb->pspCfg.pspType == LIT_PSPTYPE_SGP) ||
                      ((pspCb->pspCfg.pspType == LIT_PSPTYPE_IPSP) &&
                       (pspCb->pspCfg.ipspMode == LIT_IPSPMODE_SE))) &&
                      (tmpPsCb->psSta.psStaEndp[IT_ASSOC2SUID(tmpAssocId)].\
                           aspSt[IT_ASSOC2PSPID(tmpAssocId)] != LIT_ASP_ACTIVE))
                  {
                     continue;
                  }
                  /* Add a new Child PS CB to Remote PS Child PS List */
                  if (itLscCfg(psCb->psCfg.loadShareMode, psCb, tmpPsCb, 
                                  &chldIndx) != ROK)
                  {
                     continue;
                  }
                  /* If SLS based loadshare, update the SLS Map */
                  if (psCb->psCfg.loadShareMode == LIT_LOADSH_SLS)
                  {
                     itLscSlsUpdLst(&psCb->chldPsLst[chldIndx]->lsCb->sls,
                                     tmpPsCb, oldAsSt);
                  }
               } /* if chldFound FALSE */
            } /* end of for on PS */
         } /* end of if assocCb != NULLP */
         if (event != IT_EVT_RECONFIG)
         {
            break;
         }
      } /* end of for (z = 0; z < LIT_MAX_PSP; z++) */
   } /* end of for on Active Assocs */

   RETVOID;

} /* End itLscUpd */
#endif  /* ITASP && OG_RTE_ON_LPS_STA */

#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
/*
*
*       Fun:   itPsmChkRcRdyRcvTraf
*
*       Desc:  Called by itPsmAspAc, to verify that LPS is ready to receive 
*              traffic or not. 
*
*       Ret:  Void 
*             
*            
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/
#ifdef ANSI
PRIVATE Void itPsmChkRcRdyRcvTraf
(
ItRtCtx        *nrCtx,        /* routing context list */
U16            *nrCtxLen,     /* length of list */
ItRtCtx        *irCtx,        /* routing context list */
U16            *irCtxLen      /* length of list */
)
#else
PRIVATE Void itPsmChkRcRdyRcvTraf(nrCtx, nrCtxLen, irCtx, irCtxLen)
ItRtCtx        *nrCtx;        /* routing context list */
U16            *nrCtxLen;     /* length of list */
ItRtCtx        *irCtx;        /* routing context list */
U16            *irCtxLen;     /* length of list */
#endif
{
   U16         j;             /* loop index */
   ItPsCb      *psCb;         /* PS Control Block */
   U16         rcOkCount;     /* Count of "accpeted" RCs */
   U8          nwkId;         /* Network ID, required to access nwkCb */
   ItDpcCb     *dpcCb;        /* DPC CB */
   ItRtCtx     rCtxTmp;       /* used for swapping of nrCtx values */

   rcOkCount  = 0;
   *irCtxLen   = 0;
   nwkId      = 0;
   dpcCb      = (ItDpcCb *)NULLP;

   /* get the nwkId from PsCB, it has to be same for all RCs as all RCs
      sent in a single ASPAC message corresponds to a single nwk only  */
   /* the nrCtx list contains psId list */
   psCb = itPsmFindPs(nrCtx[0].rtCtx);
   if (psCb != NULLP)
   {
      nwkId = psCb->nwk->nwkCfg.nwkId;
   }
   /* Get all DPCs, their RCB's and than search for the psId/nsap and 
      its state */
   while ((itAtGetDpcs(nwkId, (Dpc) 0, (Dpc) 0, &dpcCb)
               == ROK))
   {
      /* Special case of dpcCb->routes equal to zero */
      if (cmLListLen(&dpcCb->routes) == 0)
      {
         if ((dpcCb->owner != (ItPsCb *) NULLP) && 
             (dpcCb->nSap != (ItNSapCb *)NULLP) && 
             (dpcCb->nSap->sntSta.hlSt == LIT_SAP_BOUND))
         {
            /* Note: Since all DPC CBs are required to be accessed, 
               the approach taken here is to access these DPCs only onces 
               and then compare it with RCs instead of conventional approach 
               of executing loop on all RCs and accessing DPCs multiple times
               for each iteration of loop on RCs */

            /* This route is active as the sap in dpcCb is bound */
            /* match the owner id with any of the RC's sent in ASPM mesg */
            for (j = rcOkCount; j < *nrCtxLen; j++)
            {
               if (dpcCb->owner->psCfg.psId == nrCtx[j].rtCtx)
               {
                  /* Swap the matched RC with list */
                  rCtxTmp = nrCtx[rcOkCount];
                  nrCtx[rcOkCount++] = nrCtx[j];
                  nrCtx[j] = rCtxTmp;
                  break; /* from the for loop */
               }
            }
         }
      }
      else /* dpcCb->route != 0, i.e., Dpc has 1 or more than 1 RCB */
      {
         /* Search DPC's RCB(s) to find matched RCs, SAPs and if
            SAP's state is BOUND then increment the rcOkCount */
         IT_SEARCH_RCB_NSAP(&dpcCb->routes, nrCtx, *nrCtxLen, rcOkCount);
      } /* End of if (dpcCb->route == 0) */
   } /* End of while on DPCs */

   /* Search in global list, if any of the RC is not matched yet */
   if (rcOkCount != *nrCtxLen)
   {
      IT_SEARCH_RCB_NSAP(&itGlobalCb.addrTrn.rtList, nrCtx, *nrCtxLen,
                         rcOkCount);
   } /* end of if (rcOkCount != *nrCtxLen) */

   /* Get the list of all rejected RCs into irCtx */
   if (rcOkCount != *nrCtxLen)
   {
      for (j = rcOkCount; j < *nrCtxLen; j++)
      {
         irCtx[*irCtxLen] = nrCtx[j]; 
         (*irCtxLen)++;
      }
   } /* End of if (rcOkCount != *nrCtxLen) */

   /* Get the valid RC count in *nrCtxLen */
   *nrCtxLen = rcOkCount;

  RETVOID;
} /* End of function itPsmChkRcRdyRcvTraf */
#endif /* (defined(ITASP) && defined(OG_RTE_ON_LPS_STA)) */

#ifndef SNT_BACK_COMP_MERGED_NIF
#ifdef ITSG

/*
*
*       Fun:   itLiBndMtp3Sap
*
*       Desc:  Bind an Mtp3 SAP. Call ItLiSntBndReq and start a timer.
*
*       Ret:   Failure: RFAILED
*
*              Success: ROK
*
*       Notes: Called by LMI(control)
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLiBndMtp3Sap
(
SuId          suId,           /* service user ID */
CmStatus      *sta,           /* returned status */
Bool          first           /* TRUE for first try */
)
#else
PUBLIC S16 itLiBndMtp3Sap (suId, sta, first)
SuId          suId;           /* service user ID */
CmStatus      *sta;           /* returned status */
Bool          first;          /* TRUE for first try */
#endif
{
   ItNSapCb  *sapCb;        /* MTP3 SAP control block */
   S16        ret;          /* Return values */

   TRC2(itLiBndMtp3Sap)

   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "itLiBndMtp3Sap(suId(%d), sta)\n", suId));

   ret   = RFAILED;
   sapCb = itGlobalCb.nSap[suId];

   if (first == TRUE)
   {
      sapCb->nmbBndRetry = 0;
   }
   
   switch (sapCb->sntSta.hlSt)
   {
      case LIT_SAP_UNBOUND:
      case LIT_SAP_WAIT_BNDCFM:
         /* Send BndReq */   
         if (sapCb->nmbBndRetry < IT_MAX_MTP3_BND_RETRY)
         {
            sapCb->nmbBndRetry++;

            /* Start bind confirm timer */
            itTcStartTimer(&sapCb->tmrPrim, (PTR)sapCb, IT_TMR_MTP3_SAP_BND, 
                           &sapCb->sntCfg.tmrPrim);
            /* State should change before invoking BndReq */
            sapCb->sntSta.hlSt = LIT_SAP_WAIT_BNDCFM;
            (Void) ItLiSntBndReq(&sapCb->pst, suId, sapCb->sntCfg.mtp3SapId,
                                  SI_MTP3);
            if (sta != (CmStatus *)NULLP)
            {
               sta->status = LCM_PRIM_OK;
               sta->reason = LCM_REASON_NOT_APPL;
            }
            RETVALUE(ROK);
         }
         /* If we haven't exited yet, we send status indication */
         (Void) itMiStaInd(STITNSAP, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_BND_FAIL, LIT_CAUSE_RETRY_EXCEED, 
                           (U32)suId);

         if (sta != (CmStatus *)NULLP)
         {
            sta->status = LCM_PRIM_NOK;
            sta->reason = LCM_REASON_MISC_FAILURE;
         }
         ret = RFAILED;
         break;      
      case LIT_SAP_BOUND:
         if (sta != (CmStatus *)NULLP)
         {
            sta->status = LCM_PRIM_OK;
            sta->reason = LCM_REASON_NOT_APPL;
         }
         ret = ROK;
         break;
      default:
         if (sta != (CmStatus *)NULLP)
         {
            sta->status = LCM_PRIM_NOK;
            sta->reason = LCM_REASON_INVALID_STATE;
         }
         ret = RFAILED;
         break;

   }
   RETVALUE(ret);
} /* end of itLiBndMtp3Sap */

/*
*
*       Fun:   itLiBndMtp3TmrExp
*
*       Desc:  Bind confirm timer expired. Increment retry counter and
*              retry. If counter is greater than the configured maximum,
*              call MI to indicate control failure.
*
*       Ret:   Failure:
*
*              Success: ROK
*
*       Notes: <none>
*
*       File:  it_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 itLiBndMtp3TmrExp
(
ItNSapCb    *sntSap         /* SnT SAP control block */
)
#else
PUBLIC S16 itLiBndMtp3TmrExp (sntSap)
ItNSapCb    *sntSap;        /* SnT SAP control block */
#endif
{
   TRC2(itLiBndMtp3TmrExp)

   ITDBGP(DBGMASK_LI, (itGlobalCb.itInit.prntBuf, 
          "itLiBndMtp3TmrExp(sntSap)\n"));

   /* Send another bind request */
   RETVALUE(itLiBndMtp3Sap(sntSap->sntCfg.sapId, (CmStatus*)NULLP, FALSE));
} /* end of itLiBndTmrExp */

#endif
#endif /* SNT_BACK_COMP_MERGED_NIF */
/********************************************************************30**

         End of file:     it_bdy4.c@@/main/7 - Thu Apr  1 03:51:48 2004

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:

*********************************************************************61*/
/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/3      ---      nj   1. initial release.
/main/3      ---      nt   1. Changes for TCR18,
                              the controlling entity is added at
                              the time of configuring Lower SAP. 
             ---      nt   2. Changes for removing warnings.
             ---      mrw  3. Update to Release 1.2
             ---      pn   4. Removed itAtStaCfm func - never used
                           5. Removed check for suId range in itLiCfgSap
                              - this already gets done in ItMiLitCfgReq
/main/4      ---      sg   1. Routing, IPSP and Loadshare changes.
             ---      sg   2. Update to Release 1.3
/main/5      ---      sg   1. Update to Release 1.4
/main/5    it001.104  sg   1. Changes for Outgoing Message Routing based on
                              Local PS status at ASP/IPSP.
           it001.104  vt   2. Changes for cfgForAllLps.
           it001.104  vt   3. Patch propagation from 1.2
/main/5    it002.104  sg   1. Changes for SG view for DPC status on ASP.
                           2. All patches of ver 1.3 has been propagated.
           it007.104  an   1. SAP STATE should change before calling EndCfm.
           it009.104  an   1. In IPSP-DE ASP-UP and ASP-DN are Optional
           it010.104  an   1. In case of IPSP-DE we create local PS also 
                              so delete that also
/main/5    it011.104  sg   1. Added check in itPsmCfgPs, to update Routing 
                              Context, as static, in PS control block during 
                              reconfiguration only if PS reconfig is not 
                              dynamic.
/main/5    it013.104  vt   1. Logic for deletion of PS corrected
           it013.104  vt   2. Incorrect function specified in itA010.104  
           it013.104  vt   3. Corrected the logic to call MifPsEvt function
                              in Down state. 
           it013.104  vt   4. it013.104 Fix for Larger configuration of PS 
                              and DPCs 
/main/5    it014.104  vt   1. Changes done to delete ACtive Remote PS at ASP
                           2. Changes done for problem in which DPC is struck
                              to Unavailable state in SGVIEW 
                           3. Changes done for making the DPC into Available 
                              state after being added to an active SGP.
/main/5    it015.104  vt   1. Changes done to cleanup spAssocId after
                              de-activation 
/main/5    it016.104  vt   1. Initialize the statistics
                           2. added SCT SAP status argument
                           3. changes to provide proper status indication 
/main/5    it018.104  vt   1. PSP destination Re-configuration changes
                           2. Association abort handling
/main/5    it019.104  vt   1. Missing check for node type added
                           2. Changes to allowing Same RC for LPS and RPS 
                              in case of IPSP DE
                           3. Changes done to allow IPSP DE to be able to 
                              send ASP Down in case the remote IPSP has 
                              not de-registered.
/main/5    it021.104  nt   1. Changes done to accept ASPAC in IPSP SE only when
                              the AS is ready to receive the traffic.  
                           2. Changes done to stop sending traffic in IPSP SE when
                              peer node sends ASPIA for an AS. 
/main/5    it022.104  uv   1. Additions for route alarms
/main/6      ---      nt   1. Update to Release 1.5
/main/7      ---      rs   1. Update to Release 1.6.
/main/7    it001.106  nt   1. Correct AssocId is used in round robin and lscUpd
                              function.
                      sg   2. Change in itAcReleaseSap for terminating the 
                              association if not already terminated and marking
                              it to down state on receiving sct sap unbind
                              request.
                           3. Hash key type changed to CM_HASH_KEYTYPE_U32MOD
/main/7    it004.106  vt   1. Changes in itLiCfgSap to set srcProcId if FTHA or
                              DFTHA.
                      sg   2. Changes to add abrtFlg param in itLiTermReq and 
                              itAcTerm unconditionally, even if IT_ABORT_ASSOC
                              not defined.
                           3. Changes in itAcReleaseSap to abort the assoc   
                              always.
/main/7    it007.106  vt   1. Changes done to remove code warnings. 
/main/7    it009.106  sg   1. Added check to disallow the reconfiguration of 
                              TOS param in ItAssocCfg.
                           2. Added TOS param in association request and 
                              association response to SCTP.
                           3. Changes for IPSP-SE, Remote PS becomes Active 
                              on (re)configuration if peer IPSP is already 
                              Active.
/main/7    it010.106  sg   1. Changes in itAcTerm for the case when control 
                              request, for termination, is received while 
                              association is being established.
/main/7    it011.106  sg   1. The interface ID corrected to SCTIF in SCT SAP 
                              config function itLiCfgSap. 
/main/7    it013.106  sg   1. Changes in itPsmAspUp to send Error message if 
                              an IPSP-DE sends ASPUP after sending ASPAC. 
                           2. Change in itAcInh to return RFAILED if aspSt is 
                              not Down.
                           3. Changes in itLiBndSap and itLiEndpOpen to use
                              correct event defines while calling itMiStaInd 
                              when number of retries exceed the maximum.
/main/7   it015.106   sg   1. For IPSP DE check if peer is UP before sending
                              Active message to it
                           2. Changes in function itAcStaInd to add the case 
                              for SCT_STATUS_SND_FAIL, delete case for 
                              SCT_STATUS_COMM_LOST, move the calls to zvRTUpd 
                              for assocCb and itAcAssocEvt within the switch 
                              case handling.
                           3. Change in itAssocEvt to replace event 
                              LIT_EVENT_STATUS_IND with LIT_EVENT_SEND_FAIL. 
                              This new event is used when M3UA receives 
                              SctStaInd with status as SCT_STATUS_SND_FAIL.
/main/7    it016.106  sg   1. Changes for new association congestion and
                              unavailability statistics.
                           2. Change in itPsmAspDn to stop tmrAspm when PSP 
                              goes down due to association termination and 
                              not due to ASPDN-Ack received from peer.
                           3. Changes to make storing of ASPID optional
                              when rxTxAspId is FALSE. So, even if rxTxAspId 
                              is FALSE send ASPID(if available) in Notify.
/main/7    it018.106  sb   1. M3UA DFTHA Enhancement.   
                           2. Made changes to send runtime update for following 
                              newly added table Types:
                              a.ZV_PS_ENDP_PSPSTA   
                              b.ZV_PS_ENDP_ACTPSP
                              c.ZV_PS_ENDP_RCTX  
                              d.ZV_PSP_ACTPS     
                              e.ZV_PSP_REGPS  
                              f.ZV_DPCSTA       
                              g.ZV_ASPID         
/main/7    it020.106  sg   1. Changes in itPsmAspAc and itPsmAspIa to stop
                              tmrAspm when the ASPAC-Ack/ASPIA-Ack is valid.
/main/7    it023.106  sg   1. Changes to update and initialise PS statistics 
                              under compilation flag LITV6.
                           2. Changes to not mark the association down on
                              receiving SctStaInd with status as 
                              SCT_STATUS_SND_FAIL.
*********************************************************************91*/
