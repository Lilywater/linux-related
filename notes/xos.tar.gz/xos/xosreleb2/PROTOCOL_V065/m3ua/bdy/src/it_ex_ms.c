/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/


/********************************************************************20**

     Name:     Contains message activation functions for M3UA interfaces. 

     Type:     C source file

     Desc:     Functions for scheduling loosely coupled incoming events

     File:     it_ex_ms.c

     Sid:      it_ex_ms.c@@/main/7 - Thu Apr  1 03:52:25 2004

     Prg:      jdb

*********************************************************************21*/

/*

  it_ex_ms.c -

  Following functions are provided in this file:  
  
     itInitExt        initialization - external
     itActvTsk        task activation - loosely coupled interfaces

*/

/*
 *     this software may be combined with the following TRILLIUM
 *     software:
 *
 *     part no.                      description
 *     --------    ----------------------------------------------
 *     1000163                      SCTP layer
 */

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_ss7.h"        /* common SS7 */
#include "cm_tpt.h"        /* common transport defines */
#include "lit.h"           /* layer management M3UA  */
#include "sct.h"           /* SCT interface */
#include "snt.h"           /* SNT interface */
#ifdef IT_FTHA             
#include "sht.h"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "it.h"            /* M3UA internal defines */
#include "it_err.h"        /* M3UA error */
#ifdef ZV
#include "cm_ftha.h"
#include "cm_psfft.h"          /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.h"
#include "cmzvdvlb.h"
#endif /* ZV_DFTHA */
#include "mrs.h"
#include "lzv.h"
#include "zv.h"            /* m3ua  PSF */
#endif /* ZV */

/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_ss7.x"        /* common SS7 */
#include "cm_tpt.x"        /* common transport */
#include "sct.x"           /* SCT interface */
#ifdef IT_FTHA            
#include "sht.x"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "lit.x"           /* layer management M3UA */
#include "snt.x"           /* SNT interface */
#include "it.x"            /* M3UA internal typedefs */
#ifdef ZV
#include "cm_ftha.x"
#include "cm_psfft.x"
#ifdef ZV_DFTHA
#include "cmzvdv.x"
#include "cmzvdvlb.x"
#endif
#include "mrs.x"
#include "lzv.x"
#include "zv.x"            /* m3ua PSF */
#endif /* ZV */
/* public routines */


/*
*
*       Fun:   itInitExt
*
*       Desc:  Initializes variables used to interface with Upper/Lower
*              Layer
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*
*       Notes: None
*
*       File:  it_ex_ms.c
*
*/

#ifdef ANSI
PUBLIC S16 itInitExt
(
)
#else
PUBLIC S16 itInitExt()
#endif
{
   TRC2(itInitExt)
   RETVALUE(ROK);
} /* end of itInitExt */


/*
*
*       Fun:    activate task
*
*       Desc:   Processes received event from SCTP layer.
*               - Unpack the post structure
*               - Pass parameters to procedure in it_bdy1.c
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   it_ex_ms.c
*
*/

#ifdef ANSI
PUBLIC S16 itActvTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 itActvTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   S16 ret;                 /* return valu */
#ifdef PERF_TEST
   Bool lclTimeStmpFlg = FALSE;      /* local time stamp flag */
#endif /* PERF_TEST */

   TRC3(itActvTsk)
#ifdef PERF_TEST
   if ( timeStmpFlg == TRUE)
   {
      gettimeofday(&time1, NULL);
      lclTimeStmpFlg = TRUE;
      timeStmpFlg = FALSE; /* this is to prevent overwriting of time1
                                  in the primitive handling fn. */
   }
#endif /* PERF_TEST */

   ret = ROK;
   switch (pst->srcEnt)
   {
#ifdef LCITLISCT
      case ENTSB:                      /* SCTP */
         switch (pst->event)
         {
            case SCT_EVTBNDCFM:        /* Bind confirm */
               ret = cmUnpkSctBndCfm(ItLiSctBndCfm, pst, mBuf);
               break;
            case SCT_EVTASSOCIND:      /* Assoc. Establishment indication */
               ret = cmUnpkSctAssocInd(ItLiSctAssocInd, pst, mBuf);
               break;
            case SCT_EVTASSOCCFM:      /* Assoc. Establishment confirmation */
               ret = cmUnpkSctAssocCfm(ItLiSctAssocCfm, pst, mBuf);
               break;
            case SCT_EVTTERMIND:       /* Association Termination indication */
               ret = cmUnpkSctTermInd(ItLiSctTermInd, pst, mBuf);
               break;
            case SCT_EVTTERMCFM:       /* Assoc. Termination confirmation */
               ret = cmUnpkSctTermCfm(ItLiSctTermCfm, pst, mBuf);
               break;
            case SCT_EVTDATIND:        /* Data Indication */
               ret = cmUnpkSctDatInd(ItLiSctDatInd, pst, mBuf);
               break;
            case SCT_EVTSTACFM:        /* Status confirm */
               ret = cmUnpkSctStaCfm(ItLiSctStaCfm, pst, mBuf);
               break;
            case SCT_EVTSTAIND:        /* Status Indication */
               ret = cmUnpkSctStaInd(ItLiSctStaInd, pst, mBuf);
               break;
            case SCT_EVTFLCIND:        /* Flow control indication */
               ret = cmUnpkSctFlcInd(ItLiSctFlcInd, pst, mBuf);
               break;
            case SCT_EVTENDPOPENCFM:   /* Endpoint open confirmation */
               ret = cmUnpkSctEndpOpenCfm(ItLiSctEndpOpenCfm, pst, mBuf);
               break;
            case SCT_EVTENDPCLOSECFM:  /* Endpoint close confirmation */
               ret = cmUnpkSctEndpCloseCfm(ItLiSctEndpCloseCfm, pst, mBuf);
               break;
            default:
#if (ERRCLASS & ERRCLS_DEBUG)
               ITLOGERROR(ERRCLS_DEBUG, EIT443, (ErrVal) pst->event,
               "itActvTsk: Invalid event specified for srcEnt (ENTSB)"); 
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
               SPutMsg(mBuf);
               ret = RFAILED;
               break;
         }
         break;
#endif  /* LCITLISCT */

#ifdef LCITUISNT
/* it013.106 - addition - support for GCP */   
      case ENTMG:
      case ENTSI:
      case ENTTP:
      case ENTSP:
      case ENTAL2:
#ifdef SNT_BACK_COMP_MERGED_NIF
      case ENTNF:
#endif
         switch (pst->event)
         {
            case EVTSNTBNDREQ:
               ret = cmUnpkSntBndReq(ItUiSntBndReq, pst, mBuf);
               break;
            case EVTSNTUDATREQ:
               ret = cmUnpkSntUDatReq(ItUiSntUDatReq, pst, mBuf);
               break;
#ifdef SNT2
            case EVTSNTSTAREQ:
               ret = cmUnpkSntStaReq(ItUiSntStaReq, pst, mBuf);
               break;
#endif /* SNT2 */
/* 
#ifdef SNT_BACK_COMP_MERGED_NIF
*/
#ifdef SNTIWF
            case EVTSNTSTAAPYREQ:
            case EVTSNTSTAAPYIND:
               ret = cmUnpkSntStaApyReq(ItLiSntStaApyInd, pst, mBuf);
               break;
            case EVTSNTSTAQRYREQ:
            case EVTSNTSTAQRYIND:
               ret = cmUnpkSntStaQryReq(ItLiSntStaQryInd, pst, mBuf);
               break;
            case EVTSNTSTAQRYRSP:
            case EVTSNTSTAQRYCFM:
               ret = cmUnpkSntStaQryRsp(ItLiSntStaQryCfm, pst, mBuf);
               break;
#endif /* SNTIWF */
/*
#endif  SNT_BACK_COMP_MERGED_NIF */

            default:
#if (ERRCLASS & ERRCLS_DEBUG)
               ITLOGERROR(ERRCLS_DEBUG, EIT444, (ErrVal) pst->event,
               "itActvTsk: Invalid event specified for srcEnt"); 
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
               SPutMsg(mBuf);
               ret = RFAILED;
               break;
         }
         break;
#endif /* LCITUISNT */

#ifdef LCITLISNT
#ifdef SNTIWF
      case ENTSN:
        {
          switch(pst->event)
          {
            case EVTSNTSTAAPYREQ:
            case EVTSNTSTAAPYIND:
               ret = cmUnpkSntStaApyReq(ItLiSntStaApyInd, pst, mBuf);
               break;
            case EVTSNTSTAQRYREQ:
            case EVTSNTSTAQRYIND:
               ret = cmUnpkSntStaQryReq(ItLiSntStaQryInd, pst, mBuf);
               break;
            case EVTSNTSTAQRYRSP:
            case EVTSNTSTAQRYCFM:
               ret = cmUnpkSntStaQryRsp(ItLiSntStaQryCfm, pst, mBuf);
               break;
#ifndef SNT_BACK_COMP_MERGED_NIF
            case EVTSNTBNDCFM:        /* Bind confirm */
               ret = cmUnpkSntBndCfm(ItLiSntBndCfm, pst, mBuf);
               break;
            case EVTSNTUDATIND:
               ret = cmUnpkSntUDatInd(ItLiSntUDatInd, pst, mBuf);
               break;
#endif
            default:
#if (ERRCLASS & ERRCLS_DEBUG)
               ITLOGERROR(ERRCLS_DEBUG, EIT445, (ErrVal) pst->event,
               "itActvTsk: Invalid event specified for srcEnt"); 
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
               SPutMsg(mBuf);
               ret = RFAILED;
               break;
            }
         }
         break;
#endif /* SNTIWF */
#endif /* LCITLISNT */

#ifdef LCITMILIT     /* loosely coupled layer manager */
      case ENTSM:
         switch (pst->event)
         {

            case EVTLITCFGREQ:       /* Configuration Request */
               ret = cmUnpkLitCfgReq(ItMiLitCfgReq, pst, mBuf);
               break;
            case EVTLITSTSREQ:       /* Statistics Request */
               ret = cmUnpkLitStsReq(ItMiLitStsReq, pst, mBuf);
               break;
            case EVTLITCNTRLREQ:     /* Control Request */
               ret = cmUnpkLitCntrlReq(ItMiLitCntrlReq, pst, mBuf);
               break;
            case EVTLITSTAREQ:       /* Status Request */
               ret = cmUnpkLitStaReq(ItMiLitStaReq, pst, mBuf);
               break;
            default:
#ifdef ZV
               zvActvTsk(pst, mBuf);
#else
#if (ERRCLASS & ERRCLS_DEBUG)
               ITLOGERROR(ERRCLS_DEBUG, EIT446, (ErrVal) pst->event,
               "itActvTsk: Invalid srcEnt"); 
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
               SPutMsg(mBuf);
               ret = RFAILED;
#endif /* ZV */
               break;
         }
         break;
#endif /* LCITMILIT */

#ifdef IT_FTHA             
      case ENTSH:
         switch (pst->event)
         {

            case EVTSHTCNTRLREQ:     /* system agent control request */
               ret = cmUnpkMiShtCntrlReq(ItMiShtCntrlReq, pst, mBuf);
               break;
/* Following case statements have been added specifically
   for scenarios where IT_FTHA is enabled in CORE1 architecture, */
#ifdef LCITMILIT     /* loosely coupled layer manager */
#ifdef M3UA_CORE1
            case EVTLITCFGREQ:       /* Configuration Request */
               ret = cmUnpkLitCfgReq(ItMiLitCfgReq, pst, mBuf);
               break;
            case EVTLITSTSREQ:       /* Statistics Request */
               ret = cmUnpkLitStsReq(ItMiLitStsReq, pst, mBuf);
               break;
            case EVTLITCNTRLREQ:     /* Control Request */
               ret = cmUnpkLitCntrlReq(ItMiLitCntrlReq, pst, mBuf);
               break;
            case EVTLITSTAREQ:       /* Status Request */
               ret = cmUnpkLitStaReq(ItMiLitStaReq, pst, mBuf);
               break;
#endif
#endif
            default:
#ifdef ZV
               /* the event received could be PSF event */
               zvActvTsk(pst, mBuf);
#else 
#if (ERRCLASS & ERRCLS_DEBUG)
               ITLOGERROR(ERRCLS_DEBUG, EIT447, (ErrVal) pst->event,
               "itActvTsk: Invalid event for ENTSH"); 
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
               SPutMsg(mBuf);
               ret = RFAILED;
#endif /* ZV */
               break;
         }
         break;
#endif /* IT_FTHA */

#ifdef ZV
      /* event from M3UA (self or peer) layer */
      case ENTIT:
         /* the event received could be PSF event */
         zvActvTsk(pst, mBuf);
         break;
#endif /* ZV */

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         ITLOGERROR(ERRCLS_DEBUG, EIT448, (ErrVal) pst->event,
         "itActvTsk: Invalid event specified for srcEnt (ENTSM)"); 
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         SPutMsg(mBuf);
         ret = RFAILED;
         break;
   }

#ifdef IT_RUG
   if ((ret == RINVIFVER) && (itGlobalCb.itInit.cfgDone == TRUE))
   {
      (Void) itMiStaInd(STITGEN, LCM_CATEGORY_INTERFACE, LCM_EVENT_INV_EVT, 
                        LCM_CAUSE_DECODE_ERR, 0);
   }
#endif /* IT_RUG */

#ifdef PERF_TEST  /* M3UA PERFORMANCE TESTING */
   if (lclTimeStmpFlg == TRUE)
   {
       gettimeofday(&time2, NULL);
       timeA.tv_usec += (time2.tv_usec - time1.tv_usec);
       if (time2.tv_usec < time1.tv_usec)
       {
               timeA.tv_usec += 1000000;
               time2.tv_sec--;
       }
       timeA.tv_sec += (time2.tv_sec - time1.tv_sec);
       if (timeA.tv_usec >= 1000000)
       {
               timeA.tv_usec -= 1000000;
               timeA.tv_sec++;
       }
       timeStmpFlg = TRUE;
   }
#endif /* PERF_TEST */

   SExitTsk();
   RETVALUE(ret);
} /* end of itActvTsk */


/********************************************************************30**

         End of file:     it_ex_ms.c@@/main/7 - Thu Apr  1 03:52:25 2004

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/3      ---      mrw  1. Initial version
/main/3      ---      nt   1. Changes for TCR18:
                              system agent control request handled in
                              itActvTsk
             ---      as   2. Updates to Release 1.2
/main/4      ---      sg   1. Update to Release 1.3
/main/5      ---      sg   1. Update to Release 1.4
/main/5    it011.104  sg   1. Added a case for ENTTP (TUP) in itActvTsk.
/main/6      ---      nt   1. Update to Release 1.5
/main/7      ---      rs   1. Update to Release 1.6.
/main/7    it013.106  sg   1. Support for GCP added.
*********************************************************************91*/
