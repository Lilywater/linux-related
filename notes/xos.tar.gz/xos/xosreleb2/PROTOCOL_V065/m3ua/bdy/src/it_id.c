/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:    M3UA Layer

     Type:    C source file

     Desc:    product id file

     File:    it_id.c

     Sid:      it_id.c@@/main/7 - Thu Apr  1 03:52:36 2004

     Prg:     pn

*********************************************************************21*/

/* header include files (.h) */

#include "envopt.h"           /* environment options */
#include "envdep.h"           /* environment dependent */
#include "envind.h"           /* environment independent */

#include "gen.h"              /* general layer */
#include "ssi.h"              /* system services */
#include "lit.h"              /* layer management */

/* header/extern include files (.x) */

#include "gen.x"              /* general layer */
#include "ssi.x"              /* system services */

/* defines */

#define ITSWMV 1            /* M3UA - main version */
#define ITSWMR 6            /* M3UA - main revision */
#define ITSWBV 0            /* M3UA - branch version */
#define ITSWBR 23           /* M3UA - For patch it023.106 */
#define ITSWPN "1000192"    /* M3UA - part number */


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* forward references */

PUBLIC S16 itGetSid ARGS((SystemId *sid));

/* public variable declarations */

/* copyright banner */

CONSTANT PUBLIC Txt itBan1[] =
      {"(c) COPYRIGHT 1989-2000, Trillium Digital Systems, Inc."};
CONSTANT PUBLIC Txt itBan2[] =
      {"                 All rights reserved."};

/* system id */

PRIVATE CONSTANT SystemId sId ={
   ITSWMV,                    /* main version */
   ITSWMR,                    /* main revision */
   ITSWBV,                    /* branch version */
   ITSWBR,                    /* branch revision */
   ITSWPN,                    /* part number */
};


/*
*     support functions
*/


/*
*
*       Fun:   itGetSid
*
*       Desc:  Get system id consisting of part number, main version and
*              revision and branch version and branch.
*
*       Ret:   TRUE      - ok
*
*       Notes: None
*
*       File:  it_id.c
*
*/

#ifdef ANSI
PUBLIC S16 itGetSid
(
SystemId *s                 /* system id */
)
#else
PUBLIC S16 itGetSid(s)
SystemId *s;                /* system id */
#endif
{
   TRC2(itGetSid)

   s->mVer = sId.mVer;
   s->mRev = sId.mRev;
   s->bVer = sId.bVer;
   s->bRev = sId.bRev;
   s->ptNmb = sId.ptNmb;

   RETVALUE(TRUE);

} /* itGetSid */

#ifdef __cplusplus
}
#endif /* __cplusplus */



/********************************************************************30**

         End of file:     it_id.c@@/main/7 - Thu Apr  1 03:52:36 2004

*********************************************************************31*/
/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/3      ---      pn  1. initial release.
                      nt  1. Branch Revision 1 for it001.11
/main/3      ---      nt  1. Branch Revision 2 for it004.11
             ---      mrw 2. Updates to Release 1.2
/main/4      ---      sg  1. Main Revision changed to 3.
             ---      sg  2. Updates to Release 1.3
/main/5      ---      sg  1. Update to Release 1.4
/main/5    it001.104  sg  1. Branch Revision 1 for it001.104
      5    it004.104  cg  1. Branch Revision 4 for it004.104
           it005.104  cg  1. Branch Revision 5 for it005.104
           it006.104  an  1. Branch Revision 6 for it006.104
           it007.104  cg  1. Branch Revision 7 for it007.104
           it008.104  an  1. branch Revision 8 for it008.104
           it009.104  an  1. branch Revision 9 for it009.104
           it010.104  an  1. branch Revision 10 for it010.104
/main/5    it011.104  sg  1. Branch Revision 11 for it011.104
/main/5    it012.104  sg  1. Branch Revision 12 for it012.104
/main/5    it013.104  vt  1. Branch Revision 13 for it013.104
/main/5    it014.104  vt  1. Branch Revision 14 for it014.104
/main/5    it015.104  vt  1. Branch Revision 15 for it015.104
/main/5    it016.104  vt  1. Branch Revision 16 for it016.104
/main/5    it017.104  vt  1. Branch Revision 17 for it017.104
/main/5    it019.104  nt  1. Branch Revision 19 for it019.104
/main/5    it020.104  nt  1. Branch Revision 20 for it020.104
/main/5    it021.104  nt  1. Branch Revision 21 for it021.104
/main/5    it022.104  uv  1. Branch Revision 22 for it022.104
/main/5    it023.104  uv  1. Branch Revision 22 for it023.104
/main/6      ---      nt   1. Update to Release 1.5
/main/7      ---      rs  1. Update to release 1.6.
/main/7    it001.106  nt  1. Branch Revision 1 for it001.106
/main/7    it002.106  sg  1. Branch Revision 2 for it002.106
/main/7    it003.106  sg  1. Branch Revision 3 for it003.106
/main/7    it004.106  sg  1. Branch Revision 4 for it004.106
/main/7    it005.106  sg  1. Branch Revision 5 for it005.106
/main/7    it006.106  sg  1. Branch Revision 6 for it006.106
/main/7    it007.106  vt  1. Branch Revision 7 for it007.106
/main/7    it008.106  vt  1. Branch Revision 8 for it008.106
/main/7    it009.106  sg  1. Branch Revision 9 for it009.106
/main/7    it010.106  sg  1. Branch Revision 10 for it010.106
/main/7    it011.106  sg  1. Branch Revision 11 for it011.106
/main/7    it012.106  jc  1. Branch Revision 12 for it012.106
/main/7    it013.106  sg  1. Branch Revision 13 for it013.106
/main/7    it014.106  sg  1. Branch Revision 14 for it014.106
/main/7    it015.106  sg  1. Branch Revision 15 for it015.106
/main/7    it016.106  sg  1. Branch Revision 16 for it016.106
/main/7    it017.106  sb  1. Branch Revision 17 for it017.106
/main/7    it018.106  sb  1. Branch Revision 18 for it018.106
/main/7    it019.106  sg  1. Branch Revision 19 for it019.106
/main/7    it020.106  sg  1. Branch Revision 20 for it020.106
/main/7    it021.106  sg  1. Branch Revision 21 for it021.106
/main/7    it022.106  sg  1. Branch Revision 22 for it022.106
/main/7    it023.106  sg  1. Branch Revision 23 for it023.106
*********************************************************************91*/
