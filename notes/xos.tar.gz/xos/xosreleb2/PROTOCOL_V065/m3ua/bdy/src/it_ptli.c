/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/


/********************************************************************20**

     Name:     it_ptli.c - M3UA layer portable lower layer interface

     Type:     C source file

     Desc:     C source code for the outgoing lower layer primitives 
               (originating at the service user) used in loosely/tightly 
               coupled systems. The two sections of the file are:
               - The setting up of the primitive mapping table
               - Transmission of the primitives using the mapping table.

     File:     it_ptli.c

     Sid:      it_ptli.c@@/main/7 - Thu Apr  1 03:52:47 2004

     Prg:      jdb

*********************************************************************21*/

/*

  it_ptli.c -

Following public functions are provided in this file:
 * ItLiSctBndReq            - Bind request
 * ItLiSctEndpOpenReq       - Open endpoint request
 * ItLiSctEndpCloseReq      - Close endpoint request
 * ItLiSctAssocReq          - Association Establish request
 * ItLiSctAssocRsp          - Association Establish response
 * ItLiSctTermReq           - Association Termination request
 * ItLiSctSetPriReq         - Set Primary Destination Network Address request
 * ItLiSctHBeatReq          - Enable/Disable Heartbeat request
 * ItLiSctDatReq            - Data request
 * ItLiSctStaReq            - Status request
 * ItLiSntBndReq            - Bind request to MTP3 SAP
 * ItLiSntStaQryReq         - Status Query request to MTP3
 * ItLiSntStaApyReq         - Status Apply request to MTP3
 * ItLiSntStaQryRsp         - Status Query Response to MTP3
 * ItLiSntUDatReq           - UDat request to MTP3
*/

/*
 *     this software may be combined with the following TRILLIUM
 *     software:
 *
 *     part no.                      description
 *     --------    ----------------------------------------------
 *     1000163                      SCTP layer
 */

/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_ss7.h"        /* common SS7 */
#include "cm_tpt.h"        /* common transport defines */
#include "lit.h"           /* layer management M3UA  */
#include "sct.h"           /* SCT interface */
#include "it.h"            /* M3UA internal defines */
#include "it_err.h"        /* M3UA error */
#include "snt.h"           /* SNT interface */

/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_ss7.x"        /* common SS7 */
#include "cm_tpt.x"        /* common transport */
#include "sct.x"           /* SCT interface */
#ifdef IT_FTHA            
#include "sht.x"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "lit.x"           /* layer management M3UA */
#include "it.x"            /* M3UA internal typedefs */
#include "snt.x"           /* SNT interface */


/* local defines */
#ifndef LCITLISCT
#define PTITLISCT
#else
#ifndef SB
#define PTITLISCT
#endif
#endif

#ifndef LCITLISNT
#define PTITLISNT
#else
#ifndef L3/*2006 3 30 chenning*/
#define PTITLISNT
#endif
#endif

#define IT_MAX_SCT_SEL               2

/* forward references */
#ifdef PTITLISCT
PRIVATE S16 PtLiSctBndReq            ARGS((Pst           *pst,
                                          SuId           suId,
                                          SpId           spId));

#ifdef SCT_ENDP_MULTI_IPADDR
PRIVATE S16 PtLiSctEndpOpenReq       ARGS((Pst           *pst,
                                          SpId           spId,
                                          UConnId        suEndpId,
                                          SctPort        port,
                                          SctNetAddrLst  *srcAddrLst));
#else
PRIVATE S16 PtLiSctEndpOpenReq       ARGS((Pst           *pst,
                                          SpId           spId,
                                          UConnId        suEndpId,
                                          SctPort        port,
                                          CmNetAddr     *intfNAddr));
#endif
PRIVATE S16 PtLiSctEndpCloseReq      ARGS((Pst           *pst,
                                          SpId           spId,
                                          UConnId        endpId,
                                          U8             endpIdType));
#ifdef SCT3
PRIVATE S16 PtLiSctAssocReq          ARGS((Pst           *pst,
                                          SpId           spId,
                                          UConnId        spEndpId,
                                          UConnId        suAssocId,
                                          CmNetAddr     *priDstNAddr,
                                          SctPort        dstPort,
                                          SctStrmId      outStrms,
                                          SctNetAddrLst *dstNAddrLst,
                                          SctNetAddrLst *srcNAddrLst,
                                          SctTos         tos,
                                          Buffer        *vsInfo));
#else /* SCT3 */
PRIVATE S16 PtLiSctAssocReq          ARGS((Pst           *pst,
                                          SpId           spId,
                                          UConnId        spEndpId,
                                          UConnId        suAssocId,
                                          CmNetAddr     *priDstNAddr,
                                          SctPort        dstPort,
                                          SctStrmId      outStrms,
                                          SctNetAddrLst *dstNAddrLst,
                                          SctNetAddrLst *srcNAddrLst,
                                          Buffer        *vsInfo));
#endif /* SCT3 */
#ifdef SCT3
PRIVATE S16 PtLiSctAssocRsp          ARGS((Pst               *pst,
                                          SpId               spId,
                                          UConnId            spEndpId,
                                          SctAssocIndParams *assocIndParams,
                                          SctTos             tos,
                                          SctResult          result,
                                          Buffer            *vsInfo));
#else /* SCT3 */
PRIVATE S16 PtLiSctAssocRsp          ARGS((Pst               *pst,
                                          SpId               spId,
                                          UConnId            spEndpId,
                                          SctAssocIndParams *assocIndParams,
                                          SctResult          result,
                                          Buffer            *vsInfo));
#endif /* SCT3 */
PRIVATE S16 PtLiSctTermReq           ARGS((Pst           *pst,
                                          SpId           spId,
                                          UConnId        assocId,
                                          U8             assocIdType,
                                          Bool           abrtFlg));
PRIVATE S16 PtLiSctDatReq            ARGS((Pst           *pst,
                                          SpId           spId,
                                          UConnId        spAssocId,
                                          CmNetAddr     *dstNAddr,
                                          SctStrmId      strmId,
                                          Bool           unorderFlg,
                                          Bool           nobundleFlg,
                                          U16            lifeTime,
                                          U32            protId,
                                          Buffer        *mBuf));
PRIVATE S16 PtLiSctStaReq            ARGS((Pst           *pst,
                                          SpId           spId,
                                          UConnId        spAssocId,
                                          CmNetAddr     *dstNAddr,
                                          U8             staType));
#endif

#ifdef PTITLISNT
#ifdef SNTIWF
PRIVATE S16 PtLiSntBndReq ARGS ((Pst *pst, SpId suId, SpId spId, 
                                      SrvInfo srvInfo));
PRIVATE S16 PtLiSntStaQryReq ARGS ((Pst *pst, SuId suId, Dpc aPc, Dpc opc));
PRIVATE S16 PtLiSntStaApyReq ARGS ((Pst *pst, SuId suId, Dpc aPc, Dpc opc, 
                                    SrvInfo srvInfo, Status status, 
                                    Priority congLevel));
PRIVATE S16 PtLiSntStaQryRsp ARGS (( Pst *pst, 
                                      SuId suId, 
                                      Dpc aPc,  
                                      Dpc opc, 
                                      Status status,   
                                      Priority congLevel));
PRIVATE S16 PtLiSntUDatReq ARGS((Pst *pst, SpId spId, Dpc cgAdr, Dpc cdAdr, 
                 SrvInfo srvInfo, LnkSel lnkSel, Priority prior, Buffer *mBuf));
#endif /* SNTIWF */
#endif /* PTITLISNT */

/* private variable definitions */
#if (ERRCLASS & ERRCLS_DEBUG)
#if (defined(PTITLISCT) || (defined(PTITLISNT) && defined(SNTIWF)))
/* for logging purposes in error conditions for portable environment*/
PRIVATE Txt prntBuf[PRNTSZE];
#endif
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
/*
The following matrices define the mapping between the primitives
called by the upper layer interface of SCTP layer and the corresponding
primitives in the SCTP.

The parameter IT_MAX_SCT_SEL defines the maximum number of selector options
below the upper layer.
There is an array of functions per primitive invoked by the upper layer.
Every array is IT_MAX_SCT_SEL long.

The dispatching is performed by the configurable variable: selector.
The selector is configured during general configuration.

The selectors are:

   0 - loosely coupled (#define LCITLISCT)
   1 - Lsb (#define SB)

*/

 /* Bind request Primitive */
PRIVATE SctBndReq ItLiSctBndReqMt[IT_MAX_SCT_SEL] =
{
#ifdef LCITLISCT
   cmPkSctBndReq,          /* 0 - loosely coupled  */
#else
   PtLiSctBndReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef SB
   SbUiSctBndReq,          /* 1 - tightly coupled, layer management */
#else
   PtLiSctBndReq,          /* 1 - tightly coupled, portable */
#endif
};


/* Open endpoint request primitive */

PRIVATE SctEndpOpenReq ItLiSctEndpOpenReqMt[IT_MAX_SCT_SEL] =
{
#ifdef LCITLISCT
   cmPkSctEndpOpenReq,     /* 0 - loosely coupled */
#else
   PtLiSctEndpOpenReq,     /* 0 - tightly coupled, portable */
#endif
#ifdef SB
   SbUiSctEndpOpenReq,     /* 1 - tightly coupled, layer management */
#else
   PtLiSctEndpOpenReq,     /* 1 - tightly coupled, portable */
#endif
};

/* Close endpoint request primitive */

PRIVATE SctEndpCloseReq ItLiSctEndpCloseReqMt[IT_MAX_SCT_SEL] =
{
#ifdef LCITLISCT
   cmPkSctEndpCloseReq,     /* 0 - loosely coupled */
#else
   PtLiSctEndpCloseReq,     /* 0 - tightly coupled, portable */
#endif
#ifdef SB
   SbUiSctEndpCloseReq,     /* 1 - tightly coupled, layer management */
#else
   PtLiSctEndpCloseReq,     /* 1 - tightly coupled, portable */
#endif
};

/* Association request primitive */

PRIVATE SctAssocReq ItLiSctAssocReqMt[IT_MAX_SCT_SEL] =
{
#ifdef LCITLISCT
   cmPkSctAssocReq,        /* 0 - loosely coupled */
#else
   PtLiSctAssocReq,        /* 0 - tightly coupled, portable */
#endif
#ifdef SB
   SbUiSctAssocReq,        /* 1 - tightly coupled, layer management */
#else
   PtLiSctAssocReq,        /* 1 - tightly coupled, portable */
#endif
};

/* Association response primitive */

PRIVATE SctAssocRsp ItLiSctAssocRspMt[IT_MAX_SCT_SEL] =
{
#ifdef LCITLISCT
   cmPkSctAssocRsp,        /* 0 - loosely coupled */
#else
   PtLiSctAssocRsp,        /* 0 - tightly coupled, portable */
#endif
#ifdef SB
   SbUiSctAssocRsp,        /* 1 - tightly coupled, layer management */
#else
   PtLiSctAssocRsp,        /* 1 - tightly coupled, portable */
#endif
};

/* Association termination request primitive */

PRIVATE SctTermReq ItLiSctTermReqMt[IT_MAX_SCT_SEL] =
{
#ifdef LCITLISCT
   cmPkSctTermReq,        /* 0 - loosely coupled */
#else
   PtLiSctTermReq,        /* 0 - tightly coupled, portable */
#endif
#ifdef SB
   SbUiSctTermReq,        /* 1 - tightly coupled, layer management */
#else
   PtLiSctTermReq,        /* 1 - tightly coupled, portable */
#endif
};

/* Data request primitive */

PRIVATE SctDatReq ItLiSctDatReqMt[IT_MAX_SCT_SEL] =
{
#ifdef LCITLISCT
   cmPkSctDatReq,          /* 0 - loosely coupled */
#else
   PtLiSctDatReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef SB
   SbUiSctDatReq,          /* 1 - tightly coupled, layer management */
#else
   PtLiSctDatReq,          /* 1 - tightly coupled, portable */
#endif
};


/* Status request primitive */

PRIVATE SctStaReq ItLiSctStaReqMt[IT_MAX_SCT_SEL] =
{
#ifdef LCITLISCT
   cmPkSctStaReq,         /* 0 - loosely coupled */
#else
   PtLiSctStaReq,         /* 0 - tightly coupled, portable */
#endif
#ifdef SB
   SbUiSctStaReq,        /* 1 - tightly coupled, layer management */
#else
   PtLiSctStaReq,        /* 1 - tightly coupled, portable */
#endif
};


/*
*     Lower layer interface functions
*/


/*
*
*       Fun:   Bind request
*
*       Desc:  This function is used to bind two upper SAPs.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  It_ptli.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSctBndReq
(
Pst *pst,                 /* post structure */
SuId suId,                /* Su SAP Id */
SpId spId                 /* Sp SAP Id */
)
#else
PUBLIC S16 ItLiSctBndReq(pst, suId, spId)
Pst *pst;                 /* post structure */
SuId suId;                /* Su SAP Id */
SpId spId;                /* Sp SAP Id */
#endif
{
   TRC3(ItLiSctBndReq)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_MAX_SCT_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   /* jump to specific primitive depending on configured selector */
   RETVALUE((*ItLiSctBndReqMt[pst->selector])(pst, suId, spId));
  

} /* end of ItLiSctBndReq */


/*
*
*       Fun:   Opening of endpoint request
*
*       Desc:  This function is used to request the opening of
*              an endpoint at the SCTP layer.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  it_ptli.c
*
*/

#ifdef SCT_ENDP_MULTI_IPADDR
#ifdef ANSI
PUBLIC S16 ItLiSctEndpOpenReq
(
Pst *pst,                    /* post structure */
SpId spId,                   /* Service provider SAP Id */
UConnId suEndpId,            /* Service user Endpoint Id */
SctPort port,                /* SCTP Port number */
SctNetAddrLst *srcAddrLst    /* Interface IP address list  */
)
#else
PUBLIC S16 ItLiSctEndpOpenReq(pst, spId, suEndpId, port, srcAddrLst)
Pst *pst;                    /* post structure */
SpId spId;                   /* Service provider SAP Id */
UConnId suEndpId;            /* Service user Endpoint Id */
SctPort port;                /* SCTP Port number */
SctNetAddrLst *srcAddrLst;   /* Interface IP address list  */
#endif
#else
#ifdef ANSI
PUBLIC S16 ItLiSctEndpOpenReq
(
Pst *pst,                    /* post structure */
SpId spId,                   /* Service provider SAP Id */
UConnId suEndpId,            /* Service user Endpoint Id */
SctPort port,                /* SCTP Port number */
CmNetAddr *intfNAddr         /* Interface IP address   */
)
#else
PUBLIC S16 ItLiSctEndpOpenReq(pst, spId, suEndpId, port, intfNAddr)
Pst *pst;                    /* post structure */
SpId spId;                   /* Service provider SAP Id */
UConnId suEndpId;            /* Service user Endpoint Id */
SctPort port;                /* SCTP Port number */
CmNetAddr *intfNAddr;        /* Interface IP address   */
#endif
#endif 
{
   TRC3(ItLiSctEndpOpenReq)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_MAX_SCT_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   /* jump to specific primitive depending on configured selector */

#ifdef SCT_ENDP_MULTI_IPADDR
   RETVALUE((*ItLiSctEndpOpenReqMt[pst->selector])(pst, spId, suEndpId, port, 
                                                   srcAddrLst));
#else
   RETVALUE((*ItLiSctEndpOpenReqMt[pst->selector])(pst, spId, suEndpId, port, 
                                                   intfNAddr));
#endif
} /* end of ItLiSctEndpOpenReq */


/*
*
*       Fun:   Endpoint closing request
*
*       Desc:  This function is used to send a request for the closing of 
*              the SCTP endpoint
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  it_ptli.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSctEndpCloseReq
(
Pst *pst,                 /* post structure */
SpId spId,                /* service provider SAPID */
UConnId endpId,           /* endpoint ID */
U8 endpIdType             /* endpoint ID type */
)
#else
PUBLIC S16 ItLiSctEndpCloseReq(pst, spId, endpId, endpIdType)
Pst *pst;                 /* post structure */
SpId spId;                /* service provider SAPID */
UConnId endpId;           /* endpoint ID */
U8 endpIdType;            /* endpoint ID type */
#endif
{
   TRC3(ItLiSctEndpCloseReq)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_MAX_SCT_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   /* jump to specific primitive depending on configured selector */
   RETVALUE((*ItLiSctEndpCloseReqMt[pst->selector])(pst, spId, endpId, 
                                                    endpIdType));
} /* end of ItLiSctEndpCloseReq */


/*
*
*       Fun:   Association establishment request
*
*       Desc:  This function is used to send a request for the closing of 
*              the SCTP endpoint
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  it_ptli.c
*
*/

/* it009.106 - Added type of service parameter */
#ifdef SCT3
#ifdef ANSI
PUBLIC S16 ItLiSctAssocReq
(
Pst *pst,                  /* post structure */
SpId spId,                 /* service provider SAP ID */
UConnId spEndpId,          /* service provider endpoint ID */
UConnId suAssocId,         /* service userassociation ID */
CmNetAddr *priDstNAddr,    /* primary destination network address */
SctPort dstPort,           /* destination port number */
SctStrmId outStrms,        /* no. of outgoing streams */
SctNetAddrLst *dstNAddrLst, /* dest. network address list */
SctNetAddrLst *srcNAddrLst, /* src. network address list */
SctTos tos,                 /* type of service */
Buffer *vsInfo              /* vendor specific info */
)
#else
PUBLIC S16 ItLiSctAssocReq(pst, spId, spEndpId, suAssocId, priDstNAddr, dstPort,
outStrms, dstNAddrLst, srcNAddrLst, tos, vsInfo)
Pst *pst;                  /* post structure */
SpId spId;                 /* service provider SAP ID */
UConnId spEndpId;          /* service provider endpoint ID */
UConnId suAssocId;         /* service userassociation ID */
CmNetAddr *priDstNAddr;    /* primary destination network address */
SctPort dstPort;           /* destination port number */
SctStrmId outStrms;        /* no. of outgoing streams */
SctNetAddrLst *dstNAddrLst; /* dest. network address list */
SctNetAddrLst *srcNAddrLst; /* src. network address list */
SctTos tos;                 /* type of service */
Buffer *vsInfo;             /* vendor specific info */
#endif
#else /* SCT3 */
#ifdef ANSI
PUBLIC S16 ItLiSctAssocReq
(
Pst *pst,                  /* post structure */
SpId spId,                 /* service provider SAP ID */
UConnId spEndpId,          /* service provider endpoint ID */
UConnId suAssocId,         /* service userassociation ID */
CmNetAddr *priDstNAddr,    /* primary destination network address */
SctPort dstPort,           /* destination port number */
SctStrmId outStrms,        /* no. of outgoing streams */
SctNetAddrLst *dstNAddrLst, /* dest. network address list */
SctNetAddrLst *srcNAddrLst, /* src. network address list */
Buffer *vsInfo              /* vendor specific info */
)
#else
PUBLIC S16 ItLiSctAssocReq(pst, spId, spEndpId, suAssocId, priDstNAddr, dstPort,
outStrms, dstNAddrLst, srcNAddrLst, vsInfo)
Pst *pst;                  /* post structure */
SpId spId;                 /* service provider SAP ID */
UConnId spEndpId;          /* service provider endpoint ID */
UConnId suAssocId;         /* service userassociation ID */
CmNetAddr *priDstNAddr;    /* primary destination network address */
SctPort dstPort;           /* destination port number */
SctStrmId outStrms;        /* no. of outgoing streams */
SctNetAddrLst *dstNAddrLst; /* dest. network address list */
SctNetAddrLst *srcNAddrLst; /* src. network address list */
Buffer *vsInfo;             /* vendor specific info */
#endif
#endif /* SCT3 */
{
   TRC3(ItLiSctAssocReq)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_MAX_SCT_SEL)
   {
      if (vsInfo != (Buffer *)NULLP)
      {
         SPutMsg(vsInfo);
      }
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   /* jump to specific primitive depending on configured selector */
#ifdef SCT3
   RETVALUE((*ItLiSctAssocReqMt[pst->selector])(pst, spId, spEndpId, suAssocId,
                                                priDstNAddr, dstPort, outStrms, 
                                                dstNAddrLst, srcNAddrLst, 
                                                tos, vsInfo));
#else /* SCT3 */
   RETVALUE((*ItLiSctAssocReqMt[pst->selector])(pst, spId, spEndpId, suAssocId,
                                                priDstNAddr, dstPort, outStrms, 
                                                dstNAddrLst, srcNAddrLst, 
                                                vsInfo));
#endif /* SCT3 */
} /* end of ItLiSctAssocReq */


/*
*
*       Fun:   Association Establishment response
*
*       Desc:  This function is used by the service user to respond to an 
*              association iniitialization indication by accepting the 
*              association.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  it_ptli.c
*
*/

/* it009.106 - Added type of service parameter */
#ifdef SCT3
#ifdef ANSI
PUBLIC S16 ItLiSctAssocRsp
(
Pst *pst,                  /* post structure */
SpId spId,                 /* service provider SAP ID */
UConnId spAssocId,         /* service provider association ID */
SctAssocIndParams *assocIndParams, /* association parameters */
SctTos tos,                /* type of service */
SctResult result,          /* result */
Buffer *vsInfo             /* vendor specific info */
)
#else
PUBLIC S16 ItLiSctAssocRsp(pst, spId, spAssocId, assocIndParams, tos, result, vsInfo)
Pst *pst;                  /* post structure */
SpId spId;                 /* service provider SAP ID */
UConnId spAssocId;         /* service provider association ID */
SctAssocIndParams *assocIndParams; /* association parameters */
SctTos tos;                /* type of service */
SctResult result;          /* result */
Buffer *vsInfo;            /* vendor specific info */
#endif
#else /* SCT3 */
#ifdef ANSI
PUBLIC S16 ItLiSctAssocRsp
(
Pst *pst,                  /* post structure */
SpId spId,                 /* service provider SAP ID */
UConnId spAssocId,         /* service provider association ID */
SctAssocIndParams *assocIndParams, /* association parameters */
SctResult result,          /* result */
Buffer *vsInfo             /* vendor specific info */
)
#else
PUBLIC S16 ItLiSctAssocRsp(pst, spId, spAssocId, assocIndParams, result, vsInfo)
Pst *pst;                  /* post structure */
SpId spId;                 /* service provider SAP ID */
UConnId spAssocId;         /* service provider association ID */
SctAssocIndParams *assocIndParams; /* association parameters */
SctResult result;          /* result */
Buffer *vsInfo;            /* vendor specific info */
#endif
#endif /* SCT3 */
{
   TRC3(ItLiSctAssocRsp)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_MAX_SCT_SEL)
   {
      if (vsInfo != (Buffer *)NULLP)
      {
         SPutMsg(vsInfo);
      }
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   /* jump to specific primitive depending on configured selector */
#ifdef SCT3
   RETVALUE((*ItLiSctAssocRspMt[pst->selector])(pst, spId, spAssocId, 
                                                assocIndParams, tos,
                                                result, vsInfo));
#else /* SCT3 */
   RETVALUE((*ItLiSctAssocRspMt[pst->selector])(pst, spId, spAssocId, 
                                                assocIndParams, result, 
                                                vsInfo));
#endif /* SCT3 */
} /* end of ItLiSctAssocRsp */


/*
*
*       Fun:   Association Termination Request
*
*       Desc:  This function is used to request the termination of an 
*              association which is either established or being established.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  it_ptli.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSctTermReq
(
Pst *pst,                 /* post structure */
SpId spId,                /* service provider SAP ID */
UConnId assocId,          /* association ID */
U8 assocIdType,           /* association ID type */
Bool abrtFlg              /* abort flag */
)
#else
PUBLIC S16 ItLiSctTermReq(pst, spId, assocId, assocIdType, abrtFlg)
Pst *pst;                 /* post structure */
SpId spId;                /* service provider SAP ID */
UConnId assocId;          /* association ID */
U8 assocIdType;           /* association ID type */
Bool abrtFlg;             /* abort flag */
#endif
{
   TRC3(ItLiSctTermReq)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_MAX_SCT_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   /* jump to specific primitive depending on configured selector */
   RETVALUE((*ItLiSctTermReqMt[pst->selector])(pst, spId, assocId, assocIdType, 
                                               abrtFlg));
} /* end of ItLiSctTermReq */


/*
*
*       Fun:   Data request
*
*       Desc:  This function is used to request the service provider to send a
*              user datagram to the destination.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  it_ptli.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSctDatReq
(
Pst *pst,                 /* post structure */
SpId spId,                /* service provider SAP ID */
UConnId spAssocId,        /* service provider association ID */
CmNetAddr *dstNAddr,      /* dest. network address */
SctStrmId strmId,         /* stream ID */
Bool unorderFlg,          /* unordered delivery flag */
Bool nobundleFlg,         /* nobundleFlg */
U16 lifetime,             /* datagram lifetime */
U32 protId,               /* protocol ID */
Buffer *mBuf              /* message buffer */
)
#else
PUBLIC S16 ItLiSctDatReq(pst, spId, spAssocId, dstNAddr, strmId, unorderFlg, 
                         nobundleFlg, lifetime, protId, mBuf)
Pst *pst;                 /* post structure */
SpId spId;                /* service provider SAP ID */
UConnId spAssocId;        /* service provider association ID */
CmNetAddr *dstNAddr;      /* dest. network address */
SctStrmId strmId;         /* stream ID */
Bool unorderFlg;          /* unordered delivery flag */
Bool nobundleFlg;         /* nobundleFlg */
U16 lifetime;             /* datagram lifetime */
U32 protId;               /* protocol ID */
Buffer *mBuf;             /* message buffer */
#endif
{
   TRC3(ItLiSctDatReq)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_MAX_SCT_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

#ifdef PERF_TEST  /* M3UA PERFORMANCE TESTING */
   /*Tightly coupled case */
   if ((timeStmpFlg == TRUE)  && (pst->selector !=0))
   {
       gettimeofday(&time2, NULL);
       timeA.tv_usec += (time2.tv_usec - time1.tv_usec);
       if (time2.tv_usec < time1.tv_usec)
       {
               timeA.tv_usec += 1000000;
               time2.tv_sec--;
       }
       timeA.tv_sec += (time2.tv_sec - time1.tv_sec);
       if (timeA.tv_usec >= 1000000)
       {
               timeA.tv_usec -= 1000000;
               timeA.tv_sec++;
       }
   }

#endif  /* M3UA PERFORMANCE TESTING */

   /* jump to specific primitive depending on configured selector */
   RETVALUE((*ItLiSctDatReqMt[pst->selector])(pst, spId, spAssocId, dstNAddr, 
                                              strmId, unorderFlg, nobundleFlg, 
                                              lifetime, protId, mBuf));
} /* end of ItLiSctDatReq */


 /*
*
*       Fun:   Status request
*
*       Desc:  This function is used to retrieve 
*              unsent/unacknowledged/undelivered datagrams from the service 
*              provider and to get statistical information from the service 
*              provider.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  it_ptli.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSctStaReq
(
Pst *pst,                 /* post structure */
SpId spId,                /* service provider SAP ID */
UConnId spAssocId,        /* service provider association ID */
CmNetAddr *dstNAddr,      /* dest. network address */
U8 staType                /* status type */
)
#else
PUBLIC S16 ItLiSctStaReq(pst, spId, spAssocId, dstNAddr, staType)
Pst *pst;                 /* post structure */
SpId spId;                /* service provider SAP ID */
UConnId spAssocId;        /* service provider association ID */
CmNetAddr *dstNAddr;      /* dest. network address */
U8 staType;               /* status type */
#endif
{
   TRC3(ItLiSctStaReq)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_MAX_SCT_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   /* jump to specific primitive depending on configured selector */
   RETVALUE((*ItLiSctStaReqMt[pst->selector])(pst, spId, spAssocId, dstNAddr, 
                                              staType));
} /* end of ItLiSctStaReq */


#ifdef SNTIWF
/*
The selectors are:

   0 - loosely coupled (#define LCITLISNT)
   1 - MTP3 (#define SN)

*/
/* local defines */
#define IT_MAX_MTP3_SEL               2

 /* Bind request Primitive */
PRIVATE SntBndReq ItLiSntBndReqMt[IT_MAX_MTP3_SEL] =
{
#ifdef LCITLISNT
   cmPkSntBndReq,          /* 0 - loosely coupled  */
#else
   PtLiSntBndReq,          /* 0 - tightly coupled, portable */
#endif
#if (defined(SN) || defined(L3))/*2006 3 30 chenning*/
   SnUiSntBndReq,          /* 1 - tightly coupled, MTP3 */
#else
   PtLiSntBndReq,          /* 1 - tightly coupled, portable */
#endif
};

/* Status Query Request primitive */

PUBLIC SntStaQryReq ItLiSntStaQryReqMt[IT_MAX_MTP3_SEL] =
{
#ifdef LCITLISNT
   cmPkSntStaQryReq,          /* 0 - loosely coupled */
#else
   PtLiSntStaQryReq,          /* 0 - tightly coupled, portable */
#endif
#if( defined(SN) ||defined(L3) )/*2006 3 30 chenning*/
   SnUiSntStaQryReq,          /* 1 - tightly coupled, MTP3 */
#else
   PtLiSntStaQryReq,          /* 1 - tightly coupled, portable */
#endif
};
/* Status Apply Req primitive */

PUBLIC SntStaApyReq ItLiSntStaApyReqMt[IT_MAX_MTP3_SEL] =
{
#ifdef LCITLISNT
   cmPkSntStaApyReq,          /* 0 - loosely coupled */
#else
   PtLiSntStaApyReq,          /* 0 - tightly coupled, portable */
#endif
#if( defined(SN) ||defined(L3) )/*2006 3 30 chenning*/
   SnUiSntStaApyReq,          /* 1 - tightly coupled, MTP3 */
#else
   PtLiSntStaApyReq,          /* 1 - tightly coupled, portable */
#endif
};

/* Status Query Response primitive */

PUBLIC SntStaQryRsp ItLiSntStaQryRspMt[IT_MAX_MTP3_SEL] =
{
#ifdef LCITLISNT
   cmPkSntStaQryRsp,          /* 0 - loosely coupled */
#else
   PtLiSntStaQryRsp,          /* 0 - tightly coupled, portable */
#endif
#if( defined(SN) ||defined(L3) )/*2006 3 30 chenning*/
   SnUiSntStaQryRsp,          /* 1 - tightly coupled, MTP3 */
#else
   PtLiSntStaQryRsp,          /* 1 - tightly coupled, portable */
#endif
};

/* MTP3 UDATA request */

PUBLIC SntUDatReq ItLiSntUDatReqMt[IT_MAX_MTP3_SEL] =
{
#ifdef LCITLISNT
   cmPkSntUDatReq,          /* 0 - loosely coupled */
#else
   PtLiSntUDatReq,          /* 0 - tightly coupled, portable */
#endif
#if( defined(SN) ||defined(L3) )/*2006 3 30 chenning*/
   SnUiSntUDatReq,          /* 1 - tightly coupled, MTP3 */
#else
   PtLiSntUDatReq,          /* 1 - tightly coupled, portable */
#endif
};
/* MTP3 BND function */

/*
*
*       Fun:   Bind request
*
*       Desc:  This function is used to bind two upper SAPs.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  It_ptli.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSntBndReq
(
Pst *pst,                 /* post structure */
SuId suId,                /* Su SAP Id */
SpId spId,                /* Sp SAP Id */
SrvInfo srvInfo           /* Service Info */
)
#else
PUBLIC S16 ItLiSntBndReq(pst, suId, spId, srvInfo)
Pst *pst;                 /* post structure */
SuId suId;                /* Su SAP Id */
SpId spId;                /* Sp SAP Id */
SrvInfo srvInfo;          /* Service Info */
#endif
{
   TRC3(ItLiSntBndReq)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_MAX_MTP3_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   switch (pst->dstEnt)
   {
#ifdef DN
      case ENTSN:
         if (pst->route == RTE_PROTO)
            ((*ItLiSntBndReqMt[pst->selector])(pst, suId, spId, srvInfo));
         else
            DnUiSntBndReq(pst, suId, spId, srvInfo);
      break;
#endif

      default:
      /* jump to specific primitive depending on configured selector */
      ((*ItLiSntBndReqMt[pst->selector])(pst, suId, spId, srvInfo));
      break;
   }
   RETVALUE(ROK);
} /* end of ItLiSntBndReq */


/*
*
*       Fun:   Status Query Request
*
*       Desc:  This function is used to query Signalling Point status.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptli.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSntStaQryReq
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
Dpc aPc,                      /* affected Point Code */
Dpc opc                      /* originator Point Code */
)
#else
PUBLIC S16 ItLiSntStaQryReq(pst, suId, aPc, opc)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
Dpc aPc;                      /* affected Point Code */
Dpc opc;                      /* originator Point Code */
#endif
{
   TRC3(ItLiSntStaQryReq)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_MAX_MTP3_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   switch (pst->dstEnt)
   {
#ifdef DN
      case ENTSN:
         if (pst->route == RTE_PROTO)
            ((*ItLiSntStaQryReqMt[pst->selector])(pst, suId,  aPc, opc));
         else
            DnUiSntStaQryReq(pst, suId, aPc, opc);
         break;
#endif
      default:
        /* jump to specific primitive depending on configured selector */
        ((*ItLiSntStaQryReqMt[pst->selector])(pst, suId,  aPc, opc));
        break;
   }
   RETVALUE(ROK);
} /* end of ItLiSntStaQryReq */


/*
*
*       Fun:   Status Apply Request
*
*       Desc:  This function is used to set Signalling Point status.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSntStaApyReq
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
Dpc aPc,                      /* affected Point Code */
Dpc opc,                      /* originator Point Code */
SrvInfo srvInfo,              /* service information octet */
Status status,                /* status */
Priority congLevel            /* congestion level */
)
#else
PUBLIC S16 ItLiSntStaApyReq(pst, suId, aPc, opc, srvInfo, status, congLevel)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
Dpc aPc;                      /* affected Point Code */
Dpc opc;                      /* originator Point Code */
SrvInfo srvInfo;              /* service information octet */
Status status;                /* status */
Priority congLevel;           /* congestion level */
#endif
{
   TRC3(ItLiSntStaApyReq)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_MAX_MTP3_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   switch (pst->dstEnt)
   {
#ifdef DN
      case ENTSN:
         if (pst->route == RTE_PROTO)
            ((*ItLiSntStaApyReqMt[pst->selector])(pst, suId,  aPc, opc, 
                                                 srvInfo, status, congLevel));
         else
            DnUiSntStaApyReq(pst, suId, aPc, opc, srvInfo, status, congLevel);
         break;
#endif
      default:
        /* jump to specific primitive depending on configured selector */
        ((*ItLiSntStaApyReqMt[pst->selector])(pst, suId,  aPc, opc, srvInfo, 
                                                 status, congLevel));
         break;
   }
   RETVALUE(ROK);
} /* end of ItLiSntStaApyInd */

/*
*
*       Fun:   Status Query Rsp
*
*       Desc:  This function is used to confirm Signalling Point status.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSntStaQryRsp
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
Dpc aPc,                      /* affected Point Code */
Dpc opc,                      /* originator Point Code */
Status status,                /* status */
Priority congLevel            /* congestion level */
)
#else
PUBLIC S16 ItLiSntStaQryRsp(pst, suId, aPc, opc, status, congLevel)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
Dpc aPc;                      /* affected Point Code */
Dpc opc;                      /* originator Point Code */
Status status;                /* status */
Priority congLevel;           /* congestion level */
#endif
{
   TRC3(ItLiSntStaQryRsp)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_MAX_MTP3_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   switch (pst->dstEnt)
   {
#ifdef DN
      case ENTSN:
         if (pst->route == RTE_PROTO)
            ((*ItLiSntStaQryRspMt[pst->selector])(pst, suId,  aPc, opc, status,
                                                 congLevel));
         else
            DnUiSntStaQryRsp(pst, suId, aPc, opc, status, congLevel);
      break;
#endif
      default:
         /* jump to specific primitive depending on configured selector */
         ((*ItLiSntStaQryRspMt[pst->selector])(pst, suId,  aPc, opc, status,
                                                 congLevel));
      break;
   }
   RETVALUE(ROK);
} /* end of ItLiSntStaQryRsp */

/*
*
*       Fun:   MTP3 UDAT req
*
*       Desc:  This function is used for unit data request towards MTP3
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 ItLiSntUDatReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service provider id */
Dpc opc,                        /* originating pont code */
Dpc dpc,                        /* destination point code */
SrvInfo sInfo,                  /* service information */
LnkSel sls,                     /* signalling link selector */
Priority prior,                 /* priority */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 ItLiSntUDatReq(pst, spId, opc, dpc, sInfo, sls, prior, mBuf)
Pst *pst;                       /* post structure */
SpId spId;                      /* service provider id */
Dpc opc;                        /* originating pont code */
Dpc dpc;                        /* destination point code */
SrvInfo sInfo;                  /* service information */
LnkSel sls;                     /* signalling link selector */
Priority prior;                 /* priority */
Buffer *mBuf;                   /* message buffer */
#endif
{
   TRC3(ItLiSntUDatReq)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_MAX_MTP3_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
#ifdef PERF_TEST  /* M3UA PERFORMANCE TESTING */
   /*Tightly coupled case */
   if ((timeStmpFlg == TRUE)  && (pst->selector !=0))
   {
      gettimeofday(&time2, NULL);
       timeA.tv_usec += (time2.tv_usec - time1.tv_usec);
       if (time2.tv_usec < time1.tv_usec)
       {
               timeA.tv_usec += 1000000;
               time2.tv_sec--;
       }
       timeA.tv_sec += (time2.tv_sec - time1.tv_sec);
       if (timeA.tv_usec >= 1000000)
       {
               timeA.tv_usec -= 1000000;
               timeA.tv_sec++;
       }
   }

#endif  /* M3UA PERFORMANCE TESTING */
   switch (pst->dstEnt)
   {
#ifdef DN
      case ENTSN:
         if (pst->route == RTE_PROTO)
            ((*ItLiSntUDatReqMt[pst->selector])(pst, spId,  opc, dpc, sInfo,
                               sls, prior, mBuf)); 
         else
            DnUiSntUDatReq(pst, spId, opc, dpc, sInfo, sls, prior, mBuf);
         break;
#endif /* DN */
      default:
       /* jump to specific primitive depending on configured selector */
       ((*ItLiSntUDatReqMt[pst->selector])(pst, spId,  opc, dpc, sInfo,
                               sls, prior, mBuf)); 
         break;
   }

   RETVALUE(ROK);
} /* end of ItLiSntUDatReq */

#endif /* SNTIWF */
/* #endif SNT_BACK_COMP_MERGED_NIF */


#ifdef PTITLISCT
/* Portable lower interface functions */


/*
*
*       Fun:   Portable bind Request
*
*       Desc:  This function is used to request a bind
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  it_ptli.c
*
*/

#ifdef ANSI
PRIVATE S16 PtLiSctBndReq
(
Pst *pst,                 /* post structure */
SuId suId,                /* Service user SAP Id */
SpId spId                /* Service provider SAP Id */
)
#else
PRIVATE S16 PtLiSctBndReq(pst, suId, spId)
Pst *pst;                 /* post structure */
SuId suId;                /* Service user SAP Id */
SpId spId;                /* Service provider SAP Id */
#endif
{
   TRC3(PtLiSctBndReq);
   ITLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(spId);
   RETVALUE(ROK);
} /* end of PtLiSctBndReq */


/*
*
*       Fun:   Portable open endpoint request
*
*       Desc:  This function is used to request a new endpoint
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  it_ptli.c
*
*/

#ifdef SCT_ENDP_MULTI_IPADDR
#ifdef ANSI
PRIVATE S16 PtLiSctEndpOpenReq
(
Pst *pst,                    /* post structure */
SpId spId,                   /* Service provider SAP Id */
UConnId suEndpId,          /* Service user Endpoint Id */
U16 port,                    /* SCTP Port number */
SctNetAddrLst *srcAddrLst     /* Interface IP address list  */
)
#else
PRIVATE S16 PtLiSctEndpOpenReq(pst, spId, suEndpId, port, srcAddrLst)
Pst *pst;                    /* post structure */
SpId spId;                   /* Service provider SAP Id */
UConnId suEndpId;          /* Service user Endpoint Id */
U16 port;                    /* SCTP Port number */
SctNetAddrLst *srcAddrLst;    /* Interface IP address list  */
#endif
#else
#ifdef ANSI
PRIVATE S16 PtLiSctEndpOpenReq
(
Pst *pst,                    /* post structure */
SpId spId,                   /* Service provider SAP Id */
UConnId suEndpId,          /* Service user Endpoint Id */
U16 port,                    /* SCTP Port number */
CmNetAddr *intfNAddr         /* Interface IP address   */
)
#else
PRIVATE S16 PtLiSctEndpOpenReq(pst, spId, suEndpId, port, intfNAddr)
Pst *pst;                    /* post structure */
SpId spId;                   /* Service provider SAP Id */
UConnId suEndpId;          /* Service user Endpoint Id */
U16 port;                    /* SCTP Port number */
CmNetAddr *intfNAddr;        /* Interface IP address   */
#endif
#endif
{
   TRC3(PtLiSctEndpOpenReq);
   ITLOGINVSEL;
   UNUSED(pst);
   UNUSED(spId);
   UNUSED(suEndpId);
   UNUSED(port);
#ifdef SCT_ENDP_MULTI_IPADDR
   UNUSED(srcAddrLst);
#else
   UNUSED(intfNAddr);
#endif
   RETVALUE(ROK);
} /* end of PtLiSctEndpOpenReq */


/*
*
*       Fun:   Portable close endpoint request
*  
*       Desc:  This function is used to close an endpoint
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  it_ptli.c
*
*/

#ifdef ANSI
PRIVATE S16 PtLiSctEndpCloseReq
(
Pst *pst,                 /* post structure */
SpId spId,                /* service provider SAPID */
UConnId endpId,           /* endpoint ID */
U8 endpIdType             /* endpoint ID type */
)
#else
PRIVATE S16 PtLiSctEndpCloseReq(pst, spId, endpId, endpIdType)
Pst *pst;                 /* post structure */
SpId spId;                /* service provider SAPID */
UConnId endpId;           /* endpoint ID */
U8 endpIdType;            /* endpoint ID type */
#endif
{
   TRC3(PtLiSctEndpCloseReq);
   ITLOGINVSEL;
   UNUSED(pst);
   UNUSED(spId);
   UNUSED(endpId);
   UNUSED(endpIdType);
   RETVALUE(ROK);
} /* end of PtLiSctEndpCloseReq */


/*
*
*       Fun:   Portable Association request
*
*       Desc:  This function is used to request a new association
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  it_ptli.c
*
*/

/* it009.106 - Added type of service parameter */
#ifdef SCT3
#ifdef ANSI
PRIVATE S16 PtLiSctAssocReq
(
Pst *pst,                  /* post structure */
SpId spId,                 /* service provider SAP ID */
UConnId spEndpId,        /* service provider endpoint ID */
UConnId suAssocId,      /* service userassociation ID */
CmNetAddr *priDstNAddr,    /* primary destination network address */
U16 dstPort,               /* destination port number */
SctStrmId outStrms,        /* no. of outgoing streams */
SctNetAddrLst *dstNAddrLst, /* dest. network address list */
SctNetAddrLst *srcNAddrLst, /* src. network address list */
SctTos tos,                 /* type of service */
Buffer *vsInfo          /* vendor specific info */
)
#else
PRIVATE S16 PtLiSctAssocReq(pst, spId, spEndpId, suAssocId, priDstNAddr, 
                            dstPort, outStrms, dstNAddrLst, srcNAddrLst, tos, vsInfo)
Pst *pst;                  /* post structure */
SpId spId;                 /* service provider SAP ID */
UConnId spEndpId;        /* service provider endpoint ID */
UConnId suAssocId;      /* service userassociation ID */
CmNetAddr *priDstNAddr;    /* primary destination network address */
U16 dstPort;               /* destination port number */
SctStrmId outStrms;        /* no. of outgoing streams */
SctNetAddrLst *dstNAddrLst; /* dest. network address list */
SctNetAddrLst *srcNAddrLst; /* src. network address list */
SctTos tos;                 /* type of service */
Buffer *vsInfo;          /* vendor specific info */
#endif
#else /* SCT3 */
#ifdef ANSI
PRIVATE S16 PtLiSctAssocReq
(
Pst *pst,                  /* post structure */
SpId spId,                 /* service provider SAP ID */
UConnId spEndpId,        /* service provider endpoint ID */
UConnId suAssocId,      /* service userassociation ID */
CmNetAddr *priDstNAddr,    /* primary destination network address */
U16 dstPort,               /* destination port number */
SctStrmId outStrms,        /* no. of outgoing streams */
SctNetAddrLst *dstNAddrLst, /* dest. network address list */
SctNetAddrLst *srcNAddrLst, /* src. network address list */
Buffer *vsInfo          /* vendor specific info */
)
#else
PRIVATE S16 PtLiSctAssocReq(pst, spId, spEndpId, suAssocId, priDstNAddr, 
                            dstPort, outStrms, dstNAddrLst, srcNAddrLst, vsInfo)
Pst *pst;                  /* post structure */
SpId spId;                 /* service provider SAP ID */
UConnId spEndpId;        /* service provider endpoint ID */
UConnId suAssocId;      /* service userassociation ID */
CmNetAddr *priDstNAddr;    /* primary destination network address */
U16 dstPort;               /* destination port number */
SctStrmId outStrms;        /* no. of outgoing streams */
SctNetAddrLst *dstNAddrLst; /* dest. network address list */
SctNetAddrLst *srcNAddrLst; /* src. network address list */
Buffer *vsInfo;          /* vendor specific info */
#endif
#endif /* SCT3 */
{
   TRC3(PtLiSctAssocReq);
   ITLOGINVSEL;
   UNUSED(pst);
   UNUSED(spId);
   UNUSED(spEndpId);
   UNUSED(suAssocId);
   UNUSED(priDstNAddr);
   UNUSED(dstPort);
   UNUSED(outStrms);
   UNUSED(dstNAddrLst);
   UNUSED(srcNAddrLst);
#ifdef SCT3
   UNUSED(tos);
#endif /* SCT3 */
   if (vsInfo != (Buffer *)NULLP)
   {
      SPutMsg(vsInfo);
   }

   RETVALUE(ROK);
} /* end of PtLiSctAssocReq */


/*
*
*       Fun:   Portable association response
*
*       Desc:  This function is used to respond to an association indication
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  it_ptli.c
*
*/

/* it009.106 - Added type of service parameter */
#ifdef SCT3
#ifdef ANSI
PRIVATE S16 PtLiSctAssocRsp
(
Pst *pst,                  /* post structure */
SpId spId,                 /* service provider SAP ID */
UConnId spAssocId,         /* service provider association ID */
SctAssocIndParams *assocIndParams, /* association parameters */
SctTos tos,                /* type of service */
SctResult result,          /* result */
Buffer *vsInfo             /* vendor specific info */
)
#else
PRIVATE S16 PtLiSctAssocRsp(pst, spId, spAssocId, assocIndParams, tos, result, 
                            vsInfo)
Pst *pst;                  /* post structure */
SpId spId;                 /* service provider SAP ID */
UConnId spAssocId;         /* service provider association ID */
SctAssocIndParams *assocIndParams; /* association parameters */
SctTos tos;                /* type of service */
SctResult result;          /* result */
Buffer *vsInfo;            /* vendor specific info */
#endif
#else /* SCT3 */
#ifdef ANSI
PRIVATE S16 PtLiSctAssocRsp
(
Pst *pst,                  /* post structure */
SpId spId,                 /* service provider SAP ID */
UConnId spAssocId,         /* service provider association ID */
SctAssocIndParams *assocIndParams, /* association parameters */
SctResult result,          /* result */
Buffer *vsInfo             /* vendor specific info */
)
#else
PRIVATE S16 PtLiSctAssocRsp(pst, spId, spAssocId, assocIndParams, result, 
                            vsInfo)
Pst *pst;                  /* post structure */
SpId spId;                 /* service provider SAP ID */
UConnId spAssocId;         /* service provider association ID */
SctAssocIndParams *assocIndParams; /* association parameters */
SctResult result;          /* result */
Buffer *vsInfo;            /* vendor specific info */
#endif
#endif /* SCT3 */
{
   TRC3(PtLiSctAssocRsp);
   ITLOGINVSEL;
   UNUSED(pst);
   UNUSED(spId);
   UNUSED(spAssocId);
   UNUSED(assocIndParams);
   UNUSED(result);
#ifdef SCT3
   UNUSED(tos);
#endif /* SCT3 */
   if (vsInfo != (Buffer *)NULLP)
   {
      SPutMsg(vsInfo);
   }

   RETVALUE(ROK);
} /* end of PtLiSctAssocRsp */


/*
*
*       Fun:   Portable termination request
*
*       Desc:  This function is used to terminate an association
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  it_ptli.c
*
*/

#ifdef ANSI
PRIVATE S16 PtLiSctTermReq
(
Pst *pst,                 /* post structure */
SpId spId,                /* service provider SAP ID */
UConnId assocId,          /* association ID */
U8 assocIdType,           /* association ID type */
Bool abrtFlg              /* abort flag */
)
#else
PRIVATE S16 PtLiSctTermReq(pst, spId, assocId, assocIdType, abrtFlg)
Pst *pst;                 /* post structure */
SpId spId;                /* service provider SAP ID */
UConnId assocId;          /* association ID */
U8 assocIdType;           /* association ID type */
Bool abrtFlg;             /* abort flag */
#endif
{
   TRC3(PtLiSctTermReq);
   ITLOGINVSEL;
   UNUSED(pst);
   UNUSED(spId);
   UNUSED(assocId);
   UNUSED(assocIdType);
   UNUSED(abrtFlg);
   RETVALUE(ROK);
} /* end of PtLiSctTermReq */


/*
*
*       Fun:   Portable data Request
*
*       Desc:  This function is used to send data to a peer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  it_ptli.c
*
*/

#ifdef ANSI
PRIVATE S16 PtLiSctDatReq
(
Pst *pst,                 /* post structure */
SpId spId,                /* service provider SAP ID */
UConnId spAssocId,        /* service provider association ID */
CmNetAddr *dstNAddr,      /* dest. network address */
SctStrmId strmId,         /* stream ID */
Bool unorderFlg,          /* unordered delivery flag */
Bool nobundleFlg,         /* nobundleFlg */
U16 lifetime,             /* datagram lifetime */
U32 protId,               /* protocol ID */
Buffer *mBuf              /* message buffer */
)
#else
PRIVATE S16 PtLiSctDatReq(pst, spId, spAssocId, dstNAddr, strmId, unorderFlg,
   nobundleFlg, lifetime, protId, mBuf)
Pst *pst;                 /* post structure */
SpId spId;                /* service provider SAP ID */
UConnId spAssocId;        /* service provider association ID */
CmNetAddr *dstNAddr;      /* dest. network address */
SctStrmId strmId;         /* stream ID */
Bool unorderFlg;          /* unordered delivery flag */
Bool nobundleFlg;         /* nobundleFlg */
U16 lifetime;             /* datagram lifetime */
U32 protId;               /* protocol ID */
Buffer *mBuf;             /* message buffer */
#endif
{
   TRC3(PtLiSctDatReq);
   ITLOGINVSEL;
   UNUSED(pst);
   UNUSED(spId);
   UNUSED(spAssocId);
   UNUSED(dstNAddr);
   UNUSED(strmId);
   UNUSED(unorderFlg);
   UNUSED(nobundleFlg);
   UNUSED(lifetime);
   UNUSED(protId);
   if (mBuf != (Buffer *)NULLP)
   {
      SPutMsg(mBuf);
   }

   RETVALUE(ROK);
} /* end of PtLiSctDatReq */


/*
*
*       Fun:   Portable status request
*
*       Desc:  This function is used to request status
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  it_ptli.c
*
*/

#ifdef ANSI
PRIVATE S16 PtLiSctStaReq
(
Pst *pst,                 /* post structure */
SpId spId,                /* service provider SAP ID */
UConnId spAssocId,        /* service provider association ID */
CmNetAddr *dstNAddr,      /* dest. network address */
U8 staType                /* status type */
)
#else
PRIVATE S16 PtLiSctStaReq(pst, spId, spAssocId, dstNAddr, staType)
Pst *pst;                 /* post structure */
SpId spId;                /* service provider SAP ID */
UConnId spAssocId;        /* service provider association ID */
CmNetAddr *dstNAddr;      /* dest. network address */
U8 staType;               /* status type */
#endif
{
   TRC3(PtLiSctStaReq);
   ITLOGINVSEL;
   UNUSED(pst);
   UNUSED(spId);
   UNUSED(spAssocId);
   UNUSED(dstNAddr);
   UNUSED(staType);
   RETVALUE(ROK);
} /* end of PtLiSctStaReq */

#endif

/* #ifndef SNT_BACK_COMP_MERGED_NIF */
#ifdef SNTIWF
#ifdef PTITLISNT
/* Portable lower interface functions */


/*
*
*       Fun:   Portable bind Request
*
*       Desc:  This function is used to request a bind
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  it_ptli.c
*
*/

#ifdef ANSI
PRIVATE S16 PtLiSntBndReq
(
Pst *pst,                 /* post structure */
SuId suId,                /* Service user SAP Id */
SpId spId,               /* Service provider SAP Id */
SrvInfo srvInfo          /* Service info */
)
#else
PRIVATE S16 PtLiSntBndReq(pst, suId, spId, srvInfo)
Pst *pst;                 /* post structure */
SuId suId;                /* Service user SAP Id */
SpId spId;                /* Service provider SAP Id */
SrvInfo srvInfo;         /* Service info */
#endif
{
   TRC3(PtLiSntBndReq);
   ITLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(spId);
   UNUSED(srvInfo);
   RETVALUE(ROK);
} /* end of PtLiSntBndReq */

/*
*
*       Fun:   portable - Status Apply Request
*
*       Desc:  This function is used to set Signalling Point status.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtLiSntStaApyReq
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
Dpc aPc,                      /* affected Point Code */
Dpc opc,                      /* originator Point Code */
SrvInfo srvInfo,              /* service information octet */
Status status,                /* status */
Priority congLevel            /* congestion level */
)
#else
PRIVATE S16 PtLiSntStaApyReq(pst, suId, aPc, opc, srvInfo, status, congLevel)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
Dpc aPc;                      /* affected Point Code */
Dpc opc;                      /* originator Point Code */
SrvInfo srvInfo;              /* service information octet */
Status status;                /* status */
Priority congLevel;           /* congestion level */
#endif
{
   TRC3(PtLiSntStaApyReq)
#if (ERRCLASS & ERRCLS_DEBUG)
   ITLOGERROR(ERRCLS_DEBUG, EIT449, (ErrVal) ERRZERO, "PtLiSntStaApyReq");
#endif
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(aPc);
   UNUSED(opc);
   UNUSED(status);
   UNUSED(congLevel);
   UNUSED(srvInfo);
   RETVALUE(ROK);
} /* end of PtLiSntStaApyReq */

/*
*
*       Fun:   portable - Status Query Request
*
*       Desc:  This function is used to query Signalling Point status.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtLiSntStaQryReq
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
Dpc aPc,                      /* affected Point Code */
Dpc opc                       /* originator Point Code */
)
#else
PRIVATE S16 PtLiSntStaQryReq(pst, suId, aPc, opc)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
Dpc aPc;                      /* affected Point Code */
Dpc opc;                      /* originator Point Code */
#endif
{
   TRC3(PtLiSntStaQryReq)
#if (ERRCLASS & ERRCLS_DEBUG)
   ITLOGERROR(ERRCLS_DEBUG, EIT450, (ErrVal) ERRZERO, "PtLiSntStaQryReq");
#endif
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(aPc);
   UNUSED(opc);
   RETVALUE(ROK);
} /* end of PtLiSntStaQryReq */

/*
*
*       Fun:   portable - Status Query Response
*
*       Desc:  This function is used to confirm Signalling Point status.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtLiSntStaQryRsp
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
Dpc aPc,                      /* affected Point Code */
Dpc opc,                      /* originator Point Code */
Status status,                /* status */
Priority congLevel            /* congestion level */
)
#else
PRIVATE S16 PtLiSntStaQryRsp(pst, suId, aPc, opc, status, congLevel)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
Dpc aPc;                      /* affected Point Code */
Dpc opc;                      /* originator Point Code */
Status status;                /* status */
Priority congLevel;           /* congestion level */
#endif
{
   TRC3(PtLiSntStaQryRsp)
#if (ERRCLASS & ERRCLS_DEBUG)
   ITLOGERROR(ERRCLS_DEBUG, EIT451, (ErrVal) ERRZERO, "PtLiSntStaQryRsp");
#endif
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(aPc);
   UNUSED(opc);
   UNUSED(status);
   UNUSED(congLevel);
   RETVALUE(ROK);
} /* end of PtLiSntStaQryRsp */

/*
*
*       Fun:   Portable MTP3 UDAT req
*
*       Desc:  This function is used for unit data request towards MTP3
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  it_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 PtLiSntUDatReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service provider id */
Dpc opc,                        /* originating pont code */
Dpc dpc,                        /* destination point code */
SrvInfo sInfo,                  /* service information */
LnkSel sls,                     /* signalling link selector */
Priority prior,                 /* priority */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 PtLiSntUDatReq(pst, spId, opc, dpc, sInfo, sls, prior, mBuf)
Pst *pst;                       /* post structure */
SpId spId;                      /* service provider id */
Dpc opc;                        /* originating pont code */
Dpc dpc;                        /* destination point code */
SrvInfo sInfo;                  /* service information */
LnkSel sls;                     /* signalling link selector */
Priority prior;                 /* priority */
Buffer *mBuf;                   /* message buffer */
#endif
{
   TRC3(PtLiSntUDatReq)
#if (ERRCLASS & ERRCLS_DEBUG)
   ITLOGERROR(ERRCLS_DEBUG, EIT452, (ErrVal) ERRZERO, "PtLiSntUDatReq");
#endif
   UNUSED(pst);
   UNUSED(spId);
   UNUSED(opc);
   UNUSED(dpc);
   UNUSED(sInfo);
   UNUSED(sls);
   UNUSED(prior);
   UNUSED(mBuf);
   RETVALUE(ROK);
} /* end of PtLiSntUDatReq */

#endif /* SNTIWF */
#endif
/* #endif SNT_BACK_COMP_MERGED_NIF */



/********************************************************************30**

         End of file:     it_ptli.c@@/main/7 - Thu Apr  1 03:52:47 2004

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/3      ---      mrw  1. Initial version
/main/3      ---      as   1. Updates to Release 1.2
/main/4      ---      sg   1. Updates to Release 1.3
/main/5      ---      sg   1. Update to Release 1.4
/main/5    it019.104  vt   1. Changes done to resolve the problem
                              of double de-allocation of message buffer
/main/6      ---      nt   1. Update to Release 1.5
/main/7      ---      rs   1. Update to release 1.6.
/main/7    it009.106  sg   1. Added TOS parameter to association request 
                              and association response.
*********************************************************************91*/
