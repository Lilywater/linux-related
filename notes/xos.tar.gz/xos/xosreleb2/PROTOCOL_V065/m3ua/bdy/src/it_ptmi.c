/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/


/********************************************************************20**

     Name:     it_ptmi.c - M3UA Layer Management Interface

     Type:     C source file

     Desc:     C code for the APIs implemented by the layer manager, viz.
               LIT confirms and indications

     File:     it_ptmi.c

     Sid:      it_ptmi.c@@/main/6 - Tue Dec 30 22:37:17 2003

     Prg:      jdb

*********************************************************************21*/

/*

  it_ptmi.c - M3UA Layer Management Interface Functions

Following function pointers are provided in this file for LIT:
         ItMiLitCfgCfm    - configuration confirm
         ItMiLitStsCfm    - statistics confirm
         ItMiLitStaCfm    - status confirm
         ItMiLitCntrlCfm  - control confirm
         ItMiLitStaInd    - status indication
         ItMiLitTrcInd    - trace indication

These pointers map to the actual functions based on the selector value.
Selector for Cfm functions is given in ItMngnt.hdr.response.selector.
Selector for Ind functions is given in ItGlobalCb.tskInit.lmPst.selector.
The mapping for function ItMiLitXxxYyy is defined in the array
itMiLitXxxYyyMt. Selector acts as the array index, which can be one of:

Selector    #define          Coupling        Primitive
   0        LCITMILIT         loose          cmPkLitXxxYyy
   1           SM             tight          SmMiLitXxxYyy
   2         custom           tight          PtMiLitXxxYyy
Max selector value = 2 = IT_LIT_MAX_SEL - 1.
*/

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_ss7.h"        /* common SS7 */
#include "cm_tpt.h"        /* common transport defines */
#include "lit.h"           /* layer management M3UA  */
#include "sct.h"           /* SCT interface */
#include "snt.h"           /* SNT interface */
#include "it_err.h"        /* M3UA error */
#ifdef IT_FTHA          
#include  "sht.h"          /* SHT Interface header file */
#endif /* IT_FTHA */
#include "it.h"            /* M3UA internal defines */


/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_ss7.x"        /* common SS7 */
#include "cm_tpt.x"        /* common transport */
#include "sct.x"           /* SCT interface */
#ifdef IT_FTHA            
#include "sht.x"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "lit.x"           /* layer management M3UA */
#include "snt.x"           /* SNT interface */
#include "it.x"            /* M3UA internal typedefs */



/* local defines */
#ifndef LCITMILIT
#define PTITMILIT
#else
#ifndef SM
#define PTITMILIT
#endif
#endif

#define IT_LIT_MAX_SEL       2      /* maximum number of selectors */

/* forward references */
#ifdef PTITMILIT
PRIVATE S16 PtMiLitCfgCfm    ARGS((Pst *pst, ItMgmt *cfg));
PRIVATE S16 PtMiLitStsCfm    ARGS((Pst *pst, ItMgmt *sts));
PRIVATE S16 PtMiLitStaCfm    ARGS((Pst *pst, ItMgmt *ssta));
PRIVATE S16 PtMiLitCntrlCfm  ARGS((Pst *pst, ItMgmt *cntrl));
PRIVATE S16 PtMiLitStaInd    ARGS((Pst *pst, ItMgmt *usta));
PRIVATE S16 PtMiLitTrcInd    ARGS((Pst *pst, ItMgmt *trc));
#endif
#ifdef IT_FTHA   
#ifndef SH
PRIVATE S16 PtItMiShtCntrlCfm    ARGS((Pst *pst, ShtCntrlCfmEvnt *cfmInfo));
#endif
#endif /* IT_FTHA */


/* private variable definitions */
#if (ERRCLASS & ERRCLS_DEBUG)
#if (defined (PTITMILIT) || ( defined (IT_FTHA) && !defined (SH) ) ) 
/* for logging purposes in error conditions for portable environment */
PRIVATE Txt prntBuf[PRNTSZE];
#endif 
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

PRIVATE LitCfgCfm itMiLitCfgCfmMt[IT_LIT_MAX_SEL] =
{
   /* selector = 0 */
#ifdef LCITMILIT
   cmPkLitCfgCfm,
#else
   PtMiLitCfgCfm,
#endif /* LCITMILIT */

   /* selector = 1 */
#ifdef SM
   SmMiLitCfgCfm,
#else
   PtMiLitCfgCfm,
#endif /* SM */
};

PRIVATE LitStsCfm itMiLitStsCfmMt[IT_LIT_MAX_SEL] =
{
   /* selector = 0 */
#ifdef LCITMILIT
   cmPkLitStsCfm,
#else
   PtMiLitStsCfm,
#endif /* LCITMILIT */

   /* selector = 1 */
#ifdef SM
   SmMiLitStsCfm,
#else
   PtMiLitStsCfm,
#endif /* SM */
};

PRIVATE LitStaCfm itMiLitStaCfmMt[IT_LIT_MAX_SEL] =
{
   /* selector = 0 */
#ifdef LCITMILIT
   cmPkLitStaCfm,
#else
   PtMiLitStaCfm,
#endif /* LCITMILIT */

   /* selector = 1 */
#ifdef SM
   SmMiLitStaCfm,
#else
   PtMiLitStaCfm,
#endif /* SM */
};

PRIVATE LitCntrlCfm itMiLitCntrlCfmMt[IT_LIT_MAX_SEL] =
{
   /* selector = 0 */
#ifdef LCITMILIT
   cmPkLitCntrlCfm,
#else
   PtMiLitCntrlCfm,
#endif /* LCITMILIT */

   /* selector = 1 */
#ifdef SM
   SmMiLitCntrlCfm,
#else
   PtMiLitCntrlCfm,
#endif /* SM */
};

PRIVATE LitStaInd itMiLitStaIndMt[IT_LIT_MAX_SEL] =
{
   /* selector = 0 */
#ifdef LCITMILIT
   cmPkLitStaInd,
#else
   PtMiLitStaInd,
#endif /* LCITMILIT */

   /* selector = 1 */
#ifdef SM
   SmMiLitStaInd,
#else
   PtMiLitStaInd,
#endif /* SM */
};

PRIVATE LitTrcInd itMiLitTrcIndMt[IT_LIT_MAX_SEL] =
{
   /* selector = 0 */
#ifdef LCITMILIT
   cmPkLitTrcInd,
#else
   PtMiLitTrcInd,
#endif /* LCITMILIT */

   /* selector = 1 */
#ifdef SM
   SmMiLitTrcInd,
#else
   PtMiLitTrcInd,
#endif /* SM */
};


#ifdef IT_FTHA             
/* System agent control Confirm primitive */
PRIVATE ShtCntrlCfm ItMiShtCntrlCfmMt[IT_LIT_MAX_SEL] =
{
   cmPkMiShtCntrlCfm,               /* 0 - loosely coupled          */

#ifdef SH
   ShMiShtCntrlCfm,                 /* 1 - tightly coupled system agent */
#else
   PtItMiShtCntrlCfm,               /* 1 - tightly coupled, portable*/
#endif
};
#endif /* IT_FTHA */


/* public routines */


/*
*
*       Fun:    ItMiLitCfgCfm
*
*       Desc:   configuration confirm
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   it_ptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 ItMiLitCfgCfm
(
Pst         *pst,
ItMgmt     *cfg
)
#else
PUBLIC S16 ItMiLitCfgCfm(pst, cfg)
Pst         *pst;
ItMgmt     *cfg;
#endif /* ANSI */
{
   TRC3(ItMiLitCfgCfm)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_LIT_MAX_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   RETVALUE((*itMiLitCfgCfmMt[pst->selector])(pst, cfg));
} /* end of ItMiLitCfgCfm() */


/*
*
*       Fun:    ItMiLitStsCfm
*
*       Desc:   statistics confirm
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   it_ptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 ItMiLitStsCfm
(
Pst         *pst,
ItMgmt     *sts
)
#else
PUBLIC S16 ItMiLitStsCfm(pst, sts)
Pst         *pst;
ItMgmt     *sts;
#endif /* ANSI */
{
   TRC3(ItMiLitStsCfm)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_LIT_MAX_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   RETVALUE((*itMiLitStsCfmMt[pst->selector])(pst, sts));
} /* end of ItMiLitStsCfm() */


/*
*
*       Fun:    ItMiLitStaCfm
*
*       Desc:   status confirm
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   it_ptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 ItMiLitStaCfm
(
Pst         *pst,             /* post structure */
ItMgmt      *ssta             /* management structure */
)
#else
PUBLIC S16 ItMiLitStaCfm(pst, ssta)
Pst         *pst;             /* post structure */         
ItMgmt      *ssta;            /* management structure */   
#endif /* ANSI */
{
   TRC3(ItMiLitStaCfm)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_LIT_MAX_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   RETVALUE((*itMiLitStaCfmMt[pst->selector])(pst, ssta));
} /* end of ItMiLitStaCfm() */


/*
*
*       Fun:    ItMiLitCntrlCfm
*
*       Desc:   control confirm
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   it_ptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 ItMiLitCntrlCfm
(
Pst         *pst,             /* post structure */         
ItMgmt      *cntrl            /* management structure */   
)
#else
PUBLIC S16 ItMiLitCntrlCfm(pst, cntrl)
Pst         *pst;             /* post structure */         
ItMgmt      *cntrl;           /* management structure */   
#endif /* ANSI */
{
   TRC3(ItMiLitCntrlCfm)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_LIT_MAX_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   RETVALUE((*itMiLitCntrlCfmMt[pst->selector])(pst, cntrl));
} /* end of ItMiLitCntrlCfm() */


/*
*
*       Fun:    ItMiLitStaInd
*
*       Desc:   status indication
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   it_ptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 ItMiLitStaInd
(
Pst         *pst,             /* post structure */         
ItMgmt      *usta             /* management structure */   
)
#else
PUBLIC S16 ItMiLitStaInd(pst, usta)
Pst         *pst;             /* post structure */         
ItMgmt      *usta;            /* management structure */   
#endif /* ANSI */
{
   TRC3(ItMiLitStaInd)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_LIT_MAX_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   RETVALUE((*itMiLitStaIndMt[pst->selector])(pst, usta));
} /* end of ItMiLitStaInd() */


/*
*
*       Fun:    ItMiLitTrcInd
*
*       Desc:   trace indication
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   it_ptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 ItMiLitTrcInd
(
Pst         *pst,             /* post structure */         
ItMgmt      *trc              /* management structure */   
)
#else
PUBLIC S16 ItMiLitTrcInd(pst, trc)
Pst         *pst;             /* post structure */         
ItMgmt      *trc;             /* management structure */   
#endif /* ANSI */
{
   TRC3(ItMiLitTrcInd)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= IT_LIT_MAX_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   RETVALUE((*itMiLitTrcIndMt[pst->selector])(pst, trc));
} /* end of ItMiLitTrcInd() */


#ifdef IT_FTHA
/*
*
*       Fun:   System agent control Confirm
*
*       Desc:  This function is used to send the system agent control confirm 
*              primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  it_ptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 ItMiShtCntrlCfm
(
Pst             *pst,        /* post structure */
ShtCntrlCfmEvnt *cfmInfo     /* system agent control confirm event */
)
#else
PUBLIC S16 ItMiShtCntrlCfm(pst, cfmInfo)
Pst             *pst;        /* post structure */
ShtCntrlCfmEvnt *cfmInfo;    /* system agent control confirm event */
#endif
{
   TRC3(ItMiShtCntrlCfm)

   /* jump to specific primitive depending on configured selector */
   (*ItMiShtCntrlCfmMt[pst->selector])(pst, cfmInfo); 

   RETVALUE(ROK);
} /* end of ItMiShtCntrlCfm */ 
#endif /* IT_FTHA */


#ifdef PTITMILIT
/*
*
*       Fun:    PtMiLitCfgCfm
*
*       Desc:   Dummy configuration confirm, customize if necessary
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   it_ptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 PtMiLitCfgCfm
(
Pst         *pst,             /* post structure */         
ItMgmt      *cfg              /* management structure */   
)
#else
PUBLIC S16 PtMiLitCfgCfm(pst, cfg)
Pst         *pst;             /* post structure */         
ItMgmt      *cfg;             /* management structure */   
#endif /* ANSI */
{
   TRC3(PtMiLitCfgCfm)
   ITLOGINVSEL;
   UNUSED(pst);
   UNUSED(cfg);
   RETVALUE(RFAILED);
} /* end of PtMiLitCfgCfm() */


/*
*
*       Fun:    PtMiLitStsCfm
*
*       Desc:   Dummy statistics confirm, customize if necessary
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   it_ptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 PtMiLitStsCfm
(
Pst         *pst,             /* post structure */         
ItMgmt      *sts              /* management structure */   
)
#else
PUBLIC S16 PtMiLitStsCfm(pst, sts)
Pst         *pst;             /* post structure */         
ItMgmt      *sts;             /* management structure */   
#endif /* ANSI */
{
   TRC3(PtMiLitStsCfm)
   ITLOGINVSEL;
   UNUSED(pst);
   UNUSED(sts);
   RETVALUE(RFAILED);
} /* end of PtMiLitStsCfm() */


/*
*
*       Fun:    PtMiLitStaCfm
*
*       Desc:   Dummy status confirm, customize if necessary
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   it_ptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 PtMiLitStaCfm
(
Pst         *pst,             /* post structure */         
ItMgmt      *ssta             /* management structure */   
)
#else
PUBLIC S16 PtMiLitStaCfm(pst, ssta)
Pst         *pst;             /* post structure */         
ItMgmt      *ssta;            /* management structure */   
#endif /* ANSI */
{
   TRC3(PtMiLitStaCfm)
   ITLOGINVSEL;
   UNUSED(pst);
   UNUSED(ssta);
   RETVALUE(RFAILED);
} /* end of PtMiLitStaCfm() */


/*
*
*       Fun:    PtMiLitCntrlCfm
*
*       Desc:   Dummy control confirm, customize if necessary
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   it_ptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 PtMiLitCntrlCfm
(
Pst         *pst,             /* post structure */         
ItMgmt      *cntrl            /* management structure */   
)
#else
PUBLIC S16 PtMiLitCntrlCfm(pst, cntrl)
Pst         *pst;             /* post structure */         
ItMgmt      *cntrl;           /* management structure */   
#endif /* ANSI */
{
   TRC3(PtMiLitCntrlCfm)
   ITLOGINVSEL;
   UNUSED(pst);
   UNUSED(cntrl);
   RETVALUE(RFAILED);
} /* end of PtMiLitCntrlCfm() */


/*
*
*       Fun:    PtMiLitStaInd
*
*       Desc:   Dummy status indication, customize if neceusary
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   it_ptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 PtMiLitStaInd
(
Pst         *pst,             /* post structure */         
ItMgmt      *usta             /* management structure */   
)
#else
PUBLIC S16 PtMiLitStaInd(pst, usta)
Pst         *pst;             /* post structure */         
ItMgmt      *usta;            /* management structure */   
#endif /* ANSI */
{
   TRC3(PtMiLitStaInd)
   ITLOGINVSEL;
   UNUSED(pst);
   UNUSED(usta);
   RETVALUE(RFAILED);
} /* end of PtMiLitStaInd() */


/*
*
*       Fun:    PtMiLitTrcInd
*
*       Desc:   Dummy trace indication, customize if neceusary
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   it_ptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 PtMiLitTrcInd
(
Pst         *pst,             /* post structure */         
ItMgmt      *trc              /* management structure */   
)
#else
PUBLIC S16 PtMiLitTrcInd(pst, trc)
Pst         *pst;             /* post structure */         
ItMgmt      *trc;             /* management structure */   
#endif /* ANSI */
{
   TRC3(PtMiLitTrcInd)
   ITLOGINVSEL;
   UNUSED(pst);
   UNUSED(trc);
   RETVALUE(RFAILED);
} /* end of PtMiLitTrcInd() */
#endif

#ifdef IT_FTHA
#ifndef SH
/*
*
*       Fun:    PtItMiShtCntrlCfm
*
*       Desc:   Dummy SHT Contrl Confirm, customize if neccessary.
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   it_ptmi.c
*
*/

#ifdef ANSI
PRIVATE S16 PtItMiShtCntrlCfm
(
Pst             *pst,         /* post structure */                      
ShtCntrlCfmEvnt *cfmInfo      /* system agent control confirm event */  
)
#else
PRIVATE S16 PtItMiShtCntrlCfm(pst, cfmInfo)
Pst             *pst;         /* post structure */                      
ShtCntrlCfmEvnt *cfmInfo;     /* system agent control confirm event */  
#endif /* ANSI */
{
   TRC3(PtItMiShtCntrlCfm)
   ITLOGINVSEL;
   UNUSED(pst);
   UNUSED(cfmInfo);
   RETVALUE(RFAILED);
} /* end of PtItMiShtCntrlCfm() */
#endif
#endif /* IT_FTHA */


/********************************************************************30**

         End of file:     it_ptmi.c@@/main/6 - Tue Dec 30 22:37:17 2003

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/3      ---      mrw  1.Initial version
/main/3      ---      nt   1. Changes for TCR18:
                              System agent cntrl Cfm primitive added
             ---      mrw  2. Updates to Release 1.2        
/main/4      ---      sg   1. Updates to Release 1.3
/main/5      ---      sg   1. Update to Release 1.4
/main/6      ---      nt   1. Update to Release 1.5
*********************************************************************91*/
