/**********************************************************************

        Name:   st_dbg.c - Debug print for M3UA

        Type:   C source file

        Desc:   C code for M3UA debug print

        File:   it_dbg.c

        Sid:    it_dbg.c - 2006/04/17

        Created by:     Chenning

**********************************************************************/
/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_ss7.h"        /* common SS7 */
#include "cm_tpt.h"        /* common transport defines */
#include "lit.h"           /* layer management M3UA  */
#include "sct.h"           /* SCT interface */
#include "snt.h"           /* SNT interface */
#include "it_err.h"        /* M3UA error */
#ifdef IT_FTHA
#include "sht.h"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "it.h"            /* M3UA internal defines */
#ifdef DI
#include "dit.h"
#endif /* DI */
#ifdef ZV
#include "cm_ftha.h"
#include "cm_psfft.h"          /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.h"
#include "cmzvdvlb.h"
#endif /* ZV_DFTHA */
#include "mrs.h"
#include "lzv.h"
#include "zv.h"            /* m3ua  PSF */
#endif /* ZV */
/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_ss7.x"        /* common SS7 */
#include "cm_tpt.x"        /* common transport */
#include "sct.x"           /* SCT interface */
#ifdef IT_FTHA
#include "sht.x"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "lit.x"           /* layer management M3UA */
#include "snt.x"           /* SNT interface */
#include "it.x"            /* M3UA internal typedefs */
#ifdef DI
#include "dit.x"
#endif /* DI */
#ifdef ZV
#include "cm_ftha.x"
#include "cm_psfft.x"
#ifdef ZV_DFTHA
#include "cmzvdv.x"
#include "cmzvdvlb.x"
#endif
#include "mrs.x"
#include "lzv.x"
#include "zv.x"            /* m3ua PSF */
#endif /* ZV */
#include "it_dbg.h"
#include "it_star.h"

/* local defines */
#ifdef SSI_WITH_CLI_ENABLED
/* local externs */

#ifdef ITASP 
#ifndef IT_AUTO_START
extern S16 StartWork(S16 suId);
#endif
#endif

EXTERN ItGlobalCb itGlobalCb;

CLI_ENV *pItCliEnv;
S32 ItDbgNowStep;
S32 ItDbgStepNum;
S8 achItDbgVar[ItVarMaxNum][ItVarNameMaxLength];
S32 ItDbgLock = 0;
/* functions */
PRIVATE VOID itDbg(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
PRIVATE VOID itDbgSelfShow(VOID);
PRIVATE VOID itDbgSelfControl(VOID);
PRIVATE VOID itDbgSelfHelp(VOID);
PRIVATE VOID itDbgSelfSet(XS32 siArgc, XCHAR **ppArgv );
PRIVATE VOID itCliExtLevel(U32 pfLevel);

/***************  Set  **********************/
/***************  Set  **********************/
PRIVATE VOID itDbgSetHelp(VOID);
PRIVATE VOID itDbgSetTraceName(XS32 siArgc, XCHAR **ppArgv);
PRIVATE VOID itDbgSetTraceNameHelp(VOID);
/*****************************************/
/*****************************************/

/***************  Control *******************/
/***************  Control *******************/
PRIVATE VOID itDbgControlSendData(VOID);
PRIVATE VOID itDbgControlAutoStart(VOID);
PRIVATE VOID itDbgControlSetMask(VOID);
PRIVATE VOID itDbgControlHelp(VOID);
PRIVATE VOID itDbgControlAutoStartHelp(VOID);
PRIVATE VOID itDbgControlSendDataHelp(VOID);
PRIVATE VOID itDbgControlSetMaskHelp(VOID);
/***** Control Inside Funcation *****/
PRIVATE VOID itDbgControlSetMaskCommHelp(VOID);
PRIVATE VOID itDbgControlSetMaskM3uaHelp(VOID);

PRIVATE VOID itDbgControlAutoStartStatus(VOID);
PRIVATE VOID itDbgControlAutoStartOpen(VOID);
PRIVATE VOID itDbgControlAutoStartClose(VOID);

PRIVATE VOID itDbgControlSetMaskStatus(VOID);
PRIVATE VOID itDbgControlSetMaskComm(VOID);
PRIVATE VOID itDbgControlSetMaskM3ua(VOID);

PRIVATE VOID itDbgControlSetMaskCommAdd(VOID);
PRIVATE VOID itDbgControlSetMaskCommSub(VOID);
PRIVATE VOID itDbgControlSetMaskM3uaAdd(VOID);
PRIVATE VOID itDbgControlSetMaskM3uaSub(VOID);
/*****************************************/
/*****************************************/


/*************** Show ************************/
/*************** Show ************************/
PRIVATE VOID itDbgShowCBK(VOID);
PRIVATE VOID itDbgShowCFG(VOID);
PRIVATE VOID itDbgShowSTS(VOID);
PRIVATE VOID itDbgShowSTA(VOID);
PRIVATE VOID itDbgShowHelp(VOID);

PRIVATE VOID itDbgShowCBKHelp(VOID);
PRIVATE VOID itDbgShowCFGHelp(VOID);
PRIVATE VOID itDbgShowSTSHelp(VOID);
PRIVATE VOID itDbgShowSTAHelp(VOID);
/***** Show Inside Funcation *****/

/***** CBK *****/
PRIVATE VOID itDbgShowCBKgen(VOID);
PRIVATE VOID itDbgShowCBKnwk(VOID);
PRIVATE VOID itDbgShowCBKnsp(VOID);
PRIVATE VOID itDbgShowCBKcsp(VOID);
PRIVATE VOID itDbgShowCBKpse(VOID);
PRIVATE VOID itDbgShowCBKass(VOID);
PRIVATE VOID itDbgShowCBKpsp(VOID);
PRIVATE VOID itDbgShowCBKdpc(VOID);
PRIVATE VOID itDbgShowCBKrte(VOID);

PRIVATE VOID itDbgPrintfGenCbk(U32 pfLevel, ItGlobalCb* GlobalCb);
PRIVATE VOID itDbgPrintfNwkCbk(U32 NwkID, U32 pfLevel);
PRIVATE VOID itDbgPrintfOneNwkCbk(U32 nwkID, U32 pfLevel, ItNwkCb* NwkCb);
PRIVATE VOID itDbgPrintfNsapCbk(U32 NsapID, U32 pfLevel);
PRIVATE VOID itDbgPrintfOneNsapCbk(S32 nsapID, U32 pfLevel, ItNSapCb* NsapCb);
PRIVATE VOID itDbgPrintfSctsapCbk(U32 SctsapID, U32 pfLevel);
PRIVATE VOID itDbgPrintfOneSctsapCbk(S32 sctsapID, U32 pfLevel, ItSctSapCb* SctsapCb);
PRIVATE VOID itDbgPrintfPsCbk(U32 PsId, U32 pfLevel);
PRIVATE VOID itDbgPrintfOnePsCbk(U32 psID, U32 pfLevel, ItPsCb* PsCb);
PRIVATE VOID itDbgPrintfAssCbk(U32 AssID, U32 pfLevel);
PRIVATE VOID itDbgPrintfOneAssCbk(U32 AssID, U32 pfLevel, ItAssocCb* AssCb);
PRIVATE VOID itDbgPrintfPspCbk(U32 PspID, U32 pfLevel);
PRIVATE VOID itDbgPrintfOnePspCbk(U32 pspID, U32 pfLevel, ItPspCb* PspCb);

PRIVATE VOID itDbgPrintfDpcCbk(U32 pfLevel, CmHashListCp* DpcList);
PRIVATE VOID itDbgPrintfOneDpcCbk(U8 NwkID, U32 DPC, U32 pfLevel, ItDpcCb* DpcCb);
PRIVATE VOID itDbgPrintfRouteCbk(U32 pfLevel, CmLListCp* RteList);
PRIVATE VOID itDbgPrintfOneRouteCbk(U8 NwkID, U32 DPC, U32 pfLevel, ItRouteCb* RouteCb);
    
PRIVATE VOID itDbgPrintfOneLscAllCbk(U8 LoadShareType, U32 pfLevel, ItLscAllCb* LscAllCb);
PRIVATE VOID itDbgPrintfOneLscRndRbnCbk(U32 pfLevel, ItLscRndRbnCb* LscRndRbnCb);
PRIVATE VOID itDbgPrintfOneLscSls(U32 pfLevel, ItLscSlsCb* LscSlsCb);
PRIVATE VOID itDbgPrintfOneHashListCbk(U32 pfLevel, CmHashListCp* HashListCp);
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
PRIVATE VOID itDbgPrintfOneChldPsCbk(U8 LoadShareType, U32 pfLevel, ItChldPsCb* chldPsLst);
#endif
PRIVATE VOID itDbgPrintfOnePstCbk(U32 pfLevel, Pst* pst);
PRIVATE VOID itDbgPrintfOneTimerCbk(U32 pfLevel, CmTimer* Timer);
PRIVATE VOID itDbgPrintfOneRrkCbk(U32 pfLevel, ItRegReqTmrCb* RegReqTmrCb);
PRIVATE VOID itDbgPrintfPsIdListCbk(U32 pfLevel, ItPsLstCb* PsLstCb);
PRIVATE VOID itDbgPrintfAspIdCbk(U32 pfLevel, ItAspIdCb* AspIdCb);
PRIVATE VOID itDbgPrintfAddrTrnCbk(U32 pfLevel, ItAddrTrnCb* AddrTrnCb);

PRIVATE VOID itDbgPrintfOneMemoryId(U32 pfLevel, MemoryId* MemId);
PRIVATE VOID itDbgPrintfOneDateTime(U32 pfLevel, DateTime* DTime);
PRIVATE VOID itDbgPrintfTaskInit(U32 pfLevel, TskInit* TskInitial);
PRIVATE S32 CheckMaskValue ( S8* chMaskValue );

/***** CFG *****/
PRIVATE VOID itDbgShowCFGgen(VOID);
PRIVATE VOID itDbgShowCFGnwk(VOID);
PRIVATE VOID itDbgShowCFGnsp(VOID);
PRIVATE VOID itDbgShowCFGcsp(VOID);
PRIVATE VOID itDbgShowCFGpse(VOID);
PRIVATE VOID itDbgShowCFGpsp(VOID);

PRIVATE VOID itDbgPrintfGenCfg(U32 pfLevel, ItGenCfg* GenCfg);
PRIVATE VOID itDbgPrintfOneNwkCfg( U32 pfLevel, ItNwkCfg* NwkCfg );
PRIVATE VOID itDbgPrintfOneNsapCfg( U32 pfLevel, ItNSapCfg* NSapCfg );
PRIVATE VOID itDbgPrintfOneSctsapCfg( U32 pfLevel, ItSctSapCfg* SctSapCfg );
PRIVATE VOID itDbgPrintfOnePspCfg( U32 pfLevel, ItPspCfg* PspCfg );
PRIVATE VOID itDbgPrintfOnePsCfg( U32 pfLevel, ItPsCfg* PsCfg );
PRIVATE VOID itDbgPrintfOneAssCfg( U32 pfLevel, ItAssocCfg* AssocCfg );
PRIVATE VOID itDbgPrintfRteCfg( U32 pfLevel, ItRteCfg* RteCfg );
PRIVATE VOID itDbgPrintfRteFilter( U32 pfLevel, ItRtFilter* RtFilter );

/***** STS *****/
PRIVATE VOID itDbgShowSTSgen(VOID);
PRIVATE VOID itDbgShowSTSnsp(VOID);
PRIVATE VOID itDbgShowSTScsp(VOID);
PRIVATE VOID itDbgShowSTSpsp(VOID);

PRIVATE VOID itDbgPrintfGenSts(U32 pfLevel, ItGenSts* GenSts);
PRIVATE VOID itDbgPrintfOneNsapSts(U32 pfLevel, ItNSapSts* NSapSts);
PRIVATE VOID itDbgPrintfOneSctsapSts(U32 pfLevel, ItSctSapSts* SctSapSts);
PRIVATE VOID itDbgPrintfOnePspSts(U32 pfLevel, ItPspSts* PspSts);

PRIVATE VOID itDbgPrintfOneMtp3Sts(U32 pfLevel, ItMtp3Sts* Mtp3Sts);
PRIVATE VOID itDbgPrintfOneM3uaSts(U32 pfLevel, ItM3uaSts* M3uaSts);
PRIVATE VOID itDbgPrintfOneDataSts(U32 pfLevel, ItDataSts* DataSts);
PRIVATE VOID itDbgPrintfOneDataErrSts(U32 pfLevel, ItDataErrSts* DataErrSts);
#ifdef LITV3
PRIVATE VOID itDbgPrintfOneUnavSts(U32 pfLevel, ItUnavSts* UnavSts);
PRIVATE VOID itDbgPrintfOneCongSts(U32 pfLevel, ItCongSts* CongSts);
#endif
/***** STA *****/
/***** STA *****/
PRIVATE VOID itDbgShowSTAgen(VOID);
PRIVATE VOID itDbgShowSTAnsp(VOID);
PRIVATE VOID itDbgShowSTAcsp(VOID);
PRIVATE VOID itDbgShowSTApse(VOID);
PRIVATE VOID itDbgShowSTApsp(VOID);
PRIVATE VOID itDbgShowSTAadd(VOID);
PRIVATE VOID itDbgShowSTAdrk(VOID);
PRIVATE VOID itDbgShowSTApri(VOID);
PRIVATE VOID itDbgShowSTAdpc(VOID);

PRIVATE VOID itDbgPrintfGenSta(U32 pfLevel, ItGenSta* GenSta);
PRIVATE VOID itDbgPrintfOneNsapSta(U32 pfLevel, ItNSapSta* NSapSta);
PRIVATE VOID itDbgPrintfOnePsendpSta(U32 pfLevel, ItPsStaEndp* PsStaEndp);
PRIVATE VOID itDbgPrintfOnePsSta(U32 pfLevel, ItPsSta* PsSta);
PRIVATE VOID itDbgPrintfOneAssocSta(U32 pfLevel, ItAssocSta* AssocSta);
PRIVATE VOID itDbgPrintfOnePspSta(U32 pfLevel, ItPspSta* PspSta);
PRIVATE VOID itDbgPrintfOneSctSapSta(U32 pfLevel, ItSctSapSta* SctSapSta);
PRIVATE VOID itDbgPrintfAtSta(U32 pfLevel, ItAtSta* AtSta);
PRIVATE VOID itDbgPrintfRkSta(U32 pfLevel, ItRkSta* RkSta);
PRIVATE VOID itDbgPrintfPspRkIdSta(U32 pfLevel, ItPspRkIdSta* PspRkIdSta);
PRIVATE VOID itDbgPrintfDpcSta(U32 pfLevel, ItDpcSta* DpcSta);
/*****************************************/
/*****************************************/

/***************************************************************************
*
* Interface Functions to OAM
*
***************************************************************************/
VOID itDbgShow(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR**ppArgv)
{
    itDbg(pCliEnv, siArgc, ppArgv);
}

VOID itDbgControl(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    itDbg(pCliEnv, siArgc, ppArgv);
}

VOID itDbgSet(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    itDbg(pCliEnv, siArgc, ppArgv);
}

VOID itDbgPrintfConfig(VOID)
{
    U32 i;
    U32 j;
    ItPsCb* pPsCb;
    ItRouteCb * curRouteCb;
    
    printf("\r\nM3UA General Configuration Table:\r\n");
    printf("MaxPsNum: %d\r\n", itGlobalCb.genCfg.maxNmbPs);
    printf("MaxPspNum: %d\r\n", itGlobalCb.genCfg.maxNmbPsp);
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
    printf("MaxLpsNum: %d\r\n", itGlobalCb.genCfg.maxNmbLps);
#endif
    printf("MaxNumMsg: %d\r\n", itGlobalCb.genCfg.maxNmbMsg);
    printf("MaxNumRndRbnls: %d\r\n", itGlobalCb.genCfg.maxNmbRndRbnLs);
    printf("MaxNumSlsls: %d\r\n", itGlobalCb.genCfg.maxNmbSlsLs);
    printf("MaxNumSls: %d\r\n", itGlobalCb.genCfg.maxNmbSls);
    printf("DrkmSupp: %d\r\n", itGlobalCb.genCfg.drkmSupp);
    printf("DrstSupp: %d\r\n", itGlobalCb.genCfg.drstSupp);
    printf("Heartbeat Time: %d\r\n", itGlobalCb.genCfg.tmr.tmrHeartbeat.val);

    printf("\r\nM3UA Node Configuration Table:\r\n");
    printf("Node Type: %d\r\n", itGlobalCb.genCfg.nodeType);

    printf("\r\nM3UA Psp Configuration Table:\r\n");
    for ( i = 0; i < itGlobalCb.genCfg.maxNmbPsp; i++ )
    {
        if ( ( (ItPspCb*)NULLP == itGlobalCb.psp[i] ) || ( 0 ==  i )  )
        {
            continue;
        }
        printf("    Psp %d Table:\r\n", i);
        printf("        PspType: %d\r\n", itGlobalCb.psp[i]->pspCfg.pspType);
        printf("        IpspType: %d\r\n", itGlobalCb.psp[i]->pspCfg.ipspMode);
        printf("        DfltLshareMode: %d\r\n", itGlobalCb.psp[i]->pspCfg.dfltLshareMode);
        printf("        NwkAppIncl: %d\r\n", itGlobalCb.psp[i]->pspCfg.nwkAppIncl);
        printf("        NwkID: %d\r\n", itGlobalCb.psp[i]->pspCfg.nwkId);
    }

    printf("\r\nM3UA Ps Configuration Table:\r\n");
    for ( i = 0; i < itGlobalCb.genCfg.maxNmbPs; i++ )
    {
        pPsCb  = itPsmFindPs(i);
        if ( (ItPsCb*)NULLP == pPsCb )
        {
            continue;
        }
        printf("    Ps %d Table:\r\n", i);
        printf("        NwkID: %d\r\n", pPsCb->psCfg.nwkId);
        printf("        PsWorkMode: %d\r\n", pPsCb->psCfg.mode);
        printf("        RoutCtx: %d\r\n", pPsCb->psCfg.routCtx);
        printf("        LoadShareMode: %d\r\n", pPsCb->psCfg.loadShareMode);
        printf("        LocalFlag: %d\r\n", pPsCb->psCfg.lclFlag);
        printf("        ActivePspRequired: %d\r\n", pPsCb->psCfg.nmbActPspReqd);
        printf("        PspNum: %d\r\n", pPsCb->psCfg.nmbPsp);
        for ( j=0; j<pPsCb->psCfg.nmbPsp; j++)
        {
            printf("            Psp: %d\r\n", pPsCb->psCfg.psp[j]);
        }
    }

    printf("\r\nM3UA Route Configuration Table:\r\n");
    i = 0;
    for (curRouteCb = (ItRouteCb *)cmLListFirst(&itGlobalCb.addrTrn.rtList); 
    curRouteCb;
    curRouteCb = (ItRouteCb *)cmLListNext(&itGlobalCb.addrTrn.rtList))
    {
        printf("    Route %d Table:\r\n", i);
        printf("        RouteType: %d\r\n",curRouteCb->rteCfg.rtType);
        printf("        PsID: %d\r\n",curRouteCb->rteCfg.psId);
        printf("        NwkID: %d\r\n",curRouteCb->rteCfg.nwkId);
        printf("        DPCValue: %d\r\n",curRouteCb->rteCfg.rtFilter.dpc);
        printf("        OPCValue: %d\r\n",curRouteCb->rteCfg.rtFilter.opc);
        printf("        SIO: %d\r\n",curRouteCb->rteCfg.rtFilter.sio);
        printf("        CICStart: %d\r\n",curRouteCb->rteCfg.rtFilter.cicStart);
        printf("        CICEnd: %d\r\n",curRouteCb->rteCfg.rtFilter.cicEnd);
        printf("        SSN: %d\r\n",curRouteCb->rteCfg.rtFilter.ssn);
        printf("        TridStart: %d\r\n",curRouteCb->rteCfg.rtFilter.tridStart);
        printf("        TridEnd: %d\r\n",curRouteCb->rteCfg.rtFilter.tridEnd);
        i++;
    }
}

VOID itDbgControlSetMaskAdd(VOID)
{
    U32 uiMaskValue = IT_MASK_ALL;
    
    itGlobalCb.itInit.dbgMask |= uiMaskValue;
    
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UA Set Mask Command Operation Succeed");
}

VOID itDbgControlSetMaskSub(VOID)
{
    U32 uiMaskValue = IT_MASK_ALL;
    
    itGlobalCb.itInit.dbgMask &= ~(uiMaskValue);
    
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UA Set Mask Command Operation Succeed");
}

/***************************************************************************
*
* Inside Functions
*
***************************************************************************/

/***************************************************************************
* Inside Functions
***************************************************************************/
PRIVATE VOID itDbg(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    S32 i = 0;
    S32 j = 0;
    S32 ret = 0;

    if ( 0 == ItDbgLock )
    {
        ItDbgLock = 1;
        if ( NULLP == pCliEnv )
        {
            XOS_CliExtPrintf(pCliEnv, IT_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
            goto EndItDbg;
        }

        pItCliEnv = pCliEnv;
        
        if ( NULLP == ppArgv )
        {
            XOS_CliExtPrintf(pCliEnv, IT_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
            goto EndItDbg;
        }

        i = siArgc;

        if ( 2 > i )
        {
            XOS_CliExtWriteStrLine(pCliEnv, IT_DBG_ERR_STR_VARNUMBERLACK);
            goto EndItDbg;
        }

        if ( ItVarMaxNum < i )
        {
            XOS_CliExtWriteStrLine(pCliEnv, IT_DBG_ERR_STR_VARNUMBERMORE);
            goto EndItDbg;
        }
        
        memset(achItDbgVar, 0, ItVarMaxNum*ItVarNameMaxLength*sizeof(achItDbgVar[0][0]));  
        
        for ( j = 0; j < i; j++ )
        {
            memcpy(achItDbgVar[j], ppArgv[j], ItVarNameMaxLength-1);
            achItDbgVar[j][ItVarNameMaxLength-1] = '\0';
        }

        ItDbgStepNum = i;
        ItDbgNowStep = 0;
        
        ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR1_SHOW, ItVarNameMaxLength);
        if ( 0 == ret )
        {
            ItDbgNowStep++;
            itDbgSelfShow();
            goto EndItDbg;
        }

        ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR1_CONTROL, ItVarNameMaxLength);
        if ( 0 == ret )
        {
            ItDbgNowStep++;
            itDbgSelfControl();
            goto EndItDbg;
        }

        ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR1_SET, ItVarNameMaxLength);
        if ( 0 == ret )
        {
            ItDbgNowStep++;
            itDbgSelfSet(siArgc, ppArgv);
            goto EndItDbg;
        }
        
        ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP, ItVarNameMaxLength);
        if ( 0 == ret )
        {
            ItDbgNowStep++;
            itDbgSelfHelp();
            goto EndItDbg;
        }
        
        XOS_CliExtWriteStrLine(pCliEnv, IT_DBG_ERR_STR_FIRSTVARTYPE);
        goto EndItDbg;
    }
    else
    {
        XOS_CliExtWriteStrLine(pCliEnv, IT_DBG_ERR_STR_LOCK);
        goto EndItDbgLock;
    }
EndItDbg:
    ItDbgLock = 0;
EndItDbgLock:
    RETVOID;
}

PRIVATE VOID itDbgSelfShow(VOID )
{
    S32 ret = 0;

    XOS_CliExtWriteStrLine(pItCliEnv, "Result :");
    
    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR2_CONTROLBLOCK, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowCBK();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR2_CONFIG, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowCFG();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR2_STATUS, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowSTS();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR2_STATIS, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowSTA();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowHelp();
        RETVOID;
    }

    XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_SECONDVARTYPE);
    RETVOID;
}

PRIVATE VOID itDbgSelfControl(VOID)
{
    S32 ret = 0;

    XOS_CliExtWriteStrLine(pItCliEnv, "Result :");

    /*
    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR2_SENDDATA, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlSendData();
        RETVOID;
    }
    */
    
#ifdef ITASP
#ifndef IT_AUTO_START
    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR2_AUTOSTART, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlAutoStart();
        RETVOID;
    }
#endif
#endif
    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR2_SETMASK, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlSetMask();
        RETVOID;
    }
    
    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlHelp();
        RETVOID;
    }

    XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Error");
    XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_SECONDVARTYPE);
    RETVOID;
}

PRIVATE VOID itDbgSelfSet(XS32 siArgc, XCHAR **ppArgv)
{
    S32 ret = 0;

    XOS_CliExtWriteStrLine(pItCliEnv, "Result :");
    
    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR2_TRACENAME, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgSetTraceName(siArgc, ppArgv);
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgSetHelp();
        RETVOID;
    }

    XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_SECONDVARTYPE);
    RETVOID;
}

PRIVATE VOID itDbgSelfHelp(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UAЭ��֧�������б�:");
    XOS_CliExtWriteStrLine(pItCliEnv, "");
    XOS_CliExtWriteStrLine(pItCliEnv, "    show ---- �ò���Ϊ��ӡ�����û�ͳ�ơ�״̬��Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "              �ò���������Ϣ������show ?|help����ȡ");
    XOS_CliExtWriteStrLine(pItCliEnv, "");
    XOS_CliExtWriteStrLine(pItCliEnv, "    ctrl ---- �ò���Ϊִ�и�����������ɲ�ͬ�Ĺ���");
    XOS_CliExtWriteStrLine(pItCliEnv, "              �ò���������Ϣ������ctrl ?|help����ȡ");
    XOS_CliExtWriteStrLine(pItCliEnv, "");
    XOS_CliExtWriteStrLine(pItCliEnv, "    set ---- �ò���Ϊ���ø��ֹ��ܲ���");
    XOS_CliExtWriteStrLine(pItCliEnv, "              �ò���������Ϣ������set ?|help����ȡ");
    XOS_CliExtWriteStrLine(pItCliEnv, "");
    XOS_CliExtWriteStrLine(pItCliEnv, "    help ----  �ò���Ϊ��ȡ�������ڲ��������help��?");
    XOS_CliExtWriteStrLine(pItCliEnv, "              ���ܻ�ȡ�ò����ľ�����Ϣ");
}

/***************************************************************************
* Inside Functions
***************************************************************************/

/**********************************************
* Show Funcation
**********************************************/
PRIVATE VOID itDbgShowCBK(VOID)
{
    S32 ret = 0;

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_GENERAL, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowCBKgen();
        RETVOID;
    }
    
    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_NETWORK, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowCBKnwk();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_NSAP, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowCBKnsp();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_SCTSAP, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowCBKcsp();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_PS, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowCBKpse();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_ASSOCIATION, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowCBKass();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_PSP, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowCBKpsp();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_DPC, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowCBKdpc();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_ROUTING, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowCBKrte();
        RETVOID;
    }
    
    ret = ( ( strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP, ItVarNameMaxLength) ) && (strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP_OTHER, ItVarNameMaxLength)) );
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowCBKHelp();
        RETVOID;
    }
    
    XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_THIRDVARTYPE);
    RETVOID;
}

PRIVATE VOID itDbgShowCFG(VOID)
{
    S32 ret = 0;

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_GENERAL, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowCFGgen();
        RETVOID;
    }
    
    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_NETWORK, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowCFGnwk();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_NSAP, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowCFGnsp();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_SCTSAP, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowCFGcsp();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_PS, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowCFGpse();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_PSP, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowCFGpsp();
        RETVOID;
    }

    ret = ( ( strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP, ItVarNameMaxLength) ) && (strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP_OTHER, ItVarNameMaxLength)) );
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowCFGHelp();
        RETVOID;
    }
    
    XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_THIRDVARTYPE);
    RETVOID;
}

PRIVATE VOID itDbgShowSTS(VOID)
{
    S32 ret = 0;

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_GENERAL, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowSTSgen();
        RETVOID;
    }
    
    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_NSAP, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowSTSnsp();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_SCTSAP, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowSTScsp();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_PSP, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowSTSpsp();
        RETVOID;
    }

    ret = ( ( strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP, ItVarNameMaxLength) ) && (strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP_OTHER, ItVarNameMaxLength)) );
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowSTSHelp();
        RETVOID;
    }
    
    XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_THIRDVARTYPE);
    RETVOID;
}

PRIVATE VOID itDbgShowSTA(VOID)
{
    S32 ret = 0;

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_GENERAL, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowSTAgen();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_NSAP, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowSTAnsp();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_SCTSAP, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowSTAcsp();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_PS, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowSTApse();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_PSP, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowSTApsp();
        RETVOID;
    }

    /*
    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_DYNARK, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowSTAdrk();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_PSPRKID, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowSTApri();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_DPC, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowSTAdpc();
        RETVOID;
    }
    */
    ret = ( ( strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP, ItVarNameMaxLength) ) && (strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP_OTHER, ItVarNameMaxLength)) );
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgShowSTAHelp();
        RETVOID;
    }
    
    XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_THIRDVARTYPE);
    RETVOID;
}

PRIVATE VOID itDbgShowHelp(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UAЭ��show ����֧�������б�:");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  cbk  ---- �ò���Ϊ��ӡ�����ƿ���Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "            �ò���������Ϣ������show cbk ?|help  ����ȡ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  cfg  ---- �ò���Ϊ��ӡ��������Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "            �ò���������Ϣ������show cfg ?|help  ����ȡ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  sts  ---- �ò���Ϊ��ӡ��ͳ����Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "            �ò���������Ϣ������show sts ?|help  ����ȡ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  sta  ---- �ò���Ϊ��ӡ��״̬��Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "            �ò���������Ϣ������show sta ?|help  ����ȡ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  help ---- �ò���Ϊ��ȡ�������ڲ��������?��help");
    XOS_CliExtWriteStrLine(pItCliEnv, "            ���ܻ�ȡ�ò����ľ�����Ϣ");
}

PRIVATE VOID itDbgShowCBKHelp(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UAЭ��show cbk ����֧�������б�:");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  gen ---- �ò���Ϊ��ӡ���������ƿ���Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  nwk ---- �ò���Ϊ��ӡ���������ÿ��ƿ���Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "           ����治���������ӡ�������������ÿ��ƿ�ID");
    XOS_CliExtWriteStrLine(pItCliEnv, "           �������������ӡ����ӦID �������ÿ��ƿ���Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  csp ---- �ò���Ϊ��ӡ��SCTSAP ���ƿ���Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "           ����治���������ӡ������SCTSAP ���ƿ�ID");
    XOS_CliExtWriteStrLine(pItCliEnv, "           �������������ӡ����ӦID SCTSAP ���ƿ���Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  nsp ---- �ò���Ϊ��ӡ��NSAP ���ƿ���Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "           ����治���������ӡ��NSAP ���ƿ�ID");
    XOS_CliExtWriteStrLine(pItCliEnv, "           �������������ӡ����ӦID NSAP ���ƿ���Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  psp ---- �ò���Ϊ��ӡ��PSP ���ƿ���Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "           ����治���������ӡ������PSP ���ƿ�ID");
    XOS_CliExtWriteStrLine(pItCliEnv, "           �������������ӡ����ӦID PSP ���ƿ���Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  pse ---- �ò���Ϊ��ӡ��PS ���ƿ���Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "           ����治���������ӡ������PS ���ƿ�ID");
    XOS_CliExtWriteStrLine(pItCliEnv, "           �������������ӡ����ӦID PS ���ƿ���Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  ass ---- �ò���Ϊ��ӡ��Associations ���ƿ���Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "           ����治���������ӡ������Associations ���ƿ�ID");
    XOS_CliExtWriteStrLine(pItCliEnv, "           �������������ӡ����ӦID Associations ���ƿ���Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  rte ---- �ò���Ϊ��ӡ������·�ɿ��ƿ���Ϣ"); 
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  dpc ---- �ò���Ϊ��ӡ������DPC���ƿ���Ϣ"); 
}

PRIVATE VOID itDbgShowCFGHelp(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UAЭ��show cfg ����֧�������б�:");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  gen ---- �ò���Ϊ��ӡ������������Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  nwk ---- �ò���Ϊ��ӡ������������Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "           ����治���������ӡ��������������ID");
    XOS_CliExtWriteStrLine(pItCliEnv, "           �������������ӡ����ӦID ����������Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  csp ---- �ò���Ϊ��ӡ��SCTSAP ������Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "           ����治���������ӡ������SCTSAP ����ID");
    XOS_CliExtWriteStrLine(pItCliEnv, "           �������������ӡ����ӦID SCTSAP ������Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  nsp ---- �ò���Ϊ��ӡ��NSAP ������Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "           ����治���������ӡ��NSAP ����ID");
    XOS_CliExtWriteStrLine(pItCliEnv, "           �������������ӡ����ӦID NSAP ������Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  psp ---- �ò���Ϊ��ӡ��PSP ������Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "           ����治���������ӡ������PSP ����ID");
    XOS_CliExtWriteStrLine(pItCliEnv, "           �������������ӡ����ӦID PSP ������Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  pse ---- �ò���Ϊ��ӡ��PS ������Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "           ����治���������ӡ������PS ����ID");
    XOS_CliExtWriteStrLine(pItCliEnv, "           �������������ӡ����ӦID PS ������Ϣ");
}

PRIVATE VOID itDbgShowSTSHelp(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UAЭ��show sts ����֧�������б�:");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  gen ---- �ò���Ϊ��ӡ������ͳ����Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  nsp ---- �ò���Ϊ��ӡ��NSAP ͳ����Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "           ����治���������ӡ��NSAP ͳ��ID");
    XOS_CliExtWriteStrLine(pItCliEnv, "           �������������ӡ����ӦID NSAP ͳ����Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  csp ---- �ò���Ϊ��ӡ��SCTSAP ͳ����Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "           ����治���������ӡ������SCTSAP ͳ��ID");
    XOS_CliExtWriteStrLine(pItCliEnv, "           �������������ӡ����ӦID SCTSAP ͳ����Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  psp ---- �ò���Ϊ��ӡ��PSP ͳ����Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "           ����治���������ӡ������PSP ͳ��ID");
    XOS_CliExtWriteStrLine(pItCliEnv, "           �������������ӡ����ӦID PSP ͳ����Ϣ");
}

PRIVATE VOID itDbgShowSTAHelp(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UAЭ��show sta ����֧�������б�:");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  gen ---- �ò���Ϊ��ӡ������״̬��Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  csp ---- �ò���Ϊ��ӡ��SCTSAP ״̬��Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "           ����治���������ӡ������SCTSAP ״̬ID");
    XOS_CliExtWriteStrLine(pItCliEnv, "           �������������ӡ����ӦID SCTSAP ״̬��Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  nsp ---- �ò���Ϊ��ӡ��NSAP ״̬��Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "           ����治���������ӡ��NSAP ״̬ID");
    XOS_CliExtWriteStrLine(pItCliEnv, "           �������������ӡ����ӦID NSAP ״̬��Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  psp ---- �ò���Ϊ��ӡ��PSP ״̬��Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "           ����治���������ӡ������PSP ״̬ID");
    XOS_CliExtWriteStrLine(pItCliEnv, "           �������������ӡ����ӦID PSP ״̬��Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  pse ---- �ò���Ϊ��ӡ��PS ״̬��Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "           ����治���������ӡ������PS ״̬ID");
    XOS_CliExtWriteStrLine(pItCliEnv, "           �������������ӡ����ӦID PS ״̬��Ϣ");
}

/***************************************************************************
* Control Functions
***************************************************************************/
PRIVATE VOID itDbgControlHelp(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UAЭ��ctrl����֧�������б�:");
    /*
    XOS_CliExtWriteStrLine(pItCliEnv, "");
    XOS_CliExtWriteStrLine(pItCliEnv, "  data ---- �ò���Ϊ������Ϣ");
    XOS_CliExtWriteStrLine(pItCliEnv, "            �ò���������Ϣ������ctrl data ?|help����ȡ");
    */
#ifdef ITASP
#ifndef IT_AUTO_START
    XOS_CliExtWriteStrLine(pItCliEnv, "");
    XOS_CliExtWriteStrLine(pItCliEnv, "  auto ---- �ò���Ϊ����M3UA�Զ�������ʱ��");
    XOS_CliExtWriteStrLine(pItCliEnv, "            �ò���������Ϣ������ctrl auto ?|help ����ȡ");
#endif
#endif
    XOS_CliExtWriteStrLine(pItCliEnv, "");
    XOS_CliExtWriteStrLine(pItCliEnv, "  mask ---- �ò���Ϊ����M3UAЭ��Ĵ�ӡ����");
    XOS_CliExtWriteStrLine(pItCliEnv, "            �ò���������Ϣ������ctrl mask ?|help ����ȡ");
    XOS_CliExtWriteStrLine(pItCliEnv, "");
    XOS_CliExtWriteStrLine(pItCliEnv, "  help ---- �ò���Ϊ��ȡ�������ڲ��������?|help");
    XOS_CliExtWriteStrLine(pItCliEnv, "            ���ܻ�ȡ�ò����ľ�����Ϣ");
}

PRIVATE VOID itDbgControlAutoStartHelp(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UAЭ��ctrl auto ����֧�������б�:");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  open ---- �ò���Ϊ���Զ�������ʱ��");
    XOS_CliExtWriteStrLine(pItCliEnv, "            �ò���������Ҫ����PSP ID����");
    XOS_CliExtWriteStrLine(pItCliEnv, "            ������ӽ������е��Զ�������ʱ��");
#if 0
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  clos ---- �ò���Ϊ�ر��Զ�������ʱ��");
    XOS_CliExtWriteStrLine(pItCliEnv, "            �ò���������Ҫ����PSP ID����");
    XOS_CliExtWriteStrLine(pItCliEnv, "            ������ӽ��ر����е��Զ�������ʱ��");
#endif
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  sta  ---- �ò���Ϊ�鿴�Զ�������ʱ���Ƿ�򿪻�ر�");
    XOS_CliExtWriteStrLine(pItCliEnv, "            �ò���������Ҫ����PSP ID����");
    XOS_CliExtWriteStrLine(pItCliEnv, "            ������ӽ��鿴���е��Զ�������ʱ����״̬");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  help ---- �ò���Ϊ��ȡ�������ڲ��������?|help");
    XOS_CliExtWriteStrLine(pItCliEnv, "            ���ܻ�ȡ�ò����ľ�����Ϣ");
    RETVOID;
}

PRIVATE VOID itDbgControlSendDataHelp(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UAЭ��ctrl data ����֧�������б�:");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  open ---- �ò���Ϊ���Զ�����");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  clos ---- �ò���Ϊ�ر��Զ�����");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  sta  ---- �ò���Ϊ�鿴�Զ������Ƿ�򿪻�ر�");
    RETVOID;
}

PRIVATE VOID itDbgControlSetMaskHelp(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UAЭ��ctrl mask ����֧�������б�:");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  comm ---- �ò���Ϊ����ͨ�õ�DEBUG����");
    XOS_CliExtWriteStrLine(pItCliEnv, "            �ò���������Ϣ������ctrl mask comm ?|help ����ȡ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  m3ua ---- �ò���Ϊ����M3UAר�е�DEBUG����");
    XOS_CliExtWriteStrLine(pItCliEnv, "            �ò���������Ϣ������ctrl mask m3ua ?|help ����ȡ");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  sta  ---- �ò���Ϊ��ӡ����DEBUG����״̬");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  add  ---- �ò���Ϊ��M3UA ���е�DEBUG���ͣ�");
    XOS_CliExtWriteStrLine(pItCliEnv, "            ����ͨ�ú�M3UAר��DEBUG����");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  sub  ---- �ò���Ϊ�ر�M3UA ���е�DEBUG���ͣ�");
    XOS_CliExtWriteStrLine(pItCliEnv, "            ����ͨ�ú�M3UAר��DEBUG����");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  help ---- �ò���Ϊ��ȡ�������ڲ��������?|help");
    XOS_CliExtWriteStrLine(pItCliEnv, "            ���ܻ�ȡ�ò����ľ�����Ϣ");
    RETVOID;
}

PRIVATE VOID itDbgControlSetMaskCommHelp(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UAЭ��ctrl mask comm ����֧�������б�:");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  add  ---- �ò���Ϊ����ͨ�õ�DEBUG����");
    XOS_CliExtWriteStrLine(pItCliEnv, "            �ò�����������������������������е�DEBUG����");
    XOS_CliExtWriteStrLine(pItCliEnv, "            Ҳ�����ò�ͬ���͵�ֵ�ۼ������������������");
    XOS_CliExtWriteStrLine(pItCliEnv, "            ��ͬ���͵�ֵ���������������");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  sub  ---- �ò���Ϊɾ��ͨ�õ�DEBUG����");
    XOS_CliExtWriteStrLine(pItCliEnv, "            �ò����������������������ɾ�����е�DEBUG����");
    XOS_CliExtWriteStrLine(pItCliEnv, "            Ҳ�����ò�ͬ���͵�ֵ�ۼ�����ɾ�����������");
    XOS_CliExtWriteStrLine(pItCliEnv, "            ��ͬ���͵�ֵ���������������");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "----------------------------------------------------------");
    XOS_CliExtWriteStrLine(pItCliEnv, "  ͨ��DEBUG����                  ��д                ֵ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  system service interface        SI                  1");
    XOS_CliExtWriteStrLine(pItCliEnv, "  layer management interface      MI                  2");
    XOS_CliExtWriteStrLine(pItCliEnv, "  upper interface                 UI                  4");
    XOS_CliExtWriteStrLine(pItCliEnv, "  lower interface                 LI                  8");
    XOS_CliExtWriteStrLine(pItCliEnv, "  peer interface                  PI                  16");
    XOS_CliExtWriteStrLine(pItCliEnv, "  PSF's protocol layer interface  PLI                 32");
    XOS_CliExtWriteStrLine(pItCliEnv, "----------------------------------------------------------");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  help ---- �ò���Ϊ��ȡ�������ڲ��������?|help");
    XOS_CliExtWriteStrLine(pItCliEnv, "            ���ܻ�ȡ�ò����ľ�����Ϣ");
}

PRIVATE VOID itDbgControlSetMaskM3uaHelp(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UAЭ��ctrl mask m3ua ����֧�������б�:");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  add  ---- �ò���Ϊ����M3UA��DEBUG����");
    XOS_CliExtWriteStrLine(pItCliEnv, "            �ò�����������������������������е�DEBUG����");
    XOS_CliExtWriteStrLine(pItCliEnv, "            Ҳ�����ò�ͬ���͵�ֵ�ۼ������������������");
    XOS_CliExtWriteStrLine(pItCliEnv, "            ��ͬ���͵�ֵ���������������");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  sub  ---- �ò���Ϊɾ��M3UA��DEBUG����");
    XOS_CliExtWriteStrLine(pItCliEnv, "            �ò����������������������ɾ�����е�DEBUG����");
    XOS_CliExtWriteStrLine(pItCliEnv, "            Ҳ�����ò�ͬ���͵�ֵ�ۼ�����ɾ�����������");
    XOS_CliExtWriteStrLine(pItCliEnv, "            ��ͬ���͵�ֵ���������������");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "----------------------------------------------------------");
    XOS_CliExtWriteStrLine(pItCliEnv, "  M3UA DEBUG����                  ��д                ֵ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  Addr . Transl                   AT                 256");
    XOS_CliExtWriteStrLine(pItCliEnv, "  MMH                             MMH                512");
    XOS_CliExtWriteStrLine(pItCliEnv, "  DATA request                    DATA               1024");
    XOS_CliExtWriteStrLine(pItCliEnv, "  Dummy Stack Manager             DMSM               2048");
    XOS_CliExtWriteStrLine(pItCliEnv, "  Message Trace                   MTRA               4096");
    XOS_CliExtWriteStrLine(pItCliEnv, "----------------------------------------------------------");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  help ---- �ò���Ϊ��ȡ�������ڲ��������?|help");
    XOS_CliExtWriteStrLine(pItCliEnv, "            ���ܻ�ȡ�ò����ľ�����Ϣ");
}
 
PRIVATE VOID itDbgControlSendData(VOID)
{
    
    XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Error");
    XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_THIRDVARTYPE);
    RETVOID;
}

PRIVATE VOID itDbgControlAutoStart(VOID)
{
    S32 ret = 0;

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_STATUS, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlAutoStartStatus();
        RETVOID;
    }
    
    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_AUTOSTARTOPEN, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlAutoStartOpen();
        RETVOID;
    }
#if 0
    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_AUTOSTARTCLOSE, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlAutoStartClose();
        RETVOID;
    }
#endif
    ret = ( ( strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP, ItVarNameMaxLength) ) && (strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP_OTHER, ItVarNameMaxLength)) );
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlAutoStartHelp();
        RETVOID;
    }

    XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Error");
    XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_THIRDVARTYPE);
    RETVOID;
}

PRIVATE VOID itDbgControlSetMask(VOID)
{
    S32 ret = 0;

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_STATUS, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlSetMaskStatus();
        RETVOID;
    }
    
    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_SETMASKCOMM, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlSetMaskComm();
        RETVOID;
    }
    
    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_SETMASKM3UA, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlSetMaskM3ua();
        RETVOID;
    }

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_SETMASKADD, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlSetMaskAdd();
        RETVOID;
    }
    
    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR3_SETMASKSUB, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlSetMaskSub();
        RETVOID;
    }
    
    ret = ( ( strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP, ItVarNameMaxLength) ) && (strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP_OTHER, ItVarNameMaxLength)) );
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlSetMaskHelp();
        RETVOID;
    }

    XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Error");
    XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_THIRDVARTYPE);
    RETVOID;
}

PRIVATE VOID itDbgControlSetMaskStatus(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "----------------------------------------------------------");
    XOS_CliExtWriteStrLine(pItCliEnv, "  M3UA DEBUG����                  ��д                ״̬");
    XOS_CliExtPrintf(pItCliEnv, "  system service interface        SI                   ");
    if ( DBGMASK_SI & itGlobalCb.itInit.dbgMask )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "O");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "X");
    }
    
    XOS_CliExtPrintf(pItCliEnv, "  layer management interface      MI                   ");
    if ( DBGMASK_MI & itGlobalCb.itInit.dbgMask )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "O");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "X");
    }
    
    XOS_CliExtPrintf(pItCliEnv, "  upper interface                 UI                   ");
    if ( DBGMASK_UI & itGlobalCb.itInit.dbgMask )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "O");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "X");
    }
    
    XOS_CliExtPrintf(pItCliEnv, "  lower interface                 LI                   ");
    if ( DBGMASK_LI & itGlobalCb.itInit.dbgMask )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "O");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "X");
    }
    
    XOS_CliExtPrintf(pItCliEnv, "  peer interface                  PI                   ");
    if ( DBGMASK_PI & itGlobalCb.itInit.dbgMask )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "O");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "X");
    }
    
    XOS_CliExtPrintf(pItCliEnv, "  PSF's protocol layer interface  PLI                  ");
    if ( DBGMASK_PLI & itGlobalCb.itInit.dbgMask )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "O");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "X");
    }
    
    XOS_CliExtPrintf(pItCliEnv, "  Addr . Transl                   AT                   ");
    if ( IT_DBGMASK_AT & itGlobalCb.itInit.dbgMask )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "O");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "X");
    }
    
    XOS_CliExtPrintf(pItCliEnv, "  MMH                             MMH                  ");
    if ( IT_DBGMASK_MMH & itGlobalCb.itInit.dbgMask )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "O");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "X");
    }
    
    XOS_CliExtPrintf(pItCliEnv, "  DATA request                    DATA                 ");
    if ( IT_DBGMASK_DATA & itGlobalCb.itInit.dbgMask )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "O");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "X");
    }
    
    XOS_CliExtPrintf(pItCliEnv, "  Dummy Stack Manager             DMSM                 ");
    if ( IT_DBGMASK_DUMMYSM & itGlobalCb.itInit.dbgMask )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "O");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "X");
    }

    XOS_CliExtPrintf(pItCliEnv, "  Message Trace                   MTRC                 ");
    if ( IT_DBGMASK_MSGTRACE & itGlobalCb.itInit.dbgMask )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "O");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "X");
    }
    
    XOS_CliExtWriteStrLine(pItCliEnv, "----------------------------------------------------------");
}

PRIVATE VOID itDbgControlSetMaskComm(VOID)
{
    S32 ret = 0;

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR4_SETMASKADD, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlSetMaskCommAdd();
        RETVOID;
    }
    
    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR4_SETMASKSUB, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlSetMaskCommSub();
        RETVOID;
    }

    ret = ( ( strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP, ItVarNameMaxLength) ) && (strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP_OTHER, ItVarNameMaxLength)) );
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlSetMaskCommHelp();
        RETVOID;
    }

    XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Error");
    XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_FOURTHVARTYPE);
    RETVOID;
}

PRIVATE VOID itDbgControlSetMaskM3ua(VOID)
{
    S32 ret = 0;

    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR4_SETMASKADD, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlSetMaskM3uaAdd();
        RETVOID;
    }
    
    ret = strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR4_SETMASKSUB, ItVarNameMaxLength);
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlSetMaskM3uaSub();
        RETVOID;
    }

    ret = ( ( strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP, ItVarNameMaxLength) ) && (strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP_OTHER, ItVarNameMaxLength)) );
    if ( 0 == ret )
    {
        ItDbgNowStep++;
        itDbgControlSetMaskM3uaHelp();
        RETVOID;
    }

    XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Error");
    XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_FOURTHVARTYPE);
    RETVOID;
}

PRIVATE S32 CheckMaskValue ( S8* chMaskValue )
{
    U32 uiLength = ItVarNameMaxLength;
    U32 uiLoop = 0;
    S8   chTemp = 0;
    S32 iRet = 0;
    
    uiLength = strlen(chMaskValue);
    for ( uiLoop=0; uiLoop<uiLength; uiLoop++ )
    {
        chTemp = chMaskValue[uiLoop];
        iRet = isdigit(chTemp);
        if ( 0 == iRet )
        {
            RETVALUE(0);
        }
    }

    RETVALUE(1);
}

PRIVATE VOID itDbgControlSetMaskCommAdd(VOID)
{
    U32 uiMaskValue = 0;
    S32 iRet = 0;
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            uiMaskValue = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Error");
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_MASKERROR);
            RETVOID;
        }
        
        if ( ( 63 < uiMaskValue ) || ( 0 == uiMaskValue ) )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Error");
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_MASKERROR);
            RETVOID;
        }
    }
    else
    {
        uiMaskValue = IT_MASK_COMM_ALL;
    }
    
    itGlobalCb.itInit.dbgMask |= uiMaskValue;
    
    XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Succeed");
    RETVOID;
}

PRIVATE VOID itDbgControlSetMaskCommSub(VOID)
{
    U32 uiMaskValue = 0;
    S32 iRet = 0;
        
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            uiMaskValue = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Error");
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_MASKERROR);
            RETVOID;
        }
        
        if ( ( 63 < uiMaskValue ) || ( 0 == uiMaskValue ) )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Error");
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_MASKERROR);
            RETVOID;
        }
    }
    else
    {
        uiMaskValue = IT_MASK_COMM_ALL;
    }
    
    itGlobalCb.itInit.dbgMask &= ~(uiMaskValue);
    
    XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Succeed");
    RETVOID;
}

PRIVATE VOID itDbgControlSetMaskM3uaAdd(VOID)
{
    U32 uiMaskValue = 0;
    U32 uiMaskTemp = 0;
    S32 iRet = 0;
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            uiMaskValue = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Error");
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_MASKERROR);
            RETVOID;
        }

        uiMaskTemp = uiMaskValue;
        uiMaskTemp &= IT_MASK_M3UA_CHECK1;
        
        if (  uiMaskTemp && IT_MASK_M3UA_CHECK1 )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Error");
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_MASKERROR);
            RETVOID;
        }

        uiMaskTemp = uiMaskValue;
        uiMaskTemp &= IT_MASK_M3UA_CHECK2;
        
        if (  !(uiMaskTemp &&  IT_MASK_M3UA_CHECK2) )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Error");
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_MASKERROR);
            RETVOID;
        }
    }
    else
    {
        uiMaskValue = IT_MASK_M3UA_ALL;
    }
    
    itGlobalCb.itInit.dbgMask |= uiMaskValue;
    
    XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Succeed");
    RETVOID;
}

PRIVATE VOID itDbgControlSetMaskM3uaSub(VOID)
{
    U32 uiMaskValue = 0;
    U32 uiMaskTemp = 0;
    S32 iRet = 0;

    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            uiMaskValue = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Error");
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_MASKERROR);
            RETVOID;
        }

        uiMaskTemp = uiMaskValue;
        uiMaskTemp &= IT_MASK_M3UA_CHECK1;
        
        if (  uiMaskTemp && IT_MASK_M3UA_CHECK1 )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Error");
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_MASKERROR);
            RETVOID;
        }

        uiMaskTemp = uiMaskValue;
        uiMaskTemp &= IT_MASK_M3UA_CHECK2;
        
        if (  !(uiMaskTemp &&  IT_MASK_M3UA_CHECK2) )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Error");
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_MASKERROR);
            RETVOID;
        }
    }
    else
    {
        uiMaskValue = IT_MASK_M3UA_ALL;
    }
    
    itGlobalCb.itInit.dbgMask &= ~(uiMaskValue);
    XOS_CliExtWriteStrLine(pItCliEnv, "Command Operation Succeed");
    RETVOID;
}

PRIVATE VOID itDbgControlAutoStartStatus(VOID)
{
    U32 pspId;
    U32 i = 0;
    pspId = itGlobalCb.genCfg.maxNmbPsp+1;
    
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        pspId = atoi(achItDbgVar[ItDbgNowStep]);
        if (  itGlobalCb.genCfg.maxNmbPsp < pspId )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDMAX);
            RETVOID;
        }

        if ( 0 == pspId )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDZERO);
            RETVOID;
        }
        
        if ( (ItPspCb*)NULLP == itGlobalCb.psp[pspId] )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDNULLP);
            RETVOID;
        }
#ifdef ITASP
        if ( TRUE == itGlobalCb.psp[pspId]->pspCfg.autostartstatus )
        {
            XOS_CliExtPrintf(pItCliEnv, "  PSP %d Auto Start Status: TRUE\r\n", pspId);
        }
        else
        {
            XOS_CliExtPrintf(pItCliEnv, "  PSP %d Auto Start Status: FALSE\r\n", pspId);
        }
#endif
        RETVOID;
    }

    for ( i=1; i <  itGlobalCb.genCfg.maxNmbPsp; i++ )
    {
        if ( (ItPspCb*)NULLP == itGlobalCb.psp[i] )
        {
            continue;
        }

#ifdef ITASP
        if ( TRUE == itGlobalCb.psp[i]->pspCfg.autostartstatus )
        {
            XOS_CliExtPrintf(pItCliEnv, "  PSP %d Auto Start Status: TRUE\r\n", i);
        }
        else
        {
            XOS_CliExtPrintf(pItCliEnv, "  PSP %d Auto Start Status: FALSE\r\n", i);
        }
#endif
    }
    
    RETVOID;
}

PRIVATE VOID itDbgControlAutoStartOpen(VOID)
{
    U32 pspId;
    U32 i = 0;
    pspId = itGlobalCb.genCfg.maxNmbPsp+1;
    
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        pspId = atoi(achItDbgVar[ItDbgNowStep]);
        if (  itGlobalCb.genCfg.maxNmbPsp < pspId )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDMAX);
            RETVOID;
        }

        if ( 0 == pspId )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDZERO);
            RETVOID;
        }
        
        if ( (ItPspCb*)NULLP == itGlobalCb.psp[pspId] )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDNULLP);
            RETVOID;
        }
#ifdef ITASP
        if ( FALSE == itGlobalCb.psp[pspId]->pspCfg.autostartstatus )
        {
            itSgReconnect(pspId);
            XOS_CliExtPrintf(pItCliEnv, "  PSP %d Auto Start: Open\r\n", pspId);
        }
        else
        {
            XOS_CliExtPrintf(pItCliEnv, "  PSP %d Auto Starts is Opening\r\n", pspId);
        }
#endif
        RETVOID;
    }

    for ( i=1; i <  itGlobalCb.genCfg.maxNmbPsp; i++ )
    {
        if ( (ItPspCb*)NULLP == itGlobalCb.psp[i] )
        {
            continue;
        }

#ifdef ITASP
        if ( FALSE == itGlobalCb.psp[i]->pspCfg.autostartstatus )
        {
            StartWork(itGlobalCb.sctSap[0]->sctCfg.suId);
            XOS_CliExtPrintf(pItCliEnv, "  PSP %d Auto Start: Open\r\n", i);
        }
        else
        {
            XOS_CliExtPrintf(pItCliEnv, "  PSP %d Auto Starts is Opening\r\n", i);
        }
#endif
    }
    
    RETVOID;
}

PRIVATE VOID itDbgControlAutoStartClose(VOID)
{
    U32 pspId;
    U32 i = 0;
    pspId = itGlobalCb.genCfg.maxNmbPsp+1;
    
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        pspId = atoi(achItDbgVar[ItDbgNowStep]);
        if (  itGlobalCb.genCfg.maxNmbPsp < pspId )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDMAX);
            RETVOID;
        }

        if ( 0 == pspId )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDZERO);
            RETVOID;
        }
        
        if ( (ItPspCb*)NULLP == itGlobalCb.psp[pspId] )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDNULLP);
            RETVOID;
        }
#ifdef ITASP
        if ( TRUE == itGlobalCb.psp[pspId]->pspCfg.autostartstatus )
        {
            itTcStopTimer(&( itGlobalCb.psp[pspId]->assoc[0].tmrReconnect));
            itGlobalCb.psp[pspId]->pspCfg.autostartstatus = FALSE;
            XOS_CliExtPrintf(pItCliEnv, "  PSP %d Auto Start: Close\r\n", pspId);
        }
        else
        {
            XOS_CliExtPrintf(pItCliEnv, "  PSP %d Auto Starts is Closed\r\n", pspId);
        }
#endif
        RETVOID;
    }

    for ( i=1; i <  itGlobalCb.genCfg.maxNmbPsp; i++ )
    {
        if ( (ItPspCb*)NULLP == itGlobalCb.psp[i] )
        {
            continue;
        }

#ifdef ITASP
        if ( TRUE == itGlobalCb.psp[i]->pspCfg.autostartstatus )
        {
            itTcStopTimer(&( itGlobalCb.psp[i]->assoc[0].tmrReconnect));
            itGlobalCb.psp[i]->pspCfg.autostartstatus = FALSE;
            XOS_CliExtPrintf(pItCliEnv, "  PSP %d Auto Start: Close\r\n", i);
        }
        else
        {
            XOS_CliExtPrintf(pItCliEnv, "  PSP %d Auto Starts is Closed\r\n", i);
        }
#endif
    }
    
    RETVOID;
}

/***************************************************************************
* Set Functions
***************************************************************************/
PRIVATE VOID itDbgSetHelp(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UAЭ��set ����֧�������б�:");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  -o   ---- �ò���Ϊ����M3UA��TRACE�ļ���");
    XOS_CliExtWriteStrLine(pItCliEnv, "            �����ļ�������ܽ�TRACE��¼���ļ���");
    XOS_CliExtWriteStrLine(pItCliEnv, "            ���ļ���������ļ����ͣ�����m3uatrac.txt");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  help ---- �ò���Ϊ��ȡ�������ڲ��������?|help");
    XOS_CliExtWriteStrLine(pItCliEnv, "            ���ܻ�ȡ�ò����ľ�����Ϣ");

}

PRIVATE VOID itDbgSetTraceName(XS32 siArgc, XCHAR **ppArgv)
{
    S32 ret=0;
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        ret = ( ( strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP, ItVarNameMaxLength) ) && (strncmp(achItDbgVar[ItDbgNowStep], IT_STR_VAR_HELP_OTHER, ItVarNameMaxLength)) );
        {
            ItDbgNowStep++;
            itDbgSetTraceNameHelp();
            RETVOID;
        }
    }
#ifdef WIN32
    nsGetOpts(siArgc, ppArgv);
#else
    XOS_CliExtWriteStrLine(pItCliEnv, "������WINDOWSƽ̨�� ��֧�ָù���");
#endif
}

PRIVATE VOID itDbgSetTraceNameHelp(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UAЭ��set -o ����֧�ֲ����б�:");
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    XOS_CliExtWriteStrLine(pItCliEnv, "  ����1 --- TRACE�ļ��ļ���");
    XOS_CliExtWriteStrLine(pItCliEnv, "            �����ļ�������ܽ�TRACE��¼���ļ���");
    XOS_CliExtWriteStrLine(pItCliEnv, "            ���ļ���������ļ����ͣ�����m3uatrac.txt");
    XOS_CliExtWriteStrLine(pItCliEnv, " ע��: ��ֻ֧��WINDOWSƽ̨");
    RETVOID;
}
/***************************************************************************
* Inside Functions
***************************************************************************/

/********************   CBK     **********************************************/
PRIVATE VOID itDbgShowCBKgen(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UA Global Control Block:");
    itDbgPrintfGenCbk(1, &itGlobalCb);                
    RETVOID;
}


PRIVATE VOID itDbgShowCBKnwk(VOID)
{
    U32 networkID;
    S32 iRet = 0;
    networkID = itGlobalCb.genCfg.maxNmbNwk+1;
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            networkID = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NWKIDNULLP);
            RETVOID;
        }
        
        if (  itGlobalCb.genCfg.maxNmbNwk < networkID )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NWKIDMAX);
            RETVOID;
        }

        if ( (ItNwkCb*)NULLP == itGlobalCb.nwk[networkID] )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NWKIDNULLP);
            RETVOID;
        }
    }

    itDbgPrintfNwkCbk(networkID, 0);
    
    RETVOID;
}

PRIVATE VOID itDbgShowCBKnsp(VOID)
{
    U32 NsapID;
    S32 iRet = 0;
    NsapID = itGlobalCb.genCfg.maxNmbNSap+1;
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            NsapID = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NSAPIDNULLP);
            RETVOID;
        }
        
        if (  itGlobalCb.genCfg.maxNmbNSap < NsapID )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NSAPIDMAX);
            RETVOID;
        }

        if ( (ItNSapCb*)NULLP == itGlobalCb.nSap[NsapID] )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NSAPIDNULLP);
            RETVOID;
        }
    }

    itDbgPrintfNsapCbk(NsapID, 0);
    
    RETVOID;
}

PRIVATE VOID itDbgShowCBKcsp(VOID)
{
    U32 sctsapID;
    S32 iRet = 0;
    sctsapID = itGlobalCb.genCfg.maxNmbSctSap+1;
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            sctsapID = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_SCTSAPIDNULLP);
            RETVOID;
        }
        
        if (  itGlobalCb.genCfg.maxNmbSctSap < sctsapID )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_SCTSAPIDMAX);
            RETVOID;
        }

        if ( (ItSctSapCb*)NULLP == itGlobalCb.sctSap[sctsapID] )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_SCTSAPIDNULLP);
            RETVOID;
        }
    }

    itDbgPrintfSctsapCbk(sctsapID, 0);
    RETVOID;
}

PRIVATE VOID itDbgShowCBKpse(VOID)
{
    U32 PsId;
    S32 iRet = 0;
    PsId = itGlobalCb.genCfg.maxNmbPs+1;

    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            PsId = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSIDNULLP);
            RETVOID;
        }
        
        if (  itGlobalCb.genCfg.maxNmbPs < PsId )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSIDMAX);
            RETVOID;
        }

        if ( (ItPsCb*)NULLP == itPsmFindPs(PsId) )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSIDNULLP);
            RETVOID;
        }
    }

    itDbgPrintfPsCbk(PsId, 0);
    RETVOID;
}

PRIVATE VOID itDbgShowCBKass(VOID)
{
    U32 assID;
    S32 iRet = 0;
    assID = itGlobalCb.maxNmbAssoc+1;

    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            assID = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_ASSIDNULLP);
            RETVOID;
        }
        
        if (  itGlobalCb.maxNmbAssoc < assID )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_ASSIDMAX);
            RETVOID;
        }

        if ( (ItAssocCb*)NULLP == itGlobalCb.assoc[assID] )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_ASSIDNULLP);
            RETVOID;
        }
    }

    itDbgPrintfAssCbk(assID, 0);
    
    RETVOID;
}
    
PRIVATE VOID itDbgShowCBKpsp(VOID)
{
    U32 pspID;
    S32 iRet = 0;
    pspID = itGlobalCb.genCfg.maxNmbPsp+1;
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            pspID = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDNULLP);
            RETVOID;
        }
        
        if (  itGlobalCb.genCfg.maxNmbPsp < pspID )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDMAX);
            RETVOID;
        }

        if ( (ItPspCb*)NULLP == itGlobalCb.psp[pspID] )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDNULLP);
            RETVOID;
        }
    }

    itDbgPrintfPspCbk(pspID, 0);
    
    RETVOID;
}

PRIVATE VOID itDbgShowCBKdpc(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "Hash list of DPCs:");
    itDbgPrintfDpcCbk(1, &(itGlobalCb.addrTrn.dpcList));
    RETVOID;
}

PRIVATE VOID itDbgShowCBKrte(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "Linked list of routes:");
    itDbgPrintfRouteCbk(1, &(itGlobalCb.addrTrn.rtList));
    RETVOID;
}

/********************   GEN     **********************************************/
PRIVATE VOID itDbgPrintfOneMemoryId(U32 pfLevel, MemoryId* MemId)
{
    U32 NowLevel;
    MemoryId* pMemId;
    
    pMemId = (MemoryId*)NULLP;

    if ( (MemoryId*)NULLP == MemId )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_MEMID);
        RETVOID;
    }
    else
    {
        pMemId = MemId;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Region: %d\r\n", pMemId->region);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Pool  : %d\r\n", pMemId->pool);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Spare : %d\r\n", pMemId->spare);

    RETVOID;
}

PRIVATE VOID itDbgPrintfOneDateTime(U32 pfLevel, DateTime* DTime)
{
    U32 NowLevel;
    DateTime* pDateTime;
    
    pDateTime = (DateTime*)NULLP;

    if ( (DateTime*)NULLP == DTime )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_DATATIME);
        RETVOID;
    }
    else
    {
        pDateTime = DTime;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Date: %d-%d-%d\r\n", pDateTime->year+1900,pDateTime->month,pDateTime->day);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Time: %d:%d:%d:%d\r\n", pDateTime->hour,pDateTime->min,pDateTime->sec,pDateTime->tenths);
    
    RETVOID;
}

PRIVATE VOID itDbgPrintfTaskInit(U32 pfLevel, TskInit* TskInitial)
{
    U32 NowLevel;
    TskInit* pTskInit;
    
    pTskInit = (TskInit*)NULLP;

    if ( (TskInit*)NULLP == TskInitial )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_TSKINIT);
        RETVOID;
    }
    else
    {
        pTskInit = TskInitial;
        NowLevel = pfLevel;
    }

    
#ifdef SS_MULTIPLE_PROCS
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Processor         : %d\r\n", pTskInit->proc);
#endif /* SS_MULTIPLE_PROCS */
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Entity            : %d\r\n", pTskInit->ent);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Instance          : %d\r\n", pTskInit->inst);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Static Region     : %d\r\n", pTskInit->region);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Static Pool       : %d\r\n", pTskInit->pool);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Reason            : %d\r\n", pTskInit->reason);
    
    itCliExtLevel(NowLevel);
    if ( TRUE == pTskInit->cfgDone )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Configuration done: TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Configuration done: FALSE");
    }

    itCliExtLevel(NowLevel);
    if ( TRUE == pTskInit->acnt )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Accounting        : TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Accounting        : FALSE");
    }

    itCliExtLevel(NowLevel);
    if ( TRUE == pTskInit->usta)
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Unsolicited status: TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Unsolicited status: FALSE");
    }

    itCliExtLevel(NowLevel);
    if ( TRUE == pTskInit->trc)
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Trace             : TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Trace             : FALSE");
    }

#ifdef DEBUGP
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Debug mask        : %d\r\n", pTskInit->dbgMask);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Print buffer      : %s\r\n", pTskInit->prntBuf);
#endif
    RETVOID;
}
/********************   CFG     **********************************************/
PRIVATE VOID itDbgShowCFGgen(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UA General Configuration:");
    itDbgPrintfGenCfg( 1, &(itGlobalCb.genCfg) );
    RETVOID;
}

PRIVATE VOID itDbgShowCFGnwk(VOID)
{
    U32 i = 0;
    U32 networkID;
    S32 iRet = 0;
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            networkID = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NWKIDNULLP);
            RETVOID;
        }
        
        if (  itGlobalCb.genCfg.maxNmbNwk < networkID )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NWKIDMAX);
            RETVOID;
        }

        if ( (ItNwkCb*)NULLP == itGlobalCb.nwk[networkID] )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NWKIDNULLP);
            RETVOID;
        }
        XOS_CliExtPrintf(pItCliEnv, "Network Configuration ID : %d\r\n", networkID);
        itDbgPrintfOneNwkCfg(1, &(itGlobalCb.nwk[networkID]->nwkCfg) );
        RETVOID;
    }
    else
    {
        /*û�к�����������Ҫ����ȫ����ӡ*/
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStr(pItCliEnv, "Network Configuration ID:");
#endif
        for ( i = 0; i < itGlobalCb.genCfg.maxNmbNwk; i++ )
        {
            if ( (ItNwkCb*)NULLP == itGlobalCb.nwk[i] )
            {
                continue;
            }
#ifdef IT_DBG_PRINTF_EVERY
            XOS_CliExtPrintf(pItCliEnv, "Network Configuration ID: %d\r\n", i);
            itDbgPrintfOneNwkCfg(1, &(itGlobalCb.nwk[i]->nwkCfg) );
#else
            XOS_CliExtPrintf(pItCliEnv, "  %d", i);
#endif
        }
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
#endif
    }
    
    RETVOID;
}

PRIVATE VOID itDbgShowCFGnsp(VOID)
{
    U32 i = 0;
    S32 nsapID;
    S32 iRet = 0;
    
    nsapID = itGlobalCb.genCfg.maxNmbNSap+1;
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
         iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            nsapID = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NSAPIDNULLP);
            RETVOID;
        }
        
        if (  itGlobalCb.genCfg.maxNmbNSap < nsapID )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NSAPIDMAX);
            RETVOID;
        }

        if ( (ItNSapCb*)NULLP == itGlobalCb.nSap[nsapID] )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NSAPIDNULLP);
            RETVOID;
        }
        XOS_CliExtPrintf(pItCliEnv, "Upper SAP Configuration ID: %d\r\n", nsapID);
        itDbgPrintfOneNsapCfg(1, &(itGlobalCb.nSap[nsapID]->sntCfg) );
        RETVOID;
    }
    else
    {
        /*û�к�����������Ҫ����ȫ����ӡ*/
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStr(pItCliEnv, "Upper SAP Configuration  ID:");
#endif
        for ( i = 0; i < itGlobalCb.genCfg.maxNmbNSap; i++ )
        {
            if ( (ItNSapCb*)NULLP == itGlobalCb.nSap[i] )
            {
                continue;
            }
#ifdef IT_DBG_PRINTF_EVERY
            XOS_CliExtPrintf(pItCliEnv, "Upper SAP Configuration ID: %d\r\n", i);
            itDbgPrintfOneNsapCfg(1, &(itGlobalCb.nSap[i]->sntCfg) );
#else
            XOS_CliExtPrintf(pItCliEnv, "  %d", i);
#endif
        }
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
#endif
    }
    
    RETVOID;
}

PRIVATE VOID itDbgShowCFGcsp(VOID)
{
    U32 i = 0;
    S32 sctsapID;
    S32 iRet = 0;
    sctsapID = itGlobalCb.genCfg.maxNmbSctSap+1;
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            sctsapID = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_SCTSAPIDNULLP);
            RETVOID;
        }
        
        if (  itGlobalCb.genCfg.maxNmbSctSap < sctsapID )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_SCTSAPIDMAX);
            RETVOID;
        }

        if ( (ItSctSapCb*)NULLP == itGlobalCb.sctSap[sctsapID] )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_SCTSAPIDNULLP);
            RETVOID;
        }

        XOS_CliExtPrintf(pItCliEnv, "Lower SAP Configuration ID: %d\r\n", sctsapID);
        itDbgPrintfOneSctsapCfg(1, &(itGlobalCb.sctSap[sctsapID]->sctCfg) );
        RETVOID;
    }
    else
    {
        /*û�к�����������Ҫ����ȫ����ӡ*/
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStr(pItCliEnv, "Lower SAP Configuration ID:");
#endif
        for ( i = 0; i < itGlobalCb.genCfg.maxNmbSctSap; i++ )
        {
            if ( (ItSctSapCb*)NULLP == itGlobalCb.sctSap[i] )
            {
                continue;
            }
#ifdef IT_DBG_PRINTF_EVERY
            XOS_CliExtPrintf(pItCliEnv, "Lower SAP Configuration ID: %d\r\n", i);
            itDbgPrintfOneSctsapCfg(1, &(itGlobalCb.sctSap[i]->sctCfg) );
#else
            XOS_CliExtPrintf(pItCliEnv, "  %d", i);
#endif
        }
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
#endif
    }
    
    RETVOID;
}

PRIVATE VOID itDbgShowCFGpse(VOID)
{
    U32 i = 0;
    S32 psID;
    S32 iRet = 0;
    ItPsCb* pPsCb = (ItPsCb*)NULLP;
    
    psID = itGlobalCb.genCfg.maxNmbPs+1;
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            psID = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSIDNULLP);
            RETVOID;
        }
        
        if (  itGlobalCb.genCfg.maxNmbPs < psID )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSIDMAX);
            RETVOID;
        }
        XOS_CliExtPrintf(pItCliEnv, "Peer Server Configuration ID: %d\r\n", psID);
        pPsCb  = itPsmFindPs(psID);
        if ( (ItPsCb*)NULLP == pPsCb )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSIDNULLP);
            RETVOID;
        }
        itDbgPrintfOnePsCfg( 1, &(pPsCb->psCfg));
        RETVOID;
    }
    else
    {
        /*û�к�����������Ҫ����ȫ����ӡ*/
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStr(pItCliEnv, "Peer Server Configuration ID:");
#endif
        for ( i = 0; i < itGlobalCb.genCfg.maxNmbPs; i++ )
        {
            pPsCb  = itPsmFindPs(i);
            if ( (ItPsCb*)NULLP != pPsCb )
            {
#ifdef IT_DBG_PRINTF_EVERY
                XOS_CliExtPrintf(pItCliEnv, "Peer Server Configuration ID: %d\r\n", i);
                itDbgPrintfOnePsCfg( 1, &(pPsCb->psCfg));
#else
                XOS_CliExtPrintf(pItCliEnv, "  %d", i);
#endif            
            }
        }
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
#endif
    }
    
    RETVOID;
}

PRIVATE VOID itDbgShowCFGpsp(VOID)
{
    U32 i = 0;
    U32 pspID;
    S32 iRet = 0;
    pspID = itGlobalCb.genCfg.maxNmbPsp+1;
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            pspID = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDNULLP);
            RETVOID;
        }
        
        if (  itGlobalCb.genCfg.maxNmbPsp < pspID )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDMAX);
            RETVOID;
        }

        if ( ((ItPspCb*)NULLP == itGlobalCb.psp[pspID] ) && (0 == pspID)  )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDNULLP);
            RETVOID;
        }

        XOS_CliExtPrintf(pItCliEnv, "PSP Configuration ID: %d\r\n", pspID);
        itDbgPrintfOnePspCfg( 1, &(itGlobalCb.psp[pspID]->pspCfg) );
        RETVOID;
    }
    else
    {
        /*û�к�����������Ҫ����ȫ����ӡ*/
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStr(pItCliEnv, "PSP Configuration ID:");
#endif
        for ( i = 1; i < itGlobalCb.genCfg.maxNmbPsp; i++ )
        {
            if ( (ItPspCb*)NULLP == itGlobalCb.psp[i] )
            {
                continue;
            }
#ifdef IT_DBG_PRINTF_EVERY
            XOS_CliExtPrintf(pItCliEnv, "PSP Configuration ID: %d\r\n", i);
            itDbgPrintfOnePspCfg( 1, &(itGlobalCb.psp[i]->pspCfg) );
#else
            XOS_CliExtPrintf(pItCliEnv, "  %d", i);
#endif
        }
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
#endif
    }
    
    RETVOID;
}

/********************   STS     **********************************************/
PRIVATE VOID itDbgShowSTSgen(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "M3ua General Statistics:");
    itDbgPrintfGenSts(1, &(itGlobalCb.genSts) );
    RETVOID;
}

PRIVATE VOID itDbgShowSTSnsp(VOID)
{
    U32 i = 0;
    S32 nsapID;
    S32 iRet = 0;
    
    nsapID = itGlobalCb.genCfg.maxNmbNSap+1;
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            nsapID = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NSAPIDNULLP);
            RETVOID;
        }
        
        if (  itGlobalCb.genCfg.maxNmbNSap < nsapID )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NSAPIDMAX);
            RETVOID;
        }

        if ( (ItNSapCb*)NULLP == itGlobalCb.nSap[nsapID] )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NSAPIDNULLP);
            RETVOID;
        }
        XOS_CliExtPrintf(pItCliEnv, "Upper SAP Statistics ID: %d\r\n", nsapID);
        itDbgPrintfOneNsapSts(1, &(itGlobalCb.nSap[nsapID]->sntSts) );
        RETVOID;
    }
    else
    {
        /*û�к�����������Ҫ����ȫ����ӡ*/
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStr(pItCliEnv, "Upper SAP Statistics ID:");
#endif
        for ( i = 0; i < itGlobalCb.genCfg.maxNmbNSap; i++ )
        {
            if ( (ItNSapCb*)NULLP == itGlobalCb.nSap[i] )
            {
                continue;
            }
#ifdef IT_DBG_PRINTF_EVERY
            XOS_CliExtPrintf(pItCliEnv, "Upper SAP Statistics ID: %d\r\n", i);
            itDbgPrintfOneNsapSts(1, &(itGlobalCb.nSap[i]->sntSts) );
#else
            XOS_CliExtPrintf(pItCliEnv, "  %d", i);
#endif
        }
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
#endif
    }
    
    RETVOID;
}

PRIVATE VOID itDbgShowSTScsp(VOID)
{
    U32 i = 0;
    S32 sctsapID;
    S32 iRet = 0;
    
    sctsapID = itGlobalCb.genCfg.maxNmbSctSap+1;
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            sctsapID = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_SCTSAPIDNULLP);
            RETVOID;
        }
        
        if (  itGlobalCb.genCfg.maxNmbSctSap < sctsapID )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_SCTSAPIDMAX);
            RETVOID;
        }

        if ( (ItSctSapCb*)NULLP == itGlobalCb.sctSap[sctsapID] )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_SCTSAPIDNULLP);
            RETVOID;
        }

        XOS_CliExtPrintf(pItCliEnv, "Lower SAP Statistics ID: %d\r\n", sctsapID);
        itDbgPrintfOneSctsapSts(1, &(itGlobalCb.sctSap[sctsapID]->sctSts) );
        RETVOID;
    }
    else
    {
        /*û�к�����������Ҫ����ȫ����ӡ*/
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStr(pItCliEnv, "Lower SAP Statistics ID:");
#endif
        for ( i = 0; i < itGlobalCb.genCfg.maxNmbSctSap; i++ )
        {
            if ( (ItSctSapCb*)NULLP == itGlobalCb.sctSap[i] )
            {
                continue;
            }
#ifdef IT_DBG_PRINTF_EVERY
            XOS_CliExtPrintf(pItCliEnv, "Lower SAP Statistics ID: %d\r\n", i);
            itDbgPrintfOneSctsapSts(1, &(itGlobalCb.sctSap[i]->sctSts) );
#else
            XOS_CliExtPrintf(pItCliEnv, "  %d", i);
#endif
        }
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
#endif
    }
    
    RETVOID;
}

PRIVATE VOID itDbgShowSTSpsp(VOID)
{
    U32 i = 0;
    U32 pspID;
    S32 iRet = 0;
    
    pspID = itGlobalCb.genCfg.maxNmbPsp+1;
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            pspID = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDNULLP);
            RETVOID;
        }
        
        if (  itGlobalCb.genCfg.maxNmbPsp < pspID )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDMAX);
            RETVOID;
        }

        if ( ((ItPspCb*)NULLP == itGlobalCb.psp[pspID] ) && (0 == pspID))
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDNULLP);
            RETVOID;
        }

        XOS_CliExtPrintf(pItCliEnv, "PSP Statistics ID: %d\r\n", pspID);
        itDbgPrintfOnePspSts( 1, &(itGlobalCb.psp[pspID]->pspSts) );
        RETVOID;
    }
    else
    {
        /*û�к�����������Ҫ����ȫ����ӡ*/
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStr(pItCliEnv, "PSP Statistics ID:");
#endif
        for ( i = 1; i < itGlobalCb.genCfg.maxNmbPsp; i++ )
        {
            if ( (ItPspCb*)NULLP == itGlobalCb.psp[i] )
            {
                continue;
            }
#ifdef IT_DBG_PRINTF_EVERY
            XOS_CliExtPrintf(pItCliEnv, "PSP Statistics ID: %d\r\n", i);
            itDbgPrintfOnePspSts( 1, &(itGlobalCb.psp[i]->pspSts) );
#else
            XOS_CliExtPrintf(pItCliEnv, "  %d", i);
#endif
        }
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
#endif
    }
    
    RETVOID;
}

/********************   STA     **********************************************/
PRIVATE VOID itDbgShowSTAgen(VOID)
{
    XOS_CliExtWriteStrLine(pItCliEnv, "M3ua General Status:");
    itDbgPrintfGenSta(1, &(itGlobalCb.genSta) );
    RETVOID;
}

PRIVATE VOID itDbgShowSTAnsp(VOID)
{
    U32 i = 0;
    S32 nsapID;
    S32 iRet = 0;
    nsapID = itGlobalCb.genCfg.maxNmbNSap+1;
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            nsapID = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NSAPIDNULLP);
            RETVOID;
        }
        
        if (  itGlobalCb.genCfg.maxNmbNSap < nsapID )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NSAPIDMAX);
            RETVOID;
        }

        if ( (ItNSapCb*)NULLP == itGlobalCb.nSap[nsapID] )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NSAPIDNULLP);
            RETVOID;
        }
        XOS_CliExtPrintf(pItCliEnv, "Upper SAP Status ID: %d\r\n", nsapID);
        itDbgPrintfOneNsapSta(1, &(itGlobalCb.nSap[nsapID]->sntSta) );
        RETVOID;
    }
    else
    {
        /*û�к�����������Ҫ����ȫ����ӡ*/
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStr(pItCliEnv, "Upper SAP Status ID:");
#endif
        for ( i = 0; i < itGlobalCb.genCfg.maxNmbNSap; i++ )
        {
            if ( (ItNSapCb*)NULLP == itGlobalCb.nSap[i] )
            {
                continue;
            }
#ifdef IT_DBG_PRINTF_EVERY
            XOS_CliExtPrintf(pItCliEnv, "Upper SAP Status ID: %d\r\n", i);
            itDbgPrintfOneNsapSta(1, &(itGlobalCb.nSap[i]->sntSta) );
#else
            XOS_CliExtPrintf(pItCliEnv, "  %d", i);
#endif
        }
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
#endif
    }
    
    RETVOID;
}

PRIVATE VOID itDbgShowSTAcsp(VOID)
{
    U32 i = 0;
    S32 sctsapID;
    S32 iRet = 0;
    
    sctsapID = itGlobalCb.genCfg.maxNmbSctSap+1;
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            sctsapID = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_SCTSAPIDNULLP);
            RETVOID;
        }
        
        if (  itGlobalCb.genCfg.maxNmbSctSap < sctsapID )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_SCTSAPIDMAX);
            RETVOID;
        }

        if ( (ItSctSapCb*)NULLP == itGlobalCb.sctSap[sctsapID] )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_SCTSAPIDNULLP);
            RETVOID;
        }

        XOS_CliExtPrintf(pItCliEnv, "Lower SAP Status ID: %d\r\n", sctsapID);
        itDbgPrintfOneSctSapSta(1, &(itGlobalCb.sctSap[sctsapID]->sctSta) );
        RETVOID;
    }
    else
    {
        /*û�к�����������Ҫ����ȫ����ӡ*/
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStr(pItCliEnv, "Lower SAP Status ID:");
#endif
        for ( i = 0; i < itGlobalCb.genCfg.maxNmbSctSap; i++ )
        {
            if ( (ItSctSapCb*)NULLP == itGlobalCb.sctSap[i] )
            {
                continue;
            }
#ifdef IT_DBG_PRINTF_EVERY
            XOS_CliExtPrintf(pItCliEnv, "Lower SAP Status ID: %d\r\n", i);
            itDbgPrintfOneSctSapSta(1, &(itGlobalCb.sctSap[i]->sctSta) );
#else
            XOS_CliExtPrintf(pItCliEnv, "  %d", i);
#endif
        }
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
#endif
    }
    
    RETVOID;
}

PRIVATE VOID itDbgShowSTApse(VOID)
{
    U32 i = 0;
    U32 psID;
    S32 iRet = 0;
    ItPsCb* pPsCb = (ItPsCb*)NULLP;
    
    psID = itGlobalCb.genCfg.maxNmbPs+1;
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            psID = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSIDNULLP);
            RETVOID;
        }
        
        if (  itGlobalCb.genCfg.maxNmbPs < psID )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSIDMAX);
            RETVOID;
        }
        XOS_CliExtPrintf(pItCliEnv, "Peer Server Status ID: %d\r\n", psID);
        pPsCb  = itPsmFindPs(psID);
        if ( (ItPsCb*)NULLP == pPsCb )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSIDNULLP);
            RETVOID;
        }
        itDbgPrintfOnePsSta( 1, &(pPsCb->psSta));
        RETVOID;
    }
    else
    {
        /*û�к�����������Ҫ����ȫ����ӡ*/
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStr(pItCliEnv, "Peer Server Status ID:");
#endif
        for ( i = 0; i < itGlobalCb.genCfg.maxNmbPs; i++ )
        {
            pPsCb  = itPsmFindPs(i);
            if ( (ItPsCb*)NULLP != pPsCb )
            {
#ifdef IT_DBG_PRINTF_EVERY
                XOS_CliExtPrintf(pItCliEnv, "Peer Server Status ID: %d\r\n", i);
                itDbgPrintfOnePsSta( 1, &(pPsCb->psSta));
#else
                XOS_CliExtPrintf(pItCliEnv, "  %d", i);
#endif            
            }
        }
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
#endif
    }
    
    RETVOID;
}

PRIVATE VOID itDbgShowSTApsp(VOID)
{
    U32 i = 0;
    U32 pspID;
    S32 iRet = 0;
    pspID = itGlobalCb.genCfg.maxNmbPsp+1;
    
    if ( ItDbgStepNum > ItDbgNowStep )
    {
        /*˵�����в���*/
        iRet = CheckMaskValue ( (S8 *)(achItDbgVar[ItDbgNowStep])); 
        
        if ( iRet )
        {
            pspID = atoi(achItDbgVar[ItDbgNowStep]);
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDNULLP);
            RETVOID;
        }
        
        if (  itGlobalCb.genCfg.maxNmbPsp < pspID )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDMAX);
            RETVOID;
        }

        if ( ((ItPspCb*)NULLP == itGlobalCb.psp[pspID] ) && (0 == pspID) )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDNULLP);
            RETVOID;
        }

        XOS_CliExtPrintf(pItCliEnv, "PSP Status ID: %d\r\n", pspID);
        itDbgPrintfOnePspSta( 1, &(itGlobalCb.psp[pspID]->pspSta) );
        RETVOID;
    }
    else
    {
        /*û�к�����������Ҫ����ȫ����ӡ*/
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStr(pItCliEnv, "PSP Status ID:");
#endif
        for ( i = 1; i < itGlobalCb.genCfg.maxNmbPsp; i++ )
        {
            if ( (ItPspCb*)NULLP == itGlobalCb.psp[i] )
            {
                continue;
            }
#ifdef IT_DBG_PRINTF_EVERY
            XOS_CliExtPrintf(pItCliEnv, "PSP Status ID: %d\r\n", i);
            itDbgPrintfOnePspSta( 1, &(itGlobalCb.psp[i]->pspSta) );
#else
            XOS_CliExtPrintf(pItCliEnv, "  %d", i);
#endif
        }
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
#endif
    }
    
    RETVOID;
}

PRIVATE VOID itDbgShowSTAadd(VOID)
{
    /*��ʱ������*/
    RETVOID;
}

PRIVATE VOID itDbgShowSTAdrk(VOID)
{
    /*��ʱ������*/
    RETVOID;
}

PRIVATE VOID itDbgShowSTApri(VOID)
{
    /*��ʱ������*/
    RETVOID;
}

PRIVATE VOID itDbgShowSTAdpc(VOID)
{
    /*��ʱ������*/
    RETVOID;
}


/***************************************************************************
* printf format Functions
***************************************************************************/
PRIVATE VOID itCliExtLevel(U32 pfLevel)
{
    U32 i;
    char achLevel[IT_DBG_PF_FORMAT_NUMBER*IT_DBG_PF_MAX_LAYER_NMB+1];

    if ( 0 != pfLevel )
    {
        memset(achLevel, ' ', (IT_DBG_PF_FORMAT_NUMBER*IT_DBG_PF_MAX_LAYER_NMB+1)*(sizeof(achLevel[0])));
        i = pfLevel*IT_DBG_PF_FORMAT_NUMBER;
        achLevel[i] = '\0';
        XOS_CliExtPrintf(pItCliEnv, achLevel);
    }
    RETVOID;
}
/***************************************************************************
* Control block printf Functions Start
***************************************************************************/
#ifdef Control_block_printf_Func
#endif
PRIVATE VOID itDbgPrintfOneAddrCbk(U32 pfLevel, ItAddrTrnCb* AddrTrnCb)
{
    ItAddrTrnCb* pAddrTrnCb;
    U32 NowLevel;
    
    pAddrTrnCb = (ItAddrTrnCb*)NULLP;

    if ( (ItAddrTrnCb*)NULLP == AddrTrnCb )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_ADDRTRNINPUT);
        RETVOID;
    }
    else
    {
        pAddrTrnCb = AddrTrnCb;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Address Translation Status:");
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "    Number of entries in DPC table    : %d \r\n", pAddrTrnCb->atSta.nmbDpc);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "    Number of entries in routing table: %d \r\n", pAddrTrnCb->atSta.nmbRout);
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Dynamic Routing key status:");
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "    Num of RK dynamically registered  : %d \r\n", pAddrTrnCb->rkSta.nmbRkReg);
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Hash list of DPCs:");
    itDbgPrintfOneHashListCbk(NowLevel+1, &(pAddrTrnCb->dpcList));
    RETVOID;
}

PRIVATE VOID itDbgPrintfGenCbk(U32 pfLevel, ItGlobalCb* GlobalCb)
{
    U32 NowLevel;
    ItGlobalCb* pGlobalCb;

    pGlobalCb = (ItGlobalCb*)NULLP;

    if ( (ItGlobalCb*)NULLP == GlobalCb )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_GLOABLNULLP);
        RETVOID;
    }
    else
    {
        pGlobalCb = GlobalCb;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Task initialization info:");
    itDbgPrintfTaskInit(NowLevel+1, &(itGlobalCb.itInit));
    
#ifdef SS_MULTIPLE_PROCS
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "PSF control block                      : %d \r\n", itGlobalCb->used);
#endif /* SS_MULTIPLE_PROCS */

     /* static management structure is not printf*/

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "General configuration:");
    itDbgPrintfGenCfg(pfLevel+1, &(itGlobalCb.genCfg));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "General statistics:");
    itDbgPrintfGenSts(pfLevel+1, &(itGlobalCb.genSts));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "General status:");
    itDbgPrintfGenSta(pfLevel+1, &(itGlobalCb.genSta));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Network Control Block:");
    itDbgPrintfNwkCbk(itGlobalCb.genCfg.maxNmbNwk+1, pfLevel+1);

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Nsap Control Block:");
    itDbgPrintfNsapCbk(itGlobalCb.genCfg.maxNmbNSap+1, pfLevel+1);

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Sct Sap Control Block:");
    itDbgPrintfSctsapCbk(itGlobalCb.genCfg.maxNmbSctSap+1, pfLevel+1);

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "PS Control Block:");
    itDbgPrintfPsCbk(itGlobalCb.genCfg.maxNmbPs+1, pfLevel+1);

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "PSP Control Block:");
    itDbgPrintfPspCbk(itGlobalCb.genCfg.maxNmbPsp+1, pfLevel+1);

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Association Control Block:");
    itDbgPrintfAssCbk(itGlobalCb.maxNmbAssoc+1, pfLevel+1);
    
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Address Translation Control Block:");
    itDbgPrintfAddrTrnCbk(pfLevel+1, &(itGlobalCb.addrTrn));

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Maximum number of associations         : %d \r\n", itGlobalCb.maxNmbAssoc);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of messages in the layer        : %d \r\n", itGlobalCb.nmbMsg);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Local RK ID                            : %d \r\n", itGlobalCb.lclRkId);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Running no for allocatingRC dynamically: %d \r\n", itGlobalCb.rCtx);

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "PS ID List:");
    itDbgPrintfPsIdListCbk(pfLevel+1, &(itGlobalCb.psLstCb));
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Trace Mask                             : %d \r\n", itGlobalCb.trcMask);
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "To store ASP Id received in ASP UP Msg:");
    itDbgPrintfAspIdCbk(pfLevel+1, &(itGlobalCb.aspIdCb));

    itCliExtLevel(NowLevel);
    if ( TRUE == itGlobalCb.timerFreezeFlg )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Timer frozen by PSF              : TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Timer frozen by PSF              : FALSE");
    }
}


PRIVATE VOID itDbgPrintfNwkCbk(U32 NwkID, U32 pfLevel)
{
    U32 i = 0;
    U32 j = 0;
    
    if ( NwkID > itGlobalCb.genCfg.maxNmbNwk )
    {
#ifndef IT_DBG_PRINTF_EVERY
        itCliExtLevel(pfLevel);
        XOS_CliExtWriteStr(pItCliEnv, "Network Control Block ID:");
#endif
        for ( i = 0; i < itGlobalCb.genCfg.maxNmbNwk; i++ )
        {
            if ( (ItNwkCb*)NULLP == itGlobalCb.nwk[i] )
            {
                continue;
            }
            j++;
#ifdef IT_DBG_PRINTF_EVERY
            itCliExtLevel(pfLevel);
            XOS_CliExtPrintf(pItCliEnv, "Network Control Block ID: %d\r\n", i);
            itDbgPrintfOneNwkCbk(i, pfLevel+1, (ItNwkCb*)NULLP );
#else
            if ( 0 == j%6 )
            {
                itCliExtLevel(pfLevel);
                XOS_CliExtWriteStr(pItCliEnv, "\r\n                         ");
            }
            XOS_CliExtPrintf(pItCliEnv, "    %d", i);
#endif
        }
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
#endif
    }
    else
    {
        itCliExtLevel(pfLevel);
        XOS_CliExtPrintf(pItCliEnv, "Network Control Block ID: %d\r\n", NwkID);
        itDbgPrintfOneNwkCbk(NwkID, pfLevel+1, (ItNwkCb*)NULLP );
        RETVOID;
    }
    
    RETVOID;
}

PRIVATE VOID itDbgPrintfOneNwkCbk(U32 nwkID, U32 pfLevel, ItNwkCb* NwkCb)
{
    U32 uLoop;
    U32 NowLevel;
    ItPsCb   *pPsCb; 
    ItNwkCb* pNwkCb;
    U8 bRestart = 0;
    
    pPsCb = (ItPsCb*)NULLP;
    pNwkCb = (ItNwkCb*)NULLP;

    if ( (ItNwkCb*)NULLP == NwkCb )
    {
        pNwkCb = itGlobalCb.nwk[nwkID];
    }
    else
    {
        pNwkCb = NwkCb;
    }
    
    NowLevel = pfLevel;
    
    if ( (ItNwkCb*)NULLP == pNwkCb )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NWKIDNULLP);
        RETVOID;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Network Configuration ID: %d \r\n", pNwkCb->nwkCfg.nwkId);
    itDbgPrintfOneNwkCfg( NowLevel+1, &(pNwkCb->nwkCfg) );
    itCliExtLevel(NowLevel);
    if ( (ItNSapCb*)NULLP != pNwkCb->mtp3NSap )
    {
        XOS_CliExtPrintf(pItCliEnv, "NSAP Control Block ID   : %d \r\n", pNwkCb->mtp3NSap->sntCfg.sapId);
    }
    else
    {
        XOS_CliExtPrintf(pItCliEnv, "NSAP Control Block ID   : NULL\r\n");
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of PS Block      : %d \r\n", pNwkCb->nmbPs);
    if ( 0 != pNwkCb->nmbPs )
    {
        itCliExtLevel(NowLevel);
        XOS_CliExtWriteStr(pItCliEnv, "    List of PS Block ID:");
        for ( uLoop = 0; uLoop < pNwkCb->nmbPs; uLoop++)
        {
            pPsCb = pNwkCb->ps[uLoop];
            if ( (ItPsCb*)NULLP != pPsCb )
            {
                XOS_CliExtPrintf(pItCliEnv, "  %d", pPsCb->psCfg.psId);
            }           
        }
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
    }

    itCliExtLevel(NowLevel);
    if ( TRUE == itGlobalCb.nwk[nwkID]->restart )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Restarting              : TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Restarting              : FALSE");
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Remote SGP Restarting: ");
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "    Restarting SGP ID: ");
    itCliExtLevel(NowLevel+2);
    for ( uLoop = 0; uLoop < LIT_MAX_PSP; uLoop++ )
    {
        if ( TRUE == itGlobalCb.nwk[nwkID]->sgpRst[uLoop] )
        {
            XOS_CliExtPrintf(pItCliEnv, "  %d", uLoop);
            bRestart = 1;
        }
    }

    if ( 0 == bRestart )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "NULL");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
    }
    
    RETVOID;
}

PRIVATE VOID itDbgPrintfNsapCbk(U32 NsapID, U32 pfLevel)
{
    U32 i = 0;
    
    if ( NsapID > itGlobalCb.genCfg.maxNmbNSap )
    {
#ifndef IT_DBG_PRINTF_EVERY
        itCliExtLevel(pfLevel);
        XOS_CliExtWriteStr(pItCliEnv, "Upper SAP Control Block ID:");
#endif
        for ( i = 0; i < itGlobalCb.genCfg.maxNmbNSap; i++ )
        {
            if ( (ItNSapCb*)NULLP == itGlobalCb.nSap[i] )
            {
                continue;
            }
#ifdef IT_DBG_PRINTF_EVERY
            itCliExtLevel(pfLevel);
            XOS_CliExtPrintf(pItCliEnv, "Upper SAP Control Block ID: %d\r\n", i);
            itDbgPrintfOneNsapCbk(i, pfLevel+1, (ItNSapCb*)NULLP );
#else
            XOS_CliExtPrintf(pItCliEnv, "    %d", i);
#endif
        }
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
#endif

    }
    else
    {
        itCliExtLevel(pfLevel);
        XOS_CliExtPrintf(pItCliEnv, "Upper SAP Control Block ID: %d\r\n", NsapID);
        itDbgPrintfOneNsapCbk(NsapID, pfLevel+1, (ItNSapCb*)NULLP );
        RETVOID;
    }
}

PRIVATE VOID itDbgPrintfOneNsapCbk(S32 nsapID, U32 pfLevel, ItNSapCb* NsapCb)
{
    ItNSapCb* pNsapCb;
    U32 NowLevel;
    
    pNsapCb = (ItNSapCb*)NULLP;

    if ( (ItNSapCb*)NULLP == NsapCb )
    {
        pNsapCb = itGlobalCb.nSap[nsapID];
    }
    else
    {
        pNsapCb = NsapCb;
        
    }

    NowLevel = pfLevel;
    
    if ( (ItNSapCb*)NULLP == pNsapCb )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NSAPIDNULLP);
        RETVOID;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Upper SAP  Configuration ID      : %d \r\n", pNsapCb->sntCfg.sapId);
    itDbgPrintfOneNsapCfg(NowLevel+1, &(pNsapCb->sntCfg) );
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Upper SAP Statistics ID          : %d \r\n", pNsapCb->sntSts.spId);
    itDbgPrintfOneNsapSts(NowLevel+1, &(pNsapCb->sntSts));
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Upper SAP State ID               : %d \r\n", pNsapCb->sntSta.lclSapId);
    itDbgPrintfOneNsapSta(NowLevel+1, &(pNsapCb->sntSta));
    
    itCliExtLevel(NowLevel);
    if ( (ItNwkCb*)NULLP != pNsapCb->nwk )
    {
        XOS_CliExtPrintf(pItCliEnv, "Network Context ID               : %d \r\n", pNsapCb->nwk->nwkCfg.nwkId);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Network Context ID               : NULL");
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Service User Post Structure:");
    itDbgPrintfOnePstCbk( NowLevel+1, &(pNsapCb->pst) );
    
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Corresponding Local PS Id        : %d \r\n", pNsapCb->lpsId);
#endif
#ifdef ITSG
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Interface Primitive Timer:");
    itDbgPrintfOneTimerCbk( NowLevel+1, &(pNsapCb->tmrPrim) );
    
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of Bind retries on the SAP: %d \r\n", pNsapCb->nmbBndRetry);
#endif
    
    RETVOID;
}

PRIVATE VOID itDbgPrintfSctsapCbk(U32 SctsapID, U32 pfLevel)
{
    U32 i = 0;
    
    if ( SctsapID > itGlobalCb.genCfg.maxNmbSctSap )
    {
#ifndef IT_DBG_PRINTF_EVERY
        itCliExtLevel(pfLevel);
        XOS_CliExtWriteStr(pItCliEnv, "Lower SAP Control Block ID:");
#endif
        for ( i = 0; i < itGlobalCb.genCfg.maxNmbSctSap; i++ )
        {
            if ( (ItSctSapCb*)NULLP == itGlobalCb.sctSap[i] )
            {
                continue;
            }
#ifdef IT_DBG_PRINTF_EVERY
            itCliExtLevel(pfLevel);
            XOS_CliExtPrintf(pItCliEnv, "Lower SAP Control Block ID: %d\r\n", i);
            itDbgPrintfOneSctsapCbk(i, pfLevel+1, (ItSctSapCb*)NULLP );
#else
            XOS_CliExtPrintf(pItCliEnv, "  %d", i);
#endif
        }
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
#endif
    }
    else
    {
        itCliExtLevel(pfLevel);
        XOS_CliExtPrintf(pItCliEnv, "Lower SAP Control Block ID: %d\r\n", SctsapID);
        itDbgPrintfOneSctsapCbk(SctsapID, pfLevel+1, (ItSctSapCb*)NULLP );
        RETVOID;
    }
}

PRIVATE VOID itDbgPrintfOneSctsapCbk(S32 sctsapID, U32 pfLevel, ItSctSapCb* SctsapCb)
{
    ItSctSapCb* pSctsapCb;
    U32 NowLevel;
    
    pSctsapCb = (ItSctSapCb*)NULLP;

    if ( (ItSctSapCb*)NULLP == SctsapCb )
    {
        pSctsapCb = itGlobalCb.sctSap[sctsapID];
    }
    else
    {
        pSctsapCb = SctsapCb;
        
    }

    NowLevel = pfLevel;
    
    if ( (ItSctSapCb*)NULLP == pSctsapCb )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_SCTSAPIDNULLP);
        RETVOID;
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Lower SAP Configuration ID       : %d \r\n", pSctsapCb->sctCfg.suId);
    itDbgPrintfOneSctsapCfg(NowLevel+1, &(pSctsapCb->sctCfg));
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Lower SAP Statistics ID          : %d \r\n", pSctsapCb->sctSts.suId);
    itDbgPrintfOneSctsapSts(NowLevel+1, &(pSctsapCb->sctSts));
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Lower SAP State ID               : %d \r\n", pSctsapCb->sctSta.suId);
    itDbgPrintfOneSctSapSta(NowLevel+1, &(pSctsapCb->sctSta));
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of Bind retries on the SAP: %d \r\n", pSctsapCb->nmbBndRetry);
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Service User Post Structure:");
    itDbgPrintfOnePstCbk(NowLevel+1, &(pSctsapCb->pst));
    
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Interface Primitive Timer:");
    itDbgPrintfOneTimerCbk( NowLevel+1, &(pSctsapCb->tmrPrim) );

    RETVOID;
}


PRIVATE VOID itDbgPrintfPsCbk(U32 PsId, U32 pfLevel)
{
    U32 i = 0;
    
    if ( PsId > itGlobalCb.genCfg.maxNmbPs )
    {
#ifndef IT_DBG_PRINTF_EVERY
        itCliExtLevel(pfLevel);
        XOS_CliExtWriteStr(pItCliEnv, "Peer Server Control Block ID:");
#endif
        for ( i = 0; i < itGlobalCb.genCfg.maxNmbPs; i++ )
        {
            if ( (ItPsCb*)NULLP == itPsmFindPs(i) )
            {
                continue;
            }
#ifdef IT_DBG_PRINTF_EVERY
            itCliExtLevel(pfLevel);
            XOS_CliExtPrintf(pItCliEnv, "Peer Server Control Block ID: %d\r\n", i);
            itDbgPrintfOnePsCbk(i, pfLevel+1, (ItPsCb*)NULLP );
#else
            XOS_CliExtPrintf(pItCliEnv, "  %d", i);
#endif
        }
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
#endif
    }
    else
    {
        itCliExtLevel(pfLevel);
        XOS_CliExtPrintf(pItCliEnv, "Peer Server Control Block ID: %d\r\n", PsId);
        itDbgPrintfOnePsCbk(PsId, pfLevel+1, (ItPsCb*)NULLP );
    }
    
    RETVOID;
}

PRIVATE VOID itDbgPrintfOnePsCbk(U32 psID, U32 pfLevel, ItPsCb* PsCb)
{
    U32 NowLevel = 0;
    ItPsCb* pPsCb;
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
    ItChldPsCb* pChldPsCb;
    U32 uLoop = 0;
    pChldPsCb = (ItChldPsCb*)NULLP;
#endif /* ITASP && OG_RTE_ON_LPS_STA */
    pPsCb = (ItPsCb*)NULLP;
    

    if ( (ItPsCb*)NULLP == PsCb )
    {
    /* �����PS��Ҫ����*/
        pPsCb = itPsmFindPs(psID);
    }
    else
    {
        pPsCb = PsCb;
        
    }

    NowLevel = pfLevel;
    
    if ( (ItPsCb*)NULLP == pPsCb )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSIDNULLP);
        RETVOID;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Hash Table Header:");
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "    Pointer to key     : %s\r\n", pPsCb->hlEnt.key);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "    Length of key      : %d\r\n", pPsCb->hlEnt.keyLen);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "    Computed hash value: %d\r\n", pPsCb->hlEnt.hashVal);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Peer Server Configuration ID: %d \r\n", pPsCb->psCfg.psId);
    itDbgPrintfOnePsCfg(NowLevel+1, &(pPsCb->psCfg));
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Peer Server Status ID       : %d \r\n", pPsCb->psSta.psId);
    itDbgPrintfOnePsSta(NowLevel+1, &(pPsCb->psSta));
    itCliExtLevel(NowLevel);
    if ( TRUE == pPsCb->staticCfg )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "PS Statically Configured    : TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "PS Statically Configured    : FALSE");
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Overall PS Congestion Level : %d \r\n", pPsCb->congLevel);
    itCliExtLevel(NowLevel);
    if ( (ItNwkCb*)NULLP != pPsCb->nwk )
    {
        XOS_CliExtPrintf(pItCliEnv, "Network Context ID          : %d \r\n", pPsCb->nwk->nwkCfg.nwkId);    
    }
    else
    {
        XOS_CliExtPrintf(pItCliEnv, "Network Context ID            : NULL\r\n");
    }
    itCliExtLevel(NowLevel);
    if ( (ItDpcCb*)NULLP != pPsCb->spmc )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Signaling Point Management Cluster DPC:");
        itDbgPrintfOneDpcCbk( 0, 0, NowLevel+1, pPsCb->spmc );
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Signaling Point Management Cluster DPC: NULL");
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "AS-PENDING Timer:");
    itDbgPrintfOneTimerCbk( NowLevel+1, &(pPsCb->tmrPend) );

#if !(defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
    itCliExtLevel(NowLevel);
    if ( (ItLscAllCb*)NULLP != pPsCb->lsCb )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Load Sharing Control Block: ");
        itDbgPrintfOneLscAllCbk(pPsCb->psCfg.loadShareMode, NowLevel+1, pPsCb->lsCb);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Load Sharing Control Block  : NULL");
    }
#else
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of Child PSs         : %d \r\n", pPsCb->nmbChldPs);
    for ( uLoop = 0; uLoop < pPsCb->nmbChldPs; uLoop++ )
    {
        pChldPsCb = (ItChldPsCb*)(pPsCb->chldPsLst[uLoop]);
        if ( (ItChldPsCb*)NULLP != pChldPsCb )
        {
            itCliExtLevel(NowLevel);
            XOS_CliExtPrintf(pItCliEnv, "Child PS List : %d \r\n", uLoop);
            itDbgPrintfOneChldPsCbk(pPsCb->psCfg.loadShareMode, NowLevel+1, pChldPsCb);
        }
    }
#endif
    RETVOID;
}

PRIVATE VOID itDbgPrintfAssCbk(U32 AssID, U32 pfLevel)
{
    U32 i = 0;
    U32 j = 0;
    
    if ( AssID > itGlobalCb.maxNmbAssoc )
    {
#ifndef IT_DBG_PRINTF_EVERY
        itCliExtLevel(pfLevel);
        XOS_CliExtWriteStr(pItCliEnv, "Association Control Block ID:");
#endif
        for ( i = 0; i < itGlobalCb.maxNmbAssoc; i++ )
        {
            if ( (ItAssocCb*)NULLP == itGlobalCb.assoc[i] )
            {
                continue;
            }
            if ( 0 == itGlobalCb.assoc[i]->owner->pspCfg.pspId )
            {
                continue;
            }
            j++;
#ifdef IT_DBG_PRINTF_EVERY
            itCliExtLevel(pfLevel);
            XOS_CliExtPrintf(pItCliEnv, "Association Control Block ID: %d\r\n", i);
            itDbgPrintfOneAssCbk(i, pfLevel+1, (ItAssocCb*)NULLP );
#else
            if ( 0 == j%6 )
            {
                itCliExtLevel(pfLevel);
                XOS_CliExtWriteStr(pItCliEnv, "\r\n                             ");
            }
            XOS_CliExtPrintf(pItCliEnv, "    %d", i);
#endif
        }
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
#endif
    }
    else
    {
        itCliExtLevel(pfLevel);
        XOS_CliExtPrintf(pItCliEnv, "Association Control Block ID: %d\r\n", AssID);
        itDbgPrintfOneAssCbk(AssID, pfLevel+1, (ItAssocCb*)NULLP );
    }

    RETVOID;
}

PRIVATE VOID itDbgPrintfOneAssCbk(U32 AssID, U32 pfLevel, ItAssocCb* AssCb)
{
    U32 uLoop;
    U32 NowLevel;
    ItAssocCb   *pAssCb; 

    pAssCb = (ItAssocCb*)NULLP;

    if ( (ItAssocCb*)NULLP == AssCb )
    {
        pAssCb = itGlobalCb.assoc[AssID];
    }
    else
    {
        pAssCb = AssCb;
        
    }

    NowLevel = pfLevel;
    
    if ( (ItAssocCb*)NULLP == pAssCb )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_ASSIDNULLP);
        RETVOID;
    }

    itCliExtLevel(NowLevel);
    if ( (ItSctSapCb*)NULLP != pAssCb->sctSap )
    {
        XOS_CliExtPrintf(pItCliEnv, "Lower SCT SAP ID                         : %d \r\n", pAssCb->sctSap->sctCfg.suId);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Lower SCT SAP ID                         : NULL");
    }
    
    itCliExtLevel(NowLevel);
    if ( (ItPspCb*)NULLP != pAssCb->owner )
    {
        XOS_CliExtPrintf(pItCliEnv, "Pointer to owner PSP Block ID            : %d \r\n", pAssCb->owner->pspCfg.pspId);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Pointer to owner PSP Block ID            : NULL");
    }
    
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Service User Association ID              : %d \r\n", pAssCb->assocId);
    itCliExtLevel(NowLevel);
    if ( TRUE == pAssCb->congActive )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Congestion Queue Active                  : TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Congestion Queue Active                  : FALSE");
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Polling Congestion Status Timer:");
    itDbgPrintfOneTimerCbk(NowLevel+1, &(pAssCb->tmrCong) );
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Primitive Timer:");
    itDbgPrintfOneTimerCbk(NowLevel+1, &(pAssCb->tmrPrim) );
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Actual Number of Outgoing Streams        : %d \r\n", pAssCb->outStrms);
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Heartbeat Timer:");
    itDbgPrintfOneTimerCbk(NowLevel+1, &(pAssCb->tmrHBeatRX) );
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of Supported PSs                  : %d \r\n", pAssCb->nmbPs);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "List of Supported PSs: ");
    for ( uLoop = 0; uLoop < pAssCb->nmbPs; uLoop++ )
    {
        XOS_CliExtPrintf(pItCliEnv, "  %d", pAssCb->ps[uLoop]->psCfg.psId);
    }
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "State Variable for MIF                   : ");
    switch ( pAssCb->mifSt )
    {
        case IT_MIF_UNLISTED:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Not Listed");
            break;
        }
        case IT_MIF_LISTED:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Listed ");
            break;
        }
        case IT_MIF_ELIMINATED:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Eliminated");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Error");
            break;
        }
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Type of ASPM being sent                  : ");
    switch ( pAssCb->aspmType )
    {
        case IT_ASPM_ASPDN:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "ASPDN message");
            break;
        }
        case IT_ASPM_ASPUP:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "ASPUP message");
            break;
        }    
        case IT_ASPM_ASPAC:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "ASPAC message");
            break;
        }    
        case IT_ASPM_ASPIA:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "ASPIA message");
            break;
        }    
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Error");
            break;
        }
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Temporary storage for INFO str           : %s \r\n", pAssCb->info);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "ASPM retry counter                       : %d \r\n", pAssCb->retryCount);
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "ASPM retry/fail timer:");
    itDbgPrintfOneTimerCbk(NowLevel+1, &(pAssCb->tmrAspm) );
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Heart beat send timer:");
    itDbgPrintfOneTimerCbk(NowLevel+1, &(pAssCb->tmrHBeatTX) );
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Time to settle DUNA message:");
    itDbgPrintfOneTimerCbk(NowLevel+1, &(pAssCb->tmrDunaSettle) );
    for ( uLoop = 0; uLoop < IT_MAX_REG_TMR; uLoop++ )
    {
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "Timer to track RK in RKM msg ID: %d \r\n", uLoop);
        itDbgPrintfOneRrkCbk(NowLevel+1, &(pAssCb->regReqTmrCb[uLoop]) );
    }
#ifdef LITV3
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "System ticks when association unavailable: %d \r\n", pAssCb->ticksCong);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "System ticks when association congested: %d \r\n", pAssCb->ticksUnav);
#endif
    itCliExtLevel(NowLevel);
    if ( (ItAssocSta*)NULLP != pAssCb->assocSta )
    {
        XOS_CliExtPrintf(pItCliEnv, "Association status ID                    : %d \r\n", pAssCb->assocSta->spAssocId);
        itDbgPrintfOneAssocSta(NowLevel+1, pAssCb->assocSta);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Association status ID                    : NULL");
    }

    RETVOID;
}

PRIVATE VOID itDbgPrintfPspCbk(U32 PspID, U32 pfLevel)
{
    U32 i = 0;
    
    if ( PspID > itGlobalCb.genCfg.maxNmbPsp )
    {
#ifndef IT_DBG_PRINTF_EVERY
        itCliExtLevel(pfLevel);
        XOS_CliExtWriteStr(pItCliEnv, "PSP Control Block ID:");
#endif
        for ( i = 1; i < itGlobalCb.genCfg.maxNmbPsp; i++ )
        {
            if ( (ItPspCb*)NULLP == itGlobalCb.psp[i] )
            {
                continue;
            }
#ifdef IT_DBG_PRINTF_EVERY
            itCliExtLevel(pfLevel);
            XOS_CliExtPrintf(pItCliEnv, "PSP Control Block ID: %d\r\n", i);
            itDbgPrintfOnePspCbk(i, pfLevel+1, (ItPspCb*)NULLP );
#else
            XOS_CliExtPrintf(pItCliEnv, "    %d", i);
#endif
        }
#ifndef IT_DBG_PRINTF_EVERY
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
#endif
    }
    else
    {
        itCliExtLevel(pfLevel);
        XOS_CliExtPrintf(pItCliEnv, "PSP Control Block ID: %d\r\n", PspID);
        itDbgPrintfOnePspCbk(PspID, pfLevel+1, (ItPspCb*)NULLP );
    }
    
    RETVOID;
}

PRIVATE VOID itDbgPrintfOnePspCbk(U32 pspID, U32 pfLevel, ItPspCb* PspCb)
{
    U32 uLoop;
    U32 NowLevel;
    ItPspCb   *pPspCb; 

    pPspCb = (ItPspCb*)NULLP;

    if ( (ItPspCb*)NULLP == PspCb )
    {
        pPspCb = itGlobalCb.psp[pspID];
    }
    else
    {
        pPspCb = PspCb;
    }

    NowLevel = pfLevel;
    
    if ( (ItPspCb*)NULLP == pPspCb )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPIDNULLP);
        RETVOID;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "PSP Configuration ID: %d \r\n", pPspCb->pspCfg.pspId);
    itDbgPrintfOnePspCfg( NowLevel+1, &(pPspCb->pspCfg) );
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "PSP Statistics ID: %d \r\n", pPspCb->pspSts.pspId);
    itDbgPrintfOnePspSts( NowLevel+1, &(pPspCb->pspSts) );
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "PSP Status ID: %d \r\n", pPspCb->pspSta.pspId);
    itDbgPrintfOnePspSta( NowLevel+1, &(pPspCb->pspSta) );

    for ( uLoop = 0; uLoop < LIT_MAX_SEP; uLoop++ )
    {
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "linked SCTP association: %d \r\n", uLoop);
        itDbgPrintfOneAssCbk(0, NowLevel+1, &(pPspCb->assoc[uLoop]));
    }

    RETVOID;
}

PRIVATE VOID itDbgPrintfOneRrkCbk(U32 pfLevel, ItRegReqTmrCb* RegReqTmrCb)
{
    U32 NowLevel;
    ItRegReqTmrCb* pRegReqTmrCb;
    U32 uLoop;
    
    pRegReqTmrCb = (ItRegReqTmrCb*)NULLP;

    if ( (ItRegReqTmrCb*)NULLP == RegReqTmrCb )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_CHLDPS);
        RETVOID;
    }
    else
    {
        pRegReqTmrCb = RegReqTmrCb;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    if ( LIT_REG_REQ == pRegReqTmrCb->reqType )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Registration Request Type      : REG REQ ");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Registration Request Type      : DEREG REQ");
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Association ID                 : %d \r\n", pRegReqTmrCb->assocId);
    itCliExtLevel(NowLevel);
    if ( LIT_REG_REQ == pRegReqTmrCb->reqType )
    {
        XOS_CliExtPrintf(pItCliEnv, "Nmb of local-RKs sent in REGREQ: %d \r\n", pRegReqTmrCb->req.regReq.nmbLclRkId);
        for ( uLoop = 0; uLoop < pRegReqTmrCb->req.regReq.nmbLclRkId; uLoop++ )
        {
            itCliExtLevel(NowLevel);
            XOS_CliExtPrintf(pItCliEnv, "    LclRkId in REGREQ[%d]: %d \r\n", uLoop, pRegReqTmrCb->req.regReq.localRkId[uLoop]);
        }
    }
    else
    {
        XOS_CliExtPrintf(pItCliEnv, "Nmb of RCs sent in DEREG REQ   : %d \r\n", pRegReqTmrCb->req.deRegReq.nmbRctx);
        for ( uLoop = 0; uLoop < pRegReqTmrCb->req.deRegReq.nmbRctx; uLoop++ )
        {
            itCliExtLevel(NowLevel);
            XOS_CliExtPrintf(pItCliEnv, "    PS ID to which RC belongs[%d]: %d \r\n", uLoop, pRegReqTmrCb->req.deRegReq.rCtx[uLoop].psId);
            itCliExtLevel(NowLevel);
            XOS_CliExtPrintf(pItCliEnv, "    RC ID in DEREG REQ[%d]       : %d \r\n", uLoop, pRegReqTmrCb->req.deRegReq.rCtx[uLoop].routCntx);
        }
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "T(Rk-ack):");
    itDbgPrintfOneTimerCbk(NowLevel+1, &(pRegReqTmrCb->tmrRegReq) );
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Counter for number of retries  : %d \r\n", pRegReqTmrCb->reqCntr);
    itCliExtLevel(NowLevel);
    if ( TRUE == pRegReqTmrCb->rspPend )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "rspPend                        : TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "rspPend                        : FALSE");
    }
    
    RETVOID;
}


#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
PRIVATE VOID itDbgPrintfOneChldPsCbk(U8 LoadShareType, U32 pfLevel, ItChldPsCb* chldPsLst)
{
    U32 NowLevel;
    ItChldPsCb* pchldPsLst;
    
    pchldPsLst = (ItChldPsCb*)NULLP;

    if ( (ItChldPsCb*)NULLP == chldPsLst )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_CHLDPS);
        RETVOID;
    }
    else
    {
        pchldPsLst = chldPsLst;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Local PS ID: %d\r\n", pchldPsLst->lpsId);
    itCliExtLevel(NowLevel);
    if ( (ItLscAllCb*)NULLP != pchldPsLst->lsCb )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Load sharing control block for this Child:");
        itDbgPrintfOneLscAllCbk(LoadShareType, NowLevel+1, pchldPsLst->lsCb);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Load sharing control block for this Child: NULL");
    }
    
    RETVOID;
}
#endif

PRIVATE VOID itDbgPrintfOneLscAllCbk(U8 LoadShareType, U32 pfLevel, ItLscAllCb* LscAllCb)
{
    U32 NowLevel;
    ItLscAllCb* pLscAllCb;
    
    pLscAllCb = (ItLscAllCb*)NULLP;

    if ( (ItLscAllCb*)NULLP == LscAllCb )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_ALLLSCINPUT);
        RETVOID;
    }
    else
    {
        pLscAllCb = LscAllCb;
        NowLevel = pfLevel;
    }

    switch (LoadShareType)
    {
        case LIT_LOADSH_RNDROBIN:
        {
            itDbgPrintfOneLscRndRbnCbk(NowLevel+1, &(pLscAllCb->rndRbn));
            break;
        }
        case LIT_LOADSH_SLS:
        {
            itDbgPrintfOneLscSls(NowLevel+1, &(pLscAllCb->sls));
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_ALLLSCTYPE);
            RETVOID;
            break;
        }
    }

    RETVOID;
}

PRIVATE VOID itDbgPrintfOneLscRndRbnCbk(U32 pfLevel, ItLscRndRbnCb* LscRndRbnCb)
{
    U32 NowLevel;
    ItLscRndRbnCb* pLscRndRbnCb;
    
    pLscRndRbnCb = (ItLscRndRbnCb*)NULLP;

    if ( (ItLscRndRbnCb*)NULLP == LscRndRbnCb )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_LSCRNDRBN);
        RETVOID;
    }
    else
    {
        pLscRndRbnCb = LscRndRbnCb;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    if ( (ItPsCb*)NULLP != pLscRndRbnCb->cluster )
    {
        XOS_CliExtPrintf(pItCliEnv, "Parent cluster Ps Control Block ID: %d \r\n", pLscRndRbnCb->cluster->psCfg.psId);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Parent cluster Ps Control Block ID: NULL");
    }
    
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "ID of most recently used target   : %d \r\n", pLscRndRbnCb->lastId);
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "List of XUDT contexts:");
    itDbgPrintfOneHashListCbk(NowLevel+1, &(pLscRndRbnCb->xudtLst));

    RETVOID;
}

PRIVATE VOID itDbgPrintfOneLscSls(U32 pfLevel, ItLscSlsCb* LscSlsCb)
{
    U32 NowLevel;
    ItLscSlsCb* pLscSlsCb;

    pLscSlsCb = (ItLscSlsCb*)NULLP;

    if ( (ItLscSlsCb*)NULLP == LscSlsCb )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_LSCRNDRBN);
        RETVOID;
    }
    else
    {
        pLscSlsCb = LscSlsCb;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    if ( (ItPsCb*)NULLP != pLscSlsCb->cluster )
    {
        XOS_CliExtPrintf(pItCliEnv, "Parent cluster Ps Control Block ID: %d \r\n", pLscSlsCb->cluster->psCfg.psId);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Parent cluster Ps Control Block ID: NULL");
    }
    
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "List of SLS contexts:");
    itCliExtLevel(NowLevel);
    if ( (ItLscSlsCtx*)NULLP != pLscSlsCb->slsLst )
    {
        XOS_CliExtPrintf(pItCliEnv, "    Selected Target ID         : %d \r\n", pLscSlsCb->slsLst->targetId);
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "    Index for SeqCntrl Array ID: %d \r\n", pLscSlsCb->slsLst->seqTmrId);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "    List of SLS contexts       : NULL");
    }

    RETVOID;
}

PRIVATE VOID itDbgPrintfOneHashListCbk(U32 pfLevel, CmHashListCp* HashListCp)
{
    U32 NowLevel;
    CmHashListCp* pHashListCp;

    pHashListCp = (CmHashListCp*)NULLP;

    if ( (CmHashListCp*)NULLP == HashListCp )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_HASHLISTINPUT);
        RETVOID;
    }
    else
    {
        pHashListCp = HashListCp;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Memory region to allocate bins         : %d \r\n", pHashListCp->region);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Memory pool to allocate bins           : %d \r\n", pHashListCp->pool);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of hash list bins               : %d \r\n", pHashListCp->nmbBins);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of bits if nmbBins is power of 2: %d \r\n", pHashListCp->binBitMask);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of bits to represent nmbBins     : %d \r\n", pHashListCp->nmbBinBits);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Current number of entries              : %d \r\n", pHashListCp->nmbEnt);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Offset of CmHashListEnt in entries     : %d \r\n", pHashListCp->offset);
    itCliExtLevel(NowLevel);
    if ( TRUE == pHashListCp->dupFlg )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Allow duplicate keys                   : TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Allow duplicate keys                   : FALSE");
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Key type for selecting hash functions  : %d \r\n", pHashListCp->keyType);

    RETVOID;
}

PRIVATE VOID itDbgPrintfDpcCbk(U32 pfLevel, CmHashListCp* DpcList)
{
    ItDpcCb     *prevEnt;      /* previous DPC CB */
    ItDpcCb     *entry;        /* current DPC CB */
    U32             NumDpc = 0;
    
    TRC2(itDbgPrintfDpcCbk);

    prevEnt = (ItDpcCb *)NULLP;

    itCliExtLevel(pfLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Hash List of DPCs:");
    while (cmHashListGetNext(DpcList, (PTR) prevEnt, (PTR *) &entry) ==  ROK)
    {
        itCliExtLevel(pfLevel);
        XOS_CliExtPrintf(pItCliEnv, "DPCs(%d): %x\r\n", NumDpc, entry->dpc);
        NumDpc++;
        itDbgPrintfOneDpcCbk(0, 0, pfLevel+1, entry);
        prevEnt = entry;
    }
}

PRIVATE VOID itDbgPrintfOneDpcCbk(U8 NwkID, U32 DPC, U32 pfLevel, ItDpcCb* DpcCb)
{
    U32 uLoop = 0;
    U32 NowLevel;
    ItDpcCb* pDpcCb;
    U32      tmphlKey;         /* temporary hash list key */
    
    pDpcCb = (ItDpcCb*)NULLP;

    if ( (ItDpcCb*)NULLP == DpcCb )
    {
        tmphlKey = ((U32)NwkID << 24) | DPC;
        if (cmHashListFind(&itGlobalCb.addrTrn.dpcList, (U8 *) &tmphlKey,
                      sizeof(tmphlKey), 0, (PTR *) &pDpcCb) == RFAILED)
       {
            pDpcCb = (ItDpcCb*)NULLP;
       }
        NowLevel = ITDBGLVL0;
    }
    else
    {
        pDpcCb = DpcCb;
        NowLevel = pfLevel;
    }

    if ( (ItDpcCb*)NULLP == pDpcCb )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_DPCNOFIND);
        RETVOID;
    }
    
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Hash Table Header:");
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "    Pointer to Key     : %s\r\n", pDpcCb->hlEnt.key);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "    Length of Key      : %d\r\n", pDpcCb->hlEnt.keyLen);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "    Computed Hash Value: %x\r\n", pDpcCb->hlEnt.hashVal);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Hash Table Key                  : %x \r\n", pDpcCb->hlKey);
    itCliExtLevel(NowLevel);
    if ( (ItNwkCb*)NULLP != pDpcCb->nwk )
    {
        XOS_CliExtPrintf(pItCliEnv, "Network Context ID for this CB  : %d \r\n", pDpcCb->nwk->nwkCfg.nwkId);
    }
    else
    {
        XOS_CliExtPrintf(pItCliEnv, "Network Context ID for this CB  : NULL\r\n");
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Type of DPC CB                  : ");
    
    switch ( pDpcCb->type )
    {
        case IT_DPCCB_SPMC:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "LIT_RTTYPE_PS");
            break;
        }
        case IT_DPCCB_SS7:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "LIT_RTTYPE_MTP3");
            break;
        }
        case IT_DPCCB_LOCAL:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "LIT_RTTYPE_LOCAL");
            break;
        }
        case IT_DPCCB_UNKNOWN:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Currently Unknown");
            break;
        }
        case IT_DPCCB_NONROUTE:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Non-routing DPC CB");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Error");
            break;
        }
    }
    
    itCliExtLevel(NowLevel);
    if ( (ItPsCb*)NULLP != pDpcCb->owner )
    {
        XOS_CliExtPrintf(pItCliEnv, "Owner of this entry PS ID       : %d \r\n", pDpcCb->owner->psCfg.psId);
    }
    else
    {
        XOS_CliExtPrintf(pItCliEnv, "Owner of this entry PS ID       : NULL\r\n");
    }
    itCliExtLevel(NowLevel);
    if ( (ItNSapCb*)NULLP != pDpcCb->nSap )
    {
        XOS_CliExtPrintf(pItCliEnv, "NSAP ID related to this entry   : %d \r\n", pDpcCb->nSap->sntCfg.sapId);
    }
    else
    {
        XOS_CliExtPrintf(pItCliEnv, "NSAP ID related to this entry   : NULL\r\n");
    }
    itCliExtLevel(NowLevel);
    if ( TRUE == pDpcCb->noStatus )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "No status to be relayed to MTP-3: TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "No status to be relayed to MTP-3: FALSE");
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "MTP3 Status Poll Timer:");
    itDbgPrintfOneTimerCbk( NowLevel+1, &(pDpcCb->tmrPoll) );
    
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Status Audit Timer:");
    itDbgPrintfOneTimerCbk( NowLevel+1, &(pDpcCb->tmrDaud) );

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "State of DPC                    :  ");
    switch ( pDpcCb->dpcSt )
    {
        case IT_DPC_UNKNOWN:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Unknown");
            break;
        }
        case IT_DPC_AVAILABLE:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Available");
            break;
        }
        case IT_DPC_CONGESTED:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Congested");
            break;
        }
        case IT_DPC_UNAVAILABLE:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Unavailable");
            break;
        }
        case IT_DPC_RESTRICTED:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Restricted");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Error");
            break;
        }
    }
    
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "State of DPC SS7                :  ");
    switch ( pDpcCb->dpcStSs7 )
    {
        case IT_DPC_UNKNOWN:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Unknown");
            break;
        }
        case IT_DPC_AVAILABLE:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Available");
            break;
        }
        case IT_DPC_CONGESTED:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Congested");
            break;
        }
        case IT_DPC_UNAVAILABLE:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Unavailable");
            break;
        }
        case IT_DPC_RESTRICTED:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Restricted");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Error");
            break;
        }
    }
    
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Congestion level                :  ");
    switch ( pDpcCb->congLevel )
    {
        case SN_PRI0:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "priority 0");
            break;
        }
        case SN_PRI1:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "priority 1");
            break;
        }
        case SN_PRI2:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "priority 2");
            break;
        }
        case SN_PRI3:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "priority 3");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Error");
            break;
        }
    }

    /*����������������ò��󣬵���ӡ�Ķ���̫�࣬��������*/
    /*
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStr(pItCliEnv, "DPC state per assoc:");
    for ( uLoop = 0; uLoop < LIT_MAX_ASSOC; uLoop++ )
    {
        if ( 0 == ( uLoop%4 ) )
        {
            itCliExtLevel(NowLevel);
            XOS_CliExtWriteStr(pItCliEnv, "\r\n                ");
        }
        XOS_CliExtPrintf(pItCliEnv, "DpcSt[%d]: %d  ", uLoop, pDpcCb->pspDpcSt[uLoop]);
    }
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStr(pItCliEnv, "DPC cong level per assoc :");
    for ( uLoop = 0; uLoop < LIT_MAX_ASSOC; uLoop++ )
    {
        if ( 0 == ( uLoop%4 ) )
        {
            itCliExtLevel(NowLevel);
            XOS_CliExtWriteStr(pItCliEnv, "\r\n                ");
        }
        XOS_CliExtPrintf(pItCliEnv, "DpcCong[%d]: %d  ", uLoop, pDpcCb->pspDpcCong[uLoop]);
    }
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
    */
}


PRIVATE VOID itDbgPrintfOnePstCbk(U32 pfLevel, Pst* pst)
{
    U32 NowLevel;
    Pst* pPst;

    pPst = (Pst*)NULLP;

    if ( (Pst*)NULLP == pst )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSTINPUT);
        RETVOID;
    }
    else
    {
        pPst = pst;
        NowLevel = pfLevel;
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "DstProcId: %d \r\n", pPst->dstProcId);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "DstInst  : %d \r\n", pPst->dstInst);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "DstEnt   : %d \r\n", pPst->dstEnt);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "SrcProcId: %d \r\n", pPst->srcProcId);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "SrcInst  : %d \r\n", pPst->srcInst);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "SrcEnt   : %d \r\n", pPst->srcEnt);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Prior    : %d \r\n", pPst->prior);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Route    : %d \r\n", pPst->route);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Event    : %d \r\n", pPst->event);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Region   : %d \r\n", pPst->region);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Pool     : %d \r\n", pPst->pool);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Selector : %d \r\n", pPst->selector);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "IntfVer  : %d \r\n", pPst->intfVer);
}


PRIVATE VOID itDbgPrintfOneTimerCbk(U32 pfLevel, CmTimer* Timer)
{
    U32 NowLevel;
    CmTimer* pTimer;

    pTimer = (CmTimer*)NULLP;

    if ( (CmTimer*)NULLP == Timer )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_TIMERINPUT);
        RETVOID;
    }
    else
    {
        pTimer = Timer;
        NowLevel = pfLevel;
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "TmrEvnt : %d \r\n", pTimer->tmrEvnt);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "TqExpire: %d \r\n", pTimer->tqExpire);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Cb      : %d \r\n", pTimer->cb);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Ent2bUpd: %d \r\n", pTimer->ent2bUpd);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "EntIdx  : %d \r\n", pTimer->entIdx);
}

PRIVATE VOID itDbgPrintfAddrTrnCbk(U32 pfLevel, ItAddrTrnCb* AddrTrnCb)
{
    U32 NowLevel;
    ItAddrTrnCb* pAddrTrnCb;

    pAddrTrnCb = (ItAddrTrnCb*)NULLP;

    if ( (ItAddrTrnCb*)NULLP == AddrTrnCb )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_TIMERINPUT);
        RETVOID;
    }
    else
    {
        pAddrTrnCb = AddrTrnCb;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Address Translation Status:");
    itDbgPrintfAtSta(NowLevel+1, &(itGlobalCb.addrTrn.atSta));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Dynamic Routing Key Status:");
    itDbgPrintfRkSta(NowLevel+1, &(itGlobalCb.addrTrn.rkSta));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Hash List of DPCs:");
    itDbgPrintfDpcCbk(NowLevel+1, &(itGlobalCb.addrTrn.dpcList));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Linked List of Routes:");
    itDbgPrintfRouteCbk(NowLevel+1, &(itGlobalCb.addrTrn.rtList));
    
    RETVOID;
}

PRIVATE VOID itDbgPrintfRouteCbk(U32 pfLevel, CmLListCp* RteList)
{
    ItRouteCb* prouteCb;     /* route CB, if available */
    U32  NumRte = 0;
    ItDpcCb     *prevEnt;      /* previous DPC CB */
    ItDpcCb     *entry;        /* current DPC CB */
    U32             NumDpc = 0;

    TRC2(itDbgPrintfRouteCbk);

    prouteCb = (ItRouteCb *)cmLListFirst(RteList);

    if ( (ItRouteCb *)NULLP == prouteCb )
    {
        prevEnt = (ItDpcCb *)NULLP;

        while (cmHashListGetNext(&(itGlobalCb.addrTrn.dpcList), (PTR) prevEnt, (PTR *) &entry) ==  ROK)
        {
            prouteCb = (ItRouteCb *)cmLListFirst(&(entry->routes));
            while ( prouteCb != (ItRouteCb *)NULLP)
            {
                itCliExtLevel(pfLevel);
                XOS_CliExtPrintf(pItCliEnv, "Routes(%d):\r\n", NumRte);

                itDbgPrintfOneRouteCbk(0, 0, pfLevel+1, prouteCb);
                
                prouteCb = (ItRouteCb *)cmLListNext(RteList);
                NumRte++;
            }
            prevEnt = entry;
        }
    }
    else
    {
        while ( prouteCb != (ItRouteCb *)NULLP)
        {
            itCliExtLevel(pfLevel);
            XOS_CliExtPrintf(pItCliEnv, "Routes(%d):\r\n", NumRte);

            itDbgPrintfOneRouteCbk(0, 0, pfLevel+1, prouteCb);
            
            prouteCb = (ItRouteCb *)cmLListNext(RteList);
            NumRte++;
        }
    }

    RETVOID;
}

PRIVATE VOID itDbgPrintfOneRouteCbk(U8 NwkID, U32 DPC, U32 pfLevel, ItRouteCb* RouteCb)
{
    U32 NowLevel;
    ItRouteCb* pRouteCb;

    pRouteCb = (ItRouteCb*)NULLP;

    if ( (ItRouteCb*)NULLP == RouteCb )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSTINPUT);
        RETVOID;
    }
    else
    {
        pRouteCb = RouteCb;
        NowLevel = pfLevel;
    }

    itCliExtLevel(pfLevel);
    XOS_CliExtPrintf(pItCliEnv, "Route Filter[0]          : %x\r\n", pRouteCb->rtFilter[0]);
    itCliExtLevel(pfLevel);
    XOS_CliExtPrintf(pItCliEnv, "Route Filter[1]          : %x\r\n", pRouteCb->rtFilter[1]);
    itCliExtLevel(pfLevel);
    XOS_CliExtPrintf(pItCliEnv, "Route Mask[0]            : %x\r\n", pRouteCb->rtMask[0]);
    itCliExtLevel(pfLevel);
    XOS_CliExtPrintf(pItCliEnv, "Route Mask[1]            : %x\r\n", pRouteCb->rtMask[1]);
    itCliExtLevel(pfLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Routing Entry Configuration:");
    itDbgPrintfRteCfg(NowLevel+1, &(pRouteCb->rteCfg));
    itCliExtLevel(pfLevel);
    XOS_CliExtPrintf(pItCliEnv, "Owner of this entry PS ID: %d\r\n", pRouteCb->owner->psCfg.psId);
    /*
    itDbgPrintfOnePsCbk(0, pfLevel+1, pRouteCb->owner);
    */
    RETVOID;
}

PRIVATE VOID itDbgPrintfPsIdListCbk(U32 pfLevel, ItPsLstCb* PsLstCb)
{
    U32 NowLevel;
    ItPsLstCb* pPsLstCb;
    U32 uLoop;
    
    pPsLstCb = (ItPsLstCb*)NULLP;

    if ( (ItPsLstCb*)NULLP == PsLstCb )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DEB_ERR_STR_PSLISTINPUT);
        RETVOID;
    }
    else
    {
        pPsLstCb = PsLstCb;
        NowLevel = pfLevel;
    }

    itCliExtLevel(pfLevel);
    XOS_CliExtPrintf(pItCliEnv, "Indicates valid PsId Number: %d:\n", pPsLstCb->nmbPsCfged);
    itCliExtLevel(pfLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "List of PsID Free:");
    for ( uLoop=0; uLoop<pPsLstCb->nmbPsCfged; uLoop++)
    {
        itCliExtLevel(pfLevel);
        if ( TRUE == pPsLstCb->psIdFree[uLoop] )
        {
            XOS_CliExtPrintf(pItCliEnv, "    PS %d: TRUE", uLoop);
        }
        else
        {
            XOS_CliExtPrintf(pItCliEnv, "    PS %d: FALSE", uLoop);
        }
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
    }
    RETVOID;
}

PRIVATE VOID itDbgPrintfAspIdCbk(U32 pfLevel, ItAspIdCb* AspIdCb)
{
    U32 NowLevel;
    ItAspIdCb* pAspIdCb;
    U32 uLoop;
    
    pAspIdCb = (ItAspIdCb*)NULLP;

    if ( (ItAspIdCb*)NULLP == AspIdCb )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DEB_ERR_STR_ASPIDINPUT);
        RETVOID;
    }
    else
    {
        pAspIdCb = AspIdCb;
        NowLevel = pfLevel;
    }

    itCliExtLevel(pfLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Indicates valid AspId:");
    for ( uLoop=0; uLoop<LIT_MAX_PSP; uLoop++)
    {
        itCliExtLevel(pfLevel);
        if ( TRUE == pAspIdCb->aspIdValid[uLoop] )
        {
            XOS_CliExtPrintf(pItCliEnv, "    PSP ID %d: TRUE", uLoop);
            XOS_CliExtPrintf(pItCliEnv, "    Value:%d\r\n", pAspIdCb->aspIdLst[uLoop]);
        }
        else
        {
            XOS_CliExtPrintf(pItCliEnv, "    PSP ID %d: FALSE\r\n", uLoop);
        }
    }
    RETVOID;
}
/***************************************************************************
* Control block printf Functions End
***************************************************************************/


/***************************************************************************
* Configuration printf Functions Start
***************************************************************************/
#ifdef Configuration_Printf_Func
#endif
PRIVATE VOID itDbgPrintfGenCfg(U32 pfLevel, ItGenCfg* GenCfg)
{
    U32 NowLevel;
    ItGenCfg* pGenCfg;

    pGenCfg = (ItGenCfg*)NULLP;

    if ( (ItGenCfg*)NULLP == GenCfg )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_GENCFGINPUT);
        RETVOID;
    }
    else
    {
        pGenCfg = GenCfg;
        NowLevel = pfLevel;
    }
    
    itCliExtLevel(NowLevel);
    if ( LIT_TYPE_ASP == pGenCfg->nodeType )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Type of M3UA                            : ASP");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Type of M3UA                            : SGP");
    }
    itCliExtLevel(NowLevel);
    if ( TRUE == pGenCfg->dpcLrnFlag )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "DPC Learning Mode                       : TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "DPC Learning Mode                       : FALSE");
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of Upper SAPs                    : %d \r\n", pGenCfg->maxNmbNSap);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of Lower SAPs                    : %d \r\n", pGenCfg->maxNmbSctSap);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of Network Appearances           : %d \r\n", pGenCfg->maxNmbNwk);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of Routing Entries               : %d \r\n", pGenCfg->maxNmbRtEnt);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of DPC Entries                   : %d \r\n", pGenCfg->maxNmbDpcEnt);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of Peer Servers                  : %d \r\n", pGenCfg->maxNmbPs);
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of Local PS                      : %d \r\n", pGenCfg->maxNmbLps);
#endif
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of Peer Signalling Processes     : %d \r\n", pGenCfg->maxNmbPsp);  
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Max MTP3/M3UA messages in transit       : %d \r\n", pGenCfg->maxNmbMsg);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of Round Robin Loadshare contexts: %d \r\n", pGenCfg->maxNmbRndRbnLs);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of SLS based Loadshare contexts  : %d \r\n", pGenCfg->maxNmbSlsLs);
    itCliExtLevel(NowLevel);
    if ( TRUE == pGenCfg->drkmSupp )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "DRKM supported                          : TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "DRKM supported                          : FALSE");
    }
    itCliExtLevel(NowLevel);
    if ( TRUE == pGenCfg->drstSupp)
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "DRST supported                          : TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "DRST supported                          : FALSE");
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Congestion queue size in M3UA           : %d \r\n", pGenCfg->qSize);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Congestion level 1 in the queue         : %d \r\n", pGenCfg->congLevel1);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Congestion level 2 in the queue         : %d \r\n", pGenCfg->congLevel2);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Congestion level 3 in the queue         : %d \r\n", pGenCfg->congLevel3);
    
    itCliExtLevel(NowLevel);
    if ( TRUE == pGenCfg->tmr.tmrRestart.enb )
    {
        XOS_CliExtPrintf(pItCliEnv, "Restart hold-off time                   : %d \r\n", pGenCfg->tmr.tmrRestart.val);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Restart hold-off time                   : 0");
    }

    itCliExtLevel(NowLevel);
    if ( TRUE == pGenCfg->tmr.tmrMtp3Sta.enb )
    {
        XOS_CliExtPrintf(pItCliEnv, "MTP3 status poll time                   : %d \r\n", pGenCfg->tmr.tmrMtp3Sta.val);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "MTP3 status poll time                   : 0");
    }
    itCliExtLevel(NowLevel);
    if ( TRUE == pGenCfg->tmr.tmrAsPend.enb )
    {
        XOS_CliExtPrintf(pItCliEnv, "AS-PENDING time                         : %d \r\n", pGenCfg->tmr.tmrAsPend.val);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "AS-PENDING time                         : 0");
    }
    itCliExtLevel(NowLevel);
    if ( TRUE == pGenCfg->tmr.tmrHeartbeat.enb )
    {
        XOS_CliExtPrintf(pItCliEnv, "Heartbeat period                        : %d \r\n", pGenCfg->tmr.tmrHeartbeat.val);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Heartbeat period                            : 0");
    }
    itCliExtLevel(NowLevel);
    if ( TRUE == pGenCfg->tmr.tmrAspUp1.enb )
    {
        XOS_CliExtPrintf(pItCliEnv, "Initial time between ASPUP              : %d \r\n", pGenCfg->tmr.tmrAspUp1.val);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Initial time between ASPUP              : 0");
    }
    itCliExtLevel(NowLevel);
    if ( TRUE == pGenCfg->tmr.tmrAspUp2.enb )
    {
        XOS_CliExtPrintf(pItCliEnv, "Steady-state time between ASPUP         : %d \r\n", pGenCfg->tmr.tmrAspUp2.val);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Steady-state time between ASPUP         : 0");
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Initial number of ASPUP                 : %d \r\n", pGenCfg->tmr.nmbAspUp1);
    
    itCliExtLevel(NowLevel);
    if ( TRUE == pGenCfg->tmr.tmrAspDn.enb )
    {
        XOS_CliExtPrintf(pItCliEnv, "Time between ASPDN                      : %d \r\n", pGenCfg->tmr.tmrAspDn.val);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Time between ASPDN                      : 0");
    }
    itCliExtLevel(NowLevel);
    if ( TRUE == pGenCfg->tmr.tmrAspM.enb )
    {
        XOS_CliExtPrintf(pItCliEnv, "Timeout value for ASPM messages         : %d \r\n", pGenCfg->tmr.tmrAspM.val);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Timeout value for ASPM messages         : 0");
    }
    itCliExtLevel(NowLevel);
    if ( TRUE == pGenCfg->tmr.tmrDaud.enb )
    {
        XOS_CliExtPrintf(pItCliEnv, "Time between DAUD                       : %d \r\n", pGenCfg->tmr.tmrDaud.val);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Time between DAUD                       : 0");
    }
    itCliExtLevel(NowLevel);
    if ( TRUE == pGenCfg->tmr.tmrDrkm.enb )
    {
        XOS_CliExtPrintf(pItCliEnv, "Time between DRKM msgs                  : %d \r\n", pGenCfg->tmr.tmrDrkm.val);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Time between DRKM msgs                  : 0");
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Initial number of DRKM msgs             : %d \r\n", pGenCfg->tmr.maxNmbRkTry);

    itCliExtLevel(NowLevel);
    if ( TRUE == pGenCfg->tmr.tmrDunaSettle.enb )
    {
        XOS_CliExtPrintf(pItCliEnv, "Time to settle DUNA message             : %d \r\n", pGenCfg->tmr.tmrDunaSettle.val);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Time to settle DUNA message             : 0");
    }
    itCliExtLevel(NowLevel);
    if ( TRUE == pGenCfg->tmr.tmrSeqCntrl.enb )
    {
        XOS_CliExtPrintf(pItCliEnv, "Sequence Control timer                  : %d \r\n", pGenCfg->tmr.tmrSeqCntrl.val);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Sequence Control timer                  : 0");
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Timer resolution                        : %d \r\n", pGenCfg->timeRes);
    
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Stack manager post structure:");
    itDbgPrintfOnePstCbk(NowLevel+1, (Pst*)&(pGenCfg->smPst));
}

PRIVATE VOID itDbgPrintfOneNwkCfg( U32 pfLevel, ItNwkCfg* NwkCfg )
{
    U32 NowLevel;
    ItNwkCfg* pNwkCfg;
    U32 i;
    
    pNwkCfg = (ItNwkCfg*)NULLP;

    if ( (ItNwkCfg*)NULLP == NwkCfg )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NWKCFGINPUT);
        RETVOID;
    }
    else
    {
        pNwkCfg = NwkCfg;
        NowLevel = pfLevel;
    }
    
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Network ID                              : %d \r\n", pNwkCfg->nwkId);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Network Appearance Code: \r\n");
    for ( i=1; i<LIT_MAX_PSP; i++ )
    {
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "    PSP ID %d: NA=%d\r\n", i, pNwkCfg->nwkApp[i]);
    }

    itCliExtLevel(NowLevel);
    switch ( pNwkCfg->ssf)
    {
        case SSF_INTL:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Sub Service Field                       : International");
            break;
        }
        case SSF_SPARE:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Sub Service Field                       : Spare");
            break;
        }
        case SSF_NAT:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Sub Service Field                       : National");
            break;
        }
        case SSF_RES:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Sub Service Field                       : Reserved");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Sub Service Field                       : Error");
            break;
        }
    }

    itCliExtLevel(NowLevel);
    switch ( pNwkCfg->dpcLen )
    {
        case DPC14:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "DPC or OPC Length                       : DPC14");
            break;
        }
        case DPC24:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "DPC or OPC Length                       : DPC24");
            break;
        }
        case DPC_DEFAULT:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "DPC or OPC Length                       : DPC_DEFAULT");
            break;
        }
        case DPC16:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "DPC or OPC Length                       : DPC16");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "DPC or OPC Length                       : Error");
            break;
        }
    }

    itCliExtLevel(NowLevel);
    switch ( pNwkCfg->slsLen )
    {
        case LIT_SLS4:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "SLS Length                              : SLS4");
            break;
        }
        case LIT_SLS5:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "SLS Length                              : SLS5");
            break;
        }
        case LIT_SLS8:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "SLS Length                              : SLS8");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "SLS Length                              : Error");
            break;
        }
    }

    itCliExtLevel(NowLevel);
    switch ( pNwkCfg->suSwtch )
    {
        case LIT_SW_ANS:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Protocol variant of service user        : ANS");
            break;
        }
        case LIT_SW_ITU:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Protocol variant of service user        : ITU");
            break;
        }
        case LIT_SW_CHINA:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Protocol variant of service user        : CHINA");
            break;
        }
        case LIT_SW_BICI:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Protocol variant of service user        : BICI");
            break;
        }
        case LIT_SW_ANS96:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Protocol variant of service user        : ANS96");
            break;
        }
        case LIT_SW_TTC:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Protocol variant of service user        : TTC");
            break;
        }
        case LIT_SW_NTT:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Protocol variant of service user        : NTT");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Protocol variant of service user        : Error");
            break;
        }
    }

    itCliExtLevel(NowLevel);
    switch ( pNwkCfg->su2Swtch )
    {
        case LIT_SW2_UNUSED:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Protocol variant of user of service user: UNUSED");
            break;
        }
        case LIT_SW2_ITU:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Protocol variant of user of service user: ITU");
            break;
        }
        case LIT_SW2_ETS:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Protocol variant of user of service user: ETS");
            break;
        }
        case LIT_SW2_ANS:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Protocol variant of user of service user: ANS");
            break;
        }
        case LIT_SW2_TTC:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Protocol variant of user of service user: TTC");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Protocol variant of user of service user: Error");
            break;
        }
    }
}

PRIVATE VOID itDbgPrintfOneNsapCfg( U32 pfLevel, ItNSapCfg* NSapCfg )
{
    U32 NowLevel;
    ItNSapCfg* pNSapCfg;
    
    pNSapCfg = (ItNSapCfg*)NULLP;

    if ( (ItNSapCfg*)NULLP == NSapCfg )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NSAPCFGINPUT);
        RETVOID;
    }
    else
    {
        pNSapCfg = NSapCfg;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "NSAP ID                   : %d \r\n", pNSapCfg->sapId);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Logical Network ID        : %d \r\n", pNSapCfg->nwkId);

    itCliExtLevel(NowLevel);
    switch ( pNSapCfg->suType )
    {
        case LIT_SU_SCCP:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Service user protocol type: SCCP");
            break;
        }
        case LIT_SU_TUP:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Service user protocol type: TUP");
            break;
        }
        case LIT_SU_ISUP:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Service user protocol type: ISUP");
            break;
        }
        case LIT_SU_DUP:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Service user protocol type: DUP");
            break;
        }
        case LIT_SU_DUPF:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Service user protocol type: DUPF");
            break;
        }
        case LIT_SU_MTUP:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Service user protocol type: MTUP");
            break;
        }
        case LIT_SU_B_ISUP:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Service user protocol type: B_ISUP");
            break;
        }
        case LIT_SU_S_ISUP:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Service user protocol type: S_ISUP");
            break;
        }
        case LIT_SU_AAL2:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Service user protocol type: AAL2");
            break;
        }
        case LIT_SP_MTP3:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Service user protocol type: MTP3");
            break;
        }
        case LIT_SU_MGCP:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Service user protocol type: MGCP");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Service user protocol type: Error");
            break;
        }
    }
    
    itCliExtLevel(NowLevel);
    switch ( pNSapCfg->selector )
    {
        case 0:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Upper layer selector      : LOOSE");
            break;
        }
        case 1:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Upper layer selector      : TIGHT");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Upper layer selector      : Error");
            break;
        }
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Memory region and pool ID:");
    itDbgPrintfOneMemoryId(NowLevel+1, &(pNSapCfg->mem));

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Priority                  : %d \r\n", pNSapCfg->prior);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Route                     : %d \r\n", pNSapCfg->route);
#ifdef ITSG
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Lower SAP primitive timer:");
    itCliExtLevel(NowLevel);
    if ( TRUE == pNSapCfg->tmrPrim.enb )
    {
        XOS_CliExtPrintf(pItCliEnv, "    Enable: TRUE");
        XOS_CliExtPrintf(pItCliEnv, "    Value: %d \r\n", pNSapCfg->tmrPrim.val);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "    Enable: FALSE");
    }
    
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Processor ID              : %d \r\n", pNSapCfg->procId);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Entity                    : %d \r\n", pNSapCfg->ent);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Instance                  : %d \r\n", pNSapCfg->inst);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "MTP3 service provider ID  : %d \r\n", pNSapCfg->mtp3SapId);
#endif
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    itCliExtLevel(NowLevel);
    if ( TRUE == pNSapCfg->remIntfValid )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "    Remote interface version is valid: TRUE");
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "    Remote interface version         : %d \r\n", pNSapCfg->remIntfVer);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "    Remote interface version is valid: FALSE");
    }
#endif
}

PRIVATE VOID itDbgPrintfOneSctsapCfg( U32 pfLevel, ItSctSapCfg* SctSapCfg )
{
    U32 NowLevel;
    ItSctSapCfg* pSctSapCfg;
    U32 i;
    
    pSctSapCfg = (ItSctSapCfg*)NULLP;

    if ( (ItSctSapCfg*)NULLP == SctSapCfg )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NSAPCFGINPUT);
        RETVOID;
    }
    else
    {
        pSctSapCfg = SctSapCfg;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Service user SAP ID               : %d \r\n", pSctSapCfg->suId);
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Lower SAP primitive timer:");
    itCliExtLevel(NowLevel);
    if ( TRUE == pSctSapCfg->tmrPrim.enb )
    {
        XOS_CliExtPrintf(pItCliEnv, "    Enable: TRUE");
        XOS_CliExtPrintf(pItCliEnv, "    Value: %d \r\n", pSctSapCfg->tmrPrim.val);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "    Enable: FALSE");
    }
    
    
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Congestion poll time:");
    itCliExtLevel(NowLevel);
    if ( TRUE == pSctSapCfg->tmrSta.enb )
    {
        XOS_CliExtPrintf(pItCliEnv, "    Enable: TRUE");
        XOS_CliExtPrintf(pItCliEnv, "    Value: %d \r\n", pSctSapCfg->tmrSta.val);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "    Enable: FALSE");
    }
    

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Source port for listening endpoint: %d \r\n", pSctSapCfg->srcPort);
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Source address list:");
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "    Number of Network Addresses: %d \r\n", pSctSapCfg->srcAddrLst.nmb);
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "    List of Network Addresses:");
    
    for ( i = 0; i<pSctSapCfg->srcAddrLst.nmb; i++ )
    {
        if ( CM_NETADDR_IPV4 == pSctSapCfg->srcAddrLst.nAddr[i].type )
        {
            itCliExtLevel(NowLevel);
            XOS_CliExtPrintf(pItCliEnv, "        Network Addresses[%d] Type : IPV4\r\n", i);
            itCliExtLevel(NowLevel);
            XOS_CliExtPrintf(pItCliEnv, "        Network Addresses[%d] Value: %x\r\n", i, pSctSapCfg->srcAddrLst.nAddr[i].u.ipv4NetAddr);
        }
        else
        {
            itCliExtLevel(NowLevel);
            XOS_CliExtPrintf(pItCliEnv, "        Network Addresses[%d] Type : IPV6\r\n", i);
            itCliExtLevel(NowLevel);
            XOS_CliExtPrintf(pItCliEnv, "        Network Addresses[%d] Value: %s\r\n", i, pSctSapCfg->srcAddrLst.nAddr[i].u.ipv6NetAddr);
        }
    }
    
    itCliExtLevel(NowLevel);
    switch ( pSctSapCfg->selector )
    {
        case 0:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Selector for SCT                  : LOOSE");
            break;
        }
        case 1:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Selector for SCT                  : TIGHT");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Selector for SCT                  : Error");
            break;
        }
    }
    
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Memory region and pool ID:");
    itDbgPrintfOneMemoryId(NowLevel+1, &(pSctSapCfg->mem));
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Processor ID                      : %d \r\n", pSctSapCfg->procId);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Entity                            : %d \r\n", pSctSapCfg->ent);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Instance                          : %d \r\n", pSctSapCfg->inst);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Priority                          : %d \r\n", pSctSapCfg->prior);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Route                             : %d \r\n", pSctSapCfg->route);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Service provider ID               : %d \r\n", pSctSapCfg->spId);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    itCliExtLevel(NowLevel);
    if ( TRUE == pSctSapCfg->remIntfValid)
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "    Remote interface version is valid: TRUE");
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "    Remote interface version: %d \r\n", pSctSapCfg->remIntfVer);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "    Remote interface version is valid: FALSE");
    }
#endif
}


PRIVATE VOID itDbgPrintfOnePspCfg( U32 pfLevel, ItPspCfg* PspCfg )
{
    U32 NowLevel;
    ItPspCfg* pPspCfg;

    pPspCfg = (ItPspCfg*)NULLP;

    if ( (ItPspCfg*)NULLP == PspCfg )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPCFGINPUT);
        RETVOID;
    }
    else
    {
        pPspCfg = PspCfg;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "PSP ID                             : %d \r\n", pPspCfg->pspId);
    
    itCliExtLevel(NowLevel);
    switch ( pPspCfg->pspType )
    {
        case LIT_PSPTYPE_LOCAL:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "PSP client/server type             : LOCAL");
            break;
        }
        case LIT_PSPTYPE_ASP:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "PSP client/server type             : ASP");
            break;
        }
        case LIT_PSPTYPE_SGP:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "PSP client/server type             : SGP");
            break;
        }
        case LIT_PSPTYPE_IPSP:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "PSP client/server type             : IPSP");
            itCliExtLevel(NowLevel);
            switch ( pPspCfg->ipspMode )
            {
                case LIT_IPSPMODE_SE:
                {
                    XOS_CliExtWriteStrLine(pItCliEnv, "IPSP end type                      : Single ended");
                    break;
                }
                case LIT_IPSPMODE_DE:
                {
                    XOS_CliExtWriteStrLine(pItCliEnv, "IPSP end type                      : Double ended");
                    break;
                }
                default:
                {
                    XOS_CliExtWriteStrLine(pItCliEnv, "IPSP end type                      : Error");
                    break;
                }
            }
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "PSP client/server type             : Error");
            break;
        }
    }

    itCliExtLevel(NowLevel);
    if ( TRUE == pPspCfg->dynRegRkallwd )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "PSP is authorized for DRKM mesg    : TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "PSP is authorized for DRKM mesg    : FALSE");
    }

    itCliExtLevel(NowLevel);
    switch ( pPspCfg->dfltLshareMode )
    {
        case LIT_LOADSH_RNDROBIN:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Default mode for dynamic cfg of ps : RNDROBIN");
            break;
        }
        case LIT_LOADSH_SLS:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Default mode for dynamic cfg of ps : SLS");
            break;
        }
        case LIT_LOADSH_CIC:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Default mode for dynamic cfg of ps : CIC");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Default mode for dynamic cfg of ps : Error");
            break;
        }
    }

    itCliExtLevel(NowLevel);
    if ( TRUE == pPspCfg->nwkAppIncl )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Network Appearance flag            : TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Network Appearance flag            : FALSE");
    }

    itCliExtLevel(NowLevel);
    if ( TRUE == pPspCfg->rxTxAspId )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "ASP Id flag                        : TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "ASP Id flag                        : FALSE");
    }
    
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "ASP Id to be sent in ASP UP message: %d \r\n", pPspCfg->selfAspId);

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Default network ID                 : %d \r\n", pPspCfg->nwkId);

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Association configuration:");
    itDbgPrintfOneAssCfg(NowLevel+1, &(pPspCfg->assocCfg) );

#ifdef ITASP
    itCliExtLevel(NowLevel);
    if ( TRUE == pPspCfg->cfgForAllLps)
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Configure for all local PSs        : TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Configure for all local PSs        : FALSE");
    }
#ifdef SGVIEW
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "SG Id to which this PSP belongs    : %d \r\n", pPspCfg->sgId);
#endif /* SGVIEW */
#endif /* ITASP */
}

PRIVATE VOID itDbgPrintfOnePsCfg( U32 pfLevel, ItPsCfg* PsCfg )
{
    U32 NowLevel;
    ItPsCfg* pPsCfg;
    U32 i;
    
    pPsCfg = (ItPsCfg*)NULLP;

    if ( (ItPsCfg*)NULLP == PsCfg )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSCFGINPUT);
        RETVOID;
    }
    else
    {
        pPsCfg = PsCfg;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Network ID                        : %d \r\n", pPsCfg->nwkId);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Peer Server ID                    : %d \r\n", pPsCfg->psId);
    
    itCliExtLevel(NowLevel);
    switch ( pPsCfg->mode )
    {
        case LIT_MODE_ACTSTANDBY:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Active/Standby or load sharing    : ACTSTANDBY");
            break;
        }
        case LIT_MODE_LOADSHARE:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Active/Standby or load sharing    : LOADSHARE");
            break;
        }
        case LIT_MODE_BROADCAST:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Active/Standby or load sharing    : BROADCAST");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_MODETYPEINPUT);
            break;
        }
    }

    itCliExtLevel(NowLevel);
    if ( TRUE == pPsCfg->reqAvail )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Required for SPMC availability    : TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Required for SPMC availability    : FALSE");
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of active PSPs sharing load: %d \r\n", pPsCfg->nmbActPspReqd);

    itCliExtLevel(NowLevel);
    if ( TRUE == pPsCfg->lclFlag)
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "PS type is local if set           : TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "PS type is local if set           : FALSE");
        
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "Number of entries in PSP list     : %d \r\n", pPsCfg->nmbPsp);

        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "Ordered list of PSPs:\r\n");
        itCliExtLevel(NowLevel);
        for ( i=0; i<pPsCfg->nmbPsp; i++ )
        {
            XOS_CliExtPrintf(pItCliEnv, "    %d", pPsCfg->psp[i]);
        }
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Routing Context                   : %d \r\n", pPsCfg->routCtx);
}


PRIVATE VOID itDbgPrintfOneAssCfg( U32 pfLevel, ItAssocCfg* AssocCfg )
{
    U32 NowLevel;
    ItAssocCfg* pAssocCfg;
    U32 i;
    
    pAssocCfg = (ItAssocCfg*)NULLP;

    if ( (ItAssocCfg*)NULLP == AssocCfg )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_ASSCFGINPUT);
        RETVOID;
    }
    else
    {
        pAssocCfg = AssocCfg;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Primary destination address");
    if ( CM_NETADDR_IPV4 == pAssocCfg->priDstAddr.type )
    {
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "    Network Addresses Type : IPV4\r\n");
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "    Network Addresses Value: %x\r\n", pAssocCfg->priDstAddr.u.ipv4NetAddr);
    }
    else
    {
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "    Network Addresses Type : IPV6\r\n");
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "    Network Addresses Value: %s\r\n", pAssocCfg->priDstAddr.u.ipv6NetAddr);
    }


    
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Destination port           : %d \r\n", pAssocCfg->dstPort);
    
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Destination address list :");

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "    Number of Network Addresses: %d \r\n", pAssocCfg->dstAddrLst.nmb);
    for ( i = 0; i<pAssocCfg->dstAddrLst.nmb; i++ )
    {
        if ( CM_NETADDR_IPV4 == pAssocCfg->dstAddrLst.nAddr[i].type )
        {
            itCliExtLevel(NowLevel);
            XOS_CliExtPrintf(pItCliEnv, "    Network Addresses[%d] Type  : IPV4\r\n", i);
            itCliExtLevel(NowLevel);
            XOS_CliExtPrintf(pItCliEnv, "    Network Addresses[%d] Value : %x\r\n", i, pAssocCfg->dstAddrLst.nAddr[i].u.ipv4NetAddr);
        }
        else
        {
            itCliExtLevel(NowLevel);
            XOS_CliExtPrintf(pItCliEnv, "    Network Addresses[%d] Type  : IPV6\r\n", i);
            itCliExtLevel(NowLevel);
            XOS_CliExtPrintf(pItCliEnv, "    Network Addresses[%d] Value : %s\r\n", i,pAssocCfg->dstAddrLst.nAddr[i].u.ipv6NetAddr);
        }
    }
    
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "number of streams supported    : %d \r\n", pAssocCfg->locOutStrms);
#ifdef SCT3
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Type of service            : %d \r\n", pAssocCfg->tos);
#endif /* SCT3 */
}

PRIVATE VOID itDbgPrintfRteCfg( U32 pfLevel, ItRteCfg* RteCfg )
{
    U32 NowLevel;
    ItRteCfg* pRteCfg;
    
    pRteCfg = (ItRteCfg*)NULLP;

    if ( (ItRteCfg*)NULLP == RteCfg )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_RTECFGINPUT);
        RETVOID;
    }
    else
    {
        pRteCfg = RteCfg;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Network ID               : %d\r\n", RteCfg->nwkId);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Route Type               : ");
    switch ( RteCfg->rtType )
    {
        case LIT_RTTYPE_NOTFOUND:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "No route found");
            break;
        }
        case LIT_RTTYPE_LOCAL:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Route to a local user");
            break;
        }
        case LIT_RTTYPE_MTP3:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Route to SS7 via the MTP3");
            break;
        }
        case LIT_RTTYPE_PS:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Route to a Peer Server ");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Error");
            break;
        }
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UA routing filter:");
    itDbgPrintfRteFilter(NowLevel+1, &(RteCfg->rtFilter) );
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Peer Server ID           : %d\r\n", RteCfg->psId);
    itCliExtLevel(NowLevel);
    if ( TRUE == RteCfg->nSapIdPres )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Upper SAP ID present     : TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Upper SAP ID present     : FALSE");
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Upper SAP ID             : %d\r\n", RteCfg->nSapId);
    itCliExtLevel(NowLevel);
    if ( TRUE == RteCfg->noStatus)
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "TRUE if status suppressed: TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "TRUE if status suppressed: FALSE");
    }
    RETVOID;
}

PRIVATE VOID itDbgPrintfRteFilter( U32 pfLevel, ItRtFilter* RtFilter )
{
    U32 NowLevel;
    ItRtFilter* pRtFilter;
    
    pRtFilter = (ItRtFilter*)NULLP;

    if ( (ItRtFilter*)NULLP == RtFilter )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_RTECFGINPUT);
        RETVOID;
    }
    else
    {
        pRtFilter = RtFilter;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "DPC wildcard mask                 : %x\r\n", pRtFilter->dpcMask);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Destination Point Code            : %x\r\n", pRtFilter->dpc);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "OPC wildcard mask                 : %x\r\n", pRtFilter->opcMask);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Originator Point Code             : %x\r\n", pRtFilter->opc);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Link Selector wildcard mask       : %x\r\n", pRtFilter->slsMask);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Link Selector                     : %x\r\n", pRtFilter->sls);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "SIO wildcard mask                 : %x\r\n", pRtFilter->sioMask);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Service Identifier Octet          : %x\r\n", pRtFilter->sio);
    itCliExtLevel(NowLevel);
    if ( TRUE == pRtFilter->includeCic )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Include ISUP CIC in filter        : TRUE");
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "Start of CIC range                : %d\r\n", pRtFilter->cicStart);
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "End of CIC range                  : %d\r\n", pRtFilter->cicEnd);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Include ISUP CIC in filter        : FALSE");
    }

    itCliExtLevel(NowLevel);
    if ( TRUE == pRtFilter->includeSsn )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Include SCCP SSN in filter            : TRUE");
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "Subsystem Number                  : %d\r\n", pRtFilter->ssn);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Include SCCP SSN in filter        : FALSE");
    }

    itCliExtLevel(NowLevel);
    if ( TRUE == pRtFilter->includeTrid )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "IncludeTCAP TRID in filter        : TRUE");
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "Start of TCAP Transaction ID range: %d\r\n", pRtFilter->tridStart);
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "End of TCAP Transaction ID range  : %d\r\n", pRtFilter->tridEnd);
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Include TCAP TRID in filter       : FALSE");
    }
    RETVOID;
}
/***************************************************************************
* Configuration printf Functions End
***************************************************************************/


/***************************************************************************
* Satistics printf Functions Start
***************************************************************************/
#ifdef Satistics_Printf_Func
#endif

PRIVATE VOID itDbgPrintfGenSts(U32 pfLevel, ItGenSts* GenSts)
{
    U32 NowLevel;
    ItGenSts* pGenSts;
    
    pGenSts = (ItGenSts*)NULLP;

    if ( (ItGenSts*)NULLP == GenSts )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_GENSTSINPUT);
        RETVOID;
    }
    else
    {
        pGenSts = GenSts;
        NowLevel = pfLevel;
    }
    
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Date and time: ");
    itDbgPrintfOneDateTime(NowLevel+1, &(pGenSts->dt));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "MTP3 message statistics - TX: ");
    itDbgPrintfOneMtp3Sts(NowLevel+1, &(pGenSts->txMtp3Sts));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "MTP3 message statistics - RX: ");
    itDbgPrintfOneMtp3Sts(NowLevel+1, &(pGenSts->rxMtp3Sts));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UA message statistics - TX: ");
    itDbgPrintfOneM3uaSts(NowLevel+1, &(pGenSts->txM3uaSts));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "M3UA message statistics - RX: ");
    itDbgPrintfOneM3uaSts(NowLevel+1, &(pGenSts->rxM3uaSts));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Lower interface data statistics - TX: ");
    itDbgPrintfOneDataSts(NowLevel+1, &(pGenSts->liTxDataSts));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Lower interface data statistics - RX: ");
    itDbgPrintfOneDataSts(NowLevel+1, &(pGenSts->liRxDataSts));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Upper interface data statistics - TX: ");
    itDbgPrintfOneDataSts(NowLevel+1, &(pGenSts->uiTxDataSts));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Upper interface data statistics - RX: ");
    itDbgPrintfOneDataSts(NowLevel+1, &(pGenSts->uiRxDataSts));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Layer data error stats - downward: ");
    itDbgPrintfOneDataErrSts(NowLevel+1, &(pGenSts->downDataErrSts));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Layer data error statistics - upward: ");
    itDbgPrintfOneDataErrSts(NowLevel+1, &(pGenSts->upDataErrSts));
}

PRIVATE VOID itDbgPrintfOneNsapSts(U32 pfLevel, ItNSapSts* NSapSts)
{
    U32 NowLevel;
    ItNSapSts* pNSapSts;
    
    pNSapSts = (ItNSapSts*)NULLP;

    if ( (ItNSapSts*)NULLP == NSapSts )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NSAPSTSINPUT);
        RETVOID;
    }
    else
    {
        pNSapSts = NSapSts;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "NSAP Id: %d\r\n", pNSapSts->spId);
    
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Date and time: ");
    itDbgPrintfOneDateTime(NowLevel+1, &(pNSapSts->dt));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "MTP3 message statistics - TX: ");
    itDbgPrintfOneMtp3Sts(NowLevel+1, &(pNSapSts->txMtp3Sts));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "MTP3 message statistics - RX: ");
    itDbgPrintfOneMtp3Sts(NowLevel+1, &(pNSapSts->rxMtp3Sts));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "SAP data statistics - TX: ");
    itDbgPrintfOneDataSts(NowLevel+1, &(pNSapSts->txDataSts));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "SAP data statistics - RX: ");
    itDbgPrintfOneDataSts(NowLevel+1, &(pNSapSts->rxDataSts));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "SAP data error statistics - downward: ");
    itDbgPrintfOneDataErrSts(NowLevel+1, &(pNSapSts->dataErrSts));
}

PRIVATE VOID itDbgPrintfOneSctsapSts(U32 pfLevel, ItSctSapSts* SctSapSts)
{
    U32 NowLevel;
    ItSctSapSts* pSctSapSts;
    
    pSctSapSts = (ItSctSapSts*)NULLP;

    if ( (ItSctSapSts*)NULLP == SctSapSts )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_SCTSAPSTSINPUT);
        RETVOID;
    }
    else
    {
        pSctSapSts = SctSapSts;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Service user SAP Id: %d\r\n", pSctSapSts->suId);
    
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Date and time: ");
    itDbgPrintfOneDateTime(NowLevel+1, &(pSctSapSts->dt));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "SAP data statistics - TX: ");
    itDbgPrintfOneDataSts(NowLevel+1, &(pSctSapSts->txDataSts));

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "SAP data statistics - RX: ");
    itDbgPrintfOneDataSts(NowLevel+1, &(pSctSapSts->rxDataSts));
}

PRIVATE VOID itDbgPrintfOnePspSts(U32 pfLevel, ItPspSts* PspSts)
{
    U32 NowLevel;
    ItPspSts* pPspSts;
    U32 i;
    
    pPspSts = (ItPspSts*)NULLP;

    if ( (ItPspSts*)NULLP == PspSts )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPSTSINPUT);
        RETVOID;
    }
    else
    {
        pPspSts = PspSts;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "PSP ID: %d\r\n", pPspSts->pspId);
    
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Date and time: ");
    itDbgPrintfOneDateTime(NowLevel+1, &(pPspSts->dt));

    for ( i=0; i<LIT_MAX_SEP; i++)
    {
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "Association of Self End Points: %d\r\n", i);

        itCliExtLevel(NowLevel);
        XOS_CliExtWriteStrLine(pItCliEnv, "    M3UA message statistics - TX: ");
        itDbgPrintfOneM3uaSts(NowLevel+2, &(pPspSts->assocSts[i].txM3uaSts));

        itCliExtLevel(NowLevel);
        XOS_CliExtWriteStrLine(pItCliEnv, "    M3UA message statistics - RX: ");
        itDbgPrintfOneM3uaSts(NowLevel+2, &(pPspSts->assocSts[i].rxM3uaSts));

        itCliExtLevel(NowLevel);
        XOS_CliExtWriteStrLine(pItCliEnv, "    PSP data statistics - TX: ");
        itDbgPrintfOneDataSts(NowLevel+2, &(pPspSts->assocSts[i].txDataSts));

        itCliExtLevel(NowLevel);
        XOS_CliExtWriteStrLine(pItCliEnv, "    PSP data statistics - RX: ");
        itDbgPrintfOneDataSts(NowLevel+2, &(pPspSts->assocSts[i].rxDataSts));

        itCliExtLevel(NowLevel);
        XOS_CliExtWriteStrLine(pItCliEnv, "    PSP data error statistics - upward: ");
        itDbgPrintfOneDataErrSts(NowLevel+2, &(pPspSts->assocSts[i].dataErrSts));
#ifdef LITV3
        itCliExtLevel(NowLevel);
        XOS_CliExtWriteStrLine(pItCliEnv, "    Association unavailability statistics: ");
        itDbgPrintfOneUnavSts(NowLevel+2, &(pPspSts->assocSts[i].ItUnavSts));

        itCliExtLevel(NowLevel);
        XOS_CliExtWriteStrLine(pItCliEnv, "    Association congestion statistics: ");
        itDbgPrintfOneCongSts(NowLevel+2, &(pPspSts->assocSts[i].ItCongSts));
#endif /* LITV3 */
    }
    
}

PRIVATE VOID itDbgPrintfOneMtp3Sts(U32 pfLevel, ItMtp3Sts* Mtp3Sts)
{
    U32 NowLevel;
    ItMtp3Sts* pMtp3Sts;
    
    pMtp3Sts = (ItMtp3Sts*)NULLP;

    if ( (ItMtp3Sts*)NULLP == Mtp3Sts )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_MTP3STSINPUT);
        RETVOID;
    }
    else
    {
        pMtp3Sts = Mtp3Sts;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "MTP3 Data primitives              : %d\r\n", pMtp3Sts->data);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "MTP3 Pause status primitives      : %d\r\n", pMtp3Sts->pause);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "MTP3 Resume status primitives     : %d\r\n", pMtp3Sts->resume);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "MTP3 Cong status primitives       : %d\r\n", pMtp3Sts->cong);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "MTP3 Restrict status primitive    : %d\r\n", pMtp3Sts->drst);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "MTP3 Reset begin status primitives: %d\r\n", pMtp3Sts->rstBeg);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "MTP3 Reset end status primitives  : %d\r\n", pMtp3Sts->rstEnd);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "MTP3 UPU status primitives        : %d\r\n", pMtp3Sts->upu);
}

PRIVATE VOID itDbgPrintfOneM3uaSts(U32 pfLevel, ItM3uaSts* M3uaSts)
{
    U32 NowLevel;
    ItM3uaSts* pM3uaSts;
    
    pM3uaSts = (ItM3uaSts*)NULLP;

    if ( (ItM3uaSts*)NULLP == M3uaSts )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_M3UASTSINPUT);
        RETVOID;
    }
    else
    {
        pM3uaSts = M3uaSts;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA DATA messages     : %d\r\n", pM3uaSts->data);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA DAVA messages     : %d\r\n", pM3uaSts->dava);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA DAUD messages     : %d\r\n", pM3uaSts->daud);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA SCON messages     : %d\r\n", pM3uaSts->scon);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA DUPU messages     : %d\r\n", pM3uaSts->dupu);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA DRST messages     : %d\r\n", pM3uaSts->drst);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA REG-REQ messages  : %d\r\n", pM3uaSts->regReq);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA DEREG-REQ messages: %d\r\n", pM3uaSts->deRegReq);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA REG-RSP messages  : %d\r\n", pM3uaSts->regRsp);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA DEREG-RSP messages: %d\r\n", pM3uaSts->deRegRsp);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA ASPUP messages    : %d\r\n", pM3uaSts->aspUp);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA ASPUP ACK messages: %d\r\n", pM3uaSts->aspUpAck);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA ASPDN messages    : %d\r\n", pM3uaSts->aspDn);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA ASPDN ACK messages: %d\r\n", pM3uaSts->aspDnAck);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA ASPAC messages    : %d\r\n", pM3uaSts->aspAc);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA ASPAC ACK messages: %d\r\n", pM3uaSts->aspAcAck);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA ASPIA messages    : %d\r\n", pM3uaSts->aspIa);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA ASPIA ACK messages: %d\r\n", pM3uaSts->aspIaAck);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA HBEAT messages    : %d\r\n", pM3uaSts->hBeat);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA HBEAT ACK messages: %d\r\n", pM3uaSts->hBeatAck);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA ERR messages      : %d\r\n", pM3uaSts->err);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "M3UA NTFY messages     : %d\r\n", pM3uaSts->notify);
}

PRIVATE VOID itDbgPrintfOneDataSts(U32 pfLevel, ItDataSts* DataSts)
{
    U32 NowLevel;
    ItDataSts* pDataSts;
    
    pDataSts = (ItDataSts*)NULLP;

    if ( (ItDataSts*)NULLP == DataSts )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_DATASTSINPUT);
        RETVOID;
    }
    else
    {
        pDataSts = DataSts;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of PDUs    : %d\r\n", pDataSts->nPdus);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Total size of PDUs: %d\r\n", pDataSts->pduBytes);
}

PRIVATE VOID itDbgPrintfOneDataErrSts(U32 pfLevel, ItDataErrSts* DataErrSts)
{
    U32 NowLevel;
    ItDataErrSts* pDataErrSts;
    
    pDataErrSts = (ItDataErrSts*)NULLP;

    if ( (ItDataErrSts*)NULLP == DataErrSts )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_DATAERRASTSINPUT);
        RETVOID;
    }
    else
    {
        pDataErrSts = DataErrSts;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Data dropped, no route found      : %d\r\n", pDataErrSts->dropNoRoute);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Data dropped, point code unavail  : %d\r\n", pDataErrSts->dropPcUnavail);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Data dropped, point code congested: %d\r\n", pDataErrSts->dropPcCong);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Data dropped, no NSAP avail       : %d\r\n", pDataErrSts->dropNoNSapAvail);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Data dropped, no route found      : %d\r\n", pDataErrSts->dropNoRoute);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Data dropped, load-sharing failed : %d\r\n", pDataErrSts->dropLoadShFail);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Data dropped, M3UA message failed : %d\r\n", pDataErrSts->dropMmhFail);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Data queued in congestion queue   : %d\r\n", pDataErrSts->dataQCong);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Data queued in AS-PENDING queue   : %d\r\n", pDataErrSts->dataQAsPend);
}
#ifdef LITV3
PRIVATE VOID itDbgPrintfOneUnavSts(U32 pfLevel, ItUnavSts* UnavSts)
{
    U32 NowLevel;
    ItUnavSts* pUnavSts;
    
    pUnavSts = (ItUnavSts*)NULLP;

    if ( (ItUnavSts*)NULLP == UnavSts )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_UNVASTSINPUT);
        RETVOID;
    }
    else
    {
        pUnavSts = UnavSts;
        NowLevel = pfLevel;
    }

    itCliExtLevel(pfLevel);
    XOS_CliExtPrintf(pItCliEnv, "Association unavailable               : %d\r\n", pUnavSts->unav);
    itCliExtLevel(pfLevel);
    XOS_CliExtPrintf(pItCliEnv, "Duration of association unavailability: %d\r\n", pUnavSts->durUnav);
}

PRIVATE VOID itDbgPrintfOneCongSts(U32 pfLevel, ItCongSts* CongSts)
{
    U32 NowLevel;
    ItCongSts* pCongSts;
    
    pCongSts = (ItCongSts*)NULLP;

    if ( (ItCongSts*)NULLP == CongSts )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_CONGSTSINPUT);
        RETVOID;
    }
    else
    {
        pCongSts = CongSts;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Association congested             : %d\r\n", pCongSts->cong);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Association at congestion level 1 : %d\r\n", pCongSts->cong1);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Association at congestion level 2 : %d\r\n", pCongSts->cong2);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Association at congestion level 3 : %d\r\n", pCongSts->cong3);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Duration of association congestion: %d\r\n", pCongSts->durCong);
}
#endif

/***************************************************************************
* Satistics printf Functions End
***************************************************************************/


/***************************************************************************
* Status printf Functions Start
***************************************************************************/
#ifdef Status_Prinf_Func
#endif

PRIVATE VOID itDbgPrintfGenSta(U32 pfLevel, ItGenSta* GenSta)
{
    U32 NowLevel;
    ItGenSta* pGenSta;
    
    pGenSta = (ItGenSta*)NULLP;

    if ( (ItGenSta*)NULLP == GenSta )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_GENSTAINPUT);
        RETVOID;
    }
    else
    {
        pGenSta = GenSta;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Reserved memory size : %d\r\n", pGenSta->memSize);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Allocated memory size: %d\r\n", pGenSta->memAlloc);
}

PRIVATE VOID itDbgPrintfOneNsapSta(U32 pfLevel, ItNSapSta* NSapSta)
{
    U32 NowLevel;
    ItNSapSta* pNSapSta;
    
    pNSapSta = (ItNSapSta*)NULLP;

    if ( (ItNSapSta*)NULLP == NSapSta )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_NSAPSTAINPUT);
        RETVOID;
    }
    else
    {
        pNSapSta = NSapSta;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Local SAP Id                  : %d\r\n", pNSapSta->lclSapId);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Remote (MTP3/M3UA-User) SAP Id: %d\r\n", pNSapSta->remSapId);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "High level state              : ");
    switch (pNSapSta->hlSt)
    {
        case LIT_SAP_UNBOUND:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "SAP unbound");
            break;
        }
        case LIT_SAP_WAIT_BNDCFM:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Expect the bind confirm");
            break;
        }
        case LIT_SAP_BOUND:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "SAP bound");
            break;
        }
        case LIT_SAP_WAIT_OPENCFM:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Expect the endpoint open confirm");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Error");
            break;
        }
    }
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Self interface version        : %d\r\n", pNSapSta->selfIntfVer);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Remote interface valid        : %d\r\n", pNSapSta->remIntfValid);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Remote interface version      : %d\r\n", pNSapSta->remIntfVer);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
}

PRIVATE VOID itDbgPrintfOnePsendpSta(U32 pfLevel, ItPsStaEndp* PsStaEndp)
{
    U32 NowLevel;
    ItPsStaEndp* pPsStaEndp;
    U32 i;
    
    pPsStaEndp = (ItPsStaEndp*)NULLP;

    if ( (ItPsStaEndp*)NULLP == PsStaEndp )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSENDPSTAINPUT);
        RETVOID;
    }
    else
    {
        pPsStaEndp = PsStaEndp;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "PS's assoc states:");
    for (i=0; i<LIT_MAX_PSP; i++)
    {
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "    Asp Status[PSP ID:%d]=", i);
        switch ( pPsStaEndp->aspSt[i] )
        {
            case LIT_ASP_UNSUPP:
            {
                XOS_CliExtWriteStrLine(pItCliEnv, "Unsupported");
                break;
            }
            case LIT_ASP_DOWN:
            {
                XOS_CliExtWriteStrLine(pItCliEnv, "Down");
                break;
            }
            case LIT_ASP_INACTIVE:
            {
                XOS_CliExtWriteStrLine(pItCliEnv, "Inactive");
                break;
            }
            case LIT_ASP_ACTIVE:
            {
                XOS_CliExtWriteStrLine(pItCliEnv, "Active");
                break;
            }
            default:
            {
                XOS_CliExtWriteStrLine(pItCliEnv, "Error");
                break;
            }
        }
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "number of active assocs    : %d\r\n", pPsStaEndp->nmbAct);
    if ( 0 != pPsStaEndp->nmbAct )
    {
        itCliExtLevel(NowLevel);
        XOS_CliExtWriteStrLine(pItCliEnv, "List of active assocs:");
        itCliExtLevel(NowLevel);
        for (i=0; i<pPsStaEndp->nmbAct; i++)
        {
            XOS_CliExtPrintf(pItCliEnv, "    %d", pPsStaEndp->actPsp[i]);
        }
        XOS_CliExtWriteStrLine(pItCliEnv, " ");
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "number of registered assocs: %d\r\n", pPsStaEndp->nmbPspReg);
    for (i=0; i<pPsStaEndp->nmbPspReg; i++)
    {
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "    Registered assocs             : %d\r\n", i);
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "        Routing Context           : %d\r\n", pPsStaEndp->rteCtx[i].rCtx);
        itCliExtLevel(NowLevel);
        if ( TRUE == pPsStaEndp->rteCtx[i].rcValid )
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "        Routing context valid flag: TRUE");
        }
        else
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "        Routing context valid flag: FALSE");
        }
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "        Dynamically/Static        : %d\r\n", pPsStaEndp->rteCtx[i].mode);
    }
}

PRIVATE VOID itDbgPrintfOnePsSta(U32 pfLevel, ItPsSta* PsSta)
{
    U32 NowLevel;
    ItPsSta* pPsSta;
    U32 i;
    
    pPsSta = (ItPsSta*)NULLP;

    if ( (ItPsSta*)NULLP == PsSta )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSSTAINPUT);
        RETVOID;
    }
    else
    {
        pPsSta = PsSta;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Peer Server Id: %d\r\n", pPsSta->psId);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "PS's AS state : ");
    switch ( pPsSta->asSt )
    {
        case LIT_AS_UNKNOWN:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Unknown");
            break;
        }
        case LIT_AS_DOWN:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Down");
            break;
        }
        case LIT_AS_INACTIVE:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Inactive");
            break;
        }
        case LIT_AS_ACTIVE:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Active");
            break;
        }
        case LIT_AS_PENDING:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Pending");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Error");
            break;
        }
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "List  of PS status per End point:");
    for ( i=0; i<LIT_MAX_SEP; i++ )
    {
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "    PS status per End point: %d\r\n", i);
        itDbgPrintfOnePsendpSta(NowLevel+2, &(pPsSta->psStaEndp[i]));
    }
}

PRIVATE VOID itDbgPrintfOneAssocSta(U32 pfLevel, ItAssocSta* AssocSta)
{
    U32 NowLevel;
    ItAssocSta* pAssocSta;
    U32 i;
    
    pAssocSta = (ItAssocSta*)NULLP;

    if ( (ItAssocSta*)NULLP == AssocSta )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_ASSOCSTAINPUT);
        RETVOID;
    }
    else
    {
        pAssocSta = AssocSta;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Association Id           : %d\r\n", pAssocSta->spAssocId);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "High level state         : ");
    switch ( pAssocSta->hlSt )
    {
        case LIT_ASSOC_DOWN:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Down");
            break;
        }
        case LIT_ASSOC_ACTIVE:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Up");
            break;
        }
        case LIT_ASSOC_CONGSTART:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Started Flow Control");
            break;
        }
        case LIT_ASSOC_CONGDROP:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Dropping Data");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Error");
            break;
        }
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Ready Setup state       : ");
    switch ( pAssocSta->readySetupSt)
    {
        case LIT_RDST_DEFAULT:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Default");
            break;
        }
        case LIT_RDST_ASPUP:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, " Ready AspUp");
            break;
        }
        case LIT_RDST_ASPAC:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Ready AspUp");
            break;
        }
        case LIT_RDST_OK:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Ready OK");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Error");
            break;
        }
    }
    
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "PSP's ASP state          : ");
    switch ( pAssocSta->aspSt )
    {
        case LIT_ASP_UNSUPP:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Unsupported");
            break;
        }
        case LIT_ASP_DOWN:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Down");
            break;
        }
        case LIT_ASP_INACTIVE:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Inactive");
            break;
        }
        case LIT_ASP_ACTIVE:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Active");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Error");
            break;
        }
    }
    itCliExtLevel(NowLevel);
    if ( TRUE == pAssocSta->inhibited )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Management inhibit status: TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Management inhibit status: FALSE");
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of active PSs     : %d\r\n", pAssocSta->nmbAct);
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "List of active PSs: ");
    itCliExtLevel(NowLevel);
    for ( i=0; i<pAssocSta->nmbAct; i++ )
    {
        XOS_CliExtPrintf(pItCliEnv, "    %d", pAssocSta->actPs[i]);
    }
    XOS_CliExtWriteStrLine(pItCliEnv, " ");

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of registered PSs : %d\r\n", pAssocSta->nmbRegPs);
    
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Registered PSs List: ");
    itCliExtLevel(NowLevel);
    for ( i=0; i<pAssocSta->nmbRegPs; i++ )
    {
        XOS_CliExtPrintf(pItCliEnv, "    %d", pAssocSta->regPs[i]);
    }
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
}

PRIVATE VOID itDbgPrintfOnePspSta(U32 pfLevel, ItPspSta* PspSta)
{
    U32 NowLevel;
    ItPspSta* pPspSta;
    U32 i;
    
    pPspSta = (ItPspSta*)NULLP;

    if ( (ItPspSta*)NULLP == PspSta )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPSTAINPUT);
        RETVOID;
    }
    else
    {
        pPspSta = PspSta;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "PSP Id: %d\r\n", pPspSta->pspId);
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "Status of PSP's all associations:");
    for ( i=0; i<LIT_MAX_SEP; i++)
    {
        itCliExtLevel(NowLevel);
        XOS_CliExtPrintf(pItCliEnv, "    PSP Association %d status:\r\n", i);
        itDbgPrintfOneAssocSta(NowLevel+2, &(pPspSta->assocSta[i]));
    }
}

PRIVATE VOID itDbgPrintfOneSctSapSta(U32 pfLevel, ItSctSapSta* SctSapSta)
{
    U32 NowLevel;
    ItSctSapSta* pSctSapSta;
    
    pSctSapSta = (ItSctSapSta*)NULLP;

    if ( (ItSctSapSta*)NULLP == SctSapSta )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_SCTSAPSTAINPUT);
        RETVOID;
    }
    else
    {
        pSctSapSta = SctSapSta;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "SP ID                        : %d\r\n", pSctSapSta->spEndpId);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Service user SAP Id          : %d\r\n", pSctSapSta->suId);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "High level state             : ");
    switch (pSctSapSta->hlSt)
    {
        case LIT_SAP_UNBOUND:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "SAP unbound");
            break;
        }
        case LIT_SAP_WAIT_BNDCFM:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Expect the bind confirm");
            break;
        }
        case LIT_SAP_BOUND:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "SAP bound");
            break;
        }
        case LIT_SAP_WAIT_OPENCFM:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Expect the endpoint open confirm");
            break;
        }
        case LIT_SAP_READY:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "SCT SAP ready for use");
            break;
        }
        default:
        {
            XOS_CliExtWriteStrLine(pItCliEnv, "Error");
            break;
        }
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of active associations: %d\r\n", pSctSapSta->nmbActAssoc);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Self interface version       : %d\r\n", pSctSapSta->selfIntfVer);
    itCliExtLevel(NowLevel);
    if ( TRUE == pSctSapSta->remIntfValid )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Remote interface valid       : TRUE");
    }
    else
    {
        XOS_CliExtWriteStrLine(pItCliEnv, "Remote interface valid       : FALSE");
    }
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Remote interface version     : %d\r\n", pSctSapSta->remIntfVer);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
}

PRIVATE VOID itDbgPrintfAtSta(U32 pfLevel, ItAtSta* AtSta)
{
    U32 NowLevel;
    ItAtSta* pAtSta;
    
    pAtSta = (ItAtSta*)NULLP;

    if ( (ItAtSta*)NULLP == AtSta )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_ATSTAINPUT);
        RETVOID;
    }
    else
    {
        pAtSta = AtSta;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of entries in DPC table    : %d\r\n", pAtSta->nmbDpc);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of entries in routing table: %d\r\n", pAtSta->nmbRout);
}

PRIVATE VOID itDbgPrintfRkSta(U32 pfLevel, ItRkSta* RkSta)
{
    U32 NowLevel;
    ItRkSta* pRkSta;

    pRkSta = (ItRkSta*)NULLP;

    if ( (ItRkSta*)NULLP == RkSta )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_RKSTAINPUT);
        RETVOID;
    }
    else
    {
        pRkSta = RkSta;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Number of RK dynamically registered: %d\r\n", pRkSta->nmbRkReg);
}

PRIVATE VOID itDbgPrintfPspRkIdSta(U32 pfLevel, ItPspRkIdSta* PspRkIdSta)
{
    U32 NowLevel;
    ItPspRkIdSta* pPspRkIdSta;
    U32 i;

    pPspRkIdSta = (ItPspRkIdSta*)NULLP;

    if ( (ItPspRkIdSta*)NULLP == PspRkIdSta )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_PSPRKIDSTAINPUT);
        RETVOID;
    }
    else
    {
        pPspRkIdSta = PspRkIdSta;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "PSP Id                : %d\r\n", pPspRkIdSta->pspId);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "SCT SAP SU Id         : %d\r\n", pPspRkIdSta->sctSuId);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Nmb of RKs req pending: %d\r\n", pPspRkIdSta->nmbRkReqPend);
    itCliExtLevel(NowLevel);
    XOS_CliExtWriteStrLine(pItCliEnv, "RK-ids:");
    itCliExtLevel(NowLevel);
    for ( i=0; i<LIT_MAX_RK_IN_DRKM; i++ )
    {
        XOS_CliExtPrintf(pItCliEnv, "    %d", pPspRkIdSta->lclRkId[i]);
    }
    XOS_CliExtWriteStrLine(pItCliEnv, " ");
}

PRIVATE VOID itDbgPrintfDpcSta(U32 pfLevel, ItDpcSta* DpcSta)
{
    U32 NowLevel;
    ItDpcSta* pDpcSta;

    pDpcSta = (ItDpcSta*)NULLP;

    if ( (ItDpcSta*)NULLP == DpcSta )
    {
        XOS_CliExtWriteStrLine(pItCliEnv, IT_DBG_ERR_STR_DPCSTAINPUT);
        RETVOID;
    }
    else
    {
        pDpcSta = DpcSta;
        NowLevel = pfLevel;
    }

    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "Network Id          : %d\r\n", pDpcSta->nwkId);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "DPC value           : %d\r\n", pDpcSta->dpc);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "DPC status          : %d\r\n", pDpcSta->dpcSt);
    itCliExtLevel(NowLevel);
    XOS_CliExtPrintf(pItCliEnv, "DPC Congestion Level: %d\r\n", pDpcSta->congLevel);
}

/***************************************************************************
* Status printf Functions End
***************************************************************************/
#endif


/*added by wanglijun for set dbgmask from shell*/
#ifdef IT_DEBUGP
U32 g_itDbgMask = DBGMASK_LI|DBGMASK_UI|DBGMASK_MI;
#else
U32 g_itDbgMask = 0;
#endif

Void itSetDbgMaskFromShell(U32 dbgMask)
{
  g_itDbgMask = dbgMask;
#ifdef DEBUGP
  itGlobalCb.itInit.dbgMask = g_itDbgMask;
#endif
  RETVOID;
}




