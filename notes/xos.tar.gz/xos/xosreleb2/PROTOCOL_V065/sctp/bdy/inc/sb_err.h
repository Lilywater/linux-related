/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

     Name:     sb_err.h - Error Defines for  SCTP layer.

     Type:     C include file

     Desc:     defines for the SLogError type errors

     File:     sb_err.h

     Sid:      sb_err.h@@/main/3 - Wed Jan 10 16:24:32 2001

     Prg:      mrw

*********************************************************************21*/

#ifndef __SBERRH__
#define __SBERRH__

/*

*   sb_err.h -
*
*   Defines declared in this file correspond to defines used by the
*   following TRILLIUM software:
*     part no.                      description
*     --------    ----------------------------------------------
*     1000191                   SCTP
*/


/* macros */

#define SBLOGINVSEL \
        SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,            \
                  __FILE__, __LINE__,                                   \
                  ERRCLS_DEBUG, ESBXXX,                                 \
                  0, "Invalid selector");

#define SBLOGERROR(errCls, errCode, errVal, errDesc)                    \
        SLogError(sbGlobalCb.sbInit.ent, sbGlobalCb.sbInit.inst,        \
                  sbGlobalCb.sbInit.procId, __FILE__, __LINE__,         \
                  (ErrCls)errCls, (ErrCode)errCode,                     \
                  (ErrVal)errVal, errDesc)


/* defines */
#define   ESBBASE     0
#define   ESBXXX      (ESBBASE   +0)    /* reserved */

#define   ESB001      (ESBBASE +    1)    /*    sb_bdy1.c: 375 */
#define   ESB002      (ESBBASE +    2)    /*    sb_bdy1.c: 391 */
#define   ESB003      (ESBBASE +    3)    /*    sb_bdy1.c: 496 */
#define   ESB004      (ESBBASE +    4)    /*    sb_bdy1.c: 623 */
#define   ESB005      (ESBBASE +    5)    /*    sb_bdy1.c: 780 */
#define   ESB006      (ESBBASE +    6)    /*    sb_bdy1.c: 794 */
#define   ESB007      (ESBBASE +    7)    /*    sb_bdy1.c: 817 */
#define   ESB008      (ESBBASE +    8)    /*    sb_bdy1.c: 830 */
#define   ESB009      (ESBBASE +    9)    /*    sb_bdy1.c: 913 */
#define   ESB010      (ESBBASE +   10)    /*    sb_bdy1.c:1053 */
#define   ESB011      (ESBBASE +   11)    /*    sb_bdy1.c:1065 */
#define   ESB012      (ESBBASE +   12)    /*    sb_bdy1.c:1099 */
#define   ESB013      (ESBBASE +   13)    /*    sb_bdy1.c:1111 */
#define   ESB014      (ESBBASE +   14)    /*    sb_bdy1.c:1138 */
#define   ESB015      (ESBBASE +   15)    /*    sb_bdy1.c:1239 */
#define   ESB016      (ESBBASE +   16)    /*    sb_bdy1.c:1336 */
#define   ESB017      (ESBBASE +   17)    /*    sb_bdy1.c:1367 */
#define   ESB018      (ESBBASE +   18)    /*    sb_bdy1.c:1480 */
#define   ESB019      (ESBBASE +   19)    /*    sb_bdy1.c:1503 */
#define   ESB020      (ESBBASE +   20)    /*    sb_bdy1.c:1571 */
#define   ESB021      (ESBBASE +   21)    /*    sb_bdy1.c:1585 */
#define   ESB022      (ESBBASE +   22)    /*    sb_bdy1.c:1601 */
#define   ESB023      (ESBBASE +   23)    /*    sb_bdy1.c:1688 */
#define   ESB024      (ESBBASE +   24)    /*    sb_bdy1.c:1775 */
#define   ESB025      (ESBBASE +   25)    /*    sb_bdy1.c:1792 */
#define   ESB026      (ESBBASE +   26)    /*    sb_bdy1.c:1809 */
#define   ESB027      (ESBBASE +   27)    /*    sb_bdy1.c:1828 */
#define   ESB028      (ESBBASE +   28)    /*    sb_bdy1.c:1843 */
#define   ESB029      (ESBBASE +   29)    /*    sb_bdy1.c:1859 */
#define   ESB030      (ESBBASE +   30)    /*    sb_bdy1.c:1925 */
#define   ESB031      (ESBBASE +   31)    /*    sb_bdy1.c:2153 */
#define   ESB032      (ESBBASE +   32)    /*    sb_bdy1.c:2169 */
#define   ESB033      (ESBBASE +   33)    /*    sb_bdy1.c:2199 */
#define   ESB034      (ESBBASE +   34)    /*    sb_bdy1.c:2262 */
#define   ESB035      (ESBBASE +   35)    /*    sb_bdy1.c:2276 */
#define   ESB036      (ESBBASE +   36)    /*    sb_bdy1.c:2390 */
#define   ESB037      (ESBBASE +   37)    /*    sb_bdy1.c:2533 */
#define   ESB038      (ESBBASE +   38)    /*    sb_bdy1.c:2546 */
#define   ESB039      (ESBBASE +   39)    /*    sb_bdy1.c:2597 */
#define   ESB040      (ESBBASE +   40)    /*    sb_bdy1.c:2614 */
#define   ESB041      (ESBBASE +   41)    /*    sb_bdy1.c:2790 */
#define   ESB042      (ESBBASE +   42)    /*    sb_bdy1.c:2804 */
#define   ESB043      (ESBBASE +   43)    /*    sb_bdy1.c:2822 */
#define   ESB044      (ESBBASE +   44)    /*    sb_bdy1.c:2906 */
#define   ESB045      (ESBBASE +   45)    /*    sb_bdy1.c:2920 */
#define   ESB046      (ESBBASE +   46)    /*    sb_bdy1.c:2943 */
#define   ESB047      (ESBBASE +   47)    /*    sb_bdy1.c:3075 */
#define   ESB048      (ESBBASE +   48)    /*    sb_bdy1.c:3091 */
#define   ESB049      (ESBBASE +   49)    /*    sb_bdy1.c:3111 */
#define   ESB050      (ESBBASE +   50)    /*    sb_bdy1.c:3152 */
#define   ESB051      (ESBBASE +   51)    /*    sb_bdy1.c:3347 */
#define   ESB052      (ESBBASE +   52)    /*    sb_bdy1.c:3365 */
#define   ESB053      (ESBBASE +   53)    /*    sb_bdy1.c:3383 */
#define   ESB054      (ESBBASE +   54)    /*    sb_bdy1.c:3477 */
#define   ESB055      (ESBBASE +   55)    /*    sb_bdy1.c:3549 */
#define   ESB056      (ESBBASE +   56)    /*    sb_bdy1.c:3567 */
#define   ESB057      (ESBBASE +   57)    /*    sb_bdy1.c:3603 */
#define   ESB058      (ESBBASE +   58)    /*    sb_bdy1.c:3645 */
#define   ESB059      (ESBBASE +   59)    /*    sb_bdy1.c:3722 */
#define   ESB060      (ESBBASE +   60)    /*    sb_bdy1.c:3851 */
#define   ESB061      (ESBBASE +   61)    /*    sb_bdy1.c:3880 */
#define   ESB062      (ESBBASE +   62)    /*    sb_bdy1.c:3898 */
#define   ESB063      (ESBBASE +   63)    /*    sb_bdy1.c:3911 */
#define   ESB064      (ESBBASE +   64)    /*    sb_bdy1.c:3939 */
#define   ESB065      (ESBBASE +   65)    /*    sb_bdy1.c:3953 */
#define   ESB066      (ESBBASE +   66)    /*    sb_bdy1.c:3985 */
#define   ESB067      (ESBBASE +   67)    /*    sb_bdy1.c:4034 */
#define   ESB068      (ESBBASE +   68)    /*    sb_bdy1.c:4121 */
#define   ESB069      (ESBBASE +   69)    /*    sb_bdy1.c:4139 */
#define   ESB070      (ESBBASE +   70)    /*    sb_bdy1.c:4251 */
#define   ESB071      (ESBBASE +   71)    /*    sb_bdy1.c:4326 */
#define   ESB072      (ESBBASE +   72)    /*    sb_bdy1.c:4350 */
#define   ESB073      (ESBBASE +   73)    /*    sb_bdy1.c:4525 */
#define   ESB074      (ESBBASE +   74)    /*    sb_bdy1.c:4540 */
#define   ESB075      (ESBBASE +   75)    /*    sb_bdy1.c:4568 */
#define   ESB076      (ESBBASE +   76)    /*    sb_bdy1.c:4588 */

#define   ESB077      (ESBBASE +   77)    /*    sb_bdy2.c: 240 */
#define   ESB078      (ESBBASE +   78)    /*    sb_bdy2.c: 289 */
#define   ESB079      (ESBBASE +   79)    /*    sb_bdy2.c: 370 */
#define   ESB080      (ESBBASE +   80)    /*    sb_bdy2.c: 378 */
#define   ESB081      (ESBBASE +   81)    /*    sb_bdy2.c: 410 */
#define   ESB082      (ESBBASE +   82)    /*    sb_bdy2.c: 465 */
#define   ESB083      (ESBBASE +   83)    /*    sb_bdy2.c: 486 */
#define   ESB084      (ESBBASE +   84)    /*    sb_bdy2.c: 540 */
#define   ESB085      (ESBBASE +   85)    /*    sb_bdy2.c: 560 */
#define   ESB086      (ESBBASE +   86)    /*    sb_bdy2.c: 584 */
#define   ESB087      (ESBBASE +   87)    /*    sb_bdy2.c: 641 */
#define   ESB088      (ESBBASE +   88)    /*    sb_bdy2.c: 649 */
#define   ESB089      (ESBBASE +   89)    /*    sb_bdy2.c: 667 */
#define   ESB090      (ESBBASE +   90)    /*    sb_bdy2.c: 693 */
#define   ESB091      (ESBBASE +   91)    /*    sb_bdy2.c: 717 */
#define   ESB092      (ESBBASE +   92)    /*    sb_bdy2.c: 736 */
#define   ESB093      (ESBBASE +   93)    /*    sb_bdy2.c: 756 */
#define   ESB094      (ESBBASE +   94)    /*    sb_bdy2.c: 811 */
#define   ESB095      (ESBBASE +   95)    /*    sb_bdy2.c: 823 */
#define   ESB096      (ESBBASE +   96)    /*    sb_bdy2.c: 852 */
#define   ESB097      (ESBBASE +   97)    /*    sb_bdy2.c: 862 */
#define   ESB098      (ESBBASE +   98)    /*    sb_bdy2.c: 941 */
#define   ESB099      (ESBBASE +   99)    /*    sb_bdy2.c: 948 */
#define   ESB100      (ESBBASE +  100)    /*    sb_bdy2.c:1068 */
#define   ESB101      (ESBBASE +  101)    /*    sb_bdy2.c:1124 */
#define   ESB102      (ESBBASE +  102)    /*    sb_bdy2.c:1131 */
#define   ESB103      (ESBBASE +  103)    /*    sb_bdy2.c:1255 */
#define   ESB104      (ESBBASE +  104)    /*    sb_bdy2.c:1327 */
#define   ESB105      (ESBBASE +  105)    /*    sb_bdy2.c:1334 */
#define   ESB106      (ESBBASE +  106)    /*    sb_bdy2.c:1345 */
#define   ESB107      (ESBBASE +  107)    /*    sb_bdy2.c:1495 */
#define   ESB108      (ESBBASE +  108)    /*    sb_bdy2.c:1564 */
#define   ESB109      (ESBBASE +  109)    /*    sb_bdy2.c:1571 */
#define   ESB110      (ESBBASE +  110)    /*    sb_bdy2.c:1640 */
#define   ESB111      (ESBBASE +  111)    /*    sb_bdy2.c:1647 */
#define   ESB112      (ESBBASE +  112)    /*    sb_bdy2.c:1664 */
#define   ESB113      (ESBBASE +  113)    /*    sb_bdy2.c:1676 */
#define   ESB114      (ESBBASE +  114)    /*    sb_bdy2.c:1697 */
#define   ESB115      (ESBBASE +  115)    /*    sb_bdy2.c:1715 */
#define   ESB116      (ESBBASE +  116)    /*    sb_bdy2.c:1740 */
#define   ESB117      (ESBBASE +  117)    /*    sb_bdy2.c:1756 */
#define   ESB118      (ESBBASE +  118)    /*    sb_bdy2.c:1814 */
#define   ESB119      (ESBBASE +  119)    /*    sb_bdy2.c:1821 */
#define   ESB120      (ESBBASE +  120)    /*    sb_bdy2.c:1878 */
#define   ESB121      (ESBBASE +  121)    /*    sb_bdy2.c:1942 */
#define   ESB122      (ESBBASE +  122)    /*    sb_bdy2.c:2053 */
#define   ESB123      (ESBBASE +  123)    /*    sb_bdy2.c:2065 */
#define   ESB124      (ESBBASE +  124)    /*    sb_bdy2.c:2091 */
#define   ESB125      (ESBBASE +  125)    /*    sb_bdy2.c:2165 */
#define   ESB126      (ESBBASE +  126)    /*    sb_bdy2.c:2172 */
#define   ESB127      (ESBBASE +  127)    /*    sb_bdy2.c:2288 */
#define   ESB128      (ESBBASE +  128)    /*    sb_bdy2.c:2295 */
#define   ESB129      (ESBBASE +  129)    /*    sb_bdy2.c:2344 */
#define   ESB130      (ESBBASE +  130)    /*    sb_bdy2.c:2356 */
#define   ESB131      (ESBBASE +  131)    /*    sb_bdy2.c:2381 */
#define   ESB132      (ESBBASE +  132)    /*    sb_bdy2.c:2472 */
#define   ESB133      (ESBBASE +  133)    /*    sb_bdy2.c:2504 */
#define   ESB134      (ESBBASE +  134)    /*    sb_bdy2.c:2528 */
#define   ESB135      (ESBBASE +  135)    /*    sb_bdy2.c:2554 */
#define   ESB136      (ESBBASE +  136)    /*    sb_bdy2.c:2595 */
#define   ESB137      (ESBBASE +  137)    /*    sb_bdy2.c:2627 */
#define   ESB138      (ESBBASE +  138)    /*    sb_bdy2.c:2651 */
#define   ESB139      (ESBBASE +  139)    /*    sb_bdy2.c:2714 */
#define   ESB140      (ESBBASE +  140)    /*    sb_bdy2.c:2724 */
#define   ESB141      (ESBBASE +  141)    /*    sb_bdy2.c:2759 */
#define   ESB142      (ESBBASE +  142)    /*    sb_bdy2.c:2778 */
#define   ESB143      (ESBBASE +  143)    /*    sb_bdy2.c:3088 */
#define   ESB144      (ESBBASE +  144)    /*    sb_bdy2.c:3103 */
#define   ESB145      (ESBBASE +  145)    /*    sb_bdy2.c:3137 */
#define   ESB146      (ESBBASE +  146)    /*    sb_bdy2.c:3177 */
#define   ESB147      (ESBBASE +  147)    /*    sb_bdy2.c:3256 */
#define   ESB148      (ESBBASE +  148)    /*    sb_bdy2.c:3266 */
#define   ESB149      (ESBBASE +  149)    /*    sb_bdy2.c:3276 */
#define   ESB150      (ESBBASE +  150)    /*    sb_bdy2.c:3391 */
#define   ESB151      (ESBBASE +  151)    /*    sb_bdy2.c:3401 */
#define   ESB152      (ESBBASE +  152)    /*    sb_bdy2.c:3466 */
#define   ESB153      (ESBBASE +  153)    /*    sb_bdy2.c:3492 */
#define   ESB154      (ESBBASE +  154)    /*    sb_bdy2.c:3552 */
#define   ESB155      (ESBBASE +  155)    /*    sb_bdy2.c:3562 */
#define   ESB156      (ESBBASE +  156)    /*    sb_bdy2.c:3658 */
#define   ESB157      (ESBBASE +  157)    /*    sb_bdy2.c:3719 */
#define   ESB158      (ESBBASE +  158)    /*    sb_bdy2.c:3729 */
#define   ESB159      (ESBBASE +  159)    /*    sb_bdy2.c:3825 */
#define   ESB160      (ESBBASE +  160)    /*    sb_bdy2.c:3835 */
#define   ESB161      (ESBBASE +  161)    /*    sb_bdy2.c:3847 */
#define   ESB162      (ESBBASE +  162)    /*    sb_bdy2.c:3859 */
#define   ESB163      (ESBBASE +  163)    /*    sb_bdy2.c:3908 */
#define   ESB164      (ESBBASE +  164)    /*    sb_bdy2.c:3979 */
#define   ESB165      (ESBBASE +  165)    /*    sb_bdy2.c:4041 */
#define   ESB166      (ESBBASE +  166)    /*    sb_bdy2.c:4464 */
#define   ESB167      (ESBBASE +  167)    /*    sb_bdy2.c:4489 */
#define   ESB168      (ESBBASE +  168)    /*    sb_bdy2.c:5274 */
#define   ESB169      (ESBBASE +  169)    /*    sb_bdy2.c:5330 */

#define   ESB170      (ESBBASE +  170)    /*    sb_bdy3.c: 241 */
#define   ESB171      (ESBBASE +  171)    /*    sb_bdy3.c:1136 */
#define   ESB172      (ESBBASE +  172)    /*    sb_bdy3.c:1156 */
#define   ESB173      (ESBBASE +  173)    /*    sb_bdy3.c:1209 */
#define   ESB174      (ESBBASE +  174)    /*    sb_bdy3.c:1226 */
#define   ESB175      (ESBBASE +  175)    /*    sb_bdy3.c:1251 */
#define   ESB176      (ESBBASE +  176)    /*    sb_bdy3.c:1535 */
#define   ESB177      (ESBBASE +  177)    /*    sb_bdy3.c:1590 */
#define   ESB178      (ESBBASE +  178)    /*    sb_bdy3.c:1650 */
#define   ESB179      (ESBBASE +  179)    /*    sb_bdy3.c:2558 */
#define   ESB180      (ESBBASE +  180)    /*    sb_bdy3.c:2579 */
#define   ESB181      (ESBBASE +  181)    /*    sb_bdy3.c:2667 */
#define   ESB182      (ESBBASE +  182)    /*    sb_bdy3.c:2942 */
#define   ESB183      (ESBBASE +  183)    /*    sb_bdy3.c:3154 */
#define   ESB184      (ESBBASE +  184)    /*    sb_bdy3.c:3200 */
#define   ESB185      (ESBBASE +  185)    /*    sb_bdy3.c:3237 */
#define   ESB186      (ESBBASE +  186)    /*    sb_bdy3.c:3263 */
#define   ESB187      (ESBBASE +  187)    /*    sb_bdy3.c:3295 */
#define   ESB188      (ESBBASE +  188)    /*    sb_bdy3.c:3316 */
#define   ESB189      (ESBBASE +  189)    /*    sb_bdy3.c:3347 */
#define   ESB190      (ESBBASE +  190)    /*    sb_bdy3.c:3537 */
#define   ESB191      (ESBBASE +  191)    /*    sb_bdy3.c:3563 */
#define   ESB192      (ESBBASE +  192)    /*    sb_bdy3.c:3675 */
#define   ESB193      (ESBBASE +  193)    /*    sb_bdy3.c:3846 */
#define   ESB194      (ESBBASE +  194)    /*    sb_bdy3.c:4052 */
#define   ESB195      (ESBBASE +  195)    /*    sb_bdy3.c:7462 */
#define   ESB196      (ESBBASE +  196)    /*    sb_bdy3.c:7494 */
#define   ESB197      (ESBBASE +  197)    /*    sb_bdy3.c:7521 */
#define   ESB198      (ESBBASE +  198)    /*    sb_bdy3.c:8994 */
#define   ESB199      (ESBBASE +  199)    /*    sb_bdy3.c:9360 */
#define   ESB200      (ESBBASE +  200)    /*    sb_bdy3.c:9483 */
#define   ESB201      (ESBBASE +  201)    /*    sb_bdy3.c:9616 */
#define   ESB202      (ESBBASE +  202)    /*    sb_bdy3.c:9839 */
#define   ESB203      (ESBBASE +  203)    /*    sb_bdy3.c:9945 */
#define   ESB204      (ESBBASE +  204)    /*    sb_bdy3.c:10208 */
#define   ESB205      (ESBBASE +  205)    /*    sb_bdy3.c:10546 */
#define   ESB206      (ESBBASE +  206)    /*    sb_bdy3.c:10618 */
#define   ESB207      (ESBBASE +  207)    /*    sb_bdy3.c:11193 */
#define   ESB208      (ESBBASE +  208)    /*    sb_bdy3.c:11226 */
#define   ESB209      (ESBBASE +  209)    /*    sb_bdy3.c:11253 */
#define   ESB210      (ESBBASE +  210)    /*    sb_bdy3.c:11343 */
#define   ESB211      (ESBBASE +  211)    /*    sb_bdy3.c:11608 */
#define   ESB212      (ESBBASE +  212)    /*    sb_bdy3.c:11726 */
#define   ESB213      (ESBBASE +  213)    /*    sb_bdy3.c:11840 */
#define   ESB214      (ESBBASE +  214)    /*    sb_bdy3.c:11920 */
#define   ESB215      (ESBBASE +  215)    /*    sb_bdy3.c:12068 */

#define   ESB216      (ESBBASE +  216)    /*    sb_bdy4.c: 224 */
#define   ESB217      (ESBBASE +  217)    /*    sb_bdy4.c: 231 */
#define   ESB218      (ESBBASE +  218)    /*    sb_bdy4.c: 240 */
#define   ESB219      (ESBBASE +  219)    /*    sb_bdy4.c: 247 */
#define   ESB220      (ESBBASE +  220)    /*    sb_bdy4.c: 254 */
#define   ESB221      (ESBBASE +  221)    /*    sb_bdy4.c: 261 */
#define   ESB222      (ESBBASE +  222)    /*    sb_bdy4.c: 268 */
#define   ESB223      (ESBBASE +  223)    /*    sb_bdy4.c: 275 */
#define   ESB224      (ESBBASE +  224)    /*    sb_bdy4.c: 282 */
#define   ESB225      (ESBBASE +  225)    /*    sb_bdy4.c: 289 */
#define   ESB226      (ESBBASE +  226)    /*    sb_bdy4.c: 340 */
#define   ESB227      (ESBBASE +  227)    /*    sb_bdy4.c: 608 */
#define   ESB228      (ESBBASE +  228)    /*    sb_bdy4.c: 616 */
#define   ESB229      (ESBBASE +  229)    /*    sb_bdy4.c: 624 */
#define   ESB230      (ESBBASE +  230)    /*    sb_bdy4.c: 631 */
#define   ESB231      (ESBBASE +  231)    /*    sb_bdy4.c: 643 */
#define   ESB232      (ESBBASE +  232)    /*    sb_bdy4.c: 651 */
#define   ESB233      (ESBBASE +  233)    /*    sb_bdy4.c: 660 */
#define   ESB234      (ESBBASE +  234)    /*    sb_bdy4.c: 669 */
#define   ESB235      (ESBBASE +  235)    /*    sb_bdy4.c: 677 */
#define   ESB236      (ESBBASE +  236)    /*    sb_bdy4.c: 714 */
#define   ESB237      (ESBBASE +  237)    /*    sb_bdy4.c: 774 */
#define   ESB238      (ESBBASE +  238)    /*    sb_bdy4.c: 781 */
#define   ESB239      (ESBBASE +  239)    /*    sb_bdy4.c: 789 */
#define   ESB240      (ESBBASE +  240)    /*    sb_bdy4.c: 797 */
#define   ESB241      (ESBBASE +  241)    /*    sb_bdy4.c: 810 */
#define   ESB242      (ESBBASE +  242)    /*    sb_bdy4.c: 817 */
#define   ESB243      (ESBBASE +  243)    /*    sb_bdy4.c: 895 */
#define   ESB244      (ESBBASE +  244)    /*    sb_bdy4.c:1319 */
#define   ESB245      (ESBBASE +  245)    /*    sb_bdy4.c:1420 */
#define   ESB246      (ESBBASE +  246)    /*    sb_bdy4.c:1611 */
#define   ESB247      (ESBBASE +  247)    /*    sb_bdy4.c:1629 */
#define   ESB248      (ESBBASE +  248)    /*    sb_bdy4.c:1647 */
#define   ESB249      (ESBBASE +  249)    /*    sb_bdy4.c:1675 */
#define   ESB250      (ESBBASE +  250)    /*    sb_bdy4.c:1752 */
#define   ESB251      (ESBBASE +  251)    /*    sb_bdy4.c:1829 */
#define   ESB252      (ESBBASE +  252)    /*    sb_bdy4.c:1873 */
#define   ESB253      (ESBBASE +  253)    /*    sb_bdy4.c:1929 */
#define   ESB254      (ESBBASE +  254)    /*    sb_bdy4.c:1942 */
#define   ESB255      (ESBBASE +  255)    /*    sb_bdy4.c:1955 */
#define   ESB256      (ESBBASE +  256)    /*    sb_bdy4.c:1962 */
#define   ESB257      (ESBBASE +  257)    /*    sb_bdy4.c:2028 */
#define   ESB258      (ESBBASE +  258)    /*    sb_bdy4.c:2041 */
#define   ESB259      (ESBBASE +  259)    /*    sb_bdy4.c:2116 */
#define   ESB260      (ESBBASE +  260)    /*    sb_bdy4.c:2129 */
#define   ESB261      (ESBBASE +  261)    /*    sb_bdy4.c:2142 */
#define   ESB262      (ESBBASE +  262)    /*    sb_bdy4.c:2371 */
#define   ESB263      (ESBBASE +  263)    /*    sb_bdy4.c:2666 */
#define   ESB264      (ESBBASE +  264)    /*    sb_bdy4.c:2985 */
#define   ESB265      (ESBBASE +  265)    /*    sb_bdy4.c:3139 */
#define   ESB266      (ESBBASE +  266)    /*    sb_bdy4.c:3221 */
#define   ESB267      (ESBBASE +  267)    /*    sb_bdy4.c:3246 */
#define   ESB268      (ESBBASE +  268)    /*    sb_bdy4.c:3276 */

#define   ESB269      (ESBBASE +  269)    /*   sb_ex_ms.c: 257 */
#define   ESB270      (ESBBASE +  270)    /*   sb_ex_ms.c: 301 */
#define   ESB271      (ESBBASE +  271)    /*   sb_ex_ms.c: 341 */
#define   ESB272      (ESBBASE +  272)    /*   sb_ex_ms.c: 357 */

#define   ESB273      (ESBBASE +  273)    /*     sb_mtu.c: 170 */
#define   ESB274      (ESBBASE +  274)    /*     sb_mtu.c: 176 */
#define   ESB275      (ESBBASE +  275)    /*     sb_mtu.c: 233 */
#define   ESB276      (ESBBASE +  276)    /*     sb_mtu.c: 251 */
#define   ESB277      (ESBBASE +  277)    /*     sb_mtu.c: 257 */
#define   ESB278      (ESBBASE +  278)    /*     sb_mtu.c: 263 */
#define   ESB279      (ESBBASE +  279)    /*     sb_mtu.c: 269 */
#define   ESB280      (ESBBASE +  280)    /*     sb_mtu.c: 336 */
#define   ESB281      (ESBBASE +  281)    /*     sb_mtu.c: 343 */
#define   ESB282      (ESBBASE +  282)    /*     sb_mtu.c: 350 */
#define   ESB283      (ESBBASE +  283)    /*     sb_mtu.c: 356 */
#define   ESB284      (ESBBASE +  284)    /*     sb_mtu.c: 363 */
#define   ESB285      (ESBBASE +  285)    /*     sb_mtu.c: 407 */
#define   ESB286      (ESBBASE +  286)    /*     sb_mtu.c: 461 */
#define   ESB287      (ESBBASE +  287)    /*     sb_mtu.c: 473 */
#define   ESB288      (ESBBASE +  288)    /*     sb_mtu.c: 497 */
#define   ESB289      (ESBBASE +  289)    /*     sb_mtu.c: 521 */
#define   ESB290      (ESBBASE +  290)    /*     sb_mtu.c: 604 */
#define   ESB291      (ESBBASE +  291)    /*     sb_mtu.c: 618 */
#define   ESB292      (ESBBASE +  292)    /*     sb_mtu.c: 625 */
#define   ESB293      (ESBBASE +  293)    /*     sb_mtu.c: 631 */
#define   ESB294      (ESBBASE +  294)    /*     sb_mtu.c: 638 */
#define   ESB295      (ESBBASE +  295)    /*     sb_mtu.c: 681 */
#define   ESB296      (ESBBASE +  296)    /*     sb_mtu.c: 739 */
#define   ESB297      (ESBBASE +  297)    /*     sb_mtu.c: 751 */
#define   ESB298      (ESBBASE +  298)    /*     sb_mtu.c: 775 */
#define   ESB299      (ESBBASE +  299)    /*     sb_mtu.c: 787 */
#define   ESB300      (ESBBASE +  300)    /*     sb_mtu.c: 807 */
#define   ESB301      (ESBBASE +  301)    /*     sb_mtu.c: 862 */
#define   ESB302      (ESBBASE +  302)    /*     sb_mtu.c: 874 */
#define   ESB303      (ESBBASE +  303)    /*     sb_mtu.c: 892 */
#define   ESB304      (ESBBASE +  304)    /*     sb_mtu.c: 945 */
#define   ESB305      (ESBBASE +  305)    /*     sb_mtu.c: 957 */
#define   ESB306      (ESBBASE +  306)    /*     sb_mtu.c: 975 */
#define   ESB307      (ESBBASE +  307)    /*     sb_mtu.c:1031 */
#define   ESB308      (ESBBASE +  308)    /*     sb_mtu.c:1043 */
#define   ESB309      (ESBBASE +  309)    /*     sb_mtu.c:1049 */
#define   ESB310      (ESBBASE +  310)    /*     sb_mtu.c:1062 */
#define   ESB311      (ESBBASE +  311)    /*     sb_mtu.c:1081 */
#define   ESB312      (ESBBASE +  312)    /*     sb_mtu.c:1323 */

#define   ESB313      (ESBBASE +  313)    /*    sb_ptli.c: 491 */
#define   ESB314      (ESBBASE +  314)    /*    sb_ptli.c: 542 */
#define   ESB315      (ESBBASE +  315)    /*    sb_ptli.c: 596 */
#define   ESB316      (ESBBASE +  316)    /*    sb_ptli.c: 648 */

#define   ESB317      (ESBBASE +  317)    /*    sb_ptmi.c: 555 */
#define   ESB318      (ESBBASE +  318)    /*    sb_ptmi.c: 594 */
#define   ESB319      (ESBBASE +  319)    /*    sb_ptmi.c: 633 */
#define   ESB320      (ESBBASE +  320)    /*    sb_ptmi.c: 673 */
#define   ESB321      (ESBBASE +  321)    /*    sb_ptmi.c: 713 */
#define   ESB322      (ESBBASE +  322)    /*    sb_ptmi.c: 752 */

#define   ESB323      (ESBBASE +  323)    /*    sb_ptui.c:1121 */
#define   ESB324      (ESBBASE +  324)    /*    sb_ptui.c:1156 */
#define   ESB325      (ESBBASE +  325)    /*    sb_ptui.c:1192 */
#define   ESB326      (ESBBASE +  326)    /*    sb_ptui.c:1228 */
#define   ESB327      (ESBBASE +  327)    /*    sb_ptui.c:1271 */
#define   ESB328      (ESBBASE +  328)    /*    sb_ptui.c:1316 */
#define   ESB329      (ESBBASE +  329)    /*    sb_ptui.c:1353 */
#define   ESB330      (ESBBASE +  330)    /*    sb_ptui.c:1389 */
#define   ESB331      (ESBBASE +  331)    /*    sb_ptui.c:1430 */
#define   ESB332      (ESBBASE +  332)    /*    sb_ptui.c:1471 */
#define   ESB333      (ESBBASE +  333)    /*    sb_ptui.c:1514 */
#define   ESB334      (ESBBASE +  334)    /*    sb_ptui.c:1559 */
#define   ESB335      (ESBBASE +  335)    /*    sb_ptui.c:1596 */
/* Patch sb031.102 IPV6 Support Added */
#define   ESB336      (ESBBASE +  336)    /*    sb_bdy4.c:232 */
/* Patch sb057.102 Error code for Multiple Procs */
#define   ESB337      (ESBBASE +  337)     /*    sb_bdy1.c:344 */


#endif /* __SBERRH__ */

/********************************************************************30**

         End of file:     sb_err.h@@/main/3 - Wed Jan 10 16:24:32 2001

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/3      ---      mrw   1.Initial version
 /main/3     ---      sb    1. Modified for SCTP release based on 
                             RFC-2960 'Oct 2000.
           sb031.102  hm    1. IPV6 Support Added
           sb057.102  pr    1. Error code for multiple procs added.
*********************************************************************91*/
