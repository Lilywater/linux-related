/* ***************************************************************************
 *        (c) COPYRIGHT 1995-2006 by Xinwei, Inc.
 *                   All rights reserved.
 *
 * sb_common.h:  
 *          this head file include all about use of sctp.
 *           
 * Author:
 *          zhouguishuang
 * Date:
 *          2006-5-8
 * Last Modified:
 *
 ****************************************************************************/
#ifndef  __SB_COMMONH__
#define  __SB_COMMONH__

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_inet.h"       /* common network address */
#include "cm_tpt.h"        /* common transport defines */
#include "cm_dns.h"      /* common DNS library */
#ifdef SB_FTHA
#include "sht.h"           /* SHT Interface header file */
#endif /* SB_FTHA */
#include "lsb.h"           /* layer management, SCTP  */
#include "sct.h"           /* SCT interface */
#include "hit.h"           /* HIT interface */
#include "sb.h"            /* SCTP internal defines */
#include "sb_err.h"        /* SCTP error */

/* header/extern include files (.x) */
/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_inet.x"       /* common network address */
#include "cm_tpt.x"        /* common transport address */
#include "cm_dns.x"        /* common DNS */
#include "sb_mtu.h"        /* mtu defines */
#include "sb_mtu.x"        /* mtu typedefs */
#include "sb_port.x"       /* sb_port typedefs */
#include "sct.x"           /* SCT interface */
#include "lsb.x"           /* layer management SCTP */
#include "hit.x"           /* HIT interface */
#include "sb.x"            /* sctp layer typedefs */

#include "sb_dbg.h"
#include "sb_cfg.h"

#define  DEF_ENT                    0
#define  SEL_TC                     1
#define  SEL_LC                     0
#define  SB_PRNTBUF_SIZE            255

#define  SAP_1                      1
#define  SAP_2                      2
#define  SAP_3                      3
#define  SAP_4                      4
#define  SAP_5                      5
#define  SAP_6                      6
#define  SAP_7                      7
#define  SAP_8                      8
#define  SAP_9                      9
#define  SAP_10                     10
#define  SAP_11                     11
#define  SAP_12                     12

#define     SUID_0                  0
#define     SUID_1                  1
#define     SUID_2                  2
#define     SUID_3                  3
#define     SUID_4                  4
#define     SUID_5                  5
#define     SUID_6                  6
#define     SUID_7                  7
#define     SUID_8                  8
#define     SUID_9                  9
#define     SUID_10                 10
#define     SUID_11                 11


#define     SPID_0                  0
#define     SPID_1                  1
#define     SPID_2                  2
#define     SPID_3                  3
#define     SPID_4                  4
#define     SPID_5                  5
#define     SPID_6                  6
#define     SPID_7                  7
#define     SPID_8                  8
#define     SPID_9                  9

#define ACC_MTU_INIT            1024     /* size of MTU in octets */
#define ACC_ARWND_INIT          4096
#define ACC_RTO_INIT            150      /* initial value of RTO */

#define ASSOC_1                 10             /* Referring to association 1 */
#define ASSOC_2                 11             /* Referring to association 2 */
#define ASSOC_3                 12             /* Referring to association 3 */
/* sb046.102: Multiple IP address per Endp */
#define ASSOC_4                 13             /* Referring to association 4 */
#define ASSOC_5                 14             /* Referring to association 4 */


/* Public variable declarations */
#ifdef SS_MULTIPLE_PROCS
extern PUBLIC SbGlobalCb sbGlobalCbLst[SB_MAX_INSTANCES];
extern PUBLIC SbGlobalCb *sbGlobalCbPtr;
#else
extern PUBLIC SbGlobalCb  sbGlobalCb;  /* SCTP control block */
#endif /* SS_MULTIPLE_PROCS */


#define SB_SETUP_CMNETADDR(dAddr, sAddr)  /* initialize a network address */     \
{                                                                                \
   cmMemcpy((U8*)&dAddr.u.ipv4NetAddr, (U8*)&sAddr, CM_IPV4ADDR_SIZE); \
   dAddr.type = CM_TPTADDR_IPV4;                                                \
}

#define SB_SETUP_SCTNETADDRLST(dAddr, sAddr)  /* initialize a tranport address */    \
{                                                                                     \
   dAddr.nmb = 5;                                                                    \
   for(i = 0; (i < dAddr.nmb); ++i)  {                                               \
     dAddr.nAddr[i].type = CM_TPTADDR_IPV4;  /* IPV4 addresses  */                   \
     dAddr.nAddr[i].u.ipv4NetAddr = sAddr[i];                                        \
   }                                                                                 \
}

#define SB_SETUP_CMTPTADDR(dAddr, sAddr, inPort)  /* initialize a tranport address */  \
{                                                                                    \
   /* sb058.102 : Changed to remove compilation warning */ \
   cmMemcpy((U8*)&dAddr.u.ipv4TptAddr.address, (U8*)&sAddr, CM_IPV4ADDR_SIZE); \
   dAddr.type = CM_TPTADDR_IPV4;      /* IPV4 addresses  */                          \
   dAddr.u.ipv4TptAddr.port = inPort;                                              \
}


#endif  /* __SB_COMMONH__ */
