#ifndef __HI_INITH__
#define __HI_INITH__

PUBLIC S16 sb_init_fun(void);
PUBLIC S16 sb_init_own(SSTskId sbTskId1);

#endif  /*__HI_INITH__*/