/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**

     Name:     SCTP Layer

     Type:     C include file

     Desc:     Defines required by SCTP

     File:     sb.h

     Sid:      sb.h@@/main/2 - Wed Jan 10 16:24:21 2001

     Prg:      bk,wvdl

*********************************************************************21*/

#ifndef __SBH__
#define __SBH__


/* sb042.102 - Added dependency checks for rolling upgrade */
#ifdef SB_RUG
#ifndef TDS_ROLL_UPGRADE_SUPPORT
#error "SB_RUG cannot be defined without TDS_ROLL_UPGRADE_SUPPORT"
#endif
#ifndef SB_FTHA
#error "SB_FTHA flag must be defined for rolling upgrade, please enable"
#endif
#endif /* SB_RUG */

/* Layer name */
#define SBLAYERNAME     "SCTP_LAYER"

#ifdef SS_MULTIPLE_PROCS
#ifndef SB_MAX_INSTANCES
#define SB_MAX_INSTANCES 1
#endif
#define sbGlobalCb (*sbGlobalCbPtr)
#endif  /* SS_MULTIPLE_PROCS */


/* unused type */
#define SB_UNUSED                   0
/* Additions for Cookie preserve calculations */
#define SB_MSEC_IN_TICK             100  /* Number of milliseconds in a tick */
#define SB_COOKIE_PRESERVE_REQUEST  1000  /* Number of ms to add to a cookie stale error
                                             when requesting new cookie */

/* Assigned TUCL port numbers */
#define SB_UDP_PORT                 9899       /* UDP tunneling */
#define SB_SCTP_PORT                0       /* 0 Raw IP */
#define SB_PORT_ANY                 0           /* ANY PORT */
#define SB_MIN_REG_PORT             1024        /* first non 'well known port' */

/* Maximum value that a received cumulative TSN may be behind the expected
 * value for it to be accepted as non-duplicate */
#define SB_MAX_TSN_DIFF             0x3fffffffL    /* 1/4 of SctTSN range */

#define SB_MAX_HOLE_CNT             3

/* Status codes */
#define SB_RESULT_NOT_APPL          1          /* not applicable result */
#define SB_RESULT_ASSOC_INACTIVE    2          /* association marked inactive */
#define SB_RESULT_PATH_INACTIVE     3          /* path marked inactive */

/* Chunk IDs */
#define SB_ID_DATA                  0x00  /* Payload Data             */
#define SB_ID_INIT                  0x01  /* Initiation               */
#define SB_ID_INITACK               0x02  /* Initiation
                                           * Acknowledgement          */
#define SB_ID_SACK                  0x03  /* Selective
                                           * Acknowledgement          */
#define SB_ID_HBEAT                 0x04  /* Heartbeat Request        */
#define SB_ID_HBEATACK              0x05  /* Heartbeat Request
                                           * Acknowledgement          */
#define SB_ID_ABORT                 0x06  /* Abort                    */
#define SB_ID_SDOWN                 0x07  /* Shutdown                 */
#define SB_ID_SDOWNACK              0x08  /* Shutdown Acknowledgement */
#define SB_ID_ERROR                 0x09  /* Operation Error          */
#define SB_ID_COOKIE                0x0a  /* Encryption Cookie        */
#define SB_ID_COOKIEACK             0x0b  /* Encryption Cookie
                                           * Acknowledgement          */
#define SB_ID_ECNE                  0x0c  /* Explicit Congestion
                                           * Notification Echo        */
#define SB_ID_CWR                   0x0d  /* Congestion window
                                           * reduced                  */
#define SB_ID_VSPEC                 0xfe  /* Vendor Specific
                                           * Extensions               */
#define SB_ID_IETF                  0xff  /* IETF Defined Extensions  */

#define SB_ID_SDOWNCMPLT            0x0e   /* Shutdown Completer      */


/* Chunk parameter IDs */
#define SB_ID_PAR_IPV4              0x05       /* IPV4 address */
#define SB_ID_PAR_IPV6              0x06       /* IPV6 address */
#define SB_ID_PAR_COOKIE            0x07       /* encryption cookie */
#define SB_ID_PAR_UNRECOG           0x08       /* unrecognized parameter */
#define SB_ID_PAR_COOKIE_PRESERVE   0x09       /* cookie preservative */
#define SB_ID_PAR_ECN               0x8000     /* ECN capable */
#define SB_ID_PAR_HSTNAME_ADDR      0xb       /* HostName Address */
#define SB_ID_PAR_SUP_ADDRS         0xc       /* Supported Address  */
#define SB_SUP_ADDRS_IPV4           5
#define SB_SUP_ADDRS_IPV6           6
#define SB_SUP_ADDRS_HSTNAME        11

/* Chunk parameter lengths */
#define SB_SZ_PAR_COOKIE_PRESERVE   8       /* cookie preservative */
#define SB_SZ_PAR_IPV6              20      /* IPV6 address */
#define SB_SZ_PAR_IPV4              8       /* IPV4 address */

/* SAP states */
#define SB_SAPSTATE_BND               1
#define SB_SAPSTATE_UBND              0

/* SbSctAssocCb.state : State of the association */
#define SB_ST_CLOSED          SCT_ASSOC_STATE_CLOSED       /* No association active or
                                                            * open                       */
#define SB_ST_OPEN            SCT_ASSOC_STATE_OPEN         /* Association is capable of
                                                            * receiving associations     */
#define SB_ST_COOKIE_WAIT     SCT_ASSOC_STATE_COOKIE_WAIT  /* Awaiting Cookie in INIT_ACK
                                                            * message                    */
#define SB_ST_ESTABLISHED     SCT_ASSOC_STATE_ESTABLISHED  /* Association ready for 2 way
                                                            * communication              */
#define SB_ST_COOKIE_SENT     SCT_ASSOC_STATE_COOKIE_SENT  /* Cookie has been sent.
                                                            * Awaiting COOKIE_ACK
                                                            * message                    */
#define SB_ST_SDOWN_PEND      SCT_ASSOC_STATE_SDOWN_PEND   /* Received Shutdown request
                                                            * from service user          */
#define SB_ST_SDOWN_SENT      SCT_ASSOC_STATE_SDOWN_SENT   /* Sent SHUTDOWN message,
                                                            * awaiting SHUTDOWN_ACK      */
#define SB_ST_SDOWN_RCVD      SCT_ASSOC_STATE_SDOWN_RCVD   /* Received a SHUTDOWN message
                                                            * awaiting outstanding data to
                                                            * be acknowledged            */
#define SB_ST_SDOWNACK_SENT   SCT_ASSOC_STATE_SDOWNACK_SENT /* Send shutdown Ack messages & 
                                                            * waiting for Shutdown complete */

#define SB_ST_AWTDNS_RSP_COOKIE     SCT_ASSOC_STATE_AWTDNS_RSP_COOKIE   /* Send Query to DNS server
                                                                         * and  wait  for Rsponse */

#define SB_ST_AWTDNS_RSP_COOKIEACK  SCT_ASSOC_STATE_AWTDNS_RSP_COOKIEACK /* Send Query to DNS server
                                                                          * and  awaiting  response */


/* SbQueuedChunk.qState : Queue */
#define SB_DB_TSNWAITINGQ     0x0       /* Queue for data chunks that
                                         * are waiting on the rwnd and
                                         * cwnd for TSN assignment    */
#define SB_DB_CONGESTIONQ     0x1       /* Queue for data chunks that
                                         * are waiting on the peer
                                         * acknowledgement of the
                                         * data                       */
#define SB_DB_ASSEMBLYQ       0x2       /* Queue for data chunks that
                                         * are waiting on all the
                                         * segments for reassembly into
                                         * a single data chunk        */
#define SB_DB_SEQUENCEDQ      0x3       /* Queue for data chunks that
                                         * are waiting on other data
                                         * chunks so that sequencial
                                         * delivery of data is
                                         * possible                   */
#define SB_DB_NUMQUEUES       0x4       /* Number of Database queues  */
#define SB_DB_INVALQ          0xff      /* Invalid queues             */


/* Timer Defines */
/* sb015.102: Timer queue size in increased */
#define SB_TQSIZE             201       /* Size of the Timer Queue in
                                         * the Global CB              */
#define SB_GEN_TMRS           0x4       /* Number of timers that are
                                         * started in the Global CB   */
#define SB_ASSOC_TMRS         0x4       /* Number of timers per
                                         * associations               */
#define SB_TSAP_TMRS          0x4       /* Number of timers per TSAP  */
/* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
#define SB_IPV6STR_SIZE       50
#endif

/* Timer Constants */
#define SB_TMR_LIFETIME       0x0       /* Lifetime timer             */
#define SB_TMR_T3RTX          0x1       /* T3-rxt timer               */
#define SB_TMR_ACKDELAY       0x2       /* ackDelay timer             */
#define SB_TMR_SHUTDOWN       0x3       /* Shutdown timer             */
#define SB_TMR_INIT           0x4       /* Init retransmit Timer      */
#define SB_TMR_COOKIE         0x5       /* Cookie retransmit Timer    */
#define SB_TMR_HBEAT          0x6       /* Heatbeat timeout timer     */
#define SB_TMR_KEY            0x7       /* Generate next Key          */
#define SB_TMR_TSAP_BND       0x8       /* Single TSAP Bind Timeout   */
#define SB_TMR_FREEZE         0x9       /* Freeze timer               */
#define SB_TMR_MTU_INC        0xa       /* Increment the MTU size     */
#define SB_TMR_MTU_INC_UP     0xb       /* Increment the MTU maximum  */
#define SB_TMR_SHUTDOWNACK    0xc       /* Shutdown-Ack timer         */
#define SB_TMR_AWT_DNS_RSP    0xd       /* DNS Query Awt response timer */
/* sb054.102 : Addition - Bundling Changes */
#ifdef LSB4
#define SB_TMR_BUNDLE         0xe       /* Bundling timer             */
#endif /* LSB4 */


/* Error message types for the Sequential Delivery within Streams FB  */
#define SB_SQ_ERR_INSTRM      0x0       /* Invalid incoming stream
                                         * number                     */
#define SB_SQ_ERR_OUTSTRM     0x1       /* Invalid outgoing stream
                                         * number                     */
#define SB_SQ_ERR_QUEUE       0x2       /* Error inserting chunk into
                                         * queue                      */
#define SB_SQ_ERR_SG          0x3       /* Segmentation FB Error      */
#define SB_SQ_ERR_DATIND      0x4       /* Error sending the
                                         * SbUiSctDatInd primitive    */

/* Size defines */
#define SB_MAX_LEN            1024      /* Maximum size for a static array
                                           that can be packed into a buffer */

/* sb044.102: Maximum retry attempt after disconnect received */
#define MAX_CON_RETRY_ATTMPT    5       /* Try to open server these many times
                                           once it gets a disconnect indication */

#define SB_IFL_SZ             4         /* 4 bytes for chunk ID/Flags/Length */


#define SB_TSN_LST            0xff      /* Size of TSN list to keep
                                         * track of data chunks that
                                         * have arrived from the peer */

#define SB_IP_HEADER_SIZE     20        /* IP header size */
#define SB_UDP_HEADER_SIZE    8         /* UDP header size */

#define SB_COMMON_HEADER_SIZE 12        /* SCTP common header size */

/*#define SB_CHUNK_HEADER_SIZE  20*/
#define SB_CHUNK_HEADER_SIZE  4         /* Chunk header size (TLV info size) */

/* Minimum allowable chunk sizes minus the chunk ID, flags and length fields */
#define SB_INIT_MIN_SIZE      16        /* minimum allowable size for an
                                         * INIT chunk (20 octets)     */

#define SB_SACK_MIN_SIZE      12        /* minimum allowable size for a
                                         * SACK chunk excl. chunk header */

#define SB_DATA_MIN_SIZE      12        /* minimum allowable size for a
                                           DATA chunk excl. chunk header */


#define SB_INIT_ACK_MIN_SIZE  16        /* minimum allowable size for an
                                           INIT ACK chunk */

#define SB_ERROR_STRM_LNGTH    4        /* length of stream error chunk */

#define SB_ERROR_PARAM_LNGTH   4        /* length of missing parameter error
                                           chunk */

#define SB_ERROR_RES_LNGTH     0        /* length of resource error chunk */

#define SB_ERROR_STALE_LNGTH   4        /* length of stale cookie error
                                           chunk */

/* Hash defines for DNS Module */

/* Defines for dnsState */
#define SB_DNS_SERV_CLOSED    0
#define SB_DNS_SERV_OPEN      1

/* Defines for maximum possible request list for DNS module */
#define SB_DNS_RQSTLST_SZ   1024


/* Type of random Number generator to use */
#define SB_RAND_GEN           0x0


/* Error Chunk Cause code */
#define SB_CHUNK_ERROR_STREAM 0x1       /* Invalid stream identifier  */
#define SB_CHUNK_ERROR_PARAM  0x2       /* Missing mandatory
                                         * parameter                  */
#define SB_CHUNK_ERROR_STALE  0x3       /* The cookie arrived too
                                         * late                       */
#define SB_CHUNK_ERROR_RES    0x4       /* Out of resources           */


#define SB_CHUNK_ERROR_UNRSLV_ADDR    0x5 /* Unresolvable Address   */
#define SB_CHUNK_ERROR_UNRECOG_CHUNK  0x6 /* Unrecognize Chunk   */
#define SB_CHUNK_ERROR_INVAL_MAND_PAR 0x7 /* Invalid Mandatory Parameter */
#define SB_CHUNK_ERROR_UNRECOG_PAR    0x8 /* Unrecognize Parameter   */
#define SB_CHUNK_ERROR_NO_USR_DATA    0x9 /* No User Data   */
#define SB_CHUNK_ERROR_COOKIE_RCVD_SHTDWN  0xa /* Cookie Received while shutdown */


#define SB_MAX_DNAME_LEN   64             /* Maximum length of Domain Name string */

/* sb023.102 - Added pkarray size */
#define PKARRAY_SIZE    200


/* Constant Defines */
#define MAX16BIT              0xffff       /* 65535                   */
#define MAX32BIT              0xffffffffL  /* Maximum 32 bit number   */

/* SCTP Macros */

/* return the minimum */
#define GET_SB_MIN(_a,_b) _a < _b ? _a : _b

/* return the maximum */
#define GET_SB_MAX(_a,_b) _a > _b ? _a : _b

/* validate SpId */
#define SB_CHK_SPID(_spId, _event, _ret)                               \
{                                                                      \
   _ret = ROK;                                                         \
   if ( (_spId >= (SpId) sbGlobalCb.genCfg.maxNmbSctSaps) ||           \
        (_spId < 0) )                                                  \
   {                                                                   \
      sbLmGenAlarm((U16)LCM_CATEGORY_INTERFACE,                        \
                  (U16)_event,                                         \
                  (U16)LCM_CAUSE_INV_SPID,                             \
                  _spId, LSB_SW_RFC_REL0);                              \
      _ret = RFAILED;                                                  \
   }                                                                   \
   else if ( sbGlobalCb.sctSaps[_spId] == (SbSctSapCb *) NULLP )       \
   {                                                                   \
      sbLmGenAlarm((U16)LCM_CATEGORY_INTERFACE,                        \
                  (U16)_event,                                         \
                  (U16)LCM_CAUSE_INV_SAP,                              \
                  _spId, LSB_SW_RFC_REL0);                              \
      _ret = RFAILED;                                                  \
   }                                                                   \
   else if ( sbGlobalCb.sctSaps[_spId]->sapState == SB_SAPSTATE_UBND ) \
   {                                                                   \
      sbLmGenAlarm((U16)LCM_CATEGORY_INTERFACE,                        \
                  (U16)_event,                                         \
                  (U16)LCM_CAUSE_INV_SAP,                              \
                  _spId, LSB_SW_RFC_REL0);                              \
      _ret = RFAILED;                                                  \
   }                                                                   \
}

/* validate the endpoint ID */
#define SB_CHK_SPENDPID(_spEndpId, _ret)                               \
{                                                                      \
   _ret = ROK;                                                         \
   if ( _spEndpId >= sbGlobalCb.genCfg.maxNmbEndp )                    \
   {                                                                   \
      _ret = RFAILED;                                                  \
   }                                                                   \
   else if ( sbGlobalCb.endpCb[_spEndpId] == (SbSctEndpCb *) NULLP )   \
   {                                                                   \
      _ret = RFAILED;                                                  \
   }                                                                   \
}

/* validate the association ID */
#define SB_CHK_SPASSOCID(_spAssocId, _ret)                             \
{                                                                      \
   _ret = ROK;                                                         \
   /* sb064.102 - No need to check for less than 0  */                 \
   if ( _spAssocId >= sbGlobalCb.genCfg.maxNmbAssoc )                  \
   {                                                                   \
      _ret = RFAILED;                                                  \
   }                                                                   \
   else if ( sbGlobalCb.assocCb[_spAssocId] == (SbSctAssocCb *) NULLP )  \
   {                                                                   \
      _ret = RFAILED;                                                  \
   }                                                                   \
}

/* sb001.12: Updation - Byte alignment fix */                
#define SB_CHK_DTA(_endpId, _addrPtr, _port, _ret)                       \
{                                                                        \
   SbAssocMapCb  _assocMap;                                              \
   SbAssocMapCb *_tmpAssocMap;                                           \
                                                                         \
   SB_ZERO(&(_assocMap), sizeof(SbAssocMapCb));                          \
   _assocMap.sbAssocEntry.spEndpId = _endpId;                            \
   SB_CPY_NADDR(&(_assocMap.sbAssocEntry.peerAddr), _addrPtr);           \
   _assocMap.sbAssocEntry.port     = _port;                              \
                                                                         \
   _ret = cmHashListFind(&(sbGlobalCb.assocMapHl),                       \
                   (U8 *) &(_assocMap.sbAssocEntry),                     \
                   sizeof(SbAssocMapEntry), 0, (PTR *) &_tmpAssocMap);   \
}


/* debug macro */
#define SBDBGP(_msgClass, _arg) \
   DBGP(&(sbGlobalCb.sbInit), SBLAYERNAME, _msgClass, _arg) 


/* start a timer */
#define SB_START_TMR(_timer, _cb, _evnt, _localWait)    \
{                                                       \
   U16        _wait;                                    \
   CmTmrArg   _arg;                                     \
                                                        \
   _wait = _localWait;                                  \
   if (_wait != 0)                                      \
   {                                                    \
      _arg.tq     = &(sbGlobalCb.sbTq[0]);              \
      _arg.tqCp   = &(sbGlobalCb.sbTqCp);               \
      _arg.timers = _timer;                             \
      _arg.cb     = (PTR)_cb;                           \
      _arg.evnt   = _evnt;                              \
      _arg.wait   = _wait;                              \
      _arg.tNum   = 0;                                  \
      _arg.max    = 1;                                  \
      cmPlcCbTq(&_arg);                                 \
   }                                                    \
}

/* stop a timer */
#define SB_STOP_TMR(_timer)                             \
{                                                       \
   CmTmrArg   _arg;                                     \
   _arg.tq     = &(sbGlobalCb.sbTq[0]);                 \
   _arg.tqCp   = &(sbGlobalCb.sbTqCp);                  \
   _arg.timers = _timer;                                \
   _arg.cb     = NULLP;                                 \
   _arg.evnt   = 0;                                     \
   _arg.wait   = 0;                                     \
   _arg.tNum   = 0;                                     \
   _arg.max    = 1;                                     \
   cmRmvCbTq(&_arg);                                    \
}


/* zero out a buffer */
#define SB_ZERO(_str,_len)                              \
   cmMemset((U8 *)_str, 0, _len); 

/* allocate and zero out a static buffer */
#define SB_ALLOC(_size, _datPtr, _ret)                 \
{                                                      \
   _ret = SGetSBuf(sbGlobalCb.sbInit.region,           \
                   sbGlobalCb.sbInit.pool,             \
                   (Data**)&_datPtr, _size);           \
   if ( _ret == ROK )                                  \
   {                                                   \
      cmMemset((U8*)_datPtr, 0, _size);                \
      /* add to general status */                      \
      sbGlobalCb.genSta.memAlloc += SBUFSIZE(_size);   \
   }                                                   \
}

/* sb023.102 - Added for performance improvement 
 * allocate a static buffer */
#define SB_GETSBUF(_size, _datPtr, _ret)               \
{                                                      \
   _ret = SGetSBuf(sbGlobalCb.sbInit.region,           \
                   sbGlobalCb.sbInit.pool,             \
                   (Data**)&_datPtr, _size);           \
   if ( _ret == ROK )                                  \
   {                                                   \
      /* add to general status */                      \
      sbGlobalCb.genSta.memAlloc += SBUFSIZE(_size);   \
   }                                                   \
}


/* zero out and deallocate a static buffer */
#define SB_FREE(_size, _datPtr)                         \
{                                                       \
   if (_datPtr == NULLP)                                \
   {                                                     \
      SBDBGP(DBGMASK_SI, (sbGlobalCb.sbInit.prntBuf,    \
             "************* NULL DBUFF **********\n"));   \
   }                                                       \
   else                                                    \
   {                                                       \
      (Void) SPutSBuf(sbGlobalCb.sbInit.region,            \
                      sbGlobalCb.sbInit.pool,              \
                      (Data*)_datPtr, _size);              \
      /* subtract from general status */                   \
      sbGlobalCb.genSta.memAlloc -= SBUFSIZE(_size);       \
      _datPtr = NULLP;                                     \
   }                                                       \
}

/* Get a message (dynamic) */
/* spId = 0 for Layer Manager Alarm */

#define SB_GETMSG(_mbufptr, _ret)                                        \
{                                                                        \
   _mbufptr = (Buffer *) NULLP;                                          \
   _ret = SGetMsg(sbGlobalCb.sbInit.region, sbGlobalCb.sbInit.pool,      \
                  (Buffer **) &_mbufptr);                                \
}

#define SB_SEGMSG(_mBufptr, _parSize, _tmpBufptrptr, _ret)               \
{                                                                        \
   _ret = SSegMsg(_mBufptr, _parSize, _tmpBufptrptr);                    \
}

#define SB_ADDMSGREF(_mBufptr1, _mBufptrptr2, _ret)                      \
{                                                                        \
   _ret = SAddMsgRef(_mBufptr1, sbGlobalCb.sbInit.region,                \
                     sbGlobalCb.sbInit.pool, _mBufptrptr2);              \
}


#define SB_PUTMSG(_mbufptr)                                              \
{                                                                        \
   (Void) SPutMsg(_mbufptr);                                             \
   _mbufptr = (Buffer *)NULLP;                                           \
}

#define SB_CHK_PUTMSG(_mbufptr)                                         \
{                                                                       \
   if ( _mbufptr != (Buffer *) NULLP )                                  \
   {                                                                    \
      (Void) SPutMsg(_mbufptr);                                         \
      _mbufptr = (Buffer *)NULLP;                                       \
   }                                                                    \
}

/* validate TSN values */
#define SB_CHK_CUMTSN(_old, _new)                       \
   (S16)(( ((_new - _old) < SB_MAX_TSN_DIFF ) && (_new != _old)) ? ROK : RFAILED)


/* copy a network address */
#define SB_CPY_NADDR(_tgtPtr, _srcPtr)                                  \
{                                                                       \
   S16 _i;                                                               \
                                                                        \
   SB_ZERO((_tgtPtr), sizeof(CmNetAddr));                               \
                                                                        \
   if ((_srcPtr) == (CmNetAddr *)NULLP)                                 \
   {                                                                    \
      (_tgtPtr)->type = CM_NETADDR_IPV4;                                \
      (_tgtPtr)->u.ipv4NetAddr = 0;                                     \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      if ((_srcPtr)->type == CM_NETADDR_IPV4)                           \
      {                                                                 \
         (_tgtPtr)->type = CM_NETADDR_IPV4;                             \
         (_tgtPtr)->u.ipv4NetAddr = (_srcPtr)->u.ipv4NetAddr;           \
      }                                                                 \
      else if ((_srcPtr)->type == CM_NETADDR_IPV6)                      \
      {                                                                 \
         (_tgtPtr)->type = CM_NETADDR_IPV6;                             \
         for (_i = 0; _i < CM_IPV6ADDR_SIZE; _i++)                      \
         {                                                              \
            (_tgtPtr)->u.ipv6NetAddr[_i] = (_srcPtr)->u.ipv6NetAddr[_i];\
         }                                                              \
      }                                                                 \
      else                                                              \
      {                                                                 \
         (_tgtPtr)->type = CM_NETADDR_IPV4;                             \
         (_tgtPtr)->u.ipv4NetAddr = 0;                                  \
      }                                                                 \
   }                                                                    \
}

/* sb023.102 - Performance change - This macro will copy the network address
 * without doint cmMemset becuase cmMemset is already done previously 
 *  */
#define SB_MAKE_NADDR_CPY(_tgtPtr, _srcPtr)                             \
{                                                                       \
   S16 _i;                                                              \
   if ((_srcPtr) == (CmNetAddr *)NULLP)                                 \
   {                                                                    \
      (_tgtPtr)->type = CM_NETADDR_IPV4;                                \
      (_tgtPtr)->u.ipv4NetAddr = 0;                                     \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      if ((_srcPtr)->type == CM_NETADDR_IPV4)                           \
      {                                                                 \
         (_tgtPtr)->type = CM_NETADDR_IPV4;                             \
         (_tgtPtr)->u.ipv4NetAddr = (_srcPtr)->u.ipv4NetAddr;           \
      }                                                                 \
      else if ((_srcPtr)->type == CM_NETADDR_IPV6)                      \
      {                                                                 \
         (_tgtPtr)->type = CM_NETADDR_IPV6;                             \
         for (_i = 0; _i < CM_IPV6ADDR_SIZE; _i++)                      \
         {                                                              \
            (_tgtPtr)->u.ipv6NetAddr[_i] = (_srcPtr)->u.ipv6NetAddr[_i];\
         }                                                              \
      }                                                                 \
      else                                                              \
      {                                                                 \
         (_tgtPtr)->type = CM_NETADDR_IPV4;                             \
         (_tgtPtr)->u.ipv4NetAddr = 0;                                  \
      }                                                                 \
   }                                                                    \
}



/* check for IPV6 wildcard address */
#define SB_INET6_ISANY(_addr, _ret)                                     \
{                                                                       \
   U16 _i;                                                              \
   *(_ret) = TRUE;                                                      \
   for (_i = 0; _i < CM_IPV6ADDR_SIZE; _i++)                             \
   {                                                                    \
      if ((_addr)[_i] != 0)                                             \
      {                                                                 \
         *(_ret) = FALSE;                                               \
         break;                                                         \
      }                                                                 \
   }                                                                    \
}
/* Patch sb031.102 IPV6 Support Added */
#define SB_INET6_SAMEADDR(_addr1, _addr2, _ret)                                     \
{                                                                       \
   U16 _i;                                                              \
   *(_ret) = TRUE;                                                      \
   for (_i = 0; _i < CM_IPV6ADDR_SIZE; _i++)                             \
   {                                                                    \
      if ((_addr1)[_i] != (_addr2[_i]))                                             \
      {                                                                 \
         *(_ret) = FALSE;                                               \
         break;                                                         \
      }                                                                 \
   }                                                                    \
}
#define SB_CPY_IPV6ADSTR(str, ptr)                                      \
{                                                                       \
 sprintf(str, "%x:%x:%x:%x:%x:%x:%x:%x:%x:%x:%x:%x:%x:%x:%x:%x:", *ptr, \
 *(ptr+1), *(ptr+2), *(ptr+3), *(ptr+4), *(ptr+5), *(ptr+6), *(ptr+7),  \
 *(ptr+8), *(ptr+9), *(ptr+10), *(ptr+11), *(ptr+12), *(ptr+13), *(ptr+14), \
 *(ptr+15));                                                              \
}

/* copy a network address list */
#define SB_CPY_NADDRLST(_tgtPtr, _srcPtr)                               \
{                                                                       \
   S16 _j;                                                              \
                                                                        \
   SB_ZERO((_tgtPtr), sizeof(SctNetAddrLst))                            \
   (_tgtPtr)->nmb = (_srcPtr)->nmb;                                     \
                                                                        \
   for (_j = 0; _j < (_srcPtr)->nmb; _j++)                              \
   {                                                                    \
      SB_CPY_NADDR(&((_tgtPtr)->nAddr[_j]), &((_srcPtr)->nAddr[_j]))    \
   }                                                                    \
}

/* find the local address control block for an endpoint */ 
/* sb006.102: Updation - modified for alignment here (sbSctEndpEntry)*/
#define SB_GET_LOCAL_CONN(_endpId, _locAddrCbPtr, _err)                  \
{                                                                        \
   SbSctEndpCb    *tmpEndpCb;                                            \
   /* sb046.102: Multiple IP address per Endp */                         \
   CmNetAddr _tmpAddr;                                                   \
   tmpEndpCb = sbGlobalCb.endpCb[_endpId];                               \
   if ( tmpEndpCb == (SbSctEndpCb *) NULLP )                             \
   {                                                                     \
      _locAddrCbPtr = (SbLocalAddrCb *) NULLP;                           \
      _err = RFAILED;                                                    \
   }                                                                     \
   else                                                                  \
   {                                                                     \
      /* sb046.102: Multiple IP address per Endp */                      \
      U8 _k;                                                             \
      for (_k = 0; (_k < tmpEndpCb->localAddrLst.nmb); _k++ )            \
      {                                                                  \
         SB_CPY_NADDR(&(_tmpAddr), &(tmpEndpCb->localAddrLst.nAddr[_k])); \
	  _err = cmHashListFind(&(sbGlobalCb.localAddrHl),                \
                       (U8 *) &(_tmpAddr),                               \
                       (U16) sizeof(CmNetAddr), 0,                       \
                       (PTR *) &(_locAddrCbPtr));                        \
         if ( _err == ROK )                                              \
         {                                                               \
            if ( _locAddrCbPtr->connected )                              \
               break;                                                    \
            _err = RFAILED;                                              \
         }                                                                \
      }                                                                  \
      if (_err == RFAILED)                                               \
      {                                                                  \
         SB_ZERO((U8 *) &_tmpAddr, sizeof(CmNetAddr))                    \
         _tmpAddr.type = tmpEndpCb->localAddrLst.nAddr[0].type;          \
         _err = cmHashListFind(&(sbGlobalCb.localAddrHl),                \
                              (U8 *) &(_tmpAddr),                        \
                              (U16) sizeof(CmNetAddr), 0,                \
                              (PTR *) &(_locAddrCbPtr));                 \
      }                                                                  \
   }                                                                     \
}

/* sb056.102 : Added : in case of primary dest address failure
               try assoc on alternate dest addr of address list
 */
#define SB_GET_NEXT_LOCAL_CONN(_endpId, _locAddrCbPtr, _newAddrCbPtr, _err) \
{                                                                        \
   SbSctEndpCb    *tmpEndpCb;                                            \
   CmNetAddr _tmpAddr;                                                   \
   tmpEndpCb = sbGlobalCb.endpCb[_endpId];                               \
   if ( tmpEndpCb == (SbSctEndpCb *) NULLP )                             \
   {                                                                     \
      _newAddrCbPtr = (SbLocalAddrCb *) NULLP;                           \
      _err = RFAILED;                                                    \
   }                                                                     \
   else                                                                  \
   {                                                                     \
      U8 _k;                                                             \
      U8 _found = 0;                                                     \
      U8 _last = 1;                                                     \
      SbLocalAddrCb *_firstAddr = (SbLocalAddrCb*)NULLP;                 \
      for (_k = 0; (_k < tmpEndpCb->localAddrLst.nmb); _k++ )            \
      {                                                                  \
         SB_CPY_NADDR(&(_tmpAddr), &(tmpEndpCb->localAddrLst.nAddr[_k])); \
         _err = cmHashListFind(&(sbGlobalCb.localAddrHl),                \
                       (U8 *) &(_tmpAddr),                               \
                       (U16) sizeof(CmNetAddr), 0,                       \
                       (PTR *) &(_newAddrCbPtr));                        \
         if ( _err == ROK )                                              \
         {                                                               \
            if ( _newAddrCbPtr->connected )                              \
            {                                                            \
               if(!_firstAddr)                                           \
               {                                                         \
                 _firstAddr = _newAddrCbPtr;                             \
               }                                                         \
               if(_newAddrCbPtr == _locAddrCbPtr)                        \
               {                                                         \
                 _found =1;                                              \
                 continue;                                               \
               }                                                         \
               else if(_found)                                           \
               {                                                         \
                 _last = 0;                                              \
                 break;                                                  \
               }                                                         \
            }                                                            \
            _err = RFAILED;                                              \
         }                                                               \
      }                                                                  \
      if(_last)                                                          \
      {                                                                  \
         _newAddrCbPtr = _firstAddr;                                     \
      }                                                                  \
      if (_err == RFAILED)                                               \
      {                                                                  \
         SB_ZERO((U8 *) &_tmpAddr, sizeof(CmNetAddr))                    \
         _tmpAddr.type = tmpEndpCb->localAddrLst.nAddr[0].type;          \
         _err = cmHashListFind(&(sbGlobalCb.localAddrHl),                \
                              (U8 *) &(_tmpAddr),                        \
                              (U16) sizeof(CmNetAddr), 0,                \
                              (PTR *) &(_newAddrCbPtr));                 \
      }                                                                  \
   }                                                                     \
}

/* determine the MTU size on an address */
#define SB_QUERY_MTU(_addrPtr, _mtu, _ret)                           \
{                                                                    \
   if (sbGlobalCb.genCfg.performMtu == TRUE)                         \
   {                                                                 \
      _ret = sbMtuQuerySz(&(sbGlobalCb.mtuCp), _addrPtr, &(_mtu)); \
      _mtu -= SB_IP_HEADER_SIZE;                                     \
      if (sbGlobalCb.genCfg.serviceType == HI_SRVC_UDP)              \
      {                                                              \
         _mtu -= SB_UDP_HEADER_SIZE;                                 \
      }                                                              \
   }                                                                 \
   else                                                              \
   {                                                                 \
      _mtu = sbGlobalCb.genCfg.mtuInitial;                           \
      _mtu -= SB_IP_HEADER_SIZE;                                     \
      if (sbGlobalCb.genCfg.serviceType == HI_SRVC_UDP)              \
      {                                                              \
         _mtu -= SB_UDP_HEADER_SIZE;                                 \
      }                                                              \
      _ret = ROK;                                                    \
   }                                                                 \
}

/* pack a U8 into a static array */
#define SB_PKU8(_tmpU8) \
{                           \
   pkArray[idx++] = (Data) _tmpU8; \
}

/* pack a U16 into a static array */
#define SB_PKU16(_tmpU16) \
{                           \
   pkArray[idx++] = (Data) GetLoByte(_tmpU16); \
   pkArray[idx++] = (Data) GetHiByte(_tmpU16); \
}

/* pack a U32 into a static array */
#define SB_PKU32(_tmpU32)                       \
{                                               \
   U16 _tmp;                                    \
   _tmp = (U16) GetLoWord(_tmpU32);             \
   pkArray[idx++] = (Data) GetLoByte(_tmp);     \
   pkArray[idx++] = (Data) GetHiByte(_tmp);     \
   _tmp = (U16) GetHiWord(_tmpU32);             \
   pkArray[idx++] = (Data) GetLoByte(_tmp);     \
   pkArray[idx++] = (Data) GetHiByte(_tmp);     \
}

/* unpack a U8 into a static array */
#define SB_UNPKU8(_tmpU8) \
{                           \
   _tmpU8 = (U8)pkArray[idx++]; \
}

/* unpack a U16 into a static array */
#define SB_UNPKU16(_tmpU16) \
{                           \
   _tmpU16 = 0;             \
   _tmpU16 = (U16)PutHiByte(_tmpU16, (U8)pkArray[idx++]); \
   _tmpU16 = (U16)PutLoByte(_tmpU16, (U8)pkArray[idx++]); \
}

/* unpack a U32 into a static array */
#define SB_UNPKU32(_tmpU32)                       \
{                                                 \
   U16 _tmpU16 = 0;                               \
                                              \
   _tmpU32 = 0;                               \
   _tmpU16 = (U16)PutHiByte(_tmpU16, (U8)pkArray[idx++]); \
   _tmpU16 = (U16)PutLoByte(_tmpU16, (U8)pkArray[idx++]); \
   _tmpU32 = (U32)PutHiWord(_tmpU32, (U16)_tmpU16);       \
   _tmpU16 = (U16)PutHiByte(_tmpU16, (U8)pkArray[idx++]); \
   _tmpU16 = (U16)PutLoByte(_tmpU16, (U8)pkArray[idx++]); \
   _tmpU32 = (U32)PutLoWord(_tmpU32, (U16)_tmpU16);       \
}

#define SB_ABORT_DNS_RSLV_REQ(_reqId)                                     \
{                                                                         \
   cmDnsAbortRslvReq(sbGlobalCb.dnsInfo.dnsCb, _reqId);                   \
}


/* Performance change - sb023.102 */
#define SB_GET_MTU(_addrCb, _mtu, _ret)                              \
{                                                                    \
   if (sbGlobalCb.genCfg.performMtu == TRUE)                         \
   {                                                                 \
      if( sbGlobalCb.mtuCp.addrArray[_addrCb->mtuIdx] != NULLP)      \
      {                                                              \
        _mtu = sbGlobalCb.mtuCp.addrArray[_addrCb->mtuIdx]->mtu;     \
        _mtu -= SB_IP_HEADER_SIZE;                                   \
         if (sbGlobalCb.genCfg.serviceType == HI_SRVC_UDP)           \
        {                                                            \
           _mtu -= SB_UDP_HEADER_SIZE;                               \
        }                                                            \
        _ret = ROK;                                                  \
      }                                                              \
      else                                                           \
      {                                                              \
         _mtu = sbGlobalCb.genCfg.mtuInitial;                        \
         _mtu -= SB_IP_HEADER_SIZE;                                  \
         _ret = RFAILED;                                             \
      }                                                              \
   }                                                                 \
   else                                                              \
   {                                                                 \
      _mtu = sbGlobalCb.genCfg.mtuInitial;                           \
      _mtu -= SB_IP_HEADER_SIZE;                                     \
      if (sbGlobalCb.genCfg.serviceType == HI_SRVC_UDP)              \
      {                                                              \
         _mtu -= SB_UDP_HEADER_SIZE;                                 \
      }                                                              \
      _ret = ROK;                                                    \
   }                                                                 \
}



#ifdef SB_ACC 
#ifndef SS_PS
#define cmInetGetHostByName   sbInetGetHostByName
#endif
#endif

#endif /* __SBH__ */

/********************************************************************30**

         End of file:     sb.h@@/main/2 - Wed Jan 10 16:24:21 2001

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision History:

*********************************************************************61*/
/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
 /main/2     ---    bk         1. backbone draft.
 /main/2     ---    sb         1. Modified for SCTP release based on 
                                  RFC-2960 'Oct 2000.
         sb001.12   sb         1. Alignment problem fixed.
         sb006.102  rs         1. Updation - modified for alignment in 
                                  sbSctEndpEntry
         sb015.102  rs         1. Timer queue size is increased.
         sb023.102  sb         1. Added new Macro for Mtu case
         sb027.102  hm         1. Removed TAB
         sb031.102  hm         1. IPV6 Support Added 
         sb042.102  hl         1. Added change for SHT interface and Rolling
                                  Up Grade
         sb044.102  rs         1. Max Retry attempt added
         sb046.102  hl         1. Multiple IP address per endpoint support
         sb054.102  rk         1. Bundling Changes
         sb056.102  rk         1. In case of primary dest address failure
                                  try assoc on alternate dest addr of
                                  address list 
         sb057.102  pr         1. Multiple proc ids support added.
         sb064.102  pr         1. Removed compiler warnings.
*********************************************************************91*/
