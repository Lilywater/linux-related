/* ***************************************************************************
 *        (c) COPYRIGHT 1995-2006 by Xinwei, Inc.
 *                   All rights reserved.
 *
 * sb_dbg.c:  
 *          This file include the debug of print functions in sctp protocol.
 *           
 * Author:
 *          zhouguishuang
 * Date:
 *          2006-4-17
 * Last Modified:
 *
 ****************************************************************************/



#include "sb_common.h"

#ifdef  SSI_WITH_CLI_ENABLED 
#include "xosshell.h"
#include "clishell.h"
 
  

/**********************************************************************************/
/*                               Sctp �ĵ�����Ϣ����������                        */
/**********************************************************************************/

void sb_print_state_info(CLI_ENV* pCliEnv,U16 print_action);
void sb_print_cfg_info(CLI_ENV* pCliEnv,U16 print_action);
extern  SbCfgGenWG  sbCfgGenWg;

XVOID  sbCfgProtocol(CLI_ENV* pCliEnv,XS32  siArgc,XCHAR **ppArgv);
XVOID  sbDbgSwitch(CLI_ENV* pCliEnv,XS32  siArgc,XCHAR **ppArgv);
XVOID  sbDbgBndtucl(CLI_ENV* pCliEnv,XS32  siArgc,XCHAR **ppArgv);
XVOID  sbStateDbgPrint(CLI_ENV* pCliEnv,XS32  siArgc,XCHAR **ppArgv);



/*
*
*       ����:   sbStateDbgPrint
*
*       ����:   ��ӡSCTP״̬��Ϣ�Ĵ�����������������״̬��Ϣ
*                                                 Э���ʼ����Ϣ
*                                                 �˵���ƿ���Ϣ
*                                                 ż�����ƿ���Ϣ
*                                                 SCT SAP���ƿ���Ϣ
*                                                 TSAP���ƿ���Ϣ
*
*       ����ֵ:   ʧ��:           RFAILED
*                 �ɹ�:           ROK
*       �ļ�:  sb_dbg.c
*
*/


XVOID  sbStateDbgPrint(CLI_ENV* pCliEnv,XS32  siArgc,XCHAR **ppArgv)
{

    U16  action=0;
    if( siArgc != 2 ) 
    {
        
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]Input Parameter no. > 2.\r\n");

        return;
    }      
    if((XOS_StrCmp(ppArgv[0],"show")!=0))
    {
        XOS_CliExtPrintf(pCliEnv,"\r\nParameter Input command Error!\r\n");
        return;
    }
    if((XOS_StrCmp(ppArgv[1],"config")==0))
    {
        action |= SCTP_PRINT_CONFIG_INFO; 
    }    
    
    if((XOS_StrCmp(ppArgv[1],"layer")==0))
    {
        action |= SCTP_PRINT_LAYER_INFO; 
    }
    if((XOS_StrCmp(ppArgv[1],"init")==0))
    {
        action |= SCTP_PRINT_INIT_INFO; 
    }
    if((XOS_StrCmp(ppArgv[1],"assoc")==0))
    {
        action |= SCTP_PRINT_ASSOC_INFO; 
    }
    if((XOS_StrCmp(ppArgv[1],"endp")==0))
    {
        action |= SCTP_PRINT_ENDP_INFO; 
    }
    if((XOS_StrCmp(ppArgv[1],"sctsap")==0))
    {
        action |= SCTP_PRINT_SCTSAP_INFO; 
    }
    if((XOS_StrCmp(ppArgv[1],"tsap")==0))
    {
        action |= SCTP_PRINT_TSAP_INFO; 
    }
    if((XOS_StrCmp(ppArgv[1],"all")==0))
    {
        action |= SCTP_PRINT_ALL_INFO; 
    }
    if((XOS_StrCmp(ppArgv[1],"stat")==0))
    {
        action |= SCTP_PRINT_STATS_INFO; 
    }    
    
    if(action)
    {
        sb_print_state_info(pCliEnv,action);
    }
    else
    {
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP] parameter input error.\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\nUsage:\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\nshow <all |config| layer| init| assoc| endp| sctsap| tsap>\r\n");
    }
    return;
}


/*
*
*       ����:   sb_print_state_info
*
*       ����:   ��ӡSCTP״̬��Ϣ�Ĵ�����������������״̬��Ϣ
                                                  Э���ʼ����Ϣ
*                                                 �˵���ƿ���Ϣ
*                                                 ż�����ƿ���Ϣ
*                                                 SCT SAP���ƿ���Ϣ
*                                                 TSAP���ƿ���Ϣ
*
*       ����ֵ:   ʧ��:           RFAILED
*                 �ɹ�:           ROK
*
*       ע��:  
*
*       �ļ�:  sb_dbg.c
*
*/
void sb_print_state_info(CLI_ENV* pCliEnv,U16 print_action)
{
    SbGenSta      genSta;   /* ��״̬��Ϣ */
    SbGenCfg      genCfg;   /* SCTPͨ��������Ϣ */
    TskInit       sbInit;   /* SCTPϵͳ��ʼ����Ϣ */
    SbSctEndpCb   endpCb;   /* �˵���ƿ� */
    SbSctAssocCb  assocCb;  /* ż�����ƿ� */
    SbSctSapCb    sctSaps;  /* SCT SAP���ƿ� */
    SbTSapCb      tSaps;    /* TSAP���ƿ� */
    SbGenCfg      GbGenCfg;   /* SCTPͨ��������Ϣ */
    
    U32           i=0,j=0;    
    U32           byte1=0,byte2=0,byte3=0,byte4=0;
    
    if( sbGlobalCb.sbInit.cfgDone != TRUE )  
    {   
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]WARN:SCTP protocol has not been configed yet.\r\n");
        return;        
    }/* if( sbGlobalCb.sbInit.cfgDone == TRUE ) */
    
    if((print_action&SCTP_PRINT_CONFIG_INFO)||(print_action&SCTP_PRINT_ALL_INFO))
    {
        (Void) cmMemcpy((U8 *) &GbGenCfg, (U8 *) &sbGlobalCb.genCfg, sizeof(SbGenCfg));
        XOS_CliExtPrintf(pCliEnv,"\r\n------------------- SCTP GEN CONFIG INFO ---------------------\r\n");
#ifdef SB_IPV6_SUPPORTED
        /* IPV6 service required for sctp */ 
        if( TRUE == GbGenCfg.ipv6SrvcReqdFlg)
        {
            XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]genCfg.ipv6SrvcReqdFlg       = TRUE \r\n");
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]genCfg.ipv6SrvcReqdFlg       = FALSE \r\n");
        }   

#endif  /* SB_IPV6_SUPPORTED  */

        /* TUCL transport protocol (IP/UDP) */      
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]TUCL transport protocol (IP/UDP): ");
        switch(GbGenCfg.serviceType)
        {
            case HI_SRVC_UDP:
                XOS_CliExtPrintf(pCliEnv,"UDP.\r\n");
                break;
            case HI_SRVC_TCP:
                XOS_CliExtPrintf(pCliEnv,"TCP.\r\n");
                break;
            case HI_SRVC_TCP_TPKT_HDR:
                XOS_CliExtPrintf(pCliEnv,"TCP TPKT HDR.\r\n");
                break;
            case HI_SRVC_UDP_PRIOR:
                XOS_CliExtPrintf(pCliEnv,"UDP PRIOR.\r\n");
                break;
            case HI_SRVC_UDP_TPKT_HDR:
                XOS_CliExtPrintf(pCliEnv,"UDP TPKT HDR.\r\n");
                break;
            case HI_SRVC_RAW_RAW:
                XOS_CliExtPrintf(pCliEnv,"RAW RAW.\r\n");
                break;
            case HI_SRVC_RAW_SCTP:
                XOS_CliExtPrintf(pCliEnv,"RAW SCTP.\r\n");
                break;
            case HI_SRVC_RAW_ICMP:
                XOS_CliExtPrintf(pCliEnv,"RAW ICMP.\r\n");
                break;
            default:
                break;                               
        }
        /* max no. SCT SAPS */
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]max no. SCT SAPS        = %d\r\n",GbGenCfg.maxNmbSctSaps);
        /* max no. Transport SAPS */
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]max no. Transport SAPS  = %d\r\n",GbGenCfg.maxNmbTSaps);
        /* max no. endpoints */
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]max no. endpoints       = %d\r\n",GbGenCfg.maxNmbEndp);
        /* max no. associations */
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]max no. associations    = %d\r\n",GbGenCfg.maxNmbAssoc);
        /* max no. dest. addresses */
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]max no. dest. addresses = %d\r\n",GbGenCfg.maxNmbDstAddr);
        /* max no. src. addresses */
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]max no. src.  addresses = %d\r\n",GbGenCfg.maxNmbSrcAddr);
        /* max no. outgoing chunks */
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]max no. outgoing chunks = %d\r\n",GbGenCfg.maxNmbTxChunks);
        /* max no. recv chunks */
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]max no. receive  chunks = %d\r\n",GbGenCfg.maxNmbRxChunks);
        /* max no. in streams PER ASSOCIATION */
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]max no. in  streams PER ASSOCIATION   = %d\r\n",GbGenCfg.maxNmbInStrms);
        /* max no. out streams PER ASSOCIATION */
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]max no. out streams PER ASSOCIATION   = %d\r\n",GbGenCfg.maxNmbOutStrms);
        /* max receiver window space */
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]max receiver window space  = %d\r\n",GbGenCfg.initARwnd);

        /* Perform path MTU discovery */
        if( TRUE == GbGenCfg.performMtu)
        {
            XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]genCfg.performMtu          = YES\r\n");
            XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]genCfg.mtuInitial          = %d\r\n",GbGenCfg.mtuInitial);
            XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]genCfg.mtuMinInitial       = %d\r\n",GbGenCfg.mtuMinInitial);
            XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]genCfg.mtuMaxInitial       = %d\r\n",GbGenCfg.mtuMaxInitial);
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]genCfg.performMtu          = FALSE \n");
        }
        /* Flag whether hostname is to be used in INIT and INITACK msg */        
        if( TRUE == GbGenCfg.useHstName)
        {
            XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]genCfg.useHstName          = TRUE \r\n");
            XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]genCfg.hostname            = %s\r\n",GbGenCfg.hostname);
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]genCfg.useHstName          = FALSE \r\n");
        }
        
    }    
    if((print_action&SCTP_PRINT_INIT_INFO)||(print_action&SCTP_PRINT_ALL_INFO))
    {
        /* ��ӡSCTPϵͳ��ʼ����Ϣ */
        (Void) cmMemcpy((U8 *) &sbInit, (U8 *) &sbGlobalCb.sbInit, sizeof(TskInit));
        XOS_CliExtPrintf(pCliEnv,"\r\n------------------- SCTP  Init RUN INFO ---------------------\r\n");
        
        
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP Init]entity      = %d\r\n",sbInit.ent);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP Init]instance    = %d\r\n",sbInit.inst);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP Init]static region   = %d\r\n",sbInit.region);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP Init]static pool     = %d\r\n",sbInit.pool);
        if(sbInit.acnt == TRUE )
        {
            XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP Init]do accounting :YES\r\n");
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP Init]do accounting :NO\r\n");
        }
        
        if(sbInit.usta == TRUE )
        {
            XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP Init]do unsolicited status :YES\r\n");
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP Init]do unsolicited status :NO\r\n");
        }
        
        if(sbInit.trc == TRUE )
        {
            XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP Init]do trace :YES\r\n");
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP Init]do trace :NO\r\n");
        }
        
    }/* if((print_action&SCTP_PRINT_INIT_INFO)||(print_action&SCTP_PRINT_ALL_INFO)) */
    
    if((print_action&SCTP_PRINT_LAYER_INFO)||(print_action&SCTP_PRINT_ALL_INFO))
    {
        /* ��ӡSCTPЭ���״̬��Ϣ */
        (Void) cmMemcpy((U8 *) &genSta, (U8 *) &sbGlobalCb.genSta, sizeof(SbGenSta));
        XOS_CliExtPrintf(pCliEnv,"\r\n------------------- SCTP Layer RUN INFO ---------------------\r\n");
        
        
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]genSta.status      = %d\r\n",genSta.status);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]Memory Size Reserved    = %d\r\n",genSta.memSize);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]Memory Size Allocated   = %d\r\n",genSta.memAlloc);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]Number of open associations = %d\r\n",genSta.nmbAssoc);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]Number of open endpoints    = %d\r\n",genSta.nmbEndp);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]Number of local addresses in use    = %d\r\n",genSta.nmbLocalAddr);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]Number of peer addresses in use     = %d\r\n",genSta.nmbPeerAddr);
        
    } /* if((print_action&SCTP_PRINT_LAYER_INFO)||(print_action&SCTP_PRINT_ALL_INFO)) */
    
    if((print_action&SCTP_PRINT_ASSOC_INFO)||(print_action&SCTP_PRINT_ALL_INFO))
    {
        /* ��ӡSCTP ż��״̬��Ϣ */
        XOS_CliExtPrintf(pCliEnv,"\n------------------- SCTP ASSOC RUN INFO ---------------------\r\n");    
        (Void) cmMemcpy((U8 *) &genCfg, (U8 *) &sbGlobalCb.genCfg, sizeof(SbGenCfg));
        /*for(i = 0;i < genCfg.maxNmbSctSaps; i++)*/
        for(i = 0;i < sbCfgGenWg.maxNmbSctSaps; i++)
        {
	    	if ( sbGlobalCb.assocCb[i] != (SbSctAssocCb  *) NULLP )
	    	{
	    	    (Void) cmMemcpy((U8 *) &assocCb, (U8 *) sbGlobalCb.assocCb[i], sizeof(SbSctAssocCb));
	    	    XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP association]  Id   = %d\r\n",i);
	    	    XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP association]  SCT SAP ID   = %d\r\n",assocCb.spId);
	    	    XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP association]  SCTP endpoint ID   = %d\r\n",assocCb.endpId);
	    	    XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP association]  User's side association id   = %d\r\n",assocCb.suAssocId);
	    	    XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP association]  Own association ID   = %d\r\n",assocCb.spAssocId);
	    	    XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP association]  Source SCTP Port   = %d\r\n",assocCb.localPort);
	    	    XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP association]  Destination SCTP Port   = %d\r\n",assocCb.peerPort);
	    	    XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP association]  Association's current state:");
	    	    switch(assocCb.assocState)
	    	    {
	    	        case SCT_ASSOC_STATE_CLOSED:
	    	            XOS_CliExtPrintf(pCliEnv,"STATE CLOSED\r\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_OPEN:
	    	            XOS_CliExtPrintf(pCliEnv,"STATE OPEN\r\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_COOKIE_WAIT:
	    	            XOS_CliExtPrintf(pCliEnv,"STATE COOKIE WAIT\r\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_ESTABLISHED:
	    	            XOS_CliExtPrintf(pCliEnv,"STATE ESTABLISHED\r\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_COOKIE_SENT:
	    	            XOS_CliExtPrintf(pCliEnv,"STATE COOKIE SENT\r\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_SDOWN_PEND:
	    	            XOS_CliExtPrintf(pCliEnv,"STATE SHUTDOWN PEND\r\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_SDOWN_SENT:
	    	            XOS_CliExtPrintf(pCliEnv,"STATE SHUTDOWN SENT\r\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_SDOWN_RCVD:
	    	            XOS_CliExtPrintf(pCliEnv,"STATE SHUTDOWN RCVD\r\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_SDOWNACK_SENT:
	    	            XOS_CliExtPrintf(pCliEnv,"STATE SHUTDOWN ACK SENT\r\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_AWTDNS_RSP_COOKIE:
	    	            XOS_CliExtPrintf(pCliEnv,"STATE Send DNS Query to DNS server and awaiting response\r\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_AWTDNS_RSP_COOKIEACK:
	    	            XOS_CliExtPrintf(pCliEnv,"STATE Send DNS Query to DNS server and awaiting response\r\n");
	    	            break;
	    	        default:
	    	            XOS_CliExtPrintf(pCliEnv,"ERROR STATE.\r\n");
	    	            break;

	    	    } /* switch(assocCb.assocState) */
        
	    	}     /* if ( sbGlobalCb.assocCb[i] != (SbSctAssocCb  *) NULLP ) */
	    	
        }         /* for(i = 0;i < genCfg.maxNmbSctSaps; i++) */     
           
    }  /* if((print_action&SCTP_PRINT_ASSOC_INFO)||(print_action&SCTP_PRINT_ALL_INFO)) */        


    if((print_action&SCTP_PRINT_ENDP_INFO)||(print_action&SCTP_PRINT_ALL_INFO))
    {
        /* ��ӡSCTP �˵�״̬��Ϣ */
        XOS_CliExtPrintf(pCliEnv,"\r\n------------------- SCTP ENDPT RUN INFO ---------------------\r\n");
        
        /*for ( i = 0; i < genCfg.maxNmbEndp; i++ )*/
        for ( i = 0; i < sbCfgGenWg.maxNmbEndp; i++ )
        {
          if ( sbGlobalCb.endpCb[i] != (SbSctEndpCb *) NULLP )
          {
             
             (Void) cmMemcpy((U8 *) &endpCb, (U8 *) sbGlobalCb.endpCb[i], sizeof(SbSctEndpCb));
              
             XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP Endpoint] ��Id   = %d\r\n",i);
             XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP Endpoint] ��Source Address List:\r\n");
             for(j=0;j<sbGlobalCb.endpCb[i]->localAddrLst.nmb;j++)
             {
                XOS_CliExtPrintf(pCliEnv,"Address [%d]:0x%x\n",j,sbGlobalCb.endpCb[i]->localAddrLst.nAddr[j].u.ipv4NetAddr);
             }
             XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP Endpoint] ��Port number = %d\r\n",endpCb.port);         
             XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP Endpoint] ��SCT SAP ID = %d\r\n",endpCb.spId);
             XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP Endpoint] ��Service user's endpoint ID = %d\r\n",endpCb.suEndpId);
             XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP Endpoint] ��Local endpoint ID = %d\r\n",endpCb.spEndpId);
          }
        }        
    }/* if((print_action&SCTP_PRINT_ENDP_INFO)||(print_action&SCTP_PRINT_ALL_INFO)) */

    if((print_action&SCTP_PRINT_SCTSAP_INFO)||(print_action&SCTP_PRINT_ALL_INFO))
    {
        XOS_CliExtPrintf(pCliEnv,"\n------------------- SCTP SCTSAP RUN INFO --------------------\n");
       /* for ( i = 0; i < genCfg.maxNmbSctSaps; i++ )*/
        for ( i = 0; i < sbCfgGenWg.maxNmbSctSaps; i++ )
        {
          if ( sbGlobalCb.sctSaps[i] != (SbSctSapCb *) NULLP )
          { 
             (Void) cmMemcpy((U8 *) &sctSaps, (U8 *) sbGlobalCb.sctSaps[i], sizeof(SbSctSapCb));
             XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP SCTSAP] ��suID    = %d\n",sctSaps.suId);
             XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP SCTSAP] ��spID    = %d\n",i);         
             XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP SCTSAP] ��STATE: ");
             switch(sctSaps.sapState)
             {
	    	        case SB_SAPSTATE_UBND:
	    	            XOS_CliExtPrintf(pCliEnv,"UNBOUND.\r\n");
	    	            break;
	    	        case SB_SAPSTATE_BND:
	    	            XOS_CliExtPrintf(pCliEnv,"BOUND.\r\n");
	    	            break;
	    	        default:
	    	            XOS_CliExtPrintf(pCliEnv,"ERROR.\r\n");
	    	            break;		            		                        
             }
             
          } 
        }        
    }/* if((print_action&SCTP_PRINT_SCTSAP_INFO)||(print_action&SCTP_PRINT_ALL_INFO)) */

   if((print_action&SCTP_PRINT_TSAP_INFO)||(print_action&SCTP_PRINT_ALL_INFO))
   {
        XOS_CliExtPrintf(pCliEnv,"\r\n------------------- SCTP TSAP INFO ----------------------\r\n");
        
        for ( i = 0; i < sbCfgGenWg.maxNmbTSaps; i++ )
        {
          if ( sbGlobalCb.tSaps[i] != (SbTSapCb *) NULLP )
          { 
             (Void) cmMemcpy((U8 *) &tSaps, (U8 *) sbGlobalCb.tSaps[i], sizeof(SbTSapCb));
             XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP TSAP] ��suID    = %d\r\n",i);
             XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP TSAP] ��STATE: ");
             switch(tSaps.sapState)
             {
	    	        case SB_SAPSTATE_UBND:
	    	            XOS_CliExtPrintf(pCliEnv,"UNBOUND.\r\n");
	    	            break;
	    	        case SB_SAPSTATE_BND:
	    	            XOS_CliExtPrintf(pCliEnv,"BOUND.\r\n");
	    	            break;
	    	        default:
	    	            XOS_CliExtPrintf(pCliEnv,"ERROR.\r\n");
	    	            break;		            		                        
             }
          }
        }  /*for ( i = 0; i < genCfg.maxNmbTSaps; i++ )*/
        XOS_CliExtPrintf(pCliEnv,"\r\n------------------ TSAP SOURCE ADDRLST-------------------\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP TSAP] ��src addr num   = %d\n",sbCfgAddrWG.NmbsrcNAddr);
		for(i = 0; i < sbCfgAddrWG.NmbsrcNAddr; i++)
		{
			byte1 = localNAddrLst_1V[i]&0x000000ff;
            byte2 = (localNAddrLst_1V[i]&0x0000ff00)>>8;
			byte3 = (localNAddrLst_1V[i]&0x00ff0000)>>16;
			byte4 = (localNAddrLst_1V[i]&0xff000000)>>24;
            XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP TSAP] ��addr = %d.%d.%d.%d\n",byte4,byte3,byte2,byte1);

		}

    }/* if((print_action&SCTP_PRINT_SCTSAP_INFO)||(print_action&SCTP_PRINT_ALL_INFO)) */
   
    if((print_action&SCTP_PRINT_STATS_INFO)||(print_action&SCTP_PRINT_ALL_INFO))
    {
        XOS_CliExtPrintf(pCliEnv,"\r\n------------------- SCTP STAT INFO ----------------------\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number INITs sent     = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noInitTx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number INITs resent   = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noInitReTx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number INITs received = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noInitRx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number INIT_ACKs sent = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noIAckTx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number INIT_ACKs received = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noIAckRx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number SHUTDOWNs sent     = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noShDwnTx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number SHUTDOWNs resent   = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noShDwnReTx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number SHUTDOWNs received = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noShDwnRx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number SHUTDOWN_ACKs sent = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noShDwnAckTx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number SHUTDOWN_ACKSs resent  = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noShDwnAckReTx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number SHUTDOWN_ACKs received = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noShDwnAckRx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number COOKIEs sent     = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noCookieTx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number COOKIEs resent   = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noCookieReTx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number COOKIEs received = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noCookieRx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number COOKIE_ACKs sent = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noCkAckTx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number COOKIE_ACKs received = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noCkAckRx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number DATAs sent           = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noDataTx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number DATAs resent         = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noDataReTx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number DATAs received       = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noDataRx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number SACKs sent           = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noDAckTx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number SACKs received       = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noDAckRx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number of Shutdown completed sent     = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noShDwnCmpltTx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number of Shutdown completed received = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noShDwnCmpltRx);
#ifdef LSB2
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number of HEARTBEATs sent     = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noHBeatTx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number of HEARTBEATs received = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noHBeatRx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number of HBEAT_ACKs sent     = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noHBAckTx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number of HBEAT_ACKs received = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noHBAckRx);
#endif
#ifdef LSB3
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number of ABORTs sent         = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noAbortTx);
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP STAT]number of ABORTs received     = %d\r\n",sbGlobalCb.genSts.sbChunkSts.noAbortRx);
#endif
    }  
  
    return;
}
 
/*
*
*       ����:   sbCfgProtocol
*
*       ����:   ����SCTPЭ�麯��������GEN��SCTSAP��TSAP���á�
*
*       ����ֵ: ��
*
*       �ļ�:  sb_dbg.c
*
*/
XVOID  sbCfgProtocol(CLI_ENV* pCliEnv,XS32  siArgc,XCHAR **ppArgv)
{
    if(siArgc != 2)
    {
        XOS_CliExtPrintf(pCliEnv,"\r\nParameter Input Error!\r\n");
        return;        
    }
    if((XOS_StrCmp(ppArgv[0],"config")!=0))
    {
        XOS_CliExtPrintf(pCliEnv,"\r\nParameter Input Error!\r\n");
        return;
    }	

    if((XOS_StrCmp(ppArgv[1],"gen")==0)||(XOS_StrCmp(ppArgv[1],"all")==0))
    	{
    	sctp_config_gen();
    	}

    if((XOS_StrCmp(ppArgv[1],"sct")==0)||(XOS_StrCmp(ppArgv[1],"all")==0))
    	{
    	sctp_config_sctsap();
    	}
    if((XOS_StrCmp(ppArgv[1],"tsap")==0)||(XOS_StrCmp(ppArgv[1],"all")==0))
    	{
    	sctp_config_tsap();
    	}
	return;
}


/*
*
*       ����:   sbDbgSwitch
*
*       ����:   SCTP Э����ٿ��ء�
*
*       ����ֵ: ��
*
*       �ļ�:  sb_dbg.c
*
*/
XVOID  sbDbgSwitch(CLI_ENV* pCliEnv,XS32  siArgc,XCHAR **ppArgv)
{

#ifdef DEBUGP
    if( siArgc != 2 ) 
    {
        
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]Input Parameter no. != 2.\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\nUsage:\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\ndebug <on | off>\r\n");
        return;
    }      
    if((XOS_StrCmp(ppArgv[0],"debug")!=0))
    {
        XOS_CliExtPrintf(pCliEnv,"\r\nParameter Input command Error!\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\nUsage:\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\ndebug <on | off>\r\n");        
        return;
    }
    if((XOS_StrCmp(ppArgv[1],"on")==0))
    {
        sbGlobalCb.sbInit.dbgMask = 0xffffffff;
    } 
    if((XOS_StrCmp(ppArgv[1],"off")==0))
    {
        sbGlobalCb.sbInit.dbgMask = 0;
    }
#else
    XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]NOT COMPILE WITH: DEBUGP.\r\n");
#endif
}

/*
*
*       ����:   sbDbgBndtucl
*
*       ����:   ��SCTP��TUCL��
*
*       ����ֵ: ��
*
*       �ļ�:  sb_dbg.c
*
*/
XVOID  sbDbgBndtucl(CLI_ENV* pCliEnv,XS32  siArgc,XCHAR **ppArgv)
{
    Pst  pst;
    SuId suId;
    SpId spId;
    U8   flag=0;
    U8   i=0;
    
    if( siArgc != 3 ) 
    {
        
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]Input Parameter no. != 2.\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\nUsage:\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\nbind sctp tucl\r\n");
        return;
    }      
    if((XOS_StrCmp(ppArgv[0],"bind")!=0))
    {
        XOS_CliExtPrintf(pCliEnv,"\r\nParameter Input command Error!\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\nUsage:\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\nbind sctp tucl\r\n");       
        return;
    }
    if((XOS_StrCmp(ppArgv[1],"sctp")!=0))
    {
        XOS_CliExtPrintf(pCliEnv,"\r\nParameter Input command Error!\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\nUsage:\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\nbind sctp tucl\r\n");        
        return;
    }
    if((XOS_StrCmp(ppArgv[2],"tucl")!=0))
    {
        XOS_CliExtPrintf(pCliEnv,"\r\nParameter Input command Error!\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\nUsage:\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\nbind sctp tucl\r\n");        
        return;
    }
#if 0    
    for(i=0;i<sbGlobalCb.genCfg.maxNmbTSaps;i++)
    {
          if (( sbGlobalCb.tSaps[i] != (SbTSapCb *) NULLP )&& \
              (sbGlobalCb.tSaps[i].sapState == SB_SAPSTATE_UBND))
          {
              suId = i;
              flag =1;
              break;
          }
    }
    if(!flag);
#endif 
    
     suId = 0;
     spId = 0;

#ifdef LCHIUIHIT
    pst.selector  = SEL_LC;
#else
    pst.selector  = SEL_TC;
#endif

    pst.dstProcId = SFndProcId();
    pst.srcProcId = SFndProcId();
    pst.dstEnt    = ENTHI;
    pst.dstInst   = 0;
    pst.srcEnt    = ENTSB;
    pst.srcInst   = 0;
    pst.prior     = PRIOR0;
    pst.route     = RTESPEC;
    pst.region    = DFLT_REGION;
    pst.pool      = DFLT_POOL;

    SbLiHitBndReq(&pst, suId, spId);
    return;
}


Bool XOS_CLIRegCommand_SB(Void)
{
	XS32 ret = 0;
	XS32 cmdIndex=0,sctpcmdIndex=0 ;
	cmdIndex =     XOS_RegistCmdPrompt( SYSTEM_MODE, "prtl", "Э��ģʽ", "�޲���" );
	sctpcmdIndex=     XOS_RegistCmdPrompt( cmdIndex, "sctp", "sctp Э��", "�޲���" );
#if 0    
	XOS_RegistCommand(sctpcmdIndex,
		              sbCfgProtocol,
					  "config",
					  "�ֹ�����SCTP",
					  "gen\r\nsct\r\ntsap\r\nall\r\n");
#endif
	XOS_RegistCommand(sctpcmdIndex,
		              sbDbgSwitch,
					  "debug",
					  "�ֹ���/�ر�debug����",
					  "on\r\noff\r\n");
#if 0
	XOS_RegistCommand(sctpcmdIndex,
		              sbDbgBndtucl,
					  "bind",
					  "�ֹ���sctp��tucl",
					  "sctp tucl\r\n");
#endif
	XOS_RegistCommand(sctpcmdIndex,
		              sbStateDbgPrint,
					  "show",
					  "��ʾSCTP������Ϣ",
					  "config\r\ninit\r\nlayer\r\nassoc\r\nendp\r\nsctsap\r\ntsap\r\nstat\r\nall\r\n");
					  
    return ROK;
}


#endif /* SSI_WITH_CLI_ENABLED */


#if 0


void  sbCfgBndtucl(void)
{
    Pst  pst;
    SuId suId;
    SpId spId;
    U8   flag=0;
    U8   i=0;
    
     suId = 0;
     spId = 0;

#ifdef LCHIUIHIT
    pst.selector  = SEL_LC;
#else
    pst.selector  = SEL_TC;
#endif

    pst.dstProcId = SFndProcId();
    pst.srcProcId = SFndProcId();
    pst.dstEnt    = ENTHI;
    pst.dstInst   = 0;
    pst.srcEnt    = ENTSB;
    pst.srcInst   = 0;
    pst.prior     = PRIOR0;
    pst.route     = RTESPEC;
    pst.region    = DFLT_REGION;
    pst.pool      = DFLT_POOL;

    SbLiHitBndReq(&pst, suId, spId);
    return;
}

#endif



/*
*
*       ����:   sb_print_state_cb_info
*
*       ����:   ��ӡSCTPЭ��״̬��Ϣ����������GEN��SCTSAP��TSAP���ã�ż����Ϣ���˵���Ϣ��
*
*       ����ֵ: �ɹ�  ROK
*               ʧ��  RFAILED
*
*       �ļ�:  sb_dbg.c
*
*/
PUBLIC S16  sb_print_state_cb_info(U16 print_action)
{
#if 0
    SbGenSta      genSta;   /* ��״̬��Ϣ */
    SbGenCfg      genCfg;   /* SCTPͨ��������Ϣ */
    TskInit       sbInit;   /* SCTPϵͳ��ʼ����Ϣ */
    SbSctEndpCb   endpCb;   /* �˵���ƿ� */
    SbSctAssocCb  assocCb;  /* ż�����ƿ� */
    SbSctSapCb    sctSaps;  /* SCT SAP���ƿ� */
    SbTSapCb      tSaps;    /* TSAP���ƿ� */
#endif	
    SbGenCfg      GbGenCfg;   /* SCTPͨ��������Ϣ */    
    int           i=0;    
        
    if( sbGlobalCb.sbInit.cfgDone != TRUE )  
    {   
        printf("\r\n[SCTP]WARN:SCTP protocol has not been configed yet.\r\n");
        RETVALUE(RFAILED);
    }/* if( sbGlobalCb.sbInit.cfgDone == TRUE ) */

    if((print_action&SCTP_PRINT_CONFIG_INFO)||(print_action&SCTP_PRINT_ALL_INFO))
    {
        (Void) cmMemcpy((U8 *) &GbGenCfg, (U8 *) &sbGlobalCb.genCfg, sizeof(SbGenCfg));
        printf("\r\n------------------- SCTP GEN CONFIG BEGIN ---------------------\r\n");
#ifdef SB_IPV6_SUPPORTED
        /* IPV6 service required for sctp */ 
        if( TRUE == GbGenCfg.ipv6SrvcReqdFlg)
        {
            printf("\r\n[SCTP]genCfg.ipv6SrvcReqdFlg       = TRUE \r\n");
        }
        else
        {
            printf("\r\n[SCTP]genCfg.ipv6SrvcReqdFlg       = FALSE \r\n");
        }   

#endif  /* SB_IPV6_SUPPORTED  */

        /* TUCL transport protocol (IP/UDP) */      
        printf("\r\n[SCTP]TUCL transport protocol (IP/");
        switch(GbGenCfg.serviceType)
        {
            case HI_SRVC_UDP:
                printf("UDP");
                break;
            case HI_SRVC_TCP:
                printf("TCP");
                break;
            case HI_SRVC_TCP_TPKT_HDR:
                printf("TCP TPKT HDR");
                break;
            case HI_SRVC_UDP_PRIOR:
                printf("UDP PRIOR");
                break;
            case HI_SRVC_UDP_TPKT_HDR:
                printf("UDP TPKT HDR");
                break;
            case HI_SRVC_RAW_RAW:
                printf("RAW RAW");
                break;
            case HI_SRVC_RAW_SCTP:
                printf("RAW SCTP");
                break;
            case HI_SRVC_RAW_ICMP:
                printf("RAW ICMP");
                break;
            default:
                break;                               
        }
		printf(")\n");
        /* max no. SCT SAPS */
        printf("\r\n[SCTP]max no. SCT SAPS        = %d\r\n",GbGenCfg.maxNmbSctSaps);
        /* max no. Transport SAPS */
        printf("\r\n[SCTP]max no. Transport SAPS  = %d\r\n",GbGenCfg.maxNmbTSaps);
        /* max no. endpoints */
        printf("\r\n[SCTP]max no. endpoints       = %d\r\n",GbGenCfg.maxNmbEndp);
        /* max no. associations */
        printf("\r\n[SCTP]max no. associations    = %d\r\n",GbGenCfg.maxNmbAssoc);
        /* max no. dest. addresses */
        printf("\r\n[SCTP]max no. dest. addresses = %d\r\n",GbGenCfg.maxNmbDstAddr);
        /* max no. src. addresses */
        printf("\r\n[SCTP]max no. src.  addresses = %d\r\n",GbGenCfg.maxNmbSrcAddr);
        /* max no. outgoing chunks */
        printf("\r\n[SCTP]max no. outgoing chunks = %d\r\n",GbGenCfg.maxNmbTxChunks);
        /* max no. recv chunks */
        printf("\r\n[SCTP]max no. receive  chunks = %d\r\n",GbGenCfg.maxNmbRxChunks);
        /* max no. in streams PER ASSOCIATION */
        printf("\r\n[SCTP]max no. in  streams PER ASSOCIATION   = %d\r\n",GbGenCfg.maxNmbInStrms);
        /* max no. out streams PER ASSOCIATION */
        printf("\r\n[SCTP]max no. out streams PER ASSOCIATION   = %d\r\n",GbGenCfg.maxNmbOutStrms);
        /* max receiver window space */
        printf("\r\n[SCTP]max receiver window space  = %d\r\n",GbGenCfg.initARwnd);

        /* Perform path MTU discovery */
        if( TRUE == GbGenCfg.performMtu)
        {
            printf("\r\n[SCTP]genCfg.performMtu          = YES\r\n");
            printf("\r\n[SCTP]genCfg.mtuInitial          = %d\r\n",GbGenCfg.mtuInitial);
            printf("\r\n[SCTP]genCfg.mtuMinInitial       = %d\r\n",GbGenCfg.mtuMinInitial);
            printf("\r\n[SCTP]genCfg.mtuMaxInitial       = %d\r\n",GbGenCfg.mtuMaxInitial);
        }
        else
        {
            printf("\r\n[SCTP]genCfg.performMtu          = FALSE \r\n");
        }
        /* Flag whether hostname is to be used in INIT and INITACK msg */        
        if( TRUE == GbGenCfg.useHstName)
        {
            printf("\r\n[SCTP]genCfg.useHstName          = TRUE \r\n");
            printf("\r\n[SCTP]genCfg.hostname            = %s\r\n",GbGenCfg.hostname);
        }
        else
        {
            printf("\r\n[SCTP]genCfg.useHstName          = FALSE \r\n");
        }
        printf("\r\n------------------- SCTP GEN CONFIG END ---------------------\r\n");
    }    

#if 0    
    if((print_action&SCTP_PRINT_INIT_INFO)||(print_action&SCTP_PRINT_ALL_INFO))
    {
        /* ��ӡSCTPϵͳ��ʼ����Ϣ */
        (Void) cmMemcpy((U8 *) &sbInit, (U8 *) &sbGlobalCb.sbInit, sizeof(TskInit));
        printf("\n------------------- SCTP  Init INFO ---------------------\n");
        
        
        printf("[SCTP Init]entity      = %d\n",sbInit.ent);
        printf("[SCTP Init]instance    = %d\n",sbInit.inst);
        printf("[SCTP Init]static region   = %d\n",sbInit.region);
        printf("[SCTP Init]static pool     = %d\n",sbInit.pool);
        if(sbInit.acnt == TRUE )
        {
            printf("[SCTP Init]do accounting :YES\n");
        }
        else
        {
            printf("[SCTP Init]do accounting :NO\n");
        }
        
        if(sbInit.usta == TRUE )
        {
            printf("[SCTP Init]do unsolicited status :YES\n");
        }
        else
        {
            printf("[SCTP Init]do unsolicited status :NO\n");
        }
        
        if(sbInit.trc == TRUE )
        {
            printf("[SCTP Init]do trace :YES\n");
        }
        else
        {
            printf("[SCTP Init]do trace :NO\n");
        }
        
    }/* if((print_action&SCTP_PRINT_INIT_INFO)||(print_action&SCTP_PRINT_ALL_INFO)) */
    
    if((print_action&SCTP_PRINT_LAYER_INFO)||(print_action&SCTP_PRINT_ALL_INFO))
    {
        /* ��ӡSCTPЭ���״̬��Ϣ */
        (Void) cmMemcpy((U8 *) &genSta, (U8 *) &sbGlobalCb.genSta, sizeof(SbGenSta));
        printf("\n------------------- SCTP Layer INFO ---------------------\n");
        
        
        printf("[SCTP]genSta.status      = %d\n",genSta.status);
        printf("[SCTP]Memory Size Reserved    = %d\n",genSta.memSize);
        printf("[SCTP]Memory Size Allocated   = %d\n",genSta.memAlloc);
        printf("[SCTP]Number of open associations = %d\n",genSta.nmbAssoc);
        printf("[SCTP]Number of open endpoints    = %d\n",genSta.nmbEndp);
        printf("[SCTP]Number of local addresses in use    = %d\n",genSta.nmbLocalAddr);
        printf("[SCTP]Number of peer addresses in use     = %d\n\n",genSta.nmbPeerAddr);
        
    } /* if((print_action&SCTP_PRINT_LAYER_INFO)||(print_action&SCTP_PRINT_ALL_INFO)) */
    
    if((print_action&SCTP_PRINT_ASSOC_INFO)||(print_action&SCTP_PRINT_ALL_INFO))
    {
        /* ��ӡSCTP ż��״̬��Ϣ */
        printf("\n------------------- SCTP ASSOC INFO ---------------------\n");    
        (Void) cmMemcpy((U8 *) &genCfg, (U8 *) &sbGlobalCb.genCfg, sizeof(SbGenCfg));
        for(i = 0;i < genCfg.maxNmbSctSaps; i++)
        {
	    	if ( sbGlobalCb.assocCb[i] != (SbSctAssocCb  *) NULLP )
	    	{
	    	    (Void) cmMemcpy((U8 *) &assocCb, (U8 *) sbGlobalCb.assocCb[i], sizeof(SbSctAssocCb));
	    	    printf("[SCTP association]  Id   = %d\n",i);
	    	    printf("[SCTP association]  SCT SAP ID   = %d\n",assocCb.spId);
	    	    printf("[SCTP association]  SCTP endpoint ID   = %d\n",assocCb.endpId);
	    	    printf("[SCTP association]  User's side association id   = %d\n",assocCb.suAssocId);
	    	    printf("[SCTP association]  Own association ID   = %d\n",assocCb.spAssocId);
	    	    printf("[SCTP association]  Source SCTP Port   = %d\n",assocCb.localPort);
	    	    printf("[SCTP association]  Destination SCTP Port   = %d\n",assocCb.peerPort);
	    	    printf("[SCTP association]  Association's current state:");
	    	    switch(assocCb.assocState)
	    	    {
	    	        case SCT_ASSOC_STATE_CLOSED:
	    	            printf("STATE CLOSED\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_OPEN:
	    	            printf("STATE OPEN\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_COOKIE_WAIT:
	    	            printf("STATE COOKIE WAIT\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_ESTABLISHED:
	    	            printf("STATE ESTABLISHED\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_COOKIE_SENT:
	    	            printf("STATE COOKIE SENT\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_SDOWN_PEND:
	    	            printf("STATE SHUTDOWN PEND\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_SDOWN_SENT:
	    	            printf("STATE SHUTDOWN SENT\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_SDOWN_RCVD:
	    	            printf("STATE SHUTDOWN RCVD\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_SDOWNACK_SENT:
	    	            printf("STATE SHUTDOWN ACK SENT\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_AWTDNS_RSP_COOKIE:
	    	            printf("STATE Send DNS Query to DNS server and awaiting response\n");
	    	            break;
	    	        case SCT_ASSOC_STATE_AWTDNS_RSP_COOKIEACK:
	    	            printf("STATE Send DNS Query to DNS server and awaiting response\n");
	    	            break;
	    	        default:
	    	            printf("ERROR STATE.\n");
	    	            break;
	    	                
	    	    } /* switch(assocCb.assocState) */
        
	    	}     /* if ( sbGlobalCb.assocCb[i] != (SbSctAssocCb  *) NULLP ) */
	    	
        }         /* for(i = 0;i < genCfg.maxNmbSctSaps; i++) */     
           
    }  /* if((print_action&SCTP_PRINT_ASSOC_INFO)||(print_action&SCTP_PRINT_ALL_INFO)) */        


    if((print_action&SCTP_PRINT_ENDP_INFO)||(print_action&SCTP_PRINT_ALL_INFO))
    {
        /* ��ӡSCTP �˵�״̬��Ϣ */
        printf("\n------------------- SCTP ENDPT INFO ---------------------\n");
        
        for ( i = 0; i < genCfg.maxNmbEndp; i++ )
        {
          if ( sbGlobalCb.endpCb[i] != (SbSctEndpCb *) NULLP )
          {
             
             (Void) cmMemcpy((U8 *) &endpCb, (U8 *) sbGlobalCb.endpCb[i], sizeof(SbSctEndpCb));
             printf("[SCTP Endpoint] ��Id   = %d\n",i);
             printf("[SCTP Endpoint] ��Source Address List:\n");
             printf("[SCTP Endpoint] ��Port number = %d\n",endpCb.port);         
             printf("[SCTP Endpoint] ��SCT SAP ID = %d\n",endpCb.spId);
             printf("[SCTP Endpoint] ��Service user's endpoint ID = %d\n",endpCb.suEndpId);
             printf("[SCTP Endpoint] ��Local endpoint ID = %d\n",endpCb.spEndpId);
          }
        }        
    }/* if((print_action&SCTP_PRINT_ENDP_INFO)||(print_action&SCTP_PRINT_ALL_INFO)) */

    if((print_action&SCTP_PRINT_SCTSAP_INFO)||(print_action&SCTP_PRINT_ALL_INFO))
    {
        printf("\n------------------- SCTP SCTSAP INFO ---------------------\n");
        for ( i = 0; i < genCfg.maxNmbSctSaps; i++ )
        {
          if ( sbGlobalCb.sctSaps[i] != (SbSctSapCb *) NULLP )
          { 
             (Void) cmMemcpy((U8 *) &sctSaps, (U8 *) sbGlobalCb.sctSaps[i], sizeof(SbSctSapCb));
             printf("[SCTP SCTSAP] ��suID    = %d\n",sctSaps.suId);
             printf("[SCTP SCTSAP] ��spID    = %d\n",i);         
             printf("[SCTP SCTSAP] ��STATE: ");
             switch(sctSaps.sapState)
             {
	    	        case SB_SAPSTATE_UBND:
	    	            printf("UNBOUND.\n");
	    	            break;
	    	        case SB_SAPSTATE_BND:
	    	            printf("BOUND.\n");
	    	            break;
	    	        default:
	    	            printf("ERROR.\n");
	    	            break;		            		                        
             }
             
          }
        }        
    }/* if((print_action&SCTP_PRINT_SCTSAP_INFO)||(print_action&SCTP_PRINT_ALL_INFO)) */

   if((print_action&SCTP_PRINT_SCTSAP_INFO)||(print_action&SCTP_PRINT_ALL_INFO))
   {
        printf("\n------------------- SCTP TSAP INFO ---------------------\n");
        for ( i = 0; i < genCfg.maxNmbTSaps; i++ )
        {
          if ( sbGlobalCb.tSaps[i] != (SbTSapCb *) NULLP )
          { 
             (Void) cmMemcpy((U8 *) &tSaps, (U8 *) sbGlobalCb.tSaps[i], sizeof(SbTSapCb));
             printf("[SCTP TSAP] ��suID    = %d\n",i);
             printf("[SCTP TSAP] ��STATE: ");
             switch(tSaps.sapState)
             {
	    	        case SB_SAPSTATE_UBND:
	    	            printf("UNBOUND.\n");
	    	            break;
	    	        case SB_SAPSTATE_BND:
	    	            printf("BOUND.\n");
	    	            break;
	    	        default:
	    	            printf("ERROR.\n");
	    	            break;		            		                        
             }
          }
        }     
    }/* if((print_action&SCTP_PRINT_SCTSAP_INFO)||(print_action&SCTP_PRINT_ALL_INFO)) */
#endif
    RETVALUE(ROK);
}


#if 0


void  sbBndHiReq(SuId suId)
{
    Pst  pst;
    
    SpId spId;
    U8   flag=0;
    U8   i=0;
    

     spId = 0;

#ifdef LCHIUIHIT
    pst.selector  = SEL_LC;
#else
    pst.selector  = SEL_TC;
#endif

    pst.dstProcId = SFndProcId();
    pst.srcProcId = SFndProcId();
    pst.dstEnt    = ENTHI;
    pst.dstInst   = 0;
    pst.srcEnt    = ENTSB;
    pst.srcInst   = 0;
    pst.prior     = PRIOR0;
    pst.route     = RTESPEC;
    pst.region    = DFLT_REGION;
    pst.pool      = DFLT_POOL;

    SbLiHitBndReq(&pst, suId, spId);
    return;
}


#endif


/*added by wanglijun for set dbgmask from shell*/
#ifdef SB_DEBUGP
U32 g_sbDbgMask = DBGMASK_LI|DBGMASK_UI|DBGMASK_MI;
#else
U32 g_sbDbgMask = 0;
#endif

Void sbSetDbgMaskFromShell(U32 dbgMask)
{
  g_sbDbgMask = dbgMask;
#ifdef DEBUGP
  sbGlobalCb.sbInit.dbgMask = g_sbDbgMask;
#endif
  RETVOID;
}

/********************************************************************30**

         End of file:     sb_dbg.c@@/main/2 - 2006-05-11

*********************************************************************31*/
