#include "sb_common.h"




void  sbCfgBndtucl(void)
{
    Pst  pst;
    SuId suId;
    SpId spId;
    U8   flag=0;
    U8   i=0;
    
     suId = 0;
     spId = 0;

#ifdef LCHIUIHIT
    pst.selector  = SEL_LC;
#else
    pst.selector  = SEL_TC;
#endif

    pst.dstProcId = SFndProcId();
    pst.srcProcId = SFndProcId();
    pst.dstEnt    = ENTHI;
    pst.dstInst   = 0;
    pst.srcEnt    = ENTSB;
    pst.srcInst   = 0;
    pst.prior     = PRIOR0;
    pst.route     = RTESPEC;
    pst.region    = DFLT_REGION;
    pst.pool      = DFLT_POOL;

    SbLiHitBndReq(&pst, suId, spId);
    return;
}


void  sbBndHiReq(SuId suId)
{
    Pst  pst;
    
    SpId spId;
    U8   flag=0;
    U8   i=0;
    

     spId = 0;

#ifdef LCHIUIHIT
    pst.selector  = SEL_LC;
#else
    pst.selector  = SEL_TC;
#endif

    pst.dstProcId = SFndProcId();
    pst.srcProcId = SFndProcId();
    pst.dstEnt    = ENTHI;
    pst.dstInst   = 0;
    pst.srcEnt    = ENTSB;
    pst.srcInst   = 0;
    pst.prior     = PRIOR0;
    pst.route     = RTESPEC;
    pst.region    = DFLT_REGION;
    pst.pool      = DFLT_POOL;

    SbLiHitBndReq(&pst, suId, spId);
    return;
}

