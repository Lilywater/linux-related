/* ***************************************************************************
 *        (c) COPYRIGHT 1995-2006 by Xinwei, Inc.
 *                   All rights reserved.
 *
 * sb_init.c:  
 *          Sctp protocol initialize function.
 *           
 * Author:
 *          zhouguishuang
 * Date:
 *          2006-5-8
 * Last Modified:
 *
 ****************************************************************************/

#include"sb_common.h"

#ifdef CP_OAM_SUPPORT
/*#include "sm.h"*/
#include "xosshell.h"
#include "cp_tab_def.h"
#include "sm.x"
#include "sb_cfg.h"

#include "sb_oam.x"
#include "oam_interface.h"
#include "oam_tab_def.h"
#include "cp_oam_stru.x"

extern S16 smSbSendReqQ(CmLList *node);
extern unsigned char sbNmInitCallback(unsigned short msgtype, unsigned int sepuense, unsigned char pack_end, tb_record* prow);
extern VOID sbResetCfgData(void);
#endif

PUBLIC S16 ssiInit(void);

SSTskId sbTskId;
SSTskId smTskId;
#ifdef HI
extern PUBLIC S16 hi_init_fun(SSTskId hiTskId);
#endif


Bool g_sctptaskRegComp=FALSE;


PUBLIC S16 sctp_sys_init_fun(void)
{
	S16 rc=ROK;
	rc = ssiInit();
	if (rc!=ROK)
	{
		printf(" SSI Init Failed!\n");
		return(RFAILED);
	} 
	rc = sb_init_fun();
	if (rc!=ROK)
	{
		printf(" SCTP Init Failed!\n");
		return(RFAILED);
	} 
	g_sctptaskRegComp = TRUE;
	return(ROK);
}

Bool get_sctptaskRegComp(void)
{
      return(g_sctptaskRegComp);
}

PUBLIC S16 sb_init_fun(void)
{
    char prntBuf[255];
   
	sbTskId =0;
	/* ����SCTPϵͳ���� */
   if (SCreateSTsk((SSTskPrior)PRIOR0, &(sbTskId)) != ROK)
   {
      RETVALUE(RFAILED);
   }
    
#if 1   /* SM TAPA ����Ӧ�ò������ﴴ��,�����ʱ�ŵ�����,���Ҫ���ɵĻ���Ҫͳһ�滮 */
   smTskId=0;
   smTskId = sbTskId;

#if 0
   /* ע�� SM TAPA ���� */
   if (SRegTTsk((Ent)ENTSM, (Inst)0, (Ttype)TTNORM, (Prior)PRIOR0,
                smSbActvInit, smSbActvTsk) != ROK)
   {
      sprintf(prntBuf, "tst:SRegTTsk() for SCTP failed.\n");
      RETVALUE(RFAILED);
   }
#endif
   /* ע�� SM TAPA ���� */
   if (SRegTTsk((Ent)ENTSM, (Inst)0, (Ttype)TTNORM, (Prior)PRIOR0,
                smActvInit, smActvTsk) != ROK)
   {
      sprintf(prntBuf, "tst:SRegTTsk() for SCTP failed.\n");
      RETVALUE(RFAILED);
   }

   /* ƥ�� SM TAPA ���� */
   if (SAttachTTsk((Ent)ENTSM, (Inst)0, smTskId)!= ROK)
   {
      sprintf(prntBuf, "tst:SAttachTTsk() for SCTP failed.\n");
      RETVALUE(RFAILED);
   }   
#endif



 

   /* ע�� SCTP TAPA ���� */
   if (SRegTTsk((Ent)ENTSB, (Inst)0, (Ttype)TTNORM, (Prior)PRIOR0,
                sbActvInit, sbActvTsk) != ROK)
   {
      sprintf(prntBuf, "tst:SRegTTsk() for SCTP failed.\n");
      RETVALUE(RFAILED);
   }

   /* ƥ�� SCTP TAPA ���� */
   if (SAttachTTsk((Ent)ENTSB, (Inst)0, sbTskId)!= ROK)
   {
      sprintf(prntBuf, "tst:SAttachTTsk() for SCTP failed.\n");
      RETVALUE(RFAILED);
   }



#ifdef  HI

    hi_init_fun(0);

#endif
   
   RETVALUE(ROK);
}




PUBLIC S16 sb_init_own(SSTskId sbTskId1)
{
    char prntBuf[255];
   
   if(sbTskId1 == 0)
   {
		/* ����SCTPϵͳ���� */
	   if (SCreateSTsk((SSTskPrior)PRIOR3, &(sbTskId1)) != ROK)
	   {
	      RETVALUE(RFAILED);
	   }
   }
 

   /* ע�� SCTP TAPA ���� */
   if (SRegTTsk((Ent)ENTSB, (Inst)0, (Ttype)TTNORM, (Prior)PRIOR0,
                sbActvInit, sbActvTsk) != ROK)
   {
      sprintf(prntBuf, "tst:SRegTTsk() for SCTP failed.\n");
      RETVALUE(RFAILED);
   }

   /* ƥ�� SCTP TAPA ���� */
   if (SAttachTTsk((Ent)ENTSB, (Inst)0, sbTskId1)!= ROK)
   {
      sprintf(prntBuf, "tst:SAttachTTsk() for SCTP failed.\n");
      RETVALUE(RFAILED);
   }

#ifdef CP_OAM_SUPPORT
   
   if( ROK != smRegCb((Ent)ENTSB, sbCmListSQ, sizeof(sbCmListSQ)/sizeof(CmLListCp),smSbSendReqQ,sbResetCfgData))
   {
      RETVALUE(RFAILED);
   }

	if( OAM_CALL_SUCC != register_msg_proc(CP_MODULE_ID_VOIP_SCTP,  APP_SYNC_MSG,  sbNmInitCallback, NULL))
	{
      RETVALUE(RFAILED);
   } 

   (unsigned char)get_resource(xwCpComIpTable, sizeof(CP_OAM_COM_IP_TAB), xwCpComIpTable_ROW_NUM);
   (unsigned char)get_resource(xwCpSctpGenCfg, sizeof(SbCfgGenOam), xwCpSctpGenCfg_ROW_NUM);
   (unsigned char)get_resource(xwCpSctpNetAddrCfg, sizeof(SbCfgAddrOam), xwCpSctpNetAddrCfg_ROW_NUM);
   
   if( OAM_CALL_SUCC != app_register(CP_MODULE_ID_VOIP_SCTP, &sbCfgTbl[0], 3))
   {
      RETVALUE(RFAILED);
   }
  
#endif /*CP_OAM_SUPPORT*/

   RETVALUE(ROK);
}





PUBLIC S16 sm_init_fun1
(
VOID
)
{
	SSTskId tskId=0;
	
	if (ROK != SRegTTsk(ENTSM, 0, TTNORM, PRIOR0, smActvInit, smActvTsk))
	{
		RETVALUE(RFAILED);
	}

	if(tskId == 0)
	{
	    if (SCreateSTsk(PRIOR0, &tskId) != ROK)
	    {
	         RETVALUE(RFAILED);
	    }
	}

	if (ROK != SAttachTTsk(ENTSM, 0, tskId))
	{
		RETVALUE(RFAILED);
	}

	RETVALUE(ROK);
}


PUBLIC S16 sb_message_fun(void)
{
    RETVALUE(ROK);
}


PUBLIC S16 sb_timer_fun(void)
{
    RETVALUE(ROK);
}

