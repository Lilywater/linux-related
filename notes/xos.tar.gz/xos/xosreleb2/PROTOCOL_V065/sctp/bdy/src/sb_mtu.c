/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**

     Name:     Path MTU discovery for the SCTP Layer

     Type:     C source file

     Desc:     Source file for path MTU discovery

     File:     sb_mtu.c

     Sid:      sb_mtu.c@@/main/2 - Wed Jan 10 16:24:54 2001

     Prg:      bk

*********************************************************************21*/

#ifndef __SB_MTUC__
#define __SB_MTUC__

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_tpt.h"        /* common transport defines */
#include "cm_dns.h"        /* Common DNS library */
#ifdef SB_FTHA
#include "sht.h"           /* SHT Interface header file */
#endif /* SB_FTHA */
#include "sct.h"           /* SCT interface */
#include "lsb.h"           /* layer management, SCTP  */
#include "hit.h"           /* HIT interface */
#include "sb_mtu.h"
#include "sb.h"            /* SCTP internal defines */
#include "sb_err.h"        /* SCTP error */

/* header/extern include files (.x) */
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_tpt.x"        /* common transport*/
#include "cm_dns.x"        /* Common DNS library */
#ifdef SB_FTHA
#include "sht.x"           /* SHT Interface header file */
#endif /* SB_FTHA */
#include "sct.x"           /* SCT interface */
#include "lsb.x"           /* layer management SCTP */
#include "hit.x"           /* HIT interface */
#include "sb_mtu.x"
#include "sb.x"            /* SCTP internal typedefs */



PRIVATE U16 sbMtuChecksum        ARGS((U16         *buffer,
                                       U16         size));

PRIVATE S16 sbMtuParseIcmp       ARGS((SbMtuCp     *mtuCp,
                                       U8          ver,
                                       Bool        *valid,
                                       U16         *mtu,
                                       CmNetAddr   *dst,
                                       Buffer      *mBuf));




/*
*
*      Fun:   sbMtuGetMemReq
*
*      Desc:  This function is called to query the amount of memory that
*             will be required by the Path MTU Discovery module. It excludes
*             the memory required by the SbMtuCp structure.
*
*      Ret:   ROK
*             RFAILED
*
*      Notes: None
*
*      File:  sb_mtu.c
*
*/
#ifdef ANSI
PUBLIC S16  sbMtuGetMemReq
(
U16         maxAddr,
U32         *memSz
)
#else
PUBLIC S16  sbMtuGetMemReq(maxAddr, memSz)
U16         maxAddr;
U32         *memSz;
#endif
{
   TRC2(sbMtuGetMemReq);

#if (ERRCLASS & ERRCLS_DEBUG)

   if ( (maxAddr < SB_MTU_MIN_ADDR) || (maxAddr > SB_MTU_MAX_ADDR) )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB273, (ErrVal) maxAddr, "sbMtuGetMemReq(): invalid maxAddr");
      RETVALUE( RFAILED );
   }

   if ( memSz == (U32 *)NULLP )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB274, (ErrVal) 0, "sbMtuGetMemReq(): return value is NULL");
      RETVALUE( RFAILED );
   }

#endif
   *memSz = 0;

   /* sb023.102  - Memory size also added for pointer to mtuAddrCp's 
    * performance  change */
   *memSz = maxAddr * (sizeof(SbMtuAddrCb) + sizeof(CmListEnt) + sizeof(PTR));

   RETVALUE( ROK );
}


/*
*
*      Fun:   sbMtuInit
*
*      Desc:  This function is called to initialise the SbMtuCp structure
*
*      Ret:   ROK
*             RFAILED
*
*      Notes: None
*
*      File:  sb_mtu.c
*
*/
#ifdef ANSI
PUBLIC S16  sbMtuInit
(
SbMtuCp     *mtuCp,
U16         maxAddr,
U16         minMtu,
U16         maxMtu,
U16         startMtu,
Pool        pool,
Region      region
)
#else
PUBLIC S16  sbMtuInit(mtuCp, maxAddr, minMtu, maxMtu, startMtu, pool, region)
SbMtuCp     *mtuCp;
U16         maxAddr;
U16         minMtu;
U16         maxMtu;
U16         startMtu;
Pool        pool;
Region      region;
#endif
{
   U16 i;
   S16 ret=ROK;  /* Performance change - sb023.102 */

   TRC2(sbMtuInit);

#if (ERRCLASS & ERRCLS_DEBUG)

   if ( mtuCp == (SbMtuCp *)NULLP )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB275, (ErrVal) 0, "sbMtuInit(): mtuCp is NULL");
      RETVALUE( RFAILED );
   }

#endif

#ifdef DEBUGP
   mtuCp->prntBuf = &(sbGlobalCb.sbInit.prntBuf[0]);
#endif

   SBDBGP(SB_DBGMASK_MTU, (mtuCp->prntBuf,
          "sbMtuInit(mtuCp, maxAddr(%d), minMtu(%d), maxMtu(%d), startMtu(%d), pool, region)\n",
          maxAddr, minMtu, maxMtu, startMtu));

#if (ERRCLASS & ERRCLS_DEBUG)

   if ( (maxAddr < SB_MTU_MIN_ADDR) || (maxAddr > SB_MTU_MAX_ADDR) )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB276, (ErrVal) maxAddr, "sbMtuInit(): Incorrect number of maxAddr");
      RETVALUE( RFAILED );
   }

   if (startMtu < minMtu)
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB277, (ErrVal) startMtu, "sbMtuInit(): startMtu < minMtu");
      RETVALUE( RFAILED );
   }

   if (startMtu > maxMtu)
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB278, (ErrVal) startMtu, "sbMtuInit(): startMtu > maxMtu");
      RETVALUE( RFAILED );
   }

   if (mtuCp->state != SB_MTU_STATE_INACTIVE)
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB279, (ErrVal) mtuCp->state, "sbMtuInit(): invalid mtuCp state");
      RETVALUE( RFAILED );
   }

#endif

   mtuCp->pool = pool;
   mtuCp->region = region;

   mtuCp->maxAddr = maxAddr;
   mtuCp->minMtu = minMtu;
   mtuCp->maxMtu = maxMtu;
   mtuCp->startMtu = startMtu;

   mtuCp->nextIdx = 0;

   /* sb023.102 - Allocate the memory for pointers to addressCb's 
    * performance change */
   SB_MTU_ALLOC(mtuCp, (maxAddr*sizeof(SbMtuAddrCb *)), mtuCp->addrArray, ret);
   if(ret != ROK)
   {
      SBLOGERROR(ERRCLS_DEBUG, ESBXXX, (ErrVal) mtuCp->state, "sbMtuInit(): Memory Allocation failed");
      RETVALUE( RFAILED );
   }

   /* sb023.102 - Initialize all the pointer to addrCb as NULLP 
    * performance change */
   for (i = 0; i < mtuCp->maxAddr; i++)
   {
      mtuCp->addrArray[i] = (SbMtuAddrCb *)NULLP;
   }

   /* sb051.102: Changing Hash KeyType */
   cmHashListInit(&(mtuCp->addrHl), maxAddr, 0, TRUE, CM_HASH_KEYTYPE_U32MOD, region, pool);

   mtuCp->state = SB_MTU_STATE_ACTIVE;

   RETVALUE( ROK );
}



/*     Performance Change  - sb023.102  - Function Added 
*
*      Fun:   sbMtuGetMtuCb
*
*      Desc:  This function returns 
*
*      Ret:   ROK
*             RFAILED      (optional under ERRCLS_DEBUG)
*             ROUTRES      (get resources error)
*
*      Notes: None
*
*      File:  sb_mtu.c
*
*/
#ifdef ANSI
PUBLIC S16  sbMtuGetMtuCb
(
SbMtuCp     *mtuCp,
CmNetAddr   *addr,
U16         *idx
)
#else
PUBLIC S16  sbMtuGetMtuCb(mtuCp, addr, idx)
SbMtuCp     *mtuCp;
CmNetAddr   *addr;
U16         *idx;
#endif
{
   S16 err, i;
   U16 addrIdx=0;
   SbMtuAddrCb *mtuAddr;

   TRC2(sbMtuGetMtuCb);

#if (ERRCLASS & ERRCLS_DEBUG)

   if ( mtuCp == (SbMtuCp *)NULLP )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB280, (ErrVal) 0,
                 "sbMtuGetMtuCb: mtuCp is NULL");
      RETVALUE( RFAILED );
   }

   if ( addr == (CmNetAddr *)NULLP )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB281, (ErrVal) 0,
                 "sbMtuGetMtuCb: addr is NULL");
      RETVALUE( RFAILED );
   }

   if ( addr->type == CM_NETADDR_NOTPRSNT)
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB282, (ErrVal) 0, "sbMtuGetMtuCb(): addr is CM_NETADDR_NOTPRSNT");
      RETVALUE( RFAILED );
   }

   if (mtuCp->state != SB_MTU_STATE_ACTIVE)
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB284, (ErrVal) mtuCp->state,
                 "sbMtuGetMtuCb: invalid mtuCp state");
      RETVALUE( RFAILED );
   }

#endif

   mtuAddr = (SbMtuAddrCb *)NULLP;
   err = cmHashListFind(&(mtuCp->addrHl), (U8 *)addr, sizeof(CmNetAddr), 0,
                        (PTR *)&mtuAddr);

   if ( (err != ROK) || (mtuAddr == (SbMtuAddrCb *)NULLP) )
   {
      /* not found so add it */
      mtuAddr = (SbMtuAddrCb *)NULLP;
      if( mtuCp->addrArray[mtuCp->nextIdx] != NULLP )
      {
          for(i=0;i<(mtuCp->maxAddr-1);i++)
          {
             mtuCp->nextIdx++;
             if(mtuCp->nextIdx > (mtuCp->maxAddr-1))
             {
                 mtuCp->nextIdx=0;
             }
             if(mtuCp->addrArray[mtuCp->nextIdx] == NULLP)
             {
                break; 
             }
          }
          if(mtuCp->addrArray[mtuCp->nextIdx] != NULLP)
          {
              SBLOGERROR(ERRCLS_DEBUG, ESBXXX, (ErrVal) err,
                    "sbMtuGetMtuCb: No Free Entries found in Address array");
              RETVALUE( RFAILED );
          }

      }
      /* Here we are successfully able to obtain the free index
       * so we will allocate it & increment the counter */
      addrIdx = mtuCp->nextIdx;
      mtuCp->nextIdx++;
      if(mtuCp->nextIdx > (mtuCp->maxAddr-1))
      {
        mtuCp->nextIdx=0;
      }

      SB_MTU_ALLOC(mtuCp, sizeof(SbMtuAddrCb), mtuAddr, err);
      if (err != ROK)
      {
         RETVALUE( ROUTRES );
      }

      mtuAddr->mtu = mtuCp->startMtu;
      mtuAddr->mtuUpper = mtuCp->maxMtu;
      mtuAddr->mtuLower = mtuCp->minMtu;

      mtuAddr->timeIdx = addrIdx;

      /* sb046.102: Multiple IP address per Endp */
      mtuAddr->nmbAssoc++;

      SB_MTU_CPY_NADDR(&(mtuAddr->addr), addr);

      err = cmHashListInsert(&(mtuCp->addrHl), (PTR) mtuAddr,
                             (U8 *)&(mtuAddr->addr),
                             sizeof(CmNetAddr));

#if (ERRCLASS & ERRCLS_DEBUG)
      if ( err != ROK )
      {
         SBLOGERROR(ERRCLS_DEBUG, ESB285, (ErrVal) err,
                    "sbMtuGetMtuCb: failed to insert into hash list");
         SB_MTU_FREE(mtuCp, sizeof(SbMtuAddrCb), mtuAddr);
         RETVALUE( RFAILED );
      }

#endif
     mtuCp->addrArray[addrIdx]= mtuAddr;
     *idx = addrIdx;
   }
   else
   {
      /* sb046.102: Multiple IP address per Endp */
      mtuAddr->nmbAssoc++;

      /* If the entry already exist in the hashlist then give the index back
       * to the parent function */ 
      *idx = mtuAddr->timeIdx;
   }
   RETVALUE( ROK );
}


/*     Performance Change  - sb023.102  - Function Added 
*
*      Fun:   sbMtuDeleteMtuCb
*
*      Desc:  This function returns 
*
*      Ret:   ROK
*             RFAILED      (optional under ERRCLS_DEBUG)
*             ROUTRES      (get resources error)
*
*      Notes: None
*
*      File:  sb_mtu.c
*
*/
#ifdef ANSI
PUBLIC S16  sbMtuDeleteMtuCb
(
SbMtuCp     *mtuCp,
U16          idx
)
#else
PUBLIC S16  sbMtuDeleteMtuCb(mtuCp, idx)
SbMtuCp     *mtuCp;
U16          idx;
#endif
{
   SbMtuAddrCb *mtuAddr;

   TRC2(sbMtuDeleteMtuCb);

#if (ERRCLASS & ERRCLS_DEBUG)

   if ( mtuCp == (SbMtuCp *)NULLP )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB280, (ErrVal) 0,
                 "sbMtuDeleteMtuCb: mtuCp is NULL");
      RETVALUE( RFAILED );
   }
   
   if (mtuCp->state != SB_MTU_STATE_ACTIVE)
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB284, (ErrVal) mtuCp->state,
                 "sbMtuDeleteMtuCb: invalid mtuCp state");
      RETVALUE( RFAILED );
   }

#endif

    mtuAddr = mtuCp->addrArray[idx]; 

#if (ERRCLASS & ERRCLS_DEBUG)
   if ( mtuAddr == (SbMtuAddrCb *)NULLP )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB281, (ErrVal) 0,
                 "sbMtuDeleteMtuCb: addrCb is NULL");
      RETVALUE( RFAILED );
   }
#endif

   /* sb046.102: Multiple IP address per Endp */
   mtuAddr->nmbAssoc--;
   if (mtuAddr->nmbAssoc == 0)
   {
      cmHashListDelete(&(mtuCp->addrHl), (PTR)mtuAddr);
      SB_MTU_FREE(mtuCp, sizeof(SbMtuAddrCb), mtuAddr);
      mtuCp->addrArray[idx]= NULLP;
   }

   RETVALUE( ROK );
}



/*
*
*      Fun:   sbMtuQuerySz
*
*      Desc:  This function returns the MTU for the requested destination
*             IP address.
*
*      Ret:   ROK
*             RFAILED      (optional under ERRCLS_DEBUG)
*             ROUTRES      (get resources error)
*
*      Notes: None
*
*      File:  sb_mtu.c
*
*/
#ifdef ANSI
PUBLIC S16  sbMtuQuerySz
(
SbMtuCp     *mtuCp,
CmNetAddr   *addr,
U16         *mtu
)
#else
PUBLIC S16  sbMtuQuerySz(mtuCp, addr, mtu)
SbMtuCp     *mtuCp;
CmNetAddr   *addr;
U16         *mtu;
#endif
{
   S16 err;
   SbMtuAddrCb *mtuAddr;

   TRC2(sbMtuQuerySz);

#if (ERRCLASS & ERRCLS_DEBUG)

   if ( mtuCp == (SbMtuCp *)NULLP )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB280, (ErrVal) 0,
                 "sbMtuQuerySz: mtuCp is NULL");
      RETVALUE( RFAILED );
   }

   if ( addr == (CmNetAddr *)NULLP )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB281, (ErrVal) 0,
                 "sbMtuQuerySz: addr is NULL");
      RETVALUE( RFAILED );
   }

   if ( addr->type == CM_NETADDR_NOTPRSNT)
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB282, (ErrVal) 0, "sbMtuQuerySz(): addr is CM_NETADDR_NOTPRSNT");
      RETVALUE( RFAILED );
   }

   if ( mtu == (U16 *)NULLP )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB283, (ErrVal) 0,
                 "sbMtuQuerySz: return value is NULL");
      RETVALUE( RFAILED );
   }

   if (mtuCp->state != SB_MTU_STATE_ACTIVE)
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB284, (ErrVal) mtuCp->state,
                 "sbMtuQuerySz: invalid mtuCp state");
      RETVALUE( RFAILED );
   }

#endif

   mtuAddr = (SbMtuAddrCb *)NULLP;
   err = cmHashListFind(&(mtuCp->addrHl), (U8 *)addr, sizeof(CmNetAddr), 0,
                        (PTR *)&mtuAddr);

   if ( err != ROK )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB285, (ErrVal) err,
                "sbMtuQuerySz: failed to find entry in hashlist ");
      RETVALUE( RFAILED );
   }
  
   /* sb023.102  - This function should ideally be no longer in use, 
    * although right now we are keeping it for failure cases only, i.e.
    * if then index in destination addressCb is not valid, this function
    * can be used to get the mtu */
   /* sb023.102 - Removing the case of creating an mtuAddressCb */
     
   *mtu = mtuAddr->mtu;

   RETVALUE( ROK );
}


/*
*
*      Fun:   sbMtuQueryDf
*
*      Desc:  This function is called to query whether the Don't Fragment
*             Flag should be set for a message of the specified size on
*             the supplied address.
*
*      Ret:   ROK
*             RFAILED      (optional under ERRCLS_DEBUG)
*             ROUTRES      (get resource error)
*
*      Notes: None
*
*      File:  sb_mtu.c
*
*/
#ifdef ANSI
PUBLIC S16  sbMtuQueryDf
(
SbMtuCp     *mtuCp,
CmNetAddr   *addr,
U16         msgSz,
Bool        *df
)
#else
PUBLIC S16  sbMtuQueryDf(mtuCp, addr, msgSz, df)
SbMtuCp     *mtuCp;
CmNetAddr   *addr;
U16         msgSz;
Bool        *df;
#endif
{
   S16 err;
   SbMtuAddrCb *mtuAddr;

   TRC2(sbMtuQueryDf);

#if (ERRCLASS & ERRCLS_DEBUG)

   if ( mtuCp == (SbMtuCp *)NULLP )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB290, (ErrVal) 0,
                 "sbMtuQueryDf: mtuCp is NULL");
      RETVALUE( RFAILED );
   }

#endif

   SBDBGP(SB_DBGMASK_MTU, (mtuCp->prntBuf,
          "sbMtuQueryDf(mtuCp, addr, msgSz(%d), df)\n", msgSz));

#if (ERRCLASS & ERRCLS_DEBUG)

   if ( addr == (CmNetAddr *)NULLP )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB291, (ErrVal) 0,
                 "sbMtuQueryDf: addr is NULL");
      RETVALUE( RFAILED );
   }

   if ( addr->type == CM_NETADDR_NOTPRSNT )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB292, (ErrVal) 0, "sbMtuQueryDf(): addr is CM_NETADDR_NOTPRSNT");
      RETVALUE( RFAILED );
   }

   if ( df == (Bool *)NULLP )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB293, (ErrVal) 0,
                 "sbMtuQueryDf: return value is NULL");
      RETVALUE( RFAILED );
   }

   if (mtuCp->state != SB_MTU_STATE_ACTIVE)
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB294, (ErrVal) mtuCp->state,
                 "sbMtuQueryDf: invalid mtuCp state");
      RETVALUE( RFAILED );
   }

#endif

   mtuAddr = (SbMtuAddrCb *)NULLP;
   err = cmHashListFind(&(mtuCp->addrHl), (U8 *)addr, sizeof(CmNetAddr),
                        0, (PTR *)&mtuAddr);

   if ( err != ROK )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB285, (ErrVal) err,
                "sbMtuQueryDf: failed to find entry in hashlist ");
      RETVALUE( RFAILED );
   }
   
   /* sb023.102  - This function should ideally be no longer in use, 
    * although right now we are keeping it for failure cases only, i.e.
    * if then index in destination addressCb is not valid, this function
    * can be used to get the mtu */
   /* sb023.102 - Removing the case of creating an mtuAddressCb */

   if (mtuAddr->mtu < msgSz )
   {
      *df = FALSE;
   }
   else
   {
      *df = TRUE;
   }

   RETVALUE( ROK );
}


/*
*
*      Fun:   sbMtuDestroy
*
*      Desc:  This function is called to deallocate all the memory used by the
*             Path MTU discovery unit.
*
*      Ret:   ROK
*             RFAILED
*
*      Notes: None
*
*      File:  sb_mtu.c
*
*/
#ifdef ANSI
PUBLIC S16  sbMtuDestroy
(
SbMtuCp     *mtuCp
)
#else
PUBLIC S16  sbMtuDestroy(mtuCp)
SbMtuCp     *mtuCp;
#endif
{
   U16 i;
   S16 err;
   SbMtuAddrCb *mtuAddr;

   TRC2(sbMtuDestroy);

#if (ERRCLASS & ERRCLS_DEBUG)

   if ( mtuCp == (SbMtuCp *)NULLP )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB296, (ErrVal) 0, "sbMtuDestroy(): mtuCp is NULL");
      RETVALUE( RFAILED );
   }

#endif

   SBDBGP(SB_DBGMASK_MTU, (mtuCp->prntBuf, "sbMtuDestroy(mtuCp)\n"));

#if (ERRCLASS & ERRCLS_DEBUG)

   if (mtuCp->state != SB_MTU_STATE_ACTIVE)
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB297, (ErrVal) mtuCp->state, "sbMtuDestroy(): invalid mtuCp state");
      RETVALUE( RFAILED );
   }

#endif

   /* sb023.102 - mtuMaxAddress is not set to ZERO here because we will first
    * access all the address delete the control blocks and then set it to ZERO
    * performnce change */
   mtuCp->minMtu = 0;
   mtuCp->maxMtu = 0;
   mtuCp->startMtu = 0;

   mtuCp->nextIdx = 0;

   /* sb023.102 - Deleted a block which acccess the hashlist because we will
    * be directly access all the entries via the pointers to addressCb 
    * performance Change */
   
   for(i=0;i<mtuCp->maxAddr;i++)
   {
      mtuAddr = mtuCp->addrArray[i];
      if(mtuAddr != NULLP)
      {
          err = cmHashListDelete(&(mtuCp->addrHl), (PTR)&mtuAddr->addr);
          if (err != ROK )
          {
              SBLOGERROR(ERRCLS_DEBUG, ESB299, (ErrVal) err, "sbMtuDestroy():"
                       "Could not delete hash list entry");
               RETVALUE( RFAILED );
          }
          SB_MTU_FREE(mtuCp,sizeof(SbMtuAddrCb), mtuAddr);
          mtuAddr = NULLP;
      }
   }
   SB_FREE((mtuCp->maxAddr * sizeof(PTR)), mtuCp->addrArray);
   mtuCp->maxAddr = 0;

   err = cmHashListDeinit(&(mtuCp->addrHl));

#if (ERRCLASS & ERRCLS_DEBUG)

   if (err != ROK )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB300, (ErrVal) err, "sbMtuDestroy(): Deinitialise the hash list");
      RETVALUE( RFAILED );
   }

#endif

   mtuCp->state = SB_MTU_STATE_INACTIVE;

   mtuCp->pool = 0;
   mtuCp->region = 0;

   RETVALUE( ROK );
}


/*
*
*      Fun:   sbMtuIncMtu
*
*      Desc:  This function needs to be called every time that the user
*             of the unit would like to try a higher value for the MTU
*             size. This function should be called periodically about
*             every 5 minutes.
*
*      Ret:   ROK
*             RFAILED
*
*      Notes: None
*
*      File:  sb_mtu.c
*
*/
#ifdef ANSI
PUBLIC S16  sbMtuIncMtu
(
SbMtuCp     *mtuCp
)
#else
PUBLIC S16  sbMtuIncMtu(mtuCp)
SbMtuCp     *mtuCp;
#endif
{
   U16 i;
   U16 tmpU16;
   SbMtuAddrCb *mtuAddr;

   TRC2(sbMtuIncMtu);

#if (ERRCLASS & ERRCLS_DEBUG)

   if ( mtuCp == (SbMtuCp *)NULLP )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB301, (ErrVal) 0, "sbMtuIncMtu(): mtuCp is NULL");
      RETVALUE( RFAILED );
   }

#endif

   SBDBGP(SB_DBGMASK_MTU, (mtuCp->prntBuf,"sbMtuIncMtu(mtuCp)\n"));

#if (ERRCLASS & ERRCLS_DEBUG)

   if (mtuCp->state != SB_MTU_STATE_ACTIVE)
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB302, (ErrVal) mtuCp->state, "sbMtuIncMtu(): invalid mtuCp state");
      RETVALUE( RFAILED );
   }

#endif

   /* sb023.102 - Removed a section,  We don't need to access hash list here 
    * also becuase we have  all the addrCb's available via pointers
    * - performance change */

   for(i=0;i <mtuCp->maxAddr;i++)
   {
      mtuAddr=mtuCp->addrArray[i];
      if(mtuAddr != NULLP)
      {
          tmpU16 = mtuAddr->mtu;
          mtuAddr->mtu = (U16)((mtuAddr->mtu + mtuAddr->mtuUpper) / 2);
          mtuAddr->mtuLower = tmpU16;
      }
   }

   RETVALUE( ROK );
}


/*
*
*      Fun:   sbMtuIncMtuUpper
*
*      Desc:  This function is called whenever the user of the PMTU-D
*             unit would like to shift the upper bound on the MTU size
*             to test the network for increases in path MTU.
*
*      Ret:   ROK
*             RFAILED
*
*      Notes: None
*
*      File:  sb_mtu.c
*
*/
#ifdef ANSI
PUBLIC S16  sbMtuIncMtuUpper
(
SbMtuCp     *mtuCp
)
#else
PUBLIC S16  sbMtuIncMtuUpper(mtuCp)
SbMtuCp     *mtuCp;
#endif
{
   U16 i;
   SbMtuAddrCb *mtuAddr;

   TRC2(sbMtuIncMtu);

#if (ERRCLASS & ERRCLS_DEBUG)

   if ( mtuCp == (SbMtuCp *)NULLP )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB304, (ErrVal) 0, "sbMtuIncMtuUpper(): mtuCp is NULL");
      RETVALUE( RFAILED );
   }

#endif

   SBDBGP(SB_DBGMASK_MTU, (mtuCp->prntBuf,"sbMtuIncMtuUpper(mtuCp)\n"));

#if (ERRCLASS & ERRCLS_DEBUG)

   if (mtuCp->state != SB_MTU_STATE_ACTIVE)
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB305, (ErrVal) mtuCp->state, "sbMtuIncMtuUpper(): invalid mtuCp state");
      RETVALUE( RFAILED );
   }

#endif
   
   /* sb023.102 - Removed a section,  We don't need to access hash list here 
    * also becuase we have  all the addrCb's available via pointers
    * - performance change */

   for(i=0;i <mtuCp->maxAddr;i++)
   {
      mtuAddr=mtuCp->addrArray[i];
      if(mtuAddr != NULLP)
      {
         mtuAddr->mtuUpper = (U16)((mtuAddr->mtuUpper + mtuCp->maxMtu) / 2);
         mtuAddr->mtuLower = (U16)((mtuAddr->mtuLower + mtuCp->minMtu) / 2);
      }

   }


   RETVALUE( ROK );
}


/*
*
*      Fun:   sbMtuRcvIcmp
*
*      Desc:  This function is called when an ICMP message arrives.
*             It needs to check if this message needs the path MTU
*             to be decreased.
*
*      Ret:   ROK
*             RFAILED
*
*      Notes: None
*
*      File:  sb_mtu.c
*
*/
#ifdef ANSI
PUBLIC S16  sbMtuRcvIcmp
(
SbMtuCp     *mtuCp,
Buffer      *mBuf,
U8          ver
)
#else
PUBLIC S16  sbMtuRcvIcmp(mtuCp, mBuf, ver)
SbMtuCp     *mtuCp;
Buffer      *mBuf;
U8          ver;
#endif
{
   U16 mtu;
   S16 err;
   Bool valid;
   SbMtuAddrCb *mtuAddr;
   CmNetAddr dst;

   TRC2(sbMtuRcvIcmp);

#if (ERRCLASS & ERRCLS_DEBUG)

   if ( mtuCp == (SbMtuCp *)NULLP )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB307, (ErrVal) 0, "sbMtuRcvIcmp(): mtuCp is NULL");
      RETVALUE( RFAILED );
   }

#endif

   SBDBGP(SB_DBGMASK_MTU, (mtuCp->prntBuf,"sbMtuRcvIcmp(mtuCp, mBuf)\n"));

#if (ERRCLASS & ERRCLS_DEBUG)

   if (mtuCp->state != SB_MTU_STATE_ACTIVE)
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB308, (ErrVal) mtuCp->state, "sbMtuRcvIcmp(): invalid mtuCp state");
      RETVALUE( RFAILED );
   }

   if (mBuf == (Buffer *)NULLP)
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB309, (ErrVal) 0, "sbMtuRcvIcmp(): mBuf = NULL");
      RETVALUE( RFAILED );
   }

#endif

   cmMemset((U8 *)&dst, 0, (PTR)sizeof(CmNetAddr));
   err = sbMtuParseIcmp(mtuCp, ver, &valid, &mtu, &dst, mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)

      if (err != ROK)
      {
         SBLOGERROR(ERRCLS_DEBUG, ESB310, (ErrVal) err, "sbMtuRcvIcmp(): Could not Decifer ICMP Message");
         RETVALUE( RFAILED );
      }

#endif

   if (valid == FALSE)
   {
      SBDBGP(SB_DBGMASK_MTU, (mtuCp->prntBuf,"sbMtuRcvIcmp(): Not an P-MTU D ICMP message\n"));
      RETVALUE( RFAILED );
   }

   mtuAddr = (SbMtuAddrCb *)NULLP;
   err = cmHashListFind(&(mtuCp->addrHl), (U8 *)&dst, sizeof(CmNetAddr), 0, (PTR *)&mtuAddr);

#if (ERRCLASS & ERRCLS_DEBUG)

   if ( (err != ROK) || (mtuAddr == (SbMtuAddrCb *)NULLP) )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB311, (ErrVal) err, "sbMtuRcvIcmp(): Could not find address for corresponding message");
      RETVALUE( RFAILED );
   }

#endif

   SBDBGP(SB_DBGMASK_MTU, (mtuCp->prntBuf,"sbMtuRcvIcmp: old mtu = %d\n", mtuAddr->mtu));
   if (mtu == 0)
   {
      mtu = (U16)((mtuAddr->mtu + mtuAddr->mtuLower) / 2);
      mtuAddr->mtuUpper = mtuAddr->mtu;
      mtuAddr->mtu = mtu;
   }
   else
   {
      mtuAddr->mtu = mtu;
      mtuAddr->mtuUpper = mtu;
   }
   SBDBGP(SB_DBGMASK_MTU, (mtuCp->prntBuf,"sbMtuRcvIcmp: new mtu = %d\n", mtuAddr->mtu));

   RETVALUE( ROK );
}


/*
*
*      Fun:   sbMtuChecksum
*
*      Desc:  Calculate the 16 bit checksum fo the IP header.
*
*      Ret:   ROK
*             RFAILED
*
*      Notes: None
*
*      File:  sb_mtu.c
*
*/
#ifdef ANSI
PRIVATE U16  sbMtuChecksum
(
U16         *buffer,
U16         size
)
#else
PRIVATE U16  sbMtuChecksum(buffer, size)
U16         *buffer;
U16         size;
#endif
{
   U32 cksum;

   TRC2(sbMtuChecksum);

   cksum = 0;

   while ( size > 1 )
   {
      cksum += *buffer++;
      size -= sizeof(U16);
   }

   if ( size > 0 )
   {
      cksum += *(U8*)buffer;
   }

   cksum = (cksum >> 16) + (cksum & 0xffff);
   cksum += (cksum >>16);

   RETVALUE( (U16)(~cksum) );
}


/*
*
*      Fun:   sbMtuParseIcmp
*
*      Desc:  Parse the ICMP Message to get new MTU.
*
*      Ret:   ROK
*             RFAILED
*
*      Notes: None
*
*      File:  sb_mtu.c
*
*/
#ifdef ANSI
PRIVATE S16  sbMtuParseIcmp
(
SbMtuCp     *mtuCp,
U8          ver,
Bool        *valid,
U16         *mtu,
CmNetAddr   *dst,
Buffer      *mBuf
)
#else
PRIVATE S16  sbMtuParseIcmp(mtuCp, ver, valid, mtu, dst, mBuf)
SbMtuCp     *mtuCp;
U8          ver;
Bool        *valid;
U16         *mtu;
CmNetAddr   *dst;
Buffer      *mBuf;
#endif
{
   U16 i;
   U8 tmpU8;
   U16 newCrc;
   MsgLen msgLen;
   U8  *ip4Hdr;
   U8  *ip6Hdr;
   S16 ret;

   TRC2(sbMtuParseIcmp);

#ifndef DEBUGP

   UNUSED(mtuCp);

#endif

   SBDBGP(SB_DBGMASK_MTU, (mtuCp->prntBuf,"sbMtuParseIcmp(mtuCp, ver, valid, mtu, mBuf)\n"));

   *mtu = 0;
   *valid = FALSE;

   SFndLenMsg(mBuf, &msgLen);

   if (ver == 4)
   {
      if (msgLen < 36)
      {
         SBDBGP(SB_DBGMASK_MTU, (mtuCp->prntBuf,"sbMtuParseIcmp(): Message Length too short\n"));
         RETVALUE( ROK );
      }

      if (msgLen > 36)
      {
         SBDBGP(SB_DBGMASK_MTU, (mtuCp->prntBuf,"sbMtuParseIcmp(): Message Length(%d) larger than neccessary\n",
         msgLen));
      }

      SB_ALLOC(msgLen, ip4Hdr, ret);
      if ( ret != ROK )
      {
          SBDBGP(SB_DBGMASK_PM, (sbGlobalCb.sbInit.prntBuf,
               "sbmtuParseIcmp: Fail To allocate memory \n"));
          RETVALUE(RFAILED);
      } 

      for (i = 0; i < msgLen; i++)
      {
         SUnpkU8(&tmpU8, mBuf);
         ip4Hdr[i] = tmpU8;
      }

      newCrc = sbMtuChecksum((U16 *) &ip4Hdr[0], msgLen);

      if (newCrc != 0)
      {
         SBDBGP(SB_DBGMASK_MTU, (mtuCp->prntBuf,"sbMtuParseIcmp(): Checksum failure, newCRC(%u)\n",
         newCrc));

         SB_FREE(msgLen, ip4Hdr);
         RETVALUE( ROK );
      }

      if (ip4Hdr[0] != SB_MTU_ICMP4_DST_UNREACH)
      {
         SBDBGP(SB_DBGMASK_MTU, (mtuCp->prntBuf,"sbMtuParseIcmp(): Not a P-MTU D usable ICMP message\n"));
         SB_FREE(msgLen, ip4Hdr);
         RETVALUE( ROK );
      }

      if (ip4Hdr[1] != SB_MTU_ICMP4_NEED_FRAG)
      {
         SBDBGP(SB_DBGMASK_MTU, (mtuCp->prntBuf,"sbMtuParseIcmp(): Not a P-MTU D usable ICMP message\n"));
         SB_FREE(msgLen, ip4Hdr);
         RETVALUE( ROK );
      }

      *mtu = (U16)(((U32)ip4Hdr[4] << 24) + ((U32)ip4Hdr[5] << 16) + ((U32)ip4Hdr[6] << 8) + (U32)ip4Hdr[7]);

      dst->type = CM_NETADDR_IPV4;
      dst->u.ipv4NetAddr = ((U32)ip4Hdr[24] << 24) + ((U32)ip4Hdr[25] << 16) + ((U32)ip4Hdr[26] << 8) + (U32)ip4Hdr[27];

      *valid = TRUE;
      SB_FREE(msgLen, ip4Hdr);
   }
   else if (ver == 6)
   {
      if (msgLen < 48)
      {
         SBDBGP(SB_DBGMASK_MTU, (mtuCp->prntBuf,"sbMtuParseIcmp(): Message Length too short\n"));
         RETVALUE( ROK );
      }

      SB_ALLOC(msgLen, ip6Hdr, ret);
      if ( ret != ROK )
      {
          SBDBGP(SB_DBGMASK_PM, (sbGlobalCb.sbInit.prntBuf,
               "sbmtuParseIcmp: Fail To allocate memory \n"));
          RETVALUE(RFAILED);
      } 

      for (i = 0; i < msgLen; i++)
      {
         SUnpkU8(&tmpU8, mBuf);
         ip6Hdr[i] = tmpU8;
      }

      if (ip6Hdr[0] != SB_MTU_ICMP6_TOO_BIG_TYPE)
      {
         SBDBGP(SB_DBGMASK_MTU, (mtuCp->prntBuf,"sbMtuParseIcmp(): Not a P-MTU D usable ICMP message\n"));
         SB_FREE(msgLen, ip6Hdr);
         RETVALUE( ROK );
      }

      if (ip6Hdr[1] != SB_MTU_ICMP6_TOO_BIG_CODE)
      {
         SBDBGP(SB_DBGMASK_MTU, (mtuCp->prntBuf,"sbMtuParseIcmp(): Not a P-MTU D usable ICMP message\n"));
         SB_FREE(msgLen, ip6Hdr);
         RETVALUE( ROK );
      }

      *mtu = (U16)(((U32)ip6Hdr[4] << 24) + ((U32)ip6Hdr[5] << 16) + ((U32)ip6Hdr[6] << 8) + (U32)ip6Hdr[7]);

      dst->type = CM_NETADDR_IPV6;
      for (i = 0; i < 16; i++) dst->u.ipv6NetAddr[i] = ip6Hdr[i + 32];

      *valid = TRUE;
      
      SB_FREE(msgLen, ip6Hdr);
   }

#if (ERRCLASS & ERRCLS_DEBUG)

   else
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB312, (ErrVal) ver, "sbMtuParseIcmp(): Invalid IP Version");
      RETVALUE( RFAILED );
   }

#endif

   RETVALUE( ROK );
}


#endif /* __SB_MTUC__ */

/********************************************************************30**

         End of file:     sb_mtu.c@@/main/2 - Wed Jan 10 16:24:54 2001

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision History:

*********************************************************************61*/
/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
 /main/2     ---    bk      1. backbone draft.
 /main/2     ---     sb     1. Modified for SCTP release based on 
                               RFC-2960 'Oct 2000.
         sb023.102   sb     1. Changed done in Mtu for Performance.
         sb027.102   hm     1. Removed TAB

         sb042.102   hl     1. Added change for SHT interface and Rolling
                               UpGrade
         sb046.102   hl     1. Multiple IP address per endpoint support
         sb051.102   ag     1. Hash List optimization
*********************************************************************91*/


