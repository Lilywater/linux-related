/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**

     Name:    SCTP Layer (SCTP)

     Type:    C source file

     Desc:    Code for Upper Interface and Management Interface
              primitives supplied by TRILLIUM

     File:    sb_bdy2.c

     Sid:      sb_bdy2.c@@/main/2 - Wed Jan 10 16:25:55 2001

     Prg:     bk, wvdl

*********************************************************************21*/

/***********************************************************************

    Functions contained in sb_bdy2.c

    PUBLIC S16 sbSqInSendUp(assocCb, chunk, type)
    PUBLIC S16 sbSqDeliver(assocCb, chunk)
    PUBLIC S16 sbSqRtrvUnsent(assocCb)
    PUBLIC S16 sbSqRtrvUndel(assocCb)
    PUBLIC S16 sbSqArrive(assocCb, chunk)
    PUBLIC S16 sbSqLifetimeTO(chunk)

    PUBLIC SbQueuedChunk *sbDbGetFirst(assocCb, qType)
    PUBLIC S16 sbDbDelAll(assocCb, qType)
    PUBLIC S16 sbDbInsert(assocCb, chunk, qType)
    PUBLIC S16 sbDbListSize(l, staticMem, msgMem)
    PUBLIC S16 sbDbQSize(assocCb, staticMem, msgMem, qType)
    PUBLIC U32 sbDbQPackets(assocCb, qType)
    PUBLIC SbQueuedChunk *sbDbAssembled(assocCb)
    PUBLIC SbQueuedChunk *sbDbOrdered(assocCb, stream, seqNum)
    PUBLIC SbQueuedChunk *sbDbGetChunk(assocCb, chunk)

    PUBLIC S16 sbSgSegment(assocCb)
    PUBLIC S16 sbSgAssemble(assocCb, chunk)

    PUBLIC S16 sbVaDatInd(srcAddr, dstAddr, suConId, mBuf)

    PUBLIC Void sbPmHBeatEnb(addrCb, intervalTime)
    PUBLIC Void sbPmHBeatDis(addrCb)
    PUBLIC S16 sbPmHBeatTO(addrCb)
    PUBLIC S16 sbPmNeedResend(assocCb, addrCb, result)
    PUBLIC S16 sbPmSendHBeat(assocCb, addrCb)
    PUBLIC S16 sbPmRcvHBeatAck(assocCb, mBuf)
    PUBLIC S16 sbPmCalcRto(assocCb, addrCb, newRtt)
    PUBLIC S16 sbPmRcvHBeat(assocCb, src, msgLen, mBuf)
    PUBLIC CmNetAddr *sbPmGetBestAddr(assocCb, addr)
    PUBLIC SbAddrCb *sbPmGetBestAddrCb(assocCb, addr)
    PUBLIC Void sbPmRcvSack(assocCb, chunk)
    PUBLIC SbAddrCb *sbPmAddAddr(sctSap, assocCb, addr)
    PUBLIC S16 sbPmSelNextAddr(assocCb, chunk)
    PUBLIC S16 sbPmCompNAddr(addr1, addr2)
    PUBLIC SbAddrCb *sbPmGetAddrCb(assocCb, address)

    PUBLIC S16 sbCmChunkMux(assocCb, chunk)
    PUBLIC S16 sbCmMakeMsg(chunk, mBuf)
    PUBLIC S16 sbCmDemux(localAddr, peerAddr, localPort, peerPort, vTag,
    PUBLIC S16 sbCmMakeChunk(assocCb, flags, chunkBuf, chunk)
    PUBLIC S16 sbCmResolveChunk(localPort, localAddr, peerPort, peerAddr,
    PUBLIC S16 sbCmValChunk(assocCb, vTag, chunkId, suConId,chunkFlags)

************************************************************************/

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_tpt.h"        /* common transport defines */
#include "cm_dns.h"        /* Common DNS library */
#ifdef SB_FTHA
#include "sht.h"           /* SHT Interface header file */
#endif /* SB_FTHA */
#include "sct.h"           /* SCT interface */
#include "lsb.h"           /* layer management, SCTP  */
#include "hit.h"           /* HIT interface */
#include "sb_port.h"
#include "sb_mtu.h"
#include "sb.h"            /* SCTP internal defines */
#include "sb_err.h"        /* SCTP error */

/* header/extern include files (.x) */
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_tpt.x"        /* common transport*/
#include "cm_dns.x"        /* Common DNS library */
#ifdef SB_FTHA
#include "sht.x"           /* SHT Interface header file */
#endif /* SB_FTHA */
#include "sct.x"           /* SCT interface */
#include "lsb.x"           /* layer management SCTP */
#include "hit.x"           /* HIT interface */
#include "sb_port.x"
#include "sb_mtu.x"
#include "sb.x"            /* SCTP internal typedefs */

/* Public variable declarations */


/* functions */


/**********************************************************************
 *  Sequenced delivery withing streams functional block               *
 **********************************************************************/

/*
*
*      Fun:   Send data up
*
*      Desc:  Send the data in the SbQueueudChunk up to the service
*             user. This function can be used to send ordinary messages
*             that have arrived from the peer as well as undelivered,
*             unacknowledged and unsent datagrams once a shutdown has
*             been received.
*
*      Ret:   ROK
*             RFAILED
*
*      Notes: None
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbSqInSendUp
(
SbSctAssocCb  *assocCb,                 /* Association to send on     */
SbQueuedChunk *chunk,                   /* Data to be sent            */
U8            type                      /* Type of message to send    */
)
#else
PUBLIC S16 sbSqInSendUp(assocCb, chunk, type)
SbSctAssocCb  *assocCb;                 /* Association to send on     */
SbQueuedChunk *chunk;                   /* Data to be sent            */
U8            type;                     /* Type of message to send    */
#endif
{
   S16 err;                             /* For monitoring of return
                                         * codes                      */
   Bool last;                           /* Is this the last data chunk
                                         * of the ones requested      */
   SbSctSapCb     *sctSap;
   SctDatIndType  indType;
   MsgLen         bufLen;

   TRC2( sbSqInSendUp );

   SBDBGP(SB_DBGMASK_SQ, (sbGlobalCb.sbInit.prntBuf,
                          "sbSqInSendUp(assocCb, chunk, type(%d))\n",
                          type));

   /* No chunk to send to the service user. Just ignore this request */
   if ( chunk == (SbQueuedChunk *)NULLP )
   {
      SBDBGP(SB_DBGMASK_SQ, (sbGlobalCb.sbInit.prntBuf,
             "sbSqInSendUp: No chunk provided for sending to service user\n"));
      RETVALUE( OK );
   }

#if ( ERRCLASS & ERRCLS_DEBUG )
   /* Association is NULL */
   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB077, (ErrVal) 0,
                 "sbSqInSendUp: Association variable is NULL");
      SB_PUTMSG(chunk->mBuf);

      SB_FREE(sizeof(SbQueuedChunk), chunk)
      RETVALUE( RFAILED );
   }
#endif

   last = FALSE;

   /* select the type of data to send to the service user */
   switch ( type )
   {
      case SCT_UNSENT_DAT :             /* Data not yet sent to peer  */
         if ( sbDbQPackets(assocCb, SB_DB_TSNWAITINGQ) <= 0 )
         {
            last = TRUE;
         }
         break;

      case SCT_UNACK_DAT :              /* Data not yet acknowledged  */
         if ( sbDbQPackets(assocCb, SB_DB_CONGESTIONQ) <= 0)
         {
            last = TRUE;
         }
         break;

      case SCT_UNDEL_DAT :              /* Data not yet delivered     */
         if ( (sbDbQPackets(assocCb, SB_DB_ASSEMBLYQ) <= 0) &&
              (sbDbQPackets(assocCb, SB_DB_SEQUENCEDQ) <= 0) )
         {
            last = TRUE;
         }
         break;

      case SCT_PEER_DAT :               /* Peer to peer data          */
         if ( chunk->unorderedFlg == TRUE)
         {
            type = SCT_UNORDER_DAT;
         }
         break;

      case SCT_UNORDER_DAT :            /* Unordered data             */
         break;

      default:

#if ( ERRCLASS & ERRCLS_DEBUG )           /* Invalid message type       */
         SBLOGERROR( ERRCLS_DEBUG, ESB078, (ErrVal) type,
                     "sbSqInSendUp: Invalid message type");
         SB_PUTMSG(chunk->mBuf);

         SB_FREE(sizeof(SbQueuedChunk), chunk)
         RETVALUE( RFAILED );
#endif
         break;
   }

   sctSap = *(sbGlobalCb.sctSaps + assocCb->spId);

   /* send the data up in a status indication */
   indType.type = type;
   indType.tsn = chunk->tsn;
   indType.seqNum = chunk->seqNum;
   indType.last = last;

   /* update statistics counters */
   /* sb049.102: Checking the error for SSI function call */
   err = SFndLenMsg(chunk->mBuf, &(bufLen));
   if (err != ROK)
   {
      SBDBGP(SB_DBGMASK_SQ, (sbGlobalCb.sbInit.prntBuf,
                  "sbSqInSendUp: Could not get the length of the buffer\n"));
      SB_PUTMSG(chunk->mBuf);
      SB_FREE(sizeof(SbQueuedChunk), chunk)
      RETVALUE( RFAILED );
   }
   sbGlobalCb.genSts.sbByteSts.bytesTx += bufLen;
   sctSap->sctSts.sbByteSts.bytesTx    += bufLen;

   err = SbUiSctDatInd( &(sctSap->sctPst),
                        sctSap->suId,
                        assocCb->suAssocId,
                        chunk->stream,
                        &indType,
                        chunk->protId,
                        chunk->mBuf );

   /* lose the chunk */
   SB_FREE( sizeof(SbQueuedChunk), chunk );

   RETVALUE( ROK );
}/* end of sbSqInSendUp */


/*
*
*      Fun:   Deliver data
*
*      Desc:  Send the data in the SbQueuedChunk to the peer. If the
*             sequence number is too large than a status indication is
*             sent to the service user. Otherwise the data is passed
*             onto the Data Segmentation FB.
*
*      Ret:   ROK
*             RFAILED
*
*      Notes: None
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbSqDeliver
(
SbSctAssocCb  *assocCb,                 /* Association to send on     */
SbQueuedChunk *chunk                    /* Data to be sent            */
)
#else
PUBLIC S16 sbSqDeliver(assocCb, chunk)
SbSctAssocCb  *assocCb;                 /* Association to send on     */
SbQueuedChunk *chunk;                   /* Data to be sent            */
#endif
{
   S16 err;
/* sb054.102 : Addition - Bundling Changes */
#ifdef LSB4
   U16 mtu;
   MsgLen len=0;
   PRIVATE MsgLen bundleLen=0;
   PRIVATE U16 numBundleChunks=0;
#endif
   SbSctSapCb *sctSap;

   TRC2( sbSqDeliver );

   SBDBGP( SB_DBGMASK_SQ, ( sbGlobalCb.sbInit.prntBuf,
                            "sbSqDeliver(assocCb, chunk)\n" ) );

   /* sanity checks */
#if ( ERRCLASS & ERRCLS_DEBUG )
   /* Chunk is NULL */
   if ( chunk == (SbQueuedChunk *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB079, (ErrVal) 0,
                  "sbSqDeliver: NULL pointer supplied for chunk." );
      RETVALUE( RFAILED );
   }

   /* Association is NULL */
   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB080, (ErrVal) 0,
                  "sbSqDeliver: Association variable is NULL" );
      SB_PUTMSG(chunk->mBuf);

      SB_FREE(sizeof(SbQueuedChunk), chunk)

      RETVALUE( RFAILED );
   }
#endif

   sctSap = *(sbGlobalCb.sctSaps + assocCb->spId);

   /* assign sequence number to chunk only if the unordered flag is FALSE */
   if ( chunk->unorderedFlg == TRUE )
   {
      /* get the sequence number */
      chunk->seqNum = 0;
   }
   else
   {
      /* get the sequence number */
      chunk->seqNum = assocCb->sbSqCb.outStreamSeqNum[chunk->stream];

      (assocCb->sbSqCb.outStreamSeqNum[chunk->stream])++;
   }

   /* put the chunk into the TSN Waiting Queue */
   err = sbDbInsert( assocCb, chunk, SB_DB_TSNWAITINGQ );

#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( err != ROK )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB081, (ErrVal) err,
                  "sbSqDeliver: Could not insert data chunk into tsnWaitingQ");
      RETVALUE( RFAILED );
   }
#endif

   /* Segment the data (if necessary) */
   sbSgSegment( assocCb );
/* sb054.102 : Addition - Bundling Changes */
#ifdef LSB4
   /* Check if we can do bundling */
   if((ROK == err) && (!chunk->noBundleFlg) )
   {
     /* sb055.102 bundling timer change */ 
     if(assocCb->sbAsCb.bundleTimer.tmrEvnt == TMR_NONE)
     {
       SB_START_TMR( &(assocCb->sbAsCb.bundleTimer), assocCb, SB_TMR_BUNDLE,
                    sctSap->sctSapCfg.reConfig.bundleTm );
     }
     /* Do not bundle if no chunk is in flight */
     if (cmLListLen(&(assocCb->sbDbCb.congestionQ)) != 1)
     {
       /* Chunk is qualified for bundling */
       SB_GET_MTU(chunk->addrCb, mtu, err);
       SFndLenMsg(chunk->mBuf, &len);

       bundleLen += len + SB_CHUNK_HEADER_SIZE ;
       numBundleChunks ++;

       /* Check if the bundle is mature */
       if(bundleLen >= ( mtu - SB_COMMON_HEADER_SIZE))
       {
         /* sb055.102 bundling timer change */ 
         if(assocCb->sbAsCb.bundleTimer.tmrEvnt != TMR_NONE)
         {
           SB_STOP_TMR(&(assocCb->sbAsCb.bundleTimer));
         }
         sbAcEmptyCongQ(assocCb);
         bundleLen = 0;
         numBundleChunks = 0;
       }
       RETVALUE( ROK );
     }
   }
#endif /* LSB4 */
   /* Chunk not qualified for Bundling */
   sbAcEmptyCongQ(assocCb);
#ifdef LSB4
   bundleLen = 0;
#endif /* LSB4 */

   RETVALUE( ROK );
}/* end of sbSqDeliver */


/*
*
*      Fun:   Return Unsent Data
*
*      Desc:  Return data that has not yet been sent to the peer, back
*             to the service user. This would occur when the data is
*             is still awaiting TSN assignment because they could not
*             fit into the current congestion windows.
*
*      Ret:   ROK
*             RFAILED
*
*      Notes: None
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbSqRtrvUnsent
(
SbSctAssocCb  *assocCb                  /* Association to send on     */
)
#else
PUBLIC S16 sbSqRtrvUnsent(assocCb)
SbSctAssocCb  *assocCb;                 /* Association to send on     */
#endif
{
   S16 err;
   SbQueuedChunk *chunk;

   TRC2( sbSqRtrvUnsent );

   SBDBGP( SB_DBGMASK_SQ, ( sbGlobalCb.sbInit.prntBuf,
                            "sbSqRtrvUnsent(assocCb)\n" ) );

   /* sanity checks */
#if ( ERRCLASS & ERRCLS_DEBUG )
   /* Association is NULL */
   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB082, (ErrVal) 0,
                 "sbSqRtrvUnsent: Association variable is NULL" );
      RETVALUE( RFAILED );
   }
#endif

   /* Sending up all data chunks not yet been assigned a sequence number */
   /* return pointer to first element in list */
   chunk = sbDbGetFirst( assocCb, SB_DB_TSNWAITINGQ );

   while ( chunk != (SbQueuedChunk *)NULLP )
   {
      /* remove the elemnet in list pointed to by 'chunk' */
      chunk = sbDbGetChunk( assocCb, chunk );

      /* send the element up to the user */
      err = sbSqInSendUp( assocCb, chunk, SCT_UNSENT_DAT );

#if ( ERRCLASS & ERRCLS_DEBUG )
      if ( err != ROK )
      {
         SBLOGERROR( ERRCLS_DEBUG, ESB083, (ErrVal) err,
                     "sbSqRtrvUnsent: Could not send data to service user" );
         RETVALUE( RFAILED );
      }
#endif

      /* return pointer to first element in list */
      chunk = sbDbGetFirst( assocCb, SB_DB_TSNWAITINGQ );
   }

   RETVALUE( ROK );
}/* end of sbSqRtrvUnsent */


/*
*
*      Fun:   Return Undelivered Data
*
*      Desc:  Return data that has not yet been delivered to the service
*             user because it still needs to be reassembled or
*             sequenced.
*
*      Ret:   ROK
*             RFAILED
*
*      Notes: None
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbSqRtrvUndel
(
SbSctAssocCb  *assocCb                  /* Association to send on     */
)
#else
PUBLIC S16 sbSqRtrvUndel(assocCb)
SbSctAssocCb  *assocCb;                 /* Association to send on     */
#endif
{
   S16 err;
   SbQueuedChunk *chunk;

   TRC2( sbSqRtrvUndel );

   SBDBGP( SB_DBGMASK_SQ, ( sbGlobalCb.sbInit.prntBuf,
                            "sbSqRtrvUndel(assocCb)\n" ) );

   /* sanity checks */
#if ( ERRCLASS & ERRCLS_DEBUG )
   /* Association is NULL */
   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB084, (ErrVal) 0,
                  "sbSqRtrvUndel: Association variable is NULL" );
      RETVALUE( RFAILED );
   }
#endif

   /* Sending up all data segments not yet reassembled */
   /* return pointer to first element in list */
   chunk = sbDbGetFirst( assocCb, SB_DB_ASSEMBLYQ );
   while ( chunk != (SbQueuedChunk *)NULLP )
   {
      /* remove the element in list pointed to by 'chunk' */
      chunk = sbDbGetChunk( assocCb, chunk );

      /* send it up */
      err = sbSqInSendUp( assocCb, chunk, SCT_UNDEL_DAT );

#if ( ERRCLASS & ERRCLS_DEBUG )
      if ( err != ROK )
      {
         SBLOGERROR( ERRCLS_DEBUG, ESB085, (ErrVal) err,
                     "sbSqRtrvUndel: Could not send data to service user" );
         RETVALUE( RFAILED );
      }
#endif

      /* return pointer to first element in list */
      chunk = sbDbGetFirst( assocCb, SB_DB_ASSEMBLYQ );
   };

   /* Sending up all data chunks not yet sequenced */
   /* return pointer to first element in list */
   chunk = sbDbGetFirst( assocCb, SB_DB_SEQUENCEDQ );
   while ( chunk != (SbQueuedChunk *)NULLP )
   {
      /* remove the elemenet in list pointed to by 'chunk' */
      chunk = sbDbGetChunk( assocCb, chunk );

      /* send it up */
      err = sbSqInSendUp( assocCb, chunk, SCT_UNDEL_DAT );

#if ( ERRCLASS & ERRCLS_DEBUG )
      if ( err != ROK )
      {
         SBLOGERROR( ERRCLS_DEBUG, ESB086, (ErrVal) err,
                     "sbSqRtrvUndel: Could not send data to service user" );
         RETVALUE( RFAILED );
      }
#endif

      /* return pointer to first element in list */
      chunk = sbDbGetFirst( assocCb, SB_DB_SEQUENCEDQ );

   };

   RETVALUE( ROK );
}/* end of sbSqRtrvUndel */


/*
*
*      Fun:   Sequence Arriving Data
*
*      Desc:  Data arriving from the peer must be delivered if it is an
*             unordered data chunk, otherwise it has to be placed in the
*             correct sequence in its stream.
*
*      Ret:   ROK
*             RFAILED
*
*      Notes: None
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbSqArrive
(
SbSctAssocCb  *assocCb,                 /* Association received on    */
SbQueuedChunk *chunk                    /* Data to be sent            */
)
#else
PUBLIC S16 sbSqArrive(assocCb, chunk)
SbSctAssocCb  *assocCb;                 /* Association received on    */
SbQueuedChunk *chunk;                   /* Data to be sent            */
#endif
{
   S16       err;
   SctStrmId stream;

   TRC2( sbSqArrive );

   SBDBGP( SB_DBGMASK_SQ, ( sbGlobalCb.sbInit.prntBuf,
                            "sbSqArrive(assocCb, chunk)\n" ) );

   /* sanity checks */
#if ( ERRCLASS & ERRCLS_DEBUG )
   /* Chunk is NULL              */
   if ( chunk == (SbQueuedChunk *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB087, (ErrVal) 0,
                  "sbSqArrive: chunk variable is NULL" );
      RETVALUE( RFAILED );
   }

   /* Association is NULL        */
   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB088, (ErrVal) 0,
                  "sbSqArrive(): Association variable is NULL");
      SB_PUTMSG(chunk->mBuf);

      SB_FREE(sizeof(SbQueuedChunk), chunk)

      RETVALUE( RFAILED );
   }
#endif

   if ( chunk->unorderedFlg == TRUE )
   {
      /* send it up */
      err = sbSqInSendUp( assocCb, chunk, SCT_UNORDER_DAT );

#if ( ERRCLASS & ERRCLS_DEBUG )
      if ( err != ROK )
      {
         SBLOGERROR( ERRCLS_DEBUG, ESB089, (ErrVal) err,
                     "sbSqArrive: Could not send data to service user" );
         RETVALUE( RFAILED );
      }
#endif

      RETVALUE( ROK );
   }

   if ( chunk->stream >= assocCb->sbSqCb.nmbInStreams )
   {
      SBDBGP(SB_DBGMASK_SQ, (sbGlobalCb.sbInit.prntBuf,
             "sbSqArrive: Incoming stream number too big, stream = %d\n",
             chunk->stream));

      /* send an ERROR chunk */
      err = sbAsSendErrorStrm( assocCb->ownInitTag,
                              &(assocCb->localConn->ownAddr),
                              &(chunk->addrCb->addr),
                               assocCb->localPort,
                               assocCb->peerPort,
                               chunk->stream );

#if ( ERRCLASS & ERRCLS_DEBUG )
      if ( err != ROK )
      {
         SBLOGERROR( ERRCLS_DEBUG, ESB090, (ErrVal) err,
                     "sbSqArrive: Could not send stream ERROR to peer" );
      }
#endif
      SB_PUTMSG(chunk->mBuf);

      SB_FREE(sizeof(SbQueuedChunk), chunk)

      RETVALUE( RFAILED );
   }

   if ( chunk->seqNum != assocCb->sbSqCb.inStreamSeqNum[chunk->stream] )
   {
      /* chunk is out of order, send to the Sequ. Deliv. Queue */
      SBDBGP(SB_DBGMASK_SQ, (sbGlobalCb.sbInit.prntBuf,
             "sbSqArrive: Arriving datagram out of sequence, \
             stream = %d, seqNum = %d\n",
             chunk->stream, chunk->seqNum));

      err = sbDbInsert( assocCb, chunk, SB_DB_SEQUENCEDQ );

#if ( ERRCLASS & ERRCLS_DEBUG )
      if ( err != ROK )
      {
         SBLOGERROR( ERRCLS_DEBUG, ESB091, (ErrVal) err,
                     "sbSqArrive: Could not add chunk to sequencedQ" );
         RETVALUE( RFAILED );
      }
#endif

      RETVALUE( ROK );
   }

   stream = chunk->stream;
   SBDBGP( SB_DBGMASK_SQ, (sbGlobalCb.sbInit.prntBuf,
           "sbSqArrive: Data arrived in order, stream (%d) and seqNum (%d)\n",
           stream, chunk->seqNum));

   err = sbSqInSendUp( assocCb, chunk, SCT_PEER_DAT );

#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( err != ROK )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB092, (ErrVal) err,
                  "sbSqArrive: Failed to send in-order data to service user" );
      RETVALUE( RFAILED );
   }
#endif

   /* send up the ordered data chunks */
   do
   {
      (assocCb->sbSqCb.inStreamSeqNum[stream])++;

      chunk = sbDbOrdered( assocCb, stream,
                           assocCb->sbSqCb.inStreamSeqNum[stream] );

      /* send it up */
      err = sbSqInSendUp( assocCb, chunk, SCT_PEER_DAT );

#if ( ERRCLASS & ERRCLS_DEBUG )
      if ( err != ROK )
      {
         SBLOGERROR( ERRCLS_DEBUG, ESB093, (ErrVal) err,
                   "sbSqArrive: Failed to send in-order data to service user");
         RETVALUE( RFAILED );
      }
#endif

   }
   while ( chunk != (SbQueuedChunk *)NULLP );

   RETVALUE( ROK );
}/* end of sbSqArrive */


/*
*
*      Fun:   Lifetime Timer Expired
*
*      Desc:  This function is called whenever the lifetime of a data
*             chunk expires. This function has to dequeue the data from
*             the tsnWaitingQ and needs to send a status indication to
*             the service user.
*
*      Ret:   ROK
*             RFAILED
*
*      Notes: None
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbSqLifetimeTO
(
SbQueuedChunk *chunk                    /* Data to be sent            */
)
#else
PUBLIC S16 sbSqLifetimeTO(chunk)
SbQueuedChunk *chunk;                   /* Data to be sent            */
#endif
{
   S16 err;
   SbSctAssocCb *assocCb;
   SbSctSapCb *sctSap;

   TRC2( sbSqTmrExp );

   SBDBGP( SB_DBGMASK_SQ, ( sbGlobalCb.sbInit.prntBuf,
                            "sbSqLifetimeTO(chunk)\n" ) );

   /* Sanity checks */
#if ( ERRCLASS & ERRCLS_DEBUG )
   /* Chunk is NULL */
   if ( chunk == (SbQueuedChunk *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB094, (ErrVal) 0,
                  "sbSqLifetimeTO: chunk variable is NULL" );
      RETVALUE( RFAILED );
   }
#endif

   assocCb = sbGlobalCb.assocCb[chunk->spAssocId];

#if ( ERRCLASS & ERRCLS_DEBUG )
   /* Association for chunk is NULL */
   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB095, (ErrVal) chunk->spAssocId,
                  "sbSqLifetimeTO: Association is NULL for supplied chunk" );



      SB_PUTMSG(chunk->mBuf);

      SB_FREE(sizeof(SbQueuedChunk), chunk)


      RETVALUE( RFAILED );
   }
#endif
   if ( assocCb->assocState != SB_ST_ESTABLISHED )
   {
      SBDBGP(SB_DBGMASK_AC, (sbGlobalCb.sbInit.prntBuf,
             "sbSqLifetimeTO: not in SB_ST_ESTABLISHED state"));
      RETVALUE(ROK);
   }

   sctSap = *(sbGlobalCb.sctSaps + assocCb->spId);

   /* remove chunk from queue */
   chunk = sbDbGetChunk( assocCb, chunk );

#if ( ERRCLASS & ERRCLS_DEBUG )
   /* Chunk got lost in the queueing system */
   if ( chunk == (SbQueuedChunk *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB096, (ErrVal) 0,
                  "sbSqLifetimeTO: Chunk lost in the queueing system" );
      RETVALUE( RFAILED );
   }
#endif

#if ( ERRCLASS & ERRCLS_DEBUG )
   /* Chunk is NULL */
   if ( chunk->mBuf == (Buffer *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB097, (ErrVal) 0,
                 "sbSqLifetimeTO: message buffer lost in the queueing system");
      RETVALUE( RFAILED );
   }
#endif

   /* send the chunk back to the service user */
   err = SbUiSctStaInd( &(sctSap->sctPst),
                        sctSap->suId,
                        assocCb->suAssocId,
                        assocCb->spAssocId,
                        &(chunk->addrCb->addr),
                        SCT_STATUS_SND_FAIL,
                        SCT_CAUSE_LTIME_EXPIRE,
                        chunk->mBuf);

   /* lose the chunk but not the mBuf */
   SB_FREE( sizeof(SbQueuedChunk), chunk );

   RETVALUE( ROK );
}/* end of sbSqLifetimeTO */


/**********************************************************************
 *  Database functional block                                         *
 **********************************************************************/


/*
*
*      Fun:   Get First Chunk
*
*      Desc:  Get the first instance of QueuedChunkCb in specified queue
*             Functioning of this function is dependent on the queue it
*             operates on. If it is operating on the tsnWaitingQ, then
*             this function will try and return chunks in the unordered
*             queue before returning any functions in the ordered queue.
*             If it is operating on the congestionQ or the assemblyQ
*             then it dequeues the first data chunk from those queues.
*             When operating on the sequencedQ, this function will
*             search through all stream instances of the sequenceQ until
*             it finds the first available SbQueuedChunk. This function
*             does not remove the data chunk from the linked list, it
*             only returns the pointer to the SbQueuedChunk.
*
*      Ret:   SbQueuedChunk*
*
*      Notes: None
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC SbQueuedChunk *sbDbGetFirst
(
SbSctAssocCb  *assocCb,                 /* Association                */
U8            qType                     /* Queue to operate on        */
)
#else
PUBLIC SbQueuedChunk *sbDbGetFirst(assocCb, qType)
SbSctAssocCb  *assocCb;                 /* Association                */
U8            qType;                    /* Queue to operate on        */
#endif
{
   SctStrmId   i;
   CmLList    *n;
   CmLListCp  *l;

   TRC2( sbDbGetFirst );

   SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
                            "sbDbGetFirst(assocCb, qType(%d))\n",
                            qType ) );

   /* Sanity Checks */
#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( qType >= SB_DB_NUMQUEUES )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB098, (ErrVal) qType,
                  "sbDbGetFirst: Invalid Queue Type" );
      RETVALUE( (SbQueuedChunk *)NULLP );
   }

   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB099, (ErrVal) 0,
                  "sbDbGetFirst: Association is NULL" );
      RETVALUE( (SbQueuedChunk *)NULLP );
   }
#endif

   /* select the queue */
   switch ( qType )
   {
      case SB_DB_TSNWAITINGQ:
      {
         /* TSN waiting queue */
         /* Unordered section gets priority over ordered section */
         l = &(assocCb->sbDbCb.tsnWaitingQUnord);

         if (cmLListLen( l ) <= 0 )
         {
            l = &(assocCb->sbDbCb.tsnWaitingQOrd);

            if ( cmLListLen( l ) <= 0 )
            {
               SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
                       "sbDbGetFirst: TSN Waiting Queue empty\n" ) );
               RETVALUE( (SbQueuedChunk *)NULLP );
            }

            n = cmLListFirst( l );

            RETVALUE( (SbQueuedChunk *)(n->node) );
         }
         else
         {
            n = cmLListFirst( l );

            RETVALUE( (SbQueuedChunk *)(n->node) );
         }
         break;
      }

      case SB_DB_CONGESTIONQ:
      {
         /* Congestion Queue */
         l = &(assocCb->sbDbCb.congestionQ);

         if ( cmLListLen( l ) > 0 )
         {
            n = cmLListFirst( l );

            RETVALUE( (SbQueuedChunk *)(n->node) );
         }
         else
         {
            SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
                    "sbDbGetFirst: Congestion Queue empty\n" ) );
            RETVALUE( (SbQueuedChunk *)NULLP );
         }
         break;
      }

      case SB_DB_ASSEMBLYQ:
      {
         /* Assembly Queue */
         l = &(assocCb->sbDbCb.assemblyQ);

         if ( cmLListLen( l ) > 0)
         {
            n = cmLListFirst( l );

            RETVALUE( (SbQueuedChunk *)(n->node) );
         }
         else
         {
            SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
                    "sbDbGetFirst: Assembly Queue empty\n" ) );
            RETVALUE( (SbQueuedChunk *)NULLP );
         }
         break;
      }
      case SB_DB_SEQUENCEDQ:
      {
         /* Sequenced Delivery Queues */
         if (assocCb->sbDbCb.sequencedQ == (CmLListCp *) NULLP)
         {
            RETVALUE( (SbQueuedChunk *)NULLP );
         }

         i = 0;
         l = (CmLListCp *)NULLP;
         while ( ( i < assocCb->sbSqCb.nmbInStreams ) &&
                 ( l == (CmLListCp *)NULLP ) )
         {
            l = &(assocCb->sbDbCb.sequencedQ[i]);

            if ( cmLListLen(l) <= 0 )
            {
               l = (CmLListCp *) NULLP;
            }

            i++;
         }

         if ( l == (CmLListCp *)NULLP )
         {
            SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
                    "sbDbGetFirst: Sqeuenced Delivery Queues empty\n" ) );
            RETVALUE( (SbQueuedChunk *)NULLP );
         }
         else
         {
            n = cmLListFirst( l );

            RETVALUE( (SbQueuedChunk *)(n->node) );
         }

         break;
      }

#if ( ERRCLASS & ERRCLS_DEBUG )
      default:
      {
         SBLOGERROR( ERRCLS_DEBUG, ESB100, (ErrVal) qType,
                     "sbDbGetFirst: Invalid Queue Type");
         break;
      }
#endif

   }

   RETVALUE( (SbQueuedChunk *)NULLP );
}/* end of sbDbGetFirst */


/*
*
*      Fun:   Delete all entries
*
*      Desc:  Delete all the data chunks from the queue. Used during an
*             ABORT process
*
*      Ret:   ROK
*             RFAILED         (optional under ERRCLS_DEBUG)
*
*      Notes: None
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbDbDelAll
(
SbSctAssocCb  *assocCb,                 /* Association                */
U8            qType                     /* Queue to operate on        */
)
#else
PUBLIC S16 sbDbDelAll(assocCb, qType)
SbSctAssocCb  *assocCb;                 /* Association                */
U8            qType;                    /* Queue to operate on        */
#endif
{
   SctStrmId i;
   CmLList *n;
   CmLListCp *l;
   SbQueuedChunk *chunk;
   MsgLen len;
   /* sb051.102: Checking SSI function call return */
   S16 err;

   TRC2( sbDbDelAll );

   SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
                            "sbDbDelAll(assocCb, qType(%d))\n",
                            qType ) );

   /* Sanity Checks */
#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( qType >= SB_DB_NUMQUEUES )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB101, (ErrVal) qType,
                  "sbDbDelAll: Invalid Queue Type" );
      RETVALUE( RFAILED );
   }

   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB102, (ErrVal) 0,
                  "sbDbDelAll: Association is NULL" );
      RETVALUE( RFAILED );
   }
#endif

   /* Select the queue */
   switch ( qType )
   {
      case SB_DB_TSNWAITINGQ:
      {
         /* TSN Waiting Queue */
         l = &(assocCb->sbDbCb.tsnWaitingQUnord);

         while ( cmLListLen( l ) > 0 )
         {
            n = cmLListFirst( l );
            n = cmLListDelFrm( l, n );
            sbGlobalCb.txChunks--;

            chunk = (SbQueuedChunk *)(n->node);

            if ( chunk->lifetimeTmr.tmrEvnt != TMR_NONE )
            {
               SB_STOP_TMR( &(chunk->lifetimeTmr) );
            }

            /* lose the chunk */
            SB_PUTMSG( chunk->mBuf );
            SB_FREE( sizeof(SbQueuedChunk), chunk );
         }

         l = &(assocCb->sbDbCb.tsnWaitingQOrd);

         while (cmLListLen( l ) > 0)
         {
            n = cmLListFirst( l );
            n = cmLListDelFrm( l, n );
	  
	    /*sb069.102 Decrementing txChunks counter */
	    sbGlobalCb.txChunks--;

            chunk = (SbQueuedChunk *)(n->node);

            if ( chunk->lifetimeTmr.tmrEvnt != TMR_NONE )
            {
               SB_STOP_TMR( &(chunk->lifetimeTmr) );
            }

            /* lose the chunk */
            SB_PUTMSG( chunk->mBuf );
            SB_FREE( sizeof(SbQueuedChunk), chunk );
         }

         break;
      }
      case SB_DB_CONGESTIONQ:
      {
         /* Congestion Queue */
         l = &(assocCb->sbDbCb.congestionQ);

         while ( cmLListLen( l ) > 0 )
         {
            n = cmLListFirst( l );
            n = cmLListDelFrm( l, n );
            sbGlobalCb.txChunks--;
            chunk = (SbQueuedChunk *)(n->node);

            /* lose the chunk */
            SB_PUTMSG( chunk->mBuf );
            SB_FREE( sizeof(SbQueuedChunk), chunk );
         }
         break;
      }

      case SB_DB_ASSEMBLYQ:
      {
         /* Assembly Queue */
         l = &(assocCb->sbDbCb.assemblyQ);

         while ( cmLListLen( l ) > 0 )
         {
            n = cmLListFirst( l );
            n = cmLListDelFrm( l, n );
            sbGlobalCb.rxChunks--;
            chunk = (SbQueuedChunk *)(n->node);
            /* sb051.102: Checking the error for SSI function call */
            err = SFndLenMsg(chunk->mBuf, &len);
            if(err != ROK) 
	    {
               SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
                       "sbDbDelAll:Could not get the length of the buffer\n"));
	       SB_PUTMSG(chunk->mBuf);
	       SB_FREE(sizeof(SbQueuedChunk), chunk)
	       RETVALUE( RFAILED );
	    }
            assocCb->sbAcCb.ownRWnd += len;

            /* lose the chunk */
            SB_PUTMSG( chunk->mBuf );
            SB_FREE( sizeof(SbQueuedChunk), chunk );
         }
         break;
      }

      case SB_DB_SEQUENCEDQ:
      {
         if (assocCb->sbDbCb.sequencedQ == (CmLListCp *) NULLP)
         {
            RETVALUE( ROK );
         }

         /* Sequenced Delivery Queue */
         for ( i = 0; i < assocCb->sbSqCb.nmbInStreams; i++ )
         {
            l = &(assocCb->sbDbCb.sequencedQ[i]);

            while (cmLListLen( l ) > 0)
            {
               n = cmLListFirst( l );
               n = cmLListDelFrm( l, n );
               sbGlobalCb.rxChunks--;
               chunk = (SbQueuedChunk *)(n->node);
               /* sb051.102: Checking the error for SSI function call */
               err = SFndLenMsg(chunk->mBuf, &len);
               if(err != ROK ) 
	       {
                  SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
                          "sbDbDelAll:Could not get the length of the buffer\n"));
	          SB_PUTMSG(chunk->mBuf);
	          SB_FREE(sizeof(SbQueuedChunk), chunk)
	          RETVALUE( RFAILED );
	       }
               assocCb->sbAcCb.ownRWnd += len;

               /* lose the chunk */
               SB_PUTMSG( chunk->mBuf );
               SB_FREE( sizeof(SbQueuedChunk), chunk );
            }
         }
         break;
      }

#if ( ERRCLASS & ERRCLS_DEBUG )
      default:
      {
         SBLOGERROR( ERRCLS_DEBUG, ESB103, (ErrVal) qType,
                     "sbDbDelAll: Invalid Queue Type" );
         RETVALUE( RFAILED );
         break;
      }
#endif
   }

   RETVALUE( ROK );
}/* end of sbDbDelAll */


/*
*
*      Fun:   Insert the given data chunk into a queue
*
*      Desc:  Used to insert the supplied instance of SbQueuedChunk into
*             the supplied queue. The method of inserting into the queue
*             depends on the queue that the data chunk is being inserted
*             into. If it is being inserted into the tsnWaitingQ then if
*             it is a ordered chunk it is placed at the back of the
*             ordered tsnWaiting linked list, otherwise if it is an
*             unordered data chunk, then it is placed in the unordered
*             tsnWaiting linked list. If it is placed in the congestionQ
*             then it is placed at the end of that linked list. If the
*             data chunk is to be placed in the assemblyQ, then the list
*             is traveresed and the SbQueuedChunk instance is placed in
*             ordered of increasing TSN. When the insertion is into the
*             sequencedQ, then the data chunk is put into the sequenced
*             linked list as indexed by the stream number and the chunks
*             are ordered in increasing order of sequence number. This
*             function is also responsible for starting the lifetime
*             timer when inserting the SbQueuedChunk into the
*             tsnWaitingQ.
*
*      Ret:   ROK
*             RFAILED
*
*      Notes: None
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbDbInsert
(
SbSctAssocCb  *assocCb,                 /* Association                */
SbQueuedChunk *chunk,                   /* Chunk to queue             */
U8            qType                     /* Queue to operate on        */
)
#else
PUBLIC S16 sbDbInsert(assocCb, chunk, qType)
SbSctAssocCb  *assocCb;                 /* Association                */
SbQueuedChunk *chunk;                   /* Chunk to queue             */
U8            qType;                    /* Queue to operate on        */
#endif
{
   CmLList *n;
   CmLListCp *l;
   MsgLen msgLen;
   /* sb049.102: Checking SSI function call return */
   S16 err;

   TRC2( sbDbInsert );

   SBDBGP( SB_DBGMASK_DB, (sbGlobalCb.sbInit.prntBuf,
                           "sbDbInsert(assocCb, chunk, qType(%d))\n",
                           qType ) );

   /* Sanity Checks */
#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( chunk == (SbQueuedChunk *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB104, (ErrVal) 0,
                  "sbDbInsert: Chunk pointer is NULL" );
      RETVALUE( RFAILED );
   }

   if ( qType >= SB_DB_NUMQUEUES )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB105, (ErrVal) qType,
                  "sbDbInsert: Invalid Queue Type" );
      SB_PUTMSG(chunk->mBuf);

      SB_FREE(sizeof(SbQueuedChunk), chunk)

      RETVALUE( RFAILED );
   }

   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB106, (ErrVal) 0,
                  "sbDbInsert: Association is NULL" );
      SB_PUTMSG(chunk->mBuf);

      SB_FREE(sizeof(SbQueuedChunk), chunk)

      RETVALUE( RFAILED );
   }
#endif

   /* sb049.102: Checking the error for SSI function call */
   err = SFndLenMsg(chunk->mBuf, &msgLen);
   if (err != ROK)
   {
      SBDBGP(SB_DBGMASK_DB, (sbGlobalCb.sbInit.prntBuf,
                  "sbDbInsert: Wrong Length\n"));
      SB_PUTMSG(chunk->mBuf);
      SB_FREE(sizeof(SbQueuedChunk), chunk)
      RETVALUE( RFAILED );
   }

   SBDBGP( SB_DBGMASK_DB, (sbGlobalCb.sbInit.prntBuf,
                           "sbDbInsert: msgLen = %d\n",
                           msgLen ) );

   chunk->lstEntry.node = (PTR)chunk;        /* Back pointer to itself     */

   /* Select queue */
   switch ( qType )
   {
      case SB_DB_TSNWAITINGQ:
      {
         /* TSN Waiting Queue */
         if ( chunk->unorderedFlg == TRUE )
         {
            l = &(assocCb->sbDbCb.tsnWaitingQUnord);
         }
         else
         {
            l = &(assocCb->sbDbCb.tsnWaitingQOrd);
         }

         chunk->lstEntry.node = (PTR)chunk;
         cmLListAdd2Tail( l, &(chunk->lstEntry) );
         chunk->qState = SB_DB_TSNWAITINGQ;

         /* start lifetime timer */
         if (chunk->lifetime > 0)
         {
            cmInitTimers( &(chunk->lifetimeTmr), 1 );
            SB_START_TMR( &(chunk->lifetimeTmr), chunk,
                          SB_TMR_LIFETIME, chunk->lifetime );
         }
         sbGlobalCb.txChunks++;
         break;
      }

      case SB_DB_CONGESTIONQ:
      {
         /* Congestion Queue */
         l = &(assocCb->sbDbCb.congestionQ);

         chunk->lstEntry.node = (PTR)chunk;
         cmLListAdd2Tail( l, &(chunk->lstEntry) );
         chunk->qState = SB_DB_CONGESTIONQ;
        /* Performance fix */
         if(assocCb->sbDbCb.newPkt == NULLP)
             assocCb->sbDbCb.newPkt = &chunk->lstEntry;
         sbGlobalCb.txChunks++;
         break;
      }

      case SB_DB_ASSEMBLYQ:
      {
         /* Assembly Queue */
         l = &(assocCb->sbDbCb.assemblyQ);
         n = cmLListFirst( l );

         while ( n != (CmLList *)NULLP )
         {
            if ( ( (SbQueuedChunk *)(n->node) )->tsn > chunk->tsn )
            {
               n = (CmLList *)NULLP;
            }
            else
            {
               n = cmLListNext( l );
            }
         }

         n = cmLListCrnt(l);
         chunk->lstEntry.node = (PTR)chunk;
         if ( n == (CmLList *)NULLP )
         {
            cmLListAdd2Tail( l, &(chunk->lstEntry) );
         }
         else
         {
            cmLListInsCrnt( l, &(chunk->lstEntry) );
         }

         chunk->qState = SB_DB_ASSEMBLYQ;

         sbGlobalCb.rxChunks++;
         assocCb->sbAcCb.ownRWnd -= msgLen;

         break;
      }

      case SB_DB_SEQUENCEDQ:
      {
         /* Sequenced Delivery Queue */
         if (assocCb->sbDbCb.sequencedQ == (CmLListCp *) NULLP)
         {
            SB_PUTMSG(chunk->mBuf);

            SB_FREE(sizeof(SbQueuedChunk), chunk)

            RETVALUE( RFAILED );
         }

         l = &(assocCb->sbDbCb.sequencedQ[chunk->stream]);
         n = cmLListFirst(l);

         while ( n != (CmLList *)NULLP )
         {
            if ( ((SbQueuedChunk *)(n->node))->seqNum > chunk->seqNum )
            {
               n = (CmLList *)NULLP;
            }
            else
            {
               n = cmLListNext( l );
            }
         }

         n = cmLListCrnt( l );

         chunk->lstEntry.node = (PTR)chunk;
         if ( n == (CmLList *)NULLP )
         {
            cmLListAdd2Tail( l, &(chunk->lstEntry) );
         }
         else
         {
            cmLListInsCrnt( l, &(chunk->lstEntry) );
         }

         chunk->qState = SB_DB_SEQUENCEDQ;

         sbGlobalCb.rxChunks++;
         assocCb->sbAcCb.ownRWnd -= msgLen;

         break;
      }

#if ( ERRCLASS & ERRCLS_DEBUG )
      default:
      {
         SBLOGERROR( ERRCLS_DEBUG, ESB107, (ErrVal) qType,
                     "sbDbInsert: Invalid Queue Type" );
         SB_PUTMSG(chunk->mBuf);

         SB_FREE(sizeof(SbQueuedChunk), chunk)

         RETVALUE( RFAILED );
      }
#endif

   }

   RETVALUE( ROK );
}/* end of sbDbInsert */


/*
*
*      Fun:   List Size
*
*      Desc:  This function returns the amount of memory used up by the
*             mBuf message buffers in requested linked list. It returns
*             both the dynamic memory used by the messages and the
*             static memory used by the SbQueuedChunk structures.
*
*      Ret:   ROK
*             RFAILED
*
*      Notes: None
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbDbListSize
(
CmLListCp     *l,                       /* List to search             */
U32           *staticMem,               /* Static Memory used         */
U32           *msgMem                   /* Dynamic Memory used        */
)
#else
PUBLIC S16 sbDbListSize(l, staticMem, msgMem)
CmLListCp     *l;                       /* List to search             */
U32           *staticMem;               /* Static Memory used         */
U32           *msgMem;                  /* Dynamic Memory used        */
#endif
{
   S16 err;
   CmLList *n;
   MsgLen len;

   TRC2( sbDbListSize );

/*   SBDBGP( SB_DBGMASK_DB, (sbGlobalCb.sbInit.prntBuf,
                           "sbDbListSize(l, staticMem, msgMem)\n" ) );
*/
   *staticMem = 0;
   *msgMem = 0;

   n = cmLListFirst( l );

   while ( n != (CmLList *)NULLP )
   {
      err = SFndLenMsg( ((SbQueuedChunk *)(n->node))->mBuf, &len );

#if ( ERRCLASS & ERRCLS_DEBUG )
      if ( err != ROK )
      {
         SBLOGERROR( ERRCLS_DEBUG, ESB108, (ErrVal) err,
                     "sbDbListSize: Failed to retrieve Message Length" );
         RETVALUE( RFAILED );
      }

      if ( len < 0 )
      {
         SBLOGERROR( ERRCLS_DEBUG, ESB109, (ErrVal) err,
                     "sbDbListSize: Negative Message Length" );
         RETVALUE( RFAILED );
      }
#endif

      *msgMem += len;

      n = cmLListNext( l );
   }

   *staticMem = cmLListLen( l ) * sizeof( SbQueuedChunk );

/*   SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
           "Returning sbDbListSize(l, staticMem(%ld), msgMem(%ld))\n",
           *staticMem, *msgMem ) );
*/
   RETVALUE( ROK );
}/* end of sbDbListSize */


/*
*
*      Fun:   Queue Size
*
*      Desc:  This function returns the amount of memory used up by the
*             requested queue. Returns the static and message memory
*             usage.
*
*      Ret:   ROK
*             RFAILED
*
*      Notes: None
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbDbQSize
(
SbSctAssocCb  *assocCb,                 /* Association                */
U32           *staticMem,               /* Static Memory usage        */
U32           *msgMem,                  /* Message Memory usage       */
U8            qType                     /* Queue to operate on        */
)
#else
PUBLIC S16 sbDbQSize(assocCb, staticMem, msgMem, qType)
SbSctAssocCb  *assocCb;                 /* Association                */
U32           *staticMem;               /* Static Memory usage        */
U32           *msgMem;                  /* Message Memory usage       */
U8            qType;                    /* Queue to operate on        */
#endif
{
   CmLListCp *l;
   S16 err;
   SctStrmId i;
   U32 tmpStaticMem;
   U32 tmpMsgMem;

   TRC2( sbDbQSize );

   *staticMem = 0;
   *msgMem = 0;

   /* Sanity Checks */
#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( qType >= SB_DB_NUMQUEUES )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB110, (ErrVal) qType,
                  "sbDbQSize: Invalid Queue Type" );
      RETVALUE( RFAILED );
   }

   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB111, (ErrVal) 0,
                  "sbDbQSize: Association is NULL" );
      RETVALUE( RFAILED );
   }
#endif

   switch ( qType )
   {
      case SB_DB_TSNWAITINGQ:
      {
         /* TSN Waiting Queue */
         l = &(assocCb->sbDbCb.tsnWaitingQUnord);
         err = sbDbListSize( l, staticMem, msgMem );

#if ( ERRCLASS & ERRCLS_DEBUG )
         if ( err != ROK )
         {
            SBLOGERROR( ERRCLS_DEBUG, ESB112, (ErrVal) err,
                        "sbDbQSize: Could not retrieve list size" );
            RETVALUE( RFAILED );
         }
#endif

         l = &(assocCb->sbDbCb.tsnWaitingQOrd);
         err = sbDbListSize( l, &tmpStaticMem, &tmpMsgMem );

#if ( ERRCLASS & ERRCLS_DEBUG )
         if ( err != ROK )
         {
            SBLOGERROR( ERRCLS_DEBUG, ESB113, (ErrVal) err,
                        "sbDbQSize: Could not retrieve list size" );
            RETVALUE( RFAILED );
         }
#endif

         *staticMem += tmpStaticMem;
         *msgMem += tmpMsgMem;

         break;
      }

      case SB_DB_CONGESTIONQ:
      {
         /* Congestion Queue */
         l = &(assocCb->sbDbCb.congestionQ);
         err = sbDbListSize( l, staticMem, msgMem );

#if ( ERRCLASS & ERRCLS_DEBUG )
         if ( err != ROK )
         {
            SBLOGERROR( ERRCLS_DEBUG, ESB114, (ErrVal) err,
                        "sbDbQSize: Could not retrieve list size" );
            RETVALUE( RFAILED );
         }
#endif

         break;
      }

      case SB_DB_ASSEMBLYQ:
      {
         /* Assembly Queue */
         l = &(assocCb->sbDbCb.assemblyQ);
         err = sbDbListSize( l, staticMem, msgMem );

#if ( ERRCLASS & ERRCLS_DEBUG )
         if ( err != ROK )
         {
            SBLOGERROR( ERRCLS_DEBUG, ESB115, (ErrVal) err,
                        "sbDbQSize: Could not retrieve list size" );
            RETVALUE( RFAILED );
         }
#endif

         break;
      }

      case SB_DB_SEQUENCEDQ:
      {
         /* Sequenced Delivery Queues */
         if (assocCb->sbDbCb.sequencedQ == (CmLListCp *) NULLP)
         {
            RETVALUE( RFAILED );
         }

         for ( i = 0; i < assocCb->sbSqCb.nmbInStreams; i++)
         {
            l = &(assocCb->sbDbCb.sequencedQ[i]);
            err = sbDbListSize( l, &tmpStaticMem, &tmpMsgMem );

#if ( ERRCLASS & ERRCLS_DEBUG )
            if ( err != ROK )
            {
               SBLOGERROR( ERRCLS_DEBUG, ESB116, (ErrVal) err,
                           "sbDbQSize: Could not retrieve list size" );
               RETVALUE( RFAILED );
            }
#endif

            *staticMem += tmpStaticMem;
            *msgMem += tmpMsgMem;
         }

         break;
      }

#if ( ERRCLASS & ERRCLS_DEBUG )
      default:
      {
         SBLOGERROR( ERRCLS_DEBUG, ESB117, (ErrVal) qType,
                     "sbDbQSize: Invalid Queue Type" );
         RETVALUE( RFAILED );
      }
#endif

   }

   SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
           "sbDbQSize(assocCb, staticMem(%lu), msgMem(%lu), qType(%d))\n",
           *staticMem, *msgMem, qType ) );


   RETVALUE( ROK );
}/* end of sbDbQSize */


/*
*
*      Fun:   Number of chunks in the queue
*
*      Desc:  Returns the number of data chunks that exist in the
*             specified queue.
*
*      Ret:   U32 - Number of chunks
*
*      Notes: None
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC U32 sbDbQPackets
(
SbSctAssocCb  *assocCb,                 /* Association                */
U8            qType                     /* Queue to operate on        */
)
#else
PUBLIC U32 sbDbQPackets(assocCb, qType)
SbSctAssocCb  *assocCb;                 /* Association                */
U8            qType;                    /* Queue to operate on        */
#endif
{
   U32 ret;
   SctStrmId i;
   CmLListCp *l;

   TRC2( sbDbQPackets );

   SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
                            "sbDbQPackets(assocCb, qType(%d))\n",
                            qType ) );

   /* Sanity checks */
#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( qType >= SB_DB_NUMQUEUES )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB118, (ErrVal) qType,
                  "sbDbQPackets: Invalid Queue Type" );
      RETVALUE( 0 );
   }

   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB119, (ErrVal) 0,
                  "sbDbQPackets: Association is NULL" );
      RETVALUE(0);
   }
#endif

   /* initial value */
   ret = 0;

   switch ( qType )
   {
      case SB_DB_TSNWAITINGQ:
      {
         l = &(assocCb->sbDbCb.tsnWaitingQUnord);
         ret = cmLListLen( l );

         l = &(assocCb->sbDbCb.tsnWaitingQOrd);
         ret += cmLListLen( l );

         break;
      }

      case SB_DB_CONGESTIONQ:
      {
         l = &(assocCb->sbDbCb.congestionQ);
         ret = cmLListLen( l );

         break;
      }

      case SB_DB_ASSEMBLYQ:
      {
         l = &(assocCb->sbDbCb.assemblyQ);
         ret = cmLListLen( l );

         break;
      }

      case SB_DB_SEQUENCEDQ:
      {
         if (assocCb->sbDbCb.sequencedQ == (CmLListCp *) NULLP)
         {
            RETVALUE( 0 );
         }

         for ( i = 0; i < assocCb->sbSqCb.nmbInStreams; i++ )
         {
            l = &(assocCb->sbDbCb.sequencedQ[i]);
            ret += cmLListLen( l );
         }

         break;
      }

#if ( ERRCLASS & ERRCLS_DEBUG )
      default:
      {
         SBLOGERROR( ERRCLS_DEBUG, ESB120, (ErrVal) qType,
                     "sbDbQPackets: Invalid Queue Type" );
         break;
      }
#endif

   }

   RETVALUE(ret);
}/* end of sbDbQPackets */


/*
*
*      Fun:   Assembled chunks
*
*      Desc:  Return a assembled data chunk if one exists. This function
*             needs to first check if a sequence of chunks exists that
*             are ready for assembly. This means it needs a chunk with
*             the startFlg set, a chunk with the endFlg set and then
*             every chunk with TSNs between these two chunks. If there
*             are any gaps between the start and end chunk, then the
*             message cannot be reassembled. The function also needs to
*             check for the case when segmentation takes places over the
*             TSN turnaround. I.e. when the chunk with the startFlg has
*             a larger TSN than the chunk with the endFlg.
*
*      Ret:   SbQueuedChunk*
*
*      Notes: None
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC SbQueuedChunk *sbDbAssembled
(
SbSctAssocCb  *assocCb                  /* Association                */
)
#else
PUBLIC SbQueuedChunk *sbDbAssembled(assocCb)
SbSctAssocCb  *assocCb;                 /* Association                */
#endif
{
   Bool rpt;
   SctTSN tsn;
   CmLList *n;
   CmLList *tmp;
   CmLList *nFirst;
   CmLList *nLast;
   CmLListCp *l;
   SbQueuedChunk *chunk;
   MsgLen len;
   /* sb051.102: Checking SSI function call return */
   S16 err;

   TRC2( sbDbAssembled );

   SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
                            "sbDbAssembled(assocCb)\n" ) );

   /* Sanity Checks */
#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB121, (ErrVal) 0,
                  "sbDbAssembled: Association is NULL" );
      RETVALUE( (SbQueuedChunk *)NULLP );
   }
#endif

   nFirst = (CmLList *)NULLP;
   nLast = (CmLList *)NULLP;
   rpt = FALSE;
   tsn = 0;

   l = &(assocCb->sbDbCb.assemblyQ);
   n = cmLListFirst( l );

   while ( ( nLast == (CmLList *)NULLP ) &&
           ( n != (CmLList *)NULLP     ) )
   {
      chunk = (SbQueuedChunk *)n->node;

      if ( ( chunk->startFlg == TRUE ) &&
           ( chunk->endFlg == FALSE  ) )
      {
         nFirst = n;
         nLast = (CmLList *)NULLP;
         tsn = chunk->tsn;
      }

      if ( ( chunk->startFlg == FALSE ) &&
           ( chunk->endFlg == FALSE   ) )
      {
         if ( chunk->tsn == (tsn + 1) )
         {
            tsn++;
         }
         else
         {
            nFirst = (CmLList *)NULLP;
            nLast = (CmLList *)NULLP;
         }
      }

      if ( ( chunk->startFlg == FALSE ) &&
           ( chunk->endFlg == TRUE    ) )
      {
         if ( chunk->tsn == (tsn + 1) )
         {
            tsn++;
            if ( nFirst != (CmLList *)NULLP )
            {
               nLast = n;
               n = (CmLList *)NULLP;
               SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
                       "sbDbAssembled: Found a matching, insequence endFlg\n"));
            }
         }
         else
         {
            nFirst = (CmLList *)NULLP;
            nLast = (CmLList *)NULLP;
         }
      }

      if ( n != (CmLList *)NULLP )
      {
         if ( ( n->next == (CmLList *)NULLP ) &&
              ( nFirst != (CmLList *)NULLP  ) &&
              ( rpt == FALSE                ) )
         {
            n = cmLListFirst( l );
            rpt = TRUE;
         }
         else
         {
            n = cmLListNext( l );
         }
      }
   }

   if ( ( nFirst != (CmLList *)NULLP ) &&
        ( nLast != (CmLList *)NULLP  ) )
   {

      SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
           "sbDbAssembled: Found a data chunk sequence ready for assembly\n"));

      n = nFirst;
      tmp = n->next;
      if ( tmp == (CmLList *)NULLP )
      {
         SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
                 "sbDbAssembled: Looping round to first element in queue\n"));

         tmp = cmLListFirst( l );
      }

      nFirst = cmLListDelFrm( l, nFirst );
      sbGlobalCb.rxChunks--;

      chunk = (SbQueuedChunk *)(nFirst->node);
      chunk->qState = SB_DB_INVALQ;

      /* sb051.102: Checking the error for SSI function call */
      err = SFndLenMsg(chunk->mBuf, &len);
      if(err != ROK) 
      {
         SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
  	       "sbDbAssembled: Could not get the length of the buffer\n"));
         SB_PUTMSG(chunk->mBuf);
         SB_FREE(sizeof(SbQueuedChunk), chunk)
         RETVALUE( (SbQueuedChunk *)NULLP );
      }
      assocCb->sbAcCb.ownRWnd += len;

      while ( n != nLast )
      {
         n = tmp;

#if ( ERRCLASS & ERRCLS_DEBUG )
         if ( n == (CmLList *)NULLP )
         {
            SBLOGERROR( ERRCLS_DEBUG, ESB122, (ErrVal) 0,
                        "sbDbAssembled: Reached NULL before nLast" );

            /* lose the chunk */
            SB_PUTMSG( chunk->mBuf );
            SB_FREE( sizeof(SbQueuedChunk), chunk );

            RETVALUE( (SbQueuedChunk *)NULLP );
         }

         if ( n == nFirst )
         {
            SBLOGERROR( ERRCLS_DEBUG, ESB123, (ErrVal) 0,
                        "sbDbAssembled: Looped back to the start" );

            /* lose the chunk */
            SB_PUTMSG( chunk->mBuf );
            SB_FREE( sizeof(SbQueuedChunk), chunk );

            RETVALUE( (SbQueuedChunk *)NULLP );
         }
#endif

         tmp = n->next;
         if ( tmp == (CmLList *)NULLP )
         {
            SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
                 "sbDbAssembled: Looping round to first element in queue\n"));

            tmp = cmLListFirst( l );
         }

         n = cmLListDelFrm( l, n );
         sbGlobalCb.rxChunks--;

#if ( ERRCLASS & ERRCLS_DEBUG )
         if ( n == (CmLList *)NULLP )
         {
            SBLOGERROR( ERRCLS_DEBUG, ESB124, (ErrVal) 0,
                        "sbDbAssembled: Could not remove chunk from assemblyQ");

            /* lose the chunk */
            SB_PUTMSG( chunk->mBuf );
            SB_FREE( sizeof(SbQueuedChunk), chunk );

            RETVALUE( (SbQueuedChunk *)NULLP );
         }
#endif

         /* sb051.102: Checking the error for SSI function call */
         err = SFndLenMsg(((SbQueuedChunk *)(n->node))->mBuf, &len);
         if(err != ROK) 
         {
            SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
  	          "sbDbAssembled: Could not get the length of the buffer\n"));
            SB_PUTMSG(chunk->mBuf);
            SB_FREE(sizeof(SbQueuedChunk), chunk)
            RETVALUE( (SbQueuedChunk *)NULLP );
         }
         assocCb->sbAcCb.ownRWnd += len;

         ((SbQueuedChunk *)(n->node))->qState = SB_DB_INVALQ;

         SCatMsg( chunk->mBuf, ((SbQueuedChunk *)(n->node))->mBuf, M1M2 );

         SB_PUTMSG( ((SbQueuedChunk *)(n->node))->mBuf );
         SB_FREE( sizeof(SbQueuedChunk), (n->node) );
      }

      SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
              "sbDbAssembled: Returning reassembled data chunk\n"));

      RETVALUE( chunk );
   }

   RETVALUE( (SbQueuedChunk *)NULLP );
}/* end of sbDbAssembled */


/*
*
*      Fun:   Ordered data chunks
*
*      Desc:  Return an ordered data chunk in the requested stream
*
*      Ret:   SbQueuedChunk*
*
*      Notes: None
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC SbQueuedChunk *sbDbOrdered
(
SbSctAssocCb  *assocCb,                  /* Association                */
SctStrmId      stream,                   /* Stream to order            */
U16            seqNum                    /* Expected Sequence Number   */
)
#else
PUBLIC SbQueuedChunk *sbDbOrdered(assocCb, stream, seqNum)
SbSctAssocCb  *assocCb;                  /* Association                */
SctStrmId      stream;                   /* Stream to order            */
U16            seqNum;                   /* Expected Sequence Number   */
#endif
{
   CmLList *n;
   CmLListCp *l;
   MsgLen len;
   /* sb051.102: Checking SSI function call return */
   S16 err;

   TRC2( sbDbOrdered );

   SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
                            "sbDbOrdered(assocCb, stream(%d), seqNum(%d))\n",
                            stream, seqNum ) );

   /* Sanity Checks */
#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB125, (ErrVal) 0,
                  "sbDbOrdered: Association is NULL" );
      RETVALUE( (SbQueuedChunk *)NULLP );
   }

   if ( stream >= assocCb->sbSqCb.nmbInStreams )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB126, (ErrVal) stream,
                  "sbDbOrdered: Stream too large" );
      RETVALUE( (SbQueuedChunk *)NULLP );
   }
#endif

   if (assocCb->sbDbCb.sequencedQ == (CmLListCp *) NULLP)
   {
      RETVALUE( (SbQueuedChunk *)NULLP );
   }

   l = &(assocCb->sbDbCb.sequencedQ[stream]);
   n = cmLListFirst(l);

   if ( n == (CmLList *)NULLP )
   {
      SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
              "sbDbOrdered: Sequenced Queue [stream = %d] is empty\n",
              stream));
      RETVALUE( (SbQueuedChunk *)NULLP );
   }

   if ( ((SbQueuedChunk *)(n->node))->seqNum < seqNum )
   {
      SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
              "sbDbOrdered: Need to loop around to find in-sequence chunk\n"));

      n = cmLListNext( l );

      while ( n != (CmLList *)NULLP )
      {
         if ( ((SbQueuedChunk *)(n->node))->seqNum == seqNum )
         {
            n = cmLListDelFrm( l, n );
            sbGlobalCb.rxChunks--;

            /* sb051.102: Checking the error for SSI function call */
            err = SFndLenMsg(((SbQueuedChunk *)(n->node))->mBuf, &len);
            if(err != ROK) 
            {
               SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
  	             "sbDbOrdered: Could not get the length of the buffer\n"));
               RETVALUE( (SbQueuedChunk *)NULLP );
            }
            assocCb->sbAcCb.ownRWnd += len;
            ((SbQueuedChunk *)(n->node))->qState = SB_DB_INVALQ;

            SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
                                     "sbDbOrdered: Found ordered chunk\n" ));
            RETVALUE( (SbQueuedChunk *)(n->node) );
         }

         n = cmLListNext(l);
      }
   }
   else
   {
      if ( ((SbQueuedChunk *)(n->node))->seqNum == seqNum)
      {
         n = cmLListDelFrm( l, n );
         sbGlobalCb.rxChunks--;

         /* sb051.102: Checking the error for SSI function call */
         err = SFndLenMsg(((SbQueuedChunk *)(n->node))->mBuf, &len);
         if(err != ROK) 
         {
            SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
  	          "sbDbOrdered: Could not get the length of the buffer\n"));
            RETVALUE( (SbQueuedChunk *)NULLP );
         }
         assocCb->sbAcCb.ownRWnd += len;

         ((SbQueuedChunk *)(n->node))->qState = SB_DB_INVALQ;

         SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
                                  "sbDbOrdered: Found ordered chunk\n" ));

         RETVALUE( (SbQueuedChunk *)(n->node) );
      }
   }

   RETVALUE( (SbQueuedChunk *)NULLP );
}/* end of sbDbOrdered */


/*
*
*      Fun:   Get specified Chunk
*
*      Desc:  Find out which queue the data chunk is in to get the
*             pointer to the linked list. With this the data chunk is
*             removed from the queue. If the removal takes place from
*             tsnWaitingQ, then the lifetime timer needs to be stopped
*             for the SbQueuedChunk.
*
*      Ret:   SbQueuedChunk*
*
*      Notes: None
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC SbQueuedChunk *sbDbGetChunk
(
SbSctAssocCb  *assocCb,                 /* Association                */
SbQueuedChunk *chunk                    /* Chunk Requested            */
)
#else
PUBLIC SbQueuedChunk *sbDbGetChunk(assocCb, chunk)
SbSctAssocCb  *assocCb;                 /* Association                */
SbQueuedChunk *chunk;                   /* Chunk Requested            */
#endif
{
   CmLList *n;
   CmLListCp *l;
   MsgLen len;
   /* sb051.102: Checking SSI function call return */
   S16 err;

   TRC2( sbDbGetChunk );

   SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
                            "sbDbGetChunk(assocCb, chunk)\n" ) );

   l = (CmLListCp *)NULLP;

   /* Sanity checks */
#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( chunk == (SbQueuedChunk *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB127, (ErrVal) 0,
                  "sbDbGetChunk: Chunk pointer is NULL" );
      RETVALUE( (SbQueuedChunk *)NULLP );
   }

   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB128, (ErrVal) 0,
                  "sbDbGetChunk: Association is NULL" );
      SB_PUTMSG(chunk->mBuf);

      SB_FREE(sizeof(SbQueuedChunk), chunk)

      RETVALUE( (SbQueuedChunk *)NULLP );
   }
#endif

   /* select the queue */
   switch ( chunk->qState )
   {
      case SB_DB_TSNWAITINGQ :
      {
         if ( chunk->unorderedFlg == TRUE )
         {
            l = &(assocCb->sbDbCb.tsnWaitingQUnord);
         }
         else
         {
            l = &(assocCb->sbDbCb.tsnWaitingQOrd);
         }
         sbGlobalCb.txChunks--;
         break;
      }

      case SB_DB_CONGESTIONQ :
      {
         l = &(assocCb->sbDbCb.congestionQ);
         sbGlobalCb.txChunks--;
         break;
      }

      case SB_DB_ASSEMBLYQ :
      {
         l = &(assocCb->sbDbCb.assemblyQ);
         /* sb051.102: Checking the error for SSI function call */
         err = SFndLenMsg(chunk->mBuf, &len);
         if(err != ROK) 
         {
            SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
  	          "sbDbGetChunk: Could not get the length of the buffer\n"));
            SB_PUTMSG( chunk->mBuf );
            SB_FREE( sizeof(SbQueuedChunk), chunk );
            RETVALUE( (SbQueuedChunk *)NULLP );
         }
         assocCb->sbAcCb.ownRWnd += len;
         sbGlobalCb.rxChunks--;
         break;
      }

      case SB_DB_SEQUENCEDQ :
      {

#if ( ERRCLASS & ERRCLS_DEBUG )
         if ( chunk->stream >= assocCb->sbSqCb.nmbInStreams )
         {
            SBLOGERROR( ERRCLS_DEBUG, ESB129, (ErrVal) chunk->stream,
                        "sbDbGetChunk: Invalid stream number in data chunk" );

            /* lose the chunk */
            SB_PUTMSG( chunk->mBuf );
            SB_FREE( sizeof(SbQueuedChunk), chunk );

            RETVALUE( (SbQueuedChunk *)NULLP );
         }

         if (assocCb->sbDbCb.sequencedQ == (CmLListCp *) NULLP)
         {
            SBLOGERROR( ERRCLS_DEBUG, ESB130, (ErrVal) chunk->stream,
                        "sbDbGetChunk: sequencedQ not yet initialised" );

            /* lose the chunk */
            SB_PUTMSG( chunk->mBuf );
            SB_FREE( sizeof(SbQueuedChunk), chunk );

            RETVALUE( (SbQueuedChunk *)NULLP );
         }

#endif

         l = &(assocCb->sbDbCb.sequencedQ[chunk->stream]);

         /* sb051.102: Checking the error for SSI function call */
         err = SFndLenMsg(chunk->mBuf, &len);
         if(err != ROK) 
         {
            SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
  	          "sbDbGetChunk: Could not get the length of the buffer\n"));
            SB_PUTMSG( chunk->mBuf );
            SB_FREE( sizeof(SbQueuedChunk), chunk );
            RETVALUE( (SbQueuedChunk *)NULLP );
         }
         assocCb->sbAcCb.ownRWnd += len;

         sbGlobalCb.rxChunks--;

         break;
      }

#if ( ERRCLASS & ERRCLS_DEBUG )
      default:
      {
         SBLOGERROR( ERRCLS_DEBUG, ESB131, (ErrVal) chunk->qState,
                     "sbDbGetChunk: Invalid queue type in chunk" );

         /* lose the chunk */
         SB_PUTMSG( chunk->mBuf );
         SB_FREE( sizeof(SbQueuedChunk), chunk );

         RETVALUE( (SbQueuedChunk *)NULLP );
         break;
      }
#endif

   }

   n = &(chunk->lstEntry);
   cmLListDelFrm( l, n );

   if ( chunk->qState == SB_DB_TSNWAITINGQ )
   {
      if ( chunk->lifetimeTmr.tmrEvnt != TMR_NONE )
      {
         SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
                                  "Stopping lifetime timer\n" ) );
         SB_STOP_TMR( &(chunk->lifetimeTmr) )
      }
   }

   chunk->qState = SB_DB_INVALQ;

   RETVALUE( chunk );
}/* end of sbDbGetChunk */


/**********************************************************************
 *  Segmentation and reassemble functional block                      *
 **********************************************************************/


/*
*
*      Fun:   Segment Data chunk
*
*      Desc:  Segment the next available data chunk in the tsnWaitingQ.
*             A pointer to the first chunk is first retrieved from the
*             tsnWaitingQ. The size of the data chunk together with its
*             destination address are used to decide if it can be placed
*             on the congestionQ. If it can be placed on the
*             congestionQ, then it is permanently removed from the
*             tsnWaitingQ and the size of the chunk is checked against
*             the MTU path size. If it is bigger, then additional
*             messages are created into which this one message is broken
*             up into. Each is then placed in identical copies of the
*             SbQueuedChunk structure. These are then sent to the
*             Acknowledgement and Congestion Avoidance FB
*
*      Ret:   ROK
*             RFAILED
*
*      Notes: None
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbSgSegment
(
SbSctAssocCb  *assocCb                  /* Association                */
)
#else
PUBLIC S16 sbSgSegment(assocCb)
SbSctAssocCb  *assocCb;                 /* Association                */
#endif
{
   S16 err;
   Bool space;
   U16 mtu;
   S32 tmpMtu;
   MsgLen len;
   MsgLen originalLen;
   SbQueuedChunk *chunk;
   SbQueuedChunk *newChunk;

   TRC2( sbSgSegment );

   SBDBGP( SB_DBGMASK_SG, ( sbGlobalCb.sbInit.prntBuf,
                            "sbSgSegment(assocCb)\n" ) );

#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB132, (ErrVal) 0,
                  "sbSgSegment: Association is NULL" );
      RETVALUE( RFAILED );
   }
#endif

   chunk = sbDbGetFirst( assocCb, SB_DB_TSNWAITINGQ );
   if ( chunk == (SbQueuedChunk *)NULLP )
   {
      /* queue must be empty */
      RETVALUE( RFAILED );
   }

   /* sb020.102: active takes value SCT_PATH_ACTIVE */
   if (chunk->addrCb->active == SCT_PATH_INACTIVE )
   {
      err = sbPmSelNextAddr(assocCb, chunk);
   }

   /* is there space to send more data? */
   space = sbAcSpace( assocCb, chunk );
   if ( space == FALSE )
   {
      SBDBGP( SB_DBGMASK_SG, ( sbGlobalCb.sbInit.prntBuf,
              "No space left for further transmissions\n" ) );
      RETVALUE( RFAILED );
   }

   chunk = sbDbGetChunk( assocCb, chunk );

#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( chunk == (SbQueuedChunk *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB133, (ErrVal) 0,
                  "sbSgSegment: Chunk lost in tsnWaitingQ since last check" );
      RETVALUE( RFAILED );
   }
#endif

   /* determine MTU */
   /* sb023.102  - Performance Fix, Instead of SB_QUERY_MTU, we will directly
    * get the mtu from the mtuIndex  in AddrCb */
   SB_GET_MTU(chunk->addrCb, mtu, err);

#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( err != ROK )
   {
      SBDBGP(SB_DBGMASK_AC, (sbGlobalCb.sbInit.prntBuf,
             "sbSgSegment: Path MTU discovery failed\n"));
      mtu = sbGlobalCb.genCfg.mtuInitial;
   }
#endif /* ERRCLS_DEBUG */

   tmpMtu = mtu - SB_COMMON_HEADER_SIZE - SB_CHUNK_HEADER_SIZE
            - SB_DATA_MIN_SIZE;

#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( tmpMtu <= 0 )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB134, (ErrVal) 0,
                  "sbSgSegment: MTU too small to accommodate headers" );

      /* lose the chunk */
      SB_PUTMSG( chunk->mBuf );
      SB_FREE( sizeof(SbQueuedChunk), chunk );

      RETVALUE( RFAILED );
   }
#endif

   mtu = (U16)tmpMtu;

   SBDBGP( SB_DBGMASK_SG, ( sbGlobalCb.sbInit.prntBuf,
          "sbSgSegment: using mtu of %d, mtuInitial = %d, performMtu = %d\n",
          mtu, sbGlobalCb.genCfg.mtuInitial, sbGlobalCb.genCfg.performMtu));

   /* sb051.102: Checking the error for SSI function call */
   err = SFndLenMsg(chunk->mBuf, &len);
   if(err != ROK) 
   {
      SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
  	  "sbSgSegment: Could not get the length of the buffer\n"));
      SB_PUTMSG( chunk->mBuf );
      SB_FREE( sizeof(SbQueuedChunk), chunk );
      RETVALUE( RFAILED );
   }
   if ( len <= (S16)mtu )
   {
      err = sbAcSendData(assocCb, chunk);

#if ( ERRCLASS & ERRCLS_DEBUG )

      if ( err != ROK )
      {
         SBLOGERROR( ERRCLS_DEBUG, ESB135, (ErrVal) err,
                    "sbSgSegment: Failed to send Data using sbAcSendData" );

         SB_PUTMSG( chunk->mBuf );
         SB_FREE( sizeof(SbQueuedChunk), chunk );

         RETVALUE( RFAILED );
      }

#endif

      RETVALUE( ROK );
   }

   originalLen = len;

   while ( len > (S16)mtu )
   {
      SB_ALLOC(sizeof(SbQueuedChunk), newChunk, err);

      if ( (newChunk == (SbQueuedChunk *)NULLP) || (err != ROK) )
      {
         SBDBGP( SB_DBGMASK_SG, ( sbGlobalCb.sbInit.prntBuf,
             "sbSgSegment: Failed to alloc. static mem. for segmentation\n"));

         SB_PUTMSG( chunk->mBuf );
         SB_FREE( sizeof(SbQueuedChunk), chunk );

         RETVALUE( RFAILED );
      }

      (Void) cmMemcpy( (U8 *)newChunk, (U8 *)chunk, (PTR)sizeof(SbQueuedChunk) );
      chunk->mBuf = (Buffer *)NULLP;

      SB_SEGMSG(newChunk->mBuf, (MsgLen)mtu, &(chunk->mBuf), err)
      /*err = SSegMsg(newChunk->mBuf, (MsgLen)mtu, &(chunk->mBuf));*/

#if ( ERRCLASS & ERRCLS_DEBUG )

      if ( err != ROK )
      {
         SBLOGERROR( ERRCLS_DEBUG, ESB136, (ErrVal) err,
                     "sbSgSegment: Could not segment message" );

         SB_CHK_PUTMSG( chunk->mBuf );
         SB_FREE( sizeof(SbQueuedChunk), chunk );

         SB_PUTMSG( newChunk->mBuf );
         SB_FREE( sizeof(SbQueuedChunk), newChunk );

         RETVALUE( RFAILED );
      }

#endif

      if (len == originalLen)
      {
         newChunk->startFlg = TRUE;
         newChunk->endFlg = FALSE;
      }
      else
      {
         newChunk->startFlg = FALSE;
         newChunk->endFlg = FALSE;
      }

      err = sbAcSendData( assocCb, newChunk );

#if ( ERRCLASS & ERRCLS_DEBUG )

      if ( err != ROK )
      {
         SBLOGERROR( ERRCLS_DEBUG,
                     ESB137,
                     (ErrVal) err,
                     "sbSgSegment(): Failed to send Data using sbAcSendData" );

         SB_PUTMSG( chunk->mBuf );
         SB_FREE( sizeof(SbQueuedChunk), chunk );

         RETVALUE( RFAILED );
      }

#endif

      /* sb051.102: Checking the error for SSI function call */
      err = SFndLenMsg(chunk->mBuf, &len);
      if(err != ROK) 
      {
         SBDBGP( SB_DBGMASK_DB, ( sbGlobalCb.sbInit.prntBuf,
     	  "sbSgSegment: Could not get the length of the buffer\n"));
         SB_PUTMSG( chunk->mBuf );
         SB_FREE( sizeof(SbQueuedChunk), chunk );
         RETVALUE( RFAILED );
      }
   }

   chunk->startFlg = FALSE;
   chunk->endFlg = TRUE;

   err = sbAcSendData( assocCb, chunk );

#if ( ERRCLASS & ERRCLS_DEBUG )

   if ( err != ROK )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB138,
                  (ErrVal) err,
                  "sbSgSegment(): Failed to send Data using sbAcSendData" );

      RETVALUE( RFAILED );
   }

#endif

   RETVALUE( ROK );
}/* end of sbSgSegment */


/*
*
*      Fun:   Reassemble Data chunk
*
*      Desc:  This function is responsible for reassembly of the
*             supplied data chunk into a complete message. Multiple
*             segments could have come from the same message, if the
*             message was larger than the MTU path size at the source
*             of the message. This function needs to check the startFlg
*             and endFlg of the message to decide whether the message
*             passed to it is only a segment of a larger message. If it
*             is, then the message is placed in the assemblyQ, otherwise
*             the message is just passed up to the service user. Because
*             queueing the message into the assemblyQ could have caused
*             a whole message to be present in the queue, the assemblyQ
*             needs to be checked for possible assembled messages. If
*             one exist, then it is sent to the service user.
*
*      Ret:   ROK
*             RFAILED       (optional under ERRCLS_DEBUG)
*
*      Notes: None
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbSgAssemble
(
SbSctAssocCb  *assocCb,                 /* Association                */
SbQueuedChunk *chunk                    /* Chunk                      */
)
#else
PUBLIC S16 sbSgAssemble(assocCb, chunk)
SbSctAssocCb  *assocCb;                 /* Association                */
SbQueuedChunk *chunk;                   /* Chunk                      */
#endif
{
   S16 err;

   TRC2( sbSgAssemble );

   SBDBGP( SB_DBGMASK_SG, ( sbGlobalCb.sbInit.prntBuf,
                            "sbSgAssemble(assocCb)\n" ) );

#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( chunk == (SbQueuedChunk *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG,
                  ESB139,
                  (ErrVal) 0,
                  "sbSgAssemble(): Chunk pointer is NULL" );

      RETVALUE( RFAILED );
   }

   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG,
                  ESB140,
                  (ErrVal) 0,
                  "sbSgAssemble(): Association is NULL" );
      SB_PUTMSG(chunk->mBuf);

      SB_FREE(sizeof(SbQueuedChunk), chunk)

      RETVALUE( RFAILED );
   }
#endif

   if ( (chunk->startFlg == TRUE) && (chunk->endFlg == TRUE) )
   {
      err = sbSqArrive( assocCb, chunk );

#if ( ERRCLASS & ERRCLS_DEBUG )

      if ( err != ROK )
      {
         SBDBGP( SB_DBGMASK_SG, ( sbGlobalCb.sbInit.prntBuf,
                 "sbSgAssemble: Failed to send Data using sbSqArrive\n" ) );
         RETVALUE( RFAILED );
      }

#endif

   }
   else
   {
      err = sbDbInsert( assocCb, chunk, SB_DB_ASSEMBLYQ );

#if ( ERRCLASS & ERRCLS_DEBUG )
      if ( err != ROK )
      {
         SBLOGERROR( ERRCLS_DEBUG,
                     ESB141,
                     (ErrVal) err,
                     "sbSgAssemble(): Failed to insert data into the assemblyQ" );

         RETVALUE( RFAILED );
      }
#endif

      chunk = sbDbAssembled( assocCb );

      while ( chunk != (SbQueuedChunk *)NULLP )
      {

         err = sbSqArrive( assocCb, chunk );

#if ( ERRCLASS & ERRCLS_DEBUG )
         if ( err != ROK )
         {
            SBLOGERROR( ERRCLS_DEBUG,
                        ESB142,
                        (ErrVal) err,
                        "sbSgAssemble(): Failed to send Data using sbSqArrive" );

            RETVALUE( RFAILED );
         }
#endif

         chunk = sbDbAssembled( assocCb );
      }
   }

   RETVALUE( ROK );
}/* end of sbSgAssemble */


/****************************************************************************/
/*    Message validation functional block                                   */
/****************************************************************************/


/*
*
*       Fun:   sbVaDatInd
*
*       Desc:  This function is called whenever data arrives from the
*              peer and needs to have the 32 bit checksum value validated.
*
*       Ret:   Success:              ROK
*              Failure:              RFAILED
*
*       Notes:
*
*       File:  sb_bdy2.c
*
*/
/* sb060.102 - TOS enhancement */
#ifdef SCT4
#ifdef ANSI
PUBLIC S16 sbVaDatInd
(
CmNetAddr *srcAddr, /* Address that the data arrived from */
CmNetAddr *dstAddr, /* Address interface on which the data arrived */
UConnId   suConId,  /* Connection ID used by SCTP */
Buffer    *mBuf,    /* Message Buffer */
U8        tos       /* TOS enhancement*/
)
#else
PUBLIC S16 sbVaDatInd(srcAddr, dstAddr, suConId, mBuf, tos)
CmNetAddr *srcAddr; /* Address that the data arrived from */
CmNetAddr *dstAddr; /* Address interface on which the data arrived */
UConnId   suConId;  /* Connection ID used by SCTP */
Buffer    *mBuf;    /* Message Buffer */
U8        tos;      /* TOS enhancement */
#endif
#else /* SCT4 */
#ifdef ANSI
PUBLIC S16 sbVaDatInd
(
CmNetAddr *srcAddr, /* Address that the data arrived from */
CmNetAddr *dstAddr, /* Address interface on which the data arrived */
UConnId suConId, /* Connection ID used by SCTP */
Buffer *mBuf     /* Message Buffer */
)
#else
PUBLIC S16 sbVaDatInd(srcAddr, dstAddr, suConId, mBuf)
CmNetAddr *srcAddr; /* Address that the data arrived from */
CmNetAddr *dstAddr; /* Address interface on which the data arrived */
UConnId suConId; /* Connection ID used by SCTP */
Buffer *mBuf;    /* Message Buffer */
#endif
#endif /* SCT4 */
{
   SctPort  srcPort;
   SctPort  dstPort;
   U32      vTag;
   U32      checksum;
   U32      chunkChecksum;
   U32      i;
   S16      err;
   MsgLen   len;
   U8       pkArray[12];
   U16      idx;
   S16      ret;
   MsgLen   cnt=0;
   Data     *msgBuf;

   TRC2( sbVaDatInd );

   /* read the checksum value from the header */

   /* Performance fix */
   SCpyMsgFix(mBuf, 8, 4, &pkArray[0], &cnt);
   

   /* write it into the temporary variable */
   idx = 0;
   chunkChecksum = 0;
   SB_UNPKU32(chunkChecksum);

   /* sb023.102 - Remove SRepMsg to avoid extra memory calls */

   len = 0;
   /* sb051.102: Checking the error for SSI function call */
   err = SFndLenMsg( mBuf, &len );
   if(err != ROK)
   {
      SBDBGP( SB_DBGMASK_VA, ( sbGlobalCb.sbInit.prntBuf,
     	  "sbVaDatInd: Could not get the length of the buffer\n"));
      SB_PUTMSG( mBuf );
      RETVALUE( RFAILED );
   }

   /* determine the Checksum thingy */
   checksum = 1L;
  
#ifdef SB_CHECKSUM
        /* Performance fix */
        /* sb023.102 - Change done to avoid unnecessary cmMemset, as this
         * buffer will be initialised correctly via SCpyMsgFix - Performance
         * Change */
        SB_GETSBUF(len, msgBuf, ret);
        if ( ret != ROK )
        {
           SBDBGP(SB_DBGMASK_PM, (sbGlobalCb.sbInit.prntBuf,
             "sbVaDatInd: Fail To allocate memory for checksum calcuation\n"));
           RETVALUE(RFAILED);
        }

       /* Performance fix */
       SCpyMsgFix(mBuf, 0, len, (Data*)msgBuf, &cnt);
       if( cnt != len )
       {
          SBDBGP(SB_DBGMASK_AC, (sbGlobalCb.sbInit.prntBuf,
                 "sbVaDatInd: SCpyFixMsg Failed \n"));
          RETVALUE(RFAILED);

       }
   
       /* sb023.102 - Put the extra zeros in place of checksum at this time
        * directly in msgBuf */
       for ( i = 8; i < 12; i++ )
       {
             msgBuf[i]=(U8)0x00;
       }
       checksum = sbChecksum32( checksum, (Data *)msgBuf, len );
       SB_FREE(len, msgBuf);
#else
   checksum=0L;
#endif

   if ( checksum == chunkChecksum )
   {
      /* Adler CRC checks out */
      err = SRemPreMsgMult(&pkArray[0], 12, mBuf);
      /* sb051.102: Checking for error conditions */
      if (err != ROK)
      {
         SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                  "sbVaDatInd: PreMsgMult Failed for mBuf\n"));
         SB_PUTMSG(mBuf);
         RETVALUE( RFAILED );
      }

      /* extract the header info */
      idx = 0;
 
      /* Initialize local variables */
      srcPort = 0;
      dstPort = 0;
      vTag = 0;
      checksum = 0;

      SB_UNPKU16(srcPort);
      SB_UNPKU16(dstPort);
      SB_UNPKU32(vTag);
      SB_UNPKU32(checksum);

      /* demultiplex */
      /* sb060.102 - TOS enhancement */
#ifdef SCT4
      err = sbCmDemux(dstAddr, srcAddr, dstPort, srcPort, vTag, suConId, mBuf, 
                      tos);
#else
      err = sbCmDemux(dstAddr, srcAddr, dstPort, srcPort, vTag, suConId, mBuf);
#endif /* SCT4 */
      if ( err != ROK )
      {
         SBDBGP( SB_DBGMASK_VA, ( sbGlobalCb.sbInit.prntBuf,
                 "sbVaDatInd: error while demultiplexing\n"));
         RETVALUE(err);
      }

      RETVALUE( ROK );
   }
   
   /* adler doesn't check out if we are here */
   /* sb007.102 Memory leak problem fixed for sbVaDatInd */
   SBDBGP( SB_DBGMASK_VA, ( sbGlobalCb.sbInit.prntBuf,
              "sbVaDatInd: Checksum doesn't match\n"));
   SB_PUTMSG( mBuf );
   RETVALUE( RFAILED );
}


/****************************************************************************/
/*    Path Management functional block                                      */
/****************************************************************************/

/*
*
*       Fun:   sbPmHBeatEnb
*
*       Desc:  This function is called when the user request that
*              heartbeat monitoring be enabled on a destination.
*
*       Ret:   Void
*
*       Notes:
*
*       File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC Void sbPmHBeatEnb
(
SbAddrCb *addrCb,
U16      intervalTime
)
#else
PUBLIC Void sbPmHBeatEnb(addrCb, intervalTime)
SbAddrCb *addrCb;
U16      intervalTime;
#endif
{
   U32 timeout;
   U32 tmpRand1;
   U32 tmpRand2;
   U32 tmpRand3;
   U32 tmpRand4;
   SbSctSapCb *sctSap;

   TRC2( sbPmHBeatEnb );

   SBDBGP( SB_DBGMASK_PM, ( sbGlobalCb.sbInit.prntBuf,
                            "sbPmHBeatEnb(addrCb, intervalTime(%d))\n",
                            intervalTime ) );

   sctSap = *(sbGlobalCb.sctSaps + addrCb->spId);

   if ( intervalTime == 0)
   {
      intervalTime = sctSap->sctSapCfg.reConfig.intervalTm;
   }

   addrCb->hBeatInt = intervalTime;
   addrCb->idle = TRUE;
   /* sb047: reset the heartbeat Ack flag */
   addrCb->hBeatSent = FALSE;
   addrCb->hBeatAck = FALSE;

   SB_STOP_TMR(&(addrCb->hBeatTmr));

   timeout = addrCb->hBeatInt;
   if ( timeout < addrCb->rto )
   {
      timeout = addrCb->rto;
   }
   sbRand32(SB_RAND_GEN, &tmpRand1);
   tmpRand2 = tmpRand1 & 0x7fff;
   tmpRand3 = tmpRand2 * addrCb->rto;
   tmpRand4 = tmpRand3 / 0xffff;
   timeout += tmpRand4;


   SBDBGP( SB_DBGMASK_PM, ( sbGlobalCb.sbInit.prntBuf,
                            "sbPmHBeatEnb: Starting timer for %ld ticks\nhBeatInt = %lu, rto = %lu, tmpRand1 = %lu, tmpRand2 = %lu, tmpRand3 = %lu, tmpRand4 = %lu",
                            (U32)timeout,  (U32)addrCb->hBeatInt, (U32)addrCb->rto, tmpRand1, tmpRand2, tmpRand3, tmpRand4) );

   SB_START_TMR( &(addrCb->hBeatTmr), addrCb, SB_TMR_HBEAT, (U16) timeout );
  

   RETVOID;
}


/*
*
*       Fun:   sbPmHBeatDis
*
*       Desc:  This function is is called when the service user would
*              like heartbeat monitoring to be disabled on a destination
*
*       Ret:   Void
*
*       Notes:
*
*       File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC Void sbPmHBeatDis
(
SbAddrCb *addrCb
)
#else
PUBLIC Void sbPmHBeatDis(addrCb)
SbAddrCb *addrCb;
#endif
{
   TRC2( sbPmHBeatDis );

   SBDBGP( SB_DBGMASK_PM, ( sbGlobalCb.sbInit.prntBuf,
                            "sbPmHBeatDis(addrCb)\n" ) );

   SB_STOP_TMR( &(addrCb->hBeatTmr) );

   RETVOID;
}

/*
*
*       Fun:   sbPmHBeatTO
*
*       Desc:  This function is called when the Heartbeat Timeout expires
*              This function needs to check if a heartbeat ack has been
*              received and send out the next heartbeat chunk to the peer.
*              It also needs to update the reachability of the destination.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes:
*
*       File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbPmHBeatTO
(
SbAddrCb *addrCb
)
#else
PUBLIC S16 sbPmHBeatTO(addrCb)
SbAddrCb *addrCb;
#endif
{
   SbSctAssocCb *assocCb;
   SbSctSapCb *sctSap;
   U8 result;
   U32 timeout;
   U32 tmpRand1;
   U32 tmpRand2;
   U32 tmpRand3;
   U32 tmpRand4;
   S16 err;
   /* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
   S8  ipv6Addr1[SB_IPV6STR_SIZE];
   U8  *tempIpv6Addr;
#endif
   /* sb047: the heartbeat not Acked */
   Bool sendHBeat = FALSE;

   TRC2( sbPmHBeatTO );

#if ( ERRCLASS & ERRCLS_DEBUG )
   if (addrCb == (SbAddrCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB143, (ErrVal) 0,
                  "sbPmHBeatTO: addrCb is NULL" );
      RETVALUE( RFAILED );
   }
#endif /* ERRCLS_DEBUG */
   if(addrCb->addr.type == CM_NETADDR_IPV4)
   {
      SBDBGP( SB_DBGMASK_PM, ( sbGlobalCb.sbInit.prntBuf,
                               "sbPmHBeatTO(addrCb.addr.ipv4(%lu))\n",
                               addrCb->addr.u.ipv4NetAddr) );
   }
   /* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
    if(addrCb->addr.type == CM_NETADDR_IPV6)
    {
    tempIpv6Addr = addrCb->addr.u.ipv6NetAddr;
    SB_CPY_IPV6ADSTR(ipv6Addr1, tempIpv6Addr)
   SBDBGP( SB_DBGMASK_PM, ( sbGlobalCb.sbInit.prntBuf,
                            "sbPmHBeatTO(addrCb.addr.ipv6(%s))\n",
                            ipv6Addr1) );
    }
#endif

   assocCb = *( sbGlobalCb.assocCb + addrCb->spAssocId );

#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB144, (ErrVal) addrCb->spAssocId,
                  "sbPmHBeatTO: Can not find corresponding association" );
      RETVALUE( RFAILED );
   }
#endif /* ERRCLS_DEBUG */

   if ( assocCb->assocState != SB_ST_ESTABLISHED )
   {
      SBDBGP(SB_DBGMASK_AS, (sbGlobalCb.sbInit.prntBuf,
             "sbPmHBeatTO: not in SB_ST_ESTABLISHED state"));
             RETVALUE( ROK );
   }

   /* sb069.102 fetch hbeatInt from sctsap reconfiguration if changed */ 
   sctSap = *(sbGlobalCb.sctSaps + assocCb->spId);

   /* sb047: the heartbeat not Acked */
   if ( (addrCb->hBeatSent == TRUE) && (addrCb->hBeatAck == FALSE) )
   {
      if ( addrCb->active == SCT_PATH_ACTIVE )
      {
         if ( addrCb->rtxCnt > 0 )
         {
            addrCb->rto *= 2;
         }

         if (addrCb->rto > sctSap->sctSapCfg.reConfig.rtoMax)
         {
            addrCb->rto = sctSap->sctSapCfg.reConfig.rtoMax;
         }

         err = sbPmNeedResend( assocCb, addrCb, &result );

#if ( ERRCLASS & ERRCLS_DEBUG )
         if ( err != ROK )
         {
            SBLOGERROR( ERRCLS_DEBUG, ESB145, (ErrVal) err,
                        "sbPmHBeatTO: Failed sbPmNeedResend" );
            RETVALUE( RFAILED );
         }
#endif /* ERRCLS_DEBUG */

         if ( result == SB_RESULT_ASSOC_INACTIVE )
         {
            SBDBGP( SB_DBGMASK_PM, ( sbGlobalCb.sbInit.prntBuf,
                    "sbPmHBeatTO: association is inactive\n" ) );
            RETVALUE( ROK );
         }
      }
  
      sendHBeat = TRUE;
   }
   /* sb069.102 fetch hbeatInt from sctsap reconfiguration if changed */
   if ( addrCb->hBeatInt != sctSap->sctSapCfg.reConfig.intervalTm )
   {
        addrCb->hBeatInt = sctSap->sctSapCfg.reConfig.intervalTm;
   }


   /* sb055: HB logic change, failure case should retry using rto */
   if(sendHBeat)
   {
      timeout = addrCb->rto;
   }
   else
   {
      timeout = addrCb->hBeatInt;
   }
   if ( timeout < addrCb->rto ) timeout = addrCb->rto;
   sbRand32(SB_RAND_GEN, &tmpRand1);
   tmpRand2 = tmpRand1 & 0x7fff;
   tmpRand3 = tmpRand2 * addrCb->rto;
   tmpRand4 = tmpRand3 / 0xffff;
   timeout += tmpRand4;

   SBDBGP( SB_DBGMASK_PM, ( sbGlobalCb.sbInit.prntBuf,
                            "sbPmHBeatTO: Starting timer for %ld ticks\nhBeatInt = %lu, rto = %lu, tmpRand1 = %lu, tmpRand2 = %lu, tmpRand3 = %lu, tmpRand4 = %lu",
                            (U32)timeout,  (U32)addrCb->hBeatInt, (U32)addrCb->rto, tmpRand1, tmpRand2, tmpRand3, tmpRand4) );

   if ( addrCb->hBeatTmr.tmrEvnt != TMR_NONE )
   {
      SB_STOP_TMR( &(addrCb->hBeatTmr) );
   }

   SB_START_TMR( &(addrCb->hBeatTmr), addrCb, SB_TMR_HBEAT, (U16)timeout );

   if ( sendHBeat == TRUE || addrCb->idle == TRUE )
   {
      err = sbPmSendHBeat( assocCb, addrCb );

#if ( ERRCLASS & ERRCLS_DEBUG )
      if ( err != ROK )
      {
         SBLOGERROR( ERRCLS_DEBUG, ESB146, (ErrVal) err,
                     "sbPmTimeoutHBeat: Failed sbPmSendHBeat" );
         RETVALUE( RFAILED );
      }
#endif /* ERRCLS_DEBUG */

      addrCb->hBeatSent = TRUE;
      addrCb->hBeatAck = FALSE;
   }
 
   if ( addrCb->idle == FALSE)
   {
      addrCb->idle = TRUE;
   }

   RETVALUE( ROK );
}

/*
*
*       Fun:   sbPmNeedResend
*
*       Desc:  This function is called when the Heartbeat Timeout expires
*              It needs to update the reachability status if no heartbeat
*              ack has been received since the last heartbeat was sent
*
*       Ret:   ROK
*              RFAILED
*
*       Notes:
*
*       File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbPmNeedResend
(
SbSctAssocCb *assocCb,
SbAddrCb *addrCb,
U8 *result
)
#else
PUBLIC S16 sbPmNeedResend(assocCb, addrCb, result)
SbSctAssocCb *assocCb;
SbAddrCb *addrCb;
U8 *result;
#endif
{
   SctRtrvInfo rtrvInfo;
   SbSctSapCb *sctSap;
   CmLListCp *l;
   CmLList *n;
   U16 i;
   Bool allAddrDown=FALSE;
   /* sb028.102 : allow freeze timer to be zero */
   UConnId tempSuAssocId; 
   /* sb056.102 : Added - In case of primary dest address failure
                          try assoc on alternate dest addr of
                          address list
   */
   SbLocalAddrCb      *tmpAddr;
   S16                ret;

   TRC2( sbPmNeedResend );

   SBDBGP( SB_DBGMASK_PM, ( sbGlobalCb.sbInit.prntBuf,
                            "sbPmNeedResend(assocCb, addrCb, result(%d))\n",
                            *result ) );
   /* sb058.102 : Added to remove compilation warning */
   ret = ROK;

#if ( ERRCLASS & ERRCLS_DEBUG )

   if ( addrCb == (SbAddrCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG,
                  ESB147,
                  (ErrVal) 0,
                  "sbPmNeedResend(): addrCb is NULL" );

      RETVALUE( RFAILED );
   }

   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG,
                  ESB148,
                  (ErrVal) 0,
                  "sbPmNeedResend(): assocCb is NULL" );

      RETVALUE( RFAILED );
   }
/* sb068.102  removed SB_GET_NEXT_LOCAL_CONN() call from ERRCLS_DEBUG */
#endif /* ERRCLS_DEBUG */

/* sb056.102 : Added - In case of primary dest address failure
                       try assoc on alternate dest addr of
                       address list
*/
   /* get next source address */
   SB_GET_NEXT_LOCAL_CONN(assocCb->endpId, addrCb->localConn, tmpAddr, ret);
   if(ret != RFAILED)
   {
      addrCb->localConn = tmpAddr;
   }

/* sb068.102  removed SB_GET_NEXT_LOCAL_CONN() call from ERRCLS_DEBUG */

#if ( ERRCLASS & ERRCLS_DEBUG )

   if ( result == (U8 *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG,
                  ESB149,
                  (ErrVal) 0,
                  "sbPmNeedResend(): result is NULL" );

      RETVALUE( RFAILED );
   }

#endif /* ERRCLS_DEBUG */

   sctSap = *(sbGlobalCb.sctSaps + addrCb->spId);

   addrCb->rtxCnt++;
   assocCb->sbAcCb.rtxCnt++;

   *result = SB_RESULT_NOT_APPL;

   if ( addrCb->rtxCnt > sbGlobalCb.genCfg.reConfig.maxPathReTx )
   {
      addrCb->active = SCT_PATH_INACTIVE;

      SbUiSctStaInd( &(sctSap->sctPst),
                     sctSap->suId,
                     assocCb->suAssocId,
                     assocCb->spAssocId,
                     &(addrCb->addr),
                     SCT_STATUS_NET_DOWN,
                     SCT_CAUSE_NOT_APPL,
                     (Buffer *)NULLP );

      *result = SB_RESULT_PATH_INACTIVE;

      /* sb002.12 - If all the destination addresses in an association are
       * marked inactive then mark association also as down irrespective of
       * the maxAssocReTx counter. */
      l = &(assocCb->sbAcCb.addrLst); 
      n = cmLListFirst(l);

      for (i = 0; i < cmLListLen(l); i++)
      {
          SbAddrCb *tmpAddrCb; 

          tmpAddrCb = (SbAddrCb *)n->node;
          if ((tmpAddrCb->active == SCT_PATH_ACTIVE) && (tmpAddrCb->sndTo == TRUE))
          {
             allAddrDown = FALSE;
             break; /* Come out of the loop */
          }
          /* If we reach here then there is no active address left, so 
           * increment the RtxCounter */
           /*assocCb->sbAcCb.rtxCnt++;*/
           n = n->next;
           allAddrDown = TRUE;
      }
   }

   /* sb014.102 - Terminate association when all addresses are down */
   if ((allAddrDown)||(assocCb->sbAcCb.rtxCnt > sbGlobalCb.genCfg.reConfig.maxAssocReTx ))
   {
      rtrvInfo.lastAckTsn = assocCb->sbAcCb.cumTsn;
      rtrvInfo.lastSentTsn = assocCb->sbAcCb.nextLocalTsn - 1;
      rtrvInfo.nmbUnsentDgms = sbDbQPackets(assocCb, SB_DB_TSNWAITINGQ);
      rtrvInfo.nmbUnackDgms = sbDbQPackets(assocCb, SB_DB_CONGESTIONQ);
      rtrvInfo.nmbUndelDgms = sbDbQPackets(assocCb, SB_DB_SEQUENCEDQ) +
                                           sbDbQPackets(assocCb,
                                                        SB_DB_ASSEMBLYQ);

      if ( assocCb->sbAsCb.timer.tmrEvnt != TMR_NONE )
      {
         SB_STOP_TMR( &(assocCb->sbAsCb.timer) );
      }
      /* sb028.102 : allow freeze timer to be zero */
      if(sctSap->sctSapCfg.reConfig.freezeTm > 0 )
      {
         SB_START_TMR( &(assocCb->sbAsCb.timer), assocCb, SB_TMR_FREEZE,
                    sctSap->sctSapCfg.reConfig.freezeTm );
      }

      assocCb->assocState = SB_ST_CLOSED;
      tempSuAssocId = assocCb->suAssocId;

      if(allAddrDown != TRUE)
      {
   /* sb021.102: Modification for TOS parameter */
#ifdef SCT3
        sbAsSendAbort( assocCb->peerInitTag, assocCb->localConn,
                       sbPmGetBestAddr(assocCb, (CmNetAddr *)NULLP),
                       assocCb->localPort, assocCb->peerPort, FALSE, assocCb->tos);
#else
        sbAsSendAbort( assocCb->peerInitTag, assocCb->localConn,
                       sbPmGetBestAddr(assocCb, (CmNetAddr *)NULLP),
                       assocCb->localPort, assocCb->peerPort, FALSE);
#endif /* SCT3 */
      }

      if (sctSap->sctSapCfg.reConfig.freezeTm == 0 ) 
      {
         (Void) sbAsAbortAssoc(assocCb, FALSE);
         sbGlobalCb.assocCb[assocCb->spAssocId] = (SbSctAssocCb *) NULLP;
         SB_FREE (sizeof(SbSctAssocCb), assocCb); 
      }

      /* sb046: notify user the rtrvInfo */
      SbUiSctTermInd( &(sctSap->sctPst), sctSap->suId, tempSuAssocId,
                   SCT_ASSOCID_SU, SCT_STATUS_COMM_LOST,
                   SCT_CAUSE_NOT_APPL, &rtrvInfo );

      *result = SB_RESULT_ASSOC_INACTIVE;
   }

   RETVALUE( ROK );
}


/*
*
*       Fun:   sbPmSendHBeat
*
*       Desc:  This function is called when the Heartbeat chunk needs to be
*              send to a peer to monitor the reachability of the peer on this
*              particular specified address.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes:
*
*       File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbPmSendHBeat
(
SbSctAssocCb *assocCb,
SbAddrCb *addrCb
)
#else
PUBLIC S16 sbPmSendHBeat(assocCb, addrCb)
SbSctAssocCb *assocCb;
SbAddrCb *addrCb;
#endif
{
   U32 tmptime;
   Buffer *mBuf;
   CmNetAddr *addr;
   U16 msgLen;
   U32 i;
   U8 tmpU8;
   S16 err;
   U8 pkArray[64];
   U8 idx;

   TRC2( sbPmSendHBeat );

   SBDBGP( SB_DBGMASK_PM, ( sbGlobalCb.sbInit.prntBuf,
                            "sbPmSendHBeat(assocCb, addrCb)\n" ) );

#if ( ERRCLASS & ERRCLS_DEBUG )

   if ( addrCb == (SbAddrCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG,
                  ESB150,
                  (ErrVal) 0,
                  "sbPmSendHBeat(): addrCb is NULL" );

      RETVALUE( RFAILED );
   }

   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG,
                  ESB151,
                  (ErrVal) 0,
                  "sbPmSendHBeat(): assocCb is NULL" );

      RETVALUE( RFAILED );
   }

#endif /* ERRCLS_DEBUG */

   idx = 0;

   SB_GETMSG( mBuf, err );
   if (err != ROK)
   {
      SBDBGP( SB_DBGMASK_PM, ( sbGlobalCb.sbInit.prntBuf,
              "sbPmSendHBeat: could not get mBuf for HBEAT chunk\n" ) );
      RETVALUE( RFAILED );
   }

   addr = &(addrCb->addr);

   msgLen = 8;

   if ( addr->type == CM_NETADDR_IPV4 )
   {
      SB_PKU32( addr->u.ipv4NetAddr );
      SB_PKU16( 0x0008 );
      SB_PKU16( SB_ID_PAR_IPV4 );

      msgLen += 8;
   }

   if ( addr->type == CM_NETADDR_IPV6 )
   {
      for ( i = 0; i < CM_IPV6ADDR_SIZE; i++ )
      {
         tmpU8 = addr->u.ipv6NetAddr[15 - i];
         SB_PKU8(tmpU8);
      }

      SB_PKU16(0x0014);
      SB_PKU16(SB_ID_PAR_IPV6);

      msgLen += 20;
   }

   tmptime = sbGlobalCb.sbTqCp.nxtEnt;

   SB_PKU32(tmptime);
   SB_PKU16(msgLen);
   SB_PKU16(0x0001);

   msgLen += 4;

   SB_PKU16(msgLen);
   SB_PKU8(0x0);
   SB_PKU8(SB_ID_HBEAT);

   err = SAddPreMsgMult(&pkArray[0], idx, mBuf);

#if (ERRCLASS & ERRCLS_ADD_RES)

   if (err != ROK)
   {
      SBLOGERROR( ERRCLS_ADD_RES,
                  ESB152,
                  (ErrVal) err,
                  "sbPmSendHBeat(): Error in SAddPreMsgMult function" );
      SB_PUTMSG(mBuf);

   }

#endif /* ERRCLS_ADD_RES */

   err = sbAsAddHead(assocCb->localPort, assocCb->peerPort,
               assocCb->peerInitTag, mBuf);

#if ( ERRCLASS & ERRCLS_ADD_RES )
   if ( err != ROK )
   {
      SBDBGP(SB_DBGMASK_AS, (sbGlobalCb.sbInit.prntBuf,
             "sbPmSendHBeat: could not add header to HBEAT"));
      RETVALUE(RFAILED);
   }
#endif


   /* sb021.102: Modification for TOS parameter */
#ifdef SCT3
   err = sbLiSend(addrCb->localConn, &(addrCb->addr), mBuf, FALSE
                    ,assocCb->tos, NULLP);  /* NULLP Added - sb023.102 */
#else
   err = sbLiSend(addrCb->localConn, &(addrCb->addr), mBuf, FALSE, NULLP);
                                    /* NULLP Added - sb023.102 */
#endif /* SCT3 */

   if (err != ROK )
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB153, (ErrVal) err,
                  "sbPmSendHBeat: error in sbLiSend" );
      RETVALUE( RFAILED );
   }

/* sb018.102 Heartbeat statistics added */
#ifdef LSB2
   sbGlobalCb.genSts.sbChunkSts.noHBeatTx++;
   sbGlobalCb.tSaps[assocCb->localConn->suId]->tSts.sbChunkSts.noHBeatTx++;
#endif

   RETVALUE( ROK );
}


/*
*
*       Fun:   sbPmRcvHBeatAck
*
*       Desc:  This function is called when the Heartbeat-Ack chunk has been
*              received from the peer. It needs to update the reachability status
*              of this path, as well as the rto and rtt times.
*
*       Ret:   Success:              ROK
*              Failure:              RFAILED
*
*       Notes:
*
*       File:  sb_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 sbPmRcvHBeatAck
(
SbSctAssocCb *assocCb,
Buffer *mBuf
)
#else
PUBLIC S16 sbPmRcvHBeatAck(assocCb, mBuf)
SbSctAssocCb *assocCb;
Buffer *mBuf;
#endif
{
   CmNetAddr addr;
   SbAddrCb *addrCb;
   U8 tmpU8 = 0;
   U16 tmpU16 = 0;
   U32 tmpU32 = 0;
   U32 msgTime;
   U32 currTime;
   S32 difTime;
   U16 msgType;
   U16 msgLen;
   U32 i;
   SbSctSapCb *sctSap;
   S16 err;
   U8 pkArray[12];
   U8 idx;
   S16 ret;

   TRC2( sbPmRcvHBeatAck );

  /* sb001.12 : Addition - Memory intialisation done */
   SB_ZERO(&addr, sizeof(CmNetAddr));

#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( mBuf == (Buffer *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG,
                  ESB154,
                  (ErrVal) 0,
                  "sbPmRcvHBeatAck: Message Buffer is NULL" );

      RETVALUE( RFAILED );
   }

   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG,
                  ESB155,
                  (ErrVal) 0,
                  "sbPmRcvHBeatAck(): assocCb is NULL" );

      SB_PUTMSG(mBuf);

      RETVALUE( RFAILED );
   }
#endif /* ERRCLS_DEBUG */

   sctSap = *(sbGlobalCb.sctSaps + assocCb->spId);

   ret = SRemPreMsgMult(&pkArray[0], 12, mBuf);
   /* sb051.102: Checking for error conditions */
   if (ret != ROK)
   {
      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
               "sbPmRcvHBeatAck: PreMsgMult Failed for mBuf\n"));
      SB_PUTMSG(mBuf);
      RETVALUE( RFAILED );
   }

   idx = 0;
   SB_UNPKU16( tmpU16 );
   SB_UNPKU16( tmpU16 );

   SB_UNPKU32( msgTime );
   currTime = sbGlobalCb.sbTqCp.nxtEnt;
   if ( currTime >= msgTime )
   {
      difTime = currTime - msgTime;
   }
   else
   {
      difTime = MAX16BIT - msgTime + currTime;
   }

   SB_UNPKU16( msgType );
   SB_UNPKU16( msgLen );

   if ( msgType == SB_ID_PAR_IPV4)
   {
      ret = SRemPreMsgMult(&pkArray[0], 4, mBuf);
      /* sb051.102: Checking for error conditions */
      if (ret != ROK)
      {
         SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                  "sbPmRcvHBeatAck: PreMsgMult Failed for mBuf\n"));
         SB_PUTMSG(mBuf);
         RETVALUE( RFAILED );
      }
      idx = 0;

      SB_UNPKU32( tmpU32 );

      addr.type = CM_NETADDR_IPV4;
      addr.u.ipv4NetAddr = tmpU32;
   }
   else if ( msgType == SB_ID_PAR_IPV6 )
   {
      ret = SRemPreMsgMult(&pkArray[0], 16, mBuf);
      /* sb051.102: Checking for error conditions */
      if (ret != ROK)
      {
         SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                  "sbPmRcvHBeatAck: PreMsgMult Failed for mBuf\n"));
         SB_PUTMSG(mBuf);
         RETVALUE( RFAILED );
      }
      idx = 0;

      addr.type = CM_NETADDR_IPV6;

      for ( i = 0; i < CM_IPV6ADDR_SIZE; i++ )
      {
         SB_UNPKU8( tmpU8 );
         addr.u.ipv6NetAddr[i] = tmpU8;
      }
   }

   addrCb = sbPmGetAddrCb(assocCb, &addr);

   if ( addrCb == (SbAddrCb *)NULLP )
   {
      SB_PUTMSG(mBuf);

      RETVALUE( RFAILED );
   }

   if ( difTime > addrCb->rto )
   {
      SB_PUTMSG(mBuf);

      RETVALUE( RFAILED );
   }

   addrCb->rtxCnt = 0;
   /* sb047: set the heartbeat Ack flag */
   addrCb->hBeatAck = TRUE;
   /* sb055: double HB time problem - 1 line removed*/
   assocCb->sbAcCb.rtxCnt = 0;

   if ( addrCb->active == SCT_PATH_INACTIVE )
   {
      addrCb->active = SCT_PATH_ACTIVE;
      SbUiSctStaInd( &(sctSap->sctPst),
                     sctSap->suId,
                     assocCb->suAssocId,
                     assocCb->spAssocId,
                     &(addrCb->addr),
                     SCT_STATUS_NET_UP,
                     SCT_CAUSE_NOT_APPL,
                     (Buffer *)NULLP );
   }

   err = sbPmCalcRto( assocCb, addrCb, (SctRTT)difTime );

#if ( ERRCLASS & ERRCLS_DEBUG )

   if ( err != ROK )
   {
      SBLOGERROR( ERRCLS_DEBUG,
                  ESB156,
                  (ErrVal) 0,
                  "sbPmRcvHBeatAck(): error in sbPmCalcRto" );

      SB_PUTMSG(mBuf);

      RETVALUE( RFAILED );
   }

#endif /* ERRCLS_DEBUG */

   SB_PUTMSG(mBuf);

   RETVALUE( ROK );
}

/*
*
*       Fun:   sbPmCalcRto
*
*       Desc:  This function is called when the Heartbeat-Ack chunk has been
*              received from the peer and the rto and rtt calculations need
*              to be performed.
*
*       Ret:   ROK
*              RFAILED (optional under ERRCLS_DEBUG)
*
*       Notes:
*
*       File:  sb_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 sbPmCalcRto
(
SbSctAssocCb *assocCb,
SbAddrCb *addrCb,
SctRTT newRtt
)
#else
PUBLIC S16 sbPmCalcRto(assocCb, addrCb, newRtt)
SbSctAssocCb *assocCb;
SbAddrCb *addrCb;
SctRTT newRtt;
#endif
{
   U32 tmpU32;
   S32 tmpS32;
   SbSctSapCb *sctSap;

   TRC2( sbPmCalcRto );

   SBDBGP( SB_DBGMASK_PM, ( sbGlobalCb.sbInit.prntBuf,
                            "sbPmCalcRto(assocCb, addrCb, newRtt(%d))\n",
                            newRtt ) );

#if ( ERRCLASS & ERRCLS_DEBUG )

   if ( addrCb == (SbAddrCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG,
                  ESB157,
                  (ErrVal) 0,
                  "sbPmCalcRto(): addrCb is NULL" );

      RETVALUE( RFAILED );
   }

   if (assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG,
                  ESB158,
                  (ErrVal) 0,
                  "sbPmCalcRto(): assocCb is NULL" );

      RETVALUE( RFAILED );
   }

#endif /* ERRCLS_DEBUG */

   sctSap = *(sbGlobalCb.sctSaps + assocCb->spId);

   /* Computing rttVar */
   tmpS32 = addrCb->srtt - newRtt;
   if ( tmpS32 < 0 )
   {
      tmpS32 = -tmpS32;
   }
   tmpU32 = (100 - sbGlobalCb.genCfg.reConfig.beta) *
            addrCb->rttVar + sbGlobalCb.genCfg.reConfig.beta * tmpS32;
   tmpU32 /= 100;
   if ( tmpU32 <= 0)
   {
      tmpU32 = 1;
   }
   addrCb->rttVar = (SctRTT)tmpU32;

   /* Computing srtt */
   tmpU32 = (100 - sbGlobalCb.genCfg.reConfig.alpha) *
            addrCb->srtt + sbGlobalCb.genCfg.reConfig.alpha * newRtt;
   tmpU32 /= 100;
   addrCb->srtt = (SctRTT)tmpU32;

   /* Computing RTO */
   addrCb->rto = (U16)(addrCb->srtt + 4 * addrCb->rttVar);
   if ( addrCb->rto < sctSap->sctSapCfg.reConfig.rtoMin )
   {
      addrCb->rto = sctSap->sctSapCfg.reConfig.rtoMin;
   }
   if ( addrCb->rto > sctSap->sctSapCfg.reConfig.rtoMax )
   {
      addrCb->rto = sctSap->sctSapCfg.reConfig.rtoMax;
   }

   SBDBGP( SB_DBGMASK_PM, ( sbGlobalCb.sbInit.prntBuf,
           "sbPmCalcRto(): srtt = %d, varRtt = %d, rto = %d\n",
           addrCb->srtt,addrCb->rttVar, addrCb->rto ) );

   RETVALUE( ROK );
}

/*
*
*       Fun:   sbPmRcvHBeat
*
*       Desc:  This function is called when the Heartbeat chunk has been
*              received from the peer. It needs to reply to the peer with
*              a Heartbeat-Ack chunk.
*
*       Ret:   Success:              ROK
*              Failure:              RFAILED
*
*       Notes:
*
*       File:  sb_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 sbPmRcvHBeat
(
SbSctAssocCb *assocCb,
CmNetAddr *src,
MsgLen   msgLen,
Buffer *mBuf
)
#else
PUBLIC S16 sbPmRcvHBeat(assocCb, src, msgLen, mBuf)
SbSctAssocCb *assocCb;
CmNetAddr *src;
MsgLen   msgLen;
Buffer *mBuf;
#endif
{
   U16 align;
   S16 err;
   MsgLen bufLen;
   SbSctSapCb *sctSap;
   U8 pkArray[8];
   U8 idx;
   /* sb020.102: for packing 0x0 bits */
   U8 i;

   TRC2( sbPmRcvHBeat )

#if ( ERRCLASS & ERRCLS_DEBUG )

   if ( mBuf == (Buffer *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG,
                  ESB159,
                  (ErrVal) 0,
                  "sbPmRcvHBeat(): Message Buffer is NULL" );

      RETVALUE( RFAILED );
   }

   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG,
                  ESB160,
                  (ErrVal) 0,
                  "sbPmRcvHBeat(): assocCb is NULL" );

      SB_PUTMSG(mBuf);

      RETVALUE( RFAILED );
   }

   if ( src == (CmNetAddr *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG,
                  ESB161,
                  (ErrVal) 0,
                  "sbPmRcvHBeat(): src address is NULL" );

      SB_PUTMSG(mBuf);

      RETVALUE( RFAILED );
   }

   if ( src->type == CM_NETADDR_NOTPRSNT )
   {
      SBLOGERROR( ERRCLS_DEBUG,
                  ESB162,
                  (ErrVal) 0,
                  "sbPmRcvHBeat(): src address is CM_NETADDR_NOTPRSNT" );

      SB_PUTMSG(mBuf);

      RETVALUE( RFAILED );
   }


#endif /* ERRCLS_DEBUG */

   sctSap = *(sbGlobalCb.sctSaps + assocCb->spId);

   /* sb051.102: Checking the error for SSI function call */
   err = SFndLenMsg( mBuf, &bufLen );
   if(err != ROK) 
   {
      SBDBGP( SB_DBGMASK_PM, ( sbGlobalCb.sbInit.prntBuf,
     	  "sbPmRcvHBeat: Could not get the length of the buffer\n"));
      SB_PUTMSG( mBuf );
      RETVALUE( RFAILED );
   }

   if ( (msgLen % 4) != 0 )
   {
      align = (U16)(4 - (msgLen % 4));
   }
   else
   {
      align = 0;
   }

   /* sb020.102: removing align */
   if ( msgLen != bufLen )
   {
      SBDBGP( SB_DBGMASK_PM, ( sbGlobalCb.sbInit.prntBuf,
              "sbPmRcvHBeat: HBEAT length did not add up" ) );
      SB_PUTMSG(mBuf);

      RETVALUE(RFAILED);
   }

   /* pack the length back on */
   msgLen += 4;
   idx = 0;

   SB_PKU16( msgLen );
   SB_PKU8( 0x00 );
   SB_PKU8( SB_ID_HBEATACK );

   err = SAddPreMsgMult(&pkArray[0], idx, mBuf);
   
   /* sb020.102: Adding 0 bytes to make it multiple of 4 */
   for (i=0; i< align; i++)
   {
      SB_PKU8( 0x00 );
   }

#if ( ERRCLASS & ERRCLS_ADD_RES )
      if ( err != ROK )
      {
         SB_PUTMSG( mBuf );

         SBLOGERROR( ERRCLS_ADD_RES, ESB163, (ErrVal) err,
                     "sbPmRcvHBeat: Error in SAddPreMsgMult function" );
         RETVALUE( RFAILED );
      }
#endif /* ERRCLS_ADD_RES */

   err = sbAsAddHead( assocCb->localPort, assocCb->peerPort,
                      assocCb->peerInitTag, mBuf );

#if ( ERRCLASS & ERRCLS_ADD_RES )
   if ( err != ROK )
   {
      SBDBGP(SB_DBGMASK_PM, (sbGlobalCb.sbInit.prntBuf,
             "sbPmRcvHBeat: could not add header to HBEAT ACK\n"));
      RETVALUE(RFAILED);
   }
#endif

   /* sb021.102: Modification for TOS parameter */
#ifdef SCT3
   err = sbLiSend( assocCb->localConn, src, mBuf, FALSE ,assocCb->tos, NULLP);
                                    /* NULLP Added - sb023.102 */
#else
   err = sbLiSend( assocCb->localConn, src, mBuf, FALSE, NULLP);
                                    /* NULLP Added - sb023.102 */
#endif /* SCT3 */

#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( err != ROK )
   {
      SBDBGP(SB_DBGMASK_PM, (sbGlobalCb.sbInit.prntBuf,
             "sbPmRcvHBeat: could not send HBEAT ACK chunk\n"));
      RETVALUE( RFAILED );
   }
#endif

/* sb018.102 Heartbeat statistics added */
#ifdef LSB2
   sbGlobalCb.genSts.sbChunkSts.noHBAckTx++;
   sbGlobalCb.tSaps[assocCb->localConn->suId]->tSts.sbChunkSts.noHBAckTx++;
#endif
 
   RETVALUE( ROK );
}

/*
*
*       Fun:   sbPmGetBestAddr
*
*       Desc:  This function is called to get the Network address of the
*              most suitable destination address for this association.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes:
*
*       File:  sb_bdy2.c
*
*/
#ifdef ANSI
PUBLIC CmNetAddr *sbPmGetBestAddr
(
SbSctAssocCb *assocCb,
CmNetAddr *addr
)
#else
PUBLIC CmNetAddr *sbPmGetBestAddr(assocCb, addr)
SbSctAssocCb *assocCb;
CmNetAddr *addr;
#endif
{
   SbAddrCb *addrCb;

   TRC2( sbPmGetBestAddr );

   SBDBGP( SB_DBGMASK_PM, ( sbGlobalCb.sbInit.prntBuf,
                            "sbPmGetBestAddr(assocCb, addr)\n" ) );

#if ( ERRCLASS & ERRCLS_DEBUG )

   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG,
                  ESB164,
                  (ErrVal) 0,
                  "sbPmGetBestAddr(): assocCb is NULL" );

      RETVALUE( (CmNetAddr *)NULLP );
   }

#endif /* ERRCLS_DEBUG */

   addrCb = sbPmGetBestAddrCb( assocCb, addr );

   if ( addrCb == (SbAddrCb *)NULLP )
   {
      RETVALUE( (CmNetAddr *)NULLP );
   }

   RETVALUE( &(addrCb->addr) );
}


/*
*
*       Fun:   sbPmGetBestAddrCb
*
*       Desc:  This function is called to get the SbAddrCb of the
*              most suitable destination address for this association.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes:
*
*       File:  sb_bdy2.c
*
*/
#ifdef ANSI
PUBLIC SbAddrCb *sbPmGetBestAddrCb
(
SbSctAssocCb *assocCb,
CmNetAddr *addr
)
#else
PUBLIC SbAddrCb *sbPmGetBestAddrCb(assocCb, addr)
SbSctAssocCb *assocCb;
CmNetAddr *addr;
#endif
{
   SbAddrCb *addrCb;
   CmLListCp *l;
   CmLList *n;
   U32 i;
   /* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
   S8   ipv6Addr1[SB_IPV6STR_SIZE];
   S8   ipv6Addr2[SB_IPV6STR_SIZE];
   S8   ipv6Addr3[SB_IPV6STR_SIZE];
   U8   *tempIpv6Addr;
#endif

   TRC2( sbPmGetBestAddrCb );

   SBDBGP( SB_DBGMASK_PM, ( sbGlobalCb.sbInit.prntBuf,
                            "sbPmGetBestAddrCb(assocCb, addr)\n" ) );

#if ( ERRCLASS & ERRCLS_DEBUG )

   if ( assocCb == (SbSctAssocCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_DEBUG,
                  ESB165,
                  (ErrVal) 0,
                  "sbPmGetBestAddrCb(): assocCb is NULL" );

      /* sb020.102: Returning NULLP if assocCb is NULLP */
      RETVALUE( (SbAddrCb *)NULLP );
   }

#endif /* ERRCLS_DEBUG */

   if ( addr != (CmNetAddr *)NULLP )
   {
      if (addr->type != CM_NETADDR_NOTPRSNT)
      {
         /* Check if the supplied address is the primary address */
         if ( cmMemcmp((U8 *) &(assocCb->sbAcCb.pri->addr),
                       (U8 *) addr, sizeof(CmNetAddr)) == 0 )
         {
            addrCb = assocCb->sbAcCb.pri;
            if ( (addrCb->active == SCT_PATH_ACTIVE) && (addrCb->sndTo == TRUE) )
            {
               RETVALUE( addrCb );
            }
         }
         else
         {
            l = &(assocCb->sbAcCb.addrLst);
            n = cmLListFirst(l);

            for ( i = 0; i < cmLListLen( l ); i++ )
            {
               addrCb = (SbAddrCb *)n->node;

               if ( cmMemcmp((U8 *)&(addrCb->addr),
                             (U8 *)addr, sizeof(CmNetAddr)) == 0 )
               {
                  if ( (addrCb->active == SCT_PATH_ACTIVE) &&
                       (addrCb->sndTo == TRUE) )
                  {
                     RETVALUE(addrCb);
                  }
               }
               n = cmLListNext(l);
            }
         }
      }
   }

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "sbPmGetBestAddrCb: not using the received address\n"));

   addrCb = assocCb->sbAcCb.pri;
   if ( (addrCb->active == SCT_PATH_ACTIVE) && (addrCb->sndTo == TRUE) )
   {
      RETVALUE( addrCb );
   }
   else
   {
      if(addrCb->addr.type == CM_NETADDR_IPV4)
      {
         SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                "sbPmGetBestAddrCb: primarry address(%lu) inactive or cannot be sendTo\n",
                addrCb->addr.u.ipv4NetAddr));
      }
   /* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
      if(addrCb->addr.type == CM_NETADDR_IPV6)
      {
          tempIpv6Addr = addrCb->addr.u.ipv6NetAddr;
          SB_CPY_IPV6ADSTR(ipv6Addr1, tempIpv6Addr)
         SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                "sbPmGetBestAddrCb: primarry address(%s) inactive or cannot be sendTo\n",
                ipv6Addr1));
      }
#endif
   }

   l = &(assocCb->sbAcCb.addrLst);
   n = cmLListFirst(l);

   for ( i = 0; i < cmLListLen(l); i++ )
   {
      addrCb = (SbAddrCb *)n->node;

      if ( (addrCb->active == SCT_PATH_ACTIVE) && (addrCb->sndTo == TRUE) )
      {
         RETVALUE( addrCb );
      }
      else
      {
         if(addrCb->addr.type == CM_NETADDR_IPV4)
         {
            SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                   "sbPmGetBestAddrCb: other address(%lu) inactive or cannot be sendTo\n",
                    addrCb->addr.u.ipv4NetAddr));
         }
   /* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
         if(addrCb->addr.type == CM_NETADDR_IPV6)
         {
             tempIpv6Addr = addrCb->addr.u.ipv6NetAddr;
             SB_CPY_IPV6ADSTR(ipv6Addr2, tempIpv6Addr)
            SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                   "sbPmGetBestAddrCb:other address(%s) inactive or cannot be sendTo\n",
                   ipv6Addr2));
         }
#endif
      }

      n = cmLListNext(l);
   }
   if(assocCb->sbAcCb.pri->addr.type == CM_NETADDR_IPV4)
   {
      SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
             "sbPmGetBestAddrCb: Nothing found, reverting to primart (%lu)\n",
              assocCb->sbAcCb.pri->addr.u.ipv4NetAddr));
   }
   /* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
   if(addrCb->addr.type == CM_NETADDR_IPV6)
   {
      tempIpv6Addr = assocCb->sbAcCb.pri->addr.u.ipv6NetAddr;
      SB_CPY_IPV6ADSTR(ipv6Addr3, tempIpv6Addr)
      SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
     "sbPmGetBestAddrCb: Nothing found, reverting to primart (%s)\n",
      ipv6Addr3));
   }
#endif
   RETVALUE( assocCb->sbAcCb.pri );
}

/*
*
*      Fun:   sbPmRcvSack
*
*      Desc:  RTO and RTT calculations for SACK reception
*
*      Ret:   none
*
*      Notes: This function is called after a SACK has arrived. If the
*             datagram being acknowledged has been resent then processing is
*             stopped. The time difference between when the datagram was sent
*             when the SACK arrived is used to update the RTO and RTT for the
*             specific destination.
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC Void sbPmRcvSack
(
SbSctAssocCb    *assocCb,            /* association on which to operate */
SbQueuedChunk   *chunk               /* chunk in congestion queue */
)
#else
PUBLIC Void sbPmRcvSack(assocCb, chunk)
SbSctAssocCb    *assocCb;            /* association on which to operate */
SbQueuedChunk   *chunk;              /* chunk in congestion queue */
#endif
{
   /* local parameters */
   S32          R;
   SbAddrCb    *addrCb;
   SctRTT       curTime;
   SbSctSapCb  *sctSap;
   SctRTT       alpha;
   SctRTT       beta;
   S32          var;

   TRC2(sbPmRcvSack)

   /* get SCT SAP */
   sctSap = sbGlobalCb.sctSaps[assocCb->spId];

   /* local copies of params */
   alpha = sbGlobalCb.genCfg.reConfig.alpha;
   beta  = sbGlobalCb.genCfg.reConfig.beta;

   /* get the destination address control block */
   addrCb = chunk->addrCb;

   SBDBGP(SB_DBGMASK_PM, (sbGlobalCb.sbInit.prntBuf,
          "sbPmRcvSack: tsn(%ld), chunk->rttInProg(%d), addr->rttInProg(%d), chunk->resendFlg(%d)\n",
          chunk->tsn, chunk->rttInProg, addrCb->rttInProg, chunk->resendFlg));

   if ( chunk->rttInProg == FALSE )
   {
      RETVOID;
   }

   chunk->rttInProg = FALSE;
   addrCb->rttInProg = FALSE;

   if ( chunk->resendFlg == TRUE )
   {
      RETVOID;
   }

   /* determine the current time */
   curTime = sbGlobalCb.sbTqCp.nxtEnt;

   /* determine R */
   if ( chunk->time <= curTime )
   {
      R = curTime - chunk->time;
   }
   else
   {
      R = SB_RTTMAX + curTime - chunk->time;
   }

   /* do stuff */
   if ( addrCb->srtt == 0 )
   {
      /* first RTT measurement */
      addrCb->srtt = (SctRTT) R;
      addrCb->rttVar = (U16)(((SctRTT) R) / 2);
      if ( addrCb->rttVar < 1 )
      {
         addrCb->rttVar = 1;
      }
   }
   else
   {
      var = addrCb->srtt - R;
      if (var < 0)
      {
         var = -var;
      }
      /* subsequent RTT measurement (alpha & beta are percentages) */
      addrCb->rttVar = (U16)(((100 - beta) * addrCb->rttVar + beta * var)/100);
      if ( addrCb->rttVar < 1 )
         addrCb->rttVar = 1;
      addrCb->srtt = (U16)(((100 - alpha) * addrCb->srtt + alpha * R)/100);
   }
   addrCb->rto = (U16)(addrCb->srtt + 4 * addrCb->rttVar);

   /* impose maximum and minimum constraints */
   if ( addrCb->rto < sctSap->sctSapCfg.reConfig.rtoMin )
   {
      addrCb->rto = sctSap->sctSapCfg.reConfig.rtoMin;
   }
   else if ( addrCb->rto > sctSap->sctSapCfg.reConfig.rtoMax )
   {
      addrCb->rto = sctSap->sctSapCfg.reConfig.rtoMax;
   }

   SBDBGP( SB_DBGMASK_PM, ( sbGlobalCb.sbInit.prntBuf,
           "sbPmRcvSack(): srtt = %d, varRtt = %d, rto = %d\n",
           addrCb->srtt,addrCb->rttVar, addrCb->rto ) );

   RETVOID;
}/* sbPmRcvSack() */

/*
*
*      Fun:   sbPmAddAddr
*
*      Desc:  Add a network address
*
*      Ret:   Success:           ROK
*             Failure:           RFAILED
*
*      Notes: This function adds a network address control block and inserts
*             it into the various arrays and hash lists. A pointer to the new
*             control block is returned. This pointer will be null on failure.
*             It is assumed the address has already been validated.
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC SbAddrCb *sbPmAddAddr
(
SbSctSapCb      *sctSap,             /* upper SCT SAP */
SbSctAssocCb    *assocCb,            /* association on which to operate */
CmNetAddr       *addr                /* network address to add */
)
#else
PUBLIC SbAddrCb *sbPmAddAddr(sctSap, assocCb, addr)
SbSctSapCb      *sctSap;             /* upper SCT SAP */
SbSctAssocCb    *assocCb;            /* association on which to operate */
CmNetAddr       *addr;               /* network address to add */
#endif
{
   /* local parameters */
   S16            ret;
   SbAddrCb      *addrCb;
   SbAssocMapCb  *assocMap;
   U16            mtu;
   CmLList       *n;
   /* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
   S8            ipv6Addr1[SB_IPV6STR_SIZE];
   S8            ipv6Addr2[SB_IPV6STR_SIZE];
   U8            *tempIpv6Addr;
#endif

   TRC2(sbPmAddAddr)
   if(addr->type == CM_NETADDR_IPV4)
   {
      SBDBGP(SB_DBGMASK_PM, (sbGlobalCb.sbInit.prntBuf,
             "sbPmAddAddr: suId(%d), endpId(%lX), spAssocId(%lX), suAssocId(%lX), addr.type(%d), addr.u.ipv4(%08lX)\n",
             sctSap->suId, assocCb->endpId, assocCb->spAssocId, assocCb->suAssocId, addr->type, addr->u.ipv4NetAddr));
   }
   /* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
   else if(addr->type == CM_NETADDR_IPV6)
   {
      tempIpv6Addr = addr->u.ipv6NetAddr;
      SB_CPY_IPV6ADSTR(ipv6Addr1, tempIpv6Addr)
      SBDBGP(SB_DBGMASK_PM, (sbGlobalCb.sbInit.prntBuf,
             "sbPmAddAddr: suId(%d), endpId(%lX), spAssocId(%lX), suAssocId(%lX), addr.type(%d), addr.u.ipv6(%s)\n",
             sctSap->suId, assocCb->endpId, assocCb->spAssocId, assocCb->suAssocId, addr->type, ipv6Addr1));
   }
#endif
   n = (CmLList *)NULLP;
  /* check if there is space for a new address */
   if ( sbGlobalCb.genSta.nmbPeerAddr >= sbGlobalCb.genCfg.maxNmbDstAddr )
   {
      SBDBGP(SB_DBGMASK_PM, (sbGlobalCb.sbInit.prntBuf,
             "sbPmAddAddr: configuration max reached CB\n"));
      RETVALUE((SbAddrCb *) NULLP);
   }

   /* sb004.12 -Addition : If that address already exist in the 
    * association control block then return that addrCb */
    addrCb = sbPmGetAddrCb(assocCb, (CmNetAddr *) addr);
    if ( addrCb != NULLP )
    {
     if(addr->type == CM_NETADDR_IPV4)
     {
        SBDBGP(SB_DBGMASK_PM, (sbGlobalCb.sbInit.prntBuf,
        "sbPmAddAddr: PeerAddr (%08lX) Already in AssocCb \n", addr->u.ipv4NetAddr));
     }
   /* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
     else if(addr->type == CM_NETADDR_IPV6)
     {
        tempIpv6Addr = addr->u.ipv6NetAddr;
        SB_CPY_IPV6ADSTR(ipv6Addr2, tempIpv6Addr)
        SBDBGP(SB_DBGMASK_PM, (sbGlobalCb.sbInit.prntBuf,
        "sbPmAddAddr: PeerAddr (%s) Already in AssocCb \n", ipv6Addr2));
     }
#endif
     RETVALUE((SbAddrCb *) addrCb);
    }

   /* create the address control block structure */
   SB_ALLOC(sizeof(SbAddrCb), addrCb, ret);
   if ( ret != ROK )
   {
      SBDBGP(SB_DBGMASK_PM, (sbGlobalCb.sbInit.prntBuf,
             "sbPmAddAddr: could not allocate new address CB\n"));
      RETVALUE((SbAddrCb *) NULLP);
   }

   /* create the new association map structure */
   SB_ALLOC(sizeof(SbAssocMapCb), assocMap, ret);
   if ( ret != ROK )
   {
      SB_FREE(sizeof(SbAddrCb), addrCb);
      SBDBGP(SB_DBGMASK_PM, (sbGlobalCb.sbInit.prntBuf,
             "sbPmAddAddr: could not allocate new association map CB\n"));
      RETVALUE((SbAddrCb *) NULLP);
   }

   /* fill in the default values */
   addrCb->spId         = assocCb->spId;
   addrCb->endpId       = assocCb->endpId;
   addrCb->spAssocId    = assocCb->spAssocId;

   /* Performance Change  - sb023.102 */
   if(sbGlobalCb.genCfg.performMtu == TRUE)
   {
     ret = sbMtuGetMtuCb(&(sbGlobalCb.mtuCp), addr, &addrCb->mtuIdx);
     if(ret != ROK)
     {
        SBDBGP(SB_DBGMASK_PM, (sbGlobalCb.sbInit.prntBuf,
               "sbPmAddAddr: Path MTU discovery failed\n"));
     }
   }
   else
   {
     addrCb->mtuIdx = 0xFFFF;
   }

   /* sb023.102  - Performance Fix, Instead of SB_QUERY_MTU, we will directly
    * get the mtu from the mtuIndex  in AddrCb */
   SB_GET_MTU(addrCb, mtu, ret);


#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( ret != ROK )
   {
      SBDBGP(SB_DBGMASK_PM, (sbGlobalCb.sbInit.prntBuf,
             "sbPmAddAddr: Path MTU discovery failed\n"));
      mtu = sbGlobalCb.genCfg.mtuInitial;
   }
#endif /* ERRCLS_DEBUG */

   addrCb->cwnd         = mtu;
   addrCb->bytesAcked   = 0;
   addrCb->ackCntr      = 0;
   addrCb->bytesOut     = 0;
   addrCb->ssthresh     = assocCb->sbAcCb.rwnd;
   addrCb->rtxCnt       = 0;
   addrCb->srtt         = 0;
   addrCb->rttVar       = 0;
   addrCb->rto          = sctSap->sctSapCfg.reConfig.rtoInitial;
   addrCb->hBeatInt     = sctSap->sctSapCfg.reConfig.intervalTm;
   addrCb->active       = SCT_PATH_ACTIVE;
   addrCb->sentSince    = FALSE;
   addrCb->resendInProg = FALSE;
/* sb056.102 : Modification - In case of primary dest address failure
                              try assoc on alternate dest addr of
                              address list
*/
   addrCb->sndTo        = TRUE;
   addrCb->rttInProg    = FALSE;
   addrCb->rcvFrom      = TRUE;
   SB_CPY_NADDR(&(addrCb->addr), addr);
   addrCb->port         = assocCb->peerPort;
   /* performance fix */
   addrCb->nmbRtxChunk=0;
   /* sb056.102 : added - In case of primary dest address failure
                          try assoc on alternate dest addr of
                          address list
   */
   SB_GET_LOCAL_CONN(assocCb->endpId, addrCb->localConn, ret);

   /* Initialize T3-rtx timer and heart beat timer */
   cmInitTimers(&(addrCb->t3rtx),1);
   cmInitTimers(&(addrCb->hBeatTmr),1);

   /* insert the CB into the global linked list */
   addrCb->lstEntry.node = (PTR)addrCb;
   (Void) cmLListAdd2Tail(&(assocCb->sbAcCb.addrLst), &(addrCb->lstEntry));

   /* if there is no prim. addr. on the assoc. then make this one it */
   if ( assocCb->sbAcCb.pri == (SbAddrCb *) NULLP )
   {
      assocCb->sbAcCb.pri = addrCb;
   }

   /* update the association map */
   /* sb001.12 : Updation  - Byte alignment change */
   SB_ZERO(&(assocMap->sbAssocEntry), sizeof(SbAssocMapEntry));
   SB_CPY_NADDR(&(assocMap->sbAssocEntry.peerAddr), addr);
   assocMap->sbAssocEntry.spEndpId  = assocCb->endpId;
   assocMap->sbAssocEntry.port      = assocCb->peerPort;
   assocMap->spId      = assocCb->spId;
   assocMap->spAssocId = assocCb->spAssocId;

   /* sb001.12: Updation - Byte alignment fix */
   ret = cmHashListInsert(&(sbGlobalCb.assocMapHl), (PTR) assocMap,
                          (U8 *) &(assocMap->sbAssocEntry), sizeof(SbAssocMapEntry));

#if (ERRCLASS & ERRCLS_DEBUG)
   /* hash insert failed */
   if ( ret != ROK )
   {
      SBDBGP(SB_DBGMASK_PM, (sbGlobalCb.sbInit.prntBuf,
             "sbPmAddAddr: could not insert assoc. map into hash list\n"));
      /* undo some stuff */

      n = cmLListLast(&(assocCb->sbAcCb.addrLst));
      cmLListDelFrm(&(assocCb->sbAcCb.addrLst), n);

      SB_FREE(sizeof(SbAddrCb), n->node);

      SB_FREE(sizeof(SbAssocMapCb), assocMap);

      RETVALUE((SbAddrCb *) NULLP);
   }
#endif /* (ERRCLASS & DEBUG) */

   sbGlobalCb.genSta.nmbPeerAddr++;
   RETVALUE(addrCb);
}/* sbPmAddAddr() */

/*
*
*      Fun:   sbPmSelNextAddr
*
*      Desc:  Select the next active address for a chunk.
*
*      Ret:   Success:        ROK
*             Failure:        RFAILED
*
*      Notes: This function selects the next available active path for a chunk.
*             If none is available then the original address is retained.
*             The function simply loops through the destination address
*             linked-list, once it reaches the end it loops back to the start.
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbPmSelNextAddr
(
SbSctAssocCb    *assocCb,            /* association on which to operate */
SbQueuedChunk   *chunk               /* chunk on which to operate */
)
#else
PUBLIC S16 sbPmSelNextAddr(assocCb, chunk)
SbSctAssocCb    *assocCb;            /* association on which to operate */
SbQueuedChunk   *chunk;              /* chunk on which to operate */
#endif
{
   /* local parameters */
   SbAddrCb      *addrCb;
   CmLListCp     *l;
   CmLList       *n;
   U32            i;

   TRC2(sbPmSelNextAddr)

   /* get the list of addresses */
   l = &(assocCb->sbAcCb.addrLst);

#if (ERRCLASS & ERRCLS_DEBUG)
   /* list is empty */
   if ( cmLListLen(l) == 0 )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB166, (ErrVal) 0,
                 "sbPmSelNextAddr: address Linked List empty");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_DEBUG */

   /* loop through the list until the current entry is found */
   n = cmLListFirst(l);
   addrCb = (SbAddrCb *) NULLP;
   for ( i = 0; i < cmLListLen(l); i++ )
   {
      addrCb = (SbAddrCb *) (n->node);
      if ( addrCb == chunk->addrCb )
      {
         /* previous entry found */
         break;
      }
      addrCb = (SbAddrCb *) NULLP;
      n = cmLListNext(l);
   }

#if (ERRCLASS & ERRCLS_DEBUG)
   /* check if no match was found */
   if ( addrCb == (SbAddrCb *) NULLP )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB167, (ErrVal) 0,
                 "sbPmSelNextAddr: chunk address not found in LList");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_DEBUG */

   /* select the next active and available address */
   for ( i = 0; i < cmLListLen(l); i++ )
   {
      n = cmLListNext(l);
      /* loop back to start if necessary */
      if ( n == NULLP )
      {
         n = cmLListFirst(l);
      }
      addrCb = (SbAddrCb *) (n->node);
      if ( (addrCb->active == SCT_PATH_ACTIVE) && (addrCb->sndTo == TRUE) )
      {
         /* success */
         chunk->addrCb = addrCb;
         RETVALUE(ROK);
      }
   }

   /* we shouldn't be here since if no match was found then the previous
    * address would have been reselected */
   RETVALUE(ROK);
}/* sbPmSelectNextAddr() */

/*
*
*      Fun:   sbPmCompNAddr
*
*      Desc:  Compare Network Addresses
*
*      Ret:   ROK
*             RFAILED
*
*      Notes: <none>
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbPmCompNAddr
(
CmNetAddr     *addr1,                  /* address to compare */
CmNetAddr     *addr2                   /* address to compare */
)
#else
PUBLIC S16 sbPmCompNAddr(addr1, addr2)
CmNetAddr     *addr1;                  /* address to compare */
CmNetAddr     *addr2;                  /* address to compare */
#endif
{
   /* local parameters */
   U8          i;

   TRC2(sbPmCompNAddr)

   if ( addr1->type != addr2->type )
   {
      RETVALUE(RFAILED);
   }

   if ( addr1->type == CM_NETADDR_IPV4 )
   {
      if ( addr1->u.ipv4NetAddr != addr2->u.ipv4NetAddr )
      {
         RETVALUE(RFAILED);
      }
   }
   else
   {
      for ( i = 0; i < CM_IPV6ADDR_SIZE; i++ )
      {
         if ( addr1->u.ipv6NetAddr[i] != addr2->u.ipv6NetAddr[i] )
         {
            RETVALUE(RFAILED);
         }
      }
   }

   RETVALUE(ROK);
}/* sbPmCompNAddr() */

/*
*
*      Fun:   sbPmGetAddrCb
*
*      Desc:  Search for Destination Transport Address
*
*      Ret:   SbAddrCb*
*
*      Notes: This function searches the address list on a specific
*             association for a specific Address Control Block using
*             the destination network address as the lookup field. No port
*             number is required since we are looking per association.
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC SbAddrCb *sbPmGetAddrCb
(
SbSctAssocCb  *assocCb,                 /* resolved association */
CmNetAddr     *address                  /* address to look for */
)
#else
PUBLIC SbAddrCb *sbPmGetAddrCb(assocCb, address)
SbSctAssocCb  *assocCb;                 /* resolved association */
CmNetAddr     *address;                 /* address to look for */
#endif
{
   /* local parameters */
   CmLList           *n;
   CmLListCp         *l;
   SbAddrCb          *addrCb;
   S16                ret;

   TRC2(sbPmGetAddrCb)

   /* default value */
   addrCb = (SbAddrCb *) NULLP;

   /* get the address list control point */
   l = &(assocCb->sbAcCb.addrLst);

   /* get the first DTA CB */
   n = cmLListFirst(l);

   /* loop through the list until we find a matching address */
   while ( n != NULLP )
   {
      addrCb = (SbAddrCb *) n->node;

      ret = sbPmCompNAddr(address, &(addrCb->addr));
      if ( ret == ROK )
      {
         RETVALUE( (SbAddrCb *)(n->node) );          /* success */
      }
      else
      {
         n = cmLListNext(l);                       /* try again */
         if ( n != NULLP )
         {
            addrCb = (SbAddrCb *) n->node;
         }
      }
   }

   /* if we reach here then no match was found */
   RETVALUE((SbAddrCb *) NULLP);
}/* sbPmGetAddrCb() */


/****************************************************************************/
/*    functions used with Chunk Multiplexing procedures                     */
/****************************************************************************/


   /* performance fix - This whole function is modified for incresing the 
    * performance of the SCTP layer */

/*
*
*      Fun:   sbCmChunkMux
*
*      Desc:  Chunk Multiplexing
*
*      Ret:   Success:                      ROK
*             Failure:                      RFAILED
*             Dyn Mem Resource Failure      ROUTRES
*
*      Notes: This function is called whenever DATA is required to be sent.
*             Multiple DATA chunks are multiplexed into a message of size MTU.
*             A SACK is prepended to the message.
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbCmChunkMux
(
SbSctAssocCb    *assocCb,        /* Association on which to work */
SbQueuedChunk   *chunk,           /* First chunk to send */
CmLList         *crntEntry       /* Current Entry In list */
)
#else
PUBLIC S16 sbCmChunkMux(assocCb, chunk, crntEntry)
SbSctAssocCb    *assocCb;        /* Association on which to work */
SbQueuedChunk   *chunk;          /* First chunk to send */
CmLList         *crntEntry;      /* Current Entry In list */
#endif
{
   /* local parameters */
   S16             ret;
   Buffer         *mBuf;
   Buffer         *sackBuf;
   Buffer         *nextBuf;
   MsgLen          msgLen;
   U16             mtu;
   U32             i=0;   /* sb001.12: Modification - warning removed */
   MsgLen          reqLen;
   MsgLen          tmpLen;
   SbQueuedChunk  *nextChunk;
   SbQueuedChunk  *lowChunk;
   CmLListCp       *l;
   SbAddrCb        *addrCb;
   U16             nmbData;
   Bool            sackSent;
   CmLList        *n;
   /* performance fix */
   CmLListCp  *l1;
   Bool firstChunk=FALSE;
   Bool continueFlg=TRUE;
   /* sb029.102 : changes for checking the sack address with data address */
   Bool bundleSackFlg=FALSE;
   /* sb027.102 : Fixes the core dump problem for sb023.102 */
   MsgLen sackBufLen;

   TRC2(sbCmChunkMux)

   SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
          "sbCmChunkMux(assocCb, chunk)\n"));

   /* default values */
   sackSent = FALSE;
   mBuf = (Buffer *) NULLP;
   sackBuf = (Buffer *) NULLP;
   nextBuf = (Buffer *) NULLP;
   nextChunk = (SbQueuedChunk *) NULLP;
   lowChunk = (SbQueuedChunk *) NULLP;
   addrCb = (SbAddrCb *) NULLP;
   nmbData = 1;

   /* pointer to address CB on which to send */
   addrCb = chunk->addrCb;

   /* check the buffer and window space - Bakeoff Change  */
   /* sb040.102: Do not check cwnd for Retransmission */
   if ( ((assocCb->sbAcCb.rwnd <= 0) || 
        (addrCb->bytesOut > addrCb->cwnd)) &&
        (addrCb->bytesOut > 0) && (chunk->resendFlg != TRUE))
   {
     SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf, \
       "sbCmChunkMux: rwnd(%ld) or cwnd(%ld) full, can't send more DATA,\
        addrCb.bytesOut(%ld)\n", assocCb->sbAcCb.rwnd, addrCb->cwnd, addrCb->bytesOut));
      /* sb064.102 - deleted call to free NULL mBuf */
      RETVALUE(RFAILED);
   }

   /* query MTU size */
   /* sb023.102  - Performance Fix, Instead of SB_QUERY_MTU, we will directly
    * get the mtu from the mtuIndex  in AddrCb */
   SB_GET_MTU(addrCb, mtu, ret);

#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( ret != ROK )
   {
      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmChunkMux: Path MTU discovery failed\n"));
      mtu = sbGlobalCb.genCfg.mtuInitial;
      /* sb030.102: Deduct the IP header size from mtu */
      mtu -= SB_IP_HEADER_SIZE;
   }
#endif /* ERRCLS_DEBUG */

   /* find out how much space is used for the first message */
   /* sb051.102: Checking the error for SSI function call */
   ret = SFndLenMsg(chunk->mBuf, &msgLen);
   if(ret != ROK) 
   {
      SBDBGP( SB_DBGMASK_CM, ( sbGlobalCb.sbInit.prntBuf,
     	  "sbCmChunkMux: Could not get the length of the buffer\n"));
      /* sb064.102 - deleted call to free NULL mBuf */
      RETVALUE( RFAILED );
   }

   /* Create chunk buffer */
   /* no need to SGetMsg since the SAddMsgRef does this for us
    * in sbCmMakeMsg */

   /* Pack the first chunk onto the message */
   ret = sbCmMakeMsg(chunk, &mBuf);
   if ( ret != ROK )
   {
      /* errors are already logged */
      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmChunkMux: could not build message)\n"));
      /* sb051.102: Free mBuf */
      SB_PUTMSG(mBuf);
      RETVALUE(ret);
   }

   /* restart T3-RTX timer if it is not running */
   if ( addrCb->t3rtx.tmrEvnt == TMR_NONE )
   {
      SB_START_TMR(&(addrCb->t3rtx), addrCb, SB_TMR_T3RTX, addrCb->rto);
   }

   /* update byte counters */
   assocCb->sbAcCb.bytesOut += msgLen;
   addrCb->bytesOut += msgLen;

   assocCb->sbAcCb.rwnd -= msgLen;
   if(assocCb->sbAcCb.rwnd < 0)
        assocCb->sbAcCb.rwnd = 0;

   /* RTT updates */
   if ( addrCb->rttInProg == FALSE )
   {
      addrCb->rttInProg = TRUE;
      chunk->rttInProg = TRUE;
   }
   else if (chunk->resendFlg == FALSE)
   {
      chunk->rttInProg = FALSE;
   }

   /* clear sendFlg */
   chunk->sendFlg = FALSE;

      /* Performance fix */

   if(chunk->resendFlg == TRUE)
   {
     if(addrCb->nmbRtxChunk > 0 )
      addrCb->nmbRtxChunk--;
   }

   if ( (assocCb->sbDbCb.newPkt != NULLP ) &&
        ((SbQueuedChunk *)((assocCb->sbDbCb.newPkt)->node) == chunk))
   {
     SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
            "sbCmChunkMux: New Chunk for Resend\n"));
     l = &(assocCb->sbDbCb.congestionQ);
     l->crnt = assocCb->sbDbCb.newPkt;
     assocCb->sbDbCb.newPkt = cmLListNext(l);
   }
   else
   {
      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmChunkMux: Retransmission Occuring \n"));
   }

   /* Pack a SACK into the message if there is enough space left */
   /* we don't pack a SACK if no data has been received on this
    * association yet */

   if (( assocCb->sbAcCb.firstDataRcvd == TRUE ) && (assocCb->sbAcCb.sinceSack > 0))
   {
        /* sb029.102 compare assocCb->sbAcCb.sackAddr and addrCb.addr, if both are same
           then only send SACK with Data, otherwise pending SACK will be sent
           to the peer after the timer expiry */
        if( assocCb->sbAcCb.sackAddr.type == addrCb->addr.type)
        {
           if(assocCb->sbAcCb.sackAddr.type == CM_NETADDR_IPV4 )
           {
              if(assocCb->sbAcCb.sackAddr.u.ipv4NetAddr == addrCb->addr.u.ipv4NetAddr)
              {
                 bundleSackFlg = TRUE;
              }
           }
           else if (assocCb->sbAcCb.sackAddr.type == CM_NETADDR_IPV6) /* IPV6 */
           {
              for (i = 0; i < CM_IPV6ADDR_SIZE; i++)
              {
                 if (assocCb->sbAcCb.sackAddr.u.ipv6NetAddr[i] != (addrCb->addr.u.ipv6NetAddr[i]))
                 {
                    bundleSackFlg = FALSE;
                    break;
                 }
                 else
                 {
                     bundleSackFlg = TRUE;
                 }
              }
           }
        } /* end of bundling check */

      if ( bundleSackFlg == TRUE)
      {
         SB_GETMSG(sackBuf, ret);
         if ( ret != ROK )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmChunkMux: could not get buffer for SACK\n"));
            /* sb051.102: free sackBuf as well */
            SB_PUTMSG(sackBuf);
            SB_PUTMSG(mBuf);
            RETVALUE(ROUTRES);
         }

         /* build SACK, it will know if there is enough space or not */
         /* sb023.102 -  The available length for SACK should include, message
          * length + data chunk header length + min data chunk size */
         ret = sbAcBuildSack(assocCb, (MsgLen)(mtu - (msgLen + SB_CHUNK_HEADER_SIZE + SB_DATA_MIN_SIZE)), sackBuf);
         if ( ret != ROK )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmChunkMux: could not build SACK\n"));
            SB_PUTMSG(mBuf);
            /* sb051.102: free sackBuf as well */
            SB_PUTMSG(sackBuf);
            RETVALUE(ret);
         }

         /* sb027.102 : Adding Buffersize length checking with mtu to fixes the core dump problem for sb023.102 */
         if ( (MsgLen)(mtu - (msgLen + SB_DATA_MIN_SIZE)) < (MsgLen) (SB_SACK_MIN_SIZE + SB_COMMON_HEADER_SIZE))
         {
            sackBuf = (Buffer *)NULLP;
         }
      
         if ( sackBuf != (Buffer *)NULLP)
         {
            /* sb051.102: Checking the error for SSI function call */
            ret = SFndLenMsg(sackBuf, &sackBufLen);
            if(ret != ROK) 
            {
              SBDBGP( SB_DBGMASK_CM, ( sbGlobalCb.sbInit.prntBuf,
             	  "sbCmChunkMux: Could not get the length of the buffer\n"));
               SB_PUTMSG(mBuf);
               SB_PUTMSG(sackBuf);
               RETVALUE( RFAILED );
            }
            if((sackBufLen > 0) && (sackBufLen+msgLen+SB_COMMON_HEADER_SIZE) < mtu)
            {
               /* Pack SACK in front of message */
               SCatMsg(mBuf, sackBuf, M2M1);
               SB_PUTMSG(sackBuf);

               /* stop the ackDelayTmr */
               SB_STOP_TMR(&(assocCb->sbAcCb.ackDelayTmr));

               /* reset sinceSACK counter */
               assocCb->sbAcCb.sinceSack = 0;

               /* set for statistics counting at end */
               sackSent = TRUE;
            }
         }
      }
   }

   SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
          "sbCmChunkMux: noBundle(%d), resend(%d), assocState(%d) \n",
          chunk->noBundleFlg, chunk->resendFlg, assocCb->assocState));
   /* check if we can bundle more data onto the message */

   /* Change in logic - Identify the retransmission first here */
   if ( (addrCb->nmbRtxChunk) || (chunk->resendFlg == TRUE) || 
            (assocCb->assocState == SB_ST_SDOWN_PEND))
   {
      /* find out how much space is used for the message so far */
      /* sb051.102: Checking the error for SSI function call */
      ret = SFndLenMsg(mBuf, &msgLen);
      if(ret != ROK) 
      {
         SBDBGP( SB_DBGMASK_CM, ( sbGlobalCb.sbInit.prntBuf,
  	  "sbCmChunkMux: Could not get the length of the buffer\n"));
         SB_PUTMSG(mBuf);
         RETVALUE( RFAILED );
      }

      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
       "sbCmChunkMux: bundling new chunk with existing one of length %d \n",
             msgLen));

      /* loop through the congestion queue and find the next chunk with
       * matching destination address and resendFlg */
     
      /* Point to the current Entry in the list and proceed further */

      l = &(assocCb->sbDbCb.congestionQ);
      l->crnt = crntEntry;
      n = cmLListNext(l);

      /* Loop till the end of the congestion Q */
      while((continueFlg == TRUE) && ( n != NULLP ))
      {
         nextChunk = (SbQueuedChunk *) n->node;

         SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                "sbCmChunkMux: testing chunk %d with tsn %lu \n",
                (U16)i, chunk->tsn));

         /* see if resendFlg and addrCb match AND if not the same chunk again */
         if ( (chunk != nextChunk) &&
              (chunk->resendFlg == nextChunk->resendFlg) &&
              (addrCb == nextChunk->addrCb) &&
              (nextChunk->sendFlg == TRUE) )
         {

            if(firstChunk == FALSE)
            {
              lowChunk = nextChunk;
              firstChunk = TRUE;
            }

            /* find out how much space is needed for the next chunk */
            /* sb051.102: Checking the error for SSI function call */
            ret = SFndLenMsg(nextChunk->mBuf, &reqLen);
            if(ret != ROK) 
	    {
	       SBDBGP( SB_DBGMASK_CM, ( sbGlobalCb.sbInit.prntBuf,
	 	  "sbCmChunkMux: Could not get the length of the buffer\n"));
               SB_PUTMSG(mBuf);
	       RETVALUE( RFAILED );
	    }
            tmpLen = reqLen;     /* Save for use in Congestion control Calc */
            /* sb030.102: Add SCTP common header size in reqLen */
            reqLen += ( SB_DATA_MIN_SIZE + SB_CHUNK_HEADER_SIZE + SB_COMMON_HEADER_SIZE);

            /* check if there is space left for this DATA chunk */
            if ( ((MsgLen)mtu - msgLen) > reqLen )
            {
               /* check the buffer and window space - Bakeoff fix */
               if (( (assocCb->sbAcCb.rwnd >= 0) &&  (addrCb->bytesOut < addrCb->cwnd) )
                   || (addrCb->bytesOut > 0) )
               {

                  /* build next message */
                  ret = sbCmMakeMsg(nextChunk, &nextBuf);
                  if ( ret != ROK )
                  {
                     /* errors are already logged */
                     SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                            "sbCmChunkMux: could not add next chunk \
                            onto message\n"));
                     SB_PUTMSG(mBuf);
                     RETVALUE(ret);
                  }

                  /* add next message onto end of message */
                  (Void) SCatMsg(mBuf, nextBuf, M1M2);
                  SB_PUTMSG(nextBuf);

                   /* Does the chunk have the lowest unack. TSN on its DTA? */
                   if ( nextChunk == lowChunk )
                   {
                     /* Restart T3-rxt timer */
                     if ( addrCb->t3rtx.tmrEvnt != TMR_NONE )
                     {
                        SB_STOP_TMR(&(addrCb->t3rtx));
                     }

                      SB_START_TMR(&(addrCb->t3rtx), addrCb, SB_TMR_T3RTX,
                                  addrCb->rto);
                   }

                  /* update byte counters */
                  assocCb->sbAcCb.bytesOut += tmpLen;
                  addrCb->bytesOut += tmpLen;

                  assocCb->sbAcCb.rwnd -= tmpLen;
                  if(assocCb->sbAcCb.rwnd < 0)
                     assocCb->sbAcCb.rwnd = 0;

                  /* clear sendFlg */
                  nextChunk->sendFlg = FALSE;

                  if ( (assocCb->sbDbCb.newPkt != NULLP) && 
                     ((SbQueuedChunk *)((assocCb->sbDbCb.newPkt)->node)  == nextChunk ))
                  {
                     l1 = &(assocCb->sbDbCb.congestionQ);
                     l1->crnt = assocCb->sbDbCb.newPkt;
                     assocCb->sbDbCb.newPkt = cmLListNext(l1);
                  }
                
  /* As this is definately a retransmission so decrement the
   * Retransmission counter */
                  if(addrCb->nmbRtxChunk > 0 )
                       addrCb->nmbRtxChunk--;
        
                  /* used for statistics counting at the end */
                  nmbData++;
               }
               else
               {
                  break;
               }
            }
            else
            {
               /* exit the loop if there is no space left for another message */
               break;
            }
         }       
         else   /* performance fix - bug identified during performance testing */
         { 
            if((nextChunk->sendFlg == TRUE ) && (addrCb != nextChunk->addrCb)) 
                 continueFlg=FALSE;
         }

         /* sb051.102: Checking the error for SSI function call */
         ret = SFndLenMsg(mBuf, &msgLen);
         if(ret != ROK) 
	 {
	    SBDBGP( SB_DBGMASK_CM, ( sbGlobalCb.sbInit.prntBuf,
	          "sbCmChunkMux: Could not get the length of the buffer\n"));
            SB_PUTMSG(mBuf);
	    RETVALUE( RFAILED );
	 }
         l->crnt = n;
         n = cmLListNext(l);
      }  /* while loop */ 

   }  /* retransmission ends here */

   if ( (assocCb->sbDbCb.newPkt != NULLP ) && (addrCb->nmbRtxChunk == 0 ) &&
        ( (chunk->noBundleFlg == FALSE) || (assocCb->assocState == SB_ST_SDOWN_PEND) ) )
   {

      l = &(assocCb->sbDbCb.congestionQ);
      l->crnt = assocCb->sbDbCb.newPkt;
      n = cmLListCrnt(l);

      while ((continueFlg == TRUE) && ( n != NULLP ))
      {
         nextChunk = (SbQueuedChunk *) n->node;

         SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                "sbCmChunkMux: testing chunk %d with tsn %lu \n",
                (U16)i, chunk->tsn));

       /* see if resendFlg and addrCb match AND if not the same chunk again */
         if ( (chunk != nextChunk) &&
              (chunk->resendFlg == nextChunk->resendFlg) &&
              (addrCb == nextChunk->addrCb) &&
              (nextChunk->sendFlg == TRUE))
         {
            /* find out how much space is needed for the next chunk */
            /* sb051.102: Checking the error for SSI function call */
            ret = SFndLenMsg(nextChunk->mBuf, &reqLen);
            if(ret != ROK) 
	    {
	       SBDBGP( SB_DBGMASK_CM, ( sbGlobalCb.sbInit.prntBuf,
	 	  "sbCmChunkMux: Could not get the length of the buffer\n"));
               SB_PUTMSG(mBuf);
	       RETVALUE( RFAILED );
	    }
            tmpLen = reqLen;     /* Save for use in Congestion control Calc */
            /* sb030.102: Add SCTP common header size in reqLen */
            reqLen += ( SB_DATA_MIN_SIZE + SB_CHUNK_HEADER_SIZE + SB_COMMON_HEADER_SIZE);

            /* check if there is space left for this DATA chunk */
            if ( ((MsgLen)mtu - msgLen) > reqLen )
            {
               /* check the buffer and window space - Bakeoff fix */
               if (( (assocCb->sbAcCb.rwnd >= 0) &&  (addrCb->bytesOut < addrCb->cwnd) )
                   || (addrCb->bytesOut > 0) )
               {

                  /* build next message */
                  ret = sbCmMakeMsg(nextChunk, &nextBuf);
                  if ( ret != ROK )
                  {
                     /* errors are already logged */
                     SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                            "sbCmChunkMux: could not add next chunk \
                            onto message\n"));
                     SB_PUTMSG(mBuf);
                     RETVALUE(ret);
                  }

                  /* add next message onto end of message */
                  (Void) SCatMsg(mBuf, nextBuf, M1M2);
                  SB_PUTMSG(nextBuf);

                  /* is this a retransmission? */
                  if ( nextChunk->resendFlg == TRUE)
                  {
                     /* Does the chunk have the lowest unack. TSN on its DTA? */
                     if ( nextChunk == lowChunk )
                     {
                        /* Restart T3-rxt timer */
                        if ( addrCb->t3rtx.tmrEvnt != TMR_NONE )
                        {
                           SB_STOP_TMR(&(addrCb->t3rtx));
                        }

                        SB_START_TMR(&(addrCb->t3rtx), addrCb, SB_TMR_T3RTX,
                                     addrCb->rto);
                     }

                  }
                  else
                  {
                     /* RTT updates */
                     if ( addrCb->rttInProg == FALSE )
                     {
                        addrCb->rttInProg = TRUE;
                        chunk->rttInProg = TRUE;
                     }
                     else
                     {
                        chunk->rttInProg = FALSE;
                     }
                  }

                  /* update byte counters */
                  assocCb->sbAcCb.bytesOut += tmpLen;
                  addrCb->bytesOut += tmpLen;

                  assocCb->sbAcCb.rwnd -= tmpLen;
                  if(assocCb->sbAcCb.rwnd < 0)
                     assocCb->sbAcCb.rwnd = 0;

                  /* clear sendFlg */
                  nextChunk->sendFlg = FALSE;

                  if ( (assocCb->sbDbCb.newPkt != NULLP) && 
                     ((SbQueuedChunk *)((assocCb->sbDbCb.newPkt)->node)  == nextChunk ))
                  {
                    l1 = &(assocCb->sbDbCb.congestionQ);
                    l1->crnt = assocCb->sbDbCb.newPkt;
                    assocCb->sbDbCb.newPkt = cmLListNext(l1);
                  }
                  else
                  {
                     SBDBGP(SB_DBGMASK_AS, (sbGlobalCb.sbInit.prntBuf,
                        "sbCmChunkMux: New Chunk But assocCb's newPkt does'nt match\n"));
                     /* sb051.102: free mBuf */
                     SB_PUTMSG(mBuf);
                     RETVALUE(RFAILED);
                  }
                  /* used for statistics counting at the end */
                  nmbData++;
               }
               else
               {
                  break;
               }
            }
            else
            {
          /* exit the loop if there is no space left for another message */
               break;
            }
         }
         else   /* performance fix - bug identified during performance testing */
         { 
            if((nextChunk->sendFlg == TRUE ) && (addrCb != nextChunk->addrCb)) 
                 continueFlg=FALSE;
         }
        
         /* sb051.102: Checking the error for SSI function call */
         ret = SFndLenMsg(mBuf, &msgLen);
         if(ret != ROK) 
	 {
	    SBDBGP( SB_DBGMASK_CM, ( sbGlobalCb.sbInit.prntBuf,
	          "sbCmChunkMux: Could not get the length of the buffer\n"));
            SB_PUTMSG(mBuf);
	    RETVALUE( RFAILED );
	 }
         l->crnt = n;
         n = cmLListNext(l);
      }
   } /* if nobundleFlg */

   /* add common header */
   ret = sbAsAddHead(assocCb->localPort, assocCb->peerPort,
                     assocCb->peerInitTag, mBuf);

#if ( ERRCLASS & ERRCLS_ADD_RES )
   if ( ret != ROK )
   {
      SBDBGP(SB_DBGMASK_AS, (sbGlobalCb.sbInit.prntBuf,
             "sbCmChunkMux: could not add header to DATA chunk\n"));
      /* sb051.102: free mBuf */
      SB_PUTMSG(mBuf);
      RETVALUE(RFAILED);
   }
#endif

   /* send the message */
   /* sb021.102: Modification for TOS parameter */
#ifdef SCT3
   ret = sbLiSend(assocCb->localConn, &(addrCb->addr), mBuf, TRUE ,
                  assocCb->tos, addrCb);
                                    /* AddrCb Added - sb023.102 */
#else
   ret = sbLiSend(assocCb->localConn, &(addrCb->addr), mBuf, TRUE, addrCb);
                                    /* AddrCb Added - sb023.102 */
#endif /* SCT3 */

#if (ERRCLASS & ERRCLS_DEBUG)
   if ( ret != ROK )
   {
      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmChunkMux: could not send DATA chunk\n"));
      /* sb051.102: free mBuf */
      SB_PUTMSG(mBuf);
      RETVALUE(RFAILED);
   }
#endif

   /* update statistics counters */
   if ( sackSent == TRUE )
   {
      sbGlobalCb.genSts.sbChunkSts.noDAckTx++;
      sbGlobalCb.tSaps[assocCb->localConn->suId]->tSts.sbChunkSts.noDAckTx++;
   }
   if ( chunk->resendFlg == TRUE )
   {
      /* update statistics counters */
      sbGlobalCb.genSts.sbChunkSts.noDataReTx += nmbData;
      sbGlobalCb.tSaps[assocCb->localConn->suId]->tSts.sbChunkSts.noDataReTx +=
         nmbData;
   }
   else
   {
      /* update statistics counters */
      sbGlobalCb.genSts.sbChunkSts.noDataTx += nmbData;
      sbGlobalCb.tSaps[assocCb->localConn->suId]->tSts.sbChunkSts.noDataTx +=
         nmbData;
   }

   addrCb->sentSince = TRUE;

   RETVALUE(ROK);
}/* sbCmChunkMux() */


/*
*
*      Fun:   sbCmMakeMsg
*
*      Desc:  Create a Message from a chunk structure.
*
*      Ret:   Success:         ROK
*             Failure:         RFAILED  (optional under ERRCLS_ADD_RES)
*             Resource error:  ROUTRES
*
*      Notes: This function packs chunk related info into a message buffer.
*             The chunk header is also included.
*             On failure this function must SB_PUTMSG the buffer since
*             it is allocated by SAddMsgRef within
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbCmMakeMsg
(
SbQueuedChunk   *chunk,          /* Chunk to pack into message buffer */
Buffer         **mBuf            /* Buffer */
)
#else
PUBLIC S16 sbCmMakeMsg(chunk, mBuf)
SbQueuedChunk   *chunk;          /* Chunk to pack into message buffer */
Buffer         **mBuf;           /* Buffer */
#endif
{
   /* local parameters */
   S16               ret;
   U8                flags;
   MsgLen            pad;
   MsgLen            len;
   U32               i=0;    /* sb001.12 : modification - warning removed */
   U8                pkArray[32];
   U8                idx;

   TRC2(sbCmMakeMsg)


   SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
          "sbCmMakeMsg(chunk, mBuf)\n"));

   *mBuf = (Buffer *)NULLP;

   /* Pack the DATA into the message */
   SB_ADDMSGREF(chunk->mBuf, mBuf, ret);
   /*ret = SAddMsgRef(chunk->mBuf, sbGlobalCb.sbInit.region,
                    sbGlobalCb.sbInit.pool, mBuf);*/
   if ( ret != ROK )
   {
      /* this is a GET RESOURCE failure */
      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
            "sbCmMakeMsg: could not copy chunk buffer into message buffer\n"));
      SB_PUTMSG(*mBuf);
      RETVALUE(ROUTRES);
   }

   /* determine how much padding is needed to reach a 32bit boundary */
   /* sb051.102: Checking the error for SSI function call */
   ret = SFndLenMsg(chunk->mBuf, &len);
   if(ret != ROK) 
   {
      SBDBGP( SB_DBGMASK_CM, ( sbGlobalCb.sbInit.prntBuf,
  	  "sbCmMakeMsg: Could not get the length of the buffer\n"));
      SB_PUTMSG(*mBuf);
      RETVALUE( RFAILED );
   }
   if ( (len % 4) != 0 )
   {
      pad = (S16)(4 - (len % 4));
   }
   else
   {
      pad = 0;
   }

   if(pad != 0)
   {
        idx=0;  
        /* sb023.102 Performance change - put the pad in pkArray first  */
        /* pack it on */
        for ( i = 0; i < (U32)pad; i++ )
        {
           pkArray[idx++] = 0x00;
        }

        /* sb023.102 Performance change - Do only one SAddPstMsgMult in case of
         * padding */
        ret = SAddPstMsgMult(&pkArray[0], idx, *mBuf);

#if ( ERRCLASS & ERRCLS_ADD_RES )
        if ( ret != ROK )
        {
            SBLOGERROR( ERRCLS_ADD_RES, ESB168, (ErrVal) ret,
                        "sbCmMakeMsg: Add Resource Failure" );
            SB_PUTMSG(*mBuf);
            RETVALUE(RFAILED);
        }
#endif
   }


   /* Protocol Identifier */
   idx = 0;

   SB_PKU32(chunk->protId);

   /* Stream Sequence Number */
   SB_PKU16(chunk->seqNum);

   /* Stream Identifier */
   SB_PKU16(chunk->stream);

   /* Chunk's TSN */
   SB_PKU32(chunk->tsn);

   /* Length of chunk */
   len = (U16)(len + SB_CHUNK_HEADER_SIZE + idx);   /* add chunk header stuff */
   SB_PKU16(len);

   /* U/B/E flags and reserved bits */
   flags = 0x0;
   if ( chunk->unorderedFlg == TRUE )
   {
      flags = (U8)(flags | 0x4);
   }
   if ( chunk->startFlg == TRUE )
   {
      flags = (U8)(flags | 0x2);
   }
   if ( chunk->endFlg == TRUE )
   {
      flags = (U8)(flags | 0x1);
   }

   SB_PKU8(flags);

   SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
          "sbCmMakeMsg: flags(%d), len(%d), tsn(%lu), seqNum(%d), stream(%d), protId(%lu)\n",
          flags, len, chunk->tsn, chunk->seqNum, chunk->stream, chunk->protId));

   /* Chunk ID */
   SB_PKU8((U8) SB_ID_DATA);

   ret = SAddPreMsgMult(&pkArray[0], idx, *mBuf);

#if ( ERRCLASS & ERRCLS_ADD_RES )
   if ( ret != ROK )
   {
      SBLOGERROR( ERRCLS_ADD_RES, ESB169, (ErrVal) ret,
                  "sbCmMakeMsg: Add Resource Failurein SAddPreMsgMult" );
      SB_PUTMSG(*mBuf);
      RETVALUE(RFAILED);
   }
#endif

   chunk->time = sbGlobalCb.sbTqCp.nxtEnt;

   RETVALUE(ROK);
}/* sbCmMakeMsg() */

/*
*
*      Fun:   sbCmDemux
*
*      Desc:  Chunk Demultiplexing
*
*      Ret:   Success:              ROK
*             Failure:              RFAILED
*
*      Notes: This function verifies and redirects chunks as they arrive.
*
*      File:  sb_bdy2.c
*
*/

/* sb060.102 - TOS enhancement */
#ifdef SCT4
#ifdef ANSI
PUBLIC S16 sbCmDemux
(
CmNetAddr       *localAddr,      /* Address chunk arrived on */
CmNetAddr       *peerAddr,       /* Address chunk was sent from */
U16              localPort,      /* Port chunk arrived on */
U16              peerPort,       /* Port chunk was sent on */
U32              vTag,           /* Verification tag */
UConnId          suConId,        /* Connection ID used by SCTP */
Buffer          *mBuf,            /* Buffer */
U8               tos             /*  TOS enhancement */
)
#else
PUBLIC S16 sbCmDemux(localAddr, peerAddr, localPort, peerPort, vTag,
                     suConId, mBuf, tos)
CmNetAddr       *localAddr;      /* Address chunk arrived on */
CmNetAddr       *peerAddr;       /* Address chunk was sent from */
U16              localPort;      /* Port chunk arrived on */
U16              peerPort;       /* Port chunk was sent on */
U32              vTag;           /* Verification tag */
UConnId          suConId;        /* Connection ID used by SCTP */
Buffer          *mBuf;           /* Buffer */
U8               tos;            /* TOS enhancement */
#endif
#else /* SCT4 */
#ifdef ANSI
PUBLIC S16 sbCmDemux
(
CmNetAddr       *localAddr,      /* Address chunk arrived on */
CmNetAddr       *peerAddr,       /* Address chunk was sent from */
U16              localPort,      /* Port chunk arrived on */
U16              peerPort,       /* Port chunk was sent on */
U32              vTag,           /* Verification tag */
UConnId          suConId,        /* Connection ID used by SCTP */
Buffer          *mBuf            /* Buffer */
)
#else
PUBLIC S16 sbCmDemux(localAddr, peerAddr, localPort, peerPort, vTag,
                     suConId, mBuf)
CmNetAddr       *localAddr;      /* Address chunk arrived on */
CmNetAddr       *peerAddr;       /* Address chunk was sent from */
U16              localPort;      /* Port chunk arrived on */
U16              peerPort;       /* Port chunk was sent on */
U32              vTag;           /* Verification tag */
UConnId          suConId;        /* Connection ID used by SCTP */
Buffer          *mBuf;           /* Buffer */
#endif
#endif /* SCT4 */
{
   /* local parameters */
   S16               ret;
   MsgLen            msgLen;
   SbSctEndpCb      *endpCb;
   SbSctAssocCb     *assocCb;
   SbAddrCb         *addrCb;
   SbLocalAddrCb    *localConn;
   U32               i;
   U16               pad;
   U16               chunkLen;
   U8                chunkType;
   U8                chunkFlags;
   U8                tmpU8;
   Buffer           *tmpBuf;
   Buffer           *chunkBuf;
   SbQueuedChunk    *chunk;
   Bool              rcvDataFlg;
   Bool              firstChunkFlg;
   U8                pkArray[4];
   U8                idx;
   SbSctSapCb        *sctSap;
   SbSctAssocCb      *dataAssocCb = NULLP;
   /* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
   S8                ipv6Addr1[SB_IPV6STR_SIZE];
   S8                ipv6Addr2[SB_IPV6STR_SIZE];
   U8                *tempIpv6Addr;
#endif

   TRC2(sbCmDemux)
   if((localAddr->type == CM_NETADDR_IPV4) && (peerAddr->type == CM_NETADDR_IPV4))
   {
      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmDemux(localAddr(%ld), peerAddr(%ld), localPort(%d), peerPort(%d), vTag(%ld), mBuf)\n",
             localAddr->u.ipv4NetAddr, peerAddr->u.ipv4NetAddr, localPort, peerPort, vTag));
   }
   /* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
   if((localAddr->type == CM_NETADDR_IPV6) && (peerAddr->type == CM_NETADDR_IPV6))
   {
      tempIpv6Addr = localAddr->u.ipv6NetAddr;
      SB_CPY_IPV6ADSTR(ipv6Addr1, tempIpv6Addr)
      tempIpv6Addr = peerAddr->u.ipv6NetAddr;
      SB_CPY_IPV6ADSTR(ipv6Addr2, tempIpv6Addr)
      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
               "sbCmDemux(localAddr(%s), peerAddr(%s), localPort(%d), peerPort(%d), vTag(%ld), mBuf)\n",
               ipv6Addr1, ipv6Addr2, localPort, peerPort, vTag));
   }
#endif

   /* default values */
   tmpBuf = (Buffer *) NULLP;
   chunkBuf = (Buffer *) NULLP;
   chunk = (SbQueuedChunk *) NULLP;
   endpCb = (SbSctEndpCb *) NULLP;
   assocCb = (SbSctAssocCb *) NULLP;
   addrCb = (SbAddrCb *) NULLP;
   localConn = (SbLocalAddrCb *) NULLP;

   /* find length of arrived message */
   /* sb051.102: Checking the error for SSI function call */
   ret = SFndLenMsg(mBuf, &msgLen);
   if(ret != ROK) 
   {
      SBDBGP( SB_DBGMASK_CM, ( sbGlobalCb.sbInit.prntBuf,
  	  "sbCmDemux: Could not get the length of the buffer\n"));
      SB_PUTMSG(mBuf);
      RETVALUE( RFAILED );
   }

   /* make sure it is 32bit aligned */
   if ( (msgLen & 0x0003) != 0 )
   {
      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmDemux: message not '32bit' aligned\n"));
      SB_PUTMSG(mBuf);
      RETVALUE(RFAILED);
   }

   /* default flag values */
   rcvDataFlg = FALSE;
   firstChunkFlg = TRUE;

   /* resolve the assoc and endpoint for the incoming message */
   ret = sbCmResolveChunk(localPort, localAddr, peerPort, peerAddr,
                          &endpCb, &assocCb);

   /* quick exit if endpoint CB doesn't resolve */
   if ( ret != ROK )
   {
      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmDemux: endpoint does not exist\n"));

      /* Exit here unless we have received a SHUTDOWN */
      /* We must still send a SHUTDOWN ACK if a SHUTDOWN arrives*/
      SExamMsg(&tmpU8, mBuf, 0);

      if ( tmpU8 != SB_ID_SDOWN )
      {
         SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                "sbCmDemux: Neither is the chunk a shutdown chunk\n"));
         SB_PUTMSG(mBuf);
         RETVALUE(RFAILED);
      }
   }

   /* loop through all the chunks in the message */
   while ( msgLen > 0 )
   {
      if ( msgLen < SB_IFL_SZ )
      {
         SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                "sbCmDemux: too little message left to process\n"));
         SB_PUTMSG(mBuf);
         RETVALUE(RFAILED);
      }

      /* get chunk info */
      ret = SRemPreMsgMult(&pkArray[0], 4, mBuf);
      /* sb049.102: Checking for error conditions */
      if (ret != ROK)
      {
         SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                  "sbCmDemux: PreMsgMult Failed for mBuf\n"));
         SB_PUTMSG(mBuf);
         RETVALUE( RFAILED );
      }
      idx = 0;

      SB_UNPKU8(chunkType);                    /* chunk type   */
      SB_UNPKU8(chunkFlags);                   /* chunk flags  */
      SB_UNPKU16(chunkLen);                    /* chunk length */

      /* adjust message and chunk lengths for the removed IFL header */
      msgLen -= 4;
      chunkLen -= 4;

      if ( msgLen < chunkLen )
      {
         SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                "sbCmDemux: chunk length(%d) > remaining message length(%d)\n", chunkLen, msgLen));
         SB_PUTMSG(mBuf);
         RETVALUE(RFAILED);
      }


      /* work out no. of padding octets at end of chunk */
      if ( (chunkLen & 0x0003) == 0 )
      {
         pad = 0;
      }
      else
      {
         pad = (U16)(4 - (chunkLen & 0x0003));
      }

      /* cut out the chunk from the message */
      /* tmpBuf is inititated in there */
      if (chunkLen == msgLen)
      {
         chunkBuf = mBuf;
         mBuf = (Buffer *)NULLP;
         msgLen = 0;
      }
      else
      {
         SB_SEGMSG(mBuf, chunkLen, &tmpBuf, ret)
         /*ret = SSegMsg(mBuf, chunkLen, &tmpBuf);*/

         if (ret != ROK)
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmDemux: could not get segment buffer\n"));

            /* get resource failure */
            sbLmGenAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                         LCM_CAUSE_MEM_ALLOC_FAIL, 0, LSB_SW_RFC_REL0);

            SB_PUTMSG(mBuf);
            RETVALUE(RFAILED);
         }

         /* need to swap them round */
         chunkBuf = mBuf;
         mBuf = tmpBuf;
         tmpBuf = (Buffer *)NULLP;

         msgLen = (MsgLen)(msgLen - chunkLen);
      }

      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmDemux: (chunkType(%d), chunkFlags(%x), chunkLen(%d), msgLen(%d), pad(%d))\n",
             chunkType, chunkFlags, chunkLen, msgLen, pad));

      /* redirect the chunk */
      switch ( chunkType )
      {
         case  SB_ID_DATA:

            ret = sbCmValChunk(assocCb, vTag, chunkType, suConId,chunkFlags);
            if ( ret == RFAILED )
            {
               /* OOTB chunk */
               /* find local address control block */
               localConn = sbGlobalCb.localAddrCb[suConId];
   /* sb021.102: Modification for TOS parameter */
#ifdef SCT3
   /* sb060.102 - TOS enhancement */
#ifdef SCT4
               ret = sbAsSendAbort(vTag, localConn, peerAddr,
                                   localPort, peerPort,TRUE, tos);
#else 
               ret = sbAsSendAbort(vTag, localConn, peerAddr,
                                   localPort, peerPort,TRUE, 0);
#endif /* SCT4 */
#else
               ret = sbAsSendAbort(vTag, localConn, peerAddr,
                                   localPort, peerPort,TRUE);
#endif /* SCT3 */
               if ( ret == ROUTRES )
               {
                  sbLmGenAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                               LCM_CAUSE_MEM_ALLOC_FAIL, 0, LSB_SW_RFC_REL0);
               }
               SB_PUTMSG(chunkBuf);
               SB_CHK_PUTMSG(mBuf);
               RETVALUE(RFAILED);
            }
            else if ( ret != ROK )
            {
               /* silently discard */
               SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                      "sbCmDemux: sbCmValChunk Failed\n"));

               SB_PUTMSG(chunkBuf);
               SB_CHK_PUTMSG(mBuf);
               RETVALUE(RFAILED);
            }

            /* create new chunk */
            /* sb023.102 - To reduce number of cmMemset operations we are 
             * directly allocating SbQueuedChunk sturture, It is anyway 
             * initialised field by field so there is no need for 
             * cmMemSet - performance change */
            SB_GETSBUF(sizeof(SbQueuedChunk), chunk, ret);
            if ( ret != ROK )
            {
               SB_PUTMSG(chunkBuf);
               SB_CHK_PUTMSG(mBuf);

               /* get resource failure */
               sbLmGenAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_SMEM_ALLOC_FAIL,
                            LCM_CAUSE_MEM_ALLOC_FAIL, 0, LSB_SW_RFC_REL0);

               RETVALUE(RFAILED);
            }

            /* build new chunk and process it */
            SB_CPY_NADDR(&(assocCb->sbAcCb.sackAddr), peerAddr);
            ret = sbCmMakeChunk(assocCb, chunkFlags, chunkBuf, chunk);
            if ( ret != ROK )
            {
               SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                      "sbCmDemux: sbCmMakeChunk Failed, ret = %d\n", ret));

               /* something wrong with this DATA chunk but we can still
                * look at the rest in the message */
               SB_FREE(sizeof(SbQueuedChunk), chunk);
               /* sb026.102: to send SACK for duplicate DATA */
               if(dataAssocCb == NULLP)
               {
                 dataAssocCb=assocCb;
               }
               /* sb026.102: to send SACK for duplicate DATA */
            }
            else
            {
               ret = sbAcRcvData(assocCb, chunk);
               if ( ret != ROK )
               {
                  SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                         "sbCmDemux: sbAcRcvData Failed, \n"));
                  /* something wrong with this DATA chunk but we can still
                   * look at the rest in the message */
                  /*sb024:102 dynamic buffer needs to be freed here */
                  SB_CHK_PUTMSG(chunk->mBuf);
                  SB_FREE(sizeof(SbQueuedChunk), chunk);
               }
               if(dataAssocCb == NULLP)
               {
                 dataAssocCb=assocCb;
               }
               /* no more control chunks allowed but more DATA allowed */
               rcvDataFlg = TRUE;
               firstChunkFlg = FALSE;
            }
            break;

         case  SB_ID_INIT:
            /* INIT must be first chunk and alone */
            if ( firstChunkFlg == TRUE )
            {
               ret = sbCmValChunk(assocCb, vTag, chunkType, suConId,chunkFlags);
               if ( ret != ROK )
               {
                  SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                         "sbCmDemux: sbCmValChunk Failed\n"));

                  SB_PUTMSG(chunkBuf);
                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }
      /* sb060.102 - TOS enhancement */
#ifdef SCT4
               ret = sbAsRcvInit(endpCb, peerAddr, peerPort, chunkLen,
                                 chunkBuf, tos);
#else
               ret = sbAsRcvInit(endpCb, peerAddr, peerPort, chunkLen,
                                 chunkBuf);
#endif /* SCT4 */
               if ( ret != ROK )
               {
                  SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                         "sbCmDemux: sbAsRcvInit Failed\n"));

                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }
            }
            else
            {
               SB_PUTMSG(chunkBuf);
            }

            /* no more chunks allowed */
            SB_CHK_PUTMSG(mBuf);
            RETVALUE(ROK);
            break;

         case  SB_ID_INITACK:
            /* INIT ACK must be first chunk and alone */
            if ( firstChunkFlg == TRUE )
            {
               if (assocCb == (SbSctAssocCb *)NULLP)
               {
                  ret = sbAsFindAssoc(chunkBuf, &assocCb, endpCb->spEndpId, peerPort);
               }

               ret = sbCmValChunk(assocCb, vTag, chunkType, suConId,chunkFlags);
               if ( ret != ROK )
               {
                  SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                         "sbCmDemux: sbCmValChunk Failed\n"));

                  SB_PUTMSG(chunkBuf);
                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }

               ret = sbAsRcvInitAck(assocCb, peerAddr, chunkLen, chunkBuf);
               if ( ret != ROK )
               {
                  SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                         "sbCmDemux: sbAsRcvInitAck Failed\n"));

                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }

            }
            else
            {
               SB_PUTMSG(chunkBuf);
            }

            /* no more chunks allowed */
            SB_CHK_PUTMSG(mBuf);
            RETVALUE(ROK);
            break;

         case  SB_ID_SACK:
            /* SACK does not have to be first chunk but must be before DATA */
            if ( rcvDataFlg != TRUE )
            {
               ret = sbCmValChunk(assocCb, vTag, chunkType, suConId,chunkFlags);
               if ( ret != ROK )
               {
                  SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                         "sbCmDemux: sbCmValChunk Failed\n"));

                  SB_PUTMSG(chunkBuf);
                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }

               ret = sbAcRcvSack(assocCb, chunkBuf);
               if ( ret != ROK )
               {
                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }

            }
            else  /* SACK came after DATA */
            {
               /* no more chunks allowed since something is wrong */
               SB_PUTMSG(chunkBuf);
               SB_CHK_PUTMSG(mBuf);
               RETVALUE(RFAILED);
            }
            /* clear the first chunk flag just in case */
            firstChunkFlg = FALSE;
            break;

         case  SB_ID_HBEAT:
            /* HBEAT must be before DATA */
            if ( rcvDataFlg != TRUE )
            {
               ret = sbCmValChunk(assocCb, vTag, chunkType, suConId,chunkFlags);
               if ( ret != ROK )
               {
                  SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                         "sbCmDemux: sbCmValChunk Failed\n"));

                  SB_PUTMSG(chunkBuf);
                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }

               ret = sbPmRcvHBeat(assocCb, peerAddr, chunkLen, chunkBuf);
               if ( ret != ROK )
               {
                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }

            }
            else /* HBEAT came after DATA */
            {
               /* no more chunks allowed since something is wrong */
               SB_PUTMSG(chunkBuf);
               SB_CHK_PUTMSG(mBuf);
               RETVALUE(ROK);
            }
            /* clear the first chunk flag just in case */
            firstChunkFlg = FALSE;
            break;

         case  SB_ID_HBEATACK:
            /* HBEAT ACK must be before DATA */
            if ( rcvDataFlg != TRUE )
            {
               ret = sbCmValChunk(assocCb, vTag, chunkType, suConId,chunkFlags);
               if ( ret != ROK )
               {
                  SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                         "sbCmDemux: sbCmValChunk Failed\n"));

                  SB_PUTMSG(chunkBuf);
                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }

               ret = sbPmRcvHBeatAck(assocCb, chunkBuf);
               if ( ret != ROK )
               {
                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }

            }
            else /* HBEAT ACK came after DATA */
            {
               /* no more chunks allowed since something is wrong */
               SB_PUTMSG(chunkBuf);
               SB_CHK_PUTMSG(mBuf);
               RETVALUE(ROK);
            }
            /* clear the first chunk flag just in case */
            firstChunkFlg = FALSE;
            break;

         case  SB_ID_ABORT:
            /* DATA not allowed with ABORT */
            if ( rcvDataFlg != TRUE )
            {
               ret = sbCmValChunk(assocCb, vTag, chunkType, suConId,chunkFlags);
               if ( ret != ROK )
               {
                  SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                         "sbCmDemux: sbCmValChunk Failed\n"));

                  SB_PUTMSG(chunkBuf);
                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }

               ret = sbAsRcvAbort(assocCb, chunkLen, chunkBuf);
               if ( ret != ROK )
               {
                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }

            /* all subsequent chunks will be ignored anyway */
               SB_CHK_PUTMSG(mBuf);
               RETVALUE(ROK);
            }
            else /* ABORT came with DATA */
            {
               /* no more chunks allowed since something is wrong */
               SB_PUTMSG(chunkBuf);
               SB_CHK_PUTMSG(mBuf);
               RETVALUE(ROK);
            }

         case  SB_ID_SDOWN:
            /* SDOWN may be bundled with SACK */
            if ( rcvDataFlg != TRUE )
            {
               /* send a SHUTDOWN ACK if a SHUTDOWN is received which
                * doesn't resolve */
               if ( (endpCb == (SbSctEndpCb *) NULLP) ||
                    (assocCb == (SbSctAssocCb *) NULLP) )
               {
                  /* find local address control block */
                  localConn = sbGlobalCb.localAddrCb[suConId];
   /* sb021.102: Modification for TOS parameter */
#ifdef SCT3
  /* sb060.102 - TOS enhancement */
#ifdef SCT4
                  ret = sbAsSendSdownAck(localPort, peerPort, peerAddr,
                                         localConn, 0x0000, FALSE, tos);
#else
                  ret = sbAsSendSdownAck(localPort, peerPort, peerAddr,
                                        localConn, 0x0000, FALSE, 0);
#endif /* SCT4 */
#else
                  ret = sbAsSendSdownAck(localPort, peerPort, peerAddr,
                                        localConn, 0x0000, FALSE);
#endif /* SCT3 */
                  if ( ret != ROK )
                  {
                     SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                            "sbCmDemux: could not send SHUTDOWN ACK\n"));
                     SB_PUTMSG(chunkBuf);
                     SB_CHK_PUTMSG(mBuf);
                     /* should not continue in this case */
                     RETVALUE(RFAILED);
                  }
               }
               else
               {
                  ret = sbCmValChunk(assocCb, vTag, chunkType, suConId,chunkFlags);
                  if ( ret != ROK )
                  {
                     SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                            "sbCmDemux: sbCmValChunk Failed\n"));

                     SB_PUTMSG(chunkBuf);
                     SB_CHK_PUTMSG(mBuf);
                     RETVALUE(RFAILED);
                  }

                  ret = sbAsRcvShutdown(assocCb, chunkLen, chunkBuf);
                  if ( ret != ROK )
                  {
                     SB_CHK_PUTMSG(mBuf);
                     RETVALUE(RFAILED);
                  }
               }
            }
            else /* SDOWN came after DATA */
            {
               /* no more chunks allowed since something is wrong */
               SB_PUTMSG(chunkBuf);
               SB_CHK_PUTMSG(mBuf);
               RETVALUE(ROK);
            }
            /* clear the first chunk flag just in case */
            firstChunkFlg = FALSE;
            break;

         case  SB_ID_SDOWNACK:
            /* SDOWN ACK must be first chunk and alone */
            if ( firstChunkFlg == TRUE )
            {
               ret = sbCmValChunk(assocCb, vTag, chunkType, suConId,chunkFlags);
               if ( ret == RIGNORE )   /* TCB not present */
               {
                  SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                  "sbCmDemux:SDOWN_ACK Recvd, Assoc not found sending STDOWN_CMPLT\n"));
               
                  localConn = sbGlobalCb.localAddrCb[suConId];
   /* sb021.102: Modification for TOS parameter */
#ifdef SCT3
  /* sb060.102 - TOS enhancement */
#ifdef SCT4
                  ret = sbAsSendSdownCmplt(localPort, peerPort, peerAddr,
                        localConn, vTag, TRUE, tos);

#else
                  ret = sbAsSendSdownCmplt(localPort, peerPort, peerAddr,
                  localConn, vTag, TRUE, 0);
#endif /* SCT4 */
#else
                  ret = sbAsSendSdownCmplt(localPort, peerPort, peerAddr,
                  localConn, vTag, TRUE);
#endif /* SCT3 */
                  if(ret != ROK)
                  {
                     sbLmGenAlarm(LCM_CATEGORY_RESOURCE, 
                      LCM_EVENT_DMEM_ALLOC_FAIL, LCM_CAUSE_MEM_ALLOC_FAIL, 
                      0, LSB_SW_RFC_REL0);

                  }
                  SB_PUTMSG(chunkBuf);
                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(ROK);

               }else 
               if ( ret != ROK )
               {
                  SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                         "sbCmDemux: sbCmValChunk Failed\n"));

                  SB_PUTMSG(chunkBuf);
                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }
       /* section 8.5.1.E implementation - send SDOWN_CMPLT and wait
        * for INIT/COOKIE timer to expire and send INIT/COOKIE again
        * to re-established the association.
       */
               if((assocCb->assocState == SB_ST_COOKIE_WAIT) ||
                      (assocCb->assocState == SB_ST_COOKIE_SENT) )
               {
                  SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmDemux:SDOWN_ACK Recvd, Assoc Find state COOKIE-WAIT/SENT SendingSDOWNCMPLT \n"));
               
                 localConn = sbGlobalCb.localAddrCb[suConId];
   /* sb021.102: Modification for TOS parameter */
#ifdef SCT3
  /* sb060.102 - TOS enhancement */
#ifdef SCT4
                 ret = sbAsSendSdownCmplt(localPort, peerPort, peerAddr,
                                             localConn, vTag, TRUE, tos);
#else
                  ret = sbAsSendSdownCmplt(localPort, peerPort, peerAddr,
                                             localConn, vTag, TRUE, 0);
#endif /* SCT4 */
#else
                  ret = sbAsSendSdownCmplt(localPort, peerPort, peerAddr,
                                             localConn, vTag, TRUE);
#endif /* SCT3 */
                  if(ret != ROK)
                  {
                     sbLmGenAlarm(LCM_CATEGORY_RESOURCE, 
                         LCM_EVENT_DMEM_ALLOC_FAIL, LCM_CAUSE_MEM_ALLOC_FAIL, 
                         0, LSB_SW_RFC_REL0);

                  }
                  SB_PUTMSG(chunkBuf);
                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(ROK);
               }

               ret = sbAsRcvShutDownAck(assocCb);
               if ( ret != ROK )
               {
                  SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                         "sbCmDemux: sbAsRcvShutDownAck Failed\n"));

                  SB_PUTMSG(chunkBuf);
                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }
            }

            /* no more chunks allowed */
            SB_CHK_PUTMSG(mBuf);
            SB_PUTMSG(chunkBuf);
            RETVALUE(ROK);
            break;

          case  SB_ID_SDOWNCMPLT:
            /* SHUTDOWN CMPLT  must be first chunk and alone */
            if ( firstChunkFlg == TRUE )
            {
               ret = sbCmValChunk(assocCb, vTag, chunkType, suConId,chunkFlags);
               if ( ret != ROK )
               {
                  SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                         "sbCmDemux: sbCmValChunk Failed\n"));

                  SB_PUTMSG(chunkBuf);
                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }

               ret = sbAsRcvShutDownCmplt(assocCb);
               if ( ret != ROK )
               {
                  SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                         "sbCmDemux: sbAsRcvShutDownCmplt Failed\n"));

                  SB_PUTMSG(chunkBuf);
                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }

            }

            /* no more chunks allowed */
            SB_CHK_PUTMSG(mBuf);
            SB_PUTMSG(chunkBuf);
            RETVALUE(ROK);

         case  SB_ID_ERROR:
              /* If assocCb is NULLP try ot find the matching association here 'cause 
               * it might have created due to COOKIE chunk arrived */
             if(assocCb == NULLP)
             {
                /* resolve the assoc and endpoint for the incoming message */
                 ret = sbCmResolveChunk(localPort, localAddr, peerPort, peerAddr,
                                               &endpCb, &assocCb);
             }

            ret = sbCmValChunk(assocCb, vTag, chunkType, suConId,chunkFlags);
            if ( ret != ROK )
            {
               SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                      "sbCmDemux: sbCmValChunk Failed\n"));

               SB_PUTMSG(chunkBuf);
               SB_CHK_PUTMSG(mBuf);
               RETVALUE(RFAILED);
            }

            ret = sbAsRcvError(assocCb, chunkLen, chunkBuf);
            if ( ret != ROK )
            {
               SB_CHK_PUTMSG(mBuf);
               RETVALUE(RFAILED);
            }
            break;

         case  SB_ID_COOKIE:
            /* COOKIE must be first chunk but may have more DATA */
            if ( firstChunkFlg == TRUE )
            {
               ret = sbCmValChunk(assocCb, vTag, chunkType, suConId,chunkFlags);
               if ( ret != ROK )
               {
                  SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                         "sbCmDemux: sbCmValChunk Failed\n"));

                  SB_PUTMSG(chunkBuf);
                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }
    /* sb060.102 - TOS enhancement */
#ifdef SCT4
              ret = sbAsRcvCookie(endpCb, peerAddr, peerPort, chunkBuf, vTag, 
                                  tos);

#else
               ret = sbAsRcvCookie(endpCb, peerAddr, peerPort, chunkBuf, vTag);
#endif /* SCT4 */
               if ( ret != ROK )
               {
                  SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                         "sbCmDemux: sbAsRcvCookie Failed\n"));

                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }
            }
            else  /* COOKIE not first chunk */
            {
               /* no more chunks allowed since something is wrong */
               SB_PUTMSG(chunkBuf);
               SB_CHK_PUTMSG(mBuf);
               RETVALUE(RFAILED);
            }
            firstChunkFlg = FALSE;
            /* sb022.102: Get the assocCb */
            sbCmResolveChunk(localPort, localAddr, peerPort, peerAddr,
                             &endpCb, &assocCb);
            break;

         case  SB_ID_COOKIEACK:
            /* COOKIE ACK must be first chunk but may have more DATA */
            if ( firstChunkFlg == TRUE )
            {
               ret = sbCmValChunk(assocCb, vTag, chunkType, suConId,chunkFlags);
               if ( ret != ROK )
               {
                  SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                         "sbCmDemux: sbCmValChunk Failed\n"));

                  SB_PUTMSG(chunkBuf);
                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }

               if ( chunkLen != 0 )
               {
                  SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                         "sbCmDemux: COOKIE ACK is wrong length\n"));
                  SB_PUTMSG(chunkBuf);
                  SB_CHK_PUTMSG(mBuf);
                  RETVALUE(RFAILED);
               }
               sbAsRcvCookieAck(assocCb);
            }
            else  /* COOKIE ACK not first chunk */
            {
               /* no more chunks allowed since something is wrong */
               SB_CHK_PUTMSG(mBuf);
               RETVALUE(RFAILED);
            }
            SB_PUTMSG(chunkBuf);
            firstChunkFlg = FALSE;
            break;

         case  SB_ID_ECNE:
            SB_PUTMSG(chunkBuf);
            break;

         case  SB_ID_CWR:
            SB_PUTMSG(chunkBuf);
            break;

         case  SB_ID_VSPEC:
            SB_PUTMSG(chunkBuf);
            break;

         case  SB_ID_IETF:
            SB_PUTMSG(chunkBuf);
            break;

         default:
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmDemux: Unrecognised Chunk Sending Operation Error \n"));

            ret = sbAsSendErrorUnrecogChunk(assocCb,chunkType, chunkFlags, chunkLen,
                                             chunkBuf);
            if ( ret != ROK )
            {
              SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                      "sbCmDemux: Failed to Send Error to Remote end - RFAILED  \n"));
              /* sb041: possible memory double deallocation */
              SB_CHK_PUTMSG(chunkBuf);
              SB_CHK_PUTMSG(mBuf);
              RETVALUE(RFAILED);
            }
            break;

      }

      /* lose the padding */
      for ( i = 0; i < pad; i++ )
      {
         SUnpkU8(&tmpU8, mBuf);
      }
      msgLen = (S16)(msgLen - pad);

      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmDemux: (chunkType(%d), chunkFlags(%x), chunkLen(%d), msgLen(%d), pad(%d))\n",
             chunkType, chunkFlags, chunkLen, msgLen, pad));

   }

    /* sb001.11 - Send SACK if atleast one data chunk is present */
    if(dataAssocCb != NULLP)
    {

       sctSap=sbGlobalCb.sctSaps[dataAssocCb->spId];
       dataAssocCb->sbAcCb.sinceSack++;

        /* send a stand alone SACK if in SHUTDOWN SENT state */
       if ( dataAssocCb->assocState == SB_ST_SDOWN_SENT )
       {
          /* send SACK (ackDelayTmr stopped in this function) */
          ret = sbAcSendSack(dataAssocCb);

          if ( ret != ROK )
          {
             SBDBGP(SB_DBGMASK_AC, (sbGlobalCb.sbInit.prntBuf,
                "sbCmDemux: Could not send SACK\n"));
             RETVALUE(RFAILED);
          }

          /* restart T2-shutdown timer with RTO value */
          SB_START_TMR(&(assocCb->sbAsCb.timer), &(assocCb->sbAsCb),
                          SB_TMR_SHUTDOWN, assocCb->sbAcCb.pri->rto);

       }
       else if ((dataAssocCb->sbAcCb.tsnLstSz > 0) ||
         (dataAssocCb->sbAcCb.sinceSack >= sctSap->sctSapCfg.reConfig.maxAckDelayDg) ||
         (dataAssocCb->sbAcCb.dupTsnLstSz > 0))
       {
         /* send SACK (ackDelayTmr stopped in this function) */
         ret = sbAcSendSack(dataAssocCb);
         if ( ret != ROK )
         {
           SBDBGP(SB_DBGMASK_AC, (sbGlobalCb.sbInit.prntBuf,
             "sbCmDemux: Could not send SACK\n"));
           RETVALUE(RFAILED);
         }
  /* Sack Timer is started when first unacked chunk is received */
       }
    }

   SB_CHK_PUTMSG(mBuf);
   RETVALUE(ROK);
}/* sbCmDemux() */


/*
*
*      Fun:   sbCmMakeChunk
*
*      Desc:  Create a Chunk structure from a received DATA message
*
*      Ret:   Success:                       ROK
*             Failure:                       RFAILED
*
*      Notes: <none>
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbCmMakeChunk
(
SbSctAssocCb    *assocCb,        /* Association on which it arrived */
U8               flags,          /* Chunk Flags */
Buffer          *chunkBuf,       /* Buffer */
SbQueuedChunk   *chunk           /* chunk structure to fill in */
)
#else
PUBLIC S16 sbCmMakeChunk(assocCb, flags, chunkBuf, chunk)
SbSctAssocCb    *assocCb;        /* Association on which it arrived */
U8               flags;          /* Chunk Flags */
Buffer          *chunkBuf;       /* Buffer */
SbQueuedChunk   *chunk;          /* chunk structure to fill in */
#endif
{

   /* local parameters */
   S16               ret;
   U32               tmpU32 = 0;
   U8                pkArray[12];
   U8                idx;
   MsgLen            msgLen;
   SctRtrvInfo       rtrvInfo;
   SbSctSapCb       *sctSap;


   TRC2(sbCmMakeChunk)

   SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
          "sbCmMakeChunk(spAssocId(%ld), flags(%d), chunkBuf)\n", assocCb->spAssocId, flags));

   /* E bit */
   if ( (flags & 0x01) == 0x01 )
   {
      chunk->endFlg = TRUE;
   }
   else
   {
      chunk->endFlg = FALSE;
   }
   /* B bit */
   if ( (flags & 0x02) == 0x02 )
   {
      chunk->startFlg = TRUE;
   }
   else
   {
      chunk->startFlg = FALSE;
   }

   /* sb051.102: Checking the error for SSI function call */
   ret = SFndLenMsg(chunkBuf, &msgLen);
   if(ret != ROK) 
   {
      SBDBGP( SB_DBGMASK_CM, ( sbGlobalCb.sbInit.prntBuf,
  	  "sbCmMakeChunk: Could not get the length of the buffer\n"));
      SB_PUTMSG(chunkBuf);
      RETVALUE( RFAILED );
   }

   if (msgLen < 12)
   {
      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmMakeChunk: received buffer too small for manadatory parameters\n"));
      SB_PUTMSG(chunkBuf);
      RETVALUE( RFAILED );
   }

   ret = SRemPreMsgMult(&pkArray[0], 12, chunkBuf);
   /* sb051.102: Checking for error conditions */
   if (ret != ROK)
   {
      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                "sbCmMakeChunk: PreMsgMult Failed for chunkBuf\n"));
      SB_PUTMSG(chunkBuf);
      RETVALUE( RFAILED );
   }

   idx = 0;

   /* unpack TSN */
   chunk->tsn = 0;     /* Initialize before unpacking */
   SB_UNPKU32(chunk->tsn);

   if(msgLen == 12)  /* NO User Data Abort Association */
   {
      sctSap = *(sbGlobalCb.sctSaps + assocCb->spId);

      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmMakeChunk: Sending Abort Message len too short %d\n", msgLen));

      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmMakeChunk: No User Data Received Aborting association \n"));
 
      SB_ZERO(&rtrvInfo, sizeof(SctRtrvInfo));

      SbUiSctTermInd( &(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                      SCT_ASSOCID_SU, SCT_STATUS_INV,
                     SCT_CAUSE_NOUSR_DATA, &rtrvInfo );
   /* sb021.102: Modification for TOS parameter */
#ifdef SCT3
      sbAsSendAbortNoData(assocCb->peerInitTag, assocCb->localConn,
                       &(assocCb->sbAcCb.sackAddr), assocCb->localPort,
                       assocCb->peerPort, FALSE, chunk->tsn, assocCb->tos);
#else
      sbAsSendAbortNoData(assocCb->peerInitTag, assocCb->localConn,
                       &(assocCb->sbAcCb.sackAddr), assocCb->localPort,
                       assocCb->peerPort, FALSE, chunk->tsn);
#endif /* SCT3 */
      
      /* Abort association without sending Abort */
      (Void) sbAsAbortAssoc(assocCb, FALSE);

      /* Remove assoc. from Global list and free memory */
      sbGlobalCb.assocCb[assocCb->spAssocId] = (SbSctAssocCb *) NULLP;
      SB_FREE(sizeof(SbSctAssocCb), assocCb);

      SB_PUTMSG(chunkBuf);
      RETVALUE( RFAILED );
   }

   /* check to see if the received TSN is valid */
   if ( SB_CHK_CUMTSN( assocCb->sbAcCb.cumPeerTsn, chunk->tsn) == RFAILED )
   {
      SB_PUTMSG(chunkBuf);

      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmMakeChunk: Invalid TSN (%lu), cumPeerTsn = %lu\n",
             chunk->tsn, assocCb->sbAcCb.cumPeerTsn));

      ret = sbAcInsDupTsn(assocCb, chunk->tsn);



      RETVALUE( RFAILED );
   }


   /* check to see if buffer space is still available */
   if ( (msgLen - 12) >  assocCb->sbAcCb.ownRWnd )
   {
      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmMakeChunk: message (%d) too big for local buffers available (%ld)",
             (msgLen - 12), assocCb->sbAcCb.ownRWnd));

      sbAcReneg(assocCb);

      if ( (msgLen - 12) >  assocCb->sbAcCb.ownRWnd )
      {
         sbSqRtrvUndel(assocCb);
      }

      if ( (msgLen - 12) >  assocCb->sbAcCb.ownRWnd )
      {
         SB_PUTMSG(chunkBuf);

         /* send SACK (ackDelayTmr stopped in this function) */
         ret = sbAcSendSack(assocCb);

         if ( ret != ROK )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmMakeChunk: Could not send SACK\n"));
            RETVALUE(RFAILED);
         }

         RETVALUE( RFAILED );
      }
   }

   if (sbGlobalCb.rxChunks >= sbGlobalCb.genCfg.maxNmbRxChunks)
   {
      SB_PUTMSG(chunkBuf);

      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmMakeChunk: maximum number of Rx chunks (%lu) already in use",
             sbGlobalCb.genCfg.maxNmbRxChunks));

      /* send SACK (ackDelayTmr stopped in this function) */
   /* sb021.102: Modification for TOS parameter */
#ifdef SCT3
      sbAsSendAbortRes(assocCb->peerInitTag,
                       assocCb->localConn,
                       &(assocCb->sbAcCb.sackAddr),
                       assocCb->localPort,
                       assocCb->peerPort, FALSE, assocCb->tos);
#else
      sbAsSendAbortRes(assocCb->peerInitTag,
                       assocCb->localConn,
                       &(assocCb->sbAcCb.sackAddr),
                       assocCb->localPort,
                       assocCb->peerPort, FALSE);
#endif /* SCT3 */

      /* Abort association without sending Abort */
      (Void) sbAsAbortAssoc(assocCb, FALSE);

      /* Remove assoc. from Global list and free memory */
      sbGlobalCb.assocCb[assocCb->spAssocId] = (SbSctAssocCb *) NULLP;
      SB_FREE(sizeof(SbSctAssocCb), assocCb);

      RETVALUE( RFAILED );
   }

   /* U bit */
   if ( (flags & 0x04) == 0x04 )
   {
      chunk->unorderedFlg = TRUE;

      /* stream stuff */
      SB_UNPKU32(tmpU32);
      chunk->stream = 0;
      chunk->seqNum = 0;
   }
   else
   {
      chunk->unorderedFlg = FALSE;
      /* stream stuff */
      SB_UNPKU16(chunk->stream);
      SB_UNPKU16(chunk->seqNum);
   }

   /* send stream ERROR if necessary */
   if ( chunk->stream > sbGlobalCb.genCfg.maxNmbInStrms )
   {
      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmMakeChunk: received DATA has incorrect stream number\n"));

      ret = sbAsSendErrorStrm(assocCb->peerInitTag,
                              &(assocCb->localConn->ownAddr),
                              &(assocCb->sbAcCb.pri->addr),
                              assocCb->localPort, assocCb->peerPort,
                              chunk->stream);

      if ( ret != ROK )
      {
         SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                "sbCmMakeChunk: could not send stream ERROR chunk\n"));

         if ( ret == ROUTRES )
         {
            /* get resource error */
            sbLmGenAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_SMEM_ALLOC_FAIL,
                         LCM_CAUSE_MEM_ALLOC_FAIL, 0, LSB_SW_RFC_REL0);
         }
      }
      SB_PUTMSG(chunkBuf);
      RETVALUE(RFAILED);
   }

   /* Protocol ID */
   chunk->protId = 0; /* Initialize before unpacking */
   SB_UNPKU32(chunk->protId);

   SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
         "sbCmMakeChunk: protId = %lu, stream = %u, seqNum = %u, tsn = %lu\n",
         chunk->protId, chunk->stream, chunk->seqNum, chunk->tsn));

   /* set other chunk values */
   chunk->noBundleFlg  = FALSE;
   chunk->resendFlg    = FALSE;
   chunk->sendFlg      = FALSE;
   chunk->dfFlg        = FALSE;
   chunk->qState       = SB_DB_INVALQ;
   chunk->holeCnt      = 0;
   chunk->lifetime     = 0;
   chunk->time         = 0;
   chunk->addrCb       = assocCb->sbAcCb.pri;
   chunk->spAssocId    = assocCb->spAssocId;
   chunk->endpId       = assocCb->endpId;
   chunk->mBuf         = chunkBuf;
   chunkBuf            = (Buffer *) NULLP;

   /* we do NOT initialize the lifetime timer */

   RETVALUE(ROK);
}/* sbCmMakeChunk() */

/*
*
*      Fun:   sbCmResolveChunk
*
*      Desc:  Resolves the endpoint and association for an incoming message
*
*      Ret:   Success:     ROK
*             Failure:     RFAILED
*
*      Notes: <none>
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbCmResolveChunk
(
SctPort          localPort,      /* local port on which message arrived */
CmNetAddr       *localAddr,      /* local address on which message arrived */
SctPort          peerPort,       /* peer port from where message came */
CmNetAddr       *peerAddr,       /* peer address from where message came */
SbSctEndpCb    **endpCbPtr,      /* Endpoint on which it arrived */
SbSctAssocCb   **assocCbPtr      /* Association on which it arrived */
)
#else
PUBLIC S16 sbCmResolveChunk(localPort, localAddr, peerPort, peerAddr,
                            endpCbPtr, assocCbPtr)
SctPort          localPort;      /* local port on which message arrived */
CmNetAddr       *localAddr;      /* local address on which message arrived */
SctPort          peerPort;       /* peer port from where message came */
CmNetAddr       *peerAddr;       /* peer address from where message came */
SbSctEndpCb    **endpCbPtr;      /* Endpoint on which it arrived */
SbSctAssocCb   **assocCbPtr;     /* Association on which it arrived */
#endif
{
   /* local parameters */
   S16               ret;
   SbSctEndpCb       tmpEndpCb;
   SbAssocMapCb     *assocMap;
   SbAssocMapCb      tmpAssocMap;
   /* sb046.102: Multiple IP address per Endp */
   /* sb049.102 : Initialization of addrPortCb */
   SbAddrPortCb     *addrPortCb=NULLP;
   SbAddrPortEntry   tmpAddrPortEntry;
   /* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
   S8                ipv6Addr1[SB_IPV6STR_SIZE];
   S8                ipv6Addr2[SB_IPV6STR_SIZE];
   U8                *tempIpv6Addr;
#endif

   TRC2(sbCmResolveChunk)

   /* bug fix - zero out assocmap */    
   SB_ZERO(&(tmpAssocMap), sizeof(SbAssocMapCb));

   /* sb001.12 : Addition - Zero out the assocMap */
   SB_ZERO(&(tmpEndpCb), sizeof(SbSctEndpCb));
   
   /* sb046.102: Multiple IP address per Endp */
   SB_ZERO(&(tmpAddrPortEntry), sizeof(SbAddrPortEntry));
   tmpAddrPortEntry.localAddr.type = localAddr->type;
   tmpAddrPortEntry.port = localPort;

   addrPortCb = (SbAddrPortCb *)NULLP;

   /* First lookup is for an IP_ANY+port match - the most common case */
   /* sb049.102 : Hash list problem resolved */
   ret = cmHashListFind(&(sbGlobalCb.addrPortHl), (U8 *) &(tmpAddrPortEntry),
                        (U16) sizeof(SbAddrPortEntry),
                        0, (PTR *) &addrPortCb);

   if (ret != ROK)
   {
      /* Second lookup is for a specific IP transport address match */
      SB_MAKE_NADDR_CPY(&(tmpAddrPortEntry.localAddr), localAddr);
      /* Find the AddrPortCb to which this chunk is destined to */
      /* sb049.102 : Hash list problem resolved */
      ret = cmHashListFind(&(sbGlobalCb.addrPortHl), (U8 *) &(tmpAddrPortEntry),
                           (U16) sizeof(SbAddrPortEntry),
                           0, (PTR *) &addrPortCb);
   }

   if ( ret == ROK )
   {
      (*endpCbPtr) = sbGlobalCb.endpCb[addrPortCb->spEndpId];

      /* we now have the addrPortCB, thus maps to a EndpCb */
      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmResolveChunk: found spEndpId(%ld)\n", addrPortCb->spEndpId));

      /* Find the association Map to which this chunk is destined to */

      /* sb001.12 : Updation  - Byte alignment change */
      /* sb023.102 - Removing the SB_ZERO for Assoc Entry stucture because
       * the parent strcuture is already zeroed out above */
      tmpAssocMap.sbAssocEntry.spEndpId = (*endpCbPtr)->spEndpId;
      /* sb023.102 - Changed the macro SB_CPY_NADDR to below because we don't
       * want to do cmMemcpy here becuase it will be already done above 
       * - Performance Change */
      SB_MAKE_NADDR_CPY(&(tmpAssocMap.sbAssocEntry.peerAddr), peerAddr);
      tmpAssocMap.sbAssocEntry.port = peerPort;
      assocMap = (SbAssocMapCb *) NULLP;

      ret = cmHashListFind(&(sbGlobalCb.assocMapHl),
                           (U8 *) &(tmpAssocMap.sbAssocEntry),
                           sizeof(SbAssocMapEntry), 0, (PTR *) &assocMap);


      if ( ret == ROK )
      {
         /* we now have the association map */
         SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                "sbCmResolveChunk: found assocMap(spAssocId(%ld))\n", assocMap->spAssocId));

         /* find the association from this association map */

         *assocCbPtr = sbGlobalCb.assocCb[assocMap->spAssocId];
      }
      else
      {
         if(tmpAssocMap.sbAssocEntry.peerAddr.type == CM_NETADDR_IPV4)
        {
       /* sb001.12 : Updation  - Byte alignment change */
         SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
        "sbCmResolveChunk: Could not find assocMap(spEndpId(%ld), peerPort(%d), peerAddr(%08lX))\n",
         tmpAssocMap.sbAssocEntry.spEndpId, tmpAssocMap.sbAssocEntry.port,
         tmpAssocMap.sbAssocEntry.peerAddr.u.ipv4NetAddr));
         }
   /* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
        if(tmpAssocMap.sbAssocEntry.peerAddr.type == CM_NETADDR_IPV6)
        {
           tempIpv6Addr = tmpAssocMap.sbAssocEntry.peerAddr.u.ipv6NetAddr;
           SB_CPY_IPV6ADSTR(ipv6Addr1, tempIpv6Addr)
         SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
        "sbCmResolveChunk: Could not find assocMap(spEndpId(%ld), peerPort(%d), peerAddr(%s))\n",
         tmpAssocMap.sbAssocEntry.spEndpId, tmpAssocMap.sbAssocEntry.port,
         ipv6Addr1));
        }
#endif
      }
   }
   else
   {
      /* endpoint control block not found */
      /* sb006.102: Updation - modified for alignment */ 
      if(tmpAddrPortEntry.localAddr.type == CM_NETADDR_IPV4)
      {
      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmResolveChunk: Could not find addrPortCb(localport(%u), localaddr(%08lX))\n",
             tmpAddrPortEntry.port, tmpAddrPortEntry.localAddr.u.ipv4NetAddr));
      }
   /* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
      if(tmpAddrPortEntry.localAddr.type == CM_NETADDR_IPV6)
      {
          tempIpv6Addr = tmpAddrPortEntry.localAddr.u.ipv6NetAddr;
         SB_CPY_IPV6ADSTR(ipv6Addr2, tempIpv6Addr) 
      SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
             "sbCmResolveChunk: Could not find endpoint(localport(%u), localaddr(%s))\n",
             tmpAddrPortEntry.port, ipv6Addr2));
      }
#endif

      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* sbCmResolveChunk() */

/*
*
*      Fun:   sbCmValChunk
*
*      Desc:  Decides whether enough info checks out to process the
*             chunk further
*
*      Ret:   Success:           ROK
*             Failure:           RFAILED
*             Silently Discard:  RIGNORE
*
*      Notes: The endpoint has already been resolved by the time this
*             function is called
*
*      File:  sb_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 sbCmValChunk
(
SbSctAssocCb    *assocCb,        /* Association on which it arrived */
U32              vTag,           /* verification tag */
U8               chunkId,        /* chunk type */
UConnId          suConId,         /* TUCL connection ID */
U8               chunkFlags       /* Chunk Flags */
)
#else
PUBLIC S16 sbCmValChunk(assocCb, vTag, chunkId, suConId, chunkFlags)
SbSctAssocCb    *assocCb;        /* Association on which it arrived */
U32              vTag;           /* verification tag */
U8               chunkId;        /* chunk type */
UConnId          suConId;        /* TUCL connection ID */
U8               chunkFlags;      /* Chunk Flags */
#endif
{
   /* local parameters */
   SbLocalAddrCb *localAddrCb;
   SuId           suId;

   TRC2(sbCmValChunk)

   SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
          "sbCmValChunk(assocCb, vTag(%lu), chunkId(%u), suConId(%lu))\n", vTag, chunkId, suConId));

   suId = 0;

   /* find a corresponding local adderess control block (for statistics) */
   if ( ( chunkId == SB_ID_INIT ) ||
        ( chunkId == SB_ID_SDOWN ) ||
        ( chunkId == SB_ID_COOKIE ) )
   {
      if (suConId < sbGlobalCb.genCfg.maxNmbSrcAddr)
      {
         localAddrCb = *(sbGlobalCb.localAddrCb + suConId);
      }
      else
      {
         localAddrCb = *(sbGlobalCb.localAddrCb + suConId - sbGlobalCb.genCfg.maxNmbSrcAddr);
      }

#if (ERRCLASS & ERRCLS_DEBUG)
      if ( localAddrCb == (SbLocalAddrCb *)NULLP )
      {
         SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                "sbCmValChunk: could not find a local address CB\n"));
         RETVALUE(RIGNORE);
      }
#endif

      suId = localAddrCb->suId;
   }

   switch ( chunkId )
   {
      case SB_ID_DATA :
      {
         if ( assocCb == (SbSctAssocCb *) NULLP )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: assocCb is NULL, therefore OOTB chunk\n"));

            RETVALUE(RFAILED);
         }
         /* sb036.102: Data should be dumped if the state is not established */
         if (((assocCb->assocState != SB_ST_ESTABLISHED) &&
              (assocCb->assocState != SB_ST_SDOWN_PEND) &&
              /* sb043.102: Data should be not dumped in SDOWN_SENT */
              (assocCb->assocState != SB_ST_SDOWN_SENT)) ||
              ( vTag != assocCb->ownInitTag ))
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: vTag != assocCb->ownInitTag, must discard chunk\n"));

            RETVALUE(RIGNORE);
         }
         /* update statistics counters since DATA is valid */
         sbGlobalCb.genSts.sbChunkSts.noDataRx++;
         sbGlobalCb.tSaps[assocCb->localConn->suId]->tSts.sbChunkSts.noDataRx++;
         break;
      }

      case SB_ID_INIT :
      {
         /* verification Tag check */
         if ( vTag != 0x0000 )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: vTag invalid for SB_ID_INIT\n"));

            RETVALUE(RIGNORE);
         }
         /* update statistics counters since INIT is valid */
         sbGlobalCb.genSts.sbChunkSts.noInitRx++;
         sbGlobalCb.tSaps[suId]->tSts.sbChunkSts.noInitRx++;
         break;
      }

      case SB_ID_INITACK :
      {
         if ( assocCb == (SbSctAssocCb *) NULLP )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: assocCb is NULL, but is needed for further processing\n"));

            RETVALUE(RIGNORE);
         }
         if ( vTag != assocCb->ownInitTag )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: vTag != assocCb->ownInitTag, must discard chunk\n"));

            RETVALUE(RIGNORE);
         }

         /* update statistics counters */
         sbGlobalCb.genSts.sbChunkSts.noIAckRx++;
         sbGlobalCb.tSaps[assocCb->localConn->suId]->tSts.sbChunkSts.noIAckRx++;
         break;
      }

      case SB_ID_SACK :
      {
         if ( assocCb == (SbSctAssocCb *) NULLP )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: assocCb is NULL, but is needed for further processing\n"));

            RETVALUE(RIGNORE);
         }
         if ( vTag != assocCb->ownInitTag )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: vTag != assocCb->ownInitTag, must discard chunk\n"));

            RETVALUE(RIGNORE);
         }

         /* update statistics counters since ACK is valid */
         sbGlobalCb.genSts.sbChunkSts.noDAckRx++;
         sbGlobalCb.tSaps[assocCb->localConn->suId]->tSts.sbChunkSts.noDAckRx++;
         break;
      }

      case SB_ID_HBEAT :
      {
         if ( assocCb == (SbSctAssocCb *) NULLP )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: assocCb is NULL, but is needed for further processing\n"));

            RETVALUE(RIGNORE);
         }
         if ( vTag != assocCb->ownInitTag )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: vTag != assocCb->ownInitTag, must discard chunk\n"));

            RETVALUE(RIGNORE);
         }

/* sb018.102 Heartbeat statistics added */
#ifdef LSB2
        /* update statistics counters since ACK is valid */
        sbGlobalCb.genSts.sbChunkSts.noHBeatRx++;
        sbGlobalCb.tSaps[assocCb->localConn->suId]->tSts.sbChunkSts.noHBeatRx++;
#endif

         break;
      }

      case SB_ID_HBEATACK :
      {
         if ( assocCb == (SbSctAssocCb *) NULLP )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: assocCb is NULL, but is needed for further processing\n"));

            RETVALUE(RIGNORE);
         }
         if ( vTag != assocCb->ownInitTag )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: vTag != assocCb->ownInitTag, must discard chunk\n"));

            RETVALUE(RIGNORE);
         }

/* sb018.102 Heartbeat statistics added */
#ifdef LSB2
        /* update statistics counters since HB Ack is valid */
        sbGlobalCb.genSts.sbChunkSts.noHBAckRx++;
        sbGlobalCb.tSaps[assocCb->localConn->suId]->tSts.sbChunkSts.noHBAckRx++;
#endif

         break;
      }

      case SB_ID_ABORT :
      {
         if ( assocCb == (SbSctAssocCb *) NULLP )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: assocCb is NULL, but is needed for further processing\n"));

            RETVALUE(RIGNORE);
         }
         if ( (vTag != assocCb->ownInitTag) &&
              (vTag != assocCb->peerInitTag) )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: vTag != assocCb->ownInitTag || peerInitTag, must discard chunk\n"));

            RETVALUE(RIGNORE);
         }
/* sb052.102 Abort Statistics added*/
#ifdef LSB3
        sbGlobalCb.genSts.sbChunkSts.noAbortRx++;
        sbGlobalCb.tSaps[assocCb->localConn->suId]->tSts.sbChunkSts.noAbortRx++;
#endif
         break;
      }

      case SB_ID_SDOWN :
      {
         if ( (vTag != 0x0000) && (vTag != assocCb->ownInitTag) )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: vTag != assocCb->ownInitTag || 0, must discard chunk\n"));

            RETVALUE(RIGNORE);
         }
         /* update statistics counters */
         sbGlobalCb.genSts.sbChunkSts.noShDwnRx++;
         sbGlobalCb.tSaps[suId]->tSts.sbChunkSts.noShDwnRx++;

         break;
      }

      case SB_ID_SDOWNACK :
      {
         if ( assocCb == (SbSctAssocCb *) NULLP )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: assocCb is NULL, but is needed for further processing\n"));

            RETVALUE(RIGNORE);
         }
         if ( (vTag != assocCb->ownInitTag) ||
              (vTag == 0) )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: vTag != assocCb->ownInitTag || 0, must discard chunk\n"));
            RETVALUE(RFAILED);
         }

         /* update statistics counters */
         sbGlobalCb.genSts.sbChunkSts.noShDwnAckRx++;
         sbGlobalCb.tSaps[assocCb->localConn->suId]->tSts.sbChunkSts.noShDwnAckRx++;
         break;
      }

      case SB_ID_ERROR :
      {
         if ( assocCb == (SbSctAssocCb *) NULLP )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: assocCb is NULL, but is needed for further processing\n"));

            RETVALUE(RIGNORE);
         }
         if ( vTag != assocCb->ownInitTag )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: vTag != assocCb->ownInitTag, must discard chunk\n"));

            RETVALUE(RIGNORE);
         }
/* sb068.102 Error Statistics added*/
#ifdef LSB6
        sbGlobalCb.genSts.sbChunkSts.noErrorRx++;
        sbGlobalCb.tSaps[assocCb->localConn->suId]->tSts.sbChunkSts.noErrorRx++;
#endif/* LSB6 */

         break;
      }

      case SB_ID_COOKIE :
      {
         /* endpoint already checked */
         /* vTag checked once TCB recreated */

         /* update statistics counters */
         sbGlobalCb.genSts.sbChunkSts.noCookieRx++;
         sbGlobalCb.tSaps[suId]->tSts.sbChunkSts.noCookieRx++;
         break;
      }

      case SB_ID_COOKIEACK :
      {
         if ( assocCb == (SbSctAssocCb *) NULLP )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: assocCb is NULL, but is needed for further processing\n"));

            RETVALUE(RIGNORE);
         }
         if ( vTag != assocCb->ownInitTag )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                   "sbCmValChunk: vTag != assocCb->ownInitTag, must discard chunk\n"));

            RETVALUE(RIGNORE);
         }

         /* update statistics counters since INIT is valid */
         sbGlobalCb.genSts.sbChunkSts.noCkAckRx++;
         sbGlobalCb.tSaps[assocCb->localConn->suId]->tSts.sbChunkSts.noCkAckRx++;
         break;
      }

      case SB_ID_SDOWNCMPLT :
      {
         if ( assocCb == (SbSctAssocCb *) NULLP )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
              "sbCmValChunk: SHUTDOWN_CMPLT Rcvd but assocCb is NULL,\n"));

            RETVALUE(RIGNORE);
         }
         if ( (vTag != assocCb->ownInitTag) &&
               ((vTag != assocCb->peerInitTag) && (!(chunkFlags & 0x01))) && 
              (vTag == 0) )
         {
            SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
              "sbCmValChunk: SDOWNCMPLT Chunk : Tag Not Matched \n"));

            RETVALUE(RIGNORE);
         }

         /* update statistics counters */ 
         sbGlobalCb.genSts.sbChunkSts.noShDwnCmpltRx++;
         sbGlobalCb.tSaps[assocCb->localConn->suId]->tSts.sbChunkSts.noShDwnCmpltRx++;
         break;
      }

      default:
      {
         SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
                "sbCmValChunk: Invalid chunkId\n"));

         RETVALUE(RIGNORE);
         break;
      }
   }

   SBDBGP(SB_DBGMASK_CM, (sbGlobalCb.sbInit.prntBuf,
          "sbCmValChunk: ROK\n"));

   RETVALUE(ROK);
} /* sbCmValChunk() */



/********************************************************************30**

         End of file:     sb_bdy2.c@@/main/2 - Wed Jan 10 16:25:55 2001

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:

*********************************************************************61*/
/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
 /main/2     ---    bk    1. initial skeleton draft.
 /main/2     ---    sb    1. Modified for SCTP release based on 
                             RFC-2960 'Oct 2000.
         sb001.12   sb    1. Alignment fix done for AssocMap.
                          2. Memory Initialisation done.
         sb002.12   nj    1. If all the dest addresses are inactive in an
                             association then bring down the association.
         sb004.12   sb    1. In function sbPmAddAddr, don't add address is
                             it already  exist in an association.
         sb006.102  rs    1. Updation - modified for alignment in
                             sbSctEndpEntry
         sb007.102  ap    1. Memory leak problem fixed for sbVaDatInd
         sb014.102  ap    1. Terminate association when all addresses 
                             are down.
         sb018.102  ab    1. Heartbeat statistics added.
         sb020.102  rs    1. Padding problem solved for heart beat.
                          2. NULLP problem for addressCb.
                          3. SCT Path Active is properly compared.
         sb021.102  rs    1. Modification for TOS parameter.
         sb022.102  rs    1. Retrive assocCb after COOKIE is processed.
         sb023.102  sb    1. Changed done in Mtu for Performance.
         sb024.102  kk    1. Memory leak problem fixed for duplicate data.
         sb026.102  kk    1. Send SACK for duplicate data.
         sb027.102  rs    1. Solves the core dump problem, double memory release.
                          2. Removed TAB
         sb028.102  hm    1. Changes to allow freeze timer to be zero
         sb029.102  hm    1. Changes to check data address with sack address
         sb030.102  kk    1. Checks that data bundling should not exceed MTU
         sb031.102  hm    1. IPV6 Support Added
         sb036.102  rs    1. Dump the data if assoc is not established
         sb040.102  rs    1. Do not check cwnd for Retransmission.
         sb041.102  hl    1. remove the errcls parameter check flag 
         sb042.102  hl    1. Added change for SHT interface
         sb043.102  hl    1. Data should be not dumped in SDOWN_SENT state
         sb046.102  hl    1. Multiple IP address per endpoint support
                          2. Alwasy notify retrievel info to user in case
                             of abort.
         sb047.102  hl    1. The heartbeat mechanism is modified.
         sb049.102  rs    1. Hash list problem resolved.
         sb051.102  ag    1. SSI return values checked.
         sb052.102  ag    1. Abort Statistics added.
         sb054.102  rk    1. Bundling Changes
         sb055.102  ag    1. HearBeat Changes
                          2. Bundling Timer change
         sb056.102  rk    1. In case of primary dest address failure
                             try assoc on alternate dest addr of
                             address list
         sb058.102  pr    1. Removed compilation warning.
         sb060.102  pr    1. Tos enhancement.
         sb064.102  pr    1. Deleted lines that free NULL buf.
         sb068.102  kp    1. Addition of Error Statistics. 
			  2. Removed SB_GET_NEXT_LOCAL_CONN() 
			     call from ERRCLS_DEBUG 
         sb069.102  kp    1. Decrementing txChunks counter 
 			  2. Fetch hbeatInt from sctsap reconfiguration if changed
*********************************************************************91*/
