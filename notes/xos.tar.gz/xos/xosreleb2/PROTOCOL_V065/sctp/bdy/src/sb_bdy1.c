/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**

     Name:    SCTP Layer (SCTP)

     Type:    C source file

     Desc:    Code for Upper Interface and Management Interface
              primitives supplied by TRILLIUM

     File:    sb_bdy1.c

     Sid:      sb_bdy1.c@@/main/2 - Wed Jan 10 16:26:15 2001

     Prg:     asa

*********************************************************************21*/

/***********************************************************************

    Functions contained in sb_bdy1.c

    PUBLIC S16 sbActvInit(entity, inst, region, reason)
    PUBLIC S16 sbActvTmr()
    PUBLIC S16 sbTmrEvnt(cb, evnt)

    PUBLIC S16 SbMiLsbCfgReq(pst, cfg)
    PUBLIC S16 SbMiLsbCntrlReq(pst, cntrl)
    PUBLIC S16 SbMiLsbStaReq(pst, sta)
    PUBLIC S16 SbMiLsbStsReq(pst, action, sts)

    PUBLIC S16 SbUiSctBndReq(pst, suId, spId)
    PUBLIC S16 SbUiSctEndpOpenReq(pst, spId, suEndpId, port, intfNAddr)
    PUBLIC S16 SbUiSctEndpCloseReq(pst, spId, endpId, endpIdType)
    PUBLIC S16 SbUiSctAssocReq(pst, spId, spEndpId, suAssocId, priDstNAddr,
    PUBLIC S16 SbUiSctAssocRsp(pst, spId, suId, spEndpId, assocIndParams,
                               result)
    PUBLIC S16 SbUiSctTermReq(pst, spId, assocId, assocIdType, abortFlg)
    PUBLIC S16 SbUiSctSetPriReq(pst, spId, spAssocId, dstNAddr)
    PUBLIC S16 SbUiSctHBeatReq(pst, spId, spAssocId, dstNAddr, intervalTime,
                               status)
    PUBLIC S16 SbUiSctDatReq(pst, spId, spAssocId, dstNAddr, strmId,
                             unorderFlg, nobundleFlg, lifeTime, protId, mBuf)
    PUBLIC S16 SbUiSctStaReq(pst, spId, spAssocId, dstNAddr, staType)

    PUBLIC S16 SbLiHitConCfm(pst, suId, cntrl, suConId, spConId, localAddr)
    * Patch sb031.102 IPV6 Support Added *
    PUBLIC S16 SbLiHitUDatInd(pst, suId, suConId, srcAddr, dstAddr, hdrParm,
#ifdef LOCAL_INTF
                              localIf, 
#endif
                              mBuf)
    PUBLIC S16 SbLiHitDiscInd(pst, suId, choice, conId, reason)
    PUBLIC S16 SbLiHitDiscCfm(pst, suId, choice, conId, action)
    PUBLIC S16 SbLiHitConInd(pst, suId, servConId, spConId, peerAddr)
    PUBLIC S16 SbLiHitFlcInd(pst, suId, reason)
    PUBLIC S16 SbLiHitDatInd(pst, suId, suConId, mBuf)
    PUBLIC S16 SbLiHitBndCfm(pst, suId, status)

***********************************************************************/


/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_tpt.h"        /* common transport defines */
#include "cm_dns.h"        /* Common DNS library */
#ifdef SB_FTHA
#include "sht.h"           /* SHT Interface header file */
#endif /* SB_FTHA */
#include "lsb.h"           /* layer management, SCTP  */
#include "sct.h"           /* SCT interface */
#include "hit.h"           /* HIT interface */
#include "sb_port.h"
#include "sb_mtu.h"
#include "sb.h"            /* SCTP internal defines */
#include "sb_err.h"        /* SCTP error */

/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_tpt.x"        /* common transport */
#include "cm_dns.x"        /* Common DNS library */
#ifdef SB_FTHA
#include "sht.x"           /* SHT Interface header file */
#endif /* SB_FTHA */
#include "sct.x"           /* SCT interface */
#include "lsb.x"           /* layer management SCTP */
#include "hit.x"           /* HIT interface */
#include "sb_port.x"
#include "sb_mtu.x"
#include "sb.x"            /* SCTP internal typedefs */



extern void sbCfgInit(void);
/* Public variable declarations */
#ifdef SS_MULTIPLE_PROCS
PUBLIC SbGlobalCb sbGlobalCbLst[SB_MAX_INSTANCES];
PUBLIC SbGlobalCb *sbGlobalCbPtr;
#else
PUBLIC SbGlobalCb  sbGlobalCb;  /* SCTP control block */
#endif /* SS_MULTIPLE_PROCS */

#ifdef SSI_WITH_CLI_ENABLED
/* function prototypes */
EXTERN Bool XOS_CLIRegCommand_SB(Void);
/* functions */
#endif

EXTERN U32 g_sbDbgMask;
/* ------------------------------------------------------------------*/
/* Interface Functions to System Services
 */

/*
*
*      Fun:   Activate Task - initialize
*
*      Desc:  Invoked by system services to initialize a task.
*
*      Ret:   ROK
*
*      Notes: None
*
*      File:  sb_bdy1.c
*
*/

#ifdef SS_MULTIPLE_PROCS
#ifdef ANSI
PUBLIC S16 sbActvInit
(
ProcId  proc,           /* procId */
Ent     entity,         /* entity */
Inst    inst,           /* instance */
Region  region,         /* region */
Reason  reason,         /* reason */
Void    **xxCb          /* protocol control block */
)
#else  
PUBLIC S16 sbActvInit(proc, entity, inst, region, reason, xxCb)
ProcId  proc;           /* procId */
Ent     entity;         /* entity */
Inst    inst;           /* instance */
Region  region;         /* region */
Reason  reason;         /* reason */
Void    **xxCb;         /* protocol control block */
#endif
#else  /* SS_MULTIPLE_PROCS */
#ifdef ANSI
PUBLIC S16 sbActvInit
(
Ent entity,            /* entity */
Inst inst,             /* instance */
Region region,         /* region */
Reason reason          /* reason */
)
#else
PUBLIC S16 sbActvInit(entity, inst, region, reason)
Ent entity;            /* entity */
Inst inst;             /* instance */
Region region;         /* region */
Reason reason;         /* reason */
#endif
#endif  /* SS_MULTIPLE_PROCS */
{
   /* local variables */
#ifdef SS_MULTIPLE_PROCS
   U16 i = 0;
   PRIVATE U16 sbNumCallsToInit = 0;
#endif /* SS_MULTIPLE_PROCS */
   U8                idx;
 
   TRC2(sbActvInit)

#ifdef SS_MULTIPLE_PROCS

   if(reason != SHUTDOWN)
   {
     if( !sbNumCallsToInit )
     {
       for(i=0;i<SB_MAX_INSTANCES;i++)
       {
         SB_ZERO((Data *)&sbGlobalCbLst[i],(S32)sizeof(SbGlobalCb));
       }
     }

     if( sbNumCallsToInit >= SB_MAX_INSTANCES )
     {
       RETVALUE(FALSE);
     }

     sbGlobalCbPtr = &sbGlobalCbLst[sbNumCallsToInit];
     *xxCb = (void *)&sbGlobalCbLst[sbNumCallsToInit];
     sbGlobalCbPtr->used = TRUE;
     sbNumCallsToInit++;
   }
#endif /*SS_MULTIPLE_PROCS*/

   SBDBGP(DBGMASK_SI, (sbGlobalCb.sbInit.prntBuf,
          "sbActvInit(Ent(%d), Inst(%d), Region(%d), Reason(%d))\n",
           entity, inst, region, reason));

   /* Initialize the SCTP control block */

   SB_ZERO(&sbGlobalCb, sizeof(sbGlobalCb));

   sbGlobalCb.sbInit.ent = entity;
   sbGlobalCb.sbInit.inst = inst;
   sbGlobalCb.sbInit.region = region;
   sbGlobalCb.sbInit.reason = reason;
   sbGlobalCb.sbInit.cfgDone = FALSE;

   /* Pool Id is obtained after SGetSMem in general configuration */
   sbGlobalCb.sbInit.pool = 0;

#ifndef SS_MULTIPLE_PROCS
   sbGlobalCb.sbInit.procId = SFndProcId();
#else
   sbGlobalCb.sbInit.procId = proc;
#endif /*SS_MULTIPLE_PROCS*/

   sbGlobalCb.sbInit.acnt = FALSE;
   sbGlobalCb.sbInit.usta = TRUE;
   sbGlobalCb.sbInit.trc =  FALSE;

   /* Initialize timing queue */
   sbGlobalCb.sbTqCp.nxtEnt = 0;
   sbGlobalCb.sbTqCp.tmrLen = SB_TQSIZE;

   for (idx = 0; idx < SB_TQSIZE; idx++)
   {
      sbGlobalCb.sbTq[idx].first = NULLP;
   }

#ifdef DEBUGP
/* sb018.102 dbgMask initialized to 0 */
   sbGlobalCb.sbInit.dbgMask = 0x0;
#endif /* DEBUGP */

/* sb048.102 dbgMask initialized to ffffffff *
 * if the code is compiled with SB_DEBUGP    */
#ifdef SB_DEBUGP
   sbGlobalCb.sbInit.dbgMask = g_sbDbgMask;
#endif /* SB_DEBUGP */
   sbCfgInit();
#ifdef SSI_WITH_CLI_ENABLED
	XOS_CLIRegCommand_SB();
#endif /* DEBUGP */

   /* sbInit.lmPst is initialised in general configuration */
   /* perform external initialization, if needed */
   sbInitExt();

   RETVALUE(ROK);
}/* end of sbActvInit */

/*
*
*       Fun:   Activate Task - timer
*
*       Desc:  Invoked by system services to activate a task with
*              a timer tick.
*
*       Ret:   ROK      - ok
*
*       Notes: <none>
*
*       File:  sb_bdy1.c
*
*/
#ifdef SS_MULTIPLE_PROCS
#ifdef ANSI
PUBLIC S16 sbActvTmr
(
ProcId proc,
Ent    ent,
Inst   inst
)
#else
PUBLIC S16 sbActvTmr(proc, ent, inst)
ProcId proc;
Ent    ent;
Inst   inst;
#endif
#else  /* SS_MULTIPLE_PROCS */
#ifdef ANSI
PUBLIC S16 sbActvTmr
(
Void
)
#else
PUBLIC S16 sbActvTmr()
#endif
#endif  /* SS_MULTIPLE_PROCS */
{
   TRC2(sbActvTmr)
#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(proc, ent, inst, (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "sbActvTmr () failed, cannot derive sbCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_SI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         proc, ent, inst));

#endif /* SS_MULTIPLE_PROCS */

   cmPrcTmr(&sbGlobalCb.sbTqCp, sbGlobalCb.sbTq, (PFV)sbTmrEvnt);

   RETVALUE(ROK);
}


/*
*
*       Fun:   sbTmrEvnt
*
*       Desc:  This function is used to process the expiry of SCTP
*              timer events.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <none>
*
*       File:  sb_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 sbTmrEvnt
(
PTR  cb,                  /* control block */
S16 evnt                  /* timer number */
)
#else
PUBLIC S16 sbTmrEvnt(cb, evnt)
PTR  cb;                  /* control block */
S16 evnt;                 /* timer number */
#endif
{
   S16 err;

   TRC2(sbTmrEvnt);

   err = ROK;

   /* sb064.102 : Remove compiler warnings */

   switch (evnt)
   {
      case SB_TMR_LIFETIME:
         err = sbSqLifetimeTO((SbQueuedChunk *)cb);
         break;
      case SB_TMR_T3RTX:
         err = sbAcRTO((SbAddrCb *)cb);
         break;
      case SB_TMR_ACKDELAY:
         err = sbAcSackTO((SbSctAssocCb  *)cb);
         break;
      case SB_TMR_SHUTDOWN:
         err = sbAsSDownTO((SbSctAssocCb *)cb);
         break;
      case SB_TMR_INIT:
         err = sbAsInitTO((SbSctAssocCb *)cb);
         break;
      case SB_TMR_COOKIE:
         err = sbAsCookieTO((SbSctAssocCb *)cb);
         break;
      case SB_TMR_HBEAT:
         err = sbPmHBeatTO((SbAddrCb *)cb);
         break;
      case SB_TMR_KEY:
         err = sbAsKeyTO();
         break;
      case SB_TMR_TSAP_BND:
         err = sbLiBndTO((SbTSapCb *)cb);
         break;
      case SB_TMR_FREEZE:
         err = sbAsFreezeTO((SbSctAssocCb *)cb);
         break;
      case SB_TMR_MTU_INC:
         err = sbMtuIncMtu((SbMtuCp *)cb);
         SB_START_TMR(&(sbGlobalCb.mtuIncTmr),  &(sbGlobalCb.mtuCp),
                      SB_TMR_MTU_INC, SB_MTU_INC_MTU)
         break;
      case SB_TMR_MTU_INC_UP:
         err = sbMtuIncMtuUpper((SbMtuCp *)cb);
         SB_START_TMR(&(sbGlobalCb.mtuIncTmrUp),  &(sbGlobalCb.mtuCp),
                      SB_TMR_MTU_INC_UP, SB_MTU_INC_MTU_UPPER)
         break;

      case SB_TMR_SHUTDOWNACK:
         err = sbAsSDownAckTO((SbSctAssocCb *)cb);
         break;
      
      case SB_TMR_AWT_DNS_RSP:
         err = sbAsDnsRspTO((SbSctAssocCb *)cb);
         break;

     /* sb054.102 : Addition - Bundling Changes */
#ifdef LSB4
      case SB_TMR_BUNDLE:
         err = sbAsBundleTO((SbSctAssocCb *)cb);
         break;
#endif

      default:

#if (ERRCLASS & ERRCLS_DEBUG)

         SBLOGERROR( ERRCLS_DEBUG,
                     ESB001,
                     (ErrVal) 0,
                     "sbTmrEvnt(): Invalid timer event" );

         RETVALUE( RFAILED );

#endif /* ERRRCLS_DEBUG */

         break;
   }

#if (ERRCLASS & ERRCLS_DEBUG)

   if (err != ROK)
   {
      SBLOGERROR( ERRCLS_DEBUG,
                  ESB002,
                  (ErrVal) evnt,
                  "sbTmrEvnt(): Timer function call failed" );

      RETVALUE( RFAILED );
   }

#endif /* ERRRCLS_DEBUG */


   RETVALUE(ROK);
}/* end of  sbTmrEvnt() */


/****************************************************************************/
/*  Layer Management interface LSB primitives                               */
/****************************************************************************/

/*
*
*       Fun:   SbMiLsbCfgReq
*
*       Desc:  This function is used by the Layer Management to
*              configure the layer. The SCTP layer responds with a
*              Configuration Confirm to the layer manager. This primitive
*              can also be used to reconfigure the layer.
*
*       Ret:   Success: ROK
*              Failure: RFAILED
*
*       Notes: Configuration must be performed in the following
*              sequence:
*              1) general configuration (STGEN);
*              2) sap configuration (STSCTSAP and/or STTSAP).
*
*       File:  sb_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SbMiLsbCfgReq
(
Pst     *pst,                /* post structure */
SbMgmt  *cfg                 /* configuration structure */
)
#else
PUBLIC S16 SbMiLsbCfgReq(pst, cfg)
Pst     *pst;                /* post structure */
SbMgmt  *cfg;                /* configuration structure */
#endif
{
   Header      *hdr;               /* Header structure */
   SbMgmt      cfmMsg;             /* configuration confirm */
   S16         ret;                /* return code */

   TRC3(SbMiLsbCfgReq)

#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                          (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbMiLsbCfgReq() failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */

   SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
          "SbMiLsbCfgReq(pst, elmnt(%d))\n", cfg->hdr.elmId.elmnt));

   /* obtain the header structure from the configuration */
   hdr = &(cfg->hdr);

   /* zero out the confirm structure */
   SB_ZERO(&cfmMsg, sizeof(SbMgmt));

   /* Check if general configuration has been done */
   if ( (hdr->elmId.elmnt != STSBGEN) &&
        (sbGlobalCb.sbInit.cfgDone == FALSE) )
   {
      SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
             "SbMiLsbCfgReq: general configuration not done yet\n"));

      sbLmSendCfm(pst, TCFG, hdr, LCM_PRIM_NOK, LCM_REASON_GENCFG_NOT_DONE,
                  &cfmMsg);
      RETVALUE(RFAILED);
   }

   /* Check if currently busy servicing a layer manager request */
   if ( sbGlobalCb.sbMgmt.hdr.elmId.elmnt != 0 )
   {
      SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
             "SbMiLsbCfgReq: currently servicing a layer manager request\n"));

      sbLmSendCfm(pst, TCFG, hdr, LCM_PRIM_NOK, LSB_REASON_LMI_BUSY,
                  &cfmMsg);
      RETVALUE(RFAILED);
   }

   /* choose the element (ie. which type of configuration) */
   switch (hdr->elmId.elmnt)
   {
      case STSBGEN:               /* general configuration */
         ret = sbCfgGen(&cfg->t.cfg.s.genCfg);
         break;

      case STSBSCTSAP:              /* upper SCT SAP configuration */
         ret = sbCfgSctSap(&cfg->t.cfg.s.sctSapCfg);
         break;

      case STSBTSAP:                /* transport SAP configuration */
         ret = sbCfgTSap(cfg);
         break;

      default:                  /* invalid */
#if (ERRCLASS & ERRCLS_INT_PAR)
         SBLOGERROR(ERRCLS_INT_PAR, ESB003, (ErrVal) hdr->elmId.elmnt,
                    "SbMiLsbCfgReq: Bad Element in control request");
#endif
         ret = LCM_REASON_INVALID_ELMNT;
         break;

   }

   /* In normal cases, LCM_REASON_NOT_APPL is returned, in all error
    * cases appropriate reason is returned by the above functions */

   /* send the layer manager confirm */
   if (ret != LCM_REASON_NOT_APPL)
   {
      sbLmSendCfm(pst, TCFG, hdr, LCM_PRIM_NOK, ret,
                  &cfmMsg);
      RETVALUE(RFAILED);
   }

   sbLmSendCfm(pst, TCFG, hdr, LCM_PRIM_OK, LCM_REASON_NOT_APPL,
               &cfmMsg);
   RETVALUE(ROK);
} /* end of SbMiLsbCfgReq() */

/*
*
*       Fun:   Control Request Primitive
*
*       Desc:  This primitive is used to control the specified element.
*              It can be used to enable or disable the general elements
*              (trace, alarm and debug prints.)
*              It can also be used to: delete or disable a SAP or a group of
*              SAPs; bind or enable a SAP or group of SAPs or
*              Shutdown all the operations.
*              A control confirm is sent to acknowledge the request
*
*       Ret:   Success:       ROK
*              Failure:       RFAILED
*
*       Notes: <none>
*
*       File:  sb_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SbMiLsbCntrlReq
(
Pst    *pst,                   /* post structure */
SbMgmt *cntrl                  /* pointer to control structure */
)
#else
PUBLIC S16 SbMiLsbCntrlReq(pst, cntrl)
Pst    *pst;                   /* post structure */
SbMgmt *cntrl;                 /* pointer to control structure */
#endif
{
   Header      *hdr;                /* Header structure */
   /* sb004.12 - Change - cfmMsg is taken as Pointer to minimise stack memory */
   SbMgmt      *cfmMsg;             /* configuration confirm */
   S16          ret;                /* return code */
   SbTSapCb    *tSap;

   TRC3(SbMiLsbCntrlReq)

#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                         (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbMiLsbCntrlReq() failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */

   SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
          "SbMiLsbCntrlReq(pst, elmnt(%d))\n", cntrl->hdr.elmId.elmnt));

#ifndef SS_MULTIPLE_PROCS
   UNUSED(pst);
#endif

   /* obtain the header structure from the configuration */
   hdr = &(cntrl->hdr);

    /* sb004.12 - Addition : Allocate memory for Response msg  */
    SB_ALLOC(sizeof(SbMgmt), cfmMsg, ret);
    if ( ret != ROK )
    {
        SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
               "SbMiLsbCntrlReq: could not allocate memory for Response Structure\n"));
        RETVALUE(RFAILED);
     }

   /* sb004.12 - Change : cfmMsg is already a pointer */
   /* zero out the confirm structure */
   SB_ZERO(cfmMsg, sizeof(SbMgmt));

   /* set the current time */
   (Void) SGetDateTime(&(cfmMsg->t.cntrl.dt));

   /* Check if configuration has been done */
   if ( (sbGlobalCb.sbInit.cfgDone == FALSE) && (hdr->elmId.elmnt != STSBGEN) )
   {
      SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
             "SbMiLsbCntrlReq: general configuration not done yet\n"));

      sbLmSendCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK, LCM_REASON_GENCFG_NOT_DONE,
                  cfmMsg);
      /* sb004.12 - Addition : deallocate cfmMsg structure */
      SB_FREE(sizeof(SbMgmt), cfmMsg);
      RETVALUE(RFAILED);
   }

   /* Check if currently busy servicing a layer manager request */
   if ( sbGlobalCb.sbMgmt.hdr.elmId.elmnt != 0 )
   {
      SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
             "SbMiLsbCntrlReq: currently servicing a layer manager request\n"));

      sbLmSendCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK, LSB_REASON_LMI_BUSY,
                  cfmMsg);
      /* sb004.12 - Addition : deallocate cfmMsg structure */
      SB_FREE(sizeof(SbMgmt), cfmMsg);
      RETVALUE(RFAILED);
   }

   /* check element */
   switch(hdr->elmId.elmnt)
   {
      case STSBGEN:                               /* General control */
         ret = sbCntrlGen(cntrl);
         break;

      case STSBSCTSAP:
         ret = sbCntrlSctSap(cntrl);             /* SCT SAP control */
         break;

      case STSBTSAP:                              /* Transport SAP control */
         if ( cntrl->t.cntrl.action == ABND_ENA )
         {
            /* set the current time for when the bind request was received */
            (Void) SGetDateTime(&(cntrl->t.cntrl.dt));

            /* Store current Management structure */
            (Void) cmMemcpy((U8 *) &(sbGlobalCb.sbMgmt), (U8 *) cntrl,
                           (PTR) sizeof(SbMgmt));
         }
         cmMemcpy((U8 *)&(sbGlobalCb.genCfg.smPst), (U8 *)pst, sizeof(Pst));
         ret = sbCntrlTSap(cntrl);
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SBLOGERROR(ERRCLS_DEBUG, ESB004, (ErrVal) hdr->elmId.elmnt,
                    "SbMiLsbCntrlReq: Bad Element in control request");
         /* element must be one of the above */
#endif
         ret = LCM_REASON_INVALID_ELMNT;
         break;
   } /* end switch */

   /* In normal cases, LCM_REASON_NOT_APPL is returned, in all error
    * cases appropriate reason is returned by the above functions */

   /* send the layer manager confirm */
   if (ret != LCM_REASON_NOT_APPL)
   {
      SB_ZERO( &(sbGlobalCb.sbMgmt), sizeof(SbMgmt) );
      sbLmSendCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK, ret, cfmMsg);
      /* sb004.12 - Addition : deallocate cfmMsg structure */
      SB_FREE(sizeof(SbMgmt), cfmMsg);
      RETVALUE(RFAILED);
   }

   /* we need to store the sbMgmt struct if binding a TSAP */
   /* the confirm is also slightly different */
   if ( (hdr->elmId.elmnt == STSBTSAP) && (cntrl->t.cntrl.action == ABND_ENA) )
   {
      tSap = sbGlobalCb.tSaps[cntrl->t.cntrl.sapId];
      if (tSap->sapState != SB_SAPSTATE_BND)
      {
         sbLmSendCfm(pst, TCNTRL, hdr, LCM_PRIM_OK_NDONE, LCM_REASON_NOT_APPL,
                     cfmMsg);
      }
      /* sb004.12 - Addition : deallocate cfmMsg structure */
      SB_FREE(sizeof(SbMgmt), cfmMsg);
      RETVALUE(ROK);
   }

   sbLmSendCfm(pst, TCNTRL, hdr, LCM_PRIM_OK, LCM_REASON_NOT_APPL,
               cfmMsg);
  
   /* sb004.12 - Addition : deallocate cfmMsg structure */
   SB_FREE(sizeof(SbMgmt), cfmMsg);

   RETVALUE(ROK);
}/* end of SbMiLsbCntrlReq() */



/* ------------------------------------------------------------------*
 * Interface Functions for SHT Interface                           *
 * ------------------------------------------------------------------*/

/* sb042.102 - Added change for SHT interface and Rolling Up Grade */
#ifdef SB_FTHA  

/*
*
*       Fun  :  System agent control Request 
*
*       Desc :  Processes system agent control request primitive
*
*       Ret  :  ROK  - ok
*
*       Notes:  <None>
*
*       File :  sb_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SbMiShtCntrlReq
(
Pst               *pst,       /* post structure          */
ShtCntrlReqEvnt   *reqInfo    /* system agent control request event */
)
#else
PUBLIC S16 SbMiShtCntrlReq(pst, reqInfo)
Pst               *pst;       /* post structure          */
ShtCntrlReqEvnt   *reqInfo;   /* system agent control request event */
#endif
{
   Pst               repPst;  /* reply post structure */
   ShtCntrlCfmEvnt   cfmInfo; /* system agent control confirm event */
   SbSctSapCb        *sctSap; /* SCT Sap control Block */
   SbTSapCb          *tSap;   /* TSap control Block */
   S16               i;

   TRC3(SbMiShtCntrlReq)

#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                          (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbMiShtCntrlReq () failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */

   SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf, "SbMiShtCntrlReq at SHT "
     "interface \n"));

   /* fill reply pst structure */
   repPst.dstProcId = pst->srcProcId;
   repPst.dstEnt    = pst->srcEnt;
   repPst.dstInst   = pst->srcInst;
   repPst.prior     = reqInfo->hdr.response.prior;
   repPst.route     = reqInfo->hdr.response.route;
   repPst.selector  = reqInfo->hdr.response.selector;
   repPst.event     = EVTNONE;
   repPst.srcProcId = sbGlobalCb.sbInit.procId;
   repPst.srcEnt    = ENTSB;
   repPst.srcInst   = sbGlobalCb.sbInit.inst;
   repPst.region    = reqInfo->hdr.response.mem.region; 
   repPst.pool      = reqInfo->hdr.response.mem.pool; 

   /* fill reply transaction Id */
   cfmInfo.transId = reqInfo->hdr.transId;

#ifdef SB_RUG
   cfmInfo.reqType = reqInfo->reqType;
#endif 

   /* check if general configuration done */
   if (sbGlobalCb.sbInit.cfgDone != TRUE)
   {
      cfmInfo.status.status = LCM_PRIM_NOK;
      cfmInfo.status.reason = LCM_REASON_GENCFG_NOT_DONE;

      SbMiShtCntrlCfm(&repPst, &cfmInfo);
      RETVALUE(ROK); 
   }

   /* fill status value */
   cfmInfo.status.reason = LCM_REASON_NOT_APPL;
   sbGlobalCb.genCfg.smPst.srcEnt = ENTSM;
   sbGlobalCb.genCfg.smPst.srcInst = sbGlobalCb.sbInit.lmPst.srcInst;
   sbGlobalCb.genCfg.smPst.srcProcId = sbGlobalCb.sbInit.lmPst.srcProcId;

   switch (reqInfo->reqType)
   {
      case SHT_REQTYPE_BND_ENA:   /* system agent control bind enable */
         switch (reqInfo->s.bndEna.grpType)
         {
            case SHT_GRPTYPE_ALL:
               /* 
                * go through all the sap control blocks and start bind  
                * enable procedure on those SAPs for which              
                * (tPst->dstProcId == reqInfo->s.bndEna.dstProcId) && 
                * (tPst->dstEnt == reqInfo->s.bndEna.dstEnt) &&       
                * (tPst->dstInst == reqInfo->s.bndEna.dstInst)        
                */
                
                /* call function for all SAPs */
                for (i = 0; i < sbGlobalCb.genCfg.maxNmbTSaps; i++)
                {
                   tSap = sbGlobalCb.tSaps[i];
                   if (tSap != (SbTSapCb *) NULLP)
                   {
                      if ((tSap->tPst.dstProcId == reqInfo->s.bndEna.dstProcId)
                         && (tSap->tPst.dstEnt == reqInfo->s.bndEna.dstEnt.ent)
                         && (tSap->tPst.dstInst == 
                             reqInfo->s.bndEna.dstEnt.inst))
                      {
                         /* tSap found, bind it */
                         if (tSap->contEnt != ENTSM)
                         {
                            sbGlobalCb.sbMgmt.hdr.elmId.elmnt = STSBTSAP;
                            sbLiBindSap(tSap->tSapCfg.suId, (SbMgmt*)NULLP);
                         }
                      }
                   }
                }
                break;

             case SHT_GRPTYPE_ENT:
                /* 
                 * go through all the sap control blocks and start bind  
                 * enable procedure on those SAPs for which
                 * (tPst->dstEnt == reqInfo->s.bndEna.dstEnt) &&       
                 * (tPst->dstInst == reqInfo->s.bndEna.dstInst)        
                 */
                
                /* call function for all SAPs */
                for (i = 0; i < sbGlobalCb.genCfg.maxNmbTSaps; i++)
                {
                   tSap = sbGlobalCb.tSaps[i];
                   if (tSap != (SbTSapCb *) NULLP)
                   {
                      if ((tSap->tPst.dstEnt == reqInfo->s.bndEna.dstEnt.ent) 
                         && (tSap->tPst.dstInst == 
                             reqInfo->s.bndEna.dstEnt.inst))
                      {
                         /* tSap found, bind it */
                         if (tSap->contEnt != ENTSM)
                         {
                            sbLiBindSap(tSap->tSapCfg.suId, (SbMgmt*)NULLP);
                         }
                      }
                   }
                }
                break;
             default:
                cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
                break;
          }
          break;

       case SHT_REQTYPE_UBND_DIS:  /* system agent control unbind disable */
          /* sb042.102 - Added change for rolling upgrade */
#ifdef SB_RUG
          /* Delete the stored version information for that SAP
           * Loop in the stored version information store and
           * delete all version information entries to that dest */
          for(i = sbGlobalCb.numIntfInfo - 1; i >= 0; i--)
          {
             if(sbGlobalCb.intfInfo[i].grpType == reqInfo->s.ubndDis.grpType)
             {
                switch(sbGlobalCb.intfInfo[i].grpType)
                {
                   case SHT_GRPTYPE_ALL:
                      if (sbGlobalCb.intfInfo[i].dstProcId == 
                               reqInfo->s.ubndDis.dstProcId &&
                          sbGlobalCb.intfInfo[i].dstEnt.ent == 
                               reqInfo->s.ubndDis.dstEnt.ent &&
                          sbGlobalCb.intfInfo[i].dstEnt.inst == 
                               reqInfo->s.ubndDis.dstEnt.inst)
                      {
                         /* delete the stored version information by copying the
                          * last version info into current location
                          */
                         cmMemcpy((U8*) &sbGlobalCb.intfInfo[i],
                           (U8*) &sbGlobalCb.intfInfo[sbGlobalCb.numIntfInfo-1],
                           sizeof(ShtVerInfo));
                         sbGlobalCb.numIntfInfo--;
                      }
                      break;
                   case SHT_GRPTYPE_ENT:
                      if (sbGlobalCb.intfInfo[i].dstEnt.ent == 
                               reqInfo->s.ubndDis.dstEnt.ent &&
                          sbGlobalCb.intfInfo[i].dstEnt.inst == 
                               reqInfo->s.ubndDis.dstEnt.inst)
                      {
                         /* delete the version information by copying the
                          * last version info into current location
                          */
                         cmMemcpy((U8*) &sbGlobalCb.intfInfo[i],
                           (U8*) &sbGlobalCb.intfInfo[sbGlobalCb.numIntfInfo-1],
                           sizeof(ShtVerInfo));
                         sbGlobalCb.numIntfInfo--;
                      }
                      break;
                    default:
                       cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
                       break;

                } /* switch sbGlobalCb.numIntfInfo */
             } /* end of if sbGlobalCb.numIntfInfo */
          } /* for (i = 0) */
#endif /* SB_RUG */

          switch (reqInfo->s.ubndDis.grpType)
          {
             case SHT_GRPTYPE_ALL:
                /* 
                 * go through all the sap control blocks and start unbind 
                 * disable procedure on those SAPs for which              
                 * (tPst->dstProcId == reqInfo->s.ubndDis.dstProcId) && 
                 * (tPst->dstEnt == reqInfo->s.ubndDis.dstEnt) &&       
                 * (tPst->dstInst == reqInfo-.s.ubndDis.dstInst)        
                 */
                
                /* call function for all TSAPs */
                for (i = 0; i < sbGlobalCb.genCfg.maxNmbTSaps; i++)
                {
                   tSap = sbGlobalCb.tSaps[i];
                   if (tSap != (SbTSapCb *) NULLP)
                   {
                      if ((tSap->tPst.dstProcId == reqInfo->s.bndEna.dstProcId)
                         && (tSap->tPst.dstEnt == reqInfo->s.bndEna.dstEnt.ent) 
                         && (tSap->tPst.dstInst == 
                             reqInfo->s.bndEna.dstEnt.inst))
                      {
                         if (tSap->sapState == SB_SAPSTATE_BND)
                         {
                            sbLiUnbindSap(tSap->tSapCfg.suId);
                         }
                      }
                   }
                }
                /* call function for all SCT SAPs */
                for (i = 0; i < sbGlobalCb.genCfg.maxNmbSctSaps; i++)
                {
                   sctSap = sbGlobalCb.sctSaps[i];
                   if (sctSap != (SbSctSapCb *) NULLP)
                   {
                      if ((sctSap->sctPst.dstProcId == reqInfo->s.bndEna.dstProcId)
                         && (sctSap->sctPst.dstEnt == reqInfo->s.bndEna.dstEnt.ent)
                         && (sctSap->sctPst.dstInst == 
                             reqInfo->s.bndEna.dstEnt.inst))
                      {
                         if (sctSap->sapState != SB_SAPSTATE_UBND)
                         {
                            sbUiUnbindSap(sctSap->sctSapCfg.spId);
                         }
                      }
                   }
                }


                break;

             case SHT_GRPTYPE_ENT:
                /* 
                 * go through all the sap control blocks and start unbind 
                 * disable procedure on those SAPs for which              
                 * (tPst->dstEnt == reqInfo->s.ubndDis.dstEnt) &&       
                 * (tPst->dstInst == reqInfo-.s.ubndDis.dstInst)        
                 */
                
                /* call function for all NSAPs */
                for (i = 0; i < sbGlobalCb.genCfg.maxNmbTSaps; i++)
                {
                   tSap = sbGlobalCb.tSaps[i];
                   if (tSap != (SbTSapCb *) NULLP)
                   {
                      if ((tSap->tPst.dstEnt == reqInfo->s.bndEna.dstEnt.ent) 
                         && (tSap->tPst.dstInst == 
                             reqInfo->s.bndEna.dstEnt.inst))
                      {
                         if (tSap->sapState == SB_SAPSTATE_BND)
                         {
                            sbLiUnbindSap(tSap->tSapCfg.suId);
                         }
                      }
                   }
                }

                /* call function for all SCT SAPs */
                for (i = 0; i < sbGlobalCb.genCfg.maxNmbSctSaps; i++)
                {
                   sctSap = sbGlobalCb.sctSaps[i];
                   if (sctSap != (SbSctSapCb *) NULLP)
                   {
                      if ((sctSap->sctPst.dstEnt == reqInfo->s.bndEna.dstEnt.ent) 
                         && (sctSap->sctPst.dstInst == 
                             reqInfo->s.bndEna.dstEnt.inst))
                      {
                         if (sctSap->sapState != SB_SAPSTATE_UBND)
                         {
                            sbUiUnbindSap(sctSap->sctSapCfg.spId);
                         }
                      }
                   }
                }

                break;

             default:
                cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
                break;
           }
           break;

        /* sb042.102 - Added change for rolling upgrade */
#ifdef SB_RUG
       case SHT_REQTYPE_GETVER:      /* system agent get version */
          sbGetVer(&cfmInfo.t.gvCfm);
          break;

       case SHT_REQTYPE_SETVER:      /* system agent set version */
          sbSetVer(&reqInfo->s.svReq, &cfmInfo.status);
          break;
#endif /* SB_RUG */

       default:
          cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
          break;
   }

   if (cfmInfo.status.reason != LCM_REASON_NOT_APPL)
   {
      cfmInfo.status.status = LCM_PRIM_NOK;
   }
   else
   {
      cfmInfo.status.status = LCM_PRIM_OK;
   }

   /* send the response */
   SbMiShtCntrlCfm(&repPst, &cfmInfo);
      
   RETVALUE(ROK);
} /* end SbMiShtCntrlReq */
#endif /* SB_FTHA */
/*
*
*       Fun:   Status Request Primitive
*
*       Desc:  This primitive is used by the Layer Manager to solicit
*              status information. The information is returned via the
*              SbMiLsbStaCfm primitive.
*
*       Ret:   ROK      - ok
*
*       Notes: <none>
*
*       File:  sb_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SbMiLsbStaReq
(
Pst    *pst,                   /* post structure */
SbMgmt *sta                    /* status structure */
)
#else
PUBLIC S16 SbMiLsbStaReq(pst, sta)
Pst    *pst;                   /* post structure */
SbMgmt *sta;                   /* status structure */
#endif
{
   Header      *hdr;               /* Header structure */
   SbMgmt      cfmMsg;             /* configuration confirm */
   S16         ret;                /* return code */
   SbSctSapCb *sctSap;             /* SAP pointer */
   SpId        spId;               /* spId */
   SbTSapCb   *tSap;               /* SAP pointer */
   SuId        suId;               /* suId */
   U32         i;

   TRC3(SbMiLsbStaReq);
#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                         (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbMiLsbStaReq () failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */


   SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
          "SbMiLsbStaReq(pst, elmnt(%d))\n", sta->hdr.elmId.elmnt));

#ifndef SS_MULTIPLE_PROCS
   UNUSED(pst);
#endif  /* SS_MULTIPLE_PROCS */

   /* obtain the header structure from the configuration */
   hdr = &(sta->hdr);

   /* zero out the confirm structure */
   SB_ZERO(&cfmMsg, sizeof(SbMgmt));

   /* Check if configuration has been done */
   if ( (sbGlobalCb.sbInit.cfgDone == FALSE) )
   {
      SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
             "SbMiLsbStaReq: general configuration not done yet\n"));

      sbLmSendCfm(pst, TSSTA, hdr, LCM_PRIM_NOK, LCM_REASON_GENCFG_NOT_DONE,
                  &cfmMsg);
      RETVALUE(RFAILED);
   }

   /* Check if currently busy servicing a layer manager request */
   if ( sbGlobalCb.sbMgmt.hdr.elmId.elmnt != 0 )
   {
      SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
             "SbMiLsbStaReq: currently servicing a layer manager request\n"));
      sbLmSendCfm(pst, TSSTA, hdr, LCM_PRIM_NOK, LSB_REASON_LMI_BUSY,
                  &cfmMsg);
      RETVALUE(RFAILED);
   }

   /* default value */
   ret = LCM_REASON_NOT_APPL;

   /* check element */
   switch (hdr->elmId.elmnt)
   {
      case STSBSID:                   /* get the system id information */
      {
         (Void) sbGetSid(&cfmMsg.t.ssta.s.sysId);
         break;
      }

      case STSBGEN:                 /* get the general layer status */
      {
         cfmMsg.t.ssta.s.genSta.memSize  = sbGlobalCb.genSta.memSize;
         cfmMsg.t.ssta.s.genSta.memAlloc = sbGlobalCb.genSta.memAlloc;
         cfmMsg.t.ssta.s.genSta.nmbAssoc = 0;
         for ( i = 0; i < sbGlobalCb.genCfg.maxNmbAssoc; i++ )
         {
            if ( sbGlobalCb.assocCb[i] != (SbSctAssocCb *) NULLP )
            {
               cfmMsg.t.ssta.s.genSta.nmbAssoc++;
            }
         }
         cfmMsg.t.ssta.s.genSta.nmbEndp = 0;
         for ( i = 0; i < sbGlobalCb.genCfg.maxNmbEndp; i++ )
         {
            if ( sbGlobalCb.endpCb[i] != (SbSctEndpCb *) NULLP )
            {
               cfmMsg.t.ssta.s.genSta.nmbEndp++;
            }
         }

         cfmMsg.t.ssta.s.genSta.nmbLocalAddr = sbGlobalCb.genSta.nmbLocalAddr;
         cfmMsg.t.ssta.s.genSta.nmbPeerAddr = sbGlobalCb.genSta.nmbPeerAddr;

         break;
      }

      case STSBSCTSAP:                /* get status of a SCT SAP */
      {
         /* get the spId to look up status for */
         spId = sta->t.ssta.sapId;

         /* validate the sapId */
#if (ERRCLASS & ERRCLS_INT_PAR)
         if( (spId >= sbGlobalCb.genCfg.maxNmbSctSaps) || (spId < 0) )
         {
            SBLOGERROR(ERRCLS_INT_PAR, ESB005, (ErrVal) spId,
                       "SbMiLsbStaReq: spId out of range");
            ret = LCM_REASON_INVALID_SAP;
            break;
         }
#endif /* ERRCLS_INT_PAR */

         /* get the SCT SAP control block */
         sctSap = sbGlobalCb.sctSaps[spId];

#if (ERRCLASS & ERRCLS_INT_PAR)
         /* check to see if the SAP exists */
         if ( sctSap == (SbSctSapCb *) NULLP)
         {
            SBLOGERROR(ERRCLS_INT_PAR, ESB006, (ErrVal) spId,
                       "SbMiLsbStaReq: Sap not configured");
            ret = LCM_REASON_INVALID_SAP;
            break;
         }
#endif /* ERRCLS_INT_PAR */

         /* get the status of the SCT SAP */
         cfmMsg.t.ssta.s.sapSta.swtch    = sctSap->sctSapCfg.swtch;
         cfmMsg.t.ssta.s.sapSta.hlSt     = sctSap->sapState;
         cfmMsg.t.ssta.sapId             = spId;
         /* sb042.102 - Added change for rolling upgrade */
#ifdef SB_RUG
         cfmMsg.t.ssta.s.sapSta.remIntfValid = sctSap->remIntfValid;
         cfmMsg.t.ssta.s.sapSta.selfIfVer    = SCTIFVER;
         cfmMsg.t.ssta.s.sapSta.remIfVer     = sctSap->sctPst.intfVer;
#endif
         break;
      }

      case STSBTSAP:                  /* get status of a Transport SAP */
      {
         /* get the spId to look up status for */
         suId = sta->t.ssta.sapId;

         /* validate the sapId */
#if (ERRCLASS & ERRCLS_INT_PAR)
         if((suId >= (SuId) sbGlobalCb.genCfg.maxNmbTSaps) || (suId < 0))
         {
            SBLOGERROR(ERRCLS_INT_PAR, ESB007, (ErrVal) suId,
                       "SbMiLsbStaReq: suId out of range");
            ret = LCM_REASON_INVALID_SAP;
            break;
         }
#endif /* ERRCLS_INT_PAR */
         /* get the SCT SAP control block */
         tSap = sbGlobalCb.tSaps[suId];

         /* check to see if the SAP exists */
#if (ERRCLASS & ERRCLS_INT_PAR)
         if (tSap == (SbTSapCb *) NULLP)
         {
            SBLOGERROR(ERRCLS_INT_PAR, ESB008, (ErrVal) suId,
                       "SbMiLsbStaReq: Sap not configured");
            ret = LCM_REASON_INVALID_SAP;
            break;
         }
#endif /* ERRCLS_INT_PAR */

         /* get the status of the Transport SAP */
         cfmMsg.t.ssta.s.sapSta.swtch    = tSap->tSapCfg.swtch;
         cfmMsg.t.ssta.s.sapSta.hlSt     = tSap->sapState;
         cfmMsg.t.ssta.sapId             = suId;
         /* sb042.102 - Added change for rolling upgrade */
#ifdef SB_RUG
         cfmMsg.t.ssta.s.sapSta.remIntfValid = tSap->remIntfValid;
         cfmMsg.t.ssta.s.sapSta.selfIfVer    = HITIFVER;
         cfmMsg.t.ssta.s.sapSta.remIfVer     = tSap->tPst.intfVer;
#endif
         break;
      }
      case STSBASSOC:               /* get status of an association */
      {
         ret = sbLmAssocSta(sta->t.ssta.s.assocSta.assocId, &(cfmMsg));
         break;
      }

      case STSBDTA:                 /* get status of a dest. tpt addr. */
      {
         ret = sbLmDtaSta(&(sta->t.ssta.s.dtaSta), &(cfmMsg));
         break;
      }

#ifdef SB_ACC
      case STSBTMR:
      {
         CmTimer *tmr;
         SbTmrSta *tmrSta;

         tmrSta = &(cfmMsg.t.ssta.s.tmrSta);

         for (i = 0; i < SB_TQSIZE; i++)
         {
            tmr = sbGlobalCb.sbTq[i].first;
            while (tmr != (CmTimer *)NULLP)
            {
               switch (tmr->tmrEvnt)
               {
                  case SB_TMR_LIFETIME:
                     tmrSta->lifetimeTmr++;
                     break;
                  case SB_TMR_T3RTX:
                     tmrSta->t3rtx++;
                     break;
                  case SB_TMR_ACKDELAY:
                     tmrSta->ackDelayTmr++;
                     break;
                  case SB_TMR_SHUTDOWN:
                     tmrSta->t2Shutdown++;
                     break;
                  case SB_TMR_INIT:
                     tmrSta->t1InitTmr++;
                     break;
                  case SB_TMR_COOKIE:
                     tmrSta->cookieTmr++;
                     break;
                  case SB_TMR_HBEAT:
                     tmrSta->hBeat++;
                     break;
                  case SB_TMR_KEY:
                     tmrSta->keyTmr++;
                     break;
                  case SB_TMR_TSAP_BND:
                     tmrSta->tIntTmr++;
                     break;
                  case SB_TMR_FREEZE:
                     tmrSta->freezeTmr++;
                     break;
/* sb054.102 : Addition - Bundling Changes */
#ifdef LSB4
                  case SB_TMR_BUNDLE:
                     tmrSta->bundleTmr++;
                     break;
#endif

                  default:
                     break;
               }
               tmr = tmr->next;
            }
         }
         break;
      }
#endif /* SB_ACC */

      default:
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         SBLOGERROR(ERRCLS_INT_PAR, ESB009, (ErrVal) hdr->elmId.elmnt,
                    "SbMiLsbStaReq: Invalid Element in Status request");
         ret = LCM_REASON_INVALID_ELMNT;
#endif /* ERRCLS_INT_PAR */
         break;
      }

   } /* end switch */

   /* fill the date and time */
   (Void) SGetDateTime(&cfmMsg.t.ssta.dt);

   /* In normal cases, LCM_REASON_NOT_APPL is returned, in all error
    * cases appropriate reason is returned by the above functions */

   /* send the layer manager confirm */
   if (ret != LCM_REASON_NOT_APPL)
   {
      sbLmSendCfm(pst, TSSTA, hdr, LCM_PRIM_NOK, ret, &cfmMsg);
      RETVALUE(RFAILED);
   }

   sbLmSendCfm(pst, TSSTA, hdr, LCM_PRIM_OK, LCM_REASON_NOT_APPL, &cfmMsg);
   RETVALUE(ROK);
}/* end of SbMiLsbStaReq() */

/*
*
*       Fun:   Statistics Request Primitive
*
*       Desc:  This primitive is used by the Layer Manager to solicit
*              statistics information. The statistics values are
*              returned by SbMiLsbStsCfm primitive.The statistics
*              counters can be initialized to NULL using the "action"
*              parameter. The possible values for "action" are:
*
*              ZEROSTS:    zero statistics counters
*              NOZEROSTS:  do not zero statistics counters
*
*       Ret:   ROK
*
*       Notes: <none>
*
*       File:  sb_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SbMiLsbStsReq
(
Pst     *pst,                /* post structure */
Action  action,              /* action to be done */
SbMgmt *sts                  /* statistics structure */
)
#else
PUBLIC S16 SbMiLsbStsReq(pst, action, sts)
Pst     *pst;                /* post structure */
Action  action;              /* action to be done */
SbMgmt *sts;                 /* statistics structure */
#endif
{
   Header      *hdr;               /* Header structure */
   SbMgmt       cfmMsg;            /* configuration confirm */
   SbSctSapCb  *sctSap;            /* SCT SAP */
   SbTSapCb    *tSap;              /* transport SAP */
   DateTime     lastTime;          /* date and time of last stats report */
   DateTime     currentTime;       /* current date and time*/
   S16          ret;

   TRC3(SbMiLsbStsReq)

#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                         (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbMiLsbStsReq () failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */

   SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
          "SbMiLsbStsReq(pst, action(%d), elmnt(%d))\n",
           action, sts->hdr.elmId.elmnt));
#ifndef SS_MULTIPLE_PROCS
   UNUSED(pst);
#endif  /* SS_MULTIPLE_PROCS */

   /* obtain the header structure from the configuration */
   hdr = &(sts->hdr);

   /* zero out the confirm structure */
   SB_ZERO(&cfmMsg, sizeof(SbMgmt));

   /* Check if configuration has been done */
   if ( (sbGlobalCb.sbInit.cfgDone == FALSE) )
   {
      SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
             "SbMiLsbStsReq: general configuration not done yet\n"));

      sbLmSendCfm(pst, TSTS, hdr, LCM_PRIM_NOK, LCM_REASON_GENCFG_NOT_DONE,
                  &cfmMsg);
      RETVALUE(RFAILED);
   }

   /* Check if currently busy servicing a layer manager request */
   if ( sbGlobalCb.sbMgmt.hdr.elmId.elmnt != 0 )
   {
      SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
             "SbMiLsbStsReq: currently servicing a layer manager request\n"));
      sbLmSendCfm(pst, TSTS, hdr, LCM_PRIM_NOK, LSB_REASON_LMI_BUSY,
                  &cfmMsg);
      RETVALUE(RFAILED);
   }

   /* get the current date and time for when the request is made */
   SGetDateTime(&currentTime);

   /* default value */
   ret = LCM_REASON_NOT_APPL;

   switch (hdr->elmId.elmnt)
   {
      case STSBGEN:               /* general statistics */
         /* copy the general statistics from the control block */
         cmMemcpy((U8 *)&cfmMsg.t.sts.u.genSts, (U8 *) &sbGlobalCb.genSts,
                  (PTR)sizeof(SbGenSts));

         /* save the last date/time a report was requested */
         cmMemcpy((U8 *)&lastTime, (U8 *) &(sbGlobalCb.genSts.dt),
                  (PTR)sizeof(DateTime));

         if (action == ZEROSTS)
         {
            SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
                   "SbMiLsbStsReq: statistics counters cleared\n"));
            /* zero out the stored statistics */
            SB_ZERO(&sbGlobalCb.genSts, sizeof(SbGenSts));
            /* set time for zeroing action */
            SGetDateTime(&(sbGlobalCb.genSts.dt));
         }

         break;

      case STSBSCTSAP:              /* sap statistics */
      {
         /* verify the SpId */
#if (ERRCLASS & ERRCLS_INT_PAR)
         if ( (sts->t.sts.sapId >= sbGlobalCb.genCfg.maxNmbSctSaps) ||
              (sts->t.sts.sapId < 0) )
         {
            SBLOGERROR(ERRCLS_INT_PAR, ESB010, (ErrVal) sts->t.sts.sapId,
                       "SbMiLsbStsReq: sapId out of range");
            ret = LCM_REASON_INVALID_SAP;
            break;
         }
#endif /* ERRCLS_INT_PAR */

         sctSap = sbGlobalCb.sctSaps[sts->t.sts.sapId];

#if (ERRCLASS & ERRCLS_INT_PAR)
         if ( sctSap == (SbSctSapCb *) NULLP )
         {
            SBLOGERROR(ERRCLS_INT_PAR, ESB011, (ErrVal) sts->t.sts.sapId,
                       "SbMiLsbStsReq: SAP not configured");
            ret = LCM_REASON_INVALID_SAP;
            break;
         }
#endif /* ERRCLS_INT_PAR */

         /* copy the statistics from the sap to the management structure */
         (Void) cmMemcpy((U8 *) &cfmMsg.t.sts.u.sctSts, (U8 *) &sctSap->sctSts,
                          sizeof(SbSctSapSts));

         /* save the last date/time a report was requested */
         (Void) cmMemcpy((U8 *)&lastTime, (U8 *) &(sctSap->sctSts.dt),
                         sizeof(DateTime));

         if (action == ZEROSTS)
         {
            SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
                   "SbMiLsbStsReq: statistics counters cleared\n"));
            /* zero out the stored statistics in the sap structure */
            SB_ZERO(&sctSap->sctSts, sizeof(SbSctSapSts));
            /* set time for zeroing action */
            SGetDateTime(&(sctSap->sctSts.dt));
         }

         /* sb036.102: Filling in the sap information in the *
          * response message                                 */
         cfmMsg.t.sts.sapId = sts->t.sts.sapId;
         

         break;
      }

       case STSBTSAP:              /* sap statistics */
         /* verify the SuId */
#if (ERRCLASS & ERRCLS_INT_PAR)
         if ( (sts->t.sts.sapId >= sbGlobalCb.genCfg.maxNmbTSaps) ||
              (sts->t.sts.sapId < 0) )
         {
            SBLOGERROR(ERRCLS_INT_PAR, ESB012, (ErrVal) sts->t.sts.sapId,
                       "SbMiLsbStsReq: sapId out of range");
            ret = LCM_REASON_INVALID_SAP;
            break;
         }
#endif /* ERRCLS_INT_PAR */

         tSap = sbGlobalCb.tSaps[sts->t.sts.sapId];

#if (ERRCLASS & ERRCLS_INT_PAR)
         if ( tSap == (SbTSapCb *) NULLP )
         {
            SBLOGERROR(ERRCLS_INT_PAR, ESB013, (ErrVal) sts->t.sts.sapId,
                       "SbMiLsbStsReq: SAP not configured");
            ret = LCM_REASON_INVALID_SAP;
            break;
         }
#endif /* ERRCLS_INT_PAR */

         /* copy the statistics from the sap to the management structure */
         cmMemcpy((U8 *) &cfmMsg.t.sts.u.tSts, (U8 *) &(tSap->tSts),
                  sizeof(SbTSapSts));

         /* save the last date/time a report was requested */
         cmMemcpy((U8 *) &lastTime, (U8 *) &(tSap->tSts.dt), sizeof(DateTime));

         if (action == ZEROSTS)
         {
            SBDBGP(DBGMASK_MI, (sbGlobalCb.sbInit.prntBuf,
                   "SbMiLsbStsReq: statistics counters cleared\n"));
            /* zero out the stored statistics in the sap structure */
            SB_ZERO(&(tSap->tSts), sizeof(SbTSapSts));
            /* set time for zeroing action */
            SGetDateTime(&(tSap->tSts.dt));
         }
         /* sb036.102: Filling in the sap information in the *
          * response message                                 */
         cfmMsg.t.sts.sapId = sts->t.sts.sapId;
         break;

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         SBLOGERROR(ERRCLS_INT_PAR, ESB014, (ErrVal) hdr->elmId.elmnt,
                    "SbMiLsbStsReq: Bad Element in statistics request");
#endif /* ERRCLS_INT_PAR */
         ret = LCM_REASON_INVALID_ELMNT;
         break;
   } /* end of switch statement */

   /* determine the duration since the counters were zeroed */
   sbDetDuration(&lastTime, &currentTime, &(cfmMsg.t.sts.dura));

   /* set the current date/time */
   cmMemcpy((U8 *) &(cfmMsg.t.sts.dt), (U8 *) &currentTime, sizeof(DateTime));

   /* In normal cases, LCM_REASON_NOT_APPL is returned, in all error
    * cases appropriate reason is returned by the above functions */

   /* send the layer manager confirm */
   if (ret != LCM_REASON_NOT_APPL)
   {
      sbLmSendCfm(pst, TSTS, hdr, LCM_PRIM_NOK, ret, &cfmMsg);
      RETVALUE(RFAILED);
   }

   /* Issue a statistics confirm */
   sbLmSendCfm(pst, TSTS, hdr, LCM_PRIM_OK, LCM_REASON_NOT_APPL, &cfmMsg);

   RETVALUE(ROK);
}/* end of SbMiLsbStsReq() */

/****************************************************************************/
/* SCT upper interface primitives                                           */
/****************************************************************************/

/*
*
*       Fun:   SbUiSctBndReq
*
*       Desc:  Bind Request Primitive
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: This function binds a User to the SCTP Layer.
*              The SCTP Layer allocates a service access point for this
*              bind and records the identity of the service user. If the
*              SAP is already bound then it is first unbound and then rebound.
*              It also issues a SbUiSctBndCfm to the service user
*              after completing a successful bind.
*
*       File:  sb_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SbUiSctBndReq
(
Pst        *pst,              /* Post structure */
SuId        suId,             /* service user id */
SpId        spId              /* service provider id */
)
#else
PUBLIC S16 SbUiSctBndReq(pst, suId, spId)
Pst        *pst;              /* Post Structure */
SuId        suId;             /* service user id */
SpId        spId;             /* service provider id */
#endif
{
   SbSctSapCb *sctSap;         /* pointer to current SAP */
   S16         ret;
#ifdef SB_RUG
   Bool        found;
   S16         i;
#endif /* SB_RUG */

   TRC3(SbUiSctBndReq)

#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                         (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbUiSctBndReq () failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctBndReq(pst, suId(%d), spId(%d))\n", suId, spId));

   /* Validation of Input parameters */
   ret = ROK;

   /* sb041.102: remove the errcls parameter check flag */
   /* check the SpId. If it fails then no bind confirm sent */

   if ( (spId >= (SpId) sbGlobalCb.genCfg.maxNmbSctSaps) ||
        (spId < 0) )
   {
      sbLmGenAlarm((U16)LCM_CATEGORY_INTERFACE,
                  (U16)LCM_EVENT_UI_INV_EVT,
                  (U16)LCM_CAUSE_INV_SPID,
                  spId, LSB_SW_RFC_REL0);
      ret = RFAILED;
   }
   else if ( sbGlobalCb.sctSaps[spId] == (SbSctSapCb *) NULLP )
   {
      sbLmGenAlarm((U16)LCM_CATEGORY_INTERFACE,
                  (U16)LCM_EVENT_UI_INV_EVT,
                  (U16)LCM_CAUSE_INV_SAP,
                  spId, LSB_SW_RFC_REL0);
      ret = RFAILED;
   }

   if ( ret != ROK )
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB015, (ErrVal)spId,
                 "SbUiSctBndReq: Invalid spId");
      RETVALUE(RFAILED);
   }

   /* Check if the SAP is already bound. If it is then first unbind it */
   sctSap = sbGlobalCb.sctSaps[spId];
   if (sctSap->sapState == SB_SAPSTATE_BND)
   {
      sbUiUnbindSap(spId);
   }

#ifdef SB_RUG
   /* For upper interface SAP, we look up the version info from the stored
    * information if it is available already at first bound request
    */
   found = FALSE;
   if (sctSap->remIntfValid == FALSE)
   {
      for (i = 0; i < sbGlobalCb.numIntfInfo && found == FALSE; i++)
      {
         if (sbGlobalCb.intfInfo[i].intf.intfId == SCTIF)
         {
            switch (sbGlobalCb.intfInfo[i].grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if (sbGlobalCb.intfInfo[i].dstProcId == pst->srcProcId &&
                      sbGlobalCb.intfInfo[i].dstEnt.ent == pst->srcEnt &&
                      sbGlobalCb.intfInfo[i].dstEnt.inst == pst->srcInst)
                     found = TRUE;
                  break;
               case SHT_GRPTYPE_ENT:
                  if (sbGlobalCb.intfInfo[i].dstEnt.ent == pst->srcEnt &&
                      sbGlobalCb.intfInfo[i].dstEnt.inst == pst->srcInst)
                     found = TRUE;
                  break;
            }
         }
      }
      if (found == TRUE)
      {
         sctSap->sctPst.intfVer = sbGlobalCb.intfInfo[i-1].intf.intfVer;
         sctSap->remIntfValid = TRUE;
      }
      else
      {
         /* send a NACK back to the user */
         (Void) SbUiSctBndCfm(&(sctSap->sctPst), suId, CM_BND_NOK);

         SBLOGERROR(ERRCLS_INT_PAR, ESBXXX, (ErrVal)spId,
                    "SbUiSctBndReq: Failed, remote ver info not available");
         sbLmGenAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                      LCM_CAUSE_SWVER_NAVAIL, spId, LSB_SW_RFC_REL0);
         RETVALUE(ROK);
      }
   }
#endif /* SB_RUG */

   /* next we bind the SAP */
   /* SAP is configured already */
   /* copy the necessary parameters in the SAP */
   sctSap->suId             = suId;
   sctSap->sctPst.dstProcId = pst->srcProcId;
   sctSap->sctPst.dstEnt    = pst->srcEnt;
   sctSap->sctPst.dstInst   = pst->srcInst;

   /* don't know if these are required */
   sctSap->sctPst.event     = EVTNONE;
   /* sb017.102: Code removed for spare1 */

   /* set SAP state to bound */
   sctSap->sapState         = SB_SAPSTATE_BND;

   /* Update the date and time for statistics */
   (Void) SGetDateTime(&(sctSap->sctSts.dt));

   /* send an acknowledgement back to the user */
   (Void) SbUiSctBndCfm(&(sctSap->sctPst), suId, CM_BND_OK);

   RETVALUE(ROK);
}/* end of SbUiSctBndReq() */

/*
*
*       Fun:   SbUiSctEndpOpenReq
*
*       Desc:  Primitive to Open an Endpoint Server.
*
*       Ret:   ROK
*              ROKDUP
*              RFAILED
*
*       Notes: This function opens an endpoint on the SCTP Layer. An unused
*              spEndpId is found and the necessary structures are created
*              and initialised.
*
*       File:  sb_bdy1.c
*
*/

/* sb046.102: Multiple IP address per Endp */
#ifdef SCT_ENDP_MULTI_IPADDR
#ifdef ANSI
PUBLIC S16 SbUiSctEndpOpenReq
(
Pst           *pst,              /* Post structure */
SpId           spId,             /* Service provider Id */
UConnId        suEndpId,         /* Service user Endpoint ID */
SctPort        port,             /* Port number */
SctNetAddrLst *intfNAddrLst      /* Interface IP address list */
)
#else
PUBLIC S16 SbUiSctEndpOpenReq(pst, spId, suEndpId, port, intfNAddr)
Pst           *pst;              /* Post structure */
SpId           spId;             /* Service provider Id */
UConnId        suEndpId;         /* Service user Endpoint ID */
SctPort        port;             /* Port number */
SctNetAddrLst *intfNAddrLst;     /* Interface IP address list */
#endif
#else /* SCT_ENDP_MULTI_IPADDR */
#ifdef ANSI
PUBLIC S16 SbUiSctEndpOpenReq
(
Pst           *pst,              /* Post structure */
SpId           spId,             /* Service provider Id */
UConnId        suEndpId,         /* Service user Endpoint ID */
SctPort        port,             /* Port number */
CmNetAddr     *intfNAddr         /* Interface IP address */
)
#else
PUBLIC S16 SbUiSctEndpOpenReq(pst, spId, suEndpId, port, intfNAddr)
Pst           *pst;              /* Post structure */
SpId           spId;             /* Service provider Id */
UConnId        suEndpId;         /* Service user Endpoint ID */
SctPort        port;             /* Port number */
CmNetAddr     *intfNAddr;        /* Interface IP address */
#endif
#endif /* SCT_ENDP_MULTI_IPADDR */
{
   /* local parameters */
   U32            i;
   U32            j;
   UConnId        spEndpId;
   SbSctEndpCb   *endpCb;
   SbSctSapCb    *sctSap;
   CmNetAddr      tmpAddr;
   S16            ret;
   SbLocalAddrCb  *localAddr;

   TRC3(SbUiSctEndpOpenReq)

#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                         (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbUiSctEndpOpenReq () failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */

   /* Patch sb031.102 IPV6 Support Added */
#ifdef SCT_ENDP_MULTI_IPADDR
   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
      "SbUiSctEndpOpenReq(pst, spId(%d), suEndpId(%ld), port(%d), intfNAddrType(%d))\n",
      spId, suEndpId, port, intfNAddrLst->nAddr[0].type));
#else /* SCT_ENDP_MULTI_IPADDR */
   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
      "SbUiSctEndpOpenReq(pst, spId(%d), suEndpId(%ld), port(%d), intfNAddrType(%d))\n",
      spId, suEndpId, port, intfNAddr->type));
#endif /* SCT_ENDP_MULTI_IPADDR */

   /* sb051.102 - debug prints added */
#ifdef SCT_ENDP_MULTI_IPADDR
   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
      "Defined SCT_ENDP_MULTI_IPADDR, intfNAddrLst->nmb = %d , intfNAddrLst->nAddr[0] = %lu, intfNAddrLst->nAddr[1] = %lu\n",
      intfNAddrLst->nmb, intfNAddrLst->nAddr[0].u.ipv4NetAddr, 
      intfNAddrLst->nAddr[1].u.ipv4NetAddr)); 
#else /* SCT_ENDP_MULTI_IPADDR */
   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
      " Undefined SCT_ENDP_MULTI_IPADDR, intfNAddr = %lu\n",
      intfNAddr->u.ipv4NetAddr)); 
#endif /* SCT_ENDP_MULTI_IPADDR */

   UNUSED(pst);
   localAddr = (SbLocalAddrCb  *)NULLP;
     /* Validation of Input parameters */

   /* sb001.12: Addition initalize tmpAddr before hash-list operation */
   SB_ZERO((U8 *) &tmpAddr, sizeof(CmNetAddr));


#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check the SpId. */
   SB_CHK_SPID(spId, LCM_EVENT_UI_INV_EVT, ret);
   if(ret != ROK)
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB016, (ErrVal)spId,
                 "SbUiSctEndpOpenReq: Invalid spId");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   /* get the SAP to operate on */
   sctSap = sbGlobalCb.sctSaps[spId];

#if (ERRCLASS & ERRCLS_INT_PAR)

   /* sb046.102: Multiple IP address per Endp */
#ifdef SCT_ENDP_MULTI_IPADDR
   for ( i = 0; i < intfNAddrLst->nmb; i++ )
   {
      SB_CPY_NADDR(&(tmpAddr), &(intfNAddrLst->nAddr[i]));
      
      /* sanity check on the interface address */
      ret = cmHashListFind(&(sbGlobalCb.localAddrHl),
                           (U8 *) &(tmpAddr),
                           (U16) sizeof(CmNetAddr), 0,
                           (PTR *) &localAddr);
      
      if (ret != ROK)
      {
         SBLOGERROR(ERRCLS_INT_PAR, ESB017, (ErrVal)0,
            "SbUiSctEndpOpenReq: Invalid interface address, address "
            "not configured for TSAP");
         SbUiSctEndpOpenCfm( &(sctSap->sctPst), sctSap->suId, suEndpId,
                             0, SCT_NOK, SCT_CAUSE_INV_PAR_VAL);
         RETVALUE(RFAILED);
      }
   } 
#else /* SCT_ENDP_MULTI_IPADDR */
   SB_CPY_NADDR(&(tmpAddr), intfNAddr);

   /* sanity check on the interface address */
   ret = cmHashListFind(&(sbGlobalCb.localAddrHl),
                        (U8 *) &(tmpAddr),
                        (U16) sizeof(CmNetAddr), 0,
                        (PTR *) &localAddr);

   if (ret != ROK)
   {
      /* Try to find an IP_ANY if no specific match is found */
      SB_ZERO((U8 *) &tmpAddr, sizeof(CmNetAddr))
      tmpAddr.type = intfNAddr->type;
      ret = cmHashListFind(&(sbGlobalCb.localAddrHl),
                           (U8 *) &(tmpAddr),
                           (U16) sizeof(CmNetAddr), 0,
                           (PTR *) &localAddr);
   }
   if (ret != ROK)
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB017, (ErrVal)0,
         "SbUiSctEndpOpenReq: Invalid interface address, address not configured for TSAP");
      SbUiSctEndpOpenCfm( &(sctSap->sctPst), sctSap->suId, suEndpId,
                          0, SCT_NOK, SCT_CAUSE_INV_PAR_VAL);
      RETVALUE(RFAILED);
   }
#endif /* SCT_ENDP_MULTI_IPADDR */
#endif /* ERRCLS_INT_PAR */

   /* check to see if the endpoint exists using suEndpId as a lookup field */
   endpCb = (SbSctEndpCb *) NULLP;
   spEndpId = 0;

   for ( i = 0; i < sbGlobalCb.genCfg.maxNmbEndp; i++ )
   {
      if ( sbGlobalCb.endpCb[i] != (SbSctEndpCb *) NULLP )
      {
         endpCb = sbGlobalCb.endpCb[i];
         if ( (endpCb->suEndpId != suEndpId) || (endpCb->spId != spId) )
         {
            endpCb = (SbSctEndpCb *) NULLP;
         }
         else
         {
            /* if we are here then the endpoint exists */
            SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
               "SbUiSctEndpOpenReq: endpoint exists for suEndpId(%ld) and spId(%d)\n",
               suEndpId, spId));
            spEndpId = i;
            i = sbGlobalCb.genCfg.maxNmbEndp;      /* set to exit the loop */
         }
      }
   }

   if ( endpCb == (SbSctEndpCb *) NULLP )
   {
      /* if we are here then the endpoint does not already exist */
      SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
             "SbUiSctEndpOpenReq: suEndpId not used\n"));
      /* look for empty slot in list */
      for ( i = 0; i < sbGlobalCb.genCfg.maxNmbEndp; i++ )
      {
         if ( sbGlobalCb.endpCb[i] == (SbSctEndpCb *) NULLP )
         {
            break;
         }
      }
      spEndpId = i;

      /* check to see if config. maximum is reached */
      if ( spEndpId >= sbGlobalCb.genCfg.maxNmbEndp )
      {
         SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                "SbUiSctEndpOpenReq: endpoint config. max reached\n"));
         SbUiSctEndpOpenCfm( &(sctSap->sctPst), sctSap->suId, suEndpId,
                             0, SCT_NOK, SCT_CAUSE_EXCEED_CONF_VAL);
         RETVALUE(RFAILED);
      }

      /* create new endpoint structure */
      SB_ALLOC(sizeof(SbSctEndpCb), endpCb, ret);
      if ( ret != ROK )
      {
         SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                "SbUiSctEndpOpenReq: could not allocate new endpoint\n"));
         SbUiSctEndpOpenCfm( &(sctSap->sctPst), sctSap->suId, suEndpId,
                             0, SCT_NOK, SCT_CAUSE_OUTRES);
         RETVALUE(RFAILED);
      }

      endpCb->suEndpId  = suEndpId;
      endpCb->spEndpId  = spEndpId;
      endpCb->spId      = spId;
      
      /* sb046.102: Multiple IP address per Endp */
#ifdef SCT_ENDP_MULTI_IPADDR
      SB_CPY_NADDRLST(&(endpCb->localAddrLst), intfNAddrLst);
   
      /* sb051.102 - debug prints added */
      SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
      "endpCb->localAddrLst.nmb = %d , endpCb->localAddrLst.nAddr[0] = %lu, endpCb->localAddrLst.nAddr[1] = %lu\n",
      endpCb->localAddrLst.nmb, endpCb->localAddrLst.nAddr[0].u.ipv4NetAddr, 
      endpCb->localAddrLst.nAddr[1].u.ipv4NetAddr)); 

#else /* SCT_ENDP_MULTI_IPADDR */
      endpCb->localAddrLst.nmb = 1;
      SB_CPY_NADDR(&(endpCb->localAddrLst.nAddr[0]), intfNAddr);
#endif /* SCT_ENDP_MULTI_IPADDR */

      /* choose the port */
      if ( port == SB_PORT_ANY )
      {
         /* choose a port */
         endpCb->port = sbAsChoosePort(&(endpCb->localAddrLst.nAddr[0]));
      }
      else
      {
         endpCb->port = port;
      }

      /* insert into array list */
      sbGlobalCb.endpCb[spEndpId] = endpCb;

      /* Insert the IP address + port number combination into the hash list */
      for ( i = 0; i < endpCb->localAddrLst.nmb; i++ )
      {
         SbAddrPortCb *addrPortCb=NULLP;

         /* create new address/port structure */
         SB_ALLOC(sizeof(SbAddrPortCb), addrPortCb, ret);
         if ( ret != ROK )
         {
            SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                 "SbUiSctEndpOpenReq: could not allocate new SbAddrPortCb\n"));
            SbUiSctEndpOpenCfm( &(sctSap->sctPst), sctSap->suId, suEndpId,
                                0, SCT_NOK, SCT_CAUSE_OUTRES);
            RETVALUE(RFAILED);
         }

         addrPortCb->spEndpId  = endpCb->spEndpId;
         /* sb048.102: set addressCb entry to zero */
         cmMemset((U8 *)&(addrPortCb->sbAddrPortEntry),
                        0, sizeof(SbAddrPortEntry));
         addrPortCb->sbAddrPortEntry.port = port;
         SB_CPY_NADDR(&(addrPortCb->sbAddrPortEntry.localAddr), 
                       &(endpCb->localAddrLst.nAddr[i]));
         ret = cmHashListInsert(&(sbGlobalCb.addrPortHl), (PTR) addrPortCb,
                                (U8 *) &(addrPortCb->sbAddrPortEntry),
                                sizeof(SbAddrPortEntry));
#if (ERRCLASS & ERRCLS_INT_PAR)
         /* check if there is address/port overlapping */
         if ( ret != ROK )
         {
            for ( j = 0; j < i; j++ )
            {
               SbAddrPortCb *tmpAddrPortCb=NULLP;
               SbAddrPortEntry tmpAddrPortEntry;

               /* sb048.102: set addressCb entry to zero */
               cmMemset((U8 *)&tmpAddrPortEntry, 0, sizeof(SbAddrPortEntry));
               tmpAddrPortEntry.port = port;
               SB_CPY_NADDR(&(tmpAddrPortEntry.localAddr), 
                            &(endpCb->localAddrLst.nAddr[j]));

               /* sb048.102: pass the tmpAddrPortCb address */
               cmHashListFind(&(sbGlobalCb.addrPortHl),
                                    (U8 *) &(tmpAddrPortEntry),
                                    (U16) sizeof(SbAddrPortEntry), 0,
                                    (PTR *) &tmpAddrPortCb);
               
               /* remove the addrPortCb that was inserted in this primitive */
               SB_FREE(sizeof(SbAddrPortCb), tmpAddrPortCb);
            }
         
            /* endpoint has been allocated so delete it */
            SB_FREE(sizeof(SbSctEndpCb), endpCb);
            sbGlobalCb.endpCb[spEndpId] = (SbSctEndpCb *) NULLP;
         
            SBLOGERROR(ERRCLS_INT_PAR, ESB018, (ErrVal)0,
                       "SbUiSctEndpOpenReq: Interface-port combination overlap");
            SbUiSctEndpOpenCfm( &(sctSap->sctPst), sctSap->suId, suEndpId,
                                0, SCT_NOK, SCT_CAUSE_ENDP_OPEN);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */
      }
      SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
             "SbUiSctEndpOpenReq: inserted addr/port entry into HL\n"));
      SbUiSctEndpOpenCfm( &(sctSap->sctPst), sctSap->suId, suEndpId,
                          spEndpId, SCT_OK, SCT_CAUSE_NOT_APPL);
      RETVALUE(ROK);
   } /* if ( endpCb == (SbSctEndpCb *) NULLP ) */
   else
   {
      Bool duplicateAddr = FALSE;
      /* compare if there is any address change */
#ifdef SCT_ENDP_MULTI_IPADDR
      U8 commonAddr = 0;
      for ( i = 0; i < intfNAddrLst->nmb; i++ )
      {
         for ( j = 0; j < endpCb->localAddrLst.nmb; j++ )
         {
            if (cmMemcmp((U8 *) &(intfNAddrLst->nAddr[i]), 
                         (U8 *) &(endpCb->localAddrLst.nAddr[j]), 
                         sizeof(CmNetAddr)) == 0)
            {
               commonAddr++;
               break;
            }
         }
      }
      if (commonAddr == intfNAddrLst->nmb)
      {
         duplicateAddr = TRUE;
      }
#else /* SCT_ENDP_MULTI_IPADDR */
      SB_CPY_NADDR(&(tmpAddr), intfNAddr);
      if (cmMemcmp((U8 *) &tmpAddr, (U8 *) &(endpCb->localAddrLst.nAddr[0]), 
                   sizeof(CmNetAddr)) == 0)
      {
         duplicateAddr = TRUE;
      }
#endif /* SCT_ENDP_MULTI_IPADDR */

      /* sb006.102: Updation - modified for alignment */
      if ( (endpCb->spId != spId) ||
           (endpCb->port != port) ||
           (duplicateAddr != TRUE) )
      {
         /* if we are here then the endpoint is trying to be reopened with
          * different values */

#if (ERRCLASS & ERRCLS_INT_PAR)
         SBLOGERROR(ERRCLS_INT_PAR, ESB019, (ErrVal)0,
                    "SbUiSctEndpOpenReq: trying to reopen endpoint");
#endif

         SbUiSctEndpOpenCfm( &(sctSap->sctPst), sctSap->suId, suEndpId,
                             spEndpId, SCT_NOK, SCT_CAUSE_ENDP_OPEN);
         RETVALUE(RFAILED);
      }
      else
      {
         SbUiSctEndpOpenCfm( &(sctSap->sctPst), sctSap->suId, suEndpId,
                             spEndpId, SCT_OK, SCT_CAUSE_NOT_APPL);
      }
   }
   RETVALUE(ROK);
}/* SbUiSctEndpOpenReq() */

/*
*
*       Fun:   SbUiSctEndpCloseReq
*
*       Desc:  Primitive to Close an Endpoint Server.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: This function closes an endpoint on the SCTP Layer.
*
*       File:  sb_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SbUiSctEndpCloseReq
(
Pst           *pst,              /* Post structure */
SpId           spId,             /* Service provider Id */
UConnId        endpId,           /* endpoint ID */
U8             endpIdType        /* service user/provider */
)
#else
PUBLIC S16 SbUiSctEndpCloseReq(pst, spId, endpId, endpIdType)
Pst           *pst;              /* Post structure */
SpId           spId;             /* Service provider Id */
UConnId        endpId;           /* endpoint ID */
U8             endpIdType;       /* service user/provider */
#endif
{
   /* local parameters */
   U32            i;
   SbSctEndpCb   *endpCb;
   SbSctSapCb    *sctSap;
   SbSctAssocCb  *assocCb;
   S16            ret;
   /* patch sb009.102 for endpoint close problem */
   U32            endpIndex;
   Bool           endpFound;
   /* sb068.102 for sending suEndpId in SbUiSctEndpCloseCfm if endpIdType = SCT_ENDPID_SP */ 
   UConnId        suEndpId;

   TRC3(SbUiSctEndpCloseReq)

#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                         (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbUiSctEndpCloseReq () failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctEndpCloseReq(pst, spId(%d), endpId(%ld), endpIdType(%d))\n",
          spId, endpId, endpIdType));

#ifndef SS_MULTIPLE_PROCS
   UNUSED(pst);
#endif  /* SS_MULTIPLE_PROCS */

   /* patch sb009.102 for endpoint close problem */
   endpIndex = 0;
   endpFound = FALSE;

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check the SpId. */
   SB_CHK_SPID(spId, LCM_EVENT_UI_INV_EVT, ret);
   if (ret != ROK)
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB020, (ErrVal)spId,
                 "SbUiSctEndpCloseReq: Invalid spId");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   /* get the SAP to operate on */
   sctSap = sbGlobalCb.sctSaps[spId];
   endpCb = (SbSctEndpCb *)NULLP;

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check the endpIdType */
   if ( (endpIdType != SCT_ENDPID_SU) && (endpIdType != SCT_ENDPID_SP) )
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB021, (ErrVal)endpIdType,
                 "SbUiSctEndpCloseReq: Invalid endpIdType");
      sbLmGenAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                   LCM_CAUSE_INV_PAR_VAL, spId, LSB_SW_RFC_REL0);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   if ( endpIdType == SCT_ENDPID_SP )
   {

#if (ERRCLASS & ERRCLS_INT_PAR)
      /* check if the endpoint exists */
      SB_CHK_SPENDPID(endpId, ret)
      if ( ret !=ROK )
      {
         SBLOGERROR(ERRCLS_INT_PAR, ESB022, (ErrVal)endpId,
                    "SbUiSctEndpCloseReq: Invalid spEndpId");
         sbLmGenAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                      LCM_CAUSE_INV_PAR_VAL, spId, LSB_SW_RFC_REL0);
         RETVALUE(RFAILED);
      }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

      /* get the endpoint control block */
      endpCb = sbGlobalCb.endpCb[endpId];
      /* sb017.102: Endpoint close problem while using multiple endpoint */
      endpFound = TRUE;
      endpIndex = endpId;

      /* sb068.102 for sending suEndpId in SbUiSctEndpCloseCfm if endpIdType = SCT_ENDPID_SP */ 
      suEndpId = endpCb->suEndpId;
   }
   else /* assocIdType == SCT_ENDPID_SU */
   {

      /* find an open endpoint with a matching spId and suEndpId */
      /* patch sb009.102 for endpoint close problem */
      for ( i = 0; (i < sbGlobalCb.genCfg.maxNmbEndp) && (endpFound == FALSE); i++ )
      {
         if ( sbGlobalCb.endpCb[i] != (SbSctEndpCb *) NULLP )
         {
            endpCb = sbGlobalCb.endpCb[i];
            if ( (endpCb->suEndpId == endpId) && (endpCb->spId == spId) )
            {
               /* if we are here then the endpoint exists */
               SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                  "SbUiSctEndpCloseReq: endpoint exists for suEndpId(%ld) and spId(%d)\n",
                  endpId, spId));

               /* patch sb009.102 for endpoint close problem */
               endpFound = TRUE;
               endpIndex = i;
            }
         }
      }

      /* patch sb009.102 for endpoint close problem */
      if ( !endpFound )
      {
         /* endpoint isn't open yet */
         /* send confirm */
         SbUiSctEndpCloseCfm( &(sctSap->sctPst), sctSap->suId, endpId,
                              SCT_OK, SCT_CAUSE_NOT_APPL);
         RETVALUE(ROK);
      }
   }

   /* if we are here then a matching endpoint was found and we must close it */

   /* abort and remove all associations on this endpoint */
   for ( i = 0; i < sbGlobalCb.genCfg.maxNmbAssoc; i++ )
   {
      assocCb = sbGlobalCb.assocCb[i];
      if ( assocCb != (SbSctAssocCb *) NULLP )
      {
         if ( assocCb->endpId == endpId )
         {
            ret = sbAsAbortAssoc(assocCb, TRUE);

            sbGlobalCb.assocCb[i] = (SbSctAssocCb *) NULLP;
            SB_FREE(sizeof(SbSctAssocCb), assocCb);

            if ( ret != ROK )
            {
               /* could not send ABORT chunk */
               SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                      "SbUiSctEndpCloseReq: could not send ABORT chunk\n"));
               if ( ret == ROUTRES )
               {
                  /* send alarm since the abort request is still being
                   * processed and we cant send a negative confirm */
                  sbLmGenAlarm(LCM_CATEGORY_RESOURCE,
                               LCM_EVENT_DMEM_ALLOC_FAIL,
                               LCM_CAUSE_MEM_ALLOC_FAIL, 0, LSB_SW_RFC_REL0);
               }
               /* continue anyway */
            }
         }
      }
   }

   /* remove the endpoint from the hash list, array and free its memory */
   if (endpCb != (SbSctEndpCb *)NULLP)
   {
      /* sb046.102: Multiple IP address per Endp */
      for ( i = 0; i < endpCb->localAddrLst.nmb; i++ )
      {
         SbAddrPortCb *tmpAddrPortCb=NULLP;
         SbAddrPortEntry tmpAddrPortEntry;

         /* sb048.102: memset tmpAddrPortEntry to zero  */
         cmMemset((U8 *)&tmpAddrPortEntry, 0, sizeof(SbAddrPortEntry));
         tmpAddrPortEntry.port = endpCb->port;
         SB_CPY_NADDR(&(tmpAddrPortEntry.localAddr), &(endpCb->localAddrLst.nAddr[i]));

         /* sb048.102: Pass the address of tmpAddrPrtCb */
         ret = cmHashListFind(&(sbGlobalCb.addrPortHl),
                              (U8 *) &(tmpAddrPortEntry),
                              (U16) sizeof(SbAddrPortEntry), 0,
                              (PTR *) &tmpAddrPortCb);
#if (ERRCLASS & ERRCLS_INT_PAR)
         if (ret != ROK)
         {
            SBLOGERROR(ERRCLS_INT_PAR, ESB017, (ErrVal)0,
               "SbUiSctEndpCloseReq: Invalid interface address/port, "
               "no addr/port found ");
            /* sb049 : If the hash list find fails */
            SbUiSctEndpCloseCfm( &(sctSap->sctPst), sctSap->suId, endpId,
                              SCT_NOK, SCT_CAUSE_NOT_APPL);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLASS & ERRCLS_INT_PAR */
         if (tmpAddrPortCb != (SbAddrPortCb *)NULLP)
         {
            ret = cmHashListDelete(&(sbGlobalCb.addrPortHl), (PTR) tmpAddrPortCb);
         }

#if (ERRCLASS & ERRCLS_DEBUG)
         if ( ret == RFAILED )
         {
            /* couldn't delete endpoint from hashlist */
            SBLOGERROR(ERRCLS_DEBUG, ESB023, (ErrVal)ret,
                 "SbUiSctEndpCloseReq: could not delete endpoint from HL");
            /* sb049 : If the hash list delete fails */
            SbUiSctEndpCloseCfm( &(sctSap->sctPst), sctSap->suId, endpId,
                              SCT_NOK, SCT_CAUSE_NOT_APPL);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_DEBUG */
         SB_FREE(sizeof(SbAddrPortCb), tmpAddrPortCb);
      }
   }

   /* patch sb009.102 for endpoint close problem */
   sbGlobalCb.endpCb[endpIndex] = (SbSctEndpCb *) NULLP;
   SB_FREE(sizeof(SbSctEndpCb), endpCb);

   /* sb068.102 for sending suEndpId in SbUiSctEndpCloseCfm if endpIdType = SCT_ENDPID_SP */  
   if ( endpIdType == SCT_ENDPID_SP )
   {
      /* send confirm */
      SbUiSctEndpCloseCfm( &(sctSap->sctPst), sctSap->suId, suEndpId,
                        SCT_OK, SCT_CAUSE_NOT_APPL);
   }
   else /* if ( endpIdType == SCT_ENDPID_SU ) */
   {
      /* send confirm */
      SbUiSctEndpCloseCfm( &(sctSap->sctPst), sctSap->suId, endpId,
                        SCT_OK, SCT_CAUSE_NOT_APPL);
   }
   RETVALUE(ROK);

} /* SbUiSctEndpCloseReq() */

/*
*
*       Fun:   SbUiSctAssocReq
*
*       Desc:  Primitive to Open an Association
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: This function tries to establish an association with a peer.
*              Termination indications are sent if something goes wrong.
*
*       File:  sb_bdy1.c
*
*/
/* ����ż������ԭ��.ZGS/2006.3.9 */
#ifdef ANSI
PUBLIC S16 SbUiSctAssocReq
(
Pst           *pst,              /* Post structure */
SpId           spId,             /* Service provider Id */
UConnId        spEndpId,         /* Service provider Endpoint ID */
UConnId        suAssocId,        /* Service user Association ID */
CmNetAddr     *priDstNAddr,      /* Primary destination network address */
SctPort        dstPort,          /* Destination port number */
SctStrmId      outStrms,         /* no. outgoing streams */
SctNetAddrLst *dstNAddrLst,      /* destination network address list */
SctNetAddrLst *srcNAddrLst,      /* source network address list */
/* sb021.102: Modification for TOS parameter */
#ifdef SCT3
SctTos         tos,              /* TOS Parameter */
#endif /* SCT3 */
Buffer        *vsInfo            /* VsInfo - not used anymore */
)
#else
/* sb021.102: Modification for TOS parameter */
#ifdef SCT3
PUBLIC S16 SbUiSctAssocReq(pst, spId, spEndpId, suAssocId, priDstNAddr,
                           dstPort, outStrms, dstNAddrLst, srcNAddrLst, 
                           tos, vsInfo)
#else
PUBLIC S16 SbUiSctAssocReq(pst, spId, spEndpId, suAssocId, priDstNAddr,
                           dstPort, outStrms, dstNAddrLst, srcNAddrLst, 
                           vsInfo)
#endif /* SCT3 */
Pst           *pst;              /* Post structure */
SpId           spId;             /* Service provider Id */
UConnId        spEndpId;         /* Service provider Endpoint ID */
UConnId        suAssocId;        /* Service user Association ID */
CmNetAddr     *priDstNAddr;      /* Primary destination network address */
SctPort        dstPort;          /* Destination port number */
SctStrmId      outStrms;         /* no. outgoing streams */
SctNetAddrLst *dstNAddrLst;      /* destination network address list */
SctNetAddrLst *srcNAddrLst;      /* source network address list */
/* sb021.102: Modification for TOS parameter */
#ifdef SCT3
SctTos         tos;              /* TOS Parameter */
#endif /* SCT3 */
Buffer        *vsInfo;           /* VsInfo - not used anymore */
#endif
{
   /* local parameters */
   U32            i;
   SbSctEndpCb   *endpCb;
   UConnId        spAssocId;
   SbSctSapCb    *sctSap;
   SbSctAssocCb  *assocCb;
   S16            ret;
   SctRtrvInfo    rtrv;
   /* sb004.12 - addition : Added to check the retvalue of sbPmAddAddr */
   SbAddrCb       *addrCb;
   /* sb021.102: Modification for TOS parameter */
#ifdef SCT3
   Bool           addrIpv4;
#endif /* SCT3 */
   /* Patch sb031.102 IPV6 Support Added */
   U32            addrCount;
   /* sb049.102: Warnings removed */
#ifdef SB_IPV6_SUPPORTED
   Bool           isAny; 
#endif /* SB_IPV6_SUPPORTED */

   TRC3(SbUiSctAssocReq)

#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                         (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbUiSctAssocReq () failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */

   /* SCTPv13 - vendor specific information removed */

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctAssocReq(pst, spId(%d), spEndpId(%ld), suAssocId(%ld), \
          priDstNAddr, dstPort(%d), outStrms(%d), dstNAddrLst, srcNAddrLst, \
          sInfo)\n",
          spId, spEndpId, suAssocId, dstPort, outStrms));

#ifndef SS_MULTIPLE_PROCS
   UNUSED(pst);
#endif  /* SS_MULTIPLE_PROCS */
   SB_CHK_PUTMSG(vsInfo);

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check the SpId. */
   SB_CHK_SPID(spId, LCM_EVENT_UI_INV_EVT, ret);
   if (ret != ROK)
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB024, (ErrVal)spId,
                 "SbUiSctAssocReq: Invalid spId");

      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   /* get the SAP to operate on */
   sctSap = sbGlobalCb.sctSaps[spId];

   SB_ZERO(&rtrv, sizeof(SctRtrvInfo));

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check if the endpoint exists */
   SB_CHK_SPENDPID(spEndpId, ret)
   if ( ret != ROK )
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB025, (ErrVal)spEndpId,
                 "SbUiSctAssocReq: Invalid spEndpId");

      SbUiSctTermInd( &(sctSap->sctPst), sctSap->suId, suAssocId,
                      SCT_ASSOCID_SU, SCT_STATUS_INV, SCT_CAUSE_INV_PAR_VAL,
                      &rtrv);
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* get the endpoint control block */
   endpCb = sbGlobalCb.endpCb[spEndpId];

   /* check the out streams parameter */
#if (ERRCLASS & ERRCLS_INT_PAR)
   if ( (outStrms > sbGlobalCb.genCfg.maxNmbOutStrms) || (outStrms == 0) )
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB026, (ErrVal)outStrms,
                 "SbUiSctAssocReq: Invalid outStrm");

      SbUiSctTermInd( &(sctSap->sctPst), sctSap->suId, suAssocId,
                      SCT_ASSOCID_SU, SCT_STATUS_INV, SCT_CAUSE_INV_PAR_VAL,
                      &rtrv);
      RETVALUE(RFAILED);
   }

   /* check to see if association ID exists */
   for ( i = 0; i < sbGlobalCb.genCfg.maxNmbAssoc; i++ )
   {
      assocCb = sbGlobalCb.assocCb[i];
      if ( assocCb != (SbSctAssocCb *) NULLP )
      {
         /* sb020.102: suAssocId should be unique per SAP */
         if ( ( assocCb->suAssocId == suAssocId ) && (assocCb->spId == spId) )
         {
            /* the association already exists */
#if 0   /* zhouguishuang closed this 2006-9-27 */
            SBLOGERROR(ERRCLS_INT_PAR, ESB027, (ErrVal)suAssocId,
                       "SbUiSctAssocReq: The association already exists.");
#endif
            SbUiSctTermInd( &(sctSap->sctPst), sctSap->suId, suAssocId,
                            SCT_ASSOCID_SU, SCT_STATUS_INV,
                            SCT_CAUSE_INV_PAR_VAL, &rtrv);
            RETVALUE(RFAILED);
         }
      }
   }

   /* check the primary destination transport address */
   SB_CHK_DTA(spEndpId, priDstNAddr, dstPort, ret);
   if ( ret == ROK )
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB028, (ErrVal)0,
                 "SbUiSctAssocReq: primary destination address overlaps");

      SbUiSctTermInd( &(sctSap->sctPst), sctSap->suId, suAssocId,
                      SCT_ASSOCID_SU, SCT_STATUS_INV, SCT_CAUSE_INV_PAR_VAL,
                      &rtrv);
      RETVALUE(RFAILED);
   }

   /* check the destination address list to see if DTA is already in use*/
   for ( i = 0; i < dstNAddrLst->nmb; i++ )
   {
      SB_CHK_DTA(spEndpId, &(dstNAddrLst->nAddr[i]), dstPort, ret);
      if ( ret == ROK )
      {
         /* the DTA exists if we are here */
         SBLOGERROR(ERRCLS_INT_PAR, ESB029, (ErrVal)0,
                    "SbUiSctAssocReq: overlap in destination address list");

         SbUiSctTermInd( &(sctSap->sctPst), sctSap->suId, suAssocId,
                         SCT_ASSOCID_SU, SCT_STATUS_INV, SCT_CAUSE_INV_PAR_VAL,
                         &rtrv);
         RETVALUE(RFAILED);
      }
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* find the first unused association entry in the array */
   i = 0;
   while ( (i < sbGlobalCb.genCfg.maxNmbAssoc) &&                       /* ����һ��ż����Ŀ ZGS/2006.3.9 */
           (sbGlobalCb.assocCb[i] != (SbSctAssocCb *) NULLP) )
   {
      i++;
   }
   spAssocId = i;

   /* see if there is space for a new association */
   if ( spAssocId == sbGlobalCb.genCfg.maxNmbAssoc )
   {
      /* association array full */
      SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
             "SbUiSctAssocReq: config. max reached for number of assocs\n"));

      SbUiSctTermInd( &(sctSap->sctPst), sctSap->suId, suAssocId,
                      SCT_ASSOCID_SU, SCT_STATUS_INV, SCT_CAUSE_OUTRES,
                      &rtrv);
      RETVALUE(RFAILED);
   }

   /* sb021.102: Modification for TOS parameter */
#ifdef SCT3
   /* tos parameter is supported only in IPV4 */
   addrIpv4 = TRUE;  
   for ( i = 0; i < srcNAddrLst->nmb; i++ )
      if ( srcNAddrLst->nAddr[i].type != CM_NETADDR_IPV4 )
         addrIpv4 = FALSE;

   if ( addrIpv4 == FALSE )
   {
      /* address type is not IPV4 */
      SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
             "SbUiSctAssocReq: tos parameter supportd only in IPV4\n"));

      SbUiSctTermInd( &(sctSap->sctPst), sctSap->suId, suAssocId,
                      SCT_ASSOCID_SU, SCT_STATUS_INV, SCT_CAUSE_INV_PAR_VAL,
                      &rtrv);
      RETVALUE(RFAILED);
   }
#endif /* SCT3 */

   /* create new association control block */
   SB_ALLOC(sizeof(SbSctAssocCb), assocCb, ret);                            /* ����һ��ż�����ƿ� ZGS/2006.3.9 */
   if ( ret != ROK )
   {
      SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
             "SbUiSctAssocReq: could not allocate new association\n"));

      SbUiSctTermInd( &(sctSap->sctPst), sctSap->suId, suAssocId,
                      SCT_ASSOCID_SU, SCT_STATUS_INV, SCT_CAUSE_OUTRES,
                      &rtrv);
      RETVALUE(RFAILED);
   }

   assocCb->spId        = spId;
   assocCb->endpId      = spEndpId;
   assocCb->suAssocId   = suAssocId;
   assocCb->spAssocId   = spAssocId;
   assocCb->assocState  = SB_ST_CLOSED;
   /* sb021.102: Modification for TOS parameter */
#ifdef SCT3
   assocCb->tos         = tos; 
#endif /* SCT3 */
   assocCb->peerInitTag = 0;
   sbRand32(0, &(assocCb->ownInitTag));
   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctAssocReq: assocCb->ownInitTag=%lu\n",
           assocCb->ownInitTag));
   /* sb006.102: Updation - modified for alignment */
   /* sb046.102: Multiple IP address per Endp */
   assocCb->localPort   = endpCb->port;
   assocCb->peerPort    = dstPort;

   /* get the local address control block */                            /* ȡ�þֲ���ַ���ƿ� */
   SB_GET_LOCAL_CONN(spEndpId, assocCb->localConn, ret);
#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( ret != ROK )
   {
      SB_FREE(sizeof(SbSctAssocCb), assocCb);

      SBLOGERROR(ERRCLS_DEBUG, ESB030, (ErrVal)0,
                 "SbUiSctAssocReq: could not find local address CB in HL");
      SbUiSctTermInd( &(sctSap->sctPst), sctSap->suId, suAssocId,
                      SCT_ASSOCID_SU, SCT_STATUS_INV, SCT_CAUSE_UNKNOWN,
                      &rtrv);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_DEBUG */

   assocCb->sbSqCb.nmbOutStreams   = outStrms;
   assocCb->sbSqCb.nmbInStreams    = sbGlobalCb.genCfg.maxNmbInStrms;
   assocCb->sbSqCb.inStreamSeqNum  = (SctStrmId *) NULLP;
   assocCb->sbSqCb.outStreamSeqNum = (SctStrmId *) NULLP;

   assocCb->sbAcCb.nextLocalTsn = assocCb->ownInitTag;
   assocCb->sbAcCb.cumTsn       = assocCb->ownInitTag - 1;
   assocCb->sbAcCb.cumPeerTsn   = 0;
   /* sb020.102: Double SACK problem */
   assocCb->sbAcCb.cumPeerTsnAcked   = 0;
   assocCb->sbAcCb.rwnd         = 0;
   assocCb->sbAcCb.rtxCnt       = 0;
   assocCb->sbAcCb.sinceSack    = sctSap->sctSapCfg.reConfig.maxAckDelayDg - 1;
   assocCb->sbAcCb.bytesOut     = 0;
   assocCb->sbAcCb.pri          = (SbAddrCb *) NULLP;
   assocCb->sbAcCb.tsnLstSz     = 0;
   assocCb->sbAcCb.rcvDupTsnFlg = FALSE;
   assocCb->sbAcCb.dupTsnLstSz  = 0;
   assocCb->sbAcCb.ownRWnd      = sbGlobalCb.genCfg.initARwnd;
   /* sb015.102: DNS timer problem */
   assocCb->sbDnsCb.dnsTmrInit  = FALSE;

   /* Initialize the ack delay timer */
   cmInitTimers(&(assocCb->sbAcCb.ackDelayTmr), 1);

   /* Initialize the address linked lists */
   (Void) cmLListInit(&(assocCb->sbAcCb.addrLst));

   /* source network address list stuff */
   if ( srcNAddrLst->nmb == 0 )
   {
      /* User didn't specify so use endpoint configured value */
      /* sb046.102: Multiple IP address per Endp. If IP_ANY is used, only one
       * IP address is in the Endpoint address list */
      if ( (endpCb->localAddrLst.nmb == 1 ) &&
           (endpCb->localAddrLst.nAddr[0].type == CM_NETADDR_IPV4) &&
           (endpCb->localAddrLst.nAddr[0].u.ipv4NetAddr == 0) )
      {

         /* IP_ANY so fill in the config. values for the TSAP */
         SbTSapCb          *tSap;                     /* local variable */

         /* get transport SAP */
         tSap = sbGlobalCb.tSaps[assocCb->localConn->suId];

         if (sbGlobalCb.genCfg.useHstName  == TRUE) 
         {
            /* If useHstName is TRUE, then set localAddrLst to 0 */
            assocCb->sbAsCb.localAddrLst.nmb=0;
            assocCb->incldHstName  = TRUE;
         }
         else
         {
            /* Patch sb031.102 IPV6 Support Added */
            /* copy the src address list */
            for(addrCount=0; addrCount < tSap->tSapCfg.srcNAddrLst.nmb; addrCount++)
            {
               if(tSap->tSapCfg.srcNAddrLst.nAddr[addrCount].type == CM_NETADDR_IPV4)
               {
                   SB_CPY_NADDR(&(assocCb->sbAsCb.localAddrLst.nAddr[assocCb->sbAsCb.localAddrLst.nmb]),
                         &(tSap->tSapCfg.srcNAddrLst.nAddr[addrCount]));
                   assocCb->sbAsCb.localAddrLst.nmb++;
               }
           }

           /* remove the last address if this is TSAP 0 because then 
            * the last address is IP_ANY */
            /* Patch sb031.102 IPV6 Support Added */
           /* if (tSap->ipv4_any == TRUE)*/
           /* sb046.102: Multiple IP address per Endp.*/
            if ((tSap->ipv4_any == TRUE) && (assocCb->localConn->suId == 0)) 
            {
              /* sb002.12 : check nmb==0 case before decrementing it */
              if (assocCb->sbAsCb.localAddrLst.nmb > 0)
              {
                 assocCb->sbAsCb.localAddrLst.nmb--;
              }
            }

         }
      }
      /* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
      /* Copy the IPV6 addresses from TSAP configuration */
      else if ( (endpCb->localAddrLst.nmb == 1 ) &&
                (endpCb->localAddrLst.nAddr[0].type == CM_NETADDR_IPV6) )
      {
         SB_INET6_ISANY(endpCb->localAddrLst.nAddr[0].u.ipv6NetAddr, &isAny)
         if(isAny == TRUE)
         {

         /* IP_ANY so fill in the config. values for the TSAP */
         SbTSapCb          *tSap;                     /* local variable */

         /* get transport SAP */
         tSap = sbGlobalCb.tSaps[assocCb->localConn->suId];

         if (sbGlobalCb.genCfg.useHstName  == TRUE) 
         {
            /* If useHstName is TRUE, then set localAddrLst to 0 */
            assocCb->sbAsCb.localAddrLst.nmb=0;
            assocCb->incldHstName  = TRUE;
         }
         else
         {
            /* copy the src address list */
            for(addrCount=0; addrCount < tSap->tSapCfg.srcNAddrLst.nmb; addrCount++)
            {
               if(tSap->tSapCfg.srcNAddrLst.nAddr[addrCount].type == CM_NETADDR_IPV6)
               {
                   SB_CPY_NADDR(&(assocCb->sbAsCb.localAddrLst.nAddr[assocCb->sbAsCb.localAddrLst.nmb]),
                         &(tSap->tSapCfg.srcNAddrLst.nAddr[addrCount]));
                   assocCb->sbAsCb.localAddrLst.nmb++;
               }
          }

           /* remove the last address if this is TSAP 0 because then 
            * the last address is IP_ANY */
           /* if (assocCb->localConn->suId == 0) */
            if (tSap->ipv6_any == TRUE)
            {
              if (assocCb->sbAsCb.localAddrLst.nmb > 0)
              {
                 assocCb->sbAsCb.localAddrLst.nmb--;
              }
            }

         }
       }
      }
#endif
      else
      {
         /* sb046.102: Multiple IP address per Endp. */
         SB_CPY_NADDRLST(&(assocCb->sbAsCb.localAddrLst), 
                         &(endpCb->localAddrLst));
      }
   }
   else
   {
      /* use the user supplied addresses */
      SB_CPY_NADDRLST(&(assocCb->sbAsCb.localAddrLst), srcNAddrLst);
   }

   /* initialize the "general purpose timer" */
   (Void) cmInitTimers(&(assocCb->sbAsCb.timer), 1);           /* ��ʼ��ͨ��Ŀ�Ķ�ʱ�� */

   /* set up the queues */
   assocCb->sbDbCb.sequencedQ = (CmLListCp *) NULLP;
   /* Performance fix */
   assocCb->sbDbCb.newPkt = NULLP; 
   cmLListInit(&(assocCb->sbDbCb.tsnWaitingQOrd));
   cmLListInit(&(assocCb->sbDbCb.tsnWaitingQUnord));
   cmLListInit(&(assocCb->sbDbCb.assemblyQ));
   cmLListInit(&(assocCb->sbDbCb.congestionQ));

   /* insert new association control block into global array list */
   sbGlobalCb.assocCb[spAssocId] = assocCb;

   /* add addresses (they have all been checked already) */
   addrCb = sbPmAddAddr(sctSap, assocCb, priDstNAddr);
   
   /* sb004.12 - Addition : If sbPmAddAddr function fails then we will send
    * TermInd to the upper layer  */
   if ( addrCb == NULLP )
   {
      SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
             "SbUiSctAssocReq: Failure from sbPmAddAddr, Terminating Assoc\n"));
      
      /* sb020.102: Association control block freed */
      sbGlobalCb.assocCb[spAssocId] = (SbSctAssocCb *) NULLP;
      SB_FREE(sizeof(SbSctAssocCb), assocCb);

      SBLOGERROR(ERRCLS_DEBUG, ESBXXX, (ErrVal)0,
                 "SbUiSctAssocReq: Failure returned from function sbPmAddAddr\n ");
      SbUiSctTermInd( &(sctSap->sctPst), sctSap->suId, suAssocId,
                      SCT_ASSOCID_SU, SCT_STATUS_INV, SCT_CAUSE_UNKNOWN,
                      &rtrv);
      RETVALUE(RFAILED);
   }
   for ( i = 0; i < dstNAddrLst->nmb; i++ )
   {
     /* sb004.12 - Modification : If sbPmAddAddr function fails then we will send
      * TermInd to the upper layer  */
      /* sb020.102: Primary destination address should not come in address list */
      if (sbPmCompNAddr(priDstNAddr,(CmNetAddr *) &(dstNAddrLst->nAddr[i])) == ROK)
         continue;
      addrCb = sbPmAddAddr(sctSap, assocCb,
                         (CmNetAddr *) &(dstNAddrLst->nAddr[i]));
      if ( addrCb == NULLP )
      {
      
         SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
             "SbUiSctAssocReq: Failure from sbPmAddAddr, Terminating Assoc\n"));

         /* sb020.102: Association control block freed */
         sbGlobalCb.assocCb[spAssocId] = (SbSctAssocCb *) NULLP;
         SB_FREE(sizeof(SbSctAssocCb), assocCb);

         SBLOGERROR(ERRCLS_DEBUG, ESBXXX, (ErrVal)0,
                  "SbUiSctAssocReq: Failure returned from function sbPmAddAddr\n ");
         SbUiSctTermInd( &(sctSap->sctPst), sctSap->suId, suAssocId,
                        SCT_ASSOCID_SU, SCT_STATUS_INV, SCT_CAUSE_UNKNOWN,
                        &rtrv);
         RETVALUE(RFAILED);
      }
   }

   /* set the dest address screening flag here */
   if (dstNAddrLst->nmb == 0)
   {
      assocCb->sbAcCb.pAddrScrnFlg = FALSE;
   }
   else
   {
      assocCb->sbAcCb.pAddrScrnFlg = TRUE;
   }

   /* Finished creating new association */

   /* send an INIT chunk to the peer */
   ret = sbAsSendInit(assocCb, 0, 0 );                                         /* ����INIT��Ϣ���Է� ZGS/2006 */
   if ( ret != ROK )
   {
      /* undo everything */

      /* no ABORT chunk sent so no need to check output */
      (Void) sbAsAbortAssoc(assocCb, FALSE);
      sbGlobalCb.assocCb[spAssocId] = (SbSctAssocCb *) NULLP;
      SB_FREE(sizeof(SbSctAssocCb), assocCb);

      if ( ret == RFAILED )            /* ret from the SendInit */
      {
         SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
             "SbUiSctAssocReq: could not send INIT chunk\n"));
         SbUiSctTermInd( &(sctSap->sctPst), sctSap->suId, suAssocId,
                         SCT_ASSOCID_SU, SCT_STATUS_INV, SCT_CAUSE_INIT_FAILED,
                         &rtrv);
         RETVALUE(RFAILED);
      }
      else if ( ret == ROUTRES )       /* ret from the SendInit */
      {
         SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
             "SbUiSctAssocReq: could not build INIT chunk\n"));
         SbUiSctTermInd( &(sctSap->sctPst), sctSap->suId, suAssocId,
                         SCT_ASSOCID_SU, SCT_STATUS_INV, SCT_CAUSE_OUTRES,
                         &rtrv);
         RETVALUE(RFAILED);
      }

      RETVALUE(ROK);
   }

   /* INIT sent so enter COOKIE_WAIT state and start Init-timer */
   assocCb->assocState = SB_ST_COOKIE_WAIT;                               /* ��Ǩ״̬��SB_ST_COOKIE_WAIT ZGS/2006 */

   assocCb->sbAsCb.rtxCnt = 0;                  /* one INIT sent */
   SB_START_TMR(&(assocCb->sbAsCb.timer), assocCb, SB_TMR_INIT,           /* ������ʱ��SB_TMR_INIT ZGS/2006 */
                sctSap->sctSapCfg.reConfig.rtoInitial);

   RETVALUE(ROK);
}/* SbUiSctAssocReq() */

/*
*
*       Fun:   SbUiSctAssocRsp
*
*       Desc:  Primitive to Respond to an Open an Association Indication
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: This function tries to establish an association with a peer.
*              Termination indications are sent if something goes wrong.
*
*       File:  sb_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SbUiSctAssocRsp
(
Pst                  *pst,              /* Post structure */
SpId                  spId,             /* Service provider SAP ID */
UConnId               spEndpId,         /* Service provider endpoint ID */
SctAssocIndParams    *assocIndParams,   /* interface specific params */
/* sb021.102: Modification for TOS parameter */
#ifdef SCT3
SctTos                tos,              /* TOS parameter */
#endif /* SCT3 */
SctResult             result,          /* result */
Buffer               *vsInfo           /* VsInfo - not used any more */
)
#else
/* sb021.102: Modification for TOS parameter */
#ifdef SCT3
PUBLIC S16 SbUiSctAssocRsp(pst, spId, spEndpId, assocIndParams, 
                           tos, result, vsInfo)
#else 
PUBLIC S16 SbUiSctAssocRsp(pst, spId, spEndpId, assocIndParams, 
                           result, vsInfo)
#endif /* SCT3 */
Pst                  *pst;              /* Post structure */
SpId                  spId;             /* Service provider SAP ID */
UConnId               spEndpId;         /* Service provider endpoint ID */
SctAssocIndParams    *assocIndParams;   /* interface specific params */
/* sb021.102: Modification for TOS parameter */
#ifdef SCT3
SctTos                tos;              /* TOS parameter */
#endif /* SCT3 */
SctResult             result;           /* result */
Buffer               *vsInfo;          /* VsInfo - not used any more */
#endif
{
   /* local parameters */
   S16             ret;
   SbSctSapCb     *sctSap;
   SbLocalAddrCb  *localAddrCb;
   SbSctEndpCb    *endpCb;
   SbSctAssocCb   *assocCb;
   SbQueuedChunk  *chunk;
   SbAddrCb       *addrCb;
   CmLList        *n;
   CmLListCp      *l;
   U32             i;
   U32             j;
   SbTcb           tcb;
   SctRtrvInfo     rtrv;

   TRC3(SbUiSctAssocRsp)

#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                         (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbUiSctAssocRsp () failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */

  /* SCTPv13  - Vendor specific info removed */

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctAssocRsp(pst, spId(%d), spEndpId(%ld))\n",
          spId, spEndpId));

#ifndef SS_MULTIPLE_PROCS
   UNUSED(pst);
#endif  /* SS_MULTIPLE_PROCS */
   SB_CHK_PUTMSG(vsInfo);

   /* Sanity checks */
#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check the SpId. */
   SB_CHK_SPID(spId, LCM_EVENT_UI_INV_EVT, ret);
   if (ret != ROK)
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB031, (ErrVal)spId,
                 "SbUiSctAssocRsp: Invalid spId");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   sctSap = sbGlobalCb.sctSaps[spId];

   SB_ZERO(&rtrv, sizeof(SctRtrvInfo));

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check if the endpoint exists */
   SB_CHK_SPENDPID(spEndpId, ret)

   if (ret != ROK)
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB032, (ErrVal)spEndpId,
                 "SbUiSctAssocRsp: Invalid spEndpId");

      if ( assocIndParams->type == SCT_ASSOC_IND_COOKIE )
      {
         SbUiSctTermInd( &(sctSap->sctPst), sctSap->suId,
                         assocIndParams->t.cookieParams.suAssocId,
                         SCT_ASSOCID_SU, SCT_STATUS_INV, SCT_CAUSE_INV_PAR_VAL,
                         &rtrv);
      }
      else
      {
         /* no confirm so send alarm */
         sbLmGenAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                      LCM_CAUSE_INV_PAR_VAL, spId, LSB_SW_RFC_REL0);
      }

      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* get the endpoint control block */
   endpCb = sbGlobalCb.endpCb[spEndpId];

   /* get link through to TSAP */
   SB_GET_LOCAL_CONN(spEndpId, localAddrCb, ret);

#if ( ERRCLASS & ERRCLS_DEBUG )
   if ( ret != ROK )
   {
      SBLOGERROR(ERRCLS_DEBUG, ESB033, (ErrVal)0,
                 "SbUiSctAssocRsp: could not find local address CB in HL");


      if ( assocIndParams->type == SCT_ASSOC_IND_COOKIE )
      {
         SbUiSctTermInd( &(sctSap->sctPst), sctSap->suId,
                         assocIndParams->t.cookieParams.suAssocId,
                         SCT_ASSOCID_SU, SCT_STATUS_INV, SCT_CAUSE_UNKNOWN,
                         &rtrv);
      }

      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_DEBUG */

   /* Distinguish between INIT and COOKIE processing */
   if ( assocIndParams->type == SCT_ASSOC_IND_INIT )               /* INIT */
   {
      SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
             "SbUiSctAssocRsp: assocIndParams->type = SCT_ASSOC_IND_INIT\n"));

      /* Check result of previous assoc indication */
      if ( result != SCT_OK )
      {
/* sb021.102: Modification for TOS parameter */
#ifdef SCT3
         ret = sbAsSendAbort(assocIndParams->t.initParams.iTag, localAddrCb,
                  &(assocIndParams->t.initParams.peerAddrLst.nAddr[0]),
                  assocIndParams->t.initParams.localPort,
                  assocIndParams->t.initParams.peerPort, FALSE, tos);
#else
         ret = sbAsSendAbort(assocIndParams->t.initParams.iTag, localAddrCb,
                  &(assocIndParams->t.initParams.peerAddrLst.nAddr[0]),
                  assocIndParams->t.initParams.localPort,
                  assocIndParams->t.initParams.peerPort, FALSE);
#endif /* SCT3 */

         if ( ret == ROUTRES )
         {
            SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                   "SbUiSctAssocRsp: could not build ABORT chunk\n"));

            /* we send an alarm since the abort process still continues and
            * there are no positive confirms that cover resource failure */
            sbLmGenAlarm(LCM_CATEGORY_RESOURCE,
                         LCM_EVENT_DMEM_ALLOC_FAIL,
                         LCM_CAUSE_MEM_ALLOC_FAIL, 0, LSB_SW_RFC_REL0);

            /* continue anyway */
         }
         else if ( ret == RFAILED )
         {
            SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                "SbUiSctAssocRsp: could not send ABORT chunk\n"));
            /* continue anyway */
         }

      }
      else              /* result == SCT_OK */
      {


#if (ERRCLASS & ERRCLS_INT_PAR)
         /* check the streams */
         /* Alarms sent since no confirms here */

         if ( (assocIndParams->t.initParams.outStrms == 0) ||
              (assocIndParams->t.initParams.outStrms >
               sbGlobalCb.genCfg.maxNmbOutStrms) )
         {
            SBLOGERROR(ERRCLS_INT_PAR, ESB034,
                       (ErrVal)assocIndParams->t.initParams.outStrms,
                       "SbUiSctAssocRsp: Invalid outStrms");

            sbLmGenAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                         LCM_CAUSE_INV_PAR_VAL, spId, LSB_SW_RFC_REL0);

            RETVALUE(RFAILED);
         }

         if ( (assocIndParams->t.initParams.inStrms == 0) ||
              (assocIndParams->t.initParams.inStrms >
               sbGlobalCb.genCfg.maxNmbInStrms) )
         {
            SBLOGERROR(ERRCLS_INT_PAR, ESB035,
                       (ErrVal)assocIndParams->t.initParams.inStrms,
                       "SbUiSctAssocRsp: Invalid inStrms");

            sbLmGenAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                         LCM_CAUSE_INV_PAR_VAL, spId, LSB_SW_RFC_REL0);

            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */

         /* build and send an INIT ACK */
         sbRand32(SB_RAND_GEN, &j);
         if ( j == 0 )
         {
            j++;
         }
         tcb.tcbInitAck.iTag = j;
         if ( sbGlobalCb.genCfg.reConfig.altAcceptFlg == FALSE)
         {
            assocIndParams->t.initParams.cookieLife = 0;
         }

/* sb021.102: Modification for TOS parameter */
#ifdef SCT3
         ret = sbAsSendInitAck(spId, assocIndParams, &tcb, localAddrCb,
                               tos, (Buffer *)NULLP);
#else
         ret = sbAsSendInitAck(spId, assocIndParams, &tcb, localAddrCb,
                               (Buffer *)NULLP);
#endif
         if ( ret != ROK )
         {
            SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                   "SbUiSctAssocRsp: could not build/send INIT ACK chunk\n"));
            if ( ret == ROUTRES )
            {
               /* no confirm covers this so send layer manager alarm */
               sbLmGenAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                            LCM_CAUSE_MEM_ALLOC_FAIL, 0, LSB_SW_RFC_REL0);
            }
            /* continue anyway */
         }
      }

   }
   else if ( assocIndParams->type == SCT_ASSOC_IND_COOKIE )        /* COOKIE */
   {
      SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
             "SbUiSctAssocRsp: assocIndParams->type = SCT_ASSOC_IND_COOKIE\n"));


      /* get the assoc CB */
      assocCb = sbGlobalCb.assocCb[assocIndParams->t.cookieParams.spAssocId];

      if ( result != SCT_OK )
      {
         /* user does not want this association */
         ret = sbAsAbortAssoc(assocCb, TRUE);

         if ( ret != ROK )
         {
            SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                   "SbUiSctAssocRsp: could not build ABORT chunk\n"));
            if ( ret == ROUTRES )
            {
               /* we send an alarm since the abort process still continues and
               * there are no positive confirms that cover resource failure */
               sbLmGenAlarm(LCM_CATEGORY_RESOURCE,
                            LCM_EVENT_DMEM_ALLOC_FAIL,
                            LCM_CAUSE_MEM_ALLOC_FAIL, 0, LSB_SW_RFC_REL0);
            }
            /* continue anyway */
         }

         /* remove from the list and free the memory */
         sbGlobalCb.assocCb[assocIndParams->t.cookieParams.spAssocId] =
               (SbSctAssocCb *) NULLP;
         SB_FREE(sizeof(SbSctAssocCb), assocCb);

      }
      else                                /* result == SCT_OK */
      {

         /* user wants this association */
         assocCb->suAssocId = assocIndParams->t.cookieParams.suAssocId;

/* sb056.102 : Addition - In case of primary dest address failure
                          try assoc on alternate dest addr of
                          address list 
*/
          /* reset the addrlist and redefine as per peer */
          l = &(assocCb->sbAcCb.addrLst);
          n = cmLListFirst(l);
          for ( i = 0; i < cmLListLen(l); i++ )
          {
             addrCb = (SbAddrCb *)(n->node);
             if ( addrCb != (SbAddrCb *) NULLP )
             {
                addrCb->sndTo = FALSE;
             }
             n = cmLListNext(l);
          }
 
         if ( assocIndParams->t.cookieParams.peerAddrLst.nmb == 0 )
         {
            /* user wants to use configured address list */
            l = &(assocCb->sbAcCb.addrLst);
            n = cmLListFirst(l);
            for ( i = 0; i < cmLListLen(l); i++ )
            {
               addrCb = (SbAddrCb *)(n->node);
               if ( addrCb != (SbAddrCb *) NULLP )
               {
                  addrCb->sndTo = TRUE;
                  addrCb->rcvFrom = TRUE;
               }
               n = cmLListNext(l);
            }
         }
         else
         {
            /* user has selected address list subset */
            for ( i = 0; i < assocIndParams->t.cookieParams.peerAddrLst.nmb; \
                  i++ )
            {
               addrCb = sbPmGetAddrCb(assocCb, &(assocIndParams-> \
                                      t.cookieParams.peerAddrLst.nAddr[i]));
               if ( addrCb != (SbAddrCb *) NULLP )
               {
                  addrCb->sndTo = TRUE;
                  addrCb->rcvFrom = TRUE;
               }
#if (ERRCLASS & ERRCLS_INT_PAR)
               else
               {
                  /* address is invalid, send error notification */
                  SBLOGERROR(ERRCLS_INT_PAR, ESB036, (ErrVal)0,
                             "SbUiSctAssocRsp: Invalid peer address");

                  /* sb036.102: remove the association control block */
                  sbGlobalCb.assocCb[assocIndParams->t.cookieParams.spAssocId] =
                        (SbSctAssocCb *) NULLP;
                  SB_FREE(sizeof(SbSctAssocCb), assocCb);

                  SbUiSctTermInd( &(sctSap->sctPst), sctSap->suId,
                                  assocIndParams->t.cookieParams.suAssocId,
                                  SCT_ASSOCID_SU, SCT_STATUS_INV,
                                  SCT_CAUSE_INV_PAR_VAL, &rtrv);
                  RETVALUE(RFAILED);
               }
#endif /* ERRCLS_INT_PAR */

            }  /* for */
         } /* if peerAddrLst.nmb */

         /* send COOKIE ACK */
         /* sb021.102: Modification for TOS parameter */
#ifdef SCT3
         assocCb->tos = tos;              /* TOS parameter */
#endif /* SCT3 */
         ret = sbAsSendCookieAck(assocCb, &(assocCb->sbAcCb.pri->addr));
         if ( ret != ROK )
         {
            SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                   "SbUiSctAssocRsp: could not send COOKIE ACK chunk\n"));
            /* get resource error */
            if ( ret == ROUTRES )
            {
               sbLmGenAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                            LCM_CAUSE_MEM_ALLOC_FAIL, 0, LSB_SW_RFC_REL0);
            }
            RETVALUE(RFAILED);
         }

         /* send COMM UP notification */
         SbUiSctStaInd(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                       assocCb->spAssocId, &(assocCb->sbAcCb.pri->addr),
                       SCT_STATUS_COMM_UP, SCT_CAUSE_NOT_APPL,
                       (Buffer *) NULLP);

         /* association now established */
         assocCb->assocState = SB_ST_ESTABLISHED;

         /* look for chunks that arrived with the cookie */
         for ( i = 0; i < assocCb->sbSqCb.nmbInStreams; i++ )
         {
            chunk = sbDbOrdered(assocCb, (SctStrmId)i,
                                assocCb->sbSqCb.inStreamSeqNum[i]);
            while ( chunk != (SbQueuedChunk *) NULLP )
            {
               /* send them up to the user */
               ret = sbSqInSendUp(assocCb, chunk, SCT_PEER_DAT);
               if ( ret != ROK )
               {
                  SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                         "SbUiSctAssocRsp: could not send chunks to user\n"));
               }
               assocCb->sbSqCb.inStreamSeqNum[i]++;

               chunk = sbDbOrdered(assocCb, (SctStrmId)i,
                                   assocCb->sbSqCb.inStreamSeqNum[i]);
            }
         }
        
         /* HBEAT - Here check if heartbeat is to be enabled by default the do it */
        if(sctSap->sctSapCfg.reConfig.hBeatEnable == TRUE )
        {
            SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                   "SbUiSctAssocRsp: Enabling HeartBeat By Default \n"));

            l = &(assocCb->sbAcCb.addrLst);
            n = cmLListFirst(l);

            /* enable/disable on an association */
            for ( i = 0; i < cmLListLen(l); i++)
            {
               addrCb = (SbAddrCb *)n->node;
               if (addrCb->sndTo == TRUE)
               {
                  sbPmHBeatEnb(addrCb, 0);
               }
               n = cmLListNext(l);
            }
         }
      }
   }

   RETVALUE(ROK);
}/* SbUiSctAssocRsp() */

/*
*
*       Fun:   SbUiSctTermReq
*
*       Desc:  Primitive to Request Termination of an Association
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: This function tries to terminate an association with a peer.
*              Termination confirmation is sent on successful completion with
*              positive status, and with negative status if something went
*              wrong. The termination procedure can be graceful or ungraceful.
*
*       File:  sb_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SbUiSctTermReq
(
Pst                  *pst,              /* Post structure */
SpId                  spId,             /* Service provider SAP ID */
UConnId               assocId,          /* Association ID */
U8                    assocIdType,      /* Association ID type */
Bool                  abortFlg          /* Termination type */
)
#else
PUBLIC S16 SbUiSctTermReq(pst, spId, assocId, assocIdType, abortFlg)
Pst                  *pst;              /* Post structure */
SpId                  spId;             /* Service provider SAP ID */
UConnId               assocId;          /* Association ID */
U8                    assocIdType;      /* Association ID type */
Bool                  abortFlg;         /* Termination type */
#endif
{
   /* local parameters */
   SbSctSapCb     *sctSap;
   SbSctAssocCb   *assocCb;
   U32             i;
   S16             ret;
   UConnId         suAssocId;

   TRC3(SbUiSctTermReq)

#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                         (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbUiSctTermReq () failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
       "SbUiSctTermReq(pst, spId(%d), assocId(%ld), assocIdType(%d), \
       abortFlg(%d))\n",
       spId, assocId, assocIdType, abortFlg));

#ifndef SS_MULTIPLE_PROCS
   UNUSED(pst);
#endif  /* SS_MULTIPLE_PROCS */

   /* Sanity checks */

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check the SpId. */
   SB_CHK_SPID(spId, LCM_EVENT_UI_INV_EVT, ret);
   if (ret != ROK)
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB037, (ErrVal)spId,
                 "SbUiSctTermReq: Invalid spId");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   /* get the SCT SAP control block */
   sctSap = sbGlobalCb.sctSaps[spId];

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate the assocIdType */
   if ( (assocIdType != SCT_ASSOCID_SU) && (assocIdType != SCT_ASSOCID_SP) )
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB038, (ErrVal)assocIdType,
                 "SbUiSctTermReq: Invalid assocIdType");
      sbLmGenAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                   LCM_CAUSE_INV_PAR_VAL, spId, LSB_SW_RFC_REL0);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   /* the validation check for the assocIdType is at the bottom */
   if ( assocIdType == SCT_ASSOCID_SU)                 /* service user ID */
   {
      for (i = 0; i < sbGlobalCb.genCfg.maxNmbAssoc; i++ )
      {
         assocCb = sbGlobalCb.assocCb[i];
         if ( assocCb != (SbSctAssocCb *) NULLP )
         {
            /* find a match for the suAssocId */
            /* sb020.102: suAssocId should be unique per SAP */
            if ( (assocCb->suAssocId == assocId ) && (assocCb->spId == spId) )
            {
               /* Only Abort Permitted, no graceful shutdown */
               ret = sbAsAbortAssoc(assocCb, TRUE);

               sbGlobalCb.assocCb[i] = (SbSctAssocCb *) NULLP;
               SB_FREE(sizeof(SbSctAssocCb), assocCb);

               if ( ret != ROK )
               {
                  /* could not send ABORT chunk */
                  SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                         "SbUiSctTermReq: could not send ABORT chunk\n"));
                  if ( ret == ROUTRES )
                  {
                     /* send alarm since the abort request is still being
                      * processed and we cant send a negative confirm */
                     sbLmGenAlarm(LCM_CATEGORY_RESOURCE,
                                  LCM_EVENT_DMEM_ALLOC_FAIL,
                                  LCM_CAUSE_MEM_ALLOC_FAIL, 0, LSB_SW_RFC_REL0);
                  }
                  /* continue anyway */
               }

               /* return with positive status */
               SbUiSctTermCfm(&(sctSap->sctPst), sctSap->suId, assocId,
                              SCT_OK, SCT_CAUSE_NOT_APPL);
               RETVALUE(ROK);
            }
         }
      }

#if (ERRCLASS & ERRCLS_INT_PAR)
      /* if we are here then the association does not exist */
      SBLOGERROR(ERRCLS_INT_PAR, ESB039, (ErrVal)assocId,
                 "SbUiSctTermReq: Invalid suAssocId");
      /* alarm sent since we don't know where to send a confirm */
      sbLmGenAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                   LCM_CAUSE_INV_PAR_VAL, spId, LSB_SW_RFC_REL0);
      RETVALUE(RFAILED);
#endif
   }

   if ( assocIdType == SCT_ASSOCID_SP )              /* service provider ID */
   {

#if (ERRCLASS & ERRCLS_INT_PAR)
      /* validate the assocId */
      SB_CHK_SPASSOCID(assocId, ret);
      if ( ret != ROK )
      {
         SBLOGERROR(ERRCLS_INT_PAR, ESB040, (ErrVal)assocId,
                    "SbUiSctTermReq: Invalid spAssocId (assoc. not found)");
         /* alarm sent since we don't know where to send a confirm */
         sbLmGenAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                      LCM_CAUSE_INV_PAR_VAL, spId, LSB_SW_RFC_REL0);
         RETVALUE(RFAILED);
      }
#endif

      /* get the association CB */
      assocCb = sbGlobalCb.assocCb[assocId];

      /* check the state of the association */
      if ( assocCb->assocState == SB_ST_ESTABLISHED )
      {
         if ( abortFlg == TRUE )
         {
            /* ungraceful shutdown (abort) */
            ret = sbAsAbortAssoc(assocCb, TRUE);

            SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                   "SbUiSctTermReq: completed assoc Abort\n"));

            if ( ret != ROK )
            {
               /* could not send ABORT chunk */
               SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                      "SbUiSctTermReq: could not send ABORT chunk\n"));
               if ( ret == ROUTRES )
               {
                  /* send alarm since the abort request is still being
                  * processed and we cant send a negative confirm */
                  sbLmGenAlarm(LCM_CATEGORY_RESOURCE,
                               LCM_EVENT_DMEM_ALLOC_FAIL,
                               LCM_CAUSE_MEM_ALLOC_FAIL, 0, LSB_SW_RFC_REL0);
               }
               /* continue anyway */
            }

            /* send positive confirmation */
            ret = SbUiSctTermCfm(&(sctSap->sctPst), sctSap->suId,
                                 assocCb->suAssocId, SCT_OK,
                                 SCT_CAUSE_NOT_APPL);

            /* remove association and free the memory */
            sbGlobalCb.assocCb[assocId] = (SbSctAssocCb *) NULLP;
            SB_FREE(sizeof(SbSctAssocCb), assocCb);

            RETVALUE(ROK);

         }
         else /* abrtFlg != TRUE */
         {

            /* graceful shutdown */
            /* send SHUTDOWN */
            assocCb->assocState = SB_ST_SDOWN_PEND;
            if ( (assocCb->sbAcCb.cumTsn + 1) == assocCb->sbAcCb.nextLocalTsn )
            {
               ret = sbAsShutdown(assocCb);
               if ( ret == ROUTRES )
               {
                  /* error should be logged */
                  SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                         "SbUiSctTermReq: could not build SHUTDOWN\n"));

                  /* sb010.102 suAssocId in Termination Indication */
                  SbUiSctTermCfm(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                                 SCT_NOK, SCT_CAUSE_OUTRES);
                  RETVALUE(RFAILED);
               }
               else if ( ret == RFAILED )
               {
                  /* error should be logged */
                  SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                         "SbUiSctTermReq: could not send SHUTDOWN\n"));
                  SbUiSctTermCfm(&(sctSap->sctPst), sctSap->suId,
                                 assocCb->suAssocId,
                                 SCT_NOK, SCT_CAUSE_TERM_FAILED);
                  RETVALUE(RFAILED);
               }

               RETVALUE(ROK);
            }
         }

      }
      else /* assocCb->assocState != SB_ST_ESTABLISHED */
      {
         SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
            "SbUiSctTermReq: assoc. state not ESTABLISHED, aborting instead\n"));

         /* ABORT it then */
         ret = sbAsAbortAssoc(assocCb, TRUE);

         if ( ret != ROK )
         {
            /* could not send ABORT chunk */
            SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                   "SbUiSctTermReq: could not send ABORT chunk\n"));
            if ( ret == ROUTRES )
            {
               /* send alarm since the abort request is still being
               * processed and we cant send a negative confirm */
               sbLmGenAlarm(LCM_CATEGORY_RESOURCE,
                            LCM_EVENT_DMEM_ALLOC_FAIL,
                            LCM_CAUSE_MEM_ALLOC_FAIL, 0, LSB_SW_RFC_REL0);
            }
            /* continue anyway */
         }

         /* remove association and free the memory */
         suAssocId = assocCb->suAssocId;
         sbGlobalCb.assocCb[assocId] = (SbSctAssocCb *) NULLP;
         SB_FREE(sizeof(SbSctAssocCb), assocCb);

         /* send positive confirmation */
         SbUiSctTermCfm(&(sctSap->sctPst), sctSap->suId,
                        suAssocId, SCT_OK, SCT_CAUSE_NOT_APPL);
      }
   }

   RETVALUE(ROK);
}/* SbUiSctTermReq() */

/*
*
*       Fun:   SbUiSctSetPriReq
*
*       Desc:  Primitive to Set a New Primary Address on an Association
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <none>
*
*       File:  sb_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SbUiSctSetPriReq
(
Pst                  *pst,              /* Post structure */
SpId                  spId,             /* Service provider SAP ID */
UConnId               spAssocId,        /* Service provider association ID */
CmNetAddr            *dstNAddr          /* New primary network address */
)
#else
PUBLIC S16 SbUiSctSetPriReq(pst, spId, spAssocId, dstNAddr)
Pst                  *pst;              /* Post structure */
SpId                  spId;             /* Service provider SAP ID */
UConnId               spAssocId;        /* Service provider association ID */
CmNetAddr            *dstNAddr;         /* New primary network address */
#endif
{
   /* local parameters */
   S16             ret;
   SbSctSapCb     *sctSap;
   SbSctAssocCb   *assocCb;
   SbAddrCb       *addrCb;
   /* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
   S8             ipv6Addr1[SB_IPV6STR_SIZE]; /* To  generate ipv6 traces */
   S8             ipv6Addr2[SB_IPV6STR_SIZE];
   S8             ipv6Addr3[SB_IPV6STR_SIZE];
   U8             *tempIpv6Addr;
#endif

   TRC3(SbUiSctSetPriReq)

#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                         (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbUiSctSetPriReq () failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
       "SbUiSctSetPriReq(pst, spId(%d), spAssocId(%ld), dstNAddr)\n",
       spId, spAssocId));

#ifndef SS_MULTIPLE_PROCS
   UNUSED(pst);
#endif  /* SS_MULTIPLE_PROCS */
   ret = ROK;

   /* Sanity checks */

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check the SpId. */
   SB_CHK_SPID(spId, LCM_EVENT_UI_INV_EVT, ret);
   if (ret != ROK)
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB041, (ErrVal)spId,
                 "SbUiSctSetPriReq: Invalid spId");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   /* get the SCT SAP control block */
   sctSap = sbGlobalCb.sctSaps[spId];

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate the assocId */
   SB_CHK_SPASSOCID(spAssocId, ret);
   if ( ret != ROK )
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB042, (ErrVal)spAssocId,
                 "SbUiSctSetPriReq: Invalid association ID");
      SbUiSctSetPriCfm(&(sctSap->sctPst), sctSap->suId, spAssocId,
                       SCT_NOK, SCT_CAUSE_INV_PAR_VAL);
      RETVALUE(RFAILED);
   }
#endif

   /* get the association control block */
   assocCb = sbGlobalCb.assocCb[spAssocId];

   /* get the address control block */
   addrCb = sbPmGetAddrCb(assocCb, dstNAddr);

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate the address */
   if ( addrCb == (SbAddrCb *) NULLP )
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB043, (ErrVal)0,
                 "SbUiSctSetPriReq: primary destination address invalid");
      SbUiSctSetPriCfm(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                       SCT_NOK, SCT_CAUSE_INV_PAR_VAL);
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
 
   /* Patch sb031.102 IPV6 Support Added */
   if((assocCb->sbAcCb.pri->addr.type == CM_NETADDR_IPV4) && (addrCb->addr.type == CM_NETADDR_IPV4) && (dstNAddr->type == CM_NETADDR_IPV4))
   {
   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
       "SbUiSctSetPriReq: Old = %lu, New = %lu, requested = %lu\n",
       assocCb->sbAcCb.pri->addr.u.ipv4NetAddr, addrCb->addr.u.ipv4NetAddr,
       dstNAddr->u.ipv4NetAddr));
   }
   /* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
   if((assocCb->sbAcCb.pri->addr.type == CM_NETADDR_IPV6) && (addrCb->addr.type == CM_NETADDR_IPV6) && (dstNAddr->type == CM_NETADDR_IPV6))
   {
      tempIpv6Addr = assocCb->sbAcCb.pri->addr.u.ipv6NetAddr;
      SB_CPY_IPV6ADSTR(ipv6Addr1, tempIpv6Addr)

      tempIpv6Addr = addrCb->addr.u.ipv6NetAddr;
      SB_CPY_IPV6ADSTR(ipv6Addr2, tempIpv6Addr)

      tempIpv6Addr = dstNAddr->u.ipv6NetAddr;
      SB_CPY_IPV6ADSTR(ipv6Addr3, tempIpv6Addr)

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
       "SbUiSctSetPriReq: Old = %s, New = %s, requested = %s\n",
       ipv6Addr1, ipv6Addr2, ipv6Addr3)); 
   }
#endif

   /* set the new value on the association CB */
   assocCb->sbAcCb.pri = addrCb;

   SbUiSctSetPriCfm(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                    SCT_OK, SCT_CAUSE_NOT_APPL);
   RETVALUE(ROK);
}/* SbUiSctSetPriReq() */

/*
*
*       Fun:   SbUiSctHBeatReq
*
*       Desc:  Primitive to Request enable/disable Heartbeat Information.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: Heartbeat can be enabled/disabled per association or per
*              destination address.
*
*       File:  sb_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SbUiSctHBeatReq
(
Pst                  *pst,              /* Post structure */
SpId                  spId,             /* Service provider SAP ID */
UConnId               spAssocId,        /* Service provider association ID */
CmNetAddr            *dstNAddr,         /* New primary network address */
U16                   intervalTime,     /* heartbeat periodicity value */
SctStatus             status            /* Type of request to process */
)
#else
PUBLIC S16 SbUiSctHBeatReq(pst, spId, spAssocId, dstNAddr, intervalTime, status)
Pst                  *pst;              /* Post structure */
SpId                  spId;             /* Service provider SAP ID */
UConnId               spAssocId;        /* Service provider association ID */
CmNetAddr            *dstNAddr;         /* New primary network address */
U16                   intervalTime;     /* heartbeat periodicity value */
SctStatus             status;           /* Type of request to process */
#endif
{
   /* local parameters */
   SbSctSapCb           *sctSap;
   SbSctAssocCb         *assocCb;
   SbAddrCb             *addrCb;
   S16                   ret;
   CmLListCp            *l;
   CmLList              *n;
   U32                   i;

   TRC3(SbUiSctHBeatReq)

#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                         (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbUiSctHBeatReq () failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctHBeatReq(pst, spId(%d), spAssocId(%ld), dstNAddr, \
          intervalTime(%d), status(%d))\n",
          spId, spAssocId, intervalTime, status));

#ifndef SS_MULTIPLE_PROCS
   UNUSED(pst);
#endif /* SS_MULTIPLE_PROCS */

   ret = ROK;

   /* Sanity checks */
#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check the SpId. */
   SB_CHK_SPID(spId, LCM_EVENT_UI_INV_EVT, ret);
   if (ret != ROK)
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB044, (ErrVal)spId,
                 "SbUiSctHBeatReq: Invalid spId");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   /* get the SCT SAP control block */
   sctSap = sbGlobalCb.sctSaps[spId];

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate the assocId */
   SB_CHK_SPASSOCID(spAssocId, ret);
   if ( ret != ROK )
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB045, (ErrVal)spAssocId,
                 "SbUiSctHBeatReq: Invalid association ID");
      /* can't send confirm since assoc CB can't be resolved */
      sbLmGenAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                   LCM_CAUSE_INV_PAR_VAL, spId, LSB_SW_RFC_REL0);
      RETVALUE(RFAILED);
   }
#endif

   /* get the association control block */
   assocCb = sbGlobalCb.assocCb[spAssocId];

   addrCb = (SbAddrCb *)NULLP;

   if ( (status == SCT_HBEAT_ENB_DTA) || (status == SCT_HBEAT_DIS_DTA) )
   {
      /* get the address control block */
      addrCb = sbPmGetAddrCb(assocCb, dstNAddr);

#if (ERRCLASS & ERRCLS_INT_PAR)
      /* validate the address */
      if ( addrCb == (SbAddrCb *) NULLP )
      {
         SBLOGERROR(ERRCLS_INT_PAR, ESB046, (ErrVal)0,
                    "SbUiSctHBeatReq: primary destination address invalid");
         SbUiSctHBeatCfm(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                         dstNAddr, status, SCT_NOK, SCT_CAUSE_INV_PAR_VAL);
         RETVALUE(RFAILED);
      }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

      if (addrCb->sndTo != TRUE)
      {
         SbUiSctHBeatCfm(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                         dstNAddr, status, SCT_NOK, SCT_CAUSE_INV_PAR_VAL);
         RETVALUE(RFAILED);
      }

   }

   /* enable on one destination address */
   if ( status == SCT_HBEAT_ENB_DTA )
   {
      sbPmHBeatEnb(addrCb, intervalTime);
      SbUiSctHBeatCfm(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                      dstNAddr, status, SCT_OK, SCT_CAUSE_NOT_APPL);
      RETVALUE(ROK);
   }

   /* enable on one destination address */
   if ( status == SCT_HBEAT_DIS_DTA )
   {
      sbPmHBeatDis(addrCb);
      SbUiSctHBeatCfm(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                      dstNAddr, status, SCT_OK, SCT_CAUSE_NOT_APPL);
      RETVALUE(ROK);
   }

   l = &(assocCb->sbAcCb.addrLst);
   n = cmLListFirst(l);

   /* enable/disable on an association */
   for ( i = 0; i < cmLListLen(l); i++)
   {
      addrCb = (SbAddrCb *)n->node;
      if (addrCb->sndTo == TRUE)
      {
         if ( status == SCT_HBEAT_ENB_ASSOC )
         {
            sbPmHBeatEnb(addrCb, intervalTime);
         }
         else if ( status == SCT_HBEAT_DIS_ASSOC )
         {
            sbPmHBeatDis(addrCb);
         }
      }

      n = cmLListNext(l);
   }

   SbUiSctHBeatCfm(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                   dstNAddr, status, SCT_OK, SCT_CAUSE_NOT_APPL);
   RETVALUE(ROK);
}/* SbUiSctHBeatReq() */

/*
*
*       Fun:   SbUiSctDatReq
*
*       Desc:  Primitive Request to send Data to a peer.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <none>
*
*       File:  sb_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SbUiSctDatReq
(
Pst                  *pst,              /* Post structure */
SpId                  spId,             /* Service provider SAP ID */
UConnId               spAssocId,        /* Service provider association ID */
CmNetAddr            *dstNAddr,         /* New primary network address */
SctStrmId             strmId,           /* Stream ID */
Bool                  unorderFlg,       /* unordered delivery */
Bool                  nobundleFlg,      /* no bundling  */
U16                   lifeTime,         /* datagram lifetime value */
U32                   protId,           /* Protocol ID */
Buffer               *mBuf              /* message buffer */
)
#else
PUBLIC S16 SbUiSctDatReq(pst, spId, spAssocId, dstNAddr, strmId, unorderFlg,
                         nobundleFlg, lifeTime, protId, mBuf)
Pst                  *pst;              /* Post structure */
SpId                  spId;             /* Service provider SAP ID */
UConnId               spAssocId;        /* Service provider association ID */
CmNetAddr            *dstNAddr;         /* New primary network address */
SctStrmId             strmId;           /* Stream ID */
Bool                  unorderFlg;       /* unordered delivery */
Bool                  nobundleFlg;      /* no bundling  */
U16                   lifeTime;         /* datagram lifetime value */
U32                   protId;           /* Protocol ID */
Buffer               *mBuf;             /* message buffer */
#endif
{
   /* local parameters */
   SbSctSapCb           *sctSap;
   SbSctAssocCb         *assocCb;
   SbAddrCb             *addrCb;
   S16                   ret;
   SbQueuedChunk        *chunk;
   U32                   nmbQPkt;
   MsgLen                bufLen;
   U16                   mtu;
   U16                   numChunks;
   /* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
   S8                    ipv6Addr1[SB_IPV6STR_SIZE];
   S8                    ipv6Addr2[SB_IPV6STR_SIZE];
   U8                    *tempIpv6Addr;
#endif

   TRC3(SbUiSctDatReq)

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Entered SbUiSctDatReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif
#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                         (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbUiSctDatReq () failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
       "SbUiSctDatReq(pst, spId(%d), spAssocId(%ld), dstNAddr, strmId(%d), \
       unorderFlg(%d), nobundleFlg(%d), lifeTime(%d), protId(%ld), mBuf)\n",
       spId, spAssocId, strmId, unorderFlg, nobundleFlg, lifeTime, protId));

#ifndef SS_MULTIPLE_PROCS
   UNUSED(pst);
#endif  /* SS_MULTIPLE_PROCS */

   /* Sanity checks */

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check the SpId. */
   SB_CHK_SPID(spId, LCM_EVENT_UI_INV_EVT, ret);
   if (ret != ROK)
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB047, (ErrVal)spId,
                 "SbUiSctDatReq: Invalid spId");

      SB_CHK_PUTMSG(mBuf);
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* get the SCT SAP control block */
   sctSap = sbGlobalCb.sctSaps[spId];

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate the assocId */
   SB_CHK_SPASSOCID(spAssocId, ret);
   if ( ret != ROK )
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB048, (ErrVal)spAssocId,
                 "SbUiSctDatReq: Invalid association ID");

      SbUiSctStaInd(&(sctSap->sctPst), sctSap->suId, 0, spAssocId, dstNAddr,
                    SCT_STATUS_SND_FAIL, SCT_CAUSE_INV_PAR_VAL, mBuf);

      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* get the association control block */
   assocCb = sbGlobalCb.assocCb[spAssocId];

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* sb023.102 -  Check is dstNAddress is not NULLP before accessing it */
   if ( (dstNAddr != (CmNetAddr *)NULLP ) &&
        (dstNAddr->type != CM_NETADDR_NOTPRSNT ) )
   {
      /* validate the address */
      addrCb = sbPmGetAddrCb(assocCb, dstNAddr);
      if ( addrCb == (SbAddrCb *) NULLP )
      {
         SBLOGERROR(ERRCLS_INT_PAR, ESB049, (ErrVal)0,
                    "SbUiSctDatReq: Invalid destination address");

         SbUiSctStaInd(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                       spAssocId, dstNAddr, SCT_STATUS_SND_FAIL,
                       SCT_CAUSE_INV_PAR_VAL, mBuf);

         RETVALUE(RFAILED);
      }
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* get the best address control block */
   /* sb023.102 - Performance Change, If dstNAddress is not specified or if
    * specified and not present then select the primary destination address if
    * it is active */
   if ( ((dstNAddr == (CmNetAddr *)NULLP )   ||
        ((dstNAddr != (CmNetAddr *)NULLP) &&
        (dstNAddr->type == CM_NETADDR_NOTPRSNT)))       &&
        (assocCb->sbAcCb.pri->active == SCT_PATH_ACTIVE) && 
        (assocCb->sbAcCb.pri->sndTo == TRUE) )
   {
       addrCb = assocCb->sbAcCb.pri;
   }
   else
   {
       addrCb = sbPmGetBestAddrCb(assocCb, dstNAddr);
   }
   /* Patch sb031.102 IPV6 Support Added */
   if((dstNAddr->type == CM_NETADDR_IPV4) && (addrCb->addr.type == CM_NETADDR_IPV4))
   {
      SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctDatReq: requestedAddr = %lu, selectedAddress = %lu, type = %d\n",
          dstNAddr->u.ipv4NetAddr, addrCb->addr.u.ipv4NetAddr, dstNAddr->type));
   }
#ifdef SB_IPV6_SUPPORTED
   if((dstNAddr->type == CM_NETADDR_IPV6) && (addrCb->addr.type == CM_NETADDR_IPV6))
   {
      tempIpv6Addr = dstNAddr->u.ipv6NetAddr;
      SB_CPY_IPV6ADSTR(ipv6Addr1, tempIpv6Addr)

      tempIpv6Addr = addrCb->addr.u.ipv6NetAddr;
      SB_CPY_IPV6ADSTR(ipv6Addr2, tempIpv6Addr)

      /* Patch sb031.102 IPV6 Support Added */
      SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctDatReq: requestedAddr = %s, selectedAddress = %s, type = %d\n",
          ipv6Addr1, ipv6Addr2, dstNAddr->type));

   }
#endif

   /* shouldn't be necessary to validate since if an address can't be found
    * then the assoc should have been aborted anyway */

#if ( ERRCLASS & ERRCLS_DEBUG )
   /* neg. return for above function only occurs in ERRCLS_DEBUG */
   if ( addrCb == (SbAddrCb *) NULLP )
   {
      SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
             "SbUiSctDatReq: could not find best addr. to send DATA on\n"));

      SbUiSctStaInd(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                    spAssocId, dstNAddr, SCT_STATUS_SND_FAIL,
                    SCT_CAUSE_UNKNOWN, mBuf);

      RETVALUE(RFAILED);
   }
#endif

   /* check the out streams parameter */
#if (ERRCLASS & ERRCLS_INT_PAR)
   if ( strmId >= sbGlobalCb.genCfg.maxNmbOutStrms )
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB050, (ErrVal)strmId,
                 "SbUiSctDatReq: Invalid strmId");

      SbUiSctStaInd(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                    spAssocId, dstNAddr, SCT_STATUS_SND_FAIL,
                    SCT_CAUSE_INV_PAR_VAL, mBuf);

      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* sb023.102 - Check the established state first & later check the rest of
    * the states - performance change */
   if (assocCb->assocState != SB_ST_ESTABLISHED)
   {
       /* check the state */
       if ( (assocCb->assocState == SB_ST_SDOWN_PEND) ||
            (assocCb->assocState == SB_ST_SDOWN_SENT) ||
            (assocCb->assocState == SB_ST_SDOWN_RCVD) ||
            (assocCb->assocState == SB_ST_SDOWNACK_SENT) )
       {
          SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                 "SbUiSctDatReq: SHUTDOWN in progress\n"));

          SbUiSctStaInd(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                        spAssocId, dstNAddr, SCT_STATUS_SND_FAIL,
                        SCT_CAUSE_SHUTDOWN_PRGS, mBuf);

          RETVALUE(RFAILED);
       }
       if ( (assocCb->assocState == SB_ST_CLOSED) ||
            (assocCb->assocState == SB_ST_OPEN) ||
            (assocCb->assocState == SB_ST_COOKIE_WAIT))
       {
          SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                 "SbUiSctDatReq: Invalid state\n"));
    
          SbUiSctStaInd(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                        spAssocId, dstNAddr, SCT_STATUS_SND_FAIL,
                        SCT_CAUSE_INV_STATE, mBuf);

          RETVALUE(RFAILED);
       }
   }

   /* sb023.102 - Get the number of Qed packets directly, don't call any
    * functions - performance change */
   /* Flow control */
   nmbQPkt = cmLListLen(&(assocCb->sbDbCb.congestionQ))    + 
             cmLListLen(&(assocCb->sbDbCb.tsnWaitingQOrd)) +
             cmLListLen(&(assocCb->sbDbCb.tsnWaitingQUnord));

   /* sb023.102  - Performance Fix, Instead of SB_QUERY_MTU, we will directly
    * get the mtu from the mtuIndex  in AddrCb */
   SB_GET_MTU(addrCb, mtu, ret);
   /* sb051.102: Cheking for MTU discovery error */  
   #if ( ERRCLASS & ERRCLS_DEBUG )
      if ( ret != ROK )
      {
         SBDBGP(SB_DBGMASK_AC, (sbGlobalCb.sbInit.prntBuf,
                "SbUiSctDatReq: Path MTU discovery failed\n"));
         mtu = sbGlobalCb.genCfg.mtuInitial;
      }
   #endif /* ERRCLS_DEBUG */

   /* sb051.102: Checking the error for SSI function call */
   ret = SFndLenMsg(mBuf, &(bufLen));
   if (ret != ROK)
   {
      SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                 "SbUiSctDatReq: Find length message failed\n"));
      SbUiSctStaInd(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                    spAssocId, dstNAddr, SCT_STATUS_SND_FAIL,
                    SCT_CAUSE_UNKNOWN, mBuf);
      RETVALUE( RFAILED );
   }

   numChunks = (U16)((bufLen / mtu) + 1);
   if ( (numChunks + sbGlobalCb.txChunks) >= sbGlobalCb.genCfg.maxNmbTxChunks )
   {
      /* queues are full */
      SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
             "SbUiSctDatReq: queues are full, flow control dropping\n"));

      SbUiSctStaInd(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                    spAssocId, dstNAddr, SCT_STATUS_SND_FAIL, SCT_CAUSE_QFULL,
                    mBuf);
      SbUiSctFlcInd(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                    SCT_FLC_DROP);

      RETVALUE(RFAILED);
   }

   if ( nmbQPkt >= sctSap->sctSapCfg.reConfig.flcUpThr )
   {
      /* breached FLC upper threshold */
      if ( assocCb->flcFlg == FALSE )
      {
         SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
             "SbUiSctDatReq: flow control started\n"));

         SbUiSctFlcInd(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                       SCT_FLC_START);
         assocCb->flcFlg = TRUE;
      }
   }

   /* create new chunk */
   /* sb023.102 - To reduce number of cmMemset operations we are directly
    * allocating SbQueuedChunk sturture, It is anyway initialised field by
    * field so there is no need for cmMemSet - performance change */
   SB_GETSBUF(sizeof(SbQueuedChunk), chunk, ret);
   if ( ret != ROK )
   {
      SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
             "SbUiSctDatReq: could not alloc. mem. for new chunk\n"));

      SbUiSctStaInd(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                    spAssocId, dstNAddr, SCT_STATUS_SND_FAIL, SCT_CAUSE_OUTRES,
                    mBuf);

      RETVALUE(RFAILED);
   }

   /* set new chunk values */
   chunk->noBundleFlg  = nobundleFlg;
   chunk->resendFlg    = FALSE;
   chunk->sendFlg      = FALSE;
   chunk->startFlg     = TRUE;
   chunk->endFlg       = TRUE;
   chunk->dfFlg        = FALSE;
   chunk->rttInProg    = FALSE;
   chunk->unorderedFlg = unorderFlg;
   chunk->qState       = SB_DB_INVALQ;
   chunk->tsn          = 0;
   chunk->seqNum       = 0;
   chunk->stream       = strmId;
   chunk->holeCnt      = 0;
   chunk->lifetime     = lifeTime;
   chunk->time         = 0;
   chunk->addrCb       = addrCb;
   chunk->spAssocId    = spAssocId;
   chunk->mBuf         = mBuf;
   chunk->protId       = protId;
   /* sb029.102: Duplicate Retransmission */
   chunk->dlvrCfmChunk = FALSE; /* default value, not confirmed */

   /* initialize the lifetime timer */
   cmInitTimers(&(chunk->lifetimeTmr), 1);

   /* deliver to sequenced delivery */
   ret = sbSqDeliver(assocCb, chunk);
   if ( ret != ROK )
   {
      /* lose the chunk */
      SBDBGP(SB_DBGMASK_AS, (sbGlobalCb.sbInit.prntBuf,
             "SbUiSctDatReq: Could not send chunk to Sequ. Deliv.\n"));

      RETVALUE(RFAILED);
   }

   /* update statistics counterts */
   sbGlobalCb.genSts.sbByteSts.bytesRx += bufLen;
   sctSap->sctSts.sbByteSts.bytesRx    += bufLen;

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Leaving SbUiSctDatReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif
   /* no confirm */
   RETVALUE(ROK);
}/* SbUiSctDatReq() */

/*
*
*       Fun:   SbUiSctStaReq
*
*       Desc:  Primitive Request for Status Information.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <none>
*
*       File:  sb_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SbUiSctStaReq
(
Pst                  *pst,              /* Post structure */
SpId                  spId,             /* Service provider SAP ID */
UConnId               spAssocId,        /* Service provider association ID */
CmNetAddr            *dstNAddr,         /* New primary network address */
U8                    staType           /* Status type */
)
#else
PUBLIC S16 SbUiSctStaReq(pst, spId, spAssocId, dstNAddr, staType)
Pst                  *pst;              /* Post structure */
SpId                  spId;             /* Service provider SAP ID */
UConnId               spAssocId;        /* Service provider association ID */
CmNetAddr            *dstNAddr;         /* New primary network address */
U8                    staType;          /* Status type */
#endif
{
   /* local parameters */
   SbSctSapCb           *sctSap;
   SbSctAssocCb         *assocCb;
   SbAddrCb             *addrCb;
   S16                   ret;
   CmLListCp            *l;
   CmLList              *n;
   U32                   i;
   SctStaInfo            staInfo;

   TRC3(SbUiSctStaReq)

#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                         (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbUiSctStaReq () failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
       "SbUiSctStaReq(pst, spId(%d), spAssocId(%lu), dstNAddr, staType(%d))\n",
       spId, spAssocId, staType));

#ifndef SS_MULTIPLE_PROCS
   UNUSED(pst);
#endif  /* SS_MULTIPLE_PROCS */

   ret = ROK;

   /* Sanity Checks */

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check the SpId. */
   SB_CHK_SPID(spId, LCM_EVENT_UI_INV_EVT, ret);
   if (ret != ROK)
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB051, (ErrVal)spId,
                 "SbUiSctStaReq: Invalid spId");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   /* get the SCT SAP control block */
   sctSap = sbGlobalCb.sctSaps[spId];

   SB_ZERO(&staInfo, sizeof(SctStaInfo));

   staInfo.staType = staType;

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate the assocId */
   SB_CHK_SPASSOCID(spAssocId, ret);
   if ( ret != ROK )
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB052, (ErrVal)spAssocId,
                 "SbUiSctDatReq: Invalid association ID");
      SbUiSctStaCfm(&(sctSap->sctPst), sctSap->suId, 0, dstNAddr,
                    SCT_NOK, SCT_CAUSE_INV_PAR_VAL, &staInfo);
      RETVALUE(RFAILED);
   }
#endif

   /* get the association control block */
   assocCb = sbGlobalCb.assocCb[spAssocId];

   /* get the address control block */
   addrCb = sbPmGetAddrCb(assocCb, dstNAddr);

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate the address */
   if ( (addrCb == (SbAddrCb *) NULLP) && (staType == SCT_GET_ADDR_INFO) )
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB053, (ErrVal)0,
                 "SbUiSctDatReq: Invalid address");
      SbUiSctStaCfm(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                    dstNAddr, SCT_NOK, SCT_CAUSE_INV_PAR_VAL,
                    &staInfo);
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   switch ( staType )
   {
      case SCT_RTRV_UNSENT_DGMS:
         (Void) sbSqRtrvUnsent(assocCb);
         break;

      case SCT_RTRV_UNACK_DGMS:
         (Void) sbAcRtrvUnack(assocCb);
         break;

      case SCT_RTRV_UNDEL_DGMS:
         (Void) sbSqRtrvUndel(assocCb);
         break;

      case SCT_GET_ASSOC_INFO:
      {
         staInfo.u.assocInfo.rwnd       = assocCb->sbAcCb.rwnd;
         staInfo.u.assocInfo.connSta    = assocCb->assocState;
         SB_CPY_NADDR(&(staInfo.u.assocInfo.priDstAddr),
                      &(assocCb->sbAcCb.pri->addr));
         staInfo.u.assocInfo.dstPort    = assocCb->peerPort;

         l = &(assocCb->sbAcCb.addrLst);
         n = cmLListFirst(l);
         staInfo.u.assocInfo.dstAddrLst.nmb = 0;
         for (i = 0; i < cmLListLen(l); i++ )
         {
            addrCb = (SbAddrCb *)(n->node);
            SB_CPY_NADDR(&(staInfo.u.assocInfo.dstAddrLst.nAddr \
                         [staInfo.u.assocInfo.dstAddrLst.nmb]), \
                         &(addrCb->addr));
            staInfo.u.assocInfo.dstAddrLst.nmb++;
            n = cmLListNext(l);
         }

         SbUiSctStaCfm(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                       dstNAddr, SCT_OK, SCT_CAUSE_NOT_APPL,
                       &staInfo);
         break;
      }

      case SCT_GET_ADDR_INFO:
      {
         staInfo.u.addrInfo.rtt    = addrCb->srtt;
         staInfo.u.addrInfo.rto    = addrCb->rto;
         staInfo.u.addrInfo.cwnd   = addrCb->cwnd;
         staInfo.u.addrInfo.active = addrCb->active;
         SbUiSctStaCfm(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                       dstNAddr, SCT_OK, SCT_CAUSE_NOT_APPL,
                       &staInfo);
         break;
      }

      case SCT_GET_RTRV_INFO:
      {
         staInfo.u.rtrvInfo.lastAckTsn    = assocCb->sbAcCb.cumTsn;
         staInfo.u.rtrvInfo.lastSentTsn   = assocCb->sbAcCb.nextLocalTsn - 1;
         staInfo.u.rtrvInfo.nmbUnsentDgms =
            (U16)sbDbQPackets(assocCb, SB_DB_TSNWAITINGQ);
         staInfo.u.rtrvInfo.nmbUnackDgms  =
            (U16)sbDbQPackets(assocCb, SB_DB_CONGESTIONQ);
         staInfo.u.rtrvInfo.nmbUndelDgms  =
            (U16)( sbDbQPackets(assocCb, SB_DB_SEQUENCEDQ) +
              sbDbQPackets(assocCb, SB_DB_ASSEMBLYQ) );
         SbUiSctStaCfm(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                       dstNAddr, SCT_OK, SCT_CAUSE_NOT_APPL,
                       &staInfo);
         break;
      }

      case SCT_GET_FLC_INFO:
         if (assocCb->flcFlg == TRUE)
         {
            SbUiSctFlcInd(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                          SCT_FLC_ACTIVE);
         }
         else
         {
            SbUiSctFlcInd(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                          SCT_FLC_INACTIVE);
         }
         break;

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         SBLOGERROR(ERRCLS_INT_PAR, ESB054, (ErrVal) staType,
                    "SbUiSctDatReq: Invalid status type");
         SbUiSctStaCfm(&(sctSap->sctPst), sctSap->suId, assocCb->suAssocId,
                       dstNAddr, SCT_NOK, SCT_CAUSE_INV_PAR_VAL,
                       &staInfo);
#endif
         break;
   }

   /* All the confirms have been sent by now */
   RETVALUE(ROK);
}/* SbUiSctStaReq() */

/****************************************************************************/
/* HIT lower interface primitives                                           */
/****************************************************************************/


/*
*
*       Fun:   SbLiHitConCfm
*
*       Desc:  This function is received from the layer below in
*              responce to a ServOpen request.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes:
*
*       File:  sb_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SbLiHitConCfm
(
Pst     *pst,    /* Post structure containing INFO on the src and dst */
SuId    suId,    /* ID of the TSAP in SCTP layer*/
UConnId suConId, /* Connection ID used by SCTP */
UConnId spConId, /* Connection used by service provider */
CmTptAddr *localAddr /* Address that was connected to */
)
#else
PUBLIC S16 SbLiHitConCfm(pst, suId, suConId, spConId, localAddr)
Pst     *pst;    /* Post structure containing INFO on the src and dst */
SuId    suId;    /* ID of the TSAP */
UConnId suConId; /* Connection ID used by SCTP */
UConnId spConId; /* Connection used by service provider */
CmTptAddr *localAddr; /* Address that was connected to */
#endif
{
   SbTSapCb *tSap;
   SbLocalAddrCb *localAddrCb;
   U16 i;
   U16 cnt;
   S16 err;
   CmNetAddr addr;
   Mem sMem;

#ifndef SS_MULTIPLE_PROCS
   UNUSED( pst );
#endif

   TRC3( SbLiHitConCfm )

#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                         (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbLiHitConCfm () failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_LI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */

   SBDBGP( DBGMASK_LI, ( sbGlobalCb.sbInit.prntBuf,
      "SbLiHitConCfm(pst, suId(%d), suConId(%ld), spConId(%ld), localAddr)\n",
      suId, suConId, spConId ) );

   /* Sanity Checks */
#if ( ERRCLASS & ERRCLS_INT_PAR )
   if( (suId >= (SuId) sbGlobalCb.genCfg.maxNmbTSaps) || (suId < 0) )
   {
      SBLOGERROR( ERRCLS_INT_PAR, ESB055, (ErrVal) suId,
                  "SbLiHitConCfm: suId out of range");
                   sbLmGenAlarm( (U16)LCM_CATEGORY_INTERFACE,
                    (U16)LCM_EVENT_LI_INV_EVT,
                    (U16)LCM_CAUSE_INV_SUID,
                    suId,
                    LSB_SW_RFC_REL0 );
      RETVALUE( RFAILED );
   }
#endif /* ERRCLS_INT_PAR */

   /* get the SCT SAP control block */
   tSap = *(sbGlobalCb.tSaps + suId);

   /* check to see if the SAP exists */
#if ( ERRCLASS & ERRCLS_INT_PAR )
   if ( tSap == (SbTSapCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_INT_PAR, ESB056, (ErrVal) suId,
                  "SbLiHitConCfm: Sap not configured" );
                   sbLmGenAlarm( (U16)LCM_CATEGORY_INTERFACE,
                    (U16)LCM_EVENT_LI_INV_EVT,
                    (U16)LCM_CAUSE_INV_SAP,
                    suId,
                    LSB_SW_RFC_REL0 );
      RETVALUE( RFAILED );
   }
#endif /* ERRCLS_INT_PAR */

   SB_ZERO( &addr, sizeof(CmNetAddr) );

   if ( localAddr == (CmTptAddr *)NULLP )
   {
      addr.type = CM_NETADDR_IPV4;
   }
   else
   {

      if ( localAddr->type == CM_TPTADDR_IPV4 )
      {
         addr.u.ipv4NetAddr = localAddr->u.ipv4TptAddr.address;
         addr.type = CM_NETADDR_IPV4;
      }
      else if ( localAddr->type == CM_TPTADDR_IPV6 )
      {
         addr.type = CM_NETADDR_IPV6;
         (Void) cmMemcpy((U8 *) &(addr.u.ipv6NetAddr),
                         (U8 *)&(localAddr->u.ipv6TptAddr.ipv6NetAddr),
                         (PTR) CM_IPV6ADDR_SIZE);
      }

#if ( ERRCLASS & ERRCLS_INT_PAR )
      else
      {
         SBLOGERROR( ERRCLS_INT_PAR, ESB057, (ErrVal) 0,
                     "SbLiHitConCfm(): invalid address type" );
         sbLmGenAlarm( (U16)LCM_CATEGORY_INTERFACE,
                    (U16)LCM_EVENT_LI_INV_EVT,
                    (U16)LCM_CAUSE_INV_PAR_VAL,
                    suId,
                    LSB_SW_RFC_REL0 );
         RETVALUE( RFAILED );
      }
#endif /* ERRCLS_INT_PAR */

   }

   err = cmHashListFind(&(sbGlobalCb.localAddrHl),
                        (U8 *)&addr, sizeof(CmNetAddr), 0,
                        (PTR *)&localAddrCb);

   if ( (err == ROK) && (localAddrCb != (SbLocalAddrCb *)NULLP) )
   {
      if ( (localAddrCb->suId == suId) &&
           (localAddrCb->suConId == suConId) &&
           (localAddrCb->connected == FALSE) )
      {
         localAddrCb->spConId = spConId;
         localAddrCb->connected = TRUE;
         /* sb044.102: Connection Confirm received */
         localAddrCb->conRetryAttempt = 0;
      }
      else if ( (localAddrCb->suId == suId) &&
                (localAddrCb->suOtherConId == suConId) &&
                (localAddrCb->otherConnected == FALSE) )
      {
         localAddrCb->spOtherConId = spConId;
         localAddrCb->otherConnected = TRUE;
         /* sb044.102: Connection Confirm received */
         localAddrCb->conRetryAttempt = 0;
      }
      else  if ( (sbGlobalCb.dnsInfo.suId == suId) &&
                 (sbGlobalCb.dnsInfo.suConId == suConId) )
      {
         /* don't fail just continue */
      }
      
#if (ERRCLASS & ERRCLS_DEBUG)
      else
      {
         SBLOGERROR(ERRCLS_DEBUG, ESB058, (ErrVal) 0,
                 "SbLiHitConCfm: Inconsistancy with conn. IDs and addresses");
      }
#endif /* ERRCLS_DEBUG */

   }

   cnt = 0;

   for ( i = 0; i < sbGlobalCb.genCfg.maxNmbSrcAddr; i++)
   {
      localAddrCb = *(sbGlobalCb.localAddrCb + i);

      if ( localAddrCb != (SbLocalAddrCb *)NULLP )
      {
         if ( localAddrCb->suId == tSap->tSapCfg.suId )
         {
#if SB_OLD_SERVER_MODE
            if ( localAddrCb->connected == FALSE )
            {
               cnt++;
            }
            if ( localAddrCb->otherConnected == FALSE )
            {
               cnt++;
            }
#else
            /* sb008.12 - Condition for UDP has been removed from here as 
             * for UDP also now connected flag will be used */
            if (localAddrCb->connected == FALSE) 
            {
               if (localAddrCb->ownAddr.type == CM_NETADDR_IPV4)
               {
                  if (((tSap->ipv4_any == TRUE) &&
                     (localAddrCb->ownAddr.u.ipv4NetAddr
                     == CM_INET_INADDR_ANY)) ||
                     (tSap->ipv4_any == FALSE))
                  {
                     cnt++;
                  }
               }
               else if (localAddrCb->ownAddr.type == CM_TPTADDR_IPV6)
               {
                  Bool isAny;
                  SB_INET6_ISANY(localAddrCb->ownAddr.u.ipv6NetAddr,
                     &isAny)
                  if (((tSap->ipv6_any == TRUE) && (isAny == TRUE)) ||
                     (tSap->ipv6_any == FALSE))
                  {
                     cnt++;
                  }
               }
            }
#endif /* !SB_OLD_SERVER_MODE */
         }
      }
   }

   /* In case  of Version 13 we will always open the DNS server at last */

   /* sb051.102 - DNS server is opened only when useDnsLib is TRUE for
    * this TSAP. */
   if ( ((tSap->tSapCfg.reConfig.sbDnsCfg.useDnsLib == TRUE) && 
         ( cnt == 0 ) && (sbGlobalCb.dnsInfo.suId == suId) &&
         (sbGlobalCb.dnsInfo.suConId == suConId)) ||
        ((tSap->tSapCfg.reConfig.sbDnsCfg.useDnsLib != TRUE)&&
         (cnt == 0)) )
    {
   
       /* sb051.102 - Check if useDnsLib is TRUE */
       if(tSap->tSapCfg.reConfig.sbDnsCfg.useDnsLib == TRUE)
       {
       SBDBGP(DBGMASK_LI, ( sbGlobalCb.sbInit.prntBuf,
          "SbLiHitConCfm: Connection Cfm Received for DNS Server\n"));

       sbGlobalCb.dnsInfo.spConId = spConId;
       sbGlobalCb.dnsInfo.dnsState = SB_DNS_SERV_OPEN;
     
       /* sb051.102 - Moved the condition for useDnsLib */ 
         SB_ALLOC(sizeof(CmDnsCb),sbGlobalCb.dnsInfo.dnsCb, err)
         cmDnsDeInitDnsCb(sbGlobalCb.dnsInfo.dnsCb); 

         if( err != ROK )
         {
           SBLOGERROR( ERRCLS_INT_PAR, ESB059, (ErrVal) 0,
                     "SbLiHitConCfm(): Memory Allocation Failure for DNSCB" );
           sbLmGenAlarm(LCM_CATEGORY_RESOURCE,
                            LCM_EVENT_DMEM_ALLOC_FAIL,
                            LCM_CAUSE_MEM_ALLOC_FAIL, suId, LSB_SW_RFC_REL0);
           RETVALUE(LCM_REASON_MEM_NOAVAIL);
         }
          sMem.region = tSap->tPst.region;
          sMem.pool = tSap->tPst.pool;

         err = sbInitDnsCb(sbGlobalCb.dnsInfo.dnsCb, SB_DNS_RQSTLST_SZ, 
                   &sMem, &tSap->tSapCfg.reConfig.sbDnsCfg.dnsAddr);
         if(err != ROK)
         {
            SBDBGP(DBGMASK_LI, ( sbGlobalCb.sbInit.prntBuf,
                "SbLiHitConCfm: Failure returned from sbInitDnsCb \n"));
            RETVALUE(RFAILED);
         }
       }


      /* stop bind timer if running */
      if (tSap->timer.tmrEvnt != TMR_NONE)
      {
         SB_STOP_TMR(&(tSap->timer));
      }

      if ( sbGlobalCb.sbMgmt.hdr.elmId.elmnt == STSBTSAP )
      {
         /* sb004.12 - Change - cfmMsg is taken as Pointer to minimise stack memory */
         SbMgmt      *cfmMsg;             /* control confirm */
         U16         ret;

         /* sb004.12 - Addition : Allocate memory for Response msg  */
         SB_ALLOC(sizeof(SbMgmt), cfmMsg, ret);
         if ( ret != ROK )
         {
            SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
                 "SbLiHitConCfm: could not allocate memory for Response Structure\n"));
            RETVALUE(RFAILED);
         }

         /* zero out the confirm structure */
         SB_ZERO(cfmMsg, sizeof(SbMgmt));

         /* set the current time */
         (Void) SGetDateTime(&(cfmMsg->t.cntrl.dt));

         SBDBGP(DBGMASK_LI, ( sbGlobalCb.sbInit.prntBuf,
                "SbLiHitConCfm: sending CntrlCfm\n"));

         sbLmSendCfm(&(sbGlobalCb.genCfg.smPst), TCNTRL,
                     &(sbGlobalCb.sbMgmt.hdr), LCM_PRIM_OK,
                     LCM_REASON_NOT_APPL, cfmMsg);
      
          /* sb004.12 - Addition : deallocate cfmMsg structure */
          SB_FREE(sizeof(SbMgmt), cfmMsg);

         /* zero this out so that lyr man. can process other instructions */
          SB_ZERO( &(sbGlobalCb.sbMgmt), sizeof(SbMgmt) );
      }
   }

   SBDBGP(DBGMASK_LI, ( sbGlobalCb.sbInit.prntBuf,
          "SbLiHitConCfm: Returning ROK\n"));

   RETVALUE( ROK );
}


/*
*
*       Fun:   SbLiHitUDatInd
*
*       Desc:  This function is received from the layer below whenever
*              data arrives at the lower interface from the peer.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes:
*
*       File:  sb_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SbLiHitUDatInd
(
Pst     *pst,          /* Post structure containing INFO on the src and dst */
SuId    suId,          /* ID of the TSAP in SCTP layer*/
UConnId suConId,       /* Connection ID used by SCTP */
CmTptAddr *srcAddr,    /* Address that the data arrived from */
CmTptAddr *dstAddr,    /* Address interface on which the data arrived */
CmIpHdrParm *hdrParm,  /* IP Header parameters */
      /* Patch sb031.102 IPV6 Support Added */
#ifdef LOCAL_INTF
CmTptLocalInf *localIf, /* Local interface parameter */
#endif 
Buffer *mBuf           /* Message Buffer */
)
#else
PUBLIC S16 SbLiHitUDatInd(pst, suId, suConId, srcAddr, dstAddr, hdrParm, mBuf)
Pst     *pst;    /* Post structure containing INFO on the src and dst */
SuId    suId;    /* ID of the TSAP in SCTP layer*/
UConnId suConId; /* Connection ID used by SCTP */
CmTptAddr *srcAddr; /* Address that the data arrived from */
CmTptAddr *dstAddr; /* Address interface on which the data arrived */
CmIpHdrParm *hdrParm; /* IP Header parameters */
      /* Patch sb031.102 IPV6 Support Added */
#ifdef LOCAL_INTF
CmTptLocalInf *localIf; /* Local interface parameter */
#endif 
Buffer *mBuf;    /* Message Buffer */
#endif
{
   CmNetAddr srcNetAddr;
   CmNetAddr dstNetAddr;
   SbTSapCb *tSap;
   S16 err;
   MsgLen len;
   U8 ver;
   /* sb060.102 - TOS enhancement */
#ifdef SCT4
   U8 incomingTos = 0;
#endif /* SCT4 */
      /* Patch sb031.102 IPV6 Support Added */
#ifdef LOCAL_INTF
   CmTptLocalInf *intfAddr;
#endif

   TRC3( SbLiHitUDatInd );
#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                         (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbLiHitUDatInd () failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_LI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */

   SBDBGP( DBGMASK_LI, ( sbGlobalCb.sbInit.prntBuf,
           "SbLiHitUDatInd(pst, suId(%d), suConId(%ld))\n",
           suId, suConId ) );

#ifndef SS_MULTIPLE_PROCS
   UNUSED( pst );
#endif  /* SS_MULTIPLE_PROCS */
   len = 0;
      /* Patch sb031.102 IPV6 Support Added */
#ifdef LOCAL_INTF
   intfAddr = localIf; 
   if(localIf->intfPrsnt == TRUE)
   {
      if(dstAddr != NULL)
      {
          if(localIf->localIfAddr.type == CM_NETADDR_IPV4)
          {
             dstAddr->type = CM_TPTADDR_IPV4;
             dstAddr->u.ipv4TptAddr.address = localIf->localIfAddr.u.ipv4NetAddr;
          }
          if(localIf->localIfAddr.type == CM_NETADDR_IPV6)
          {
             dstAddr->type = CM_TPTADDR_IPV6;
             cmMemcpy((U8*)dstAddr->u.ipv6TptAddr.ipv6NetAddr, (U8 *)localIf->localIfAddr.u.ipv6NetAddr, CM_IPV6ADDR_SIZE); 
          }
      }
   }
#endif
   if (hdrParm->type == CM_HDRPARM_IPV4)
   {
      if ( (hdrParm->u.hdrParmIpv4.proto.pres == TRUE) &&
           (sbGlobalCb.genCfg.performMtu == TRUE) )
      {
         if ( (hdrParm->u.hdrParmIpv4.proto.val == CM_PROTOCOL_ICMP) &&
              (sbGlobalCb.genCfg.performMtu == TRUE) )
         {
            if (srcAddr->type == CM_TPTADDR_IPV4)
            {
               ver = 4;
            }
            else if (srcAddr->type == CM_TPTADDR_IPV6)
            {
               ver = 6;
            }
            else
            {
               ver = 0;
               SBLOGERROR( ERRCLS_INT_PAR, ESB060, (ErrVal) srcAddr->type,
                           "SbLiHitUDatInd: Incorrect address type" );

               RETVALUE( RFAILED );
            }

            err = sbMtuRcvIcmp(&(sbGlobalCb.mtuCp), mBuf, ver);
            if(mBuf != NULLP )
               SB_PUTMSG( mBuf );
            RETVALUE( err );
         }
      }
      /* sb060.102 - TOS enhancement */
#ifdef SCT4
      if (hdrParm->u.hdrParmIpv4.tos.pres == TRUE)
      {
         incomingTos = hdrParm->u.hdrParmIpv4.tos.val;
      }
#endif /* SCT4 */
   }
      /* Patch sb031.102 IPV6 Support Added */
#ifdef SB_IPV6_SUPPORTED
   /* process the received ICMP6 message */
   else if (hdrParm->type == CM_HDRPARM_ICMP6)
   {
      if(sbGlobalCb.genCfg.performMtu == TRUE)
      {
            if (srcAddr->type == CM_TPTADDR_IPV4)
            {
               ver = 4;
            }
            else if (srcAddr->type == CM_TPTADDR_IPV6)
            {
               ver = 6;
            }
            else
            {
               ver = 0;
               SBLOGERROR( ERRCLS_INT_PAR, ESB060, (ErrVal) srcAddr->type,
                           "SbLiHitUDatInd: Incorrect address type" );

               RETVALUE( RFAILED );
            }

            err = sbMtuRcvIcmp(&(sbGlobalCb.mtuCp), mBuf, ver);
            if(mBuf != NULLP )
               SB_PUTMSG( mBuf );
            RETVALUE( err );
      }
   }
#endif

   if (sbGlobalCb.sbInit.trc == TRUE)
   {
      /* sb052.102 Provide ethereal like logs */
      sbTrcBuf(suId, LSB_MSG_RECVD, mBuf, srcAddr, dstAddr);
   }

   /* sanity checks */
#if ( ERRCLASS & ERRCLS_INT_PAR )

   if( (suId >= (SuId) sbGlobalCb.genCfg.maxNmbTSaps) || (suId < 0) )
   {
      SBLOGERROR( ERRCLS_INT_PAR, ESB061, (ErrVal) suId,
                  "SbLiHitUDatInd: suId out of range" );
                   sbLmGenAlarm( (U16)LCM_CATEGORY_INTERFACE,
                    (U16)LCM_EVENT_LI_INV_EVT,
                    (U16)LCM_CAUSE_INV_SUID,
                    suId,
                    LSB_SW_RFC_REL0 );
      RETVALUE( RFAILED );
   }
#endif /* ERRCLS_INT_PAR */

   /* get the SCT SAP control block */
   tSap = *(sbGlobalCb.tSaps + suId);

   /* check to see if the SAP exists */
#if ( ERRCLASS & ERRCLS_INT_PAR )
   if ( tSap == (SbTSapCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_INT_PAR, ESB062, (ErrVal) suId,
                  "SbLiHitUDatInd: Sap not configured" );
      sbLmGenAlarm( (U16)LCM_CATEGORY_INTERFACE,
                    (U16)LCM_EVENT_LI_INV_EVT,
                    (U16)LCM_CAUSE_INV_SAP,
                    suId,
                    LSB_SW_RFC_REL0 );
      RETVALUE( RFAILED );
   }

   /* Check if the message buffer is of an acceptable length */
   if ( mBuf == (Buffer *)NULLP )
   {
      SBLOGERROR( ERRCLS_INT_PAR, ESB063, (ErrVal) 0,
                  "SbLiHitUDatInd: NULL message" );
      sbLmGenAlarm( (U16)LCM_CATEGORY_INTERFACE,
                    (U16)LCM_EVENT_LI_INV_EVT,
                    (U16)LCM_CAUSE_INV_PAR_VAL,
                    suId,
                    LSB_SW_RFC_REL0 );
      RETVALUE( RFAILED );
   }
   else
   {
      /* sb051.102: Checking the error for SSI function call */
      err = SFndLenMsg(mBuf, &len);
      if (err != ROK)
      {
         SBDBGP(DBGMASK_LI, (sbGlobalCb.sbInit.prntBuf,
                 "SbLiHitUDatInd: Find length message failed\n"));
         SB_PUTMSG( mBuf );
         RETVALUE( RFAILED );
      }


      SBDBGP(DBGMASK_LI, ( sbGlobalCb.sbInit.prntBuf,
             "SbLiHitUDatInd: Message length is %d bytes)\n", len));

      if ( len < 4 )
      {
         SBDBGP(DBGMASK_LI, ( sbGlobalCb.sbInit.prntBuf,
                "SbLiHitUDatInd: Message too short: (%d) bytes)\n",
                len ) );
         SB_PUTMSG( mBuf );
         RETVALUE( ROK );
      }
   }

   if ( srcAddr == (CmTptAddr *)NULLP )
   {
      SBLOGERROR( ERRCLS_INT_PAR, ESB064, (ErrVal) 0,
                  "SbLiHitUDatInd: Source address NULL" );
      sbLmGenAlarm( (U16)LCM_CATEGORY_INTERFACE,
                    (U16)LCM_EVENT_LI_INV_EVT,
                    (U16)LCM_CAUSE_INV_PAR_VAL,
                    suId,
                    LSB_SW_RFC_REL0 );

      SB_PUTMSG( mBuf );
      RETVALUE( RFAILED );
   }

   if ( dstAddr == (CmTptAddr *)NULLP)
   {
      SBLOGERROR( ERRCLS_INT_PAR, ESB065, (ErrVal) 0,
                  "SbLiHitUDatInd: Destination address NULL" );
      sbLmGenAlarm( (U16)LCM_CATEGORY_INTERFACE,
                    (U16)LCM_EVENT_LI_INV_EVT,
                    (U16)LCM_CAUSE_INV_PAR_VAL,
                    suId,
                    LSB_SW_RFC_REL0 );

      SB_PUTMSG( mBuf );
      RETVALUE( RFAILED );
   }
#endif /* ERRCLS_INT_PAR */

   /* Zero and convert the source address to a network address */
   SB_ZERO( &srcNetAddr, sizeof(CmNetAddr) );

   if ( srcAddr->type == CM_TPTADDR_IPV4 )
   {
      srcNetAddr.u.ipv4NetAddr = srcAddr->u.ipv4TptAddr.address;
      srcNetAddr.type = CM_NETADDR_IPV4;
   }
   else if ( srcAddr->type == CM_TPTADDR_IPV6 )
   {
      srcNetAddr.type = CM_NETADDR_IPV6;
      (Void) cmMemcpy( (U8 *) &(srcNetAddr.u.ipv6NetAddr),
                       (U8 *)&(srcAddr->u.ipv6TptAddr.ipv6NetAddr),
                       (PTR) CM_IPV6ADDR_SIZE );
   }

#if ( ERRCLASS & ERRCLS_INT_PAR )
   else
   {
      SBLOGERROR( ERRCLS_INT_PAR, ESB066, (ErrVal) srcAddr->type,
                  "SbLiHitUDatInd: invalid source address type" );
      sbLmGenAlarm( (U16)LCM_CATEGORY_INTERFACE,
                    (U16)LCM_EVENT_LI_INV_EVT,
                    (U16)LCM_CAUSE_INV_PAR_VAL,
                    suId,
                    LSB_SW_RFC_REL0 );

      SB_PUTMSG( mBuf );
      RETVALUE( RFAILED );
   }
#endif /* ERRCLS_INT_PAR */


   if ((tSap->tSapCfg.reConfig.sbDnsCfg.useDnsLib == TRUE) &&  
         (suId == sbGlobalCb.dnsInfo.suId) && 
         (suConId == sbGlobalCb.dnsInfo.suConId))
   {
      SBDBGP( DBGMASK_LI, ( sbGlobalCb.sbInit.prntBuf,
              "sbLiHitUDatInd: Dns Response Received From Server" ));

      cmDnsPrcDnsRsp(sbGlobalCb.dnsInfo.dnsCb, srcAddr, mBuf);

      /* Free Message Buffer */
      if (mBuf != NULLP)
          SPutMsg(mBuf);

      RETVALUE(ROK);
   }

   /* Zero and convert the destination address to a network address */
   SB_ZERO( &dstNetAddr, sizeof(CmNetAddr) );
   
   /* sb008.12 - The change done for UDP, if service type is UDP then search
    * the  correct localAddrCb and copy the own Address from that block in the
    * destination address */
   if( sbGlobalCb.genCfg.serviceType  == HI_SRVC_UDP) 
   {
      S16 i;
      SbLocalAddrCb *localConn;
      for (i = 0; i < sbGlobalCb.genCfg.maxNmbSrcAddr; i++)
      {
         localConn = *(sbGlobalCb.localAddrCb + i);
         if( (localConn != (SbLocalAddrCb *)NULLP ) &&
             ( localConn->connected == TRUE)  &&
             ( localConn->suId == suId ) && 
             ( localConn->suConId ==  suConId ) ) 
         {
            if(localConn->ownAddr.type == CM_NETADDR_IPV4)
            {
              dstAddr->type = CM_TPTADDR_IPV4;
              dstAddr->u.ipv4TptAddr.address = localConn->ownAddr.u.ipv4NetAddr;

/* sb065.102: compile time flag to make udp port as configurable parameter */
#ifdef LSB5
              dstAddr->u.ipv4TptAddr.port =  sbGlobalCb.genCfg.dstUdpPort;
#else
              dstAddr->u.ipv4TptAddr.port =  SB_UDP_PORT;
#endif /* LSB5 */
            }
            else
            {
              S16 j;
              dstAddr->type = CM_NETADDR_IPV6;
/* sb065.102: compile time flag to make udp port as configurable parameter */
#ifdef LSB5
              dstAddr->u.ipv4TptAddr.port =  sbGlobalCb.genCfg.dstUdpPort;
#else
              dstAddr->u.ipv6TptAddr.port =  SB_UDP_PORT;
#endif /* LSB5 */
              for (j = 0; j < CM_IPV6ADDR_SIZE; j++)                    
              {                                                          
                dstAddr->u.ipv6TptAddr.ipv6NetAddr[j] = 
                   localConn->ownAddr.u.ipv6NetAddr[j];
              }                                                        
            }
            break;
         }
      }
   }

   if ( dstAddr->type == CM_TPTADDR_IPV4 )
   {
      dstNetAddr.u.ipv4NetAddr = dstAddr->u.ipv4TptAddr.address;
      dstNetAddr.type = CM_NETADDR_IPV4;
   }
   else if ( dstAddr->type == CM_TPTADDR_IPV6 )
   {
      dstNetAddr.type = CM_NETADDR_IPV6;
      (Void) cmMemcpy( (U8 *) &(dstNetAddr.u.ipv6NetAddr),
                       (U8 *)&(dstAddr->u.ipv6TptAddr.ipv6NetAddr),
                       (PTR) CM_IPV6ADDR_SIZE );
   }

#if ( ERRCLASS & ERRCLS_INT_PAR )
   else
   {
      SBLOGERROR( ERRCLS_INT_PAR, ESB067, (ErrVal) dstAddr->type,
                  "SbLiHitUDatInd: invalid destination address type" );
      sbLmGenAlarm( (U16)LCM_CATEGORY_INTERFACE,
                    (U16)LCM_EVENT_LI_INV_EVT,
                    (U16)LCM_CAUSE_INV_PAR_VAL,
                    suId,
                    LSB_SW_RFC_REL0 );

      SB_PUTMSG( mBuf );
      RETVALUE( RFAILED );
   }
#endif /* ERRCLS_INT_PAR */

  /* sb060.102 - TOS enhancement. */
#ifdef SCT4
   err = sbVaDatInd( &srcNetAddr, &dstNetAddr, suConId, mBuf, incomingTos );
#else
   err = sbVaDatInd( &srcNetAddr, &dstNetAddr, suConId, mBuf );
#endif /* SCT4 */
   if ( err != ROK )
   {
      SBDBGP( DBGMASK_LI, ( sbGlobalCb.sbInit.prntBuf,
              "sbLiHitUDatInd: message validation failed\n" ));
   }

   SBDBGP( DBGMASK_LI, ( sbGlobalCb.sbInit.prntBuf,
           "sbLiHitUDatInd: RETVALUE( ROK )\n" ));
   /* mBuf is released on error above and sbVaDatInd releases it on success */
   RETVALUE( ROK );
}


/*
*
*       Fun:   SbLiHitDiscInd
*
*       Desc:  This function is received when the service provider can
*              no longer provide the requested service on the specified
*              connection.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes:
*
*       File:  sb_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SbLiHitDiscInd
(
Pst     *pst,    /* Post structure containing INFO on the src and dst */
SuId    suId,    /* ID of the TSAP in SCTP layer*/
U8      choice,  /* Selction of either a SU or a SP ConId */
UConnId conId,   /* Connection ID used by SCTP */
Reason  reason   /* Reason for the diconnection */
)
#else
PUBLIC S16 SbLiHitDiscInd(pst, suId, choice, conId, reason)
Pst     *pst;    /* Post structure containing INFO on the src and dst */
SuId    suId;    /* ID of the TSAP in SCTP layer*/
U8      choice;  /* Selction of either a SU or a SP ConId */
UConnId conId;   /* Connection ID used by SCTP */
Reason  reason;  /* Reason for the diconnection */
#endif
{
   SbTSapCb *tSap;
   SbLocalAddrCb *localAddrCb;
   SbSctAssocCb *assocCb;
   SctRtrvInfo rtrvInfo;
   SbSctSapCb *sctSap;
   U16 i;
   /* Patch sb028.102: changes required for freeze timer */
   UConnId tempSuAssocId;
   /* Patch sb044.102: Retry Attempt */
   S16 ret=ROK; 

   TRC3( SbLiHitDiscInd );

#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                         (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbLiHitDiscInd () failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_LI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */

   SBDBGP( DBGMASK_LI, ( sbGlobalCb.sbInit.prntBuf,
         "SbLiHitDiscInd(pst, suId(%d), choice(%d), conId(%ld), reason(%d))\n",
         suId, choice, conId, reason ) );

#ifndef SS_MULTIPLE_PROCS
   UNUSED( pst );
#endif  /* SS_MULTIPLE_PROCS */

#ifndef DEBUGP

   UNUSED( reason );

#endif

   /* sanity checks */
#if ( ERRCLASS & ERRCLS_INT_PAR )
   if( (suId >= (SuId) sbGlobalCb.genCfg.maxNmbTSaps) || (suId < 0) )
   {
      SBLOGERROR( ERRCLS_INT_PAR, ESB068, (ErrVal) suId,
                  "SbLiHitDiscInd: suId out of range" );
                   sbLmGenAlarm( (U16)LCM_CATEGORY_INTERFACE,
                    (U16)LCM_EVENT_LI_INV_EVT,
                    (U16)LCM_CAUSE_INV_SUID,
                    suId,
                    LSB_SW_RFC_REL0 );
     RETVALUE( RFAILED );
   }
#endif /* ERRCLS_INT_PAR */

   /* get the SCT SAP control block */
   tSap = *(sbGlobalCb.tSaps + suId);

   /* check to see if the SAP exists */
#if ( ERRCLASS & ERRCLS_INT_PAR )
   if ( tSap == (SbTSapCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_INT_PAR, ESB069, (ErrVal) suId,
                  "SbLiHitDiscInd: Sap not configured" );
                   sbLmGenAlarm( (U16)LCM_CATEGORY_INTERFACE,
                    (U16)LCM_EVENT_LI_INV_EVT,
                    (U16)LCM_CAUSE_INV_SAP,
                    suId,
                    LSB_SW_RFC_REL0 );
      RETVALUE( RFAILED );
   }
#endif /* ERRCLS_INT_PAR */

   localAddrCb = (SbLocalAddrCb *)NULLP;

   if ( choice == HI_USER_CON_ID )
   {
      if (conId < sbGlobalCb.genCfg.maxNmbSrcAddr)
      {
         localAddrCb = *(sbGlobalCb.localAddrCb + conId);
      }
      else
      {
         localAddrCb = *( sbGlobalCb.localAddrCb +
                          (conId - sbGlobalCb.genCfg.maxNmbSrcAddr) );
      }

   }
   else if ( choice == HI_PROVIDER_CON_ID )
   {

      for ( i = 0; i < sbGlobalCb.genCfg.maxNmbSrcAddr; i++ )
      {
         localAddrCb = *(sbGlobalCb.localAddrCb + i);

         if ( localAddrCb != (SbLocalAddrCb *)NULLP )
         {
            if ( (localAddrCb->spConId == conId) ||
                 (localAddrCb->spOtherConId == conId) )
            {
               i = sbGlobalCb.genCfg.maxNmbSrcAddr;
            }
            else
            {
               localAddrCb = (SbLocalAddrCb *)NULLP;
            }
         }
      }
   }

   if ( localAddrCb != (SbLocalAddrCb *)NULLP )
   {
      if (conId < sbGlobalCb.genCfg.maxNmbSrcAddr)
      {
         /* sb046.102: Multiple IP address per Endp */
         localAddrCb->connected = FALSE;

         /* remove all associations (we assume they abort properly) */
         for ( i = 0; i < sbGlobalCb.genCfg.maxNmbAssoc; i++ )
         {
            assocCb = sbGlobalCb.assocCb[i];

            if ( assocCb != (SbSctAssocCb *) NULLP )
            {
               if ( assocCb->localConn == localAddrCb )
               {
                  /* try to find another local address control block in the
                   * same endpCb */
                  SB_GET_LOCAL_CONN(assocCb->endpId, assocCb->localConn, ret);
                  if ( ret != ROK )
                  {
                     sctSap = *(sbGlobalCb.sctSaps + assocCb->spId);
                     if ( sctSap != (SbSctSapCb *)NULLP)
                     {
                        rtrvInfo.lastAckTsn = assocCb->sbAcCb.cumTsn;
                        rtrvInfo.lastSentTsn = assocCb->sbAcCb.nextLocalTsn - 1;
                        rtrvInfo.nmbUnsentDgms = sbDbQPackets(assocCb,
                                                              SB_DB_TSNWAITINGQ);
                        rtrvInfo.nmbUnackDgms = sbDbQPackets(assocCb,
                                                             SB_DB_CONGESTIONQ);
                        rtrvInfo.nmbUndelDgms = sbDbQPackets(assocCb,
                                                             SB_DB_SEQUENCEDQ)
                                              + sbDbQPackets(assocCb,
                                                             SB_DB_ASSEMBLYQ);
                     
                        /* start freeze timer */
                        if ( assocCb->sbAsCb.timer.tmrEvnt != TMR_NONE )
                        {
                           SB_STOP_TMR(&(assocCb->sbAsCb.timer));
                        }
                        /* sb028: changes for freeze timer, allow timer to be zero */
                        if ( sctSap->sctSapCfg.reConfig.freezeTm > 0)
                        {
                           SB_START_TMR(&(assocCb->sbAsCb.timer), assocCb,
                                     SB_TMR_FREEZE,
                                     sctSap->sctSapCfg.reConfig.freezeTm);
                        }
                     
                        assocCb->assocState = SB_ST_CLOSED;
                     
                        tempSuAssocId = assocCb -> suAssocId;
                        if (sctSap -> sctSapCfg.reConfig.freezeTm == 0 )
                        {
                           (Void) sbAsAbortAssoc (assocCb, FALSE);
                           sbGlobalCb.assocCb[assocCb->spAssocId] = (SbSctAssocCb *) NULLP;
                           SB_FREE(sizeof(SbSctAssocCb), assocCb);
                        }

                        /* sb045.102: New Cause added */
                        /* sb046.102: notify user the rtrvInfo */
                        SbUiSctTermInd(&(sctSap->sctPst), sctSap->suId,
                                    tempSuAssocId, SCT_ASSOCID_SU,
                                    SCT_STATUS_COMM_LOST, SCT_CAUSE_SOCK_ERR,
                                    &rtrvInfo);
                     }
                  }
               }
            }
         }
      }
      else
      {
         localAddrCb->otherConnected = FALSE;
      }

      /* sb044.102: Try to reconnect once disconnect indication is received */
      if (localAddrCb->connected == FALSE)
      {
         if (localAddrCb->conRetryAttempt < MAX_CON_RETRY_ATTMPT)
         {
            if ((ret = sbLiOpenServer(tSap, localAddrCb)) != ROK)
            {
               SBDBGP(DBGMASK_LI, (sbGlobalCb.sbInit.prntBuf,
                    "SbLiHitBndCfm: could not open server\n"));
               RETVALUE(ret);
            }
         }
         else
         {
            sbLmGenAlarm(LCM_CATEGORY_INTERFACE, LSB_EVENT_TUCLCONNECT_FAIL,
                   LSB_CAUSE_EXCEED_CONF_VAL, tSap->tSapCfg.suId, LSB_SW_RFC_REL0);
            *(sbGlobalCb.localAddrCb + localAddrCb->suId) = (SbLocalAddrCb *)NULLP;
            (Void) cmHashListDelete(&(sbGlobalCb.localAddrHl), (PTR)localAddrCb);
         }
      }
   }

#if ( ERRCLASS & ERRCLS_DEBUG )
   else
   {
      SBLOGERROR( ERRCLS_DEBUG, ESB070, (ErrVal) conId,
                  "SbLiHitDiscInd: Invalid conId" );
                   sbLmGenAlarm( (U16)LCM_CATEGORY_INTERFACE,
                    (U16)LCM_EVENT_LI_INV_EVT,
                    (U16)LCM_CAUSE_INV_PAR_VAL,
                    (SuId)suId,
                    LSB_SW_RFC_REL0 );
      RETVALUE( RFAILED );
   }
#endif /* ERRCLS_DEBUG */

   RETVALUE( ROK );
}


/*
*
*       Fun:   SbLiHitDiscCfm
*
*       Desc:  This function is received in responce to a Disconnect
*              request when the Sap is being removed.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes:
*
*       File:  sb_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SbLiHitDiscCfm
(
Pst     *pst,    /* Post structure containing INFO on the src and dst */
SuId    suId,    /* ID of the TSAP in SCTP layer*/
U8      choice,  /* Selction of either a SU or a SP ConId */
UConnId conId,   /* Connection ID used by SCTP */
Action  action   /* Reason for the diconnection */
)
#else
PUBLIC S16 SbLiHitDiscCfm(pst, suId, choice, conId, action)
Pst     *pst;    /* Post structure containing INFO on the src and dst */
SuId    suId;    /* ID of the TSAP in SCTP layer*/
U8      choice;  /* Selction of either a SU or a SP ConId */
UConnId conId;   /* Connection ID used by SCTP */
Action  action;  /* Reason for the diconnection */
#endif
{
   SbTSapCb *tSap;
   SbLocalAddrCb *localAddrCb;
   SbSctAssocCb *assocCb;
   SctRtrvInfo rtrvInfo;
   SbSctSapCb *sctSap;
   U16 i;
   /* Patch sb028: allow freeze timer to be zero */
   UConnId tempSuAssocId;
   /* sb046.102: Multiple IP address per Endp */
   S16               ret=ROK;

   TRC3( SbLiHitDiscCfm );

#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                         (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbLiHitDiscCfm () failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_LI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */


   SBDBGP( DBGMASK_LI, ( sbGlobalCb.sbInit.prntBuf,
         "SbLiHitDiscCfm(pst, suId(%d), choice(%d), conId(%ld), action(%d))\n",
         suId, choice, conId, action ) );

#ifndef SS_MULTIPLE_PROCS
   UNUSED( pst );
#endif  /* SS_MULTIPLE_PROCS */

#ifndef DEBUGP

   UNUSED( action );

#endif

   /* sb022.102: Fix for layer shutdown */
   if (sbGlobalCb.sbInit.cfgDone == FALSE)
   {
      SBDBGP( DBGMASK_LI, ( sbGlobalCb.sbInit.prntBuf, 
              "sbLiHitDiscCfm: General configuration not done\n"));
      RETVALUE( RFAILED );
   }

#if ( ERRCLASS & ERRCLS_INT_PAR )

   if( (suId >= (SuId) sbGlobalCb.genCfg.maxNmbTSaps) || (suId < 0) )
   {
       SBLOGERROR( ERRCLS_INT_PAR,
                  ESB071,
                  (ErrVal) suId,
                  "SbLiHitDiscCfm(): suId out of range" );

       sbLmGenAlarm( (U16)LCM_CATEGORY_INTERFACE,
                    (U16)LCM_EVENT_LI_INV_EVT,
                    (U16)LCM_CAUSE_INV_SUID,
                    suId,
                    LSB_SW_RFC_REL0 );

       RETVALUE( RFAILED );
   }

#endif /* ERRCLS_INT_PAR */

   /* get the SCT SAP control block */
   tSap = *(sbGlobalCb.tSaps + suId);

   /* check to see if the SAP exists */
#if ( ERRCLASS & ERRCLS_INT_PAR )

   if ( tSap == (SbTSapCb *)NULLP )
   {
      SBLOGERROR( ERRCLS_INT_PAR,
                  ESB072,
                  (ErrVal) suId,
                  "SbLiHitDiscCfm(): Sap not configured" );

      sbLmGenAlarm( (U16)LCM_CATEGORY_INTERFACE,
                    (U16)LCM_EVENT_LI_INV_EVT,
                    (U16)LCM_CAUSE_INV_SAP,
                    suId,
                    LSB_SW_RFC_REL0 );

      RETVALUE( RFAILED );
   }

#endif /* ERRCLS_INT_PAR */

   localAddrCb = (SbLocalAddrCb *)NULLP;

   if ( choice == HI_USER_CON_ID )
   {
      if (conId < sbGlobalCb.genCfg.maxNmbSrcAddr)
      {
         localAddrCb = *(sbGlobalCb.localAddrCb + conId);
      }
      else
      {
         localAddrCb = *( sbGlobalCb.localAddrCb +
                          (conId - sbGlobalCb.genCfg.maxNmbSrcAddr) );
      }
   }
   else if ( choice == HI_PROVIDER_CON_ID )
   {
      for ( i = 0; i < sbGlobalCb.genCfg.maxNmbSrcAddr; i++ )
      {
         localAddrCb = *(sbGlobalCb.localAddrCb + i);

         if ( localAddrCb != (SbLocalAddrCb *)NULLP )
         {
            if ( (localAddrCb->spConId == conId) ||
                 (localAddrCb->spOtherConId == conId) )
            {
               i = sbGlobalCb.genCfg.maxNmbSrcAddr;
            }
            else
            {
               localAddrCb = (SbLocalAddrCb *)NULLP;
            }
         }
      }
   }

   if ( localAddrCb != (SbLocalAddrCb *)NULLP )
   {
      if (conId < sbGlobalCb.genCfg.maxNmbSrcAddr)
      {
         /* sb046.102: Multiple IP address per Endp */
         localAddrCb->connected = FALSE;

         /* remove all associations (we assume they abort properly) */
         for ( i = 0; i < sbGlobalCb.genCfg.maxNmbAssoc; i++ )
         {
            assocCb = sbGlobalCb.assocCb[i];

            if ( assocCb != (SbSctAssocCb *) NULLP )
            {
               if ( assocCb->localConn == localAddrCb )
               {
                  /* try to find another local address control block in the
                   * same endpCb */
                  SB_GET_LOCAL_CONN(assocCb->endpId, assocCb->localConn, ret);
                  if ( ret != ROK )
                  {
                     sctSap = *(sbGlobalCb.sctSaps + assocCb->spId);
                     if ( sctSap != (SbSctSapCb *)NULLP)
                     {
                        rtrvInfo.lastAckTsn = assocCb->sbAcCb.cumTsn;
                        rtrvInfo.lastSentTsn = assocCb->sbAcCb.nextLocalTsn - 1;
                        rtrvInfo.nmbUnsentDgms = sbDbQPackets(assocCb,
                                                              SB_DB_TSNWAITINGQ);
                        rtrvInfo.nmbUnackDgms = sbDbQPackets(assocCb,
                                                             SB_DB_CONGESTIONQ);
                        rtrvInfo.nmbUndelDgms = sbDbQPackets(assocCb,
                                                             SB_DB_SEQUENCEDQ) +
                                                             sbDbQPackets(assocCb,
                                                             SB_DB_ASSEMBLYQ);
                     
                        /* start freeze timer */
                        if ( assocCb->sbAsCb.timer.tmrEvnt != TMR_NONE )
                        {
                           SB_STOP_TMR(&(assocCb->sbAsCb.timer));
                        }
                        /* sb028.102 : allow freeze timer to be zero */
                        if (sctSap -> sctSapCfg.reConfig.freezeTm > 0)
                        {
                           SB_START_TMR(&(assocCb->sbAsCb.timer), assocCb,
                                     SB_TMR_FREEZE,
                                     sctSap->sctSapCfg.reConfig.freezeTm);
                        }
                     
                        assocCb->assocState = SB_ST_CLOSED;
                     
                        tempSuAssocId = assocCb->suAssocId;
                     
                        /* sb036.102: Remove assocCb in case of freezeTm ZERO */
                        if (sctSap -> sctSapCfg.reConfig.freezeTm == 0 )
                        {
                           (Void) sbAsAbortAssoc (assocCb, FALSE);
                           sbGlobalCb.assocCb[i] = (SbSctAssocCb *) NULLP;
                           SB_FREE(sizeof(SbSctAssocCb), assocCb);
                        }

                        /* sb046.102: notify user the rtrvInfo */
                        SbUiSctTermInd(&(sctSap->sctPst), sctSap->suId,
                                    tempSuAssocId, SCT_ASSOCID_SU,
                                    SCT_STATUS_COMM_LOST, SCT_CAUSE_NOT_APPL,
                                    &rtrvInfo);
                     }
                  }
               }
            }
         }
      }
      else
      {
         localAddrCb->otherConnected = FALSE;
      }

      if ( (localAddrCb->connected == FALSE) &&
           (localAddrCb->otherConnected == FALSE) )
      {
         sbGlobalCb.localAddrCb[localAddrCb->suId] = (SbLocalAddrCb *)NULLP;
         (Void) cmHashListDelete(&(sbGlobalCb.localAddrHl), (PTR)localAddrCb);
      }

   }

#if ( ERRCLASS & ERRCLS_DEBUG )
   else
   {
      SBDBGP( DBGMASK_LI, ( sbGlobalCb.sbInit.prntBuf,
                            "SbLiHitDiscCfm: Connection already deleted\n") );
      RETVALUE( ROK );
   }
#endif /* ERRCLS_DEBUG */

   RETVALUE( ROK );
}


/*
*
*       Fun:   SbLiHitBndCfm
*
*       Desc:  This function is received from the layer below in
*              response to a Bind request. This function must inform
*              the layer manager that the bind has succeeded or failed.
*              A server open request is sent to the TUCL layer for each
*              configured source address. The bind confirm timer is only
*              stopped once all these requests are confirmed.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes:
*
*       File:  sb_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SbLiHitBndCfm
(
Pst            *pst,     /* Post structure */
SuId            suId,    /* Service user SAP ID */
U8              status   /* Status of the Bind requested */
)
#else
PUBLIC S16 SbLiHitBndCfm(pst, suId, status)
Pst            *pst;     /* Post structure */
SuId            suId;    /* Service user SAP ID */
U8              status;  /* Status of the Bind requested */
#endif
{
   SbTSapCb         *tSap;
   SbLocalAddrCb    *localAddrCb;
   U16               i;
   U16               j=0;  /* sb001.12 : modification - warning removed */
   S16               ret;
   TRC3(SbLiHitBndCfm)

#ifdef SS_MULTIPLE_PROCS

   if(SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                         (void **)&sbGlobalCbPtr) != ROK)
   {
     SBLOGERROR(ERRCLS_DEBUG, ESB337, 0,
               "SbLiHitBndCfm () failed, cannot derive sbGlobalCbPtr");
     RETVALUE(FALSE);
   }

   SBDBGP(DBGMASK_LI, (sbGlobalCb.sbInit.prntBuf,
         "-------SCTP------(proc(%d), ent(%d), inst(%d))--------\n",
         pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif /* SS_MULTIPLE_PROCS */

   SBDBGP(DBGMASK_LI, (sbGlobalCb.sbInit.prntBuf,
          "SbLiHitBndCfm(pst, suId(%d), status(%d))\n", suId, status));

#ifndef SS_MULTIPLE_PROCS
   UNUSED(pst);
#endif  /* SS_MULTIPLE_PROCS */

   /* sanity check on suId */
#if (ERRCLASS & ERRCLS_INT_PAR)
   if ( (suId >= (SuId) sbGlobalCb.genCfg.maxNmbTSaps) || (suId < 0) )
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB073, (ErrVal) suId,
                 "SbLiHitBndCfm(): suId out of range");
      sbLmGenAlarm((U16)LCM_CATEGORY_INTERFACE, (U16)LCM_EVENT_LI_INV_EVT,
                   (U16)LCM_CAUSE_INV_SUID, suId, LSB_SW_RFC_REL0);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   /* get the transport SAP control block */
   tSap = sbGlobalCb.tSaps[suId];

   /* check to see if the SAP exists */
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (tSap == (SbTSapCb *)NULLP )
   {
      SBLOGERROR(ERRCLS_INT_PAR, ESB074, (ErrVal) suId,
                 "SbLiHitBndCfm(): Sap not configured");
      sbLmGenAlarm((U16)LCM_CATEGORY_INTERFACE, (U16)LCM_EVENT_LI_INV_EVT,
                   (U16)LCM_CAUSE_INV_SAP, suId, LSB_SW_RFC_REL0);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   if ( status == CM_BND_OK )
   {
      /* SAP bound OK */
      /* set the SAP state */
      tSap->sapState = SB_SAPSTATE_BND;

      /* loop through the configured src address list */
      for ( i = 0; i < tSap->tSapCfg.srcNAddrLst.nmb; i++ )
      {
         /* see if src address is already in a localAddrCb */
         /* this is really a sanity check */
         localAddrCb = (SbLocalAddrCb *)NULLP;
         ret = cmHashListFind(&(sbGlobalCb.localAddrHl),
                             (U8 *) &(tSap->tSapCfg.srcNAddrLst.nAddr[i]),
                             sizeof(CmNetAddr), 0, (PTR *) &localAddrCb);

#if (ERRCLASS & ERRCLS_INT_PAR)
         if ( ret == ROK )
         {
            /* src address already put into localAddrCb */
            SBLOGERROR(ERRCLS_INT_PAR, ESB075, (ErrVal)0,
                       "SbLiHitBndCfm(): local address overlap");
            break;
         }
#endif /*(ERRCLASS & ERRCLS_INT_PAR)*/

         /* look for an empty spot for a new localAddrCb */
         for ( j = 0; j < sbGlobalCb.genCfg.maxNmbSrcAddr; j++)
         {
            if ( sbGlobalCb.localAddrCb[j] == (SbLocalAddrCb *) NULLP )
            {
               /* empty spot in list found */
               break;
            }
         }

         if ( j >= sbGlobalCb.genCfg.maxNmbSrcAddr)
         {
            /* Resource Error */
#if (ERRCLASS & ERRCLS_INT_PAR)
            SBLOGERROR(ERRCLS_INT_PAR, ESB076, (ErrVal)0,
                       "SbLiHitBndCfm: config. max reached for localAddrCb");
#endif
         }
         else
         {
            /* create a new localAddrCb */
            SB_ALLOC(sizeof(SbLocalAddrCb), localAddrCb, ret);
            if ( ret != ROK )
            {
               SBDBGP(DBGMASK_LI, (sbGlobalCb.sbInit.prntBuf,
                      "SbLiHitBndCfm: could not alloc mem for localAddrCb\n"));
            }
            else
            {

               SB_CPY_NADDR(&(localAddrCb->ownAddr),
                            &(tSap->tSapCfg.srcNAddrLst.nAddr[i]));
               localAddrCb->suId = suId;
               localAddrCb->connected = FALSE;
               localAddrCb->spConId = 0;
               localAddrCb->suConId = j;
               localAddrCb->spOtherConId = 0;
               localAddrCb->suOtherConId = j + sbGlobalCb.genCfg.maxNmbSrcAddr;
               /* sb044.102: Try to reconnect */
               localAddrCb->conRetryAttempt = 0;

               /* insert into the global hash list */
               ret = cmHashListInsert(&(sbGlobalCb.localAddrHl),
                                      (PTR) localAddrCb,
                                      (U8 *) &(localAddrCb->ownAddr),
                                      sizeof(CmNetAddr));
               if ( ret != ROK )
               {
                  /* couldn't insert localAddrCb into hashlist */
                  SBDBGP(DBGMASK_LI, (sbGlobalCb.sbInit.prntBuf,
                      "SbLiHitBndCfm: could not insert localAddrCb into HL\n"));
                  /* localAddrCb has been allocated so delete it */
                  SB_FREE(sizeof(SbLocalAddrCb), localAddrCb);
                  RETVALUE(RFAILED);
               }

               /* insert into the global array list */
               sbGlobalCb.localAddrCb[localAddrCb->suConId] = localAddrCb;

               if ((ret = sbLiOpenServer(tSap, localAddrCb)) != ROK)
               {
                  SBDBGP(DBGMASK_LI, (sbGlobalCb.sbInit.prntBuf,
                        "SbLiHitBndCfm: could not open server\n"));
                  RETVALUE(ret);
               }
            }
         } /* end else */
      } /* end for */

     sbGlobalCb.dnsInfo.suId = suId;
     sbGlobalCb.dnsInfo.dnsState = SB_DNS_SERV_CLOSED;
     /* Set the suConId to the next available Running number */
     /* sb044.102: Don not open DNS server if dns is not configured */
     if(tSap->tSapCfg.reConfig.sbDnsCfg.useDnsLib == TRUE)
     {
        sbGlobalCb.dnsInfo.suConId  = 2 * (j + sbGlobalCb.genCfg.maxNmbSrcAddr);
        ret = sbOpenDnsServer(tSap);
        if(ret != ROK)
        {
           SBDBGP(DBGMASK_LI, (sbGlobalCb.sbInit.prntBuf,
              "SbLiHitBndCfm: could not open  DNS Server\n"));
           RETVALUE(ret);
        }
      }
   }
   else
   {
      /* SAP did not Bind */
      SBDBGP(DBGMASK_LI, (sbGlobalCb.sbInit.prntBuf,
             "SbLiHitBndCfm: bind was unsuccessful\n"));

      if ( sbGlobalCb.sbMgmt.hdr.elmId.elmnt == STTSAP )
      {
         /* stop bind confirm timer */
         if (tSap->timer.tmrEvnt != TMR_NONE)
         {
            SB_STOP_TMR(&(tSap->timer));
         }

         sbGlobalCb.sbMgmt.cfm.status = LCM_PRIM_NOK;
         sbGlobalCb.sbMgmt.cfm.reason = LCM_REASON_NEG_CFM;
         SbMiLsbCntrlCfm(&(sbGlobalCb.sbInit.lmPst), &(sbGlobalCb.sbMgmt));

         /* clear this so that other layer manager requests can proceed */
         SB_ZERO(&(sbGlobalCb.sbMgmt), sizeof(SbMgmt));
      }

      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
}/* SbLiHitBndCfm() */


/********************************************************************30**

         End of file:     sb_bdy1.c@@/main/2 - Wed Jan 10 16:26:15 2001

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:

*********************************************************************61*/
/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
 /main/2     ---   wvdl,      1. initial release.
 /main/2     ---    sb        1. Modified for SCTP release based on 
                                 RFC-2960 'Oct 2000.
         sb001.12   sb        1. Memory Initialisation problem fix.
         sb002.12   nj        1. Added a defensive check for 0 value.
         sb004.12   sb        1. Memory for Confirm structure allocated 
                                 from heap.
                              2. Return value of sbPmAddAddr is checked.
         sb006.102  rs        1. Updation - modified for alignment in
                                 sbSctEndpEntry
         sb008.12   sb        1. For UDP, In UDatInd primitive copy the
                                 own address for localConnAddrCb. Only 
                                 when this is done SCTP will be able to 
                                 find association. 
                              2. Condition modified in ConCfm for UDP case.
         sb009.102  rs        1. Closing endpoint with SU id
         sb010.102  rs        1. suAssocId in Termination Indication.
         sb015.102  rs        1. DNS Timer is Enabled flag is implemented. 
         sb017.102  rs        1. Endpoint close problem removed. 
                              2. spare1 removed.
         sb018.102  ab        1. dbgMask initialized to 0.
         sb020.102  ab        1. suAssocId should be unique per SAP.
                    rs        2. Association control block freed.
                    rs        3. Destination Network addresslist problem
                                 with maxNmbDestAddr = 1 solved.
                    rs        4. Double SACK problem.
         sb021.102  rs        1. Modification for TOS parameter.
         sb022.101  ab        1. Fix for layer shutdown.
         sb023.102  sb        1. Changes done in Mtu procedure
         sb027.102  hm        1. Removed TAB
         sb028.102  hm        1. Changes to allow freeze timer to be zero
         sb029.102  hm        1. dlvrCfmChunk is set to FALSE, default value
         sb031.102  hm        1. IPV6 Support Added 
         sb036.102  rs        1. Dump the data if assoc is not established
         sb041.102  hl        1. remove the errcls parameter check flag 
         sb042.102  hl        1. Added change for SHT interface and Rolling
                                 Up Grade
         sb044.102  rs        1. Added reconnect once disconnect indication is
                                 received
         sb045.102  rs        1. New Cause value added in disconnect indication.
         sb046.102  hl        1. Multiple IP address per endpoint support
                              2. Alwasy notify retrievel info to user in case
                                 of abort.
         sb048.102  rs        1. New compile time option SB_DEBUGP will
                                 enable the debug prints by default.
                              2. Endpoint hash list problem resolved.
         sb049.102  rs        1. Warnings removed.
                              2. Hash list problems resolved.
         sb051.102  ag        1. System Services Returns checked.
                              2. DNS Server is opened only when useDNS is True
         sb052.102  ag        1. Provide ethereal like message trace. 
         sb054.102  rk        1. Bundling Changes.
         sb056.102  rk        1. In case of primary dest address failure
                                 try assoc on alternate dest addr of
                                 address list 
         sb057.102  pr        1. Multiple proc ids support added.
         sb060.102  pr        1. TOS enhancement.
         sb064.102  pr        1. Remove compiler warnings.
         sb065.102  kp        1. UDP port as configurable parameter.
	 sb068.102  kp        1. For sending suEndpId in SbUiSctEndpCloseCfm 
				 if endpIdType = SCT_ENDPID_SP 
*********************************************************************91*/


