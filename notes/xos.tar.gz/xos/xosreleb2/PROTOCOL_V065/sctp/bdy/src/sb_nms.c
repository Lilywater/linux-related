/* ***************************************************************************
 *        (c) COPYRIGHT 1995-2006 by Xinwei, Inc.
 *                   All rights reserved.
 *
 * sb_nms.c:  
 *          Sctp protocol net manage function.
 *           
 * Author:
 *          zhouguishuang
 * Date:
 *          2006-5-8
 * Last Modified:
 *
 ****************************************************************************/

#ifdef CP_OAM_SUPPORT

#include "sb_common.h"
#include "xosshell.h"
#include "cp_tab_def.h"
#include "cm_ss7.h"
/*#include "sm.h"*/

#include "cm_ss7.x"
#include "cp_oam_stru.x"
#include "cp_oam_stru.h"
#include "sm.x"
#include "sb_cfg.h"
#include "oam_interface.h"
#include "sb_oam.x"
#ifdef CP_OAM_DATA_SHOW
EXTERN PUBLIC S16  sb_print_state_cb_info(U16 print_action);
#endif /*CP_OAM_DATA_SHOW*/

extern void  sbBndHiReq(SuId suId);

unsigned int sctp_startup_flag = 0;

void sbHsttoNet(U32 *tmpIpAddr)
{
	U32 byte1,byte2,byte3,byte4;
	byte1=byte2=byte3=byte4=0;

	if(tmpIpAddr == NULL)
	{
		SPrint("Convert host to net byte order error!\n");
		return;
	}
	
	if(*tmpIpAddr == 0)
	{
		return;
	}

	*tmpIpAddr = XOS_NtoHl(*tmpIpAddr);
	return;
	
}


VOID sbResetCfgData(void)
{
	return;
}







S16 sbRecvInitCfg(unsigned short msgtype, tb_record* prow)
{
   SbCfgGenWG  * tmpsbCfgGen=NULLP;
   SbCfgAddrWG  * tmpsbCfgAddrGen=NULLP;
   U32 			TempIpAddr;
   CP_OAM_COM_IP_TAB*             pIpTab;
   
   /*
   U8 * tmpsbCfgGen=NULLP; 
   U8 * tmpsbCfgAddrGen=NULLP; 
   */
    S16  n = 0, recNo = 1;
    U32 i=0;
    if(!prow)
    {
        SPrint("SCTP OAM READ ERROR!\n");
        return RFAILED;
    }
	while(prow)
	{
		switch(prow->tableid)
		{
			case APP_TABLE_ID_VOIP_SCTP_GEN:
				
				tmpsbCfgGen = (SbCfgGenWG *) prow->panytbrow;
				/* memcpy((SbCfgGenWG *)&sbCfgGenWg,(SbCfgGenWG *)tmpsbCfgGen,sizeof(SbCfgGenWG));*/
				if((tmpsbCfgGen->maxNmbSctSaps >= 1)&&(tmpsbCfgGen->maxNmbSctSaps <=10))
				{
                    sbCfgGenWg.maxNmbSctSaps = tmpsbCfgGen->maxNmbSctSaps;
				}
                else
                {
                    SPrint("SCTP:maxNmbSctSaps cfg value error.range:[1-10].\n");
					return RFAILED;
                }
				
				if((tmpsbCfgGen->maxNmbTSaps >= 1)&&(tmpsbCfgGen->maxNmbTSaps <=5))
				{
                    sbCfgGenWg.maxNmbTSaps = tmpsbCfgGen->maxNmbTSaps;
				}                
                else
                {
                    SPrint("SCTP:maxNmbTSaps cfg value error.range:[1-5].\n");
					return RFAILED;
                }
				
				if((tmpsbCfgGen->maxNmbEndp >= 50)&&(tmpsbCfgGen->maxNmbEndp <=1000))
				{
                    sbCfgGenWg.maxNmbEndp = tmpsbCfgGen->maxNmbEndp;
				}                
                else
                {
                    SPrint("SCTP:maxNmbEndp cfg value error.range:[50-1000].\n");
					return RFAILED;
                }
				
				if((tmpsbCfgGen->maxNmbAssoc >= 50)&&(tmpsbCfgGen->maxNmbAssoc <=1000))
				{
                    sbCfgGenWg.maxNmbAssoc = tmpsbCfgGen->maxNmbAssoc;
				}                
                else
                {
                    SPrint("SCTP:maxNmbAssoc cfg value error.range:[50-1000].\n");
					return RFAILED;
                }
				
				if((tmpsbCfgGen->maxNmbDstAddr >= 50)&&(tmpsbCfgGen->maxNmbDstAddr <=100))
				{
					sbCfgGenWg.maxNmbDstAddr = tmpsbCfgGen->maxNmbDstAddr ;
				}                
                else
                {
                    SPrint("SCTP:maxNmbDstAddr cfg value error.range:[50-100].\n");
					return RFAILED;
                }
				
				if((tmpsbCfgGen->maxNmbSrcAddr >= 50)&&(tmpsbCfgGen->maxNmbSrcAddr <=100))
				{
                 	sbCfgGenWg.maxNmbSrcAddr = tmpsbCfgGen->maxNmbSrcAddr ;
				}                
                else
                {
                    SPrint("SCTP:maxNmbSrcAddr cfg value error.range:[50-100].\n");
					return RFAILED;
                }
				
				if((tmpsbCfgGen->maxNmbTxChunks >= 30)&&(tmpsbCfgGen->maxNmbTxChunks <=10000))
				{
                	sbCfgGenWg.maxNmbTxChunks = tmpsbCfgGen->maxNmbTxChunks;
				}                
                else
                {
                    SPrint("SCTP:maxNmbTxChunks cfg value error.range:[30-10000].\n");
					return RFAILED;
                }
				
				if((tmpsbCfgGen->maxNmbRxChunks >= 30)&&(tmpsbCfgGen->maxNmbRxChunks <=10000))
				{
                	sbCfgGenWg.maxNmbRxChunks = tmpsbCfgGen->maxNmbRxChunks;
				}                
                else
                {
                    SPrint("SCTP:maxNmbRxChunks cfg value error.range:[30-10000].\n");
					return RFAILED;
                }
				
				if((tmpsbCfgGen->maxNmbInStrms >= 30)&&(tmpsbCfgGen->maxNmbInStrms <=10000))
				{
                	sbCfgGenWg.maxNmbInStrms = tmpsbCfgGen->maxNmbInStrms ; 
				}                
                else
                {
                    SPrint("SCTP:maxNmbInStrms cfg value error.range:[30-10000].\n");
					return RFAILED;
                }
				
				if((tmpsbCfgGen->maxNmbOutStrms >= 30)&&(tmpsbCfgGen->maxNmbOutStrms <=10000))
				{
                	sbCfgGenWg.maxNmbOutStrms = tmpsbCfgGen->maxNmbOutStrms;
				}                
                else
                {
                    SPrint("SCTP:maxNmbOutStrms cfg value error.range:[30-10000].\n");
					return RFAILED;
                }
				
				if((tmpsbCfgGen->initARwnd >= 2048)&&(tmpsbCfgGen->initARwnd <=9120480))
				{
                	sbCfgGenWg.initARwnd = tmpsbCfgGen->initARwnd; 
				}                
                else
                {
                    SPrint("SCTP:initARwnd cfg value error.range:[2048-9120480].\n");
					return RFAILED;
                }
				
				if((tmpsbCfgGen->mtuInitial >= 200)&&(tmpsbCfgGen->mtuInitial <=2000))
				{
                	sbCfgGenWg.mtuInitial = tmpsbCfgGen->mtuInitial; 
				}                
                else
                {
                    SPrint("SCTP:mtuInitial cfg value error.range:[200-2000].\n");
					return RFAILED;
                } 
				
				if((tmpsbCfgGen->performMtu >= 0)&&(tmpsbCfgGen->performMtu <=1))
				{
                	sbCfgGenWg.performMtu = tmpsbCfgGen->performMtu ;
				}                
                else
                {
                    SPrint("SCTP:performMtu cfg value error.range:[0-1].\n");
					return RFAILED;
                }
				if((tmpsbCfgGen->UsePerAssocChunks >= 1)&&(tmpsbCfgGen->UsePerAssocChunks <=9999))
				{
                	sbCfgGenWg.UsePerAssocChunks = tmpsbCfgGen->UsePerAssocChunks;
				}                
                else
                {
                    SPrint("SCTP:FlcUpValue cfg value error.range:[1-9999].\n");
					return RFAILED;
                }				
				if((tmpsbCfgGen->UseFlcAssocChunks >= 1)&&(tmpsbCfgGen->UseFlcAssocChunks <=9999))
				{
                	sbCfgGenWg.UseFlcAssocChunks = tmpsbCfgGen->UseFlcAssocChunks;
				}                
                else
                {
                    SPrint("SCTP:FlcLowValue cfg value error.range:[1-9999].\n");
					return RFAILED;
                }
				
				break;
			case APP_TABLE_ID_VOIP_SCTP_SRC_ADDR:
				
				tmpsbCfgAddrGen = (SbCfgAddrWG *) prow->panytbrow;
				memcpy((U8 *)&sbCfgAddrWG,(U8 *)tmpsbCfgAddrGen,sizeof(SbCfgAddrWG));
                
				if((tmpsbCfgAddrGen->NmbsrcNAddr >= 1)&&(tmpsbCfgAddrGen->NmbsrcNAddr <=5))
				{
					for(i=0;i<tmpsbCfgAddrGen->NmbsrcNAddr;i++)
					{
						TempIpAddr = 0;
	                	if (( ROK != CpComGetSrcIpAddr(sbCfgAddrWG.srcNAddrIndex1, &TempIpAddr) )&&(i==0))
	                	{
	                    	SPrint("SCTP:CpComGetIpAddr srcNAddrIndex1 error.NOT IP OF INDEX.\n");
	                    	RETVALUE(RFAILED);
	                	}					
						sbHsttoNet(&TempIpAddr);
						localNAddrLst_1V[0] = TempIpAddr;
						
						TempIpAddr = 0;
	                	if (( ROK != CpComGetSrcIpAddr(sbCfgAddrWG.srcNAddrIndex2, &TempIpAddr) )&&(i==1))
	                	{
	                    	SPrint("SCTP:CpComGetIpAddr srcNAddrIndex2 error.NOT IP OF INDEX.\n");
	                    	RETVALUE(RFAILED);
	                	}					
						sbHsttoNet(&TempIpAddr);
						localNAddrLst_1V[1] = TempIpAddr;

						TempIpAddr = 0;
	                	if (( ROK != CpComGetSrcIpAddr(sbCfgAddrWG.srcNAddrIndex3, &TempIpAddr) )&&(i==2))
	                	{
	                     	SPrint("SCTP:CpComGetIpAddr srcNAddrIndex3 error.NOT IP OF INDEX.\n");
	                   		RETVALUE(RFAILED);
	                	}					
						sbHsttoNet(&TempIpAddr);
						localNAddrLst_1V[2] = TempIpAddr;

						TempIpAddr = 0;
	                	if (( ROK != CpComGetSrcIpAddr(sbCfgAddrWG.srcNAddrIndex4, &TempIpAddr) )&&(i==3))
	                	{
	                    	SPrint("SCTP:CpComGetIpAddr srcNAddrIndex4 error.NOT IP OF INDEX.\n");
	                    	RETVALUE(RFAILED);
	                	}					
						sbHsttoNet(&TempIpAddr);
						localNAddrLst_1V[3] = TempIpAddr;
						TempIpAddr = 0;
	                	if (( ROK != CpComGetSrcIpAddr(sbCfgAddrWG.srcNAddrIndex5, &TempIpAddr) )&&(i==4))
	                	{
	                    	SPrint("SCTP:CpComGetIpAddr srcNAddrIndex5 error.NOT IP OF INDEX.\n");
	                    	RETVALUE(RFAILED);
	                	}					
						sbHsttoNet(&TempIpAddr);
						localNAddrLst_1V[4] = TempIpAddr;

					}

						
				}
                else
                {
                   SPrint("SCTP:NmbsrcNAddr cfg value error.range:[1-5].\n");
				   return RFAILED;
                }
				break;
            case APP_TABLE_ID_COM_IP:
                pIpTab = (CP_OAM_COM_IP_TAB*)prow->panytbrow;

                if ( ROK !=  CpComSetOneIpTab(EN_CP_OPR_ADD,  pIpTab) )
                {
					SPrint("SCTP:CpComSetOneIpTab error.\n");
                    RETVALUE(RFAILED);
                }
                break;


			default:
				break;
		}

		prow = prow->next;
	}


    return ROK;                                         
}


S16 sbSendCfgMsg(viod)
{
    S16 ret = ROK;

    /* static config data only be done in config start phase, and it would not change after system started*/
    if( gSmCb[ENTSB].smStatus == SM_INIT_CFG_STATE)
    {
        ret = sctp_oam_config_gen();
	if(ret == RFAILED)
		{
		    return ret;
		}
        ret = sctp_oam_config_sctsap();
	if(ret == RFAILED)
		{
		    return ret;
		}		
        ret = sctp_oam_config_tsap();
	if(ret == RFAILED)
		{
		    return ret;
		}		
    }

	RETVALUE(ROK);
}







unsigned char sbNmInitCallback(unsigned short msgtype, unsigned int sepuense, unsigned char pack_end, tb_record* prow)
{
	
	SuId suId=0;
	sctp_startup_flag = 0;
    /* 1.ȡ��������  */
	if(ROK != sbRecvInitCfg(msgtype,prow))
	{
		opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
		return RFAILED;
	} 	
    
	if(TRUE == pack_end)
	{
	   /* 2.����������д������*/
		if(ROK != sbSendCfgMsg())
		{
			opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
			return RFAILED;
		} 	

		/* send out a config req message to sm*/
		/*3.����һ����ʾ��Ϣ������SM���Կ�ʼ������������*/
		if( ROK != smSendCfgReq(ENTSB, SM_INIT_CFG_STATE))
		{
			opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
			return RFAILED;                 
		}
		/* wait initial cofiguration finished*/
		ssWaitSema(&gSmCb[ENTSB].sema);

		/* send response to subagent*/
		if(SM_SUCCESS_STATE ==  gSmCb[ENTSB].smStatus)
		{
			/* All the initialization configuration data is processed successfully */
			opt_response_batch(sepuense, OAM_RESPONSE_OK);
			sctp_startup_flag = 1;
			sbBndHiReq(suId);
			smReset(ENTSB);
		}
		else 
		{
			opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
		}
	    
	
	}
    SPrint("SCTP cfg finished.\n");
#ifdef CP_OAM_DATA_SHOW
	sb_print_state_cb_info(0x0080);
#endif /*CP_OAM_DATA_SHOW*/
	return ROK;
}


#endif /*CP_OAM_SUPPORT*/


