/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**

     Name:     SCTP Layer

     Type:     C source file

     Desc:     C source code for SB layer portable Upper Interface

     File:     sb_ptui.c

     Sid:      sb_ptui.c@@/main/2 - Wed Jan 10 16:25:42 2001

     Prg:      wvdl, bk

*********************************************************************21*/


/* header include files (.h) */

/* header/extern include files (.x) */



/*

The following functions are provided in this file:


It should be noted that not all of these functions may be required
by a particular network layer service user.


*/

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "lsb.h"           /* layer management SB */
#include "cm_err.h"        /* common error */
#include "cm_tpt.h"        /* common transport defines */
#include "cm_dns.h"        /* common transport defines */
#ifdef SB_FTHA
#include "sht.h"           /* SHT Interface header file */
#endif /* SB_FTHA */
#include "sct.h"           /* sct interface */
#include "hit.h"           /* hit interface */
#include "sb_mtu.h"
#include "sb.h"            /* SCTP defines */
#include "sb_err.h"        /* SB error */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_tpt.x"        /* common transport address */
#include "cm_dns.x"        /* common transport defines */
#include "cm5.x"           /* common timer */
#ifdef SB_FTHA
#include "sht.x"           /* SHT Interface header file */
#endif /* SB_FTHA */
#include "hit.x"           /* hit interface */
#include "sct.x"           /* sct interface */
#include "lsb.x"           /* layer management SCTP */
#include "sb_mtu.x"
#include "sb.x"            /* SCTP typedefs */



 /* sb003.11 - changed due to added users */
/* local defines */
/* sb048.102: GCP added as new SCTP user */
/* sb052.102: NBAP (ENTIB), M1UA (ENTMZ) added as new SCTP user. */
/* sb065.102: SIP added as new SCTP user */
#define MAXSBUI 10          /* max SB Layer upper users */

/* sb048.102: Changes to incorporate GCP */
/* sb052.102: NBAP (ENTIB), M1UA (ENTMZ) added as new SCTP user. */
/* sb065.102: SIP added as new SCTP user */
#if ( (!defined(LCSBUISCT)) || !(defined(IT)) || !(defined(SU)) || !(defined(MW)) || (!defined(MG)) || (!defined(DM)) || (!defined(IB)) || (!defined(MZ)) || (!defined(SO)))
#define PTSBUISCT
#endif

/* local typedefs */

/* local externs */

#ifdef PTSBUISCT

/* declaration of portable functions */
PRIVATE S16 PtUiSctBndCfm            ARGS((Pst           *pst,
                                          SuId           suId,
                                          SctResult      result));

PRIVATE S16 PtUiSctEndpOpenCfm       ARGS((Pst           *pst,
                                          SuId           suId,
                                          UConnId        suEndpId,
                                          UConnId        spEndpId,
                                          SctResult      result,
                                          SctCause       cause));

PRIVATE S16 PtUiSctEndpCloseCfm      ARGS((Pst           *pst,
                                          SuId           suId,
                                          UConnId        suEndpId,
                                          SctResult      result,
                                          SctCause       cause));


PRIVATE S16 PtUiSctAssocInd          ARGS((Pst               *pst,
                                           SuId               suId,
                                           UConnId            suEndpId,
                                           SctAssocIndParams *assocParams,
                                           Buffer            *vsInfo));

/* sb016.102 - Include in-stream parameter here */
#ifdef SCT2
PRIVATE S16 PtUiSctAssocCfm          ARGS((Pst           *pst,
                                          SuId           suId,
                                          UConnId        suAssocId,
                                          UConnId        spAssocId,
                                          SctNetAddrLst *dstNAddrLst,
                                          SctPort        dstPort,
                                          SctStrmId      inStrms,
                                          SctStrmId      outStrms,
                                          Buffer        *vsInfo ));
#else /* SCT2 */
PRIVATE S16 PtUiSctAssocCfm          ARGS((Pst           *pst,
                                          SuId           suId,
                                          UConnId        suAssocId,
                                          UConnId        spAssocId,
                                          SctNetAddrLst *dstNAddrLst,
                                          SctPort        dstPort,
                                          SctStrmId      outStrms,
                                          Buffer        *vsInfo ));
#endif /* SCT2 */

PRIVATE S16 PtUiSctTermInd           ARGS((Pst           *pst,
                                          SuId           suId,
                                          UConnId        assocId,
                                          U8             assocIdType,
                                          SctStatus      status,
                                          SctCause       cause,
                                          SctRtrvInfo   *rtrvInfo));

PRIVATE S16 PtUiSctTermCfm           ARGS((Pst           *pst,
                                          SuId           suId,
                                          UConnId        suAssocId,
                                          SctResult      result,
                                          SctCause       cause));

PRIVATE S16 PtUiSctSetPriCfm         ARGS((Pst           *pst,
                                          SuId           suId,
                                          UConnId        suAssocId,
                                          SctResult      result,
                                          SctCause       cause));

PRIVATE S16 PtUiSctHBeatCfm          ARGS((Pst           *pst,
                                          SuId           suId,
                                          UConnId        suAssocId,
                                          CmNetAddr     *dstNAddr,
                                          SctStatus      status,
                                          SctResult      result,
                                          SctCause       cause));

PRIVATE S16 PtUiSctDatInd            ARGS((Pst           *pst,
                                          SuId           suId,
                                          UConnId        suAssocId,
                                          SctStrmId      strmId,
                                          SctDatIndType *indType,
                                          U32            protId,
                                          Buffer        *mBuf));

PRIVATE S16 PtUiSctStaCfm            ARGS((Pst           *pst,
                                          SuId           suId,
                                          UConnId        suAssocId,
                                          CmNetAddr     *dstNAddr,
                                          SctResult      result,
                                          SctCause       cause,
                                          SctStaInfo    *staInfo));

PRIVATE S16 PtUiSctStaInd            ARGS((Pst           *pst,
                                          SuId           suId,
                                          UConnId        suAssocId,
                                          UConnId        spAssocId,
                                          CmNetAddr     *dstNAddr,
                                          SctStatus      status,
                                          SctCause       cause,
                                          Buffer        *mBuf));

PRIVATE S16 PtUiSctFlcInd            ARGS((Pst           *pst,
                                          SuId           suId,
                                          UConnId        suAssocId,
                                          Reason         reason));


#endif /* PTSBUISCT */


/*
  The following matrices define the mapping between the primitives
  called by the upper interface of SCTP Layer
  and the corresponding primitives of the SCTP Layer
  service user(s).

  The parameter MAXSBUI defines the maximum number of service users on
  top of SCTP Layer. There is an array of functions
  per primitive invoked by SCTP Layer. Every array is
  MAXSBUI long(i.e.there are as many functions as the number of service
  users).

  The dispatching is performed by the configurable variable: selector.
  The selector is configured on a per SAP basis.

  The selectors are:

  0 - loosely coupled (#define LCSBUISCT)
  1 - M3UA            (#define IT)
  2 - IUA             (#define ID)
  3 - SUA             (#define SU)
  4 - M2UA            (#define MW)
  sb048.102: Changes to incorporate GCP
  5 - GCP             (#define MG)
  6 - Dummy Layer     (#define DM)
  sb052.102: NBAP (ENTIB) added as new SCTP user. 
  7 - NBAP            (#define IB)
  8 - M1UA            (#define MZ)
  9 - SIP             (#define SO)

*/



PRIVATE SctBndCfm SbUiSctBndCfmMt[MAXSBUI] =
{
#ifdef LCSBUISCT
   cmPkSctBndCfm,         /* 0 - loosely coupled */
#else
   PtUiSctBndCfm,         /* 0 - tightly coupled, portable */
#endif
#ifdef IT
   ItLiSctBndCfm,         /* 1 - tightly coupled, M3UA */
#else
   PtUiSctBndCfm,         /* 1 - tightly coupled, portable */
#endif
#ifdef ID
   IdLiSctBndCfm,         /* 2 - tightly coupled, IUA */
#else
   PtUiSctBndCfm,         /* 2 - tightly coupled, portable */
#endif
#ifdef SU
   SuLiSctBndCfm,         /* 3 - tightly coupled, SUA */
#else
   PtUiSctBndCfm,         /* 3 - tightly coupled, portable */
#endif
#ifdef MW
   MwLiSctBndCfm,         /* 4 - tightly coupled, M2UA */
#else
   PtUiSctBndCfm,         /* 4 - tightly coupled, portable */
#endif
/* sb048.102: Changes to incorporate GCP */
#ifdef SCTP_MG     /*chendh modify*/
   MgLiSctBndCfm,         /* 5 - tightly coupled, GCP */
#else
   PtUiSctBndCfm,         /* 5 - tightly coupled, portable */
#endif
#ifdef DM
   DmLiSctBndCfm,         /* 6 - tightly coupled, DM */
#else
   PtUiSctBndCfm,         /* 6 - tightly coupled, portable */
#endif
/* sb052.102: NBAP (ENTIB), M1UA (ENTMZ) added as new SCTP user. */
#ifdef IB
   IbLiSctBndCfm,         /* 7 - tightly coupled, GCP */
#else
   PtUiSctBndCfm,         /* 7 - tightly coupled, portable */
#endif
#ifdef MZ
   MzLiSctBndCfm,         /* 8 - tightly coupled, GCP */
#else
   PtUiSctBndCfm,         /* 8 - tightly coupled, portable */
#endif
/* sb065.102: SIP added as new SCTP user */
#ifdef SCTP_SO     /*chendh modify*/
   SoLiSctBndCfm,         /* 8 - tightly coupled, SIP */
#else
   PtUiSctBndCfm,         /* 8 - tightly coupled, portable */
#endif
};


PRIVATE SctEndpOpenCfm SbUiSctEndpOpenCfmMt[MAXSBUI] =
{
#ifdef LCSBUISCT
   cmPkSctEndpOpenCfm,         /* 0 - loosely coupled */
#else
   PtUiSctEndpOpenCfm,         /* 0 - tightly coupled, portable */
#endif
#ifdef IT
   ItLiSctEndpOpenCfm,         /* 1 - tightly coupled, M3UA */
#else
   PtUiSctEndpOpenCfm,         /* 1 - tightly coupled, portable */
#endif
#ifdef ID
   IdLiSctEndpOpenCfm,         /* 2 - tightly coupled, IUA */
#else
   PtUiSctEndpOpenCfm,         /* 2 - tightly coupled, portable */
#endif
#ifdef SU
   SuLiSctEndpOpenCfm,         /* 3 - tightly coupled, SUA */
#else
   PtUiSctEndpOpenCfm,         /* 3 - tightly coupled, portable */
#endif
#ifdef MW
   MwLiSctEndpOpenCfm,         /* 4 - tightly coupled, M2UA */
#else
   PtUiSctEndpOpenCfm,         /* 4 - tightly coupled, portable */
#endif
/* sb048.102: Changes to incorporate GCP */
#ifdef SCTP_MG     /*chendh modify*/
   MgLiSctEndpOpenCfm,         /* 5 - tightly coupled, GCP */
#else
   PtUiSctEndpOpenCfm,         /* 5 - tightly coupled, portable */
#endif
#ifdef DM
   DmLiSctEndpOpenCfm,         /* 6 - tightly coupled, DM */
#else
   PtUiSctEndpOpenCfm,         /* 6 - tightly coupled, portable */
#endif
/* sb052.102: NBAP (ENTIB), M1UA (ENTMZ) added as new SCTP user. */
#ifdef IB 
   IbLiSctEndpOpenCfm,         /* 7 - tightly coupled, GCP */
#else
   PtUiSctEndpOpenCfm,         /* 7 - tightly coupled, portable */
#endif
#ifdef MZ 
   MzLiSctEndpOpenCfm,         /* 8 - tightly coupled, GCP */
#else
   PtUiSctEndpOpenCfm,         /* 8 - tightly coupled, portable */
#endif
/* sb065.102: SIP added as new SCTP user */
#ifdef SCTP_SO     /*chendh modify*/ 
   SoLiSctEndpOpenCfm,         /* 8 - tightly coupled, SIP */
#else
   PtUiSctEndpOpenCfm,         /* 8 - tightly coupled, portable */
#endif
};

PRIVATE SctEndpCloseCfm SbUiSctEndpCloseCfmMt[MAXSBUI] =
{
#ifdef LCSBUISCT
   cmPkSctEndpCloseCfm,         /* 0 - loosely coupled */
#else
   PtUiSctEndpCloseCfm,         /* 0 - tightly coupled, portable */
#endif
#ifdef IT
   ItLiSctEndpCloseCfm,         /* 1 - tightly coupled, M3UA */
#else
   PtUiSctEndpCloseCfm,         /* 1 - tightly coupled, portable */
#endif
#ifdef ID
   IdLiSctEndpCloseCfm,         /* 2 - tightly coupled, IUA */
#else
   PtUiSctEndpCloseCfm,         /* 2 - tightly coupled, portable */
#endif
#ifdef SU
   SuLiSctEndpCloseCfm,         /* 3 - tightly coupled, SUA */
#else
   PtUiSctEndpCloseCfm,         /* 3 - tightly coupled, portable */
#endif
#ifdef MW
   MwLiSctEndpCloseCfm,         /* 4 - tightly coupled, M2UA */
#else
   PtUiSctEndpCloseCfm,         /* 4 - tightly coupled, portable */
#endif
/* sb048.102: Changes to incorporate GCP */
#ifdef SCTP_MG     /*chendh modify*/
   MgLiSctEndpCloseCfm,         /* 5 - tightly coupled, GCP */
#else
   PtUiSctEndpCloseCfm,         /* 5 - tightly coupled, portable */
#endif
#ifdef DM
   DmLiSctEndpCloseCfm,         /* 6 - tightly coupled, DM */
#else
   PtUiSctEndpCloseCfm,         /* 6 - tightly coupled, portable */
#endif
/* sb052.102: NBAP (ENTIB), M1UA (ENTMZ) added as new SCTP user. */
#ifdef IB 
   IbLiSctEndpCloseCfm,         /* 7 - tightly coupled, GCP */
#else
   PtUiSctEndpCloseCfm,         /* 7 - tightly coupled, portable */
#endif
#ifdef MZ 
   MzLiSctEndpCloseCfm,         /* 8 - tightly coupled, GCP */
#else
   PtUiSctEndpCloseCfm,         /* 8 - tightly coupled, portable */
#endif
/* sb065.102: SIP added as new SCTP user */
#ifdef SCTP_SO     /*chendh modify*/ 
   SoLiSctEndpCloseCfm,         /* 8 - tightly coupled, SIP */
#else
   PtUiSctEndpCloseCfm,         /* 8 - tightly coupled, portable */
#endif
};

PRIVATE SctAssocInd SbUiSctAssocIndMt[MAXSBUI] =
{
#ifdef LCSBUISCT
   cmPkSctAssocInd,         /* 0 - loosely coupled */
#else
   PtUiSctAssocInd,         /* 0 - tightly coupled, portable */
#endif
#ifdef IT
   ItLiSctAssocInd,         /* 1 - tightly coupled, M3UA */
#else
   PtUiSctAssocInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef ID
   IdLiSctAssocInd,         /* 2 - tightly coupled, IUA */
#else
   PtUiSctAssocInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef SU
   SuLiSctAssocInd,         /* 3 - tightly coupled, SUA */
#else
   PtUiSctAssocInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef MW
   MwLiSctAssocInd,         /* 4 - tightly coupled, M2UA */
#else
   PtUiSctAssocInd,         /* 4 - tightly coupled, portable */
#endif
/* sb048.102: Changes to incorporate GCP */
#ifdef SCTP_MG     /*chendh modify*/
   MgLiSctAssocInd,         /* 5 - tightly coupled, GCP */
#else
   PtUiSctAssocInd,         /* 5 - tightly coupled, portable */
#endif
#ifdef DM
   DmLiSctAssocInd,         /* 6 - tightly coupled, DM */
#else
   PtUiSctAssocInd,         /* 6 - tightly coupled, portable */
#endif
/* sb052.102: NBAP (ENTIB), M1UA (ENTMZ) added as new SCTP user. */
#ifdef IB
   IbLiSctAssocInd,         /* 7 - tightly coupled, GCP */
#else
   PtUiSctAssocInd,         /* 7 - tightly coupled, portable */
#endif
#ifdef MZ
   MzLiSctAssocInd,         /* 8 - tightly coupled, GCP */
#else
   PtUiSctAssocInd,         /* 8 - tightly coupled, portable */
#endif
/* sb065.102: SIP added as new SCTP user */
#ifdef SCTP_SO     /*chendh modify*/
   SoLiSctAssocInd,         /* 8 - tightly coupled, SIP */
#else
   PtUiSctAssocInd,         /* 8 - tightly coupled, portable */
#endif
};

PRIVATE SctAssocCfm SbUiSctAssocCfmMt[MAXSBUI] =
{
#ifdef LCSBUISCT
   cmPkSctAssocCfm,         /* 0 - loosely coupled */
#else
   PtUiSctAssocCfm,         /* 0 - tightly coupled, portable */
#endif
#ifdef IT
   ItLiSctAssocCfm,         /* 1 - tightly coupled, M3UA */
#else
   PtUiSctAssocCfm,         /* 1 - tightly coupled, portable */
#endif
#ifdef ID
   IdLiSctAssocCfm,         /* 2 - tightly coupled, IUA */
#else
   PtUiSctAssocCfm,         /* 2 - tightly coupled, portable */
#endif
#ifdef SU
   SuLiSctAssocCfm,         /* 3 - tightly coupled, SUA */
#else
   PtUiSctAssocCfm,         /* 3 - tightly coupled, portable */
#endif
#ifdef MW
   MwLiSctAssocCfm,         /* 4 - tightly coupled, M2UA */
#else
   PtUiSctAssocCfm,         /* 4 - tightly coupled, portable */
#endif
/* sb048.102: Changes to incorporate GCP */
#ifdef SCTP_MG     /*chendh modify*/
   MgLiSctAssocCfm,         /* 5 - tightly coupled, GCP */
#else
   PtUiSctAssocCfm,         /* 5 - tightly coupled, portable */
#endif
#ifdef DM
   DmLiSctAssocCfm,         /* 6 - tightly coupled, DM */
#else
   PtUiSctAssocCfm,         /* 6 - tightly coupled, portable */
#endif
/* sb052.102: NBAP (ENTIB), M1UA (ENTMZ) added as new SCTP user. */
#ifdef IB
   IbLiSctAssocCfm,         /* 7 - tightly coupled, GCP */
#else
   PtUiSctAssocCfm,         /* 7 - tightly coupled, portable */
#endif
#ifdef MZ
   MzLiSctAssocCfm,         /* 8 - tightly coupled, GCP */
#else
   PtUiSctAssocCfm,         /* 8 - tightly coupled, portable */
#endif
/* sb065.102: SIP added as new SCTP user */
#ifdef SCTP_SO     /*chendh modify*/
   SoLiSctAssocCfm,         /* 8 - tightly coupled, SIP */
#else
   PtUiSctAssocCfm,         /* 8 - tightly coupled, portable */
#endif
};

PRIVATE SctTermInd SbUiSctTermIndMt[MAXSBUI] =
{
#ifdef LCSBUISCT
   cmPkSctTermInd,         /* 0 - loosely coupled */
#else
   PtUiSctTermInd,         /* 0 - tightly coupled, portable */
#endif
#ifdef IT
   ItLiSctTermInd,         /* 1 - tightly coupled, M3UA */
#else
   PtUiSctTermInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef ID
   IdLiSctTermInd,         /* 2 - tightly coupled, IUA */
#else
   PtUiSctTermInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef SU
   SuLiSctTermInd,         /* 3 - tightly coupled, SUA */
#else
   PtUiSctTermInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef MW
   MwLiSctTermInd,         /* 4 - tightly coupled, M2UA */
#else
   PtUiSctTermInd,         /* 4 - tightly coupled, portable */
#endif
/* sb048.102: Changes to incorporate GCP */
#ifdef SCTP_MG     /*chendh modify*/
   MgLiSctTermInd,         /* 5 - tightly coupled, GCP */
#else
   PtUiSctTermInd,         /* 5 - tightly coupled, portable */
#endif
#ifdef DM
   DmLiSctTermInd,         /* 6 - tightly coupled, DM */
#else
   PtUiSctTermInd,         /* 6 - tightly coupled, portable */
#endif
/* sb052.102: NBAP (ENTIB), M1UA (ENTMZ) added as new SCTP user. */
#ifdef IB
   IbLiSctTermInd,         /* 7 - tightly coupled, GCP */
#else
   PtUiSctTermInd,         /* 7 - tightly coupled, portable */
#endif
#ifdef MZ
   MzLiSctTermInd,         /* 8 - tightly coupled, GCP */
#else
   PtUiSctTermInd,         /* 8 - tightly coupled, portable */
#endif
/* sb065.102: SIP added as new SCTP user */
#ifdef SCTP_SO     /*chendh modify*/
   SoLiSctTermInd,         /* 8 - tightly coupled, SIP */
#else
   PtUiSctTermInd,         /* 8 - tightly coupled, portable */
#endif
};

PRIVATE SctTermCfm SbUiSctTermCfmMt[MAXSBUI] =
{
#ifdef LCSBUISCT
   cmPkSctTermCfm,         /* 0 - loosely coupled */
#else
   PtUiSctTermCfm,         /* 0 - tightly coupled, portable */
#endif
#ifdef IT
   ItLiSctTermCfm,         /* 1 - tightly coupled, M3UA */
#else
   PtUiSctTermCfm,         /* 1 - tightly coupled, portable */
#endif
#ifdef ID
   IdLiSctTermCfm,         /* 2 - tightly coupled, IUA */
#else
   PtUiSctTermCfm,         /* 2 - tightly coupled, portable */
#endif
#ifdef SU
   SuLiSctTermCfm,         /* 3 - tightly coupled, SUA */
#else
   PtUiSctTermCfm,         /* 3 - tightly coupled, portable */
#endif
#ifdef MW
   MwLiSctTermCfm,         /* 4 - tightly coupled, M2UA */
#else
   PtUiSctTermCfm,         /* 4 - tightly coupled, portable */
#endif
/* sb048.102: Changes to incorporate GCP */
#ifdef SCTP_MG     /*chendh modify*/
   MgLiSctTermCfm,         /* 5 - tightly coupled, GCP */
#else
   PtUiSctTermCfm,         /* 5 - tightly coupled, portable */
#endif
#ifdef DM
   DmLiSctTermCfm,         /* 6 - tightly coupled, DM */
#else
   PtUiSctTermCfm,         /* 6 - tightly coupled, portable */
#endif
/* sb052.102: NBAP (ENTIB), M1UA (ENTMZ) added as new SCTP user. */
#ifdef IB
   IbLiSctTermCfm,         /* 7 - tightly coupled, GCP */
#else
   PtUiSctTermCfm,         /* 7 - tightly coupled, portable */
#endif
#ifdef MZ
   MzLiSctTermCfm,         /* 8 - tightly coupled, GCP */
#else
   PtUiSctTermCfm,         /* 8 - tightly coupled, portable */
#endif
/* sb065.102: SIP added as new SCTP user */
#ifdef SCTP_SO     /*chendh modify*/
   SoLiSctTermCfm,         /* 8 - tightly coupled, SIP */
#else
   PtUiSctTermCfm,         /* 8 - tightly coupled, portable */
#endif
};

PRIVATE SctSetPriCfm SbUiSctSetPriCfmMt[MAXSBUI] =
{
#ifdef LCSBUISCT
   cmPkSctSetPriCfm,         /* 0 - loosely coupled */
#else
   PtUiSctSetPriCfm,         /* 0 - tightly coupled, portable */
#endif
#ifdef IT
   ItLiSctSetPriCfm,         /* 1 - tightly coupled, M3UA */
#else
   PtUiSctSetPriCfm,         /* 1 - tightly coupled, portable */
#endif
#ifdef ID
   IdLiSctSetPriCfm,         /* 2 - tightly coupled, IUA */
#else
   PtUiSctSetPriCfm,         /* 2 - tightly coupled, portable */
#endif
#ifdef SU
   SuLiSctSetPriCfm,         /* 3 - tightly coupled, SUA */
#else
   PtUiSctSetPriCfm,         /* 3 - tightly coupled, portable */
#endif
#ifdef MW
   MwLiSctSetPriCfm,         /* 4 - tightly coupled, M2UA */
#else
   PtUiSctSetPriCfm,         /* 4 - tightly coupled, portable */
#endif
/* sb048.102: Changes to incorporate GCP */
#ifdef SCTP_MG     /*chendh modify*/
   MgLiSctSetPriCfm,         /* 5 - tightly coupled, M2UA */
#else
   PtUiSctSetPriCfm,         /* 5 - tightly coupled, portable */
#endif
#ifdef DM
   DmLiSctSetPriCfm,         /* 6 - tightly coupled, DM */
#else
   PtUiSctSetPriCfm,         /* 6 - tightly coupled, portable */
#endif
/* sb052.102: NBAP (ENTIB), M1UA (ENTMZ) added as new SCTP user. */
#ifdef IB
   IbLiSctSetPriCfm,         /* 7 - tightly coupled, M2UA */
#else
   PtUiSctSetPriCfm,         /* 7 - tightly coupled, portable */
#endif
#ifdef MZ
   MzLiSctSetPriCfm,         /* 8 - tightly coupled, M2UA */
#else
   PtUiSctSetPriCfm,         /* 8 - tightly coupled, portable */
#endif
/* sb065.102: SIP added as new SCTP user */
#ifdef SCTP_SO     /*chendh modify*/
   SoLiSctSetPriCfm,         /* 8 - tightly coupled, SIP */
#else
   PtUiSctSetPriCfm,         /* 8 - tightly coupled, portable */
#endif
};

PRIVATE SctHBeatCfm SbUiSctHBeatCfmMt[MAXSBUI] =
{
#ifdef LCSBUISCT
   cmPkSctHBeatCfm,         /* 0 - loosely coupled */
#else
   PtUiSctHBeatCfm,         /* 0 - tightly coupled, portable */
#endif
#ifdef IT
   ItLiSctHBeatCfm,         /* 1 - tightly coupled, M3UA */
#else
   PtUiSctHBeatCfm,         /* 1 - tightly coupled, portable */
#endif
#ifdef ID
   IdLiSctHBeatCfm,         /* 2 - tightly coupled, IUA */
#else
   PtUiSctHBeatCfm,         /* 2 - tightly coupled, portable */
#endif
#ifdef SU
   SuLiSctHBeatCfm,         /* 3 - tightly coupled, SUA */
#else
   PtUiSctHBeatCfm,         /* 3 - tightly coupled, portable */
#endif
#ifdef MW
   MwLiSctHBeatCfm,         /* 4 - tightly coupled, M2UA */
#else
   PtUiSctHBeatCfm,         /* 4 - tightly coupled, portable */
#endif
/* sb048.102: Changes to incorporate GCP */
#ifdef SCTP_MG     /*chendh modify*/
   MgLiSctHBeatCfm,         /* 5 - tightly coupled, GCP */
#else
   PtUiSctHBeatCfm,         /* 5 - tightly coupled, portable */
#endif
#ifdef DM
   DmLiSctHBeatCfm,         /* 6 - tightly coupled, DM */
#else
   PtUiSctHBeatCfm,         /* 6 - tightly coupled, portable */
#endif
/* sb052.102: NBAP (ENTIB), M1UA (ENTMZ) added as new SCTP user. */
#ifdef IB
   IbLiSctHBeatCfm,         /* 7 - tightly coupled, GCP */
#else
   PtUiSctHBeatCfm,         /* 7 - tightly coupled, portable */
#endif
#ifdef MZ
   MzLiSctHBeatCfm,         /* 8 - tightly coupled, GCP */
#else
   PtUiSctHBeatCfm,         /* 8 - tightly coupled, portable */
#endif
/* sb065.102: SIP added as new SCTP user */
#ifdef SCTP_SO     /*chendh modify*/
   SoLiSctHBeatCfm,         /* 8 - tightly coupled, SIP */
#else
   PtUiSctHBeatCfm,         /* 8 - tightly coupled, portable */
#endif
};

PRIVATE SctDatInd SbUiSctDatIndMt[MAXSBUI] =
{
#ifdef LCSBUISCT
   cmPkSctDatInd,         /* 0 - loosely coupled */
#else
   PtUiSctDatInd,         /* 0 - tightly coupled, portable */
#endif
#ifdef IT
   ItLiSctDatInd,         /* 1 - tightly coupled, M3UA */
#else
   PtUiSctDatInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef ID 
   IdLiSctDatInd,         /* 2 - tightly coupled, IUA */
#else
   PtUiSctDatInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef SU
   SuLiSctDatInd,         /* 3 - tightly coupled, SUA */
#else
   PtUiSctDatInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef MW
   MwLiSctDatInd,         /* 4 - tightly coupled, M2UA */
#else
   PtUiSctDatInd,         /* 4 - tightly coupled, portable */
#endif
/* sb048.102: Changes to incorporate GCP */
#ifdef SCTP_MG     /*chendh modify*/
   MgLiSctDatInd,         /* 5 - tightly coupled, GCP */
#else
   PtUiSctDatInd,         /* 5 - tightly coupled, portable */
#endif
#ifdef DM
   DmLiSctDatInd,         /* 6 - tightly coupled, DM */
#else
   PtUiSctDatInd,         /* 6 - tightly coupled, portable */
#endif
/* sb052.102: NBAP (ENTIB), M1UA (ENTMZ) added as new SCTP user. */
#ifdef IB
   IbLiSctDatInd,         /* 7 - tightly coupled, GCP */
#else
   PtUiSctDatInd,         /* 7 - tightly coupled, portable */
#endif
#ifdef MZ
   MzLiSctDatInd,         /* 8 - tightly coupled, GCP */
#else
   PtUiSctDatInd,         /* 8 - tightly coupled, portable */
#endif
/* sb065.102: SIP added as new SCTP user */
#ifdef SCTP_SO     /*chendh modify*/
   SoLiSctDatInd,         /* 8 - tightly coupled, SIP */
#else
   PtUiSctDatInd,         /* 8 - tightly coupled, portable */
#endif
};

PRIVATE SctStaCfm SbUiSctStaCfmMt[MAXSBUI] =
{
#ifdef LCSBUISCT
   cmPkSctStaCfm,         /* 0 - loosely coupled */
#else
   PtUiSctStaCfm,         /* 0 - tightly coupled, portable */
#endif
#ifdef IT
   ItLiSctStaCfm,         /* 1 - tightly coupled, M3UA */
#else
   PtUiSctStaCfm,         /* 1 - tightly coupled, portable */
#endif
#ifdef ID
   IdLiSctStaCfm,         /* 2 - tightly coupled, IUA */
#else
   PtUiSctStaCfm,         /* 2 - tightly coupled, portable */
#endif
#ifdef SU
   SuLiSctStaCfm,         /* 3 - tightly coupled, SUA */
#else
   PtUiSctStaCfm,         /* 3 - tightly coupled, portable */
#endif
#ifdef MW
   MwLiSctStaCfm,         /* 4 - tightly coupled, M2UA */
#else
   PtUiSctStaCfm,         /* 4 - tightly coupled, portable */
#endif
/* sb048.102: Changes to incorporate GCP */
#ifdef SCTP_MG     /*chendh modify*/
   MgLiSctStaCfm,         /* 5 - tightly coupled, GCP  */
#else
   PtUiSctStaCfm,         /* 5 - tightly coupled, portable */
#endif
#ifdef DM
   DmLiSctStaCfm,         /* 6 - tightly coupled, DM */
#else
   PtUiSctStaCfm,         /* 6 - tightly coupled, portable */
#endif
/* sb052.102: NBAP (ENTIB), M1UA (ENTMZ) added as new SCTP user. */
#ifdef IB
   IbLiSctStaCfm,         /* 7 - tightly coupled, GCP  */
#else
   PtUiSctStaCfm,         /* 7 - tightly coupled, portable */
#endif
#ifdef MZ
   MzLiSctStaCfm,         /* 8 - tightly coupled, GCP  */
#else
   PtUiSctStaCfm,         /* 8 - tightly coupled, portable */
#endif
/* sb065.102: SIP added as new SCTP user */
#ifdef SCTP_SO     /*chendh modify*/
   SoLiSctStaCfm,         /* 8 - tightly coupled, SIP  */
#else
   PtUiSctStaCfm,         /* 8 - tightly coupled, portable */
#endif
};

PRIVATE SctStaInd SbUiSctStaIndMt[MAXSBUI] =
{
#ifdef LCSBUISCT
   cmPkSctStaInd,         /* 0 - loosely coupled */
#else
   PtUiSctStaInd,         /* 0 - tightly coupled, portable */
#endif
#ifdef IT
   ItLiSctStaInd,         /* 1 - tightly coupled, M3UA */
#else
   PtUiSctStaInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef ID
   IdLiSctStaInd,         /* 2 - tightly coupled, IUA */
#else
   PtUiSctStaInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef SU
   SuLiSctStaInd,         /* 3 - tightly coupled, SUA */
#else
   PtUiSctStaInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef MW
   MwLiSctStaInd,         /* 4 - tightly coupled, M2UA */
#else
   PtUiSctStaInd,         /* 4 - tightly coupled, portable */
#endif
/* sb048.102: Changes to incorporate GCP */
#ifdef SCTP_MG     /*chendh modify*/
   MgLiSctStaInd,         /* 5 - tightly coupled, GCP */
#else
   PtUiSctStaInd,         /* 5 - tightly coupled, portable */
#endif
#ifdef DM
   DmLiSctStaInd,         /* 6 - tightly coupled, DM */
#else
   PtUiSctStaInd,         /* 6 - tightly coupled, portable */
#endif
/* sb052.102: NBAP (ENTIB), M1UA (ENTMZ) added as new SCTP user. */
#ifdef IB
   IbLiSctStaInd,         /* 7 - tightly coupled, GCP */
#else
   PtUiSctStaInd,         /* 7 - tightly coupled, portable */
#endif
#ifdef MZ
   MzLiSctStaInd,         /* 8 - tightly coupled, GCP */
#else
   PtUiSctStaInd,         /* 8 - tightly coupled, portable */
#endif
/* sb065.102: SIP added as new SCTP user */
#ifdef SCTP_SO     /*chendh modify*/
   SoLiSctStaInd,         /* 8 - tightly coupled, SIP */
#else
   PtUiSctStaInd,         /* 8 - tightly coupled, portable */
#endif
};

PRIVATE SctFlcInd SbUiSctFlcIndMt[MAXSBUI] =
{
#ifdef LCSBUISCT
   cmPkSctFlcInd,         /* 0 - loosely coupled */
#else
   PtUiSctFlcInd,         /* 0 - tightly coupled, portable */
#endif
#ifdef IT
   ItLiSctFlcInd,         /* 1 - tightly coupled, M3UA */
#else
   PtUiSctFlcInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef ID
   IdLiSctFlcInd,         /* 2 - tightly coupled, IUA */
#else
   PtUiSctFlcInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef SU 
   SuLiSctFlcInd,         /* 3 - tightly coupled, SUA */
#else
   PtUiSctFlcInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef MW
   MwLiSctFlcInd,         /* 4 - tightly coupled, M2UA */
#else
   PtUiSctFlcInd,         /* 4 - tightly coupled, portable */
#endif
/* sb048.102: Changes to incorporate GCP */
#ifdef SCTP_MG     /*chendh modify*/ 
   MgLiSctFlcInd,         /* 5 - tightly coupled, GCP */
#else
   PtUiSctFlcInd,         /* 5 - tightly coupled, portable */
#endif
#ifdef DM
   DmLiSctFlcInd,         /* 6 - tightly coupled, DM */
#else
   PtUiSctFlcInd,         /* 6 - tightly coupled, portable */
#endif
/* sb052.102: NBAP (ENTIB), M1UA (ENTMZ) added as new SCTP user. */
#ifdef IB
   IbLiSctFlcInd,         /* 7 - tightly coupled, GCP */
#else
   PtUiSctFlcInd,         /* 7 - tightly coupled, portable */
#endif
#ifdef MZ
   MzLiSctFlcInd,         /* 8 - tightly coupled, GCP */
#else
   PtUiSctFlcInd,         /* 8 - tightly coupled, portable */
#endif
/* sb065.102: SIP added as new SCTP user */
#ifdef SCTP_SO     /*chendh modify*/
   SoLiSctFlcInd,         /* 8 - tightly coupled, SIP */
#else
   PtUiSctFlcInd,         /* 8 - tightly coupled, portable */
#endif
};

/*
 *  upper interface functions
 */




#ifdef ANSI
PUBLIC S16 SbUiSctBndCfm
(
Pst           *pst,
SuId           suId,
SctResult      result
)
#else
PUBLIC S16 SbUiSctBndCfm(pst, suId, result)
Pst           *pst;
SuId           suId;
SctResult      result;
#endif
{
   TRC3(SbUiSctBndCfm)

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctBndCfm(pst, suId(%d), result(%d))\n",
          suId, result));

   /* jump to specific primitive depending on configured selector */
   /* sb048.102: DFTHA M3UA Support */
   switch (pst->dstEnt)
   {
#ifdef DV
      case ENTIT:
         if (pst->route == RTE_PROTO)
         {
            (*SbUiSctBndCfmMt[pst->selector])(pst, suId, result);
         }
         else
         {
            DvUiSctBndCfm(pst, suId, result);
         }
         break;
#endif /* DV */
      default:
         (*SbUiSctBndCfmMt[pst->selector])(pst, suId, result);
         break;
   }

   RETVALUE(ROK);
}


#ifdef ANSI
PUBLIC S16 SbUiSctEndpOpenCfm
(
Pst           *pst,
SuId           suId,
UConnId        suEndpId,
UConnId        spEndpId,
SctResult      result,
SctCause       cause
)
#else
PUBLIC S16 SbUiSctEndpOpenCfm(pst, suId, suEndpId, spEndpId, result, cause)
Pst           *pst;
SuId           suId;
UConnId        suEndpId;
UConnId        spEndpId;
SctResult      result;
SctCause       cause;
#endif
{
   TRC3(SbUiSctEndpOpenCfm)

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctEndpOpenCfm(pst, suId(%d), suEndpId(%ld), spEndpId(%ld), result(%d), cause(%d))\n",
          suId, suEndpId, spEndpId, result, cause));

   /* jump to specific primitive depending on configured selector */
   /* sb048.102: DFTHA M3UA Support */
   switch (pst->dstEnt)
   {
#ifdef DV
      case ENTIT:
         if (pst->route == RTE_PROTO)
         {
            (*SbUiSctEndpOpenCfmMt[pst->selector])(pst, suId, suEndpId, spEndpId, 
                result, cause);
         }
         else
         {
            DvUiSctEndpOpenCfm(pst, suId, suEndpId, spEndpId, result, cause);
         }
         break;
#endif /* DV */
      default:
         (*SbUiSctEndpOpenCfmMt[pst->selector])(pst, suId, suEndpId, spEndpId, 
             result, cause);
         break;
   }

   RETVALUE(ROK);
}


#ifdef ANSI
PUBLIC S16 SbUiSctEndpCloseCfm
(
Pst           *pst,
SuId           suId,
UConnId        suEndpId,
SctResult      result,
SctCause       cause
)
#else
PUBLIC S16 SbUiSctEndpCloseCfm(pst, suId, suEndpId, result, cause)
Pst           *pst;
SuId           suId;
UConnId        suEndpId;
SctResult      result;
SctCause       cause;
#endif
{
   TRC3(SbUiSctEndpCloseCfm)

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctEndpCloseCfm(pst, suId(%d), suEndpId(%ld), result(%d), cause(%d))\n",
          suId, suEndpId, result, cause));

   /* jump to specific primitive depending on configured selector */
   /* sb048.102: DFTHA M3UA Support */
   switch (pst->dstEnt)
   {
#ifdef DV
      case ENTIT:
         if (pst->route == RTE_PROTO)
         {
            (*SbUiSctEndpCloseCfmMt[pst->selector])(pst, suId, suEndpId, result, 
              cause);
         }
         else
         {
            DvUiSctEndpCloseCfm(pst, suId, suEndpId, result, cause);
         }
         break;
#endif /* DV */
      default:
         (*SbUiSctEndpCloseCfmMt[pst->selector])(pst, suId, suEndpId, result, 
              cause);
         break;
   }

   RETVALUE(ROK);
}



#ifdef ANSI
PUBLIC S16 SbUiSctAssocInd
(
Pst               *pst,
SuId               suId,
UConnId            suEndpId,
SctAssocIndParams *assocParams,
Buffer            *vsInfo
)
#else
PUBLIC S16 SbUiSctAssocInd(pst, suId, suEndpId, assocParams, vsInfo)
Pst               *pst;
SuId               suId;
UConnId            suEndpId;
SctAssocIndParams *assocParams;
Buffer            *vsInfo;
#endif
{
   TRC3(SbUiSctAssocInd)

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctAssocInd(pst, assocParams)\n"));

   /* jump to specific primitive depending on configured selector */
   /* sb048.102: DFTHA M3UA Support */
   switch (pst->dstEnt)
   {
#ifdef DV
      case ENTIT:
         if (pst->route == RTE_PROTO)
         {
            (*SbUiSctAssocIndMt[pst->selector])(pst, suId, suEndpId, assocParams, 
                vsInfo);
         }
         else
         {
            DvUiSctAssocInd(pst, suId, suEndpId, assocParams, vsInfo);
         }
         break;
#endif /* DV */
      default:
         (*SbUiSctAssocIndMt[pst->selector])(pst, suId, suEndpId, assocParams, 
             vsInfo);
         break;
   }

   RETVALUE(ROK);
}



#ifdef ANSI
PUBLIC S16 SbUiSctAssocCfm
(
Pst           *pst,
SuId           suId,
UConnId        suAssocId,
UConnId        spAssocId,
SctNetAddrLst *dstNAddrLst,
SctPort        dstPort,
/* sb016.102 - Include in-stream parameter here */
#ifdef SCT2
SctStrmId      inStrms,
#endif /* SCT2 */
SctStrmId      outStrms,
Buffer        *vsInfo
)
#else
/* sb016.102 - Include in-stream parameter here */ 
#ifdef SCT2
PUBLIC S16 SbUiSctAssocCfm(pst, suId, suAssocId, spAssocId, dstNAddrLst, dstPort, inStrms, outStrms, vsInfo )
#else /* SCT2 */
PUBLIC S16 SbUiSctAssocCfm(pst, suId, suAssocId, spAssocId, dstNAddrLst, dstPort, outStrms,vsInfo )
#endif /* SCT2 */
Pst           *pst;
SuId           suId;
UConnId        suAssocId;
UConnId        spAssocId;
SctNetAddrLst *dstNAddrLst;
SctPort        dstPort;
/* sb016.102 - Include in-stream parameter here */
#ifdef SCT2
SctStrmId      inStrms;
#endif /* SCT2 */
SctStrmId      outStrms;
Buffer        *vsInfo;
#endif
{
   TRC3(SbUiSctAssocCfm)

/* sb016.102 - Include in-stream parameter here */
#ifdef SCT2

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctAssocCfm(pst, suId(%d), suAssocId(%ld), spAssocId(%ld), dstNAddrLst, dstPort(%d), inStrms(%d), outStrms(%d))\n",
          suId, suAssocId, spAssocId, dstPort, inStrms, outStrms));

   /* jump to specific primitive depending on configured selector */
   /* sb048.102: DFTHA M3UA Support */
   /* sb049.102: DFTHA M3UA Support */
   switch (pst->dstEnt)
   {
#ifdef DV
      case ENTIT:
         if (pst->route == RTE_PROTO)
         {
            (*SbUiSctAssocCfmMt[pst->selector])(pst, suId, suAssocId, spAssocId, 
              dstNAddrLst, dstPort, inStrms, outStrms, vsInfo);
         }
         else
         {
            DvUiSctAssocCfm(pst, suId, suAssocId, spAssocId, dstNAddrLst, 
               dstPort, inStrms, outStrms, vsInfo);
         }
         break;
#endif /* DV */
      default:
         (*SbUiSctAssocCfmMt[pst->selector])(pst, suId, suAssocId, spAssocId, 
              dstNAddrLst, dstPort, inStrms, outStrms, vsInfo);
         break;
   }

#else /* SCT2 */

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctAssocCfm(pst, suId(%d), suAssocId(%ld), spAssocId(%ld), dstNAddrLst, dstPort(%d), outStrms(%d))\n",
          suId, suAssocId, spAssocId, dstPort, outStrms));

   /* jump to specific primitive depending on configured selector */
   /* sb048.102: DFTHA M3UA Support */
   switch (pst->dstEnt)
   {
#ifdef DV
      case ENTIT:
         if (pst->route == RTE_PROTO)
         {
            (*SbUiSctAssocCfmMt[pst->selector])(pst, suId, suAssocId, spAssocId, 
              dstNAddrLst, dstPort, outStrms, vsInfo);
         }
         else
         {
            DvUiSctAssocCfm(pst, suId, suAssocId, spAssocId, dstNAddrLst, 
               dstPort, outStrms, vsInfo);
         }
         break;
#endif /* DV */
      default:
         (*SbUiSctAssocCfmMt[pst->selector])(pst, suId, suAssocId, spAssocId, 
              dstNAddrLst, dstPort, outStrms, vsInfo);
         break;
   }

#endif /* SCT2 */

   RETVALUE(ROK);
}




#ifdef ANSI
PUBLIC S16 SbUiSctTermInd
(
Pst           *pst,
SuId           suId,
UConnId        assocId,
U8             assocIdType,
SctStatus      status,
SctCause       cause,
SctRtrvInfo   *rtrvInfo
)
#else
PUBLIC S16 SbUiSctTermInd(pst, suId, assocId, assocIdType, status, cause, rtrvInfo)
Pst           *pst;
SuId           suId;
UConnId        assocId;
U8             assocIdType;
SctStatus      status;
SctCause       cause;
SctRtrvInfo   *rtrvInfo;
#endif
{
   TRC3(SbUiSctTermInd)

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctTermInd(pst, suId(%d), assocId(%ld), assocIdType(%d), status(%d), cause(%d), rtrvInfo)\n",
          suId, assocId, assocIdType, status, cause));

   /* jump to specific primitive depending on configured selector */
   /* sb048.102: DFTHA M3UA Support */
   switch (pst->dstEnt)
   {
#ifdef DV
      case ENTIT:
         if (pst->route == RTE_PROTO)
         {
            (*SbUiSctTermIndMt[pst->selector])(pst, suId, assocId, assocIdType, 
                status, cause, rtrvInfo);
         }
         else
         {
            DvUiSctTermInd(pst, suId, assocId, assocIdType, status, cause, 
               rtrvInfo);
         }
         break;
#endif /* DV */
      default:
         (*SbUiSctTermIndMt[pst->selector])(pst, suId, assocId, assocIdType, 
             status, cause, rtrvInfo);
         break;
   }

   RETVALUE(ROK);
}


#ifdef ANSI
PUBLIC S16 SbUiSctTermCfm
(
Pst           *pst,
SuId           suId,
UConnId        suAssocId,
SctResult      result,
SctCause       cause
)
#else
PUBLIC S16 SbUiSctTermCfm(pst, suId, suAssocId, result, cause)
Pst           *pst;
SuId           suId;
UConnId        suAssocId;
SctResult      result;
SctCause       cause;
#endif
{
   TRC3(SbUiSctTermCfm)

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctTermCfm(pst, suId(%d), suAssocId(%ld), result(%d), cause(%d))\n",
          suId, suAssocId, result, cause));

   /* jump to specific primitive depending on configured selector */
   /* sb048.102: DFTHA M3UA Support */
   switch (pst->dstEnt)
   {
#ifdef DV
      case ENTIT:
         if (pst->route == RTE_PROTO)
         {
            (*SbUiSctTermCfmMt[pst->selector])(pst, suId, suAssocId, result,
                cause);
         }
         else
         {
            DvUiSctTermCfm(pst, suId, suAssocId, result, cause);
         }
         break;
#endif /* DV */
      default:
         (*SbUiSctTermCfmMt[pst->selector])(pst, suId, suAssocId, result, cause);
         break;
   }

   RETVALUE(ROK);
}



#ifdef ANSI
PUBLIC S16 SbUiSctSetPriCfm
(
Pst           *pst,
SuId           suId,
UConnId        suAssocId,
SctResult      result,
SctCause       cause
)
#else
PUBLIC S16 SbUiSctSetPriCfm(pst, suId, suAssocId, result, cause)
Pst           *pst;
SuId           suId;
UConnId        suAssocId;
SctResult      result;
SctCause       cause;
#endif
{
   TRC3(SbUiSctSetPriCfm)

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctSetPriCfm(pst, suId(%d), suAssocId(%ld), result(%d), cause(%d))\n",
          suId, suAssocId, result, cause));

   /* jump to specific primitive depending on configured selector */
   /* sb048.102: DFTHA M3UA Support */
   switch (pst->dstEnt)
   {
#ifdef DV
      case ENTIT:
         if (pst->route == RTE_PROTO)
         {
            (*SbUiSctSetPriCfmMt[pst->selector])(pst, suId, suAssocId, result,
                cause);
         }
         else
         {
            SbUiSctSetPriCfm(pst, suId, suAssocId, result, cause);
         }
         break;
#endif /* DV */
      default:
         (*SbUiSctSetPriCfmMt[pst->selector])(pst, suId, suAssocId, result,
             cause);
         break;
   }

   RETVALUE(ROK);
}



#ifdef ANSI
PUBLIC S16 SbUiSctHBeatCfm
(
Pst           *pst,
SuId           suId,
UConnId        suAssocId,
CmNetAddr     *dstNAddr,
SctStatus      status,
SctResult      result,
SctCause       cause
)
#else
PUBLIC S16 SbUiSctHBeatCfm(pst, suId, suAssocId, dstNAddr, status, result, cause)
Pst           *pst;
SuId           suId;
UConnId        suAssocId;
CmNetAddr     *dstNAddr;
SctStatus      status;
SctResult      result;
SctCause       cause;
#endif
{
   TRC3(SbUiSctHBeatCfm)

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctHBeatCfm(pst, suId(%d), suAssocId(%ld), dstNAddr, status(%d), result(%d), cause(%d))\n",
          suId, suAssocId, status, result, cause));

   /* jump to specific primitive depending on configured selector */
   /* sb048.102: DFTHA M3UA Support */
   switch (pst->dstEnt)
   {
#ifdef DV
      case ENTIT:
         if (pst->route == RTE_PROTO)
         {
            (*SbUiSctHBeatCfmMt[pst->selector])(pst, suId, suAssocId, dstNAddr,
               status, result, cause);
         }
         else
         {
            DvUiSctHBeatCfm(pst, suId, suAssocId, dstNAddr, status, result,
               cause);
         }
         break;
#endif /* DV */
      default:
         (*SbUiSctHBeatCfmMt[pst->selector])(pst, suId, suAssocId, dstNAddr,
              status, result, cause);
         break;
   }

   RETVALUE(ROK);
}


#ifdef ANSI
PUBLIC S16 SbUiSctDatInd
(
Pst           *pst,
SuId           suId,
UConnId        suAssocId,
SctStrmId      strmId,
SctDatIndType *indType,
U32            protId,
Buffer        *mBuf
)
#else
PUBLIC S16 SbUiSctDatInd(pst, suId, suAssocId, strmId, indType, protId, mBuf)
Pst           *pst;
SuId           suId;
UConnId        suAssocId;
SctStrmId      strmId;
SctDatIndType *indType;
U32            protId;
Buffer        *mBuf;
#endif
{
   TRC3(SbUiSctDatInd)

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctDatInd(pst, suId(%d), suAssocId(%ld), strmId(%d), indType, protId(%ld), mBuf)\n",
          suId, suAssocId, strmId, protId));

   /* jump to specific primitive depending on configured selector */
   /* sb048.102: DFTHA M3UA Support */
   switch (pst->dstEnt)
   {
#ifdef DV
      case ENTIT:
         if (pst->route == RTE_PROTO)
         {
            (*SbUiSctDatIndMt[pst->selector])(pst, suId, suAssocId, strmId, 
                indType, protId, mBuf);
         }
         else
         {
            DvUiSctDatInd(pst, suId, suAssocId, strmId, indType, protId, mBuf);
         }
         break;
#endif /* DV */
      default:
         (*SbUiSctDatIndMt[pst->selector])(pst, suId, suAssocId, strmId, 
             indType, protId, mBuf);
         break;
   }

   RETVALUE(ROK);
}



#ifdef ANSI
PUBLIC S16 SbUiSctStaCfm
(
Pst           *pst,
SuId           suId,
UConnId        suAssocId,
CmNetAddr     *dstNAddr,
SctResult      result,
SctCause       cause,
SctStaInfo    *staInfo
)
#else
PUBLIC S16 SbUiSctStaCfm(pst, suId, suAssocId, dstNAddr, result, cause, staInfo)
Pst           *pst;
SuId           suId;
UConnId        suAssocId;
CmNetAddr     *dstNAddr;
SctResult      result;
SctCause       cause;
SctStaInfo    *staInfo;
#endif
{
   TRC3(SbUiSctStaCfm)

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctStaCfm(pst, suId(%d), suAssocId(%ld), dstNAddr, result(%d), cause(%d), staInfo)\n",
          suId, suAssocId, result, cause));

   /* jump to specific primitive depending on configured selector */
   /* sb048.102: DFTHA M3UA Support */
   switch (pst->dstEnt)
   {
#ifdef DV
      case ENTIT:
         if (pst->route == RTE_PROTO)
         {
            (*SbUiSctStaCfmMt[pst->selector])(pst, suId, suAssocId, dstNAddr, 
               result, cause, staInfo);
         }
         else
         {
            DvUiSctStaCfm(pst, suId, suAssocId, dstNAddr, result, cause, 
               staInfo);
         }
         break;
#endif /* DV */
      default:
         (*SbUiSctStaCfmMt[pst->selector])(pst, suId, suAssocId, dstNAddr, 
             result, cause, staInfo);
         break;
   }

   RETVALUE(ROK);
}



#ifdef ANSI
PUBLIC S16 SbUiSctStaInd
(
 Pst           *pst,       /* post structure */
 SuId          suId,       /* service user SAP identifier */
 UConnId       suAssocId,  /* service user assoc identifier */
 UConnId       spAssocId,  /* service provider assoc identifier */
 CmNetAddr     *dstNAddr,  /* destination network address */
 SctStatus     status,
 SctCause      cause,
 Buffer        *mBuf       /* message buffer */
)
#else
PUBLIC S16 SbUiSctStaInd (pst, suId, suAssocId, spAssocId, dstNAddr,
                           status, cause, mBuf)
Pst            *pst;       /* post structure */
SuId           suId;       /* service user SAP identifier */
UConnId        suAssocId;  /* service user assoc identifier */
UConnId        spAssocId;  /* service provider assoc identifier */
CmNetAddr      *dstNAddr;  /* destination network address */
SctStatus      status;
SctCause       cause;
Buffer         *mBuf;       /* message buffer */
#endif
{
   TRC3(SbUiSctStaInd)

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctStaInd(pst, suId(%d), suAssocId(%ld), spAssocId(%ld), dstNAddr, status(%d), cause(%d), mBuf)\n",
          suId, suAssocId, spAssocId, status, cause));

   /* jump to specific primitive depending on configured selector */
   /* sb048.102: DFTHA M3UA Support */
   switch (pst->dstEnt)
   {
#ifdef DV
      case ENTIT:
         if (pst->route == RTE_PROTO)
         {
            (*SbUiSctStaIndMt[pst->selector])(pst, suId, suAssocId, spAssocId, 
                dstNAddr, status, cause, mBuf);
         }
         else
         {
            DvUiSctStaInd (pst, suId, suAssocId, spAssocId, dstNAddr,
                           status, cause, mBuf);
         }
         break;
#endif /* DV */
      default:
         (*SbUiSctStaIndMt[pst->selector])(pst, suId, suAssocId, spAssocId, 
             dstNAddr, status, cause, mBuf);
         break;
   }

   RETVALUE(ROK);
}



#ifdef ANSI
PUBLIC S16 SbUiSctFlcInd
(
Pst           *pst,
SuId           suId,
UConnId        suAssocId,
Reason         reason
)
#else
PUBLIC S16 SbUiSctFlcInd(pst, suId, suAssocId, reason)
Pst           *pst;
SuId           suId;
UConnId        suAssocId;
Reason         reason;
#endif
{
   TRC3(SbUiSctFlcInd)

   SBDBGP(DBGMASK_UI, (sbGlobalCb.sbInit.prntBuf,
          "SbUiSctFlcInd(pst, suId(%d), suAssocId(%ld), reason(%d))\n",
          suId, suAssocId, reason));

   /* jump to specific primitive depending on configured selector */
   /* sb048.102: DFTHA M3UA Support */
   switch (pst->dstEnt)
   {
#ifdef DV
      case ENTIT:
         if (pst->route == RTE_PROTO)
         {
            (*SbUiSctFlcIndMt[pst->selector])(pst, suId, suAssocId, reason);
         }
         else
         {
            DvUiSctFlcInd(pst, suId, suAssocId, reason);
         }
         break;
#endif /* DV */
      default:
         (*SbUiSctFlcIndMt[pst->selector])(pst, suId, suAssocId, reason);
         break;
   }

   RETVALUE(ROK);
}


/*
*     upper interface portable functions
*/

#ifdef PTSBUISCT


#ifdef ANSI
PUBLIC S16 PtUiSctBndCfm
(
Pst           *pst,
SuId           suId,
SctResult      result
)
#else
PUBLIC S16 PtUiSctBndCfm(pst, suId, result)
Pst           *pst;
SuId           suId;
SctResult      result;
#endif
{
   TRC3(PtUiSctBndCfm)

#if (ERRCLASS & ERRCLS_DEBUG)
   SBLOGERROR(ERRCLS_DEBUG, ESB323, (ErrVal)ERRZERO,
              "PtUiSctBndCfm: Failed");
#endif /* ERRCLASS */

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(result);

   RETVALUE(ROK);
}


#ifdef ANSI
PUBLIC S16 PtUiSctEndpOpenCfm
(
Pst           *pst,
SuId           suId,
UConnId        suEndpId,
UConnId        spEndpId,
SctResult      result,
SctCause       cause
)
#else
PUBLIC S16 PtUiSctEndpOpenCfm(pst, suId, suEndpId, spEndpId, result, cause)
Pst           *pst;
SuId           suId;
UConnId        suEndpId;
UConnId        spEndpId;
SctResult      result;
SctCause       cause;
#endif
{
   TRC3(PtUiSctEndpOpenCfm)

#if (ERRCLASS & ERRCLS_DEBUG)
   SBLOGERROR(ERRCLS_DEBUG, ESB324, (ErrVal)ERRZERO,
              "PtUiSctEndpOpenCfm: Failed");
#endif /* ERRCLASS */

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suEndpId);
   UNUSED(spEndpId);
   UNUSED(result);
   UNUSED(cause);

   RETVALUE(ROK);
}


#ifdef ANSI
PUBLIC S16 PtUiSctEndpCloseCfm
(
Pst           *pst,
SuId           suId,
UConnId        suEndpId,
SctResult      result,
SctCause       cause
)
#else
PUBLIC S16 PtUiSctEndpCloseCfm(pst, suId, suEndpId, result, cause)
Pst           *pst;
SuId           suId;
UConnId        suEndpId;
SctResult      result;
SctCause       cause;
#endif
{
   TRC3(PtUiSctEndpCloseCfm)

#if (ERRCLASS & ERRCLS_DEBUG)
   SBLOGERROR(ERRCLS_DEBUG, ESB325, (ErrVal)ERRZERO,
              "PtUiSctEndpCloseCfm: Failed");
#endif /* ERRCLASS */

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suEndpId);
   UNUSED(result);
   UNUSED(cause);

   RETVALUE(ROK);
}



#ifdef ANSI
PUBLIC S16 PtUiSctAssocInd
(
Pst               *pst,
SuId               suId,
UConnId            suEndpId,
SctAssocIndParams *assocParams,
Buffer            *vsInfo
)
#else
PUBLIC S16 PtUiSctAssocInd(pst, suId, suEndpId, assocParams, vsInfo)
Pst               *pst;
SuId               suId;
UConnId            suEndpId;
SctAssocIndParams *assocParams;
Buffer            *vsInfo;
#endif
{
   TRC3(PtUiSctAssocInd)

#if (ERRCLASS & ERRCLS_DEBUG)
   SBLOGERROR(ERRCLS_DEBUG, ESB326, (ErrVal)ERRZERO,
              "PtUiSctAssocInd: Failed");
#endif /* ERRCLASS */

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suEndpId);
   UNUSED(assocParams);
   UNUSED(vsInfo);

   RETVALUE(ROK);
}



#ifdef ANSI
PUBLIC S16 PtUiSctAssocCfm
(
Pst           *pst,
SuId           suId,
UConnId        suAssocId,
UConnId        spAssocId,
SctNetAddrLst *dstNAddrLst,
SctPort        dstPort,
/* sb016.102 - Include in-stream parameter here */
#ifdef SCT2
SctStrmId      inStrms,
#endif /* SCT2 */
SctStrmId      outStrms,
Buffer        *vsInfo
)
#else
/* sb016.102 - Include in-stream parameter here */
#ifdef SCT2
PUBLIC S16 PtUiSctAssocCfm(pst, suId, suAssocId, spAssocId, dstNAddrLst,
                           dstPort, inStrms, outStrms, vsInfo)
#else /* SCT2 */
PUBLIC S16 PtUiSctAssocCfm(pst, suId, suAssocId, spAssocId, dstNAddrLst,
                           dstPort, outStrms, vsInfo)
#endif /* SCT2 */
Pst           *pst;
SuId           suId;
UConnId        suAssocId;
UConnId        spAssocId;
SctNetAddrLst *dstNAddrLst;
SctPort        dstPort;
/* sb016.102 - Include in-stream parameter here */
#ifdef SCT2
SctStrmId      inStrms;
#endif /* SCT2 */
SctStrmId      outStrms;
Buffer        *vsInfo;
#endif
{
   TRC3(PtUiSctAssocCfm)

#if (ERRCLASS & ERRCLS_DEBUG)
   SBLOGERROR(ERRCLS_DEBUG, ESB327, (ErrVal)ERRZERO,
              "PtUiSctAssocCfm: Failed");
#endif /* ERRCLASS */

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suAssocId);
   UNUSED(spAssocId);
   UNUSED(dstNAddrLst);
   UNUSED(dstPort);
/* sb016.102 - Include in-stream parameter here */
#ifdef SCT2
   UNUSED(inStrms);
#endif /* SCT2 */
   UNUSED(outStrms);
   UNUSED(vsInfo);

   RETVALUE(ROK);
}




#ifdef ANSI
PUBLIC S16 PtUiSctTermInd
(
Pst           *pst,
SuId           suId,
UConnId        assocId,
U8             assocIdType,
SctStatus      status,
SctCause       cause,
SctRtrvInfo   *rtrvInfo
)
#else
PUBLIC S16 PtUiSctTermInd(pst, suId, assocId, assocIdType, status, cause,
                          rtrvInfo)
Pst           *pst;
SuId           suId;
UConnId        assocId;
U8             assocIdType;
SctStatus      status;
SctCause       cause;
SctRtrvInfo   *rtrvInfo;
#endif
{
   TRC3(PtUiSctTermInd)

#if (ERRCLASS & ERRCLS_DEBUG)
   SBLOGERROR(ERRCLS_DEBUG, ESB328, (ErrVal)ERRZERO,
              "PtUiSctTermInd: Failed");
#endif /* ERRCLASS */

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(assocId);
   UNUSED(assocIdType);
   UNUSED(status);
   UNUSED(cause);
   UNUSED(rtrvInfo);

   RETVALUE(ROK);
}


#ifdef ANSI
PUBLIC S16 PtUiSctTermCfm
(
Pst           *pst,
SuId           suId,
UConnId        suAssocId,
SctResult      result,
SctCause       cause
)
#else
PUBLIC S16 PtUiSctTermCfm(pst, suId, suAssocId, result, cause)
Pst           *pst;
SuId           suId;
UConnId        suAssocId;
SctResult      result;
SctCause       cause;
#endif
{
   TRC3(PtUiSctTermCfm)

#if (ERRCLASS & ERRCLS_DEBUG)
   SBLOGERROR(ERRCLS_DEBUG, ESB329, (ErrVal)ERRZERO,
              "PtUiSctTermCfm: Failed");
#endif /* ERRCLASS */

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suAssocId);
   UNUSED(result);
   UNUSED(cause);

   RETVALUE(ROK);
}



#ifdef ANSI
PUBLIC S16 PtUiSctSetPriCfm
(
Pst           *pst,
SuId           suId,
UConnId        suAssocId,
SctResult      result,
SctCause       cause
)
#else
PUBLIC S16 PtUiSctSetPriCfm(pst, suId, suAssocId, result, cause)
Pst           *pst;
SuId           suId;
UConnId        suAssocId;
SctResult      result;
SctCause       cause;
#endif
{
   TRC3(PtUiSctSetPriCfm)

#if (ERRCLASS & ERRCLS_DEBUG)
   SBLOGERROR(ERRCLS_DEBUG, ESB330, (ErrVal)ERRZERO,
              "PtUiSctSetPriCfm: Failed");
#endif /* ERRCLASS */

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suAssocId);
   UNUSED(result);
   UNUSED(cause);

   RETVALUE(ROK);
}



#ifdef ANSI
PUBLIC S16 PtUiSctHBeatCfm
(
Pst           *pst,
SuId           suId,
UConnId        suAssocId,
CmNetAddr     *dstNAddr,
SctStatus      status,
SctResult      result,
SctCause       cause
)
#else
PUBLIC S16 PtUiSctHBeatCfm(pst, suId, suAssocId, dstNAddr, status, result,
                           cause)
Pst           *pst;
SuId           suId;
UConnId        suAssocId;
CmNetAddr     *dstNAddr;
SctStatus      status;
SctResult      result;
SctCause       cause;
#endif
{
   TRC3(PtUiSctHBeatCfm)

#if (ERRCLASS & ERRCLS_DEBUG)
   SBLOGERROR(ERRCLS_DEBUG, ESB331, (ErrVal)ERRZERO,
              "PtUiSctHBeatCfm: Failed");
#endif /* ERRCLASS */

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suAssocId);
   UNUSED(dstNAddr);
   UNUSED(status);
   UNUSED(result);
   UNUSED(cause);

   RETVALUE(ROK);
}


#ifdef ANSI
PUBLIC S16 PtUiSctDatInd
(
Pst           *pst,
SuId           suId,
UConnId        suAssocId,
SctStrmId      strmId,
SctDatIndType *indType,
U32            protId,
Buffer        *mBuf
)
#else
PUBLIC S16 PtUiSctDatInd(pst, suId, suAssocId, strmId, indType, protId, mBuf)
Pst           *pst;
SuId           suId;
UConnId        suAssocId;
SctStrmId      strmId;
SctDatIndType *indType;
U32            protId;
Buffer        *mBuf;
#endif
{
   TRC3(PtUiSctDatInd)

#if (ERRCLASS & ERRCLS_DEBUG)
   SBLOGERROR(ERRCLS_DEBUG, ESB332, (ErrVal)ERRZERO,
              "PtUiSctDatInd: Failed");
#endif /* ERRCLASS */

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suAssocId);
   UNUSED(strmId);
   UNUSED(indType);
   UNUSED(protId);
   UNUSED(mBuf);

   RETVALUE(ROK);
}



#ifdef ANSI
PUBLIC S16 PtUiSctStaCfm
(
Pst           *pst,
SuId           suId,
UConnId        suAssocId,
CmNetAddr     *dstNAddr,
SctResult      result,
SctCause       cause,
SctStaInfo    *staInfo
)
#else
PUBLIC S16 PtUiSctStaCfm(pst, suId, suAssocId, dstNAddr, result,
                         cause, staInfo)
Pst           *pst;
SuId           suId;
UConnId        suAssocId;
CmNetAddr     *dstNAddr;
SctResult      result;
SctCause       cause;
SctStaInfo    *staInfo;
#endif
{
   TRC3(PtUiSctStaCfm)

#if (ERRCLASS & ERRCLS_DEBUG)
   SBLOGERROR(ERRCLS_DEBUG, ESB333, (ErrVal)ERRZERO,
              "PtUiSctStaCfm: Failed");
#endif /* ERRCLASS */

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suAssocId);
   UNUSED(dstNAddr);
   UNUSED(result);
   UNUSED(cause);
   UNUSED(staInfo);

   RETVALUE(ROK);
}



#ifdef ANSI
PUBLIC S16 PtUiSctStaInd
(
Pst           *pst,
SuId           suId,
UConnId        suAssocId,
UConnId        spAssocId,
CmNetAddr     *dstNAddr,
SctStatus      status,
SctCause       cause,
Buffer        *mBuf
)
#else
PUBLIC S16 PtUiSctStaInd(pst, suId, suAssocId, spAssocId, dstNAddr, status,
                         cause, mBuf)
Pst           *pst;
SuId           suId;
UConnId        suAssocId;
UConnId        spAssocId;
CmNetAddr     *dstNAddr;
SctStatus      status;
SctCause       cause;
Buffer        *mBuf;
#endif
{
   TRC3(PtUiSctStaInd)

#if (ERRCLASS & ERRCLS_DEBUG)
   SBLOGERROR(ERRCLS_DEBUG, ESB334, (ErrVal)ERRZERO,
              "PtUiSctStaInd: Failed");
#endif /* ERRCLASS */

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suAssocId);
   UNUSED(spAssocId);
   UNUSED(dstNAddr);
   UNUSED(status);
   UNUSED(cause);
   UNUSED(mBuf);

   RETVALUE(ROK);
}



#ifdef ANSI
PUBLIC S16 PtUiSctFlcInd
(
Pst           *pst,
SuId           suId,
UConnId        suAssocId,
Reason         reason
)
#else
PUBLIC S16 PtUiSctFlcInd(pst, suId, suAssocId, reason)
Pst           *pst;
SuId           suId;
UConnId        suAssocId;
Reason         reason;
#endif
{
   TRC3(PtUiSctFlcInd)

#if (ERRCLASS & ERRCLS_DEBUG)
   SBLOGERROR(ERRCLS_DEBUG, ESB335, (ErrVal)ERRZERO,
              "PtUiSctFlcInd: Failed");
#endif /* ERRCLASS */

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suAssocId);
   UNUSED(reason);

   RETVALUE(ROK);
}

#endif /* PTSBUISCT */


/********************************************************************30**

         End of file:     sb_ptui.c@@/main/sip_rel_2.2_dev/sip_rel_2.2_tpt_dev/1 - Fri Jan  6 03:54:40 2006

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/
/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
 /main/2     ---      asa   1. initial release.
           sb003.11    sb   1. Function matrics modified for IUA layer.
 /main/2     ---       sb   1. Modified for SCTP release based on 
                               RFC-2960 'Oct 2000.
          sb016.102    ap   1. Include in-stream parameter in AssocCfm 
                               under SCT2 compile time flag.
          sb042.102    hl   1. Added change for SHT interface and Rolling
                               UpGrade
          sb048.102    rs   1. GCP added as new SCTP user. 
                            2. Dummy user added.
                            3. DFTHA M3UA support.
          sb052.102    ag   1. NBAP (ENTIB),M1UA (ENTMZ) added as new SCTP user. 
          sb065.102    kp   1. SIP added as new SCTP user.
*********************************************************************91*/
