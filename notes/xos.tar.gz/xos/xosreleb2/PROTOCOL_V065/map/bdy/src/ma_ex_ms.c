/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     application - external - mos
  
     Type:     C source file
  
     Desc:     Functions required for scheduling and initialization.
  
     File:     ca_ex_ms.c
  
     Sid:      ca_ex_ms.c@@/main/10 - Fri Sep 16 02:47:49 2005

     Prg:      aa
  
*********************************************************************21*/


/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#if MAP_MSC
#if MAP_VLR
#if MAP_HLR
      -05      MSC, VLR and HLR
#else
#endif
#else
#if MAP_HLR
#else
      -01      MSC
#endif
#endif
#else
#if MAP_VLR
#if MAP_HLR
      -04      VLR and HLR
#else
      -02      VLR
#endif
#else
#if MAP_HLR
      -03      HLR
#else
#endif
#endif
#endif

************************************************************************/
 

/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common SS7 */
#include "lma.h"           /* layer management, MAP */
#include "cm_err.h"        /* common error */
#include "stu.h"           /* tcap layer */
#include "mat.h"           /* map layer */
#include "cm5.h"
#ifdef MA_FTHA             /* fault tolerance */
#include "sht.h"           /* SHT Interface header file */
#endif /* MA_FTHA */
#include "ma.h"            /* map */
#include "ma_mf.h"         /* map */
#include "ma_err.h"        /* map error */
#include "cm_llist.h"
#ifdef ZJ
#include "cm_ftha.h"       /* Common FTHA */
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#include "cm_tupsf.h"      /* Common TCAP user PSF */
#include "zj.h"            /* PSF MAP */
#endif /* ZJ */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"
#include "cm_ss7.x"        /* common */
#include "cm_llist.x"        /* common */
#include "stu.x"           /* tcap layer */
#include "lma.x"           /* layer management, TCAP */
#include "mat.x"           /* map  layer */
#ifdef MA_FTHA             /* fault tolerance */
#include "sht.x"           /* SHT Interface */
#endif /* MA_FTHA */
#ifdef ZJ
#include "cm_ftha.x"       /* Common FTHA */
#include "cm_pftha.x"      /* Common PSF defines */
#include "cm_psfft.x"
#include "cm_tupsf.x"      /* Common TCAP user PSF */
#include "ma.x"            /* map  layer */
#include "zj.x"            /* PSF MAP */
#endif /* ZJ */
#include "ma.x"            /* map */
  
#ifdef CP_OAM_SUPPORT
#include "xosshell.h"
#include "oam_interface.h"
#include "ma_nms.h"
#include "cp_tab_def.h"
#include "cp_oam_stru.x"
#include "cp_oam_stru.h"
#include "sm.h"
#include "sm.x"
#include "ma_oam.x"
#include "ma_cfg.h"
#endif
#ifdef SSI_WITH_CLI_ENABLED
#include "clishell.h"
#include "ma_dbg.h"
#endif
  
/* local defines */

/* local typedefs */
  
/* local externs */
  

/* functions in other modules */

/* public variable declarations */
  
/* private variable declarations */
  
  
/*
*     support functions
*/



/*
*
*       Fun:    initialize external
*
*       Desc:   Initializes variables used to interface with Upper/Lower
*               Layer  
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   ca_ex_ms.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maInitExt
(
void
)
#else
PUBLIC S16 maInitExt()
#endif
{
   TRC2(maInitExt)
#ifdef SSI_WITH_CLI_ENABLED
{
    S32 ret, retma;
	ret = XOS_RegistCmdPrompt( SYSTEM_MODE, "prtl", "Э��ģʽ", "�޲���" );
	retma = XOS_RegistCmdPrompt(ret, "map", "MAP Э��", "�޲���" );
/*
	XOS_RegistCommand(retma, Test_Init_MAP, "maprun", "run and config the map protocol", " no parameter" );
	XOS_RegistCommand(retma, maTstCaseRun, "caserun", "run test case", "cmd [caseid]" );
	XOS_RegistCommand(retma, maDbgMAPCfg, "macfg", "default cfg MAP", "no parameter" );
	XOS_RegistCommand(retma, maDbgGenCfg, "magencfg", "MAP gencfg req", "cdm [instance]" );
	XOS_RegistCommand(retma, maDbgSapCfg, "masapcfg", "MAP sapcfg req", "cmd [sapId] [sapIdTC] [switch]" );	
	XOS_RegistCommand(retma, maDbgCntr, "macntcfg", "MAP cnrt req", "cmd [sapId] [elemnt] [action] [subaction]" );
	XOS_RegistCommand(retma, maDbgBnd, "mabnd", "MAP bind req: bind MAP to ST", "cmd [suId] [spId]" );
*/
    XOS_RegistCommand(retma, maDbgSetDbgmsk, "setdbgmask", "set dbgmsk for dbg info", "cmd \n\t[SSI] :0x01\t[LMA] :0x02\n\t[UI]  :0x04\t[LI]  :0x08\n\t"
                                                                                                  "[PI]  :0x10\t[PLI] :0x20\n\t[GEN] :0x100\t[ENC] :0x2800\n\t"
                                                                                                  "[DEC] :0x3000\n");
    

	XOS_RegistCommand(retma, maShowDbgStat, "showdbgmask", "show debug mask info", " no parameters" );
    /*get some state and config information*/
	XOS_RegistCommand(retma, maShowSapStat, "showsap", "show SAP info", " shsap [sapId]" );
	XOS_RegistCommand(retma, maShowDlgStat, "showdlg", "show Dlg info", " shdlg [sapId]" );
	XOS_RegistCommand(retma, maShowMaCfg, "showcfg", "show MAP Config info", " no parameter" );
	XOS_RegistCommand(retma, maShowSts, "showsts", "show statistics info", " shsts [sapId] [action]\n action:\n --0:zero\n --1:print\n --2:print&zero" );
}
#endif/*SSI_WITH_CLI_ENABLED*/

   RETVALUE(ROK);
} /* end of maInitExt */

/*
*
*       Fun:    new activate task
*
*       Desc:   Processes received event from Upper/Lower Layer
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   ca_ex_ms.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maActvTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 maActvTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   S16 ret;
   
   TRC3(maActvTsk)

   ret = ROK;   

   switch(pst->srcEnt)
   {
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__,
                   __LINE__, (ErrCls) ERRCLS_DEBUG, EMA276, (ErrVal)pst->event,
                   "maActvTsk: Invalid source entity\n");
#endif
         (Void)SPutMsg(mBuf);
         break;

      case ENTAU: /* MAP user events */
         switch(pst->event)
         {
            default:
#if (ERRCLASS & ERRCLS_DEBUG)
               SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__,
               __LINE__, (ErrCls) ERRCLS_DEBUG, EMA277, (ErrVal)pst->event,
               "maActvTsk: Invalid upper layer Event \n");
#endif
             (Void)SPutMsg(mBuf);
             break;
#if ( defined(LCMAUIMAT) || defined(LWLCMAUIMAT) )

#ifdef XWEXT /* xuxingzhou: Xinwei Management */
            case MAT_EVTDETCTREQ:          /* detect request */
               if ((ret = cmUnpkMatXWMgmtReq(MaUiMatXWMgmtReq, pst, mBuf)) != ROK)
                  RETVALUE(ret);
				break;
			case MAT_EVTDETCTRSP:          /* detect response */
               if ((ret = cmUnpkMatXWMgmtRsp(MaUiMatXWMgmtRsp,pst, mBuf)) != ROK)
                  RETVALUE(ret);
				break;
#endif /* XWEXT */
            case MAT_EVTBNDREQ:             /* Bind request */
               if ((ret = cmUnpkMatBndReq(MaUiMatBndReq,pst, mBuf)) != ROK)
                  RETVALUE(ret);
               break;
            case MAT_EVTUBNDREQ:            /* UnBind request */
               if ((ret = cmUnpkMatUbndReq(MaUiMatUbndReq,pst, mBuf)) != ROK)
                  RETVALUE(ret);
               break;
            case MAT_EVTOPENREQ:          /* Open Request */
               if ((ret = cmUnpkMatOpenReq(MaUiMatOpenReq,pst, mBuf)) != ROK)
                  RETVALUE(ret);
               break;
            case MAT_EVTOPENRSP:          /* Open Response */
               if ((ret = cmUnpkMatOpenRsp(MaUiMatOpenRsp,pst, mBuf)) != ROK)
                  RETVALUE(ret);
               break;
            case MAT_EVTCLOSEREQ:         /* Close Request */
               if ((ret = cmUnpkMatCloseReq(MaUiMatCloseReq,pst, mBuf)) != ROK)
                  RETVALUE(ret);
               break;
            case MAT_EVTDELIMREQ:         /* Delimeter Request */
               if ((ret = cmUnpkMatDelimReq(MaUiMatDelimReq,pst, mBuf)) != ROK)
                  RETVALUE(ret);
               break;
            case MAT_EVTABRTREQ:          /* Abort Request */
               if ((ret = cmUnpkMatAbrtReq(MaUiMatAbrtReq,pst, mBuf)) != ROK)
                  RETVALUE(ret);
               break;

            case MAT_EVTSTEREQ:    /* State Change Request */
               if ((ret = cmUnpkMatSteReq(MaUiMatSteReq,pst, mBuf)) != ROK)
                  RETVALUE(ret);
               break;

            case MAT_EVTSTERSP:    /* State Change Response */
               if ((ret = cmUnpkMatSteRsp(MaUiMatSteRsp,pst, mBuf)) != ROK)
                  RETVALUE(ret);
               break;

#if MAP_MSC
            case MAT_EVTHOMGMTREQ:    /* Handover Management Request */
               if ((ret = cmUnpkMatHOMgmtReq(MaUiMatHOMgmtReq,pst, mBuf))!=ROK)
                  RETVALUE(ret);
               break;
            case MAT_EVTHOMGMTRSP:    /* Handover Management Response */
               if ((ret = cmUnpkMatHOMgmtRsp(MaUiMatHOMgmtRsp,pst, mBuf))!=ROK)
                  RETVALUE(ret);
               break;

#endif /* MAP_MSC */

#if (MAP_VLR || MAP_HLR || MAP_GSN)

            case MAT_EVTLOCMGMTREQ:       /* Location Management Request */
               if ((ret=cmUnpkMatLocMgmtReq(MaUiMatLocMgmtReq,pst, mBuf))!=ROK)
                  RETVALUE(ret);
               break;

            case MAT_EVTLOCMGMTRSP:       /* Location Management Response */
               if ((ret=cmUnpkMatLocMgmtRsp(MaUiMatLocMgmtRsp,pst, mBuf))!=ROK)
                  RETVALUE(ret);
               break;
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_GSN)

            case MAT_EVTAUTHMGMTREQ:      /* Auth. Management Request */
               if ((ret=cmUnpkMatAuthMgmtReq(MaUiMatAuthMgmtReq,pst,mBuf))!=ROK)
                  RETVALUE(ret);
                  break;

#endif /* MAP_VLR || MAP_GSN */

#if MAP_HLR

            case MAT_EVTAUTHMGMTRSP:      /* Auth. Management Response */
               if ((ret=cmUnpkMatAuthMgmtRsp(MaUiMatAuthMgmtRsp,pst,mBuf))!=ROK)
                  RETVALUE(ret);
               break;
#endif /* MAP_HLR */

/* --------------- Identification Management ------------------------ */
#if MAP_VLR
            case MAT_EVTIMEIMGMTRSP:      /* IMEI Management Response */
               if ((ret=cmUnpkMatIMEIMgmtRsp(MaUiMatIMEIMgmtRsp,pst,mBuf))!=ROK)
                  RETVALUE(ret);
      break;
#endif /* MAP_VLR */

#if (MAP_MSC || MAP_GSN)
            case MAT_EVTIMEIMGMTREQ:      /* IMEI Management Request */
               if ((ret=cmUnpkMatIMEIMgmtReq(MaUiMatIMEIMgmtReq,pst,mBuf))!=ROK)
                  RETVALUE(ret);
               break;
#endif /* MAP_MSC || MAP_GSN */

/* --------------- Fault and Recovery Management -------------------- */
#if (MAP_VLR || MAP_HLR)
            case MAT_EVTFRMGMTREQ:    /* Fault & Rec. Management Request */
               if ((ret=cmUnpkMatFRMgmtReq(MaUiMatFRMgmtReq,pst, mBuf)) != ROK)
                  RETVALUE(ret);
               break;
#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
            case MAT_EVTFRMGMTRSP:    /* Fault & Rec. Management Response */
           if ((ret = cmUnpkMatFRMgmtRsp(MaUiMatFRMgmtRsp,pst, mBuf)) != ROK)
              RETVALUE(ret);
           break;


#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

/* --------------- OAM Management ----------------------------------- */
#if (MAP_MSC || MAP_VLR || MAP_HLR)
            case MAT_EVTOAMMGMTREQ:       /* OAM Management Request */
               if ((ret = cmUnpkMatOAMReq(MaUiMatOAMReq,pst, mBuf)) != ROK)
                  RETVALUE(ret);
            break;
#endif /* MAP_MSC || MAP_VLR || MAP_HLR */

#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)

            case MAT_EVTOAMMGMTRSP:       /* OAM Management Response */
               if ((ret = cmUnpkMatOAMRsp(MaUiMatOAMRsp,pst, mBuf)) != ROK)
                  RETVALUE(ret);
            break;
#endif /* MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN */

/* --------------- Call Management ----------------------------------- */
#if (MAP_MSC || MAP_VLR || MAP_HLR)
            case MAT_EVTCALLMGMTREQ:      /* Call Management Request */
               if ((ret=cmUnpkMatCallMgmtReq(MaUiMatCallMgmtReq,pst,mBuf)) 
                        != ROK)
                  RETVALUE(ret);
            break;
            case MAT_EVTCALLMGMTRSP:      /* Call Management Response */
               if ((ret=cmUnpkMatCallMgmtRsp(MaUiMatCallMgmtRsp,pst,mBuf))!=ROK)
                  RETVALUE(ret);
            break;
#endif /* MAP_MSC || MAP_VLR || MAP_HLR */

/* --------------- Supplementary Services Management ----------------- */
#if (MAP_VLR || MAP_HLR)

            case MAT_EVTSSMGMTREQ:    /* Supplementry Services Request */
               if ((ret = cmUnpkMatSSReq(MaUiMatSSReq,pst, mBuf)) != ROK)
                  RETVALUE(ret);
            break;
#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR)
            case MAT_EVTSSMGMTRSP:    /* Supplementry Services Response */
               if ((ret = cmUnpkMatSSRsp(MaUiMatSSRsp,pst, mBuf)) != ROK)
                  RETVALUE(ret);
            break;

#endif /* MAP_HLR */

/* --------------- Short Message Services Management ------------------ */
#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)

            case MAT_EVTSMMGMTREQ:    /* SM Management Request */
               if ((ret = cmUnpkMatSMReq(MaUiMatSMReq,pst, mBuf)) != ROK)
                  RETVALUE(ret);
            break;

#endif /* MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_MSC || MAP_HLR || MAP_GSN)

            case MAT_EVTSMMGMTRSP:    /* SM Management Response */
               if ((ret = cmUnpkMatSMRsp(MaUiMatSMRsp,pst, mBuf)) != ROK)
                  RETVALUE(ret);
            break;
#endif /* MAP_MSC || MAP_HLR || MAP_GSN */

/* --------------- Subscriber Management ------------------------------ */
#if (MAP_VLR || MAP_HLR || MAP_GSN)

            case MAT_EVTSUBMGMTREQ:       /* Subs. Management Request */
               if ((ret=cmUnpkMatSubMgmtReq(MaUiMatSubMgmtReq,pst,mBuf)) != ROK)
                  RETVALUE(ret);
            break;

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR || MAP_GSN || MAP_MLC)

            case MAT_EVTSUBMGMTRSP:       /* Subs. Management Confirm */
               if ((ret=cmUnpkMatSubMgmtRsp(MaUiMatSubMgmtRsp,pst,mBuf)) != ROK)
                  RETVALUE(ret);
            break;

#endif /* MAP_VLR || MAP_HLR || MAP_GSN || MAP_MLC */

/* --------------- PDP Context Activation Management ------------------ */
#if (MAP_HLR || MAP_GSN)
            case MAT_EVTPDPACTVREQ:       /* Pdp Cntxt Act.Request */
               if ((ret = cmUnpkMatNwReqPdpCntxtActvReq(
                    MaUiMatNwReqPdpCntxtActvReq, pst, mBuf)) != ROK) 
               RETVALUE(ret);
            break;
            case MAT_EVTPDPACTVRSP:       /* PdpActv Management Response */
               if ((ret = cmUnpkMatNwReqPdpCntxtActvRsp(
                    MaUiMatNwReqPdpCntxtActvRsp, pst, mBuf)) != ROK)
               RETVALUE(ret);
            break;

#endif /* MAP_HLR || MAP_GSN */

#if (MAP_REL98 || MAP_REL99)

/* --------------- Location Service Management ------------------ */
#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL4 && MAP_GSN))
            case MAT_EVTLOCSERVREQ:      /* Loc. Services Management Request */
               if ((ret = cmUnpkMatLocServReq(MaUiMatLocServReq, pst, mBuf)) != ROK)
                  RETVALUE(ret);
            break;
#endif 
#endif

#if (MAP_MSC || MAP_HLR || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_HLR || MAP_MLC || (MAP_REL4 && MAP_GSN))
            case MAT_EVTLOCSERVRSP:      /* Loc. Services Management Response */
               if ((ret = cmUnpkMatLocServRsp(MaUiMatLocServRsp, pst, mBuf)) != ROK)
                  RETVALUE(ret);
            break;
#endif
#endif

#endif /* (MAP_REL98 || MAP_REL99) */

#endif /* LCMAUIMAT || LWLCMAUIMAT */
       }
       break;
      case ENTSM: /* Stack manager events */
         switch(pst->event)
         {
            default:
#ifdef ZJ
            /* Pass all unrecognized events to PSF */
            zjActvTsk(pst, mBuf);
#else /* ZJ */
#if (ERRCLASS & ERRCLS_DEBUG)
               SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__,
               __LINE__, (ErrCls) ERRCLS_DEBUG, EMA278, (ErrVal)pst->event,
               "maActvTsk: Invalid management layer Event \n");
#endif
             (Void)SPutMsg(mBuf);
#endif /* ZJ */
             break;
#ifdef LCMAMILMA
            case MA_EVTLMACFGREQ:        /* Configuration Request */
               if ((ret = cmUnpkLmaCfgReq(MaMiLmaCfgReq,pst, mBuf)) != ROK)
                  RETVALUE(ret);
               break;
            case MA_EVTLMASTAREQ:        /* Status Request */
               if ((ret = cmUnpkLmaStaReq(MaMiLmaStaReq,pst, mBuf)) != ROK)
                  RETVALUE(ret);
               break;
            case MA_EVTLMASTSREQ:        /* Statistics Request */
               if ((ret = cmUnpkLmaStsReq(MaMiLmaStsReq,pst, mBuf)) != ROK)
                  RETVALUE(ret);
               break;
            case MA_EVTLMACNTRLREQ:      /* Control Request */
               if ((ret = cmUnpkLmaCntrlReq(MaMiLmaCntrlReq,pst, mBuf)) != ROK)
                  RETVALUE(ret);
               break;
#endif
         } /* Switch on layer manager events */
         break;
         case ENTST: /* lower layer events */
         switch(pst->event)
         {
            default:
#if (ERRCLASS & ERRCLS_DEBUG)
               SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__,
               __LINE__, (ErrCls) ERRCLS_DEBUG, EMA279, (ErrVal)pst->event,
               "maActvTsk: Invalid Lower layer Event \n");
#endif
               (Void)SPutMsg(mBuf);
               break;
#ifdef LCMALISTU
            case EVTSTUBNDCFM:     /* Bind Confirm */
               if ((ret = cmUnpkStuBndCfm(MaLiStuBndCfm,pst, mBuf)) != ROK)
               {
                  RETVALUE(ret);
               }
            break;
            case  EVTSTUDATIND:
               if ((ret = cmUnpkStuDatInd(MaLiStuDatInd,pst, mBuf)) != ROK)
                  RETVALUE(ret);
               break;
            case  EVTSTUNOTIND:
               if ((ret = cmUnpkStuNotInd(MaLiStuNotInd,pst, mBuf)) != ROK)
                  RETVALUE(ret);
               break;
            case  EVTSTUCMPIND:
               if ((ret = cmUnpkStuCmpInd(MaLiStuCmpInd,pst, mBuf)) != ROK)
                  RETVALUE(ret);
               break;
            case  EVTSTUCMPCFM:
               if ((ret = cmUnpkStuCmpCfm(MaLiStuCmpCfm,pst, mBuf)) != ROK)
                  RETVALUE(ret);
               break;
            case  EVTSTUSTAIND:
               if ((ret = cmUnpkStuStaInd(MaLiStuStaInd,pst, mBuf)) != ROK)
                  RETVALUE(ret);
               break;
            case EVTSTUSTEIND:             /* State indication */
               ret = cmUnpkStuSteInd(MaLiStuSteInd,pst, mBuf);
               break;
            case EVTSTUSTECFM:             /* State Confirm */
               ret = cmUnpkStuSteCfm(MaLiStuSteCfm,pst, mBuf);
               break;
#endif
     } /* switch on lower layer events */
     break;
     case ENTSH:   /* system Agent - always loosely coupled */
        switch(pst->event)
        {
            default:
#ifdef ZJ
            /* Pass all unrecognized events to PSF */
            zjActvTsk(pst, mBuf);
#else /* ZJ */
#if (ERRCLASS & ERRCLS_DEBUG)
               SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__,
               __LINE__, (ErrCls) ERRCLS_DEBUG, EMA280, (ErrVal)pst->event,
               "maActvTsk: Invalid System Agent Event \n");
#endif
               (Void)SPutMsg(mBuf);
#endif /* ZJ */
               break;
#ifdef MA_FTHA
            case EVTSHTCNTRLREQ:  /* system agent control request */
               /* call unpakcing function */
               ret = cmUnpkMiShtCntrlReq(MaMiShtCntrlReq, pst, mBuf);
               break;
#endif /* MA_FTHA */

         } /* end of switch for layer mgmt entity */
         break;

/* Loosley coupled peer interface */

#ifdef ZJ
     case ENTMA:   /* Peer MAP */
        zjActvTsk(pst, mBuf);
        break;
#endif /* ZT */

   } /* switch on source entity */

#ifdef MA_RUG
   /* Generate alarm for invalid version on any interfaces */
   if(ret == RINVIFVER) 
   {
      maSendAlrm(MA_UNUSED, MA_UNUSED, MA_UNUSED, MA_UNUSED, MA_UNUSED,
                 LCM_EVENT_INV_EVT,
                 LCM_CATEGORY_INTERFACE,
                 LCM_CAUSE_DECODE_ERR);
   }
#endif /* MA_RUG */

   SExitTsk();
   RETVALUE(ret);
} /* end of maActvTsk */

/********************************************************************30**
  
         End of file:     ca_ex_ms.c@@/main/10 - Fri Sep 16 02:47:49 2005

*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  aa   1. initial release

1.2          ---  aa    1. text changes

*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.3          ---      aa   1. Removed the lnkId parameter from SSRsp primtives
             ---      aa   2. Include cm_ss7.h
             ---      aa   3. Compilation warning

1.4          ---      aa   1. Moved XXYYMatAuthMgmtInd from #ifdef MSC to HLR.
             ---      sg   2. Added SteReq & SteRsp unpacking code which was missing
             ---      ssk  3. Added the Phase 2+ Variant

1.5          ---      jz   1. Changes for TCR0018, system agent control 
                              request handled in iaActvTsk.

/main/5      ---      jie  1. update for MAP 1.5 release.

             ---      jie  1. MaMiShtCntrlReq prototype is moved to ma.x.

             ---      jie  1. Rolling upgrade compliance.

             ---      jie  1. Change for 3.9.0 REL_99 support.

             ---      jie  1. Change for MAP REL4 support without the MAPsec 
                              feature.

/main/6      ---      jie  1. update for MAP 1.6 release.

/main/7      ---      jie  1. update for MAP 1.7 release.

/main/9      ---      zj   1. PSF-MAP changes.
/main/10     ---      rbabu 1. update for MAP 2.3 release.
*********************************************************************91*/
