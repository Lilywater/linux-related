#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"
#include "cm_ss7.h"
#include "cm_err.h"        /* common error */
#include "cm_llist.h"
#include "stu.h"           /* tcap upper interface */
#include "mat.h"           /* inap upper interface */
#include "lma.h"           /* layer management interface */
#ifdef MA_FTHA
#include "sht.h"           /* SHT interface */
#endif /* MA_FTHA */
#include "ma.h"
#include "ma_err.h"        /* error defines */
#include "ma_mf.h"
#ifdef ZJ
#include "cm_ftha.h"       /* Common FTHA */
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#include "cm_tupsf.h"      /* Common TCAP user PSF */
#include "lzj.h"
#endif

#ifdef STMA 
#include "spt.h"           /* sccp layer */
#include "lst.h"           /* layer management, TCAP */
#include "st.h"            /* tcap */
#include "st_err.h"        /* tcap error */
#include "st_mf.h"         /* message function defines */
#endif /* STMA */

 

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"
#include "cm_ss7.x"        /* Common */
#include "cm_lib.x"        /* Common library headers */
#include "cm_llist.x"
#include "stu.x"           /* tcap upper interface */
#include "lma.x"           /* layer management interface */
#include "mat.x"           /* inap upper interface */
#ifdef MA_FTHA
#include "sht.x"           /* SHT interface */
#endif /* MA_FTHA */
#ifdef ZJ
#include "cm_ftha.x"       /* Common FTHA */
#include "cm_pftha.x"      /* Common PSF defines */
#include "cm_psfft.x"
#include "cm_tupsf.x"      /* Common TCAP user PSF */
#endif
#include "ma.x"
#ifdef ZJ
#include "lzj.x"
#include "zj.x"
#endif

#ifdef STMA 
#include "lst.x"           /* Layer management, TCAP */
#include "spt.x"           /* Sccp layer             */
#include "st_mf.x"         /* message function       */
#endif /* STMA */

#include "ma_init.h"


#ifdef CP_OAM_SUPPORT
#include "xosshell.h"
#include "oam_interface.h"
#include "oam_tab_def.h"
#include "cp_oam_stru.x"
#include "ma_nms.h"
#include "cp_tab_def.h"
#include "cp_oam_stru.x"
#include "cp_oam_stru.h"
#include "sm.h"
#include "sm.x"
#include "ma_oam.x"
#include "ma_cfg.h"
#endif


#ifdef ANSI
PUBLIC S16 ma_init_fun
(
SSTskId    tskId
)
#else
PUBLIC S16 ma_init_fun(tskId)
SSTskId    tskId;
#endif
{
   if(tskId == 0)
   {
	   if(SCreateSTsk(PRIOR0, &tskId)!= ROK)
	   {
	      SPrint("INIT SCreateSTsk for MAP failed.\n");
	      RETVALUE(RFAILED);   	
	   }
   }

   if(SRegTTsk(ENTMA, TSTINST_0, TTNORM, 0,(PAIFS16) maActvInit, maActvTsk)!= ROK)
   	{
      SPrint("INIT:SRegTTsk() for MAP failed.\n");
      RETVALUE(RFAILED);   	
   	}
   if(SAttachTTsk(ENTMA, TSTINST_0, tskId)!= ROK)
   	{
      SPrint("INIT:SAttachTTsk() for MAP failed.\n");
      RETVALUE(RFAILED);   	
   	}
   
  #ifdef CP_OAM_SUPPORT
   maInitCfgData();

   if( ROK != smRegCb((Ent)ENTMA, gMaSmQ, sizeof(gMaSmQ)/sizeof(CmLListCp), smMaSendReqQ, maResetCfgData))
   {
      RETVALUE(RFAILED);
   }

	if( OAM_CALL_SUCC != register_msg_proc(CP_MODULE_ID_SS7_MAP,  APP_SYNC_MSG,  maInitCfgCallback, NULL))
	{
      RETVALUE(RFAILED);
   } 

   (unsigned char)get_resource(xwCpSS7NwkTable, sizeof(CP_OAM_SS7_NETWORK_TAB), xwCpSS7NwkTable_ROW_NUM);
   (unsigned char)get_resource(xwCpSS7UpTable, sizeof(CP_OAM_SS7_UP_TAB), xwCpSS7UpTable_ROW_NUM);
   (unsigned char)get_resource(xwCpSS7SsnTable, sizeof(CP_OAM_SS7_SSN_TAB), xwCpSS7SsnTable_ROW_NUM);
   (unsigned char)get_resource(xwCpMapGenCfg, sizeof(MaGenCfgTab), xwCpMapGenCfg_ROW_NUM);
   (unsigned char)get_resource(xwCpMapSapCfg, sizeof(MaMAUCfgTab), xwCpMapSapCfg_ROW_NUM);
   (unsigned char)get_resource(xwCpMapAcnCfg, sizeof(MaACNCfgTab), xwCpMapAcnCfg_ROW_NUM);

   if( OAM_CALL_SUCC != app_register(CP_MODULE_ID_SS7_MAP, &maCfgTbl[0], SM_MAP_TAB_NUM))/*sizeof(maCfgTbl)/sizeof(maCfgTbl[0])*/
   {
      RETVALUE(RFAILED);
   }
#endif


   RETVALUE(ROK);
}

