/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     map
  
     Type:     C Source file
  
     Desc:     Common MAP functions.
  
     File:     ca_bdy2.c
  
     Sid:      ca_bdy2.c@@/main/12 - Fri Sep 16 02:46:48 2005
  
     Prg:      ssk
  
************************************************************************/


/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#if MAP_MSC
#if MAP_VLR
#if MAP_HLR
      -05      MSC, VLR and HLR
#else
#endif
#else
#if MAP_HLR
#else
      -01      MSC
#endif
#endif
#else
#if MAP_VLR
#if MAP_HLR
      -04      VLR and HLR
#else
      -02      VLR
#endif
#else
#if MAP_HLR
      -03      HLR
#else
#endif
#endif
#endif

************************************************************************/
 

/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "lma.h"           /* layer management, MAP */
#include "cm_err.h"        /* common error */
#include "stu.h"           /* tcap layer */
#include "mat.h"           /* map layer */
#ifdef MA_RUG
#include "sht.h"
#endif /* MA_RUG */
#include "cm5.h"
#include "ma.h"            /* map */
#include "ma_mf.h"         /* map */
#include "ma_err.h"        /* map error */
#ifdef ZJ
#include "cm_ftha.h"       /* Common FTHA */
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#include "cm_tupsf.h"      /* Common TCAP user PSF */
#include "zj.h"            /* Tcap PSF defines */
#include "lzj.h"
#endif /* ZJ */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"
#include "cm_ss7.x"           /* common */
#include "stu.x"           /* tcap layer */
#include "lma.x"           /* layer management, TCAP */
#include "mat.x"           /* map  layer */
#ifdef MA_FTHA
#include  "sht.x"
#endif /* MA_FTHA */
#ifdef ZJ
#include "cm_ftha.x"       /* Common FTHA */
#include "cm_pftha.x"      /* Common PSF defines */
#include "cm_psfft.x"
#include "cm_tupsf.x"      /* Common TCAP user PSF */
#endif /* ZJ */
#include "ma.x"            /* map */
#include "cm_lib.x"        /* Common Portable Library */
#ifdef ZJ
#include "zj.x"            /* Tcap PSF defines */
#include "lzj.x"
#endif /* ZJ */
 
/* Private Functions */

/* Globals */
PUBLIC U32 maMemAlloc = 0;
PUBLIC U32 maMemFree = 0;

/* Dialogue State Matrix */

PRIVATE S16 maOpenReqM00 ARGS ((MaSap *s));
PRIVATE S16 maInvEv ARGS ((MaSap *s));
PRIVATE S16 maOpenRspM05 ARGS ((MaSap *s));
PRIVATE S16 maCloseReqCom ARGS ((MaSap *s));
PRIVATE S16 maDelimReqM01 ARGS ((MaSap *s));
PRIVATE S16 maDelimReqCom ARGS ((MaSap *s));
PRIVATE S16 maAbrtReqCom ARGS ((MaSap *s));
PRIVATE S16 maBeginM00 ARGS ((MaSap *s));
PRIVATE S16 maInvPdu ARGS ((MaSap *s));
PRIVATE S16 maContM03 ARGS ((MaSap *s));
PRIVATE S16 maContCom ARGS ((MaSap *s));
PRIVATE S16 maEndM03 ARGS ((MaSap *s));
PRIVATE S16 maEndCom ARGS ((MaSap *s));
PRIVATE S16 maAbrtM03 ARGS ((MaSap *s));
PRIVATE S16 maAbrtCom ARGS ((MaSap *s));
PRIVATE S16 maNotM03   ARGS ((MaSap *s));

PRIVATE S16 maAddLastResult ARGS((Buffer  *mBuf,MaCmpCp *cmpCp));

#ifdef MA_MULT_SEG_DECODE
PRIVATE S16 maProcessSegments ARGS((MaSap *s,MaDlgCp *dlgCp,
                                    Buffer  *mBuf,MaCmpCp *cmpCp));
#endif /* MA_MULT_SEG_DECODE */

/* Forward reference */
PRIVATE S16 maBldOid ARGS((MaDlgCp *dlgCp, StDlgEv *dlgEv));
PRIVATE S16 maDecOpenPdu ARGS((MaSap *s, MaOpenEv *openEv, U8 acName));
PRIVATE S16 maBldOpenMsg ARGS((MaSap *s, Buffer *mBuf));
PRIVATE S16 maChkLoad ARGS((MaSap *s));
PRIVATE S16 maIsAcnSupp ARGS(( MaApnCfg *acnCfg, U8 *evtPtr, MaDlgCp *dlgCp));
PRIVATE S16 maGetAcn ARGS(( MaSap *s, U8 oprCode, TknStrS *acn));
PRIVATE S16 maSndSSInd ARGS((MaSap *s, MaCmpCp *cmpCp));
#ifndef MA_STATIC_EVT_STRUCT
PRIVATE Void maFreeEncEv ARGS((MaSap *s, U8 *tmpEvtPtr, MaCmpCp *cmpCp));
#endif
PRIVATE S16 maDecRefPdu ARGS((MaSap *s, MaOpenEv *openEv, StStr *apn));
PRIVATE S16 maDecAbrtPdu ARGS((MaSap *s, MaAbrtEv *abrtEv));
PRIVATE S16 maDecErrParam ARGS (( Buffer *mBuf, U8 errCode, MaUsrErr *usrErr,
                                  U8 maVer, U8 *rejFlg));
PRIVATE S16 maDecInCompCause ARGS (( Buffer *mBuf, MaUsrErr *usrErr, U8 *rejFlg));
PRIVATE S16 maDecSMDelFailCause ARGS (( Buffer *mBuf, MaUsrErr *usrErr, 
                                        U8 maVer, U8 *rejFlg));

PRIVATE Void maUpdatRxSts ARGS((MaSap *s, U8 oprType, U8 type));

extern Void maGetStoreEvtFrmCmp(MaDlgCp * dlgCp, MaInvokeId * invkId, MaCmpCp ** cmpCp, U8 ** evt);
extern S16 maStoreEvtToCmpCp(MaDlgCp * dlgCp, MaCmpCp * cmpCp, U8 * evt);

PUBLIC PCFS16    maDSMTbl[MA_NMB_DSM_EVNT][MA_NMB_DSM_STATE] = 
{
     {
     /* MAP Open Request */
     maOpenReqM00,              /* M00 IDLE State */
     maInvEv,                   /* M01 Wait For User Request */
     maInvEv,                   /* M02 Wait Init Data */ 
     maInvEv,                   /* M03 Dialogue Initiated */
     maInvEv,                   /* M04 Dialogue Accepted */
     maInvEv,                   /* M05 Dialogue Pending */
     maInvEv,                   /* M06 Dialogue Established */
     },

     {
     /* MAP Open Response */
     maOpenRspM05,                      /* M00 IDLE State */
     maInvEv,                   /* M01 Wait For User Request */
     maInvEv,                   /* M02 Wait Init Data */ 
     maInvEv,                   /* M03 Dialogue Initiated */
     maInvEv,                   /* M04 Dialogue Accepted */
     maOpenRspM05,              /* M05 Dialogue Pending */
     maInvEv,                   /* M06 Dialogue Established */
     },

     {
     /* MAP Close Request */
     maCloseReqCom,             /* M00 IDLE State */
     maCloseReqCom,             /* M01 Wait For User Request */
     maCloseReqCom,             /* M02 Wait Init Data */ 
     maCloseReqCom,             /* M03 Dialogue Initiated */
     maCloseReqCom,             /* M04 Dialogue Accepted */
     maCloseReqCom,             /* M05 Dialogue Pending */
     maCloseReqCom,             /* M06 Dialogue Established */
     },

     {

     /* MAP Delimeter Request */

     maDelimReqCom,             /* M00 IDLE State */
     maDelimReqM01,             /* M01 Wait For User Request */
     maInvEv,                   /* M02 Wait Init Data */ 
     maInvEv,                   /* M03 Dialogue Initiated */
     maDelimReqCom,             /* M04 Dialogue Accepted */
     maDelimReqCom,             /* M05 Dialogue Pending */
     maDelimReqCom,             /* M06 Dialogue Established */
     },

     {

     /* MAP Abort request */
     maInvEv,                   /* IDLE State */
     maAbrtReqCom,              /* Wait For User Request */
     maAbrtReqCom,              /* Wait Init Data */ 
     maAbrtReqCom,              /* Dialogue Initiated */
     maAbrtReqCom,              /* Dialogue Accepted */
     maAbrtReqCom,              /* Dialogue Pending */
     maAbrtReqCom,              /* Dialogue Established */
     },

     {

     /* TC Begin PDU */
     maBeginM00,                /* Idle State */
     maInvPdu,                  /* Wait For User Request */
     maInvPdu,                  /* Wait Init Data */ 
     maInvPdu,                  /* Dialogue Initiated */
     maInvPdu,                  /* Dialogue Accepted */
     maInvPdu,                  /* Dialogue Pending */
     maInvPdu,                  /* Dialogue Established */
     },

     {

     /* TC Continue PDU */
     maInvPdu,                  /* Idle State */
     maInvPdu,                  /* Wait For User Request */
     maInvPdu,                  /* Wait Init Data */ 
     maContM03,                 /* Dialogue Initiated */
     maContCom,                 /* Dialogue Accepted */
     maInvPdu,                  /* Dialogue Pending */
     maContCom,                 /* Dialogue Established */
     },

     {

     /* TC END PDU */
     maInvPdu,                  /* Idle State */
     maInvPdu,                  /* Wait For User Request */
     maInvPdu,                  /* Wait Init Data */ 
     maEndM03,                  /* Dialogue Initiated */
     maEndCom,                  /* Dialogue Accepted */
     maInvPdu,                  /* Dialogue Pending */
     maEndCom,                  /* Dialogue Established */
     },

     {

     /* TC ABORT PDU */
     maInvPdu,                  /* Idle State */
     maInvPdu,                  /* Wait For User Request */
     maInvPdu,                  /* Wait Init Data */ 
     maAbrtM03,                 /* Dialogue Initiated */
     maAbrtCom,                 /* Dialogue Accepted */
     maInvPdu,                  /* Dialogue Pending */
     maAbrtCom,                 /* Dialogue Established */
     },

     {

     /* TC Notice Indication */
     maInvPdu,                  /* Idle State */
     maInvPdu,                  /* Wait For User Request */
     maInvPdu,                  /* Wait Init Data */ 
     maNotM03,              /* Dialogue Initiated */
     maInvPdu,              /* Dialogue Accepted */
     maInvPdu,              /* Dialogue Pending */
     maInvPdu,              /* Dialogue Established */
     },

}; 

/*
*
*       Fun:   maOpenM00   
*
*       Desc:  Handles the MAP Open request in DSM IDLE state 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maOpenReqM00 
(
MaSap  *s               /* MAP SAP pointer */
)
#else
PRIVATE S16 maOpenReqM00(s)
MaSap *s;               /* MAP SAP pointer */
#endif
{
  S16 ret;          /* return value of the function */
  MaDlgCp *dlgCp;   /* Dialogue control point */
  StComps cmpEv;    /* Component event structure */
  MaInvokeId invokeId; 
  MaSSEv    ssEv;
  Bool      usrDatReq; /* User data require */

   TRC2(maOpenReqM00)

   maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
   usrDatReq=FALSE;
   dlgCp = s->curDlgCp;

   /* Check for the Mandotry information */
   if (( s->curDlgCp->apn.pres == FALSE) || 
        (s->curDlgCp->destAddr.pres == FALSE))
   {
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "maOpenReqM00() failed, mandatory info missing,\
          suId(%d), sapId(%d), suDlgId(%ld), spDlgId(%ld))\n", 
          s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "maOpenReqM00() failed, mandatory info missing,\
          suId(%d), sapId(%d), suDlgId(%d), spDlgId(%d))\n", 
          s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
   }

   if ( !IS_VALID_VERSION(dlgCp->apn.val[dlgCp->apn.len -1]) )
   {
#ifndef ALIGN_64BIT

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "maOpenReqM00() failed, invalid protocol version(%d),\
             suId(%d), sapId(%d), suDlgId(%ld), spDlgId(%ld))\n", 
             dlgCp->apn.val[dlgCp->apn.len -1],
             s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "maOpenReqM00() failed, invalid protocol version(%d),\
             suId(%d), sapId(%d), suDlgId(%d), spDlgId(%d))\n", 
             dlgCp->apn.val[dlgCp->apn.len -1],
             s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
      RETVALUE(RFAILED);
        
#endif/*ALIGN_64BIT*/  
}

   if ( (dlgCp->srcRef.pres == FALSE) && 
        (( dlgCp->apn.val[dlgCp->apn.len -2] == MA_NETFUNC_SS) || 
         ( dlgCp->apn.val[dlgCp->apn.len -2] == MA_CALL_COMP_AC)) )
   {
      usrDatReq = TRUE;
   }

   if ((dlgCp->destRef.pres == FALSE) &&
       ((dlgCp->apn.val[dlgCp->apn.len -2] == MA_NETFUNC_SS) || 
       (dlgCp->apn.val[dlgCp->apn.len -2] == MA_NETUSS_SS) ||
       (dlgCp->apn.val[dlgCp->apn.len -2] == MA_CALL_COMP_AC)))
   {
      usrDatReq = TRUE;
   }

   if ((dlgCp->srcRef.pres == TRUE) && 
       (dlgCp->apn.val[dlgCp->apn.len -2] != MA_NETFUNC_SS) && 
       (dlgCp->apn.val[dlgCp->apn.len -2] != MA_NETUSS_SS) && 
       (dlgCp->apn.val[dlgCp->apn.len -2] != MA_CALL_COMP_AC))
   {
      usrDatReq = TRUE;
   }

   if ((dlgCp->destRef.pres == TRUE) &&
       (dlgCp->apn.val[dlgCp->apn.len -2] != MA_NETFUNC_SS) && 
       (dlgCp->apn.val[dlgCp->apn.len -2] != MA_NETUSS_SS) && 
       (dlgCp->apn.val[dlgCp->apn.len -2] != MA_CALL_COMP_AC))
   {
      usrDatReq = TRUE;
   }

   if (usrDatReq == TRUE)
   {
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "maOpenReqM00() failed, user data is required for ACN class(%d),\
             suId(%d), sapId(%d), suDlgId(%ld), spDlgId(%ld))\n", 
             dlgCp->apn.val[dlgCp->apn.len -2],
             s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
      RETVALUE(RFAILED); 

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "maOpenReqM00() failed, user data is required for ACN class(%d),\
             suId(%d), sapId(%d), suDlgId(%d), spDlgId(%d))\n", 
             dlgCp->apn.val[dlgCp->apn.len -2],
             s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/ 
   }

   /* Get the MAP version from the application conetxt name */

   if ( dlgCp->apn.val[dlgCp->apn.len -1] == LMA_VER1) 
   {
      if ( (dlgCp->srcRef.pres == TRUE) && (dlgCp->destRef.pres == TRUE)) 
      {
         /* Send the TC Inv. Component operation = Begin susbcriber activity */ 
         /* prepare the Begin subscriber activity structure */
         cmCopy((U8 *)&dlgCp->destRef, (U8 *)&ssEv.bgnSubActvReq.imsi,
                 sizeof(MaDestRef));
         cmCopy((U8 *)&dlgCp->srcRef, (U8 *)&ssEv.bgnSubActvReq.orgEntNmb,
                sizeof(MaSrcRef));
         ret = maEncOpr(s, (U8 *)&ssEv, MAT_BEGIN_SUBS_ACTV, MAT_SS_REQ);
         if (ret != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
           MALOGERROR(ERRCLS_DEBUG, EMA066, (ErrVal)MAT_BEGIN_SUBS_ACTV, 
                     "Failed in encoding");
#endif
           if (s->ctlp.mBuf != NULLP)
           {
             SPutMsg(s->ctlp.mBuf);
             s->ctlp.mBuf = NULLP;
           }
           RETVALUE(RFAILED);
         }

         invokeId.pres = TRUE;
         
         invokeId.octet = 127; /* use any invoke Id */

         cmpEv.stCompType = STU_INVOKE;
         cmpEv.stInvokeId.pres = TRUE;
         cmpEv.stInvokeId.octet = invokeId.octet;
         cmpEv.stInvokeTimer = MA_BEGIN_SUBS_ACTV_TMR; 
         cmpEv.stLinkedId.pres = FALSE;
         cmpEv.stOpCode.len = 1;
         cmpEv.stOpCode.string[0] = MAT_BEGIN_SUBS_ACTV;
         cmpEv.stOpCodeFlg = STU_LOCAL;
         cmpEv.stErrorCode.len = 0;
         cmpEv.stErrorCodeFlg = STU_NONE;
         cmpEv.stProbCodeFlg = STU_NONE;
         cmpEv.stProbCode.len = 0;
         cmpEv.cancelFlg = FALSE;  
         cmpEv.opClass = MAT_OPRCLASS4;  

         if (s->trc == TRUE)
         {
           maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);
         }

         dlgCp->dsmState = MA_DLG_WAIT_USER_REQ;

#ifdef ZJ
         MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_ADD)
         cmTuUpdPeer(&zjCb.tuCb);
#endif /* ZJ */
         MaLiStuCmpReq (&s->maPstST, s->spIdTC, dlgCp->spDlgId, 0, &cmpEv, 
                        s->ctlp.mBuf);

         RETVALUE(ROK);
      }
    
   }
   
   dlgCp->dsmState = MA_DLG_WAIT_USER_REQ;

#ifdef ZJ
   MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_ADD)
#endif /* ZJ */
   RETVALUE(ROK);
 
} /* end of maOpenReqM00 */


/*
*
*       Fun:  maDelimMReqM01   
*
*       Desc:  This function handles the MAP delimeter request in
*              DSM Wait for User Request state.
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maDelimReqM01 
(
MaSap   *s              /* MAP SAP pointer */
)
#else
PRIVATE  S16 maDelimReqM01 (s)
MaSap  *s;              /* MAP SAP pointer */
#endif
{
 MaDlgCp     *dlgCp;    /* Dialogue control point */
 StDlgEv     dlgEv;     /* Dialogue Event */
 Buffer      *mBuf;     /* Message buffer */
 U8          maVer;
 S16         ret;       /* return value of the function */
#ifdef STUV2
 StDataParam dataParam;
#endif

   TRC2(maDelimReqM01)

/* ma001.203 : Addition. Initialized dataParam */
#ifdef STUV2
   cmZero((Data *) &dataParam, sizeof(StDataParam));
#endif

   dlgCp = s->curDlgCp;
   mBuf = (Buffer *)NULLP;

   if (dlgCp->apn.val[dlgCp->apn.len-1] == LMA_VER2)
   {
     maVer = LMA_VER2;
   }
   else
   {
      if (dlgCp->apn.val[dlgCp->apn.len-1] == LMA_VER1)
         maVer = LMA_VER1;
      else
#if (MAP_REL98 || MAP_REL99)
      {
         if (dlgCp->apn.val[dlgCp->apn.len-1] == LMA_VER4)
            maVer = LMA_VER4;
         else
            maVer = LMA_VER2P;
      }
#else 
         maVer = LMA_VER2P;
#endif /* MAP_REL98 || MAP_REL99 */
   }

   if ((((dlgCp->destRef.pres == TRUE) || (dlgCp->srcRef.pres == TRUE)) &&
        (maVer > LMA_VER1)) || (dlgCp->extCont.priExtLst[0].pres == TRUE) || 
       (dlgCp->usrInfo.pres == TRUE)) 
   {
      /* Build the MAP Open PDU */
     if ((ret = SGetMsg(s->maPstST.region, s->maPstST.pool, &mBuf )) != ROK)
     {
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "maOpenReqM00() failed, fail to allocate mBuf,\
       suId(%d), sapId(%d), suDlgId(%ld), spDlgId(%ld))\n", 
       s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "maOpenReqM00() failed, fail to allocate mBuf,\
       suId(%d), sapId(%d), suDlgId(%d), spDlgId(%d))\n", 
       s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
       RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
     }
     if ((maBldOpenMsg(s, mBuf)) != ROK)
     {

       /*
       ** Inside the function maBldOpenMsg we free the
       ** message buffer, so we need not free it here
       */

#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "maOpenReqM00() failed, fail to build MAP open PDU,\
       suId(%d), sapId(%d), suDlgId(%ld), spDlgId(%ld))\n", 
       s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));

       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "maOpenReqM00() failed, fail to build MAP open PDU,\
       suId(%d), sapId(%d), suDlgId(%d), spDlgId(%d))\n", 
       s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));

       RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
     }
   }

#if MAP_REL99
#if (MAP_SEC && LMAV2)

   if (s->curDlgCp->mapSec == TRUE)
   {
      if ((mBuf == (Buffer *)NULLP) && ((ret = 
       SGetMsg(s->maPstST.region, s->maPstST.pool, &mBuf )) != ROK))
      {
#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                  "maDelimReqM01() failed, fail to allocate mBuf,\
         suId(%d), sapId(%d), suDlgId(%ld), spDlgId(%ld))\n", 
         s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                  "maDelimReqM01() failed, fail to allocate mBuf,\
         suId(%d), sapId(%d), suDlgId(%d), spDlgId(%d))\n", 
         s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
         RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
      }
      if ((ret = maBldProtDlgPdu(s, mBuf)) !=ROK)
      {
         SPutMsg(mBuf);
         MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
                "maOpenReqM00() failed, unable to build protected \
                dialogue PDU.\n"));
         RETVALUE(RFAILED);
      }
   }

#endif /* MAP_SEC */
#endif
   
   if (maVer > LMA_VER1)
   {
     dlgEv.pres = TRUE;
     maBldDlgEv(s, &dlgEv, STU_DLGP_REQ);
   }
   else
   {
     dlgEv.pres = FALSE; 
   }

   if (s->trc == TRUE)
   {
     maGenTrc(s, LMA_DATA_TXED, mBuf);
   }

   s->curDlgCp->dsmState = MA_DLG_INITIATED;
#ifdef MATV3
   MA_UPD_QOS_PARAMS(s,dlgCp);
#endif

#ifdef ZJ
   MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_MOD)
   cmTuUpdPeer(&zjCb.tuCb);
#endif /* ZJ */

#ifdef STUV2
#ifdef MATV2
   if (dlgCp->imp.pres == TRUE)
   {
      dataParam.imp.pres = TRUE;
      dataParam.imp.val = dlgCp->imp.val;
      dlgCp->imp.pres = FALSE;
   }
   else
   {
      dataParam.imp.pres = FALSE;
   }
#else /* MATV2 */
   /* use the importance level which is higer that ril for BEGIN message */
   dataParam.imp.pres = TRUE;
   dataParam.imp.val = ((s->ril+1)>=MAT_IMP_VAL_7)?MAT_IMP_VAL_7:(s->ril+1);
#endif /* MATV2 */

   MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_BEGIN, dlgCp->spDlgId, 
                 dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                 FALSE, &s->qosSet, &dlgEv, &dataParam, mBuf);
#else  /* STUV2 */
   MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_BEGIN, dlgCp->spDlgId, 
                 dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                 FALSE, &s->qosSet, &dlgEv, mBuf);
#endif /* STUV2 */

   RETVALUE(ROK);

} /* End of maDelimReqM01 */

/*
*
*       Fun:  maDelimReqCom   
*
*       Desc:  This function handles the MAP delimeter request in
*              DSM Accepted or Established state.
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maDelimReqCom 
(
MaSap   *s              /* MAP SAP pointer */
)
#else
PRIVATE  S16 maDelimReqCom (s)
MaSap *s;               /* MAP SAP pointer */
#endif
{
   MaDlgCp  *dlgCp;       /* Dialogue Control point */
   StDlgEv     dlgEv;     /* Dialogue Event */
   U8       pkArray[20];
   Buffer   *mBuf;
   S16      ret;
   MsgLen   len;
   MsgLen   msglen;
#ifdef STUV2
   StDataParam  dataParam;
#endif

   TRC2(maDelimReqMCom)

/* ma001.203 : Addition. Initialized dataParam */
#ifdef STUV2
   cmZero((Data *) &dataParam, sizeof(StDataParam));
#endif

   mBuf = NULLP;
   len = 0;
   msglen = 0;
   dlgCp = s->curDlgCp;
   dlgEv.pres = FALSE;

   if ((dlgCp->dsmState == MA_DLG_IDLE) || (dlgCp->dsmState == MA_DLG_PENDING))
   {
      if (dlgCp->openRspRcvd.pres == TRUE)
      {
         maRestoreOpenRsp(dlgCp);
      }
      else
      {
         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                "maDelimReqCom() failed, event in bad state(%d).\n",\
                dlgCp->dsmState));
         RETVALUE(RFAILED);
      }
   }

   if (dlgCp->dlgEvFlg == TRUE)
   {
     dlgEv.pres = TRUE;
     maBldDlgEv(s,  &dlgEv, STU_DLGP_RSP);
     if ((dlgCp->dsmState == MA_DLG_ACCEPTED) && 
         ((dlgCp->usrInfoPres == TRUE)||
         (dlgCp->usrInfo.pres == TRUE) ||
         (dlgCp->extCont.priExtLst[0].pres == TRUE)))
     {
        /* Build the MAP Accept PDU */ 
        if ((ret = SGetMsg(s->maPstST.region, s->maPstST.pool, &mBuf )) != ROK)
        {
           dlgCp->dlgEvFlg = FALSE;
           MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                  "maDelimReqCom() failed, fail to allocate mBuf.\n"));
           RETVALUE(RFAILED);
        }
        if (dlgCp->usrInfo.pres == TRUE)
        {
           ret = SAddPstMsgMult(dlgCp->usrInfo.val, 
                           (MsgLen)dlgCp->usrInfo.len, mBuf);
           if (ret != ROK)
           {
#if (ERRCLASS & ERRCLS_ADD_RES)
              MALOGERROR(ERRCLS_ADD_RES, EMA067, (ErrVal)ret, 
                              "maDelimReqCom() Failed");
#endif 
              (Void)SPutMsg(mBuf);
              RETVALUE(ret);
           }
           dlgCp->usrInfo.pres = FALSE;
        }
        if (dlgCp->extCont.priExtLst[0].pres == TRUE) 
        {  
           /*Introduce entry MA_MI_DLGPDU in MAT_SS_RETERR type to */
           /*encode extCont with existing encode routine                  */
           if ((ret = maEncOprPar(s, (U8 *)(&(dlgCp->extCont)),
               LMA_VER2P,(U8)s->cfg.swtch,MAT_SS_RETERR,MA_MI_DLGPDU)) != ROK)
           {
#if (ERRCLASS & ERRCLS_ADD_RES)
              MALOGERROR(ERRCLS_ADD_RES, EMA068, (ErrVal)ret, 
                      "maDelimReqCom() Failed at encoding extCont");
#endif
              if (s->ctlp.mBuf != NULLP)
              {
                 (Void)SPutMsg(s->ctlp.mBuf);
              }
              (Void)SPutMsg(mBuf);
              RETVALUE(RFAILED);
           }
           maBZero((U8 *)&dlgCp->extCont, sizeof(MaExtContSeq));
           if (s->ctlp.mBuf != (Buffer *)NULLP)
           {
              (Void)SCatMsg(mBuf, s->ctlp.mBuf, M2M1);
              (Void)SPutMsg(s->ctlp.mBuf);
              s->ctlp.mBuf = (Buffer *)NULLP;
           }
        }
        (Void)SFndLenMsg(mBuf, &msglen);
        MA_ENCODE_LEN(msglen,len)
        pkArray[len++] = MA_TAG_ACCEPT_PDU;
        ret = SAddPreMsgMult(pkArray, (MsgLen)len, mBuf);
        if (ret != ROK)
        {
#if (ERRCLASS & ERRCLS_ADD_RES)
           MALOGERROR(ERRCLS_ADD_RES, EMA069, (ErrVal)ret, "SAddPreMsgMult() Failed");
#endif 
           (Void)SPutMsg(mBuf);

           RETVALUE(ret);
        }
        dlgCp->usrInfoPres = FALSE;
#if (MAP_SEC && LMAV2)
#if MAP_REL99
        if (dlgCp->mapSec != TRUE)
        {
           maBldDlgId(mBuf, FALSE);
        }
#endif
#else
        maBldDlgId(mBuf, FALSE);
#endif /* MAP_SEC */
     }
#if (MAP_SEC && LMAV2)
#if MAP_REL99
     if ((dlgCp->mapSec == TRUE) && (dlgCp->dsmState == MA_DLG_ACCEPTED))
     {
        if ( mBuf == (Buffer *)NULLP)
        {
           if ((ret = SGetMsg(s->maPstST.region, s->maPstST.pool, &mBuf )) != ROK)
           {
#ifndef ALIGN_64BIT
         
              MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                     "maDelimReqMCom() failed, fail to allocate mBuf,\
              suId(%d), sapId(%d), suDlgId(%ld), spDlgId(%ld))\n", 
              s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
              RETVALUE(RFAILED);

#else

              MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                     "maDelimReqMCom() failed, fail to allocate mBuf,\
              suId(%d), sapId(%d), suDlgId(%d), spDlgId(%d))\n", 
              s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
              RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
           }
        }
        if ((ret = maBldProtDlgPdu(s, mBuf)) != ROK)
        {
              SPutMsg(mBuf);
              MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
                     "maDelimReqCom() failed, unable to build protected \
                     dialogue PDU.\n"));
              RETVALUE(RFAILED);
         }
           s->secSts.secSapSts.openRspTx++;
      }
#endif
#endif /* MAP_SEC */
      dlgCp->dlgEvFlg = FALSE;
   }

   /* change the dialogue state to established if it is accepted */
   if(dlgCp->dsmState == MA_DLG_ACCEPTED)
   {
      dlgCp->dsmState = MA_DLG_ESTABLISHED;
   }
#ifdef MATV3
   MA_UPD_QOS_PARAMS(s,dlgCp);
#endif

#ifdef ZJ
   MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_MOD)
   cmTuUpdPeer(&zjCb.tuCb);
#endif

#ifdef STUV2
#ifdef MATV2
   if (dlgCp->imp.pres == TRUE)
   {
      dataParam.imp.pres = TRUE;
      dataParam.imp.val = dlgCp->imp.val;
      dlgCp->imp.pres = FALSE;
   }
   else
   {
      dataParam.imp.pres = FALSE;
   }
#else /* MATV2 */
   /* use the importance level which is higer that ril for CONTINUE message */
   dataParam.imp.pres = TRUE;
   dataParam.imp.val = ((s->ril+1)>=MAT_IMP_VAL_7)?MAT_IMP_VAL_7:(s->ril+1);
#endif /* MATV2 */

   MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_CONTINUE, dlgCp->spDlgId, 
                 dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                 FALSE, &s->qosSet, &dlgEv, &dataParam, mBuf);
#else
   MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_CONTINUE, dlgCp->spDlgId, 
                 dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                 FALSE, &s->qosSet, &dlgEv, mBuf);
#endif /* STUV2 */

   RETVALUE(ROK);

} /* End of maDelimReqMCom */

/*
*
*       Fun:  maCloseReqCom   
*
*       Desc:  This function handles the MAP Close request in
*              any state.
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maCloseReqCom 
(
MaSap   *s              /* MAP SAP pointer */
)
#else
PRIVATE  S16 maCloseReqCom (s)
MaSap   *s;             /* MAP SAP pointer */
#endif
{
   MaDlgCp  *dlgCp;       /* Dialogue Control point */
   StDlgEv     dlgEv;     /* Dialogue Event structure */
   MaCloseEv  *closeEv;   /* Close Event structure */
   U8         rlsFlg;     /* Release flag */
   U8         pkArray[20];
   Buffer     *mBuf;
   S16        ret;
   MsgLen     len;
   MsgLen     msglen;
#ifdef STUV2
   StDataParam dataParam;
#endif

   TRC2(maCloseReqCom)

/* ma001.203 : Addition. Initialized dataParam */
#ifdef STUV2
   cmZero((Data *) &dataParam, sizeof(StDataParam));
#endif

   mBuf = NULLP;
   len = 0;
   msglen = 0;
   dlgCp = s->curDlgCp;
   closeEv = (MaCloseEv *)(s->evtPtr);
   dlgEv.pres = FALSE;

   /*
   ** if the user has not asked for the pre-arranged release  and
   **    the dialogue state is not equal to the initiated state and 
   **    dialgoue event flag is set 
   **    then form dialogue event parameter to TCAP.
   ** Otherwise
   **    dont fill the dialogue event TCAP parameter .
   */
   if ( (closeEv->rlsCause != MAT_PREARRANGED_RELEASE) &&
        (dlgCp->dsmState   != MA_DLG_INITIATED      ) &&
        (dlgCp->dlgEvFlg   == TRUE                  )
      )
   {
     dlgEv.pres = TRUE;
     maBldDlgEv(s, &dlgEv,  STU_DLGP_RSP);
     if ((dlgCp->usrInfoPres == TRUE) && (dlgCp->dsmState == MA_DLG_ACCEPTED))
     {
        /* Build the MAP Accept PDU */ 
        if ((ret = SGetMsg(s->maPstST.region, s->maPstST.pool, &mBuf )) != ROK)
        {
           dlgCp->dlgEvFlg = FALSE;
           MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
           "maCloseReqCom() failed, fail to allocate mBuf.\n"));
           RETVALUE(RFAILED);
        }
        s->ctlp.mBuf = (Buffer *)NULLP;
        if (dlgCp->usrInfo.pres == TRUE) 
        {
           ret = SAddPstMsgMult(dlgCp->usrInfo.val, 
                                (MsgLen)dlgCp->usrInfo.len, mBuf);
           if (ret != ROK)
           {
#if (ERRCLASS & ERRCLS_ADD_RES)
              MALOGERROR(ERRCLS_ADD_RES, EMA070, (ErrVal)ret, 
                         "maCloseReqCom() Failed");
#endif
              (Void)SPutMsg(mBuf);
              RETVALUE(ret);
           }
           dlgCp->usrInfo.pres = FALSE;
        }
        if (dlgCp->extCont.priExtLst[0].pres == TRUE) 
        {
           /*Introduce entry MA_MI_DLGPDU in MAT_SS_RETERR type */
           /*to encode extCont with existing encode routine  */
           if ((ret = maEncOprPar(s, (U8 *)(&(dlgCp->extCont)),
                                  LMA_VER2P, (U8)s->cfg.swtch, MAT_SS_RETERR,
                                  MA_MI_DLGPDU)) != ROK)
           {
#if (ERRCLASS & ERRCLS_ADD_RES)
              MALOGERROR(ERRCLS_ADD_RES, EMA071, (ErrVal)ret, 
                         "maCloseReqCom() Failed at encoding extCont");
#endif
              if (s->ctlp.mBuf != NULLP)
              {
                 (Void)SPutMsg(s->ctlp.mBuf);
              }
              (Void)SPutMsg(mBuf);
              RETVALUE(RFAILED);
           }
           maBZero((U8 *)&dlgCp->extCont, sizeof(MaExtContSeq));
        }
        if (s->ctlp.mBuf != (Buffer *)NULLP)
        {
           (Void)SCatMsg(mBuf, s->ctlp.mBuf, M2M1);
           (Void)SPutMsg(s->ctlp.mBuf);
           s->ctlp.mBuf = (Buffer *)NULLP;
        }
        (Void)SFndLenMsg(mBuf, &msglen);
        MA_ENCODE_LEN(msglen,len)
        pkArray[len++] = MA_TAG_ACCEPT_PDU;
        ret = SAddPreMsgMult(pkArray, (MsgLen)len, mBuf);
         if (ret != ROK)
         {
#if (ERRCLASS & ERRCLS_ADD_RES)
            MALOGERROR(ERRCLS_ADD_RES, EMA072, (ErrVal)ret, "SAddPstMsgMult() Failed");
#endif
            (Void)SPutMsg(mBuf);
            RETVALUE(ret);
         }
        dlgCp->usrInfoPres = FALSE;
#if (MAP_SEC && LMAV2)
#if MAP_REL99
        if (dlgCp->mapSec != TRUE)
         {
            maBldDlgId(mBuf, FALSE);
         }
#endif
#else
         maBldDlgId(mBuf, FALSE);
#endif /* MAP_SEC */
     }

     dlgCp->dlgEvFlg = FALSE;
   }

   if ((dlgCp->dsmState == MA_DLG_ESTABLISHED) && 
       ((closeEv->extCont.priExtLst[0].pres == TRUE) ||
        (closeEv->usrInfo.pres == TRUE)))
   {
      /* Build the MAP Close PDU */ 
      if ((ret = SGetMsg(s->maPstST.region, s->maPstST.pool, &mBuf )) != ROK)
      {
         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                "maCloseReqCom() failed, fail to allocate mBuf.\n"));
         RETVALUE(RFAILED);
      }

      s->ctlp.mBuf = (Buffer *)NULLP;
      if (closeEv->usrInfo.pres == TRUE) 
      {
         ret = SAddPstMsgMult(closeEv->usrInfo.val, 
                             (MsgLen)closeEv->usrInfo.len, mBuf);
         if (ret != ROK)
         {
#if (ERRCLASS & ERRCLS_ADD_RES)
            MALOGERROR(ERRCLS_ADD_RES, EMA073, (ErrVal)ret, 
                       "maCloseReqCom() Failed");
#endif 
            (Void)SPutMsg(mBuf);
            RETVALUE(ret);
         }
      }
      if (closeEv->extCont.priExtLst[0].pres == TRUE) 
      {
         /*Introduce entry MA_MI_DLGPDU in MAT_SS_RETERR type to */
         /*encode extCont with existing encode routine */
         if ((ret = maEncOprPar(s, (U8 *)(&(closeEv->extCont)),
                                LMA_VER2P, (U8)s->cfg.swtch, MAT_SS_RETERR, 
                                MA_MI_DLGPDU)) != ROK)
         {
#if (ERRCLASS & ERRCLS_ADD_RES)
            MALOGERROR(ERRCLS_ADD_RES, EMA074, (ErrVal)ret, 
                       "maCloseReqCom() Failed at encoding extCont");
#endif
            if (s->ctlp.mBuf != NULLP)
            {
               (Void)SPutMsg(s->ctlp.mBuf);
            }
            (Void)SPutMsg(mBuf);
            RETVALUE(RFAILED);
         }
      }
      if (s->ctlp.mBuf != (Buffer *)NULLP)
      {
         (Void)SCatMsg(mBuf, s->ctlp.mBuf, M2M1);
         (Void)SPutMsg(s->ctlp.mBuf);
         s->ctlp.mBuf = (Buffer *)NULLP;
      }
      (Void)SFndLenMsg(mBuf, &msglen);
      MA_ENCODE_LEN(msglen,len)
      pkArray[len++] = MA_TAG_CLOSE_PDU;
      ret = SAddPreMsgMult(pkArray, (MsgLen)len, mBuf);
      if (ret != ROK)
      {
#if (ERRCLASS & ERRCLS_ADD_RES)
         MALOGERROR(ERRCLS_ADD_RES, EMA075, (ErrVal)ret, "SAddPreMsgMult() Failed");
#endif
         (Void)SPutMsg(mBuf);
         RETVALUE(ret);
      }
#if (MAP_SEC && LMAV2)
#if MAP_REL99
      if (dlgCp->mapSec != TRUE)
      {
         maBldDlgId(mBuf, FALSE);
      }
#ifndef MA_SECPDU_BUILD
      else if (dlgCp->dsmState == MA_DLG_ESTABLISHED)
      {
         maBldDlgId(mBuf, FALSE);
      }
#endif /* MAP_REL99 */
#endif
#else
      maBldDlgId(mBuf, FALSE);
#endif /* MAP_SEC */
   }

#if (MAP_SEC && LMAV2)
#if MAP_REL99

#ifndef MA_SECPDU_BUILD
   if((dlgCp->mapSec == TRUE) && 
      (dlgCp->dsmState != MA_DLG_ESTABLISHED))
#else   
   if (dlgCp->mapSec == TRUE)
#endif
   {
      ret = ROK;
      if (mBuf == (Buffer *)NULLP)
      {
         ret = SGetMsg(s->maPstST.region,s->maPstST.pool,&mBuf );
      }
      if (ret != ROK)
      {
#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                "maCloseReqCom() failed, fail to allocate mBuf,\
                suId(%d), sapId(%d), suDlgId(%ld), spDlgId(%ld))\n", 
                s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                "maCloseReqCom() failed, fail to allocate mBuf,\
                suId(%d), sapId(%d), suDlgId(%d), spDlgId(%d))\n", 
                s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
         RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
      }
      /* PASS the type as STU_END here */
      if ((ret = maBldProtDlgPdu(s, mBuf)) != ROK)
      {
         SPutMsg(mBuf);
         MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
                "maCloseReqCom() failed, unable to build protected \
                dialogue PDU.\n"));
         RETVALUE(RFAILED);
      }
   }
   if (dlgCp->mapSec == TRUE)
   {
      s->secSts.secSapSts.closeTx++;
   }
#endif
#endif /* MAP_SEC */

   /*
   ** When the dialogue is in the initiated state , then
   ** we cant do the normal close. So we have to do the
   ** pre arranged close.
   */
   if ( closeEv->rlsCause == MAT_PREARRANGED_RELEASE ||
        dlgCp->dsmState == MA_DLG_INITIATED )
   {
      rlsFlg = TRUE;
   }
   else
   {
     rlsFlg = FALSE;
   } 
#ifdef MATV3
   MA_UPD_QOS_PARAMS(s,dlgCp);
#endif

#ifdef ZJ
   MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
   cmTuUpdPeer(&zjCb.tuCb);
#endif /* ZJ */

#ifdef STUV2
#ifdef MATV2
   if (dlgCp->imp.pres == TRUE)
   {
      dataParam.imp.pres = TRUE;
      dataParam.imp.val = dlgCp->imp.val;
      dlgCp->imp.pres = FALSE;
   }
   else
   {
      dataParam.imp.pres = FALSE;
   }
#else /* MATV2 */
   /* use the highest importance level for END message */
   dataParam.imp.pres = TRUE;
   dataParam.imp.val = MAT_IMP_VAL_7;
#endif /* MATV2 */

   MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_END, dlgCp->spDlgId, 
                 dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                 rlsFlg, &s->qosSet, &dlgEv, &dataParam, mBuf);
#else
   MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_END, dlgCp->spDlgId, 
                 dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                 rlsFlg, &s->qosSet, &dlgEv, mBuf);
#endif /* STUV2 */

   RETVALUE(ROK);
} /* end of maCloseReqCom */

/*
*
*       Fun:   maAbrtReqCom    
*
*       Desc:  This function handles the Abort request from the user in
*              any state. 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maAbrtReqCom 
(
MaSap *s
)
#else
PRIVATE S16 maAbrtReqCom(s)
MaSap *s;
#endif
{
  MaAbrtEv    *abrtp;   /* pointer to abort structure */
  Buffer      *mBuf;    /* Message Buffer */
  StDlgEv     dlgEv;    /* Dialogue Event strcuture */
  MaDlgCp     *dlgCp;   /* Dialogue control point */
  MsgLen      msgLen;   /* Message Length */
  MsgLen      curLen;   /* Message Length */
  U8          maVer;    /* MAP Version */
  Data        pkArray[20];
  S16         ret;
  MsgLen      len;
#ifdef STUV2
  StDataParam dataParam;
#endif

  TRC2(maAbrtReqCom)

/* ma001.203 : Addition. Initialized dataParam */
#ifdef STUV2
   cmZero((Data *) &dataParam, sizeof(StDataParam));
#endif

  len = 0;
  abrtp = (MaAbrtEv *)(s->evtPtr);
  dlgEv.pres = FALSE;

  dlgCp = s->curDlgCp;
  if (dlgCp->endFlg == TRUE)
     RETVALUE (ROK); /* no need for an abort for the remote in this case */

  if ((ret = SGetMsg(s->maPstST.region, s->maPstST.pool, &mBuf )) != ROK)
  {
    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "maAbrtReqCom() failed, fail to allocate mBuf.\n"));
    RETVALUE(RFAILED);
  }

  if (dlgCp->apn.val[dlgCp->apn.len-1] != LMA_VER1)
  {
     maVer = dlgCp->apn.val[dlgCp->apn.len-1];
     dlgEv.pres = TRUE;
     maBldDlgEv(s, &dlgEv,  STU_DLGP_ABT); 
  }
  else
  {
     maVer = LMA_VER1;
  }

  if (abrtp->usrInfo.pres == TRUE) 
  {
     ret = SAddPstMsgMult(abrtp->usrInfo.val, 
                          (MsgLen)abrtp->usrInfo.len, mBuf);
     if (ret != ROK)
     {
#if (ERRCLASS & ERRCLS_ADD_RES)
        MALOGERROR(ERRCLS_ADD_RES, EMA076, (ErrVal)ret, 
                   "maAbrtReqCom() Failed");
#endif
        (Void)SPutMsg(mBuf);
        RETVALUE(ret);
     }
  }
  if (abrtp->extCont.priExtLst[0].pres == TRUE) 
  {
     /*Introduce entry MA_MI_DLGPDU in MAT_SS_RETERR type to */
     /*encode extCont with existing encode routine                  */
     if ((ret = maEncOprPar(s, (U8 *)(&(abrtp->extCont)),
                            LMA_VER2P, (U8)s->cfg.swtch, MAT_SS_RETERR, 
                            MA_MI_DLGPDU)) != ROK)
     {
#if (ERRCLASS & ERRCLS_ADD_RES)
        MALOGERROR(ERRCLS_ADD_RES, EMA077, (ErrVal)ret, 
                   "maAbrtReqCom () Failed at encoding extCont");
#endif
        if (s->ctlp.mBuf != NULLP)
        {
           (Void)SPutMsg(s->ctlp.mBuf);
        }
        (Void)SPutMsg(mBuf);
        RETVALUE(RFAILED);
     }
     if (s->ctlp.mBuf != (Buffer *)NULLP)
     {
        (Void)SCatMsg(mBuf, s->ctlp.mBuf, M2M1);
        (Void)SPutMsg(s->ctlp.mBuf);
        s->ctlp.mBuf = (Buffer *)NULLP;
     }
  }
  (Void)SFndLenMsg(mBuf, &len);

  msgLen = 0; 
  switch (abrtp->abrtReason)
  {
     case MAT_ABRT_USR_SPECIFIC:
          pkArray[msgLen++] = (Data)0;
          pkArray[msgLen++] = (Data)MA_TAG_ABRT_USR_SPECIFIC;
       break;
     case MAT_ABRT_RESLIMIT:
          pkArray[msgLen++] = (Data)0;
          pkArray[msgLen++] = (Data)MA_TAG_ABRT_RESLIMIT;
          break;
     case MAT_ABRT_RESUNAVAIL:
          pkArray[msgLen++] = (Data)abrtp->diagInfo;
          pkArray[msgLen++] = (Data)1;
          pkArray[msgLen++] = (Data)MA_TAG_ABRT_RESUNAVAIL;
        break;
     case MAT_ABRT_APC:
          pkArray[msgLen++] = (Data)abrtp->diagInfo;
          pkArray[msgLen++] = (Data)1;
          pkArray[msgLen++] = (Data)MA_TAG_ABRT_APC;
          break;
     default :
#if (ERRCLASS & ERRCLS_INT_PAR)
         MALOGERROR(ERRCLS_INT_PAR, EMA078, (ErrVal)abrtp->abrtReason, "maAbrtReqCom () Failed");
#endif
         (Void)SPutMsg(mBuf);

        RETVALUE(RFAILED);  
        break;
  }
  curLen = msgLen + len;
  MA_ENCODE_LEN(curLen,msgLen)
  pkArray[msgLen++] = (Data)MA_TAG_USRABRT_PDU; 
  ret = SAddPreMsgMult(pkArray, (MsgLen)msgLen, mBuf);

  if (ret != ROK)
  {
#if (ERRCLASS & ERRCLS_ADD_RES)
    MALOGERROR(ERRCLS_ADD_RES, EMA079, (ErrVal)ret, "maAbrtReqCom () Failed");
#endif
    (Void)SPutMsg(mBuf);
    RETVALUE(RFAILED);
  }


#if (MAP_SEC && LMAV2)
#if MAP_REL99
  if (dlgCp->mapSec == TRUE)
  {
     /* Pass the type as STU_U_ABORT here */
#ifdef MA_SECPDU_BUILD
     if ((ret = maBldProtDlgPdu(s, mBuf)) != ROK)
#else
     if ((ret = maBldDlgId(mBuf,FALSE)) != ROK)
#endif
     {
        SPutMsg(mBuf);
        MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
               "maAbrtReqCom() failed, unable to build protected \
                dialogue PDU.\n"));
        RETVALUE(RFAILED);
     }
     s->secSts.secSapSts.abrtTx++;
  }
  else if (maVer != LMA_VER1)
  {
     maBldDlgId(mBuf, FALSE);
  }
#endif
#else
  if (maVer != LMA_VER1)
  {
     maBldDlgId(mBuf, FALSE);
  }
#endif /* MAP_SEC */

  if (s->trc == TRUE)
  {
     maGenTrc(s, LMA_DATA_TXED, mBuf);
  }
#ifdef MATV3
   MA_UPD_QOS_PARAMS(s,dlgCp);
#endif

#ifdef ZJ
   MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
   cmTuUpdPeer(&zjCb.tuCb);
#endif /* ZJ */

#ifdef STUV2
#ifdef MATV2
  if (dlgCp->imp.pres == TRUE)
  {
     dataParam.imp.pres = TRUE;
     dataParam.imp.val = dlgCp->imp.val;
     dlgCp->imp.pres = FALSE;
  }
  else
  {
     dataParam.imp.pres = FALSE;
  }
#else /* MATV2 */
  /* use the highest importance level for END message */
  dataParam.imp.pres = TRUE;
  dataParam.imp.val = MAT_IMP_VAL_7;
#endif /* MATV2 */

  MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_U_ABORT, dlgCp->spDlgId, 
                dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                FALSE, &s->qosSet, &dlgEv, &dataParam, mBuf);
#else
  MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_U_ABORT, dlgCp->spDlgId, 
                dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                FALSE, &s->qosSet, &dlgEv, mBuf);
#endif /* STUV2 */
  RETVALUE(ROK);
} /* maAbrtReqCom */

/*
*
*       Fun:   maInvEv    
*
*       Desc:  This function handles the event in bad state   
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maInvEv 
(
 MaSap     *s           /* Map SAP */
)
#else
PRIVATE S16 maInvEv (s)
 MaSap     *s;          /* Map SAP */
#endif
{
  TRC2(maInvEv)
  MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "maInvEv() failed, event in bad state(%d).\n", s->curDlgCp->dsmState));
  RETVALUE(RFAILED);
} /* maInvEv  */

/*
*
*       Fun:   maInvPdu    
*
*       Desc:  This function handles the Invalid PDU   
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maInvPdu 
(
 MaSap     *s           /* Map SAP */
)
#else
PRIVATE S16 maInvPdu (s)
 MaSap     *s;          /* Map SAP */
#endif
{
  TRC2(maInvPdu)
  /* just Return from this function */
  RETVALUE(ROK);
} /* mamaInvPdu  */

/*
*
*       Fun:   maAbrtM03    
*
*       Desc:  This function handles the Abort in Dialogue initiated state
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maAbrtM03 
(
 MaSap  *s      /* Map Sap Pointer */
)
#else
PRIVATE S16 maAbrtM03 (s)
 MaSap  *s;     /* Map Sap Pointer */
#endif
{
  MaDlgCp *dlgCp;
  MaOpenEv openEv;
  MaAbrtEv abrtEv;
  StDlgEv  *dlgEv;
  Buffer   *mBuf;
  Data     tag;
  S16      ret;
  MaDlgId  tmpSuDlgId;        /* temporary Service user Dlg Id */
  MaDlgId  tmpSpDlgId;        /* temporary Service provider Dlg Id */
  MsgLen   len;
#ifdef ZJ
  Bool     rtUpd;
#endif

  TRC2(maAbrtM03)
 
  tag = 0;
  dlgCp = s->curDlgCp;
  tmpSuDlgId = dlgCp->suDlgId;    
  tmpSpDlgId = dlgCp->spDlgId;    
#ifdef ZJ
  rtUpd = dlgCp->upd;
#endif


  if (dlgCp->tcAbrtType == STU_P_ABORT)
  {
    if (dlgCp->tcAbrtCause.octet == STU_ABORT_INC_TRANS)
    {
#if MAP_REL99
#if (MAP_SEC && LMAV2)
       if (dlgCp->mapSec == TRUE)
       {
          s->secSts.secSapSts.openRspRx++;
          if (dlgCp->saCp->sa.txFbInd != TRUE)
          {
             maBZero((U8 *)&openEv, sizeof (MaOpenEv));
             openEv.result = MAT_DLG_REFUSED;
             openEv.refReason.pres = TRUE;
             openEv.refReason.val = MAT_SEC_TRANS_NOT_PBLE;
             cmCopy((U8 *)&dlgCp->srcAddr, (U8 *)&openEv.srcAddr, 
                    sizeof(SpAddr)); 
             cmCopy((U8 *)&dlgCp->destAddr, (U8 *)&openEv.destAddr, 
                    sizeof(SpAddr)); 
#ifdef ZJ
             MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
             MA_UPD_PEER(rtUpd)
#endif /* ZJ */
             maDlgIdle(s);
             MaUiMatOpenCfm(&s->maPstMU, s->suId, tmpSuDlgId, tmpSpDlgId, 
                            &openEv);
             RETVALUE(ROK);
          }
          else
          {
             dlgCp->mapSec       = FALSE;
             dlgCp->lowerSpDlgId = 0;
             if (dlgCp->saCp != NULLP)
             {
                maRemSaDlg(dlgCp, dlgCp->saCp);
             }
             while(dlgCp->cmpLst != (MaCmpStd *)NULLP)
             {
                maRestoreReq(s, dlgCp);
                s->secSts.nmbFbAtmpt++;
             }
             dlgCp->dsmState = MA_DLG_WAIT_USER_REQ;
#ifdef ZJ
             MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_MOD)
             MA_UPD_PEER(rtUpd)
#endif /* ZJ */
             if ((ret = (*maDSMTbl[MA_EV_DELIM_REQ][dlgCp->dsmState]) (s)) != 
                  ROK)
             {
                MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                       "maAbrtM03() failed, invalid dialog state(%d).\n", 
                       dlgCp->dsmState));
                RETVALUE(RFAILED);
             }
             RETVALUE(ROK); 
          }
       }
#endif /* MAP_SEC */
#endif
       maBZero((U8 *)&openEv, sizeof (MaOpenEv));
       openEv.result = MAT_DLG_REFUSED;
       openEv.refReason.pres = TRUE;
       openEv.refReason.val = MAT_POT_VER_INCOMP;
#if MAP_REL99
#if (MAP_SEC && LMAV2)
       if (dlgCp->mapSec == FALSE)
#endif
#endif
       s->sts.openRspRx++;
       cmCopy((U8 *)&dlgCp->srcAddr, (U8 *)&openEv.srcAddr, sizeof(SpAddr)); 
       cmCopy((U8 *)&dlgCp->destAddr, (U8 *)&openEv.destAddr, sizeof(SpAddr)); 
#ifdef ZJ
       MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(rtUpd)
#endif /* ZJ */
       maDlgIdle(s);
       MaUiMatOpenCfm(&s->maPstMU, s->suId, tmpSuDlgId, tmpSpDlgId, &openEv);
       RETVALUE(ROK);
    }
    else 
    {
      maBZero((U8 *)&abrtEv, sizeof (MaAbrtEv));
      /* send the provider abort to MAp user */
      abrtEv.abrtSrc = MAT_PROV_ABRT;

      abrtEv.abrtPSrc = MAT_PABRT_TC;
      switch(dlgCp->tcAbrtCause.octet)
      {
        case STU_ABORT_UNREC_MSG:
        case STU_ABORT_ABNML_DLG:
        case STU_ABORT_BAD_FRMT:
          abrtEv.abrtReason = MAT_PROV_MALFUNC; 
          break; 
        case STU_ABORT_UNREC_TRS:
          abrtEv.abrtReason = MAT_SUP_DLG_RLS; 
          break; 
        case STU_ABORT_RESOURCE:
          abrtEv.abrtReason = MAT_RSRS_LIMIT; 
          break; 
        case STU_ABORT_NO_CMN_DLG:
          abrtEv.abrtReason = MAT_VER_INCOMP; 
          break; 
        default:
          abrtEv.abrtReason = MAT_PROV_MALFUNC; 
          break; 
   
      }
#if MAP_REL99
#if MAP_SEC
      if (dlgCp->mapSec == TRUE)
      {
         s->secSts.secSapSts.abrtRx++;
      }
#endif
#endif
#ifdef ZJ
      MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
      MA_UPD_PEER(rtUpd)
#endif /* ZJ */
      maDlgIdle(s);
      MaUiMatAbrtInd(&s->maPstMU, s->suId, tmpSuDlgId, tmpSpDlgId, &abrtEv);
      RETVALUE(ROK);
    }
  }
  else
  {
    if ( dlgCp->apn.val[dlgCp->apn.len -1] == LMA_VER1) 
    {
       maBZero((U8 *)&openEv, sizeof (MaOpenEv));
       openEv.result = MAT_DLG_REFUSED;
       openEv.refReason.pres = TRUE;
       openEv.refReason.val = MAT_POT_VER_INCOMP;
#if MAP_REL99
#if (MAP_SEC && LMAV2)
       if (dlgCp->mapSec == FALSE)
#endif
#endif
       s->sts.openRspRx++;
       cmCopy((U8 *)&dlgCp->srcAddr, (U8 *)&openEv.srcAddr, sizeof(SpAddr)); 
       cmCopy((U8 *)&dlgCp->destAddr, (U8 *)&openEv.destAddr, sizeof(SpAddr)); 
#ifdef ZJ
       MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(rtUpd)
#endif /* ZJ */
       maDlgIdle(s);
       MaUiMatOpenCfm(&s->maPstMU, s->suId, tmpSuDlgId, tmpSpDlgId, &openEv);
       RETVALUE(ROK);
    }
    else
    {
      dlgEv = (StDlgEv *)(s->evtPtr);
      if ((dlgEv->resReason == ST_DLG_RSD_NOACN) &&
             (dlgEv->resSrc == ST_DLG_SU_TAG))
      {
#if MAP_REL99
#if (MAP_SEC && LMAV2)
         if (dlgCp->mapSec == TRUE)
         {
            s->secSts.secSapSts.openRspRx++;

            if (dlgCp->saCp->sa.txFbInd != TRUE)
            {
               maBZero((U8 *)&openEv, sizeof (MaOpenEv));
               openEv.result = MAT_DLG_REFUSED;
               openEv.refReason.pres = TRUE;
               openEv.refReason.val = MAT_SEC_TRANS_NOT_PBLE;
               cmCopy((U8 *)&dlgCp->srcAddr, (U8 *)&openEv.srcAddr, 
                      sizeof(SpAddr)); 
               cmCopy((U8 *)&dlgCp->destAddr, (U8 *)&openEv.destAddr, 
                      sizeof(SpAddr)); 
#ifdef ZJ
               MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
               MA_UPD_PEER(rtUpd)
#endif /* ZJ */
               maDlgIdle(s);
               MaUiMatOpenCfm(&s->maPstMU, s->suId, tmpSuDlgId, tmpSpDlgId, 
                              &openEv);
               RETVALUE(ROK);
            }
            else
            {
               dlgCp->mapSec = FALSE;
               dlgCp->lowerSpDlgId = 0;
               if (dlgCp->saCp != NULLP)
               {
                  maRemSaDlg(dlgCp, dlgCp->saCp);
               }
               while(dlgCp->cmpLst != (MaCmpStd *)NULLP)
               {
                  maRestoreReq(s, dlgCp);
                  s->secSts.nmbFbAtmpt++;
               }
               dlgCp->dsmState = MA_DLG_WAIT_USER_REQ;
#ifdef ZJ
               MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_MOD)
               MA_UPD_PEER(rtUpd)
#endif /* ZJ */
               if ((ret = (*maDSMTbl[MA_EV_DELIM_REQ][dlgCp->dsmState])(s)) != 
                    ROK)
               {
                  MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                         "maAbrtM03() failed, invalid dialog state(%d).\n", 
                         dlgCp->dsmState));
                  RETVALUE(RFAILED);
               }
               RETVALUE(ROK); 
            }
         }
#endif /* MAP_SEC */
#endif
        maBZero((U8 *)&openEv, sizeof (MaOpenEv));
        openEv.apn.pres = TRUE;
        maConvertACN(&dlgEv->apConName);
        openEv.apn.len = (U8)dlgEv->apConName.len;

        cmCopy((U8 *)&dlgEv->apConName.string[0],
               (U8 *)&openEv.apn.val[0], dlgEv->apConName.len);
        openEv.result = MAT_DLG_REFUSED;
        openEv.refReason.pres = TRUE;
        openEv.refReason.val = MAT_ACN_NOT_SUPPORTED;
#if MAP_REL99
#if (MAP_SEC && LMAV2)
        if (dlgCp->mapSec == FALSE)
#endif
#endif
        s->sts.openRspRx++;

        cmCopy((U8 *)&dlgCp->srcAddr, 
               (U8 *)&openEv.srcAddr, sizeof(SpAddr)); 

        cmCopy((U8 *)&dlgCp->destAddr, 
               (U8 *)&openEv.destAddr, sizeof(SpAddr)); 

#ifdef ZJ
        MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
        MA_UPD_PEER(rtUpd)
#endif /* ZJ */
        maDlgIdle(s);
        MaUiMatOpenCfm(&s->maPstMU, s->suId, tmpSuDlgId, tmpSpDlgId, &openEv);
        RETVALUE(ROK);
      }
#if MAP_REL99
#if (MAP_SEC && LMAV2)
      if (dlgCp->mapSec == TRUE)
      {
         len = 0;
         if(s->crntRxMsg != (Buffer *)NULLP)
         {
            SFndLenMsg(s->crntRxMsg,&len);
         }
         if ((s->crntRxMsg != (Buffer *)NULLP) && (len > 0))
         {
            mBuf = s->crntRxMsg;
            /* Decode the protected dialogue PDU */
            if( (ret = maDecProtDlgPdu(s, s->crntRxMsg, FALSE)) != ROK)
            {
#if (ERRCLASS & ERRCLS_DEBUG)
               SPrntMsg(mBuf,0,0);
               MALOGERROR(ERRCLS_DEBUG, EMA080, (ErrVal)0, 
                         "Bad protected PDU received in maAbrtM03");
#endif
               goto error;

            }
            /* Now, we have MAP dialogue PDU in s->crntRxMsg if it is 
             * present. s->crntRxMsg will be NULL if it is not present.
             */
         }
      }
#endif
#endif
      len = 0;
      if(s->crntRxMsg != (Buffer *)NULLP)
      {
         SFndLenMsg(s->crntRxMsg,&len);
      }
      if ((s->crntRxMsg != (Buffer *)NULLP) && (len > 0))
      {
        mBuf = s->crntRxMsg;

#if (MAP_SEC && LMAV2)
#if MAP_REL99
        if (dlgCp->mapSec != TRUE)
        {
           if ((ret = maDecDlgId(mBuf)) != ROK)
           {
#if (ERRCLASS & ERRCLS_DEBUG)
              SPrntMsg(mBuf,0,0);
              MALOGERROR(ERRCLS_DEBUG, EMA081, (ErrVal)tag, 
              "Bad PDU received in maAbrtM03");
#endif
              goto error;
           }
        }
#endif 
#else  /* MAP_SEC && LMAV2 */
        if ((ret = maDecDlgId(mBuf)) != ROK)
        {
#if (ERRCLASS & ERRCLS_DEBUG)
          SPrntMsg(mBuf,0,0);
          MALOGERROR(ERRCLS_DEBUG, EMA082, (ErrVal)tag, 
          "Bad PDU received in maAbrtM03");
#endif
          goto error;
       }
#endif /* MAP_SEC */

       if ((ret = SExamMsg(&tag, mBuf, 0)) != ROK)
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         SPrntMsg(mBuf,0,0);
         MALOGERROR(ERRCLS_DEBUG, EMA083, (ErrVal)tag, 
         "Bad PDU received in maAbrtM03");
#endif
         goto error;
       }
       if (tag == MA_TAG_REFUSE_PDU)
       {
          maBZero((U8 *)&openEv, sizeof (MaOpenEv));
          openEv.result = MAT_DLG_REFUSED;
          openEv.refReason.pres = TRUE;
          maDecRefPdu(s, &openEv, &dlgEv->apConName);
#if MAP_REL99
#if (MAP_SEC && LMAV2)
          cmCopy(&dlgEv->apConName.string[0], &openEv.apn.val[0], 
                 dlgEv->apConName.len); 
          if (openEv.refReason.val == MAT_ENCACN_NOT_SUPPORTED)
          {
             openEv.refReason.val = MAT_ACN_NOT_SUPPORTED;
          }
          if (dlgCp->mapSec == FALSE)
#endif
#endif
          s->sts.openRspRx++;
          /* Send the confirm with no reason given */
          openEv.result = MAT_DLG_REFUSED;
          cmCopy((U8 *)&dlgCp->srcAddr, (U8 *)&openEv.srcAddr, sizeof(SpAddr)); 
          cmCopy((U8 *)&dlgCp->destAddr, (U8 *)&openEv.destAddr, sizeof(SpAddr)); 
#ifdef ZJ
          MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
          MA_UPD_PEER(rtUpd)
#endif /* ZJ */
          maDlgIdle(s);
          MaUiMatOpenCfm(&s->maPstMU, s->suId, tmpSuDlgId, tmpSpDlgId, &openEv);
          RETVALUE(ROK);
       }
       else if (tag == MA_TAG_USRABRT_PDU)
       {
          maBZero((U8 *)&abrtEv, sizeof (MaAbrtEv));
          abrtEv.abrtSrc = MAT_USR_ABRT;
          if ((ret = maDecAbrtPdu(s, &abrtEv)) != ROK)
          { 
#if (ERRCLASS & ERRCLS_DEBUG)
            SPrntMsg(mBuf,0,0);
            MALOGERROR(ERRCLS_DEBUG, EMA084, (ErrVal)tag, 
            "Bad PDU received in maAbrtM03");
#endif
            goto error;
          }
#ifdef ZJ
          MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
          MA_UPD_PEER(rtUpd)
#endif /* ZJ */
          maDlgIdle(s);
          MaUiMatAbrtInd(&s->maPstMU, s->suId, tmpSuDlgId, 
                     tmpSpDlgId, &abrtEv);
       }
       else
       {
          maBZero((U8 *)&abrtEv, sizeof (MaAbrtEv));
          abrtEv.abrtSrc = MAT_PROV_ABRT;
          abrtEv.abrtPSrc = MAT_PABRT_MAP;
          if ((ret = maDecAbrtPdu(s, &abrtEv)) != ROK)
          {
#if (ERRCLASS & ERRCLS_DEBUG)
            SPrntMsg(mBuf,0,0);
            MALOGERROR(ERRCLS_DEBUG, EMA085, (ErrVal)tag, 
            "Bad PDU received in maAbrtM03");
#endif
            goto error;
          }
#ifdef ZJ
          MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
          MA_UPD_PEER(rtUpd)
#endif /* ZJ */
          maDlgIdle(s);
          MaUiMatAbrtInd(&s->maPstMU, s->suId, tmpSuDlgId, 
                     tmpSpDlgId, &abrtEv);
       } 
     }
     else
     { 
        maBZero((U8 *)&openEv, sizeof (MaOpenEv));
        openEv.result = MAT_DLG_REFUSED;
        openEv.refReason.pres = TRUE;
        openEv.refReason.val = MAT_POT_VER_INCOMP;
#if MAP_REL99
#if (MAP_SEC && LMAV2)
        if (dlgCp->mapSec == FALSE)
#endif
#endif
        s->sts.openRspRx++;
        cmCopy((U8 *)&dlgCp->srcAddr, (U8 *)&openEv.srcAddr, sizeof(SpAddr)); 
        cmCopy((U8 *)&dlgCp->destAddr, (U8 *)&openEv.destAddr, sizeof(SpAddr)); 
#ifdef ZJ
        MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
        MA_UPD_PEER(rtUpd)
#endif /* ZJ */
        maDlgIdle(s);
        MaUiMatOpenCfm(&s->maPstMU, s->suId, tmpSuDlgId, tmpSpDlgId, &openEv);
        RETVALUE(ROK);
     }
    }
  }
#ifdef ZJ
  MA_UPD_PEER(rtUpd)
#endif /* ZJ */

  RETVALUE(ROK);
error:

  maBZero((U8 *)&abrtEv, sizeof (MaAbrtEv));
  abrtEv.abrtSrc = MAT_PROV_ABRT;
  abrtEv.abrtPSrc = MAT_PABRT_MAP;
  abrtEv.abrtReason = MAT_P_ABNORMAL_DLG;
#ifdef ZJ
  MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
  MA_UPD_PEER(rtUpd)
#endif /* ZJ */
  maDlgIdle(s);
  MaUiMatAbrtInd(&s->maPstMU, s->suId, tmpSuDlgId, tmpSpDlgId, &abrtEv);
  RETVALUE(RFAILED);
} /* maAbrtM03  */

/*
*
*       Fun:   maAbrtCom    
*
*       Desc:  This function handles the abort in dialogue aceepted and established state
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maAbrtCom 
(
 MaSap  *s      /* Map Sap Pointer */
)
#else
PRIVATE S16 maAbrtCom (s)
 MaSap  *s;     /* Map Sap Pointer */
#endif
{
  MaDlgCp   *dlgCp;
  MaAbrtEv  abrtEv;
  Buffer    *mBuf;
  Data      tag;
  S16       ret;
  MaDlgId  tmpSuDlgId;        /* temporary Service user Dlg Id */
  MaDlgId  tmpSpDlgId;        /* temporary Service provider Dlg Id */
  MsgLen   len; 
#ifdef ZJ
  Bool     rtUpd;
#endif
  
  TRC2(maAbrtCom)

  tag = 0;
  dlgCp = s->curDlgCp;
  tmpSuDlgId = dlgCp->suDlgId;    
  tmpSpDlgId = dlgCp->spDlgId;    
#ifdef ZJ
  rtUpd = dlgCp->upd;
#endif
  maBZero((U8 *)&abrtEv, sizeof (MaAbrtEv));
#if MAP_REL99
#if MAP_SEC
  if (dlgCp->mapSec == TRUE)
  {
     s->secSts.secSapSts.abrtRx++;
  }
#endif
#endif

  if (dlgCp->tcAbrtType == STU_P_ABORT)
  {
    abrtEv.abrtSrc = MAT_PROV_ABRT; 
    abrtEv.abrtPSrc = MAT_PABRT_TC;
    switch(dlgCp->tcAbrtCause.octet)
    {
      case STU_ABORT_UNREC_MSG:
         abrtEv.abrtReason = MAT_PROV_MALFUNC; 
        break; 
      case STU_ABORT_UNREC_TRS:
         abrtEv.abrtReason = MAT_SUP_DLG_RLS; 
        break; 
      case STU_ABORT_BAD_FRMT:
         abrtEv.abrtReason = MAT_PROV_MALFUNC; 
        break; 
      case STU_ABORT_INC_TRANS:
         abrtEv.abrtReason = MAT_PROV_MALFUNC; 
        break; 
      case STU_ABORT_RESOURCE:
         abrtEv.abrtReason = MAT_RSRS_LIMIT; 
        break; 
      case STU_ABORT_ABNML_DLG:
         abrtEv.abrtReason = MAT_PROV_MALFUNC; 
        break; 
      case STU_ABORT_NO_CMN_DLG:
         abrtEv.abrtReason = MAT_VER_INCOMP; 
        break; 
    }
#ifdef ZJ
    MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
    MA_UPD_PEER(rtUpd)
#endif /* ZJ */
    maDlgIdle(s);
    MaUiMatAbrtInd(&s->maPstMU, s->suId, tmpSuDlgId, tmpSpDlgId, &abrtEv);
  }
  else
  {
    abrtEv.abrtSrc = MAT_USR_ABRT; 
    mBuf   = s->crntRxMsg;
    len = 0;
    if(s->crntRxMsg != (Buffer *)NULLP)
    {
       SFndLenMsg(s->crntRxMsg,&len);
    }
    if ((mBuf != NULLP) && (len > 0))
    {
#if (MAP_SEC && LMAV2)
#if MAP_REL99
      if (dlgCp->mapSec == TRUE)
      {
        /* Decode the protected dialogue PDU */
        if( (ret = maDecProtDlgPdu(s, s->crntRxMsg, FALSE)) != ROK)
        {
#if (ERRCLASS & ERRCLS_DEBUG)
           SPrntMsg(mBuf,0,0);
           MALOGERROR(ERRCLS_DEBUG, EMA086, (ErrVal)0, 
                      "Bad protected PDU received in maAbrtM03");
#endif
           goto error;
        }
        /* Now, we have MAP dialogue PDU in s->crntRxMsg if it is 
         * present. s->crntRxMsg will be NULL if it is not present.
         */
      }
      else
      {
         if ((ret = maDecDlgId(mBuf)) != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            SPrntMsg(mBuf,0,0);
            MALOGERROR(ERRCLS_DEBUG, EMA087, (ErrVal)tag, 
                       "Bad PDU received in maAbrtCom");
#endif
            goto error;
         }
      }
#endif  /* MAP_REL99 */
#else

      if ((ret = maDecDlgId(mBuf)) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
        SPrntMsg(mBuf,0,0);
        MALOGERROR(ERRCLS_DEBUG, EMA088, (ErrVal)tag, 
                   "Bad PDU received in maAbrtCom");
#endif
        goto error;
      }
#endif /* MAP_SEC */

      if ((ret = SExamMsg(&tag, mBuf, 0)) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         SPrntMsg(mBuf,0,0);
         MALOGERROR(ERRCLS_DEBUG, EMA089, (ErrVal)tag, 
                    "Bad PDU received in maAbrtCom");
#endif
         goto error;
      }
      if (tag == MA_TAG_USRABRT_PDU)
      {
        abrtEv.abrtSrc = MAT_USR_ABRT; 
        if ((ret = maDecAbrtPdu(s, &abrtEv)) != ROK)               
        {                                            
#if (ERRCLASS & ERRCLS_DEBUG)                       
           SPrntMsg(mBuf,0,0);                       
           MALOGERROR(ERRCLS_DEBUG, EMA090, (ErrVal)tag,
                      "Bad PDU received in maAbrtCom");
#endif                                                
           goto error;                               
        }                                           
      }
      else
      {
        abrtEv.abrtSrc = MAT_PROV_ABRT; 
        abrtEv.abrtPSrc = MAT_PABRT_NET; 
        if ((ret = maDecAbrtPdu(s, &abrtEv)) != ROK)
        {
#if (ERRCLASS & ERRCLS_DEBUG)
           SPrntMsg(mBuf,0,0);
           MALOGERROR(ERRCLS_DEBUG, EMA091, (ErrVal)tag, 
                      "Bad PDU received in maAbrtCom");
#endif
           goto error;
        }
      }
       
    } 
#ifdef ZJ
    MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
    MA_UPD_PEER(rtUpd)
#endif /* ZJ */
    maDlgIdle(s);
    MaUiMatAbrtInd(&s->maPstMU, s->suId, tmpSuDlgId, tmpSpDlgId, &abrtEv);
  }

#ifdef ZJ
   MA_UPD_PEER(rtUpd)
#endif /* ZJ */
  RETVALUE(ROK);
error:
  abrtEv.abrtSrc = MAT_PROV_ABRT; 
  abrtEv.abrtPSrc = MAT_PABRT_TC;
  abrtEv.abrtReason = MAT_PROV_MALFUNC; 
#ifdef ZJ
  MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
  MA_UPD_PEER(rtUpd)
#endif /* ZJ */
  maDlgIdle(s);
  MaUiMatAbrtInd(&s->maPstMU, s->suId, tmpSuDlgId, tmpSpDlgId, &abrtEv);
  RETVALUE(RFAILED);
} /* maAbrtCom  */


/*
*
*       Fun:   maEndCom    
*
*       Desc:  This function handles  the End from TCAP in dialogue 
*              established and accepted state.
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maEndCom 
(
 MaSap  *s      /* Map Sap Pointer */
)
#else
PRIVATE S16 maEndCom (s)
 MaSap  *s;     /* Map Sap Pointer */
#endif
{
  MaDlgCp  *dlgCp;
  MaCloseEv closeEv;
  MaDlgId  tmpSuDlgId;        /* temporary Service user Dlg Id */
  MaDlgId  tmpSpDlgId;        /* temporary Service provider Dlg Id */
  U32      i;
  Buffer   *mBuf;
  U8       tag;
  S16      ret;
  Bool     eocFlg;
  MsgLen   len;
#ifdef ZJ
  Bool     rtUpd;
#endif

  TRC2(maEndCom)

  tag = 0;
  dlgCp = s->curDlgCp;
#ifdef ZJ
  rtUpd = dlgCp->upd;
#endif
  maBZero((U8 *)&closeEv, sizeof (MaCloseEv));
#if MAP_REL99
#if MAP_SEC
  if (dlgCp->mapSec == TRUE)
  {
     s->secSts.secSapSts.closeRx++;
  }
#endif
#endif


  len = 0;
  if(s->crntRxMsg != (Buffer *)NULLP)
  {
     SFndLenMsg(s->crntRxMsg,&len);
  }
  /* protected dialogue PDU is mandatory for secure transport */
  if ((s->crntRxMsg != (Buffer *)NULLP) && (len > 0))
  {
     dlgCp->closePduPres = TRUE;
     mBuf = s->crntRxMsg;
#if (MAP_SEC && LMAV2)
#if MAP_REL99
      if (dlgCp->mapSec == TRUE)
      {
        /* Decode the protected dialogue PDU */
        if( (ret = maDecProtDlgPdu(s, s->crntRxMsg, FALSE)) != ROK)
        {
#if (ERRCLASS & ERRCLS_DEBUG)
           SPrntMsg(mBuf,0,0);
           MALOGERROR(ERRCLS_DEBUG, EMA092, (ErrVal)0, 
                      "Bad protected PDU received in maAbrtM03");
#endif
           RETVALUE(RFAILED);
        }
        /* Now, we have MAP dialogue PDU in s->crntRxMsg if it is 
         * present. s->crntRxMsg will be NULL if it is not present.
         */
      }
      else
      {
         if ((ret = maDecDlgId(mBuf)) != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            SPrntMsg(mBuf,0,0);
            MALOGERROR(ERRCLS_DEBUG, EMA093, (ErrVal)tag, 
                       "Bad PDU received in maAbrtCom");
#endif
            RETVALUE(RFAILED);
         }
      }
#endif  /* MAP_REL99 */
#else

     if ((ret = maDecDlgId(mBuf)) != ROK)
     {
#if (ERRCLASS & ERRCLS_DEBUG)
        SPrntMsg(mBuf,0,0);
        MALOGERROR(ERRCLS_DEBUG, EMA094, (ErrVal)tag, "Bad PDU received in maEndCom");
#endif
        RETVALUE(RFAILED);
     }
#endif /* MAP_SEC */

     (Void)SFndLenMsg(mBuf,&len);
     if(len > 0)
     {
        if ((ret = SExamMsg(&tag, mBuf, 0)) != ROK)
        {
#if (ERRCLASS & ERRCLS_DEBUG)
           SPrntMsg(mBuf,0,0);
           MALOGERROR(ERRCLS_DEBUG, EMA095, (ErrVal)tag, "Bad PDU received in maEndCom");
#endif
           RETVALUE(RFAILED);
        }

        if (tag == MA_TAG_CLOSE_PDU)
        {
           (Void)SRemPreMsg(&tag, mBuf);
           if ((ret = maRemLen(mBuf, &eocFlg)) != ROK)
           {
#if (ERRCLASS & ERRCLS_DEBUG)
              SPrntMsg(mBuf,0,0);
              MALOGERROR(ERRCLS_DEBUG, EMA096, (ErrVal)ret, "Bad MAP PDU received");
#endif
              RETVALUE(RFAILED);
           }
           (Void)SFndLenMsg(mBuf,&len);
           if ((mBuf != NULLP) && (dlgCp->apn.val[dlgCp->apn.len-1]>LMA_VER2))
           {
              if ( (len != 0) && ((len != 2) || (eocFlg == FALSE)))
              {
                 (Void)SExamMsg(&tag, mBuf, 0);
                 if (tag == MA_TAG_SEQ)
                 {
                    /* Decoding the mBuf using standard routine*/
                    if((ret = maDecExtCont(s, (U8 *)(&(closeEv.extCont)),
                                        LMA_VER2P, (U8)s->cfg.swtch,
                                        MA_MI_DLGPDU)) != ROK)
                    {
#if (ERRCLASS & ERRCLS_DEBUG)
                       SPrntMsg(mBuf,0,0);
                       MALOGERROR(ERRCLS_DEBUG, EMA097, (ErrVal)ret, 
                                      "Bad MAP PDU received");
#endif
                       RETVALUE(RFAILED);
                    }
                 }
              }
           }
           (Void)SFndLenMsg(mBuf,&len);
           if ( (len != 0) && ((len != 2) || (eocFlg == FALSE)))
           {
              closeEv.usrInfo.pres = TRUE;
              closeEv.usrInfo.len  = (U8)len;
              SRemPreMsgMult(closeEv.usrInfo.val, (MsgLen)len, mBuf);
           }
        }
     } /* len > 0 */
  }

  if (dlgCp->cmpPresFlg == TRUE)
  {
    if( dlgCp->closePduPres == TRUE)
    {
       if(closeEv.extCont.priExtLst[0].pres == TRUE)
       {
          for (i = 0; i< MA_MAX_NMB_PRI_EXT; i++)
          {
             cmCopy((U8 *)&closeEv.extCont.priExtLst[i], 
                    (U8 *)&dlgCp->closePdu.extCont.priExtLst[i],    
                    sizeof(TknStrE));
          }
       }
       if (closeEv.usrInfo.pres == TRUE)
       {
          cmCopy((U8 *)&closeEv.usrInfo, (U8 *)&dlgCp->closePdu.usrInfo,
                  sizeof(TknStrS));
       }
    }
    /* mark the end flag TRUE */
    dlgCp->endFlg = TRUE;
#ifdef ZJ
    MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_MOD)
    MA_UPD_PEER(rtUpd)
#endif /* ZJ */
  }
  else
  {
    /* Send the close indication to upper user */
    closeEv.rlsCause = MAT_NORMAL_RELEASE;
    tmpSuDlgId = dlgCp->suDlgId;    
    tmpSpDlgId = dlgCp->spDlgId;    
#ifdef ZJ
    MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
    MA_UPD_PEER(rtUpd)
#endif /* ZJ */
    maDlgIdle(s);
    MaUiMatCloseInd(&s->maPstMU, s->suId, tmpSuDlgId, tmpSpDlgId, &closeEv);
  }
  RETVALUE(ROK);
} /* maEndCom  */

/*
*
*       Fun:   maBeginM00    
*
*       Desc:  This function handles the reception of BEGIN PDU in 
*              DSM IDLE state  
*
*       Ret:   ROK  
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maBeginM00 
(
MaSap *s
)
#else
PRIVATE S16 maBeginM00 (s)
MaSap *s;
#endif
{
 MaDlgCp  *dlgCp;    /* Dialogue Control point */
 MaOpenEv openEv;
 StDlgEv  *dlgEv;
 StDlgEv  txDlgEv;
 S16      ret;
 MsgLen   len;
#ifdef STUV2
 StDataParam dataParam;
#endif
#ifdef ZJ
 Bool     rtUpd;
#endif
  
 TRC2(maBeginM00)

/* ma001.203 : Addition. Initialized dataParam */
#ifdef STUV2
   cmZero((Data *) &dataParam, sizeof(StDataParam));
#endif

 /* Increment the active dialogue count */
 s->nmbActvDlg++;
 dlgCp = s->curDlgCp;
 dlgEv = (StDlgEv *)(s->evtPtr);
 maBZero( (U8 *)&openEv, sizeof (MaOpenEv));

 if(dlgEv->pres == TRUE) 
 {
   maConvertACN(&dlgEv->apConName);

   /* Store the application context name in dlg control point */
   dlgCp->apn.pres = TRUE;
   dlgCp->apn.len = (U8)dlgEv->apConName.len;
   cmCopy(&dlgEv->apConName.string[0],&dlgCp->apn.val[0], dlgEv->apConName.len);

   if ( !IS_VALID_VERSION(dlgCp->apn.val[dlgCp->apn.len -1]) )
   {
      /* Abort the dialogue */
      txDlgEv.pres = TRUE;
      maAbrtDlg(s, &txDlgEv, MAT_ACN_NOT_SUPPORTED); 
      maDlgIdle(s);
      RETVALUE(ROK);
   }

   if ((dlgEv->apConName.string[dlgEv->apConName.len -1]) == LMA_VER1)
   {
      /* Abort the dialogue */
      txDlgEv.pres = TRUE;
      maAbrtDlg(s, &txDlgEv, MAT_P_ABNORMAL_DLG); 
      maDlgIdle(s);
      RETVALUE(ROK);
   }

#if MAP_REL99
#if (MAP_SEC && LMAV2)
   if ((dlgEv->apConName.string[dlgEv->apConName.len -2]) == 
       MA_SEC_TRANS_HANDL_AC)
   {
      s->secSts.secSapSts.openReqRx++;

#if MAP_REL5
#else
      if (maChkProtMode(dlgCp, (LmaSecPl)NULLD, FALSE, LMA_CMP_USR) != ROK)
      {
        /* if protection mode is not correct, abort the dialogue
         * with refuse reason transport protection not adequate
         */
         maSndRefPdu(s,MAT_TRANS_PROTE_NOT_ADEQ,FALSE);
         maDlgIdle(s);
         RETVALUE(ROK);
      }
#endif

      if(s->crntRxMsg == (Buffer *)NULLP)
      {
         /* Protected dialogue PDU must be present for secure 
          * dialogue hence abort the dialogue.
          */
         txDlgEv.pres = TRUE;
         maAbrtDlg(s, &txDlgEv, MAT_P_ABNORMAL_DLG); 
         maDlgIdle(s);
         RETVALUE(ROK);
      }
      else
      {
         /* Decode the protected open PDU */
         if( (ret = maDecProtDlgPdu(s, s->crntRxMsg, TRUE)) != ROK)
         {
            /* Abort the dialogue */
            txDlgEv.pres = TRUE;
            maAbrtDlg(s, &txDlgEv, MAT_P_ABNORMAL_DLG); 
            maDlgIdle(s);
            RETVALUE(ROK);
         }
         /* Now, we have MAP dialogue PDU in s->crntRxMsg if it is 
          * present. s->crntRxMsg will be NULL if it is not present.
          */


#if MAP_REL5
         if (maChkProtMode(dlgCp, (LmaSecPl)NULLD, FALSE, LMA_CMP_USR) != ROK)
         {
            /* if protection mode is not correct, abort the dialogue
            * with refuse reason transport protection not adequate
            */
            maSndRefPdu(s,MAT_TRANS_PROTE_NOT_ADEQ,FALSE);
            maDlgIdle(s);
            RETVALUE(ROK);
         }
#endif
      }
   }
   else
   {
      /* if unsecured transport is not permitted, abort the dialogue
       * with refuse reason transport protection not adequate
       */

      if (maCb.maCP.secGenCfg.rxFbInd == LMA_FB_DISABLED)
      {
         /* Fallback is not allowed */
            /* SPD mandates the use of MAPSec for included original 
             * component identifier, the message is discarded */

            s->secSts.nmbInvUnsecOpenReq++;
            maSndRefPdu(s,MAT_TRANS_PROTE_NOT_ADEQ, FALSE);
            maDlgIdle(s);
            RETVALUE(ROK);
         }
      }
#endif /* MAP_SEC */
#endif

   len = 0;
   if(s->crntRxMsg != (Buffer *)NULLP)
   {
      SFndLenMsg(s->crntRxMsg,&len);
   }
   if((s->crntRxMsg == (Buffer *)NULLP) || (len == 0))
   {
      /* Check whether user info is required or not */
     if((dlgCp->apn.val[dlgCp->apn.len - 2] == MA_NETFUNC_SS) || 
        (dlgCp->apn.val[dlgCp->apn.len - 2] == MA_NETUSS_SS) ||
        (dlgCp->apn.val[dlgCp->apn.len - 2] == MA_CALL_COMP_AC))
     {
         /* User info was required hence abort the dialogue */
         /* Abort the dialogue */
         txDlgEv.pres = TRUE;
         maAbrtDlg(s, &txDlgEv, MAT_P_ABNORMAL_DLG); 
         maDlgIdle(s);
         RETVALUE(ROK);
     }
   }
   else
   {
     /* Decode the MAP PDU */
     if( (ret = maDecOpenPdu(s, &openEv, 
                dlgEv->apConName.string[dlgEv->apConName.len -2])) != ROK)
     {
        /* Abort the dialogue */
        txDlgEv.pres = TRUE;
        maAbrtDlg(s, &txDlgEv, MAT_P_ABNORMAL_DLG); 
        maDlgIdle(s);
        RETVALUE(ROK);
     }
   }

   if (maChkLoad(s) == FALSE)
   {
        /* System is overloaded don't except the dialogue */
 
      StDlgEv rspDlgEv;
 
       /* pre arranged close for the dialogue instance in TCAP */
      rspDlgEv.pres = FALSE;
#ifdef STUV2
      dataParam.imp.pres = FALSE;

      MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_END, dlgCp->spDlgId,
                 dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                 TRUE, &s->qosSet, &rspDlgEv, &dataParam, NULLP);
#else
      MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_END, dlgCp->spDlgId,
                 dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                 TRUE, &s->qosSet, &rspDlgEv, NULLP);
#endif /* STUV2 */
      maDlgIdle(s);
      RETVALUE(ROK);
   }

   /* check if secure transport AC is support if secure transport
    * is used, otherwise check normal AC */

   if (maIsAcnSupp (&s->cfg.apnCfg[0], s->evtPtr, s->curDlgCp) != TRUE)
   {
       MaDlgId tmpSpDlgId;
       MaDlgId tmpLowerSpDlgId;
       SpAddr  tmpDestAddr;
       SpAddr  tmpSrcAddr;

       /* Abort the dialogue */
       txDlgEv.pres = TRUE;
       maBldDlgEv(s, &txDlgEv, STU_DLGP_RSP);
       txDlgEv.resReason = ST_DLG_RSD_NOACN;
       txDlgEv.resSrc = ST_DLG_SU_TAG;
       txDlgEv.result = ST_DLG_REJ_PERM;
       tmpSpDlgId = dlgCp->spDlgId;
       tmpLowerSpDlgId = dlgCp->lowerSpDlgId;
       cmCopy((U8 *)&dlgCp->destAddr,(U8 *)&tmpDestAddr,sizeof(SpAddr));
       cmCopy((U8 *)&dlgCp->srcAddr,(U8 *)&tmpSrcAddr,sizeof(SpAddr));
       maDlgIdle(s);
#ifdef MATV3
       MA_UPD_DEFAULT_QOS_PARAMS(s,dlgCp);
#endif
#ifdef STUV2
       /* this is a MAP self-generated U_ABORT, highest imp is used */
       dataParam.imp.val = MAT_IMP_VAL_7;
       dataParam.imp.pres = TRUE;

       MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_U_ABORT, tmpSpDlgId, 
                 tmpLowerSpDlgId, &tmpDestAddr, &tmpSrcAddr,
                 FALSE, &s->qosSet, &txDlgEv, &dataParam, NULLP);
#else
       MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_U_ABORT, tmpSpDlgId, 
                 tmpLowerSpDlgId, &tmpDestAddr, &tmpSrcAddr,
                 FALSE, &s->qosSet, &txDlgEv, NULLP);
#endif /* STUV2 */
       RETVALUE(ROK);
   }

#if MAP_REL99
#if (MAP_SEC && LMAV2)
   if (dlgEv->apConName.string[dlgEv->apConName.len -2] == 
       MA_SEC_TRANS_HANDL_AC)
   {
      /* check if encapsulated AC is support. Encapsulated AC was 
       * saved in dlgCp when we extracted MAP protected dialogue PDU. 
       * We have to retrieve it and pass to acn checking function.
       */
      StDlgEv tmpDlgEv;

      tmpDlgEv.apConName.len = dlgCp->apn.len;
      cmCopy(&dlgCp->apn.val[0],&tmpDlgEv.apConName.string[0],dlgCp->apn.len);

      if (maIsAcnSupp (&s->cfg.apnCfg[0], (U8 *)&tmpDlgEv, dlgCp) != TRUE)
      {
         /* check if alternative AC exist. If yes, alt AC was saved 
          * on dlgCp inside maIsAcnSupp(). If no, dlgCp will keep the 
          * original AC 
          */
         if((cmMemcmp((U8 *)&tmpDlgEv.apConName.string[0], 
            (U8 *)&dlgCp->apn.val[0], dlgCp->apn.len)) == 0)
         {
            maSndRefPdu(s,MAT_ENCACN_NOT_SUPPORTED, FALSE);
         }
         else
         {
            maSndRefPdu(s,MAT_ENCACN_NOT_SUPPORTED, TRUE);
         }
         maDlgIdle(s);
         RETVALUE(ROK);
      }
      else
      {
         s->curDlgCp->mapSec = TRUE;
      }
   }

#endif /* MAP_SEC */
#endif


   /* Send MAP Open Indication to the Upper user */
   cmCopySpAddr(&dlgCp->destAddr, &openEv.destAddr);
   cmCopySpAddr(&dlgCp->srcAddr, &openEv.srcAddr);

   openEv.apn.pres = TRUE;
   openEv.apn.len = (U8)dlgEv->apConName.len;
   cmCopy(&dlgCp->apn.val[0],&openEv.apn.val[0],dlgEv->apConName.len);
   
   dlgCp->dsmState = MA_DLG_PENDING;

#ifdef ZJ
   if (zjCb.tuCb.genCfg.updAllDlg == TRUE)
   {
      dlgCp->upd = TRUE;
   }
   else
   {
      if (maIsUpdReq(s, dlgCp) == TRUE)
      {
         dlgCp->upd = TRUE;
         cmTuAddMapping (&zjCb.tuCb, (PTR)dlgCp);
      }
   }
   rtUpd = dlgCp->upd;
   MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_ADD)
   MA_UPD_PEER(rtUpd)

#endif
   MaUiMatOpenInd(&s->maPstMU,s->suId, dlgCp->suDlgId,dlgCp->spDlgId, &openEv);
   if (s->curDlgCp == NULLP)
   {
      /* current dialogue maybe deallocated due to negative openRsp or AbrtReq*/
      RETVALUE(ROK);
   }
   if (dlgCp->cmpPresFlg != TRUE)
   {
     if (dlgCp->openRspRcvd.pres == TRUE)
     {
        maRestoreOpenRsp(dlgCp);
     }
#ifdef ZJ
     MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_MOD)
     MA_UPD_PEER(rtUpd)
#endif
    /*move the delimeter to open rsp*/
#ifndef XW_IND_OPTIMIZE
     MaUiMatDelimInd(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId);
#endif
   }
 }
 else
 {
    /* Application context name not included */
    if (dlgCp->cmpPresFlg == FALSE)
    {
        /* Abort the dialogue */
        txDlgEv.pres = FALSE;
        maAbrtDlg(s, &txDlgEv, MAT_P_ABNORMAL_DLG); 
        maDlgIdle(s);
        RETVALUE(ROK);
    }
    dlgCp->dsmState = MA_DLG_WAIT_INIT_DATA;
#ifdef ZJ
    /* For verison 1, we don't know the ACN yet, so we don't know 
     * if runtime update is required based on ACN. Wait until receive 
     * component from TCAP
     */
    if (zjCb.tuCb.genCfg.updAllDlg == TRUE)
    {
       dlgCp->upd = TRUE;
    }
    rtUpd = dlgCp->upd;
    MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_ADD)
    MA_UPD_PEER(rtUpd)
#endif
 }
#ifdef ZJ
 MA_UPD_PEER(rtUpd)
#endif /* ZJ */

 RETVALUE(ROK);
} /* end of maBeginM00 */


/*
*
*       Fun:   maContM03    
*
*       Desc:  This function handles the TC_CONTINUE in the
*              dialogue initiated state. 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maContM03 
(
MaSap *s        /* MAP sap pointer */
)
#else
PRIVATE S16  maContM03 (s)
MaSap *s;       /* MAP sap pointer */
#endif
{
 MaDlgCp  *dlgCp;
 StDlgEv  *dlgEv;
 StDlgEv  txDlgEv;
 MaOpenEv openEv;
 MaAbrtEv abrtEv;
 Bool     eocFlg;
 MsgLen   len;
 S16      ret;
 Buffer   *mBuf;
 U8       tag;
 MaDlgId  tmpSuDlgId;        /* temporary Service user Dlg Id */
 MaDlgId  tmpSpDlgId;        /* temporary Service provider Dlg Id */
 Bool     cmpPresFlg;        /* temporary component present falg */
#ifdef ZJ
 Bool     rtUpd;
#endif

 TRC2(maContM03)

 tag = 0;
 mBuf = NULLP;
 eocFlg = FALSE;
 dlgEv = (StDlgEv *)(s->evtPtr); 
 dlgCp = s->curDlgCp;
 tmpSuDlgId = dlgCp->suDlgId;    
 tmpSpDlgId = dlgCp->spDlgId;    
 cmpPresFlg = dlgCp->cmpPresFlg;
 maBZero((U8 *)&openEv, sizeof (MaOpenEv));
#ifdef ZJ
 rtUpd = dlgCp->upd;
#endif
 
 if (dlgEv->pres == TRUE)
 {
    /* check if the AC is unchanged */
    maConvertACN(&dlgEv->apConName);
#if MAP_REL99
#if (MAP_SEC && LMAV2)
    if (dlgCp->mapSec == TRUE)
    {
       s->secSts.secSapSts.openRspRx++;

       if (maCmpSecAcn (&dlgCp->apn.val[0], &dlgEv->apConName.string[0], 
                        dlgCp->apn.len, dlgEv->apConName.len) != 0) 
       {
          /* send the provider abort to MAP user */
          maBZero((U8 *)&abrtEv, sizeof (MaAbrtEv));
          abrtEv.abrtReason = MAT_P_ABNORMAL_DLG;
          abrtEv.abrtSrc = MAT_PROV_ABRT;
          abrtEv.abrtPSrc = MAT_PABRT_MAP;
#ifdef ZJ
          MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
          MA_UPD_PEER(rtUpd)
#endif
          MaUiMatAbrtInd(&s->maPstMU,s->suId,dlgCp->suDlgId,dlgCp->spDlgId,
                         &abrtEv);
          /* send the Tc-U_Abort req and return to idle state */
          txDlgEv.pres = TRUE;
          maAbrtDlg(s, &txDlgEv, MAT_P_ABNORMAL_DLG); 
          maDlgIdle(s);
          RETVALUE(ROK);
       }
       else
       {
          /* protected dialogue PDU is mandatory for secure transport */
          if (s->crntRxMsg == (Buffer *)NULLP)
          {
             /* send the provider abort to MAP user */
             maBZero((U8 *)&abrtEv, sizeof (MaAbrtEv));
             abrtEv.abrtReason = MAT_P_ABNORMAL_DLG;
             abrtEv.abrtSrc = MAT_PROV_ABRT;
             abrtEv.abrtPSrc = MAT_PABRT_MAP;
#ifdef ZJ
             MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
             MA_UPD_PEER(rtUpd)
#endif
             MaUiMatAbrtInd(&s->maPstMU,s->suId,dlgCp->suDlgId,dlgCp->spDlgId,
                            &abrtEv);
             /* send the Tc-U_Abort req and return to idle state */
             txDlgEv.pres = TRUE;
             maAbrtDlg(s, &txDlgEv, MAT_P_ABNORMAL_DLG); 
             maDlgIdle(s);
#if (ERRCLASS & ERRCLS_DEBUG)
             MALOGERROR(ERRCLS_DEBUG, EMA098, (ErrVal)0, "Bad PDU received in maContM03");
#endif
             RETVALUE(RFAILED);
          }
          else
          {
             if (maGetEncapAcn (s->crntRxMsg, &dlgEv->apConName) != ROK) 
             {
#if (ERRCLASS & ERRCLS_DEBUG)
             MALOGERROR(ERRCLS_DEBUG, EMA099, (ErrVal)0, "Bad PDU received in maContM03");
#endif
                RETVALUE(RFAILED);
             }
          }
       }
    }
#endif /* MAP_SEC */
#endif

    if (maCmpAcn (&dlgCp->apn.val[0], &dlgEv->apConName.string[0], 
                  dlgCp->apn.len, dlgEv->apConName.len) != 0) 
    {
        /* send the provider abort to MAp user */
        maBZero((U8 *)&abrtEv, sizeof (MaAbrtEv));
        abrtEv.abrtReason = MAT_P_ABNORMAL_DLG;
        abrtEv.abrtSrc = MAT_PROV_ABRT;
        abrtEv.abrtPSrc = MAT_PABRT_MAP;
#ifdef ZJ
        MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
        MA_UPD_PEER(rtUpd)
#endif
        MaUiMatAbrtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId, 
                       &abrtEv);
        /* send the Tc-U_Abort req and return to idle state */
        txDlgEv.pres = TRUE;
        maAbrtDlg(s, &txDlgEv, MAT_P_ABNORMAL_DLG); 
        maDlgIdle(s);
        RETVALUE(ROK);
    }
    else
    {
       len = 0;
       if (s->crntRxMsg != (Buffer *)NULLP)
       {
          SFndLenMsg(s->crntRxMsg,&len);
       }
       /* checking accept Pdu if any */
       if((len > 0) && (s->crntRxMsg != (Buffer *)NULLP))
       {
          mBuf = s->crntRxMsg;
#if (MAP_SEC && LMAV2)
#if MAP_REL99
       if (dlgCp->mapSec == FALSE)
       {
          if ((ret = maDecDlgId(mBuf)) != ROK)
          {
#if (ERRCLASS & ERRCLS_DEBUG)
             SPrntMsg(mBuf,0,0);
             MALOGERROR(ERRCLS_DEBUG, EMA100, (ErrVal)tag, "Bad PDU received in maEndM03");
#endif
             RETVALUE(RFAILED);
          }
       }
#endif
#else  /* MAP_SEC */

       if ((ret = maDecDlgId(mBuf)) != ROK)
       {
#if (ERRCLASS & ERRCLS_DEBUG)
          SPrntMsg(mBuf,0,0);
          MALOGERROR(ERRCLS_DEBUG, EMA101, (ErrVal)tag, "Bad PDU received in maEndM03");
#endif
          RETVALUE(RFAILED);
       }

#endif /* MAP_SEC */
          SFndLenMsg(s->crntRxMsg,&len);
          if(len>0)
          {
          if ((ret = SExamMsg(&tag, mBuf, 0)) != ROK)
          {
#if (ERRCLASS & ERRCLS_DEBUG)
             SPrntMsg(mBuf,0,0);
             MALOGERROR(ERRCLS_DEBUG, EMA102, (ErrVal)tag, 
                             "Bad PDU received in maContM03");
#endif
             RETVALUE(RFAILED);
          }
          if (tag == MA_TAG_ACCEPT_PDU) 
          {
             maBZero((U8 *)&openEv, sizeof (MaOpenEv));
             openEv.result = MAT_DLG_OK;
             (Void)SRemPreMsg(&tag, mBuf);
             if ((ret = maRemLen(mBuf, &eocFlg)) != ROK)
             {
#if (ERRCLASS & ERRCLS_DEBUG)
                SPrntMsg(mBuf,0,0);
                MALOGERROR(ERRCLS_DEBUG, EMA103, (ErrVal)ret, 
                                "Bad MAP Accept PDU received");
#endif
                RETVALUE(RFAILED);
             }
             (Void)SFndLenMsg(mBuf,&len);
             if ((mBuf != NULLP) && 
                 (dlgCp->apn.val[dlgCp->apn.len-1]>LMA_VER2))
             {
                if ( (len != 0) && ((len != 2) || (eocFlg == FALSE)))
                {
                   (Void)SExamMsg(&tag, mBuf, 0);
                   if (tag == MA_TAG_SEQ)
                   {
                      /* Decoding the mBuf using standard routine*/
                      if(( ret = maDecExtCont(s, (U8 *)(&(openEv.extCont)),
                                              LMA_VER2P, (U8)s->cfg.swtch,
                                              MA_MI_DLGPDU)) != ROK)
                      {
#if (ERRCLASS & ERRCLS_DEBUG)
                         SPrntMsg(mBuf,0,0);
                         MALOGERROR(ERRCLS_DEBUG, EMA104, (ErrVal)ret, 
                                      "Bad MAP Accept PDU received");
#endif
                         RETVALUE(RFAILED);
                      }
                   }
                }
             }
             (Void)SFndLenMsg(mBuf,&len);
             if ( (len != 0) && ((len != 2) || (eocFlg == FALSE)))
             {
                openEv.usrInfo.pres = TRUE;
                openEv.usrInfo.len  = (U8)len;
                SRemPreMsgMult(openEv.usrInfo.val, (MsgLen)len, mBuf);
             }
          }
          } 
       }
       /* copy the Application context name */
       openEv.apn.pres = TRUE;
       openEv.apn.len = dlgCp->apn.len;
       /* Source and destination addresses has to be copied */
       cmCopy((U8 *)&dlgCp->srcAddr, (U8 *)&openEv.srcAddr, sizeof(SpAddr)); 
       cmCopy((U8 *)&dlgCp->destAddr, (U8 *)&openEv.destAddr, sizeof(SpAddr)); 
       cmCopy(&dlgCp->apn.val[0], &openEv.apn.val[0], dlgCp->apn.len); 
    }
 }

 /* send the response to the MAP user */
 openEv.result = MAT_DLG_OK;
#if MAP_REL99
#if (MAP_SEC && LMAV2)
 if (dlgCp->cmpLst != (MaCmpStd *)NULLP)
 {
    maReqIdle(dlgCp);
 }
 if (dlgCp->mapSec == FALSE)
#endif
#endif
 s->sts.openRspRx++;

 dlgCp->dsmState = MA_DLG_ESTABLISHED;

 cmCopy((U8 *)&dlgCp->srcAddr, (U8 *)&openEv.srcAddr, sizeof(SpAddr)); 
 cmCopy((U8 *)&dlgCp->destAddr, (U8 *)&openEv.destAddr, sizeof(SpAddr)); 
#ifdef ZJ
 MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_MOD)
 MA_UPD_PEER(rtUpd)
#endif
 MaUiMatOpenCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId, &openEv);
 if ((dlgCp != NULLP) && (cmpPresFlg != TRUE))
 {
    MaUiMatDelimInd(&s->maPstMU, s->suId, tmpSuDlgId, tmpSpDlgId);
 }
  
 RETVALUE(ROK);
} /* end of maContM03 */

/*
*
*       Fun:   maContCom 
*
*       Desc:  This function handles the TC-Continue in Dialogue 
*              Established and Accepted state. 
*
*       Ret:   ROK 
*
*       Notes: This function does nothing.
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maContCom 
(
MaSap *s
)
#else
PRIVATE S16 maContCom (s)
MaSap *s;
#endif
{

 TRC2(maContCom)
 RETVALUE(ROK); 
} /* end of maContCom */

/*
*
*       Fun:   maEndM03  
*
*       Desc:  This function handles the TC-END in dialogue initiated state. 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maEndM03 
(
MaSap *s
)
#else
PRIVATE S16  maEndM03 (s)
MaSap *s;
#endif
{
  MaDlgCp *dlgCp;
  StDlgEv *dlgEv;
  MaAbrtEv abrtEv;
  MaOpenEv openEv;
  MaCloseEv closeEv;
  Buffer    *mBuf;
  U8        tag;
  S16       ret;
  MaDlgId  tmpSuDlgId;        /* temporary Service user Dlg Id */
  MaDlgId  tmpSpDlgId;        /* temporary Service provider Dlg Id */
  Bool     eocFlg;
  MsgLen   len;
#ifdef ZJ
  Bool     rtUpd;
#endif

  TRC2(maEndM03)

  /* xingzhou.xu: init close event */
  memset(&closeEv, 0, sizeof(MaCloseEv));
  tag = 0;
  mBuf = NULLP;
  eocFlg = FALSE;
  dlgCp = s->curDlgCp;
  dlgEv = (StDlgEv *)(s->evtPtr);
  tmpSuDlgId = dlgCp->suDlgId;    
  tmpSpDlgId = dlgCp->spDlgId;    
#ifdef ZJ
  rtUpd = dlgCp->upd;
#endif

 if ( dlgEv->pres == TRUE)
 {
    maConvertACN(&dlgEv->apConName);
#if MAP_REL99
#if (MAP_SEC && LMAV2)
    if (dlgCp->mapSec == TRUE)
    {
       s->secSts.secSapSts.closeRx++;
       if (maCmpSecAcn (&dlgCp->apn.val[0], &dlgEv->apConName.string[0], 
                        dlgCp->apn.len, dlgEv->apConName.len) != 0) 
       {
          /* send the provider abort to MAP user */
          maBZero((U8 *)&abrtEv, sizeof (MaAbrtEv));
          abrtEv.abrtReason = MAT_P_ABNORMAL_DLG;
          abrtEv.abrtSrc = MAT_PROV_ABRT;
          abrtEv.abrtPSrc = MAT_PABRT_MAP;
#ifdef ZJ
          MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
          MA_UPD_PEER(rtUpd)
#endif
          maDlgIdle(s);
          MaUiMatAbrtInd(&s->maPstMU,s->suId,tmpSuDlgId,tmpSpDlgId,&abrtEv);
          RETVALUE(ROK);
       }
       else
       {
          len = 0;
          if(s->crntRxMsg != (Buffer *)NULLP)
          {
             SFndLenMsg(s->crntRxMsg,&len);
          }
          /* protected dialogue PDU is mandatory for secure transport */
          if ((s->crntRxMsg == (Buffer *)NULLP) || (len == 0))
          {
             /* send the provider abort to MAP user */
             maBZero((U8 *)&abrtEv, sizeof (MaAbrtEv));
             abrtEv.abrtReason = MAT_P_ABNORMAL_DLG;
             abrtEv.abrtSrc = MAT_PROV_ABRT;
             abrtEv.abrtPSrc = MAT_PABRT_MAP;
#ifdef ZJ
             MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
             MA_UPD_PEER(rtUpd)
#endif
             maDlgIdle(s);
             MaUiMatAbrtInd(&s->maPstMU,s->suId,tmpSuDlgId,tmpSpDlgId,&abrtEv);
#if (ERRCLASS & ERRCLS_DEBUG)
             MALOGERROR(ERRCLS_DEBUG, EMA105, (ErrVal)0, "Bad PDU received in maEndM03");
#endif
             RETVALUE(RFAILED);
          }
          else
          {
             if (maGetEncapAcn (s->crntRxMsg, &dlgEv->apConName) != ROK) 
             {
#if (ERRCLASS & ERRCLS_DEBUG)
                MALOGERROR(ERRCLS_DEBUG, EMA106, (ErrVal)0, "Bad PDU received in maEndM03");
#endif
                RETVALUE(RFAILED);
             }
          }
       }
    }
#endif /* MAP_SEC */
#endif
    if (maCmpAcn (&dlgCp->apn.val[0], &dlgEv->apConName.string[0], 
                  dlgCp->apn.len, dlgEv->apConName.len) != 0) 
    {
        /* send the provider abort to MAP user */
        maBZero((U8 *)&abrtEv, sizeof (MaAbrtEv));
        abrtEv.abrtReason = MAT_P_ABNORMAL_DLG;
        abrtEv.abrtSrc = MAT_PROV_ABRT;
        abrtEv.abrtPSrc = MAT_PABRT_MAP;
#ifdef ZJ
        MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
        MA_UPD_PEER(rtUpd)
#endif
        maDlgIdle(s);
        MaUiMatAbrtInd(&s->maPstMU, s->suId, tmpSuDlgId, tmpSpDlgId, &abrtEv);
        RETVALUE(ROK);
    }
    else
    {
       maBZero((U8 *)&openEv, sizeof (MaOpenEv));
       openEv.result = MAT_DLG_OK;
       len = 0;
       if (s->crntRxMsg != (Buffer *)NULLP)
       {
          SFndLenMsg(s->crntRxMsg,&len);
       }
       /* checking accept Pdu if any */
       if((len > 0) && (s->crntRxMsg != (Buffer *)NULLP))
       {
         mBuf = s->crntRxMsg;

#if (MAP_SEC && LMAV2)
#if MAP_REL99
       if (dlgCp->mapSec == FALSE)
       {
          if ((ret = maDecDlgId(mBuf)) != ROK)
          {
#if (ERRCLASS & ERRCLS_DEBUG)
             SPrntMsg(mBuf,0,0);
             MALOGERROR(ERRCLS_DEBUG, EMA107, (ErrVal)tag, "Bad PDU received in maEndM03");
#endif
             RETVALUE(RFAILED);
          }
       }
#endif
#else  /* MAP_SEC */

       if ((ret = maDecDlgId(mBuf)) != ROK)
       {
#if (ERRCLASS & ERRCLS_DEBUG)
          SPrntMsg(mBuf,0,0);
          MALOGERROR(ERRCLS_DEBUG, EMA108, (ErrVal)tag, "Bad PDU received in maEndM03");
#endif
          RETVALUE(RFAILED);
       }

#endif /* MAP_SEC */

        if ((ret = SExamMsg(&tag, mBuf, 0)) != ROK)
        {
#if (ERRCLASS & ERRCLS_DEBUG)
          SPrntMsg(mBuf,0,0);
          MALOGERROR(ERRCLS_DEBUG, EMA109, (ErrVal)tag, "Bad PDU received in maEndM03");
#endif
          RETVALUE(RFAILED);
        }
        if (tag == MA_TAG_REFUSE_PDU)
        {
           maBZero((U8 *)&openEv, sizeof (MaOpenEv));
           /* Send the confirm with no reason given */
           openEv.result = MAT_DLG_REFUSED;
           openEv.apn.pres = TRUE;
           openEv.apn.len = dlgCp->apn.len;
           cmCopy(&dlgCp->apn.val[0], &openEv.apn.val[0], dlgCp->apn.len); 
           openEv.refReason.pres = TRUE;
           maDecRefPdu(s, &openEv, &dlgEv->apConName);
#if MAP_REL99
#if (MAP_SEC && LMAV2)
           cmCopy(&dlgEv->apConName.string[0], &openEv.apn.val[0], 
                   dlgEv->apConName.len); 

           if (dlgCp->mapSec == FALSE)
#endif
#endif
           s->sts.openRspRx++;
           dlgCp->endFlg = TRUE;
           cmCopy((U8 *)&dlgCp->srcAddr, (U8 *)&openEv.srcAddr, sizeof(SpAddr)); 
           cmCopy((U8 *)&dlgCp->destAddr, (U8 *)&openEv.destAddr, sizeof(SpAddr)); 
#ifdef ZJ
           MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
           MA_UPD_PEER(rtUpd)
#endif
           maDlgIdle(s);
           MaUiMatOpenCfm(&s->maPstMU, s->suId, tmpSuDlgId, tmpSpDlgId, &openEv);
           RETVALUE(ROK);
        }
        if (tag == MA_TAG_ACCEPT_PDU)
        {
           maBZero((U8 *)&openEv, sizeof (MaOpenEv));
           openEv.result = MAT_DLG_OK;
           (Void)SRemPreMsg(&tag, mBuf);
           if ((ret = maRemLen(mBuf, &eocFlg)) != ROK)
           {
#if (ERRCLASS & ERRCLS_DEBUG)
              SPrntMsg(mBuf,0,0);
              MALOGERROR(ERRCLS_DEBUG, EMA110, (ErrVal)ret, "Bad MAP PDU received");
#endif
              RETVALUE(RFAILED);
           }
           (Void)SFndLenMsg(mBuf,&len);
           if ((mBuf != NULLP) && (dlgCp->apn.val[dlgCp->apn.len-1]>LMA_VER2))
           {
              if ( (len != 0) && ((len != 2) || (eocFlg == FALSE)))
              {
                 (Void)SExamMsg(&tag, mBuf, 0);
                 if (tag == MA_TAG_SEQ)
                 {
                    /* Decoding the mBuf using standard routine*/
                    if(( ret = maDecExtCont(s, (U8 *)(&(openEv.extCont)),
                               LMA_VER2P, (U8)s->cfg.swtch, MA_MI_DLGPDU)) != ROK)
                    {
#if (ERRCLASS & ERRCLS_DEBUG)
                       SPrntMsg(mBuf,0,0);
                       MALOGERROR(ERRCLS_DEBUG, EMA111, (ErrVal)ret, 
                                      "Bad MAP PDU received");
#endif
                       RETVALUE(RFAILED);
                    }
                 }
              }
           }
           (Void)SFndLenMsg(mBuf,&len);
           if ( (len != 0) && ((len != 2) || (eocFlg == FALSE)))
           {
              openEv.usrInfo.pres = TRUE;
              openEv.usrInfo.len  = (U8)len;
              SRemPreMsgMult(openEv.usrInfo.val, (MsgLen)len, mBuf);
           }
        }
      }
       /* copy the Application context name */
       openEv.apn.pres = TRUE;
       openEv.apn.len = dlgCp->apn.len;
       cmCopy(&dlgCp->apn.val[0], &openEv.apn.val[0], dlgCp->apn.len); 
       dlgCp->endFlg = TRUE;
#if MAP_REL99
#if (MAP_SEC && LMAV2)
       if (dlgCp->mapSec == FALSE)
#endif
#endif
       s->sts.openRspRx++;
       cmCopy((U8 *)&dlgCp->srcAddr, (U8 *)&openEv.srcAddr, sizeof(SpAddr)); 
       cmCopy((U8 *)&dlgCp->destAddr, (U8 *)&openEv.destAddr, sizeof(SpAddr)); 
#ifdef ZJ
       MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_MOD)
       MA_UPD_PEER(rtUpd)
#endif
       MaUiMatOpenCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId, &openEv);
    }
 }
 else
 {
    maBZero((U8 *)&openEv, sizeof (MaOpenEv));
    openEv.apn.pres = FALSE;
    openEv.result = MAT_DLG_OK;
    dlgCp->endFlg = TRUE;
#if MAP_REL99
#if (MAP_SEC && LMAV2)
    if (dlgCp->mapSec == FALSE)
#endif
#endif
    s->sts.openRspRx++;
    cmCopy((U8 *)&dlgCp->srcAddr, (U8 *)&openEv.srcAddr, sizeof(SpAddr)); 
    cmCopy((U8 *)&dlgCp->destAddr, (U8 *)&openEv.destAddr, sizeof(SpAddr)); 
#ifdef ZJ
    MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_MOD)
    MA_UPD_PEER(rtUpd)
#endif
    MaUiMatOpenCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId, &openEv);
 }
 if (dlgCp->cmpPresFlg != TRUE)
 {
   closeEv.usrInfo.pres = FALSE;
   closeEv.rlsCause = MAT_NORMAL_RELEASE;
#ifdef ZJ
   MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
   MA_UPD_PEER(rtUpd)
#endif
   maDlgIdle(s);
   MaUiMatCloseInd(&s->maPstMU, s->suId, tmpSuDlgId, tmpSpDlgId, &closeEv);
 }
#ifdef ZJ
 MA_UPD_PEER(rtUpd)
#endif
 RETVALUE(ROK);
} /* end of maEndM03 */

/*
*
*       Fun:  maOpenRspM05  
*
*       Desc:  This function handles the MAP Open response in 
*               dialogue pending state 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maOpenRspM05 
(
MaSap *s
)
#else
PRIVATE S16 maOpenRspM05 (s)
MaSap *s;
#endif
{
  
  StDlgEv  dlgEv;
  MaDlgCp  *dlgCp;
  MaOpenEv *openEv;
  Buffer   *mBuf;
  U8       maVer;
  Data     pkArray[20];
  MsgLen   len;
  S16      ret;
  MsgLen   msglen;
  MsgLen   curLen;
#ifdef STUV2
  StDataParam dataParam;
#endif
#ifdef ZJ
  Bool     rtUpd;
#endif

  TRC2(maOpenRspM05)

/* ma001.203 : Addition. Initialized dataParam */
#ifdef STUV2
   cmZero((Data *) &dataParam, sizeof(StDataParam));
#endif

  msglen = 0;
  len = 0;
  dlgCp = s->curDlgCp;
  openEv = (MaOpenEv *)(s->evtPtr);
  dlgEv.pres = FALSE;
#ifdef ZJ
  rtUpd = dlgCp->upd;
#endif

  if (openEv->result == MAT_DLG_OK)
  {
     dlgCp->dsmState = MA_DLG_ACCEPTED;
     if (dlgCp->apn.val[dlgCp->apn.len-1] != LMA_VER1)
     {
       dlgCp->dlgEvFlg = TRUE;
     }
     if (openEv->usrInfo.pres == TRUE)
     {
        dlgCp->usrInfoPres = TRUE;
     }
#ifdef XW_IND_OPTIMIZE
#ifndef MA_STATIC_EVT_STRUCT
     /*send the stored invoke*/
     {
        U8 i=0;
        U8 *evt=NULL;
        U8 *evtbk;
        MaCmpCp *cmpCp=NULL;
        
        for(i=0; i<MAX_DLG_RESEVT; i++)
        {
            maGetStoreEvtFrmCmp(dlgCp, &dlgCp->storIvkId[i], &cmpCp, &evt);
            if(evt != NULL)
            {
                evtbk = s->evtPtr;
                s->evtPtr = evt;
                
                if ((cmpCp->oprClass == MAT_OPRCLASS4) || (cmpCp->oprCode == MAT_BEGIN_SUBS_ACTV))
                {
                    /* remove the component control point */
                    maRemHashInv(dlgCp, &dlgCp->storIvkId[i], FALSE);
                }
                else
                {
                    cmpCp->ssmState = MA_SSM_WAITRSP;
                    maStartTmr(MA_GAURD_TMR,s, cmpCp); 
#ifdef ZJ
                    MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_ADD)
#endif
                }
#ifdef ZJ
                cmTuUpdPeer(&zjCb.tuCb);  
#endif
                maSndSSInd(s, cmpCp);

                s->evtPtr = evtbk;
            }
        }

        MaUiMatDelimInd(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId);
     }
#endif
#endif
#ifdef ZJ
     MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_MOD)
#endif /* ZJ */
  }
  else
  {
    /* get the version MAP version */
    if (dlgCp->apn.val[dlgCp->apn.len-1] != LMA_VER1)
      maVer = dlgCp->apn.val[dlgCp->apn.len-1];
    else
      maVer = LMA_VER1;
    if (maVer != LMA_VER1)
    {
      /* If user refuses the dialogue in dialogue pending DSM state, 
       * MAP should pass the refused reason to TCAP. TCAP will build 
       * dialogue portion of TCAP message according to the user specific
       * refused/abort reason. If the reason is "application-context
       * -name-not-supported" or "dialogue-refused", TCAP should encode
       * dialogue portion as "Dialogue Response". For other reasons, 
       * TCAP needs to generate a Dialogue Abort (ABRT) APDU.
       */
      cmZero((U8 *)&dlgEv,sizeof(StDlgEv));
      dlgEv.pres = TRUE;
      dlgEv.apConName.len = 0;

	/* ma001.203 : addition, updating the dlgCp with supported version */
#ifdef MAP_ACNNOTSUPP_ABRTDLG
		  if(openEv->refReason.val==MAT_ACN_NOT_SUPPORTED)
      {
       	dlgCp->apn.val[dlgCp->apn.len-1] = openEv->apn.val[dlgCp->apn.len-1];
      }
#endif /* MAP_ACNNOTSUPP_ABRTDIG */
      (Void) maBldOid(dlgCp, &dlgEv);     /* build ACN */
      dlgEv.stDlgType = STU_DLGP_RSP;     /* "Dialogue Response" */
      dlgEv.resPres = TRUE;
      dlgEv.resSrc = ST_DLG_SU_TAG;       /* dialog service user tag */
      dlgEv.result = ST_DLG_REFUSED;      /* Dialog refused */
      dlgEv.resReason = (openEv->refReason.val==MAT_ACN_NOT_SUPPORTED)?
                        (ST_DLG_RSD_NOACN):(ST_DLG_RSD_NULL); 
      dlgEv.abrtSrc = STU_DLG_USR_ABRT;   /* User abort */

      if ((ret = SGetMsg(s->maPstST.region, s->maPstST.pool, &mBuf )) != ROK)
      {
         RETVALUE(ret);
      }

      if ( dlgCp->usrInfo.pres == TRUE )
      {
         ret = SAddPstMsgMult(dlgCp->usrInfo.val, 
                             (MsgLen)dlgCp->usrInfo.len, mBuf);
         if (ret != ROK)
         {
#if (ERRCLASS & ERRCLS_ADD_RES)
            MALOGERROR(ERRCLS_ADD_RES, EMA112, (ErrVal)ret, 
                       "SAddPstMsgMult() Failed");
#endif
           (Void)SPutMsg(mBuf);
            RETVALUE(ret);
         }
         dlgCp->usrInfo.pres = FALSE;
      }
      if (dlgCp->extCont.priExtLst[0].pres == TRUE )  
      {
         /*Introduce entry MA_MI_DLGPDU in MAT_SS_RETERR type to */
         /*encode extCont with existing encode routine           */
         if ((ret = maEncOprPar(s, (U8 *)(&(dlgCp->extCont)),
                               LMA_VER2P, (U8)s->cfg.swtch, MAT_SS_RETERR, 
                               MA_MI_DLGPDU)) != ROK)
         {
#if (ERRCLASS & ERRCLS_ADD_RES)
            MALOGERROR(ERRCLS_ADD_RES, EMA113, (ErrVal)ret, 
                      "maOpenRspM05 () Failed at encoding extCont");
#endif 
            if (s->ctlp.mBuf != NULLP)
            {
               (Void)SPutMsg(s->ctlp.mBuf);
            }
            (Void)SPutMsg(mBuf);
            RETVALUE(RFAILED);
         }
         maBZero((U8 *)&dlgCp->extCont, sizeof(MaExtContSeq));
         if (s->ctlp.mBuf != (Buffer *)NULLP)
         {
            (Void)SCatMsg(mBuf, s->ctlp.mBuf, M2M1);
            (Void)SPutMsg(s->ctlp.mBuf);
            s->ctlp.mBuf = (Buffer *)NULLP;
         }
      }
      (Void)SFndLenMsg(mBuf, &msglen);

      pkArray[len++] = openEv->refReason.val;
      pkArray[len] = (Data)len;
      len++;
      pkArray[len++] = MA_TAG_ENUM;
      curLen = len + msglen;
      MA_ENCODE_LEN(curLen,len)
      pkArray[len++] = MA_TAG_REFUSE_PDU; 
      ret = SAddPreMsgMult(pkArray, (MsgLen)len, mBuf);

      if (ret != ROK)
      {
#if (ERRCLASS & ERRCLS_ADD_RES)
         MALOGERROR(ERRCLS_ADD_RES, EMA114, (ErrVal)ret, 
                    "maOpenRspM05 () Failed");
#endif
         (Void)SPutMsg(mBuf);
         RETVALUE(RFAILED);
      }
#if (MAP_SEC && LMAV2)
#if MAP_REL99
       if (dlgCp->mapSec == TRUE)
       {
#ifdef MA_SECPDU_BUILD
          /* pass the type as STU_U_ABORT here */
          if ((ret = maBldProtDlgPdu(s, mBuf)) != ROK)
#else
          if ((ret = maBldDlgId(mBuf, FALSE)) != ROK)
#endif
          {
             SPutMsg(mBuf);
             MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
                    "maOpenRspM05() failed, unable to build protected \
                     dialogue PDU.\n"));
             RETVALUE(RFAILED);
          }
          s->secSts.secSapSts.openRspTx++;
       }
       else
       {
          if ((ret = maBldDlgId(mBuf, FALSE)) != ROK)
          {
             (Void)SPutMsg(mBuf);
             MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                    "maOpenRspM05() failed,unable to build dialog Id.\n")); 
             RETVALUE(RFAILED);
          }
       }
#endif
#else
      if ((ret = maBldDlgId(mBuf, FALSE)) != ROK)
      {
         (Void)SPutMsg(mBuf);
         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "maOpenRspM05() failed,unable to build dialog Id.\n")); 
         RETVALUE(RFAILED);
      }
#endif /* MAP_SEC */
    }
    else
    {
       mBuf = NULLP;
       dlgEv.pres = FALSE;
    }
    if (s->trc == TRUE)
    {
       maGenTrc(s, LMA_DATA_TXED, mBuf);
    }

#ifdef ZJ
   MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
   MA_UPD_PEER(rtUpd)
#endif /* ZJ */

#ifdef MATV3
   MA_UPD_QOS_PARAMS(s,dlgCp);
#endif
#ifdef STUV2
#ifdef MATV2
   if (dlgCp->imp.pres == TRUE)
   {
      dataParam.imp.pres = TRUE;
      dataParam.imp.val = dlgCp->imp.val;
      dlgCp->imp.pres = FALSE;
   }
   else
   {
      dataParam.imp.pres = FALSE;
   }
#else /* MATV2 */
   /* use the highest importance level */
   dataParam.imp.pres = TRUE;
   dataParam.imp.val = MAT_IMP_VAL_7;
#endif /* MATV2 */

    MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_U_ABORT, dlgCp->spDlgId, 
                  dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                  FALSE, &s->qosSet, &dlgEv, &dataParam, mBuf);
#else  /* STUV2 */
    MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_U_ABORT, dlgCp->spDlgId, 
                  dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                  FALSE, &s->qosSet, &dlgEv, mBuf);
#endif /* STUV2 */
    maDlgIdle(s);
   
  }
  RETVALUE(ROK); 
} /* end of maOpenRspM05 */

/*
*
*       Fun:  maNotM03      
*
*       Desc:  This function handles the TC Not.Ind  in 
*               dialogue Initiated State
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maNotM03       
(
MaSap *s
)
#else
PRIVATE S16 maNotM03(s)
MaSap *s;
#endif
{
  
  MaDlgCp  *dlgCp;
  MaOpenEv openEv;
  StDlgEv rspDlgEv; /* dummy dialogue event structure */
#ifdef STUV2
  StDataParam dataParam;
#endif
#ifdef ZJ
  Bool     rtUpd;
#endif
  MaDlgId   spDlgId;
  MaDlgId   suDlgId;

  TRC2(maNotM03)       

/* ma001.203 : Addition. Initialized dataParam */
#ifdef STUV2
   cmZero((Data *) &dataParam, sizeof(StDataParam));
#endif

  dlgCp = s->curDlgCp;
#ifdef ZJ
  rtUpd = dlgCp->upd;
#endif

  /* get the version MAP version 
  ** If the MAP version is not equal to Phase 2+ then quit
  */
  if (dlgCp->apn.val[dlgCp->apn.len-1] == LMA_VER2 ||
      dlgCp->apn.val[dlgCp->apn.len-1] == LMA_VER1  )
  {
     MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
     "maNotM03() failed, invalid MAP version(%d).\n", dlgCp->apn.val[dlgCp->apn.len-1]));
     RETVALUE(RFAILED);
  }
  /*
  ** Set_Result = Dialogue Refused;
  ** Set_Refuse_Reason = Node_Not_Reachable; 
  ** MAP_OPEN_CFM to the Map user;
  */
  maBZero((U8 *)&openEv, sizeof (MaOpenEv));
  openEv.result = MAT_DLG_REFUSED;
  openEv.refReason.pres = TRUE;
  openEv.refReason.val = MAT_NODE_NOT_REACHABLE;
#if MAP_REL99
#if (MAP_SEC && LMAV2)
  if (dlgCp->mapSec == FALSE)
#endif
#endif
  s->sts.openRspRx++;
  cmCopy((U8 *)&dlgCp->srcAddr, (U8 *)&openEv.srcAddr, sizeof(SpAddr)); 
  cmCopy((U8 *)&dlgCp->destAddr, (U8 *)&openEv.destAddr, sizeof(SpAddr)); 

  rspDlgEv.pres = FALSE;

#ifdef ZJ
  MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
  MA_UPD_PEER(rtUpd)
#endif /* ZJ */

#ifdef STUV2
  dataParam.imp.pres = FALSE;

  MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_END, dlgCp->spDlgId,
                dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                TRUE, &s->qosSet, &rspDlgEv, &dataParam, NULLP);
#else
  MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_END, dlgCp->spDlgId,
                dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                TRUE, &s->qosSet, &rspDlgEv, NULLP);
#endif /* STUV2 */
  suDlgId = dlgCp->suDlgId;
  spDlgId = dlgCp->spDlgId;

  maDlgIdle(s);

  MaUiMatOpenCfm(&s->maPstMU, s->suId, suDlgId,
                 spDlgId, &openEv);

  RETVALUE(ROK); 
} /* end of maNotM03 */



/*
*
*       Fun: maBldDlgEv   
*
*       Desc:  This function builds the dialogue event 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maBldDlgEv 
(
MaSap   *s,       /* Pointer to MAP SAP */
StDlgEv *dlgEv,   /* Dialogue Event Structure */
U8      dlgType   /* Dialogue type */
)
#else
PUBLIC S16  maBldDlgEv(s, dlgEv, dlgType)
MaSap   *s;        /* Pointer to MAP SAP */
StDlgEv *dlgEv;   /* Dialogue Event Structure */
U8      dlgType;  /* Dialogue Type */
#endif
{
 MaDlgCp *dlgCp;        /* Dialogue Control point */

 TRC2(maBldDlgEv)

 dlgCp = s->curDlgCp;
 cmZero((U8 *)dlgEv,sizeof(StDlgEv));
 dlgEv->pres = TRUE;
 dlgEv->stDlgType = dlgType;
 dlgEv->apConName.len = 0;

 switch (dlgType)
 {
   case STU_DLGP_REQ :
     (Void) maBldOid(dlgCp, dlgEv);
     dlgEv->resPres = FALSE;
     break;
   case STU_DLGP_RSP :
     (Void) maBldOid(dlgCp, dlgEv);
     dlgEv->resPres = TRUE;
     dlgEv->resSrc = ST_DLG_SU_TAG;
     dlgEv->result = ST_DLG_ACCEPTED;
     dlgEv->resReason = ST_DLG_RSD_NULL;
     break;
   case STU_DLGP_ABT :
     (Void) maBldOid(dlgCp, dlgEv);
     dlgEv->abrtSrc = STU_DLG_USR_ABRT;
     break;
   default :
     break;
 } 
 RETVALUE(ROK);
} /* end of maBldDlgEv */

/*
*
*       Fun:   maDecOpenPdu   
*
*       Desc:  This function decodes the MAP open PDU  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maDecOpenPdu 
(
MaSap    *s,            /* SAP */
MaOpenEv *openEv,       /* MAP open event */
U8       acName
)
#else
PRIVATE S16 maDecOpenPdu (s, openEv, acName)
MaSap    *s;            /* SAP */
MaOpenEv *openEv;       /* MAP open event */
U8       acName;
#endif
{
  MsgLen   len;
  Data     tag;
  Bool     eocFlg = FALSE;
  S16      ret;
  Buffer   *mBuf;         /* Message buffer */

  TRC2(maDecOpenPdu)

  mBuf = s->crntRxMsg;
  openEv->srcRef.pres  = FALSE;
  openEv->destRef.pres = FALSE;

#if (MAP_SEC && LMAV2)
#if MAP_REL99
  if (acName != MA_SEC_TRANS_HANDL_AC)
  {
     if ( (ret = maDecDlgId(mBuf)) != ROK)
     {
        MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
               "maDecOpenPdu() failed, unable to decode dialog Id.\n"));
        RETVALUE(RFAILED);
     }
  }
#endif
#else /* MAP_SEC */
  UNUSED(acName);
  if ( (ret = maDecDlgId(mBuf)) != ROK)
  {
     MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
     "maDecOpenPdu() failed, unable to decode dialog Id.\n"));
     RETVALUE(RFAILED);
  }
#endif /* MAP_SEC */
  (Void)SFndLenMsg(mBuf,&len);
  if (len == 0)
  {
    RETVALUE(ROK);
  }

  (Void)SRemPreMsg(&tag, mBuf);
  if (tag != MA_TAG_OPEN_PDU)
  {
#if (ERRCLASS & ERRCLS_DEBUG)
     SPrntMsg(mBuf,0,0);
     MALOGERROR(ERRCLS_DEBUG, EMA115, (ErrVal)tag, "Bad MAP Open PDU received");
#endif
     RETVALUE(RFAILED);
  }
  if ((ret = maRemLen(mBuf, &eocFlg)) != ROK)
  {
#if (ERRCLASS & ERRCLS_DEBUG)
     SPrntMsg(mBuf,0,0);
     MALOGERROR(ERRCLS_DEBUG, EMA116, (ErrVal)ret, "Bad MAP Open PDU received");
#endif
    RETVALUE(RFAILED);
  }

  (Void)SFndLenMsg(mBuf,&len);
  if ( (len == 0) || ((len == 2) && (eocFlg == TRUE)))
  {
    RETVALUE(ROK);
  }
  (Void)SExamMsg(&tag, mBuf, 0);

  /* remove the primitive */
  if (tag == MA_TAG_DESTREF)
  {
     if ((ret = maRemPrim(mBuf,NULLP, &openEv->destRef.val[0], &openEv->destRef.len)) != ROK)
     {

#if (ERRCLASS & ERRCLS_DEBUG)
        SPrntMsg(mBuf,0,0);
        MALOGERROR(ERRCLS_DEBUG, EMA117, (ErrVal)ret, "Bad MAP Open PDU received");
#endif
        RETVALUE(RFAILED);
     }
     openEv->destRef.pres = TRUE;
  }
  (Void)SFndLenMsg(mBuf,&len);
  if ((len == 0) || ((len == 2) && (eocFlg == TRUE)))
  {
    RETVALUE(ROK);
  }
  (Void)SExamMsg(&tag, mBuf, 0);
  if (tag == MA_TAG_ORGREF)
  {
     if ((ret = maRemPrim(mBuf,NULLP, &openEv->srcRef.val[0], &openEv->srcRef.len)) != ROK)
     {
#if (ERRCLASS & ERRCLS_DEBUG)
       SPrntMsg(mBuf,0,0);
       MALOGERROR(ERRCLS_DEBUG, EMA118, (ErrVal)ret, "Bad MAP Open PDU received");
#endif
        RETVALUE(RFAILED);
     }
     openEv->srcRef.pres = TRUE;
  }
  /* decoding extCont and usrInfo in OpenPdu */
  (Void)SFndLenMsg(mBuf,&len);
  if ((len == 0) || ((len == 2) && (eocFlg == TRUE)))
  {
      RETVALUE(ROK);
  }
  (Void)SExamMsg(&tag, mBuf, 0);
  if (tag == MA_TAG_SEQ)
  {
     if(( ret = maDecExtCont(s, (U8 *)(&(openEv->extCont)), LMA_VER2P,
                 (U8)s->cfg.swtch, MA_MI_DLGPDU)) !=ROK)
     { 
#if (ERRCLASS & ERRCLS_DEBUG)
        SPrntMsg(mBuf,0,0);
        MALOGERROR(ERRCLS_DEBUG, EMA119, (ErrVal)ret, "Bad MAP Open PDU received");
#endif
        RETVALUE(RFAILED);
     }
  }
  (Void)SFndLenMsg(mBuf,&len);
  if ((len == 0) || ((len == 2) && (eocFlg == TRUE)))
  {
     RETVALUE(ROK);
  }
  openEv->usrInfo.pres = TRUE;
  openEv->usrInfo.len  = (U8)len;
  SRemPreMsgMult(openEv->usrInfo.val,(MsgLen)len, mBuf);

  RETVALUE(ROK);
   
} /* end of maDecOpenPdu */


/*
*
*       Fun:   maDecRefPdu   
*
*       Desc:  This function decodes the MAP refuse PDU  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maDecRefPdu 
(
MaSap    *s,            /* MAP sap */
MaOpenEv *openEv,       /* open event structure */
StStr    *apn           /* application context name */
)
#else
PRIVATE S16 maDecRefPdu (s, openEv, apn)
MaSap    *s;            /* MAP sap */
MaOpenEv *openEv;       /* open event structure */
StStr    *apn;          /* application context name */
#endif
{
  MsgLen   len;
  Bool     eocFlg;
  Data     tag;
  S16      ret;
  Buffer   *mBuf;         /* Message buffer */

  TRC2(maDecRefPdu)

   mBuf = s->crntRxMsg;
   (Void)SFndLenMsg(mBuf,&len);
   if (len == 0)
   {
     openEv->refReason.val  = MAT_NO_REASON;
     RETVALUE(ROK);
   }

   (Void)SRemPreMsg(&tag, mBuf);
   if (tag != MA_TAG_REFUSE_PDU)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA120, (ErrVal)tag, 
                 "Bad PDU received in maDecRefPdu");
#endif
     openEv->refReason.val = MAT_NO_REASON;
     RETVALUE(RFAILED);
   }
   if ((ret = maRemLen(mBuf, &eocFlg)) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA121, (ErrVal)ret, 
                 "Bad PDU received in maDecRefPdu");
#endif
      RETVALUE(RFAILED);
   }
   if ((ret = SExamMsg(&tag, mBuf, 0)) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA122, (ErrVal)ret, 
                 "Bad PDU received in maDecRefPdu");
#endif
      RETVALUE(RFAILED);
   }
   if (tag != MA_TAG_ENUM)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA123, (ErrVal)ret, 
                 "Bad PDU received in maDecRefPdu");
#endif
     openEv->refReason.val = MAT_NO_REASON;
     RETVALUE(RFAILED);
   }
   if ((ret = SExamMsg(&openEv->refReason.val, mBuf, 2)) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA124, (ErrVal)ret, 
                 "Bad PDU received in maDecRefPdu");
#endif
      RETVALUE(RFAILED);
   }
   
   /* alternative APN is optional, which is introduced in MAP release 4.
    * The following piece of code can be kept without MAP_SEC flag */
   (Void)SFndLenMsg(mBuf,&len);
   if ((len == 0) || ((len == 2) && (eocFlg == TRUE)))
   {
      RETVALUE(ROK);
   }

   /* decode extCont and usrInfo */
   (Void)SRemPreMsgMult(NULLP, (MsgLen)3, mBuf);
   (Void)SFndLenMsg(mBuf, &len);
   if ( (len == 0) || ((len == 2) && (eocFlg == TRUE)))
   {
      RETVALUE(ROK);
   }
   (Void)SExamMsg(&tag, mBuf, 0);
   if (tag == MA_TAG_SEQ) 
   {
      if(( ret = maDecExtCont(s, (U8 *)(&(openEv->extCont)), LMA_VER2P,
                              (U8)s->cfg.swtch, MA_MI_DLGPDU)) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         SPrntMsg(mBuf,0,0);
         MALOGERROR(ERRCLS_DEBUG, EMA125, (ErrVal)ret, "Bad MAP refused PDU extCont received");
#endif
         RETVALUE(RFAILED);
      }
   }

   /* remove alternative AC  */

   if ((ret = maRemPrim(mBuf, NULLP, &apn->string[0], 
       (U8 *)&(apn->len))) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA126, (ErrVal)ret, \
                 "maDecRefPdu() failed, Bad encapsulated AC received");
#endif
      RETVALUE(RFAILED);
   }
   maConvertACN(apn);

   (Void)SFndLenMsg(mBuf, &len);
   if ( (len == 0) || ((len == 2) && (eocFlg == TRUE)))
   {
      RETVALUE(ROK);
   }
   openEv->usrInfo.pres = TRUE;
   openEv->usrInfo.len  = (U8)len;
   SRemPreMsgMult(openEv->usrInfo.val, (MsgLen) len, mBuf);

   RETVALUE(ROK);
} /* end of maDecRefPdu */

/*
*
*       Fun:   maDecAbrtPdu   
*
*       Desc:  This function decodes the MAP Abort PDU  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maDecAbrtPdu 
(
MaSap    *s,            /* Sap */
MaAbrtEv *abrtEv        /* Abort event*/
)
#else
PRIVATE S16 maDecAbrtPdu (s, abrtEv)
MaSap    *s;           /* Sap */
MaAbrtEv *abrtEv;      /* Abort event */
#endif
{
  MsgLen   len;
  U8       destLen;
  Data     data, tag;
  Bool     eocFlg;
  S16      ret;
  Buffer   *mBuf;         /* Message buffer */

  TRC2(maDecAbrtPdu)

   mBuf = s->crntRxMsg;
   (Void)SFndLenMsg(mBuf,&len);
   if (len == 0)
   {
     RETVALUE(ROK);
   }

   (Void)SRemPreMsg(&tag, mBuf);
   if ( (tag != MA_TAG_USRABRT_PDU) && (tag != MA_TAG_PRVABRT_PDU))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
     MALOGERROR(ERRCLS_DEBUG, EMA127, (ErrVal)tag, 
                "maDecAbrtPdu() Bad TAG type");
#endif
     RETVALUE(RFAILED);
   }
   if ((ret = maRemLen(mBuf,&eocFlg)) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
     MALOGERROR(ERRCLS_DEBUG, EMA128, (ErrVal)tag, 
                "maDecAbrtPdu() Bad TAG type");
#endif
   }
   if (tag == MA_TAG_PRVABRT_PDU)
   {
     if ( (((ret = SExamMsg(&data, mBuf, 0)) != ROK)) ||
          (data != MA_TAG_ENUM))
     {
#if (ERRCLASS & ERRCLS_DEBUG)
        MALOGERROR(ERRCLS_DEBUG, EMA129, (ErrVal)ret, 
                   "maDecAbrtPdu() Badly formatted PDU");
#endif
        RETVALUE(RFAILED);
     }
     if ((ret = maRemPrim(mBuf, NULLP, &abrtEv->abrtReason, &destLen)) != ROK)
     {
#if (ERRCLASS & ERRCLS_DEBUG)
        MALOGERROR(ERRCLS_DEBUG, EMA130, (ErrVal)ret, 
                   "maDecAbrtPdu() Badly formatted PDU");
#endif
        RETVALUE(ret);
     }

   }
   else
   {
     if ((ret = SRemPreMsg(&tag, mBuf)) != ROK)
     {
        RETVALUE(ret);
     }
     if ( (tag != MAT_ABRT_USR_SPECIFIC) && (tag != MAT_ABRT_RESLIMIT) &&
          (tag != MAT_ABRT_RESUNAVAIL) && (tag != MAT_ABRT_APC))
     {
#if (ERRCLASS & ERRCLS_DEBUG)
        MALOGERROR(ERRCLS_DEBUG, EMA131, (ErrVal)tag, 
                   "maDecAbrtPdu() Bad tag");
#endif
        RETVALUE(RFAILED);
     }

     abrtEv->abrtReason = tag;
     if ((ret = SRemPreMsg(&data, mBuf)) != ROK)
     {
#if (ERRCLASS & ERRCLS_DEBUG)
        MALOGERROR(ERRCLS_DEBUG, EMA132, (ErrVal)ret, 
                   "maDecAbrtPdu() Badly formatted PDU");
#endif
        RETVALUE(RFAILED);
     }
     if (data == 0)
     {
       if ((tag == MAT_ABRT_USR_SPECIFIC) || (tag == MAT_ABRT_RESLIMIT))
       {

         RETVALUE(ROK);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
          MALOGERROR(ERRCLS_DEBUG, EMA133, (ErrVal)ret, 
                     "maDecAbrtPdu() Badly formatted PDU");
#endif
         RETVALUE(RFAILED);
       }
     }
     if ((ret = SRemPreMsg(&abrtEv->diagInfo, mBuf)) != ROK)
     {
#if (ERRCLASS & ERRCLS_DEBUG)
        MALOGERROR(ERRCLS_DEBUG, EMA134, (ErrVal)ret, 
                   "maDecAbrtPdu() Badly formatted PDU");
#endif
        RETVALUE(RFAILED);
     }
       
   }
   
   /* decoding usrInfo and extCont */
   (Void)SFndLenMsg(mBuf,&len);
   if ( (len == 0) || ((len == 2) && (eocFlg == TRUE)))
   {
      RETVALUE(ROK);
   }
   (Void)SExamMsg(&tag, mBuf, 0);
   if ( tag == MA_TAG_SEQ)
   {
      if(( ret = maDecExtCont(s, (U8 *)(&(abrtEv->extCont)), LMA_VER2P,
                 (U8)s->cfg.swtch, MA_MI_DLGPDU)) !=ROK)
      { 
#if (ERRCLASS & ERRCLS_DEBUG)
         SPrntMsg(s->crntRxMsg,0,0);
         MALOGERROR(ERRCLS_DEBUG, EMA135, (ErrVal)ret, "Bad MAP abort PDU extCont received");
#endif
         RETVALUE(RFAILED);
      }
   }
   (Void)SFndLenMsg(mBuf,&len);
   if ( (len == 0) || ((len == 2) && (eocFlg == TRUE)))
   {
      RETVALUE(ROK);
   }
   /*decode usrInfo*/
   abrtEv->usrInfo.pres = TRUE;
   abrtEv->usrInfo.len = (U8)len;
   SRemPreMsgMult(abrtEv->usrInfo.val, (MsgLen)len, mBuf);

   RETVALUE(ROK);
} /* end of maDecAbrtPdu */

/*
*
*       Fun: maAbrtDlg   
*
*       Desc:  This function sends the Abort to the TCAP  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maAbrtDlg 
(
MaSap   *s,
StDlgEv *dlgEv,
U8      reason
)
#else
PUBLIC S16 maAbrtDlg(s, dlgEv, reason)
MaSap   *s;
StDlgEv *dlgEv;
U8      reason;
#endif
{
   MaDlgCp    *dlgCp;
   Buffer     *mBuf;
   Data       pkArray[10];
   S16        ret;
   MsgLen     len;
#ifdef STUV2
   StDataParam dataParam;
#endif

   TRC2(maAbrtDlg)
   
/* ma001.203 : Addition. Initialized dataParam */
#ifdef STUV2
   cmZero((Data *) &dataParam, sizeof(StDataParam));
#endif

   mBuf = NULLP;
   dlgCp = s->curDlgCp;
   if (dlgEv->pres == TRUE)
   {

     maBldDlgEv(s, dlgEv, STU_DLGP_ABT);

     if ((ret = SGetMsg(s->maPstST.region, s->maPstST.pool, &mBuf )) != ROK)
     {
        MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
        "maAbrtDlg() failed, unable to allocate mBuf.\n"));
        RETVALUE(RFAILED);
     }
     len = 0;
     pkArray[len] = reason;
     len++;
     pkArray[len] = (Data)len;
     len++;
     pkArray[len] = (Data)MA_TAG_ENUM;
     len++;
     pkArray[len] = (Data)len;
     len++;
     pkArray[len] = MA_TAG_PRVABRT_PDU;
     len++;
     ret = SAddPreMsgMult(pkArray, (MsgLen)len, mBuf);

     if (ret != ROK)
     {
#if (ERRCLASS & ERRCLS_ADD_RES)
        MALOGERROR(ERRCLS_ADD_RES, EMA136, (ErrVal)ret, "maOpenRspM05 () Failed");
#endif    
        (Void)SPutMsg(mBuf);
        RETVALUE(RFAILED);
     }
#if (MAP_SEC && LMAV2)
#if MAP_REL99
     if (dlgCp->mapSec != TRUE)
     {
        if ((ret = maBldDlgId(mBuf, FALSE)) != ROK)
        {
           (Void)SPutMsg(mBuf);
           MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
                  "maAbrtDlg() failed, unable to build dialog Id.\n"));
           RETVALUE(RFAILED);
        }
     }
#endif
#else
     if ((ret = maBldDlgId(mBuf, FALSE)) != ROK)
     {
        (Void)SPutMsg(mBuf);
        MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
        "maAbrtDlg() failed, unable to build dialog Id.\n"));
        RETVALUE(RFAILED);
     }
#endif /* MAP_SEC */
   }

#if (MAP_SEC && LMAV2)
#if MAP_REL99
   if (dlgCp->mapSec == TRUE)
   {
      if ( mBuf == (Buffer *)NULLP)
      {
         if ((ret = SGetMsg(s->maPstST.region, s->maPstST.pool, &mBuf )) != ROK)
         {
#ifndef ALIGN_64BIT

             MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "maAbrtDlg() failed, fail to allocate mBuf,\
                   suId(%d), sapId(%d), suDlgId(%ld), spDlgId(%ld))\n", 
                   s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
            RETVALUE(RFAILED);

#else

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "maAbrtDlg() failed, fail to allocate mBuf,\
                   suId(%d), sapId(%d), suDlgId(%d), spDlgId(%d))\n", 
                   s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
            RETVALUE(RFAILED);

#endif /*ALIGN_64BIT*/
         }
      }
#ifdef  MA_SECPDU_BUILD
      if ((ret = maBldProtDlgPdu(s, mBuf)) != ROK)
#else
      if ((ret = maBldDlgId(mBuf,FALSE)) != ROK)
#endif
      {
         SPutMsg(mBuf);
         MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
                "maAbrtDlg() failed, unable to build protected \
                dialogue PDU.\n"));
         RETVALUE(RFAILED);
      }
      s->secSts.secSapSts.abrtTx++;
   }
#endif
#endif /* MAP_SEC */

   if (s->trc == TRUE)
   {
     maGenTrc(s, LMA_DATA_TXED, mBuf);
   }
#ifdef MATV3
   MA_UPD_DEFAULT_QOS_PARAMS(s,dlgCp);
#endif
#ifdef STUV2
   /* highest importance level is used for U_ABORT */
   dataParam.imp.val = MAT_IMP_VAL_7;
   dataParam.imp.pres = TRUE;

   MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_U_ABORT, dlgCp->spDlgId, 
                 dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                 FALSE, &s->qosSet, dlgEv, &dataParam, mBuf);
#else
   MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_U_ABORT, dlgCp->spDlgId, 
                 dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                 FALSE, &s->qosSet, dlgEv, mBuf);
#endif /* STUV2 */
   RETVALUE(ROK);
} /* end of maAbrtDlg */

/*
*
*       Fun:   maBldOpenMsg 
*
*       Desc:  Builds the MAP open message  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File: ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maBldOpenMsg 
(
MaSap  *s,              /* MAP SAP pointer */
Buffer *mBuf            /* Message pointer */
)
#else
PRIVATE S16 maBldOpenMsg(s, mBuf)
MaSap  *s;              /* MAP SAP pointer */
Buffer *mBuf;           /* Message buffer */
#endif
{
   MaSrcRef   *srcRef;   /* Orignator reference */
   MaDestRef  *destRef;  /* Destination reference */
   MsgLen     msgLen;
   Data       pkArray[20];
   S16        ret;       /* return value */
   S16        i;
   MsgLen     len;
   MsgLen     curLen;
   Data       idx;

    TRC2(maBldOpenMsg)

    srcRef  = &s->curDlgCp->srcRef;
    destRef = &s->curDlgCp->destRef;
    msgLen = 0;
    len = 0;

    /* add extCont and usrInfo into dlgPdu */
    if (s->curDlgCp->usrInfo.pres == TRUE) 
    {
       SAddPstMsgMult((U8 *)s->curDlgCp->usrInfo.val, 
                      (MsgLen) s->curDlgCp->usrInfo.len, mBuf);
       s->curDlgCp->usrInfo.pres = FALSE;
    }
    if (s->curDlgCp->extCont.priExtLst[0].pres == TRUE) 
    {
       /*Introduce entry MA_MI_DLGPDU in MAT_SS_RETERR type to */
       /*encode extCont with existing encode routine maEncOprPar()*/
       if ((ret = maEncOprPar(s, (U8 *)(&(s->curDlgCp->extCont)),
                              LMA_VER2P, (U8)s->cfg.swtch, MAT_SS_RETERR, 
                              MA_MI_DLGPDU)) != ROK)
       {
#if (ERRCLASS & ERRCLS_ADD_RES)
          MALOGERROR(ERRCLS_ADD_RES, EMA137, (ErrVal)ret, 
                      "maBldOpenMsg () Failed at encoding extCont");
#endif
          if (s->ctlp.mBuf != NULLP)
          {
             (Void)SPutMsg(s->ctlp.mBuf);
          }
          (Void)SPutMsg(mBuf);
          RETVALUE(RFAILED);
       }
       maBZero((U8 *)&s->curDlgCp->extCont, sizeof(MaExtContSeq));
       if (s->ctlp.mBuf != (Buffer *)NULLP)
       {
          (Void)SCatMsg(mBuf, s->ctlp.mBuf, M2M1);
          (Void)SPutMsg(s->ctlp.mBuf);
          s->ctlp.mBuf = (Buffer *)NULLP;
       }
    }
    (Void)SFndLenMsg(mBuf, &len);

    if (srcRef->pres == TRUE)
    {
       for (i = srcRef->len -1; i>=0; i--)
       {
         ret = SAddPreMsg(srcRef->val[i], mBuf);
         if (ret != ROK)
         {
#if (ERRCLASS & ERRCLS_ADD_RES)
           MALOGERROR(ERRCLS_ADD_RES, EMA138, (ErrVal)ret, 
                      "maBldOpenMsg () Failed");
#endif
           (Void)SPutMsg(mBuf);
           RETVALUE(RFAILED);
         }
       } 
       pkArray[0] = (Data)srcRef->len;
       pkArray[1] = (Data)MA_TAG_ORGREF;
       ret = SAddPreMsgMult(pkArray, (MsgLen)2, mBuf);
       if (ret != ROK)
       {
#if (ERRCLASS & ERRCLS_ADD_RES)
         MALOGERROR(ERRCLS_ADD_RES, EMA139, (ErrVal)ret, 
                    "maBldOpenMsg () Failed");
#endif
         (Void)SPutMsg(mBuf);
         RETVALUE(RFAILED);
       }
       msgLen = srcRef->len + 2;

    }

    if (destRef->pres == TRUE)
    {
       for (i = destRef->len -1; i>=0; i--)
       {
         ret = SAddPreMsg(destRef->val[i], mBuf);
         if (ret != ROK)
         {
#if (ERRCLASS & ERRCLS_ADD_RES)
           MALOGERROR(ERRCLS_ADD_RES, EMA140, (ErrVal)ret, 
                      "maBldOpenMsg () Failed");
#endif
           (Void)SPutMsg(mBuf);
           RETVALUE(RFAILED); 
         } 
       }
       pkArray[0] = (Data)destRef->len;
       pkArray[1] = (Data)MA_TAG_DESTREF;
       ret = SAddPreMsgMult(pkArray, (MsgLen)2, mBuf);
       if (ret != ROK)
       {
#if (ERRCLASS & ERRCLS_ADD_RES)
         MALOGERROR(ERRCLS_ADD_RES, EMA141, (ErrVal)ret, 
                    "maBldOpenMsg () Failed");
#endif
         (Void)SPutMsg(mBuf);
         RETVALUE(RFAILED);
       }
      msgLen += destRef->len + 2;
    }
  
    /* Add the length and tag of the MAP Open PDU */
    idx = 0;
    curLen = msgLen + len;
    MA_ENCODE_LEN(curLen,idx)
    pkArray[idx++] = (Data)MA_TAG_OPEN_PDU;
    ret = SAddPreMsgMult(pkArray, (MsgLen)idx, mBuf);
    if (ret != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
      MALOGERROR(ERRCLS_ADD_RES, EMA142, (ErrVal)ret, "maBldOpenMsg () Failed");
#endif
      (Void)SPutMsg(mBuf);
      RETVALUE(RFAILED);
    }

#if MAP_REL99
#if (MAP_SEC && LMAV2)
    if (s->curDlgCp->mapSec == TRUE)
    {
       /* build dialogue Id in maBldPortOpenPdu() */
       RETVALUE(ROK);
    }
#endif /* MAP_SEC */
#endif

    if ((ret = maBldDlgId (mBuf, FALSE)) != ROK)
    {
      SPutMsg(mBuf);
      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "maBldOpenMsg() failed, unable to build dialog Id.\n"));
      RETVALUE(RFAILED);
    }

    RETVALUE(ROK);
} /* end of maBldOpenMsg */


/*
*
*       Fun:   maProcessInvk 
*
*       Desc:  This function process the invoke component  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maProcessInvk 
(
MaSap   *s,             /* SAP pointer */
MaDlgCp *dlgCp,         /* Dialogue Control Point */
StComps *cmpEv          /* Component Event */
)
#else
PUBLIC S16 maProcessInvk (s, dlgCp, cmpEv)
MaSap      *s;          /* SAP pointer */
MaDlgCp    *dlgCp;      /* Dialogue Control Point */
StComps    *cmpEv;      /* Component Event */
#endif
{
  MaCmpCp    *cmpCp;
  MaCmpCp    *lcmpCp;
  MaCmpCp    tcmpCp;
  StStr      errStr;
  U8         oprClass;
  U16        tmrVal;
  MaUsrErr   usrErr;
  MaPrvErr   prvErr;
  S16        ret = ROK;

  TRC2(maProcessInvk)

  usrErr.pres = FALSE;
  prvErr.pres = FALSE;

  if(dlgCp->cmpPresFlg != TRUE) 
  {
    /* send notice indication to the map user */
    MaUiMatNotInd(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId, 
                  MAT_ABEVT_RCVD_PEER);
    RETVALUE(ROK);
  } 

  cmpCp = maFindHashInvk(dlgCp, &cmpEv->stInvokeId,FALSE);

  if (cmpCp != (MaCmpCp *)NULLP)
  {
     /* duplicate invoke Id send the Tc-U Reject */
     maSndTcRej(s, cmpEv, STU_PROB_INVOKE, STU_DUP_INVOKE);

     /* send notice indication to the map user */
     MaUiMatNotInd(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId, 
     MAT_ABEVT_RCVD_PEER);
     RETVALUE(ROK);
  }
  else
  {
     /* create a new Component control point */
     if(maCb.maCP.nmbOpr  ==  maCb.maInvCnt)
     {
        /* send notice indication to the map user */
        MaUiMatNotInd(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId, 
                      MAT_MAX_INVOKE_RCHD);
        MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
               "maProcessInvk() failed, maxmum operations limit reached.\n"));
        RETVALUE(RFAILED);
     }

     cmpCp = maInsHashInv(s, &cmpEv->stInvokeId,FALSE);
     if (cmpCp == (MaCmpCp *)NULLP)
     {
#if (ERRCLASS & ERRCLS_DEBUG)
        MALOGERROR(ERRCLS_DEBUG, EMA143, (ErrVal)0, \
                   "maProcessInv() No static Memory left");
#endif
        maSendAlrm(NEW,s->sapId, STMATSAP, LMAT_OUT_OF_RSRS, "maProcessInvk",
                   LMA_EVENT_INVCB_ALLOC_FAIL,LCM_CATEGORY_RESOURCE,
                   LCM_CAUSE_INV_PAR_VAL);
        MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
               "maProcessInvk() failed, fail to insert hash list.\n"));
        RETVALUE(RFAILED);
     }  
     /* update the component control point */
     cmpCp->spDlgId = dlgCp->spDlgId;
     cmpCp->oprCode = cmpEv->stOpCode.string[0];
     cmpCp->sap = s;
  }

#if MAP_REL99
#if (MAP_SEC && LMAV2)

  if (dlgCp->mapSec == TRUE)
  {
     if ((cmpEv->stOpCode.string[0] == MAT_SEC_TRANS_CLASS1) ||
         (cmpEv->stOpCode.string[0] == MAT_SEC_TRANS_CLASS2) ||
         (cmpEv->stOpCode.string[0] == MAT_SEC_TRANS_CLASS3) ||
         (cmpEv->stOpCode.string[0] == MAT_SEC_TRANS_CLASS4))
     {
        /* Operation code is updated inside this function 
         * in cmpCp and cmpEv */

        if((ret = maProcSecInvk(s, dlgCp, cmpEv, cmpCp)) != ROK)
        {
           RETVALUE(ROK);
        }
     }
     else
     {
         /* un-protected message is not allowed in a secure dialogue */
         maDropSecOprReq(s, cmpEv, dlgCp, LMA_CAUSE_INV_UNSEC_OPR);
         MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                "maProcessInvk() failed, MAPSec is required.\n"));
         RETVALUE(ROK);
     }
  }

#endif /* MAP_SEC */
#endif

  /* check whether operation is supported */ 
  
  if (dlgCp->apn.val[dlgCp->apn.len -1] == LMA_VER1)
  {
     ret = maIsOprSupp(s, cmpCp->oprCode, &oprClass, &tmrVal, LMA_VER1);
  }
  else
  {
     ret = maIsOprApnSupp(s, cmpCp->oprCode, dlgCp, &oprClass, &tmrVal);
  }
  if (ret != ROK)
  {
     /* operation code not supported send the Tc-U Reject */
     maSndTcRej(s, cmpEv, STU_PROB_INVOKE, STU_UNREC_OPR);
     if(dlgCp->apn.val[dlgCp->apn.len - 1] < LMA_VER2P)
     {
        /* send notice indication to the map user */
        MaUiMatNotInd(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId, 
                      MAT_ABEVT_RCVD_PEER);
     }
     /* TODO - to add free inv */
     RETVALUE(ROK);
  }
  cmpCp->oprClass = oprClass;
  cmpCp->invkTmr = tmrVal;

   if (cmpEv->stLinkedId.pres == TRUE)
   {
      lcmpCp = maFindHashInvk(dlgCp, &cmpEv->stLinkedId,TRUE);
      if (lcmpCp == (MaCmpCp *)NULLP)
      {

        /* send notice indication to the map user */
        MaUiMatNotInd(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId, 
                      MAT_ABEVT_RCVD_PEER);

        /* send the Tc-U Reject */
        maSndTcRej(s, cmpEv, STU_PROB_INVOKE, STU_UNX_LINKED_OP);

        /* remove the component control point */
        maRemHashInv(dlgCp, &cmpEv->stInvokeId,FALSE);
        RETVALUE(ROK);
      }

      /* check the operation class */
      if (oprClass == MAT_OPRCLASS4)
      {
      
        if (maIsLinkedOpr(lcmpCp->oprCode, cmpCp->oprCode, TRUE) != ROK)
        {
           /* Send confirm to the user */
           prvErr.pres = TRUE;
           prvErr.errSrc = MAT_REMOTE_PRV_ERR;
           prvErr.errCode = MAT_INVRSP_RCVD;
           maSndSSCfm(s, lcmpCp, &prvErr, &usrErr);

           /* send the Tc-U Reject */
           maSndTcRej(s, cmpEv, STU_PROB_INVOKE, STU_LINKED_RESP_UNX);
           /* remove the component control point */
           maRemHashInv(dlgCp, &cmpEv->stInvokeId,FALSE);
           RETVALUE(ROK);
        }

        if ( (ret = maDecOpr(s, cmpEv->stOpCode.string[0], MAT_SS_REQ)) != ROK)
        {
           /* Send confirm to the user */
           prvErr.pres = TRUE;
           prvErr.errSrc = MAT_REMOTE_PRV_ERR;
           prvErr.errCode = MAT_INVRSP_RCVD;
           maSndSSCfm(s, lcmpCp, &prvErr, &usrErr);

           /* send the Tc-U Reject */
           maSndTcRej(s, cmpEv, STU_PROB_INVOKE, STU_MISTYPED_PARAM);
           /* remove the component control point */
           maRemHashInv(dlgCp, &cmpEv->stInvokeId,FALSE);
           RETVALUE(ROK);
        }
        maSndSSCfm(s, lcmpCp, &prvErr, &usrErr);
        RETVALUE(ROK);
      }
      else
      {
         /* assumption here is that there is no linked 
          * class 1,2,3 operation */
         lcmpCp->impCfmFlg = TRUE;
      }
   }

  /* decode the operation parameters */
  ret = maDecOpr(s, cmpCp->oprCode,MAT_SS_REQ);
  if (ret != ROK)
  {
      if (s->ctlp.errCode == MAT_MISTYPE_PARAM)
      {
         maSndTcRej(s, cmpEv, STU_PROB_INVOKE, STU_MISTYPED_PARAM);
      }
      else
      {
        if( (oprClass == MAT_OPRCLASS1) || (oprClass == MAT_OPRCLASS2))
        {
           /* operation parameter not supported send the Tc-U Error */
           errStr.len = 1;
           errStr.string[0] = s->ctlp.errCode;
           maSndTcErr(s, &cmpEv->stInvokeId, &errStr, cmpCp, NULLP);
        }
      }

      /* send notice indication to the map user */
      MaUiMatNotInd(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId, 
                    MAT_ABEVT_RCVD_PEER);

      /* remove the component control point */
      maRemHashInv(dlgCp, &cmpEv->stInvokeId,FALSE);
      RETVALUE(ROK);
  }
  /* update the linked Id if present in Invoke */
  if (cmpEv->stLinkedId.pres == TRUE)
  {
    cmpCp->lnkId.pres = TRUE;
    cmpCp->lnkId.octet = cmpEv->stLinkedId.octet;
  }
  cmCopy((U8 *) cmpCp, (U8 *)&tcmpCp,sizeof(MaCmpCp));

#ifdef XW_IND_OPTIMIZE/*must work in NO static event struct*/
#ifndef MA_STATIC_EVT_STRUCT
   if((dlgCp->suDlgId == 0)&&(dlgCp->dsmState == MA_DLG_PENDING))
   {
       if(maStoreEvtToCmpCp(dlgCp, cmpCp, s->evtPtr) != ROK)
       {
        /* send notice indication to the map user */
          MaUiMatNotInd(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId, 
                    MAT_ABEVT_RCVD_PEER);

        /*store failed ,free the Dec struct*/
          maFreeEncEv(s, s->evtPtr, cmpCp);
       
          /* remove the component control point */
          maRemHashInv(dlgCp, &cmpEv->stInvokeId,FALSE);
          RETVALUE(RFAILED);
       }
   }
   else
#endif
#endif
   {
    if (oprClass == MAT_OPRCLASS4)
    {
     /* remove the component control point */
      maRemHashInv(dlgCp, &cmpEv->stInvokeId,FALSE);
    }
    else
    {
    cmpCp->ssmState = MA_SSM_WAITRSP;
    maStartTmr(MA_GAURD_TMR,s, cmpCp); 
#ifdef ZJ
    MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_ADD)
    cmTuUpdPeer(&zjCb.tuCb);
#endif
    }
    maSndSSInd(s, &tcmpCp);
  }
  RETVALUE(ROK);

} /* maProcessInvk */

/*
*
*       Fun:   maProcessInvM02 
*
*       Desc:  This function process the invoke component 
*              in Wiat for Init Data state 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
extern Void maStoreEvtToCmp(MaCmpCp * cmpCp, U8 * evt);
#ifdef ANSI
PUBLIC S16 maProcessInvM02 
(
MaSap   *s,             /* SAP pointer */
MaDlgCp *dlgCp,         /* Dialogue Control Point */
StComps *cmpEv          /* Component Event */
)
#else
PUBLIC S16 maProcessInvM02 (s, dlgCp, cmpEv)
MaSap      *s;          /* SAP pointer */
MaDlgCp    *dlgCp;      /* Dialogue Control Point */
StComps    *cmpEv;      /* Component Event */
#endif
{
  StDlgEv    dlgEv;
  MaOpenEv   openEv;
  MaCmpCp    *cmpCp;
  MaCmpCp    tcmpCp;
  U8         oprClass;
  U16        tmrVal;
  S16        ret = ROK;
#ifdef ZJ
  Bool       rtUpd;
#endif
#ifndef MA_STATIC_EVT_STRUCT
  U8        *tmpEvtPtr;             /* Pointer to event structure */
#endif

  TRC2(maProcessInvM02)

  maBZero((U8 *)&openEv, sizeof (MaOpenEv));
 
  ret = maGetAcn(s ,cmpEv->stOpCode.string[0], &openEv.apn);
  cmCopy((U8 *)&openEv.apn, (U8 *)&dlgCp->apn, sizeof (MaApConName)); 

  if( ret != ROK)
  {
     dlgEv.pres = FALSE;
     /* Abort the dialogue */
     maAbrtDlg(s, &dlgEv, MAT_P_ABNORMAL_DLG); 
     maDlgIdle(s);
     RETVALUE(ROK);
  }
#ifdef ZJ
   /* For version 1 dialogue, we have to wait for operation to 
    * get ACN and decide if update is required.
    */
   if ((dlgCp->upd != TRUE) && (maIsUpdReq(s,dlgCp) == TRUE))
   {
      dlgCp->upd = TRUE;
      cmTuAddMapping (&zjCb.tuCb, (PTR)dlgCp);
      MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_ADD)
      MA_UPD_PEER(dlgCp->upd)
   }
   rtUpd = dlgCp->upd;
#endif

  if ((ret = maIsOprSupp(s, cmpEv->stOpCode.string[0], &oprClass, &tmrVal,  dlgCp->apn.val[dlgCp->apn.len -1])) != ROK)
  {
    /* operation code not supported send the Tc-U Reject */
    maSndTcRej(s, cmpEv, STU_PROB_INVOKE, STU_UNREC_OPR);

    /* send notice indication to the map user */
    MaUiMatNotInd(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId, MAT_ABEVT_RCVD_PEER);
    RETVALUE(ROK);
  }

#if MAP_REL99
#if (MAP_SEC && LMAV2)

  if (maCb.maCP.secGenCfg.rxFbInd == LMA_FB_DISABLED)
  {
     /* SPD mandates the use of MAPSec for included original 
      * component identifier, the message is discarded */

     dlgEv.pres = FALSE;
#ifdef ZJ
     MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
     MA_UPD_PEER(rtUpd)
#endif
     /* Abort the dialogue */
     maAbrtDlg(s, &dlgEv, MAT_P_ABNORMAL_DLG); 
     maDlgIdle(s);
     RETVALUE(ROK);
  }

#endif /* MAP_SEC */
#endif

  if (maChkLoad(s) == FALSE)
  {
      /* System is overloaded don't except the dialogue */
     dlgEv.pres = FALSE;
#ifdef ZJ
     MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
     MA_UPD_PEER(rtUpd)
#endif
     /* Abort the dialogue */
     maAbrtDlg(s, &dlgEv, MAT_P_ABNORMAL_DLG); 
     maDlgIdle(s);
     RETVALUE(ROK);
  }

  if((cmpEv->stOpCode.string[0] == MAT_BEGIN_SUBS_ACTV) &&
     (cmpEv->stLastCmp == TRUE))
  {
     dlgEv.pres = FALSE;
#ifdef ZJ
     MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
     MA_UPD_PEER(rtUpd)
#endif
     /* Abort the dialogue */
     maAbrtDlg(s, &dlgEv, MAT_P_ABNORMAL_DLG); 
     maDlgIdle(s);
     RETVALUE(ROK);
  }
  cmpCp = maFindHashInvk(dlgCp, &cmpEv->stInvokeId,FALSE);

  if (cmpCp != (MaCmpCp *)NULLP)
  {
     /* duplicate invoke Id send the Tc-U Reject */
     maSndTcRej(s, cmpEv, STU_PROB_INVOKE, STU_DUP_INVOKE);

     dlgEv.pres = FALSE;
#ifdef ZJ
     MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
     MA_UPD_PEER(rtUpd)
#endif
     /* Abort the dialogue */
     maAbrtDlg(s, &dlgEv, MAT_P_ABNORMAL_DLG); 
     maDlgIdle(s);
     RETVALUE(ROK);
  }
  else
  {
    /* create a new Component control point */
    if(maCb.maCP.nmbOpr  == maCb.maInvCnt)
    {
      dlgEv.pres = FALSE;
#ifdef ZJ
      MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
      MA_UPD_PEER(rtUpd)
#endif
      /* Abort the dialogue */
      maAbrtDlg(s, &dlgEv, MAT_P_ABNORMAL_DLG); 
      maDlgIdle(s);
      /* send notice indication to the map user */
      /* Since the dialogue context is removed, spDlgId and suDlgId 
      ** are set to NULL 
      */
      MaUiMatNotInd(&s->maPstMU, s->suId, (0), (0),MAT_MAX_INVOKE_RCHD);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "maProcessInvM02() failed, max invoke number(%ld) reached.\n", maCb.maInvCnt));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "maProcessInvM02() failed, max invoke number(%d) reached.\n", maCb.maInvCnt));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
    }

    cmpCp = maInsHashInv(s, &cmpEv->stInvokeId,FALSE);
    if (cmpCp == (MaCmpCp *)NULLP)
    {
      dlgEv.pres = FALSE;
#ifdef ZJ
      MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
      MA_UPD_PEER(rtUpd)
#endif
      /* Abort the dialogue */
      maAbrtDlg(s, &dlgEv, MAT_P_ABNORMAL_DLG); 
      maDlgIdle(s);
      RETVALUE(ROK);
    }
  }  
  /* update the component control point */
  cmpCp->oprClass = oprClass;
  cmpCp->invkTmr = 0;
  cmpCp->spDlgId = dlgCp->spDlgId;
  cmpCp->oprCode = cmpEv->stOpCode.string[0];
  cmpCp->sap = s;

  /* decode the operation parameters */
  ret = maDecOpr(s, cmpEv->stOpCode.string[0],MAT_SS_REQ);
  if (ret != ROK)
  {
     dlgEv.pres = FALSE;
#ifdef ZJ
     MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
     MA_UPD_PEER(rtUpd)
#endif
     /* Abort the dialogue */
     maAbrtDlg(s, &dlgEv, MAT_P_ABNORMAL_DLG); 
     maDlgIdle(s);
     RETVALUE(ROK);
  }
  
  if (cmpEv->stOpCode.string[0] == MAT_BEGIN_SUBS_ACTV)
  {
    openEv.destRef.pres = ((MaSSEv *)(s->evtPtr))->bgnSubActvReq.imsi.pres;
    openEv.srcRef.pres = ((MaSSEv *)(s->evtPtr))->bgnSubActvReq.orgEntNmb.pres;
    openEv.destRef.len = ((MaSSEv *)(s->evtPtr))->bgnSubActvReq.imsi.len;
    openEv.srcRef.len = ((MaSSEv *)(s->evtPtr))->bgnSubActvReq.orgEntNmb.len;
 
    cmCopy( ((MaSSEv *)(s->evtPtr))->bgnSubActvReq.imsi.val,(U8 *)&openEv.destRef.val,
           ((MaSSEv *)(s->evtPtr))->bgnSubActvReq.imsi.len);
    cmCopy( ((MaSSEv *)(s->evtPtr))->bgnSubActvReq.orgEntNmb.val,(U8 *)&openEv.srcRef.val,
           ((MaSSEv *)(s->evtPtr))->bgnSubActvReq.orgEntNmb.len);
    
  }
  /* Send MAP Open Indication to the Upper user */

  cmCopySpAddr(&dlgCp->destAddr, &openEv.destAddr);
  cmCopySpAddr(&dlgCp->srcAddr, &openEv.srcAddr);
  dlgCp->dsmState = MA_DLG_PENDING;
  cmCopy((U8 *) cmpCp, (U8 *)&tcmpCp,sizeof(MaCmpCp));
  /* This is because s->evtPtr might be modified in case of TC */
#ifndef MA_STATIC_EVT_STRUCT
  tmpEvtPtr = s->evtPtr;
#endif
#ifdef ZJ
  MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_MOD)
#endif
  MaUiMatOpenInd(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId, &openEv);
  if(s->curDlgCp == NULLP)
  {
    /* Dialogue maybe deallocated by negative immediate openRsp in TC case  */
#ifndef MA_STATIC_EVT_STRUCT
    maFreeEncEv(s, tmpEvtPtr, &tcmpCp);
#endif
    RETVALUE(ROK);
  }

/**/
#ifdef XW_IND_OPTIMIZE/*must work in NO static event struct*/
#ifndef MA_STATIC_EVT_STRUCT
   if((dlgCp->suDlgId == 0)&&(dlgCp->dsmState == MA_DLG_PENDING))
   {
       if(maStoreEvtToCmpCp(dlgCp, cmpCp, s->evtPtr) != ROK)
       {
        /* send notice indication to the map user */
          MaUiMatNotInd(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId, 
                    MAT_ABEVT_RCVD_PEER);

        /*store failed ,free the Dec struct*/
          maFreeEncEv(s, s->evtPtr, cmpCp);
       
          /* remove the component control point */
          maRemHashInv(dlgCp, &cmpEv->stInvokeId,FALSE);
          RETVALUE(RFAILED);
       }
   }
   else
#endif
#endif
   {
      if ((oprClass == MAT_OPRCLASS4) || 
           (cmpEv->stOpCode.string[0] == MAT_BEGIN_SUBS_ACTV))
      {
         /* remove the component control point */
          maRemHashInv(dlgCp, &cmpEv->stInvokeId,FALSE);
      }
      else
      {
         cmpCp->ssmState = MA_SSM_WAITRSP;
         maStartTmr(MA_GAURD_TMR,s, cmpCp); 
       #ifdef ZJ
         MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_ADD)
       #endif
      }
     #ifdef ZJ
      cmTuUpdPeer(&zjCb.tuCb);  
     #endif
 
      maSndSSInd(s, &tcmpCp);
   }

   RETVALUE(ROK);

} /* maProcessInvM02 */

/*
*
*       Fun:   maProcessRetRsltL    
*
*       Desc:  This function process the return result last 
*              componet from TCAP. 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maProcessRetRsltL 
(
MaSap     *s,           /* MAP SAP */
MaDlgCp *dlgCp,         /* Dialogue Control Point */
StComps *cmpEv          /* Component Event */
)
#else
PUBLIC S16 maProcessRetRsltL (s, dlgCp, cmpEv)
MaSap     *s;           /* MAP SAP */
MaDlgCp    *dlgCp;      /* Dialogue Control Point */
StComps    *cmpEv;      /* Component Event */
#endif
{
  MaCmpCp     *cmpCp;
  Buffer      *mBuf;
  MaUsrErr    usrErr;
  MaPrvErr    prvErr;
/* ma002.203 - Changed the type from S16 to MsgLen */
  MsgLen      len;
  S16         ret;
  U8          allocFlg;
  U8          oprCode;
#ifdef ZJ
  Bool        rtUpd;
#endif

  TRC2(maProcessRetRsltL)

  allocFlg = 0;
  mBuf = s->crntRxMsg;
  usrErr.pres = FALSE;
  prvErr.pres = FALSE;
#ifdef ZJ
  rtUpd = dlgCp->upd;
#endif

  cmpCp = maFindHashInvk(dlgCp, &cmpEv->stInvokeId,TRUE);

  if(cmpCp == (MaCmpCp *)NULLP)
  {
    /* result not correct send the Tc-U Reject */
    maSndTcRej(s, cmpEv, STU_PROB_RET_RES, STU_RR_UNREC_INVKID);
#ifdef MATV2
    /* send notice indication to the map user */
    MaUiMatNotInd(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId, 
                    MAT_ABEVT_RCVD_PEER);
#endif /* MATV2 */

    RETVALUE(ROK);
  }
  if ((cmpCp->ssmState != MA_SSM_WAITCFM) ||
      (cmpCp->oprClass == MAT_OPRCLASS2) ||
      (cmpCp->oprClass == MAT_OPRCLASS4))
  {
#ifdef ZJ
    MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
    cmTuUpdPeer(&zjCb.tuCb);  
#endif
    /* result not correct send the Tc-U Reject */
    maSndTcRej(s, cmpEv, STU_PROB_RET_RES, STU_UNX_RETRSLT);
    /* send confirm to the map user */
    prvErr.pres = TRUE;
    prvErr.errSrc = MAT_REMOTE_PRV_ERR;
    prvErr.errCode = MAT_INVRSP_RCVD;
    if (cmpCp->mBuf != (Buffer *)NULLP)
    {
      (Void)SPutMsg(cmpCp->mBuf);
      cmpCp->mBuf = (Buffer *)NULLP;
    }
    maSndSSCfm(s, cmpCp, &prvErr, &usrErr);
    maRemHashInv(dlgCp,&cmpCp->invkId,cmpCp->initiator);
    RETVALUE(ROK);
  }

  oprCode = cmpCp->oprCode;
#if MAP_REL99
#if (MAP_SEC && LMAV2)
  if (dlgCp->mapSec == TRUE)
  {
     switch(cmpCp->oprClass)
     {
        case MAT_OPRCLASS1:
           oprCode = MAT_SEC_TRANS_CLASS1;

           break;
        case MAT_OPRCLASS3:
           oprCode = MAT_SEC_TRANS_CLASS3;

           break;
        default:
#if (ERRCLASS & ERRCLS_DEBUG)
           MALOGERROR(ERRCLS_DEBUG, EMA144, (ErrVal)cmpCp->oprClass, \
                      "maProcessRetRsltL() Failed, wrong operation class.");
#endif
           if (cmpCp->mBuf != (Buffer *)NULLP)
           {
             (Void)SPutMsg(cmpCp->mBuf);
             cmpCp->mBuf = (Buffer *)NULLP;
           }
           RETVALUE(RFAILED);
           break;
     }
  }
#endif
#endif
  if ( (mBuf != NULLP) && SFndLenMsg(mBuf,&len) == ROK &&
       len > 0 && (oprCode != cmpEv->stOpCode.string[0]))
  {
#ifdef ZJ
     MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
     cmTuUpdPeer(&zjCb.tuCb);  
#endif
     /* result not correct send the Tc-U Reject */
     maSndTcRej(s, cmpEv, STU_PROB_RET_RES, STU_UNX_RETRSLT);

     /* send confirm to the map user */
     prvErr.pres = TRUE;
     prvErr.errSrc = MAT_LOCAL_PRV_ERR;
     prvErr.errCode = MAT_INVRSP_RCVD;
     if (cmpCp->mBuf != (Buffer *)NULLP)
     {
       (Void)SPutMsg(cmpCp->mBuf);
       cmpCp->mBuf = (Buffer *)NULLP;
     }
     maSndSSCfm(s, cmpCp, &prvErr, &usrErr);
     maRemHashInv(dlgCp,&cmpCp->invkId,cmpCp->initiator);
     RETVALUE(ROK);
  }

#if MAP_REL99
#if (MAP_SEC && LMAV2)
  if ((mBuf != (Buffer *)NULLP) && (dlgCp->mapSec == TRUE))
  {
     if ((ret = maProcSecRetRsltL(s, dlgCp, cmpEv, cmpCp)) != ROK)
     {
#ifdef ZJ
        MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
        cmTuUpdPeer(&zjCb.tuCb);  
#endif
        RETVALUE(ROK);
     }
  }
#endif /* MAP_SEC */
#endif
  if (cmpCp->mBuf != (Buffer *)NULLP)
  {
     if(mBuf != (Buffer *)NULLP)
     {
        ret = maAddLastResult(mBuf,cmpCp);
        if(ret != ROK)
        {
#ifdef ZJ
           MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
           cmTuUpdPeer(&zjCb.tuCb);  
#endif
           /* result not correct send the Tc-U Reject */
           maSndTcRej(s, cmpEv, STU_PROB_RET_RES, STU_UNX_RETRSLT);

           /* send confirm to the map user */
           prvErr.pres = TRUE;
           prvErr.errSrc = MAT_LOCAL_PRV_ERR;
           prvErr.errCode = MAT_INVRSP_RCVD;
           maSndSSCfm(s, cmpCp, &prvErr, &usrErr);

           maRemHashInv(dlgCp,&cmpCp->invkId,cmpCp->initiator);
           RETVALUE(ROK);
        }
     }
     else 
     {
        mBuf = cmpCp->mBuf;
        cmpCp->mBuf = (Buffer *)NULLP;
        allocFlg = 1;
     }
     
  }

  if (mBuf == NULLP)
  {
     if(SGetMsg(maCb.maInit.region, maCb.maInit.pool, &mBuf) != ROK)
     {
#ifdef ZJ
        MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
        cmTuUpdPeer(&zjCb.tuCb);  
#endif
        /* send confirm to the map user */
        prvErr.pres = TRUE;
        prvErr.errSrc = MAT_LOCAL_PRV_ERR;
        prvErr.errCode = MAT_INVRSP_RCVD;
        maSndSSCfm(s, cmpCp, &prvErr, &usrErr);
        maRemHashInv(dlgCp,&cmpCp->invkId,cmpCp->initiator);
        RETVALUE(ROK);
     }
     else
     {
        allocFlg = 1;
     }
  }

  ret = ROK;
#ifdef MA_MULT_SEG_DECODE
  ret = maProcessSegments(s,dlgCp,mBuf,cmpCp);
#else /* MA_MULT_SEG_DECODE */
  if (mBuf != NULLP)
  {
     ret = maDecOpr(s,cmpCp->oprCode, MAT_SS_RSP);
  }
#endif /* MA_MULT_SEG_DECODE */
#ifdef MA_SEG
  if(ret == ROK)
  {
     /* once the decoding is over, check for the rules */
     ret = maChkSegRules(s,(PTR)s->evtPtr,cmpCp->oprCode,
                 dlgCp->apn.val[dlgCp->apn.len-1]);
#ifndef MA_STATIC_EVT_STRUCT
     if (ret != ROK)
     {
        maFreeEncEv(s, s->evtPtr, cmpCp);
     }
#endif
  }
#endif /* MA_SEG */

  if (ret != ROK)
  {
    if ((s->ctlp.errCode == MAT_MISTYPE_PARAM) ||
        (s->ctlp.errCode == MAT_DATA_MISSING))
    {
      maSndTcRej(s, cmpEv, STU_PROB_RET_RES, STU_RR_MISTYPED_PAR);
    }
    /* send confirm to the map user */
    prvErr.pres = TRUE;
    prvErr.errSrc = MAT_REMOTE_PRV_ERR;
    prvErr.errCode = MAT_INVRSP_RCVD;
    maSndSSCfm(s, cmpCp, &prvErr, &usrErr);
  }
  else
  {
    maSndSSCfm(s, cmpCp, &prvErr, &usrErr);
  }
#ifdef ZJ
  MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
  cmTuUpdPeer(&zjCb.tuCb);  
#endif
  /* remove the component control point */
  maRemHashInv(dlgCp, &cmpEv->stInvokeId,TRUE);

  if(allocFlg && mBuf)
  {
     SPutMsg(mBuf);
  }

  RETVALUE(ROK);
  
} /* maProcessRetRsltL  */

#ifdef MA_MULT_SEG_DECODE
/*
*
*       Fun:   maProcessSegments    
*
*       Desc:  This function process the return result last 
*              componet from TCAP, along with the components if present. 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maProcessSegments 
(
MaSap     *s,           /* MAP SAP */
MaDlgCp *dlgCp,         /* Dialogue Control Point  */
Buffer  *mBuf,          /* Possibly last segment   */
MaCmpCp *cmpCp          /* component control point */
)
#else
PRIVATE S16 maProcessSegments (s, dlgCp, mBuf,cmpCp)
MaSap     *s;           /* MAP SAP */
MaDlgCp *dlgCp;         /* Dialogue Control Point  */
Buffer  *mBuf;          /* Possibly last segment   */
MaCmpCp *cmpCp;         /* component control point */
#endif
{

#ifndef MA_STATIC_EVT_STRUCT
  U32  evSz;  /* event structure size */
#endif /* MA_STATIC_EVT_STRUCT */
  S16  ret;   /* return value         */

  TRC2(maProcessSegments)

  ret = ROK;
  /* Queue the mBuf as last message segment in the queue */
  SQueueLast(mBuf,&cmpCp->segQ);

  SDequeueFirst(&s->crntRxMsg,&cmpCp->segQ);
#ifndef MA_STATIC_EVT_STRUCT
  /* store the allocated memory before decOpr */
  evSz = maMemAlloc;
#endif /* MA_STATIC_EVT_STRUCT */
  ret = maDecOpr(s,cmpCp->oprCode, MAT_SS_RSP);
#ifndef MA_STATIC_EVT_STRUCT
  /* calculate the event structure size allocated indirectly */
  /* since only one allocation is done at the most within maDecOpr */
  evSz = (maMemAlloc - evSz);
#endif /* MA_STATIC_EVT_STRUCT */
  /* Until the last message segment is decoded/freed */
  while (s->crntRxMsg != mBuf)
  {
     SPutMsg(s->crntRxMsg);
     SDequeueFirst(&s->crntRxMsg,&cmpCp->segQ);
     if(ret == ROK)
     {
        ret = maDecOprPar(s,(U8 *)(s->evtPtr),dlgCp->apn.val[dlgCp->apn.len-1], 
                           s->cfg.swtch, MAT_SS_RSP, s->ctlp.idx);
#ifndef MA_STATIC_EVT_STRUCT
        if(ret != ROK)
        {
           /* Free the event structure  */
           (Void) maFree((Data *)s->evtPtr,evSz);
        }
#endif /* MA_STATIC_EVT_STRUCT */
     }
  }
  /* freeing up the last message segment is upto the parent function */
  RETVALUE(ret);
} /* maProcessSegments */
#endif /* MA_MULT_SEG_DECODE */

/*
*
*       Fun:   maAddLastResult
*
*       Desc:  This function process the partial return result last 
*              Concatenation method: 
*              In this scheme the code assumes that the 
*              segments are created at the parameter boundaries of the sequence.
*              The code is intelligent enough to take care of 
*              the differences in the length encodings 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maAddLastResult 
(
Buffer  *mBuf,          /* Possibly last segment   */
MaCmpCp *cmpCp          /* component control point */
)
#else
PRIVATE S16 maAddLastResult(mBuf,cmpCp)
Buffer  *mBuf;          /* Possibly last segment   */
MaCmpCp *cmpCp;         /* component control point */
#endif
{
    Data data1;   /* dummy data variable */
    Bool eocFlg;  /* dummy eoc Flag used for RemLen() */
    S16  ret;     /* return value */
    MsgLen len;   /* length of the message */

    /* cmpCp->mBuf has the concatenated  message which 
     * represents the sequence with the parameters received
     * until now thorugh RR-NL segments. This sequence is 
     * encoded in indefinite form
     * Remove EOC from the cmpCp->mBuf 
     */
    SFndLenMsg(mBuf,&len);
    if(len > 0)
    {    
       /* length of the last component is non-zero */      
       /* Remove one byte MAP tag and length form */
       ret = SRemPreMsg(&data1,mBuf);
       if(ret == ROK)
       {
          ret = maRemLen(mBuf,&eocFlg);
       }
       if (ret != ROK)
       {
          RETVALUE(RFAILED);
       }
       /* Add EOC if the mBuf is not having it */
       if(eocFlg == FALSE)
       {
          SAddPstMsg(0x0,mBuf);
          SAddPstMsg(0x0,mBuf);
       }
       SRemPstMsg(&data1,cmpCp->mBuf);
       SRemPstMsg(&data1,cmpCp->mBuf);
    } /* non zero length */
    (Void)SCatMsg(mBuf, cmpCp->mBuf, M2M1);
    (Void)SPutMsg(cmpCp->mBuf);
    cmpCp->mBuf = (Buffer *)NULLP;

    RETVALUE(ROK);
}/* maAddLastResult */

/*
*
*       Fun:   Send a cancel request
*
*       Desc:  This function sends a cancel request to
*              TCAP
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*       File:  ca_bdy2.c
*
*/
 
#ifdef ANSI
PUBLIC S16 maSndCan
(
MaSap      *sap,          /* sap pointer */
MaDlgCp    *dlg,          /* pointer to the dialogue control */
MaInvokeId *invId         /* Invoke Identifier          */
)
#else
PUBLIC S16 maSndCan(sap, dlg, invId)
MaSap      *sap;          /* sap pointer */
MaDlgCp    *dlg;          /* pointer to the dialogue control */
MaInvokeId *invId;        /* invoke Identifier */
#endif
{
   StComps  cmpEv;        /* component event structure */

   TRC2(maSndCan)

   /* zero out the component event structure */
   cmZero((Data *)&cmpEv, sizeof(StComps));

   /* fill in the component type */
   cmpEv.stCompType        = STU_UNKNOWN;

   /* fill in the invoke id */
   cmpEv.stInvokeId.pres   = invId->pres;
   cmpEv.stInvokeId.octet  = invId->octet;

   /* initialize the cancel flag */
   cmpEv.cancelFlg     = TRUE;

   (Void) MaLiStuCmpReq(&sap->maPstST,
                        sap->spIdTC,
                        dlg->spDlgId,
                        dlg->lowerSpDlgId,
                        &cmpEv,
                        NULLP);
   RETVALUE(ROK);

} /* maSndCan */

#ifdef MA_SEG
/*
*
*
*       Fun:   Check segmentation rules
*
*       Desc:  This function checks for the segmentation related
*              Rules.
*              
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*       File:  ca_bdy2.c
*
*/
 
#ifdef ANSI
PUBLIC S16 maChkSegRules
(
MaSap      *s,         /* sap pointer */
PTR        evPtr,      /* event structure pointer */
U8         oprType,    /* operation code */
U8         ver         /* dialogue version */
)
#else
PUBLIC S16 maChkSegRules(s,evPtr,oprType,ver)
MaSap      *s;          /* sap pointer */
PTR        evPtr;       /* event structure pointer */
U8         oprType;     /* operation code */
U8         ver;         /* dialogue version */
#endif
{
   S16 ret; /* return value */
   TRC2(maChkSegRules)

   s->ctlp.errCode = 0;
   ret = ROK;
   switch(oprType)
   {
    
      case MAT_ROUTINFO: /* send routing information rsp */
      {
         /* version 3 RI Rsp Must have IMSI */
         MaSndRoutInfoRsp *riRsp;
         if(ver == LMA_VER2P)
         {
            
            riRsp = &(((MaCallEv *)evPtr)->sndRoutInfoRsp);
            /* if the choice presence is false (or)
            ** choice is present and choice value not equal to 
            ** true or imsi is absent then IMSI is not present
            ** for version 3 send rout info operation 
            */
            if((riRsp->imsi.elmntPres.pres == FALSE)||
               ((riRsp->imsi.elmntPres.pres == TRUE) && 
               ((riRsp->imsi.elmntPres.val != 2) || 
               (riRsp->imsi.u.ver2PImsi.pres == FALSE))))
            {
               ret = RFAILED;
               s->ctlp.errCode = MAT_DATA_MISSING;
               break;
            }
         }
      } /* send routing information rsp */

      default: /* all other responses */
      {
         break;
      }
   }/* switch */
   RETVALUE(ret);
}/* maChkSegRules */
#endif /* MA_SEG */

/*
*
*       Fun:   maProcessRetRsltNL    
*
*       Desc:  This function process the return result not last 
*              componet from TCAP. 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maProcessRetRsltNL 
(
MaSap     *s,             /* MAP SAP */
MaDlgCp   *dlgCp,         /* Dialogue Control Point */
StComps   *cmpEv          /* Component Event */
)
#else
PUBLIC S16 maProcessRetRsltNL (s, dlgCp, cmpEv)
MaSap      *s;          /* MAP SAP */
MaDlgCp    *dlgCp;      /* Dialogue Control Point */
StComps    *cmpEv;      /* Component Event */
#endif
{
  MaCmpCp     *cmpCp;
  Buffer      *mBuf;
  MaPrvErr    prvErr;
  MaUsrErr    usrErr;
  U8          oprCode;
  S16         ret;
#ifndef MA_MULT_SEG_DECODE
  Data data1; /* dummy data */
  Bool eocFlg; /* eoc flag for remLen() */
#endif /* MA_MULT_SEG_DECODE */
  MsgLen len; /* length */

  TRC2(maProcessRetRsltNL)

  ret = ROK;
  mBuf = s->crntRxMsg;
  cmpCp = maFindHashInvk(dlgCp, &cmpEv->stInvokeId,TRUE);

  if (cmpCp == (MaCmpCp *)NULLP)
  {
    /* result not correct send the Tc-U Reject */
    maSndTcRej(s, cmpEv, STU_PROB_RET_RES, STU_RR_UNREC_INVKID);
    /* send confirm to the map user */
    prvErr.pres = TRUE;
    prvErr.errSrc = MAT_REMOTE_PRV_ERR;
    prvErr.errCode = MAT_INVRSP_RCVD;
    maSndSSCfm(s, cmpCp, &prvErr, &usrErr);
    RETVALUE(ROK);
  }

  if (cmpCp->ssmState != MA_SSM_WAITCFM)
  {
     maSndCan(s,dlgCp,&cmpEv->stInvokeId);

     /* ignore the Component */
     MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
     "maProcessRetRsltNL() failed, invalid SSM state(%d).\n", cmpCp->ssmState));
     RETVALUE(RFAILED);
  }

  /* check whether correct result is received */
  
  oprCode = cmpCp->oprCode;
#if MAP_REL99
#if (MAP_SEC && LMAV2)
  if (dlgCp->mapSec == TRUE)
  {
     switch(cmpCp->oprClass)
     {
        case MAT_OPRCLASS1:
           oprCode = MAT_SEC_TRANS_CLASS1;

           break;
        case MAT_OPRCLASS3:
           oprCode = MAT_SEC_TRANS_CLASS3;

           break;
        default:
#if (ERRCLASS & ERRCLS_DEBUG)
           MALOGERROR(ERRCLS_DEBUG, EMA145, (ErrVal)cmpCp->oprClass, \
                      "maProcessRetRsltNL() Failed, wrong operation class.");
#endif
           RETVALUE(RFAILED);
           break;
     }
  }
#endif
#endif
  if ( (mBuf != NULLP) && SFndLenMsg(mBuf,&len) == ROK &&
       len > 0 && (oprCode != cmpEv->stOpCode.string[0]))
  {

#ifdef ZJ
    MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
    cmTuUpdPeer(&zjCb.tuCb);  
#endif
    /* result not correct send the Tc-U Reject */
    maSndTcRej(s, cmpEv, STU_PROB_RET_RES, STU_RR_MISTYPED_PAR);

    /* send confirm to the map user */
    prvErr.pres = TRUE;
    prvErr.errSrc = MAT_REMOTE_PRV_ERR;
    prvErr.errCode = MAT_INVRSP_RCVD;
    maSndSSCfm(s, cmpCp, &prvErr, &usrErr);

    /* Free the invoke control block  */
    maRemHashInv(dlgCp,&cmpCp->invkId,cmpCp->initiator);

    /* send TC-U-Cancel component */
    RETVALUE(ROK);
  }

  /* NULL partial results are ignored  */
  if(mBuf == (Buffer *)NULLP)
  {
    /* NL component is empty , so return */
    RETVALUE(ROK);
  }
  if(len == 0)
  {
    /* NL component is empty , so return */
    RETVALUE(ROK);
  }

   /* Segmentation - partial result is not null */
#ifndef MA_MULT_SEG_DECODE
  if (cmpCp->mBuf != (Buffer *)NULLP)
  {
#if MAP_REL99
#if (MAP_SEC && LMAV2)
     if (dlgCp->mapSec == TRUE)
     {
        if ((ret = maProcSecRetRsltL(s, dlgCp, cmpEv, cmpCp)) != ROK)
        {
#ifdef ZJ
           MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
           cmTuUpdPeer(&zjCb.tuCb);  
#endif
           RETVALUE(ROK);
        }
     }
#endif /* MAP_SEC */
#endif
    /* Segmentation - partial result is not null */
    /* Remove the tag from latest partial result */
    ret = SRemPreMsg(&data1,mBuf);
    if(ret == ROK)
    {
       /* Remove length form from latest partial result */
       ret = maRemLen(mBuf,&eocFlg);
    }
    if(ret != ROK)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       cmTuUpdPeer(&zjCb.tuCb);  
#endif
       /* result not correct send the Tc-U Reject */
       maSndTcRej(s, cmpEv, STU_PROB_RET_RES, STU_RR_MISTYPED_PAR);

       /* send confirm to the map user */
       prvErr.pres = TRUE;
       prvErr.errSrc = MAT_REMOTE_PRV_ERR;
       prvErr.errCode = MAT_INVRSP_RCVD;
       maSndSSCfm(s, cmpCp, &prvErr, &usrErr);
       maRemHashInv(dlgCp,&cmpCp->invkId,cmpCp->initiator);
       RETVALUE(RFAILED);
    }
    /* If the new segment does not have the EOC, add it */
    if(eocFlg == FALSE)
    {
       SAddPstMsg(0x0,mBuf);
       SAddPstMsg(0x0,mBuf);
    }
    /* remove EOC from the stored mBuf */
    SRemPstMsg(&data1,cmpCp->mBuf);
    SRemPstMsg(&data1,cmpCp->mBuf);
    (Void)SCatMsg(cmpCp->mBuf, mBuf, M1M2);
  }
  else
  {
#if MAP_REL99
#if (MAP_SEC && LMAV2)
     if (dlgCp->mapSec == TRUE)
     {
        if ((ret = maProcSecRetRsltL(s, dlgCp, cmpEv, cmpCp)) != ROK)
        {
#ifdef ZJ
           MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
           cmTuUpdPeer(&zjCb.tuCb);  
#endif
           RETVALUE(ROK);
        }
     }
#endif /* MAP_SEC */
#endif
    if((ret = SCpyMsgMsg(mBuf, s->maPstST.region, s->maPstST.pool, &cmpCp->mBuf)) != ROK)
    {
      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "maProcessRetRsltNL() failed, can not allocate mBuf.\n"));
      RETVALUE(RFAILED);
    }
     
    SExamMsg(&data1,cmpCp->mBuf,1);
    if(data1 != 0x80)
    {
       /* Remove the Tag and length form */
       SRemPreMsg(&data1,cmpCp->mBuf);
       ret = maRemLen(cmpCp->mBuf,&eocFlg);
       if(ret != ROK)
       {
#ifdef ZJ
          MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
          cmTuUpdPeer(&zjCb.tuCb);  
#endif
          /* result not correct send the Tc-U Reject */
          maSndTcRej(s, cmpEv, STU_PROB_RET_RES, STU_RR_MISTYPED_PAR);

          /* send confirm to the map user */
          prvErr.pres = TRUE;
          prvErr.errSrc = MAT_REMOTE_PRV_ERR;
          prvErr.errCode = MAT_INVRSP_RCVD;
          maSndSSCfm(s, cmpCp, &prvErr, &usrErr);
          maRemHashInv(dlgCp,&cmpCp->invkId,cmpCp->initiator);
          RETVALUE(RFAILED);
       }
       /* Add the Tag and indefinite length octet */
       SAddPreMsg(0x80,cmpCp->mBuf);
       SAddPreMsg(data1,cmpCp->mBuf);
       /* Add the EOC octets at the end of the message */
       SAddPstMsg(0x0,cmpCp->mBuf);
       SAddPstMsg(0x0,cmpCp->mBuf);
    }
  }
#else /* MA_MULT_SEG_DECODE */
  {
     Buffer *tmp_mBuf;
#if MAP_REL99
#if (MAP_SEC && LMAV2)
     if (dlgCp->mapSec == TRUE)
     {
        if ((ret = maProcSecRetRsltL(s, dlgCp, cmpEv, cmpCp)) != ROK)
        {
#ifdef ZJ
           MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
           cmTuUpdPeer(&zjCb.tuCb);  
#endif
           RETVALUE(ROK);
        }
     }
#endif /* MAP_SEC */
#endif /* MAP_REL99 */
     if((ret = SCpyMsgMsg(mBuf, s->maPstST.region, s->maPstST.pool, 
                  &tmp_mBuf)) != ROK)
     {
        MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
        "maProcessRetRsltNL() failed, can not allocate mBuf.\n"));
        RETVALUE(RFAILED);
     }
     /* queue the message segment */
     SQueueLast(tmp_mBuf,&cmpCp->segQ);
  }
#endif /* MA_MULT_SEG_DECODE */

  RETVALUE(ROK);
  
} /* maProcessRetRsltNL  */

/*
*
*       Fun:   maProcessRej    
*
*       Desc:  This function handles the reject component from TCAP 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maProcessRej 
(
MaSap    *s,         /* MAP SAP */
MaDlgCp  *dlgCp,     /* Dialogue Control Point */
StComps  *cmpEv,     /* Component Event */
U8       status      /* Reject status- Local/User */
)
#else
PUBLIC S16 maProcessRej (s,dlgCp, cmpEv, status)
MaSap      *s;          /* MAP SAP */
MaDlgCp    *dlgCp;      /* Dialogue Control Point */
StComps    *cmpEv;      /* Component Event */
U8         status;      /* Reject status- Local/User */
#endif
{
  MaCmpCp     *cmpCp;
  U8          probCode;
  U8          probType;
  MaUsrErr    usrErr;
  MaPrvErr    prvErr;
  U8          diag;

  TRC2(maProcessRej)

  cmpCp = NULLP;
  /* get the problem code and problem type */
  probCode = cmpEv->stProbCode.string[0];
  probType = cmpEv->stProbCodeFlg;

  if(probType != STU_PROB_GENERAL)
  {
     if(probType == STU_PROB_INVOKE)
     {
        if ((cmpEv->stInvokeId.pres != TRUE) || 
         ((cmpCp = maFindHashInvk(dlgCp, &cmpEv->stInvokeId,TRUE)) == NULLP))
        {
           cmpCp = NULLP;
        }
     }
     else
     {
        if ((cmpEv->stInvokeId.pres != TRUE) || 
         ((cmpCp = maFindHashInvk(dlgCp, &cmpEv->stInvokeId,FALSE)) == NULLP))
        {
           cmpCp = NULLP;
        }
     }


     /* Check if not able to correlate the component received */
     if (cmpCp == NULLP)
     {
        /* fill the appropriate diagnostics parameter */
        switch(status)
        {
          case STU_COMP_REJ_LOCAL:
             diag = MAT_ABEVT_RCVD_PEER; 
             break;
          case STU_COMP_REJ_USR:
             diag = MAT_EVT_REJ_PEER;
             break;
          case STU_COMP_REJ_REMOTE:
             diag = MAT_ABEVT_DET_PEER;
             break;
          default:
             diag = MAT_ABEVT_DET_PEER;
             break;
        }/* switch(status) */

        /* generate a notice indication to the MAP user */
        MaUiMatNotInd(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId, 
                  diag);

        RETVALUE(ROK); 
     }/* cmpCp == NULLP */
  } /* probType != STU_PROB_GENERAL */

  /* Were able to correlate the component, generate a error confirm if */
  /* problem type is not general problem */


  /* initialize the user and the provider error structures */
  usrErr.pres = FALSE;
  prvErr.pres = FALSE;
  
  /* switch based on the problem type and then problem code */
  switch (probType)
  {
      /* problem is general problem, so generate a notice indication */
      case STU_PROB_GENERAL:
      {
         if (status == STU_COMP_REJ_LOCAL)
         {
            diag = MAT_ABEVT_RCVD_PEER;
         }
         else
         {
            diag = MAT_ABEVT_DET_PEER;
         }

         MaUiMatNotInd(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId, 
                       diag);
         RETVALUE(ROK); 
      }

      /* problem is a invoke problem */
      case STU_PROB_INVOKE:
      {
         switch (probCode)
         {
            case STU_DUP_INVOKE:
               prvErr.pres = TRUE;
               prvErr.errSrc = MAT_REMOTE_PRV_ERR;
               prvErr.errCode = MAT_DUP_INVOKE_ID;
               break;
             case STU_MISTYPED_PARAM:
               prvErr.pres = TRUE;
               prvErr.errSrc = MAT_REMOTE_PRV_ERR;
               prvErr.errCode = MAT_MISTYPE_PARAM;
               break;
             case STU_UNREC_OPR:
               prvErr.pres = TRUE;
               prvErr.errSrc = MAT_REMOTE_PRV_ERR;
               prvErr.errCode = MAT_SERV_NOT_SUPP;
               break;
             case STU_INIT_RELEASE:
               maBZero((U8 *)&usrErr, (U16)sizeof (MaUsrErr));
               usrErr.pres = TRUE;
               usrErr.usrSpecErr.pres = TRUE;
               usrErr.usrSpecErr.val = MAT_USR_INIT_RLS;
               break;
             case STU_RESOURCE_LIMIT:
               maBZero((U8 *)&usrErr, (U16)sizeof (MaUsrErr));
               usrErr.pres = TRUE;
               usrErr.usrSpecErr.pres = TRUE;
               usrErr.usrSpecErr.val = MAT_USR_RSRS_LIMIT;
               break;
             case STU_LINKED_RESP_UNX:
               prvErr.pres = TRUE;
               prvErr.errSrc = MAT_REMOTE_PRV_ERR;
               prvErr.errCode = MAT_LINKED_RSP_UNX;
               break;
             case STU_UNX_LINKED_OP:
               prvErr.pres = TRUE;
               prvErr.errSrc = MAT_REMOTE_PRV_ERR;
               prvErr.errCode = MAT_UNX_LINKED_OP;
               break;
             default:
               prvErr.pres = TRUE;
               prvErr.errCode = MA_PRV_ERR_NONE;
               prvErr.errSrc = MAT_REMOTE_PRV_ERR;
               break;
          }
          break;
      }

      /* problem is return result */
      case STU_PROB_RET_RES:
      {
         switch(probCode)
         {
            case STU_UNX_RETRSLT:
               prvErr.pres    = TRUE;
               prvErr.errSrc  = MAT_REMOTE_PRV_ERR;
               prvErr.errCode = MAT_UNX_RSP_PEER;
               break;
            case STU_RR_MISTYPED_PAR:
               prvErr.pres    = TRUE;
               prvErr.errSrc  = MAT_REMOTE_PRV_ERR;
               prvErr.errCode = MAT_UNX_RSP_PEER;
               break;
         }
         break;
      }

      /* problem is return error */
      case STU_PROB_RET_ERR:
      {
         switch(probCode)
         {
            case STU_RE_UNX_RETERR:
               prvErr.pres    = TRUE;
               prvErr.errSrc  = MAT_REMOTE_PRV_ERR;
               prvErr.errCode = MAT_UNX_RSP_PEER;
               break;
            case STU_UNX_ERR:
            case STU_RE_MISTYPED_PAR:
            case STU_UNREC_ERROR:
               prvErr.pres    = TRUE;
               prvErr.errSrc  = MAT_REMOTE_PRV_ERR;
               prvErr.errCode = MAT_MISTYPE_PARAM;
               break;
         }
         break;
      }

  } /* end switch */
  
#ifdef MATV2
  /* fill the errSrc for the confirm appropriately*/
    if (prvErr.pres == TRUE)
    {
       switch(status)
       {
         case STU_COMP_REJ_LOCAL:
            prvErr.errSrc = MAT_LOCAL_PRV_ERR; 
            break;
         default:
            break;
       }/* reject type switch */
    }
#endif /* MATV2 */

#ifdef ZJ
    if (cmpCp != NULLP)
    {
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       cmTuUpdPeer(&zjCb.tuCb);  
    }
#endif
  /* send confirm to the map user */
  maSndSSCfm(s, cmpCp, &prvErr, &usrErr);

  /* Remove the component control point */
  maRemHashInv(dlgCp, &cmpEv->stInvokeId,TRUE);

  RETVALUE(ROK);

} /* maProcessRej  */

/*
*
*       Fun:   maProcessCan    
*
*       Desc:  This function process the cancel indication from TCAP 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maProcessCan 
(
MaSap   *s,             /* MAP SAP */
MaDlgCp *dlgCp,         /* Dialogue Control Point */
StComps *cmpEv          /* Component Event */
)
#else
PUBLIC S16 maProcessCan (s, dlgCp, cmpEv)
MaSap      *s;          /* MAP SAP */
MaDlgCp    *dlgCp;      /* Dialogue Control Point */
StComps    *cmpEv;      /* Component Event */
#endif
{
  MaCmpCp     *cmpCp;
  MaOpenEv    openEv;
  U8          oprClass;
  MaUsrErr    usrErr;
  MaPrvErr    prvErr;
  MaDlgId     tmpSuDlgId;        /* temporary Service user Dlg Id */
  MaDlgId     tmpSpDlgId;        /* temporary Service provider Dlg Id */
  MaDlgCp     *tmpdlgCp;

  TRC2(maProcessCan)

  tmpSuDlgId = dlgCp->suDlgId;        /* temporary Service user Dlg Id */
  tmpSpDlgId = dlgCp->spDlgId;        /* temporary Service provider Dlg Id */

  usrErr.pres = FALSE;
  prvErr.pres = FALSE;

  if (dlgCp->dsmState == MA_DLG_INITIATED)
  {
    maBZero((U8 *)&openEv, sizeof (MaOpenEv));
    openEv.result = MAT_DLG_OK;
#if MAP_REL99
#if (MAP_SEC && LMAV2)
    if (dlgCp->mapSec == FALSE)
#endif
#endif
    s->sts.openRspRx++;
    cmCopy((U8 *)&dlgCp->srcAddr, (U8 *)&openEv.srcAddr, sizeof(SpAddr)); 
    cmCopy((U8 *)&dlgCp->destAddr, (U8 *)&openEv.destAddr, sizeof(SpAddr)); 
    MaUiMatOpenCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId, 
                   &openEv);
  }
  cmpCp = maFindHashInvk(dlgCp, &cmpEv->stInvokeId,TRUE);

  if (cmpCp == (MaCmpCp *)NULLP)
  {
     /* this may happen when the timer expires for Class 4 type of
        operation codes as Component Control point is not allocated
        for them
      */
     /* make the last componet as FALSE so the user doesn't get any
      * delimiter Indication for Calss 4 type of operation codes
      */
     cmpEv->stLastCmp = FALSE;
     RETVALUE(ROK);
  }
  
  oprClass = cmpCp->oprClass;

  if (oprClass == MAT_OPRCLASS1)
  {
      /* send confirm to the map user */
      prvErr.pres = TRUE;
      prvErr.errSrc = MAT_REMOTE_PRV_ERR;
      prvErr.errCode = MAT_NO_RSP_PEER;
      maSndSSCfm(s, cmpCp, &prvErr, &usrErr);
  }

  if (oprClass == MAT_OPRCLASS3)
  {
      /* send confirm to the map user */
      prvErr.pres = TRUE;
      prvErr.errSrc = MAT_REMOTE_PRV_ERR;
      prvErr.errCode = MAT_SERV_COMP_FAILURE;
      maSndSSCfm(s, cmpCp, &prvErr,&usrErr);
  }
  if (oprClass == MAT_OPRCLASS2)
  {
     if(maIsLinkedOpr(cmpCp->oprCode, 0, FALSE) != ROK)
     {
        /* if linked operation is not allowed for this operation code */
        /* send confirm to the map user */
        maSndSSCfm(s, cmpCp, &prvErr,&usrErr);
     }
     else
     {
       if (cmpCp->impCfmFlg != TRUE)
       {
         prvErr.pres = TRUE;
         prvErr.errSrc = MAT_REMOTE_PRV_ERR;
         prvErr.errCode = MAT_SERV_COMP_FAILURE;
         maSndSSCfm(s, cmpCp, &prvErr,&usrErr);
         
       }
       else
       {
           /* Ignore the primitive */
           RETVALUE(ROK);
       }
     }
  }

  /* In tightly mode, when the above procedure return, dlgCp and curDlgCp
   * could be changed, find out the dialogue control point again*/
  if (s->curDlgCp != dlgCp )
  {
     if (tmpSuDlgId == 0)
     {
        tmpdlgCp = maFindHashDlgLower(s, tmpSpDlgId);
     }
     else
     {
        tmpdlgCp = maFindHashDlg(s, tmpSuDlgId);
     }
     if (tmpdlgCp == dlgCp)
     {
        s->curDlgCp = dlgCp;
     }
     else
     {
        RETVALUE(ROK);
     }
  }

#ifdef ZJ
  MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
  cmTuUpdPeer(&zjCb.tuCb);  
#endif
  /* remove the component control point */
  maRemHashInv(dlgCp, &cmpEv->stInvokeId,TRUE);
  RETVALUE(ROK);

} /* maProcessCan  */

/*
*
*       Fun:   maProcessRetErr    
*
*       Desc:  This function process the TC Error component 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maProcessRetErr 
(
MaSap  *s,              /* MAP SAP pointer */
MaDlgCp *dlgCp,         /* Dialogue Control Point */
StComps *cmpEv          /* Component Event */
)
#else
PUBLIC S16 maProcessRetErr (s, dlgCp, cmpEv)
MaSap      *s;          /* MAP SAP pointer */
MaDlgCp    *dlgCp;      /* Dialogue Control Point */
StComps    *cmpEv;      /* Component Event */
#endif
{
  MaCmpCp     *cmpCp;
  Buffer      *mBuf;
  U8          probCode;
  U8          maVer;
  MaUsrErr    usrErr;
  MaPrvErr    prvErr;
  Bool        rejFlg = FALSE;
  S16         ret = ROK;

  TRC2(maProcessRetErr)
  mBuf = s->crntRxMsg;
  usrErr.pres = FALSE;
  prvErr.pres = FALSE;

  switch(dlgCp->apn.val[dlgCp->apn.len-1])
  {
     case LMA_VER1:
     case LMA_VER2:
     case LMA_VER2P:
#if (MAP_REL98 || MAP_REL99)
     case LMA_VER4:
#endif /* MAP_REL98 || MAP_REL99 */
        maVer = dlgCp->apn.val[dlgCp->apn.len-1];
        break;
     default:
        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "maProcessRetErr() failed, invalid version(%d).\n",
        dlgCp->apn.val[dlgCp->apn.len-1]));
        RETVALUE(RFAILED);

  } /* end switch */

  cmpCp = maFindHashInvk(dlgCp, &cmpEv->stInvokeId,TRUE);
  if (cmpCp == (MaCmpCp *)NULLP)
  {
    /* Error Component not correct send the Tc-U Reject */
    maSndTcRej(s, cmpEv, STU_PROB_RET_ERR, STU_RE_UNREC_INVKID);

#ifndef MATV2
    /* send confirm to the map user */
    prvErr.pres = TRUE;
    prvErr.errSrc = MAT_REMOTE_PRV_ERR;
    prvErr.errCode = MAT_INVRSP_RCVD;
    maSndSSCfm(s, cmpCp, &prvErr, &usrErr);
#else /* MATV2 */
    /* send notice indication to the map user */
    MaUiMatNotInd(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId, 
                    MAT_ABEVT_RCVD_PEER);
#endif /* MATV2 */
    RETVALUE(ROK);
  }
  if (cmpEv->stErrorCodeFlg != STU_LOCAL)
  {
    /* Error Component not correct send the Tc-U Reject */
    maSndTcRej(s, cmpEv, STU_PROB_RET_ERR, STU_UNREC_ERROR);
    /* send confirm to the map user */
    prvErr.pres = TRUE;
    prvErr.errSrc = MAT_REMOTE_PRV_ERR;
    prvErr.errCode = MAT_INVRSP_RCVD;
    maSndSSCfm(s, cmpCp, &prvErr, &usrErr);
    RETVALUE(ROK);
  }
  cmpCp->errCode = cmpEv->stErrorCode.string[0];
#if MAP_REL99
#if (MAP_SEC && LMAV2)
  if (dlgCp->mapSec == TRUE)
  {
     if (cmpEv->stErrorCode.string[0] == MAT_SEC_TRANS_ERROR)
     {

        if((ret = maProcSecRetErr(s, dlgCp, cmpEv, cmpCp)) != ROK)
        {
           RETVALUE(ROK);
        }
     }
     else
     {
        maDropSecOprErr(s, cmpEv, cmpCp, LMA_CAUSE_INV_UNSEC_OPR);
        MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
               "maProcessRetErr() failed, MAPSec is required.\n"));
        RETVALUE(ROK);
     }
  }
#endif /* MAP_SEC */
#endif

  probCode = (U8)maChkRcvdErr(s,cmpCp->oprCode, cmpCp->errCode,maVer);
  if (probCode != ROK)
  {
     rejFlg = TRUE;
  }
  else 
  {
     probCode = STU_UNREC_ERROR; 
  }
  if (rejFlg == TRUE)
  {
    /* Error not correct send the Tc-U Reject */
    maSndTcRej(s, cmpEv, STU_PROB_RET_ERR, probCode);
    /* send confirm to the map user */
    prvErr.pres = TRUE;
    prvErr.errSrc = MAT_REMOTE_PRV_ERR;
    prvErr.errCode = MAT_INVRSP_RCVD;
    maSndSSCfm(s, cmpCp, &prvErr, &usrErr);
    RETVALUE(ROK);
  }

  maBZero((U8 *)&usrErr, sizeof (MaUsrErr));
  usrErr.val = MAT_INV_USR_ERRVAL;

  if (maVer >= LMA_VER2P)
  {
     usrErr.pres = TRUE;
     usrErr.errCode = cmpCp->errCode;

     if ((ret = maDecVer2PErrParam(s, &usrErr, MAT_SS_RETERR, maVer)) != ROK)
     {
        /* decode error params failed, set reject flag for error recovery below */
        rejFlg = TRUE;
     }
  }
  else
  {
     /* For version 1 and 2, decode without using the database */
     ret = maDecErrParam(mBuf, cmpCp->errCode, &usrErr, maVer, &rejFlg);
  }

  if (ret != ROK)
  {
    if (rejFlg == TRUE)
    {
      /* Error not correct send the Tc-U Reject */
      maSndTcRej(s, cmpEv, STU_PROB_RET_ERR, probCode);
      /* send confirm to the map user */
    }
    usrErr.pres = FALSE;
    prvErr.pres = TRUE;
    prvErr.errSrc = MAT_REMOTE_PRV_ERR;
    prvErr.errCode = MAT_INVRSP_RCVD;
    maSndSSCfm(s, cmpCp, &prvErr, &usrErr);
    RETVALUE(ROK);
  }
  maSndSSCfm(s, cmpCp, &prvErr, &usrErr);
  RETVALUE(ROK);
} /* maProcessRetErr  */

/*
*
*       Fun:   maDecErrParam    
*
*       Desc:  This function Decodes the user error paramaters 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maDecErrParam 
(
Buffer  *mBuf,    /* Message Buffer */
U8      errCode,  /* Error code */
MaUsrErr *usrErr,  /* User Error */
U8       maVer,   /* MAP Version */
U8       *rejFlg  /* Reject flag */
)
#else
PRIVATE S16 maDecErrParam (mBuf, errCode, usrErr, maVer, rejFlg)
Buffer  *mBuf;    /* Message Buffer */
U8      errCode;  /* Error code */
MaUsrErr *usrErr;   /* User Error */
U8       maVer;   /* MAP Version */
U8       *rejFlg;
#endif
{
  MsgLen  len;
  U8      tag;
  S16     ret;

  TRC2(maDecErrParam);

  usrErr->pres = TRUE;
  usrErr->errCode = errCode;

  /* If not phase 2+, continue decoding without using the database */
  switch(errCode)
  {
     case MAT_SYS_FAILURE:
       if (mBuf == (Buffer *)NULLP)
       {
          RETVALUE(ROK);
       }
       (Void)SFndLenMsg(mBuf, &len);
       if (len == 0)
       {
         RETVALUE(ROK);
       }
       (Void)SExamMsg(&tag, mBuf, 0);
       if (tag != MA_TAG_ENUM)
       {
         *rejFlg = TRUE;
         MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
         "maDecErrParam() failed, wrong tag(%d) in message,errcode MAT_SYS_FAILURE.\n", tag));
         RETVALUE(RFAILED);
       }
       if ((ret = maRemPrim(mBuf, NULLP, &usrErr->val, 
           (U8 *)&(len))) != ROK)
       {
         *rejFlg = TRUE;
         MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
         "maDecErrParam() failed, error in decode usrErr,errcode MAT_SYS_FAILURE.\n"));
         RETVALUE(RFAILED);
       }
       if ((usrErr->val > (U8)MAT_NETRSRS_RSS))
       {
         *rejFlg = TRUE;
         MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
         "maDecErrParam() failed, usrErr value(%d) is invalid,errcode MAT_SYS_FAILURE.\n", usrErr->val));
         RETVALUE(RFAILED);
       }
       break;

     case MAT_ROAM_NOTALLOWED:
       if (mBuf == (Buffer *)NULLP)
       {
          if (maVer == LMA_VER1)
          {
            RETVALUE(ROK);
          }
          else
          {
             *rejFlg = TRUE;
             MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
             "maDecErrParam() failed,wrong MAP version(%d),errcode MAT_ROAM_NOTALLOWED.\n", maVer));
             RETVALUE(RFAILED);
          }
       }
       (Void)SFndLenMsg(mBuf, &len);
       if (len == 0)
       {
          if (maVer == LMA_VER1)
          {
            RETVALUE(ROK);
          }
          else
          {
             *rejFlg = TRUE;
             MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
             "maDecErrParam() failed,wrong MAP version(%d),errcode MAT_ROAM_NOTALLOWED.\n", maVer));
             RETVALUE(RFAILED);
          }
       }
       (Void)SExamMsg(&tag, mBuf, 0);
       if (tag != MA_TAG_ENUM)
       {
          *rejFlg = TRUE;
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecErrParam() failed,wrong tag(%d),errcode MAT_ROAM_NOTALLOWED.\n", tag));
          RETVALUE(RFAILED);
       }
       if ((ret = maRemPrim(mBuf, NULLP, &usrErr->val, 
           (U8 *)&(len))) != ROK)
       {
          *rejFlg = TRUE;
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecErrParam() failed,error in getting usrErr(%d,errcode MAT_ROAM_NOTALLOWED).\n", usrErr->val));
          RETVALUE(RFAILED);
       }
       if ((usrErr->val != MAT_PLMN_ROAM_NOTALLOWED) &&
          (usrErr->val != MAT_OPR_DET_BARRING))
       {
          *rejFlg = TRUE;
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecErrParam() failed, usrErr value(%d) is invalid,errcode MAT_ROAM_NOTALLOWED.\n", usrErr->val));
          RETVALUE(RFAILED);
       }
       break;
     case MAT_ABSENT_SUBS:
       if (mBuf == (Buffer *)NULLP)
       {
             RETVALUE(ROK);
       }
       (Void)SFndLenMsg(mBuf, &len);
       if (len == 0)
       {
             RETVALUE(ROK);
       }
       if (maVer != LMA_VER1)
       {
           *rejFlg = TRUE;
           MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
           "maDecErrParam() failed,wrong MAP version(%d),errcode MAT_ABSENT_SUBS.\n", maVer));
           RETVALUE(RFAILED);
       }
       (Void)SExamMsg(&tag, mBuf, 0);
       if (tag != MA_TAG_BOOL)
       {
          *rejFlg = TRUE;
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecErrParam() failed,wrong tag(%d),errcode MAT_ABSENT_SUBS..\n", tag));
          RETVALUE(RFAILED);
       }
       if ((ret = maRemPrim(mBuf, NULLP, &usrErr->val, 
           (U8 *)&(len))) != ROK)
       {
          *rejFlg = TRUE;
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecErrParam() failed,error in getting usrErr(%d),errcode MAT_ABSENT_SUBS..\n", usrErr->val));
          RETVALUE(RFAILED);
       }
       break;
     case MAT_CALL_BARRED:
       if (mBuf == (Buffer *)NULLP)
       {
             RETVALUE(ROK);
       }
       (Void)SFndLenMsg(mBuf, &len);
       if (len == 0)
       {
             RETVALUE(ROK);
       }
       (Void)SExamMsg(&tag, mBuf, 0);
       if (tag != MA_TAG_ENUM)
       {
          *rejFlg = TRUE;
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecErrParam() failed, wrong tag(%d) in message,errcode MAT_CALL_BARRED .\n", tag));
          RETVALUE(RFAILED);
       }
       if ((ret = maRemPrim(mBuf, NULLP, &usrErr->val, 
           (U8 *)&(len))) != ROK)
       {
          *rejFlg = TRUE;
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecErrParam() failed, error in decode usrErr(%d),errcode MAT_CALL_BARRED.\n", usrErr->val));
          RETVALUE(RFAILED);
       }
       if ((usrErr->val != MAT_BARRING_SERV_ACTV) &&
          (usrErr->val != MAT_OPR_BARRING))
       {
          *rejFlg = TRUE;
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecErrParam() failed, usrErr value(%d) is invalid,errcode MAT_CALL_BARRED.\n", usrErr->val));
          RETVALUE(RFAILED);
       }
       break;
     case MAT_CUG_REJECT :
       if (mBuf == (Buffer *)NULLP)
       {
             RETVALUE(ROK);
       }
       (Void)SFndLenMsg(mBuf, &len);
       if (len == 0)
       {
             RETVALUE(ROK);
       }
       (Void)SExamMsg(&tag, mBuf, 0);
       if (tag != MA_TAG_ENUM)
       {
          *rejFlg = TRUE;
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecErrParam() failed, wrong tag(%d) in message,errcode MAT_CUG_REJECT.\n", tag));
          RETVALUE(RFAILED);
       }
       if ((ret = maRemPrim(mBuf, NULLP, &usrErr->val, 
           (U8 *)&(len))) != ROK)
       {
          *rejFlg = TRUE;
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecErrParam() failed, error in decode usrErr(%d),errcode MAT_CUG_REJECT.\n", usrErr->val));
          RETVALUE(RFAILED);
       }
       if ((maVer == LMA_VER1) && (usrErr->val == MAT_CPTY_INTER_VIOL))
       {
          *rejFlg = TRUE;
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecErrParam() failed, usrErr value(%d) is invalid,errcode MAT_CUG_REJECT.\n", usrErr->val));
          RETVALUE(RFAILED);
       }

       if ((usrErr->val != MAT_INCALL_BARR_CUG) &&
          (usrErr->val != MAT_SUBS_NOT_MEM_CUG) &&
          (usrErr->val != MAT_RBS_VIOL_CUG) &&
          (usrErr->val != MAT_RBS_VIOL_CUG) &&
          (usrErr->val != MAT_CPTY_INTER_VIOL))
       {
           *rejFlg = TRUE;
           MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
           "maDecErrParam() failed, usrErr value(%d) is invalid,errcode MAT_CUG_REJECT.\n", usrErr->val));
           RETVALUE(RFAILED);
       }
       break;
     case MAT_SS_STATUS_ERR:
       if (mBuf == (Buffer *)NULLP)
       {
             RETVALUE(ROK);
       }
       (Void)SFndLenMsg(mBuf, &len);
       if (len == 0)
       {
             RETVALUE(ROK);
       }
       (Void)SExamMsg(&tag, mBuf, 0);
       if (tag != MA_TAG_OCTSTR)
       {
          *rejFlg = TRUE;
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecErrParam() failed, wrong tag(%d) in message,errcode MAT_SS_STATUS_ERR.\n",tag));
          RETVALUE(RFAILED);
       }
       if ((ret = maRemPrim(mBuf, NULLP, &usrErr->ssErr.ssStatus.val, 
           (U8 *)&(len))) != ROK)
       {
          *rejFlg = TRUE;
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecErrParam() failed, error in decode usrErr(%d),errcode MAT_SS_STATUS_ERR.\n", usrErr->ssErr.ssStatus.val));
          RETVALUE(RFAILED);
       }
       break;
     case MAT_SS_SUBSVIOL_ERR:
       if (mBuf == (Buffer *)NULLP)
       {
             RETVALUE(ROK);
       }
       (Void)SFndLenMsg(mBuf, &len);
       if (len == 0)
       {
             RETVALUE(ROK);
       }
       if (maVer != LMA_VER1)
       {
           *rejFlg = TRUE;
           MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
           "maDecErrParam() failed,wrong MAP version(%d),errcode MAT_SS_SUBSVIOL_ERR.\n", maVer));
           RETVALUE(RFAILED);
       }
       (Void)SExamMsg(&tag, mBuf, 0);
       if ( (tag != MA_TAG_CSPRIM2) && (tag != MA_TAG_CSPRIM1))
       {
          *rejFlg = TRUE;
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecErrParam() failed, wrong tag(%d) in message,errcode MAT_SS_SUBSVIOL_ERR.\n", tag));
          RETVALUE(RFAILED);
       }
       if (tag == MA_TAG_CSPRIM1)
       {
          ret = maRemPrim(mBuf, NULLP, &usrErr->ssErr.ovrRideCat.val, (U8 *)&(len));
          if ((ret != ROK) || 
              ((usrErr->ssErr.ovrRideCat.val != MAT_OVRRIDE_ENABLED) && 
              (usrErr->ssErr.ovrRideCat.val != MAT_OVRRIDE_DISABLED)))
          {
            *rejFlg = TRUE;
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maDecErrParam() failed, usrErr value(%d) is invalid,errcode MAT_SS_SUBSVIOL_ERR.\n", usrErr->val));
            RETVALUE(RFAILED);
          }
          usrErr->ssErr.ovrRideCat.pres = TRUE;
       }
       if (tag == MA_TAG_CSPRIM2)
       {
          ret= maRemPrim(mBuf, NULLP, &usrErr->ssErr.cliRestOpt.val, (U8 *)&(len));
          if ((ret != ROK) || 
              ((usrErr->ssErr.cliRestOpt.val != MAT_PERMANENT_REST) && 
              (usrErr->ssErr.cliRestOpt.val != MAT_TEMP_DEFAULT_REST) &&
              (usrErr->ssErr.cliRestOpt.val != MAT_TEMP_DEFAULT_ALLOWED)))
          {
            *rejFlg = TRUE;
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maDecErrParam() failed, usrErr value(%d) is invalid,errcode MAT_SS_SUBSVIOL_ERR.\n", usrErr->val));
            RETVALUE(RFAILED);
          }
          usrErr->ssErr.cliRestOpt.pres = TRUE;
       }
       break;
     case MAT_SS_INCOMP_ERR:
       ret = maDecInCompCause(mBuf,usrErr,rejFlg);
       RETVALUE(ret);
     case MAT_PASSWD_REG_ERR:
       if (mBuf == (Buffer *)NULLP)
       {
             RETVALUE(ROK);
       }
       (Void)SFndLenMsg(mBuf, &len);
       if (len == 0)
       {
          *rejFlg = TRUE;
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecErrParam() failed, wrong message len(%d),errcode MAT_PASSWD_REG_ERR.\n",len));
          RETVALUE(RFAILED);
       }
       (Void)SExamMsg(&tag, mBuf, 0);
       if (tag != MA_TAG_ENUM)
       {
          *rejFlg = TRUE;
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecErrParam() failed, wrong tag(%d) in message,errcode MAT_PASSWD_REG_ERR.\n", tag));
          RETVALUE(RFAILED);
       }
       if ((ret = maRemPrim(mBuf, NULLP, &usrErr->val, 
           (U8 *)&(len))) != ROK)
       {
          *rejFlg = TRUE;
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecErrParam() failed, error in decode usrErr(%d),errcode MAT_PASSWD_REG_ERR.\n", usrErr->val));
          RETVALUE(RFAILED);
       }
       if ((usrErr->val != MAT_UNDETERMINED) &&
          (usrErr->val != MAT_INV_FRMT) &&
          (usrErr->val != MAT_NEW_PASSWD_MISMATCH))
       {
          *rejFlg = TRUE;
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecErrParam() failed, usrErr value(%d) is invalid,errcode MAT_PASSWD_REG_ERR.\n",usrErr->val));
          RETVALUE(RFAILED);
       }
       break;
     case MAT_SM_DEL_FAIL:
       if ((ret = maDecSMDelFailCause(mBuf, usrErr, maVer, rejFlg)) != ROK)
       {
          *rejFlg = TRUE;
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecErrParam() failed, decode SM deliver cause fail,errcode MAT_SM_DEL_FAIL.\n"));
          RETVALUE(RFAILED);
       }
       break;
     default:
       if (mBuf != (Buffer *)NULLP)
       {
          (Void)SFndLenMsg(mBuf, &len);
          if (len != 0)
          {
             *rejFlg = TRUE;
             MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
             "maDecErrParam() failed, error len(%d) in message, invalid errCode.\n", len));
             RETVALUE(RFAILED); 
          }
       }
       break;
  }
  RETVALUE(ROK);
} /* maDecErrParam */

/*
*
*       Fun:   maDecInCompCause    
*
*       Desc:  This function decodes the SS Incompatibilty cause 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maDecInCompCause 
(
Buffer   *mBuf,
MaUsrErr *usrErr,
U8       *rejFlg
)
#else
PRIVATE S16 maDecInCompCause (mBuf, usrErr, rejFlg)
Buffer   *mBuf;
MaUsrErr *usrErr;
U8       *rejFlg;
#endif
{
  U8     tag;
  S16    ret;
  Bool   eocFlg = FALSE;
  MsgLen len;

  TRC2(maDecInCompCause)
  if (mBuf == (Buffer *)NULLP)
  {
       RETVALUE(ROK);
  }
  (Void)SFndLenMsg(mBuf, &len);
  if (len == 0)
  {
     RETVALUE(ROK);
  }
  (Void)SRemPreMsg(&tag, mBuf);
  if (tag != MA_TAG_SEQ)
  {
      *rejFlg = TRUE;
      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "ma()DecInCompCause() failed, wrong tag in message.\n"));
      RETVALUE(RFAILED);
  }

  if ((ret = maRemLen(mBuf,&eocFlg)) != ROK)
  {
    *rejFlg = TRUE;
    MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
    "ma()DecInCompCause() failed, fail to get eocFlg from message.\n"));
    RETVALUE(RFAILED);
  }

  (Void)SFndLenMsg(mBuf, &len);
  if ((len == 0) || ((len == 2) && (eocFlg == TRUE)))
  {
     RETVALUE(ROK);
  }

  (Void)SExamMsg(&tag, mBuf,0);
  if (tag == MA_TAG_CSPRIM1)
  {
     if ((ret = maRemPrim(mBuf, NULLP, &usrErr->ssErr.ssCode.val, 
         (U8 *)&(len))) != ROK)
     {
       *rejFlg = TRUE;
       MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
       "ma()DecInCompCause() failed, fail to get usrErr from message.\n"));
       RETVALUE(RFAILED);
     }
     usrErr->ssErr.ssCode.pres = TRUE;
  }
  (Void)SFndLenMsg(mBuf, &len);
  if ((len == 0) || ((len == 2) && (eocFlg == TRUE)))
  {
     RETVALUE(ROK);
  }

  (Void)SExamMsg(&tag, mBuf,0);
  if ((tag == MA_TAG_CSPRIM2) || (MA_TAG_CSPRIM3))
  {
    if (tag == MA_TAG_CSPRIM2)
    {
      if ((ret = maRemPrim(mBuf, NULLP, &usrErr->ssErr.bearServ.val, 
                           (U8 *)&(len))) != ROK)
      {
        *rejFlg = TRUE;
        MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
        "ma()DecInCompCause() failed, fail to get usrErr from message.\n"));
        RETVALUE(RFAILED);
      }
      usrErr->ssErr.bearServ.pres = TRUE;
    }
    else
    {
      if ((ret = maRemPrim(mBuf, NULLP, &usrErr->ssErr.teleServ.val, 
                           (U8 *)&(len))) != ROK)
      {
        *rejFlg = TRUE;
        MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
        "ma()DecInCompCause() failed, fail to get usrErr from message.\n"));
        RETVALUE(RFAILED);
      }
      usrErr->ssErr.teleServ.pres = TRUE;
    }
  }
  (Void)SFndLenMsg(mBuf, &len);
  if ((len == 0) || ((len == 2) && (eocFlg == TRUE)))
  {
     RETVALUE(ROK);
  }

  (Void)SExamMsg(&tag, mBuf,0);
  if (tag != MA_TAG_CSPRIM4)
  {
    *rejFlg = TRUE;
    MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
    "ma()DecInCompCause() failed, wrong tag in message.\n"));
    RETVALUE(RFAILED);
  }
  if ((ret = maRemPrim(mBuf, NULLP, &usrErr->ssErr.ssStatus.val, 
                      (U8 *)&(len))) != ROK)
  {
     *rejFlg = TRUE;
     MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
     "ma()DecInCompCause() failed, fail to decode usrErr.\n"));
     RETVALUE(RFAILED);
  }
  usrErr->ssErr.ssStatus.pres = TRUE;

  (Void)SFndLenMsg(mBuf, &len);
  if ( (len == 0) || ((len == 2) && (eocFlg == TRUE)))
  {
    RETVALUE(ROK);
  }
  else
  {
    maBZero((U8 *)&usrErr->ssErr, sizeof (MaSSErr));
    MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
    "ma()DecInCompCause() failed, error in message.\n"));
    RETVALUE(RFAILED);
  }
} /* maDecInCompCause  */

/*
*
*       Fun:   maDecSMDelFailCause    
*
*       Desc:  This function decodes the SM Delivery cause
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maDecSMDelFailCause 
(
Buffer   *mBuf,
MaUsrErr *usrErr,
U8       maVer,
U8       *rejFlg
)
#else
PRIVATE S16 maDecSMDelFailCause (mBuf, usrErr, maVer, rejFlg)
Buffer   *mBuf;
MaUsrErr *usrErr;
U8       maVer;
U8       *rejFlg;
#endif
{
  U8     tag;
  S16    ret;
  Bool   eocFlg = FALSE;
  MsgLen len;
  U8     length;

  TRC2(maDecSMDelFailCause)
  if (mBuf == (Buffer *)NULLP)
  {
     MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
     "maDecSMDelFailCause() failed,empty message buffer passed.\n"));
     RETVALUE(RFAILED);
  }
  (Void)SFndLenMsg(mBuf, &len);
  if (len == 0)
  {
     RETVALUE(ROK);
  }
  (Void)SExamMsg(&tag, mBuf, 0);
  if ( (tag != MA_TAG_SEQ) &&  (tag != MA_TAG_ENUM))
  {
     *rejFlg = TRUE;
     MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
     "maDecSMDelFailCause() failed,message has wrong tag value.\n"));
     RETVALUE(RFAILED);
  }
  if ( ((tag == MA_TAG_ENUM) && (maVer != LMA_VER1)) ||
       ((tag == MA_TAG_SEQ) && (maVer == LMA_VER1)))
  {
     *rejFlg = TRUE;
     MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
     "maDecSMDelFailCause() failed,tag and MAP version don't match.\n"));
     RETVALUE(RFAILED);
  }
  if (tag == MA_TAG_ENUM)
  {
    if ((ret = maRemPrim(mBuf, NULLP, &usrErr->smErr.smFailCause.val, 
                         &length)) != ROK)
    {
    }
    usrErr->smErr.smFailCause.pres = TRUE;
    RETVALUE(ROK);
  }

  /* Remove the tag */
  if ((ret = SRemPreMsg(&tag, mBuf)) != ROK)
  {
     *rejFlg = TRUE;
     MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
     "maDecSMDelFailCause() failed,fail to get tag from message.\n"));
     RETVALUE(RFAILED);
  }
  if ((ret = maRemLen(mBuf,&eocFlg)) != ROK)
  {
     *rejFlg = TRUE;
     MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
     "maDecSMDelFailCause() failed,fail to get eocFlg from message.\n"));
     RETVALUE(RFAILED);
  }

  (Void)SFndLenMsg(mBuf, &len);
  if ((len == 0) || ((len == 2) && (eocFlg == TRUE)))
  {
     RETVALUE(ROK);
  }

  (Void)SExamMsg(&tag, mBuf,0);
  if (tag == MA_TAG_ENUM)
  {
     if ((ret = maRemPrim(mBuf, NULLP, &usrErr->smErr.smFailCause.val, 
                          &length)) != ROK)
     {
        *rejFlg = TRUE;
        MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
        "maDecSMDelFailCause() failed,fail to get usrErr from message.\n"));
        RETVALUE(RFAILED);
     }
     usrErr->smErr.smFailCause.pres = TRUE;
  }
  else
  {
     *rejFlg = TRUE;
     MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
     "maDecSMDelFailCause() failed,wrong tag(%d) in message.\n", tag));
     RETVALUE(RFAILED);
  }
  (Void)SFndLenMsg(mBuf, &len);
  if (len == 0)
  {
    RETVALUE(ROK);
  }

  if ((len == 2) && (eocFlg == TRUE))
  {
     RETVALUE(ROK);
  }

  (Void)SExamMsg(&tag, mBuf,0);
  if (tag != MA_TAG_OCTSTR)
  {
     *rejFlg = TRUE;
     MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
     "maDecSMDelFailCause() failed,wrong tag in message.\n"));
     RETVALUE(RFAILED);
  }
  else 
  {
     if ((ret = maRemPrim(mBuf, NULLP, &usrErr->smErr.diagInfo.val[0], 
                          &length)) != ROK)
     {
        *rejFlg = TRUE;
        MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
        "maDecSMDelFailCause() failed,fail to get usrErr from  message.\n"));
        RETVALUE(RFAILED);
     }
     usrErr->smErr.diagInfo.pres = TRUE;
     usrErr->smErr.diagInfo.len = length;
  } 
  SFndLenMsg(mBuf, &len);
  if ( (len == 0) || ((len == 2) && (eocFlg == TRUE)))
  {
    RETVALUE(ROK);
  }
  else
  {
     *rejFlg = TRUE;
     maBZero((U8 *)&usrErr->smErr, sizeof (MaSMErr));
     MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
     "maDecSMDelFailCause() failed,error in receiving message.\n"));
     RETVALUE(RFAILED);
  }
} /* maDecSMDelFailCause  */


/*
*
*       Fun:   maDecOpr    
*
*       Desc:  This function decodes the operation parameter 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maDecOpr 
(
 MaSap  *s,        /* Map Sap Pointer */
 U8     oprCode,   /* Operation Code */
 U8     decType    /* Decode Type */
)
#else
PUBLIC S16 maDecOpr (s,oprCode,decType)
 MaSap  *s;         /* Map Sap Pointer */
 U8     oprCode;    /* Operation Code */
 U8     decType;    /* Decode Type */
#endif
{
  MaDlgCp   *dlgCp;
  U8        maVer;
  S16       ret;

  TRC2(maDecOpr)
  ret = RFAILED; /* Initialised to RFAILED */
  dlgCp  = s->curDlgCp;
  maVer =  dlgCp->apn.val[dlgCp->apn.len-1];

  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf,
  "maDecOpr() decode operation(%d), decode type(%d).\n", oprCode, decType));

  switch (oprCode)
  {
#ifdef XWEXT /* xingzhou.xu: added for paging detect 2006/10/16 */
   case MAT_PAGING_DETECT:
     {
       MaXWDetectEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaXWDetectEv *) maAllocWithoutInit(sizeof(MaXWDetectEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaXWDetectEv *)&(maGlobDecEv->detectEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->pagingDetectReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->pagingDetectReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_XW_DETECT_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->pagingDetectRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->pagingDetectRsp)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_XW_DETECT_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaXWDetectEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
#endif /* XWEXT */	 

#if (MAP_VLR || MAP_HLR)
   case MAT_REGSS:
     {
       MaSSEv *evt;
#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSSEv *) maAllocWithoutInit(sizeof(MaSSEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {
         cmZero((Data *)evt,sizeof(evt->regSSReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->regSSReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_REGSS_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->regSSRsp));
         ret = maDecOprPar(s,(U8 *) (&(evt->regSSRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_REGSS_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
   case MAT_ERASESS:
     {
       MaSSEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSSEv *) maAllocWithoutInit(sizeof(MaSSEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {
         cmZero((Data *)evt,sizeof(evt->eraseSSReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->eraseSSReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_ERASESS_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->eraseSSRsp));
         ret = maDecOprPar(s,(U8 *) (&(evt->eraseSSRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_ERASE_SS_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
   case MAT_ACTVSS:
     {
       MaSSEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSSEv *) maAllocWithoutInit(sizeof(MaSSEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {
         cmZero((Data *)evt,sizeof(evt->actvSSReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->actvSSReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_ACTVSS_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->actvSSRsp));
         ret = maDecOprPar(s,(U8 *) (&(evt->actvSSRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_ACTVSS_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
   case MAT_DACTVSS:
     {
       MaSSEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSSEv *) maAllocWithoutInit(sizeof(MaSSEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {
         cmZero((Data *)evt,sizeof(evt->dactvSSReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->dactvSSReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_DACTVSS_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->dactvSSRsp));
         ret = maDecOprPar(s,(U8 *) (&(evt->dactvSSRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_DACTVSS_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
   case MAT_INTERSS:
     {
       MaSSEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSSEv *) maAllocWithoutInit(sizeof(MaSSEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {
         cmZero((Data *)evt,sizeof(evt->interSSReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->interSSReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_INTERSS_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->interSSRsp));
         ret = maDecOprPar(s,(U8 *) (&(evt->interSSRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_INTERSS_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
   case MAT_REGPASSWD:
     {
       MaSSEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSSEv *) maAllocWithoutInit(sizeof(MaSSEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {
         cmZero((Data *)evt,sizeof(evt->regPasswdReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->regPasswdReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_REGPASSWD_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->regPasswdRsp));
         ret = maDecOprPar(s,(U8 *) (&(evt->regPasswdRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_REGPASSWD_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
   case MAT_GETPASSWD:
     {
       MaSSEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSSEv *) maAllocWithoutInit(sizeof(MaSSEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->getPasswdReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->getPasswdReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_GETPASSWD_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->getPasswdRsp));
         ret = maDecOprPar(s,(U8 *) (&(evt->getPasswdRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_GETPASSWD_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
   case MAT_PROCUSSREQ:
     {
       MaSSEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSSEv *) maAllocWithoutInit(sizeof(MaSSEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {
         cmZero((Data *)evt,sizeof(evt->procUssReqReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->procUssReqReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_PROCUSS_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->procUssReqRsp));
         ret = maDecOprPar(s,(U8 *) (&(evt->procUssReqRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_PROCUSS_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
   case MAT_PROCUSSDATA:
     {
       MaSSEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSSEv *) maAllocWithoutInit(sizeof(MaSSEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->procUssDatReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->procUssDatReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_PROCUSSDAT_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->procUssDatRsp));
         ret = maDecOprPar(s,(U8 *) (&(evt->procUssDatRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_PROCUSSDAT_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
   case MAT_USSREQ:
     {
       MaSSEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSSEv *) maAllocWithoutInit(sizeof(MaSSEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->ussReqReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->ussReqReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_USS_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->ussReqRsp));
         ret = maDecOprPar(s,(U8 *) (&(evt->ussReqRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_USS_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
   case MAT_USSNOTIFY:
     {
       MaSSEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSSEv *) maAllocWithoutInit(sizeof(MaSSEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->ussNotifyReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->ussNotifyReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_USSNOTIFY_REQ);
       }
       else
       {
        ret = ROK;
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
#endif /* VLR || HLR */
 
#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_SMRDY:
     {
       MaSMEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSMEv *) maAllocWithoutInit(sizeof(MaSMEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSMEv *)&(maGlobDecEv->smEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->smRdyReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->smRdyReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_SMRDY_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->smRdyRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->smRdyRsp)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_SMRDY_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSMEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if MAP_MSC
   case MAT_DET_IMSI:
     {
       MaLocEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaLocEv *) maAllocWithoutInit(sizeof(MaLocEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocEv *)&(maGlobDecEv->locEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->detIMSIReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->detIMSIReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_DET_IMSI_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA146, (ErrVal)oprCode, 
                    "maDecOpr () bad decode type");
#endif
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaLocEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
#endif   /* MSC */
 
#if (MAP_MSC || MAP_VLR || MAP_GSN)
   case MAT_CHKIMEI:
     {
       MaIMEIEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaIMEIEv *) maAllocWithoutInit(sizeof(MaIMEIEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaIMEIEv *)&(maGlobDecEv->imeiEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->imeiReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->imeiReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_CHKIMEI_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->imeiRsp));
         ret = maDecOprPar(s,(U8 *) (&(evt->imeiRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_CHKIMEI_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaIMEIEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
#endif /* MAP_MSC || MAP_VLR || MAP_GSN */
 
#if MAP_MSC
   case MAT_TRACESUBSACTV:
     {
       MaOAMEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaOAMEv *) maAllocWithoutInit(sizeof(MaOAMEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaOAMEv *)&(maGlobDecEv->oamEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->trSubsActvReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->trSubsActvReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_TRACESUBSACTV_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA147, (ErrVal)oprCode, 
                    "maDecOpr () bad decode type");
#endif
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaOAMEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
#endif   /* MSC */

#if (MAP_MSC || MAP_HLR)
   case MAT_ROUTINFO:
     {
       MaCallEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaCallEv *) maAllocWithoutInit(sizeof(MaCallEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->sndRoutInfoReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->sndRoutInfoReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_ROUTINFO_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->sndRoutInfoRsp));
         ret = maDecOprPar(s,(U8 *) (&(evt->sndRoutInfoRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_ROUTINFO_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
   case MAT_ROUTINFOSM:
     {
       MaSMEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSMEv *) maAllocWithoutInit(sizeof(MaSMEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSMEv *)&(maGlobDecEv->smEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->routInfoSMReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->routInfoSMReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_ROUTINFOSM_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->routInfoSMRsp));
         ret = maDecOprPar(s,(U8 *) (&(evt->routInfoSMRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_ROUTINFOSM_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSMEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
   case MAT_SMDEL:
     {
       MaSMEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSMEv *) maAllocWithoutInit(sizeof(MaSMEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSMEv *)&(maGlobDecEv->smEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->repSMDelReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->repSMDelReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_SMDEL_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->repSMDelRsp));
         ret = maDecOprPar(s,(U8 *) (&(evt->repSMDelRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_SMDEL_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSMEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }
     }
     break;
   case MAT_ALRTSC:
     {
       MaSMEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSMEv *) maAllocWithoutInit(sizeof(MaSMEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSMEv *)&(maGlobDecEv->smEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->alrtSCReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->alrtSCReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_ALRTSC_REQ);
       }
       else
       {
         ret = ROK;
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSMEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
   case MAT_ALRTSCWRSLT:
     {
       MaSMEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSMEv *) maAllocWithoutInit(sizeof(MaSMEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSMEv *)&(maGlobDecEv->smEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->alrtSCReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->alrtSCReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_ALRTSCWRSLT_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA148, (ErrVal)oprCode, 
                    "maDecOpr () bad decode type");
#endif
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSMEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_INFSC:
     {
       MaSMEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSMEv *) maAllocWithoutInit(sizeof(MaSMEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSMEv *)&(maGlobDecEv->smEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->infSCReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->infSCReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_INFSC_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA149, (ErrVal)oprCode, 
                    "maDecOpr () bad decode type");
#endif
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSMEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
#endif  /* MSC || HLR */

#if (MAP_VLR || MAP_HLR)
   case MAT_UPLOC:
     {
       MaLocEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaLocEv *) maAllocWithoutInit(sizeof(MaLocEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocEv *)&(maGlobDecEv->locEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->upLocReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->upLocReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_UPLOC_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->upLocRsp));
         ret = maDecOprPar(s,(U8 *) (&(evt->upLocRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_UPLOC_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaLocEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
#endif /* MAP_VLR || MAP_HLR */
 
#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_CANCELLOC:
     {
       MaLocEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaLocEv *) maAllocWithoutInit(sizeof(MaLocEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocEv *)&(maGlobDecEv->locEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->canLocReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->canLocReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_CANCELLOC_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->canLocRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->canLocRsp)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_CANCELLOC_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaLocEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_PURGE:
     {
       MaLocEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaLocEv *) maAllocWithoutInit(sizeof(MaLocEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocEv *)&(maGlobDecEv->locEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->purgeMsReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->purgeMsReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_PURGE_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->purgeMsRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->purgeMsRsp)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_PURGE_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaLocEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
     
   case MAT_AUTHINFO:
     {
       MaAuthEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaAuthEv *) maAllocWithoutInit(sizeof(MaAuthEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaAuthEv *)&(maGlobDecEv->authEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->authInfoReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->authInfoReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_AUTHINFO_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->authInfoRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->authInfoRsp)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_AUTHINFO_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaAuthEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }

     }
     break;
   case MAT_INSSUBSDATA:
     {
       MaSubEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSubEv *) maAllocWithoutInit(sizeof(MaSubEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSubEv *)&(maGlobDecEv->subEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->isdReq));
         ret = maDecOprPar(s, (U8 *)(&(evt->isdReq)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_INSSUBSDATA_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->isdRsp));
         ret = maDecOprPar(s, (U8 *) (&(evt->isdRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_INSSUBSDATA_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSubEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_DELSUBSDATA:
     {
       MaSubEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSubEv *) maAllocWithoutInit(sizeof(MaSubEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSubEv *)&(maGlobDecEv->subEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->dsdReq));
         ret = maDecOprPar(s, (U8 *)(&(evt->dsdReq)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_DELSUBSDATA_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->dsdRsp));
         ret = maDecOprPar(s, (U8 *) (&(evt->dsdRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_DELSUBSDATA_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSubEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;

   case MAT_RESET:
     {
       MaFREv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaFREv *) maAllocWithoutInit(sizeof(MaFREv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaFREv *)&(maGlobDecEv->frEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->resetReq));
         ret = maDecOprPar(s, (U8 *)(&(evt->resetReq)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_RESET_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA150, (ErrVal)oprCode, 
                    "maDecOpr () bad decode type");
#endif
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaFREv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;

   case MAT_SNDPARAM:
     {
       MaSubEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSubEv *) maAllocWithoutInit(sizeof(MaSubEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSubEv *)&(maGlobDecEv->subEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->sndParamReq));
         ret = maDecOprPar(s, (U8 *)(&(evt->sndParamReq)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_SNDPARAM_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->sndParamRsp));
         ret = maDecOprPar(s, (U8 *) (&(evt->sndParamRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_SNDPARAM_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSubEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */
 
#if (MAP_VLR || MAP_HLR)

   case MAT_RESTOREDATA:
     {
       MaFREv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaFREv *) maAllocWithoutInit(sizeof(MaFREv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaFREv *)&(maGlobDecEv->frEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->restDatReq));
         ret = maDecOprPar(s, (U8 *)(&(evt->restDatReq)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_RESTOREDATA_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->restDatRsp));
         ret = maDecOprPar(s, (U8 *) (&(evt->restDatRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_RESTOREDATA_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaFREv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_FWDCHKSSIND:
     ret = ROK;
     break;
#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_ACTVTRACE:
     {
       MaOAMEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaOAMEv *) maAllocWithoutInit(sizeof(MaOAMEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaOAMEv *)&(maGlobDecEv->oamEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->actvTrReq));
         ret = maDecOprPar(s, (U8 *)(&(evt->actvTrReq)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_ACTVTRACE_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->actvTrRsp));
         ret = maDecOprPar(s, (U8 *)(&(evt->actvTrRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_ACTVTRACE_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaOAMEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_DACTVTRACE:
     {
       MaOAMEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaOAMEv *) maAllocWithoutInit(sizeof(MaOAMEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaOAMEv *)&(maGlobDecEv->oamEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->dactvTrReq));
         ret = maDecOprPar(s, (U8 *)(&(evt->dactvTrReq)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_DACTVTRACE_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->dactvTrRsp));
         ret = maDecOprPar(s, (U8 *)(&(evt->dactvTrRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_DACTVTRACE_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaOAMEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;

#if MAP_REL99

  case MAT_AUTHFAILRPT:
     {
       MaAuthEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaAuthEv *) maAllocWithoutInit(sizeof(MaAuthEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaAuthEv *)&(maGlobDecEv->authEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->authFailRptReq));
         ret = maDecOprPar(s, (U8 *)(&(evt->authFailRptReq)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_AUTHFAILRPT_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->authFailRptRsp));
         ret = maDecOprPar(s, (U8 *)(&(evt->authFailRptRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_AUTHFAILRPT_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaAuthEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;

   case MAT_NOTE_MMEVT:
     {
       MaLocEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaLocEv *) maAllocWithoutInit(sizeof(MaLocEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocEv *)&(maGlobDecEv->locEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->noteMmEventReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->noteMmEventReq)),
               maVer,(U8)s->cfg.swtch, decType, MA_MI_NOTMMEV_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->noteMmEventRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->noteMmEventRsp)),
               maVer,(U8)s->cfg.swtch, decType, MA_MI_NOTMMEV_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaLocEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;

#endif /* MAP_REL99 */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */
 
#if (MAP_VLR || MAP_HLR)
   case MAT_SNDIMSI:
     {
       MaOAMEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaOAMEv *) maAllocWithoutInit(sizeof(MaOAMEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaOAMEv *)&(maGlobDecEv->oamEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->sndImsiReq));
         ret = maDecOprPar(s, (U8 *)(&(evt->sndImsiReq)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_SNDIMSI_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->sndImsiRsp));
         ret = maDecOprPar(s, (U8 *)(&(evt->sndImsiRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_SNDIMSI_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaOAMEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;

   case MAT_PROVROAMNMB:
     {
       MaCallEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaCallEv *) maAllocWithoutInit(sizeof(MaCallEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->roamNmbReq));
         ret = maDecOprPar(s, (U8 *)(&(evt->roamNmbReq)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_PROVROAMNMB_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->roamNmbRsp));
         ret = maDecOprPar(s, (U8 *)(&(evt->roamNmbRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_PROVROAMNMB_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;

   case MAT_NOTSUBPRES:
     {
       MaSMEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSMEv *) maAllocWithoutInit(sizeof(MaSMEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSMEv *)&(maGlobDecEv->smEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->notSubPresReq));
         ret = maDecOprPar(s, (U8 *)(&(evt->notSubPresReq)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_NOTSUBPRES_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA151, (ErrVal)oprCode, 
                    "maDecOpr () bad decode type");
#endif
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSMEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;

   case MAT_BEGIN_SUBS_ACTV:
     {
       MaSSEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSSEv *) maAllocWithoutInit(sizeof(MaSSEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->bgnSubActvReq));
         ret = maDecOprPar(s, (U8 *)(&(evt->bgnSubActvReq)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_BGNSUBSACTV_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA152, (ErrVal)oprCode, 
                    "maDecOpr () bad decode type");
#endif
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_SETRPTSTATE:
     {
       MaCallEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaCallEv *) maAllocWithoutInit(sizeof(MaCallEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->setRptStateReq));
         ret=maDecOprPar(s,(U8 *)(&(evt->setRptStateReq)),
               maVer,(U8)s->cfg.swtch, decType, MA_MI_SETRPTSTATE_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->setRptStateRsp));
         ret=maDecOprPar(s,(U8 *)(&(evt->setRptStateRsp)),
               maVer,(U8)s->cfg.swtch, decType, MA_MI_SETRPTSTATE_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_STARPT:
     {
       MaCallEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaCallEv *) maAllocWithoutInit(sizeof(MaCallEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->staRptReq));
         ret = maDecOprPar(s, (U8 *)(&(evt->staRptReq)),
               maVer,(U8)s->cfg.swtch, decType, MA_MI_STARPT_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->staRptRsp));
         ret = maDecOprPar(s, (U8 *)(&(evt->staRptRsp)),
               maVer,(U8)s->cfg.swtch, decType, MA_MI_STARPT_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_RMTUSRFREE:
     {
       MaCallEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaCallEv *) maAllocWithoutInit(sizeof(MaCallEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->rmtUsrFreeReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->rmtUsrFreeReq)),
               maVer,(U8)s->cfg.swtch, decType, MA_MI_RMTUSRFREE_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->rmtUsrFreeRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->rmtUsrFreeRsp)),
               maVer,(U8)s->cfg.swtch, decType, MA_MI_RMTUSRFREE_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;

   case MAT_REGCCENT:
     {
       MaSSEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSSEv *) maAllocWithoutInit(sizeof(MaSSEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->regCcEntReq));
         ret = maDecOprPar(s, (U8 *)(&(evt->regCcEntReq)),
               maVer,(U8)s->cfg.swtch, decType, MA_MI_REGCCENT_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->regCcEntRsp));
         ret = maDecOprPar(s, (U8 *)(&(evt->regCcEntRsp)),
               maVer,(U8)s->cfg.swtch, decType, MA_MI_REGCCENT_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_ERASECCENT:
     {
       MaSSEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSSEv *) maAllocWithoutInit(sizeof(MaSSEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->eraseCcEntReq));
         ret = maDecOprPar(s, (U8 *)(&(evt->eraseCcEntReq)),
               maVer,(U8)s->cfg.swtch, decType, MA_MI_ERASECCENT_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->eraseCcEntRsp));
         ret = maDecOprPar(s, (U8 *)(&(evt->eraseCcEntRsp)),
               maVer,(U8)s->cfg.swtch, decType, MA_MI_ERASECCENT_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;

#endif  /* MAP_VLR || MAP_HLR */

#if MAP_MSC
   case MAT_PRE_HO:
     {
       MaHoEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaHoEv *) maAllocWithoutInit(sizeof(MaHoEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaHoEv *)&(maGlobDecEv->hoEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->preHoReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->preHoReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_PREHO_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->preHoRsp));
         ret = maDecOprPar(s,(U8 *) (&(evt->preHoRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_PREHO_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaHoEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_PER_HO:
     {
       MaHoEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaHoEv *) maAllocWithoutInit(sizeof(MaHoEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaHoEv *)&(maGlobDecEv->hoEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->perHoReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->perHoReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_PERHO_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->perHoRsp));
         ret = maDecOprPar(s,(U8 *) (&(evt->perHoRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_PERHO_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaHoEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_SNDENDSIG:
     {
       MaHoEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaHoEv *) maAllocWithoutInit(sizeof(MaHoEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaHoEv *)&(maGlobDecEv->hoEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->sndEndSigReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->sndEndSigReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_SNDENDSIG_REQ);
       }
       else
       {
#if MAP_REL99
         cmZero((Data *)evt,sizeof(evt->sndEndSigRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->sndEndSigRsp)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_SNDENDSIG_RSP);
#else /* MAP_REL99 */
         ret = ROK; 
#endif /* MAP_REL99 */
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaHoEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_PROCACCSIG:
     {
       MaHoEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaHoEv *) maAllocWithoutInit(sizeof(MaHoEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaHoEv *)&(maGlobDecEv->hoEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->procAccSigReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->procAccSigReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_PROCACCSIG_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA153, (ErrVal)oprCode, 
                    "maDecOpr () bad decode type");
#endif
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaHoEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_FWDACCSIG:
     {
       MaHoEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaHoEv *) maAllocWithoutInit(sizeof(MaHoEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaHoEv *)&(maGlobDecEv->hoEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->fwdAccSigReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->fwdAccSigReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_FWDACCSIG_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA154, (ErrVal)oprCode, 
                    "maDecOpr () bad decode type");
#endif
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaHoEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_PRE_SUBSHO:
     {
       MaHoEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaHoEv *) maAllocWithoutInit(sizeof(MaHoEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaHoEv *)&(maGlobDecEv->hoEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->preSubHoReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->preSubHoReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_PRESUBSHO_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->preSubHoRsp));
         ret = maDecOprPar(s,(U8 *) (&(evt->preSubHoRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_PRESUBSHO_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaHoEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_PER_SUBSHO:
     {
       MaHoEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaHoEv *) maAllocWithoutInit(sizeof(MaHoEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaHoEv *)&(maGlobDecEv->hoEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->perSubHoReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->perSubHoReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_PERSUBSHO_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->perSubHoRsp));
         ret = maDecOprPar(s,(U8 *) (&(evt->perSubHoRsp)), maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_PERSUBSHO_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaHoEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_NOTEINTERHO:
     {
       MaOAMEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaOAMEv *) maAllocWithoutInit(sizeof(MaOAMEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaOAMEv *)&(maGlobDecEv->oamEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->interHoReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->interHoReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_NOTEINTERHO_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA155, (ErrVal)oprCode, 
                    "maDecOpr () bad decode type");
#endif
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaOAMEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
#endif /* MAP_MSC */
 
#if (MAP_MSC || MAP_GSN)
   case MAT_FWDSM:
     {
       MaSMEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSMEv *) maAllocWithoutInit(sizeof(MaSMEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSMEv *)&(maGlobDecEv->smEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->fwdSMReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->fwdSMReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_FWDSM_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->fwdSMRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->fwdSMRsp)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_FWDSM_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSMEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_MT_FWDSM:
     {
       MaSMEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSMEv *) maAllocWithoutInit(sizeof(MaSMEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSMEv *)&(maGlobDecEv->smEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->mtFwdSMReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->mtFwdSMReq)),  maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_MTFWDSM_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->mtFwdSMRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->mtFwdSMRsp)),  maVer, 
                           (U8)s->cfg.swtch, decType, MA_MI_MTFWDSM_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSMEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
#endif /* MAP_MSC || MAP_GSN */
 
#if MAP_MSC
   case MAT_RESCALLHANDL:
     {
       MaCallEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaCallEv *) maAllocWithoutInit(sizeof(MaCallEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->resCallHandlReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->resCallHandlReq)),  
                        maVer,(U8)s->cfg.swtch, decType, MA_MI_RESCALLHANDL_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->resCallHandlRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->resCallHandlRsp)),  
                        maVer,(U8)s->cfg.swtch, decType, MA_MI_RESCALLHANDL_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_PREP_GRPCALL:
     {
       MaCallEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaCallEv *) maAllocWithoutInit(sizeof(MaCallEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->prepGrpCallReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->prepGrpCallReq)),  
                     maVer,(U8)s->cfg.swtch, decType, MA_MI_PREPGRPCALL_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->prepGrpCallRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->prepGrpCallRsp)),  
                     maVer,(U8)s->cfg.swtch, decType, MA_MI_PREPGRPCALL_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_PRO_GRPCALLSIG:
     {
       MaCallEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaCallEv *) maAllocWithoutInit(sizeof(MaCallEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->proGrpCallSigReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->proGrpCallSigReq)),  
                    maVer,(U8)s->cfg.swtch, decType, MA_MI_PROGRPCALLSIG_REQ);
       }
       else
       {
         ret = ROK;
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_FWD_GRPCALLSIG:
     {
       MaCallEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaCallEv *) maAllocWithoutInit(sizeof(MaCallEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->fwdGrpCallSigReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->fwdGrpCallSigReq)),  
                      maVer,(U8)s->cfg.swtch, decType, MA_MI_FWDGRPCALLSIG_REQ);
       }
       else
       {
         ret = ROK;
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_SND_GRPCALLENDSIG:
     {
       MaCallEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaCallEv *) maAllocWithoutInit(sizeof(MaCallEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->sndGrpCallEndSigReq));
         ret=maDecOprPar(s,(U8 *)(&(evt->sndGrpCallEndSigReq)),  
                      maVer,(U8)s->cfg.swtch, decType, MA_MI_SNDGRPCALLENDSIG_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->sndGrpCallEndSigRsp));
         ret=maDecOprPar(s,(U8 *)(&(evt->sndGrpCallEndSigRsp)),  
                      maVer,(U8)s->cfg.swtch, decType, MA_MI_SNDGRPCALLENDSIG_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_PROV_SIWFS_NMB:
     {
       MaCallEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaCallEv *) maAllocWithoutInit(sizeof(MaCallEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->provSiwfsNmbReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->provSiwfsNmbReq)),  
                      maVer,(U8)s->cfg.swtch, decType, MA_MI_PROVSIWFSNMB_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->provSiwfsNmbRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->provSiwfsNmbRsp)),  
                     maVer,(U8)s->cfg.swtch, decType, MA_MI_PROVSIWFSNMB_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_SIWFS_SIGMOD:
     {
       MaCallEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaCallEv *) maAllocWithoutInit(sizeof(MaCallEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->siwfsSigModReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->siwfsSigModReq)),  
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_SIWFSSIGMOD_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->siwfsSigModRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->siwfsSigModRsp)),  
                     maVer, (U8)s->cfg.swtch, decType, MA_MI_SIWFSSIGMOD_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
#endif  /* MSC */

#if (MAP_MSC || MAP_HLR)

   case MAT_SSINV_NOTIFY:
     {
/* ma013.203 : Correction SS_INVOKE_NOTIFY is moved in SS Service */
       MaSSEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSSEv *) maAllocWithoutInit(sizeof(MaSSEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->ssInvNotReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->ssInvNotReq)),  
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_SSINV_NOTIFY_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->ssInvNotRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->ssInvNotRsp)),  
                     maVer, (U8)s->cfg.swtch, decType, MA_MI_SSINV_NOTIFY_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;

#if MAP_REL99

   case MAT_IST_ALERT:
     {
       MaCallEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaCallEv *) maAllocWithoutInit(sizeof(MaCallEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->istAlertReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->istAlertReq)),  
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_ISTALRT_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->istAlertRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->istAlertRsp)),  
                     maVer, (U8)s->cfg.swtch, decType, MA_MI_ISTALRT_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }
     }
     break;

   case MAT_IST_COMMAND:
     {
       MaCallEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaCallEv *) maAllocWithoutInit(sizeof(MaCallEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->istCmdReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->istCmdReq)),  
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_ISTCMD_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->istCmdRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->istCmdRsp)),  
                     maVer, (U8)s->cfg.swtch, decType, MA_MI_ISTCMD_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }
     }
     break;

#endif /* MAP_REL99 */

#endif /* MAP_MSC || MAP_HLR */

#if MAP_MSC
#if MAP_REL99
#if MAP_REL6

/* Release Resources operations */

   case MAT_REL_RES:
     {
       MaCallEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaCallEv *) maAllocWithoutInit(sizeof(MaCallEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->relResReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->relResReq)),  
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_RELRES_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->relResRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->relResRsp)),  
                     maVer, (U8)s->cfg.swtch, decType, MA_MI_RELRES_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }
     }
     break;

#endif /* MAP_REL6 */
#endif /* MAP_REL99 */
#endif /* MAP_MSC */

#if MAP_VLR
  /* Send Identification Request */
  case MAT_SNDID:
     {
       MaLocEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaLocEv *) maAllocWithoutInit(sizeof(MaLocEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocEv *)&(maGlobDecEv->locEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->sendIdReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->sendIdReq)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_SNDID_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->sendIdRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->sendIdRsp)), maVer, 
                            (U8)s->cfg.swtch, decType, MA_MI_SNDID_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaLocEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;

#endif  /* MAP_VLR */

#if (MAP_HLR || MAP_MLC)
   case MAT_ANY_INTER:
     {
       MaSubEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSubEv *) maAllocWithoutInit(sizeof(MaSubEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSubEv *)&(maGlobDecEv->subEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->anyInterReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->anyInterReq)),  
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_ANYINTER_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->anyInterRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->anyInterRsp)),  
                     maVer, (U8)s->cfg.swtch, decType, MA_MI_ANYINTER_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSubEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;

#if (MAP_REL98 || MAP_REL99)

   case MAT_SENDROUTINFOFORLCS:
     {
       MaLocServEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaLocServEv *) maAllocWithoutInit(sizeof(MaLocServEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocServEv *)&(maGlobDecEv->locServEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->routInfoForLcsReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->routInfoForLcsReq)),  
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_ROUTINFOFORLCS_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->routInfoForLcsRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->routInfoForLcsRsp)),  
                     maVer, (U8)s->cfg.swtch, decType, MA_MI_ROUTINFOFORLCS_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaLocServEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break; 

#endif /* MAP_REL98 || MAP_REL99 */
#endif /* MAP_HLR || MAP_MLC */

#if (MAP_HLR || MAP_GSN)
   case MAT_GPRS_UPLOC:
     {
       MaLocEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaLocEv *) maAllocWithoutInit(sizeof(MaLocEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocEv *)&(maGlobDecEv->locEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->gprsUpLocReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->gprsUpLocReq)),  
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_GPRSUPLOC_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->gprsUpLocRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->gprsUpLocRsp)),  
                     maVer, (U8)s->cfg.swtch, decType, MA_MI_GPRSUPLOC_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaLocEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_GPRS_ROUTINFO:
     {
       MaPdpActvEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaPdpActvEv *) maAllocWithoutInit(sizeof(MaPdpActvEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaPdpActvEv *)&(maGlobDecEv->pdpActvEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->gprsRoutInfoReq));
         ret=maDecOprPar(s,(U8 *)(&(evt->gprsRoutInfoReq)),  
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_GPRSROUTINFO_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->gprsRoutInfoRsp));
         ret=maDecOprPar(s,(U8 *)(&(evt->gprsRoutInfoRsp)),  
                     maVer, (U8)s->cfg.swtch, decType, MA_MI_GPRSROUTINFO_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaPdpActvEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_GPRS_NOTEMSPRES:
     {
       MaPdpActvEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaPdpActvEv *) maAllocWithoutInit(sizeof(MaPdpActvEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaPdpActvEv *)&(maGlobDecEv->pdpActvEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->gprsNoteMsPresReq));
        ret=maDecOprPar(s,(U8 *)(&(evt->gprsNoteMsPresReq)), 
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_GPRSNOTEMSPRES_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->gprsNoteMsPresRsp));
        ret=maDecOprPar(s,(U8 *)(&(evt->gprsNoteMsPresRsp)), 
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_GPRSNOTEMSPRES_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaPdpActvEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
   case MAT_FAILRPT:
     {
       MaPdpActvEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaPdpActvEv *) maAllocWithoutInit(sizeof(MaPdpActvEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaPdpActvEv *)&(maGlobDecEv->pdpActvEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->failRptReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->failRptReq)),  
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_FAILRPT_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->failRptRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->failRptRsp)),  
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_FAILRPT_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaPdpActvEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
#endif  /*(MAP_HLR || MAP_GSN)*/

#if (MAP_VLR || MAP_HLR || MAP_GSN)
#if (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5))
   case MAT_PROVSUBSINFO:
     {
       MaSubEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSubEv *) maAllocWithoutInit(sizeof(MaSubEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSubEv *)&(maGlobDecEv->subEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->provSubsInfoReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->provSubsInfoReq)),  
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_PROVSUBSINFO_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->provSubsInfoRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->provSubsInfoRsp)),  
                     maVer, (U8)s->cfg.swtch, decType, MA_MI_PROVSUBSINFO_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSubEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;
#endif  /* (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5)) */ 
#endif  /* MAP_VLR || MAP_HLR */

#if MAP_REL99

#if MAP_HLR

   case MAT_ANY_SUBSDATA_INTER:
     {
       MaSubEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSubEv *) maAllocWithoutInit(sizeof(MaSubEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSubEv *)&(maGlobDecEv->subEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->anySubsInterReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->anySubsInterReq)),  
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_ANYSUBSINTER_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->anySubsInterRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->anySubsInterRsp)),  
                     maVer, (U8)s->cfg.swtch, decType, MA_MI_ANYSUBSINTER_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSubEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }
     }
     break;

   case MAT_ANY_MOD:
     {
       MaSubEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSubEv *) maAllocWithoutInit(sizeof(MaSubEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSubEv *)&(maGlobDecEv->subEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->anyModReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->anyModReq)),  
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_ANYMOD_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->anyModRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->anyModRsp)),  
                     maVer, (U8)s->cfg.swtch, decType, MA_MI_ANYMOD_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSubEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }
     }
     break;

   case MAT_NOTE_SUBSDATA_MOD:
     {
       MaSubEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaSubEv *) maAllocWithoutInit(sizeof(MaSubEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSubEv *)&(maGlobDecEv->subEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->noteSubsDataModReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->noteSubsDataModReq)),  
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_NOTSUBSMOD_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->noteSubsDataModRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->noteSubsDataModRsp)),  
                     maVer, (U8)s->cfg.swtch, decType, MA_MI_NOTSUBSMOD_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaSubEv));
#endif  /* MA_STATIC_EVT_STRUCT */
       }
     }
     break;

#endif /* MAP_HLR */
   
#endif /* MAP_REL99 */

#if (MAP_REL98 || MAP_REL99)

#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL4 && MAP_GSN))
   case MAT_PROVSUBSLOC:
     {
       MaLocServEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaLocServEv *) maAllocWithoutInit(sizeof(MaLocServEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocServEv *)&(maGlobDecEv->locServEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->prvSubsLocReq));
         ret=maDecOprPar(s,(U8 *)(&(evt->prvSubsLocReq)),  
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_PRVSUBSLOC_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->prvSubsLocRsp));
         ret=maDecOprPar(s,(U8 *)(&(evt->prvSubsLocRsp)),  
                     maVer, (U8)s->cfg.swtch, decType, MA_MI_PRVSUBSLOC_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaLocServEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }

     }
     break;

   case MAT_SUBSLOCRPT:
     {
       MaLocServEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
       if ((evt = (MaLocServEv *) maAllocWithoutInit(sizeof(MaLocServEv))) == NULLP)
       {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maDecOpr() failed, fail to allocate memory for operation event, oprCode(%d).\n",oprCode));
          RETVALUE(RFAILED);
       }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocServEv *)&(maGlobDecEv->locServEv);
#endif  /* MA_STATIC_EVT_STRUCT */

       /* initialize the event pointer in the sap */
       s->evtPtr = (U8 *) evt;

       if (decType == MAT_SS_REQ)
       {

         cmZero((Data *)evt,sizeof(evt->subsLocRptReq));
         ret = maDecOprPar(s,(U8 *)(&(evt->subsLocRptReq)),  
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_SUBSLOCRPT_REQ);
       }
       else
       {
         cmZero((Data *)evt,sizeof(evt->subsLocRptRsp));
         ret = maDecOprPar(s,(U8 *)(&(evt->subsLocRptRsp)),  
                      maVer, (U8)s->cfg.swtch, decType, MA_MI_SUBSLOCRPT_RSP);
       }

       if (ret != ROK)
       {
#ifndef MA_STATIC_EVT_STRUCT
          (Void) maFree((Data *)evt, sizeof(MaLocServEv));
#endif  /* MA_STATIC_EVT_STRUCT */

       }
     }
     break;
#endif  /*(MAP_MSC || MAP_MLC || (MAP_REL4 && MAP_GSN))*/
#endif

#endif /* (MAP_REL98 || MAP_REL99) */

   default:
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA156, (ErrVal)oprCode, 
                    "maDecOpr () bad operation code");
#endif
     ret = RFAILED;
     break;
  }
#if (ERRCLASS & ERRCLS_DEBUG)
  if (ret != ROK)
  {  /* ma007.203 : Print the Buffer in case of Error */
     SPrntMsg( s->ctlp.mBuf,0,0);
     MALOGERROR(ERRCLS_INT_PAR, EMA157, (ErrVal)oprCode, "maDecOpr () Failed to decode");
  }
#endif
  RETVALUE(ret);

} /* maDecOpr  */

/*
*
*       Fun:   maSndTcErr    
*
*       Desc:  This function sends the TC -U Error component  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maSndTcErr 
(
MaSap   *s,             /* MAP SAP */
StInvokeId *invkId,     /* Invoke Id */
StStr   *errStr,        /* Error string */
MaCmpCp    *cmpCp,      /* Component control point */
Buffer  *mBuf           /* Message buffer */
)
#else
PUBLIC S16 maSndTcErr (s, invkId, errStr, cmpCp, mBuf)
MaSap      *s;          /* MAP SAP */
StInvokeId *invkId;     /* Invoke Id */
StStr      *errStr;     /* Error string */
MaCmpCp    *cmpCp;      /* Component control point */
Buffer     *mBuf;       /* Message buffer */
#endif
{
  StComps   cmpEv;
  MaDlgCp   *dlgCp;
#if MAP_REL99
#if (MAP_SEC && LMAV2)
  S16       ret;
#endif
#endif

  TRC2(maSndTcErr)
 
  maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
  dlgCp  = s->curDlgCp;
  cmpCp = maFindHashInvk(dlgCp, invkId,FALSE);

  cmpEv.stCompType = STU_RET_ERR;
  cmpEv.stInvokeId.pres = TRUE;
  cmpEv.stInvokeId.octet = invkId->octet;
  cmpEv.stLinkedId.pres = FALSE;

  /*
  ** For the Return Error component we should not
  ** fill the operation code
  */
  cmpEv.stOpCode.len = 0;

  cmpEv.stErrorCode.len = 1;
  cmpEv.stErrorCode.string[0] = errStr->string[0];
  cmpEv.stErrorCodeFlg = STU_LOCAL;
  cmpEv.cancelFlg = FALSE;  
  cmpEv.stProbCode.len = 0;  
  cmpEv.opClass = cmpCp->oprClass; 
  if (s->trc == TRUE)
  {
    maGenTrc(s, LMA_CMP_TXED, mBuf);
  }

#if MAP_REL99
#if (MAP_SEC && LMAV2)
  if(dlgCp->mapSec == TRUE)
  {
     if(mBuf == (Buffer *)NULLP)
     {
        if ((ret = SGetMsg(s->maPstST.region, s->maPstST.pool, &mBuf )) != ROK)
        {
#ifndef ALIGN_64BIT

           MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
           "maSndTcErr() alloc failed, fail to allocate mBuf,\
           suId(%d), sapId(%d), suDlgId(%ld), spDlgId(%ld))\n",
           s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
           RETVALUE(RFAILED);

#else

           MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
           "maSndTcErr() alloc failed, fail to allocate mBuf,\
           suId(%d), sapId(%d), suDlgId(%d), spDlgId(%d))\n",
           s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
           RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
        }
     }
     s->ctlp.mBuf = mBuf;
     ret = maProcSecOprErr(s,dlgCp,&cmpEv,cmpCp,mBuf);

     if(ret != ROK)
     {
        MADBGP(MA_DBGMASK_SEC_RESP, (maCb.maInit.prntBuf,
               "maSndTcErr() failed, fail to encode Sec error.\n"));
        if (s->ctlp.mBuf != NULLP)
        {
           SPutMsg(s->ctlp.mBuf);
        }
        RETVALUE(RFAILED);
     }
     mBuf = s->ctlp.mBuf;
  }
#endif /* MAP_SEC */
#endif

  MaLiStuCmpReq (&s->maPstST, s->spIdTC, dlgCp->spDlgId, dlgCp->lowerSpDlgId, 
                 &cmpEv, mBuf);
  RETVALUE(ROK);
} /* maSndTcErr  */

/*
*
*       Fun:   maSndTcRej    
*
*       Desc:  This function sends the TC -U Reject component  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maSndTcRej 
(
MaSap   *s,             /* MAP SAP */
StComps *curCmpEv,      /* Component Event Structure */
U8      probType,       /* problem type */
U8      probCode        /* problem code */
)
#else
PUBLIC S16 maSndTcRej (s, curCmpEv, probType, probCode)
MaSap   *s;             /* MAP SAP */
StComps *curCmpEv;         /* Component Event Structure */
U8      probType;       /* problem type */
U8      probCode;      /* problem code */
#endif
{
  MaDlgCp   *dlgCp;
  StComps   cmpEv;      /* Component Event Structure */

  TRC2(maSndTcRej)
  maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
 
  dlgCp  = s->curDlgCp;

  cmpEv.stCompType = STU_REJECT;
  cmpEv.stInvokeId.pres = TRUE;
  cmpEv.stInvokeId.octet = curCmpEv->stInvokeId.octet;
  cmpEv.stLinkedId.pres = FALSE;
  cmpEv.stOpCode.string[0] =curCmpEv->stOpCode.string[0];
  cmpEv.stOpCode.len = 1;
  cmpEv.stOpCodeFlg = STU_LOCAL;
  cmpEv.stProbCode.len = 1;
  cmpEv.stProbCodeFlg = probType;
  cmpEv.stProbCode.string[0] = probCode;
  cmpEv.stErrorCode.len = 0;
  cmpEv.cancelFlg = FALSE;  
  cmpEv.opClass = curCmpEv->opClass;
  MaLiStuCmpReq (&s->maPstST, s->spIdTC, dlgCp->spDlgId, dlgCp->lowerSpDlgId, 
                 &cmpEv, NULLP);
  RETVALUE(ROK);
} /* maSndTcRej  */

/*
*
*       Fun:   maCmpAcn    
*
*       Desc:  This function compares the Application context names 
*
*       Ret:   0 if both the strings are same. 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maCmpAcn 
(
U8 *s1,         /* string 1 */
U8 *s2,         /* String 2 */
S16 len1,       /* length of string1 */
S16 len2        /* length of string2 */
)
#else
PUBLIC S16 maCmpAcn (s1,s2,len1,len2)
U8 *s1;         /* string 1 */
U8 *s2;         /* String 2 */
S16 len1;       /* length of string1 */
S16 len2;       /* length of string2 */
#endif
{
   S16 i;

   TRC2(maCmpAcn)

   if (len1 != len2)
   {
      RETVALUE(len1 - len2);
   }
   for(i=0;i<len1;i++)
   {
      if (s1[i] != s2[i])
      {
         RETVALUE(s1[i] - s2[i]);
      }
   }
   /* equal strings */
   RETVALUE(0);
} /* end of maCmpAcn */

/*
*
*       Fun:   maIsOprSupp    
*
*       Desc:  This function  ichecks whether a operation is supported 
*              by MAP
*
*       Ret:   ROK  if operation supported
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maIsOprSupp 
(
MaSap   *s,             /* MAP Sap */
U8      oprCode,        /* Operation code */
U8      *oprClass,         /* class of operation */
U16     *tmrVal,         /* Timer for the operation */
U8      maVer            /* version sent in the open request */
)
#else
PUBLIC S16 maIsOprSupp (s, oprCode, oprClass, tmrVal,maVer)
MaSap   *s;             /* MAP Sap */
U8      oprCode;        /* Operation code */
U8      *oprClass;         /* class of operation */
U16     *tmrVal;        /* Timer for the operation */
U8      maVer;          /* Version sent in the open request */
#endif
{
  S16   i;

  TRC2(maIsOprSupp)
 
  for (i=0; i< MA_MAX_OPR; i++)
  {
     
    if (s->cfg.apnCfg[i].pres == TRUE)
    {
      if (s->cfg.apnCfg[i].oprCode == oprCode)
      {
        /* match the version */
        switch (maVer)
        {
          case LMA_VER1:
            if ((IS_EQUAL_VER1(s->cfg.apnCfg[i].maVer)))
            break;
            continue;
          case LMA_VER2:
            if ((IS_EQUAL_VER2(s->cfg.apnCfg[i].maVer)))
            break;
            continue;
          case LMA_VER2P:
            if ((IS_EQUAL_VER2P(s->cfg.apnCfg[i].maVer)))
            break;
            continue;
          case LMA_VER4:
            if ((IS_EQUAL_VER4(s->cfg.apnCfg[i].maVer)))
            break;
            continue;
          default :
        MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
               "maIsOprSupp() failed, Operation doesn't supported.\n"));
        RETVALUE(RFAILED);
            break;
        }

        *oprClass = s->cfg.apnCfg[i].oprClass; 
        *tmrVal = s->cfg.apnCfg[i].oprTmr.val;
        RETVALUE(ROK); 
      }
    }
  }

  MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
  "maIsOprSupp() failed, Operation doesn't supported.\n"));
  RETVALUE(RFAILED);
} /* maIsOprSupp  */


/*
*
*       Fun:   maIsOprApnSupp    
*
*       Desc:  This function  checks whether a operation is supported 
*              by MAP  
*
*       Ret:   ROK  if operation supported
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maIsOprApnSupp 
(
MaSap   *s,             /* MAP Sap */
U8      oprCode,        /* Operation code */
MaDlgCp *dlgCp,         /* Dialogue Control point */
U8      *oprClass,      /* class of operation */
U16     *tmrVal         /* Timer for the operation */
)
#else
PUBLIC S16 maIsOprApnSupp (s, oprCode, dlgCp, oprClass, tmrVal)
MaSap   *s;             /* MAP Sap */
U8      oprCode;        /* Operation code */
MaDlgCp *dlgCp;         /* Dialogue Control point */
U8      *oprClass;      /* class of operation */
U16     *tmrVal;        /* Timer for the operation */
#endif
{
  S16   i;

  TRC2(maIsOprApnSupp)

/*for insert_sub_data primitive, it is included in tow AC (MA_SUBS_DATA_MNGMT_AC and MA_NETWORK_LOCUP_AC)*/
  if((oprCode == MAT_INSSUBSDATA)&&(dlgCp->apn.val[dlgCp->apn.len - 2] == MA_SUBS_DATA_MNGMT_AC))
    RETVALUE(ROK);
     
  for (i=0; i< MA_MAX_OPR; i++)
  {
     if (s->cfg.apnCfg[i].pres == TRUE)
     {
        if (s->cfg.apnCfg[i].oprCode == oprCode)
        {
           if(dlgCp->apn.val[dlgCp->apn.len - 1] > LMA_VER1)
           {
              if(dlgCp->apn.val[dlgCp->apn.len - 2] == s->cfg.apnCfg[i].apn.string[s->cfg.apnCfg[i].apn.len - 2])
              {        
                 *oprClass = s->cfg.apnCfg[i].oprClass; 
                 *tmrVal = s->cfg.apnCfg[i].oprTmr.val;
                 RETVALUE(ROK);
              }
           }
        }
     }
  }

  MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
  "maIsOprApnSupp() failed, Operation is not within Apn.\n"));
  RETVALUE(RFAILED);
} /* maIsOprApnSupp  */

/*
*
*       Fun:   maConvertACN    
*
*       Desc:  This function  converts Application
*              context name from ASN.1 encoded format 
*              in the dialogue event structure of TC into 
*              non ASN.1 format. 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maConvertACN 
(
StStr *acn
)
#else
PUBLIC S16 maConvertACN (acn)
StStr *acn;
#endif
{

   StStr   tmpStr;
   MsgLen  idx =  0;
   U8      first = 1;   /* first subId */
   U16     subId1;         /* value */
   U16     subId2;         /* value */
   U8      len;         /* length */
 
   TRC2(maConvertACN);
 
   tmpStr.len = 0;
 
   /* get the length */
   len = (U8)acn->len;
 
   while (len > 0)
   {
      U32     val = 0;         /* value */
      U8      data;
 
      do {
         data = acn->string[idx];
         val = (val << 7) | (data & 0x7f);
         idx++;
         len--;
      } while (data & 0x80);
 
      if (first)
      {
         subId1 = (val / 40);
         subId2 = (val % 40);
 
         if (subId1 >= 2)
         {
            subId2 += ((subId1- 2) * 40);
            subId1 = 2;
         }
 
         tmpStr.string[(tmpStr.len)++] = (U8) subId1;
         tmpStr.string[(tmpStr.len)++] = (U8) subId2;
         first = 0;
      }
      else
      {
         tmpStr.string[(tmpStr.len)++] = (U8) val;
      }
   }

   /* copy the decoded string back to acn */ 
   cmCopyStStr(&tmpStr, acn);

  RETVALUE(ROK);
} /* maConvertACN */

/*
*
*       Fun:   maIsAcnSupp    
*
*       Desc:  This function  checks whether Application
*              context name is supported or not and changes
*              the storage of Application contetxt name in
*              dialogue event structure. (the way it is stored
*              in dialogue control point) 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maIsAcnSupp 
(
MaApnCfg  *apnCfg,
U8        *evtPtr,
MaDlgCp   *dlgCp
)
#else
PUBLIC S16 maIsAcnSupp (apnCfg, evtPtr, dlgCp)
MaApnCfg  *apnCfg;
U8        *evtPtr;
MaDlgCp   *dlgCp;
#endif
{
  StDlgEv  *dlgEv;
  U8       i;
  U8       j;
  /* added flag MA_ACN_VER1_SUPPCHK to keep checking for ACN when
     multiple entries for the ACN are in the table. We donot return
     after the first entry anymore. */
#ifndef MA_ACN_VER1_SUPPCHK
  U8       altApnFound = 0;
  MaApnStr altApn;
#endif /* MA_ACN_VER1_SUPPCHK */

  TRC2(maIsAcnSupp)

  dlgEv = (StDlgEv *)evtPtr;

  for (i=0; i< MA_MAX_OPR; i++)
  {
    if ((apnCfg[i].apn.len != dlgEv->apConName.len)
#ifdef MA_ACN_VER1_SUPPCHK
        || (apnCfg[i].apn.string[apnCfg[i].apn.len - 1] == LMA_VER1)
#endif /* MA_ACN_VER1_SUPPCHK */
       )
    {
      continue;
    }
    for (j=0; j< (U16)(apnCfg[i].apn.len -1); j++)
    { 
      if (apnCfg[i].apn.string[j] != dlgEv->apConName.string[j])
      {
        break;
      }
    }
    if (j == apnCfg[i].apn.len-1)
    {
      /* If the application context names are same 
      **                   or 
      **  configured version is ALL (and) version  in the dialogue 
      **  is less than or equal to configured version
      */
      if( (apnCfg[i].apn.string[j] == dlgEv->apConName.string[j])
                           ||
          ( apnCfg[i].maVer == LMA_VER_ALL  &&
            (apnCfg[i].apn.string[j] >= dlgEv->apConName.string[j]) ))
      {
         /* same APN is supported or MAP V1, V2 and V3 are supported */
         RETVALUE(TRUE);
      }
      else
      {
         if(apnCfg[i].altApn.len != 0)
         {
            /* supports operation code with different APN */
            /* copy the alternative conext name in the dialogue 
            * control point and return FALSE
            */
#ifndef MA_ACN_VER1_SUPPCHK

            altApnFound = 1; /* Alternate APN found */
            altApn.len   = (U8)apnCfg[i].altApn.len;
            cmCopy(&apnCfg[i].altApn.string[0], &altApn.string[0], 
                   apnCfg[i].altApn.len);

#else /* MA_ACN_VER1_SUPPCHK */

            dlgCp->apn.len = (U8)apnCfg[i].altApn.len;
            cmCopy(&apnCfg[i].altApn.string[0],&dlgCp->apn.val[0], 
                   apnCfg[i].altApn.len);
#endif /* MA_ACN_VER1_SUPPCHK */
         }
         else
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
                                "maIsAcnSupp() failed, alt. APN is not configured.\n"));
            RETVALUE(FALSE);
         }
#ifndef MA_ACN_VER1_SUPPCHK
         /* Continue to find the APN in the list */ 
         continue;
#else
         RETVALUE(FALSE);
#endif /* MA_ACN_VER1_SUPPCHK */

      }

    }
  }

#ifndef MA_ACN_VER1_SUPPCHK
  /* If alternate APN is found return it */
  if (altApnFound)
  {
      dlgCp->apn.len = (U8)altApn.len;
      cmCopy(&altApn.string[0], &dlgCp->apn.val[0], altApn.len);

      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maIsAcnSupp(), alt. APN is configured.\n"));

      RETVALUE(FALSE);
  }
#endif  /* MA_ACN_VER1_SUPPCHK */

  MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
  "maIsAcnSupp() failed, APN is not supported.\n"));
  RETVALUE(FALSE);
} /* maIsAcnSupp  */

/*
*
*       Fun:   maIsLinkedOpr    
*
*       Desc:  This function  determines whether linked operation
*              is allowed or not.
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maIsLinkedOpr 
(
U8    parOprCode,       /* parent operation code */
U8    lnkOprCode,       /* Linked operation code */
Bool  flag              /* Flag */
)
#else
PUBLIC S16 maIsLinkedOpr (parOprCode, lnkOprCode, flag)
U8    parOprCode;          /* operation code */
U8    lnkOprCode;  /* Linked operation code */
Bool  flag;        /* Flag */
#endif
{
  TRC2(maIsLinkedOpr)

  switch(parOprCode)
  {
    case MAT_REGPASSWD:
      if (flag == TRUE)
      {
        if (lnkOprCode == MAT_GETPASSWD)
          RETVALUE(ROK);
        else
        {
          MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
          "maIsLinkedOpr() failed, invalid link oprCode.\n"));
          RETVALUE(RFAILED);
        }
      }
      RETVALUE(ROK);
    default:
      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "maIsLinkedOpr() failed, invalid operation code.\n"));
      RETVALUE(RFAILED);
  }
} /* maIsLinkedOpr  */


/*
*
*       Fun:   maGetAcn    
*
*       Desc:  This function Gets the application context name associated 
*              with the application context name
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maGetAcn 
(
MaSap   *s,      /* MAP SAP */
U8      oprCode, /* operation code */
TknStrS *acn     /* Application context name */
)
#else
PRIVATE S16 maGetAcn (s, oprCode, acn)
MaSap   *s;      /* MAP SAP */
U8      oprCode; /* operation code */
TknStrS *acn;    /* Application context name */
#endif
{
  U8 i;
  TRC2(maGetAcn)

  for (i=0; i< MA_MAX_OPR; i++)
  {
    if (s->cfg.apnCfg[i].pres == TRUE)
    {
      if (s->cfg.apnCfg[i].oprCode == oprCode)
      {
        if (!IS_EQUAL_VER1(s->cfg.apnCfg[i].maVer))
        {
				/* ma001.203: Modification. Allowing to search entire apnCfg Table */
				continue;	
        }
        else
        {
          cmCopy(&s->cfg.apnCfg[i].apn.string[0], &acn->val[0],
                 (U32)s->cfg.apnCfg[i].apn.len);
          acn->len =  (U8)s->cfg.apnCfg[i].apn.len;
          acn->pres =  TRUE;

            acn->val[acn->len-1] = LMA_VER1;
          RETVALUE(ROK);
        }
      }
    }
  }
  MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
  "maGetAcn() failed, fail to get the Acn.\n"));
  RETVALUE(RFAILED);
} /* maGetAcn  */


/*
*
*       Fun:   maBldDlgId    
*
*       Desc:  This function Build the dialogue identifier 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maBldDlgId 
(
Buffer *mBuf,     /* Message Buffer */
Bool   mapSec     /* mapSec Flag */
)
#else
PUBLIC S16 maBldDlgId (mBuf, mapSec)
Buffer *mBuf;     /* Message Buffer */
Bool   mapSec;    /* mapSec Flag */
#endif
{
  MsgLen curLen;
  MsgLen msgLen;
  Data   idx;
  Data   pkArray[20];
  S16    ret;

  TRC2(maBldDlgId)

  (Void)SFndLenMsg(mBuf, &curLen);

  idx = 0;
  /* encode the length */
  MA_ENCODE_LEN(curLen,idx)

  /* encode the single ASN1-Type tag */
  pkArray[idx++] = (Data)MA_TAG_SNGL_ASN1_TYPE;
  pkArray[idx++] = (Data)MA_TAG_DLGID_B7;
  if (mapSec == TRUE)
  {
     pkArray[idx++] = (Data)MA_TAG_PROT_DLGID_B6;
  }
  else
  {
     pkArray[idx++] = (Data)MA_TAG_DLGID_B6;
  }   
  pkArray[idx++] = (Data)MA_TAG_DLGID_B5;
  pkArray[idx++] = (Data)MA_TAG_DLGID_B4;
  pkArray[idx++] = (Data)MA_TAG_DLGID_B3;
  pkArray[idx++] = (Data)MA_TAG_DLGID_B2;
  pkArray[idx++] = (Data)MA_TAG_DLGID_B1;
  pkArray[idx++] = (Data)7;
  pkArray[idx++] = (Data)MA_TAG_OBJID;

  msgLen = (curLen + idx);

  /* encode the external tag and length */
  /* encode the length */
  MA_ENCODE_LEN(msgLen,idx)

  pkArray[idx++] = (Data)MA_TAG_EXT;
  ret = SAddPreMsgMult(pkArray, (MsgLen)idx, mBuf);

#if (ERRCLASS & ERRCLS_ADD_RES)
  if (ret != ROK)
  {
    MALOGERROR(ERRCLS_ADD_RES, EMA158, (ErrVal)ret, "maBldDlgId () Failed");
    RETVALUE(RFAILED);
  }
#endif

  RETVALUE(ROK);
} /* maBldDlgId  */


/*
*
*       Fun:   maDecDlgId    
*
*       Desc:  This function Decodes the dialogue identifier 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maDecDlgId 
(
Buffer *mBuf    /* Message Buffer */
)
#else
PUBLIC S16 maDecDlgId (mBuf)
Buffer *mBuf;   /* Message Buffer */
#endif
{
 Data   data;
 MsgLen len;
 StStr  str;
 U8     i;
 S16    ret;

 TRC2(maDecDlgId);


 if ( (ret = SRemPreMsg(&data, mBuf)) != ROK)
   RETVALUE(ret);

 if (data != MA_TAG_EXT)
 {
    MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
    "maDecDlgId() failed, invalid tag value(%d).\n", data));
    RETVALUE(RFAILED);
 }

 if ((ret = SFndLenMsg(mBuf,&len)) != ROK)
   RETVALUE(ret);

 if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
   RETVALUE(ret);

 if(!(data  &0x80))
 {
   /* short form of length remove one length of byte */
   if ((ret = SRemPreMsg(&data, mBuf)) != ROK)
     RETVALUE(ret);
 }
 else if (data == 0x80)
 {
   /* indefinate form of length remove the EOC marker */
   if ((ret = SRemPreMsg (&data, mBuf)) != ROK)
     RETVALUE(ret);
 }
 else
 {
   /* remove long form of length bytes */
   if ((ret = SRemPreMsg(&data, mBuf)) != ROK)
     RETVALUE(ret);

   data &= 0x7f;
   for (i=0; i< data; i++)
   {
     if ((ret = SRemPreMsg(&data, mBuf)) != ROK)
       RETVALUE(ret);
   }
 }
 if ((ret = SExamMsg(&data, mBuf,0)) != ROK)
    RETVALUE(ret);

 /* ma007.203: Modified the check in order to treat 
    Object identifer as optional */
 if (data == MA_TAG_OBJID)
 {
    /* remove the object Id */
   if ((ret = maRemPrim(mBuf, NULLP, &str.string[0], (U8 *)&(str.len))) != ROK)
          RETVALUE(ret);
 }
  
 if ((ret = SExamMsg(&data, mBuf,0)) != ROK)
     RETVALUE(ret);
 
 /* Check if optional integer tag is present */
 if (data == MA_TAG_INTEGER)
 {
     /* remove the integer */
   if ((ret = maRemPrim(mBuf, NULLP, &str.string[0], (U8 *)&(str.len))) != ROK)
      RETVALUE(ret);
 }
 
 if ((ret = SExamMsg(&data, mBuf,0)) != ROK)
      RETVALUE(ret);
 
 /* Check if optional object descriptor tag is present */
 if (data == MA_TAG_OBJDES)
 {
    /* remove the object descriptor */
   if ((ret = maRemPrim(mBuf, NULLP, &str.string[0], (U8 *)&(str.len))) != ROK)
    RETVALUE(ret);
 }
 /* remove the single ASN-1 type tag and length */
 if ((ret = SRemPreMsg(&data, mBuf)) != ROK)
    RETVALUE(ret);
 if (data != MA_TAG_SNGL_ASN1_TYPE)
 {
    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf,
    "maDecDlgId() failed, invalid tag value(%d).\n", data));
    RETVALUE(RFAILED);
 }
 
 /* remove the length */
 if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
   RETVALUE(ret);

 if(!(data  &0x80))
 {
   /* short form of length remove one length of byte */
   if ((ret = SRemPreMsg(&data, mBuf)) != ROK)
     RETVALUE(ret);
 }
 else if (data == 0x80)
 {
   /* indefinate form of length remove the EOC marker */
   if ((ret = SRemPreMsg(&data, mBuf)) != ROK)
     RETVALUE(ret);
 }
 else
 {
   /* remove long form of length bytes */
   if ((ret = SRemPreMsg(&data, mBuf)) != ROK)
     RETVALUE(ret);

   data &= 0x7f;
   for (i=0; i< data; i++)
   {
     if ((ret = SRemPreMsg(&data, mBuf)) != ROK)
       RETVALUE(ret);
   }
 }
 RETVALUE(ROK);
} /* maDecDlgId */


/*
*
*       Fun:   maChkLoad    
*
*       Desc:  This function  checks whether an incoming dialogue request
*              can ve accepted or not.
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maChkLoad 
(
MaSap *s
)
#else
PRIVATE S16 maChkLoad (s)
MaSap *s;
#endif
{
  TRC2(maChkLoad)
 
  if (s->nmbActvDlg <= s->cfg.maxDlg)
    RETVALUE(TRUE);
  else
    RETVALUE(FALSE);
} /* maChkLoad  */

/*
*
*       Fun:   maSendAlrm    
*
*       Desc:  This function  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maSendAlrm 
(
U8   old,          /* old/new interface */
SuId suId,         /* service user identifier */
Elmnt elmnt,       /* element identifier */
Status status,     /* status  */
Txt *func,         /* function name */
U16 evnt,          /* Event */
U16 cgy,           /* alarm category */
U16 cause          /* cause */
)
#else
PUBLIC S16 maSendAlrm (old,suId, elmnt,status, func,evnt,cgy,cause)
U8   old;      /* old/new interface */
SuId suId;     /* service user identifier */
Elmnt elmnt;   /* element identifier */
Status status; /* status */
Txt *func;     /* function name */
U16 evnt;      /* Event */
U16 cgy;       /* alarm category */
U16 cause;     /* cause */
#endif
{
   MaMngmt usta;
   MaSap   *s;
   MaDlgCp *dlgCp;

   TRC2(maSendAlrm)

   if(maCb.maInit.usta != TRUE)
   {
      /* Dont generate the alarm */
      RETVALUE(ROK);
   }

#ifdef MA_RUG
   /* If general configuration not done the smPst is *
    * not valid and we cant generate any alarms      */
   if (maCb.maInit.cfgDone == FALSE)
   {
      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
             "General configuration not done, no alarms can be generated\n"));
      RETVALUE(ROK);
   }       
#endif /* MA_RUG */

   UNUSED(old);
   UNUSED(suId);
   UNUSED(elmnt);
   UNUSED(status);
   UNUSED(func);

   /* zero out the management structure */
   cmZero((Data *) &usta,sizeof(MaMngmt));
   usta.hdr.msgType = TUSTA;

   usta.hdr.msgLen             = MA_UNUSED;
   usta.hdr.version            = MA_UNUSED;
   usta.hdr.seqNmb             = MA_UNUSED;
   usta.hdr.entId.ent          = MA_UNUSED;
   usta.hdr.entId.inst         = MA_UNUSED;
   usta.hdr.elmId.elmnt        = MA_UNUSED;
   usta.hdr.elmId.elmntInst1   = MA_UNUSED;
   usta.hdr.elmId.elmntInst2   = MA_UNUSED;
   usta.hdr.elmId.elmntInst3   = MA_UNUSED;
 
   /* fill in the event , category and cause */
   usta.t.usta.alarm.category  = cgy;
   usta.t.usta.alarm.event     = evnt;
   usta.t.usta.alarm.cause     = cause;
 

   usta.t.usta.info.mem.region  = maCb.maInit.region;
   usta.t.usta.info.mem.pool    = maCb.maInit.pool;
   usta.t.usta.info.sapId       = suId;

/* ma011.203 : To Handle crash in case of sap configuration is not done and try                to access maSapLmaPtr. */
 if(maCb.maSapLmaPtr != (MaSap**) NULLP)
 {
 
/* ma008.203 : To Handle the crash in the case of -ve suId */
 
   if (suId < (SuId)maCb.maCP.nmbMAUSaps && suId >=0 && ((s = *(maCb.maSapLmaPtr + suId)) != (MaSap *)NULLP))
   {
      dlgCp = s->curDlgCp;
      if (dlgCp != (MaDlgCp *)NULLP)
      {
         usta.t.usta.info.dlgId  = dlgCp->spDlgId;
         usta.t.usta.info.state  = dlgCp->dsmState;
#if MAP_REL99
#if (MAP_SEC && LMAV2)
         usta.t.usta.info.secUsta.plmnId.mcc.pres = TRUE;
         usta.t.usta.info.secUsta.plmnId.mcc.val = dlgCp->peerId.mcc.val;
         usta.t.usta.info.secUsta.plmnId.mnc.pres = TRUE;
         usta.t.usta.info.secUsta.plmnId.mnc.val = dlgCp->peerId.mnc.val;
         if (dlgCp->apn.pres == TRUE)
         {
            usta.t.usta.info.secUsta.acName = dlgCp->apn.val[6];
            usta.t.usta.info.secUsta.acVer = (LmaAcVer)dlgCp->apn.val[7];
         }
         if (dlgCp->mapSec == TRUE)
         {
            usta.t.usta.info.secUsta.secSpi = dlgCp->saCp->sa.spi;
            usta.t.usta.info.secUsta.cmpId.cmpType = dlgCp->cmpId.cmpType;
            usta.t.usta.info.secUsta.cmpId.cmpVal = dlgCp->cmpId.cmpVal;
         }
#endif /* MAP_SEC */
#endif
      }
   }
  }
   MaMiLmaStaInd(&maCb.maCP.smPst, &usta);
   RETVALUE(ROK);
} /* maSendAlrm  */

#ifndef MA_STATIC_EVT_STRUCT
/*
*
*       Fun:   maFreeEncEv    
*
*       Desc:  This function  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE Void maFreeEncEv 
(
MaSap     *s,
U8        *evtPtr,
MaCmpCp   *cmpCp
)
#else
PRIVATE Void maFreeEncEv (s, evtPtr, cmpCp)
MaSap     *s;
U8        *evtPtr;
MaCmpCp   *cmpCp;
#endif
{
   TRC2(maFreeEncEv);

   if (!evtPtr)
      RETVOID;

  switch (cmpCp->oprCode)
  {
#if MAP_VLR
   case MAT_GETPASSWD:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaSSEv));
     }
     break;
#endif /* VLR */

#if (MAP_VLR || MAP_HLR)
   case MAT_USSREQ:
   case MAT_USSNOTIFY:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaSSEv));
     }
     break;
#endif /* VLR || HLR */

#if MAP_HLR
   case MAT_REGSS:
   case MAT_ERASESS:
   case MAT_ACTVSS:
   case MAT_DACTVSS:
   case MAT_INTERSS:
   case MAT_REGPASSWD:
   case MAT_PROCUSSDATA:
   case MAT_PROCUSSREQ:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaSSEv));
     }

     break;
#endif /* HLR */
 
#if MAP_MSC
   case MAT_TRACESUBSACTV:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaOAMEv));
     }

     break;
#endif /* MSC */

#if MAP_MSC
   case MAT_INFSC:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaSMEv));
     }

     break;
#endif /* MAP_MSC */

#if MAP_HLR
   case MAT_ROUTINFOSM:
   case MAT_SMDEL:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaSMEv));
     }

     break;
#endif /* MAP_HLR */
/* ma013.203 : Correction SS_INVOKE_NOTIFY is moved in SS Service */
#if MAP_HLR
   case MAT_SSINV_NOTIFY:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaSSEv));
     }

     break;
#endif /* MAP_HLR */

#if MAP_MSC
   case MAT_ALRTSC:
   case MAT_ALRTSCWRSLT:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaSMEv));
     }
     break;
#endif  /* MSC */

#if MAP_HLR
   case MAT_NOTSUBPRES:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaSMEv));
     }
     break;
#endif /* MAP_HLR */

#if MAP_HLR
   case MAT_UPLOC:
#if MAP_REL99
   case MAT_NOTE_MMEVT:
#endif /* MAP_REL99 */
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaLocEv));
     }

     break;
     
   case MAT_RESTOREDATA:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaFREv));
     }

     break;
#endif /* MAP_HLR */

#if MAP_VLR
   case MAT_PROVROAMNMB:
   case MAT_SETRPTSTATE:
   case MAT_RMTUSRFREE:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaCallEv));
     }

     break;
#endif  /* VLR) */

#if MAP_HLR
   case MAT_REGCCENT:
   case MAT_ERASECCENT:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaSSEv));
     }
     break;

#endif /* MAP_HLR */
#if MAP_VLR 
   case MAT_FWDCHKSSIND:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaFREv));
     }

     break;
#endif /* HLR */

#if MAP_MSC
   case MAT_PRE_HO:
   case MAT_PER_HO:
   case MAT_SNDENDSIG:
   case MAT_PROCACCSIG:
   case MAT_FWDACCSIG:
   case MAT_PRE_SUBSHO:
   case MAT_PER_SUBSHO:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaHoEv));
     }
     break;
   case MAT_NOTEINTERHO:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaOAMEv));
     }
     break;
   case MAT_RESCALLHANDL:
   case MAT_PREP_GRPCALL:
   case MAT_PRO_GRPCALLSIG:
   case MAT_FWD_GRPCALLSIG:
   case MAT_SND_GRPCALLENDSIG:
   case MAT_PROV_SIWFS_NMB:
   case MAT_SIWFS_SIGMOD:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaCallEv));
     }
     break;
#endif  /* MSC */

#if MAP_VLR
  /* Send Identification Request */
  case MAT_SNDID:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaLocEv));
     }
     break;
   case MAT_DET_IMSI:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaLocEv));
     }
     break;
#endif  /* MAP_VLR */

#if MAP_HLR
   case MAT_ROUTINFO: 
   case MAT_STARPT:  
#if MAP_REL99
   case MAT_IST_ALERT:
#endif /* MAP_REL99 */
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaCallEv));
     }
     break;
   case MAT_BEGIN_SUBS_ACTV:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaSSEv));
     }
     break;
   case MAT_PURGE:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaLocEv));
     }
     break;
#endif /* MAP_HLR */

#if (MAP_HLR || MAP_MLC)
   case MAT_ANY_INTER:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaSubEv));
     }

     break;
#endif /* MAP_HLR || MAP_MLC */

#if (MAP_VLR || MAP_HLR)
   case MAT_SNDPARAM:  
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaSubEv));
     }
     break;
#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_GSN)
   case MAT_CANCELLOC:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaLocEv));
     }
     break;
#endif /* MAP_VLR || MAP_GSN */

#if MAP_HLR
   case MAT_GPRS_UPLOC:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaLocEv));
     }

     break;

   case MAT_GPRS_ROUTINFO:
   case MAT_FAILRPT:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaPdpActvEv));
     }
     break;
#endif /* MAP_HLR */

#if MAP_GSN
   case MAT_GPRS_NOTEMSPRES:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaPdpActvEv));
     }

     break;
#endif /* MAP_GSN */

#if (MAP_MSC || MAP_GSN)
   case MAT_FWDSM:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaSMEv));
     }
     break;
#endif /* MAP_MSC */

#if (MAP_MSC || MAP_GSN)
   case MAT_MT_FWDSM:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaSMEv));
     }
     break;
#endif /* MAP_MSC || MAP_GSN */

#if MAP_HLR
   case MAT_SMRDY:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaSMEv));
     }
     break; 
#endif /* MAP_HLR */

#if (MAP_VLR || MAP_GSN)
   case MAT_INSSUBSDATA:
   case MAT_DELSUBSDATA:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaSubEv));
     }
     break;

#if (MAP_VLR || (MAP_GSN && MAP_REL5))
   case MAT_PROVSUBSINFO:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaSubEv));
     }
     break;
#endif /* (MAP_VLR || (MAP_GSN && MAP_REL5)) */
#endif /* MAP_VLR || MAP_GSN */

#if MAP_HLR
   case MAT_SNDIMSI:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaOAMEv));
     }
     break;
#endif /* MAP_HLR */

#if (MAP_VLR || MAP_GSN)
   case MAT_ACTVTRACE:
   case MAT_DACTVTRACE:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaOAMEv));
     }
     break;

   case MAT_RESET:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaFREv));
     }
     break;
#endif /* MAP_VLR || MAP_GSN */

#if MAP_REL99
#if MAP_MSC
   case MAT_IST_COMMAND:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaCallEv));
     }
     break;
#if MAP_REL6
   case MAT_REL_RES:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaCallEv));
     }
     break;
#endif /* MAP_REL6 */
#endif /* MAP_MSC */

#if MAP_HLR
   case MAT_AUTHFAILRPT:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaAuthEv));
     }
     break;
#endif /* MAP_HLR */
#endif /* MAP_REL99 */

#if MAP_HLR
   case MAT_AUTHINFO:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaAuthEv));
     }
     break;
#endif /* MAP_HLR */

#if MAP_VLR
   case MAT_CHKIMEI:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaIMEIEv));
     }
     break;
#endif /* MAP_VLR */

#if (MAP_REL98 || MAP_REL99)
#if MAP_HLR
   case MAT_SENDROUTINFOFORLCS:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaLocServEv));
     }
     break;
#endif /* MAP_HLR */

#if MAP_MLC
   case MAT_SUBSLOCRPT:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaLocServEv));
     }
     break;
#endif /* MAP_MLC */
#endif /* MAP_REL98 || MAP_REL99 */

#if (MAP_REL98 || MAP_REL99)
#if (MAP_MSC || MAP_GSN)
#if (MAP_MSC || (MAP_REL4 && MAP_GSN))

   case MAT_PROVSUBSLOC:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaLocServEv));
     }
     break;
#endif
#endif

#if MAP_HLR
   case MAT_ANY_SUBSDATA_INTER:
   case MAT_ANY_MOD:
   case MAT_NOTE_SUBSDATA_MOD:
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) evtPtr, sizeof(MaSubEv));
     }
     break;
#endif /* MAP_HLR */
#endif /* (MAP_REL98 || MAP_REL99) */

   default:
     break;
  }
  RETVOID;

} /* maFreeEncEv  */
#endif /* MA_STATIC_EVT_STRUCT */

/*
*
*       Fun:   maSndSSInd    
*
*       Desc:  This function  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maSndSSInd 
(
MaSap     *s,
MaCmpCp   *cmpCp
)
#else
PRIVATE S16 maSndSSInd (s, cmpCp)
MaSap     *s;
MaCmpCp   *cmpCp;
#endif
{
  MaDlgCp   *dlgCp;

  TRC2(maSndSSInd)
 
  dlgCp = s->curDlgCp;

  /* Update the Stat. */
#if MAP_REL99
#if (MAP_SEC && LMAV2)
  if (dlgCp->mapSec == FALSE)
#endif
#endif
  maUpdatRxSts(s,cmpCp->oprCode, MAT_SS_REQ);

  switch (cmpCp->oprCode)
  {
#ifdef XWEXT /* xuxingzhou: xinwei */
   case MAT_PAGING_DETECT:
   	MaUiMatXWMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                  dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, (MaXWDetectEv*)(s->evtPtr) );
	
#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaXWDetectEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* XWEXT */

#if MAP_VLR
   case MAT_GETPASSWD:
     MaUiMatSSInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                  dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                  &cmpCp->lnkId, (MaSSEv *)(s->evtPtr) );

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaSSEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* VLR */

#if (MAP_VLR || MAP_HLR)
   case MAT_USSREQ:
   case MAT_USSNOTIFY:
     MaUiMatSSInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                  dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                  &cmpCp->lnkId, (MaSSEv *)(s->evtPtr) );

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaSSEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* VLR || HLR */

#if MAP_HLR
   case MAT_REGSS:
   case MAT_ERASESS:
   case MAT_ACTVSS:
   case MAT_DACTVSS:
   case MAT_INTERSS:
   case MAT_REGPASSWD:
   case MAT_PROCUSSDATA:
   case MAT_PROCUSSREQ:
     MaUiMatSSInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                  dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                  &cmpCp->lnkId, (MaSSEv *)(s->evtPtr) );

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaSSEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* HLR */
 
#if MAP_MSC
   case MAT_TRACESUBSACTV:
     MaUiMatOAMInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                   dlgCp->spDlgId, &cmpCp->invkId, 
                   cmpCp->oprCode, (MaOAMEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaOAMEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MSC */

#if MAP_MSC
   case MAT_INFSC:
     MaUiMatSMInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                  dlgCp->spDlgId, &cmpCp->invkId, 
                  cmpCp->oprCode, (MaSMEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaSMEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_MSC */

#if MAP_HLR
   case MAT_ROUTINFOSM:
   case MAT_SMDEL:
     MaUiMatSMInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                  dlgCp->spDlgId, &cmpCp->invkId, 
                  cmpCp->oprCode, (MaSMEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaSMEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_HLR */

#if MAP_HLR
   case MAT_SSINV_NOTIFY:
/* ma013.203 : Correction SS_INVOKE_NOTIFY is moved in SS Service */
 MaUiMatSSInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                  dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                  &cmpCp->lnkId, (MaSSEv *)(s->evtPtr) );


#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaSSEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_HLR */


#if MAP_MSC
   case MAT_ALRTSC:
   case MAT_ALRTSCWRSLT:
     MaUiMatSMInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                  dlgCp->spDlgId, &cmpCp->invkId, 
                  cmpCp->oprCode, (MaSMEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaSMEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif  /* MSC */

#if MAP_HLR
   case MAT_NOTSUBPRES:
     MaUiMatSMInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                  dlgCp->spDlgId, &cmpCp->invkId, 
                  cmpCp->oprCode, (MaSMEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaSMEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_HLR */

#if MAP_HLR
   case MAT_UPLOC:
#if MAP_REL99
   case MAT_NOTE_MMEVT:
#endif /* MAP_REL99 */
     MaUiMatLocMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                       dlgCp->spDlgId, &cmpCp->invkId, 
                       cmpCp->oprCode, (MaLocEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaLocEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
     
   case MAT_RESTOREDATA:
     MaUiMatFRMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                      dlgCp->spDlgId, &cmpCp->invkId, 
                      cmpCp->oprCode, (MaFREv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaFREv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_HLR */

#if MAP_VLR
   case MAT_PROVROAMNMB:
   case MAT_SETRPTSTATE:
   case MAT_RMTUSRFREE:
     MaUiMatCallMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                   dlgCp->spDlgId, &cmpCp->invkId, 
                   cmpCp->oprCode, (MaCallEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaCallEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif  /* VLR) */

#if MAP_HLR
   case MAT_REGCCENT:
   case MAT_ERASECCENT:
     MaUiMatSSInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                  dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                  &cmpCp->lnkId, (MaSSEv *)(s->evtPtr) );

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaSSEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;

#endif /* MAP_HLR */
#if MAP_VLR 
   case MAT_FWDCHKSSIND:
     MaUiMatFRMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                      dlgCp->spDlgId, &cmpCp->invkId, 
                      cmpCp->oprCode, (MaFREv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaFREv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* HLR */

#if MAP_MSC
   case MAT_PRE_HO:
   case MAT_PER_HO:
   case MAT_SNDENDSIG:
   case MAT_PROCACCSIG:
   case MAT_FWDACCSIG:
   case MAT_PRE_SUBSHO:
   case MAT_PER_SUBSHO:
     MaUiMatHOMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                      dlgCp->spDlgId, &cmpCp->invkId, 
                      cmpCp->oprCode, (MaHoEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaHoEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
   case MAT_NOTEINTERHO:
     MaUiMatOAMInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                      dlgCp->spDlgId, &cmpCp->invkId, 
                      cmpCp->oprCode, (MaOAMEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaOAMEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
   case MAT_RESCALLHANDL:
   case MAT_PREP_GRPCALL:
   case MAT_PRO_GRPCALLSIG:
   case MAT_FWD_GRPCALLSIG:
   case MAT_SND_GRPCALLENDSIG:
   case MAT_PROV_SIWFS_NMB:
   case MAT_SIWFS_SIGMOD:
   
     MaUiMatCallMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, (MaCallEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaCallEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif  /* MSC */

#if MAP_VLR
  /* Send Identification Request */
  case MAT_SNDID:
     MaUiMatLocMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                       dlgCp->spDlgId, &cmpCp->invkId, 
                       cmpCp->oprCode, (MaLocEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaLocEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
   case MAT_DET_IMSI:
     MaUiMatLocMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                       dlgCp->spDlgId, &cmpCp->invkId, 
                       cmpCp->oprCode, (MaLocEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaLocEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif  /* MAP_VLR */

#if MAP_HLR
   case MAT_ROUTINFO: 
   case MAT_STARPT:  
#if MAP_REL99
   case MAT_IST_ALERT:
#endif /* MAP_REL99 */
     MaUiMatCallMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, (MaCallEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaCallEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
   case MAT_BEGIN_SUBS_ACTV:
     MaUiMatSSInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                   dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                   &cmpCp->lnkId, (MaSSEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaSSEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
   case MAT_PURGE:
     MaUiMatLocMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                       dlgCp->spDlgId, &cmpCp->invkId, 
                       cmpCp->oprCode, (MaLocEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaLocEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_HLR */

#if (MAP_HLR || MAP_MLC)
   case MAT_ANY_INTER:
     MaUiMatSubMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                       dlgCp->spDlgId, &cmpCp->invkId, 
                       cmpCp->oprCode, (MaSubEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaSubEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_HLR || MAP_MLC */

#if (MAP_VLR || MAP_HLR)
   case MAT_SNDPARAM:  
     MaUiMatSubMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                       dlgCp->spDlgId, &cmpCp->invkId, 
                       cmpCp->oprCode, (MaSubEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaSubEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_GSN)
   case MAT_CANCELLOC:
     MaUiMatLocMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                       dlgCp->spDlgId, &cmpCp->invkId, 
                       cmpCp->oprCode, (MaLocEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaLocEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_VLR || MAP_GSN */

#if MAP_HLR
   case MAT_GPRS_UPLOC:
     MaUiMatLocMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, (MaLocEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaLocEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;

   case MAT_GPRS_ROUTINFO:
   case MAT_FAILRPT:
     MaUiMatNwReqPdpCntxtActvInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, (MaPdpActvEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaPdpActvEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_HLR */

#if MAP_GSN
   case MAT_GPRS_NOTEMSPRES:
     MaUiMatNwReqPdpCntxtActvInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, (MaPdpActvEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaPdpActvEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_GSN */

#if (MAP_MSC || MAP_GSN)
   case MAT_FWDSM:
     MaUiMatSMInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                  dlgCp->spDlgId, &cmpCp->invkId, 
                  cmpCp->oprCode, (MaSMEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaSMEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_MSC */

#if (MAP_MSC || MAP_GSN)
   case MAT_MT_FWDSM:
     MaUiMatSMInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                  dlgCp->spDlgId, &cmpCp->invkId, 
                  cmpCp->oprCode, (MaSMEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaSMEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_MSC || MAP_GSN */

#if MAP_HLR
   case MAT_SMRDY:
     MaUiMatSMInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                  dlgCp->spDlgId, &cmpCp->invkId, 
                  cmpCp->oprCode, (MaSMEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaSMEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break; 
#endif /* MAP_HLR */

#if (MAP_VLR || MAP_GSN)
   case MAT_INSSUBSDATA:
   case MAT_DELSUBSDATA:
     MaUiMatSubMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                       dlgCp->spDlgId, &cmpCp->invkId, 
                       cmpCp->oprCode, (MaSubEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaSubEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;

#if (MAP_VLR || (MAP_GSN && MAP_REL5))
   case MAT_PROVSUBSINFO:
     MaUiMatSubMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                       dlgCp->spDlgId, &cmpCp->invkId, 
                       cmpCp->oprCode, (MaSubEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaSubEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* (MAP_VLR || (MAP_GSN && MAP_REL5)) */
#endif /* MAP_VLR || MAP_GSN */

#if MAP_HLR
   case MAT_SNDIMSI:
     MaUiMatOAMInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                   dlgCp->spDlgId, &cmpCp->invkId, 
                   cmpCp->oprCode, (MaOAMEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaOAMEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_HLR */

#if (MAP_VLR || MAP_GSN)
   case MAT_ACTVTRACE:
   case MAT_DACTVTRACE:
     MaUiMatOAMInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                   dlgCp->spDlgId, &cmpCp->invkId, 
                   cmpCp->oprCode, (MaOAMEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaOAMEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;

   case MAT_RESET:
     MaUiMatFRMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                      dlgCp->spDlgId, &cmpCp->invkId, 
                      cmpCp->oprCode, (MaFREv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaFREv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_VLR || MAP_GSN */

#if MAP_REL99
#if MAP_MSC
   case MAT_IST_COMMAND:

     MaUiMatCallMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, (MaCallEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaCallEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#if MAP_REL6
/* Release Resrouces */
   case MAT_REL_RES:

     MaUiMatCallMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, (MaCallEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaCallEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_REL6 */
#endif /* MAP_MSC */

#if MAP_HLR
   case MAT_AUTHFAILRPT:
     MaUiMatAuthMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, (MaAuthEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaAuthEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_HLR */
#endif /* MAP_REL99 */

#if MAP_HLR
   case MAT_AUTHINFO:
     MaUiMatAuthMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, (MaAuthEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaAuthEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_HLR */

#if MAP_VLR
   case MAT_CHKIMEI:
     MaUiMatIMEIMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, (MaIMEIEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaIMEIEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_VLR */

#if (MAP_REL98 || MAP_REL99)
#if MAP_HLR
   case MAT_SENDROUTINFOFORLCS:
     MaUiMatLocServInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, (MaLocServEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaLocServEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_HLR */

#if MAP_MLC
   case MAT_SUBSLOCRPT:
     MaUiMatLocServInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, (MaLocServEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaLocServEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_MLC */
#endif /* MAP_REL98 || MAP_REL99 */

#if (MAP_REL98 || MAP_REL99)
#if (MAP_MSC || MAP_GSN)
#if (MAP_MSC || (MAP_REL4 && MAP_GSN))

   case MAT_PROVSUBSLOC:
     MaUiMatLocServInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, (MaLocServEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaLocServEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif
#endif

#if MAP_HLR
   case MAT_ANY_SUBSDATA_INTER:
   case MAT_ANY_MOD:
   case MAT_NOTE_SUBSDATA_MOD:
     MaUiMatSubMgmtInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                       dlgCp->spDlgId, &cmpCp->invkId, 
                       cmpCp->oprCode, (MaSubEv *)(s->evtPtr));

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
        (Void) maFree((Data *) s->evtPtr, sizeof(MaSubEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

     break;
#endif /* MAP_HLR */
#endif /* (MAP_REL98 || MAP_REL99) */

   default:
     break;
  }
  RETVALUE(ROK);

} /* maSndSSInd  */


/*
*
*       Fun:   maSndSSCfm    
*
*       Desc:  This function  sends the Service Specific confirm
*              to the map user.
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maSndSSCfm 
(
MaSap     *s,           /* MAP SAP pointer */
MaCmpCp   *cmpCp,       /* Compnenet control point */
MaPrvErr  *prvErr,      /* Provider error  */
MaUsrErr  *usrErr       /* User error */
)
#else
PUBLIC S16 maSndSSCfm (s, cmpCp, prvErr, usrErr)
MaSap     *s;           /* MAP SAP pointer */
MaCmpCp   *cmpCp;       /* Component Control point */
MaPrvErr  *prvErr;      /* Provider error  */
MaUsrErr  *usrErr;      /* User error */
#endif
{
  MaDlgCp  *dlgCp;

  TRC2(maSndSSCfm)

  dlgCp = s->curDlgCp;

  /* Update the Stat. */
  if(cmpCp == (MaCmpCp *)NULLP)
  {
     RETVALUE(ROK);
  }
  if((usrErr->pres !=  TRUE) && (prvErr->pres != TRUE))
  {
     maUpdatRxSts(s,cmpCp->oprCode, MAT_SS_RSP);
  }


  switch (cmpCp->oprCode)
  {
#ifdef XWEXT /* xuxingzhou: xinwei */
   case MAT_PAGING_DETECT:
   {
      MaXWDetectEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaXWDetectEv *) maAlloc(sizeof(MaXWDetectEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event, oprCode(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaXWDetectEv *)&(maGlobDecEv->detectEv);
       cmZero((Data *)evt,sizeof(MaXWDetectEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaXWDetectEv *) s->evtPtr;
      }

      MaUiMatXWMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                   dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                   usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaXWDetectEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */
    }
   break;
#endif

#if MAP_HLR
   case MAT_GETPASSWD:
    {
      MaSSEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSSEv *) maAlloc(sizeof(MaSSEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event, oprCode(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
       cmZero((Data *)evt,sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaSSEv *) s->evtPtr;
      }

      MaUiMatSSCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                   dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                   usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaSSEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_HLR */

#if MAP_VLR
   case MAT_REGSS:
   case MAT_ERASESS:
   case MAT_ACTVSS:
   case MAT_DACTVSS:
   case MAT_INTERSS:
   case MAT_REGPASSWD:
    {
      MaSSEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSSEv *) maAlloc(sizeof(MaSSEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
       cmZero((Data *)evt,sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaSSEv *) s->evtPtr;
      }

      MaUiMatSSCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                   dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                   usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaSSEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_VLR */

#if MAP_HLR
   case MAT_USSREQ:
   case MAT_USSNOTIFY:
    {
      MaSSEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSSEv *) maAlloc(sizeof(MaSSEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
       cmZero((Data *)evt,sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaSSEv *) s->evtPtr;
      }

      MaUiMatSSCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                   dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                   usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaSSEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_HLR */

#if (MAP_VLR || MAP_HLR)
   case MAT_PROCUSSDATA:
   case MAT_PROCUSSREQ:
    {
      MaSSEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSSEv *) maAlloc(sizeof(MaSSEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
       cmZero((Data *)evt,sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaSSEv *) s->evtPtr;
      }

      MaUiMatSSCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                   dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                   usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaSSEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* VLR || HLR */

#if (MAP_MSC || MAP_HLR)
   case MAT_SSINV_NOTIFY:
    {
/* ma013.203 : Correction SS_INVOKE_NOTIFY is moved in SS Service */
      MaSSEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSSEv *) maAlloc(sizeof(MaSSEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
       cmZero((Data *)evt,sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaSSEv *) s->evtPtr;
      }

  MaUiMatSSCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                   dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                   usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaSSEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break; 
#endif /* MAP_MSC || MAP_HLR */

#if MAP_HLR
   case MAT_INFSC:
    {
      MaSMEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSMEv *) maAlloc(sizeof(MaSMEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSMEv *)&(maGlobDecEv->smEv);
       cmZero((Data *)evt,sizeof(MaSMEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaSMEv *) s->evtPtr;
      }

      MaUiMatSMCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                   dlgCp->spDlgId, &cmpCp->invkId, 
                   cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaSMEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_HLR */


#if (MAP_MSC || MAP_HLR)
   case MAT_ROUTINFO:
    {
      MaCallEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaCallEv *) maAlloc(sizeof(MaCallEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
       cmZero((Data *)evt,sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaCallEv *) s->evtPtr;
      }

      MaUiMatCallMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                         dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                         usrErr, prvErr,evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaCallEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_MSC || MSC_HLR */

#if MAP_MSC
#if MAP_REL99
   case MAT_IST_ALERT:
    {
      MaCallEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaCallEv *) maAlloc(sizeof(MaCallEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
       cmZero((Data *)evt,sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaCallEv *) s->evtPtr;
      }

      MaUiMatCallMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                         dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                         usrErr, prvErr,evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaCallEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_REL99 */

   case MAT_ROUTINFOSM:
   case MAT_SMDEL:
    {
      MaSMEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
         /*ma029.105-deletion, remove double memory allocation*/
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSMEv *) maAlloc(sizeof(MaSMEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSMEv *)&(maGlobDecEv->smEv);
       cmZero((Data *)evt,sizeof(MaSMEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaSMEv *) s->evtPtr;
      }

      MaUiMatSMCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                   dlgCp->spDlgId, &cmpCp->invkId, 
                   cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaSMEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_MSC */

#if MAP_HLR
   case MAT_ALRTSC:
    {
      MaSMEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
         /*ma029.105-deletion, remove double memory allocation*/
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSMEv *) maAlloc(sizeof(MaSMEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSMEv *)&(maGlobDecEv->smEv);
       cmZero((Data *)evt,sizeof(MaSMEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaSMEv *) s->evtPtr;
      }

      MaUiMatSMCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                   dlgCp->spDlgId, &cmpCp->invkId, 
                   cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaSMEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif  /* HLR */

#if MAP_VLR
   case MAT_REGCCENT:
   case MAT_ERASECCENT:
    {
      MaSSEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSSEv *) maAlloc(sizeof(MaSSEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
       cmZero((Data *)evt,sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaSSEv *) s->evtPtr;
      }

      MaUiMatSSCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                   dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                   usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaSSEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_VLR */

#if MAP_HLR
   case MAT_SETRPTSTATE:
   case MAT_RMTUSRFREE:
    {
      MaCallEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaCallEv *) maAlloc(sizeof(MaCallEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
       cmZero((Data *)evt,sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaCallEv *) s->evtPtr;
      }

      MaUiMatCallMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                         dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                         usrErr, prvErr,evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaCallEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_HLR */

#if MAP_VLR
   case MAT_UPLOC:
    {
      MaLocEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaLocEv *) maAlloc(sizeof(MaLocEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocEv *)&(maGlobDecEv->locEv);
       cmZero((Data *)evt,sizeof(MaLocEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaLocEv *) s->evtPtr;
      }

      MaUiMatLocMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaLocEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif  /* VLR */

#if MAP_REL99
#if (MAP_VLR || MAP_GSN)
   case MAT_NOTE_MMEVT:
    {
      MaLocEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaLocEv *) maAlloc(sizeof(MaLocEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocEv *)&(maGlobDecEv->locEv);
       cmZero((Data *)evt,sizeof(MaLocEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaLocEv *) s->evtPtr;
      }

      MaUiMatLocMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaLocEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif  /* VLR_GSN */
#endif /* MAP_REL99 */

#if MAP_MSC
   case MAT_PRE_HO:
   case MAT_PER_HO:
   case MAT_SNDENDSIG:
   case MAT_PROCACCSIG:
   case MAT_FWDACCSIG:
   case MAT_PRE_SUBSHO:
   case MAT_PER_SUBSHO:
    {
      MaHoEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaHoEv *) maAlloc(sizeof(MaHoEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaHoEv *)&(maGlobDecEv->hoEv);
       cmZero((Data *)evt,sizeof(MaHoEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaHoEv *) s->evtPtr;
      }

      MaUiMatHOMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                       dlgCp->spDlgId, &cmpCp->invkId, 
                       cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaHoEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
   case MAT_RESCALLHANDL:
   case MAT_PRO_GRPCALLSIG:
   case MAT_FWD_GRPCALLSIG:
   case MAT_SND_GRPCALLENDSIG:
   case MAT_PROV_SIWFS_NMB:
   case MAT_SIWFS_SIGMOD:
   case MAT_PREP_GRPCALL:

    {
      MaCallEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaCallEv *) maAlloc(sizeof(MaCallEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
       cmZero((Data *)evt,sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaCallEv *) s->evtPtr;
      }

      MaUiMatCallMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                   dlgCp->spDlgId, &cmpCp->invkId, 
                   cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaCallEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif  /* MSC */

#if MAP_VLR
   case MAT_STARPT:
    {
      MaCallEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaCallEv *) maAlloc(sizeof(MaCallEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
       cmZero((Data *)evt,sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaCallEv *) s->evtPtr;
      }

      MaUiMatCallMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                   dlgCp->spDlgId, &cmpCp->invkId, 
                   cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaCallEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;

  /* Send Identification Request */
  case MAT_SNDID:
    {
      MaLocEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaLocEv *) maAlloc(sizeof(MaLocEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocEv *)&(maGlobDecEv->locEv);
       cmZero((Data *)evt,sizeof(MaLocEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaLocEv *) s->evtPtr;
      }

      MaUiMatLocMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaLocEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;

   case MAT_RESTOREDATA: 
    {
      MaFREv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaFREv *) maAlloc(sizeof(MaFREv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaFREv *)&(maGlobDecEv->frEv);
       cmZero((Data *)evt,sizeof(MaFREv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaFREv *) s->evtPtr;
      }

      MaUiMatFRMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                       dlgCp->spDlgId, &cmpCp->invkId, 
                       cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaFREv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif  /* MAP_VLR */

#if  (MAP_VLR || MAP_GSN)
   case MAT_SNDPARAM: 
    {
      MaSubEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSubEv *) maAlloc(sizeof(MaSubEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSubEv *)&(maGlobDecEv->subEv);
       cmZero((Data *)evt,sizeof(MaSubEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaSubEv *) s->evtPtr;
      }

      MaUiMatSubMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaSubEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_VLR || MAP_GSN */

#if MAP_HLR
   case MAT_ANY_INTER:
    {
      MaSubEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSubEv *) maAlloc(sizeof(MaSubEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSubEv *)&(maGlobDecEv->subEv);
       cmZero((Data *)evt,sizeof(MaSubEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaSubEv *) s->evtPtr;
      }

      MaUiMatSubMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaSubEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;

   case MAT_PROVROAMNMB:
    {
      MaCallEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaCallEv *) maAlloc(sizeof(MaCallEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
       cmZero((Data *)evt,sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaCallEv *) s->evtPtr;
      }

      MaUiMatCallMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaCallEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_HLR */

#if MAP_HLR
   case MAT_CANCELLOC:
    {
      MaLocEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaLocEv *) maAlloc(sizeof(MaLocEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocEv *)&(maGlobDecEv->locEv);
       cmZero((Data *)evt,sizeof(MaLocEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaLocEv *) s->evtPtr;
      }

      MaUiMatLocMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaLocEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_HLR */

#if (MAP_VLR || MAP_GSN)
   case MAT_PURGE:
    {
      MaLocEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaLocEv *) maAlloc(sizeof(MaLocEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocEv *)&(maGlobDecEv->locEv);
       cmZero((Data *)evt,sizeof(MaLocEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaLocEv *) s->evtPtr;
      }

      MaUiMatLocMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaLocEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }

    break;
#endif /* MAP_VLR || MAP_GSN */

#if MAP_GSN
   case MAT_GPRS_UPLOC:
    {
      MaLocEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaLocEv *) maAlloc(sizeof(MaLocEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocEv *)&(maGlobDecEv->locEv);
       cmZero((Data *)evt,sizeof(MaLocEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaLocEv *) s->evtPtr;
      }

      MaUiMatLocMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaLocEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
   case MAT_GPRS_ROUTINFO:
   case MAT_FAILRPT:
    {
      MaPdpActvEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaPdpActvEv *) maAlloc(sizeof(MaPdpActvEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaPdpActvEv *)&(maGlobDecEv->pdpActvEv);
       cmZero((Data *)evt,sizeof(MaPdpActvEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaPdpActvEv *) s->evtPtr;
      }

      MaUiMatNwReqPdpCntxtActvCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaPdpActvEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
     break;
#endif  /* MAP_GSN */

#if MAP_HLR
   case MAT_GPRS_NOTEMSPRES:
    {
      MaPdpActvEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaPdpActvEv *) maAlloc(sizeof(MaPdpActvEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaPdpActvEv *)&(maGlobDecEv->pdpActvEv);
       cmZero((Data *)evt,sizeof(MaPdpActvEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaPdpActvEv *) s->evtPtr;
      }

      MaUiMatNwReqPdpCntxtActvCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
            (Void) maFree((Data *)evt, sizeof(MaPdpActvEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
     break;
#endif /* MAP_HLR */

#if (MAP_MSC || MAP_GSN)
   case MAT_FWDSM:
    {
      MaSMEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSMEv *) maAlloc(sizeof(MaSMEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSMEv *)&(maGlobDecEv->smEv);
       cmZero((Data *)evt,sizeof(MaSMEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaSMEv *) s->evtPtr;
      }

      MaUiMatSMCfm(&s->maPstMU, s->suId, dlgCp->suDlgId,
                   dlgCp->spDlgId, &cmpCp->invkId,
               cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaSMEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_MSC || MAP_GSN */

#if MAP_MSC
   case MAT_MT_FWDSM:
    {
      MaSMEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSMEv *) maAlloc(sizeof(MaSMEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSMEv *)&(maGlobDecEv->smEv);
       cmZero((Data *)evt,sizeof(MaSMEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaSMEv *) s->evtPtr;
      }

      MaUiMatSMCfm(&s->maPstMU, s->suId, dlgCp->suDlgId,
                   dlgCp->spDlgId, &cmpCp->invkId,
               cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaSMEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_MSC */

#if (MAP_VLR || MAP_GSN)
   case MAT_SMRDY:
    {
      MaSMEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSMEv *) maAlloc(sizeof(MaSMEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSMEv *)&(maGlobDecEv->smEv);
       cmZero((Data *)evt,sizeof(MaSMEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaSMEv *) s->evtPtr;
      }

      MaUiMatSMCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                   dlgCp->spDlgId, &cmpCp->invkId, 
                   cmpCp->oprCode, usrErr, prvErr,evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaSMEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break; 
     break; 
#endif /* MAP_VLR || MAP_GSN */

#if MAP_HLR
   case MAT_INSSUBSDATA:
   case MAT_DELSUBSDATA:
    {
      MaSubEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSubEv *) maAlloc(sizeof(MaSubEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSubEv *)&(maGlobDecEv->subEv);
       cmZero((Data *)evt,sizeof(MaSubEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaSubEv *) s->evtPtr;
      }

      MaUiMatSubMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaSubEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_HLR */

#if MAP_HLR
   case MAT_PROVSUBSINFO:
    {
      MaSubEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSubEv *) maAlloc(sizeof(MaSubEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSubEv *)&(maGlobDecEv->subEv);
       cmZero((Data *)evt,sizeof(MaSubEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaSubEv *) s->evtPtr;
      }

      MaUiMatSubMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaSubEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;

   case MAT_ACTVTRACE:  
   case MAT_DACTVTRACE: 
    {
      MaOAMEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaOAMEv *) maAlloc(sizeof(MaOAMEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaOAMEv *)&(maGlobDecEv->oamEv);
       cmZero((Data *)evt,sizeof(MaOAMEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaOAMEv *) s->evtPtr;
      }

      MaUiMatOAMCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                    dlgCp->spDlgId, &cmpCp->invkId, 
                    cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaOAMEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;

#endif /* MAP_HLR */

#if MAP_VLR
   case MAT_SNDIMSI:
    {
      MaOAMEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaOAMEv *) maAlloc(sizeof(MaOAMEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaOAMEv *)&(maGlobDecEv->oamEv);
       cmZero((Data *)evt,sizeof(MaOAMEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaOAMEv *) s->evtPtr;
      }

      MaUiMatOAMCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                    dlgCp->spDlgId, &cmpCp->invkId, 
                    cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaOAMEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_VLR */

#if MAP_HLR
   case MAT_RESET:
     /* No return result */
     break;
#endif /* MAP_HLR */

#if (MAP_VLR || MAP_GSN)
   case MAT_AUTHINFO: 
    {
      MaAuthEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaAuthEv *) maAlloc(sizeof(MaAuthEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaAuthEv *)&(maGlobDecEv->authEv);
       cmZero((Data *)evt,sizeof(MaAuthEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaAuthEv *) s->evtPtr;
      }

      MaUiMatAuthMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                         dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                         usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaAuthEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_VLR || MAP_GSN */

#if (MAP_MSC || MAP_GSN)
   case MAT_CHKIMEI:
    {
      MaIMEIEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaIMEIEv *) maAlloc(sizeof(MaIMEIEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaIMEIEv *)&(maGlobDecEv->imeiEv);
       cmZero((Data *)evt,sizeof(MaIMEIEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaIMEIEv *) s->evtPtr;
      }

      MaUiMatIMEIMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                         dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode,
                         usrErr, prvErr,  evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaIMEIEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_MSC || MAP_GSN */

#if (MAP_REL98 || MAP_REL99)
#if MAP_MLC
   case MAT_SENDROUTINFOFORLCS:
    {
      MaLocServEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaLocServEv *) maAlloc(sizeof(MaLocServEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocServEv *)&(maGlobDecEv->locServEv);
       cmZero((Data *)evt,sizeof(MaLocServEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaLocServEv *) s->evtPtr;
      }

      MaUiMatLocServCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaLocServEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
     break;

   case MAT_PROVSUBSLOC:
    {
      MaLocServEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaLocServEv *) maAlloc(sizeof(MaLocServEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocServEv *)&(maGlobDecEv->locServEv);
       cmZero((Data *)evt,sizeof(MaLocServEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaLocServEv *) s->evtPtr;
      }

      MaUiMatLocServCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaLocServEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
     break;
#endif /* MAP_MLC */
#endif /* MAP_REL98 || MAP_REL99 */

#if (MAP_REL98 || MAP_REL99)
#if (MAP_MSC || MAP_GSN)
#if (MAP_MSC || (MAP_REL4 && MAP_GSN))

   case MAT_SUBSLOCRPT:
    {
      MaLocServEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaLocServEv *) maAlloc(sizeof(MaLocServEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocServEv *)&(maGlobDecEv->locServEv);
       cmZero((Data *)evt,sizeof(MaLocServEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaLocServEv *) s->evtPtr;
      }

      MaUiMatLocServCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaLocServEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
     break;
#endif
#endif

#if MAP_HLR
   case MAT_IST_COMMAND:

    {
      MaCallEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaCallEv *) maAlloc(sizeof(MaCallEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
       cmZero((Data *)evt,sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaCallEv *) s->evtPtr;
      }

      MaUiMatCallMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                         dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                         usrErr, prvErr,evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaCallEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_HLR */

#if MAP_MSC
#if MAP_REL6
   case MAT_REL_RES:

    {
      MaCallEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaCallEv *) maAlloc(sizeof(MaCallEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
       cmZero((Data *)evt,sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaCallEv *) s->evtPtr;
      }

      MaUiMatCallMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                         dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                         usrErr, prvErr,evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaCallEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
    break;
#endif /* MAP_REL6 */
#endif /* MAP_MSC */

#if (MAP_VLR || MAP_GSN)
   case MAT_AUTHFAILRPT:
    {
      MaAuthEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaAuthEv *) maAlloc(sizeof(MaAuthEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaAuthEv *)&(maGlobDecEv->authEv);
       cmZero((Data *)evt,sizeof(MaAuthEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaAuthEv *) s->evtPtr;
      }

      MaUiMatAuthMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                         dlgCp->spDlgId, &cmpCp->invkId, cmpCp->oprCode, 
                         usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaAuthEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
     break;
#endif /* MAP_VLR || MAP_GSN */

#if MAP_HLR
   case MAT_ANY_SUBSDATA_INTER:
   case MAT_ANY_MOD:
   case MAT_NOTE_SUBSDATA_MOD:
    {
      MaSubEv *evt;

      if((usrErr->pres == TRUE) || (prvErr->pres == TRUE))
      {
#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSubEv *) maAlloc(sizeof(MaSubEv))) == NULLP)
         {
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "maSndSSCfm() failed, fail to allocate memory for operation event(%d).\n", cmpCp->oprCode));
            RETVALUE(RFAILED);
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSubEv *)&(maGlobDecEv->subEv);
       cmZero((Data *)evt,sizeof(MaSubEv));
#endif  /* MA_STATIC_EVT_STRUCT */
      }
      else
      {
         evt = (MaSubEv *) s->evtPtr;
      }

      MaUiMatSubMgmtCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                        dlgCp->spDlgId, &cmpCp->invkId, 
                        cmpCp->oprCode, usrErr, prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
     if(s->maPstMU.selector != MALWLCSEL)
     {
         (Void) maFree((Data *)evt, sizeof(MaSubEv));
     }
#endif  /* MA_STATIC_EVT_STRUCT */

    }
     break;
#endif /* MAP_HLR */
#endif /* (MAP_REL98 || MAP_REL99) */

   default:
     break;
  }

  RETVALUE(ROK);

} /* maSndSSCfm  */



/*
*
*       Fun:   maChkRcvdErr    
*
*       Desc:  This function checks the err.code for a given operation code.  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkRcvdErr 
(
MaSap *s,           /* Pointer To the Sap */
U8    oprCode,      /* Operation Code     */
U8    errCode,      /* Error Code         */
U8    maVer         /* Map Version        */
)
#else
PUBLIC S16 maChkRcvdErr (s,oprCode, errCode, maVer)
MaSap *s;           /* Pointer To the Sap */
U8    oprCode;      /* Operation Code */
U8    errCode;      /* Error Code     */
U8    maVer;        /* Map Version    */
#endif
{

  TRC2(maChkRcvdErr)


  switch (oprCode)
  {
#ifdef XWEXT /* XUXINGZHOU: xinwei management */
   case MAT_PAGING_DETECT:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
          break;  
     }
	 s->sts.detectReRx++;
	 break;
#endif

#if (MAP_VLR || MAP_HLR)
   case MAT_REGSS:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_BEAR_NOT_PROV:
        case MAT_TELE_NOT_PROV:
        case MAT_ILLEGAL_SS_OPR:
        case MAT_SS_STATUS_ERR:
        case MAT_SS_INCOMP_ERR:
          break;  
        case MAT_UNK_SUBS:
        case MAT_SS_SUBSVIOL_ERR:
          if (maVer !=  LMA_VER1)
          {
             RETVALUE(STU_UNREC_ERROR);
          }
          break;
        case MAT_CALL_BARRED:
          if (maVer == LMA_VER1)
          {
             RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.regSSReRx++;
     break;

   case MAT_ERASESS:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_ILLEGAL_SS_OPR:
        case MAT_SS_STATUS_ERR:
           break; 
        case MAT_SS_INCOMP_ERR:
           if (maVer !=  LMA_VER2)
           {
              RETVALUE(STU_UNREC_ERROR);
           }
           break;  
        case MAT_SS_SUBSVIOL_ERR:
        case MAT_UNK_SUBS:
          if (maVer != LMA_VER1)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
        case MAT_BEAR_NOT_PROV:
        case MAT_TELE_NOT_PROV:
        case MAT_DATA_MISSING:
        case MAT_CALL_BARRED:
          if (maVer == LMA_VER1)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.eraseSSReRx++;
     break;
   case MAT_ACTVSS:
     switch(errCode)
     {
        default:
            RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_ILLEGAL_SS_OPR:
        case MAT_SS_STATUS_ERR:
        case MAT_SS_SUBSVIOL_ERR:
        case MAT_SS_INCOMP_ERR:
        case MAT_NEG_PWCHK:
          break;  
        case MAT_UNK_SUBS:
          if (maVer != LMA_VER1)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
        case MAT_BEAR_NOT_PROV:
        case MAT_TELE_NOT_PROV:
        case MAT_DATA_MISSING:
        case MAT_CALL_BARRED:
        case MAT_NMB_PW_VIOL:
          if (maVer == LMA_VER1)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.actvSSReRx++;
     break;
   case MAT_DACTVSS:
     switch(errCode)
     {
        default:
            RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_ILLEGAL_SS_OPR:
        case MAT_SS_STATUS_ERR:
        case MAT_SS_SUBSVIOL_ERR:
        case MAT_NEG_PWCHK:
           break;  
        case MAT_UNK_SUBS:
           if(maVer != LMA_VER1)
           {
              RETVALUE(STU_UNREC_ERROR);
           }
          break;
        case MAT_BEAR_NOT_PROV:
        case MAT_TELE_NOT_PROV:
        case MAT_DATA_MISSING:
        case MAT_CALL_BARRED:
        case MAT_NMB_PW_VIOL:
           if (maVer == LMA_VER1)
           {
              RETVALUE(STU_UNREC_ERROR);
           }
          break;
     }
     s->sts.dactvSSReRx++;
     break;
   case MAT_INTERSS:
     switch(errCode)
     {
        default:
            RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_ILLEGAL_SS_OPR:
        case MAT_SS_NOT_AVAIL:
           break;
        case MAT_UNK_SUBS:
           if(maVer != LMA_VER1)
           {
              RETVALUE(STU_UNREC_ERROR);
           }
          break;
        case MAT_BEAR_NOT_PROV:
        case MAT_TELE_NOT_PROV:
        case MAT_DATA_MISSING:
        case MAT_CALL_BARRED:
        case MAT_NMB_PW_VIOL:
           if (maVer == LMA_VER1)
           {
              RETVALUE(STU_UNREC_ERROR);
           }
          break;
     }
     s->sts.interSSReRx++;
     break;
   case MAT_REGPASSWD:
     switch(errCode)
     {
        default:
            RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_SS_SUBSVIOL_ERR:
        case MAT_PASSWD_REG_ERR:
        case MAT_NEG_PWCHK:
          break;  
        case MAT_DATA_MISSING:
        case MAT_CALL_BARRED:
        case MAT_NMB_PW_VIOL:
          if (maVer == LMA_VER1)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.regPasswdReRx++;
     break;
   case MAT_GETPASSWD:
     s->sts.getPasswdReRx++;
     break;
   case MAT_PROCUSSDATA:
     switch(errCode)
     {
        default:
            RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
          break;
     }
     s->sts.procUSSDatReRx++;
     break;
   case MAT_PROCUSSREQ:
     switch(errCode)
     {
        default:
            RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_DATA_MISSING:
        case MAT_CALL_BARRED:
        case MAT_UNK_ALPHABET:
          break;
     }
     s->sts.procUSSReRx++;
     break;
   case MAT_USSREQ:
     switch(errCode)
     {
        default:
            RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_DATA_MISSING:
        case MAT_ILLEGAL_SUBS:
        case MAT_ILLEGAL_EQP:
        case MAT_ABSENT_SUBS:
        case MAT_USSD_BUSY:
        case MAT_UNK_ALPHABET:
          break;
     }
     s->sts.ussReRx++;
     break;
   case MAT_USSNOTIFY:
     switch(errCode)
     {
        default:
           MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
           "maChkRcvdErr() failed, invaild error code(%d), oprCode(%d).\n", errCode, oprCode));
           RETVALUE(RFAILED);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_DATA_MISSING:
        case MAT_ILLEGAL_SUBS:
        case MAT_ILLEGAL_EQP:
        case MAT_ABSENT_SUBS:
        case MAT_USSD_BUSY:
        case MAT_UNK_ALPHABET:
          break;
     }
     s->sts.ussNotReRx++;
     break;
#endif /* VLR || HLR */

#if MAP_MSC
   case MAT_DET_IMSI:
     break;
   case MAT_TRACESUBSACTV:
     break;
#endif   /* MSC */

#if (MAP_MSC || MAP_HLR)
   case MAT_ROUTINFO:
     switch(errCode)
     {
        default:
           RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_FACILITY_NOT_SUPP:
        case MAT_UNK_SUBS:
        case MAT_BEAR_NOT_PROV:
        case MAT_TELE_NOT_PROV:
        case MAT_ABSENT_SUBS:
        case MAT_CALL_BARRED:
        case MAT_FWD_VIOL:
           break;
        case MAT_NMB_CHNGD:
        case MAT_CUG_REJECT:
           if (maVer == LMA_VER1)
           {
              RETVALUE(STU_UNREC_ERROR);
           }
           break;
        case MAT_OR_NOTALLOWED:
        case MAT_NOSUBS_REPLY:
        case MAT_BUSY_SUBS:
           if (maVer != LMA_VER2P)
           {
              RETVALUE(STU_UNREC_ERROR);
           }
           break;
     }
     s->sts.routInfoReRx++;
     break;
   case MAT_ROUTINFOSM:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_FACILITY_NOT_SUPP:
        case MAT_UNK_SUBS:
        case MAT_TELE_NOT_PROV:
        case MAT_CALL_BARRED:
           break;
        case MAT_ABSENT_SUBS:
        if (maVer > LMA_VER2)
        {
           RETVALUE(STU_UNREC_ERROR);
        }
        break;
        case MAT_ABS_SUBS_SM:
            if (maVer != LMA_VER2P)
        {
           RETVALUE(STU_UNREC_ERROR);
        }
        break;
     }
     s->sts.routInfoSMReRx++;
     break;
   case MAT_SMDEL:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
        case MAT_MSG_WAIT_LISTFULL:
          break;
        case MAT_DATA_MISSING:
            if (maVer == LMA_VER1)
        {
            RETVALUE(STU_UNREC_ERROR);
        }
        break;
     }
     s->sts.smDelReRx++;
     break;
   case MAT_ALRTSC:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
          break;
     }
     s->sts.alrtSCReRx++;
     break;
   case MAT_INFSC:
     break;

  /* SS Invocation Notify */
  case MAT_SSINV_NOTIFY:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
          break;
     }
     s->sts.ssInvNotReRx++;
     break;

#if MAP_REL99

  case MAT_IST_ALERT:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_UNX_DATA_VALUE:
        case MAT_RSRC_LMT:
        case MAT_UNK_SUBS:
        case MAT_SYS_FAILURE:
        case MAT_FACILITY_NOT_SUPP:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.istAlrtReRx++;
     break;
  case MAT_IST_COMMAND:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_UNX_DATA_VALUE:
        case MAT_RSRC_LMT:
        case MAT_UNK_SUBS:
        case MAT_SYS_FAILURE:
        case MAT_FACILITY_NOT_SUPP:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.istCmdReRx++;
     break;

#endif /* MAP_REL99 */
#endif  /* MSC || HLR */

#if MAP_MSC
#if MAP_REL6
  case MAT_REL_RES:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_UNX_DATA_VALUE:
        case MAT_SYS_FAILURE:
          break;
     }
     s->sts.relResReRx++;
     break;
#endif /* MAP_REL6 */
#endif /* MAP_MSC */

#if (MAP_VLR || MAP_HLR)
   case MAT_UPLOC:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
        case MAT_ROAM_NOTALLOWED:
               break;
        case MAT_DATA_MISSING:
           if (maVer == LMA_VER1)
           {
              RETVALUE(STU_UNREC_ERROR);
           }
           break;
     }
     s->sts.upLocReRx++;
     break;
#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_SNDPARAM:
     switch(errCode)
     {
        default:
           RETVALUE(STU_UNREC_ERROR);
        case MAT_UNK_SUBS:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNID_SUBS:
           break;
     }
     s->sts.sndParamReRx++;
     break;
#if (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5))
  /* Provide Subscriber Info */
  case MAT_PROVSUBSINFO:
     switch(errCode)
     {
        default:
           RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
           break;
     }
     s->sts.provSubsInfoReRx++;
     break;
#endif /* (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5)) */

#if MAP_REL99

  /* Note MM event */
  case MAT_NOTE_MMEVT:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
        case MAT_MMEVT_NOTSUPPORTED:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.notMmEvReRx++;
     break;

#endif /* MAP_REL99 */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR)
   case MAT_RESTOREDATA:
     switch(errCode)
     {
        default:
           RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
        case MAT_SYS_FAILURE:
           break;
     }
     s->sts.restoreReRx++;
     break;
   case MAT_SNDIMSI:
     switch(errCode)
     {
        default:
           RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
           break;
     }
     s->sts.sndIMSIReRx++;
     break;

   case MAT_PROVROAMNMB:
     switch(errCode)
     {
        default:
           RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_SYS_FAILURE:
        case MAT_FACILITY_NOT_SUPP:
        case MAT_ABSENT_SUBS:
        case MAT_NO_ROAM_AVAIL:
           break;
        case MAT_OR_NOTALLOWED:
               if (maVer != LMA_VER2P)
           {
              RETVALUE(STU_UNREC_ERROR);
           }
           break;
     }
     s->sts.provRoamNmbReRx++;
     break;

  /* Set Reporting State */
  case MAT_SETRPTSTATE:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNID_SUBS:
        case MAT_UNX_DATA_VALUE:
        case MAT_DATA_MISSING:
        case MAT_RSRC_LMT    :
        case MAT_FACILITY_NOT_SUPP:
          break;
     }
     s->sts.setRptStateReRx++;
     break;
  /* Status Report */
  case MAT_STARPT:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_UNK_SUBS:
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_DATA_MISSING:
          break;
     }
     s->sts.staRptReRx++;
     break;
  /* Remote User Free */
  case MAT_RMTUSRFREE:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_INCMPTBL_TERM:
        case MAT_BUSY_SUBS:
        case MAT_ABSENT_SUBS:
        case MAT_SYS_FAILURE:
          break;
     }
     s->sts.rmtUsrFreeReRx++;
     break;

#endif  /* (VLR) || (HLR) */

#if (MAP_VLR || MAP_HLR)
  /* Register CC Entry */
  case MAT_REGCCENT:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_CALL_BARRED:
        case MAT_ILLEGAL_SS_OPR:
        case MAT_SS_STATUS_ERR:
        case MAT_SS_INCOMP_ERR:
        case MAT_SHRTTERM_DENIAL:
        case MAT_LONGTERM_DENIAL:
        case MAT_FACILITY_NOT_SUPP:
          break;
     }
     s->sts.regCcEntReRx++;
     break;
  /* Erase CC Entry */
  case MAT_ERASECCENT:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_CALL_BARRED:
        case MAT_ILLEGAL_SS_OPR:
        case MAT_SS_STATUS_ERR:
          break;
     }
     s->sts.eraseCcEntReRx++;
     break;

#endif /* MAP_VLR || MAP_HLR */

#if MAP_MSC
   case MAT_PRE_HO:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_NO_HONMB_AVAIL:
#if MAP_REL99
        case MAT_TARG_COUT_GCAREA:
#endif /* MAP_REL99 */
          break;
     }
     s->sts.preHoReRx++;
     break;
   case MAT_PER_HO:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_BASE_STAT:
        case MAT_INV_TARG_BSTAT:
        case MAT_NO_RADIO_RSRS_AVAIL:
        case MAT_NO_HONMB_AVAIL:
          break;
     }
     s->sts.perHoReRx++;
     break;
   case MAT_SNDENDSIG:
   case MAT_PROCACCSIG:
   case MAT_FWDACCSIG:
     break;
   case MAT_PRE_SUBSHO:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_MSC:
        case MAT_SUBS_HO_FAIL:
          break;
     }
     s->sts.preSubHoReRx++;
     break;
   case MAT_PER_SUBSHO:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_MSC:
        case MAT_SUBS_HO_FAIL:
        case MAT_UNK_BASE_STAT:
        case MAT_INV_TARG_BSTAT:
          break;
     }
     s->sts.perSubHoReRx++;
     break;
   case MAT_NOTEINTERHO:
     break;
  /* Resume Call Handling */
  case MAT_RESCALLHANDL:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_FWD_FAIL:
        case MAT_OR_NOTALLOWED:
        case MAT_UNX_DATA_VALUE:
#if (MAP_REL98 || MAP_REL99)
        case MAT_DATA_MISSING:
#endif /* MAP_REL98 || MAP_REL99 */
          break;
     }
     s->sts.resCallHandlReRx++;
     break;
  /* Prepare Group Call */
  case MAT_PREP_GRPCALL:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_NOGRPCALLNMB_AVAIL:
        case MAT_UNX_DATA_VALUE:
          break;
     }
     s->sts.prepGrpCallReRx++;
     break;
  /* Process Group Call Signalling */
  case MAT_PRO_GRPCALLSIG:
     s->sts.proGrpCallReRx++;
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
     }
     break;
  /* Forward Group Call Signalling */
  case MAT_FWD_GRPCALLSIG:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
     }
     break;
  /* Send Group Call End Signal */
  case MAT_SND_GRPCALLENDSIG:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
     }
     break;
  /* Provide SIWFS Number */
  case MAT_PROV_SIWFS_NMB:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_RSRC_LMT:
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
          break;
     }
     s->sts.provSiwfsNmbReRx++;
     break;
  /* SIWFS Signalling Modify */
  case MAT_SIWFS_SIGMOD:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_RSRC_LMT:
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
          break;
     }
     s->sts.siwfsSigModReRx++;
     break;
#endif  /* MSC */

#if MAP_VLR
  /* Send Identification Request */
  case MAT_SNDID:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNID_SUBS:
          break;
     }
     s->sts.sndIdReRx++;
     break;
#endif  /* MAP_VLR */

#if (MAP_HLR || MAP_MLC)
  /* Any Time Interrogation */
  case MAT_ANY_INTER:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_ATI_NOTALLOWED:
        case MAT_UNK_SUBS:
        case MAT_DATA_MISSING:
          break;
     }
     s->sts.anyInterReRx++;
     break;
#endif  /* MAP_VLR || MAP_MLC */

#if (MAP_HLR || MAP_GSN)
  /* Update GPRS Location */
  case MAT_GPRS_UPLOC:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
        case MAT_ROAM_NOTALLOWED:
          break;
     }
     s->sts.gprsUpLocReRx++;
     break;
  /* Send Routing Info for GPRS  */
  case MAT_GPRS_ROUTINFO:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_ABSENT_SUBS:
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
          break;
#if MAP_REL99
#if MAP_REL4
        case MAT_CALL_BARRED:
          if (maVer != LMA_VER4)
          {
             RETVALUE(STU_UNREC_ERROR);
          }
          break;
#endif
#endif
     }
     s->sts.gprsRoutInfoReRx++;
     break;
  /* Failure Report */
  case MAT_FAILRPT:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
          break;
     }
     s->sts.failRptReRx++;
     break;
  /* GPRS Note MS Present */
  case MAT_GPRS_NOTEMSPRES:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
          break;
     }
     s->sts.gprsNoteMsPresReRx++;
     break;
#endif /* (MAP_HLR || MAP_GSN) */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   
   case MAT_CANCELLOC:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_UNX_DATA_VALUE:
          break;
        case MAT_DATA_MISSING:
          if (maVer == LMA_VER1)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
        case MAT_UNID_SUBS:
          if (maVer != LMA_VER1)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
      }
      s->sts.canLocReRx++;
      break;
   case MAT_PURGE:
     if(maVer == LMA_VER2P)
     {
        switch(errCode)
        {
           default:
             RETVALUE(STU_UNREC_ERROR);
           case MAT_DATA_MISSING:
           case MAT_UNX_DATA_VALUE:
           case MAT_UNK_SUBS:
             break;
        }
        s->sts.purgMsReRx++;
     }
     break;
   case MAT_AUTHINFO:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
          break;
     }
     s->sts.authInfReRx++;
     break;
   case MAT_INSSUBSDATA:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNID_SUBS:
          break;
     }
     s->sts.insSubReRx++;
     break;
   case MAT_DELSUBSDATA:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNID_SUBS:
          break;
     }
     s->sts.delSubReRx++;
     break;

   case MAT_RESET:
      break;

   case MAT_ACTVTRACE:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNID_SUBS:
        case MAT_FACILITY_NOT_SUPP:
        case MAT_TRC_BUFF_FULL:
          break;
     }
     s->sts.actvTrReRx++;
     break;
   case MAT_DACTVTRACE:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNID_SUBS:
        case MAT_FACILITY_NOT_SUPP:
          break;
     }
     s->sts.dactvTrReRx++;
     break;

#if MAP_REL99

   case MAT_AUTHFAILRPT:
     switch(errCode)
     {
        default:
           RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.authFailRptReRx++;
     break;

#endif /* MAP_REL99 */

#endif /* (MAP_VLR || MAP_HLR || MAP_GSN) */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_SMRDY:
        switch(errCode)
        {
           default:
              RETVALUE(STU_UNREC_ERROR);
           case MAT_UNX_DATA_VALUE:
           case MAT_DATA_MISSING:
           case MAT_FACILITY_NOT_SUPP:
           case MAT_UNK_SUBS:
                  break;
        }
        s->sts.smRdyReRx++;
     break; 
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_MSC || MAP_VLR || MAP_GSN)
   case MAT_CHKIMEI:
     switch(errCode)
     {
        default:
           RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNK_EQP:
               break;
        case MAT_DATA_MISSING:
          if (maVer == LMA_VER1)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
        case MAT_UNX_DATA_VALUE:
          if (maVer != LMA_VER1)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.chkIMEIReRx++;
     break;
#endif /* MAP_MSC || MAP_VLR || MAP_GSN */

#if (MAP_MSC || MAP_GSN)
   case MAT_FWDSM:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_FACILITY_NOT_SUPP:
        case MAT_UNX_DATA_VALUE:
        case MAT_SM_DEL_FAIL:
           break;
        case MAT_ILLEGAL_SUBS:
        case MAT_ABSENT_SUBS:
        case MAT_UNID_SUBS:
           if((maVer != LMA_VER1) && (maVer != LMA_VER2))
           {
             RETVALUE(STU_UNREC_ERROR);
           }
           break;

        case MAT_DATA_MISSING:
        case MAT_ILLEGAL_EQP:
        case MAT_SUBS_BUSY_MTMS:
          if (maVer != LMA_VER2)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.fwdSMReRx++;
     break;
   case MAT_MT_FWDSM:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_FACILITY_NOT_SUPP:
        case MAT_UNID_SUBS:
        case MAT_ILLEGAL_SUBS:
        case MAT_ILLEGAL_EQP:
        case MAT_SUBS_BUSY_MTMS:
        case MAT_SM_DEL_FAIL:
        case MAT_ABS_SUBS_SM:
          break;
     }
     s->sts.mtFwdSMReRx++;
     break;
#endif /* MAP_MSC || MAP_GSN */

#if (MAP_REL98 || MAP_REL99)

#if (MAP_HLR || MAP_MLC)
   case MAT_SENDROUTINFOFORLCS:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_FACILITY_NOT_SUPP:
        case MAT_UNK_SUBS:
        case MAT_ABSENT_SUBS:
        case MAT_UNAUTH_REQ_NET:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.lcsSndRoutInfoReRx++;
     break;
#endif /* MAP_HLR || MAP_MLC */

#endif /* MAP_REL98 || MAP_REL99 */

#if (MAP_REL98 || MAP_REL99)

#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL44 && MAP_GSN))
   case MAT_PROVSUBSLOC:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_FACILITY_NOT_SUPP:
        case MAT_UNID_SUBS:
        case MAT_ILLEGAL_SUBS:
        case MAT_ILLEGAL_EQP:
        case MAT_ABSENT_SUBS:
        case MAT_UNAUTH_REQ_NET:
        case MAT_UNAUTH_LCSCLIENT:
        case MAT_POSITION_METH_FAIL:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.provSubsLocReRx++;
     break;
   case MAT_SUBSLOCRPT:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_RSRC_LMT:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
        case MAT_UNAUTH_REQ_NET:
        case MAT_UNKNOWN_OR_UNREACH:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.subsLocReRx++;
     break;
#endif
#endif
#endif /* (MAP_REL98 || MAP_99) */

#if MAP_REL99
#if MAP_HLR
   case MAT_ANY_SUBSDATA_INTER:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_ATSI_NOTALLOWED:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
        case MAT_BEAR_NOT_PROV:
        case MAT_TELE_NOT_PROV:
        case MAT_CALL_BARRED:
        case MAT_ILLEGAL_SS_OPR:
        case MAT_SS_NOT_AVAIL:
        case MAT_INFO_NOT_AVAIL:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.anySubsInterReRx++;
     break;
   case MAT_ANY_MOD:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_ATM_NOTALLOWED:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
        case MAT_BEAR_NOT_PROV:
        case MAT_TELE_NOT_PROV:
        case MAT_CALL_BARRED:
        case MAT_ILLEGAL_SS_OPR:
        case MAT_SS_SUBSVIOL_ERR:
        case MAT_SS_STATUS_ERR:
        case MAT_SS_INCOMP_ERR:
        case MAT_INFO_NOT_AVAIL:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.anyModReRx++;
     break;
   case MAT_NOTE_SUBSDATA_MOD:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.notSubsModReRx++;
     break;
#endif /* MAP_HLR */

#if (MAP_SEC && LMAV2)
   case MAT_SEC_TRANS_CLASS1:
   case MAT_SEC_TRANS_CLASS2:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_SEC_TRANS_ERROR:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }

     break;

#endif /* MAP_SEC */
#endif /* MAP_REL99 */


   default:
     RETVALUE(STU_RE_UNX_RETERR);
  }

  RETVALUE(ROK);

} /* maChkRcvdErr  */

/*
*
*       Fun:   maChkErr    
*
*       Desc:  This function checks the err.code for a given operation code.  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkErr 
(
MaSap *s,           /* Pointer to the Sap */
U8    oprCode,          /* Operation Code */
U8    errCode,          /* Error Code */
U8    maVer         /* Map Version */
)
#else
PUBLIC S16 maChkErr (s,oprCode, errCode, maVer)
MaSap *s;           /* Pointer to the Sap */
U8    oprCode;          /* Operation Code */
U8    errCode;          /* Error Code */
U8    maVer;            /* Map Version */
#endif
{

  TRC2(maChkErr)

  switch (oprCode)
  {

#ifdef XWEXT /* XUXINGZHOU: xinwei management */
   case MAT_PAGING_DETECT:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
          break;  
     }
	 s->sts.detectReTx++;
	 break;
#endif

#if (MAP_VLR || MAP_HLR)
   case MAT_REGSS:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_BEAR_NOT_PROV:
        case MAT_TELE_NOT_PROV:
        case MAT_ILLEGAL_SS_OPR:
        case MAT_SS_STATUS_ERR:
        case MAT_SS_INCOMP_ERR:
          break;  
        case MAT_UNK_SUBS:
        case MAT_SS_SUBSVIOL_ERR:
          if (maVer !=  LMA_VER1)
          {
             RETVALUE(STU_UNREC_ERROR);
          }
          break;
        case MAT_CALL_BARRED:
          if (maVer == LMA_VER1)
          {
             RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.regSSReTx++;
     break;

   case MAT_ERASESS:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_ILLEGAL_SS_OPR:
        case MAT_SS_STATUS_ERR:
           break; 
        /* ma033.105: SS Incomp Error is not applicable for ver 1 & 2 */
        case MAT_SS_SUBSVIOL_ERR:
        case MAT_UNK_SUBS:
          if (maVer != LMA_VER1)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
        case MAT_BEAR_NOT_PROV:
        case MAT_TELE_NOT_PROV:
        case MAT_DATA_MISSING:
        case MAT_CALL_BARRED:
          if (maVer == LMA_VER1)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.eraseSSReTx++;
     break;
   case MAT_ACTVSS:
     switch(errCode)
     {
        default:
            RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_ILLEGAL_SS_OPR:
        case MAT_SS_STATUS_ERR:
        case MAT_SS_SUBSVIOL_ERR:
        case MAT_SS_INCOMP_ERR:
        case MAT_NEG_PWCHK:
          break;  
        case MAT_UNK_SUBS:
          if (maVer != LMA_VER1)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
        case MAT_BEAR_NOT_PROV:
        case MAT_TELE_NOT_PROV:
        case MAT_DATA_MISSING:
        case MAT_CALL_BARRED:
        case MAT_NMB_PW_VIOL:
          if (maVer == LMA_VER1)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.actvSSReTx++;
     break;
   case MAT_DACTVSS:
     switch(errCode)
     {
        default:
            RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_ILLEGAL_SS_OPR:
        case MAT_SS_STATUS_ERR:
        case MAT_SS_SUBSVIOL_ERR:
        case MAT_NEG_PWCHK:
           break;  
        case MAT_UNK_SUBS:
           if(maVer != LMA_VER1)
           {
              RETVALUE(STU_UNREC_ERROR);
           }
          break;
        case MAT_BEAR_NOT_PROV:
        case MAT_TELE_NOT_PROV:
        case MAT_DATA_MISSING:
        case MAT_CALL_BARRED:
        case MAT_NMB_PW_VIOL:
           if (maVer == LMA_VER1)
           {
              RETVALUE(STU_UNREC_ERROR);
           }
          break;
     }
     s->sts.dactvSSReRx++;
     break;
   case MAT_INTERSS:
     switch(errCode)
     {
        default:
            RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_ILLEGAL_SS_OPR:
        case MAT_SS_NOT_AVAIL:
           break;
        case MAT_UNK_SUBS:
           if(maVer != LMA_VER1)
           {
              RETVALUE(STU_UNREC_ERROR);
           }
          break;
        case MAT_BEAR_NOT_PROV:
        case MAT_TELE_NOT_PROV:
        case MAT_DATA_MISSING:
        case MAT_CALL_BARRED:
        case MAT_NMB_PW_VIOL:
           if (maVer == LMA_VER1)
           {
              RETVALUE(STU_UNREC_ERROR);
           }
          break;
     }
     s->sts.interSSReTx++;
     break;
   case MAT_REGPASSWD:
     switch(errCode)
     {
        default:
            RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_SS_SUBSVIOL_ERR:
        case MAT_PASSWD_REG_ERR:
        case MAT_NEG_PWCHK:
          break;  
        case MAT_DATA_MISSING:
        case MAT_CALL_BARRED:
        case MAT_NMB_PW_VIOL:
          if (maVer == LMA_VER1)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.regPasswdReTx++;
     break;
   case MAT_GETPASSWD:
     s->sts.getPasswdReTx++;
     break;
   case MAT_PROCUSSDATA:
     switch(errCode)
     {
        default:
            RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
          break;
     }
     s->sts.procUSSDatReTx++;
     break;
   case MAT_PROCUSSREQ:
     switch(errCode)
     {
        default:
            RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_DATA_MISSING:
        case MAT_CALL_BARRED:
        case MAT_UNK_ALPHABET:
          break;
     }
     s->sts.procUSSReTx++;
     break;
   case MAT_USSREQ:
     switch(errCode)
     {
        default:
            RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_DATA_MISSING:
        case MAT_ILLEGAL_SUBS:
        case MAT_ILLEGAL_EQP:
        case MAT_ABSENT_SUBS:
        case MAT_USSD_BUSY:
        case MAT_UNK_ALPHABET:
          break;
     }
     s->sts.ussReTx++;
     break;
   case MAT_USSNOTIFY:
     switch(errCode)
     {
        default:
           MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
           "maChkErr() failed, invaild error code(%d)and oprCode(%d).\n", errCode, oprCode));
           RETVALUE(RFAILED);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_DATA_MISSING:
        case MAT_ILLEGAL_SUBS:
        case MAT_ILLEGAL_EQP:
        case MAT_ABSENT_SUBS:
        case MAT_USSD_BUSY:
        case MAT_UNK_ALPHABET:
          break;
     }
     s->sts.ussNotReTx++;
     break;
#endif /* VLR || HLR */

#if MAP_MSC
   case MAT_DET_IMSI:
     break;
   case MAT_TRACESUBSACTV:
     break;
#endif   /* MSC */

#if (MAP_MSC || MAP_HLR)
   case MAT_ROUTINFO:
     switch(errCode)
     {
        default:
           RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_FACILITY_NOT_SUPP:
        case MAT_UNK_SUBS:
        case MAT_BEAR_NOT_PROV:
        case MAT_TELE_NOT_PROV:
        case MAT_ABSENT_SUBS:
        case MAT_CALL_BARRED:
        case MAT_FWD_VIOL:
           break;
        case MAT_NMB_CHNGD:
        case MAT_CUG_REJECT:
           if (maVer == LMA_VER1)
           {
              RETVALUE(STU_UNREC_ERROR);
           }
           break;
        case MAT_OR_NOTALLOWED:
        case MAT_NOSUBS_REPLY:
        case MAT_BUSY_SUBS:
           if (maVer != LMA_VER2P)
           {
              RETVALUE(STU_UNREC_ERROR);
           }
           break;
     }
     s->sts.routInfoReTx++;
     break;
   case MAT_ROUTINFOSM:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_FACILITY_NOT_SUPP:
        case MAT_UNK_SUBS:
        case MAT_TELE_NOT_PROV:
        case MAT_CALL_BARRED:
           break;
        case MAT_ABSENT_SUBS:
        if (maVer > LMA_VER2)
        {
           RETVALUE(STU_UNREC_ERROR);
        }
        break;
        case MAT_ABS_SUBS_SM:
            if (maVer != LMA_VER2P)
        {
           RETVALUE(STU_UNREC_ERROR);
        }
        break;
     }
     s->sts.routInfoSMReTx++;
     break;
   case MAT_SMDEL:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
        case MAT_MSG_WAIT_LISTFULL:
          break;
        case MAT_DATA_MISSING:
            if (maVer == LMA_VER1)
        {
            RETVALUE(STU_UNREC_ERROR);
        }
        break;
     }
     s->sts.smDelReTx++;
     break;
   case MAT_ALRTSC:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
          break;
     }
     s->sts.alrtSCReTx++;
     break;
   case MAT_INFSC:
     break;

  /* SS Invocation Notify */
  case MAT_SSINV_NOTIFY:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
          break;
     }
     s->sts.ssInvNotReTx++;
     break;

#if MAP_REL99

  case MAT_IST_ALERT:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_UNX_DATA_VALUE:
        case MAT_RSRC_LMT:
        case MAT_UNK_SUBS:
        case MAT_SYS_FAILURE:
        case MAT_FACILITY_NOT_SUPP:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.istAlrtReTx++;
     break;
  case MAT_IST_COMMAND:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_UNX_DATA_VALUE:
        case MAT_RSRC_LMT:
        case MAT_UNK_SUBS:
        case MAT_SYS_FAILURE:
        case MAT_FACILITY_NOT_SUPP:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.istCmdReTx++;
     break;

#endif /* MAP_REL99 */

#endif  /* MSC || HLR */
    
#if MAP_MSC
#if MAP_REL6
  case MAT_REL_RES:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_UNX_DATA_VALUE:
        case MAT_SYS_FAILURE:
          break;
     }
     s->sts.relResReRx++;
     break;
#endif /* MAP_REL6 */
#endif /* MAP_MSC */

#if (MAP_VLR || MAP_HLR)
   case MAT_UPLOC:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
        case MAT_ROAM_NOTALLOWED:
               break;
        case MAT_DATA_MISSING:
           if (maVer == LMA_VER1)
           {
              RETVALUE(STU_UNREC_ERROR);
           }
           break;
     }
     s->sts.upLocReTx++;
     break;
#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_SNDPARAM:  
     switch(errCode)
     {
        default:
           RETVALUE(STU_UNREC_ERROR);
        case MAT_UNK_SUBS:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNID_SUBS:
           break;
     }
     s->sts.sndParamReTx++;
     break;

#if (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5))
  /* Provide Subscriber Info */
  case MAT_PROVSUBSINFO:
     switch(errCode)
     {
        default:
           RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
           break;
     }
     s->sts.provSubsInfoReTx++;
     break;
#endif /* (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5)) */

#if MAP_REL99

  /* Note MM event */
  case MAT_NOTE_MMEVT:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
        case MAT_MMEVT_NOTSUPPORTED:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.notMmEvReTx++;
     break;

#endif /* MAP_REL99 */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR)
   case MAT_RESTOREDATA:
     switch(errCode)
     {
        default:
           RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
        case MAT_SYS_FAILURE:
           break;
     }
     s->sts.restoreReTx++;
     break;
   case MAT_SNDIMSI:
     switch(errCode)
     {
        default:
           RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
           break;
     }
     s->sts.sndIMSIReTx++;
     break;

   case MAT_PROVROAMNMB:
     switch(errCode)
     {
        default:
           RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_SYS_FAILURE:
        case MAT_FACILITY_NOT_SUPP:
        case MAT_ABSENT_SUBS:
        case MAT_NO_ROAM_AVAIL:
           break;
        case MAT_OR_NOTALLOWED:
               if (maVer != LMA_VER2P)
           {
              RETVALUE(STU_UNREC_ERROR);
           }
           break;
     }
     s->sts.provRoamNmbReTx++;
     break;

  /* Set Reporting State */
  case MAT_SETRPTSTATE:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNID_SUBS:
        case MAT_UNX_DATA_VALUE:
        case MAT_DATA_MISSING:
        case MAT_RSRC_LMT    :
        case MAT_FACILITY_NOT_SUPP:
          break;
     }
     s->sts.setRptStateReTx++;
     break;
  /* Status Report */
  case MAT_STARPT:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_UNK_SUBS:
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_DATA_MISSING:
          break;
     }
     s->sts.staRptReTx++;
     break;
  /* Remote User Free */
  case MAT_RMTUSRFREE:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_INCMPTBL_TERM:
        case MAT_BUSY_SUBS:
        case MAT_ABSENT_SUBS:
        case MAT_SYS_FAILURE:
          break;
     }
     s->sts.rmtUsrFreeReTx++;
     break;

#endif  /* (VLR) || (HLR) */

#if (MAP_VLR || MAP_HLR)
  /* Register CC Entry */
  case MAT_REGCCENT:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_CALL_BARRED:
        case MAT_ILLEGAL_SS_OPR:
        case MAT_SS_STATUS_ERR:
        case MAT_SS_INCOMP_ERR:
        case MAT_SHRTTERM_DENIAL:
        case MAT_LONGTERM_DENIAL:
        case MAT_FACILITY_NOT_SUPP:
          break;
     }
     s->sts.regCcEntReTx++;
     break;
  /* Erase CC Entry */
  case MAT_ERASECCENT:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_CALL_BARRED:
        case MAT_ILLEGAL_SS_OPR:
        case MAT_SS_STATUS_ERR:
          break;
     }
     s->sts.eraseCcEntReTx++;
     break;

#endif /* MAP_VLR || MAP_HLR */

#if MAP_MSC
   case MAT_PRE_HO:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_NO_HONMB_AVAIL:
#if MAP_REL99
        case MAT_TARG_COUT_GCAREA:
#endif /* MAP_REL99 */
          break;
     }
     s->sts.preHoReTx++;
     break;
   case MAT_PER_HO:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_BASE_STAT:
        case MAT_INV_TARG_BSTAT:
        case MAT_NO_RADIO_RSRS_AVAIL:
        case MAT_NO_HONMB_AVAIL:
          break;
     }
     s->sts.perHoReTx++;
     break;
   case MAT_SNDENDSIG:
   case MAT_PROCACCSIG:
   case MAT_FWDACCSIG:
     break;
   case MAT_PRE_SUBSHO:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_MSC:
        case MAT_SUBS_HO_FAIL:
          break;
     }
     s->sts.preSubHoReTx++;
     break;
   case MAT_PER_SUBSHO:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_MSC:
        case MAT_SUBS_HO_FAIL:
        case MAT_UNK_BASE_STAT:
        case MAT_INV_TARG_BSTAT:
          break;
     }
     s->sts.perSubHoReTx++;
     break;
   case MAT_NOTEINTERHO:
     break;
  /* Resume Call Handling */
  case MAT_RESCALLHANDL:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_FWD_FAIL:
        case MAT_OR_NOTALLOWED:
        case MAT_UNX_DATA_VALUE:
#if (MAP_REL98 || MAP_REL99)
        case MAT_DATA_MISSING:
#endif /* MAP_REL98 || MAP_REL99 */
          break;
     }
     s->sts.resCallHandlReTx++;
     break;
  /* Prepare Group Call */
  case MAT_PREP_GRPCALL:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_NOGRPCALLNMB_AVAIL:
        case MAT_UNX_DATA_VALUE:
          break;
     }
     s->sts.prepGrpCallReTx++;
     break;
  /* Process Group Call Signalling */
  case MAT_PRO_GRPCALLSIG:
     s->sts.proGrpCallReTx++;
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
     }
     break;
  /* Forward Group Call Signalling */
  case MAT_FWD_GRPCALLSIG:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
     }
     break;
  /* Send Group Call End Signal */
  case MAT_SND_GRPCALLENDSIG:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
     }
     break;
  /* Provide SIWFS Number */
  case MAT_PROV_SIWFS_NMB:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_RSRC_LMT:
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
          break;
     }
     s->sts.provSiwfsNmbReTx++;
     break;
  /* SIWFS Signalling Modify */
  case MAT_SIWFS_SIGMOD:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_RSRC_LMT:
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
          break;
     }
     s->sts.siwfsSigModReTx++;
     break;
#endif  /* MSC */

#if MAP_VLR
  /* Send Identification Request */
  case MAT_SNDID:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNID_SUBS:
          break;
     }
     s->sts.sndIdReTx++;
     break;
#endif  /* MAP_VLR */

#if (MAP_HLR || MAP_MLC)
  /* Any Time Interrogation */
  case MAT_ANY_INTER:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_ATI_NOTALLOWED:
        case MAT_UNK_SUBS:
        case MAT_DATA_MISSING:
          break;
     }
     s->sts.anyInterReTx++;
     break;
#endif /* MAP_HLR || MAP_MLC */

#if (MAP_HLR || MAP_GSN)
  /* Update GPRS Location */
  case MAT_GPRS_UPLOC:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
        case MAT_ROAM_NOTALLOWED:
          break;
     }
     s->sts.gprsUpLocReTx++;
     break;
  /* Send Routing Info for GPRS  */
  case MAT_GPRS_ROUTINFO:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_ABSENT_SUBS:
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
          break;
#if MAP_REL99
#if MAP_REL4
        case MAT_CALL_BARRED:
          if (maVer != LMA_VER4)
          {
             RETVALUE(STU_UNREC_ERROR);
          }
          break;
#endif
#endif
     }
     s->sts.gprsRoutInfoReTx++;
     break;
  /* Failure Report */
  case MAT_FAILRPT:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
          break;
     }
     s->sts.failRptReTx++;
     break;
  /* GPRS Note MS Present */
  case MAT_GPRS_NOTEMSPRES:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
          break;
     }
     s->sts.gprsNoteMsPresReTx++;
     break;
#endif /* (MAP_HLR || MAP_GSN) */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   
   case MAT_CANCELLOC:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_UNX_DATA_VALUE:
          break;
        case MAT_DATA_MISSING:
          if (maVer == LMA_VER1)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
        case MAT_UNID_SUBS:
          if (maVer != LMA_VER1)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
      }
      s->sts.canLocReTx++;
      break;
   case MAT_PURGE:
     if(maVer == LMA_VER2P)
     {
        switch(errCode)
        {
           default:
             RETVALUE(STU_UNREC_ERROR);
           case MAT_DATA_MISSING:
           case MAT_UNX_DATA_VALUE:
           case MAT_UNK_SUBS:
             break;
        }
        s->sts.purgMsReTx++;
     }
     break;
   case MAT_AUTHINFO:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
          break;
     }
     s->sts.authInfReTx++;
     break;
   case MAT_INSSUBSDATA:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNID_SUBS:
          break;
     }
     s->sts.insSubReTx++;
     break;
   case MAT_DELSUBSDATA:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNID_SUBS:
          break;
     }
     s->sts.delSubReTx++;
     break;

   case MAT_RESET:
      break;

   case MAT_ACTVTRACE:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNID_SUBS:
        case MAT_FACILITY_NOT_SUPP:
        case MAT_TRC_BUFF_FULL:
          break;
     }
     s->sts.actvTrReTx++;
     break;
   case MAT_DACTVTRACE:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNID_SUBS:
        case MAT_FACILITY_NOT_SUPP:
          break;
     }
     s->sts.dactvTrReTx++;
     break;

#if MAP_REL99

   case MAT_AUTHFAILRPT:
     switch(errCode)
     {
        default:
           RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.authFailRptReTx++;
     break;

#endif /* MAP_REL99 */

#endif /* (MAP_VLR || MAP_HLR || MAP_GSN) */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_SMRDY:
        switch(errCode)
        {
           default:
              RETVALUE(STU_UNREC_ERROR);
           case MAT_UNX_DATA_VALUE:
           case MAT_DATA_MISSING:
           case MAT_FACILITY_NOT_SUPP:
           case MAT_UNK_SUBS:
                  break;
        }
        s->sts.smRdyReTx++;
     break; 
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_MSC || MAP_VLR || MAP_GSN)
   case MAT_CHKIMEI:
     switch(errCode)
     {
        default:
           RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_UNK_EQP:
               break;
        case MAT_DATA_MISSING:
          if (maVer == LMA_VER1)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
        case MAT_UNX_DATA_VALUE:
          if (maVer != LMA_VER1)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.chkIMEIReTx++;
     break;
#endif /* MAP_MSC || MAP_VLR || MAP_GSN */

#if (MAP_MSC || MAP_GSN)
   case MAT_FWDSM:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_FACILITY_NOT_SUPP:
        case MAT_UNX_DATA_VALUE:
        case MAT_SM_DEL_FAIL:
           break;
        case MAT_ILLEGAL_SUBS:
        case MAT_ABSENT_SUBS:
        case MAT_UNID_SUBS:
        case MAT_DATA_MISSING:
        case MAT_ILLEGAL_EQP:
        case MAT_SUBS_BUSY_MTMS:
          /* ma033.105: Modification to make it applicable for Version-1 */
          if ((maVer != LMA_VER2) && (maVer != LMA_VER1))
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.fwdSMReTx++;
     break;
   case MAT_MT_FWDSM:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_FACILITY_NOT_SUPP:
        case MAT_UNID_SUBS:
        case MAT_ILLEGAL_SUBS:
        case MAT_ILLEGAL_EQP:
        case MAT_SUBS_BUSY_MTMS:
        case MAT_SM_DEL_FAIL:
        case MAT_ABS_SUBS_SM:
          break;
     }
     s->sts.mtFwdSMReTx++;
     break;
#endif /* MAP_MSC || MAP_GSN */

#if (MAP_REL98 || MAP_REL99)

#if (MAP_HLR || MAP_MLC)
   case MAT_SENDROUTINFOFORLCS:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_FACILITY_NOT_SUPP:
        case MAT_UNK_SUBS:
        case MAT_ABSENT_SUBS:
        case MAT_UNAUTH_REQ_NET:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.lcsSndRoutInfoReTx++;
     break;
#endif /* MAP_HLR || MAP_MLC */

#endif /* MAP_REL98 || MAP_REL99 */

#if (MAP_REL98 || MAP_REL99)

#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL4 && MAP_GSN))
   case MAT_PROVSUBSLOC:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_FACILITY_NOT_SUPP:
        case MAT_UNID_SUBS:
        case MAT_ILLEGAL_SUBS:
        case MAT_ILLEGAL_EQP:
        case MAT_ABSENT_SUBS:
        case MAT_UNAUTH_REQ_NET:
        case MAT_UNAUTH_LCSCLIENT:
        case MAT_POSITION_METH_FAIL:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.provSubsLocReTx++;
     break;
   case MAT_SUBSLOCRPT:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_SYS_FAILURE:
        case MAT_DATA_MISSING:
        case MAT_RSRC_LMT:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
        case MAT_UNAUTH_REQ_NET:
        case MAT_UNKNOWN_OR_UNREACH:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.subsLocReTx++;
     break;
#endif
#endif
#endif /* (MAP_REL98 || MAP_REL99) */

#if MAP_REL99
#if MAP_HLR
   case MAT_ANY_SUBSDATA_INTER:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_ATSI_NOTALLOWED:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
        case MAT_BEAR_NOT_PROV:
        case MAT_TELE_NOT_PROV:
        case MAT_CALL_BARRED:
        case MAT_ILLEGAL_SS_OPR:
        case MAT_SS_NOT_AVAIL:
        case MAT_INFO_NOT_AVAIL:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.anySubsInterReTx++;
     break;
   case MAT_ANY_MOD:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_ATM_NOTALLOWED:
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
        case MAT_BEAR_NOT_PROV:
        case MAT_TELE_NOT_PROV:
        case MAT_CALL_BARRED:
        case MAT_ILLEGAL_SS_OPR:
        case MAT_SS_SUBSVIOL_ERR:
        case MAT_SS_STATUS_ERR:
        case MAT_SS_INCOMP_ERR:
        case MAT_INFO_NOT_AVAIL:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.anyModReTx++;
     break;
   case MAT_NOTE_SUBSDATA_MOD:
     switch(errCode)
     {
        default:
          RETVALUE(STU_UNREC_ERROR);
        case MAT_DATA_MISSING:
        case MAT_UNX_DATA_VALUE:
        case MAT_UNK_SUBS:
          if (maVer != LMA_VER2P)
          {
            RETVALUE(STU_UNREC_ERROR);
          }
          break;
     }
     s->sts.notSubsModReTx++;
     break;
#endif /* MAP_HLR */

#endif /* MAP_REL99 */

   default:
     RETVALUE(STU_RE_UNX_RETERR);
  }

  RETVALUE(ROK);

} /* maChkErr  */


/*
*
*       Fun:    maInsHashDlg
*
*       Desc:   Inserts dialog control point into the hash list
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC MaDlgCp *maInsHashDlg
(
MaSap *s,                          /* current sap */
MaDlgId maSpDlgId,                 /* current Dialog id TCAP assigned*/
MaDlgId maSuDlgId                  /* current Dialog id */
)
#else
PUBLIC MaDlgCp *maInsHashDlg(s, maSpDlgId, maSuDlgId)
MaSap *s;                          /* current sap */
MaDlgId maSpDlgId;                 /* current Dialog id TCAP assigned*/
MaDlgId maSuDlgId;                 /* current Dialog id */
#endif
{
   U32 hashEntryDlg;
   Bool found;
   MaDlgCp *d;
   MaDlgCp *newDlg;
   Data *tmpBuf;
   U32 i;
   S16 ret;

   TRC2(maInsHashDlg)

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                       "maInsHashDlg(spId(%d), spDlgId(%ld), suDlgId (%ld)\n",
                       s->sapId, maSpDlgId, maSuDlgId));

#else
  
   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                       "maInsHashDlg(spId(%d), spDlgId(%d), suDlgId (%d)\n",
                       s->sapId, maSpDlgId, maSuDlgId));

#endif/*ALIGN_64BIT*/
/* ma012.203: To support Dlg Hash Size configuration */
#ifdef MAP_NSRP
/* ma013.203 : If dlgHshSize is power of 2 then do & with maSpDlgId */
   if( (s->dlgHshSize & (s->dlgHshSize - 1)) == 0)
   { 
     hashEntryDlg = (U32)(maSpDlgId & (s->dlgHshSize)); 
   }
   else
   {
     hashEntryDlg = (U32)(maSpDlgId % (s->dlgHshSize)); 
   }
#else
   hashEntryDlg = (U32)(maSpDlgId % MA_DLG_HASH_SIZE);
#endif /* MAP_NSRP */
   if (s->maDlgTbl[hashEntryDlg] == NULLP)
   {
      if ((ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, &tmpBuf, 
         sizeof(MaDlgCp))) != ROK)
      {
        RETVALUE((MaDlgCp *)NULLP);
      }
      d = (MaDlgCp *)tmpBuf;
      s->maDlgTbl[hashEntryDlg] = d;
      d->prev = NULLP;
      d->next = NULLP;
      d->suDlgId = maSuDlgId;
      d->spDlgId = maSpDlgId;
      d->lowerSpDlgId = 0; 
      d->dsmState = MA_DLG_IDLE;
      d->apn.pres = FALSE;
      d->srcRef.pres = FALSE;
      d->destRef.pres = FALSE;
      d->endFlg = FALSE;
      d->dlgEvFlg = FALSE;
      d->usrInfoPres = FALSE;
      d->cmpPresFlg = FALSE;
      d->openRspRcvd.pres = FALSE;
      d->openRspRcvd.usrInfo.pres = FALSE;
      maBZero((U8 *)&d->openRspRcvd.extCont, sizeof(MaExtContSeq));
      d->usrInfo.pres = FALSE;
      maBZero((U8 *)&d->extCont, sizeof(MaExtContSeq));
      d->closePduPres = FALSE;
      maBZero((U8 *)&d->closePdu, sizeof(MaClosePdu));
#ifdef XW_IND_OPTIMIZE
#ifndef MA_STATIC_EVT_STRUCT
      for (i=0; i< MAX_DLG_RESEVT; i++)
         d->storIvkId[i].pres = FALSE; 
#endif
#endif
      for (i=0; i< MA_INVOKE_HASH_SIZE; i++)
         d->invkTbl[i] = (MaCmpCp *)NULLP; 
      d->sap = s;
#if MAP_REL99
#if (MAP_SEC && LMAV2)
      d->prevInSa = (MaDlgCp *)NULLP;
      d->nextInSa = (MaDlgCp *)NULLP;
      d->selfId.mcc.pres = FALSE;
      d->selfId.mnc.pres = FALSE;
      d->peerId.mcc.pres = FALSE;
      d->peerId.mnc.pres = FALSE;
      d->mapSec = FALSE;
      d->saCp = (MaSaCp *)NULLP;
      d->maPg = (LmaSecPgCfg *)NULLP;
      d->cmpLst = (MaCmpStd *)NULLP;
      cmZero((U8 *)&d->cmpId,sizeof(LmaOrigCmpId));
#endif
#endif
#if (MATV2 && STUV2)
     d->imp.pres = FALSE;
     d->openRspRcvd.imp.pres = FALSE;
#endif
#ifdef MATV3
     d->maPrior.pres = FALSE;
     d->pClass.pres  = FALSE;
#endif
#ifdef LMAV3
     /* TimeStamp when the dialogue control point was last accessed */
     SGetSysTime(&(d->tmStmp));
#endif
#ifdef ZJ
     d->upd = FALSE;
#endif
      RETVALUE(d);
   }
   else
   {
      for(found = FALSE, d=s->maDlgTbl[hashEntryDlg]; d->next != NULLP; 
         d=d->next)
         if(d->spDlgId == maSpDlgId)
         {
            found = TRUE;
            break;
         }
      if (found != TRUE)
      {
         /* create a new dialog control point */
         if ((ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, &tmpBuf, 
            sizeof(MaDlgCp))) != ROK)
         {
           RETVALUE((MaDlgCp *)NULLP);
         }
         newDlg = (MaDlgCp *)tmpBuf;
         d->next = newDlg;
         newDlg->prev = d;
         newDlg->next = (MaDlgCp *)NULLP;
         newDlg->suDlgId = maSuDlgId;
         newDlg->spDlgId = maSpDlgId;
         newDlg->lowerSpDlgId = 0; 
         newDlg->dsmState = MA_DLG_IDLE;
         newDlg->apn.pres = FALSE;
         newDlg->srcRef.pres = FALSE;
         newDlg->destRef.pres = FALSE;
         newDlg->endFlg = FALSE;
         newDlg->dlgEvFlg = FALSE;
         newDlg->usrInfoPres = FALSE;
         newDlg->cmpPresFlg = FALSE;
         newDlg->openRspRcvd.pres = FALSE;
         newDlg->openRspRcvd.usrInfo.pres = FALSE;
         maBZero((U8 *)&newDlg->openRspRcvd.extCont, sizeof(MaExtContSeq));
         newDlg->usrInfo.pres = FALSE;
         maBZero((U8 *)&newDlg->extCont, sizeof(MaExtContSeq));
         newDlg->closePduPres = FALSE;
         maBZero((U8 *)&newDlg->closePdu, sizeof(MaClosePdu));
#ifdef XW_IND_OPTIMIZE
#ifndef MA_STATIC_EVT_STRUCT
         for (i=0; i< MAX_DLG_RESEVT; i++)
           d->storIvkId[i].pres = FALSE; 
#endif
#endif
         for (i=0; i< MA_INVOKE_HASH_SIZE; i++)
           newDlg->invkTbl[i] = (MaCmpCp *)NULLP; 
         newDlg->sap = s;
#if MAP_REL99
#if (MAP_SEC && LMAV2)
         newDlg->prevInSa = (MaDlgCp *)NULLP;
         newDlg->nextInSa = (MaDlgCp *)NULLP;
         newDlg->selfId.mcc.pres = FALSE;
         newDlg->selfId.mnc.pres = FALSE;
         newDlg->peerId.mcc.pres = FALSE;
         newDlg->peerId.mnc.pres = FALSE;
         newDlg->mapSec = FALSE;
         newDlg->saCp = (MaSaCp *)NULLP;
         newDlg->maPg = (LmaSecPgCfg *)NULLP;
         newDlg->cmpLst = (MaCmpStd *)NULLP;
         cmZero((U8 *)&newDlg->cmpId,sizeof(LmaOrigCmpId));
#endif
#endif
#if (MATV2 && STUV2)
         newDlg->imp.pres = FALSE;
         newDlg->openRspRcvd.imp.pres = FALSE;
#endif
#ifdef MATV3
         newDlg->maPrior.pres = FALSE;
         newDlg->pClass.pres  = FALSE;
#endif
#ifdef LMAV3
         /* TimeStamp when the dialogue control point was last accessed */
         SGetSysTime(&(newDlg->tmStmp));
#endif
#ifdef ZJ
         newDlg->upd = FALSE;
#endif
         RETVALUE(newDlg);
      }
   }
   RETVALUE((MaDlgCp *) NULLP);
} /* end of maInsHashDlg */


/*
*
*       Fun:   maFindHashDlg 
*
*       Desc:  Finds the dialogue control point in the hash list 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ca_bdy2.c
*
*/
  

#ifdef ANSI
PUBLIC MaDlgCp *maFindHashDlg
(
MaSap *s,                        /* current sap */
MaDlgId maDlgId                  /* service provider dialog Id */
)
#else
PUBLIC MaDlgCp *maFindHashDlg(s, maDlgId)
MaSap *s;                        /* current sap */
MaDlgId maDlgId;                 /* service provider dialog Id */
#endif
{
   U32 hashEntryDlg;
   Bool found;
   MaDlgCp *d;

   TRC2(maFindHashDlg)

   s->curDlgCp = NULLP;
  /* ma012.203 : Addition, To support Dlg Hash Size configuration*/ 
#ifdef MAP_NSRP
/* ma013.203 : If dlgHshSize is power of 2 then do & with maDlgId */
   if( (s->dlgHshSize & (s->dlgHshSize - 1)) == 0)
   { 
     hashEntryDlg = (U32)(maDlgId & (s->dlgHshSize)); 
   }
   else
   {
      hashEntryDlg = (U32)(maDlgId % (s->dlgHshSize));
   }
#else
   hashEntryDlg = (U32)(maDlgId % MA_DLG_HASH_SIZE);
#endif /* MAP_NSRP */
   if (s->maDlgTbl[hashEntryDlg] == NULLP)
     RETVALUE((MaDlgCp *)NULLP);
   else
     for(found = FALSE, d=s->maDlgTbl[hashEntryDlg]; d != NULLP; d=d->next)
       if (d->spDlgId == maDlgId)
         {
           found = TRUE;
           break;
         }
   if (found != TRUE)
     RETVALUE((MaDlgCp *)NULLP);
   else
   {
     s->curDlgCp = d;
#ifdef LMAV3
     /* TimeStamp when the dialogue control point was last accessed */
     SGetSysTime(&(d->tmStmp));
#endif
     RETVALUE(d);
   }
} /* end of maFindHashDlg */

/*
*
*       Fun:   maFindHashDlgLower 
*
*       Desc:  Finds the dialogue control point in the hash list using the
*              lower layer (TCAP) spDlgId
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ca_bdy2.c
*
*/
  

#ifdef ANSI
PUBLIC MaDlgCp *maFindHashDlgLower
(
MaSap *s,                        /* current sap */
MaDlgId maDlgId                  /* service provider dialog Id */
)
#else
PUBLIC MaDlgCp *maFindHashDlgLower(s, maDlgId)
MaSap *s;                        /* current sap */
MaDlgId maDlgId;                 /* service provider dialog Id */
#endif
{
   U32 i;
   Bool found;
   MaDlgCp *d;
   TRC2(maFindHashDlgLower)
   found = 0;
   d = NULLP;

/*ma012.203 : Addition, To support Dlg Hash Size Configuration */
#ifdef MAP_NSRP
   for (i=0; i< s->dlgHshSize; i++)
#else
   for (i=0; i< MA_DLG_HASH_SIZE; i++)
#endif /* MAP_NSRP */
   { 
     for(found = FALSE, d=s->maDlgTbl[i]; d != NULLP; d=d->next)
     {
       if (d->lowerSpDlgId == maDlgId)
       {
         found = TRUE;
         break;
       }
     }
     if (found == TRUE)
        break;
   }
   if (found != TRUE)
     RETVALUE((MaDlgCp *)NULLP);
   else
     RETVALUE(d);



} /* end of maFindHashDlgLower */


/*
*
*       Fun:    maRemHashDlg
*
*       Desc:   Removes Dlg from maSap
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC MaDlgCp *maRemHashDlg
(
MaSap *s,                            /* current sap */
MaDlgId maDlgId                      /* current dialog Id */
)
#else
PUBLIC MaDlgCp *maRemHashDlg(s, maDlgId)
MaSap *s;                            /* current sap */
MaDlgId maDlgId;                     /* current dialog Id */
#endif
{
   U32 hashEntryDlg;
   MaDlgCp *d;

   TRC2(maRemHashDlg)

#ifndef ALIGN_64BIT 

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                       "maRemHashDlg(spId(%d), spDlgId(%ld)\n",
                       s->sapId, maDlgId));

#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                       "maRemHashDlg(spId(%d), spDlgId(%d)\n",
                       s->sapId, maDlgId));

#endif/*ALIGN_64BIT*/
/* ma012.203: Addition, To support Dlg Hash Size configuration */
#ifdef MAP_NSRP
/* ma013.203 : If dlgHshSize is power of 2 then do & with maSpDlgId */
   if( (s->dlgHshSize & (s->dlgHshSize - 1)) == 0)
   { 
     hashEntryDlg = (U32)(maDlgId & (s->dlgHshSize)); 
   }
   else
   {
     hashEntryDlg = (U32)(maDlgId % (s->dlgHshSize));
   }
#else
   hashEntryDlg = (U32)(maDlgId % MA_DLG_HASH_SIZE);
#endif /*MAP_NSRP */
   if (s->maDlgTbl[hashEntryDlg] == NULLP)
      RETVALUE((MaDlgCp *)NULLP);
   else
      for(d=s->maDlgTbl[hashEntryDlg]; d != NULLP; d=d->next)
         if (d->spDlgId == maDlgId)
         {
            if (d->next)
               d->next->prev = d->prev;
            if (d->prev)
               d->prev->next = d->next;
            if (d == s->maDlgTbl[hashEntryDlg]) 
            {
               /* entry to be removed is the first entry in the linked list */

               if (d->next ==(MaDlgCp *) NULLP)
               {
                  /* entry to be removed is the only entry in the linked list 
                     so make the hash table index as null */

                  s->maDlgTbl[hashEntryDlg] = (MaDlgCp *) NULLP;
               }
               else
               {

                  /* entry to be removed is not the only one in the list */
 
                  /* since first entry to be removed, make the hash table 
                     index point to the next entry in the linked list */

                  s->maDlgTbl[hashEntryDlg] = d->next;
               }
            }
#if MAP_REL99
#if (MAP_SEC && LMAV2)
            if (d->saCp != NULLP)
            {
               maRemSaDlg(d,d->saCp);
            }
#endif /* MAP_SEC */
#endif
            RETVALUE(d);
         }
      /* none found */
      RETVALUE((MaDlgCp *)NULLP);
} /* end of maRemHashDlg */

/*
*
*       Fun:    maRemHashInv
*
*       Desc:   Removes invocation from Dialogue control point
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maRemHashInv
(
MaDlgCp *dlgCp,                      /* current dialog control point */
MaInvokeId *id,              /* Invoke Id */
Bool    initiator            /* invoke initiator */
)
#else
PUBLIC S16 maRemHashInv(dlgCp, id , initiator)
MaDlgCp *dlgCp;                       /* current dialog ocntrol point */
MaInvokeId *id;              /* Invoke Id */
Bool    initiator;           /* invoke initiator */
#endif
{
   U32 hashEntryInv;
   MaCmpCp *p;

   TRC2(maRemHashInv)

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                       "maRemHashInv(spId(%d), spDlgId(%ld), invkId (%d), initiator (%d)\n",
                       dlgCp->sap->sapId, dlgCp->spDlgId, id->octet, initiator));

#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                       "maRemHashInv(spId(%d), spDlgId(%d), invkId (%d), initiator (%d)\n",
                       dlgCp->sap->sapId, dlgCp->spDlgId, id->octet, initiator));

#endif/*ALIGN_64BIT*/    
   hashEntryInv = (U32)(((U32)id->octet) % MA_INVOKE_HASH_SIZE);
   if (dlgCp->invkTbl[hashEntryInv] == NULLP)
   {
      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "maRemHashInv() failed, empty invoke entry.\n"));
      RETVALUE(RFAILED);
   }
   else
   {
      for(p=dlgCp->invkTbl[hashEntryInv]; p != NULLP; p=p->next)
         if (p->invkId.pres && p->invkId.octet == id->octet)
         {
            /* if the direction doesn't match, then continue */
            if (p->initiator !=  initiator)
            {
               continue;
            }
            /* match was found - remove from queue */
            if (p->next)
               p->next->prev = p->prev;
            if (p->prev)
               p->prev->next = p->next;


            if (p == dlgCp->invkTbl[hashEntryInv])
            {
               /* entry to be removed is the first entry in the linked list */

               if (p->next == (MaCmpCp *) NULLP)
               {
                  /* entry to be removed is the only entry in the linked list 
                     so make the hash table index as null */

                  dlgCp->invkTbl[hashEntryInv] = (MaCmpCp *)NULLP;
               }
               else
               {
                  /* entry to be removed is not the only one in the list */
 
                  /* since first entry to be removed, make the hash table 
                     index point to the next entry in the linked list */

                  dlgCp->invkTbl[hashEntryInv] = p->next;
               }
            }

#ifdef MA_MULT_SEG_DECODE
            {
               /* Free message segments queue if present */
               Buffer *mBuf; /* dummy Buffer */
               while ((SDequeueFirst(&mBuf,&p->segQ)==ROK) && 
                               (mBuf != (Buffer *)NULLP))
               {
                  SPutMsg(mBuf);
               }
            }
#else /* MA_MULT_SEG_DECODE */
            /* Free the concatenated message segments if present */
            if(p->mBuf != (Buffer *)NULLP)
            {
               SPutMsg(p->mBuf);
            }
#endif /* MA_MULT_SEG_DECODE */
#ifdef XW_IND_OPTIMIZE
#ifndef MA_STATIC_EVT_STRUCT
            if(p->evtStor != NULL)
            {
                maFreeEncEv(dlgCp->sap, p->evtStor, p);
            }
            {/*remove the stored invoke id in the dlgCp*/
               U8 i;
               for(i=0; i<MAX_DLG_RESEVT; i++)
               {
                  if((dlgCp->storIvkId[i].pres == TRUE)&&(dlgCp->storIvkId[i].octet == p->invkId.octet))
                  {
                    dlgCp->storIvkId[i].pres= 0;
                    dlgCp->storIvkId[i].octet = 0;
                  }
               }
            }
#endif
#endif
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool,(Data *)p, sizeof(MaCmpCp));
            /*
            ** decrement the invoke counter
            */
            if(maCb.maInvCnt > 0)
            {
               maCb.maInvCnt--;
            }


            RETVALUE(ROK);
         }
   }
   /* no match was found */
   MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
   "maRemHashInv() failed, no match invoke entry was found.\n"));
   RETVALUE(RFAILED);
} /* end of maRemHashInv */

/*
*
*       Fun:    maFindHashInvk
*
*       Desc:   Finds given string in dlgCp non-destructively returns
*               invocation
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC MaCmpCp *maFindHashInvk
(
MaDlgCp *dlgCp,                            /* current dialogue control point */
MaInvokeId *id,                            /* identifier */
Bool    initiator                          /* invoke initiator */
)
#else
PUBLIC MaCmpCp *maFindHashInvk(dlgCp, id, initiator)
MaDlgCp *dlgCp;                            /* current dialogue control point */
MaInvokeId *id;                            /* identifier */
Bool    initiator;                         /* invoke initiator */
#endif
{
   U32 hashEntryInv;
   MaCmpCp *p;

   TRC2(maFindHashInvk)

   hashEntryInv = (U32)(((U32)id->octet) % MA_INVOKE_HASH_SIZE);
   if (dlgCp->invkTbl[hashEntryInv] == NULLP)
      RETVALUE((MaCmpCp *)NULLP);
   else
      for(p=dlgCp->invkTbl[hashEntryInv]; p != NULLP; p=p->next)
      {
         if ( p->invkId.pres &&
              (p->invkId.octet == id->octet) &&
              (p->initiator == initiator)
            )
         {
#ifdef LMAV3
            /* TimeStamp when the dialogue control point was last accessed */
            SGetSysTime(&(p->tmStmp));
#endif
            RETVALUE(p);
         }
      }
   /* no match was found */
   RETVALUE((MaCmpCp *)NULLP);
} /* end of maFindHashInvk */

/*
*
*       Fun:    maInsHashInv
*
*       Desc:   Inserts invocation Control point into dialog control point
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC MaCmpCp *maInsHashInv
(
MaSap    *s,                         /* current sap */
MaInvokeId *invkId,                  /* current Invoke id */
Bool     initiator                   /* Invoke Initator flag */
)
#else
PUBLIC MaCmpCp *maInsHashInv(s, invkId,initiator)
MaSap    *s;                         /* current sap */
MaInvokeId *invkId;                    /* current Invoke id */
Bool     initiator;                  /* Invoke Initator flag */
#endif
{
   U32 hashEntryInv;
   MaCmpCp *p;
   MaCmpCp *newCp;
   MaDlgCp *d;
   Data *wrkBuf;
   Bool found;
   S16 ret;

   TRC2(maInsHashInv);


#ifndef ALIGN_64BIT

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                       "maInsHashInv(spId(%d), spDlgId(%ld), invkId (%d), initiator (%d)\n",
                       s->sapId, s->curDlgCp->spDlgId, invkId->octet, initiator));
#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                       "maInsHashInv(spId(%d), spDlgId(%d), invkId (%d), initiator (%d)\n",
                       s->sapId, s->curDlgCp->spDlgId, invkId->octet, initiator));

#endif/*ALIGN_64BIT*/

   /*
   ** Maximum Invokes are already allocated then return
   ** Null component control point
   */

   d = s->curDlgCp;
   hashEntryInv = (U32)(((U32)invkId->octet) % MA_INVOKE_HASH_SIZE);
   if (d->invkTbl[hashEntryInv] == NULLP)
   {
      if ((ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, &wrkBuf, 
         sizeof(MaCmpCp))) != ROK)
      {
        RETVALUE((MaCmpCp *)NULLP);
      }
      p = (MaCmpCp *)wrkBuf;
      d->invkTbl[hashEntryInv] = p;
      p->prev = NULLP;
      p->next = NULLP;
      p->impCfmFlg = FALSE;
      p->ssmState = MA_SSM_IDLE;
      p->spDlgId = d->spDlgId;
      p->sap = s;
      p->invkId.pres = TRUE;
      p->invkId.octet = invkId->octet;
      p->lnkId.pres = FALSE;
      p->mBuf = (Buffer *)NULLP;
      p->initiator = initiator;

#ifdef XW_IND_OPTIMIZE
#ifndef MA_STATIC_EVT_STRUCT
      p->evtStor = NULL;
#endif
#endif

      /*
      ** Increment the Invoke counter
      */
      maCb.maInvCnt++;
 
      /* zero timers */
      cmInitTimers(p->timers, (U8)MA_MAX_TMRS);
#ifdef MA_MULT_SEG_DECODE
      SInitQueue(&p->segQ);
#endif /* MA_MULT_SEG_DECODE */
#ifdef LMAV3
      /* TimeStamp when the dialogue control point was last accessed */
      SGetSysTime(&(d->tmStmp));
      SGetSysTime(&(p->tmStmp));
#endif
      RETVALUE(p);
   }
   else
   {
      for(found = FALSE, p=d->invkTbl[hashEntryInv]; p->next != NULLP; p=p->next)
      {
        if (p->invkId.octet  == invkId->octet)
        {
            if(initiator != p->initiator)
            {
               continue;
            }
            found = TRUE;
            break;
        }
      }
      if (found != TRUE)
      {
        if ((ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, &wrkBuf, sizeof(MaCmpCp))) != ROK)
        {
           RETVALUE((MaCmpCp *)NULLP);
        }
        newCp = (MaCmpCp *)wrkBuf;
        p->next = newCp;
        newCp->prev = p;
        newCp->next = (MaCmpCp *)NULLP;
        newCp->spDlgId = d->spDlgId;
        newCp->sap = s;
        newCp->invkId.pres = TRUE;
        newCp->invkId.octet = invkId->octet;
        newCp->lnkId.pres = FALSE;
        newCp->ssmState = MA_SSM_IDLE;
        newCp->impCfmFlg = FALSE;
        newCp->mBuf = (Buffer *)NULLP;
        newCp->initiator = initiator;

#ifdef XW_IND_OPTIMIZE
#ifndef MA_STATIC_EVT_STRUCT
      p->evtStor = NULL;
#endif
#endif
        /*
        ** Increment the Invoke counter
        */
        maCb.maInvCnt++;

 
        /* zero timers */
        cmInitTimers(newCp->timers, (U8)MA_MAX_TMRS);
#ifdef MA_MULT_SEG_DECODE
        SInitQueue(&newCp->segQ);
#endif /* MA_MULT_SEG_DECODE */
#ifdef LMAV3
        /* TimeStamp when the dialogue control point was last accessed */
        SGetSysTime(&(d->tmStmp));
        SGetSysTime(&(newCp->tmStmp));
#endif
        RETVALUE(newCp);
     }
   }
   RETVALUE((MaCmpCp *)NULLP);
}


/*
*
*       Fun:    maDlgIdle
*
*       Desc:   delete dialog control point to set idle
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC Void maDlgIdle
(
MaSap *s                   /* MAP sap */
)
#else
PUBLIC Void maDlgIdle(s)
MaSap *s;                  /* MAP sap */
#endif
{
   MaDlgCp *dlgCp;   /* dialog control point */
   MaCmpCp *p;
   MaCmpCp *d;
   U32 i;                     /* loop counter */

   TRC2(maDlgIdle)

   dlgCp = s->curDlgCp;

   if (dlgCp == (MaDlgCp *)NULLP)
   {
     RETVOID;
   }

#ifdef ZJ
   if (zjCb.tuCb.rsetCbLst != NULLP)
   {
      /* PSF MAP has not been shutdown */
      if ((zjCb.tuCb.genCfg.updAllDlg != TRUE) && (dlgCp->upd == TRUE))
         cmTuDelMapping (&zjCb.tuCb, (PTR)dlgCp);
   }
#endif

   /* free all operation CB's, loop through invokes to free them */

   for(i=0;i<MA_INVOKE_HASH_SIZE;i++)
   {
      if(dlgCp->invkTbl[i] != (MaCmpCp *)NULLP)
      {
         p = dlgCp->invkTbl[i];
         do
         {
            d = p->next;
            maInvkIdle(dlgCp, p);
            p = d;
         }  while (d);
      }
   }

#if MAP_REL99
#if (MAP_SEC && LMAV2)
   if (dlgCp->cmpLst != (MaCmpStd *)NULLP)
   {
      maReqIdle(dlgCp);
   }
#endif
#endif

   /* remove the dialogue from the hash list */
   dlgCp = maRemHashDlg(s, dlgCp->spDlgId);

   if (s->bitMap.map != NULLP)
   {
      /* free the dialogue id */
      (Void) maFreeDlgId(s, dlgCp->spDlgId);
   }

   /* free the dialogue memory */
   #ifdef XW_IND_OPTIMIZE
   #ifndef MA_STATIC_EVT_STRUCT
    /*free the stored event*/
   {
        U8 i;
        MaCmpCp *cmpCp;
        U8 *evt=NULL;
        for(i=0; i<MAX_DLG_RESEVT; i++)
        {
            maGetStoreEvtFrmCmp(dlgCp, &dlgCp->storIvkId[i], &cmpCp, &evt);
            if(evt != NULL)
                maFreeEncEv(s, evt, cmpCp);
        }
   }
   #endif
   #endif
   
   SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)dlgCp, sizeof(MaDlgCp));

   /* update the current dialogue pointer to NULL */
   s->curDlgCp = (MaDlgCp *)NULLP;

   /* decrement the number of active dialogues */
   if (s->nmbActvDlg != 0)
   {
     s->nmbActvDlg--;
   }

   RETVOID;

} /* end of maDlgIdle */

/*
*
*       Fun:    maInvkIdle
*
*       Desc:   delete transaction control point to set idle
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC Void maInvkIdle
(
MaDlgCp *dlgCp,           /* Dialogue control point */
MaCmpCp *cmpCp            /* Component Control point */
)
#else
PUBLIC Void maInvkIdle(dlgCp, cmpCp)
MaDlgCp *dlgCp;           /* Dialogue control point */
MaCmpCp *cmpCp;           /* Component Control point */
#endif
{

   TRC2(maInvkIdle)

   maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
   maRemHashInv(dlgCp, &cmpCp->invkId,cmpCp->initiator);

   RETVOID;
} /* end of maInvkIdle */

/*
*
*       Fun:    maFreeAllDlg
*
*       Desc:   Finds given string in maSap non-destructively returns dialog
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC Void maFreeAllDlg
(
MaSap *s                        /* current sap */
)
#else
PUBLIC Void maFreeAllDlg(s)
MaSap *s;                        /* current sap */
#endif
{
   U32 i;
   MaDlgCp *d;
   StDlgEv txDlgEv;
   
   TRC2(maFreeAllDlg)

/* ma012.203: Addition, To support Dlg Hash Size configuration */
#ifdef MAP_NSRP
   for (i = 0; i < s->dlgHshSize; i++)
#else
   for (i = 0; i < MA_DLG_HASH_SIZE; i++)
#endif
   {
      if (s->maDlgTbl[i] == (MaDlgCp *)NULLP)
         continue;
      else
      {
         for(d=s->maDlgTbl[i]; d != (MaDlgCp *)NULLP;)
         {
            s->curDlgCp = d;
            txDlgEv.pres = FALSE;
            maAbrtDlg(s, &txDlgEv, MAT_P_ABNORMAL_DLG); 
            d = d->next;
            maDlgIdle(s);
         }
      s->maDlgTbl[i] = (MaDlgCp *)NULLP;   
      }
   }
   RETVOID;
} /* end of maFreeAllDlg */

#ifdef ZJ
/*
*
*       Fun:    maForcedFreeAllDlg
*
*       Desc:   Finds given string in maSap non-destructively returns dialog
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC Void maForcedFreeAllDlg
(
MaSap *s                        /* current sap */
)
#else
PUBLIC Void maForcedFreeAllDlg(s)
MaSap *s;                        /* current sap */
#endif
{
/* ma012.203: Modified the "i" data type to support  higher values */
   U32 i;
   MaDlgCp *d;
   StDlgEv txDlgEv;
   
   TRC2(maForcedFreeAllDlg)
/* ma012.203: Added, to support the Dlg Hash Size */
#ifdef MAP_NSRP
   for (i = 0; i < s->dlgHshSize; i++)
#else
   for (i = 0; i < MA_DLG_HASH_SIZE; i++)
#endif /* MAP_NSRP */
   {
      if (s->maDlgTbl[i] == (MaDlgCp *)NULLP)
         continue;
      else
      {
         for(d=s->maDlgTbl[i]; d != (MaDlgCp *)NULLP;)
         {
            s->curDlgCp = d;
            txDlgEv.pres = FALSE;
            d = d->next;
            maDlgIdle(s);
         }
      s->maDlgTbl[i] = (MaDlgCp *)NULLP;   
      }
   }
   RETVOID;
} /* end of maForcedFreeAllDlg */
#endif

/*
*
*       Fun:   maStartTmr
*
*       Desc:  start control block timer
*
*       Ret:    RETVOID
*
*       Notes: None
*
*       File:  ca_bdy2.c
*
*/

#ifdef ANSI
PUBLIC Void maStartTmr
(
S16   tmrEvnt,      /* timer Event */
MaSap *s,           /* Ma sap */
MaCmpCp *cmpCp      /* component control point */
)
#else
PUBLIC Void maStartTmr(tmrEvnt,s,cmpCp)
S16 tmrEvnt;         /* timer Event */
MaSap *s;            /* Ma sap */
MaCmpCp *cmpCp;      /* component control point */
#endif
{
  CmTmrArg maTmrArg;
  U16 wait = 0;

   TRC2(maStartTmr)
   if((tmrEvnt == MA_GAURD_TMR) && 
      (s->cfg.maGrdTmr.enb == TRUE) )
   {
      wait = s->cfg.maGrdTmr.val;
   }
   else  if(tmrEvnt == MA_TINT_TMR)
   {
      if( s->cfg.tIntTmr.enb == TRUE)
      {
         wait = s->cfg.tIntTmr.val;
      }
      if(!wait)
      {
         wait = MA_TINT_TMRVAL;
      }
   }
   if (wait != 0)
   {
 
      
      maTmrArg.tqCp   = &maCb.maTqCp;
      maTmrArg.tq     = maCb.maTq;
      maTmrArg.max    = MA_MAX_TMRS;
      if(tmrEvnt == MA_GAURD_TMR)
      {
         maTmrArg.timers = cmpCp->timers;
         maTmrArg.cb     = (PTR)cmpCp;
      }
      else
      {
         maTmrArg.timers = s->timers;
         maTmrArg.cb     = (PTR)s;
      }
      maTmrArg.tNum   = 0;
      maTmrArg.evnt   = (U8)tmrEvnt;
      maTmrArg.wait   = wait;
      
      cmPlcCbTq(&maTmrArg);
   }
   RETVOID;
} /* end of maStartTmr */

/*
*
*       Fun:   maTmrEvnt    
*
*       Desc:  This function  handles the gaurd timer expiry 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maTmrEvnt 
(
PTR  cmpCp,
S16  evnt
)
#else
PUBLIC S16 maTmrEvnt (cmpCp, evnt)
PTR  cmpCp;
S16  evnt;
#endif
{
 MaSap *s;
 MaDlgCp *dlgCp;

 TRC2(maTmrEvnt)

 switch(evnt)
 {
    case MA_GAURD_TMR: 
       s = ((MaCmpCp *)cmpCp)->sap;
       dlgCp = maFindHashDlg(s, ((MaCmpCp *)cmpCp)->spDlgId);
#if (ERRCLASS & ERRCLS_DEBUG)
       if (dlgCp == (MaDlgCp *)NULLP)
       {
          MALOGERROR(ERRCLS_DEBUG, EMA159, (ErrVal)0, "maTmrEvnt() No dialogue CP");
       }
#endif
       /* return the ssm state to idle */
       maInvkIdle(dlgCp, (MaCmpCp *)cmpCp);
       MaUiMatNotInd (&s->maPstMU, s->suId, dlgCp->suDlgId,
               dlgCp->spDlgId, MAT_GAURD_TMR_EXPIRED);
       break;
    case MA_TINT_TMR:  
       s = (MaSap *)cmpCp;
       if(s->maState == MA_BND_WAIT_BNDCFM &&
         (s->bndRetryCnt < MA_MAX_INTRETRY))
       {
          /* bind service provider */
          /* issue bind request again */
          MaLiStuBndReq(&s->maPstST, s->sapId, s->spIdTC, s->ssn);
          s->bndRetryCnt++;
          maStartTmr(MA_TINT_TMR,s,(MaCmpCp *)NULLP);
       }
       else
       {
          maSendAlrm(NEW,s->suId,MA_UNUSED,MA_UNUSED,MA_UNUSED,
          LCM_EVENT_BND_FAIL,LCM_CATEGORY_INTERFACE,LCM_CAUSE_UNKNOWN);
          s->liState = MA_BND_DISABLED;
          s->maState = MA_BND_DISABLED;
          s->bndRetryCnt = 0;
       }
       break;
    default:
       break;
 }
 RETVALUE(ROK);
} /* maTmrEvnt  */


/*
*
*       Fun:   maStopTmr
*
*       Desc:  start control block timer
*
*       Ret:    RETVOID
*
*       Notes: None
*
*       File:  ca_bdy2.c
*
*/

#ifdef ANSI
PUBLIC Void maStopTmr
(
S16 tmrEvnt,         /* timer event */
MaSap *s,            /* sap structure */
MaCmpCp *cmpCp       /* Component control point */
)
#else
PUBLIC Void maStopTmr(tmrEvnt, s,cmpCp)
S16 tmrEvnt;         /* timer event */
MaSap *s;            /* sap structure */
MaCmpCp *cmpCp;      /* component control point */
#endif
{
   U8 tmrNum;
   S16 tmrEvnt1;
   CmTmrArg maTmrArg;

   TRC2(maStopTmr)
   for(tmrNum=0;tmrNum < MA_MAX_TMRS;tmrNum++)
   {
      if(tmrEvnt == MA_GAURD_TMR)
      {
         tmrEvnt1 = cmpCp->timers[tmrNum].tmrEvnt;
      }
      else
      { 
         tmrEvnt1 = s->timers[tmrNum].tmrEvnt;
      }
      if (tmrEvnt1 == tmrEvnt)
      {
             maTmrArg.tqCp   = &maCb.maTqCp;
             maTmrArg.tq     = maCb.maTq;
         if(tmrEvnt == MA_GAURD_TMR)
         {
                maTmrArg.timers = cmpCp->timers;
                maTmrArg.cb     = (PTR)cmpCp;
         }
         else
         {
                maTmrArg.timers = s->timers;
                maTmrArg.cb     = (PTR)s;
         }
         maTmrArg.evnt   = (U8)tmrEvnt;
         maTmrArg.wait   = 0;
         maTmrArg.tNum   = tmrNum;
         maTmrArg.max    = MA_MAX_TMRS;
         cmRmvCbTq(&maTmrArg);
      }
    }
   RETVOID;

} /* end of maStopTmr */


/*
*
*       Fun:   maZeroSts    
*
*       Desc:  This function initializes the Statistics to zero 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maZeroSts 
(
MaSap *s
)
#else
PUBLIC S16 maZeroSts (s)
MaSap *s;
#endif
{
   TRC2(maZeroSts)

   cmZero((Data *) &s->sts, sizeof(MaMAUSts));
#if MAP_REL99
#if (MAP_SEC && LMAV2)
   cmZero((Data *) &s->secSts, sizeof(LmaSecSapSts));
#endif
#endif

   RETVALUE(ROK);

} /* maZeroSts  */

/*
*
*       Fun:   maUpdatRxSts    
*
*       Desc:  This function updates the Statistics for service specific 
               requests and responses received.
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE Void maUpdatRxSts 
(
MaSap  *s,              /* MAP Sap */
U8     oprType,         /* Operation to be encoded */
U8     type             /* Request or Response */
)
#else
PRIVATE Void maUpdatRxSts (s,oprType, type)
MaSap  *s;              /* MAP Sap */
U8     oprType;         /* Operation to be encoded */
U8     type;            /* Request or Response */
#endif
{
  TRC2(maUpdatRxSts)
  switch (oprType)
  {
#ifdef XWEXT
   case MAT_PAGING_DETECT:
     if (type == MAT_SS_REQ)
     {
       s->sts.detectReqRx++;
     }
     else
     {
       s->sts.detectRspRx++;
     }
     break;
#endif
#if (MAP_VLR || MAP_HLR)
   case MAT_REGSS:
     if (type == MAT_SS_REQ)
     {
       s->sts.regSSReqRx++;
     }
     else
     {
       s->sts.regSSRspRx++;
     }
     break;
   case MAT_ERASESS:
     if (type == MAT_SS_REQ)
     {
       s->sts.eraseSSReqRx++;

     }
     else
     {
       s->sts.eraseSSRspRx++;
     }
     break;
   case MAT_ACTVSS:
     if (type == MAT_SS_REQ)
     {
       s->sts.actvSSReqRx++;

     }
     else
     {
       s->sts.actvSSRspRx++;
     }
     break;
   case MAT_DACTVSS:
     if (type == MAT_SS_REQ)
     {
       s->sts.dactvSSReqRx++;
     }
     else
     {
       s->sts.dactvSSRspRx++;
     }
     break;
   case MAT_INTERSS:
     if (type == MAT_SS_REQ)
     {
       s->sts.interSSReqRx++;
     }
     else
     {
       s->sts.interSSRspRx++;
     }
     break;
   case MAT_REGPASSWD:
     if (type == MAT_SS_REQ)
     {
       s->sts.regPasswdReqRx++;
     }
     else
     {
       s->sts.regPasswdRspRx++;
     }
     break;
   case MAT_GETPASSWD:
     if (type == MAT_SS_REQ)
     {
       s->sts.getPasswdReqRx++;
     }
     else
     {
       s->sts.getPasswdRspRx++;
     }
     break;
   case MAT_PROCUSSREQ:
     if (type == MAT_SS_REQ)
     {
       s->sts.procUSSReqRx++;
     }
     else
     {
       s->sts.procUSSRspRx++;
     }
     break;
   case MAT_PROCUSSDATA:
     if (type == MAT_SS_REQ)
     {
       s->sts.procUSSDatReqRx++;
     }
     else
     {
       s->sts.procUSSDatRspRx++;
     }
     break;
   case MAT_USSREQ:
     if (type == MAT_SS_REQ)
     {
       s->sts.ussReqRx++;
     }
     else
     {
       s->sts.ussRspRx++;
     }
     break;
   case MAT_USSNOTIFY:
     if (type == MAT_SS_REQ)
     {
       s->sts.ussNotReqRx++;
     }
     else
     {
       s->sts.ussNotRspRx++;
     }
     break;
#endif /* VLR || HLR */

#if (MAP_VLR || MAP_HLR)
   case MAT_FWDCHKSSIND:
     s->sts.fwdChkSSIndReqRx++;
     break;
#endif /* VLR || HLR */

#if MAP_MSC
   case MAT_DET_IMSI:
     s->sts.detIMSIReqRx++;
     break;
   case MAT_TRACESUBSACTV:
     s->sts.trSubReqRx++;
     break;
#endif   /* MSC */

#if (MAP_MSC || MAP_HLR)
   case MAT_ROUTINFO:
     if (type == MAT_SS_REQ)
     {
       s->sts.routInfoReqRx++;
     }
     else
     {
       s->sts.routInfoRspRx++;
     }
     break;
   case MAT_ROUTINFOSM:
     if (type == MAT_SS_REQ)
     {
       s->sts.routInfoSMReqRx++;
     }
     else
     {
       s->sts.routInfoSMRspRx++;
     }
     break;
   case MAT_SMDEL:
     if (type == MAT_SS_REQ)
     {
       s->sts.smDelReqRx++;
     }
     else
     {
       s->sts.smDelRspRx++;
     }
     break;
   case MAT_ALRTSC:
     if (type == MAT_SS_REQ)
     {
       s->sts.alrtSCReqRx++;
     }
     else
     {
       s->sts.alrtSCRspRx++;
     }
     break;
   case MAT_ALRTSCWRSLT:
     s->sts.alrtSCWRsltReqRx++;
     break;
   case MAT_INFSC:
     s->sts.infSCReqRx++;
     break;
#endif  /* MSC || HLR */

#if (MAP_VLR || MAP_HLR)
   case MAT_UPLOC:
     if (type == MAT_SS_REQ)
     {
       s->sts.upLocReqRx++;
     }
     else
     {
       s->sts.upLocRspRx++;
     }
     break;
#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_SNDPARAM:
     if (type == MAT_SS_REQ)
     {
       s->sts.sndParamReqRx++;
     }
     else
     {
       s->sts.sndParamRspRx++;
     }
     break;
#if (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5))
   case MAT_PROVSUBSINFO:
     if (type == MAT_SS_REQ)
     {
        s->sts.provSubsInfoReqRx++;     /*prov Subs Info req Rx */
     }
     else
     {
        s->sts.provSubsInfoRspRx++;     /*prov Subs Info rsp Rx */
     }
     break;
#endif /* (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5)) */

#if MAP_REL99

  /* Note MM event */
  case MAT_NOTE_MMEVT:
     if (type == MAT_SS_REQ)
     {
        s->sts.notMmEvReqRx++;     /* req Rx */
     }
     else
     {
        s->sts.notMmEvRspRx++;     /* rsp Rx */
     }
     break;

#endif /* MAP_REL99 */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR)
   case MAT_RESTOREDATA:
     if (type == MAT_SS_REQ)
     {
       s->sts.restoreReqRx++;
     }
     else
     {
       s->sts.restoreRspRx++;
     }
     break;
   case MAT_SNDIMSI:
     if (type == MAT_SS_REQ)
     {
       s->sts.sndIMSIReqRx++;
     }
     else
     {
       s->sts.sndIMSIRspRx++;
     }
     break;

   case MAT_NOTSUBPRES:
     s->sts.notSubPresReqRx++;
     break;

   case MAT_BEGIN_SUBS_ACTV:
     s->sts.bgnSubActvReqRx++;
     break;
   case MAT_PROVROAMNMB:
     if (type == MAT_SS_REQ)
     {
       s->sts.provRoamNmbReqRx++;
     }
     else
     {
       s->sts.provRoamNmbRspRx++;
     }
     break;

   case MAT_SETRPTSTATE:
     if (type == MAT_SS_REQ)
     {
        s->sts.setRptStateReqRx++;     /* req Rx */
     }
     else
     {
        s->sts.setRptStateRspRx++;     /* rsp Rx */
     }
     break;

   case MAT_RMTUSRFREE:
     if (type == MAT_SS_REQ)
     {
        s->sts.rmtUsrFreeReqRx++;     /* req Rx */
     }
     else
     {
        s->sts.rmtUsrFreeRspRx++;     /* rsp Rx */
     }
     break;

   case MAT_STARPT:
     if (type == MA_SS_REQ)
     {
        s->sts.staRptReqRx++;     /*   req Rx */
     }
     else
     {
        s->sts.staRptRspRx++;     /*   rsp Rx */
     }
     break;

#endif  /* (VLR) || (HLR) */

#if (MAP_VLR || MAP_HLR)
   case MAT_REGCCENT:
     if (type == MAT_SS_REQ)
     {
        s->sts.regCcEntReqRx++;     /*reg Cc Ent req Rx */
     }
     else
     {
        s->sts.regCcEntRspRx++;     /*reg Cc Ent rsp Rx */
     }
     break;

   case MAT_ERASECCENT:
     if (type == MAT_SS_REQ)
     {
        s->sts.eraseCcEntReqRx++;     /*erase Cc Ent req Rx */
     }
     else
     {
        s->sts.eraseCcEntRspRx++;     /*erase Cc Ent rsp Rx */
     }
     break;

#endif /* VLR || HLR */

#if MAP_MSC
   case MAT_PRE_HO:
     if (type == MAT_SS_REQ)
     {
       s->sts.preHoReqRx++;
     }
     else
     {
       s->sts.preHoRspRx++;
     }
     break;
   case MAT_PER_HO:
     if (type == MAT_SS_REQ)
     {
       s->sts.perHoReqRx++;
     }
     else
     {
       s->sts.perHoRspRx++;
     }
     break;
   case MAT_SNDENDSIG:
     if (type == MAT_SS_REQ)
     {
        s->sts.sndEndSigReqRx++;
     }
     else
     {
        s->sts.sndEndSigRspRx++;
     }
     break;
   case MAT_PROCACCSIG:
     s->sts.procAccSigReqRx++;
     break;
   case MAT_FWDACCSIG:
     s->sts.fwdAccSigReqRx++;
     break;
   case MAT_PRE_SUBSHO:
     if (type == MAT_SS_REQ)
     {
       s->sts.preSubHoReqRx++;
     }
     else
     {
       s->sts.preSubHoRspRx++;
     }
     break;
   case MAT_PER_SUBSHO:
     if (type == MAT_SS_REQ)
     {
       s->sts.perSubHoReqRx++;
     }
     else
     {
       s->sts.perSubHoRspRx++;
     }
     break;
   case MAT_NOTEINTERHO:
     s->sts.notInterHoReqRx++;
     break;
   case MAT_PREP_GRPCALL:
     if (type == MAT_SS_REQ)
     {
        s->sts.prepGrpCallReqRx++;     /* Prepare Grp call req Rx */
     }
     else
     {
        s->sts.prepGrpCallRspRx++;     /*  Prepare Grp call rsp Rx */
     }
     break;


   case MAT_PROV_SIWFS_NMB:
     if (type == MAT_SS_REQ)
     {
        s->sts.provSiwfsNmbReqRx++;     /* prov Siwfs Nmb req Rx */
     }
     else
     {
        s->sts.provSiwfsNmbRspRx++;     /* prov Siwfs Nmb rsp Rx */
     }
     break;

   case MAT_SIWFS_SIGMOD:
     if (type == MAT_SS_REQ)
     {
        s->sts.siwfsSigModReqRx++;     /*  siwfs Sig Mod req Rx */
     }
     else
     {
        s->sts.siwfsSigModRspRx++;     /*  siwfs Sig Mod rsp Rx */
     }
     break;

   case MAT_RESCALLHANDL:
     if (type == MAT_SS_REQ)
     {
        s->sts.resCallHandlReqRx++;     /*  siwfs Sig Mod req Rx */
     }
     else
     {
        s->sts.resCallHandlRspRx++;     /*  siwfs Sig Mod rsp Rx */
     }
      break;
   case MAT_PRO_GRPCALLSIG:
      s->sts.proGrpCallSigReqRx++;     /* Pro Grp Call Sig  req Rx */
      break;
   case MAT_FWD_GRPCALLSIG:
      s->sts.fwdGrpCallSigReqRx++;     /* Fwd Grp Call Sig req Rx */
      break;
   case MAT_SND_GRPCALLENDSIG:
     if (type == MAT_SS_REQ)
     {
       s->sts.sndGrpCallEndSigReqRx++;
     }
     else
     {
       s->sts.sndGrpCallEndSigRspRx++;
     }
      break;

#endif  /* MSC */

#if MAP_VLR
  /* Send Identification Request */
   case MAT_SNDID:
     if (type == MAT_SS_REQ)
     {
       s->sts.sndIdReqRx++;
     }
     else
     {
       s->sts.sndIdRspRx++;
     }
     break;
#endif  /* MAP_VLR */

#if (MAP_MSC || MAP_HLR)
   case MAT_SSINV_NOTIFY:
      if (type == MA_SS_REQ)
      {
         s->sts.ssInvNotReqRx++;     /*  ss Inv Not req Rx */
      }
      else
      {
         s->sts.ssInvNotRspRx++;     /*  ss Inv Not rsp Rx */
      }
      break;
#if MAP_REL99

  case MAT_IST_ALERT:
     if (type == MAT_SS_REQ)
     {
        s->sts.istAlrtReqRx++;     /* any Inter req Rx */
     }
     else
     {
        s->sts.istAlrtRspRx++;     /* any Inter rsp Rx */
     }
     break;
  case MAT_IST_COMMAND:
     if (type == MAT_SS_REQ)
     {
        s->sts.istCmdReqRx++;     /* any Inter req Rx */
     }
     else
     {
        s->sts.istCmdRspRx++;     /* any Inter rsp Rx */
     }
     break;

#endif /* MAP_REL99 */

#endif 

/* Release Resources */
#if MAP_MSC
#if MAP_REL6
  case MAT_REL_RES:
     if (type == MAT_SS_REQ)
     {
        s->sts.relResReqRx++;     /* any Inter req Rx */
     }
     else
     {
        s->sts.relResRspRx++;     /* any Inter rsp Rx */
     }
    break;
#endif /* MAP_REL6 */
#endif /* MAP_MSC */

#if (MAP_HLR || MAP_MLC)
   case MAT_ANY_INTER:
     if (type == MAT_SS_REQ)
     {
        s->sts.anyInterReqRx++;     /* any Inter req Rx */
     }
     else
     {
        s->sts.anyInterRspRx++;     /* any Inter rsp Rx */
     }
     break;

#endif /* MAP_HLR || MAP_MLC */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_SMRDY:
     if (type == MA_SS_REQ)
     {
        s->sts.smRdyReqRx++;
     }
     else
     {
        s->sts.smRdyRspRx++;
     }
     break;
#endif

#if (MAP_MSC || MAP_VLR || MAP_GSN)
   case MAT_CHKIMEI:
     if (type == MAT_SS_REQ)
     {
       s->sts.chkIMEIReqRx++;
     }
     else
     {
       s->sts.chkIMEIRspRx++;
     }
     break;
#endif

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_CANCELLOC:
     if (type == MAT_SS_REQ)
     {
       s->sts.canLocReqRx++;
     }
     else
     {
       s->sts.canLocRspRx++;
     }
     break;
   case MAT_PURGE:
     if (type == MAT_SS_REQ)
     {
       s->sts.purgMsReqRx++;
     }
     else
     {
       s->sts.purgMsRspRx++;
     }
     break;
     
   case MAT_AUTHINFO:
     if (type == MAT_SS_REQ)
     {
       s->sts.authInfReqRx++;
     }
     else
     {
       s->sts.authInfRspRx++;
     }
     break;
   case MAT_INSSUBSDATA:
     if (type == MAT_SS_REQ)
     {
       s->sts.insSubReqRx++;
     }
     else
     {
       s->sts.insSubRspRx++;
     }
     break;
   case MAT_DELSUBSDATA:
     if (type == MAT_SS_REQ)
     {
       s->sts.delSubReqRx++;
     }
     else
     {
       s->sts.delSubRspRx++;
     }
     break;
   case MAT_RESET:
     s->sts.resetReqRx++;
     break;
   case MAT_ACTVTRACE:
     if (type == MAT_SS_REQ)
     {
       s->sts.actvTrReqRx++;
     }
     else
     {
       s->sts.actvTrRspRx++;
     }
     break;
   case MAT_DACTVTRACE:
     if (type == MAT_SS_REQ)
     {
       s->sts.dactvTrReqRx++;
     }
     else
     {
       s->sts.dactvTrRspRx++;
     }
     break;

#if MAP_REL99

   case MAT_AUTHFAILRPT:
     if (type == MAT_SS_REQ)
     {
       s->sts.authFailRptReqRx++;
     }
     else
     {
       s->sts.authFailRptRspRx++;
     }

     break;

#endif /* MAP_REL99 */

#endif

#if (MAP_MSC || MAP_GSN)
   case MAT_FWDSM:
     if(type  == MAT_SS_REQ)
     {
        s->sts.fwdSMReqRx++;
     }
     else
     {
        s->sts.fwdSMRspRx++; /* mt Forward SM rsp Received */
     }
     break;

   case MAT_MT_FWDSM:
     if (type == MAT_SS_REQ)
     {
        s->sts.mtFwdSMReqRx++;  /* mt Forward SM request Received */
     }
     else
     {
        s->sts.mtFwdSMRspRx++; /* mt Forward SM rsp Received */
     }
     break;

#endif

#if (MAP_HLR || MAP_GSN)
   case MAT_GPRS_UPLOC:
     if (type == MAT_SS_REQ)
     {
        s->sts.gprsUpLocReqRx++;     /* Gprs Up. Loc req Rx */
     }
     else
     {
        s->sts.gprsUpLocRspRx++;     /* Gprs Up. Loc rsp Rx */
     }
     break;

   case MAT_GPRS_ROUTINFO:
     if (type == MAT_SS_REQ)
     {
        s->sts.gprsRoutInfoReqRx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->sts.gprsRoutInfoRspRx++;  /* Gprs Rout Info rsp Rx */
     }
     break;
   case MAT_FAILRPT:
     if (type == MA_SS_REQ)
     {
        s->sts.failRptReqRx++;     /* Fail Rpt  req Rx */
     }
     else
     {
        s->sts.failRptRspRx++;     /* Fail Rpt  rsp Rx */
     }
     break;
   case MAT_GPRS_NOTEMSPRES:
     if (type == MA_SS_REQ)
     {
        s->sts.gprsNoteMsPresReqRx++;     /* Gprs Note Ms Pres  req Rx */
     }
     else
     {
        s->sts.gprsNoteMsPresRspRx++;     /* Gprs Note Ms Pres  rsp Rx */
     }
     break;
   
#endif

#if (MAP_REL98 || MAP_REL99)

#if (MAP_HLR || MAP_MLC)
   case MAT_SENDROUTINFOFORLCS:
     if (type == MAT_SS_REQ)
     {
        s->sts.lcsSndRoutInfoReqRx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->sts.lcsSndRoutInfoRspRx++;  /* Gprs Rout Info rsp Rx */
     }

     break;
#endif /* MAP_HLR || MAP_MLC */

#endif /* MAP_REL98 || MAP_REL99 */

#if (MAP_REL98 || MAP_REL99)

#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL4 && MAP_GSN))
   case MAT_PROVSUBSLOC:
     if (type == MAT_SS_REQ)
     {
        s->sts.provSubsLocReqRx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->sts.provSubsLocRspRx++;  /* Gprs Rout Info rsp Rx */
     }

     break;
   case MAT_SUBSLOCRPT:
     if (type == MAT_SS_REQ)
     {
        s->sts.subsLocReqRx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->sts.subsLocRspRx++;  /* Gprs Rout Info rsp Rx */
     }

     break;
#endif
#endif
#endif /* (MAP_REL98 || MAP_REL99) */

#if MAP_REL99
#if MAP_HLR
   case MAT_ANY_SUBSDATA_INTER:
     if (type == MAT_SS_REQ)
     {
        s->sts.anySubsInterReqRx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->sts.anySubsInterRspRx++;  /* Gprs Rout Info rsp Rx */
     }

     break;
   case MAT_ANY_MOD:
     if (type == MAT_SS_REQ)
     {
        s->sts.anyModReqRx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->sts.anyModRspRx++;  /* Gprs Rout Info rsp Rx */
     }

     break;
   case MAT_NOTE_SUBSDATA_MOD:
     if (type == MAT_SS_REQ)
     {
        s->sts.notSubsModReqRx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->sts.notSubsModRspRx++;  /* Gprs Rout Info rsp Rx */
     }

     break;
#endif /* MAP_HLR */

#endif /* MAP_REL99 */

   default:
#if (ERRCLASS & ERRCLS_DEBUG)
     MALOGERROR(ERRCLS_DEBUG, EMA160, (ErrVal)oprType, "maUpdatRxSts () bad opr type");
#endif
     break;
  }
} /* maUpdatRxSts */

/*
*
*       Fun:   maBZero    
*
*       Desc:  This function  initializes the memory to zero
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maBZero 
(
U8  *ptr,
U32 len
)
#else
PUBLIC S16 maBZero (ptr, len)
U8  *ptr;
U32 len;
#endif
{

/* ma008.203 : To Improve the MAP Stack performance  
               replacing maBZero with cmZero;
               which internally call direct system call(memset()) if
                not enable "DONT_USE_SYS_LIB" flag.
*/

#ifdef  MA_IMPR_PER
  U32   i;
  U8    *tmpPtr;

  TRC2(maBZero)

  tmpPtr = ptr;
  for (i=0; i< len; i++, tmpPtr++)
    *tmpPtr = 0;
#else
  cmZero((Data*)ptr, (Size)len);
#endif
  RETVALUE(ROK);
} /* maBZero  */

  
/*
*
*       Fun:   Encode a trace information
*
*       Desc:  Encodes trace indication.  
*
*       Ret:   NONE              
*
*       Notes: None
*
*       File:  ca_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void maGenTrc
(
MaSap    *sap,
U16      event,
Buffer   *mBuf
)
#else
PUBLIC Void maGenTrc(sap, event, mBuf)
MaSap    *sap;
U16      event;
Buffer   *mBuf;
#endif
{
   MaMngmt    trc;                      
   MsgLen     msgLen;
   S16        ret;
   U16         i;
  
   TRC2(maGenTrc)

   if (mBuf == NULLP)
   {
      RETVOID;
   }

#ifdef MA_RUG
   /* If general configuration not done the smPst is *
    * not valid and we cant generate any alarms      */
   if (maCb.maInit.cfgDone == FALSE)
   {
      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
             "General configuration not done, no alarms can be generated\n"));
      RETVOID;
   }       
#endif /* MA_RUG */
   trc.hdr.msgLen     = 0;            /* optional - message length */
   trc.hdr.version    = 0;            /* optional - version */
   trc.hdr.seqNmb     = 0;            /* optional - sequence number */
   trc.hdr.msgType    = TTRC;         /* message type */
   trc.hdr.entId.ent  = maCb.maInit.ent;   /* entity id */
   trc.hdr.entId.inst = maCb.maInit.inst;  /* instance id */
   trc.hdr.transId = 0;                             /* transaction id */
   cmZero((Data *)&trc.hdr.response, sizeof(Resp)); /* Response */

   /* SAP where event occured */
   trc.hdr.elmId.elmnt      = STMATSAP;     /* SAP type */
   trc.hdr.elmId.elmntInst1 = sap->sapId;    /* SAP number */
   trc.hdr.elmId.elmntInst2 = 0;       /* optional - element instance */
   trc.hdr.elmId.elmntInst3 = 0;       /* optional - element instance */

   /* event */
   trc.t.trc.evnt = event;           /* event to be traced */
   for (i = 0; i < LMA_MAX_TRC_LEN; i++)          /* event parameters */
      trc.t.trc.evntParm[i] = 0;

   /* find length of message buffer */
   ret = SFndLenMsg(mBuf, &msgLen);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
     MALOGERROR(ERRCLS_DEBUG, EMA161, (ErrVal)ret, "SFndLenMsg() Failed");
     RETVOID;
   }
#endif

   /* trace upto 65535 bytes of message buffer */
   if (msgLen >= LMA_MAX_TRC_LEN)
   {
      msgLen = (LMA_MAX_TRC_LEN - 1);
   }

   for (i = 0; i < (U8) msgLen; i++)
   {
      if ((ret = SExamMsg(&trc.t.trc.evntParm[i], mBuf, i)) != ROK)
      {
         RETVOID;
      }
   } 
   /* store length of trace */
   trc.t.trc.len = (U8) msgLen;

   /* initialize date and time in trace structure */
   SGetDateTime(&trc.t.trc.dt);

   /* call management trace indication primitive */
   MaMiLmaTrcInd(&maCb.maInit.lmPst, &trc);

   RETVOID;
} /* end of maGenTrc */


/*
*
*       Fun:   Swap post structure
*
*       Desc:  Invoked  for swapping the post structure
*
*       Ret:   NONE
*
*       Notes: None
*
*       File:  ca_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void maSwapPst
(
   Pst *pst
)
#else
PUBLIC Void maSwapPst(pst)
Pst *pst;
#endif /* ANSI */
{
   Pst   tPst;
 
   TRC2(maSwapPst)

   /* copy into temprory space and swap */
   tPst.dstProcId = pst->srcProcId;
   tPst.srcProcId = pst->dstProcId;
   tPst.dstEnt    = pst->srcEnt;
   tPst.dstInst   = pst->srcInst;
   tPst.srcEnt    = pst->dstEnt;
   tPst.srcInst   = pst->dstInst;
 
   /* copy back */
   pst->dstProcId = tPst.dstProcId;
   pst->srcProcId = tPst.srcProcId;
   pst->dstEnt    = tPst.dstEnt;
   pst->dstInst   = tPst.dstInst;
   pst->srcEnt    = tPst.srcEnt;
   pst->srcInst   = tPst.srcInst;
 
   RETVOID;
 
} /* maSwapPst */

/*
*
*       Fun:   maBldOid   
*
*       Desc:  This function builds the Object Identifier 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maBldOid 
(
MaDlgCp    *dlgCp, /* Dialogue Control point */
StDlgEv    *dlgEv  /* Dialogue Event Structure */
)
#else
PRIVATE S16  maBldOid(dlgCp, dlgEv)
MaDlgCp    *dlgCp; /* Dialogue Control point */
StDlgEv    *dlgEv; /* Dialogue Event Structure */
#endif
{
   U8   *pp;                    /* position in the destination string */
   U8   *opp;                   /* original pointer in the dest. string */
   U8   *sp;                    /* position in the source string */
   U8   j = 0;                  /* index into the oid buffer */
   S8   tmpStr[5];              /* temporary string */
   U32  val;                    /* value */
   U32  mask;                   /* mask */
   S16  count;
 
   TRC2(maBldOid);

   mask = 0x7f; 
   count = dlgCp->apn.len; /* number of id's in oid */

   if (count <= 0)
   {
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                          "maBldOid() FAILED"));
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA162, (ErrVal)count, "maBldOid() invalid count");
#endif
      RETVALUE(RFAILED);
   }

   /* get the destination pointer */
   pp = &(dlgEv->apConName.string[0]);

   /* save this pointer for length calculations */
   opp = pp;

   /* get the source pointer */
   sp = &(dlgCp->apn.val[0]);


   /* encode first 2 sub-Oids
    */
   val = 40*(sp[j]) + (sp[j+1]);
   j +=2;
   count--;
   do
   {
      U8   k = 0;           /* index into the tmp string */
 
      /* trap subOid == 0 right here and continue
       */
      if (!val)
      {
         *pp++ = 0;
      }
      else
      {
         while (val)
         {
            tmpStr[k++] = (0x80 | (val & mask));
            val = (val >> 7);
         }
 
         /* for the least significant byte, reset the msb
          */
         tmpStr[0] = (tmpStr[0] & 0x7f);
 
         /* copy the encoded value to the encode buffer
          */
         while (k > 0)
         {
            *pp++ = tmpStr[k - 1];
            k--;
         }
      }
 
      count--;
      val = (sp[j++]);
   } while (count > 0);
   
   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                       "maBldOid() count = %d, j = %d, apn Length = %d \n", 
                       count, j, dlgCp->apn.len));
 
   /* fill the length now if EOC type encoding not prefferred
    */
   dlgEv->apConName.len = (pp - opp);  /* fill the length */
#if MAP_REL99
#if (MAP_SEC && LMAV2)
   if (dlgCp->mapSec == TRUE)
   {
      /* use secure transport handling Context */
      dlgEv->apConName.string[dlgEv->apConName.len-2] = MA_SEC_TRANS_HANDL_AC;
      dlgEv->apConName.string[dlgEv->apConName.len-1]  = LMA_VER3;
   }
#endif
#endif
   RETVALUE(ROK);
 
} /* maBldOid */



/*
*
*       Fun:   maAllocDlgId
*
*       Desc:  This function allocates a dialogue id for a dialogue
*
*       Ret:   pointer to memory, when successfully allocated
*              NULLP, otherwise
*
*       Notes: None
*
*       File:  ca_bdy2.c
*
*/
 
#ifdef ANSI
PUBLIC U32 maAllocDlgId
(
MaSap *maSap                 /* pointer to MAP sap */
)
#else
PUBLIC U32 maAllocDlgId(maSap)
MaSap *maSap;                /* pointer to MAP sap */
#endif
{
   U32       dlgId;      /* allocated dialogue id */
   U32       bitMapPos;  /* position of dlg id in the bitmap */
   U32       minDlgId;   /* minumum dialogue id */
   U32       maxDlgId;   /* maximum dialogue id */
   U16       octIdx;     /* octet index in the bit map */
   U8        bitIdx;     /* bit index in the octet */
   U16       idx;        /* octet index to search the octet with free bit */
   U8        bitMask;    /* to mask a single bit in the octet */

   TRC2(maAllocDlgId);

#ifdef ZJ
   if (zjCb.tuCb.cookie == CMTU_HAVE_COOKIE)
   {
      /* minumum and maximum dialogue id */
      minDlgId = maSap->cfg.stDlgId;
      maxDlgId = (maSap->cfg.stDlgId + maSap->cfg.range-1)/2;
   }
   else
   {
      /* minumum and maximum dialogue id */
      minDlgId = (maSap->cfg.stDlgId + maSap->cfg.range-1)/2 + 1;
      maxDlgId = (maSap->cfg.stDlgId + maSap->cfg.range-1);
   }
   maSap->maDlgIdPool = (maSap->maDlgIdPool<minDlgId)?minDlgId:maSap->maDlgIdPool;
   maSap->maDlgIdPool = (maSap->maDlgIdPool>maxDlgId)?minDlgId:maSap->maDlgIdPool;
#else
   /* minumum and maximum dialogue id */
   minDlgId = maSap->cfg.stDlgId;
   maxDlgId = (maSap->cfg.stDlgId + maSap->cfg.range-1);
#endif

   /* Keep the dialogue id within the configured range for dialogue id */
   if (maSap->maDlgIdPool >= maxDlgId)
   {
      maSap->maDlgIdPool = minDlgId;
   }
   else
   {
      /* increment the dialogue id pool to the next available value */
      maSap->maDlgIdPool++;
   }

   /* maDlgIdPool contains the next available dialogue id */
   dlgId  = maSap->maDlgIdPool;

   /* find the bit position in the bitmap corresponding to this dlgId */
   bitMapPos = dlgId - minDlgId;

   octIdx  = (bitMapPos >> 3);         /* octet index in the bitmap */
   bitIdx  = (bitMapPos &  0x7);         /* bit index in the octet */
   bitMask = (0x01 << bitIdx);

   /* Check if this dialogue id is free */

   if (!(maSap->bitMap.map[octIdx] & bitMask))
   {
      /* dialogue id is free, mark this dialogue id busy now */

      maSap->bitMap.map[octIdx] |= bitMask;
      RETVALUE(dlgId);
   }

   /* this dialogue id is busy, find next free dialogue id */
   idx = octIdx;  /* start searching from this index onwards */

   for (;;)
   {
      U8   curOct;  /* octet to check for free bit */

      curOct = maSap->bitMap.map[idx];

      /* check if any bit in this byte is free */

      if (curOct != 0xFF)
      {
         for (bitIdx = 0, bitMask = 0x01; bitIdx < 8; bitIdx++,bitMask <<= 1)
         {
             if (!(curOct & bitMask))
             {
                /* found a free bit, set it as used */

                maSap->bitMap.map[idx] |= bitMask;



                dlgId = (idx << 3) + bitIdx + minDlgId;

                /* it might be the extra bits in the map which are free */

                if (dlgId >= maxDlgId)
                {
                   break;
                }

                RETVALUE(dlgId);
             }

         }
        /* Control never comes here */

      } /* end if */

      /* Increment the index and wrap around if reaches the last entry */
      idx++;
      if (idx == maSap->bitMap.size)
      {
         idx = 0;
      }

      if (idx == octIdx)
      {
         /* traversed the entire bitmap without finding any free entry */
         break;
      }

   } /* end for */

   RETVALUE(0);

} /* end of maAllocDlgId */


/*
*
*       Fun:   maFreeDlgId
*
*       Desc:  This function Frees an allocated dialogue id
*
*       Ret:   pointer to memory, when successfully allocated
*              NULLP, otherwise
*
*       Notes: None
*
*       File:  ca_bdy2.c
*
*/
 
#ifdef ANSI
PUBLIC S16 maFreeDlgId
(
MaSap    *maSap,               /* pointer to MAP sap */
U32      dlgId                 /* dialogue id to be deallocated */
)
#else
PUBLIC S16 maFreeDlgId(maSap, dlgId)
MaSap   *maSap;                /* pointer to MAP sap */
U32     dlgId;                 /* pointer to MAP sap */
#endif
{
   U32       bitMapPos;  /* position of dlg id in the bitmap */
   U16       octIdx;     /* Octet index in the bit map */
   U8        bitIdx;     /* bit index in the octet */
   U8        bitMask;    /* to mask a single bit in the octet */
   U32       minDlgId;   /* minumum dialogue id */

   TRC2(maFreeDlgId)

   /* find the bit position in the bitmap corresponding to this dlgId */
/* ma013.203 : To  free correct dlgId in new active node */
   if (!((dlgId >= maSap->cfg.stDlgId) &&
                 (dlgId < (maSap->cfg.stDlgId + maSap->cfg.range))))
   {
      /* invalid dialogue Id to be freed */
      maSendAlrm(NEW,maSap->sapId, MA_UNUSED, MA_UNUSED, NULLP,
                 LMA_EVENT_ALLOC_DLGID_FAIL,LCM_CATEGORY_INTERFACE,LCM_REASON_INVALID_PAR_VAL);
      
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "maFreeDlgId() failed, invalid dialog Id(%ld) to be freed.\n", dlgId));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "maFreeDlgId() failed, invalid dialog Id(%d) to be freed.\n", dlgId));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
   }
   else
   {
     bitMapPos = dlgId - maSap->cfg.stDlgId;

   }
#ifdef ZJ
   if (zjCb.tuCb.cookie == CMTU_HAVE_COOKIE)
   {
      /* minumum and maximum dialogue id */
      minDlgId = maSap->cfg.stDlgId;
   }
   else
   {
      /* minumum and maximum dialogue id */
      minDlgId = (maSap->cfg.stDlgId + maSap->cfg.range-1)/2 + 1;
   }
#else
  /* minumum and maximum dialogue id */
   minDlgId = maSap->cfg.stDlgId;
#endif
   /* find the bit position in the bitmap corresponding to this dlgId */
   bitMapPos = dlgId - minDlgId;
   octIdx  = (bitMapPos >> 3);         /* octet index in the bitmap */
   bitIdx  = (bitMapPos &  0x7);         /* bit index in the octet */
   bitMask = (0x01 << bitIdx);

   /* reset the bit to mark this dialogue id free */
   maSap->bitMap.map[octIdx] &= ~bitMask;

   RETVALUE(ROK);

 
   /* do nothing */

} /* end of maFreeDlgId */


/*
*
*       Fun:   maGetDlgId
*
*       Desc:  This function allocates a dialogue id for a dialogue.
*              Inserts dialog control point into the hash list.
*
*       Ret:   pointer to memory, when successfully allocated
*              NULLP, otherwise
*
*       Notes: None
*
*       File:  ca_bdy2.c
*
*/
 
#ifdef ANSI
PUBLIC U32 maGetDlgId
(
MaSap *maSap                 /* pointer to MAP sap */
)
#else
PUBLIC U32 maGetDlgId(maSap)
MaSap *maSap;                /* pointer to MAP sap */
#endif
{
   U32       dlgId;      /* allocated dialogue id */
   U32       minDlgId;   /* minumum dialogue id */
   U32       maxDlgId;   /* maximum dialogue id */
   MaDlgCp   *dlgCp;     /* dialogue control block */
   U32       i;

   TRC2(maGetDlgId);

#ifdef ZJ
   if (zjCb.tuCb.cookie == CMTU_HAVE_COOKIE)
   {
      if (maSap->cfg.stDlgId == 0)
      {
         /* minumum and maximum dialogue id */
         minDlgId = 1;
         maxDlgId = MA_MAX_DLG_ID/2;
      }
      else
      {
         /* minumum and maximum dialogue id */
         minDlgId = maSap->cfg.stDlgId;
         maxDlgId = (maSap->cfg.stDlgId + maSap->cfg.range -1)/2;
      }

   }
   else
   {
      if (maSap->cfg.stDlgId == 0)
      {
         /* minumum and maximum dialogue id */
         minDlgId = MA_MAX_DLG_ID/2 + 1;
         maxDlgId = MA_MAX_DLG_ID;
      }
      else
      {
         /* minumum and maximum dialogue id */
         minDlgId = (maSap->cfg.stDlgId + maSap->cfg.range -1)/2 + 1;
         maxDlgId = (maSap->cfg.stDlgId + maSap->cfg.range -1);
      }
   }

   maSap->maDlgIdPool = (maSap->maDlgIdPool<minDlgId)?minDlgId:maSap->maDlgIdPool;
   maSap->maDlgIdPool = (maSap->maDlgIdPool>maxDlgId)?minDlgId:maSap->maDlgIdPool;

#else
   if (maSap->cfg.stDlgId == 0)
   {
      /* minumum and maximum dialogue id */
      minDlgId = 1;
      maxDlgId = MA_MAX_DLG_ID;
   }
   else
   {
      /* minumum and maximum dialogue id */
      minDlgId = maSap->cfg.stDlgId;
      maxDlgId = (maSap->cfg.stDlgId + maSap->cfg.range -1);
   }
#endif

   /* get the next available dialogue id */
   dlgId  =(maSap->maDlgIdPool==maxDlgId)?minDlgId:(maSap->maDlgIdPool+1);

   for (i = minDlgId; (i < maxDlgId); 
                       dlgId=(dlgId==maxDlgId)?minDlgId:(dlgId+1), i++)
   {
      dlgCp = maFindHashDlg(maSap, dlgId);

      if (dlgCp == (MaDlgCp *)NULLP)
      {
         RETVALUE(dlgId);
      }
   } 

   RETVALUE(0);
} /* end of maGetDlgId */

/* -------------------------------------------------------------------- */
/* Return error parameters encode/decode routines                       */
/* -------------------------------------------------------------------- */

/*
*
*       Fun:   maEncVer2PErrParam    
*
*       Desc:  This function encodes the err.code for Phase 2+.  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maEncVer2PErrParam 
(
MaSap    *s,       /* Pointer to the Sap */
MaUsrErr *usrErr,  /* Error Structure    */
U8       encType,  /* Encode Type        */
U8       maVer     /* Map Version        */
)
#else
PUBLIC S16 maEncVer2PErrParam (s, usrErr,encType,maVer)
MaSap    *s;       /* Pointer to the Sap */
MaUsrErr *usrErr;  /* Error Structure    */
U8       encType;  /* Encode Type        */
U8       maVer;    /* Map Version        */
#endif
{
  S16        ret;  /* return value */
  MaRetErr   *evt; /* return error event structure */

  TRC2(maEncVer2PErrParam)

  ret = ROK;
  evt = &usrErr->retErr;

  /* encode  Switch */
  switch(usrErr->errCode)
  {
     default: 
     {
        /* EncOprPar fills the mBuf for errors with parameters */
        s->ctlp.mBuf = (Buffer *)NULLP;
        break;
     }
     case MAT_ROAM_NOTALLOWED:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->roamNotAllParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_ROAM_NOT_ALL_RE);
        break;
     }

     case MAT_CALL_BARRED:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->callBarredParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_CALL_BARRED_RE);
        break;
     }

     case MAT_CUG_REJECT:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->cugRejectParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_CUG_REJECT_RE);
        break;
     }

     case MAT_SS_INCOMP_ERR:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->ssIncompCause)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_SS_INCOMP_RE);
        break;
     }

     case MAT_SS_STATUS_ERR:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->ssStatus)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_SS_ERR_STATUS_RE);
        break;
     }

     case MAT_SM_DEL_FAIL:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->smDlvyFailCause)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_SM_DLVY_FAIL_RE);
        break;
     }

     case MAT_ABS_SUBS_SM:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->absSubsSMParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_ABS_SUBS_SM_RE);
        break;
     }

     case MAT_SYS_FAILURE:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->sysFailParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_EXT_SYS_FAIL_RE);
        break;
     }

     case MAT_DATA_MISSING:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->dataMisParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_DATA_MISS_RE);
        break;
     }

     case MAT_UNX_DATA_VALUE:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->unexDataParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_UNEX_DATA_RE);
        break;
     }

     case MAT_FACILITY_NOT_SUPP:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->facNotSupParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_FAC_NOT_SUP_RE);
        break;
     }

     case MAT_OR_NOTALLOWED:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->orNotAllParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_OR_NOT_ALL_RE);
        break;
     }

     case MAT_UNK_SUBS:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->unknownSubsParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_UNKNOWN_SUBS_RE);
        break;
     }

     case MAT_NMB_CHNGD:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->numberChangedParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_NUMBER_CHANGED_RE);
        break;
     }

     case MAT_UNID_SUBS:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->unidentSubParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_UNIDENT_SUB_RE);
        break;
     }

     case MAT_ILLEGAL_SUBS:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->illegalSubsParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_ILLEGAL_SUBS_RE);
        break;
     }

     case MAT_ILLEGAL_EQP:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->illegalEqpParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_ILLEGAL_EQP_RE);
        break;
     }

     case MAT_BEAR_NOT_PROV:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->bearServNotProvParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_BEAR_SERV_NOT_PROV_RE);
        break;
     }

     case MAT_TELE_NOT_PROV:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->teleServNotProvParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_TELE_SERV_NOT_PROV_RE);
        break;
     }

     case MAT_TRC_BUFF_FULL:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->trcBufferFullParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_TRC_BUFFER_FULL_RE);
        break;
     }

     case MAT_NO_ROAM_AVAIL:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->noRoamNbParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_NO_ROAM_NB_RE);
        break;
     }

     case MAT_ABSENT_SUBS:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->absSubsParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_ABS_SUBS_RE);
        break;
     }

     case MAT_BUSY_SUBS:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->busySubsParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_BUSY_SUBS_RE);
        break;
     }

     case MAT_NOSUBS_REPLY:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->noSubsRplyParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_NO_SUBS_RPLY_RE);
        break;
     }

     case MAT_FWD_VIOL:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->fwdViolationParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_FWD_VIOLATION_RE);
        break;
     }

     case MAT_PASSWD_REG_ERR:
     {
       ret = maEncOprPar(s,(U8 *)(&(evt->pwRegFailCause)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_PW_REG_FAIL_RE);
        break;
     }

     case MAT_FWD_FAIL:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->fwdFailedParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_FWD_FAILED_RE);
        break;
     }

     case MAT_ATI_NOTALLOWED:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->atiNotAllParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_ATI_NOT_ALL_RE);
        break;
     }

     case MAT_SUBS_BUSY_MTMS:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->subBusyForMTSMSParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_SUB_BUSY_FOR_MTSMS_RE);
        break;
     }

     case MAT_MSG_WAIT_LISTFULL:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->msgWaitListFullParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_MSG_WAIT_LIST_FULL_RE);
        break;
     }

     case MAT_RSRC_LMT:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->resLmtParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_RES_LMT_RE);
        break;
     }

     case MAT_NOGRPCALLNMB_AVAIL:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->noGrpCallNbParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_NO_GRP_CALL_NB_RE);
        break;
     }

     case MAT_INCMPTBL_TERM:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->incompTermParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_INCOMP_TERM_RE);
        break;
     }

#if (MAP_REL98 || MAP_REL99)

     case MAT_UNAUTH_REQ_NET:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->unAuthReqNetParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_UNAUTH_REQ_NET_RE);
        break;
     }

     case MAT_POSITION_METH_FAIL:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->posiMethFailParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_POSI_METH_FAIL_RE);
        break;
     }

     case MAT_UNAUTH_LCSCLIENT:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->unAuthLcsClientParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_UNAUTH_LCS_CLIENT_RE);
        break;
     }

     case MAT_UNKNOWN_OR_UNREACH:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->unKwnOrUnRchLcsClientParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_UNKWN_OR_UNRCH_LCS_CLIENT_RE);
        break;
     }
#endif /* MAP_REL98 || MAP_REL99 */
#if MAP_REL99

     case MAT_TARG_COUT_GCAREA:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->targCellOutGcaParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_TARG_CELL_OUT_GCA_RE);
        break;
     }

     case MAT_ATSI_NOTALLOWED:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->atsiNotAllParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_ATSI_NOT_ALL_RE);
        break;
     }

     case MAT_ATM_NOTALLOWED:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->atmNotAllParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_ATM_NOT_ALL_RE);
        break;
     }

     case MAT_ILLEGAL_SS_OPR:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->illegalSsOprParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_ILLEGAL_SS_OPR_RE);
        break;
     }

     case MAT_SS_NOT_AVAIL:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->ssNotAvaiParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_SS_NOT_AVAI_RE);
        break;
     }

     case MAT_SS_SUBSVIOL_ERR:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->ssSubsViolationParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_SS_SUBS_VIOLATION_RE);
        break;
     }

     case MAT_INFO_NOT_AVAIL:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->infoNotAvaiParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_INFO_NOT_AVAI_RE);
        break;
     }

     case MAT_MMEVT_NOTSUPPORTED:
     {
        ret = maEncOprPar(s,(U8 *)(&(evt->mmEventNotSupParam)), maVer,
                        (U8)s->cfg.swtch, encType, MA_MI_EVENT_NOT_SUP_RE);
        break;
     }

#endif /* MAP_REL99 */

  } /* end of switch */

  if ((ret != ROK) && (s->ctlp.mBuf != NULLP))
  {
    (Void)SPutMsg(s->ctlp.mBuf);
  }
  RETVALUE(ret);

} /* maEncVer2PErrParam */


/*
*
*       Fun:   maDecVer2PErrParam    
*
*       Desc:  This function decodes the err.code for Phase 2+.  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maDecVer2PErrParam 
(
MaSap    *s,       /* Pointer to the Sap */
MaUsrErr *usrErr,  /* Error Structure    */
U8       decType,  /* decode Type        */
U8       maVer     /* Map Version        */
)
#else
PUBLIC S16 maDecVer2PErrParam (s, usrErr,decType,maVer)
MaSap    *s;       /* Pointer to the Sap */
MaUsrErr *usrErr;  /* Error Structure    */
U8       decType;  /* decode Type        */
U8       maVer;    /* Map Version        */
#endif
{
  S16        ret;  /* return value */
  MaRetErr   *evt; /* return error event structure */

  TRC2(maDecVer2PErrParam)

  ret = ROK;
  evt = &usrErr->retErr;

  /* encode  Switch */
  switch(usrErr->errCode)
  {
     case MAT_ROAM_NOTALLOWED:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->roamNotAllParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_ROAM_NOT_ALL_RE);
        break;
     }

     case MAT_CALL_BARRED:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->callBarredParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_CALL_BARRED_RE);
        break;
     }

     case MAT_CUG_REJECT:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->cugRejectParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_CUG_REJECT_RE);
        break;
     }

     case MAT_SS_INCOMP_ERR:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->ssIncompCause)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_SS_INCOMP_RE);
        break;
     }

     case MAT_SS_STATUS_ERR:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->ssStatus)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_SS_ERR_STATUS_RE);
        break;
     }

     case MAT_SM_DEL_FAIL:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->smDlvyFailCause)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_SM_DLVY_FAIL_RE);
        break;
     }

     case MAT_ABS_SUBS_SM:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->absSubsSMParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_ABS_SUBS_SM_RE);
        break;
     }

     case MAT_SYS_FAILURE:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->sysFailParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_EXT_SYS_FAIL_RE);
        break;
     }

     case MAT_DATA_MISSING:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->dataMisParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_DATA_MISS_RE);
        break;
     }

     case MAT_UNX_DATA_VALUE:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->unexDataParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_UNEX_DATA_RE);
        break;
     }

     case MAT_FACILITY_NOT_SUPP:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->facNotSupParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_FAC_NOT_SUP_RE);
        break;
     }

     case MAT_OR_NOTALLOWED:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->orNotAllParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_OR_NOT_ALL_RE);
        break;
     }

     case MAT_UNK_SUBS:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->unknownSubsParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_UNKNOWN_SUBS_RE);
        break;
     }

     case MAT_NMB_CHNGD:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->numberChangedParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_NUMBER_CHANGED_RE);
        break;
     }

     case MAT_UNID_SUBS:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->unidentSubParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_UNIDENT_SUB_RE);
        break;
     }

     case MAT_ILLEGAL_SUBS:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->illegalSubsParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_ILLEGAL_SUBS_RE);
        break;
     }

     case MAT_ILLEGAL_EQP:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->illegalEqpParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_ILLEGAL_EQP_RE);
        break;
     }

     case MAT_BEAR_NOT_PROV:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->bearServNotProvParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_BEAR_SERV_NOT_PROV_RE);
        break;
     }

     case MAT_TELE_NOT_PROV:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->teleServNotProvParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_TELE_SERV_NOT_PROV_RE);
        break;
     }

     case MAT_TRC_BUFF_FULL:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->trcBufferFullParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_TRC_BUFFER_FULL_RE);
        break;
     }

     case MAT_NO_ROAM_AVAIL:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->noRoamNbParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_NO_ROAM_NB_RE);
        break;
     }

     case MAT_ABSENT_SUBS:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->absSubsParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_ABS_SUBS_RE);
        break;
     }

     case MAT_BUSY_SUBS:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->busySubsParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_BUSY_SUBS_RE);
        break;
     }

     case MAT_NOSUBS_REPLY:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->noSubsRplyParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_NO_SUBS_RPLY_RE);
        break;
     }

     case MAT_FWD_VIOL:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->fwdViolationParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_FWD_VIOLATION_RE);
        break;
     }

     case MAT_PASSWD_REG_ERR:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->pwRegFailCause)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_PW_REG_FAIL_RE);
        break;
     }

     case MAT_FWD_FAIL:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->fwdFailedParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_FWD_FAILED_RE);
        break;
     }

     case MAT_ATI_NOTALLOWED:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->atiNotAllParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_ATI_NOT_ALL_RE);
        break;
     }

     case MAT_SUBS_BUSY_MTMS:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->subBusyForMTSMSParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_SUB_BUSY_FOR_MTSMS_RE);
        break;
     }

     case MAT_MSG_WAIT_LISTFULL:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->msgWaitListFullParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_MSG_WAIT_LIST_FULL_RE);
        break;
     }

     case MAT_RSRC_LMT:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->resLmtParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_RES_LMT_RE);
        break;
     }

     case MAT_NOGRPCALLNMB_AVAIL:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->noGrpCallNbParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_NO_GRP_CALL_NB_RE);
        break;
     }

     case MAT_INCMPTBL_TERM:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->incompTermParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_INCOMP_TERM_RE);
        break;
     }

#if (MAP_REL98 || MAP_REL99)

     case MAT_UNAUTH_REQ_NET:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->unAuthReqNetParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_UNAUTH_REQ_NET_RE);
        break;
     }

     case MAT_POSITION_METH_FAIL:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->posiMethFailParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_POSI_METH_FAIL_RE);
        break;
     }

     case MAT_UNAUTH_LCSCLIENT:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->unAuthLcsClientParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_UNAUTH_LCS_CLIENT_RE);
        break;
     }

     case MAT_UNKNOWN_OR_UNREACH:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->unKwnOrUnRchLcsClientParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_UNKWN_OR_UNRCH_LCS_CLIENT_RE);
        break;
     }
#endif /* MAP_REL98 || MAP_REL99 */
#if MAP_REL99

     case MAT_TARG_COUT_GCAREA:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->targCellOutGcaParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_TARG_CELL_OUT_GCA_RE);
        break;
     }

     case MAT_ATSI_NOTALLOWED:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->atsiNotAllParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_ATSI_NOT_ALL_RE);
        break;
     }

     case MAT_ATM_NOTALLOWED:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->atmNotAllParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_ATM_NOT_ALL_RE);
        break;
     }

     case MAT_ILLEGAL_SS_OPR:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->illegalSsOprParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_ILLEGAL_SS_OPR_RE);
        break;
     }

     case MAT_SS_NOT_AVAIL:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->ssNotAvaiParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_SS_NOT_AVAI_RE);
        break;
     }

     case MAT_SS_SUBSVIOL_ERR:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->ssSubsViolationParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_SS_SUBS_VIOLATION_RE);
        break;
     }

     case MAT_INFO_NOT_AVAIL:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->infoNotAvaiParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_INFO_NOT_AVAI_RE);
        break;
     }

     case MAT_MMEVT_NOTSUPPORTED:
     {
        ret = maDecOprPar(s,(U8 *)(&(evt->mmEventNotSupParam)), maVer,
                        (U8)s->cfg.swtch, decType, MA_MI_EVENT_NOT_SUP_RE);
        break;
     }

#endif /* MAP_REL99 */

  } /* end of switch */

  RETVALUE(ret);

} /* maDecVer2PErrParam */


/*
*
*       Fun:   maAllocWithoutInit
*
*       Desc:  This function returns a pointer to a block of at least
*              <size> bytes. The memory allocated is assumed contigous
*              from MAP software perspective.
*
*       Ret:   pointer to memory, when successfully allocated
*              NULLP, otherwise
*
*       Notes: The memory is uninitialized
*
*       File:  ca_bdy2.c
*
*/
 
#ifdef ANSI
PUBLIC Data *maAllocWithoutInit
(
Size size                    /* size */
)
#else
PUBLIC Data *maAllocWithoutInit(size)
Size size;                   /* size */
#endif
{
   Data *pData;              /* pointer to data allocated by system */

   TRC2(maAllocWithoutInit)
 
   if (size == 0)
   {
      RETVALUE(NULLP);
   }

#ifndef ALIGN_64BIT

    MADBGP(DBGMASK_SI, (maCb.maInit.prntBuf,
   "SGetSBuf(Region (%d), Pool (%d), Size (%ld))\n", 
             maCb.maInit.region, 
             maCb.maInit.pool,
             size));

#else

   MADBGP(DBGMASK_SI, (maCb.maInit.prntBuf,
   "SGetSBuf(Region (%d), Pool (%d), Size (%d))\n", 
             maCb.maInit.region, 
             maCb.maInit.pool,
             size));

#endif/*ALIGN_64BIT*/
 
   /* allocate list of pointers */
   if (SGetSBuf(maCb.maInit.region, maCb.maInit.pool, &pData, size)
         != ROK)
   {
      RETVALUE(NULLP);
   }

   maMemAlloc += size;

   RETVALUE(pData);
 
} /* end of maAllocWithoutInit */


/*
*
*       Fun:   maAlloc
*
*       Desc:  This function returns a pointer to a block of at least
*              <size> bytes. The memory allocated is assumed contigous
*              from MAP software perspective.
*
*       Ret:   pointer to memory, when successfully allocated
*              NULLP, otherwise
*
*       Notes: None
*
*       File:  ca_bdy2.c
*
*/
 
#ifdef ANSI
PUBLIC Data *maAlloc
(
Size size                    /* size */
)
#else
PUBLIC Data *maAlloc(size)
Size size;                   /* size */
#endif
{
   Data *pData;              /* pointer to data allocated by system */

   TRC2(maAlloc)
 
   if (size == 0)
   {
      RETVALUE(NULLP);
   }

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_SI, (maCb.maInit.prntBuf,
   "SGetSBuf(Region (%d), Pool (%d), Size (%ld))\n", 
             maCb.maInit.region, 
             maCb.maInit.pool,
             size));

#else

   MADBGP(DBGMASK_SI, (maCb.maInit.prntBuf,
   "SGetSBuf(Region (%d), Pool (%d), Size (%d))\n", 
             maCb.maInit.region, 
             maCb.maInit.pool,
             size));

#endif/*ALIGN_64BIT*/
 
   /* allocate list of pointers */
   if (SGetSBuf(maCb.maInit.region, maCb.maInit.pool, &pData, size)
         != ROK)
   {
      RETVALUE(NULLP);
   }

   /* zero out the allocated memory */
   cmZero(pData, size);

   maMemAlloc += size;

   RETVALUE(pData);
 
} /* end of maAlloc */


/*
*
*       Fun:   maFree
*
*       Desc:  The argument to maFree() is a pointer to a block
*              previously allocated by maAlloc().  After maFree()
*              is performed this space is made available for further
*              allocation.
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  ca_bdy2.c
*
*/
 
#ifdef ANSI
PUBLIC Void maFree
(
Data *data,         /* pointer to data */
Size size           /* size */
)
#else
PUBLIC Void maFree(data, size)
Data *data;         /* pointer to data */
Size size;          /* size */
#endif
{
   TRC2(maFree)
 
   if ((data == NULLP) || (size == 0))
   {
      RETVOID;
   }

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_SI, (maCb.maInit.prntBuf,
   "SPutSBuf(Region (%d), Pool (%d), Size (%ld), Data (0x%lx))\n",
             maCb.maInit.region, 
             maCb.maInit.pool,
             size,
             (PTR) data));

#else

   MADBGP(DBGMASK_SI, (maCb.maInit.prntBuf,
   "SPutSBuf(Region (%d), Pool (%d), Size (%d), Data (0x%lx))\n",
             maCb.maInit.region, 
             maCb.maInit.pool,
             size,
             (PTR) data));

#endif/*ALIGN_64BIT*/
 
   maMemFree += size;

   (Void) SPutSBuf(maCb.maInit.region,
                   maCb.maInit.pool,
                   data,
                   size);
 
   RETVOID;

} /* end of maFree */
 


/*
*
*       Fun:   Remove a sap
*
*       Desc:  Remove a sap and free all associated memory
*
*       Ret:   ROK      - success
*              RFAILED  - failed
*
*       Notes:
*
*       File:  ca_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 maRemMaSap
(
S16    sapId
)
#else
PUBLIC  S16 maRemMaSap(sapId)
S16     sapId;
#endif
{
   MaSap    *maSap;        /* Pointer to the MA layer sap */
/* ma012.203: Addition, To support Dlg Hash Configuration */
#ifdef MAP_NSRP
   Pst     maPstMU;       /* To send Status Indicaiton MAP user */
   MaInvokeId invkId;     /* Place holder in Status indication with zero */
   Size  sapDlgHshSize;   /* Memroy allocated to Dlg Hash */
#endif /* MAP_NSRP */
   TRC2(maRemMaSap)

   /* get teh pointer to the MA sap */
   maSap = maCb.maSapLmaPtr[sapId];

/* ma012.203: Addition, To support Dlg Hash Configuration */
/* Compute the memory allocated for Dlg Hash size */
#ifdef MAP_NSRP
  invkId.pres=FALSE;
  invkId.octet=0;
  /* Store the Pst info before deleting the sap */
  /* to send Status Indication */
  cmCopy((U8 *)&maSap->maPstMU,(U8 *)&maPstMU, sizeof(Pst));
 /* size of the Hash Dialogue Control point list */
  sapDlgHshSize = (Size)(maSap->dlgHshSize * sizeof(MaDlgCp *));
#endif /* MAP_NSRP */


   /* stop the timer with this sap */
   (Void) maStopTmr(MA_TINT_TMR, maSap,(MaCmpCp *)NULLP);

   /* Free all the dialogues associated with this sap */
#ifdef ZJ
   /* With PSF-MAP the behaviour is modified, and all the dialogues
      are freed silently without aany messages being sent to the
      remote end. */
   maForcedFreeAllDlg(maSap);
#else
   maFreeAllDlg(maSap);
#endif

   /*
   ** Free the memory associated with the bit map ,if allocated
   */
   if(maSap->bitMap.map != NULLP)
   {
      maFree((Data *)maSap->bitMap.map, maSap->bitMap.size);
      /* compute memory available for other SAP bitmap */
      maCb.maCP.range = maCb.maCP.range + maSap->cfg.range;
   }
/* ma012.203: Addition, Deallocate memory for Dlg Hash  */
#ifdef MAP_NSRP
   if(maSap->maDlgTbl != NULLP)
   {
      maFree((Data *)maSap->maDlgTbl, sapDlgHshSize );
   }
#endif /* MAP_NSRP */
   /* Free the memory associated with this SAP */
   maFree((Data *)maSap, sizeof(MaSap));

   /* Sap list is re-initialized with NULL Pointer */
   maCb.maSapLmaPtr[sapId] = NULLP;
/* ma012.203: Addition, Status Indication to MAP user in case of Sap deletion */
#ifdef MAP_NSRP
 /*MaUiMatStatInd(&maPstMU,sapId,0,&invkId,MAT_EVTSTATIND,(Status)MA_LSAP_DEL);
   * */
 
#endif /* MAP_NSRP */
   RETVALUE(ROK);

} /* maRemMaSap */


/*
*
*       Fun:   Upper Group Sap Control Request
*
*       Desc:  This function handles the Upper Group Sap control request
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*       File:  ca_bdy2.c
*
*/
 
#ifdef ANSI
PUBLIC S16 maCntrlGrSuSap
(
Action  action,              /* action */
MaMngmt *cntrl               /* control */
)
#else
PUBLIC S16 maCntrlGrSuSap(action, cntrl)
Action  action;              /* action */
MaMngmt *cntrl;              /* control */
#endif
{
   U32        i;        /* counter */
   MaSap     *s;        /* MAP-GSM Upper sap */
   S16      ret;        /* return value of the function */

   TRC2(maCntrlGrSuSap)

   switch(action)
   {
     /* Disable the Upper Sap */
      case AUBND_DIS:
      {
         /* delete all the saps and associated dialogues and invokes */
         for (i=0; i < maCb.maCP.nmbMAUSaps; i++)
         {
            if (((s = *(maCb.maSapLmaPtr + i)) != (MaSap *)NULLP) && 
                (s->maPstMU.dstProcId == cntrl->t.cntrl.par.dstProcId))
            {
               ret = maDisableSuSap(s);
#if (ERRCLASS &  ERRCLS_INT_PAR)
               if(ret == RFAILED)
               {
                  MALOGERROR(ERRCLS_INT_PAR, EMA163, (ErrVal)i,
                             "maCntrlGrSuSap(). Upper Sap disable failed");
                  RETVALUE(RFAILED);
               }
#endif /* ERRCLASS & ERRCLS_INT_PAR */
#ifdef MA_FTHA
               s->contEnt = ENTSM;
#endif /* MA_FTHA */
#ifdef ZJ
               cmTuRunTimeUpd(&zjCb.tuCb, CMTU_UISAP_CB, CMPFTHA_UPDTYPE_SYNC,
                              CMPFTHA_ACTN_MOD, (Void *)s);
#endif /* ZJ */ 

            }
         } /* end for */
         break;
      }
       
      default:
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA164, (ErrVal) action,
            "maCntrlGrSuSap(). Unknown or unsupported action");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         RETVALUE(RFAILED);
      }
   } /* end switch */
   RETVALUE(ROK);
} /* maCntrlGrSuSap */

/*
*
*       Fun:   Lower Group Sap Control Request
*
*       Desc:  This function handles the Lower Group Sap Control Request
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*       File:  ca_bdy2.c
*
*/
 
#ifdef ANSI
PUBLIC S16 maCntrlGrSpSap
(
Action  action,             /* action */
MaMngmt *cntrl              /* control */
)
#else
PUBLIC S16 maCntrlGrSpSap(action, cntrl)
Action  action;             /* action */
MaMngmt *cntrl;             /* control */
#endif
{
   U32      i;        /* counter */
   MaSap   *s;        /* MAP-GSM Lower sap */
   S16    ret;        /* return value of the function */

   TRC2(maCntrlGrSpSap)

   switch(action)
   {
      /* Bind and enable the lower SAP */
      case ABND_ENA:
      {
         for (i=0; i < maCb.maCP.nmbMAUSaps; i++)
         {
            if (((s = *(maCb.maSapLmaPtr + i)) != (MaSap *)NULLP) && 
                (s->maPstST.dstProcId == cntrl->t.cntrl.par.dstProcId))
            {
#ifdef MA_RUG  
               /* Bind cannot be performed in SAP does not have valid *
                * remote interface version i.e ver sync not done      */

               if(s->remIntfValidST == FALSE)
               {
                  RETVALUE(LCM_REASON_SWVER_NAVAIL);
               }
#endif /* MA_RUG */
#ifdef MA_FTHA
               s->contEnt = ENTNC;
#endif /* MA_FTHA */
               ret = maEnableSpSap(s);
#if (ERRCLASS &  ERRCLS_INT_PAR)
               if(ret == RFAILED)
               {
                  MALOGERROR(ERRCLS_INT_PAR, EMA165, (ErrVal)i,
                             "maCntrlGrSpSap(). Lower Sap Enable failed");
                  RETVALUE(RFAILED);
               }
#endif /* ERRCLASS & ERRCLS_INT_PAR */
            }
         }
         break;
      }
     
      /* Unbind and Disable the Lower Sap */
      case AUBND_DIS:
      {
         for (i=0; i < maCb.maCP.nmbMAUSaps; i++)
         {
            if (((s = *(maCb.maSapLmaPtr + i)) != (MaSap *)NULLP) && 
                (s->maPstST.dstProcId == cntrl->t.cntrl.par.dstProcId))
            {
               ret = maDisableSpSap(s);
#if (ERRCLASS &  ERRCLS_INT_PAR)
               if(ret == RFAILED)
               {
                  MALOGERROR(ERRCLS_INT_PAR, EMA166, (ErrVal)i,
                             "maCntrlGrSpSap(). Lower Sap disable failed");
                  RETVALUE(RFAILED);
               }
#endif /* ERRCLASS & ERRCLS_INT_PAR */
#ifdef MA_FTHA
               s->contEnt = ENTSM;
#endif /* MA_FTHA */
#ifdef ZJ
               cmTuRunTimeUpd(&zjCb.tuCb, CMTU_LISAP_CB, CMPFTHA_UPDTYPE_SYNC,
                              CMPFTHA_ACTN_MOD, (Void *)s);
#endif /* ZJ */ 
            }
         } /* end for */
         break;
      }
     
      default:
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA167, (ErrVal) action,
         "maCntrlGrSpSap(). Unknown or unsupported action");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         RETVALUE(RFAILED);
      }
    
   } /* end switch */
   
   RETVALUE(ROK);
 
} /* maCntrlGrSpSap */

/*
*
*
*       Fun:   maDisableSuSap
*
*       Desc:  This function unbinds and disables specified IS41 upper SAP.
*              It will cleanup all resources related to this SAP and
*              change the sap state
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  ca_bdy2.c
*
*/      
#ifdef ANSI
PUBLIC S16 maDisableSuSap
(
MaSap       *maSap     /* IS41 upper SAP */
)
#else
PUBLIC S16 maDisableSuSap(maSap)
MaSap       *maSap;    /* IS41 upper SAP */
#endif
{

   TRC2(maDisableSuSap)

   if (maSap->uiState != MA_BND_ENABLED)
   {
      RETVALUE(ROK);
   }
   
   /* Free all the dialogues associated with this sap */
   maFreeAllDlg(maSap);
   
#ifdef MA_RUG
   /* If the version controlling entity for upper SAP is 
    * Layer Manager the do not mark the remote interface 
    * version in the SAP as invalid.
    */
   if (maSap->verContEntMU == ENTNC)
   {  
      maSap->remIntfValidMU = FALSE;
   }
#endif /* MA_RUG */

   /* Change the sap status */
   maSap->uiState = MA_BND_DISABLED;
   maSap->maState   = MA_BND_DISABLED;
   
   RETVALUE(ROK);
   
} /* end of maDisableSuSap */


/*
*
*
*       Fun:   maDisableSpSap
*
*       Desc:  This function unbinds and disables specified Lower SAP.
*              It will cleanup all resources related to this SAP and
*              change the sap state
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  ca_bdy2.c
*
*/      
#ifdef ANSI
PUBLIC S16 maDisableSpSap
(
MaSap       *maSap     /* IS41 lower SAP */
)
#else
PUBLIC S16 maDisableSpSap(maSap)
MaSap       *maSap;    /* IS41 lower SAP */
#endif
{

   TRC2(maDisableSpSap)
      
   if (maSap->liState != MA_BND_ENABLED)
   {
      RETVALUE(ROK);
   }

   /* Free all the dialogues associated with this sap */ 
   maFreeAllDlg(maSap);

   /* Change the sap status */
   maSap->liState = MA_BND_DISABLED;
   maSap->maState = MA_BND_DISABLED;
   
   RETVALUE(ROK);
} /* end of maDisableSpSap */


/*
*
*
*       Fun:   maEnableSpSap
*
*       Desc:  This function enable and bind specified Lower SAP.
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  ca_bdy2.c
*
*/      
#ifdef ANSI
PUBLIC S16 maEnableSpSap
(
MaSap       *maSap     /* IS41 lower SAP */
)
#else
PUBLIC S16 maEnableSpSap(maSap)
MaSap       *maSap;    /* IS41 lower SAP */
#endif
{
   
   TRC2(maEnableSpSap)


   if (maSap->liState == MA_BND_ENABLED)
   {
      RETVALUE(ROK);
   }
   if (maSap->liState == MA_BND_WAIT_BNDCFM)
   {
      RETVALUE(ROK);
   }
   maSap->maState   = MA_BND_WAIT_BNDCFM;
   maSap->liState = MA_BND_WAIT_BNDCFM;
   
   /* start a timer */ 
   maSap->bndRetryCnt = 0;
   maStartTmr(MA_TINT_TMR,maSap,(MaCmpCp *)NULLP);
   
#ifdef ZJ
   cmTuRunTimeUpd(&zjCb.tuCb, CMTU_LISAP_CB, CMPFTHA_UPDTYPE_SYNC,
                  CMPFTHA_ACTN_MOD, (Void *)maSap);
   cmTuUpdPeer(&zjCb.tuCb);
#endif /* ZJ */ 

   /* bind Service provider */
   MaLiStuBndReq(&maSap->maPstST, maSap->sapId, maSap->spIdTC, maSap->ssn);
   
   RETVALUE(ROK);
} /* end of maEnableSpSap */



/*
*
*       Fun:   maShutDown
*
*       Desc:  This function takes care of shutting down MAP-GSM. This function
*              release all the resources occupied by MAP-GSM and leaves it 
*              in a state when MAP-GSM task was created with no configuration.
*              While cleaning up it does not generate any indication to any
*              of the upper/lower layers.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*       File:  ca_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 maShutDown
(
Void
)
#else
PUBLIC S16 maShutDown(Void)
#endif
{
   Size       sapLstSize;     /* Size of list of pointers to SAP */
   U32        idx;            /* index */
   S16        ret;            /* return value of the function */
#if MAP_REL99
#if (MAP_SEC && LMAV2)
   Size       saLstSize;      /* Size of list of pointers to SA */
   Size       pgLstSize;      /* Size of list of pointers to PG */
   Size       ppLstSize;      /* Size of list of pointers to PP */
   Size       saMapTbSize;    /* Size of list of pointers to SA mapping Tbl */
#endif
#endif

   TRC2(maShutDown);

#ifdef ZJ
   if (zjCb.tuCb.init.cfgDone == TRUE)
   {
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "maShutDown() failed, PSF shutdown pending....\n"));
      RETVALUE(RFAILED);
   }
#endif

   /* If general configuration not already done, reject the request */
   if (maCb.maInit.cfgDone != TRUE)
   {
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "maShutDown() failed, general configuration not done.\n"));
      RETVALUE(RFAILED);
   }

   /* Deregister the timer activation functions */
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
   ret = SDeregTmr(maCb.maInit.procId, maCb.maInit.ent, maCb.maInit.inst, maCb.maCP.timeRes, maActvTmr);
#else
   ret = SDeregTmr(maCb.maInit.ent, maCb.maInit.inst, maCb.maCP.timeRes, maActvTmr);
#endif

#if MAP_REL99
#if (MAP_SEC && LMAV2)

   /* delete all the PGs */
   maFreePgTbl();

   /* Compute the size of the PG list */
   pgLstSize = (Size)(MA_MAX_PGTABLE_SIZE * sizeof(LmaSecPgCfg *));
   /* Deallocate MAP PG list */
   maFree((Data *)maCb.maSecCp.maPgTbl, pgLstSize);
   maCb.maSecCp.maPgTbl = (LmaSecPgCfg **)NULLP;

   /* delete all the PPs */
   maFreePpTbl();

   /* Compute the size of the PG list */
   ppLstSize = (Size)(maCb.maCP.secGenCfg.maxpp * sizeof(LmaSecPpCfg *));
   /* Deallocate MAP PP list */
   maFree((Data *)maCb.maSecCp.maPpTbl, ppLstSize);
   maCb.maSecCp.maPpTbl = (LmaSecPpCfg **)NULLP;

   /* delete all the saCbs and associated dlgs and invokes */

   for (idx=0; idx < maCb.maCP.secGenCfg.maxPlmn; idx++)
   {
      if (maCb.maSecCp.maSaCbPtr[idx] == NULLP) 
      {
         continue;
      }
      maRemMaSa(idx);
   } /* end for */

   /* Compute the size of the SA list */
   saLstSize = (Size)(maCb.maCP.secGenCfg.maxPlmn * sizeof(MaSaCp *));
   /* Deallocate MAP SAP list */
   maFree((Data *)maCb.maSecCp.maSaCbPtr, saLstSize);
   maCb.maSecCp.maSaCbPtr = (MaSaCp **)NULLP;

   /* de-allocate SA mapping table */
   for (idx=0; idx < maCb.maCP.secGenCfg.maxPlmn; idx++)
   {
      if (maCb.maSecCp.maSaMapTbl[idx] == NULLP) 
      {
         continue;
      }
      maRemMaSaMap(idx);
   } /* end for */
   /* Compute the size of the SA mapping table */
   saMapTbSize = (Size)(maCb.maCP.secGenCfg.maxPlmn * sizeof(MaSaMapCp *));
   /* Deallocate MAP SAP list */
   maFree((Data *)maCb.maSecCp.maSaMapTbl, saMapTbSize);
   maCb.maSecCp.maSaMapTbl = (MaSaMapCp **)NULLP;
   maCb.maSecCp.saTbSize = 0;

#endif /* MAP_SEC */
#endif

#ifdef MA_RUG
   /* Free up memory for interface version info */
   if (maCb.maIntfInfo != NULLP)
   {
      /* Total number of upper and lower Saps are 
       * 2 * (stCb.genCfg.nmbSaps) */ 
      maFree((Data *)maCb.maIntfInfo, 2 * (maCb.maCP.nmbMAUSaps) * sizeof(ShtVerInfo));
      maCb.maNumIntfInfo = 0;
   }
#endif /* MA_RUG */

   /* delete all the saps and associated dlgs and invokes */
   for (idx=0; idx < maCb.maCP.nmbMAUSaps; idx++)
   {
      if (maCb.maSapLmaPtr[idx] == NULLP) 
      {
         continue;
      }
      ret = maRemMaSap((SpId)idx);
#if (ERRCLASS &  ERRCLS_DEBUG)
      if (ret == RFAILED)
      {
         MALOGERROR(ERRCLS_DEBUG, EMA168,(ErrVal)idx,
         "maShutDown(). Sap Deletion failed");
         RETVALUE(RFAILED);
      }
#endif /* ERRCLASS & ERRCLS_INT_PAR */
   } /* end for */

   /* Compute the size of the SAP list Saps */
   sapLstSize = (Size)(maCb.maCP.nmbMAUSaps * sizeof(MaSap *));

   /* Deallocate MAP SAP list */
   maFree((Data *)maCb.maSapLmaPtr, sapLstSize);

   maCb.maSapLmaPtr = (MaSap **)NULLP;


#ifdef MA_STATIC_EVT_STRUCT
#ifdef LCMAUIMAT
   /* free the memory for the  global enc.ev structure */
   SPutSBuf(maCb.maInit.region,maCb.maInit.pool,(Data *) maGlobEncEv, 
              (Size) (sizeof(MaAllSSEv)));
#endif /* LCMAUIMAT */
   /* free the memory for the  globale dec ev structure */
   SPutSBuf(maCb.maInit.region,maCb.maInit.pool,(Data *) maGlobDecEv, 
              (Size) (sizeof(MaAllSSEv)));
#endif /* MA_STATIC_EVT_STRUCT */

   /* Release the static memory */
   if (SPutSMem(maCb.maInit.region, maCb.maInit.pool) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA169, (ErrVal)0,"maShutDown:SPutSMem failed");
#endif
      RETVALUE(RFAILED);
   }

/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : maActvInit should call with reason SHUTDOWN not with 0(NRM_TERM)                if it is shutdown case. */
   maActvInit(maCb.maInit.procId,maCb.maInit.ent,maCb.maInit.inst,maCb.maInit.region,SHUTDOWN,NULLP);
#else
   maActvInit(maCb.maInit.ent,maCb.maInit.inst,maCb.maInit.region,maCb.maInit.reason);
#endif

   RETVALUE(ROK);
} /* End of maShutDown */

#ifdef MA_RUG

/*
*
*       Fun  :  Get Interface Version handling
*
*       Desc :  Processes system agent control request primitive to 
*               get interface version.
*
*       Ret  :  ROK  - ok
*
*       Notes:  None
*
*       File :  ca_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 maGetVer
(
ShtGetVerCfm *getVerCfmInfo    /* to return interface version information */
)
#else
PUBLIC S16 maGetVer(getVerCfmInfo)
ShtGetVerCfm *getVerCfmInfo;  /* to return interface version information */
#endif
{
   TRC2(maGetVer)

   /* Fill list of upper interfaces IDs and their version number */
   getVerCfmInfo->numUif = 1;
   getVerCfmInfo->uifList[0].intfId  = MATIF;
   getVerCfmInfo->uifList[0].intfVer = MATIFVER;
     
   /* Fill list of lower interfaces IDs and their version number */
   getVerCfmInfo->numLif = 1;
   getVerCfmInfo->lifList[0].intfId  = STUIF;
   getVerCfmInfo->lifList[0].intfVer = STUIFVER;
            
#ifdef ZJ  /* If FTHA layer */ 
   /* Fill peer interfaces ID and version number */
   
   zjGetVer(&(getVerCfmInfo->pif));
  
#endif /* ifdef ZJ */
   RETVALUE(ROK);
}

 
/*
*
*       Fun  :  Set Interface Version handling
*
*       Desc :  Processes system agent control request primitive to 
*               set interface version.
*
*       Ret  :  ROK  - ok
*
*       Notes:  None
*
*       File :  ca_bdy2.c
*
*/

#ifdef ANSI
PUBLIC Void maSetVer
(
ShtVerInfo *setVerInf,   /* to return interface version information */
CmStatus  *status
)
#else
PUBLIC Void maSetVer(setVerInf,status)
ShtVerInfo *setVerInf;  /* to return interface version information */
CmStatus  *status;
#endif 
{
   Bool       found;        /* used for searching */
   U16        i, counter;   /* Counters */
   ShtVerInfo *intfInf;     /* Pointer to interface version info */
   MaSap      *s;           /* MAP sap */

   TRC2(maSetVer)

   /* Initialize variables */
   found = FALSE;
   status->reason = LCM_REASON_NOT_APPL;

#ifdef ZJ
   /* See if this is applicable to PSF. If PSF says it is not 
    * applicable (RNA) we analyze further */
/* ma004:203: Modified, passing Version Info pointer */ 
   if(zjSetVer(setVerInf, status) != RNA)
   {
      MADBGP(LMA_DBGMASK_GEN, (maCb.maInit.prntBuf,
             "stSetVer:PSF set version failed\n"));
      RETVOID;
   }  
#endif

   /* Validate version info */
   maChkVer(setVerInf->intf.intfId, setVerInf->intf.intfVer, status);   

   if(status->reason != LCM_REASON_NOT_APPL )
      RETVOID;

   /* validate grptype */
   if ((setVerInf->grpType != SHT_GRPTYPE_ALL) &&
         (setVerInf->grpType != SHT_GRPTYPE_ENT))
   {
      status->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVOID;
   }

   /* See if stored information already exists */
   for(i=0; ((i < maCb.maNumIntfInfo) && (found == FALSE)); i++)
   {
      /* Get the  interface infomation */  
      intfInf = &maCb.maIntfInfo[i];
      if(intfInf->intf.intfId == setVerInf->intf.intfId)
      {
         if(intfInf->grpType == setVerInf->grpType)
         {
            /* Store new version information specified in 
             *  this set version request  */
            switch(setVerInf->grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if ((intfInf->dstProcId == setVerInf->dstProcId) &&
                      (intfInf->dstEnt.ent == setVerInf->dstEnt.ent) &&
                      (intfInf->dstEnt.inst == setVerInf->dstEnt.inst))
                  {
                     intfInf->intf.intfVer = setVerInf->intf.intfVer;
                     found = TRUE;
                  }
                  break;
                  
               case SHT_GRPTYPE_ENT:
                  if ((intfInf->dstEnt.ent == setVerInf->dstEnt.ent) &&
                      (intfInf->dstEnt.inst == setVerInf->dstEnt.inst))
                  {
                     intfInf->intf.intfVer = setVerInf->intf.intfVer;
                     found = TRUE;
                  }
                  break;
            } /* Switch */
         } /* If group type matches */
      } /* If Interface Id matches */
   } /* for */

   /* In the worst case we should be required to store one version *
    * information for every configured sap in the layer.           */
   if(found == FALSE)
   {  
      /* Maximum number of upper and lower sap together
       *  is 2 * max number of saps */

      if(maCb.maNumIntfInfo < 2* maCb.maCP.nmbMAUSaps)
      {
         /* Copy version info. to the TCAP control block */
         cmMemcpy((U8*) &maCb.maIntfInfo[i],(U8*)setVerInf, 
                  sizeof(ShtVerInfo));
         /* Increment total number of interface counter */ 
         maCb.maNumIntfInfo++;
      }
      else
      {
         /* Set error status */
         status->reason = LCM_REASON_EXCEED_CONF_VAL;
         RETVOID;
      }
   } /* if not found */
        
   /* Information in set version stored. Now update the SAPs */
   switch(setVerInf->intf.intfId)
   {
      /* Upper Interface */
      case MATIF: 
         /* Loop through all upper saps */
         for ( counter = 0; counter < maCb.maCP.nmbMAUSaps; ++counter )
         { 
            if ((s = *(maCb.maSapLmaPtr + counter)) == NULLP)
               continue;
              
            /* If it is an unbound SAP then the remote entity, instance *
             * and proc ID would not be available and hence we should   *
             * wait for bind to happen to set the remote interface ver  */

            if (s->uiState != MA_BND_ENABLED)
               continue;

            switch(setVerInf->grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if ((s->maPstMU.dstProcId == setVerInf->dstProcId) &&
                      (s->maPstMU.dstEnt == setVerInf->dstEnt.ent)   &&
                      (s->maPstMU.dstInst == setVerInf->dstEnt.inst))
                  {
                     s->maPstMU.intfVer = setVerInf->intf.intfVer;
                     s->remIntfValidMU = TRUE;
                  }
                  break;
                  
               case SHT_GRPTYPE_ENT:
                  if ((s->maPstMU.dstEnt == setVerInf->dstEnt.ent) &&
                      (s->maPstMU.dstInst == setVerInf->dstEnt.inst))
                  {     
                     s->maPstMU.intfVer = setVerInf->intf.intfVer;
                     s->remIntfValidMU = TRUE;
                  }
                  break;

               default:
                  /* not possible */
                  break;
            } /* switch(setVerInf->grpType) */
         } /* End for */ 

         break; /* Case MATIF or upper interface */
         /* Lower Interface */

      case STUIF: 
         /* Loop through all the saps */
         for ( counter = 0;counter < maCb.maCP.nmbMAUSaps;++counter )
         { 
            if ((s = *(maCb.maSapLmaPtr + counter)) == NULLP)
               continue;
             
            switch(setVerInf->grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if ((s->maPstST.dstProcId == setVerInf->dstProcId) &&
                      (s->maPstST.dstEnt == setVerInf->dstEnt.ent)   &&
                      (s->maPstST.dstInst == setVerInf->dstEnt.inst))
                  {
                     s->maPstST.intfVer = setVerInf->intf.intfVer;
                     s->remIntfValidST = TRUE;
                  }
                  break;
                  
               case SHT_GRPTYPE_ENT:
                  if ((s->maPstST.dstEnt == setVerInf->dstEnt.ent) &&
                      (s->maPstST.dstInst == setVerInf->dstEnt.inst))
                  { 
                     s->maPstST.intfVer = setVerInf->intf.intfVer;
                     s->remIntfValidST = TRUE;
                  }
                  break;

               default:
                  /* not possible */
                  break;

            } /* switch(setVerInf->grpType) */
         } /* End for */ 
         break; /* Case STUIF or lower interface */
      default:
         /* not possible */
         break;
   } /* switch(setVerInf->intf.intfId) */
} /* End of routine */

 
/*
*
*       Fun  :  Check Version Info 
*
*       Desc :  Checks whether a particular interface 
*               version can be supported
*
*       Ret  :  Void
*
*       Notes:  None
*
*       File :  ca_bdy2.c
*
*/

#ifdef ANSI
PUBLIC Void maChkVer
(
CmIntfId  intfId,   /* interface ID */
CmIntfVer intfVer,  /* interface version */
CmStatus  *status   /* status after checking version info */
)
#else
PUBLIC Void maChkVer(intfId,intfVer,status)
CmIntfId  intfId;   /* interface ID */
CmIntfVer intfVer;  /* interface version */
CmStatus  *status;  /* status after checking version info */
#endif 
{  
   TRC2(maChkVer)

   /* Validate Set Version Information  */
   switch(intfId)
   {
      /* Upper Interface */
      case MATIF:
         /* Check for version info, if it is lower or 
          * equal allow it, otherwise set reason value */

         if (MATIFVER < intfVer)  
            status->reason = LCM_REASON_VERSION_MISMATCH;
         break;

      /* Lower Interface */
      case STUIF: 
         /* Check for version info, if it is lower or 
          * equal allow it, otherwise set reason value */

         if (STUIFVER < intfVer)  
            status->reason = LCM_REASON_VERSION_MISMATCH;
         break;

      default:
         /* For unknown interface set reason value */
         status->reason = LCM_REASON_VERSION_MISMATCH;
         break;
   } /* switch */
} /* end function */

#endif /* MA_RUG */


/*
*
*       Fun:   maStoreOpenRsp
*
*       Desc:  This function is used to restore early openRsp 
*
*       Ret:   ROK , 
*
*       Notes: None
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maStoreOpenRsp
(
MaSap            *s,           /* Sap */
MaDlgId          suDlgId,      /* Service user Dlg Id */
MaDlgCp          *dlgCp,       /* Dialogue Control Point*/
MaOpenEv         *openEv       /* MAP-OPEN event */
)
#else
PUBLIC S16 maStoreOpenRsp(s, suDlgId, dlgCp, openEv)
MaSap            *s;           /* Sap */
MaDlgId          suDlgId;      /* Service user Dlg Id */
MaDlgCp          *dlgCp;       /* Dialogue Control Point*/
MaOpenEv         *openEv;      /* MAP-OPEN event */
#endif
{
   U32      i;

   TRC2(maStoreOpenRsp)

   dlgCp->openRspRcvd.dlgEvFlg     = FALSE;
   dlgCp->openRspRcvd.usrInfo.pres = FALSE;
   cmZero((U8 *)&dlgCp->openRspRcvd.extCont,sizeof(MaExtContSeq));

   if (openEv->usrInfo.pres == TRUE)  
   {
      cmCopy((U8 *)&openEv->usrInfo, 
             (U8 *)&dlgCp->openRspRcvd.usrInfo,sizeof(MaUsrInfo));
   }
   if (openEv->extCont.priExtLst[0].pres == TRUE) 
   {
      for ( i = 0; i < MA_MAX_NMB_PRI_EXT; i++)
      {
         if (openEv->extCont.priExtLst[i].pres == TRUE)
         {
            cmCopy((U8 *)&openEv->extCont.priExtLst[i],
                   (U8 *)&dlgCp->openRspRcvd.extCont.priExtLst[i],
                   sizeof (TknStrE));
         }
      }
   }

   dlgCp->openRspRcvd.pres = TRUE;
   dlgCp->openRspRcvd.usrInfoPres = openEv->usrInfo.pres;
   dlgCp->suDlgId = suDlgId;
   if (dlgCp->apn.val[dlgCp->apn.len-1] != LMA_VER1)
   {
      dlgCp->openRspRcvd.dlgEvFlg = TRUE;
   }
   if (openEv->rspAddr.pres == TRUE)
   {
      /* store the response address to the source address of OpenRspRcvd*/
      cmCopySpAddr(&openEv->rspAddr, &dlgCp->openRspRcvd.srcAddr);
   }
   else
   {
      dlgCp->openRspRcvd.srcAddr.pres = FALSE;
   }

#if (MATV2 && STUV2)
   if (openEv->imp.pres == TRUE)
   {
      dlgCp->openRspRcvd.imp.pres = TRUE;
      dlgCp->openRspRcvd.imp.val = openEv->imp.val;
   }
#endif
#ifdef MATV3
   if ((openEv->maPrior.pres == TRUE) && (openEv->maPrior.val <= MA_PRI3))
   {
      cmCopy((U8 *)&openEv->maPrior, (U8 *)&dlgCp->openRspRcvd.maPrior,
                   sizeof (TknU8));
   }
   if ((openEv->pClass.pres == TRUE) && (openEv->pClass.val <= PCLASS1))
   {
      cmCopy((U8 *)&openEv->pClass, (U8 *)&dlgCp->openRspRcvd.pClass,
                   sizeof (TknU8));
   }
#endif
   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "maStoreOpenRsp() Successfully completed with dlgEvFlg=%d \n",  
      dlgCp->openRspRcvd.dlgEvFlg));
   RETVALUE(ROK);


} /* maStoreOpenRsp*/

/*
*
*       Fun:   maRestoreOpenRsp
*
*       Desc:  This function is used to restore early openRsp 
*
*       Ret:   ROK , 
*
*       Notes: None
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maRestoreOpenRsp
(
MaDlgCp        *dlgCp   /* Dialogue Control Point*/
)
#else
PUBLIC S16 maRestoreOpenRsp(dlgCp)
MaDlgCp        *dlgCp;  /* Dialogue Control Point*/
#endif
{
   U32   i;

   TRC2(maRestoreOpenRsp)

   dlgCp->usrInfoPres = dlgCp->openRspRcvd.usrInfoPres;
   if (dlgCp->openRspRcvd.usrInfo.pres == TRUE)
   {
      cmCopy((U8 *)&dlgCp->openRspRcvd.usrInfo, 
             (U8 *)&dlgCp->usrInfo, sizeof(MaUsrInfo));
   }
   if (dlgCp->openRspRcvd.extCont.priExtLst[0].pres == TRUE)
   {
      for ( i = 0; i < MA_MAX_NMB_PRI_EXT; i++)
      {
         if (dlgCp->openRspRcvd.extCont.priExtLst[i].pres == TRUE)
         {
            cmCopy((U8 *)&dlgCp->openRspRcvd.extCont.priExtLst[i],
                   (U8 *)&dlgCp->extCont.priExtLst[i],sizeof(TknStrE));
         }
      }
   }
   dlgCp->dlgEvFlg = dlgCp->openRspRcvd.dlgEvFlg;
   if (dlgCp->openRspRcvd.srcAddr.pres == TRUE)
   {
      cmCopySpAddr(&dlgCp->openRspRcvd.srcAddr, &dlgCp->srcAddr);
   }
   dlgCp->dsmState = MA_DLG_ACCEPTED;
#if (MATV2 && STUV2)
   if (dlgCp->openRspRcvd.imp.pres == TRUE)
   {
      dlgCp->imp.pres = TRUE;
      dlgCp->imp.val = dlgCp->openRspRcvd.imp.val;
      dlgCp->openRspRcvd.imp.pres = FALSE;
   }
#endif
#ifdef MATV3
   if (dlgCp->openRspRcvd.maPrior.pres == TRUE)
   {
      cmCopy((U8 *)&dlgCp->openRspRcvd.maPrior, (U8 *)&dlgCp->maPrior,
           sizeof(TknU8));
   }
   if (dlgCp->openRspRcvd.pClass.pres == TRUE)
   {
      cmCopy((U8 *)&dlgCp->openRspRcvd.pClass, (U8 *)&dlgCp->pClass,
           sizeof(TknU8));
   }
#endif
   dlgCp->openRspRcvd.pres = FALSE;

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "maRestoreOpenRsp() completed successfully with dlgEvFlg=%d \n",  
      dlgCp->dlgEvFlg));
   RETVALUE(ROK);
} /* maRstoreOpenRsp*/

#ifdef ZJ

/*
*
*       Fun:   maIsUpdReq    
*
*       Desc:  This function  checks whether a operation is supported 
*              by MAP  
*
*       Ret:   ROK  if operation supported
*
*       Notes: None 
*
*       File:  ca_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC Bool maIsUpdReq 
(
MaSap   *s,             /* MAP Sap */
MaDlgCp *dlgCp          /* Dialogue Control point */
)
#else
PUBLIC Bool maIsUpdReq (s, dlgCp)
MaSap   *s;             /* MAP Sap */
MaDlgCp *dlgCp;         /* Dialogue Control point */
#endif
{
  S16   i;
  S16   ret;

  TRC2(maIsUpdReq)
 
  for (i=0; i< MA_MAX_OPR; i++)
  {
     if (s->cfg.apnCfg[i].pres == TRUE)
     {
        /* We don't care about the ACN version, so only the first 
         * 7 bytes are compared */
        ret = cmMemcmp((U8 *)&dlgCp->apn.val[0], 
                       (U8 *)&s->cfg.apnCfg[i].apn.string[0], 
                       s->cfg.apnCfg[i].apn.len-1);
        /* Match, return item found */
        if (ret == 0)
        {
           /* return for the first match */
           RETVALUE(s->cfg.apnCfg[i].upd);
        }
     }
  }

  MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
         "maIsUpdReq() failed, the ACN is not configured.\n"));
  RETVALUE(FALSE);
} /* maIsUpdReq  */

#endif /* ZJ */

/*
 *
 *      Fun:   maGetNextDlg
 *
 *      Desc:  Get the next SAP control block
 *
 *      Ret:   ROK     - Next SAP control is found
 *             RFAILED - Next SAP control is not found
 *
 *      Notes: None
 *
 *      File:  ma_bdy2.c
 * 
 */
#ifdef ANSI
PUBLIC S16 maGetNextDlg
(
PTR            sapCb,       /* Pointer to SAP control block */
PTR            lastHlEnt,   /* Last updated hash list entry */
U16            *currBin,    /* current bin in hash table */
PTR            *entry       /* entry to be returned */
)
#else
PUBLIC S16 maGetNextDlg (sapCb, lastHlEnt, currBin, entry)
PTR            sapCb;       /* Pointer to SAP control block */
PTR            lastHlEnt;   /* Last updated hash list entry */
U16            *currBin;    /* current bin in hash table */
PTR            *entry;      /* entry to be returned */
#endif
{
   /* ma011.203 : i is changed to U32 from U16 to avoid infinite "for" 
                  loop in case of overfolw of U16 i  */

   U32     i;      /* index of hash bin */
   MaSap   *s;     /* current sap */

   TRC2 (maGetNextDlg)
   
   MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
           "maGetNextDlg() : current bin = %d\n", *currBin));

#if (ERRCLASS & ERRCLS_DEBUG)
   /* error check on parameters */
   if ((sapCb == NULLP) || (entry == NULLP))
   {
      MALOGERROR(ERRCLS_DEBUG, EMA170, (ErrVal)0, 
                 "Either sapCb or entry is NULL ");
      RETVALUE(RFAILED);
   }
#endif

   s = (MaSap *)sapCb;

   /* MAP-GSM does not use common hash module. It use its own function
    * to find next dialogue control block entry in hash table */

   /* check if need to get first entry */
   if (lastHlEnt == NULLP)
   {
      /* get first entry in hash list */
/* ma012.203: Addition, to support Dlg Hash size configuration*/
#ifdef MAP_NSRP
      for (i = 0; i < s->dlgHshSize; i++)
#else
      for (i = 0; i < MA_DLG_HASH_SIZE; i++)
#endif
      {
         if (s->maDlgTbl[i] == (MaDlgCp *)NULLP)
            continue;
         else
         {
            *entry = (PTR)s->maDlgTbl[i];
            *currBin = i;

            RETVALUE(ROK);
         }
      }

      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
           "maGetNextDlg() : Empty hash table\n"));

      RETVALUE(RFAILED);
   }

   /* use previous entry to find next entry */

   /* if the elemnt is not at the end, don't need to search the list */
   if (((MaDlgCp *)lastHlEnt)->next != (MaDlgCp *)NULLP)
   {
      *entry = (PTR)(((MaDlgCp *)lastHlEnt)->next);
      /* no change for prevEnt->lastBin */

      RETVALUE(ROK);
   }
/*ma012.203: Addition, to support Dlg Hash size configuration */
#ifdef MAP_NSRP
   for (i = *currBin+1; i < s->dlgHshSize; i++)
#else
   for (i = *currBin+1; i < MA_DLG_HASH_SIZE; i++)
#endif /* MAP_NSRP */
   {
      if (s->maDlgTbl[i] == (MaDlgCp *)NULLP)
         continue;
      else
      {
         *entry = (PTR)s->maDlgTbl[i];
         *currBin = i;

         RETVALUE(ROK);
      }

   }

   MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
          "maGetNextDlg() : no more entries hash table\n"));

   RETVALUE (RFAILED);

}

/*
 *
 *      Fun:   maGetNextInv
 *
 *      Desc:  Get the next SAP control block
 *
 *      Ret:   ROK     - Next SAP control is found
 *             RFAILED - Next SAP control is not found
 *
 *      Notes: None
 *
 *      File:  zj_bdy2.c
 * 
 */
#ifdef ANSI
PUBLIC S16 maGetNextInv
(
PTR            dlgCb,       /* Pointer to Dialogue control block */
PTR            lastHlEnt,   /* Last updated hash list entry */
U16            *currBin,    /* current bin in hash table */
PTR            *entry       /* entry to be returned */
)
#else
PUBLIC S16 maGetNextInv (dlgCb, lastHlEnt, currBin, entry)
PTR            dlgCb;       /* Pointer to Dialogue control block */
PTR            lastHlEnt;   /* Last updated hash list entry */
U16            *currBin;    /* current bin in hash table */
PTR            *entry;      /* entry to be returned */
#endif
{

  
   /* ma011.203 : i is changed to U32 from U16 to avoid infinite "for" 
                  loop in case of overfolw of U16 i  */
   U32     i;      /* index of hash bin */
   MaDlgCp *d;     /* Dialogue control block */

   TRC2 (maGetNextInv)
   
   MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
           "maGetNextInv() : current bin = %d\n", *currBin));

#if (ERRCLASS & ERRCLS_DEBUG)
   /* error check on parameters */
   if ((dlgCb == NULLP) || (entry == NULLP))
      RETVALUE(RFAILED);
#endif

   d = (MaDlgCp *)dlgCb;

   /* MAP-GSM does not use common hash module. It use its own function
    * to find next dialogue control block entry in hash table */

   /* check if need to get first entry */
   if (lastHlEnt == NULLP)
   {
      /* get first entry in hash list */
      for (i = 0; i < MA_INVOKE_HASH_SIZE; i++)
      {
         if (d->invkTbl[i] == (MaCmpCp *)NULLP)
            continue;
         else
         {
        *entry = (PTR)d->invkTbl[i];
            *currBin = i;

            RETVALUE(ROK);
         }
      }

      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
           "maGetNextInv() : Empty hash table\n"));

      RETVALUE(RFAILED);
   }

   /* use previous entry to find next entry */

   /* if the elemnt is not at the end, don't need to search the list */
   if (((MaCmpCp *)lastHlEnt)->next != (MaCmpCp *)NULLP)
   {
      *entry = (PTR)(((MaCmpCp *)lastHlEnt)->next);
      /* no change for prevEnt->lastBin */

      RETVALUE(ROK);
   }

   for (i = *currBin+1; i < MA_INVOKE_HASH_SIZE; i++)
   {
      if (d->invkTbl[i] == (MaCmpCp *)NULLP)
         continue;
      else
      {
         *entry = (PTR)d->invkTbl[i];
         *currBin = i;

         RETVALUE(ROK);
      }
   }

   MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
          "maGetNextInv() : no more entries hash table\n"));

   RETVALUE (RFAILED);

}
#ifdef LMAV3

/*
*
*       Fun:   maRunAudits
*
*       Desc:  Run the Audit procedure.
*
*       Ret:   Void
*
*       Notes: This function release the resources allocated to the
*              control blocks which haven't been accessed for more than
*              'expTime' time. These resources are assumed to be hanging
*               ones and thus are deleted.
*
*       File:  ma_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void maRunAudits
(
SpId         spId,         /* SAP Id */
U8           cbType,       /* Control block type */
U32          nmbCb,        /* Number of control blocks if not all */
Ticks        expTime       /* Expiry time for control blocks */
)
#else
PUBLIC Void maRunAudits(spId, cbType, nmbCb, expTime)
SpId         spId;         /* SAP Id */
U8           cbType;       /* Control block type */
U32          nmbCb;        /* Number of control blocks if not all */
Ticks        expTime;      /* Expiry time for control blocks */
#endif
{
   MaSap     *sapCp;
   MaDlgCp   *dlgCp;
   MaCmpCp   *invCp;
   PTR        lastDlgEnt;
   U16        currDlgBin;  /* current bin in hash table */
   PTR        lastInvEnt;
   U16        currInvBin;  /* current bin in hash table */
   Ticks      curTime;
   U32        cbCount;
   Bool       dlgFlag;     /* If dialogues control blockes are to be deleted */
   Bool       invFlag;     /* If invoke control blockes are to be deleted */
   Bool       allFlag;     /* If all unused control blocks are to be deleted */

   TRC2(maRunAudits)

   /* get the pointer to the MA sap */
   sapCp   = maCb.maSapLmaPtr[spId];
   cbCount = 0;

   /* Get the current time */
   SGetSysTime(&curTime);

   lastDlgEnt = NULLP;
   lastInvEnt = NULLP;
   currDlgBin = 0;
   currInvBin = 0;

   /* By default delete all control blocks */
   dlgFlag = TRUE;
   invFlag = TRUE;
   allFlag = TRUE;

   switch(cbType)
   {
      case LMA_AUDIT_ALL_DLG:
         invFlag = FALSE;
         break;

      case LMA_AUDIT_ALL_INV:
         dlgFlag = FALSE;
         break;

      case LMA_AUDIT_PAR_DLG:
         allFlag = FALSE;
         invFlag = FALSE;
         break;

      case LMA_AUDIT_PAR_INV:
         allFlag = FALSE;
         dlgFlag = FALSE;
         break;

      case LMA_AUDIT_PAR_CB:
         allFlag = FALSE;
         break;

      case LMA_AUDIT_ALL_CB:
         break;
   }

   while (maGetNextDlg((PTR)sapCp, lastDlgEnt, &currDlgBin,
                             (PTR *)&dlgCp) == ROK )
   {
      /* If only some of the control blocks are to be deleted and that count
         has reached then return from here */
      if ((!allFlag) && (cbCount >= nmbCb))
      {
         RETVOID;
      }

      /* If the dialogue control point was last updated `expTime` before
         then assume it to unused and delete the dialogue */

      if ((dlgFlag) && ((curTime - dlgCp->tmStmp) >  expTime))
      {
#ifdef ZJ
         MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
         MA_UPD_PEER(dlgCp->upd)
#endif /* ZJ */
         cbCount++;
         sapCp->curDlgCp = dlgCp;
         maDlgIdle(sapCp);
      }
      else if (invFlag)
      {
         lastDlgEnt = (PTR)dlgCp;
         lastInvEnt = NULLP;

         while (maGetNextInv((PTR)dlgCp, lastInvEnt, &currInvBin, 
                                    (PTR *)&invCp) == ROK )
         {
            if ((curTime - invCp->tmStmp) >  expTime)
            {
#ifdef ZJ
               MA_UPD_INV(dlgCp, invCp, CMPFTHA_ACTN_DEL)
               MA_UPD_PEER(dlgCp->upd)
#endif 
               cbCount++;
               maInvkIdle(dlgCp, (MaCmpCp *)invCp);
            }
            else
            {
               lastInvEnt = (PTR)invCp;
            }
         }
      }
   }

   RETVOID;
} /* End of maRunAudits */

#endif


#ifdef XW_IND_OPTIMIZE

S16 maStoreEvtToCmpCp(MaDlgCp *dlgCp, MaCmpCp *cmpCp, U8 *evt)
{
   U8 i = 0;
   cmpCp->evtStor = evt;

    while(i<MAX_DLG_RESEVT)
    {
        if(dlgCp->storIvkId[i].pres == 0)
        {
            dlgCp->storIvkId[i].pres = TRUE;
            dlgCp->storIvkId[i].octet = cmpCp->invkId.octet;
            break;
        }
        i++;
        if(i>=MAX_DLG_RESEVT)
        {
			cmpCp->evtStor = NULL;
            RETVALUE(RFAILED);
        }
	}
    RETVALUE(ROK);
}

Void maGetStoreEvtFrmCmp(MaDlgCp * dlgCp, MaInvokeId *invkId, MaCmpCp **cmpCp, U8 **evt)
{
    *cmpCp = NULL;
    *evt = NULL;

    if(invkId->pres == TRUE)
    {
        *cmpCp = maFindHashInvk(dlgCp, invkId, FALSE);
        if(*cmpCp == NULL)
        {
            invkId->pres = FALSE;
            invkId->octet = 0;
            
            maSendAlrm(NEW,dlgCp->sap->sapId, MA_UNUSED, MA_UNUSED, "maGetStoreEvtFrmCmp",
                      LCM_EVENT_MI_INV_EVT,LCM_CATEGORY_INTERNAL,
                      LCM_CAUSE_INV_PAR_VAL);

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "maGetStoreEvtFrmCmp(): Can not find comp from invoke id.\n"));

            RETVOID;
        }
        *evt = (*cmpCp)->evtStor;
        (*cmpCp)->evtStor = NULL;
        invkId->pres = FALSE;
        invkId->octet = 0;
    }
    else
    {
        ;
    }

    RETVOID;
}

#endif/*XW_IND_OPTIMIZE*/

/********************************************************************30**

         End of file:     ca_bdy2.c@@/main/12 - Fri Sep 16 02:46:48 2005

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  aa    1. initial release

1.2          ---  aa    1. text changes

*********************************************************************81*/
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.3          ---      aa   1. Build the MAP Accept PDU (with length 0) while
                              sending the response to incmoing dialogue (function
                              maDelimReqCom)
             ---      aa   2.  If the Dilaogue is closed in response to an incoming
                               dialogue build MAP Accept pdu and build the dialogue
                               event structure (function maCloseReqCom) 

             ---      aa   3. If TC_END is received in response to TC_BEGIN (function
                              check the MAP PDU if any and if it is MAP REFUSE PDU
                              send the MAP Open Confirm to MAP user with result as
                              MAP_DIALOGUE_REJECTED.

             ---      aa   4. Changed the maOpenRspM05 to send the TC_END if the
                              refuse reason is other then Application Context name
                              not supported.

             ---      aa   5. Fixed the bug in function maFindHashDlgLower
  
             ---      aa   6. Fixed the Bug in function maBldOpenMsg and 
                              MaOpenReqM00

             ---      aa   7. Fixed the bug in function maBldDlgEv. The OBJID
                              tag and length was passed as part of the application
                              context name though only the the value (OBJ ID 
                              encoded) should be passed to TCAP. Changed the 
                              function maConvertACN also because of the above
                              mentioned cause
             ---      aa   8. Changed the internals of functions (now passing
                              explicit paramters required by the each function 
                              instead of passing just the pointer to SAP structure.

             ---      aa   9. Modified the function maTmrEvnt to just make the SSM
                              idle on the gaurd timer expiry. 

             ---      aa   10. Source and Destination address parameters were swapped
                               in MaLiStuDatReq.
             ---      aa   11.  Multiple OPenCfm were given in case of multiple timer
                                (Invoke Timer) expiry in MA_DLG_INITIATED state as the
                                State was not chnaged to MA_DLG_ESTABLISHED

             ---      aa   12. Encoding problem in maAbrtReqCom (the last tag and
                               length were not being Added in the mBuf)
             ---      aa   13. Added new function maSwapPst

1.4          ---      aa   1.  Moved XXYYMatAuthMgmtInd from #ifdef MSC to HLR.
             ---      aa   2.  Fixed the bug not initializing destRef in function
                             maBeginM00
             ---      aa   3.  Fixed the bug of updating the dialogue state after
                             sending Ind/Cfm to MAP user, as this was creating
                             problem when the MAP user is tightly coupled and
                             generating responses within the indication 
                             primitives.
             ---      aa   4.  The srcRef and destRef were not initialized in MAP 
                             V1
             ---      aa   5.  The TC PAbort Reasons were not mapped to MAP
                             provider Aborts properly in Dialogue Initiated
                             state.
             ---      aa   6.  Corrected the function maDecOpr for the following 
                             operation codes,MAT_CANCELLOC, MAT_PURGE,
                             MAT_SNDENDSIG, MA_ACTVTRMODE, MA_DACTVTRMODE,
                             MA_USSNOT, MAT_FWDSM, MAT_ALRTSC, MAT_SMRDY 
             ---      aa   7.  The case statement for MAT_PROVROAMNMB was missing in
                             function maUpdatRxSts
             ---      sg   8.  Fixed maRemHashInv, maRemHashDlg

             ---      sg   9.  Fixed bug in maAbrtM03.

             ---      sg   10. Fixed bug in maChkErr.

             ---      sg   11. Fixed bug in maFindHashDlg.
                             Fixed bug in maDecOpr

             ---      sg   12. Fixed bugs in abort pdu encoding and decoding

             ---      sg   13. Fixed dialogue state changes to be done before
                             requests or indications. 

             ---      sg   13. Uninitialized counter in the Hash List
                             for invoke insertion. 

             ---      sg   14. Increased support of OID values from 127
                             to 255. Written generic encoding decoding 
                             routines for encoding OID values uptill
                             65535.

             ---      sg   15. Fixed hash list indexing problem with negative 
                             invoke id's

             ---      sg   16. Incorrect abort pdu tag in provider abort
                             generated by MAP.

             ---      sg   17. Incorrect check for LMA_VER_2 in maBeginM00

             ---      sg   18. Error in ACN checks for destination reference
                             in map open request handler (maOpenReqM00)

             ---      sg   19. Accept Open and Service Specific Responses in
                             idle state. This is required if the MAP user
                             does not wish to wait for all the components
                             before issuing an  open response and service
                             specific responses. To enable this feature, the
                             flag MA_ACCEPT_RSP should be defined.

             ---      sg   20. Error in application context checks in maBeginM00
                             
             ---      ssk  21. Wrong Notice indication cause is used instead    
                             of MAT_ABEVT_RCVD_PEER.
             ---      ssk  22. In process RR function, when the mBuf is NULL
                             operation code check should not be performed.

             ---      ssk  23. Added MAP Phase 2+ variant                   
                             
1.5          ---      ssk  1. Corrected SS Event structure

1.6          ---      ssk  1. maCb.maInvCnt has to be incremented in maInsHashInv
    
                           2. maCb.maInvCnt has to be decremented in maRemHashInv

                           3. maCb.maInvCnt has to be checked for the maximum
                              reached before incrementing.

                           4. Message buffer has to be freed in some of 
                              the failure cases.

                           5. ACN check is written to give new interpretation
                              for LMA_VER_ALL.

             ---      ssk  6. When the dialogue is in the initiated state,
                              we can not do the normal close. we have to
                              perform the pre-arranged close.

                           7. We Must not fill the operation code for the
                              return error component.

             ---      ssk  8. Phase 2+ gpr release .                       

1.7          ---      ssk  1. check for usta flag is made in maSendAlrm()   
             ---      ssk  2. When mBuf==NULLP, Null Message Buf is 
                              allocated in ProcessRetRsltL() function 
                              to simulate proper working in maDecOpr().
    
             ---      ssk  3. Global Decode event structure related  
                              changes .                               
             ---      ssk  4. extension marker(ellipsis) related change 
                              in maDecDlgId() & maDecOpenPdu() functions.
    
             ---      ssk  5. LMA_VER2P must not be compared with ACN   
                              Versions coming from the network/user.     
    
             ---      ssk  6.  Component Event structure has to be initialized
                               to zeros before filling in maSndTcErr() and
                               maSndTcRej().
 
             ---      ssk  7.  Check for the version field inside the apn is  
                               made to make sure that we are receiving proper
                               version number from the user and network.
                               These checks are made in Begin() & OpenReq().
 
             ---      ssk  8.  nmbActvDlg is incremented at the start of the
                               function, so that in the error cases we can
                               decrement in inside maDlgIdle.
                               Pre-arranged TCAP dialogue release is called
                               when the check load fails.
 
             ---      ssk  12. Invoke id hashing is modified to include
                               duplicate keys with different initiator values.
 
             ---      ssk  13. State change to dialogue established is 
                               removed in maProcessCan() according to the     
                               MAP GSM Standard's Dlg State machine descr.
                               
                               Check for the Message buffer end is modified
                               to include the definite form of length 
                               encoding .                 
 
             ---      ssk  14. In CloseReqCom() , the dialgoue event parameter
                               must not be formed for pre arranged close      
                               cases.
                               Notice indication is sent when the gaurd 
                               timer expires when the compile time flag
                               MAP_GAURD_EXPIRY is defined. 
 
             ---      ssk  15. Presence indicators in the open event structure
                               are correctd in maDecOpenPdu() function.       

             ---      ssk  16. maGetAcn function is corrected to return       
                               failure only when the version 1 in not present 
                               in the combination of versions configured by 
                               the MAP user.

             ---      ssk  17. Gaurd timer enable flag is checked before      
                               intializing from the value configured.         

             ---      ssk  18. Unused mBuf variables in the functions are     
                               Removed.                                       

             ---      ssk  19. max. Invoke reached check is made before calling
                               the allocate invoke control block routine and
                               notice indication is sent to the MAP user. 

             ---      ssk  19. retOpt SAP configuration option rellated chnge.

             ---      jz   19. tmpSuDlgId and tmpSpDlgId were added to avoid
                               losing newly opened dialogs.

             ---      jz   1. Added functions to handle Group SAP 
                              enable/disable.
                           2. Changes for TCR0018, the controlling entity 
                              was added as part of Upper and lower SAPs 
                              unbind and bind operations.

/main/7      ---      jie  1. update for MAP 1.5 release.

             ---      jie  1. moved maSndSSInd to the the of maProcessInvk()
                              and maProcessInvM02() function.
                           2. update length of diagInfo in maDecSMDelFailCause.

             ---      jie  1. Rolling Upgrade compliance.

             ---      yz   1. Added function to check Apn supported.
                           2. Remove flag REL99 for sndEndSigRsp.

             ---      yz   1. Added function to restore early open response.
                           2. Check curDlgCp after OpenInd return.
                           3. For version 1, apn shouldn't be checked.

             ---      jie  1. Change for 3.9.0 REL_99 support.

             ---      yz   1. Change switch from probType to probCode and 
                              also correct a srcCode error in maProcessRej().

             ---      yz   1. Adding debug print for RFAILED case. 
                           2. Change dsmstate matrix to allow closeReq
                              at Idle state.

             ---      jie  1. Change for MAP REL4 support without the MAPsec 
                              feature.

             ---      yz   1. Change to allow AC CALL_COMP_AC using 
                              user info.
                           2. Change to allow srcRef omitted in AC
                              NETUSS_SS.
                           3. Change to skip version 1 entry for ACN checking.

             ---      yz   1. Change to allow early delimReq.

             ---      yz   1. Change to adding extCont to dlgPdu.

/main/8      ---      jie  1. update for MAP 1.6 release.

             ---      yz   1. Addition of MAP segmentation feature from 1.5.
                           2. Check endFlg before sending TC_ABORT. 

             ---      yz   1. Initialize errSrc in maProcessRetRsltL.
                           2. Correct an error in maDecErrParam().      
                           3. Absent subscriber should be allowed for ROUTINFOSM.

             ---      jie  1. Change for 2002/09 rel99/rel4 release.
                           2. Correct decoding error for Absent subscriber.
                           3. Remove double memory allocation.
                           4. maChkErr routine corrected for FwdSM & eraseSS

/main/9      ---      jie  1. update for MAP 1.7 release.

             ---      jie  1. Passed refuse reason to TCAP in dialogue 
                              pending DSM state.
                           2. All the fields are initialized inside 
                              storeOpenRsp function.
                           3. Moved the delimiter indication after 
                              restoreOpenResponse.

             ---      ssk  1. Changes related to flexibly tune the 
                              MTP3 priority and SCCP class.

/main/11     ---      zj   1. PSF-MAP changes.
                      cp   1. Removed STU2 flag
             ---      st   1. Modified maAllocDlgId so that dlgId is 
                              always incremented.
                           2. Fixed memory leakage in maAbrtReqCom()
                           3. Modified decoding related to requests
                              and responses part of the MaSubEv 
                              strcuture to make the memory 
                              initialization efficient.
                           4. Code now supports 32 bit hash tables.
                           5. Enabled MA_MI_PROVSUBSINFO_RSP for REL 5                                GSN.
                           6. Added check for phase 2 in maChkRcvdErr.
                           7. Removed the redundant checks for version 1
                              in maGetAcn.
                           8. Modified the maIsOprSupp function 
                              prototype to enforce stricter checking.
                           9. Modified parts of code where internal
                              data structures are called before
                              modifying the internal variables.
                           10.dlg state in maBeginM00 is changed 
                              before an OpenInd is generated. This 
                              allows MAP to cater to tightly coupled
                              calls to AbrtReq for the same dialogues.
               ---    st   1. Changed the decision flows as per the CR
                              583 in R5 upgrade.
               ---    st   1. Modified the instances of freeing the
                              msg in erroneous scenarios wherever it
                              was guarded by
                              (ERRCLASS & ERRCLS_ADD_RES)  and
                              (ERRCLASS & ERRCLS_ADD_PAR) flags.
                           2. Warnings removal.
/main/12     ---  rbabu 1.  Update for MAP 2.3 release.
	ma001.203			st   1. Modified the function maGetAcn()
                           to fix the problem to search entire apnCfg Tbl.
                        2. Fix for compilation warnings in maNotM03.	
								  3. Modified the function maOpenRspM05 to
									  copy ACN verison to dlgCp in case of ACN 
									  is not supported.
                        4. Initialized dataParam element.
/main/12  ma002.203   dv   1. Introduced maCb global control block.
                           2. Moved global variables to maCb.
                           3. Introduced SS_MULTIPLE_PROCS to aid
                              in internal testing.
                           4. Changed the type of msg len from S16 to
                              MsgLen
/main/12  ma004.203    rb  1. Fix for MAP-PSF compilation issues.
                               a)Passing Version Info pointer to "zjSetVer"										
/main/12  ma007.203    dm  1. Print the Buffer in case of error 
                           2. Modified maDecDlgId() so that MAP treats
                              Object identifier in DlgPDU as optional  
                           3. Added check in maDecDlgId() for optional
                              integer parameter in DlgPDU 
                           4. Added check in maDecDlgId() for optional
                              Object descriptor in DlgPDU 
/main/12 ma008.203     dm  1. To handle the crash in case of -ve suId.
                           2. To Improve the MAP Stack performance  
               		      replacing maBZero with cmZero;
                              which internally call direct system 
                              call(memset()) if not enable 
                              "DONT_USE_SYS_LIB" flag.
			   3. Remove warning and compilation error under
			      various flag combination.	 	
/main/12  ma011.203    dm  1. To Handle crash in case of sap configuration 
                              is not done and try to access maSapLmaPtr.
                           2. i is changed to U32 from U16 to avoid infinite 
                              "for" loop in case of overflow of U16 i.
/main/12  ma012.203    dm  1. Added to support Dlg Hash Size as 
                              Configurable parameter through layer manager.
                           2. Added to support Status Indication in case of 
                              Sap Deletion.
                           3. Introduced New Compilation Flag MAP_NSRP.
/main/12 ma013.203    dm   1. maActvInit should call with reason SHUTDOWN 
                              not with 0(NRM_TERM)if it is shutdown case. 
                           2. Correction SS_INVOKE_NOTIFY is moved in 
                              SS Service.
                           3. If dlgHshSize is power of 2 then do & with 
                              maSpDlgId. 
*********************************************************************91*/
