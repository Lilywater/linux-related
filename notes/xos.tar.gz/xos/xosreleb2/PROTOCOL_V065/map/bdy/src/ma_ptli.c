/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     application - portable - lower interface
  
     Type:     C source file
  
     Desc:     C source code for the MAP lower interface primitives

     File:     ma_ptli.c
  
     Sid:      ma_ptli.c@@/main/9 - Fri Sep 16 02:45:30 2005
   
     Prg:      aa
  
*********************************************************************21*/
  

/*
The following functions are provided in this file:

     MaLiStuBndReq      ma - lower interface - Bind Request
     MaLiStuUbndReq     ma - lower interface - Unbind Request
     MaLiStuDatReq      ma - lower interface - Data Request
     MaLiStuCmpReq      ma - lower interface - Component Request
     MaLiStuSteReq      ma - lower interface - State Request
     MaLiStuSteRsp      ma - lower interface - State Response


It is assumed that the following functions are provided in MAP:

     MaLiStuUDatInd     ma - lower interface - Unit Data Indication
     MaLiStuDatInd      ma - lower interface - Data Indication
     MaLiStuCmpInd      ma - lower interface - Component Indication
     MaLiStuCmpCfm      ma - lower interface - Component Confirm
     MaLiStuNotInd      ma - lower interface - Notice Indication
     MaLiStuSteInd      ma - lower interface - State Indication
     MaLiStuSteCfm      ma - lower interface - State Confirm
*/

 
/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common SS7 */
#include "lma.h"           /* layer manager interface */
#include "stu.h"           /* tcap layer */
#include "mat.h"           /* map interface */
#include "ma.h"
#include "ma_err.h"        /* error defines */
/* ma010.203:Added for WinNT Compilation */
#include "cm5.h"

#ifdef MA_FTHA
#include "sht.h"           /* SHT */
#endif /* MA_FTHA */
#ifdef ZJ
#include "cm_ftha.h"    /* Common FTHA */
#include "cm_pftha.h"   /* Common PSF defines */
#include "cm_psfft.h"
#include "cm_tupsf.h"   /* Common TCAP user PSF */
#include "zj.h"
#include "lzj.h"
#endif /* ZJ */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"		/*xqc add this line  for map compiler*/
#include "cm_ss7.x"        /* common ss7 */
#include "lma.x"           /* layer manager interface */
#include "stu.x"           /* tcap layer */
#include "mat.x"           /* map interface */
#ifdef MA_FTHA
#include "sht.x"           /* SHT */
#endif /* MA_FTHA */

#ifdef ZJ
#include "cm_ftha.x"    /* Common FTHA */
#include "cm_pftha.x"   /* Common PSF defines */
#include "cm_psfft.x"
#include "cm_tupsf.x"   /* Common TCAP user PSF */
#endif /* ZJ */
#include "ma.x"
#ifdef ZJ
#include "zj.x"
#include "lzj.x"
#endif /* ZJ */


/* local defines */
  
#define MAXTCLI   2        /* number of interfaces for TCAP */
#define MAXMALI         2               /* Lower interfaces */

/* local typedefs */

/* local externs */

/* forward references */
/*
EXTERN MaCb maCb;  */

/* portable functions */
#if (!(defined(ST) && defined(LCMALISTU)))

PRIVATE S16 PtLiStuBndReq ARGS((Pst *pst, SuId suId, SpId spId, Ssn ssn));
PRIVATE S16 PtLiStuUbndReq ARGS((Pst *pst, SpId spId, Reason reason));
#ifdef STUV2
PRIVATE S16 PtLiStuDatReq ARGS((Pst *pst, SpId spId, U8 msgType, StDlgId stSuDlgId, StDlgId stSpDlgId, SpAddr *destAddr, SpAddr *srcAddr, Bool stTerm, StQosSet *stQosSet, StDlgEv *stDlgEv, StDataParam *dataParam, Buffer *uiBuf));
#else
PRIVATE S16 PtLiStuDatReq ARGS((Pst *pst, SpId spId, U8 msgType, StDlgId stSuDlgId, StDlgId stSpDlgId, SpAddr *destAddr, SpAddr *srcAddr, Bool stTerm, StQosSet *stQosSet, StDlgEv *stDlgEv, Buffer *uiBuf));
#endif /* STUV2 */
PRIVATE S16 PtLiStuCmpReq ARGS((Pst *pst, SpId spId, StDlgId stSuDlgId,StDlgId stSpDlgId, StComps *stComp, Buffer *cpBuf));
PRIVATE S16 PtLiStuSteReq ARGS((Pst *pst, SpId spId, CmSS7SteMgmt *steMgmt));
PRIVATE S16 PtLiStuSteRsp ARGS((Pst *pst, SpId spId, CmSS7SteMgmt *steMgmt));
#endif /* (!(defined(ST) && defined(LCMALISTU))) */



/* functions in other modules */

/* public variable declarations */


/*

the following matrices define the mapping between the primitives
called by the lower interface of MAP and its providers (most likely
MAP).

The parameter MAXMALI defines the maximum number of service providers 
below MAP. There is an array of functions per primitive
invoked by MAP. Every array is MAXMALI long (i.e. there
are as many functions as the number of service providers plus loosely coupled).
 
The dispatching is performed by the configurable variable: selector.
The selector is configured on a per SAP basis.

*/


/* Bind Request primitive */

PRIVATE StuBndReq maLiStuBndReqMt[MAXMALI] =
{
#ifdef LCMALISTU
   cmPkStuBndReq,      /* 0 - loosely coupled  */
#else
   PtLiStuBndReq,        /* 0 - tightly coupled, portable */
#endif
#if(defined(ST) ||defined(L4))/*xqc add L4 for map test*/
   StUiStuBndReq         /* 1 - tightly coupled, TCAP */
#else
   PtLiStuBndReq         /* 1 - tightly coupled, portable */
#endif
};


/* Unbind Request primitive */

PRIVATE StuUbndReq maLiStuUbndReqMt[MAXMALI] =
{
#ifdef LCMALISTU
   cmPkStuUbndReq,      /* 0 - loosely coupled */
#else
   PtLiStuUbndReq,        /* 0 - tightly coupled, portable */
#endif
#if(defined(ST) ||defined(L4)) /*xqc ADD L4 for map test*/
   StUiStuUbndReq         /* 1 - tightly coupled, TCAP */
#else
   PtLiStuUbndReq         /* 1 - tightly coupled, portable */
#endif
};


/* Component Request primitive */

PRIVATE StuCmpReq maLiStuCmpReqMt[MAXMALI] =
{
#ifdef LCMALISTU
   cmPkStuCmpReq,      /* 0 - loosely coupled */
#else
   PtLiStuCmpReq,        /* 0 - tightly coupled, portable */
#endif
#if(defined(ST) ||defined(L4)) /*xqc ADD L4 for map test*/
   StUiStuCmpReq         /* 1 - tightly coupled, TCAP */
#else
   PtLiStuCmpReq         /* 1 - tightly coupled, portable */
#endif
};


/* Data Request primitive */

PRIVATE StuDatReq maLiStuDatReqMt[MAXMALI] =
{
#ifdef LCMALISTU
   cmPkStuDatReq,     /* 0 - loosely coupled */
#else
   PtLiStuDatReq,       /* 0 - tightly coupled, portable */
#endif
#if(defined(ST) ||defined(L4)) /*xqc ADD L4 for map test*/
   StUiStuDatReq        /* 1 - tightly coupled, TCAP */
#else
   PtLiStuDatReq        /* 1 - tightly coupled, portable */
#endif
};


/* State Request primitive */

PRIVATE StuSteReq maLiStuSteReqMt[MAXMALI] =
{
#ifdef LCMALISTU
   cmPkStuSteReq,      /* 0 - loosely coupled fc */
#else
   PtLiStuSteReq,        /* 0 - tightly coupled, portable */
#endif
#if(defined(ST) ||defined(L4)) /*xqc ADD L4 for map test*/
   StUiStuSteReq         /* 2 - tightly coupled, TCAP */
#else
   PtLiStuSteReq         /* 2 - tightly coupled, portable */
#endif
};


/* State Response primitive */

PRIVATE StuSteRsp maLiStuSteRspMt[MAXMALI] =
{
#ifdef LCMALISTU
   cmPkStuSteRsp,      /* 0 - loosely coupled fc */
#else
   PtLiStuSteRsp,        /* 0 - tightly coupled, portable */
#endif
#if(defined(ST) ||defined(L4)) /*xqc ADD L4 for map test*/
   StUiStuSteRsp         /* 2 - tightly coupled, TCAP */
#else
   PtLiStuSteRsp         /* 2 - tightly coupled, portable */
#endif
};


/*
*     lower interface functions
*/


/*
*
*       Fun:   lower interface - STU Bind Request
*
*       Desc:  This function resolves the Stu Bind Request
*              primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptli.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaLiStuBndReq
(
Pst *pst,             /* post structure */
SuId suId,            /* service user id */
SpId spId,            /* service provider id */
Ssn ssn               /* sub system number */
)
#else
PUBLIC S16 MaLiStuBndReq(pst, suId, spId, ssn)
Pst *pst;              /* post structure */
SuId suId;             /* service user id */
SpId spId;             /* service provider id */
Ssn ssn;               /* sub system number */
#endif
{
   TRC3(MaLiStuBndReq)

   switch (pst->dstEnt)
   {
#ifdef DT
      case ENTST:
         if (pst->route == RTE_PROTO)
            (Void) (*maLiStuBndReqMt[pst->selector])(pst, suId, spId, ssn);
         else
            DtUiStuBndReq(pst, suId, spId, ssn);
         break;
#endif /* DT */
      default:
             /* jump to specific primitive in service user, depending on 
             selector configured */
             (Void) (*maLiStuBndReqMt[pst->selector])(pst, suId, spId, ssn);
             break;
   }

   RETVALUE(ROK);
} /* end of MaLiStuBndReq */



/*
*
*       Fun:   lower interface - STU Unbind Request
*
*       Desc:  This function resolves the Stu Unbind Request
*              primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptli.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaLiStuUbndReq
(
Pst *pst,             /* post structure */
SpId spId,            /* service provider id */
Reason reason
)
#else
PUBLIC S16 MaLiStuUbndReq(pst, spId, reason)
Pst *pst;              /* post structure */
SpId spId;             /* service provider id */
Reason reason;
#endif
{
   TRC3(MaLiStuUbndReq)

   switch (pst->dstEnt)
   {
#ifdef DT
      case ENTST:
         if (pst->route == RTE_PROTO)
            (Void) (*maLiStuUbndReqMt[pst->selector])(pst, spId, reason);
         else
            DtUiStuUbndReq(pst, spId, reason);
         break;
#endif /* DT */
      default:
             /* jump to specific primitive in service user, depending on 
             selector configured */
            (Void) (*maLiStuUbndReqMt[pst->selector])(pst, spId, reason);
            break;
   }

   RETVALUE(ROK);
} /* end of MaLiStuUbndReq */


/*
*
*       Fun:   lower interface - STU Component Request
*
*       Desc:  This function resolves the Stu Component Request
*              primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptli.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaLiStuCmpReq
(
Pst *pst,                   /* post structure */
SpId spId,                  /* service provider id */
StDlgId stSuDlgId,          /* dialog id */
StDlgId stSpDlgId,          /* dialog id */
StComps *stComp,            /* component */
Buffer  *cpBuf              /* Component parameter buffer */
)
#else
PUBLIC S16 MaLiStuCmpReq(pst, spId, stSuDlgId, stSpDlgId, stComp,cpBuf)
Pst *pst;                   /* post structure */
SpId spId;                  /* service provider id */
StDlgId stSuDlgId;          /* dialog id */
StDlgId stSpDlgId;          /* dialog id */
StComps *stComp;            /* component */
Buffer  *cpBuf;             /* Component parameter buffer */
#endif
{
   TRC3(MaLiStuCmpReq)

   switch (pst->dstEnt)
   {
#ifdef DT
      case ENTST:
         if (pst->route == RTE_PROTO)
            (Void) (*maLiStuCmpReqMt[pst->selector])(pst, spId, stSuDlgId,
                                   stSpDlgId,stComp,cpBuf);
         else
            DtUiStuCmpReq(pst, spId, stSuDlgId, stSpDlgId,stComp,cpBuf);
         break;
#endif /* DT */
      default:
             /* jump to specific primitive in service user, depending on 
             selector configured */
            (Void) (*maLiStuCmpReqMt[pst->selector])(pst, spId, stSuDlgId,
                                   stSpDlgId,stComp,cpBuf);
            break;
   }

   RETVALUE(ROK);
} /* end of MaLiStuCmpReq */


/*
*
*       Fun:   lower interface - STU Data Request
*
*       Desc:  This function resolves the STU Data Request
*              primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptli.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaLiStuDatReq
(
Pst *pst,                   /* post structure */
SpId spId,                  /* service provider id */
U8 msgType,                 /* message type */
StDlgId stSuDlgId,          /* dialog id */
StDlgId stSpDlgId,          /* dialog id */
SpAddr *destAddr,           /* destination address */
SpAddr *srcAddr,            /* source address */
Bool stTerm,                /* terminate dialog */
StQosSet *stQosSet,         /* TCAP Quality of service */
StDlgEv *stDlgEv,           /* tcap dialog portion event */
#ifdef STUV2
StDataParam  *dataParam,    /* data parameter */
#endif
Buffer *uiBuf               /* tcap dialog portion user info buffer */
)
#else
#ifdef STUV2
PUBLIC S16 MaLiStuDatReq(pst, spId, msgType, stSuDlgId, stSpDlgId, destAddr, srcAddr, stTerm, stQosSet, stDlgEv, dataParam, uiBuf)
#else
PUBLIC S16 MaLiStuDatReq(pst, spId, msgType, stSuDlgId, stSpDlgId, destAddr, srcAddr, stTerm, stQosSet, stDlgEv,uiBuf)
#endif /* STUV2 */
Pst *pst;                   /* post structure */
SpId spId;                  /* service provider id */
U8 msgType;                 /* message type */
StDlgId stSuDlgId;          /* dialog id */
StDlgId stSpDlgId;          /* dialog id */
SpAddr *destAddr;           /* destination address */
SpAddr *srcAddr;            /* source address */
Bool stTerm;                /* terminate dialog */
StQosSet *stQosSet;         /* TCAP Quality of service */
StDlgEv *stDlgEv;           /* tcap dialog portion event */
#ifdef STUV2
StDataParam *dataParam;     /* data parameter */
#endif /* STUV2 */
Buffer *uiBuf;              /* tcap dialog portion user info buffer */
#endif
{
   TRC3(MaLiStuDatReq)

   switch (pst->dstEnt)
   {
#ifdef DT
      case ENTST:
#ifdef STUV2
         if (pst->route == RTE_PROTO)
            (Void)(*maLiStuDatReqMt[pst->selector])(pst, spId, msgType, 
                                stSuDlgId, stSpDlgId, destAddr, srcAddr, 
                                stTerm, stQosSet, stDlgEv, dataParam, uiBuf);
         else
            DtUiStuDatReq(pst, spId, msgType, stSuDlgId, 
                                stSpDlgId, destAddr, srcAddr, 
                                stTerm, stQosSet, stDlgEv, dataParam, uiBuf);
#else
         if (pst->route == RTE_PROTO)
            (Void)(*maLiStuDatReqMt[pst->selector])(pst, spId, msgType, 
                                stSuDlgId, stSpDlgId, destAddr, srcAddr, 
                                stTerm, stQosSet, stDlgEv,uiBuf);
         else
            DtUiStuDatReq(pst, spId, msgType, stSuDlgId, 
                                stSpDlgId, destAddr, srcAddr, 
                                stTerm, stQosSet, stDlgEv,uiBuf);
#endif /* STUV2 */
         break;
#endif /* DT */
      default:
             /* jump to specific primitive in service user, depending on 
             selector configured */
#ifdef STUV2
            (Void)(*maLiStuDatReqMt[pst->selector])(pst, spId, msgType, 
                                stSuDlgId, stSpDlgId, destAddr, srcAddr, 
                                stTerm, stQosSet, stDlgEv, dataParam, uiBuf);
#else
            (Void)(*maLiStuDatReqMt[pst->selector])(pst, spId, msgType, 
                                stSuDlgId, stSpDlgId, destAddr, srcAddr, 
                                stTerm, stQosSet, stDlgEv,uiBuf);
#endif
                  break;
   }

   RETVALUE(ROK);
} /* end of MaLiStuDatReq */


/*
*
*       Fun:   lower interface - STU State Request
*
*       Desc:  This function resolves the Stu State Request
*              primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptli.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaLiStuSteReq
(
Pst *pst,                   /* post structure */
SpId spId,                  /* service provider id */
CmSS7SteMgmt *steMgmt       /* component */
)
#else
PUBLIC S16 MaLiStuSteReq(pst, spId,steMgmt)
Pst *pst;                   /* post structure */
SpId spId;                  /* service provider id */
CmSS7SteMgmt *steMgmt;       /* component */
#endif
{
   TRC3(MaLiStuSteReq)

   switch (pst->dstEnt)
   {
#ifdef DT
      case ENTST:
         if (pst->route == RTE_PROTO)
            (Void) (*maLiStuSteReqMt[pst->selector])(pst, spId, steMgmt); 
         else
            DtUiStuSteReq(pst, spId, steMgmt);
         break;
#endif /* DT */
      default:
           /* jump to specific primitive in service user, depending on 
           selector configured */
            (Void) (*maLiStuSteReqMt[pst->selector])(pst, spId, steMgmt); 
                  break;
   }

   RETVALUE(ROK);
} /* end of MaLiStuSteReq */


/*
*
*       Fun:   lower interface - STU State Response
*
*       Desc:  This function resolves the Stu State Response
*              primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptli.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaLiStuSteRsp
(
Pst *pst,                   /* post structure */
SpId spId,                  /* service provider id */
CmSS7SteMgmt *steMgmt       /* component */
)
#else
PUBLIC S16 MaLiStuSteRsp(pst, spId,steMgmt)
Pst *pst;                   /* post structure */
SpId spId;                  /* service provider id */
CmSS7SteMgmt *steMgmt;       /* component */
#endif
{
   TRC3(MaLiStuSteRsp)

   switch (pst->dstEnt)
   {
#ifdef DT
      case ENTST:
         if (pst->route == RTE_PROTO)
            (Void) (*maLiStuSteRspMt[pst->selector])(pst, spId, steMgmt); 
         else
            DtUiStuSteRsp(pst, spId, steMgmt);
         break;
#endif /* DT */
      default:
            /* jump to specific primitive in service user, depending on 
             selector configured */
            (Void) (*maLiStuSteRspMt[pst->selector])(pst, spId, steMgmt); 
                  break;
   }

   RETVALUE(ROK);
} /* end of MaLiStuSteRsp */


/*
*     portable functions 
*/

#if (!(defined(ST) && defined(LCMALISTU)))

/*
*
*       Fun:   portable - STU Bind Request
*
*       Desc:  This function binds the STU layer service user
*              with the STU layer service provider. The STU
*              layer software will register this new service
*              user and will allocate a Service Access Point (SAP) for
*              this bind. The service user will specify the reference
*              number that will be used for the duration of this bind.
*              The Control Block for service provider is the STU
*              Layer SAP, while the Control Block for the
*              service user is dependent on the protocol.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptli.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtLiStuBndReq
(
Pst *pst,             /* post */
SuId suId,            /* service user id */
SpId spId,            /* service provider id */
Ssn ssn               /* sub system number */
)
#else
PRIVATE S16 PtLiStuBndReq(pst, suId, spId, ssn)
Pst *pst;             /* post */
SuId suId;            /* service user id */
SpId spId;            /* service provider id */
Ssn ssn;              /* sub system number */
#endif
{            
   TRC3(PtLiStuBndReq)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA336, (ErrVal)0, "PtLiStuBndReq () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtLiStuBndReq  */


/*
*
*       Fun:   portable - STU Unbind Request
*
*       Desc:  This function unbinds the STU layer service user
*              with the STU layer service provider. 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptli.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtLiStuUbndReq
(
Pst *pst,             /* post */
SpId spId,            /* service provider id */
Reason reason
)
#else
PRIVATE S16 PtLiStuUbndReq(pst, spId, reason)
Pst *pst;             /* post */
SpId spId;            /* service provider id */
Reason reason;
#endif
{            
   TRC3(PtLiStuUbndReq)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA337, (ErrVal)0, "PtLiStuUbndReq () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtLiStuUbndReq  */


/*
*
*       Fun:   portable - STU Component Request
*
*       Desc:  This function binds the STU layer service user
*              with the STU layer service provider. The STU
*              layer software will register this new service
*              user and will allocate a Service Access Point (SAP) for
*              this bind. The service user will specify the reference
*              number that will be used for the duration of this bind.
*              The Control Block for service provider is the STU
*              Layer SAP, while the Control Block for the
*              service user is dependent on the protocol.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptli.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtLiStuCmpReq
(
Pst *pst,                   /* post structure */
SpId spId,                  /* service provider id */
StDlgId stSuDlgId,          /* dialog id */
StDlgId stSpDlgId,          /* dialog id */
StComps *stComp,            /* component */
Buffer  *cpBuf              /* Component parameter buffer */
)
#else
PRIVATE S16 PtLiStuCmpReq(pst, spId, stSuDlgId, stSpDlgId, stComp,cpBuf)
Pst *pst;                   /* post structure */
SpId spId;                  /* service provider id */
StDlgId stSuDlgId;          /* dialog id */
StDlgId stSpDlgId;          /* dialog id */
StComps *stComp;            /* component */
Buffer  *cpBuf;             /* Component parameter buffer */
#endif
{            
   TRC3(PtLiStuCmpReq)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA338, (ErrVal)0, "PtLiStuCmpReq () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtLiStuCmpReq  */


/*
*
*       Fun:   portable - STU Data Request
*
*       Desc:  This function is used to transmit a message.
*              Whether or not a MADatCfm is issued after the data
*              is transmitted depends on the buffer ownership and
*              flow control type.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptli.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtLiStuDatReq
(
Pst *pst,                   /* post structure */
SpId spId,                  /* service provider id */
U8 msgType,                 /* message type */
StDlgId stSuDlgId,          /* dialog id */
StDlgId stSpDlgId,          /* dialog id */
SpAddr *destAddr,           /* destination address */
SpAddr *srcAddr,            /* source address */
Bool stTerm,                /* terminate dialog */
StQosSet *stQosSet,         /* TCAP Quality of service */
StDlgEv *stDlgEv,           /* tcap dialog portion event */
#ifdef STUV2
StDataParam *dataParam,     /* Data Parameter */
#endif /* STUV2 */
Buffer *uiBuf               /* tcap dialog portion user info buffer */
)
#else
#ifdef STUV2
PRIVATE S16 PtLiStuDatReq(pst, spId, msgType, stSuDlgId, stSpDlgId, destAddr, srcAddr, stTerm, stQosSet, stDlgEv, dataParam, uiBuf)
#else
PRIVATE S16 PtLiStuDatReq(pst, spId, msgType, stSuDlgId, stSpDlgId, destAddr, srcAddr, stTerm, stQosSet, stDlgEv,uiBuf)
#endif
Pst *pst;                   /* post structure */
SpId spId;                  /* service provider id */
U8 msgType;                 /* message type */
StDlgId stSuDlgId;          /* dialog id */
StDlgId stSpDlgId;          /* dialog id */
SpAddr *destAddr;           /* destination address */
SpAddr *srcAddr;            /* source address */
Bool stTerm;                /* terminate dialog */
StQosSet *stQosSet;         /* TCAP Quality of service */
StDlgEv *stDlgEv;           /* tcap dialog portion event */
#ifdef STUV2
StDataParam *dataParam;     /* Data Parameter */
#endif /* STUV2 */
Buffer *uiBuf;              /* tcap dialog portion user info buffer */
#endif
{
   TRC3(PtLiStuDatReq)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA339, (ErrVal)0, "PtLiStuDatReq () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtLiStuDatReq */


/*
*
*       Fun:   lower interface - STU State Request
*
*       Desc:  This function is used to request a state change of Sub System
*              number or a Point Code.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptli.c
*
*/
  
#ifdef ANSI
PUBLIC S16 PtLiStuSteReq
(
Pst *pst,                   /* post structure */
SpId spId,                  /* service provider id */
CmSS7SteMgmt *steMgmt       /* component */
)
#else
PUBLIC S16 PtLiStuSteReq(pst, spId,steMgmt)
Pst *pst;                   /* post structure */
SpId spId;                  /* service provider id */
CmSS7SteMgmt *steMgmt;       /* component */
#endif
{
   TRC3(PtLiStuSteReq)

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(steMgmt);
#if (ERRCLASS & ERRCLS_DEBUG)
   MALOGERROR(ERRCLS_DEBUG, EMA340, (ErrVal)0, "PtLiStuSteReq() Failed");
#endif
   RETVALUE(ROK);
} /* end of PtLiStuSteReq */


/*
*
*       Fun:   lower interface - STU State Response
*
*       Desc:  This function is used to response to a state change indication
*              of Sub System number. 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptli.c
*
*/
  
#ifdef ANSI
PUBLIC S16 PtLiStuSteRsp
(
Pst *pst,                   /* post structure */
SpId spId,                  /* service provider id */
CmSS7SteMgmt *steMgmt       /* component */
)
#else
PUBLIC S16 PtLiStuSteRsp(pst, spId,steMgmt)
Pst *pst;                   /* post structure */
SpId spId;                  /* service provider id */
CmSS7SteMgmt *steMgmt;       /* component */
#endif
{
   TRC3(PtLiStuSteRsp)

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(steMgmt);
#if (ERRCLASS & ERRCLS_DEBUG)
   MALOGERROR(ERRCLS_DEBUG, EMA341, (ErrVal)0, "PtLiStuSteRsp() Failed");
#endif
   RETVALUE(ROK);
} /* end of PtLiStuSteRsp */
#endif /* (!(defined(ST) && defined(LCMALISTU))) */



/********************************************************************30**
  
         End of file:     ma_ptli.c@@/main/9 - Fri Sep 16 02:45:30 2005
  
*********************************************************************31*/
  

/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

 
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  aa   1. initial release

*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.2          ---      aa   1. Include cm_ss7.h
             ---      aa   2. Corrected the flag LCTULISTU to LCMALISTU 

1.3          ---      ssk  1. Added Phase 2+ variant
1.4          ---      jz   1. Interface with LDF-TCAP was added.
/main/4      ---      jie  1. update for MAP 1.5 release.
/main/5      ---      jie  1. update for MAP 1.6 release.

/main/6      ---      jie  1. update for MAP 1.7 release.

/main/8      ---      cp   1. update for MAP release 2.2
/main/9      ---      rbabu 1. update for MAP release 2.3
         ma002.203    dv   1. Introduced maCb global control block.
                           2. Moved global variabled to maCb.
                           3. Introduced SS_MULTIPLE_PROCS to aid
                              in internal testing.
/main/9 ma010.203    dm   1. cm5.h and cm5.x are added for winNT compilation
*********************************************************************91*/
