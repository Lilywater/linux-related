/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     map
  
     Type:     C Source file
  
     Desc:     C source code for database functions
  
     File:     ca_mf.c
  
     Sid:      ca_mf.c@@/main/11 - Fri Sep 16 02:48:20 2005
  
     Prg:      ssk
  
*********************************************************************21*/


/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#if MAP_MSC
#if MAP_VLR
#if MAP_HLR
      -05      MSC, VLR and HLR
#else
#endif
#else
#if MAP_HLR
#else
      -01      MSC
#endif
#endif
#else
#if MAP_VLR
#if MAP_HLR
      -04      VLR and HLR
#else
      -02      VLR
#endif
#else
#if MAP_HLR
      -03      HLR
#else
#endif
#endif
#endif

************************************************************************/
 

/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "lma.h"           /* layer management, MAP */
#include "cm_err.h"        /* common error */
#include "stu.h"           /* tcap layer */
#include "mat.h"           /* map layer */
#ifdef MA_RUG
#include "sht.h"
#endif /* MA_RUG */
#include "cm5.h"
#include "ma.h"            /* map */
#include "ma_mf.h"
#include "ma_err.h"        /* map error */
#ifdef ZJ
#include "cm_ftha.h"       /* Common FTHA */
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#include "cm_tupsf.h"      /* Common TCAP user PSF */
#endif /* ZJ */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"
#include "cm_ss7.x"        /* SS7 common */
#include "stu.x"           /* tcap layer */
#include "lma.x"           /* layer management, TCAP */
#include "mat.x"           /* map  layer */
#ifdef MA_FTHA
#include "sht.x"
#endif /* MA_FTHA */
#ifdef ZJ
#include "cm_ftha.x"       /* Common FTHA */
#include "cm_pftha.x"      /* Common PSF defines */
#include "cm_psfft.x"
#include "cm_tupsf.x"      /* Common TCAP user PSF */
#endif /* ZJ */
#include "ma.x"            /* map */

EXTERN S16  maEncOctet ARGS((MaMsgCtl *ctlp, Bool chkEnum));
EXTERN S16  maEncNull  ARGS((MaMsgCtl *ctlp));
EXTERN S16  maEncStr ARGS((MaMsgCtl *ctlp));
EXTERN S16  maEncBitStr ARGS((MaMsgCtl *ctlp));
EXTERN S16  maEncChoice ARGS((MaMsgCtl *ctlp));
EXTERN S16  maEncSeqOf ARGS((MaMsgCtl *ctlp, S32 cntr, MaTknElmtDef **stTelDef));
EXTERN S16  maSkipTkns ARGS((MaMsgCtl *ctlp));
EXTERN S16  maSkipSeq ARGS((MaMsgCtl *ctlp));
EXTERN S16  maSkipSeqOf ARGS((MaMsgCtl *ctlp));
EXTERN S16  maDecOctet ARGS((MaMsgCtl *ctlp, Bool chkEnum));
EXTERN S16  maDecNull  ARGS((MaMsgCtl *ctlp));
EXTERN S16  maDecStr ARGS((MaMsgCtl *ctlp));
EXTERN S16  maDecBitStr ARGS((MaMsgCtl *ctlp));
EXTERN S16  maDecSeqOf ARGS((MaMsgCtl *ctlp));
EXTERN S16  maDecChoice ARGS((MaMsgCtl *ctlp));
EXTERN S16  maSkipChoice ARGS((MaMsgCtl *ctlp));
EXTERN S16  maGetTag ARGS((MaMsgCtl *ctlp, U8 *pkArray, U16 offset, U8 *size));
EXTERN S16  maEncInt ARGS((MaMsgCtl *ctlp));
EXTERN S16  maDecInt ARGS((MaMsgCtl *ctlp));
EXTERN S16 maEncTagChoice ARGS(( MaMsgCtl *ctlp ));
EXTERN S16 maDecTagChoice ARGS(( MaMsgCtl *ctlp  ));

PRIVATE S16  maEncStrUL ARGS((MaMsgCtl *ctlp));
PRIVATE S16  maDecStrUL ARGS((MaMsgCtl *ctlp));
PRIVATE S16  maEncEscSeq ARGS((MaMsgCtl *ctlp));
PRIVATE S16  maDecEscSeq ARGS((MaMsgCtl *ctlp));
PRIVATE S16  maDecExtSeqOf ARGS((MaMsgCtl *ctlp));
PRIVATE S16  maEncExtSeqOf ARGS((MaMsgCtl *ctlp, S32 cntr, MaTknElmtDef **stTelDef));
#if MAP_REL99
PRIVATE S16  maEncMinSeqOf ARGS((MaMsgCtl *ctlp, S32 cntr, MaTknElmtDef **stTelDef, S32 minSize));
PRIVATE S16  maDecMinSeqOf ARGS((MaMsgCtl *ctlp, S32 minSize));
#endif

/* forward references */
PRIVATE S16 maInitMsgCtl ARGS((MaMsgCtl *ctlp));
PRIVATE S16 maEncTknElmts ARGS((MaMsgCtl *ctlp));
PRIVATE S16 maDecTknElmts ARGS((MaMsgCtl *ctlp));
PRIVATE S16 maChkEnum ARGS ((U8 val, MaTknElmtDef *teDef, Swtch swtch));
PRIVATE S16 maChkEleMand ARGS ((MaMsgCtl *ctlp));
PRIVATE S16 maChkEncElmnt ARGS((MaMsgCtl *ctlp));
PRIVATE S16 maChkTag ARGS((MaMsgCtl *ctlp, U8 *pkArray, U8 size, Bool *skipElmnt));

#define MA_SKIP 13
#define MA_BAD_IDX 1 /* Bad Index */
#define MAX_TAG_LEN 1 /* Bad Index */
#define TAG_MORE_BIT 1 /* Bad Index */
#define STR_BUFSIZE 1 /* Bad Index */
#define EOC_TAG_LEN 1 /* Bad Index */
#define MA_MAND_MISS 35 /* Bad Index */
#define MA_TAG_ERR  1 /* Bad Index */
#define EMP_SEQ    10
#define NON_EMP_SEQ 11

#ifdef DEBUGP
PRIVATE Txt   maEleType[MA_NMB_OF_TET][16] = 
{
  {"MA_NO_ELEM"},
  {"MA_TET_NULL"},
  {"MA_TET_U8"},
  {"MA_TET_U8_ENUM"},
  {"MA_TET_INT"},
  {"MA_TET_STRS"},
  {"MA_TET_STR"},
  {"MA_TET_STRM"},
  {"MA_TET_STRE"},
  {"MA_TET_SEQ"},
  {"MA_TET_SEQ_OF"},
  {"MA_TET_SEQ_TERM"},
  {"MA_TET_CHOICE"},
  {"MA_TET_BITSTR"},
  {"MA_TET_STRUL"},
  {"MA_TET_EXT_CONT"},
  {"MA_TET_OBJID"},
}; 
#endif 


/*
*
*       Fun:   maInitMsgCtl 
*
*       Desc:  This function initializes the message control structure 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maInitMsgCtl 
(
 MaMsgCtl  *ctlp        /* message control pointer */
)
#else
PRIVATE S16 maInitMsgCtl (ctlp)
 MaMsgCtl  *ctlp;       /* message control pointer */
#endif
{
  TRC2(maInitMsgCtl)
   ctlp->decode = FALSE;         /* decode flag */
   ctlp->encode = FALSE;         /* encode flag */
   ctlp->skip   = FALSE;         /* skip flag */
   ctlp->swtch  = 0;             /* switch type */
   ctlp->mBuf   = NULLP;         /* msg buffer */
   ctlp->sSt    = NULLP;         /* src structure */ 
   ctlp->sTelDef= NULLP;         /* token list def in database */
   ctlp->maVer  = 0;             /* Map version */
   ctlp->errCode = 0;            /* error code */
#ifdef MA_SEG
   ctlp->level=0;
   ctlp->offLevel=0;
   ctlp->mandFlg1=FALSE;
   ctlp->mandFlg2=FALSE;
   ctlp->offIdx=0;
   cmZero((Data *)&ctlp->offset[0],(MA_MAX_SEGMENTS * sizeof(U32)));
#ifdef DEBUGP
   ctlp->offIdx1=0;
   cmZero((Data *)&ctlp->offset1[0],(MA_MAX_SEGMENTS * sizeof(U32)));
#endif /* DEBUGP */
#endif /* MA_SEG */
   RETVALUE(ROK);
} /* maInitMsgCtl */


/*
*
*       Fun:   maEncOprPar  
*
*       Desc:  This function encodes the parameters for MAP
*              Service Specific request 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC  S16 maEncOprPar
(
MaSap        *s,        /* Map SAP pointer */
U8           *sSt,      /* pointer to source structure */
U8           maVer,     /* Map version used for encoding */
U8           swtch,     /* switch */ 
U8           type,      /* type of data base to access */
U16          idx        /* Source message index */
)
#else
PUBLIC S16 maEncOprPar (s, sSt, maVer, swtch, type, idx)
MaSap        *s;        /* Map SAP pointer */
U8           *sSt;      /* pointer to source structure */
U8           maVer;     /* Map version used for encoding */
U8           swtch;     /* switch */ 
U8           type;      /* type of data base to access */
U16          idx;       /* Source message index */
#endif
{
  Buffer *mBuf;
  MaMsgCtl *ctlp;
  S16    ret;

  TRC2(maEncOprPar)
  if ((ret = SGetMsg(s->maPstST.region, s->maPstST.pool, &mBuf )) != ROK)
  {
    RETVALUE(ret);
  }
  ctlp = &s->ctlp;
  maInitMsgCtl(ctlp);
  ctlp->mBuf = mBuf;
  ctlp->sSt = sSt;  
  ctlp->maVer = maVer;
  ctlp->swtch = swtch;
  ctlp->encode = TRUE;

  /* get the appropriate database definition based on database type */

  switch(type)
  {
     case MAT_SS_REQ:
     {
        ctlp->sTelDef = maAllSSReqPDUDefs[idx].telDef;
        break;
     }
     case MAT_SS_RSP:
     {
        ctlp->sTelDef = maAllSSRspPDUDefs[idx].telDef;
        break;
     }
     case MAT_SS_RETERR:
     {
        ctlp->sTelDef = maAllSSErrPduDefs[idx];
        break;
     }
     default:
     {
        MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf,
        "maEncOprPar()failed, invalid database type(%d).\n", type));
        RETVALUE(RFAILED);
     }

  } /* end switch */

  /* encode the message parameters */
  ret = maEncTknElmts(ctlp);
  RETVALUE(ret);

} /* maEncOprPar */


/*
*
*       Fun:   maEncTknElmts 
*
*       Desc:  This function encodes the token elements  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maEncTknElmts 
(
MaMsgCtl     *ctlp      /* message control pointer */
)
#else
PRIVATE S16 maEncTknElmts (ctlp)
MaMsgCtl     *ctlp;     /* message control pointer */
#endif
{
  MaTknElmtDef *teDef;
  S16          ret;

  TRC2(maEncTknElmts)

 
  while(*ctlp->sTelDef != (MaTknElmtDef *)NULLP)
  {
     teDef = *ctlp->sTelDef;

     MA_INCREASE_LEVEL;
     /* Start encoding the tokens */
     switch(teDef->type)
     {
        case MA_TET_U8:
          ret = maEncOctet(ctlp,FALSE);
          break;
        case MA_TET_U8_ENUM:
          ret = maEncOctet(ctlp,TRUE);
          break;
        case MA_TET_NULL:
          ret = maEncNull(ctlp);
          break;
        case MA_TET_INT:
          ret = maEncInt(ctlp);
          break;
        case MA_TET_STR:
        case MA_TET_STRS:
        case MA_TET_STRM:
        case MA_TET_STRE:
#ifdef XWEXT
	  case MA_TET_STR4:
#endif
          ret = maEncStr(ctlp);
          break;
        case MA_TET_STRUL:
          ret = maEncStrUL(ctlp);
          break;
        case MA_TET_BITSTR:
          ret = maEncBitStr(ctlp);
          break;
        case MA_TET_SEQ:
        case MA_TET_EXT_CONT:
          ret = maEncSeq(ctlp);
          break;
        case MA_TET_SEQ_OF:
          ret = maEncSeqOf(ctlp,teDef->repCntr, ctlp->sTelDef);
          break;
        case MA_TET_CHOICE:
          ret = maEncChoice(ctlp);
          break;
        default:
          ret = RFAILED;
          break;
     }
     MA_DECREASE_LEVEL;
     if ((ret != ROK) && (ret != EMP_SEQ) && (ret != NON_EMP_SEQ))
     {
       MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf,
       "maEncTknElmts()failed, invalid encoding type(%d)\n", teDef->type));
       RETVALUE(RFAILED);
     }
  }
  RETVALUE(ROK);
} /* end of maEncTknElmts */



/*
 *
 *      Fun:   maBumpStp
 *
 *      Desc:  increments address pointer, "addr", by "len".
 *             used to access structures during encoding/decoding.
 *
 *      Ret:   ROK      - add successful
 *             RFAILED  - add unsuccessful
 *
 *      Notes: None
 *
        File:  ca_mf.c
 *
 */
 
#ifdef ANSI
PRIVATE S16 maBumpStp
(
PTR *addr,     /* address pointer */
U32 len        /* length by which to increment the pointer */
)
#else
PRIVATE S16 maBumpStp(addr, len)
PTR *addr;     /* address pointer */
U32 len;       /* length by which to increment the pointer */
#endif
{
   TRC2(maBumpStp)
#ifdef DOS
#ifdef PTRFAR
   U32 seg;
   U32 off;


   seg = *addr & 0xffff0000;
   off = (*addr & 0xffff);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (!seg)
   {
      MALOGERROR(ERRCLS_DEBUG, EMA281, (ErrVal)0, "maBumpStp () Failed");
      RETVALUE(RFAILED);
   }
#endif

   off += len;
   seg += ((off & 0xffff0000) << 12);
   *addr = seg | (off & 0xffff);
#else

   *addr += len;
#endif
#else

   *addr += len;
#endif

   RETVALUE(ROK);
} /* end of maBumpStp */


/*
*
*       Fun:   maChkEncElmnt   
*
*       Desc:  This routine checks whether the element definition  
*              in the database supports the indicated protocol. It also 
*              checks for a mandatory element which might be missing.
*
*       Ret:   ROK  - element present and defined by the protocol
*             RFAILED - element invalid and present  or mandatory and missing
*             RSKIP   - element optional or invalid and not present
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkEncElmnt 
(
MaMsgCtl  *ctlp         /* message control pointer */
)
#else
PUBLIC S16 maChkEncElmnt (ctlp)
MaMsgCtl  *ctlp;        /* message control pointer */
#endif
{
  MaTknElmtDef *teDef;
  TknU8      *tSt;

  TRC2(maChkEncElmnt)

  teDef = *ctlp->sTelDef;
  tSt = (TknU8 *)ctlp->sSt;

  /* check for the version */

  if ( ((ctlp->maVer == LMA_VER1)  && !(IS_EQUAL_VER1(teDef->verFlg)))  ||
       ((ctlp->maVer == LMA_VER2)  && !(IS_EQUAL_VER2(teDef->verFlg)))  ||
       ((ctlp->maVer == LMA_VER2P) && !(IS_EQUAL_VER2P(teDef->verFlg))) ||
       ((ctlp->maVer == LMA_VER4)  && !(IS_EQUAL_VER4(teDef->verFlg)))
     )
  {
      if (tSt->pres == TRUE)
      {
        MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf,
        "maChkEncElmnt()failed, invalid src structure.\n"));
        RETVALUE(RFAILED);
      }
      else
      {
         /* skip tokens in event structure and increments the data base
          * pointer appropriately */
         maSkipTkns(ctlp);
         RETVALUE(RSKIP);
      }
  }
     
  /* check if element is present */
  if (tSt->pres == FALSE)
  {
    /* check if element is mandatory */
    if (  ((ctlp->maVer == LMA_VER1)  && (teDef->flag & MA_TF_VER1_MAND))   || 
          ((ctlp->maVer == LMA_VER2)  && (teDef->flag & MA_TF_VER2_MAND))   || 
          ((ctlp->maVer == LMA_VER2P) && (teDef->flag & MA_TF_VER2P_MAND))  
#if (MAP_REL98 || MAP_REL99)  
          || ((ctlp->maVer == LMA_VER4)  && (teDef->flag & MA_TF_VER4_MAND))  
#endif
       )
    {
       ctlp->errCode = MAT_DATA_MISSING;
       /* mandatory element is missing */
       RETVALUE(MAT_DATA_MISSING);
    }
    else
    {
       /* element not mandatory, skip it */
       maSkipTkns(ctlp);
       RETVALUE(MA_SKIP);
    }
  }
  RETVALUE(ROK);
}


/*
*
*       Fun:   maEncOctet   
*
*       Desc:  This function encodes an octet 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maEncOctet 
(
MaMsgCtl  *ctlp,        /* message control pointer */
Bool      chkEnum       /* flag indicating token value is enumerated */
)
#else
PUBLIC S16 maEncOctet (ctlp,chkEnum)
MaMsgCtl  *ctlp;        /* message control pointer */
Bool      chkEnum;      /* flag indicating token value is enumerated */
#endif
{
  MaTknElmtDef *teDef;
  U8         val;
  S16        ret;
  TknU8      *tSt;
  Data       pkArray[MA_MAX_PKARRAY_LEN];

  TRC2(maEncOctect)

  teDef = *ctlp->sTelDef;
  tSt = (TknU8 *)ctlp->sSt;

  MA_UPD_MAND_FLG
  /* check element for protocol type and mandatory/optional flags */
  if ((ret = maChkEncElmnt(ctlp)) != ROK)
  {
     if (ret == RSKIP)
     {
        RETVALUE(ROK);
     }
     RETVALUE(ret);
  }

  pkArray[0] = teDef->tag;
  pkArray[1] = (Data)1;

  val = tSt->val;
#ifndef MAACC_EXCEPTION_TST
  if (chkEnum)
  {
    if ((ret = maChkEnum(val, teDef, 0)) != ROK)
      RETVALUE(ret);
  }
#endif /* MAACC_EXCEPTION_TST */

  pkArray[2] = val;

  /* encode the octet  */ 
  ret = SAddPstMsgMult(pkArray, (MsgLen)3, ctlp->mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
  if (ret != ROK)
  {
     MALOGERROR(ERRCLS_ADD_RES, EMA282, (ErrVal)ret, "SAddPstMsgMult() Failed");
     RETVALUE(ret);
  }
#endif

  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maEncOctect: %s Tag [%x] Len [%x] Val [%x] \n", 
          maEleType[teDef->type], pkArray[0], pkArray[1], pkArray[2]));

  MA_UPD_OFFSET_ARRAY

  /* bump structure pointer in message control */
  MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
  ctlp->sTelDef++;
  RETVALUE(ROK);

} /* maEncOctect */


/*
*
*       Fun:   maEncStr   
*
*       Desc:  This function encodes an octet string 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maEncStr 
(
MaMsgCtl  *ctlp         /* message control pointer */
)
#else
PUBLIC S16 maEncStr (ctlp)
MaMsgCtl  *ctlp;        /* message control pointer */
#endif
{
  MaTknElmtDef *teDef;
  TknStrS    *strS;   /* token string size - small */
  TknStrM    *strM;   /* token string size - medium */
  TknStr     *str;    /* token string size - regular */
  TknStrE    *strE;   /* token string size - large */
#ifdef XWEXT
  TknStr4   *str4;
#endif
  U8         len;
  MsgLen     tmpLen;
  U8         *val;
  S16        ret;
  U8         i;
  Data       pkArray[MA_MAX_PKARRAY_LEN];

  TRC2(maEncStr)

  teDef = *ctlp->sTelDef;

  MA_UPD_MAND_FLG
  /* check if there is a user function */
  if (teDef->func)
  {
     ret = (*teDef->func)(ctlp);
     MA_UPD_OFFSET_ARRAY
     RETVALUE(ret);
  }

  /* check element for protocol type and mandatory/optional flags */
  if ((ret = maChkEncElmnt(ctlp)) != ROK)
  {
     if (ret == RSKIP)
     {
        RETVALUE(ROK);
     }
     RETVALUE(ret);
  }
  switch (teDef->type)
  {
     case MA_TET_STR:
      str = (TknStr *)ctlp->sSt;
      len = str->len;
      val = &str->val[0];
      /* bump structure pointer in message control */
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStr)); 
      break;
     case MA_TET_STRS:
      strS = (TknStrS *)ctlp->sSt;
      len = strS->len;
      val = &strS->val[0];
      if(teDef->tag == MA_TAG_NUMSTR)
      {
         for (i=0; i<len; i++)
         {
            if( (val[i] < '0') || (val[i] > '9') )
            {
					  /* ma001.203: Modification. Added Tag Info */	
               MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf,
               "maEncStr()failed, Tag [%x] invalid value in string(%d).\n", 
		teDef->tag, val[i]));
               RETVALUE(RFAILED);
            }
         }
      }
      /* bump structure pointer in message control */
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
      break;
#ifdef XWEXT
     case MA_TET_STR4:
      str4 = (TknStr4 *)ctlp->sSt;
      len = str4->len;
      val = &str4->val[0];
      if(teDef->tag == MA_TAG_NUMSTR)
      {
         for (i=0; i<len; i++)
         {
            if( (val[i] < '0') || (val[i] > '9') )
            {
					  /* ma001.203: Modification. Added Tag Info */	
               MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf,
               "maEncStr()failed, Tag [%x] invalid value in string(%d).\n", 
		teDef->tag, val[i]));
               RETVALUE(RFAILED);
            }
         }
      }
      /* bump structure pointer in message control */
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStr4)); 
      break;
#endif
     case MA_TET_STRM:
      strM = (TknStrM *)ctlp->sSt;
      len = strM->len;
      val = &strM->val[0];
      /* bump structure pointer in message control */
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrM)); 
      break;
     case MA_TET_STRE:
      strE = (TknStrE *)ctlp->sSt;
      len = strE->len;
      val = &strE->val[0];
      /* bump structure pointer in message control */
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrE)); 
      break;
     default:
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA283, (ErrVal)teDef->type, "maEncStr () Failed");
#endif
      RETVALUE(RFAILED);
  }


  pkArray[0] = teDef->tag;

  /* validate the length */
  
  if ( (len < teDef->minLen) || (len >teDef->maxLen))
  {
		 /* ma001.203: Modification. Added Tag Info */	
     MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf,
     "maEncStr()failed, Tag [%x] invalid length(%d).\n", teDef->tag, len));
     RETVALUE(RFAILED); 
  }

  /* encode the length */
  if (len < 128)
  {
    pkArray[1] = (Data)len;
    tmpLen = 2;
  }
  else 
  {
    /* the TknStrE can hold upto max. 256 bytes  and in this else condition
     * we can pack upto 65535 byets of data 
     */
    pkArray[1] = MA_LEN_1_BYTE;
    pkArray[2] = (Data)len;
    tmpLen = 3;
  }
  /* encode the value  */ 
  for (i=0; i<len; i++, val++)
  {
    pkArray[tmpLen +i] = *val;
  }
  ret = SAddPstMsgMult(pkArray, (MsgLen)(tmpLen + len), ctlp->mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
  if (ret != ROK)
  {
     MALOGERROR(ERRCLS_ADD_RES, EMA284, (ErrVal)ret, "SAddPstMsgMult() Failed");
     RETVALUE(ret);
  }
#endif

  MA_UPD_OFFSET_ARRAY
 
  /* if long length encoding is used, length field has 2 bytes */
  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maEncStr: %s Tag [%x] Len [%x][%x] \n", 
          maEleType[teDef->type], pkArray[0], pkArray[1], pkArray[2]));

  ctlp->sTelDef++;
  RETVALUE(ROK);
} /* maEncStr */


/*
*
*       Fun:   maEncNull   
*
*       Desc:  This function encodes a Null tag 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maEncNull 
(
MaMsgCtl  *ctlp         /* message control pointer */
)
#else
PUBLIC S16 maEncNull (ctlp)
MaMsgCtl  *ctlp;        /* message control pointer */
#endif
{
  MaTknElmtDef *teDef;
  S16        ret;
  Data       pkArray[MA_MAX_PKARRAY_LEN];

  TRC2(maEncNull)

  teDef = *ctlp->sTelDef;

  MA_UPD_MAND_FLG
 
  /* check element for protocol type and mandatory/optional flags */
  if ((ret = maChkEncElmnt(ctlp)) != ROK)
  {
     if (ret == RSKIP)
     {
        RETVALUE(ROK);
     }
     RETVALUE(ret);
  }

  /* encode the tag */
  pkArray[0] = teDef->tag;
  pkArray[1] = (Data)0;

  /* encode the length */
  ret = SAddPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
  if (ret != ROK)
  {
     MALOGERROR(ERRCLS_ADD_RES, EMA285, (ErrVal)ret, "SAddPstMsgMult() Failed");
     RETVALUE(ret);
  }
#endif

  MA_UPD_OFFSET_ARRAY

  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maEncNull: %s Tag [%x] Len [%x] \n", 
          maEleType[teDef->type], pkArray[0], pkArray[1]));

  /* bump structure pointer in message control */
  MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
  ctlp->sTelDef++;
  RETVALUE(ROK);
} /* maEncNull */



/*
*
*       Fun:   maEncBitStr   
*
*       Desc:  This function encodes Bit string 
*
*       Ret:   ROK 
*
*       Notes: This function is used to encode 8 bit enumerated 
*              bit string.
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maEncBitStr 
(
MaMsgCtl  *ctlp         /* message control pointer */
)
#else
PUBLIC S16 maEncBitStr (ctlp)
MaMsgCtl  *ctlp;        /* message control pointer */
#endif
{
  MaTknElmtDef *teDef;
  TknStrE    *tStE;
  TknStrS    *tStS;
  U8         val;
  U8         len;
  U8         shift;
  U8         mask;
  U8         i;
  S16        ret;
  Data       pkArray[MA_MAX_PKARRAY_LEN];

  TRC2(maEncBitStr)

  MA_UPD_MAND_FLG
  
  teDef = *ctlp->sTelDef;
  shift = 0;
  tStE = (TknStrE *)NULLP;
  tStS = (TknStrS *)NULLP;

  /* check element for protocol type and mandatory/optional flags */
  if ((ret = maChkEncElmnt(ctlp)) != ROK)
  {
     if (ret == RSKIP)
     {
        RETVALUE(ROK);
     }
     RETVALUE(ret);
  }

  if (teDef->maxLen >  MF_SIZE_TKNSTRS)
  {
     tStE = (TknStrE *)ctlp->sSt;
     /* validate the length */
     len = tStE->len;
  }
  else
  {  
     tStS = (TknStrS *)ctlp->sSt;
     len = tStS->len;
  }


  if ( (len < teDef->minLen) || (len > teDef->maxLen))
  {
		 /* ma001.203: Modification. Added Tag Info */	
     MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf,
     "maEncBitStr()failed, Tag [%x] invalid length(%d).\n", teDef->tag, len));
     RETVALUE(RFAILED);   
  }

  /* encode the tag */
  pkArray[0] = teDef->tag;

  {
     U8 no_of_octets; /* number of octets */

     i=0;
     no_of_octets = 0;
     mask = 0x01;

     while(i<len)
     {
        val = 0x0;
        shift = 8;
        for (; (i<len && shift > 0); i++, shift--)
        {
           if(teDef->maxLen > MF_SIZE_TKNSTRS)
           {
              val |= (tStE->val[i] & mask) << (shift-1);
           }
           else
           {
              val |= (tStS->val[i] & mask) << (shift-1);
           }
        }

        /* encode the value  */
        pkArray[no_of_octets+3] = (Data)(val);
      
        /* increase the number of octets */
        no_of_octets ++;
     }

     /* encode the length */
     pkArray[1] = no_of_octets + 1;

     /* encode the unused bits value  */
     pkArray[2] = shift;

     ret = SAddPstMsgMult(pkArray, (MsgLen)(no_of_octets + 3), ctlp->mBuf);
  }

#if (ERRCLASS & ERRCLS_ADD_RES)
  if (ret != ROK)
  {
     MALOGERROR(ERRCLS_ADD_RES, EMA286, (ErrVal)ret, "SAddPstMsgMult() Failed");
     RETVALUE(ret);
  }
#endif

  MA_UPD_OFFSET_ARRAY
 
  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maEncBitStr: %s Tag [%x] Len [%x] shift [%x] \n", 
          maEleType[teDef->type], pkArray[0], pkArray[1], pkArray[2]));

  /* bump structure pointer in message control */
  if (teDef->maxLen > MF_SIZE_TKNSTRS)
  {
     MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrE)); 
  }
  else
  {
     MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
  }
  ctlp->sTelDef++;
  RETVALUE(ROK);
} /* maEncBitStr */



/*
*
*       Fun:   maEncChoice
*
*       Desc:  This function encodes the Choice of tokens 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maEncChoice 
(
MaMsgCtl    *ctlp       /* message control pointer */
)
#else
PUBLIC S16 maEncChoice(ctlp)
MaMsgCtl    *ctlp;      /* message control pointer */
#endif
{
  MaTknElmtDef  *teDef;    /* element definition */
  MaTknElmtDef  **tmpDef;  /* temporory element definition */
  TknU8         *tmpSst;   /* temporary pointer */
  TknU8         *tSt;      /* token pointer */
  S16           ret;       /* return value */
  U8            elmntIdx;  /* element Index */
  U16           i;         /* counter */

  TRC2(maEncChoice)

  /* Note : for choice type itself, there is no tag and length */

  teDef = *ctlp->sTelDef;

  MA_UPD_MAND_FLG

  /* check if there is a user function */
  if (teDef->func)
  {
     ret = (*teDef->func)(ctlp);
     MA_UPD_OFFSET_ARRAY
     RETVALUE(ret);
  }

  if (teDef->tag != MA_TAG_NA)
  {
     ret = maEncTagChoice(ctlp);
     MA_UPD_OFFSET_ARRAY
     RETVALUE(ret);  
  }
 
  tmpDef = ctlp->sTelDef;       /* Store the element definition */
  tmpSst = (TknU8 *) ctlp->sSt; /* Store the token pointer */
  tSt    = (TknU8 *) ctlp->sSt; /* Get the token pointer */

  /* check element for protocol type and mandatory/optional flags */
  if ((ret = maChkEncElmnt(ctlp)) != ROK)
  {
     if (ret == RSKIP)
     {
        RETVALUE(ROK);
     }
     RETVALUE(ret);
  }

  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maEncChoice: Encoding Choice ......\n"));

  /* get the element index */
  elmntIdx = tSt->val;

 /* increment the event structure over present token */
  MA_BUMP_STP((PTR *) &ctlp->sSt, (U32) sizeof(TknU8));
  tSt = (TknU8 *) ctlp->sSt;

  /* increment the token pointer over the start of choice*/
  ctlp->sTelDef++;
  teDef = *ctlp->sTelDef;

  /* initialize the counter */
  i = 1;

  /* skip n elements in the database */
  while((i<elmntIdx) && (teDef->type != MA_TET_SEQ_TERM))
  {
     /* skip the element */
     maSkipTkns(ctlp);

     /* restore the event structure pointer */
     ctlp->sSt = (U8 *)tSt; 

     /* Update the element definition */
     teDef = *ctlp->sTelDef;

     /* Increment the counter */
     i++;
  }
 
  if(teDef->type == MA_TET_SEQ_TERM)
  {
     /* reached the end of choice error */
     ctlp->errCode = MAT_MISTYPE_PARAM;
     MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf,
     "maEncChoice()failed, reached the end of choice error.\n"));
     RETVALUE(RFAILED);
  }
     
  MA_INCREASE_LEVEL;
  /* Now Start encoding the tokens */
  switch(teDef->type)
  {
     case MA_TET_U8:
       ret = maEncOctet(ctlp,FALSE);
       break;
     case MA_TET_U8_ENUM:
       ret = maEncOctet(ctlp,TRUE);
       break;
     case MA_TET_NULL:
       ret = maEncNull(ctlp);
       break;
     case MA_TET_INT:
       ret = maEncInt(ctlp);
       break;
     case MA_TET_STR:
     case MA_TET_STRS:
     case MA_TET_STRM:
     case MA_TET_STRE:
#ifdef XWEXT
     case MA_TET_STR4:
#endif
       ret = maEncStr(ctlp);
       break;
     case MA_TET_STRUL:
       ret = maEncStrUL(ctlp);
       break;
     case MA_TET_BITSTR:
       ret = maEncBitStr(ctlp);
       break;
     case MA_TET_SEQ:
     case MA_TET_EXT_CONT:
       ret = maEncSeq(ctlp);
       break;
     case MA_TET_SEQ_OF:
       ret = maEncSeqOf(ctlp,teDef->repCntr, ctlp->sTelDef);
       break;
     case MA_TET_CHOICE:
       ret = maEncChoice(ctlp);
       break;
  }
  MA_DECREASE_LEVEL;
  if((ret != ROK)&& (ret != EMP_SEQ) && (ret != NON_EMP_SEQ))
  {
    MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf,
    "maEncChoice()failed, encoding token(%d) fail.\n", teDef->type));
    RETVALUE(RFAILED);
  }

  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maEncChoice: Encoding Choice Successfully.\n"));

  /* restore the element definition pointer to start of choice */
  ctlp->sTelDef = tmpDef;
 
  /* restore the token pointer to the start of the choice */
  ctlp->sSt     = (U8 *)tmpSst;
 
  MA_UPD_OFFSET_ARRAY
  
  /* Now skip the entire choice */
  maSkipTkns(ctlp);

  RETVALUE(ROK);
} /* maEncChoice */


/*
*
*       Fun:   maEncSeq
*
*       Desc:  This function encodes the sequence of tokens 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maEncSeq 
(
MaMsgCtl    *ctlp       /* message control pointer */
)
#else
PUBLIC S16 maEncSeq(ctlp)
MaMsgCtl    *ctlp;      /* message control pointer */
#endif
{
  MaTknElmtDef  *teDef;
  MaTknElmtDef  **tmpTeDef;
  TknU8         *tmpsSt;
  S16           ret;
  Data          pkArray[MA_MAX_PKARRAY_LEN];
  S16           seqMand;
  MsgLen        orgLen;
  MsgLen        curLen;
  MsgLen        i;
  Bool          NoSeqElemFilled = FALSE;
  Bool          SeqElemFilled   = FALSE;
  Bool          empSeq          = FALSE;
  Bool          nonEmpSeq       = FALSE;
  MsgLen        curLen2;

  TRC2(maEncSeq)

  teDef = *ctlp->sTelDef;
  tmpTeDef = ctlp->sTelDef;
  tmpsSt = (TknU8 *)ctlp->sSt;
  MA_UPD_MAND_FLG
 
  /* check if there is a user function */
  if (teDef->func)
  {
     ret = (*teDef->func)(ctlp);
     MA_UPD_OFFSET_ARRAY
     RETVALUE(ret);
  }

  /* encode the sequence tag and EOC length tag */
  pkArray[0] = teDef->tag;
  pkArray[1] = (Data)MA_EOC_LEN;

  ret = SAddPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
  if (ret != ROK)
  {
     MALOGERROR(ERRCLS_ADD_RES, EMA287, (ErrVal)ret, "SAddPstMsgMult() Failed");
     RETVALUE(ret);
  }
#endif

  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maEncSeq: Encoding Sequence ...... \n \
          %s Tag [%x] Len [%x]\n",
          maEleType[teDef->type], pkArray[0], pkArray[1]));

  seqMand = maChkEleMand(ctlp);

  /* increment the token pointer */
  ctlp->sTelDef++;
 
  teDef = *ctlp->sTelDef;
  
  /* All the tokens have first field as pres so typecast to TknU8 */

  SFndLenMsg(ctlp->mBuf, &orgLen);

  while (teDef->type != MA_TET_SEQ_TERM)
  {
     MA_INCREASE_LEVEL;
     SFndLenMsg(ctlp->mBuf, &curLen2);
     /* Start encoding the tokens */
     switch(teDef->type)
     {
        case MA_TET_U8:
          ret = maEncOctet(ctlp,FALSE);
          break;
        case MA_TET_U8_ENUM:
          ret = maEncOctet(ctlp,TRUE);
          break;
        case MA_TET_NULL:
          ret = maEncNull(ctlp);
          break;
        case MA_TET_INT:
          ret = maEncInt(ctlp);
          break;
        case MA_TET_STR:
        case MA_TET_STRS:
        case MA_TET_STRM:
        case MA_TET_STRE:
#ifdef XWEXT
        case MA_TET_STR4:
#endif
          ret = maEncStr(ctlp);
          break;
        case MA_TET_STRUL:
          ret = maEncStrUL(ctlp);
          break;
        case MA_TET_BITSTR:
          ret = maEncBitStr(ctlp);
          break;
        case MA_TET_SEQ:
        case MA_TET_EXT_CONT:
          ret = maEncSeq(ctlp);
          break;
        case MA_TET_SEQ_OF:
          ret = maEncSeqOf(ctlp,teDef->repCntr, ctlp->sTelDef);
          break;
        case MA_TET_CHOICE:
          ret = maEncChoice(ctlp);
          break;
#ifdef MAP_PHASE2_EXT_MARK
        case MA_TET_EXT_MARK:
          ret = maHndlExtMark(ctlp);
          break;
#endif
     }
     MA_DECREASE_LEVEL;
     SFndLenMsg(ctlp->mBuf, &curLen);
     if ((ret != ROK) && (ret != EMP_SEQ) && (ret != NON_EMP_SEQ))
     {
        if ( ctlp->errCode == MAT_DATA_MISSING)
        {
           if (orgLen == curLen) 
           {
              ctlp->sTelDef = tmpTeDef;
              ctlp->sSt = (U8 *)tmpsSt;
              maSkipTkns(ctlp);
              /* strip of the added tag and length before returning */
              SRemPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
              if (seqMand == FALSE)
              {
                 RETVALUE(ROK);
              }
              else
              {
                 MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
                 "maEncSeq()failed, mand. data missing at encoding token(%d).\n",\
                 teDef->type));
                 RETVALUE(RFAILED);
              }
           }
           else
           {
              ctlp->sTelDef = tmpTeDef;
              ctlp->sSt = (U8 *)tmpsSt;
              maSkipTkns(ctlp);
              
              /* Strip off the encoded bytes */
              for (i=0; i< (curLen - orgLen); i++)
              {
                SRemPstMsg(pkArray, ctlp->mBuf);
              }
              /* strip of the added tag and length before returning */
              SRemPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);

              MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
              "maEncSeq()failed, data missing at encoding token(%d).\n", teDef->type));
              RETVALUE(RFAILED);
           }
        }
        else
        {
           ctlp->sTelDef = tmpTeDef;
           ctlp->sSt = (U8 *)tmpsSt;
           maSkipTkns(ctlp);
           /* strip of the added tag and length before returning */
           SRemPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
           MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
           "maEncSeq()failed, error at encoding token(%d).\n", teDef->type));
           RETVALUE(RFAILED);
        }
     }
     if (ret == EMP_SEQ)
     {
         empSeq = TRUE;
     }
     if (ret == NON_EMP_SEQ)
     {
         nonEmpSeq = TRUE;
     }
     if (curLen2 != curLen) 
     {
        switch(teDef->type)
        {
        case MA_TET_U8:
        case MA_TET_U8_ENUM:
        case MA_TET_NULL:
        case MA_TET_INT:
        case MA_TET_STR:
        case MA_TET_STRS:
#ifdef XWEXT
        case MA_TET_STR4:
#endif
        case MA_TET_STRM:
        case MA_TET_STRE:
        case MA_TET_STRUL:
        case MA_TET_BITSTR:
        case MA_TET_SEQ_OF:
        case MA_TET_CHOICE:
          NoSeqElemFilled = TRUE;
          break;
        case MA_TET_SEQ:
        case MA_TET_EXT_CONT:
          SeqElemFilled = TRUE;
          break;
        }
     }

     /* update the pointers */
     teDef = *ctlp->sTelDef;
  }

  SFndLenMsg(ctlp->mBuf, &curLen);
  if ((orgLen == curLen) && (seqMand == FALSE))
  {
    SRemPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }
  else if ((seqMand == FALSE) && 
           (orgLen != curLen) &&
           ((NoSeqElemFilled == FALSE) && 
            ((SeqElemFilled == TRUE)) && (nonEmpSeq == FALSE)&&
             (empSeq == TRUE)))
  {
     /*remove the empty mand elem*/
     SRemPstMsgMult(pkArray, (MsgLen)(2+curLen - orgLen), ctlp->mBuf);
     ctlp->sTelDef++;
     RETVALUE(ROK);
  }
#ifdef MA_ASN_NO_INDEF_LEN
  MA_ENC_DEF_LEN(curLen, orgLen)
#else /* MA_ASN_NO_INDEF_LEN */
  /* Encode the TWo EOC tag to indicate end of sequence */
  pkArray[0] = MA_TAG_EOC;
  pkArray[1] = MA_TAG_EOC;

  ret = SAddPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);

#if (ERRCLASS & ERRCLS_ADD_RES)
  if (ret != ROK)
  {
     MALOGERROR(ERRCLS_ADD_RES, EMA288, (ErrVal)ret, "SAddPstMsgMult() Failed");
     RETVALUE(ret);
  }
#endif
#endif /* MA_ASN_NO_INDEF_LEN */
  /*If no non seq type elem filled, mark empty mand seq filled*/
  if(curLen == orgLen)
  {
      ret = EMP_SEQ;
  }
  else if ((NoSeqElemFilled == FALSE)&& 
           (SeqElemFilled == TRUE) && 
           (nonEmpSeq == FALSE)&&
           (empSeq == TRUE))
  {
      ret = EMP_SEQ;
  }
  else
  {
      ret = NON_EMP_SEQ;
  }

  MA_UPD_OFFSET_ARRAY
  
  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maEncSeq: Encoding Sequence Successfully.\n"));

  /* increment the token defination pointer */
  ctlp->sTelDef++;
  RETVALUE(ret);
} /* maEncSeq */



/*
*
*       Fun:   maEncSeqOf  
*
*       Desc:  This function encodes the repeatable sequence 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maEncSeqOf 
(
MaMsgCtl      *ctlp,         /* message control pointer */
S32           cntr,          /* Counter */
MaTknElmtDef  **stTelDef     /* token element pointer */
)
#else
PUBLIC S16 maEncSeqOf (ctlp,cntr,stTelDef)
MaMsgCtl      *ctlp;        /* message control pointer */
S32           cntr;         /* Counter */
MaTknElmtDef  **stTelDef;   /* token element pointer */
#endif
{
  MaTknElmtDef  *teDef;
  Data          pkArray[MA_MAX_PKARRAY_LEN];
  S16           ret; 
  S16           seqMand; 
  MsgLen        orgLen;
  MsgLen        curLen;
  MsgLen        initLen;
  PTR           startPtr;
  PTR           endPtr;

  TRC2(maEncSeqOf)

  MA_UPD_MAND_FLG
  startPtr = 0;
  endPtr = 0;

  /* check if there is a user function */
  teDef = *ctlp->sTelDef;
  if (teDef->func)
  {
     ret = (*teDef->func)(ctlp);
     MA_UPD_OFFSET_ARRAY
     RETVALUE(ret);
  }

  /* encode the sequence tag and EOC length tag */

  pkArray[0] = teDef->tag;
  pkArray[1] = MA_EOC_LEN;

  ret = SAddPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);

#if (ERRCLASS & ERRCLS_ADD_RES)
  if (ret != ROK)
  {
     MALOGERROR(ERRCLS_ADD_RES, EMA289, (ErrVal)ret, "SAddPstMsgMult() Failed");
     RETVALUE(ret);
  }
#endif

  #ifndef ALIGN_64BIT

   MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maEncSeqOf: Encoding Sequence Of ......\n \
          %s Tag [%x] Len [%x] Counter %ld \n",
          maEleType[teDef->type], pkArray[0], pkArray[1], cntr));

   #else

  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maEncSeqOf: Encoding Sequence Of ......\n \
          %s Tag [%x] Len [%x] Counter %d \n",
          maEleType[teDef->type], pkArray[0], pkArray[1], cntr));


  #endif /* ALIGN_64BIT */
  SFndLenMsg(ctlp->mBuf, &initLen);
  seqMand = maChkEleMand(ctlp);
  while(cntr)
  {
    startPtr = (PTR)ctlp->sSt;
    ctlp->sTelDef = stTelDef;
    ctlp->sTelDef++;
    teDef = *ctlp->sTelDef;
    /* Start encoding the tokens */
    SFndLenMsg(ctlp->mBuf, &orgLen);
    MA_INCREASE_LEVEL;
    switch(teDef->type)
    {
        case MA_TET_U8:
          ret = maEncOctet(ctlp,FALSE);
          break;
        case MA_TET_U8_ENUM:
          ret = maEncOctet(ctlp,TRUE);
          break;
        case MA_TET_NULL:
          ret = maEncNull(ctlp);
          break;
        case MA_TET_INT:
          ret = maEncInt(ctlp);
          break;
        case MA_TET_STR:
        case MA_TET_STRS:
        case MA_TET_STRM:
        case MA_TET_STRE:
#ifdef XWEXT
        case MA_TET_STR4:
#endif
          ret = maEncStr(ctlp);
          break;
        case MA_TET_STRUL:
          ret = maEncStrUL(ctlp);
          break;
        case MA_TET_BITSTR:
          ret = maEncBitStr(ctlp);
          break;
        case MA_TET_SEQ:
        case MA_TET_EXT_CONT:
          ret = maEncSeq(ctlp);
          break;
        case MA_TET_SEQ_OF:
          ret = maEncSeqOf(ctlp,teDef->repCntr, ctlp->sTelDef);
          break;
        case MA_TET_CHOICE:
          ret = maEncChoice(ctlp);
          break;
        default:
#if (ERRCLASS & ERRCLS_DEBUG)
          MALOGERROR(ERRCLS_DEBUG, EMA290, (ErrVal)teDef->type, "maEncSeqOf () Failed");
#endif
          break;
    }
    MA_DECREASE_LEVEL;
    endPtr = (PTR)ctlp->sSt;
    SFndLenMsg(ctlp->mBuf, &curLen);
    if ((ret != ROK) && (ret != EMP_SEQ) && (ret != NON_EMP_SEQ))
    {
      if (ctlp->errCode == MAT_DATA_MISSING)
      {
         if ((initLen == curLen) && (seqMand == TRUE))
         {
            /* nothing was encoded, so mandatory info missing */
            SRemPstMsgMult(&pkArray[0], (MsgLen)2, ctlp->mBuf);
            while(cntr)
            {
              ctlp->sTelDef = stTelDef;
              ctlp->sTelDef++;
              maSkipTkns(ctlp);
              cntr--;
            }
            ctlp->sTelDef++;
            RETVALUE(ret);
         }
         else
         {
            break;
         }
      }
      else
      {
         RETVALUE(ret);
      }
    }
    cntr--;
    if (orgLen == curLen)
    {
      break;
    }
  }

  if ((initLen == curLen) && (seqMand == FALSE))
  {
    SRemPstMsgMult(&pkArray[0], (MsgLen)2, ctlp->mBuf);
  }
  else if ((initLen == curLen) && (seqMand == TRUE))
  {
    SRemPstMsgMult(&pkArray[0], (MsgLen)2, ctlp->mBuf);
    if (cntr != 0)
    {
       MA_BUMP_STP((PTR *)&ctlp->sSt, (U32)cntr * (endPtr - startPtr));
    }

    MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maEncSeqOf: Encoding Sequence Of Successfully.\n"));

    ctlp->sTelDef++;
    ctlp->errCode = MAT_DATA_MISSING;
    MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
    "maEncSeq()failed, data missing at encoding token(%d).\n", teDef->type));
    RETVALUE(RFAILED);
  }

  else
  {
#ifdef MA_ASN_NO_INDEF_LEN
     MA_ENC_DEF_LEN(curLen, initLen)
#else /* MA_ASN_NO_INDEF_LEN */
     /* Encode the TWo EOC tag to indicate end of sequence */
     pkArray[0] = MA_TAG_EOC;
     pkArray[1] = MA_TAG_EOC;

     ret = SAddPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);

#if (ERRCLASS & ERRCLS_ADD_RES)
     if (ret != ROK)
     {
        MALOGERROR(ERRCLS_ADD_RES, EMA291, (ErrVal)ret, "SAddPstMsgMult() Failed");
        RETVALUE(ret);
     }
#endif
#endif /* MA_ASN_NO_INDEF_LEN */
  }

  MA_UPD_OFFSET_ARRAY

  if (cntr != 0)
  {
     MA_BUMP_STP((PTR *)&ctlp->sSt, (U32)cntr * (endPtr - startPtr));
  }

  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maEncSeqOf: Encoding Sequence Of Successfully.\n"));

  ctlp->sTelDef++;
  RETVALUE(ROK);
} /* end of maEncSeqOf */

#ifdef MAP_PHASE2_EXT_MARK

/*
*
*       Fun:   maHndlExtMark   
*
*       Desc:  This function encodes extension marker. It will just
*              copy down the extension marker as it is already
*              encoded by the application. 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maHndlExtMark 
(
MaMsgCtl  *ctlp         /* message control pointer */
)
#else
PUBLIC S16 maHndlExtMark (ctlp)
MaMsgCtl  *ctlp;        /* message control pointer */
#endif
{
  MaTknElmtDef *teDef;
  TknStrE    *sStrE;   /* token string size - large */
  MsgLen     totLen;
  U8         len;
  U8         lfLen;
  U8         *val;
  S16        ret;
  U8         i;
  Data       pkArray[MA_MAX_PKARRAY_LEN];

  TRC2(maHndlExtMark)

  teDef = *ctlp->sTelDef;

  if (ctlp->encode == TRUE)
  {
     /* check element for protocol type and mandatory/optional flags */
     if ((ret = maChkEncElmnt(ctlp)) != ROK)
     {
        if (ret == RSKIP)
        {
           RETVALUE(ROK);
        }
        RETVALUE(ret);
     }

     sStrE = (TknStrE *)ctlp->sSt;
     len = sStrE->len;
     val = &sStrE->val[0];
     /* bump structure pointer in message control */
     MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrE)); 


     /* Copy Down the already encoded value by the MAP User */ 
     for (i=0; i<len; i++, val++)
     {
       pkArray[i] = *val;
     }
     ret = SAddPstMsgMult(pkArray, (MsgLen)(len), ctlp->mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
     if (ret != ROK)
     {
        MALOGERROR(ERRCLS_ADD_RES, EMA292, (ErrVal)ret, "SAddPstMsgMult() Failed");
        RETVALUE(ret);
     }
#endif

     MA_UPD_OFFSET_ARRAY
 
     ctlp->sTelDef++;
  }

  /* Decode the entension marker */
  if (ctlp->decode == TRUE)
  {
     (Void)SFndLenMsg (ctlp->mBuf, &totLen);
     len = (MsgLen)totLen;
     lfLen = 1;
     sStrE = (TknStrE *)ctlp->sSt;

      /* allocate string */
     if ((ret = SRemPreMsgMult((U8 *)&sStrE->val[0], (MsgLen)len, ctlp->mBuf)) != ROK) 
     {
       MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf,
       "maHndlExtMark() failed in decoding, unable to allocate string.\n"));
       RETVALUE(RFAILED);
     }

     sStrE->len = len;
     sStrE->pres = TRUE;
     MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrE));

  }
  RETVALUE(ROK);
} /* maHndlExtMark */
#endif


/*
*
*       Fun:   maSkipTkns 
*
*       Desc:  This function skips the tokens in event structure and increments
*              the database pointer appropriately. 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maSkipTkns 
(
MaMsgCtl        *ctlp           /* message control pointer */
)
#else
PUBLIC S16 maSkipTkns (ctlp)
MaMsgCtl        *ctlp;          /* message control pointer */
#endif
{
  MaTknElmtDef  *teDef;
 
  TRC2 (maSkipTkns)

  teDef = *ctlp->sTelDef;

  switch (teDef->type)
  {
    case MA_TET_U8:
    case MA_TET_U8_ENUM:
    case MA_TET_NULL:
      /* bump structure pointer in message control and increment the data base
       * pointer */
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
      ctlp->sTelDef++;
      break;
    case MA_TET_INT:
      /* bump structure pointer in message control and increment the data base
       * pointer */
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
      ctlp->sTelDef++;
      break;
    case MA_TET_STR:
      /* bump structure pointer in message control and increment the data base
       * pointer */
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStr)); 
      ctlp->sTelDef++;
      break;
    case MA_TET_STRS:
       {
          MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
       }
      ctlp->sTelDef++;
      break;
#ifdef XWEXT
     case MA_TET_STR4:
       {
          MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStr4)); 
       }
      ctlp->sTelDef++;
      break;
#endif
    case MA_TET_BITSTR:
      /* bump structure pointer in message control and increment the data base
       * pointer */
       if (teDef->maxLen > MF_SIZE_TKNSTRS)
       {
          MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrE)); 
       }
       else
       {
          MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
       }
      ctlp->sTelDef++;
      break;
    case MA_TET_STRM:
      /* bump structure pointer in message control and increment the data base
       * pointer */
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrM)); 
      ctlp->sTelDef++;
      break;
    case MA_TET_STRE:
      /* bump structure pointer in message control and increment the data base
       * pointer */
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrE)); 
      ctlp->sTelDef++;
      break;
    case MA_TET_STRUL:
      /* bump structure pointer in message control and increment the data base
       * pointer */
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(MaTknStrUL)); 
      ctlp->sTelDef++;
      break;
    case MA_TET_SEQ:
      {
        maSkipSeq(ctlp);
      }
      break;
    case MA_TET_SEQ_OF:
      {
        maSkipSeqOf(ctlp);
      }
      break;
    case MA_TET_CHOICE:
      {
        maSkipChoice(ctlp);
      }
      break;
    case MA_TET_EXT_CONT:
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(MaExtContSeq)); 
      ctlp->sTelDef = ctlp->sTelDef + MA_TET_EXTCONT_SIZE;
      break;       
#ifdef MAP_PHASE2_EXT_MARK
    case MA_TET_EXT_MARK:
      /* bump structure pointer in message control and increment the data base
       * pointer */
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrE)); 
      ctlp->sTelDef++;
      break;
#endif

    default:
#if (ERRCLASS & ERRCLS_DEBUG)
        MALOGERROR(ERRCLS_DEBUG, EMA293, (ErrVal)teDef->type, "maSkipTkns () Failed");
#endif
       break;
  }

  MADBGP(MA_DBGMASK_SKIP, (maCb.maInit.prntBuf, 
         "maSkipTkns: %s \n", maEleType[teDef->type]));

  RETVALUE(ROK);

} /* maSkipTkns */



/*
*
*       Fun:   maSkipSeq 
*
*       Desc:  This function skips all the tokens in a sequence of event structure.
*               and increments the database pointer appropriately.
*
*       Ret:   Rok 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maSkipSeq 
(
MaMsgCtl   *ctlp        /* message control pointer */
)
#else
PUBLIC S16 maSkipSeq (ctlp)
MaMsgCtl   *ctlp;       /* message control pointer */
#endif
{
  MaTknElmtDef  *teDef;

  TRC2(maSkipSeq)

  /* increment the Seq tag in the data base */

  ctlp->sTelDef++;
  teDef = *ctlp->sTelDef;
 
  MADBGP(MA_DBGMASK_SKIP, (maCb.maInit.prntBuf, 
         "maSkipSeq: Skiping Sequence ......\n"));

  while (teDef->type != MA_TET_SEQ_TERM)
  {
    /* start skipping the tokens */

     switch(teDef->type)
     {
        case MA_TET_U8:
        case MA_TET_U8_ENUM:
        case MA_TET_NULL:
          /* bump structure pointer in message control */
          MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
          ctlp->sTelDef++;
          break;
        case MA_TET_INT:
          /* bump structure pointer in message control */
          MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
          ctlp->sTelDef++;
          break;
        case MA_TET_STR:
          /* bump structure pointer in message control */
          MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStr)); 
          ctlp->sTelDef++;
           break;
        case MA_TET_STRS:
          /* bump structure pointer in message control */
          MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
          ctlp->sTelDef++;
           break;
#ifdef XWEXT
	  case MA_TET_STR4:
          /* bump structure pointer in message control */
          MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStr4)); 
          ctlp->sTelDef++;
           break;
#endif
        case MA_TET_BITSTR:
           /* bump  pointer in message control and increment the data base
              pointer */
           if (teDef->maxLen > MF_SIZE_TKNSTRS)
           {
              MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrE)); 
           }
           else
           {
              MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
           }
           ctlp->sTelDef++;
           break;
        case MA_TET_STRM:
          /* bump structure pointer in message control */
          MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrM)); 
          ctlp->sTelDef++;
           break;
        case MA_TET_STRE:
          /* bump structure pointer in message control */
          MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrE)); 
          ctlp->sTelDef++;
           break;
        case MA_TET_STRUL:
          /* bump structure pointer in message control */
          MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(MaTknStrUL)); 
          ctlp->sTelDef++;
           break;
        case MA_TET_SEQ:
          maSkipSeq(ctlp);
          break;
        case MA_TET_SEQ_OF:
          maSkipSeqOf(ctlp);
          break;
        case MA_TET_CHOICE:
          maSkipChoice(ctlp);
          break;
        case MA_TET_EXT_CONT:
          MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(MaExtContSeq)); 
          ctlp->sTelDef = ctlp->sTelDef + MA_TET_EXTCONT_SIZE;
          break;
#ifdef MAP_PHASE2_EXT_MARK
    case MA_TET_EXT_MARK:
      /* bump structure pointer in message control and increment the data base
       * pointer */
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrE)); 
      ctlp->sTelDef++;
      break;
#endif
        default:
#if (ERRCLASS & ERRCLS_DEBUG)
          MALOGERROR(ERRCLS_DEBUG, EMA294, (ErrVal)teDef->type, "maSkipSeq () Failed");
#endif
           break;
     }
     teDef = *ctlp->sTelDef;

  }

  MADBGP(MA_DBGMASK_SKIP, (maCb.maInit.prntBuf, 
         "maSkipSeq: Skip Sequence Successfully.\n"));

  ctlp->sTelDef++;
  RETVALUE(ROK);

} /* end of maSkipSeq */


/*
*
*       Fun:   maSkipSeqOf 
*
*       Desc:  This function skips the array of sequence 
*
*       Ret:   ROK 
*
*       Notes: None  
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maSkipSeqOf 
(
MaMsgCtl  *ctlp         /* message control pointer */
)
#else
PUBLIC S16 maSkipSeqOf (ctlp)
MaMsgCtl  *ctlp;        /* message control pointer */
#endif
{
  U32   cntr;
  MaTknElmtDef **stTelDef;
  PTR   startPtr;
  PTR   endPtr;
  U32   counter;

  TRC2 (maSkipSeqOf)

  startPtr = 0;
  endPtr = 0;
  counter = 0;
  stTelDef = ctlp->sTelDef;
  cntr = ((MaTknElmtDef *)(*stTelDef))->repCntr;

  #ifndef ALIGN_64BIT

  MADBGP(MA_DBGMASK_SKIP, (maCb.maInit.prntBuf, 
         "maSkipSeqOf: Skiping Sequence Of ...... Counter %ld \n", cntr));

  #else

  MADBGP(MA_DBGMASK_SKIP, (maCb.maInit.prntBuf, 
         "maSkipSeqOf: Skiping Sequence Of ...... Counter %d \n", cntr));

  #endif /* ALIGN_64BIT */

  ctlp->sTelDef++;
  stTelDef = ctlp->sTelDef;
  if (cntr != 0)
  {
     ctlp->sTelDef = stTelDef;
     startPtr = (PTR)ctlp->sSt;
     maSkipTkns(ctlp);
     endPtr = (PTR)ctlp->sSt;
     counter = cntr - 1;
     if (counter != 0)
     {
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32)counter * (endPtr - startPtr));
     }
  }

  MADBGP(MA_DBGMASK_SKIP, (maCb.maInit.prntBuf, 
         "maSkipSeqOf: Skip Sequence Of Successfully.\n"));

  ctlp->sTelDef++;
  RETVALUE(ROK);
  
} /* maSkipSeqOf */



/* Start of decoding functions */

/*
*
*       Fun:    maFindLen
*
*       Desc:   Return the length of the element and the length of length
*               field as well. In case of indefinate length encoding the
*               the length of length field is returned as 1 and eocFlg is
*               set to true.
*
*       Ret:    ROK     - ok
*
*       Notes:  The offset points to the tag.  It is necessary to know
*               if the tag is a constructor or a primitive
*
*       File:   ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maFindLen
(
Buffer *mBuf,    /* message buffer */
MsgLen offset,   /* message offset */
MsgLen  *len,    /* pointer to length */
Bool    *eocFlg, /* EOC flag - true for indefinate form of length encoding */
MsgLen  *lfLen   /* length field's lenght */
)
#else
PUBLIC S16 maFindLen(mBuf, offset, len, eocFlg, lfLen)
Buffer *mBuf;     /* message buffer */
MsgLen offset;    /* message offset */
MsgLen  *len;     /* pointer to length */
Bool    *eocFlg;  /* EOC flag - true for indefinate form of length encoding */
MsgLen  *lfLen;   /* length field's lenght */
#endif
{
   S16 ret;           /* return */
   MsgLen curLen;     /* current length */
   MsgLen tmpLen;     /* temp length */
   MsgLen tmpLen1;    /* temp length */
   Data tmpData;      /* holds current info */
   Data data1;        /* holds current info */
   Data data2;        /* holds current info */
   U8 i;              /* loop counter */
   MsgLen  totLen;    /* Total length of the message */ 
   U32 found;        

   TRC2(maFindLen)
   *eocFlg = FALSE;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (mBuf == (Buffer *)NULLP)
   {
      MALOGERROR(ERRCLS_DEBUG, EMA295, (ErrVal)0, "maFindLen() Failed");
      RETVALUE(RFAILED);
   }
#endif
   (Void)SFndLenMsg (mBuf, &totLen);

   if ((ret = SExamMsg(&tmpData, mBuf, (MsgLen)(offset + 1))) != ROK)
   {
      MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
      "maFindLen() failed, fail to copy data from msg at offset(%d).\n", offset+1));
      RETVALUE(RFAILED);
   }
   if (!(tmpData & 0x80))
   {
      if ( (totLen -2) < (MsgLen)tmpData)
      {
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maFindLen() failed, msg length error(%d).\n", totLen));
        RETVALUE(RFAILED);
      }

      *len = (MsgLen)tmpData;
      *lfLen = 1;
      
      RETVALUE(ROK);
   }
   curLen = 0;
   found = 0;
   if (tmpData != 0x80)
   {
      /* long form of message */
      tmpLen = (U8)(tmpData & 0x7f);
      *lfLen = (tmpLen +1);
      for(i=0;i < (U8)tmpLen;i++)
      {
         if ((ret = SExamMsg(&tmpData, mBuf, (MsgLen)(offset + i + 2))) != ROK)
         {
            MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
            "maFindLen() failed, fail to copy data from msg at offset(%d).\n",\
            offset+i+2));
            RETVALUE(RFAILED);
         }
         curLen = (MsgLen)(curLen << 8);
         curLen = (MsgLen)(curLen + (MsgLen)tmpData);
      }
      if (totLen < (tmpLen+curLen+2))
      {
        MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
        "maFindLen() failed, invalid msg length(%d).\n",totLen));
        RETVALUE (RFAILED);
      }
      *len = curLen;
      RETVALUE(ROK);
   }

   else
   {
      /* indefinate form of length */
      /* loop until find EOC */
      *lfLen = 1;
      offset += 2;
      for(;;)
      {
        if (totLen <= curLen)
        {
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maFindLen() failed, invalid length(%d).\n",totLen));
           RETVALUE(RFAILED);
        }

        /* check for end of long form of encoding */ 
        if ((ret = SExamMsg(&data1, mBuf, offset)) != ROK)
        {
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maFindLen() failed, fail to copy data at offset(%d).\n",offset));
           RETVALUE(RFAILED);
        }


        if ((ret = SExamMsg(&data2, mBuf, (MsgLen)(offset + 1))) != ROK)
        {
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maFindLen() failed, fail to copy data at offset(%d).\n",offset +1));
           RETVALUE(RFAILED);
        }

        if( (data1 == 0x00) && (data2 == 0x00))
        {
           if (found)
           {
               curLen += 2;
               offset += 2;
               found--;
               continue;
           }
           else
           {
              *len = curLen;
              *eocFlg = TRUE;
              RETVALUE(ROK);
           }
        }

        if (!(data2 & 0x80) )
        {
           tmpLen = data2;
           curLen += tmpLen+2;
           offset += tmpLen + 2;  
            continue;
        }
        else if ( data2 != 0x80)
        {
          tmpLen = 0;
          tmpLen1 = (U8)(data2 & 0x7f);
          for ( i=0; i< (U8) tmpLen1; i++)
          {
            if ((ret = SExamMsg(&tmpData, mBuf, (MsgLen)(offset+i+2))) != ROK)
            {
               MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
               "maFindLen() failed, fail to copy data at offset(%d).\n",offset +i +2));
               RETVALUE(RFAILED);
            }
            tmpLen = (MsgLen)(tmpLen << 8);
            tmpLen = (MsgLen)(tmpLen + (MsgLen)tmpData);
          }
          curLen = curLen + tmpLen1 + tmpLen +2; 
          offset += tmpLen1 + tmpLen +2;
          continue;
        }

        /* all that is left is long form of encoding */
        else
        { 
          curLen += 2;
          offset += 2;
          found++;
          continue;
        }
      }      
   }
} /* end of maFindLen */


/*
*
*       Fun:    maRemLen
*
*       Desc:   Remove  the length bytes from the message
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maRemLen
(
Buffer *mBuf,    /* message buffer */
Bool    *eocFlg  /* EOC flag - true for indefinate form of length encoding */
)
#else
PUBLIC S16 maRemLen(mBuf, eocFlg)
Buffer *mBuf;     /* message buffer */
Bool    *eocFlg;  /* EOC flag - true for indefinate form of length encoding */
#endif
{

   Data     data;
   Data     unPkArray[MA_MAX_PKARRAY_LEN];
   MsgLen   msgLen;
   S16      ret;


   *eocFlg = FALSE;

   if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
   {
      MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
      "maRemLen() failed, fail to copy data at offset(%d).\n",0));
      RETVALUE(RFAILED);
   }

   if (!(data & 0x80))
   {
      /* short form of length remove one byte */
      RETVALUE(SRemPreMsg(&data, mBuf));
   }

   if (data == 0x80)
   {
     /* indeterminate form of length */
     /* remove 0x80 tag */
     *eocFlg = TRUE;
     RETVALUE(SRemPreMsg(&data, mBuf));
   }
   else
   {

      if ((ret = SRemPreMsg(&data, mBuf)) != ROK)
      {
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maRemLen() failed, fail to copy data from mBuf.\n"));
         RETVALUE(RFAILED);
      }

     /* all that is left is long form */
     data &= 0x7f;

     (Void)SFndLenMsg (mBuf, &msgLen);

     /* check for bad message */
     if (msgLen < (S16)data)
     {
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maRemLen() failed, invalid msgLen.\n"));
        RETVALUE(RFAILED);
     }

     /* remove the correct number of length bytes */
     RETVALUE(SRemPreMsgMult(unPkArray, (MsgLen)data, mBuf));
   }

} /* maRemLen */



/*
*
*       Fun:    maRemULPrim
*
*       Desc:   read UL string primitive into a string
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maRemULPrim
(
Buffer       *mBuf,                  /* message buffer */
MaMsgCtl     *ctlp,                  /* Pointer to message control */
U8           *destStr,               /* destination string */
U16          *destLen                /* length of destination string */
)
#else
PUBLIC S16 maRemULPrim(mBuf, ctlp, destStr,destLen)
Buffer       *mBuf;                  /* message buffer */
MaMsgCtl     *ctlp;                  /* Pointer to message control */
U8           *destStr;               /* destination string */
U16          *destLen;               /* length of destination srtring */
#endif
{
   S16          ret;     /* return */
   Data         data;
   MsgLen       msgLen;
   MsgLen       maPrimLen;
   MsgLen       tmpLen;
   MsgLen       lfLen;
   U8           *tmpStr;
   MaTknElmtDef *teDef;
   Data         unPkArray[MA_MAX_PKARRAY_LEN]; 
   Bool         eocFlg;

   TRC2(maRemPrim)

   tmpStr = destStr;
   *destLen = 0;

   if (ctlp != (MaMsgCtl *)NULLP)
   {
      teDef = *ctlp->sTelDef; 
   }
   else
   {
      teDef = (MaTknElmtDef *)NULLP; 
   }

   /* tag is in first position and always 8 bit */
   (Void)SFndLenMsg(mBuf, &msgLen);

   if (( ret = maFindLen(mBuf, 0, &maPrimLen, &eocFlg, &lfLen)) != ROK)
   {
      MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
      "maRemULPrim() failed, fail to get the primitive length.\n"));
      RETVALUE(RFAILED);
   }
   if (msgLen <= maPrimLen)
   {
     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maRemULPrim() failed, invalid msg length(%d) and primitive len(%d).\n",\
     msgLen, maPrimLen));
     RETVALUE(RFAILED);
   } 

   if (teDef != (MaTknElmtDef *)NULLP)
   {
      if (( maPrimLen < (MsgLen)teDef->minLen) || 
          (maPrimLen > (MsgLen)teDef->maxLen))
      {
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maRemULPrim() failed, invalid primitive len(%d).\n",maPrimLen));
         RETVALUE(RFAILED);
      }
   }

  (Void)SExamMsg(&data, mBuf, 1);

   if ( (!(data & 0x80)) || (eocFlg == TRUE))
   {
      /* short form of length remove one byte length and tag */
      (Void)SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf);

      /* allocate string */
      if ((ret = SRemPreMsgMult(tmpStr, (MsgLen)maPrimLen, mBuf)) != ROK)
      {
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maRemULPrim() failed, unable to allocate string.\n"));
        RETVALUE(RFAILED);
      }
      *destLen = maPrimLen;
      if (eocFlg == TRUE)
      {
        (Void)SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf);

      }
      RETVALUE(ROK);
   }

   /* all that is left is long form */
   /* remove tag and then length byte */

   (Void)SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf);

   tmpLen = unPkArray[1] & 0x7f;

   (Void)SRemPreMsgMult(unPkArray, (MsgLen)tmpLen, mBuf);

   /* read into string */
   if ((ret = SRemPreMsgMult(tmpStr, (MsgLen)maPrimLen, mBuf)) != ROK)
   {
     RETVALUE(ret);
   }
   *destLen = maPrimLen;
   RETVALUE(ROK);
} /* end of maRemULPrim */

/*
*
*       Fun:    maRemPrim
*
*       Desc:   read primitive into a string
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maRemPrim
(
Buffer       *mBuf,                  /* message buffer */
MaMsgCtl     *ctlp,                  /* Pointer to message control */
U8           *destStr,               /* destination string */
U8          *destLen                 /* length of destination string */
)
#else
PUBLIC S16 maRemPrim(mBuf, ctlp, destStr,destLen)
Buffer       *mBuf;                  /* message buffer */
MaMsgCtl     *ctlp;                  /* Pointer to message control */
U8           *destStr;               /* destination string */
U8          *destLen;                /* length of destination srtring */
#endif
{
   S16 ret;                          /* return */
   Data data;
   MsgLen msgLen;
   MsgLen maPrimLen;
   MsgLen tmpLen;
   MsgLen lfLen;
   U8     *tmpStr;
   MaTknElmtDef *teDef;
   Data     unPkArray[MA_MAX_PKARRAY_LEN]; 
   Bool     eocFlg;

   TRC2(maRemPrim)

   tmpStr = destStr;
   *destLen = 0;

   if (ctlp != (MaMsgCtl *)NULLP)
   {
      teDef = *ctlp->sTelDef; 
   }
   else
   {
      teDef = (MaTknElmtDef *)NULLP; 
   }

   /* tag is in first position and always 8 bit */
   (Void)SFndLenMsg(mBuf, &msgLen);

   if (( ret = maFindLen(mBuf, 0, &maPrimLen, &eocFlg, &lfLen)) != ROK)
   {
      MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
      "maRemPrim() failed, fail to get the primitive length.\n"));
      RETVALUE(RFAILED);
   }
   if (msgLen <= maPrimLen)
   {
     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maRemPrim() failed, invalid msg length(%d) and primitive len(%d).\n",\
     msgLen, maPrimLen));
     RETVALUE(RFAILED);
   } 

   if (teDef != (MaTknElmtDef *)NULLP)
   {
      if (( maPrimLen < (MsgLen)teDef->minLen) || (maPrimLen > (MsgLen)teDef->maxLen))
      {
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maRemPrim() failed, invalid primitive len(%d).\n",maPrimLen));
         RETVALUE(RFAILED);
      }
   }

  (Void)SExamMsg(&data, mBuf, 1);

   if ( (!(data & 0x80)) || (eocFlg == TRUE))
   {
      /* short form of length remove one byte length and tag */
      (Void)SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf);

      /* allocate string */
      if ((ret = SRemPreMsgMult(tmpStr, (MsgLen)maPrimLen, mBuf)) != ROK)
      {
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maRemPrim() failed, unable to allocate string.\n"));
        RETVALUE(RFAILED);
      }
      *destLen = (U8)maPrimLen;
      if (eocFlg == TRUE)
      {
        (Void)SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf);

      }
      RETVALUE(ROK);
   }

   /* all that is left is long form */
   /* remove tag and then length byte */

   (Void)SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf);

   tmpLen = unPkArray[1] & 0x7f;

   (Void)SRemPreMsgMult(unPkArray, (MsgLen)tmpLen, mBuf);

   /* read into string */
   if ((ret = SRemPreMsgMult(tmpStr, (MsgLen)maPrimLen, mBuf)) != ROK)
   {
     RETVALUE(ret);
   }
   *destLen = (U8)maPrimLen;
   RETVALUE(ROK);
} /* end of maRemPrim */


/*
*
*       Fun:   maChkMsgMand 
*
*       Desc:  This function checks whether any mandatory element is
*              missing in message buffer. 
*
*       Ret:   ROK/RFAILED 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maChkMsgMand 
(
MaMsgCtl    *ctlp       /* message control pointer */
)
#else
PRIVATE S16 maChkMsgMand (ctlp)
MaMsgCtl    *ctlp;      /* message control pointer */
#endif
{
  MaTknElmtDef  *teDef;
  TRC2 (maChkMsgMand)

  while (*ctlp->sTelDef != (MaTknElmtDef *)NULLP)
  {
     teDef = *ctlp->sTelDef;
    /* check if element is mandatory */
    if (  (ctlp->maVer == LMA_VER1  && (teDef->flag & MA_TF_VER1_MAND))   || 
          (ctlp->maVer == LMA_VER2  && (teDef->flag & MA_TF_VER2_MAND))   || 
          (ctlp->maVer == LMA_VER2P && (teDef->flag & MA_TF_VER2P_MAND))  
#if (MAP_REL98 || MAP_REL99)  
          || ((ctlp->maVer == LMA_VER4)  && (teDef->flag & MA_TF_VER4_MAND))  
#endif
       )
     {
     /* ma001.202 - addition, error code should be updated */ 
   ctlp->errCode = MAT_DATA_MISSING;
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maChkMsgMand() failed, mand el. missing.\n"));
        RETVALUE(RFAILED);
     }
     switch(teDef->type)
     {
       case MA_TET_SEQ:
         maSkipSeq(ctlp);
         teDef = *ctlp->sTelDef;
         break;
       case MA_TET_SEQ_OF:
         maSkipSeqOf(ctlp);
         teDef = *ctlp->sTelDef;
         break;
       case MA_TET_CHOICE:
         maSkipChoice(ctlp);
         teDef = *ctlp->sTelDef;
         break;
       case MA_TET_EXT_CONT:
         MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(MaExtContSeq)); 
         ctlp->sTelDef = ctlp->sTelDef + MA_TET_EXTCONT_SIZE;
         teDef = *ctlp->sTelDef;
         break;
       default:
         ctlp->sTelDef++;
         teDef = *ctlp->sTelDef;
         break;
     }
  }
  RETVALUE(ROK);
} /* maChkMsgMand */


/*
*
*       Fun:   maChkSeqMand 
*
*       Desc:  This function checks whether any mandatory element is
*              missing in a sequence from the message buffer. 
*
*       Ret:   ROK/RFAILED 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maChkSeqMand 
(
MaMsgCtl    *ctlp       /* message control pointer */
)
#else
PRIVATE S16 maChkSeqMand (ctlp)
MaMsgCtl    *ctlp;      /* message control pointer */
#endif
{
  MaTknElmtDef  *teDef;
  TRC2 (maChkSeqMand)


  teDef = *ctlp->sTelDef;
  while (teDef->type != MA_TET_SEQ_TERM)
  {
    /* check if element is mandatory */
    if (  (ctlp->maVer == LMA_VER1  && (teDef->flag & MA_TF_VER1_MAND))   || 
          (ctlp->maVer == LMA_VER2  && (teDef->flag & MA_TF_VER2_MAND))   || 
          (ctlp->maVer == LMA_VER2P && (teDef->flag & MA_TF_VER2P_MAND)) 
#if (MAP_REL98 || MAP_REL99)  
          || ((ctlp->maVer == LMA_VER4)  && (teDef->flag & MA_TF_VER4_MAND))  
#endif
       )
     {
   ctlp->errCode = MAT_DATA_MISSING;
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maChkSeqMand() failed, mand seq missing.\n"));
        RETVALUE(RFAILED);
     }
     switch(teDef->type)
     {
       case MA_TET_SEQ:
         maSkipSeq(ctlp);
         teDef = *ctlp->sTelDef;
         break;
       case MA_TET_SEQ_OF:
         maSkipSeqOf(ctlp);
         teDef = *ctlp->sTelDef;
         break;
       case MA_TET_CHOICE:
         maSkipChoice(ctlp);
         teDef = *ctlp->sTelDef;
         break;
       case MA_TET_EXT_CONT:
         MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(MaExtContSeq)); 
         ctlp->sTelDef = ctlp->sTelDef + MA_TET_EXTCONT_SIZE;
         teDef = *ctlp->sTelDef;
         break;
       default:
         maSkipTkns(ctlp);
         teDef = *ctlp->sTelDef;
         break;
     }
  }
  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkSeqMand: Decode Sequence Successfully.\n"));

  ctlp->sTelDef++;
  RETVALUE(ROK);
} /* maChkSeqMand */


/*
*
*       Fun:   maSkipChoice
*
*       Desc:  This function encodes the sequence or a set of tokens
*
*       Ret:   ROK (encoding successful)
*              ROUTRES (out of resources)
*              RFAILED (general failure)
*
*       Notes: None
*
*       File:  ca_mf.c
*
*/
 
#ifdef ANSI
PUBLIC  S16 maSkipChoice
(
MaMsgCtl   *ctlp     /* message control pointer */
)
#else
PUBLIC  S16 maSkipChoice(ctlp)
MaMsgCtl   *ctlp;    /* message control pointer */
#endif
{
   TknU8         *evntStr;  /* stored event structure value */
   U32           size;      /* size to be incremented */
   MaTknElmtDef    *elmntDef; /* element defintion */
 
   TRC2(maSkipChoice)
 
   elmntDef = *ctlp->sTelDef;            
   evntStr = (TknU8 *) ctlp->sSt;
  
   /* get the size of the event structure to be incremented */
   size = elmntDef->maxLen;
 
   /* increment element definition over start of choice */
   ctlp->sTelDef++;
 

   MADBGP(MA_DBGMASK_SKIP, (maCb.maInit.prntBuf, 
          "maSkipChoice: Skiping Choice ......\n"));
                                   
   while (elmntDef->type != MA_TET_SEQ_TERM)
   {
      /* skip the element */
      maSkipTkns(ctlp);
 
      /* get the updated element defintion */
      elmntDef = *ctlp->sTelDef;
   }
 
  MADBGP(MA_DBGMASK_SKIP, (maCb.maInit.prntBuf, 
         "maSkipChoice: Skip Choice Successfully.\n"));

   /* increment over the end of choice */
   ctlp->sTelDef++;
 
   /* restore the event structure pointer */
   ctlp->sSt = (U8 *) evntStr;
 
   /* Increment the event structure pointer */
   ctlp->sSt += size;

   RETVALUE(ROK);
 
} /* cmSkipChoice */


/*
*
*       Fun:   maChkEleFlag 
*
*       Desc:  This function checks whether the message is defined for 
*              the protocol
*
*       Ret:   ROK/RFAILED 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maChkEleFlag 
(
MaMsgCtl    *ctlp       /* message control pointer */
)
#else
PRIVATE S16 maChkEleFlag (ctlp)
MaMsgCtl    *ctlp;      /* message control pointer */
#endif
{
  MaTknElmtDef  *teDef;
  TRC2 (maChkEleFlag)

  teDef = *ctlp->sTelDef;

  if ( (ctlp->maVer == LMA_VER1  && !(IS_EQUAL_VER1(teDef->verFlg))) ||
       (ctlp->maVer == LMA_VER2  && !(IS_EQUAL_VER2(teDef->verFlg))) ||
       (ctlp->maVer == LMA_VER2P && !(IS_EQUAL_VER2P(teDef->verFlg)))||
       (ctlp->maVer == LMA_VER4  && !(IS_EQUAL_VER4(teDef->verFlg)))    

     )
  {
     RETVALUE(FALSE);
  }
  RETVALUE(TRUE);
} /* maChkEleFlag */


/*
*
*       Fun:   maChkEleMand 
*
*       Desc:  This function checks whether any mandatory element is
*              missing in message buffer. 
*
*       Ret:   ROK/RFAILED 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maChkEleMand 
(
MaMsgCtl    *ctlp       /* message control pointer */
)
#else
PRIVATE S16 maChkEleMand (ctlp)
MaMsgCtl    *ctlp;      /* message control pointer */
#endif
{
  MaTknElmtDef  *teDef;
  TRC2 (maChkEleMand)

  teDef = *ctlp->sTelDef;

  if ( (ctlp->maVer == LMA_VER1  && !(IS_EQUAL_VER1(teDef->verFlg))) ||
       (ctlp->maVer == LMA_VER2  && !(IS_EQUAL_VER2(teDef->verFlg))) ||
       (ctlp->maVer == LMA_VER2P && !(IS_EQUAL_VER2P(teDef->verFlg)))|| 
       (ctlp->maVer == LMA_VER4  && !(IS_EQUAL_VER4(teDef->verFlg)))    
     )
  {
     RETVALUE(FALSE);
  }


  /* check if element is mandatory */
  if (  (ctlp->maVer == LMA_VER1  && (teDef->flag & MA_TF_VER1_MAND))   || 
        (ctlp->maVer == LMA_VER2  && (teDef->flag & MA_TF_VER2_MAND))   || 
        (ctlp->maVer == LMA_VER2P && (teDef->flag & MA_TF_VER2P_MAND))  
#if (MAP_REL98 || MAP_REL99)  
        || ((ctlp->maVer == LMA_VER4)  && (teDef->flag & MA_TF_VER4_MAND))  
#endif
     )
  {
    RETVALUE(TRUE);
  }

  RETVALUE(FALSE);
} /* maChkEleMand */


/*
*
*       Fun:   maDecOprPar  
*
*       Desc:  This function  decodes the parameters for MAP
*              Service Specific request 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC  S16 maDecOprPar
(
MaSap        *s,        /* Map SAP pointer */
U8           *sSt,      /* pointer to source structure */
U8           maVer,     /* Map version used for encoding */
U8           swtch,     /* switch */ 
U8           type,      /* type of data base to access */
U16          idx        /* Source message index */
)
#else
PUBLIC  S16 maDecOprPar (s, sSt, maVer, swtch, type, idx)
MaSap        *s;        /* Map SAP pointer */
U8           *sSt;      /* pointer to source structure */
U8           maVer;     /* Map version used for encoding */
U8           swtch;     /* switch */ 
U8           type;      /* type of data base to access */
U16          idx;       /* Source message index */
#endif
{
  MaMsgCtl *ctlp;
  S16    ret;

  TRC2(maDecOprPar)
  ctlp = &s->ctlp;
  maInitMsgCtl(ctlp);
  ctlp->mBuf = s->crntRxMsg;
  ctlp->sSt = sSt;  
  ctlp->maVer = maVer;
  ctlp->swtch = swtch;
  ctlp->skip = FALSE;
  ctlp->encode = FALSE;
  ctlp->decode = TRUE;
  ctlp->errCode = 0;
#ifdef  MA_MULT_SEG_DECODE
  ctlp->idx     = idx;
#endif

  /* get the appropriate database definition based on database type */

  switch(type)
  {
     case MAT_SS_REQ:
     {
        ctlp->sTelDef = maAllSSReqPDUDefs[idx].telDef;
        break;
     }
     case MAT_SS_RSP:
     {
        ctlp->sTelDef = maAllSSRspPDUDefs[idx].telDef;
        break;
     }
     case MAT_SS_RETERR:
     {
        ctlp->sTelDef = maAllSSErrPduDefs[idx];
        break;
     }
     default:
     {
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maDecOprPar() failed, invalid database type(%d).\n",type));
        RETVALUE(RFAILED);
     }

  } /* end switch */

  /* decode the message parameters */

  ret = maDecTknElmts(ctlp);
  RETVALUE(ret);

} /* maDecOprPar */


/*
*
*       Fun:   maDecTknElmnt 
*
*       Desc:  This function decodes a token element  
*
*       Ret:   ROK 
*
*       Notes: This function is used to decode an element 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maDecTknElmnt 
(
MaMsgCtl     *ctlp      /* message control pointer */
)
#else
PRIVATE S16 maDecTknElmnt (ctlp)
MaMsgCtl     *ctlp;     /* message control pointer */
#endif
{
  MaTknElmtDef *teDef;
  S16          ret;

  TRC2(maDecTknElmnt)

  teDef = *ctlp->sTelDef;
 
  switch(teDef->type)
  {
      case MA_TET_U8:
        ret = maDecOctet(ctlp,FALSE);
        break;
      case MA_TET_U8_ENUM:
        ret = maDecOctet(ctlp,TRUE);
        break;
      case MA_TET_NULL:
        ret = maDecNull(ctlp);
        break;
      case MA_TET_INT:
        ret = maDecInt(ctlp);
        break;
      case MA_TET_STR:
      case MA_TET_STRS:
      case MA_TET_STRM:
      case MA_TET_STRE:
#ifdef XWEXT
      case MA_TET_STR4:
#endif
        ret = maDecStr(ctlp);
        break;
      case MA_TET_STRUL:
        ret = maDecStrUL(ctlp);
        break;
      case MA_TET_BITSTR:
        ret = maDecBitStr(ctlp);
        ctlp->sTelDef++;
        break;
      case MA_TET_SEQ:
      case MA_TET_EXT_CONT:
        ret = maDecSeq(ctlp);
        break;
      case MA_TET_SEQ_OF:
        ret = maDecSeqOf(ctlp);
        break;
      case MA_TET_CHOICE:
        ret = maDecChoice(ctlp);
        break;
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
          MALOGERROR(ERRCLS_DEBUG, EMA296, (ErrVal)teDef->type, "maDecElmnt () Failed");
#endif
        ret = RFAILED;
        break;
  }
  RETVALUE(ret);
} /* end of maDecTknElmnt */

/*
*
*       Fun:   maDecTknElmts 
*
*       Desc:  This function decodes the token elements  
*
*       Ret:   ROK 
*
*       Notes: This function is used to encode the ordered list
*              of elements (SEQ and SEQ OF) 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maDecTknElmts 
(
MaMsgCtl     *ctlp      /* message control pointer */
)
#else
PRIVATE S16 maDecTknElmts (ctlp)
MaMsgCtl     *ctlp;     /* message control pointer */
#endif
{
  MaTknElmtDef *teDef;
  MsgLen       msgLen;
  S16          ret;

  TRC2(maDecTknElmts)

  teDef = *ctlp->sTelDef;
 
  if (ctlp->mBuf == NULLP)
  {
    RETVALUE(maChkMsgMand(ctlp));
  }

  while(teDef != (MaTknElmtDef *)NULLP) 
  {
    /* mlen is the length of the message in octets */
    (Void) SFndLenMsg(ctlp->mBuf, &msgLen);
    if (msgLen == 0)
    {
      /* reached end of buffer - check for missing mand el */
      RETVALUE(maChkMsgMand(ctlp));
    }

    switch(teDef->type)
    {
        case MA_TET_U8:
          ret = maDecOctet(ctlp,FALSE);
          break;
        case MA_TET_U8_ENUM:
          ret = maDecOctet(ctlp,TRUE);
          break;
        case MA_TET_NULL:
          ret = maDecNull(ctlp);
          break;
        case MA_TET_INT:
          ret = maDecInt(ctlp);
          break;
        case MA_TET_STR:
        case MA_TET_STRS:
        case MA_TET_STRM:
        case MA_TET_STRE:
#ifdef XWEXT
        case MA_TET_STR4:
#endif
          ret = maDecStr(ctlp);
          break;
        case MA_TET_STRUL:
          ret = maDecStrUL(ctlp);
          break;
        case MA_TET_BITSTR:
          ret = maDecBitStr(ctlp);
          ctlp->sTelDef++;
          break;
        case MA_TET_SEQ:
        case MA_TET_EXT_CONT:
          ret = maDecSeq(ctlp);
          break;
        case MA_TET_SEQ_OF:
          ret = maDecSeqOf(ctlp);
          break;
        case MA_TET_CHOICE:
          ret = maDecChoice(ctlp);
          break;
        default:
#if (ERRCLASS & ERRCLS_DEBUG)
          MALOGERROR(ERRCLS_DEBUG, EMA297, (ErrVal)teDef->type, "maDecTknElmts () Failed");
#endif
          ret = RFAILED;
          break;
    }
    if (ret != ROK)
    {
       RETVALUE(ret);
    }
    teDef = *ctlp->sTelDef;
  }
  (Void) SFndLenMsg(ctlp->mBuf, &msgLen);
  if (msgLen != 0)
  {
     ctlp->errCode = MAT_MISTYPE_PARAM;
     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maDecTknElmts() failed, mistype param.\n"));
     RETVALUE(RFAILED);
  }
  RETVALUE(ROK);
} /* end of maDecTknElmts */



/*
*
*       Fun:    maDecOctet 
*
*       Desc:  This function decodes an octet  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maDecOctet 
(
MaMsgCtl    *ctlp,      /* message control pointer */
Bool        flg         /* flag to indicate whether the octet is Enumerated */ 
)
#else
PUBLIC S16 maDecOctet (ctlp,flg)
MaMsgCtl    *ctlp;      /* message control pointer */
Bool        flg;        /* flag to indicate whether the octet is Enumerated */ 
#endif
{
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  Buffer        *mBuf;
  U8           tmpLen;
  S16           ret;

  TRC2(maDecOctet)

  teDef = *ctlp->sTelDef;
  sSt   = (TknU8 *)ctlp->sSt;
  mBuf  = ctlp->mBuf;

  /* check if there is a user function */
  if (teDef->func)
  {
     ret = (*teDef->func)(ctlp);
     RETVALUE(ret);
  }

  if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    RETVALUE(ret);
  }
  if (data != teDef->tag)
  {
    /* check whether Map versions are compatible */
    if ((ret = maChkEleMand(ctlp) == FALSE))
    {
      /* skip the element in the data base and make as not present in event str */
      ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
      sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
      /* bump structure pointer in message control */
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
      RETVALUE(ROK);
    }
    else
    {
       ctlp->errCode = MAT_DATA_MISSING;
       MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
       "maDecOctet() failed, data missing.\n"));
       RETVALUE(RFAILED);
    }

  }
  else
  {
     if ( (ctlp->maVer == LMA_VER1  && !(IS_EQUAL_VER1(teDef->verFlg))) ||
       (ctlp->maVer == LMA_VER2  && !(IS_EQUAL_VER2(teDef->verFlg))) ||
       (ctlp->maVer == LMA_VER2P && !(IS_EQUAL_VER2P(teDef->verFlg)))|| 
       (ctlp->maVer == LMA_VER4  && !(IS_EQUAL_VER4(teDef->verFlg)))    
        )
     {
         /* skip the element in the data base and make as not 
            present in event str */
         ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
         sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
         /* bump structure pointer in message control */
         MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
         RETVALUE(ROK);
     }
  }

  /* remove the octet */

  if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
  {
     ctlp->errCode = MAT_MISTYPED_PARAM;
     RETVALUE(ret);
  }

  if (flg == TRUE)
  {
    if ((ret = maChkEnum(sSt->val, teDef, 0)) != ROK)
    {
      ctlp->errCode = MAT_UNX_DATA_VALUE;
      RETVALUE(ret);
    }
  }

  /* initialize the event structure */
  sSt->pres = TRUE;

  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecOctect: %s Tag [%x] Len [%x] Val [%x] \n", 
          maEleType[teDef->type], data, tmpLen, sSt->val));

  /* bump structure pointer in message control */
  MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
  ctlp->sTelDef++;
  RETVALUE(ROK);

} /* maDecOctet */


/*
*
*       Fun:    maDecNull 
*
*       Desc:  This function decodes a null value  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maDecNull 
(
MaMsgCtl    *ctlp       /* message control pointer */
)
#else
PUBLIC S16 maDecNull (ctlp)
MaMsgCtl    *ctlp;      /* message control pointer */
#endif
{
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  Buffer        *mBuf;
  S16           ret;
  Data          unPkArray[MA_MAX_PKARRAY_LEN];

  TRC2(maDecNull)

  teDef = *ctlp->sTelDef;
  sSt   = (TknU8 *)ctlp->sSt;
  mBuf  = ctlp->mBuf;

  if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    RETVALUE(ret);
  }
  if (data != teDef->tag)
  {
    /* check whether Map versions are compatible */
    if ((ret = maChkEleMand(ctlp) == FALSE))
    {
      /* skip the element in the data base and make as not present in event str */
      ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
      sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
      /* bump structure pointer in message control */
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
      RETVALUE(ROK);
    }
    else
    {
       ctlp->errCode = MAT_DATA_MISSING;
       MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
       "maDecNull() failed, data missing.\n"));
       RETVALUE(RFAILED);
    }

  }
  /* remove the Null element */

  if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK) 
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maDecNull() failed, mistype param.\n"));
    RETVALUE(RFAILED);
  }

  if (unPkArray[1] != 0)
  {
    ctlp->errCode = MAT_UNX_DATA_VALUE;
		/* ma001.203: Modification. Added Tag Info */	
    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maDecNull() failed, Tag [%x] unexpect data value(%d).\n", unPkArray[0], unPkArray[1]));
    RETVALUE(RFAILED);
  }

  sSt->pres = TRUE;
  sSt->val = 0;

  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecNull: %s Tag [%x] Len [%x] \n", 
          maEleType[teDef->type], unPkArray[0], unPkArray[1]));

  ctlp->sTelDef++;
  /* bump structure pointer in message control */
  MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
  RETVALUE(ROK);
} /* maDecNull */



/*
*
*       Fun:    maDecStr 
*
*       Desc:  This function decodes a string value  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maDecStr 
(
MaMsgCtl    *ctlp       /* message control pointer */
)
#else
PUBLIC S16 maDecStr (ctlp)
MaMsgCtl    *ctlp;      /* message control pointer */
#endif
{
  MaTknElmtDef  *teDef;
  Data          data;
  Buffer        *mBuf;
  TknStr        *sStr;
  TknStrS       *sStrS;
  TknStr4       *sStr4;
  TknStrM       *sStrM;
  TknStrE       *sStrE;
  U16           ret;
  U8            len;

  TRC2(maDecStr)

  teDef = *ctlp->sTelDef;
  mBuf  = ctlp->mBuf;

  /* check if there is a user function */
  if (teDef->func)
  {
     ret = (*teDef->func)(ctlp);
     RETVALUE(ret);
  }

  if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    RETVALUE(ret);
  }
  if (data != teDef->tag)
  {
    if ((ret = maChkEleMand(ctlp) == FALSE))
    {
      /* skip the element in the data base and make as not present in event str */
      ctlp->sTelDef++;
      /* bump structure pointer in message control */
      switch (teDef->type)
      {
         case MA_TET_STR:
#ifndef MA_MULT_SEG_DECODE
           ((TknStr *)(ctlp->sSt))->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */ 
           MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStr)); 
           break;
         case MA_TET_STRS:
#ifndef MA_MULT_SEG_DECODE
           ((TknStrS *)(ctlp->sSt))->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
           MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
           break;
#ifdef XWEXT
         case MA_TET_STR4:
#ifndef MA_MULT_SEG_DECODE
           ((TknStr4 *)(ctlp->sSt))->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
           MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStr4)); 
           break;		   
#endif
         case MA_TET_STRM:
#ifndef MA_MULT_SEG_DECODE
           ((TknStrM *)(ctlp->sSt))->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
           MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrM)); 
           break;
         case MA_TET_STRE:
#ifndef MA_MULT_SEG_DECODE
           ((TknStrE *)(ctlp->sSt))->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
           MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrE)); 
           break;
         default:
#if (ERRCLASS & ERRCLS_DEBUG)
           MALOGERROR(ERRCLS_DEBUG, EMA298, (ErrVal)teDef->type, "maDecStr () Failed");
#endif
           break;
      }
      RETVALUE(ROK);
    }
    else
    {
       ctlp->errCode = MAT_DATA_MISSING;
       MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
       "maDecStr() failed, mistype param.\n"));
       RETVALUE(RFAILED);
    }

  }
  else
  {
     if ( (ctlp->maVer == LMA_VER1  && !(IS_EQUAL_VER1(teDef->verFlg))) ||
       (ctlp->maVer == LMA_VER2  && !(IS_EQUAL_VER2(teDef->verFlg))) ||
       (ctlp->maVer == LMA_VER2P && !(IS_EQUAL_VER2P(teDef->verFlg)))|| 
       (ctlp->maVer == LMA_VER4  && !(IS_EQUAL_VER4(teDef->verFlg)))    
        )
     {
      /* skip the element in the data base and make as not present in event str */
      ctlp->sTelDef++;
      /* bump structure pointer in message control */
      switch (teDef->type)
      {
         case MA_TET_STR:
#ifndef MA_MULT_SEG_DECODE
           ((TknStr *)(ctlp->sSt))->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
           MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStr)); 
           break;
         case MA_TET_STRS:
#ifndef MA_MULT_SEG_DECODE
           ((TknStrS *)(ctlp->sSt))->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */ 
           MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
           break;
#ifdef XWEXT
         case MA_TET_STR4:
#ifndef MA_MULT_SEG_DECODE
           ((TknStr4 *)(ctlp->sSt))->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */ 
           MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStr4)); 
           break;
#endif
         case MA_TET_STRM:
#ifndef MA_MULT_SEG_DECODE
           ((TknStrM *)(ctlp->sSt))->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */ 
           MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrM)); 
           break;
         case MA_TET_STRE:
#ifndef MA_MULT_SEG_DECODE
           ((TknStrE *)(ctlp->sSt))->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */ 
           MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrE)); 
           break;
         default:
#if (ERRCLASS & ERRCLS_DEBUG)
           MALOGERROR(ERRCLS_DEBUG, EMA299, (ErrVal)teDef->type, "maDecStr () Failed");
#endif
           break;
      }
      RETVALUE(ROK);
     }
  }

  switch (teDef->type)
  {
    case MA_TET_STR:
      sStr = (TknStr *)ctlp->sSt;
      if (( ret = maRemPrim(mBuf, ctlp, (U8 *)&sStr->val[0], &len)) != ROK)
      {
         ctlp->errCode = MAT_MISTYPED_PARAM;
         RETVALUE(ret);
      }
      sStr->len = len;
      sStr->pres = TRUE;
      /* bump structure pointer in message control */
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStr)); 
      break;
    case MA_TET_STRS:
      sStrS = (TknStrS *)ctlp->sSt;
      if (( ret = maRemPrim(mBuf, ctlp, (U8 *)&sStrS->val[0], &len)) != ROK)
      {
         ctlp->errCode = MAT_MISTYPED_PARAM;
         RETVALUE(ret);
      }
      sStrS->len = len;
      if(teDef->tag == MA_TAG_NUMSTR)
      {
         U8 i; 
         for (i=0; i<sStrS->len; i++)
         {
            if( (sStrS->val[i] < '0') || (sStrS->val[i] > '9') )
            {
               ctlp->errCode = MAT_MISTYPED_PARAM;
					  /* ma001.203: Modification. Added Tag Info */	
               MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
               "maDecStr() failed, Tag [%x] mistype param(%d).\n", teDef->tag, sStrS->val[i]));
               RETVALUE(RFAILED);
            }
         }
      }
      sStrS->pres = TRUE;
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
      break;
#ifdef XWEXT
    case MA_TET_STR4:
      sStr4 = (TknStr4 *)ctlp->sSt;
      if (( ret = maRemPrim(mBuf, ctlp, (U8 *)&sStr4->val[0], &len)) != ROK)
      {
         ctlp->errCode = MAT_MISTYPED_PARAM;
         RETVALUE(ret);
      }
      sStr4->len = len;
      if(teDef->tag == MA_TAG_NUMSTR)
      {
         U8 i; 
         for (i=0; i<sStr4->len; i++)
         {
            if( (sStr4->val[i] < '0') || (sStr4->val[i] > '9') )
            {
               ctlp->errCode = MAT_MISTYPED_PARAM;
					  /* ma001.203: Modification. Added Tag Info */	
               MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
               "maDecStr() failed, Tag [%x] mistype param(%d).\n", teDef->tag, sStr4->val[i]));
               RETVALUE(RFAILED);
            }
         }
      }
      sStr4->pres = TRUE;
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStr4)); 
      break;
#endif
    case MA_TET_STRM:
      sStrM = (TknStrM *)ctlp->sSt;
      if (( ret = maRemPrim(mBuf, ctlp, (U8 *)&sStrM->val[0], &len)) != ROK)
      {
         ctlp->errCode = MAT_MISTYPED_PARAM;
         RETVALUE(ret);
      }
      sStrM->len = len;
      sStrM->pres = TRUE;
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrM)); 
      break;
    case MA_TET_STRE:
      sStrE = (TknStrE *)ctlp->sSt;
      if (( ret = maRemPrim(mBuf,ctlp,  (U8 *)&sStrE->val[0], &len)) != ROK)
      {
         ctlp->errCode = MAT_MISTYPED_PARAM;
         RETVALUE(ret);
      }
      sStrE->len = len;
      sStrE->pres = TRUE;
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrE)); 
      break;
    default:
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA300, (ErrVal)teDef->type, "maSkipTkns () Failed");
#endif
      break;
  }

  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecStr: %s Tag [%x] Len [%x] \n", 
          maEleType[teDef->type], data, len));

  ctlp->sTelDef++;
  RETVALUE(ROK);

} /* maDecStr */



/*
*
*       Fun:   maDecBitStr 
*
*       Desc:  This function decodes the bit string. 
*
*       Ret:   ROK 
*
*       Notes: This function decodes only 8 bit enumerated bit
*              string. 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maDecBitStr 
(
MaMsgCtl    *ctlp       /* message control structure */
)
#else
PUBLIC S16 maDecBitStr (ctlp) 
MaMsgCtl    *ctlp;      /* message control structure */
#endif
{
  Buffer        *mBuf;
  MaTknElmtDef  *teDef;
  TknStrE       *dStE;
  TknStrS       *dStS;
  Data          data;
  Data          tmpData;
  Data          uBits;
  Bool          eocFlg;
  U8            i;
  S16           ret;
  Data          unPkArray[MA_MAX_PKARRAY_LEN];

  TRC2(maDecBitStr)

  mBuf = ctlp->mBuf;
  teDef = *ctlp->sTelDef;

  /* check if there is a user function */
  if (teDef->func)
  {
     ret = (*teDef->func)(ctlp);
     RETVALUE(ret);
  }

  dStE = (TknStrE *) NULLP;
  dStS = (TknStrS *) NULLP;
  if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    RETVALUE(ret);
  }
  if (data != teDef->tag)
  {
    if ((ret = maChkEleMand(ctlp) == FALSE))
    {
      /* skip the element in the data base and make as not present in event str */
      ctlp->sTelDef++;
      if (teDef->maxLen > MF_SIZE_TKNSTRS)
      {
#ifndef MA_MULT_SEG_DECODE
         ((TknStrE *)(ctlp->sSt))->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
         /* bump structure pointer in message control */
         MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrE)); 
      }
      else 
      {
#ifndef MA_MULT_SEG_DECODE
         ((TknStrS *)(ctlp->sSt))->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
         /* bump structure pointer in message control */
         MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
      }
      RETVALUE(ROK);
    }
    else
    {
       ctlp->errCode = MAT_DATA_MISSING;
       MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
       "maDecBitStr() failed, data missing.\n"));
       RETVALUE(RFAILED);
    }
  }

  if (teDef->maxLen > MF_SIZE_TKNSTRS)
  {
     dStE = (TknStrE *)(ctlp->sSt);
  }
  else
  {
     dStS = (TknStrS *)(ctlp->sSt);
  }

  /* tag is in first position and always 8 bit */
  if ((ret = SExamMsg(&data, mBuf, 1)) != ROK)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    RETVALUE(ret);
  }

  if (!(data & 0x80))
  {
     eocFlg = FALSE;
  }
  else if (data == 0x80)
  {
    eocFlg = TRUE; 
  }
  else
  {
     /* this function is used to encode only 8 bit enumerated bit string
      * so in most cases the length will be encoede in short form. But
      * it is valid to encode using the indefinate form. But long form
      * definate encoding can't be used as it will not satisfy the the
      * condition of using minimum bytes to encode the length. */
     ctlp->errCode = MAT_MISTYPE_PARAM;
     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maDecBitStr() failed, mistype param.\n"));
     RETVALUE(RFAILED);
  }

  /* remove one byte length tag and unused bits octet */

  if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)4, mBuf)) != ROK)
  {
     ctlp->errCode = MAT_MISTYPE_PARAM;
     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maDecBitStr() failed, mistype param.\n"));
     RETVALUE(RFAILED);
  }
  /* remove the bit string value */
  uBits = unPkArray[2];

  {
     U8 no_of_octets; /* number of octets */
     U8 octet_index;  /* index into the octet array */
     U8 shift;        /* temporary variable */

     no_of_octets = unPkArray[1] - 1;

     if ( (U8)((no_of_octets)*8 - uBits) < teDef->minLen || 
          (U8)((no_of_octets)*8 - uBits) > teDef->maxLen)
     {
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maDecBitStr() failed, Tag [%x] invalid param.\n",data));
        RETVALUE(RFAILED);
     }

     if(no_of_octets > 1)
     {
        if ((ret = SRemPreMsgMult(&unPkArray[4], (MsgLen)(no_of_octets-1), 
                   mBuf)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecBitStr() failed, mistype param.\n"));
           RETVALUE(RFAILED);
        }
     }
     
     octet_index = 0;
     i=0;

     while(octet_index < (no_of_octets - 1))
     {
        data = unPkArray[3+octet_index];

        /* allocate string */
        for(shift=0;shift< 8 ;shift++,i++)
        {
           tmpData = data &0x80;
           if(teDef->maxLen > MF_SIZE_TKNSTRS)
           {
              dStE->val[i] = tmpData >> 7;
           }
           else
           {
              dStS->val[i] = tmpData >> 7;
           }
           data <<=1;
        }
        octet_index ++;
     }
     data = unPkArray[3+octet_index];
     for(shift = 0;shift<(U8) (8 - uBits);shift++,i++)
     {
       tmpData = data &0x80;
       if(teDef->maxLen > MF_SIZE_TKNSTRS)
       {
          dStE->val[i] = tmpData >> 7;
       }
       else
       {
          dStS->val[i] = tmpData >> 7;
       }
       data <<=1;
     }
     if(teDef->maxLen > MF_SIZE_TKNSTRS)
     {
        dStE->pres = TRUE;
        dStE->len  = i;
     }
     else
     {
        dStS->pres = TRUE;
        dStS->len  = i;
     }
  }

  if (eocFlg == TRUE)
  {
    /* remove the two EOC tag byets */

    if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }
  }

  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecBitStr: %s Tag [%x] Len [%x] shift [%x] \n", 
          maEleType[teDef->type], data, unPkArray[1], unPkArray[2]));

  /* increment the data base pointer and event struct. pointer */
  ctlp->sTelDef++;

  if (teDef->maxLen > MF_SIZE_TKNSTRS)
  {
     MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrE)); 
  }
  else
  {
     MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
  }
  RETVALUE(ROK);
} /* maDecBitStr */

 
 
 

/*
*
*      Fun:   cmGetTag
*
*      Desc:  Copies the ASN.1 tag to an array, pointer to which
*             is passed.
*
*      Ret:   ROK (Decode was successful)
*             RFAILED (otherwise)
*
*      Notes: None
*
*      File:  ca_mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 maGetTag
(
MaMsgCtl   *ctlp,       /* message control point */
U8         *pkArray,      /* array where the tag is copied */
U16        offset,        /* Offset in the mBuf */
U8         *size          /* size of the tag */
)
#else
PUBLIC S16 maGetTag(ctlp, pkArray, offset, size)
MaMsgCtl   *ctlp;       /* message control point */
U8         *pkArray;      /* array where the tag is copied */
U16        offset;        /* offset in the mBuf */
U8         *size;         /* size of the tag */
#endif
{
   U8          i;         /* counter */
   S16         ret;       /* return values */
   TRC2(maGetTag)
 
   i = 0;    /* Intialize the array index */
 
   ret = SExamMsg(&pkArray[i], ctlp->mBuf, (MsgLen)(offset + i));
 
   if (ret != ROK)
   {
      MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
      "maGetTag() failed, fail to copy data from offset(%d).\n", offset +1));
      RETVALUE(RFAILED);
   }

   /* Check if more than one tag byte */
   if ((pkArray[i] & LONG_TAG_IND) == LONG_TAG_IND)
   {
      /* more than one tag byte, go through the loop */
 
      i++;
 
      while (i < MAX_TAG_LEN)
      {
 
         ret = SExamMsg(&pkArray[i], ctlp->mBuf, (MsgLen)(offset + i));
 
         if (ret != ROK)
         {
            MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
            "maGetTag() failed, fail to copy data from offset(%d).\n", offset +i));
            RETVALUE(RFAILED);
         }
 
         if (!(pkArray[i] & TAG_MORE_BIT))
         {
            /* no more tag bytes */
            break;
         }
 
         i++;           /* increment the number of tag bytes received */
 
      };
 
   } /* end if */
 
   if (i == MAX_TAG_LEN)
   {
      MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
      "maGetTag() failed, the received tag bytes reached MAX_TAG_LEN(%d).\n",i));
      RETVALUE(RFAILED);
   }

   /* indicate the size of the tag to the caller */
   *size = (i+1);          /* one more than the array index */
 
   RETVALUE(ROK);
 
} /* maGetTag */
 
 


/*
*
*       Fun:    maDecChoice 
*
*       Desc:  This function decodes the Choice element 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maDecChoice 
(
MaMsgCtl   *ctlp        /* message control pointer */
)
#else
PUBLIC S16 maDecChoice (ctlp )
MaMsgCtl   *ctlp;       /* message control pointer */
#endif
{
   MaTknElmtDef *teDef;     /* element definition */
   MaTknElmtDef **tmpDef;    /* element definition */
   MaTknElmtDef **tmpDefn;   /* element definition */
   Bool         multChoice;  /* multiple Choice flag */
   S16          ret;         /* return value */
   U8           tagSize;     /* Size of the tag */
   TknU8        *tmpSSt;      /* Token pointer  */
   TknU8        *tmpPtr;     /* Temporary pointer to the token pointer */
   Bool         skipElmnt;   /* need to skip the element */
   MsgLen       msgLen;     /* Length of the message */
   U16          j;           /* element counter */

   /* Temporay array */
   Data     pkArray[STR_BUFSIZE + EOC_TAG_LEN];

   TRC2(maDecChoice)

   teDef = *ctlp->sTelDef;
   if(teDef->tag != MA_TAG_NA)
   {
      ret = maDecTagChoice(ctlp);
      RETVALUE(ret);
   }

   multChoice = FALSE;

   /* check if this element is defined for this protocol */
   if (( ret = maChkEleFlag(ctlp)) == FALSE)
   {
      /* this element is not defined for this protocol , skip it */
      maSkipTkns(ctlp);
      ctlp->choiceRes = RFAILED;
      RETVALUE(ROK);
   }

   MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecChoice: Decoding Choice ......\n"));

   /* get the element definition */
   teDef = *ctlp->sTelDef;

   /* Check the message length */
   (Void) SFndLenMsg(ctlp->mBuf,&msgLen);

   if (msgLen == 0)
   {
      if (maChkEleMand(ctlp) == TRUE)
      {
         /* element is mandatory, cannot be skipped */
         ctlp->errCode = MA_MAND_MISS;
         ctlp->choiceRes = RFAILED;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecChoice() failed, mand. data missing.\n"));
         RETVALUE(RFAILED);
      }
      else
      {
         /* element is not mandatory, can be skipped */
         maSkipTkns(ctlp);
         ctlp->choiceRes = RFAILED;
         RETVALUE(ROK);
      }
   } /* end if (msgLen == 0)*/

   skipElmnt = FALSE;         /* do not skip the element */
   tmpDef     = ctlp->sTelDef; /* Store the element definition pointer */
   tmpSSt     = (TknU8 *) ctlp->sSt;    /* Store the Token Pointer */
   
   teDef      = *ctlp->sTelDef;        /* Get the element definition */

   /* increment over the start of choice */
   ctlp->sTelDef ++;

  /* Get the element definition of the first element */
  teDef = *ctlp->sTelDef; 

  /* skip over the choice type token */
  MA_BUMP_STP( (PTR *) &ctlp->sSt , (U32) sizeof(TknU8));

  /* initialize the element count */
  j=1;

  /* Get and Check the tag, do not strip the tag bytes */
  if ((ret = maGetTag(ctlp, pkArray,0, &tagSize)) == RFAILED)
  {
     ctlp->errCode = MAT_MISTYPE_PARAM;
     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maDecChoice() failed, tag error.\n"));
     RETVALUE(RFAILED);
  }
  while(teDef->type != MA_TET_SEQ_TERM)
  {
     if(teDef->type == MA_TET_CHOICE && maChkEleFlag(ctlp) == TRUE)
     {
        tmpPtr = (TknU8 *) ctlp->sSt;
        tmpDefn = ctlp->sTelDef;

        multChoice = TRUE;
        ctlp->choiceRes=RFAILED;
        maDecChoice(ctlp);
        if (ctlp->choiceRes == ROK)
        {
           break;
        }
        multChoice = FALSE;

        ctlp->sTelDef = tmpDefn;
        ctlp->sSt     = (U8 *)tmpPtr;
        maSkipTkns(ctlp);
        teDef = *ctlp->sTelDef;
        ctlp->sSt = (U8 *)tmpPtr;
       

        j++;
        continue;
     }
     else 
     /* check the tag against the data base definition of the element */
     if ((maChkEleFlag(ctlp) == FALSE) || 
         (maChkTag(ctlp, pkArray, tagSize, &skipElmnt) == RFAILED))
     {
         /* store the event structutre pointer. this is required
            because for decoding each element of the choice we need
            to make sure that we start from the start of the event
            structure pointer */
 
         tmpPtr = (TknU8 *) ctlp->sSt;
 
         /* tag defintions don't match, continue till we find one */
         maSkipTkns(ctlp);
         teDef = *ctlp->sTelDef;

         /* restore the pointer */
         ctlp->sSt = (U8 *) tmpPtr;
 
         j++;
         continue;

     }
     else
     {
        /* found the element, break out of the while loop */
        break;
     }
     
  } /* end while */

  if (teDef->type == MA_TET_SEQ_TERM)
  {
      /* did not find a match, unknown element */
 
      /* indicate that the choice is not present */
#ifndef MA_MULT_SEG_DECODE
      tmpSSt->pres = FALSE;                         /* choice present */
      tmpSSt->val  = 0;                             /* element index */
#endif /* MA_MULT_SEG_DECODE */
 
      /* Restore the pointers to the start of choice */
      ctlp->sTelDef = tmpDef;
      ctlp->sSt     = (U8 *)tmpSSt;
 
      /* Check if element is mandatory */
      if (maChkEleMand(ctlp) == TRUE)
      {
         /* element is mandatory, cannot be skipped */
         ctlp->errCode = MA_MAND_MISS;                      
         ctlp->choiceRes = RFAILED;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecChoice() failed, mand el. missing.\n"));
         RETVALUE(RFAILED);
      }
      else
      {
         /* element is not mandatory, can be skipped */
         maSkipTkns(ctlp);
         ctlp->choiceRes = RFAILED;
         RETVALUE(ROK);
      }
   }
   else
   {
      /* make the element as present in the event structure */
 
      tmpSSt->pres = TRUE;                          /* choice present */
      tmpSSt->val  = (U8) j;                        /* element index */
   }

   /* decode the element depending on the element type */
   if ( multChoice == FALSE && ((ret = maDecTknElmnt(ctlp)) != ROK))
   {
      /* error code already filled, don't do it again */
      MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
      "maDecChoice() failed, fail to decode token el(%d).\n", j));
      RETVALUE(RFAILED);
   }


   MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
          "maDecChoice: Decoding Choice Successfully.\n"));

   /* restore the element defintion to choice start */
   ctlp->sTelDef = tmpDef;
 
   /* restore the event structure */
   ctlp->sSt = (U8 *)tmpSSt;
 
   /* now skip over the set */
   maSkipTkns(ctlp);
 
   ctlp->choiceRes = ROK;

   RETVALUE(ROK);

} /* maDecChoice */


/*
*
*      Fun:   maChkTag
*
*      Desc:  Checks the tag value against the database defintion of
*             the element
*
*      Ret:   ROK (tag matches)
*             RFAILED (otherwise)
*
*      Notes: None
*
*      File:  ca_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 maChkTag
(
MaMsgCtl   *ctlp,        /* message control point */
U8         *pkArray,      /* array where the tag is present */
U8         size,          /* size of the tag */
Bool       *skipElmnt     /* TRUE is element needs to be skipped */
)
#else
PRIVATE S16 maChkTag(ctlp, pkArray, size, skipElmnt)
MaMsgCtl   *ctlp;        /* message control point */
U8         *pkArray;      /* array where the tag is copied */
U8         size;          /* size of the tag */
Bool       *skipElmnt;    /* TRUE is element needs to be skipped */
#endif
{
   U8            i=0;         /* counter */
   MaTknElmtDef  *teDef; /* database defintion for this element */
   Bool          err;       /* mismatch in tag */
 
   TRC2(maChkTag)
 
   /* get the element defintion from the message control point */
   teDef = *ctlp->sTelDef;
 
   /* make the error flag flase */
   err = FALSE;

 
   /* check for tag value mismatch */
   if (pkArray[i] != teDef->tag)
   {
      err = TRUE;
   }
 
 
   /* number of bytes copied in the array is the length of the tag in the
      element defintion for this element */
 
   if (err == FALSE)
   {
      RETVALUE(ROK);
   }
   else
   {
      /* there is no  error, check if element is mandatory */
      if (maChkEleMand(ctlp) == TRUE)
      {
         /* element is mandatory, cannot be skipped */
         *skipElmnt = FALSE;
      }
      else
      {
         /* element is not mandatory, can be skipped */
         *skipElmnt = TRUE;
      }
 
      MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
      "maChkTag() failed, tag value(%d) mismatch.\n",pkArray[i]));
      RETVALUE(RFAILED);
   }
 
} /* end of maChkTag */

/*
*
*       Fun:    maDecSeq 
*
*       Desc:  This function decodes the sequence element 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maDecSeq 
(
MaMsgCtl   *ctlp        /* message control pointer */
)
#else
PUBLIC S16 maDecSeq (ctlp )
MaMsgCtl   *ctlp;       /* message control pointer */
#endif
{
  MaTknElmtDef  *teDef;
  Data          data;
  Buffer        *mBuf;
  Bool          eocFlg;
  Bool          remEocFlg;
  U8            swtch;
  MsgLen        tmpLen;
  MsgLen        lfLen;  /* Length of length field */
  MsgLen        seqLen;
  Data          unPkArray[MA_MAX_PKARRAY_LEN];
  MsgLen        orgMsgLen;
  MsgLen        newMsgLen;
  S16           ret;
#ifdef MAP_PHASE2_EXT_MARK
  TknStrE       *sStrE;
#endif

  TRC2(maDecSeq)

  data = MA_TAG_NA;
  teDef = *ctlp->sTelDef;
  mBuf  = ctlp->mBuf;
  eocFlg = FALSE;
  swtch = (U8)ctlp->swtch;

  /* check if there is a user function */
  if (teDef->func)
  {
     ret = (*teDef->func)(ctlp);
     RETVALUE(ret);
  }

  /* check whether Map versions are compatible */
  if ( (ctlp->maVer == LMA_VER1  && !(IS_EQUAL_VER1(teDef->verFlg))) ||
       (ctlp->maVer == LMA_VER2  && !(IS_EQUAL_VER2(teDef->verFlg))) ||
       (ctlp->maVer == LMA_VER2P && !(IS_EQUAL_VER2P(teDef->verFlg)))|| 
       (ctlp->maVer == LMA_VER4  && !(IS_EQUAL_VER4(teDef->verFlg)))    
      )
  {
    /* skip in the data base and make as not present in event str */
    /* move structure pointer and element definition pionter to *
     * start of this sequence, and skip whore sequence.         */
     maSkipSeq(ctlp);
     RETVALUE(ROK);
  }

  (Void)SExamMsg(&data, mBuf, 0);

  if (data != teDef->tag)
  {
    /* check whether Map versions are compatible */
    if ((ret = maChkEleMand(ctlp) == FALSE))
    {
      /* skip the elmt. in the data base and make as not present in event str */
      maSkipSeq(ctlp);
      RETVALUE(ROK);
    }
    else
    {
       ctlp->errCode = MAT_DATA_MISSING;
       MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
       "maDecSeq() failed, mistype param, map versions are not compatible.\n"));
       RETVALUE(RFAILED);
    }

  }

  if ((ret = maFindLen(ctlp->mBuf, 0, &seqLen, &eocFlg, &lfLen)) != ROK)
  {
     ctlp->errCode = MAT_MISTYPED_PARAM;
     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maDecSeq() failed, mistype param, fail to get length.\n"));
     RETVALUE(RFAILED);
  }

  /* decode the sequence */
  (Void)SRemPreMsg(&data, mBuf);


  if ((ret = maRemLen(mBuf, &remEocFlg)) != ROK)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maDecSeq() failed, mistype param, fail to remove the len byte from mBuf.\n"));
    RETVALUE(RFAILED);
  }

  /* ma002.203: If tag and len are pres and seqLen is 0, check if any of its
  elements is mandatory. If so, return failure otherwise, return ROK ***/
  if (seqLen == 0)
  {
#ifndef MA_ASN_DEC_SEQ
    if ((ret = maChkEleMand(ctlp)) == FALSE)
    {
      maSkipSeq(ctlp);
      if (remEocFlg == TRUE)
      {
          /* remove the two EOC bytes */
          if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
          {
            ctlp->errCode = MAT_MISTYPE_PARAM;
            RETVALUE(ret);
          }
      }
      RETVALUE(ROK);
    }
    else
    {
#endif /* MA_ASN_DEC_SEQ  */
      ctlp->sTelDef++;
      if((ret = maChkSeqMand(ctlp)) == ROK)
      {
         if (remEocFlg == TRUE)
         {
            if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
            {
               ctlp->errCode = MAT_MISTYPE_PARAM;
               RETVALUE(ret);
            }
         }
         RETVALUE(ROK);
      }
      ctlp->errCode = MAT_DATA_MISSING;
      MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
      "maDecSeq() failed, mand. data missing.\n"));
      RETVALUE(RFAILED);
#ifndef MA_ASN_DEC_SEQ
    }
#endif /* MA_ASN_DEC_SEQ */
  }

  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecSeq: Decoding Sequence ...... \n \
          %s Tag [%x] \n", maEleType[teDef->type], data));

  /* increment the data base pointer */

  ctlp->sTelDef++;
  teDef = *ctlp->sTelDef;

  while (teDef->type != MA_TET_SEQ_TERM)
  {
      if (seqLen == 0)
      {
        if (remEocFlg == TRUE)
        {
          /* remove the two EOC bytes */
          if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
          {
            ctlp->errCode = MAT_MISTYPE_PARAM;
            RETVALUE(ret);
          }
        }

        /* reached end of buffer - check for missing mand el */
        RETVALUE(maChkSeqMand(ctlp));
      }
      SFndLenMsg(ctlp->mBuf, &orgMsgLen);

      switch (teDef->type)
      {
        case MA_TET_U8:
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecSeq() failed, fail to get len byte from mBuf, token(%d).\n",teDef->type));
             RETVALUE(RFAILED);
          }
          ret = maDecOctet(ctlp,FALSE);
          
          break;
        case MA_TET_U8_ENUM:
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecSeq() failed, fail to get len byte from mBuf, token(%d).\n",teDef->type));
             RETVALUE(RFAILED);
          }

          ret = maDecOctet(ctlp,TRUE);

          break;
        case MA_TET_NULL:
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecSeq() failed, fail to get len byte from mBuf, token(%d).\n",teDef->type));
             RETVALUE(RFAILED);
          }
          ret = maDecNull(ctlp);
          break;
        case MA_TET_INT:
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecSeq() failed, fail to get len byte from mBuf, token(%d).\n",teDef->type));
             RETVALUE(RFAILED);
          }
          ret = maDecInt(ctlp);
          break;
        case MA_TET_STR:
        case MA_TET_STRS:
        case MA_TET_STRM:
        case MA_TET_STRE:
#ifdef XWEXT
        case MA_TET_STR4:
#endif
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecSeq() failed, fail to get len byte from mBuf, token(%d).\n",teDef->type));
             RETVALUE(RFAILED);
          }
          ret = maDecStr(ctlp);
          break;
        case MA_TET_STRUL:
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecSeq() failed, fail to get len byte from mBuf, token(%d).\n",teDef->type));
             RETVALUE(RFAILED);
          }
          ret = maDecStrUL(ctlp);
          break;
        case MA_TET_BITSTR:
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecSeq() failed, fail to get len byte from mBuf, token(%d).\n",teDef->type));
             RETVALUE(RFAILED);
          }
          ret = maDecBitStr(ctlp);
          break;
        case MA_TET_SEQ:
        case MA_TET_EXT_CONT:
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecSeq() failed, fail to get len byte from mBuf, token(%d).\n",teDef->type));
             RETVALUE(RFAILED);
          }
          if (tmpLen > seqLen)
          {
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecSeq() failed, invalid length value(%d), token(%d).\n", tmpLen,teDef->type));
             RETVALUE(RFAILED);
          }
          ret = maDecSeq(ctlp);
          break;
        case MA_TET_SEQ_OF:
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecSeq() failed, fail to get len byte from mBuf, token(%d).\n",teDef->type));
             RETVALUE(RFAILED);
          }
          ret = maDecSeqOf(ctlp);
          break;
        case MA_TET_CHOICE:
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecSeq() failed, fail to get len byte from mBuf, token(%d).\n",teDef->type));
             RETVALUE(RFAILED);
          }
          ret = maDecChoice(ctlp);
          break;
#ifdef MAP_PHASE2_EXT_MARK
        case MA_TET_EXT_MARK:
          if ((ctlp->maVer == LMA_VER2)  && 
                           (IS_EQUAL_VER2(teDef->verFlg)))
          {
            sStrE = (TknStrE *)ctlp->sSt;
            /* If the remaining length exceeds the length of TknStrE */
            if (seqLen > MF_SIZE_TKNSTRE)
               RETVALUE(RFAILED);

            if ((ret = SRemPreMsgMult((U8 *)&sStrE->val[0], seqLen, mBuf)) != ROK)
            {
                ctlp->errCode = MAT_MISTYPED_PARAM;
                RETVALUE(ret);
            }
/* ma005.203: Addition, Copy the length of Private extensions */
/*                      in Token length filed */
            sStrE->len = (U8)seqLen;  
            sStrE->pres = TRUE;
          }
          else
          {
               maSkipTkns(ctlp);
          }
          break;
          
#endif
        default:
#if (ERRCLASS & ERRCLS_DEBUG)
           MALOGERROR(ERRCLS_DEBUG, EMA301, (ErrVal)teDef->type, "maDecSeq () Failed");
#endif
           break;
      }
      if (ret != ROK)
      {
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maDecSeq() failed, decoding token(%d) fail.\n", teDef->type));
        RETVALUE(RFAILED);
      }
      SFndLenMsg(ctlp->mBuf,&newMsgLen);
      if (orgMsgLen != newMsgLen)
      {
         seqLen -= (orgMsgLen - newMsgLen);
      }
      teDef = *ctlp->sTelDef;
      if (seqLen < 0)
      {
         ctlp->errCode = MAT_MISTYPED_PARAM;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecSeq() failed, invalid new msg len(%d).\n", newMsgLen));
         RETVALUE(RFAILED);
      }
  }

  if ( (ctlp->maVer != LMA_VER1) && (seqLen > 0) )
  {
     /*
     ** Extended elements at the end of the sequence .
     ** So Ignore them without sending error indications.
     ** This is done only for phase-2 messages.
     */
     
     /* ma007.203 : Print the Extra Buffer */

#if (ERRCLASS & ERRCLS_DEBUG)
     SPrntMsg(ctlp->mBuf,0,0);
#endif 	
     /* remove the remaining elements from the sequence */
     while(seqLen > 0)
     {
        if ((ret = SRemPreMsg(&data, mBuf)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           RETVALUE(ret);
        }
        seqLen--;
     }
  }
 
  if ( (ctlp->maVer == LMA_VER1) && (seqLen > 0) )
  {
     /*
     ** Unknown elements at the end of the sequence .
     ** So send error indications.
     ** This is done only for phase-1 messages.
     */
 
     ctlp->errCode = MAT_MISTYPE_PARAM;
     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maDecSeq() failed, unknown el at the end of the seq.\n"));
     RETVALUE(RFAILED);
  }

  if (remEocFlg == TRUE)
  {
    /* remove the two EOC bytes */
    if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }
  }

  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
  "maDecSeq: decode Sequence  Successfully.\n"));
  ctlp->sTelDef++;
  RETVALUE(ROK);
} /* maDecSeq */



/*
*
*       Fun:   maDecSeqOf  
*
*       Desc:  This function decodes the repeatable sequence 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maDecSeqOf 
(
MaMsgCtl      *ctlp      /* message control pointer */
)
#else
PUBLIC S16 maDecSeqOf (ctlp)
MaMsgCtl      *ctlp;        /* message control pointer */
#endif
{
  MaTknElmtDef  *teDef;
  MaTknElmtDef  **stTelDef;
  Buffer        *mBuf;
  MsgLen        seqLen;
  MsgLen        msgLen;
  MsgLen        tmpLen;
  MsgLen        lfLen;
  Bool          remEocFlg;
  Data          data;
  U8            swtch;
  Bool          eocFlg;
  S32           cntr;       /* Counter */
  Data          unPkArray[MA_MAX_PKARRAY_LEN];
  MsgLen        orgMsgLen;
  MsgLen        newMsgLen;
  S16           ret;

  TRC2(maDecSeqOf)

  mBuf = ctlp->mBuf;
  teDef = *ctlp->sTelDef;
  cntr = teDef->repCntr;
  eocFlg = FALSE;
  swtch = (U8)ctlp->swtch;


  /* check if there is a user function */
  if (teDef->func)
  {
     ret = (*teDef->func)(ctlp);
     RETVALUE(ret);
  }
  if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
  {
    if (ret == ROKDNA)
    {
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make them as not present */
        maSkipSeqOf(ctlp);
        RETVALUE(ROK);
      }
    }
    else
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }
  }
  if (data != teDef->tag)
  {
    /* check whether Map versions are compatible */
    if ((ret = maChkEleMand(ctlp) == FALSE))
    {
      /* skip the element in the data base and make as not present in event str */
      maSkipSeqOf(ctlp);
      RETVALUE(ROK);
    }
    else
    {
       ctlp->errCode = MAT_DATA_MISSING;
       MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
       "maDecSeqOf() failed, mand. data tag dismatched.\n"));
       RETVALUE(RFAILED);
    }
  }
  else
  {
     if ( (ctlp->maVer == LMA_VER1  && !(IS_EQUAL_VER1(teDef->verFlg))) ||
       (ctlp->maVer == LMA_VER2  && !(IS_EQUAL_VER2(teDef->verFlg))) ||
       (ctlp->maVer == LMA_VER2P && !(IS_EQUAL_VER2P(teDef->verFlg)))||
       (ctlp->maVer == LMA_VER4  && !(IS_EQUAL_VER4(teDef->verFlg)))
        )
     {
        /*skip the elmnt in data base and make as not present in event str */
        maSkipSeqOf(ctlp);
        RETVALUE(ROK);
     }

  }

  /* Find the length of sequence */

  if ((ret = maFindLen(mBuf,0,&seqLen,&eocFlg, &lfLen)) != ROK)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    RETVALUE(ret);
  }
 
  (Void)SFndLenMsg (mBuf, &msgLen);

  if (msgLen < seqLen)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maDecSeqOf() failed, invalid msgLen(%d) and seqLen(%d).\n", msgLen, seqLen));
    RETVALUE(RFAILED);
  }

  #ifndef ALIGN_64BIT

  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecSeqOf: Decoding Sequence Of ......\n \
          %s Tag [%x] Len [%x] Counter %ld \n",
          maEleType[teDef->type], data, seqLen, cntr));

  #else

  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecSeqOf: Decoding Sequence Of ......\n \
          %s Tag [%x] Len [%x] Counter %d \n",
          maEleType[teDef->type], data, seqLen, cntr));

  #endif /* ALIGN_64BIT */
  /* decode the sequence */
  (Void)SRemPreMsg(&data, mBuf); 

  /* remove the length byte */

  if ((ret = maRemLen(mBuf, &remEocFlg)) != ROK)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    RETVALUE(ret);
  }
  /* ma002.203: If tag and len are pres and seqLen is 0, check if any of its
  elements is mandatory. If so, return failure otherwise, return ROK ***/

#ifdef MA_ASN_DEC_SEQ
  if (seqLen == 0)
  {
      ctlp->sTelDef++;
      if((ret = maChkSeqMand(ctlp)) == ROK)
      {
         if (remEocFlg == TRUE)
         {
            /* remove the two EOC bytes */
            if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
            {
               ctlp->errCode = MAT_MISTYPE_PARAM;
               RETVALUE(ret);
            }
         }
         RETVALUE(ROK);
      }
      ctlp->errCode = MAT_DATA_MISSING;
      MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
      "maDecSeqOf() failed, Len 0 and mand. data missing.\n"));
      RETVALUE(RFAILED);
  }
#endif /* MA_ASN_DEC_SEQ */

  ctlp->sTelDef++;
  stTelDef = ctlp->sTelDef;
  while (cntr)
  {
    ctlp->sTelDef = stTelDef;
    teDef = *ctlp->sTelDef;
    SFndLenMsg(ctlp->mBuf, &orgMsgLen);
    if (seqLen == 0)
    {
       if ( (ret = maChkEleMand(ctlp)) != ROK)
       {
         if (msgLen == orgMsgLen)
         {
            ctlp->errCode = MAT_DATA_MISSING;
            MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
            "maDecSeqOf() failed, mand. data missing.\n"));
            RETVALUE(RFAILED);
         }
       }
       break;
    }
    switch (teDef->type)
    {
      case MA_TET_U8:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecSeqOf() failed at token(%d).\n",teDef->type));
           ctlp->errCode = MAT_MISTYPE_PARAM;
           RETVALUE(ret);
        }
        ret = maDecOctet(ctlp,FALSE);
        break;
      case MA_TET_U8_ENUM:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecSeqOf() failed at token(%d).\n",teDef->type));
           ctlp->errCode = MAT_MISTYPE_PARAM;
           RETVALUE(ret);
        }
        ret = maDecOctet(ctlp,TRUE);
        break;
      case MA_TET_NULL:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecSeqOf() failed at token(%d).\n",teDef->type));
           ctlp->errCode = MAT_MISTYPE_PARAM;
           RETVALUE(ret);
        }
        ret = maDecNull(ctlp);
        break;
        case MA_TET_INT:
          if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPE_PARAM;
             RETVALUE(ret);
          }
          ret = maDecInt(ctlp);
          break;
      case MA_TET_STR:
      case MA_TET_STRS:
      case MA_TET_STRM:
      case MA_TET_STRE:
#ifdef XWEXT
      case MA_TET_STR4:
#endif
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecSeqOf() failed at token(%d).\n",teDef->type));
           ctlp->errCode = MAT_MISTYPE_PARAM;
           RETVALUE(ret);
        }
        ret = maDecStr(ctlp);
        break;
      case MA_TET_STRUL:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecSeqOf() failed at token(%d).\n",teDef->type));
           ctlp->errCode = MAT_MISTYPE_PARAM;
           RETVALUE(ret);
        }
        ret = maDecStrUL(ctlp);
        break;
      case MA_TET_BITSTR:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecSeqOf() failed at token(%d).\n",teDef->type));
           RETVALUE(ret);
        }
        ret = maDecBitStr(ctlp);
        break;
      case MA_TET_SEQ:
      case MA_TET_EXT_CONT:
        if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPED_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecSeqOf() failed at token(%d).\n", teDef->type));
           RETVALUE(ret);
        }
        ret = maDecSeq(ctlp);
        break;
      case MA_TET_SEQ_OF:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecSeqOf() failed at token(%d).\n", teDef->type));
           RETVALUE(ret);
        }
        ret = maDecSeqOf(ctlp);
        break;
      case MA_TET_CHOICE:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecSeqOf() failed at token(%d).\n", teDef->type));
           RETVALUE(ret);
        }
        ret = maDecChoice(ctlp);
        break;
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
        MALOGERROR(ERRCLS_DEBUG, EMA302, (ErrVal)teDef->type, "maDecSeqOf () Failed");
#endif
         break;
    }
    if (ret != ROK)
    {
       MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
       "maDecSeqOf() failed, fail at decoding token(%d).\n", teDef->type));
       RETVALUE(RFAILED);
    }
    SFndLenMsg(ctlp->mBuf, &newMsgLen);
    if (orgMsgLen != newMsgLen)
    {
       seqLen -= orgMsgLen - newMsgLen;
    }
    cntr--;
  }
  while(cntr)
  {
    ctlp->sTelDef = stTelDef;
    maSkipTkns(ctlp);
    cntr--;
  }
  if (remEocFlg == TRUE)
  {
    /* remove the two EOC bytes */
    if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPE_PARAM;
       MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
       "maDecSeqOf() failed, fail to remove EOC bytes.\n"));
       RETVALUE(RFAILED);
    }
  }

  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecSeqOf: decode Sequence Of Successfully.\n"));

  /* skip the End of Seq Of pointer */
  ctlp->sTelDef++;
  RETVALUE(ROK);
} /* end of MaDecSeqOf */


/*
 *
 *      Fun:   maChkEnum
 *
 *      Desc:  tries to locate specified value in specified enumerated list.
 *
 *      Ret:   ROK          - value found in enumerated list
 *             RFAILED      - value not found in enumerated list
 *
 *      Notes: None
 *
        File:  ca_mf.c
 *
 */
 
#ifdef ANSI
PRIVATE S16 maChkEnum
(
U8 val,                    /* value */
MaTknElmtDef *teDef,        /* token definition */
Swtch swtch                 /* switch */
)
#else
PRIVATE S16 maChkEnum(val, teDef, swtch)
U8 val;                    /* value */
MaTknElmtDef *teDef;        /* token definition */
Swtch swtch;                /* switch */
#endif
{
   MaTknEnum *elist;   /* enumerated list */
   U32 count;          /* number of elements in enumerated list */
   U32 i;              /* counter */

   TRC2(maChkEnum)

   /* locate pointer to enumnerated list */
   elist = teDef->elist[0];
#if (ERRCLASS & ERRCLS_DEBUG)

   if (!elist)
   {
      MALOGERROR(ERRCLS_DEBUG, EMA303, (ErrVal)0, "maChkEnumVal () Failed");
   }
#endif

   /* locate number of entries in enumerated list */
   count = elist[0];

   /* try to find a match for value in enumerated list */
   for (i = 1; i <= count; i++)
      if (val == elist[i])
         RETVALUE(ROK);

   MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
   "maChkEnum() failed, cannot find the value(%d) in enumerated list.\n", val));
   RETVALUE(RFAILED);
} /* end of maChkEnum */



/*
*
*       Fun:   maEncInt   
*
*       Desc:  This function encodes an Integer 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maEncInt 
(
MaMsgCtl  *ctlp         /* message control pointer */
)
#else
PUBLIC S16 maEncInt (ctlp)
MaMsgCtl  *ctlp;        /* message control pointer */
#endif
{
  MaTknElmtDef *teDef;
  TknStrS    *strS;   /* token string size - small */
  U8         len;
  MsgLen     tmpLen;
  U8         *val;
  S16        ret;
  U8         i;
  Data       pkArray[MA_MAX_PKARRAY_LEN];
  U32        value;

  TRC2(maEncInt)

  teDef = *ctlp->sTelDef;

  MA_UPD_MAND_FLG

  /* check element for protocol type and mandatory/optional flags */
  if ((ret = maChkEncElmnt(ctlp)) != ROK)
  {
     if (ret == RSKIP)
     {
        RETVALUE(ROK);
     }
     RETVALUE(ret);
  }
  strS = (TknStrS *)ctlp->sSt;
  len = strS->len;
  val = &strS->val[0];

  for(i=0;i<(len-1);i++)
  {
     /* 
     ** If the first octet is all zero and Most Significant Bit 
     ** of the next octet is zero then we can drop the first 
     ** octet from the encoding . This results in smallest number
     ** of octets.
     */
     if ( (val[i] == 0x00 ) && ((val[i+1] & 0x80) == 0x00) )
     {
        continue;
     }
     /* 
     ** If the first octet is all ones and Most Significant Bit 
     ** of the next octet is one then we can drop the first 
     ** octet from the encoding . This results in smallest number
     ** of octets.
     */
     if ( (val[i] == 0xff ) && ((val[i+1] & 0x80) == 0x80) )
     {
        continue;
     }
     break;
  }

  /* 
  ** If the number of octets is > 4, then return failure 
  */

  if ((len - i) > 4  || (len - i) < 1)
  {
     MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
     "maEncInt() failed, invalid integer length(%d).\n", len));
     RETVALUE(RFAILED);
  }
  
  /* bump structure pointer in message control */
  MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 

  value = 0;

  value = val[len-1];

  if ( (len - i) > 1)
  {
     value |= (val[len-2] << 8);
  }

  if ( (len - i) > 2)
  {
     value |= (val[len-3] << 16);
  }

  if ( (len - i) > 3)
  {
     value |= (val[len-4] << 24);
  }


  if ( (value < teDef->minLen) || (value >teDef->maxLen))
  {
#ifndef ALIGN_64BIT

     MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
     "maEncInt() failed, Tag [%x] invalid integer length(%ld).\n", teDef->tag, value));
     RETVALUE(RFAILED);

#else

     MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
     "maEncInt() failed, Tag [%x] invalid integer length(%d).\n", teDef->tag, value));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }

  pkArray[0] = teDef->tag;
  pkArray[1] = len;
  tmpLen = 2;
  /* encode the value  */ 
  for ( ;i<len; i++,tmpLen++)
  {
    pkArray[tmpLen] = val[i];
  }
  ret = SAddPstMsgMult(pkArray, tmpLen, ctlp->mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
  if (ret != ROK)
  {
     MALOGERROR(ERRCLS_ADD_RES, EMA304, (ErrVal)ret, "SAddPstMsgMult() Failed");
     RETVALUE(ret);
  }
#endif

  MA_UPD_OFFSET_ARRAY

  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maEncInt: %s Tag [%x] Len [%x] Val [%x]... \n", 
          maEleType[teDef->type], pkArray[0], pkArray[1], pkArray[2]));

  ctlp->sTelDef++;
  RETVALUE(ROK);
} /* maEncInt */



/*
*
*       Fun:    maDecInt 
*
*       Desc:  This function decodes an integer.     
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maDecInt 
(
MaMsgCtl    *ctlp       /* message control pointer */
)
#else
PUBLIC S16 maDecInt (ctlp)
MaMsgCtl    *ctlp;      /* message control pointer */
#endif
{
  MaTknElmtDef  *teDef;
  Data          data;
  Buffer        *mBuf;
  TknStrS       *sStrS;
  U16           ret;
  Bool          eocFlg;
  MsgLen        lfLen;
  MsgLen        len;
  U32           value;

  TRC2(maDecInt)

  teDef = *ctlp->sTelDef;
  mBuf  = ctlp->mBuf;

  if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    RETVALUE(ret);
  }

  if (data != teDef->tag)
  {
    if ((ret = maChkEleMand(ctlp) == FALSE))
    {
      /*skip the element in the data base and make as not present in 
        event str */
      ctlp->sTelDef++;
      /* bump structure pointer in message control */
#ifndef MA_MULT_SEG_DECODE
      ((TknStrS *)(ctlp->sSt))->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */ 
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
      RETVALUE(ROK);
    }
    else
    {
       ctlp->errCode = MAT_DATA_MISSING;
       MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
       "maDecInt() failed, mand. data missing.\n"));
       RETVALUE(RFAILED);
    }
  }


  /* tag is in first position and always 8 bit */
  if ((ret = SExamMsg(&data, mBuf, 1)) != ROK)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    RETVALUE(ret);
  }
 
  if (!(data & 0x80))
  {
     eocFlg = FALSE;
  }
  else if (data == 0x80)
  {
    eocFlg = TRUE;
  }
  else
  {
     /* this function is used to decode only 4 byte integers.
      * so in most cases the length will be encoded in short form. But
      * it is valid to encode using the indefinate form. But long form
      * definate encoding can't be used as it will not satisfy the the
      * condition of using minimum bytes to encode the length. */
     ctlp->errCode = MAT_MISTYPE_PARAM;
     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maDecInt() failed, mistype param(%d).\n", data));
     RETVALUE(RFAILED);
  }

  if ((ret = SExamMsg(&data, mBuf, 2)) != ROK)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    RETVALUE(ret);
  }

  if ((ret = maFindLen(mBuf,0,&len,&eocFlg, &lfLen)) != ROK)
  {
     ctlp->errCode = MAT_MISTYPE_PARAM;
     RETVALUE(ret);
  }

  if(len < 1 || len > 4)
  {
     ctlp->errCode = MAT_MISTYPE_PARAM;
     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maDecInt() failed, Tag [%x] invalid len(%d).\n",teDef->tag, len));
     RETVALUE(RFAILED);
  }



  sStrS = (TknStrS *)ctlp->sSt;
  sStrS->pres = TRUE;
  sStrS->len = (U8)len;
  if ((ret = SRemPreMsgMult((Data *)sStrS->val, (MsgLen)2, mBuf)) != ROK)
  {
     ctlp->errCode = MAT_MISTYPE_PARAM;
     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maDecInt() failed, mistype param.\n"));
     RETVALUE(RFAILED);
  }
  if ((ret = SRemPreMsgMult((Data *)sStrS->val, (MsgLen)len, mBuf)) != ROK)
  {
     ctlp->errCode = MAT_MISTYPE_PARAM;
     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maDecInt() failed, mistype param.\n"));
     RETVALUE(RFAILED);
  }

  value = 0;

  value = sStrS->val[len-1];

  if ( (len ) > 1)
  {
     value |= (sStrS->val[len-2] << 8);
  }

  if ( (len ) > 2)
  {
     value |= (sStrS->val[len-3] << 16);
  }

  if ( (len ) > 3)
  {
     value |= (sStrS->val[len-4] << 24);
  }

  if ( (value < teDef->minLen) || (value >teDef->maxLen))
  {
     ctlp->errCode = MAT_UNX_DATA_VALUE;
#ifndef ALIGN_64BIT

     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maDecInt() failed, Tag [%x] invalid length(%ld).\n",teDef->tag, value));
     RETVALUE(RFAILED);

#else

     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maDecInt() failed, Tag [%x] invalid length(%d).\n", teDef->tag, value));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }

  if (eocFlg == TRUE)
  {
    /* remove the two EOC tag byets */
 
    if ((ret = SRemPreMsg(&data, mBuf)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if ((ret = SRemPreMsg(&data, mBuf)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }
  }

  #ifndef ALIGN_64BIT

  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
  "maDecInt: %s Tag [%x] Len [%x] Val [%ld] \n", 
  maEleType[teDef->type], teDef->tag, len, value));

  #else

  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
  "maDecInt: %s Tag [%x] Len [%x] Val [%d] \n", 
  maEleType[teDef->type], teDef->tag, len, value));

  #endif /* ALIGN_64BIT */

  MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
  ctlp->sTelDef++;
  RETVALUE(ROK);

} /* maDecInt */


/*
*
*       Fun:   maEncTagChoice
*
*       Desc:  This function encodes the Choice of tokens 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maEncTagChoice 
(
MaMsgCtl    *ctlp       /* message control pointer */
)
#else
PUBLIC S16 maEncTagChoice(ctlp)
MaMsgCtl    *ctlp;      /* message control pointer */
#endif
{
  MaTknElmtDef  *teDef;      /* element definition */
  MaTknElmtDef  **tmpDef;    /* temporory element definition */
  TknU8         *tmpSst;     /* temporary pointer */
  TknU8         *tSt;        /* token pointer */
  S16           ret;         /* return value */
  U8            elmntIdx;    /* element Index */
  Data          pkArray[MA_MAX_PKARRAY_LEN];
  S16           seqMand;
  MsgLen        orgLen;
  MsgLen        curLen;
  U16           i;         /* counter */

  TRC2(maEncTagChoice)

  tmpDef = ctlp->sTelDef;       /* Store the element definition */
  tmpSst = (TknU8 *) ctlp->sSt; /* Store the token pointer */


  teDef = *ctlp->sTelDef;
  tSt    = (TknU8 *) ctlp->sSt; /* Get the token pointer */

  /* check element for protocol type and mandatory/optional flags */
  if ((ret = maChkEncElmnt(ctlp)) != ROK)
  {
     if (ret == RSKIP)
     {
        RETVALUE(ROK);
     }
     RETVALUE(ret);
  }

  /* encode the choice tag and EOC length tag */
  pkArray[0] = teDef->tag;
  pkArray[1] = (Data)MA_EOC_LEN;
 
  ret = SAddPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
  if (ret != ROK)
  {
     MALOGERROR(ERRCLS_ADD_RES, EMA305,(ErrVal)ret,"SAddPstMsgMult() Failed");
     RETVALUE(ret);
  }
#endif
 
   MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maTagChoice: Encoding Tagged Choice ...... \n \
          %s Tag [%x] Len [%x]\n",
          maEleType[teDef->type], pkArray[0], pkArray[1]));

   seqMand = maChkEleMand(ctlp);

  /* get the element index */
  elmntIdx = tSt->val;

 /* increment the event structure over present token */
  MA_BUMP_STP((PTR *) &ctlp->sSt, (U32) sizeof(TknU8));
  tSt = (TknU8 *) ctlp->sSt;

  /* increment the token pointer over the start of choice*/
  ctlp->sTelDef++;
  teDef = *ctlp->sTelDef;

  /* initialize the counter */
  i = 1;

  /* skip n elements in the database */
  while((i<elmntIdx) && (teDef->type != MA_TET_SEQ_TERM))
  {
     /* skip the element */
     maSkipTkns(ctlp);

     /* restore the event structure pointer */
     ctlp->sSt = (U8 *)tSt; 

     /* Update the element definition */
     teDef = *ctlp->sTelDef;

     /* Increment the counter */
     i++;
  }
 
  if(teDef->type == MA_TET_SEQ_TERM)
  {
     /* reached the end of choice error */
     ctlp->errCode = MAT_MISTYPE_PARAM;
     MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
     "maEncTagChoice() failed, invalid tag(%d).\n", teDef->type));
     RETVALUE(RFAILED);
  }

  SFndLenMsg(ctlp->mBuf, &orgLen);
     
  MA_INCREASE_LEVEL;
  /* Now Start encoding the tokens */
  switch(teDef->type)
  {
     case MA_TET_U8:
       ret = maEncOctet(ctlp,FALSE);
       break;
     case MA_TET_U8_ENUM:
       ret = maEncOctet(ctlp,TRUE);
       break;
     case MA_TET_NULL:
       ret = maEncNull(ctlp);
       break;
     case MA_TET_INT:
       ret = maEncInt(ctlp);
       break;
     case MA_TET_STR:
     case MA_TET_STRS:
     case MA_TET_STRM:
     case MA_TET_STRE:
#ifdef XWEXT
     case MA_TET_STR4:
#endif
       ret = maEncStr(ctlp);
       break;
     case MA_TET_STRUL:
       ret = maEncStrUL(ctlp);
       break;
     case MA_TET_BITSTR:
       ret = maEncBitStr(ctlp);
       break;
     case MA_TET_SEQ:
     case MA_TET_EXT_CONT:
       ret = maEncSeq(ctlp);
       break;
     case MA_TET_SEQ_OF:
       ret = maEncSeqOf(ctlp,teDef->repCntr, ctlp->sTelDef);
       break;
     case MA_TET_CHOICE:
       ret = maEncChoice(ctlp);
       break;
  }
  MA_DECREASE_LEVEL;
  SFndLenMsg(ctlp->mBuf, &curLen);
  if ((ret != ROK) &&(ret != EMP_SEQ) && (ret != NON_EMP_SEQ))
  {
        if ( ctlp->errCode == MAT_DATA_MISSING)
        {
           if (orgLen == curLen)
           {
              ctlp->sTelDef = tmpDef;
              ctlp->sSt = (U8 *)tmpSst;
              maSkipTkns(ctlp);
              /* strip of the added tag and length before returning */
              SRemPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
              if (seqMand == FALSE)
              {
                 RETVALUE(ROK);
              }
              else
              {
                 MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
                 "maEncTagChoice() failed,mand. data missing.\n")); 
                 RETVALUE(RFAILED);
              }
           }
           else
           {
              ctlp->sTelDef = tmpDef;
              ctlp->sSt = (U8 *)tmpSst;
              maSkipTkns(ctlp);
 
              /* Strip off the encoded bytes */
              for (i=0; i< (curLen - orgLen); i++)
              {
                SRemPstMsg(pkArray, ctlp->mBuf);
              }
              /* strip of the added tag and length before returning */
              SRemPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
 
              MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
              "maEncTagChoice() failed, mand. data missing.\n")); 
              RETVALUE(RFAILED);
           }
        }
        else
        {
           ctlp->sTelDef = tmpDef;
           ctlp->sSt = (U8 *)tmpSst;
           maSkipTkns(ctlp);
           /* strip of the added tag and length before returning */
           SRemPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
           MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
           "maEncTagChoice() failed, encoding type(%d) failed.\n",teDef->type));  
           RETVALUE(RFAILED);
        }

  }
  else 
  {
     if ((orgLen == curLen) && (seqMand == FALSE))
     {
       SRemPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
       ctlp->sTelDef++;
       RETVALUE(ROK);
     }
#ifdef MA_ASN_NO_INDEF_LEN
     MA_ENC_DEF_LEN(curLen, orgLen)
#else /* MA_ASN_NO_INDEF_LEN */
     /* Encode the TWo EOC tag to indicate end of sequence */
     pkArray[0] = MA_TAG_EOC;
     pkArray[1] = MA_TAG_EOC;
 
     ret = SAddPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
 
#if (ERRCLASS & ERRCLS_ADD_RES)
     if (ret != ROK)
     {
        MALOGERROR(ERRCLS_ADD_RES, EMA306, (ErrVal)ret, "SAddPstMsgMult() Failed");
        RETVALUE(ret);
     }
#endif
#endif /* MA_ASN_NO_INDEF_LEN */

  }

  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
        "maEncTagChoice: Encoding Choice Successfully.\n"));

  /* restore the element definition pointer to start of choice */
  ctlp->sTelDef = tmpDef;
 
  /* restore the token pointer to the start of the choice */
  ctlp->sSt     = (U8 *)tmpSst;
 
  /* Now skip the entire choice */
  maSkipTkns(ctlp);

  RETVALUE(ROK);
} /* maEncTagChoice */


/*
*
*       Fun:    maDecTagChoice 
*
*       Desc:  This function decodes the Choice element 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maDecTagChoice 
(
MaMsgCtl   *ctlp        /* message control pointer */
)
#else
PUBLIC S16 maDecTagChoice (ctlp )
MaMsgCtl   *ctlp;       /* message control pointer */
#endif
{
   MaTknElmtDef  *teDef;       /* element definition */
   MaTknElmtDef **tmpDef;      /* element definition */
   MaTknElmtDef **tmpDefn;     /* element definition */
   Bool           multChoice;  /* multiple Choice flag */
   Bool           eocFlg;      /* EOC flag */
   Bool           remEocFlg;   /* remove EOC flag */
   S16            ret;         /* return value */
   U8             tagSize;     /* Size of the tag */
   TknU8         *tSt;         /* Token Pointer */  
   TknU8         *tmpSSt;      /* Token pointer  */
   TknU8         *tmpPtr;      /* Temporary pointer to the token pointer */
   Bool           skipElmnt;   /* need to skip the element */
   MsgLen         choiceLen;   /* Length of the choice */
   MsgLen         lfLen;       /* length of length */
   Buffer        *mBuf;        /* message buffer */
   U16            j;           /* element counter */
   Data           pkArray[MA_MAX_PKARRAY_LEN];
   Data           data;        /* data */

   TRC2(maDecTagChoice)

   multChoice = FALSE;
   teDef      = *ctlp->sTelDef;
   mBuf       = ctlp->mBuf;
   eocFlg     = FALSE;

   (Void) SExamMsg(&data,mBuf,0);
   if(data != teDef->tag)
   {

      /* check if this element is defined for this protocol */
      if (( ret = maChkEleMand(ctlp)) == FALSE)
      {
         /* this element is not defined for this protocol , skip it */
         maSkipTkns(ctlp);
         ctlp->choiceRes = RFAILED;
         RETVALUE(ROK);
      }
      else 
      {
         ctlp->choiceRes = RFAILED; 
         ctlp->errCode   = MA_MAND_MISS;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecTagChoice() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
   }


   /* Check the message length */
   ret = maFindLen(ctlp->mBuf,0,&choiceLen,&eocFlg,&lfLen);
   if(ret != ROK)
   {
      ctlp->errCode   = MAT_MISTYPED_PARAM;
      ctlp->choiceRes = RFAILED;
      MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
      "maDecTagChoice() failed, fail to get msg length.\n"));  
      RETVALUE(RFAILED);
   }

   (Void) SRemPreMsg(&data,mBuf);
   ret = maRemLen(mBuf,&remEocFlg);
   if(ret != ROK)
   {
      ctlp->errCode = MAT_MISTYPED_PARAM;
      ctlp->choiceRes = RFAILED;
      MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
      "maDecTagChoice() failed, fail to get len.\n"));  
      RETVALUE(RFAILED);
   }

   if (choiceLen == 0)
   {
      if (maChkEleMand(ctlp) == TRUE)
      {
         /* element is mandatory, cannot be skipped */
         ctlp->errCode = MA_MAND_MISS;
         ctlp->choiceRes = RFAILED;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecTagChoice() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
      else
      {
         /* element is not mandatory, can be skipped */
         maSkipTkns(ctlp);
         if (remEocFlg == TRUE)
         {
            /* remove the two EOC bytes */
            if ((ret = SRemPreMsgMult(pkArray, (MsgLen)2, mBuf)) != ROK)
            {
               ctlp->errCode = MAT_MISTYPE_PARAM;
               RETVALUE(ret);
            }
         }
         ctlp->choiceRes = RFAILED;
         RETVALUE(ROK);
      }
   } 

   MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
          "maDecTagChoice: Decoding Tagged Choice ...... \n \
           %s Tag [%x] \n", maEleType[teDef->type], data));

   skipElmnt  = FALSE;                 /* do not skip the element */
   tmpDef     = ctlp->sTelDef;         /* Store the elmnt defn pointer */
   tmpSSt     = (TknU8 *) ctlp->sSt;   /* Store the Token Pointer */
   tSt        = (TknU8 *) ctlp->sSt;   /* Get the Token Pointer */

   /* increment over the start of choice */
   ctlp->sTelDef ++;

  /* Get the element definition of the first element */
  teDef = *ctlp->sTelDef; 

  /* skip over the choice type token */
  MA_BUMP_STP( (PTR *) &ctlp->sSt , (U32) sizeof(TknU8));

  /* initialize the element count */
  j=1;

  /* Get and Check the tag, do not strip the tag bytes */
  if ((ret = maGetTag(ctlp, pkArray,0, &tagSize)) == RFAILED)
  {
     ctlp->errCode = MAT_MISTYPE_PARAM;
     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maDecTagChoice() failed, failed to get tag.\n"));  
     RETVALUE(RFAILED);
  }
  while(teDef->type != MA_TET_SEQ_TERM)
  {
     if(teDef->type == MA_TET_CHOICE && maChkEleFlag(ctlp) == TRUE)
     {
        tmpPtr = (TknU8 *) ctlp->sSt;
        tmpDefn = ctlp->sTelDef;

        multChoice = TRUE;
        ctlp->choiceRes=RFAILED;
        maDecChoice(ctlp);
        if (ctlp->choiceRes == ROK)
        {
           break;
        }
        multChoice = FALSE;

        ctlp->sTelDef = tmpDefn;
        ctlp->sSt     = (U8 *)tmpPtr;
        maSkipTkns(ctlp);
        teDef = *ctlp->sTelDef;
        ctlp->sSt = (U8 *)tmpPtr;
       

        j++;
        continue;
     }
     else 
     /* check the tag against the data base definition of the element */
     if ((maChkEleFlag(ctlp) == FALSE) || 
         (maChkTag(ctlp, pkArray, tagSize, &skipElmnt) == RFAILED))
     {
         /* store the event structutre pointer. this is required
            because for decoding each element of the choice we need
            to make sure that we start from the start of the event
            structure pointer */
 
         tmpPtr = (TknU8 *) ctlp->sSt;
 
         /* tag defintions don't match, continue till we find one */
         maSkipTkns(ctlp);
         teDef = *ctlp->sTelDef;

         /* restore the pointer */
         ctlp->sSt = (U8 *) tmpPtr;
 
         j++;
         continue;

     }
     else
     {
        /* found the element, break out of the while loop */
        break;
     }
     
  } /* end while */

  if (teDef->type == MA_TET_SEQ_TERM)
  {
      /* did not find a match, unknown element */
 
      /* indicate that the choice is not present */
#ifndef MA_MULT_SEG_DECODE
      tmpSSt->pres = FALSE;                         /* choice present */
      tmpSSt->val  = 0;                             /* element index */
#endif /* MA_MULT_SEG_DECODE */
 
      /* Restore the pointers to the start of choice */
      ctlp->sTelDef = tmpDef;
      ctlp->sSt     = (U8 *)tmpSSt;
 
      /* Check if element is mandatory */
      if (maChkEleMand(ctlp) == TRUE)
      {
         /* element is mandatory, cannot be skipped */
         ctlp->errCode = MA_MAND_MISS;                      
         ctlp->choiceRes = RFAILED;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecTagChoice() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
      else
      {
         /* element is not mandatory, can be skipped */
         maSkipTkns(ctlp);
         ctlp->choiceRes = RFAILED;
         RETVALUE(ROK);
      }
   }
   else
   {
      /* make the element as present in the event structure */
 
      tmpSSt->pres = TRUE;                          /* choice present */
      tmpSSt->val  = (U8) j;                        /* element index */
   }

   /* decode the element depending on the element type */
   if ( multChoice == FALSE && ((ret = maDecTknElmnt(ctlp)) != ROK))
   {
      /* error code already filled, don't do it again */
      MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
      "maDecTagChoice() failed, fail to decode el.\n"));  
      RETVALUE(RFAILED);
   }


   if ((multChoice == FALSE) && (remEocFlg == TRUE))
   {
      /* remove the two EOC bytes */
      if ((ret = SRemPreMsgMult(pkArray, (MsgLen)2, mBuf)) != ROK)
      {
         ctlp->errCode   = MAT_MISTYPE_PARAM;
         ctlp->choiceRes = RFAILED;
         RETVALUE(ret);
      }
   }

   MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
          "maDecTagChoice: Decoding Tagged Choice Successfully.\n"));
 
   /* restore the element defintion to choice start */
   ctlp->sTelDef = tmpDef;
 
   /* restore the event structure */
   ctlp->sSt = (U8 *)tmpSSt;
 
   /* now skip over the set */
   maSkipTkns(ctlp);
 
   ctlp->choiceRes = ROK;
   RETVALUE(ROK);
 
 

} /* maDecTagChoice */


/*
*
*       Fun:   maEncStrUL   
*
*       Desc:  This function encodes an extra large octet string 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maEncStrUL 
(
MaMsgCtl  *ctlp         /* message control pointer */
)
#else
PUBLIC S16 maEncStrUL (ctlp)
MaMsgCtl  *ctlp;        /* message control pointer */
#endif
{
  MaTknElmtDef *teDef;
  MaTknStrUL   *strUL;  /* token string size - extra large */
  U32        len;       /* Length of element */
  U32        tmpStrLen; /* temp element length */
  MsgLen     tmpLen;    /* temp counter used to encoded message length */
  U16        numBytes;  /* number of bytes used to encode element length */
  U8         *val;
  S16        ret;
  U32        i;
  Data       pkArray[MA_MAX_PKARRAY_LEN];

  TRC2(maEncStrUL)

  teDef = *ctlp->sTelDef;

  MA_UPD_MAND_FLG

  /* check element for protocol type and mandatory/optional flags */
  if ((ret = maChkEncElmnt(ctlp)) != ROK)
  {
     if (ret == RSKIP)
     {
        RETVALUE(ROK);
     }
     RETVALUE(ret);
  }

  strUL = (MaTknStrUL *)ctlp->sSt;
  len = strUL->len;
  val = &strUL->val[0];
  /* bump structure pointer in message control */
  MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(MaTknStrUL)); 

  pkArray[0] = teDef->tag;

  /* validate the length */
  
  if ( (len < teDef->minLen) || (len >teDef->maxLen))
  {
     #ifndef ALIGN_64BIT

     MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
     "maEncStrUL() failed, invalid len(%ld).\n", len));  
     RETVALUE(RFAILED);

     #else

     MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
     "maEncStrUL() failed, invalid len(%d).\n", len));  
     RETVALUE(RFAILED);

     #endif /* ALIGN_64BIT */
  }

  /* encode the length */
  if (len < 128)
  {
    pkArray[1] = (Data)len;
    tmpLen = 2;
  }
  else 
  {
    /* length will not fit in one byte */

    tmpStrLen = len;                /* store the length */ 
    i = 0;                          /* initialize the loop counter */

    /* find the number bytes to encode in length */
    while (tmpStrLen != 0)
    {
       tmpStrLen = (tmpStrLen >> 8);
       i++; 
    }

    numBytes = (i+1);   /* indicate number of bytes, include 1st byte also */
    tmpStrLen = len;    /* store the length */ 

    /* encode the length now. The first byte contains the EOC_FLAG
       and the number of bytes in the length field */

    /* Check we should include the first byte here or not */

    pkArray[1] = (MA_EOC_LEN | i);

    for (; i > 0; i--)
    {
       pkArray[i+1] = (tmpStrLen & 0xff);      /* copy the LSB */
       tmpStrLen = (tmpStrLen >> 8);           /* shift out the LSB */
    }


    tmpLen = numBytes + 1;
  }
  ret = SAddPstMsgMult(pkArray, (MsgLen)(tmpLen), ctlp->mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
  if (ret != ROK)
  {
     MALOGERROR(ERRCLS_ADD_RES, EMA307, (ErrVal)ret, "SAddPstMsgMult() Failed");
     RETVALUE(ret);
  }
#endif

  /* encode the value  */ 
  for (i=0; i<len; i++, val++)
  {
    pkArray[(i%MA_MAX_PKARRAY_LEN)] = *val;
    if((i%MA_MAX_PKARRAY_LEN) == (MA_MAX_PKARRAY_LEN-1))
    {
       ret = SAddPstMsgMult(pkArray, (MsgLen)(MA_MAX_PKARRAY_LEN), ctlp->mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
       if (ret != ROK)
       {
          MALOGERROR(ERRCLS_ADD_RES, EMA308, (ErrVal)ret, 
                      "SAddPstMsgMult() Failed");
          RETVALUE(ret);
       }
#endif
    }
  }
  if(i%MA_MAX_PKARRAY_LEN)
  {
     ret = SAddPstMsgMult(pkArray, (MsgLen)(i%MA_MAX_PKARRAY_LEN), ctlp->mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
     if (ret != ROK)
     {
        MALOGERROR(ERRCLS_ADD_RES, EMA309, (ErrVal)ret, 
                    "SAddPstMsgMult() Failed");
        RETVALUE(ret);
     }
#endif
  }
  MA_UPD_OFFSET_ARRAY

  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maEncStrUL: %s Tag [%x] Len [%x][%x] \n", 
          maEleType[teDef->type], pkArray[0], pkArray[1], pkArray[2]));

  ctlp->sTelDef++;
  RETVALUE(ROK);
} /* maEncStrUL */


/*
*
*       Fun:    maDecStrUL 
*
*       Desc:  This function decodes a string value  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maDecStrUL 
(
MaMsgCtl    *ctlp       /* message control pointer */
)
#else
PUBLIC S16 maDecStrUL (ctlp)
MaMsgCtl    *ctlp;      /* message control pointer */
#endif
{
  MaTknElmtDef  *teDef;
  Data          data;
  Buffer        *mBuf;
  MaTknStrUL    *sStrUL;
  U16           ret;

  TRC2(maDecStrUL)

  teDef = *ctlp->sTelDef;
  mBuf  = ctlp->mBuf;

  if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    RETVALUE(ret);
  }
  if (data != teDef->tag)
  {
    if ((ret = maChkEleMand(ctlp) == FALSE))
    {
      /* skip the element in the data base and make as not present in event str */
      ctlp->sTelDef++;

      /* bump structure pointer in message control */
#ifndef MA_MULT_SEG_DECODE
      ((MaTknStrUL *)(ctlp->sSt))->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */ 
       MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(MaTknStrUL)); 

      RETVALUE(ROK);
    }
    else
    {
       ctlp->errCode = MAT_DATA_MISSING;
       MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
       "maDecStrUL() failed, mand. data missing.\n"));  
       RETVALUE(RFAILED);
    }

  }

  sStrUL = (MaTknStrUL *)ctlp->sSt;
  ret = maRemULPrim(mBuf,ctlp,(U8 *)&sStrUL->val[0],(U16 *)&sStrUL->len);
  if (ret != ROK)
  {
     ctlp->errCode = MAT_MISTYPED_PARAM;
     RETVALUE(ret);
  }
  sStrUL->pres = TRUE;
  MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(MaTknStrUL)); 

  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecStrUL: %s Tag [%x] Len [%x] \n", 
          maEleType[teDef->type], data, sStrUL->len));

  ctlp->sTelDef++;
  RETVALUE(ROK);

} /* maDecStrUL */

                  /* user escape function */
/* ---------------------------------------------------------*/



/* Enumeration type exception handling */
/*-------------------------------------*/

/*
*
*       Fun:   maChkDefCallHandl    
*
*       Desc:  This function encodes/decodes/skip default call handling
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkDefCallHandl 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkDefCallHandl (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkDefCallHandl)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkDefCallHandl() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if ((sSt->val >= 2) && (sSt->val <= 31))
    {
       sSt->val = MAT_CONTINUE_CALL;
    }
    if (sSt->val > 31)
    {
       sSt->val = MAT_RELEASE_CALL;
    }

    /* initialize the event structure */
    sSt->pres = TRUE;

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkDefCallHandl: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkDefCallHandl  */

/*
*
*       Fun:   maChkRptState    
*
*       Desc:  This function encodes/decodes/skip reporting state
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkRptState 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkRptState (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkRptState)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkRptState() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if ((sSt->val >= 2) && (sSt->val <= 10))
    {
       sSt->val = MAT_STOP_MONITORING;
    }
    if (sSt->val > 10)
    {
       sSt->val = MAT_START_MONITORING;
    }

    /* initialize the event structure */
    sSt->pres = TRUE;

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkRptState: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkRptState  */

/*
*
*       Fun:   maChkCcbsSubsStatus    
*
*       Desc:  This function encodes/decodes/skip CCBS Subscriber Status
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkCcbsSubsStatus 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkCcbsSubsStatus (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkCcbsSubsStatus)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkCcbsSubsState() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if ((sSt->val >= 3) && (sSt->val <= 10))
    {
       sSt->val = MAT_CCBS_NOT_IDLE;
    }
    if ((sSt->val >= 11) && (sSt->val <= 20))
    {
       sSt->val = MAT_CCBS_IDLE;
    }
    if (sSt->val > 20)
    {
       sSt->val = MAT_CCBS_NOT_REACHABLE;
    }

    /* initialize the event structure */
    sSt->pres = TRUE;

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkCcbsSubsStatus: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkCcbsSubsStatus  */

/*
*
*       Fun:   maChkMonMode    
*
*       Desc:  This function encodes/decodes/skip Monitoring Mode
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkMonMode 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkMonMode (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkMonMode)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkMonMode() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if ((sSt->val >= 2) && (sSt->val <= 10))
    {
       sSt->val = MAT_A_SIDE;
    }
    if (sSt->val > 10)
    {
       sSt->val = MAT_B_SIDE;
    }

    /* initialize the event structure */
    sSt->pres = TRUE;

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkMonMode: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkMonMode  */

/*
*
*       Fun:   maChkCallOutcome    
*
*       Desc:  This function encodes/decodes/skip Call Outcome
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkCallOutcome 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkCallOutcome (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkCallOutcome)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkCallOutcome() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if ((sSt->val >= 3) && (sSt->val <= 10))
    {
       sSt->val = MAT_CALL_SUCCESS;
    }
    if ((sSt->val >= 11) && (sSt->val <= 20))
    {
       sSt->val = MAT_CALL_FAILURE;
    }
    if (sSt->val > 20)
    {
       sSt->val = MAT_CALL_BUSY;
    }

    /* initialize the event structure */
    sSt->pres = TRUE;

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkCallOutcome: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkCallOutcome  */

/*
*
*       Fun:   maChkRufOutcome    
*
*       Desc:  This function encodes/decodes/skip RufOutcome
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkRufOutcome 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkRufOutcome (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkRufOutcome)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkRufOutcome() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if ((sSt->val >= 6) && (sSt->val <= 20))
    {
       sSt->val = MAT_ACCEPTED;
    }
    if ((sSt->val >= 21) && (sSt->val <= 30))
    {
       sSt->val = MAT_REJECTED;
    }
    if ((sSt->val >= 31) && (sSt->val <= 40))
    {
       sSt->val = MAT_NO_RESP_FROM_FREE_MS;
    }
    if ((sSt->val >= 41) && (sSt->val <= 50))
    {
       sSt->val = MAT_NO_RESP_FROM_BUSY_MS;
    }
    if ((sSt->val >= 51) && (sSt->val <= 60))
    {
       sSt->val = MAT_UDUB_FROM_FREE_MS;
    }
    if (sSt->val > 60)
    {
       sSt->val = MAT_UDUB_FROM_BUSY_MS;
    }

    /* initialize the event structure */
    sSt->pres = TRUE;

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkRufOutcome: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkRufOutcome  */


/*
*
*       Fun:   maChkAbsSubsRsn    
*
*       Desc:  This function encodes/decodes/skip Position Method Failure
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkAbsSubsRsn 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkAbsSubsRsn (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkAbsSubsRsn)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkAbsSubsRsn() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
#if MAP_REL99
#else
    if ((sSt->val == MAT_IMSI_DETACH)         || 
        (sSt->val == MAT_ASR_RESTRICTED_AREA) || 
        (sSt->val == MAT_NO_PAGE_RESPONSE))
#endif
#if MAP_REL99          
    if ((sSt->val == MAT_IMSI_DETACH)         || 
        (sSt->val == MAT_ASR_RESTRICTED_AREA) || 
        (sSt->val == MAT_NO_PAGE_RESPONSE)    ||
        (sSt->val == MAT_PURGED_MS))
#endif /* MAP_REL99 */
    {
       sSt->pres = TRUE;
    }
    else 
    {
       sSt->pres = FALSE;
    }

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkAbsSubsRsn: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkAbsSubsRsn  */


/*
*
*       Fun:   maChkOBcsmTrigDetPt    
*
*       Desc:  This function encodes/decodes/skip the OBCSM Trigger 
*              Detection Point tokens  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkOBcsmTrigDetPt 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkOBcsmTrigDetPt (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8           tmpLen;

  TRC2 (maChkOBcsmTrigDetPt)
 
  if (ctlp->decode == TRUE)
  {
     teDef = *ctlp->sTelDef;
     sSt   = (TknU8 *)ctlp->sSt;
     mBuf  = ctlp->mBuf;

     if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
     { 
        ctlp->errCode = MAT_MISTYPE_PARAM;
        RETVALUE(ret);
     }

     if (data != teDef->tag)
     {
        /* check whether Map versions are compatible */
        if ((ret = maChkEleMand(ctlp) == FALSE))
        {
           /* skip the element in the data base and make as not */
           /* present in event str. */
           ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
           sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
           /* bump structure pointer in message control */
           MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
           RETVALUE(ROK);
        }
        else
        {
           ctlp->errCode = MAT_DATA_MISSING;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maChkOBcsmTrigDetPt() failed, mand. data missing.\n"));  
           RETVALUE(RFAILED);
        }
     }

     /* remove the octet */
     if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
     {
        ctlp->errCode = MAT_MISTYPED_PARAM;
        RETVALUE(ret);
     }

     /* exception handling */
#if MAP_REL99
#else
     if (sSt->val != MAT_COLLECTED_INFO)
     {
        ret = MA_SKIP_SEQ;
        RETVALUE(ret);
     }
#endif
#if MAP_REL99          
     if ((sSt->val != MAT_COLLECTED_INFO) && 
         (sSt->val != MAT_ROUTE_SELECT_FAILURE))
     {
        ret = MA_SKIP_SEQ;
        RETVALUE(ret);
     }
#endif /* MAP_REL99 */

     /* initialize the event structure */
     sSt->pres = TRUE;

     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maChkOBcsmTrigDetPt: %s Tag [%x] Len [%x] Val [%x] \n", 
     maEleType[teDef->type], data, tmpLen, sSt->val));
     /* bump structure pointer in message control */
     MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
     ctlp->sTelDef++;
     RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkOBcsmTrigDetPt  */

/*
*
*       Fun:   maChkTBcsmTrigDetPt    
*
*       Desc:  This function encodes/decodes/skip the TBCSM Trigger 
*              Detection Point tokens  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkTBcsmTrigDetPt 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkTBcsmTrigDetPt (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8           tmpLen;

  TRC2 (maChkTBcsmTrigDetPt)
 
  if (ctlp->decode == TRUE)
  {
     teDef = *ctlp->sTelDef;
     sSt   = (TknU8 *)ctlp->sSt;
     mBuf  = ctlp->mBuf;

     if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
     { 
        ctlp->errCode = MAT_MISTYPE_PARAM;
        RETVALUE(ret);
     }

     if (data != teDef->tag)
     {
        /* check whether Map versions are compatible */
        if ((ret = maChkEleMand(ctlp) == FALSE))
        {
           /* skip the element in the data base and make as not */
           /* present in event str. */
           ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
           sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
           /* bump structure pointer in message control */
           MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
           RETVALUE(ROK);
        }
        else
        {
           ctlp->errCode = MAT_DATA_MISSING;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maChkTBcsmTrigDetPt() failed, mand. data missing.\n"));  
           RETVALUE(RFAILED);
        }
     }

     /* remove the octet */
     if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
     {
        ctlp->errCode = MAT_MISTYPED_PARAM;
        RETVALUE(ret);
     }

     /* exception handling */
#if MAP_REL99
#else
     if (sSt->val != MAT_TERM_ATTEMPT_AUTH)
     {
        ret = MA_SKIP_SEQ;
        RETVALUE(ret);
     }
#endif
#if MAP_REL99          
     if ((sSt->val != MAT_TERM_ATTEMPT_AUTH) && 
         (sSt->val != MAT_T_BUSY) && 
         (sSt->val != MAT_T_NO_ANSWER))
     {
        ret = MA_SKIP_SEQ;
        RETVALUE(ret);
     }
#endif /* MAP_REL99 */

     /* initialize the event structure */
     sSt->pres = TRUE;

     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maChkTBcsmTrigDetPt: %s Tag [%x] Len [%x] Val [%x] \n", 
     maEleType[teDef->type], data, tmpLen, sSt->val));
     /* bump structure pointer in message control */
     MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
     ctlp->sTelDef++;
     RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkTBcsmTrigDetPt  */

#if MAP_REL5
/* Enumeration type exception handling */
/*-------------------------------------*/

/*
*
*       Fun:   maChkMtSmsTpduType    
*
*       Desc:  This function encodes/decodes/skip the TBCSM Trigger 
*              Detection Point tokens  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkMtSmsTpduType 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkMtSmsTpduType (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkMtSmsTpduType)

  if (ctlp->decode == TRUE)
  {
     teDef = *ctlp->sTelDef;
     sSt   = (TknU8 *)ctlp->sSt;
     mBuf  = ctlp->mBuf;

     if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
     { 
        ctlp->errCode = MAT_MISTYPE_PARAM;
        RETVALUE(ret);
     }

     if (data != teDef->tag)
     {
        /* check whether Map versions are compatible */
        if ((ret = maChkEleMand(ctlp) == FALSE))
        {
           /* skip the element in the data base and make as not */
           /* present in event str. */
           ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
           sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
           /* bump structure pointer in message control */
           MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
           RETVALUE(ROK);
        }
        else
        {
           ctlp->errCode = MAT_DATA_MISSING;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maChkMtSmsTpduType() failed, mand. data missing.\n"));  
           RETVALUE(RFAILED);
        }
     }

     /* remove the octet */
     if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
     {
        ctlp->errCode = MAT_MISTYPED_PARAM;
        RETVALUE(ret);
     }

     /* exception handling */
     if ((sSt->val != MAT_SMS_DELIVER) && 
         (sSt->val != MAT_SMS_SUBMIT_REPORT) && 
         (sSt->val != MAT_SMS_STATUS_REPORT))
     {
        sSt->pres = FALSE;
     }
     else
     {
        /* initialize the event structure */
        sSt->pres = TRUE;
     }
     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maChkMtSmsTpduType: %s Tag [%x] Len [%x] Val [%x] \n", 
     maEleType[teDef->type], data, tmpLen, sSt->val));
     /* bump structure pointer in message control */
     MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
     ctlp->sTelDef++;
     RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkMtSmsTpduType  */


/*
*
*       Fun:   maChkDomainType    
*
*       Desc:  This function encodes/decodes/skip default call handling
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkDomainType 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkDomainType (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkDomainType)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkDomainType() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if (sSt->val >= teDef->elist[0][0])
    {
       sSt->val = MAT_CS_DOMAIN;
    }

    /* initialize the event structure */
    sSt->pres = TRUE;

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkDomainType: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkDomainType  */

/*
*
*       Fun:   maChkAddReqCamSubsInfo    
*
*       Desc:  This function encodes/decodes/skip default call handling
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkAddReqCamSubsInfo 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkAddReqCamSubsInfo (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkAddReqCamSubsInfo)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkAddReqCamSubsInfo() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if (sSt->val >= teDef->elist[0][0])
    {
       sSt->pres = FALSE;
    }
    else 
    {
       sSt->pres = TRUE;
    }

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkAddReqCamSubsInfo: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkAddReqCamSubsInfo  */

/* Addition. Added exceptional handling for Unavailable Cause parameter */
/*
*
*       Fun:   maChkUnavailCause    
*
*       Desc:  This function takes care of exception handling
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/

#ifdef ANSI
PUBLIC S16 maChkUnavailCause
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkUnavailCause (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkUnavailCause)

  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8));
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf,
         "maChkUnavailCause() failed, mand. data missing.\n"));
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if ((sSt->val == MA_BEAR_NOT_PROV) ||
        (sSt->val == MA_TELE_NOT_PROV) ||
        (sSt->val == MA_ABSENT_SUBS) ||
        (sSt->val == MA_BUSY_SUBS) ||
        (sSt->val == MA_CALL_BARRED) ||
        (sSt->val == MA_CUG_REJECT))
    {
       sSt->pres = TRUE;
    }
    else
    {
       sSt->pres = FALSE;
    }
   


    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf,
    "maChkUnavailCause: %s Tag [%x] Len [%x] Val [%x] \n",
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8));
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);

}

#endif /* MAP_REL5 */

/*
*
*       Fun:   maChkIgnoreSeq
*
*       Desc:  This function encodes/decodes/skip the Sequence
*              tokens  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkIgnoreSeq 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkIgnoreSeq (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  MaTknElmtDef  *teDef;
  MaTknElmtDef  **tmpTeDef;
  U8            swtch;
  TknU8         *tmpsSt;
  S16           ret;
  Data          data;
  Buffer        *mBuf;
  Bool          eocFlg;
  Bool          remEocFlg;
  MsgLen        tmpLen;
  MsgLen        lfLen;  /* Length of length field */
  MsgLen        seqLen;
  Data          unPkArray[MA_MAX_PKARRAY_LEN];
  MsgLen        orgMsgLen;
  MsgLen        newMsgLen;

  TRC2 (maChkIgnoreSeq)

  /* ------ skip sequence ---------*/
  if (ctlp->skip == TRUE)
  {
     maSkipSeq(ctlp);
     RETVALUE(ROK);
  }

  /* ------ encode sequence --------*/
  if (ctlp->encode == TRUE)
  {
     maEncEscSeq(ctlp);
     RETVALUE(ROK);
  }

  /*--------- decode sequence ---------*/
  if (ctlp->decode == TRUE)
  {
     teDef = *ctlp->sTelDef;
     mBuf  = ctlp->mBuf;
     eocFlg = FALSE;
     swtch = (U8)ctlp->swtch;

     tmpTeDef = ctlp->sTelDef;
     tmpsSt = (TknU8 *)ctlp->sSt;

     (Void)SExamMsg(&data, mBuf, 0);

     if (data != teDef->tag)
     {
        /* check whether Map versions are compatible */
        if ((ret = maChkEleMand(ctlp) == FALSE))
        {
           /* skip the elmt. in the data base and make as not present */
           /* in event str */
           maSkipSeq(ctlp);
           RETVALUE(ROK);
        }
        else
        {
           ctlp->errCode = MAT_DATA_MISSING;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maChkIgnoreSeq() failed, mand. data error.\n"));  
           RETVALUE(RFAILED);
        }
     }

     if ((ret = maFindLen(ctlp->mBuf, 0, &seqLen, &eocFlg, &lfLen)) != ROK)
     {
        ctlp->errCode = MAT_MISTYPED_PARAM;
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maChkIgnoreSeq() failed, fail to get msg len.\n"));  
        RETVALUE(RFAILED);
     }

     /* decode the sequence */
     (Void)SRemPreMsg(&data, mBuf);

     if ((ret = maRemLen(mBuf, &remEocFlg)) != ROK)
     {
        ctlp->errCode = MAT_MISTYPE_PARAM;
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maChkIgnoreSeq() failed, fail to get msg len.\n"));  
        RETVALUE(RFAILED);
     }

     if (seqLen == 0)
     {
        if ((ret = maChkEleMand(ctlp)) == FALSE)
        {
           maSkipSeq(ctlp);
           if (remEocFlg == TRUE)
           {
              /* remove the two EOC bytes */
              if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
              {
                 ctlp->errCode = MAT_MISTYPE_PARAM;
                 RETVALUE(ret);
              }
           }
           RETVALUE(ROK);
        }
        else
        {
           ctlp->errCode = MAT_DATA_MISSING;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maChkIgnoreSeq() failed, mand. data missing.\n"));  
           RETVALUE(RFAILED);
        }
     }

     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maChkIgnoreSeq: Check ignore Sequence ...... \n \
     %s Tag [%x] \n", maEleType[teDef->type], data));

     /* increment the data base pointer */

     ctlp->sTelDef++;
     teDef = *ctlp->sTelDef;

     while (teDef->type != MA_TET_SEQ_TERM)
     {
        if (seqLen == 0)
        {
           if (remEocFlg == TRUE)
           {
              /* remove the two EOC bytes */
              if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
              {
                 ctlp->errCode = MAT_MISTYPE_PARAM;
                 RETVALUE(ret);
              }
           }
           /* reached end of buffer - check for missing mand el */
           RETVALUE(maChkSeqMand(ctlp));
        }
        SFndLenMsg(ctlp->mBuf, &orgMsgLen);
        switch (teDef->type)
        {
           case MA_TET_U8:
             if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
             {
                ctlp->errCode = MAT_MISTYPED_PARAM;
                MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
                "maChkIgnoreSeq() failed at token(%d), fail to get msg len.\n", teDef->type));  
                RETVALUE(RFAILED);
             }
             ret = maDecOctet(ctlp,FALSE);
          
             break;
           case MA_TET_U8_ENUM:
             if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
             {
                ctlp->errCode = MAT_MISTYPED_PARAM;
                MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
                "maChkIgnoreSeq() failed at token(%d), fail to get msg len.\n", teDef->type));  
                RETVALUE(RFAILED);
             }

             ret = maDecOctet(ctlp,TRUE);

             break;
           case MA_TET_NULL:
             if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
             {
                ctlp->errCode = MAT_MISTYPED_PARAM;
                MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
                "maChkIgnoreSeq() failed at token(%d), fail to get msg len.\n", teDef->type));  
                RETVALUE(RFAILED);
             }
             ret = maDecNull(ctlp);
             break;
           case MA_TET_INT:
             if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
             {
                ctlp->errCode = MAT_MISTYPED_PARAM;
                MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
                "maChkIgnoreSeq() failed at token(%d), fail to get msg len.\n", teDef->type));  
                RETVALUE(RFAILED);
             }
             ret = maDecInt(ctlp);
             break;
           case MA_TET_STR:
           case MA_TET_STRS:
           case MA_TET_STRM:
           case MA_TET_STRE:
#ifdef XWEXT
           case MA_TET_STR4:
#endif
             if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
             {
                ctlp->errCode = MAT_MISTYPED_PARAM;
                MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
                "maChkIgnoreSeq() failed at token(%d), fail to get msg len.\n", teDef->type));  
                RETVALUE(RFAILED);
             }
             ret = maDecStr(ctlp);
             break;
           case MA_TET_STRUL:
             if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
             {
                ctlp->errCode = MAT_MISTYPED_PARAM;
                MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
                "maChkIgnoreSeq() failed at token(%d), fail to get msg len.\n", teDef->type));  
                RETVALUE(RFAILED);
             }
             ret = maDecStrUL(ctlp);
             break;
           case MA_TET_BITSTR:
             if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
             {
                ctlp->errCode = MAT_MISTYPED_PARAM;
                MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
                "maChkIgnoreSeq() failed at token(%d), fail to get msg len.\n", teDef->type));  
                RETVALUE(RFAILED);
             }
             ret = maDecBitStr(ctlp);
             break;
           case MA_TET_SEQ:
           case MA_TET_EXT_CONT:
             if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
             {
                ctlp->errCode = MAT_MISTYPED_PARAM;
                MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
                "maChkIgnoreSeq() failed at token(%d), fail to get msg len.\n", teDef->type));  
                RETVALUE(RFAILED);
             }
             if (tmpLen > seqLen)
             {
                MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
                "maChkIgnoreSeq() failed at token(%d), len invalid.\n", teDef->type));  
                RETVALUE(RFAILED);
             }
             ret = maDecSeq(ctlp);
             break;
           case MA_TET_SEQ_OF:
             if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
             {
                ctlp->errCode = MAT_MISTYPED_PARAM;
                MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
                "maChkIgnoreSeq() failed at token(%d), fail to get msg len.\n", teDef->type));  
                RETVALUE(RFAILED);
             }
             ret = maDecSeqOf(ctlp);
             break;
           case MA_TET_CHOICE:
             if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
             {
                ctlp->errCode = MAT_MISTYPED_PARAM;
                MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
                "maChkIgnoreSeq() failed at token(%d), fail to get msg len.\n", teDef->type));  
                RETVALUE(RFAILED);
             }
             ret = maDecChoice(ctlp);
             break;
           default:
#if (ERRCLASS & ERRCLS_DEBUG)
             MALOGERROR(ERRCLS_DEBUG, EMA310, (ErrVal)teDef->type, "maDecSeq () Failed");
#endif
             break;
        }

        SFndLenMsg(ctlp->mBuf,&newMsgLen);
        if (orgMsgLen != newMsgLen)
        {
           seqLen -= (orgMsgLen - newMsgLen);
        }
        teDef = *ctlp->sTelDef;
        if (seqLen < 0)
        {
           ctlp->errCode = MAT_MISTYPED_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maChkIgnoreSeq() failed at token(%d), len invalid.\n", teDef->type));  
           RETVALUE(RFAILED);
        }

        if (ret != ROK)
        {
           /* Check if need to ignore whore sequence */
           if (ret == MA_SKIP_SEQ)
           {
              ctlp->sTelDef = tmpTeDef;
              ctlp->sSt = (U8 *)tmpsSt;
              maSkipSeq(ctlp);
              /* Remove seqLen bytes from the message buffer */
              /* buffer is only of size MA_MAX_PKARRAY_LEN */

              while(seqLen > 0)
              { 
                 if(seqLen >= MA_MAX_PKARRAY_LEN)
                 {
                    ret = SRemPreMsgMult(unPkArray, (MsgLen)MA_MAX_PKARRAY_LEN,
                                          mBuf);
                    seqLen -= MA_MAX_PKARRAY_LEN;
                 }
                 else
                 {
                    ret = SRemPreMsgMult(unPkArray, (MsgLen)seqLen, mBuf);
                    seqLen = 0;
                 }
                 if ((ret != ROK))
                 {
                    ctlp->errCode = MAT_MISTYPE_PARAM;
                    RETVALUE(ret);
                 }
              }
              if (remEocFlg == TRUE)
              {
                 /* remove the two EOC bytes */
                 if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
                 {
                    ctlp->errCode = MAT_MISTYPE_PARAM;
                    RETVALUE(ret);
                 }
              }       
              RETVALUE(ROK);
           }      
           else 
           {            
              MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
              "maChkIgnoreSeq() failed.\n"));  
              RETVALUE(RFAILED);
           }
        }
     }

     if ( (ctlp->maVer != LMA_VER1) && (seqLen > 0) )
     {
        /*
        ** Extended elements at the end of the sequence .
        ** So Ignore them without sending error indications.
        ** This is done only for phase-2 messages.
        */
 
        /* remove the remaining elements from the sequence */
        while(seqLen > 0)
        {
           if ((ret = SRemPreMsg(&data, mBuf)) != ROK)
           {
              ctlp->errCode = MAT_MISTYPE_PARAM;
              RETVALUE(ret);
           }
           seqLen--;
        }
     }
 
     if ( (ctlp->maVer == LMA_VER1) && (seqLen > 0) )
     {
        /*
        ** Unknown elements at the end of the sequence .
        ** So send error indications.
        ** This is done only for phase-1 messages.
        */
 
        ctlp->errCode = MAT_MISTYPE_PARAM;
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maChkIgnoreSeq() failed, unknown el. at the end of the seq.\n"));  
        RETVALUE(RFAILED);
     }

     if (remEocFlg == TRUE)
     {
        /* remove the two EOC bytes */
        if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           RETVALUE(ret);
        }
     }
     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maChkIgnoreSeq: Check ignore Sequence  Successfully.\n"));
     ctlp->sTelDef++;
     RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkIgnoreSeq  */

#if (MAP_REL98 || MAP_REL99)
/*
*
*       Fun:   maChkGmlcRest    
*
*       Desc:  This function encodes/decodes/skip GMLC Restriction
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkGmlcRest 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkGmlcRest (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkGmlcRest)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkGmlcRest() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if ((sSt->val == MAT_GMLC_LIST) || (sSt->val == MAT_HOME_COUNTRY))
    {
       sSt->pres = TRUE;
    }
    else 
    {
       sSt->pres = FALSE;
    }

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkGmlcRest: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkGmlcRest  */

/*
*
*       Fun:   maChkNotificationToMsUsr    
*
*       Desc:  This function encodes/decodes/skip Notifcation To MsUsr
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkNotificationToMsUsr 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkNotificationToMsUsr (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkNotificationToMsUsr)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkNotificationToMsUsr() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
#if MAP_REL4
#if MAP_REL99
    if ((sSt->val == MAT_NOTIFY_LOC_ALLOW)                || 
        (sSt->val == MAT_NOTIFY_VERIFY_LOC_ALLOW_NO_RESP) || 
        (sSt->val == MAT_NOTIFY_VERIFY_LOC_NOT_ALLOW_NO_RESP) ||
        (sSt->val == MAT_LOC_NOT_ALLOWED))
#endif
#else  /* MAP_REL4 */
    if ((sSt->val == MAT_NOTIFY_LOC_ALLOW)                || 
        (sSt->val == MAT_NOTIFY_VERIFY_LOC_ALLOW_NO_RESP) || 
        (sSt->val == MAT_NOTIFY_VERIFY_LOC_NOT_ALLOW_NO_RESP))
#endif
    {
       sSt->pres = TRUE;
    }
    else 
    {
       sSt->pres = FALSE;
    }

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkNotificationToMsUsr: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkNotificationToMsUsr  */

/*
*
*       Fun:   maChkNmbPortStatus
*
*       Desc:  This function encodes/decodes/skip Number Portability Status
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkNmbPortStatus 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkNmbPortStatus (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkNmbPortStatus)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkNmbPortStatus() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
/* Addition. Added more checks for R5 upgrade */
#if MAP_REL5
    if ((sSt->val == MAT_NOT_KNOWN_TO_BE_PORTED) ||
        (sSt->val == MAT_OWN_NMB_PORTED_OUT)     ||
        (sSt->val == MAT_FRGN_NMB_PORTED_TO_FRGN_NET) ||
        (sSt->val == MAT_OWN_NMB_NOT_PORTED_OUT) ||
        (sSt->val == MAT_FRGN_NMB_PORTED_IN))
#else
    if ((sSt->val == MAT_NOT_KNOWN_TO_BE_PORTED) || 
        (sSt->val == MAT_OWN_NMB_PORTED_OUT)     || 
        (sSt->val == MAT_FRGN_NMB_PORTED_TO_FRGN_NET))
#endif
    {
       sSt->pres = TRUE;
    }
    else 
    {
       sSt->pres = FALSE;
    }

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkNmbPortStatus: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkNmbPortStatus  */

/*
*
*       Fun:   maChkUnAuthLcsClientDiag
*
*       Desc:  This function encodes/decodes/skip Unauthorized LCS Client
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkUnAuthLcsClientDiag 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkUnAuthLcsClientDiag (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkUnAuthLcsClientDiag)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkUnAuthLcsClientDiag() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if (sSt->val >= teDef->elist[0][0])
    {
       sSt->pres = FALSE;
    }
    else 
    {
       sSt->pres = TRUE;
    }

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkUnAuthLcsClientDiag: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkUnAuthLcsClientDiag  */


/*
*
*       Fun:   maChkPosiMethFailDiag    
*
*       Desc:  This function encodes/decodes/skip Position Method Failure
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkPosiMethFailDiag 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkPosiMethFailDiag (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkPosiMethFailDiag)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkPosiMethFailDiag() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if ((sSt->val == MAT_CONGESTION)                   || 
        (sSt->val == MAT_INSUFFICIENT_RESOUSES)        || 
        (sSt->val == MAT_INSUFFICIENT_MEAS_DATA)       || 
        (sSt->val == MAT_INCONSISTENT_MEAS_DATA)       || 
        (sSt->val == MAT_LOC_PROC_NOT_COMPLETED)       || 
        (sSt->val == MAT_LOC_PROC_NOT_SUP_BY_TARGT_MS) || 
        (sSt->val == MAT_QOS_NOT_ATTAINABLE)           || 
        (sSt->val == MAT_POSI_METH_NOT_AVAI_NET)       || 
        (sSt->val == MAT_POSI_METH_NOT_AVAI_IN_LOC_AREA))
    {
       sSt->pres = TRUE;
    }
    else 
    {
       sSt->pres = FALSE;
    }

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkPosiMethFailDiag: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkPosiMethFailDiag  */

/*
*
*       Fun:   maChkRspTimeCat    
*
*       Desc:  This function encodes/decodes/skip default call handling
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkRspTimeCat 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkRspTimeCat (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkRspTimeCat)

  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkRspTimeCat() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if ((sSt->val != MAT_LOW_DELAY) && (sSt->val != MAT_DELAY_TOLERANT))
    {
       sSt->val = MAT_DELAY_TOLERANT;
    }

    sSt->pres = TRUE;

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkRspTimeCat: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkRspTimeCat  */

/*
*
*       Fun:   maChkExtProtId    
*
*       Desc:  This function encodes/decodes/skip Ext. protocol ID
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkExtProtId 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkExtProtId (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkExtProtId)
 
  if (ctlp->decode == TRUE)
  {
     teDef = *ctlp->sTelDef;
     sSt   = (TknU8 *)ctlp->sSt;
     mBuf  = ctlp->mBuf;

     if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
     { 
        ctlp->errCode = MAT_MISTYPE_PARAM;
        RETVALUE(ret);
     }

     if (data != teDef->tag)
     {
        /* check whether Map versions are compatible */
        if ((ret = maChkEleMand(ctlp) == FALSE))
        {
           /* skip the element in the data base and make as not */
           /* present in event str. */
           ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
           sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
           /* bump structure pointer in message control */
           MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
           RETVALUE(ROK);
        }
        else
        {
           ctlp->errCode = MAT_DATA_MISSING;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maChkExtProtId() failed, mand. data missing.\n"));  
           RETVALUE(RFAILED);
        }
     }

     /* remove the octet */
     if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
     {
        ctlp->errCode = MAT_MISTYPED_PARAM;
        RETVALUE(ret);
     }

     /* exception handling */
     if (sSt->val != MAT_ETS_300356)
     {
        ret = MA_SKIP_SEQ;
        RETVALUE(ret);
     }

     /* initialize the event structure */
     sSt->pres = TRUE;

     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maChkExtProtId: %s Tag [%x] Len [%x] Val [%x] \n", 
     maEleType[teDef->type], data, tmpLen, sSt->val));
     /* bump structure pointer in message control */
     MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
     ctlp->sTelDef++;
     RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkExtProtId  */


#endif /* MAP_REL98 || MAP_REL99 */

/*
*
*       Fun:   maChkSeq2    
*
*       Desc:  This function encodes/decodes/skip SndIdRspSeq,
*              maChkPreHoReq,maChkPreHoRsp,maPreSubsHoReq.
*
*       Ret:   ROK 
*
*       Notes: Ver2P: Seq tag [3], 
*              Ver2 : Seq,Universal Tag, elements have no tags in ver2P.
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkSeq2 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkSeq2 (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  MaTknElmtDef  *teDef;    /* element definition */
  MaTknElmtDef  **tmpDef;  /* temporory element definition */
  TknU8         *tmpSst;   /* temporary pointer */
  S16           ret;       /* return value */
  Data          data;
  Buffer        *mBuf;
  TknU8         *sSt;
  Data          pkArray[2];
  S16           seqMand;
  MsgLen        orgLen;
  MsgLen        curLen;
  MsgLen        i;
  Bool          eocFlg;
  Bool          remEocFlg;
  U8            swtch;
  MsgLen        tmpLen;
  MsgLen        lfLen;  /* Length of length field */
  MsgLen        seqLen;
  Data          unPkArray[MA_MAX_PKARRAY_LEN];
  MsgLen        orgMsgLen;
  MsgLen        newMsgLen;
#ifdef MAP_PHASE2_EXT_MARK
  TknStrE       *sStrE;
#endif


  TRC2 (maChkSeq2)

  /* For version 2p operation, encode/decode/skip entire seq */

  if (ctlp->maVer == LMA_VER2P)
  {
     if (ctlp->skip == TRUE)
     {
        ret = maSkipSeq(ctlp);
        RETVALUE(ret);
     }

     if (ctlp->encode == TRUE)
     {
        ret = maEncEscSeq(ctlp);
        RETVALUE(ret);
     }

     if (ctlp->decode == TRUE)
     {
        ret = maDecEscSeq(ctlp);
        RETVALUE(ret);
     }
  }

  else /* if (ctlp->maVer <= LMA_VER2) */
  {
     if (ctlp->skip == TRUE)
     {
        maSkipSeq(ctlp);   
        RETVALUE(ROK);
     }

     if (ctlp->encode == TRUE)
     {
        teDef = *ctlp->sTelDef;
        tmpDef = ctlp->sTelDef;
        tmpSst = (TknU8 *)ctlp->sSt;
 
        /* encode the universal sequence tag and EOC length tag */
        pkArray[0] = MA_TAG_SEQ;
        pkArray[1] = (Data)MA_EOC_LEN;

        ret = SAddPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
        if (ret != ROK)
        {
           MALOGERROR(ERRCLS_ADD_RES, EMA311, (ErrVal)ret, "SAddPstMsgMult() Failed");
           RETVALUE(ret);
        }
#endif
        seqMand = maChkEleMand(ctlp);

        /* increment the token pointer */
        ctlp->sTelDef++;
 
        teDef = *ctlp->sTelDef;
  
        /* All the tokens have first field as pres so typecast to TknU8 */
        sSt = (TknU8 *)ctlp->sSt;
 
        SFndLenMsg(ctlp->mBuf, &orgLen);
        MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
        "maChkSeq2: Check Sequence2  ...... \n \
        %s Tag [%x] Len [%x]\n",
        maEleType[teDef->type], pkArray[0], pkArray[1]));

        while (teDef->type != MA_TET_SEQ_TERM)
        {
           MA_INCREASE_LEVEL;
           /* Start encoding the tokens */
           switch(teDef->type)
           {
              case MA_TET_U8:
                ret = maEncOctet(ctlp,FALSE);
                break;
              case MA_TET_U8_ENUM:
                ret = maEncOctet(ctlp,TRUE);
                break;
              case MA_TET_NULL:
                ret = maEncNull(ctlp);
                break;
              case MA_TET_INT:
                ret = maEncInt(ctlp);
                break;
              case MA_TET_STR:
              case MA_TET_STRS:
              case MA_TET_STRM:
              case MA_TET_STRE:
#ifdef XWEXT
              case MA_TET_STR4:
#endif
                ret = maEncStr(ctlp);
                break;
              case MA_TET_STRUL:
                ret = maEncStrUL(ctlp);
                break;
              case MA_TET_BITSTR:
                ret = maEncBitStr(ctlp);
                break;
              case MA_TET_SEQ:
              case MA_TET_EXT_CONT:
                ret = maEncSeq(ctlp);
                break;
              case MA_TET_SEQ_OF:
                ret = maEncSeqOf(ctlp,teDef->repCntr, ctlp->sTelDef);
                break;
              case MA_TET_CHOICE:
                ret = maEncChoice(ctlp);
                break;
#ifdef MAP_PHASE2_EXT_MARK
              case MA_TET_EXT_MARK:
                ret = maHndlExtMark(ctlp);
                break;
#endif
           }
           MA_DECREASE_LEVEL;
           SFndLenMsg(ctlp->mBuf, &curLen);
           if ((ret != ROK) && (ret != EMP_SEQ) && (ret != NON_EMP_SEQ))
           {
              if ( ctlp->errCode == MAT_DATA_MISSING)
              {
                 if (orgLen == curLen) 
                 {
                    ctlp->sTelDef = tmpDef;
                    ctlp->sSt = (U8 *)tmpSst;
                    maSkipTkns(ctlp);
                    /* strip of the added tag and length before returning */
                    SRemPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
                    if (seqMand == FALSE)
                    {
                       RETVALUE(ROK);
                    }
                    else
                    {
                       MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
                       "maChkSeq2() failed, mand. data missing.\n"));  
                       RETVALUE(RFAILED);
                    }
                 }
                 else
                 {
                    ctlp->sTelDef = tmpDef;
                    ctlp->sSt = (U8 *)tmpSst;
                    maSkipTkns(ctlp);
               
                    /* Strip off the encoded bytes */
                    for (i=0; i< (curLen - orgLen); i++)
                    {
                       SRemPstMsg(pkArray, ctlp->mBuf);
                    }
                    /* strip of the added tag and length before returning */
                    SRemPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
  
                    MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
                    "maChkSeq2() failed, mand. data missing.\n"));  
                    RETVALUE(RFAILED);
                 }
              }
              else
              {
                 ctlp->sTelDef = tmpDef;
                 ctlp->sSt = (U8 *)tmpSst;
                 maSkipTkns(ctlp);
                 /* strip of the added tag and length before returning */
                 SRemPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
                 MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
                 "maChkSeq2() failed, fail to encode msg type(%d).\n", teDef->type));  
                 RETVALUE(RFAILED);
              }
           }

           /* update the pointers */
           teDef = *ctlp->sTelDef;
           sSt = (TknU8 *)ctlp->sSt;
        }

        SFndLenMsg(ctlp->mBuf, &curLen);
        if ((orgLen == curLen) && (seqMand == FALSE))
        {
           SRemPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
           ctlp->sTelDef++;
           RETVALUE(ROK);
        }
#ifdef MA_ASN_NO_INDEF_LEN
        MA_ENC_DEF_LEN(curLen, orgLen)
#else /* MA_ASN_NO_INDEF_LEN */
        /* Encode the TWo EOC tag to indicate end of sequence */
        pkArray[0] = MA_TAG_EOC;
        pkArray[1] = MA_TAG_EOC;

        ret = SAddPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
        if (ret != ROK)
        {
           MALOGERROR(ERRCLS_ADD_RES, EMA312, (ErrVal)ret, "SAddPstMsgMult() Failed");
           RETVALUE(ret);
        }
#endif
#endif /* MA_ASN_NO_INDEF_LEN */
 
        MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
        "maChkSeq2: Checking Sequence2 Successfully.\n"));
        /* increment the token defination pointer */
        ctlp->sTelDef++;
        RETVALUE(ROK);

     }

     if (ctlp->decode == TRUE)
     {
        teDef = *ctlp->sTelDef;
        mBuf  = ctlp->mBuf;
        eocFlg = FALSE;
        swtch = (U8)ctlp->swtch;

        (Void)SExamMsg(&data, mBuf, 0);

        if (data != MA_TAG_SEQ)
        {
           /* check whether Map versions are compatible */
           if ((ret = maChkEleMand(ctlp) == FALSE))
           {
              /* skip the elmt. in the data base and make as not present *
               * in event str */
               maSkipSeq(ctlp);
               RETVALUE(ROK);
           }
           else
           {
              ctlp->errCode = MAT_DATA_MISSING;
              MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
              "maChkSeq2() failed, mand. data missing.\n"));  
              RETVALUE(RFAILED);
           }
        }

        if ((ret = maFindLen(ctlp->mBuf, 0, &seqLen, &eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPED_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maChkSeq2() failed, fail to get msg len.\n"));  
           RETVALUE(RFAILED);
        }

         /* decode the sequence */
        (Void)SRemPreMsg(&data, mBuf);

        if ((ret = maRemLen(mBuf, &remEocFlg)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maChkSeq2() failed, fail to get msg len.\n"));  
           RETVALUE(RFAILED);
        }

        if (seqLen == 0)
        {
           if ((ret = maChkEleMand(ctlp)) == FALSE)
           {
              maSkipSeq(ctlp);
              if (remEocFlg == TRUE)
              {
                 /* remove the two EOC bytes */
                 if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
                 {
                    ctlp->errCode = MAT_MISTYPE_PARAM;
                    RETVALUE(ret);
                 }
              }
              RETVALUE(ROK);
           }
           else
           {
              ctlp->sTelDef++;
              if((ret = maChkSeqMand(ctlp)) == ROK)
              {
                 if (remEocFlg == TRUE)
                 {
                    if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
                    {
                       ctlp->errCode = MAT_MISTYPE_PARAM;
                       RETVALUE(ret);
                    }
                 }
                 RETVALUE(ROK);
              }
              ctlp->errCode = MAT_DATA_MISSING;
              MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
              "maChkSeq2() failed, mand. data missing.\n"));  
              RETVALUE(RFAILED);
           }
        }

        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maChkSeq2: Check Sequence 2 ...... \n \
        %s Tag [%x] \n", maEleType[teDef->type], data));
        /* increment the data base pointer */
        ctlp->sTelDef++;
        teDef = *ctlp->sTelDef;

        while (teDef->type != MA_TET_SEQ_TERM)
        {
           if (seqLen == 0)
           {
              if (remEocFlg == TRUE)
              {
                 /* remove the two EOC bytes */
                 if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
                 {
                    ctlp->errCode = MAT_MISTYPE_PARAM;
                    RETVALUE(ret);
                 }
              }
              /* reached end of buffer - check for missing mand el */
              RETVALUE(maChkSeqMand(ctlp));
           }

           SFndLenMsg(ctlp->mBuf, &orgMsgLen);
#ifdef MAP_PHASE2_EXT_MARK
           if (teDef->type != MA_TET_EXT_MARK)
           {
#endif
           if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
           {
              ctlp->errCode = MAT_MISTYPED_PARAM;
              MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
              "maChkSeq2() failed, fail to find len.\n"));  
              RETVALUE(RFAILED);
           }
#ifdef MAP_PHASE2_EXT_MARK
           }
           if (teDef->type == MA_TET_EXT_MARK)
           {
              tmpLen = seqLen;
           }
#endif

           switch (teDef->type)
           {
              case MA_TET_U8:
                ret = maDecOctet(ctlp,FALSE);
                break;
              case MA_TET_U8_ENUM:
                ret = maDecOctet(ctlp,TRUE);
                break;
              case MA_TET_NULL:
                ret = maDecNull(ctlp);
                break;
              case MA_TET_INT:
                ret = maDecInt(ctlp);
                break;
              case MA_TET_STR:
              case MA_TET_STRS:
              case MA_TET_STRM:
              case MA_TET_STRE:
#ifdef XWEXT
              case MA_TET_STR4:
#endif
                ret = maDecStr(ctlp);
                break;
              case MA_TET_STRUL:
                ret = maDecStrUL(ctlp);
                break;
              case MA_TET_BITSTR:
                ret = maDecBitStr(ctlp);
                break;
              case MA_TET_SEQ:
              case MA_TET_EXT_CONT:
                if (tmpLen > seqLen)
                {
                   MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
                   "maChkSeq2() failed, invalid seqLen(%d).\n", seqLen));  
                   RETVALUE(RFAILED);
                }
                ret = maDecSeq(ctlp);
                break;
              case MA_TET_SEQ_OF:
                ret = maDecSeqOf(ctlp);
                break;
              case MA_TET_CHOICE:
                ret = maDecChoice(ctlp);
                break;
#ifdef MAP_PHASE2_EXT_MARK
              case MA_TET_EXT_MARK:
               if ((ctlp->maVer == LMA_VER2)  &&
                                 (IS_EQUAL_VER2(teDef->verFlg)))
                {
                  sStrE = (TknStrE *)ctlp->sSt;

                  /* If the remaining length exceeds the *
                   * length of TknStrE */
                  if (seqLen > MF_SIZE_TKNSTRE)
                     RETVALUE(RFAILED);

                  if ((ret = SRemPreMsgMult((U8 *)&sStrE->val[0], seqLen, mBuf)) != ROK)
                  {
                      ctlp->errCode = MAT_MISTYPED_PARAM;
                      RETVALUE(ret);
                  }
/* ma005.203: Addition, Copy the length of Private extensions */
/*                      in Token length filed */
                  sStrE->len = (U8)seqLen;  
                  sStrE->pres = TRUE;
                }
                else
                {
                     maSkipTkns(ctlp);
                }
                break;
#endif
              default:
#if (ERRCLASS & ERRCLS_DEBUG)
                MALOGERROR(ERRCLS_DEBUG, EMA313, (ErrVal)teDef->type, "maDecSeq () Failed");
#endif
                break;
           }
           if (ret != ROK)
           {
              MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
              "maChkSeq2() failed, fail to decode type(%d).\n", teDef->type));  
              RETVALUE(RFAILED);
           }
           SFndLenMsg(ctlp->mBuf,&newMsgLen);
           if (orgMsgLen != newMsgLen)
           {
              seqLen -= (orgMsgLen - newMsgLen);
           }
           teDef = *ctlp->sTelDef;
           if (seqLen < 0)
           {
              ctlp->errCode = MAT_MISTYPED_PARAM;
              MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
              "maChkSeq2() failed, invalid seqLen(%d).\n", seqLen));  
              RETVALUE(RFAILED);
           }
        }

        while(seqLen > 0)
        {
           if ((ret = SRemPreMsg(&data, mBuf)) != ROK)
           {
              ctlp->errCode = MAT_MISTYPE_PARAM;
              RETVALUE(ret);
           }
           seqLen--;
        }

        if (remEocFlg == TRUE)
        {
           /* remove the two EOC bytes */
           if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
           {
              ctlp->errCode = MAT_MISTYPE_PARAM;
              RETVALUE(ret);
           }
        }
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maChkSeq2: Checking Sequence 2 Successfully.\n"));
        ctlp->sTelDef++;
        RETVALUE(ROK);
     }
  }

  RETVALUE(ROK);
} /* maChkSeq2  */
#if MAP_REL99

#if MAP_REL4
/*
*
*       Fun:   maChkReqNodeType    
*
*       Desc:  This function encodes/decodes/skip requesting node type
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkReqNodeType 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkReqNodeType (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkReqNodeType)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if ((sSt->val >= 2) && (sSt->val <= 15))
    {
       sSt->val = MAT_VLR;
    }
    if (sSt->val > 15)
    {
       sSt->val = MAT_SGSN;
    }

    /* initialize the event structure */
    sSt->pres = TRUE;

    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkReqNodeType  */

/*
*
*       Fun:   maChkTermCause    
*
*       Desc:  This function encodes/decodes/skip Termation cause
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkTermCause 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkTermCause (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkTermCause)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */

    if (sSt->val >= teDef->elist[0][0])
    {
       sSt->val = MAT_ERROR_UNDEFINED;
    }

    /* initialize the event structure */
    sSt->pres = TRUE;

    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkTermCause  */

/*
*
*       Fun:   maChkAccessType    
*
*       Desc:  This function encodes/decodes/skip Access type
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkAccessType 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkAccessType (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkAccessType)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if (sSt->val < teDef->elist[0][0])
    {
       sSt->pres = TRUE;
    }
    else 
    {
       sSt->pres = FALSE;
    }

    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkAccessType  */

/*
*
*       Fun:   maChkPslDefLocEventType 
*
*       Desc:  This function decodes DeferredLocationEventType.
*              If a ProvideSubscriberLocation-Arg containing an 
*              unrecognized DeferredLocationEventType, MAP returns the
*              MA_UNRECOGNIZED_VALUE to the MAP user. The MAP user 
*              should reject this request with a return error cause of 
*              unexpected data value.
*
*       Ret:   ROK 
*
*       Notes: This function decodes only 8 bit enumerated bit
*              string. 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkPslDefLocEventType 
(
MaMsgCtl    *ctlp       /* message control structure */
)
#else
PUBLIC S16 maChkPslDefLocEventType (ctlp) 
MaMsgCtl    *ctlp;      /* message control structure */
#endif
{
  Buffer        *mBuf;
  MaTknElmtDef  *teDef;
  TknStrS       *dStS;
  Data          data;
  Data          tmpData;
  Data          uBits;
  Bool          eocFlg;
  U8            i;
  S16           ret;
  Data          unPkArray[MA_MAX_PKARRAY_LEN];
  Bool          unExpected;

  TRC2(maChkPslDefLocEventType)

  mBuf = ctlp->mBuf;
  teDef = *ctlp->sTelDef;
  dStS = (TknStrS *) NULLP;

  if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    RETVALUE(ret);
  }
  if (data != teDef->tag)
  {
    if ((ret = maChkEleMand(ctlp) == FALSE))
    {
      /* skip the element in the data base and make as not present 
       * in event str */
      ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
      ((TknStrS *)(ctlp->sSt))->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
      /* bump structure pointer in message control */
      MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
      RETVALUE(ROK);
    }
    else
    {
       ctlp->errCode = MAT_DATA_MISSING;
       MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
       "maChkPslDefLocEventType() failed, data missing.\n"));
       RETVALUE(RFAILED);
    }
  }

  dStS = (TknStrS *)(ctlp->sSt);

  /* tag is in first position and always 8 bit */
  if ((ret = SExamMsg(&data, mBuf, 1)) != ROK)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    RETVALUE(ret);
  }

  if (!(data & 0x80))
  {
     eocFlg = FALSE;
  }
  else if (data == 0x80)
  {
    eocFlg = TRUE; 
  }
  else
  {
     /* this function is used to encode only 8 bit enumerated bit string
      * so in most cases the length will be encoede in short form. But
      * it is valid to encode using the indefinate form. But long form
      * definate encoding can't be used as it will not satisfy the the
      * condition of using minimum bytes to encode the length. */
     ctlp->errCode = MAT_MISTYPE_PARAM;
     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maChkPslDefLocEventType() failed, mistype param.\n"));
     RETVALUE(RFAILED);
  }

  /* remove one byte length tag and unused bits octet */

  if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)4, mBuf)) != ROK)
  {
     ctlp->errCode = MAT_MISTYPE_PARAM;
     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maChkPslDefLocEventType() failed, mistype param.\n"));
     RETVALUE(RFAILED);
  }
  /* remove the bit string value */
  uBits = unPkArray[2];

  {
     U8 no_of_octets; /* number of octets */
     U8 octet_index;  /* index into the octet array */
     U8 shift;        /* temporary variable */

     no_of_octets = unPkArray[1] - 1;

     if ( (U8)((no_of_octets)*8 - uBits) < teDef->minLen || 
          (U8)((no_of_octets)*8 - uBits) > teDef->maxLen)
     {
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maChkPslDefLocEventType() failed, invalid param.\n"));
        RETVALUE(RFAILED);
     }

     if(no_of_octets > 1)
     {
        if ((ret = SRemPreMsgMult(&unPkArray[4], (MsgLen)(no_of_octets-1), 
                   mBuf)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maChkPslDefLocEventType() failed, mistype param.\n"));
           RETVALUE(RFAILED);
        }
     }
     
     octet_index = 0;
     i=0;
     unExpected = FALSE;

     while(octet_index < (no_of_octets - 1))
     {
        data = unPkArray[3+octet_index];
        unExpected =((data|MA_DLET_BYTE1_MASK)!=MA_DLET_BYTE1_MASK)?TRUE:FALSE;

        /* allocate string */
        for(shift=0;shift< 8 ;shift++,i++)
        {
           tmpData = data &0x80;
           dStS->val[i] = tmpData >> 7;
           data <<=1;
        }
        octet_index ++;
     }
     data = unPkArray[3+octet_index];
     unExpected =((data|MA_DLET_BYTE2_MASK)!=MA_DLET_BYTE2_MASK)?TRUE:FALSE;

     for(shift = 0;shift<(U8) (8 - uBits);shift++,i++)
     {
       tmpData = data &0x80;
       dStS->val[i] = tmpData >> 7;
       data <<=1;
     }
     if (unExpected == TRUE)
     {
        dStS->val[0] = MA_UNRECOGNIZED_VALUE;
     }
     dStS->pres = TRUE;
     dStS->len  = i;
  }

  if (eocFlg == TRUE)
  {
    /* remove the two EOC tag byets */

    if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }
  }


  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkPslDefLocEventType: %s Tag [%x] Len [%x] shift [%x] \n", 
          maEleType[teDef->type], data, unPkArray[1], unPkArray[2]));

  /* increment the data base pointer and event struct. pointer */
  ctlp->sTelDef++;
  MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 

  RETVALUE(ROK);
} /* maChkPslDefLocEventType */

#endif /* MAP_REL4 */

/*
*
*       Fun:   maChkIstSupInd    
*
*       Desc:  This function encodes/decodes/skip IST Support Indicator
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkIstSupInd 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkIstSupInd (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkIstSupInd)

  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkIstSupInd() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if (sSt->val > 1)
    {
       sSt->val = MAT_IST_COMMAND_SUPPORTED;
    }

    sSt->pres = TRUE;

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkIstSupInd: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkIstSupInd  */

/*
*
*       Fun:   maChkKeyStatus    
*
*       Desc:  This function encodes/decodes/skip Key Status
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkKeyStatus 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkKeyStatus (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkKeyStatus)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkKeyStatus() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if ((sSt->val >= 2) && (sSt->val <= 31))
    {
       sSt->val = MAT_OLD;
    }
    if (sSt->val > 31)
    {
       sSt->val = MAT_NEW;
    }

    /* initialize the event structure */
    sSt->pres = TRUE;

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkKeyStatus: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkKeyStatus  */

/*
*
*       Fun:   maChkDefGprsHandl    
*
*       Desc:  This function encodes/decodes/skip default GPRS call handling
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkDefGprsHandl 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkDefGprsHandl (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkDefGprsHandl)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkDefGprsHandl() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if ((sSt->val >= 2) && (sSt->val <= 31))
    {
       sSt->val = MAT_GPRS_CONTINUE_TRANSACTION;
    }
    if (sSt->val > 31)
    {
       sSt->val = MAT_GPRS_RELEASE_TRANSACTION;
    }

    /* initialize the event structure */
    sSt->pres = TRUE;

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkDefGprsHandl: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkDefGprsHandl  */


/*
*
*       Fun:   maChkDefSmsHandl    
*
*       Desc:  This function encodes/decodes/skip default SMS call handling
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkDefSmsHandl 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkDefSmsHandl (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkDefSmsHandl)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkDefSmsHandl() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if ((sSt->val >= 2) && (sSt->val <= 31))
    {
       sSt->val = MAT_CONTINUE_TRANSACTION;
    }
    if (sSt->val > 31)
    {
       sSt->val = MAT_RELEASE_TRANSACTION;
    }

    /* initialize the event structure */
    sSt->pres = TRUE;

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkDefSmsHandl: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkDefSmsHandl  */

/*
*
*       Fun:   maChkCallTermInd    
*
*       Desc:  This function encodes/decodes/skip default call handling
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkCallTermInd 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkCallTermInd (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkCallTermInd)

  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkCallTermInd() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if ((sSt->val >= 2) && (sSt->val <= 10))
    {
       sSt->val = MAT_TERM_CALL_ACTV_REF; 
    }
    if (sSt->val > 10)
    {
       sSt->val = MAT_TERM_ALL_ACTV;
    }

    /* initialize the event structure */
    sSt->pres = TRUE;

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkCallTermInd: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkCallTermInd  */

/*
*
*       Fun:   maChkGprsTrigDetPt    
*
*       Desc:  This function encodes/decodes/skip the TBCSM Trigger 
*              Detection Point tokens  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkGprsTrigDetPt 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkGprsTrigDetPt (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkGprsTrigDetPt)

  if (ctlp->decode == TRUE)
  {
     teDef = *ctlp->sTelDef;
     sSt   = (TknU8 *)ctlp->sSt;
     mBuf  = ctlp->mBuf;

     if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
     { 
        ctlp->errCode = MAT_MISTYPE_PARAM;
        RETVALUE(ret);
     }

     if (data != teDef->tag)
     {
        /* check whether Map versions are compatible */
        if ((ret = maChkEleMand(ctlp) == FALSE))
        {
           /* skip the element in the data base and make as not */
           /* present in event str. */
           ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
           sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
           /* bump structure pointer in message control */
           MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
           RETVALUE(ROK);
        }
        else
        {
           ctlp->errCode = MAT_DATA_MISSING;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maChkGprsTrigDetPt() failed, mand. data missing.\n"));  
           RETVALUE(RFAILED);
        }
     }

     /* remove the octet */
     if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
     {
        ctlp->errCode = MAT_MISTYPED_PARAM;
        RETVALUE(ret);
     }

     /* exception handling */
     if ((sSt->val != MAT_ATTACH) && 
         (sSt->val != MAT_ATTACH_CHANGE_OF_POSITION) && 
         (sSt->val != MAT_PDP_CONTEXT_ESTABLISHMENT) && 
         (sSt->val != MAT_PDP_CONTEXT_ESTABLISHMENT_ACK) && 
         (sSt->val != MAT_PDP_CONTEXT_CHANGE_OF_POSITION))
     {
        ret = MA_SKIP_SEQ;
        RETVALUE(ret);
     }

     /* initialize the event structure */
     sSt->pres = TRUE;

     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maChkGprsTrigDetPt: %s Tag [%x] Len [%x] Val [%x] \n", 
     maEleType[teDef->type], data, tmpLen, sSt->val));
     /* bump structure pointer in message control */
     MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
     ctlp->sTelDef++;
     RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkGprsTrigDetPt  */

/*
*
*       Fun:   maChkSmsTrigDetPt    
*
*       Desc:  This function encodes/decodes/skip the TBCSM Trigger 
*              Detection Point tokens  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkSmsTrigDetPt 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkSmsTrigDetPt (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkSmsTrigDetPt)

  if (ctlp->decode == TRUE)
  {
     teDef = *ctlp->sTelDef;
     sSt   = (TknU8 *)ctlp->sSt;
     mBuf  = ctlp->mBuf;

     if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
     { 
        ctlp->errCode = MAT_MISTYPE_PARAM;
        RETVALUE(ret);
     }

     if (data != teDef->tag)
     {
        /* check whether Map versions are compatible */
        if ((ret = maChkEleMand(ctlp) == FALSE))
        {
           /* skip the element in the data base and make as not */
           /* present in event str. */
           ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
           sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
           /* bump structure pointer in message control */
           MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
           RETVALUE(ROK);
        }
        else
        {
           ctlp->errCode = MAT_DATA_MISSING;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maChkSmsTrigDetPt() failed, mand. data missing.\n"));  
           RETVALUE(RFAILED);
        }
     }

     /* remove the octet */
     if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
     {
        ctlp->errCode = MAT_MISTYPED_PARAM;
        RETVALUE(ret);
     }

     /* exception handling */
#if MAP_REL5
     if ((sSt->val != MAT_SMS_COLLECTED_INFO) &&
         (sSt->val != MAT_SMS_DELIVERY_REQUEST)) 
#else
     if (sSt->val != MAT_SMS_COLLECTED_INFO)
#endif
     {
        ret = MA_SKIP_SEQ;
        RETVALUE(ret);
     }

     /* initialize the event structure */
     sSt->pres = TRUE;

     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maChkSmsTrigDetPt: %s Tag [%x] Len [%x] Val [%x] \n", 
     maEleType[teDef->type], data, tmpLen, sSt->val));
     /* bump structure pointer in message control */
     MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
     ctlp->sTelDef++;
     RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkSmsTrigDetPt  */

/*
*
*       Fun:   maChkAccNetProtId    
*
*       Desc:  This function encodes/decodes/skip default call handling
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkAccNetProtId 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkAccNetProtId (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkAccNetProtId)
 
  if (ctlp->decode == TRUE)
  {
     teDef = *ctlp->sTelDef;
     sSt   = (TknU8 *)ctlp->sSt;
     mBuf  = ctlp->mBuf;

     if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
     { 
        ctlp->errCode = MAT_MISTYPE_PARAM;
        RETVALUE(ret);
     }

     if (data != teDef->tag)
     {
        /* check whether Map versions are compatible */
        if ((ret = maChkEleMand(ctlp) == FALSE))
        {
           /* skip the element in the data base and make as not */
           /* present in event str. */
           ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
           sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
           /* bump structure pointer in message control */
           MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
           RETVALUE(ROK);
        }
        else
        {
           ctlp->errCode = MAT_DATA_MISSING;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maChkAccNetProtId () failed, mand. data missing.\n"));  
           RETVALUE(RFAILED);
        }
     }

     /* remove the octet */
     if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
     {
        ctlp->errCode = MAT_MISTYPED_PARAM;
        RETVALUE(ret);
     }

     /* exception handling */
     if ((sSt->val != MAT_ACC_GSM_0806) && 
         (sSt->val != MAT_TS3G_25413))
     {
        ret = MA_SKIP_SEQ;
        RETVALUE(ret);
     }

     /* initialize the event structure */
     sSt->pres = TRUE;

     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maChkAccNetProtId: %s Tag [%x] Len [%x] Val [%x] \n", 
     maEleType[teDef->type], data, tmpLen, sSt->val));
     /* bump structure pointer in message control */
     MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
     ctlp->sTelDef++;
     RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkAccNetProtId  */

/* Version compatibility escape function */


/*
*
*       Fun:   maChkSeq0    
*
*       Desc:  This function encodes/decodes/skip SndIdReqSeq and 
*              AuthInfoReqSeq
*
*       Ret:   ROK 
*
*       Notes: Ver2P: Seq , 
*              Ver2:  single element (Strs)
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkSeq0 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkSeq0 (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  MaTknElmtDef  *teDef;    /* element definition */
  MaTknElmtDef  **tmpDef;  /* temporory element definition */
  TknStrS       *tmpSst;   /* temporary pointer */
  S16           ret;       /* return value */
  U16           i;         /* counter */
  TknStrS       *strS;     /* token string size - small */
  U8            len;
  MsgLen        tmpLen;
  U8            *val;
  Data          pkArray[MA_MAX_PKARRAY_LEN];
  Data          data;
  Buffer        *mBuf;

  TRC2 (maChkSeq0)

  /* For version 2p operation, encode/decode/skip entire seq */

  if (ctlp->maVer == LMA_VER2P)
  {
     if (ctlp->skip == TRUE)
     {
        ret = maSkipSeq(ctlp);
        RETVALUE(ret);
     }

     if (ctlp->encode == TRUE)
     {
        ret = maEncEscSeq(ctlp);
        RETVALUE(ret);
     }

     if (ctlp->decode == TRUE)
     {
        ret = maDecEscSeq(ctlp);
        RETVALUE(ret);
     }
  }

  /* For version 2 operation, encode/decode/skip IMSI */

  if (ctlp->maVer == LMA_VER2)
  {
     if (ctlp->skip == TRUE)
     {
        ret = maSkipSeq(ctlp); 
        RETVALUE(ret);
     }

     if (ctlp->encode == TRUE)
     {
        tmpDef = ctlp->sTelDef;         /* Store the element definition */
        tmpSst = (TknStrS *) ctlp->sSt; /* Store the token pointer */

        /* increment the token pointer over the start of sequence */
        ctlp->sTelDef++;
        teDef = *ctlp->sTelDef;

        /* check element for protocol type and mandatory/optional flags */
        if ((ret = maChkEncElmnt(ctlp)) != ROK)
        {
           if (ret == RSKIP)
           {
              RETVALUE(ROK);
           }
           RETVALUE(ret);
        }

        len = tmpSst->len;
        val = &tmpSst->val[0];

        /* validate the length */
        if ( (len < teDef->minLen) || (len >teDef->maxLen))
        {
           MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
           "maChkSeq0() failed, invalid len(%d).\n", len));  
           RETVALUE(RFAILED);
        }

        /* encode the Universal tag of string and string length */
        pkArray[0] = MA_TAG_OCTSTR;
        pkArray[1] = (Data)len;
        tmpLen = 2;
        MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
        "maChkSeq0: Checking Sequence 0 ...... \n \
        %s Tag [%x] Len [%x]\n",
        maEleType[teDef->type], pkArray[0], pkArray[1]));

        /* encode the value  */ 
        for (i=0; i<len; i++, val++)
        {
           pkArray[tmpLen +i] = *val;
        }

        ret = SAddPstMsgMult(pkArray, (MsgLen)(tmpLen + len), ctlp->mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
        if (ret != ROK)
        {
           MALOGERROR(ERRCLS_ADD_RES, EMA314, (ErrVal)ret, "SAddPstMsgMult() Failed");
           RETVALUE(ret);
        }
#endif

        /* return structure pointer and element definition pointer to *
         * the start of this sequence, and skip the whore sequence.   */
        ctlp->sTelDef = tmpDef;
        ctlp->sSt     = (U8 *)tmpSst;
        maSkipSeq(ctlp); 
        MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
        "maChkSeq0: Check Sequence 0 Successfully.\n"));
    
        RETVALUE(ROK);
     }

     if (ctlp->decode == TRUE)
     {
        tmpDef = ctlp->sTelDef;         /* Store the element definition */
        ctlp->sTelDef++;
        tmpSst = (TknStrS *) ctlp->sSt; /* Store the token pointer */

        mBuf  = ctlp->mBuf;

        if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           RETVALUE(ret);
        }

        if (data != MA_TAG_OCTSTR)
        {
           ctlp->errCode = MAT_DATA_MISSING;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maChkSeq0() failed, mand. data missing.\n"));  
           RETVALUE(RFAILED);
        }

        strS = (TknStrS *)ctlp->sSt;
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maChkSeq0: Checking Sequence 0 ...... \n \
        %s Tag [%x] \n", maEleType[(*tmpDef)->type], data));
        if (( ret = maRemPrim(mBuf, ctlp, (U8 *)&strS->val[0], (U8 *)&strS->len)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPED_PARAM;
           RETVALUE(ret);
        }

        strS->pres = TRUE;

        /* move structure pointer and element definition pionter to *
         * start of this sequence, and skip whore sequence.         */
        ctlp->sTelDef = tmpDef;
        ctlp->sSt     = (U8 *)tmpSst;
        maSkipSeq(ctlp);
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maChkSeq0: Check Sequence 0  Successfully.\n"));

        RETVALUE(ROK);
     }
  }
 
   /* ma001.202 : modified the return value */
  RETVALUE(RFAILED);
} /* maChkSeq0  */


/*
*
*       Fun:   maChkSeq1    
*
*       Desc:  This function encodes/decodes/skip AuthInfoRspSeq,
*              FwdAccSigReqSeq, SndEndSigReqSeq, ProcAccSigReqSeq,
*              PreSubsHoRspSeq.
*
*       Ret:   ROK 
*
*       Notes: Ver2P: Seq, tag [3]
*              Ver2:  single element (seqof/seq)
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkSeq1 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkSeq1 (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  MaTknElmtDef  *teDef;    /* element definition */
  MaTknElmtDef  **tmpDef;  /* temporory element definition */
  TknStrS       *tmpSst;   /* temporary pointer */
  S16           ret;       /* return value */
  Data          data;
  Buffer        *mBuf;

  TRC2 (maChkSeq1)

  /* For version 2p operation, encode/decode/skip entire seq */

  if (ctlp->maVer == LMA_VER2P)
  {
     if (ctlp->skip == TRUE)
     {
        ret = maSkipSeq(ctlp);
        RETVALUE(ret);
     }

     if (ctlp->encode == TRUE)
     {
        ret = maEncEscSeq(ctlp);
        RETVALUE(ret);
     }

     if (ctlp->decode == TRUE)
     {
        ret = maDecEscSeq(ctlp);
        RETVALUE(ret);
     }
  }

  /* For version 2 operation, encode/decode/skip  authSetLst */

  else /* if (ctlp->maVer == LMA_VER2) */
  {
     if (ctlp->skip == TRUE)
     {
        maSkipSeq(ctlp);   
        RETVALUE(ROK);
     }

     tmpDef = ctlp->sTelDef;         /* Store the element definition */
     tmpSst = (TknStrS *) ctlp->sSt; /* Store the token pointer */

     /* increment the token pointer over the start of sequence */
     ctlp->sTelDef++;
     teDef = *ctlp->sTelDef;

     if (ctlp->encode == TRUE)
     {
        /* check element for protocol type and mandatory/optional flags */
        if ((ret = maChkEncElmnt(ctlp)) != ROK)
        {
           if (ret == RSKIP)
           {
              /* skip in the data base and make as not present in event str */
              /* move structure pointer and element definition pionter to *
               * start of this sequence, and skip whore sequence.         */
              ctlp->sTelDef = tmpDef;
              ctlp->sSt     = (U8 *)tmpSst;
              maSkipSeq(ctlp);
              RETVALUE(ROK);
           }
           RETVALUE(ret);
        }
        MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
        "maChkSeq1: Checking Sequence 1 ...... \n \
        %s\n", maEleType[teDef->type]));
        switch(teDef->type)
        {
           case MA_TET_SEQ:
           case MA_TET_EXT_CONT:
#ifdef MAP_PHASE2_EXT_MARK
           case MA_TET_EXT_MARK:
#endif
             ret = maEncSeq(ctlp);
             break;
           case MA_TET_SEQ_OF:
             ret = maEncSeqOf(ctlp,teDef->repCntr, ctlp->sTelDef);
             break;
        }
        if ((ret != ROK) && (ret != EMP_SEQ) && (ret != NON_EMP_SEQ))
        {
           MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
           "maChkSeq1() failed, fail to encode seq/seqof(%d).\n", teDef->type));  
           RETVALUE(RFAILED);
        }

        /* return structure pointer and element definition pointer to *
         * the start of this sequence, and skip the whore sequence.   */
        ctlp->sTelDef = tmpDef;
        ctlp->sSt     = (U8 *)tmpSst;
        maSkipSeq(ctlp); 
        MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
        "maChkSeq1: Checking Sequence 1 Successfully.\n"));
    
        RETVALUE(ROK);
     }

     if (ctlp->decode == TRUE)
     {

        mBuf  = ctlp->mBuf;
        /* check whether Map versions are compatible */
        if ( (ctlp->maVer == LMA_VER1  && !(IS_EQUAL_VER1(teDef->verFlg))) ||
             (ctlp->maVer == LMA_VER2  && !(IS_EQUAL_VER2(teDef->verFlg))) ||
             (ctlp->maVer == LMA_VER2P && !(IS_EQUAL_VER2P(teDef->verFlg)))|| 
             (ctlp->maVer == LMA_VER4  && !(IS_EQUAL_VER4(teDef->verFlg)))    
            )
        {
          /* skip in the data base and make as not present in event str */
          /* move structure pointer and element definition pionter to *
           * start of this sequence, and skip whore sequence.         */
           ctlp->sTelDef = tmpDef;
           ctlp->sSt     = (U8 *)tmpSst;
           maSkipSeq(ctlp);
           RETVALUE(ROK);
        }

        if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           RETVALUE(ret);
        }
        if (data != MA_TAG_SEQ)
        {
           ctlp->errCode = MAT_DATA_MISSING;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maChkSeq1() failed, mand. data missing.\n"));  
           RETVALUE(RFAILED);
        }
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maChkSeq1: Checking Sequence 1 ...... \n \
        %s Tag [%x] \n", maEleType[teDef->type], data));

        switch(teDef->type)
        {
           case MA_TET_SEQ:
           case MA_TET_EXT_CONT:
#ifdef MAP_PHASE2_EXT_MARK
           case MA_TET_EXT_MARK:
#endif
             ret = maDecSeq(ctlp);
             break;
           case MA_TET_SEQ_OF:
             ret = maDecSeqOf(ctlp);
             break;
        }
        if (ret != ROK)
        {
          MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
          "maChkSeq1() failed, fail to decode seq/seqof(%d).\n", teDef->type));  
          RETVALUE(RFAILED);
        }

        /* move structure pointer and element definition pionter to *
         * start of this sequence, and skip whore sequence.         */
        ctlp->sTelDef = tmpDef;
        ctlp->sSt     = (U8 *)tmpSst;
        maSkipSeq(ctlp);
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maChkSeq1: Check Sequence 1  Successfully.\n"));

        RETVALUE(ROK);
     }
  }

  RETVALUE(ROK);
} /* maChkSeq1  */

/* Added an escape function to handle ChkIMEIRsp version changes */
#if MAP_REL5
/*
*
*       Fun:   maChkSeq3    
*
*       Desc:  This function encodes/decodes/skip ChkIMEIRspSeq
*
*       Ret:   ROK 
*
*       Notes: Ver2P: Seq , 
*              Ver2:  single element (Bit Strs)
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkSeq3 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkSeq3 (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  MaTknElmtDef  *teDef;    /* element definition */
  MaTknElmtDef  **tmpDef;  /* temporory element definition */
  TknStrS       *tmpSst;   /* temporary pointer */
  S16           ret;       /* return value */

  TRC2 (maChkSeq3)

  /* For version 2p operation, encode/decode/skip entire seq */

  if (ctlp->maVer == LMA_VER2P)
  {
     if (ctlp->skip == TRUE)
     {
        ret = maSkipSeq(ctlp);
        RETVALUE(ret);
     }

     if (ctlp->encode == TRUE)
     {
        ret = maEncEscSeq(ctlp);
        RETVALUE(ret);
     }

     if (ctlp->decode == TRUE)
     {
        ret = maDecEscSeq(ctlp);
        RETVALUE(ret);
     }
  }

  /* For version 2 operation, encode/decode/skip eqpStat */

  if ((ctlp->maVer == LMA_VER2) || (ctlp->maVer == LMA_VER1))
  {
     if (ctlp->skip == TRUE)
     {
        ret = maSkipSeq(ctlp); 
        RETVALUE(ret);
     }

     if (ctlp->encode == TRUE)
     {
        tmpDef = ctlp->sTelDef;         /* Store the element definition */
        tmpSst = (TknStrS *) ctlp->sSt; /* Store the token pointer */

        /* increment the token pointer over the start of sequence */
        ctlp->sTelDef++;
        teDef = *ctlp->sTelDef;

        switch(teDef->type)
        {
           case MA_TET_U8_ENUM:
             ret = maEncOctet(ctlp,TRUE);
             break;
           case MA_TET_STRS:
#ifdef XWEXT
           case MA_TET_STR4:
#endif
             ret = maEncStr(ctlp);
             break;
           default:
             ret = RFAILED;
             break;
        }
        if (ret != ROK)
        {
           MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf,
           "maChkSeq3() failed, invalid encoding type(%d)\n", teDef->type));
#if (ERRCLASS & ERRCLS_ADD_RES)
           MALOGERROR(ERRCLS_ADD_RES,EMA315,(ErrVal)ret,"maChkSeq3() Failed");
#endif
           RETVALUE(RFAILED);
        }


        /* return structure pointer and element definition pointer to *
         * the start of this sequence, and skip the whore sequence.   */
        ctlp->sTelDef = tmpDef;
        ctlp->sSt     = (U8 *)tmpSst;
        maSkipSeq(ctlp); 
        MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
        "maChkSeq3: Check Sequence 3 Successfully.\n"));
    
        RETVALUE(ROK);
     }

     if (ctlp->decode == TRUE)
     {
        tmpDef = ctlp->sTelDef;         /* Store the element definition */
        ctlp->sTelDef++;
        tmpSst = (TknStrS *) ctlp->sSt; /* Store the token pointer */

        teDef = *ctlp->sTelDef;

        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maChkSeq3: Checking Sequence 3 ...... \n \
        %s \n", maEleType[(*tmpDef)->type]));

        switch(teDef->type)
        {
           case MA_TET_U8_ENUM:
             ret = maDecOctet(ctlp,TRUE);
             break;
           case MA_TET_STRS:
#ifdef XWEXT
           case MA_TET_STR4:
#endif
             ret = maDecStr(ctlp);
             break;
           default:
             ret = RFAILED;
             break;
        }
        if (ret != ROK)
        {
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maChkSeq3() failed, fail to decode msg type(%d).\n", teDef->type));
#if (ERRCLASS & ERRCLS_ADD_RES)
           MALOGERROR(ERRCLS_ADD_RES,EMA316,(ErrVal)ret,"maChkSeq3() Failed");
#endif
           RETVALUE(ret);
        }

        /* move structure pointer and element definition pionter to *
         * start of this sequence, and skip whore sequence.         */
        ctlp->sTelDef = tmpDef;
        ctlp->sSt     = (U8 *)tmpSst;
        maSkipSeq(ctlp);
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maChkSeq3: Check Sequence 3  Successfully.\n"));

        RETVALUE(ROK);
     }
  }
 

  RETVALUE(ROK);
} /* maChkSeq3  */
#endif /* MAP_REL5 */

/*
*
*       Fun:   maChkLocEstiType    
*
*       Desc:  This function encodes/decodes/skip default call handling
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkLocEstiType 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkLocEstiType (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkLocEstiType)

  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkLocEstiType() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
#if MAP_REL4
#if MAP_REL99
    if ((sSt->val != MAT_CURRENT_LOCATION) && 
        (sSt->val != MAT_CURRENT_OR_LAST_KNOWN_LOCATION) &&
        (sSt->val != MAT_INITIA_LOCATION) &&
        (sSt->val != MAT_ACTV_DEFER_LOCATION) &&
        (sSt->val != MAT_CANCEL_DEFER_LOCATION))
#endif
#else  /* MAP_REL4 */
    if ((sSt->val != MAT_CURRENT_LOCATION) && 
        (sSt->val != MAT_CURRENT_OR_LAST_KNOWN_LOCATION) &&
        (sSt->val != MAT_INITIA_LOCATION))
#endif
    {
       sSt->val = MA_UNRECOGNIZED_VALUE;
    }

    /* initialize the event structure */
    sSt->pres = TRUE;

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkLocEtsiType: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkLocEstiType  */

/*
*
*       Fun:   maChkLcsClientType    
*
*       Desc:  This function encodes/decodes/skip default call handling
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkLcsClientType 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkLcsClientType (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkLcsClientType)

  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkLcsClientType() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if ((sSt->val != MAT_EMERGENCY_SERVICES) && 
        (sSt->val != MAT_VALUE_ADDED_SERVICE) &&
        (sSt->val != MAT_PLMN_OPERATOR_SERVICE) &&
        (sSt->val != MAT_LAWFUL_INTERCEPT_SERVICES))
    {
       sSt->val = MA_UNRECOGNIZED_VALUE;
    }

    /* initialize the event structure */
    sSt->pres = TRUE;

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkLcsClientType: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkLcsClientType  */

/* Addition: upgrade for MAP release 6 */
#if MAP_REL99
#if MAP_REL6
/*
*
*       Fun:  maChkPrivacyRelAction
*
*       Desc:  This function encodes/decodes/skip default call handlin
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  ca_mf.c
*
*/

#ifdef ANSI
PUBLIC S16 maChkPrivacyRelAction
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkPrivacyRelAction (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
   Buffer        *mBuf;
   S16           ret;
   MaTknElmtDef  *teDef;
   TknU8         *sSt;
   Data          data;
   U8            tmpLen;

   TRC2 (maChkPrivacyRelAction)

   if (ctlp->decode == TRUE)
   {
       teDef = *ctlp->sTelDef;
       sSt   = (TknU8 *)ctlp->sSt;
       mBuf  = ctlp->mBuf;

       if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
       {
          ctlp->errCode = MAT_MISTYPE_PARAM;
          RETVALUE(ret);
          
       }

       if (data != teDef->tag)
       {
          /* check whether Map versions are compatible */
          if ((ret = maChkEleMand(ctlp) == FALSE))
          {
             /* skip the element in the data base and make as not */
             /* present in event str. */
             ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
             sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
             /* bump structure pointer in message control */
             MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8));
             RETVALUE(ROK);
          }
          else
          {
             ctlp->errCode = MAT_DATA_MISSING;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf,
             "maChkPrivacyRelAction() failed, mand. data missing.\n"));
             RETVALUE(RFAILED);
          }
        }

       /* remove the octet */
       if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPED_PARAM;
           RETVALUE(ret);
        }
         
    /* exception handling */
    if ((sSt->val == MAT_ALLOWED_WITHOUT_NOTIFICATION) ||
        (sSt->val == MAT_ALLOWED_WITH_NOTIFICATION) ||
        (sSt->val == MAT_ALLOWED_IF_NO_RSP) ||
        (sSt->val == MAT_RST_IF_NO_RSP) ||
        (sSt->val == MAT_NOT_ALLOWED))
    {
       sSt->pres = TRUE;
    }
    else
    {
       sSt->pres = FALSE;
    }
   
         /* initialize the event structure */
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf,
         "maChkPrivacyRelAction: %s Tag [%x] Len [%x] Val [%x] \n",
          maEleType[teDef->type], data, tmpLen, sSt->val));
         /* bump structure pointer in message control */
         MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8));
         ctlp->sTelDef++;
         RETVALUE(ROK);
    }

   RETVALUE(ROK);
} /* maChkPrivacyRelAction */


/*
*
*       Fun:   maChkAddNwRes    
*
*       Desc:  This function encodes/decodes/skip Additional Network 
*              Resources.
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkAddNwRes 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkAddNwRes(ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkAddNwRes)
  
  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
    if (sSt->val < teDef->elist[0][0])
    {
       sSt->pres = TRUE;
    }
    else 
    {
       sSt->pres = FALSE;
    }

    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);

} /* maChkAddNwRes */
#endif /* MAP_REL6 */
#endif /* MAP_REL99 */

/*
*
*       Fun:   maChkLcsEvent    
*
*       Desc:  This function encodes/decodes/skip default call handling
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkLcsEvent 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkLcsEvent (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  Buffer        *mBuf;
  S16           ret;
  MaTknElmtDef  *teDef;
  TknU8         *sSt;
  Data          data;
  U8            tmpLen;

  TRC2 (maChkLcsEvent)

  if (ctlp->decode == TRUE)
  {
    teDef = *ctlp->sTelDef;
    sSt   = (TknU8 *)ctlp->sSt;
    mBuf  = ctlp->mBuf;

    if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }

    if (data != teDef->tag)
    {
      /* check whether Map versions are compatible */
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make as not */
        /* present in event str. */
        ctlp->sTelDef++;
#ifndef MA_MULT_SEG_DECODE
        sSt->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
        RETVALUE(ROK);
      }
      else
      {
         ctlp->errCode = MAT_DATA_MISSING;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkLcsEvent() failed, mand. data missing.\n"));  
         RETVALUE(RFAILED);
      }
    }

    /* remove the octet */
    if (( ret = maRemPrim(mBuf, ctlp, (U8 *)(&(sSt->val)), &tmpLen)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPED_PARAM;
       RETVALUE(ret);
    }

    /* exception handling */
#if MAP_REL4
#if MAP_REL99
    if ((sSt->val != MAT_EMERG_CALL_OR_ORIG) && 
        (sSt->val != MAT_EMERG_CALL_RELEASE) &&
        (sSt->val != MAT_MO_LR) &&
        (sSt->val != MAT_DEFER_MT_RES))
#endif
#else  /* MAP_REL4 */
    if ((sSt->val != MAT_EMERG_CALL_OR_ORIG) && 
        (sSt->val != MAT_EMERG_CALL_RELEASE) &&
        (sSt->val != MAT_MO_LR))
#endif
    {
       sSt->val = MA_UNRECOGNIZED_VALUE;
    }

    /* initialize the event structure */
    sSt->pres = TRUE;

    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maChkLcsEvent: %s Tag [%x] Len [%x] Val [%x] \n", 
    maEleType[teDef->type], data, tmpLen, sSt->val));
    /* bump structure pointer in message control */
    MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknU8)); 
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkLcsEvent  */

#endif /* MAP_REL99 */

/*
*
*       Fun:   maChkVerStr    
*
*       Desc:  This function encodes/decodes/skip default call handling
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkVerStr 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkVerStr (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  MaTknElmtDef  *teDef;
  TknStrS       *strS;   /* token string size - small */
  U8            len;
  MsgLen        tmpLen;
  U8            *val;
  S16           ret;
  U8            i;
  Data          pkArray[MA_MAX_PKARRAY_LEN];
  Data          data;
  Buffer        *mBuf;

  TRC2 (maChkVerStr)

  if (ctlp->encode == TRUE)
  {
     /* swtch = (U8)ctlp->swtch; */
     teDef = *ctlp->sTelDef;
     /* tSt = (TknStrS *)ctlp->sSt; */

     /* check element for protocol type and mandatory/optional flags */
     if ((ret = maChkEncElmnt(ctlp)) != ROK)
     {
        if (ret == RSKIP)
        {
           RETVALUE(ROK);
        }
        RETVALUE(ret);
     }

     strS = (TknStrS *)ctlp->sSt;
     len = strS->len;
     val = &strS->val[0];
     /* bump structure pointer in message control */
     MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 

     if (ctlp->maVer == LMA_VER2P)
     {
        pkArray[0] = teDef->tag;
     }
     else 
     {
        pkArray[0] = MA_TAG_OCTSTR;
     }

     /* validate the length */
     if ( (len < teDef->minLen) || (len >teDef->maxLen))
     {
        MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
        "maChkVerStr() failed, invalid msg len(%d).\n", len));  
        RETVALUE(RFAILED);
     }

     pkArray[1] = (Data)len;
     tmpLen = 2;

     /* encode the value  */ 
     for (i=0; i<len; i++, val++)
     {
        pkArray[tmpLen +i] = *val;
     }
     ret = SAddPstMsgMult(pkArray, (MsgLen)(tmpLen + len), ctlp->mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
     if (ret != ROK)
     {
        MALOGERROR(ERRCLS_ADD_RES, EMA317, (ErrVal)ret, "SAddPstMsgMult() Failed");
        RETVALUE(ret);
     }
#endif
     MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
     "maChkVerStr: %s Tag [%x] Len [%x] Val [%x] \n", 
     maEleType[teDef->type], pkArray[0], pkArray[1], pkArray[2]));
     ctlp->sTelDef++;
     RETVALUE(ROK);
  }

  if (ctlp->decode == TRUE)
  {
     teDef = *ctlp->sTelDef;
     mBuf  = ctlp->mBuf;
     /* swtch = (U8)ctlp->swtch; */

     if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
     {
        ctlp->errCode = MAT_MISTYPE_PARAM;
        RETVALUE(ret);
     }

     if (((data != teDef->tag) && (ctlp->maVer == LMA_VER2P)) ||
         ((data != MA_TAG_OCTSTR) && (ctlp->maVer == LMA_VER2)))
     {
        if ((ret = maChkEleMand(ctlp) == FALSE))
        {
           /* skip the element in the data base and make as not present 
              in event str */
            ctlp->sTelDef++;

           /* bump structure pointer in message control */
#ifndef MA_MULT_SEG_DECODE
           ((TknStrS *)(ctlp->sSt))->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
            MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
        }
        else
        {
           ctlp->errCode = MAT_DATA_MISSING;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maChkVerStr() failed, mand. data missing.\n"));  
           RETVALUE(RFAILED);
        }
        RETVALUE(ROK);
     }

     strS = (TknStrS *)ctlp->sSt;
     if (( ret = maRemPrim(mBuf, ctlp, (U8 *)&strS->val[0], (U8 *)&strS->len)) != ROK)
     {
        ctlp->errCode = MAT_MISTYPED_PARAM;
        RETVALUE(ret);
     }
     strS->pres = TRUE;
     MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 

     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maChkVerStr: %s Tag [%x] Len [%x] Val [%x] \n", 
     maEleType[teDef->type], data, strS->len, strS->val[0]));
     ctlp->sTelDef++;
     RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkVerStr  */

/*
*
*       Fun:   maChkExtSeqOf    
*
*       Desc:  This function encodes/decodes/skip forward feature list
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkExtSeqOf 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkExtSeqOf (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  S16           ret;       /* return value */
  MaTknElmtDef  *teDef;    /* element definition */

  TRC2 (maChkExtSeqOf)

  teDef = *ctlp->sTelDef;


  if (ctlp->encode == TRUE)
  {
      MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
      "maChkExtSeqOf: Checking Ext SequenceOf ...... \n"));
      ret = maEncExtSeqOf(ctlp,teDef->repCntr, ctlp->sTelDef);
      if (ret != ROK)
      {
         MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maChkExtSeqOf() failed, failed to encode ExtSeqof.\n"));  
         RETVALUE(RFAILED);
      }
      MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
      "maChkExtSeqOf: Check Ext SequenceOf successfully.\n"));

      RETVALUE(ROK);
  }

  if (ctlp->decode == TRUE)
  {
      ret = maDecExtSeqOf(ctlp);
      if (ret != ROK)
      {
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maChkExtSeqOf() failed, failed to decode ExtSeqOf.\n"));  
         RETVALUE(RFAILED);
      }
  
      RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkExtSeqOf  */

/*
*
*       Fun:   maChkFfLongFwdedToNmb    
*
*       Desc:  This function encodes/decodes/skip default call handling
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkFfLongFwdedToNmb 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkFfLongFwdedToNmb (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  MaTknElmtDef  *teDef;    /* element definition */
  S16           ret;       /* return value */
  TknStrS       *tSt;      /* token string size - small */
  Data          data;
  Buffer        *mBuf;
  TknStrS       *strS;   /* token string size - small */
  U8            len;
  MsgLen        tmpLen;
  U8            *val;
  U8            i;
  Data          pkArray[MA_MAX_PKARRAY_LEN];


  TRC2 (maChkFfLongFwdedToNmb)

  /* For version 2p operation, encode/decode/skip entire seq */

  if (ctlp->maVer == LMA_VER2P)
  {
     if (ctlp->encode == TRUE)
     {
        teDef  = *ctlp->sTelDef;         /* Store the element definition */
        tSt    = (TknStrS *) ctlp->sSt; /* Get the token pointer */

        /* check element for protocol type and mandatory/optional flags */
        if ((ret = maChkEncElmnt(ctlp)) != ROK)
        {
           if (ret == RSKIP)
           {
              RETVALUE(ROK);
           }
           RETVALUE(ret);
        }

        strS = tSt;
        len = strS->len;
        val = &strS->val[0];

        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 

        /* validate the length */
        if ( (len < teDef->minLen) || (len >teDef->maxLen))
        {
           MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
           "maChkFfLongFwdedToNmb() failed, invalid string len(%d).\n", len));  
           RETVALUE(RFAILED);
        }

        /* encode the tag [10] for ext-fwdFeat */
        pkArray[0] = MA_TAG_CSPRIM10;
        pkArray[1] = (Data)len;
        tmpLen = 2;

        /* encode the value  */ 
        for (i=0; i<len; i++, val++)
        {
           pkArray[tmpLen +i] = *val;
        }

        ret = SAddPstMsgMult(pkArray, (MsgLen)(tmpLen + len), ctlp->mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
        if (ret != ROK)
        {
           MALOGERROR(ERRCLS_ADD_RES, EMA318, (ErrVal)ret, "SAddPstMsgMult() Failed");
           RETVALUE(ret);
        }
#endif
        MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
        "maChkFfLongFwdedToNmb: %s Tag [%x] Len [%x] Val [%x] \n", 
        maEleType[teDef->type], pkArray[0], pkArray[1], pkArray[2]));
        ctlp->sTelDef++;

        RETVALUE(ROK);
     }


     if (ctlp->decode == TRUE)
     {

        mBuf  = ctlp->mBuf;

        if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           RETVALUE(ret);
        }

        if (data != MA_TAG_CSPRIM10)
        {
           if ((ret = maChkEleMand(ctlp) == FALSE))
           {
              /* skip the element in the data base and make as not present 
               * in event str */
              ctlp->sTelDef++;
 
              /* bump structure pointer in message control */
#ifndef MA_MULT_SEG_DECODE
              ((TknStrS *)(ctlp->sSt))->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
              MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
              RETVALUE(ROK);
           }
           else
           {
               ctlp->errCode = MAT_DATA_MISSING;
               MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
               "maChkFfLongFwdedToNmb() failed, mand. data missing.\n"));  
               RETVALUE(RFAILED);
           }
        }

        strS = (TknStrS *)ctlp->sSt;
        if (( ret = maRemPrim(mBuf, ctlp, (U8 *)&strS->val[0], (U8 *)&strS->len)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPED_PARAM;
           RETVALUE(ret);
        }

        strS->pres = TRUE;
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 

        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maChkFfLongFwdedToNmb: %s Tag [%x] Len [%x] Val [%x] \n", 
        maEleType[(*(ctlp->sTelDef))->type], data, strS->len, strS->val[0]));
        ctlp->sTelDef++;
        RETVALUE(ROK);
     }
  }

  else if (ctlp->maVer == LMA_VER2)
  {
     if (ctlp->encode == TRUE)
     {
        teDef  = *ctlp->sTelDef;         /* Store the element definition */
        tSt    = (TknStrS *) ctlp->sSt; /* Get the token pointer */

        /* check element for protocol type and mandatory/optional flags */
        if ((ret = maChkEncElmnt(ctlp)) != ROK)
        {
           if (ret == RSKIP)
           {
              RETVALUE(ROK);
           }
           RETVALUE(ret);
        }

        strS = tSt;
        len = strS->len;
        val = &strS->val[0];

        /* bump structure pointer in message control */
        MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 

        /* validate the length */
        if ( (len < teDef->minLen) || (len >teDef->maxLen))
        {
           MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
           "maChkFfLongFwdedToNmb() failed, invalid string len(%d).\n", len));  
           RETVALUE(RFAILED);
        }

        /* encode the tag [10] for ext-fwdFeat */
        pkArray[0] = MA_TAG_CSPRIM9;
        pkArray[1] = (Data)len;
        tmpLen = 2;

        /* encode the value  */ 
        for (i=0; i<len; i++, val++)
        {
           pkArray[tmpLen +i] = *val;
        }

        ret = SAddPstMsgMult(pkArray, (MsgLen)(tmpLen + len), ctlp->mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
        if (ret != ROK)
        {
           MALOGERROR(ERRCLS_ADD_RES, EMA319, (ErrVal)ret, "SAddPstMsgMult() Failed");
           RETVALUE(ret);
        }
#endif
        MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
        "maChkFfLongFwdedToNmb: %s Tag [%x] Len [%x] Val [%x] \n", 
        maEleType[teDef->type], pkArray[0], pkArray[1], pkArray[2]));
        ctlp->sTelDef++;

        RETVALUE(ROK);
     }

     if (ctlp->decode == TRUE)
     {

        mBuf  = ctlp->mBuf;

        if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           RETVALUE(ret);
        }

        if (data != MA_TAG_CSPRIM9)
        {
           if ((ret = maChkEleMand(ctlp) == FALSE))
           {
              /* skip the element in the data base and make as not present 
               * in event str */
              ctlp->sTelDef++;
 
              /* bump structure pointer in message control */
#ifndef MA_MULT_SEG_DECODE
              ((TknStrS *)(ctlp->sSt))->pres = FALSE;
#endif /* MA_MULT_SEG_DECODE */
              MA_BUMP_STP((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
              RETVALUE(ROK);
           }
           else
           {
               ctlp->errCode = MAT_DATA_MISSING;
               MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
               "maChkFfLongFwdedToNmb() failed, mand. data missing.\n"));  
               RETVALUE(RFAILED);
           }
        }

        strS = (TknStrS *)ctlp->sSt;
        if (( ret = maRemPrim(mBuf, ctlp, (U8 *)&strS->val[0], (U8 *)&strS->len)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPED_PARAM;
           RETVALUE(ret);
        }

        strS->pres = TRUE;
        maBumpStp((PTR *)&ctlp->sSt, (U32) sizeof(TknStrS)); 
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maChkFfLongFwdedToNmb: %s Tag [%x] Len [%x] Val [%x] \n", 
        maEleType[(*(ctlp->sTelDef))->type], data, strS->len, strS->val[0]));

        ctlp->sTelDef++;
        RETVALUE(ROK);
     }
  }
  else
  {
     maSkipTkns(ctlp);
     RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkFfLongFwdedToNmb  */


/*
*
*       Fun:   maEncEscSeq
*
*       Desc:  This function encodes the sequence of tokens 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maEncEscSeq 
(
MaMsgCtl    *ctlp       /* message control pointer */
)
#else
PUBLIC S16 maEncEscSeq(ctlp)
MaMsgCtl    *ctlp;      /* message control pointer */
#endif
{
  MaTknElmtDef  *teDef;
  MaTknElmtDef  **tmpTeDef;
  TknU8         *tmpsSt;
  S16           ret;
  Data          pkArray[MA_MAX_PKARRAY_LEN];
  S16           seqMand;
  MsgLen        orgLen;
  MsgLen        curLen;
  MsgLen        i;

  TRC2(maEncEscSeq)

  /* swtch = (U8)ctlp->swtch; */
  teDef = *ctlp->sTelDef;
  tmpTeDef = ctlp->sTelDef;
  tmpsSt = (TknU8 *)ctlp->sSt;
 
  /* encode the sequence tag and EOC length tag */
  pkArray[0] = teDef->tag;
  pkArray[1] = (Data)MA_EOC_LEN;

  ret = SAddPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
  if (ret != ROK)
  {
     MALOGERROR(ERRCLS_ADD_RES, EMA320, (ErrVal)ret, "SAddPstMsgMult() Failed");
     RETVALUE(ret);
  }
#endif

  seqMand = maChkEleMand(ctlp);

  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
  "maEncEscSeq: Encoding Token Sequence ...... \n \
  %s Tag [%x] Len [%x]\n",
  maEleType[teDef->type], pkArray[0], pkArray[1]));

  /* increment the token pointer */
  ctlp->sTelDef++;
 
  teDef = *ctlp->sTelDef;
  
  /* All the tokens have first field as pres so typecast to TknU8 */
  /* sSt = (TknU8 *)ctlp->sSt; */

  SFndLenMsg(ctlp->mBuf, &orgLen);

  while (teDef->type != MA_TET_SEQ_TERM)
  {
     MA_INCREASE_LEVEL;
     /* Start encoding the tokens */
     switch(teDef->type)
     {
        case MA_TET_U8:
          ret = maEncOctet(ctlp,FALSE);
          break;
        case MA_TET_U8_ENUM:
          ret = maEncOctet(ctlp,TRUE);
          break;
        case MA_TET_NULL:
          ret = maEncNull(ctlp);
          break;
        case MA_TET_INT:
          ret = maEncInt(ctlp);
          break;
        case MA_TET_STR:
        case MA_TET_STRS:
        case MA_TET_STRM:
        case MA_TET_STRE:
#ifdef XWEXT
        case MA_TET_STR4:
#endif
          ret = maEncStr(ctlp);
          break;
        case MA_TET_STRUL:
          ret = maEncStrUL(ctlp);
          break;
        case MA_TET_BITSTR:
          ret = maEncBitStr(ctlp);
          break;
        case MA_TET_SEQ:
        case MA_TET_EXT_CONT:
#ifdef MAP_PHASE2_EXT_MARK
        case MA_TET_EXT_MARK:
#endif
          ret = maEncSeq(ctlp);
          break;
        case MA_TET_SEQ_OF:
          ret = maEncSeqOf(ctlp,teDef->repCntr, ctlp->sTelDef);
          break;
        case MA_TET_CHOICE:
          ret = maEncChoice(ctlp);
          break;
     }
     MA_DECREASE_LEVEL;
     SFndLenMsg(ctlp->mBuf, &curLen);
     if ((ret != ROK) && (ret != EMP_SEQ) && (ret != NON_EMP_SEQ))
     {
        if ( ctlp->errCode == MAT_DATA_MISSING)
        {
           if (orgLen == curLen) 
           {
              ctlp->sTelDef = tmpTeDef;
              ctlp->sSt = (U8 *)tmpsSt;
              maSkipTkns(ctlp);
              /* strip of the added tag and length before returning */
              SRemPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
              if (seqMand == FALSE)
              {
                 RETVALUE(ROK);
              }
              else
              {
                  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
                  "maEncEscSeq() failed, mand. data missing.\n"));  
                  RETVALUE(RFAILED);
              }
           }
           else
           {
              ctlp->sTelDef = tmpTeDef;
              ctlp->sSt = (U8 *)tmpsSt;
              maSkipTkns(ctlp);
              
              /* Strip off the encoded bytes */
              for (i=0; i< (curLen - orgLen); i++)
              {
                SRemPstMsg(pkArray, ctlp->mBuf);
              }
              /* strip of the added tag and length before returning */
              SRemPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);

              MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
              "maEncEscSeq() failed, fail to encode msg type(%d).\n", teDef->type));  
              RETVALUE(RFAILED);
           }
        }
        else
        {
           ctlp->sTelDef = tmpTeDef;
           ctlp->sSt = (U8 *)tmpsSt;
           maSkipTkns(ctlp);
           /* strip of the added tag and length before returning */
           SRemPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
           MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
           "maEncEscSeq() failed, fail to encode msg type(%d).\n", teDef->type));  
           RETVALUE(RFAILED);
        }
     }

     /* update the pointers */
     teDef = *ctlp->sTelDef;
     /* sSt = (TknU8 *)ctlp->sSt; */
  }

  SFndLenMsg(ctlp->mBuf, &curLen);
  if ((orgLen == curLen) && (seqMand == FALSE))
  {
    SRemPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
    ctlp->sTelDef++;
    RETVALUE(ROK);
  }
#ifdef MA_ASN_NO_INDEF_LEN
  MA_ENC_DEF_LEN(curLen, orgLen)
#else /* MA_ASN_NO_INDEF_LEN */
  /* Encode the TWo EOC tag to indicate end of sequence */
  pkArray[0] = MA_TAG_EOC;
  pkArray[1] = MA_TAG_EOC;

  ret = SAddPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);

#if (ERRCLASS & ERRCLS_ADD_RES)
  if (ret != ROK)
  {
     MALOGERROR(ERRCLS_ADD_RES, EMA321, (ErrVal)ret, "SAddPstMsgMult() Failed");
     RETVALUE(ret);
  }
#endif
#endif /* MA_ASN_NO_INDEF_LEN */
  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
  "maEncEscSeq: Encoding Token Sequence successfully. \n"));


  /* increment the token defination pointer */
  ctlp->sTelDef++;
  RETVALUE(ROK);
} /* maEncEscSeq */

/*
*
*       Fun:    maDecEscSeq 
*
*       Desc:  This function decodes the sequence element 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maDecEscSeq 
(
MaMsgCtl   *ctlp        /* message control pointer */
)
#else
PUBLIC S16 maDecEscSeq (ctlp )
MaMsgCtl   *ctlp;       /* message control pointer */
#endif
{
  MaTknElmtDef  *teDef;
  Data          data;
  Buffer        *mBuf;
  Bool          eocFlg;
  Bool          remEocFlg;
  U8            swtch;
  MsgLen        tmpLen;
  MsgLen        lfLen;  /* Length of length field */
  MsgLen        seqLen;
  Data          unPkArray[MA_MAX_PKARRAY_LEN];
  MsgLen        orgMsgLen;
  MsgLen        newMsgLen;
  S16           ret;
#ifdef MAP_PHASE2_EXT_MARK
  TknStrE       *sStrE;
#endif

  TRC2(maDecEscSeq)
  teDef = *ctlp->sTelDef;
  mBuf  = ctlp->mBuf;
  eocFlg = FALSE;
  swtch = (U8)ctlp->swtch;

  /* check whether Map versions are compatible */
  if ( (ctlp->maVer == LMA_VER1  && !(IS_EQUAL_VER1(teDef->verFlg))) ||
       (ctlp->maVer == LMA_VER2  && !(IS_EQUAL_VER2(teDef->verFlg))) ||
       (ctlp->maVer == LMA_VER2P && !(IS_EQUAL_VER2P(teDef->verFlg)))|| 
       (ctlp->maVer == LMA_VER4  && !(IS_EQUAL_VER4(teDef->verFlg)))    
      )
  {
    /* skip in the data base and make as not present in event str */
    /* move structure pointer and element definition pionter to *
     * start of this sequence, and skip whore sequence.         */
     maSkipSeq(ctlp);
     RETVALUE(ROK);
  }

  (Void)SExamMsg(&data, mBuf, 0);

  if (data != teDef->tag)
  {
    /* check whether Map versions are compatible */
    if ((ret = maChkEleMand(ctlp) == FALSE))
    {
      /* skip the elmt. in the data base and make as not present in event str */
      maSkipSeq(ctlp);
      RETVALUE(ROK);
    }
    else
    {
       ctlp->errCode = MAT_DATA_MISSING;
       MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
       "maDecEscSeq() failed, mand. data error.\n"));  
       RETVALUE(RFAILED);
    }

  }

  if ((ret = maFindLen(ctlp->mBuf, 0, &seqLen, &eocFlg, &lfLen)) != ROK)
  {
     ctlp->errCode = MAT_MISTYPED_PARAM;
     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maDecEscSeq() failed, failed to get len from msg.\n"));  
     RETVALUE(RFAILED);
  }


  /* decode the sequence */
  (Void)SRemPreMsg(&data, mBuf);


  if ((ret = maRemLen(mBuf, &remEocFlg)) != ROK)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maDecEscSeq() failed, failed to get len from mBuf.\n"));  
    RETVALUE(RFAILED);
  }

  if (seqLen == 0)
  {
    if ((ret = maChkEleMand(ctlp)) == FALSE)
    {
      maSkipSeq(ctlp);
      if (remEocFlg == TRUE)
      {
          /* remove the two EOC bytes */
          if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
          {
            ctlp->errCode = MAT_MISTYPE_PARAM;
            RETVALUE(ret);
          }
      }
      RETVALUE(ROK);
    }
    else
    {
      ctlp->sTelDef++;
      if((ret = maChkSeqMand(ctlp)) == ROK)
      {
         if (remEocFlg == TRUE)
         {
            if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
            {
               ctlp->errCode = MAT_MISTYPE_PARAM;
               RETVALUE(ret);
            }
         }
         RETVALUE(ROK);
      }
      ctlp->errCode = MAT_DATA_MISSING;
      MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
      "maDecEscSeq() failed, mand. data missing.\n"));  
      RETVALUE(RFAILED);
    }
  }

  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
  "maDecEscSeq: Decoding EscSequence ...... \n \
  %s Tag [%x] \n", maEleType[teDef->type], data));
  /* increment the data base pointer */

  ctlp->sTelDef++;
  teDef = *ctlp->sTelDef;

  while (teDef->type != MA_TET_SEQ_TERM)
  {
      if (seqLen == 0)
      {
        if (remEocFlg == TRUE)
        {
          /* remove the two EOC bytes */
          if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
          {
            ctlp->errCode = MAT_MISTYPE_PARAM;
            RETVALUE(ret);
          }
        }
        /* reached end of buffer - check for missing mand el */
        RETVALUE(maChkSeqMand(ctlp));
      }
      SFndLenMsg(ctlp->mBuf, &orgMsgLen);
      switch (teDef->type)
      {
        case MA_TET_U8:
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecEscSeq() failed at token(%d), fail to get len.\n", teDef->type));  
             RETVALUE(RFAILED);
          }
          ret = maDecOctet(ctlp,FALSE);
          
          break;
        case MA_TET_U8_ENUM:
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecEscSeq() failed at token(%d), fail to get len.\n", teDef->type));  
             RETVALUE(RFAILED);
          }

          ret = maDecOctet(ctlp,TRUE);

          break;
        case MA_TET_NULL:
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecEscSeq() failed at token(%d), fail to get len.\n", teDef->type));  
             RETVALUE(RFAILED);
          }
          ret = maDecNull(ctlp);
          break;
        case MA_TET_INT:
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecEscSeq() failed at token(%d), fail to get len.\n", teDef->type));  
             RETVALUE(RFAILED);
          }
          ret = maDecInt(ctlp);
          break;
        case MA_TET_STR:
        case MA_TET_STRS:
        case MA_TET_STRM:
        case MA_TET_STRE:
#ifdef XWEXT
        case MA_TET_STR4:
#endif
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecEscSeq() failed at token(%d), fail to get len.\n", teDef->type));  
             RETVALUE(RFAILED);
          }
          ret = maDecStr(ctlp);
          break;
        case MA_TET_STRUL:
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecEscSeq() failed at token(%d), fail to get len.\n", teDef->type));  
             RETVALUE(RFAILED);
          }
          ret = maDecStrUL(ctlp);
          break;
        case MA_TET_BITSTR:
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecEscSeq() failed at token(%d), fail to get len.\n", teDef->type));  
             RETVALUE(RFAILED);
          }
          ret = maDecBitStr(ctlp);
          break;
        case MA_TET_SEQ:
        case MA_TET_EXT_CONT:
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecEscSeq() failed at token(%d), fail to get len.\n", teDef->type));  
             RETVALUE(RFAILED);
          }
          if (tmpLen > seqLen)
          {
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecEscSeq() failed at token(%d), invalid seq len(%d).\n", teDef->type, tmpLen));  
             RETVALUE(RFAILED);
          }
          ret = maDecSeq(ctlp);
          break;
        case MA_TET_SEQ_OF:
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecEscSeq() failed at token(%d), fail to get len.\n", teDef->type));  
             RETVALUE(RFAILED);
          }
          ret = maDecSeqOf(ctlp);
          break;
        case MA_TET_CHOICE:
          if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPED_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecEscSeq() failed at token(%d), fail to get len.\n", teDef->type));  
             RETVALUE(RFAILED);
          }
          ret = maDecChoice(ctlp);
          break;
#ifdef MAP_PHASE2_EXT_MARK
        case MA_TET_EXT_MARK:
          if ((ctlp->maVer == LMA_VER2)  && 
                           (IS_EQUAL_VER2(teDef->verFlg)))
          {
            sStrE = (TknStrE *)ctlp->sSt;
            /* If the remaining length exceeds the length of TknStrE */
            if (seqLen > MF_SIZE_TKNSTRE)
                     RETVALUE(RFAILED);

            if ((ret = SRemPreMsgMult((U8 *)&sStrE->val[0], seqLen, mBuf)) != ROK)
            {
                ctlp->errCode = MAT_MISTYPED_PARAM;
                RETVALUE(ret);
            }

/* ma005.203: Addition, Copy the length of Private extensions */
/*                      in Token length filed */
            sStrE->len = (U8)seqLen;  
            sStrE->pres = TRUE;
          }
          else
          {
               maSkipTkns(ctlp);
          }
          break;
          
#endif
        default:
#if (ERRCLASS & ERRCLS_DEBUG)
           MALOGERROR(ERRCLS_DEBUG, EMA322, (ErrVal)teDef->type, "maDecEscSeq () Failed");
#endif
           break;
      }
      if (ret != ROK)
      {
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maDecEscSeq() failed, fail to decode msg type(%d).\n", teDef->type));  
        RETVALUE(RFAILED);
      }
      SFndLenMsg(ctlp->mBuf,&newMsgLen);
      if (orgMsgLen != newMsgLen)
      {
         seqLen -= (orgMsgLen - newMsgLen);
      }
      teDef = *ctlp->sTelDef;
      if (seqLen < 0)
      {
         ctlp->errCode = MAT_MISTYPED_PARAM;
         MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecEscSeq() failed, invalid seqLen(%d).\n", seqLen));  
         RETVALUE(RFAILED);
      }
  }
  if ( (ctlp->maVer != LMA_VER1) && (seqLen > 0) )
  {
     /*
     ** Extended elements at the end of the sequence .
     ** So Ignore them without sending error indications.
     ** This is done only for phase-2 messages.
     */
 
     /* remove the remaining elements from the sequence */
     while(seqLen > 0)
     {
        if ((ret = SRemPreMsg(&data, mBuf)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           RETVALUE(ret);
        }
        seqLen--;
     }
  }
 
  if ( (ctlp->maVer == LMA_VER1) && (seqLen > 0) )
  {
     /*
     ** Unknown elements at the end of the sequence .
     ** So send error indications.
     ** This is done only for phase-1 messages.
     */
 
     ctlp->errCode = MAT_MISTYPE_PARAM;
     MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
     "maDecEscSeq() failed, invalid seqLen(%d).\n", seqLen));  
     RETVALUE(RFAILED);
  }

  if (remEocFlg == TRUE)
  {
    /* remove the two EOC bytes */
    if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }
  }

  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
  "maDecEscSeq: decode EscSequence  Successfully.\n"));
  ctlp->sTelDef++;
  RETVALUE(ROK);
} /* maDecEscSeq */



/*
*
*       Fun:   maEncExtSeqOf  
*
*       Desc:  This function encodes the repeatable sequence 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maEncExtSeqOf 
(
MaMsgCtl      *ctlp,         /* message control pointer */
S32           cntr,          /* Counter */
MaTknElmtDef  **stTelDef     /* token element pointer */
)
#else
PUBLIC S16 maEncExtSeqOf (ctlp,cntr,stTelDef)
MaMsgCtl      *ctlp;        /* message control pointer */
S32           cntr;         /* Counter */
MaTknElmtDef  **stTelDef;   /* token element pointer */
#endif
{
  MaTknElmtDef  *teDef;
  Data          pkArray[MA_MAX_PKARRAY_LEN];
  S16           ret; 
  S16           seqMand; 
  MsgLen        orgLen;
  MsgLen        curLen;
  MsgLen        initLen;

  TRC2(maEncExtSeqOf)

  /* encode the sequence tag and EOC length tag */
  teDef = *ctlp->sTelDef;
  pkArray[0] = teDef->tag;
  pkArray[1] = MA_EOC_LEN;

  ret = SAddPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);

#if (ERRCLASS & ERRCLS_ADD_RES)
  if (ret != ROK)
  {
     MALOGERROR(ERRCLS_ADD_RES, EMA323, (ErrVal)ret, "SAddPstMsgMult() Failed");
     RETVALUE(ret);
  }
#endif
  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maEncExtSeqOf: Encoding Extend Sequence of ...... \n \
          %s Tag [%x] Len [%x]\n",
          maEleType[teDef->type], pkArray[0], pkArray[1]));

  SFndLenMsg(ctlp->mBuf, &initLen);
  seqMand = maChkEleMand(ctlp);

  while(((ctlp->maVer == LMA_VER2P) && (cntr)) || 
        ((ctlp->maVer < LMA_VER2P) && 
         (cntr > (MAT_MAX_EXT_BASIC_SERV-MAT_MAX_BASIC_SERV))))
  {
    ctlp->sTelDef = stTelDef;
    ctlp->sTelDef++;
    teDef = *ctlp->sTelDef;
    /* Start encoding the tokens */
    SFndLenMsg(ctlp->mBuf, &orgLen);
    MA_INCREASE_LEVEL;
    switch(teDef->type)
    {
        case MA_TET_U8:
          ret = maEncOctet(ctlp,FALSE);
          break;
        case MA_TET_U8_ENUM:
          ret = maEncOctet(ctlp,TRUE);
          break;
        case MA_TET_NULL:
          ret = maEncNull(ctlp);
          break;
        case MA_TET_INT:
          ret = maEncInt(ctlp);
          break;
        case MA_TET_STR:
        case MA_TET_STRS:
        case MA_TET_STRM:
        case MA_TET_STRE:
#ifdef XWEXT
        case MA_TET_STR4:
#endif
          ret = maEncStr(ctlp);
          break;
        case MA_TET_STRUL:
          ret = maEncStrUL(ctlp);
          break;
        case MA_TET_BITSTR:
          ret = maEncBitStr(ctlp);
          break;
        case MA_TET_SEQ:
        case MA_TET_EXT_CONT:
          ret = maEncSeq(ctlp);
          break;
        case MA_TET_SEQ_OF:
          ret = maEncSeqOf(ctlp,teDef->repCntr, ctlp->sTelDef);
          break;
        case MA_TET_CHOICE:
          ret = maEncChoice(ctlp);
          break;
        default:
#if (ERRCLASS & ERRCLS_DEBUG)
          MALOGERROR(ERRCLS_DEBUG, EMA324, (ErrVal)teDef->type, "maEncSeqOf () Failed");
#endif
          break;
    }
    MA_DECREASE_LEVEL;
    SFndLenMsg(ctlp->mBuf, &curLen);
    if ((ret != ROK) && (ret != EMP_SEQ) && (ret != NON_EMP_SEQ))
    {
      if (ctlp->errCode == MAT_DATA_MISSING)
      {
         if ((initLen == curLen) && (seqMand == TRUE))
         {
            /* nothing was encoded, so mandatory info missing */
            SRemPstMsgMult(&pkArray[0], (MsgLen)2, ctlp->mBuf);
            while(cntr)
            {
              ctlp->sTelDef = stTelDef;
              ctlp->sTelDef++;
              maSkipTkns(ctlp);
              cntr--;
            }
            ctlp->sTelDef++;
            RETVALUE(ret);
         }
         else
         {
            break;
         }
      }
      else
      {
         RETVALUE(ret);
      }
    }
    cntr--;
    if (orgLen == curLen)
    {
      break;
    }
  }

  if ((initLen == curLen) && (seqMand == FALSE))
  {
    SRemPstMsgMult(&pkArray[0], (MsgLen)2, ctlp->mBuf);
  }
  else if ((initLen == curLen) && (seqMand == TRUE))
  {
    SRemPstMsgMult(&pkArray[0], (MsgLen)2, ctlp->mBuf);
    while(cntr)
    {
      ctlp->sTelDef = stTelDef;
      ctlp->sTelDef++;
      maSkipTkns(ctlp);
      cntr--;
    }

    ctlp->sTelDef++;
    ctlp->errCode = MAT_DATA_MISSING;

    MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
    "maEncExtSeqOf() failed, mand. data missing.\n"));  
    RETVALUE(RFAILED);
  }

  else
  {
#ifdef MA_ASN_NO_INDEF_LEN
     MA_ENC_DEF_LEN(curLen, initLen)
#else /* MA_ASN_NO_INDEF_LEN */
     /* Encode the TWo EOC tag to indicate end of sequence */
     pkArray[0] = MA_TAG_EOC;
     pkArray[1] = MA_TAG_EOC;

     ret = SAddPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);

#if (ERRCLASS & ERRCLS_ADD_RES)
     if (ret != ROK)
     {
        MALOGERROR(ERRCLS_ADD_RES, EMA325, (ErrVal)ret, "SAddPstMsgMult() Failed");
        RETVALUE(ret);
     }
#endif
#endif /* MA_ASN_NO_INDEF_LEN */
  }

  while(cntr)
  {
    ctlp->sTelDef = stTelDef;
    ctlp->sTelDef++;
    maSkipTkns(ctlp);
    cntr--;
  }

  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
  "maEncExtSeqOf: Encoding extend Sequence of successfully. \n"));
  ctlp->sTelDef++;
  RETVALUE(ROK);
} /* end of maEncExtSeqOf */


/*
*
*       Fun:   maDecExtSeqOf  
*
*       Desc:  This function decodes the repeatable sequence 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maDecExtSeqOf 
(
MaMsgCtl      *ctlp      /* message control pointer */
)
#else
PUBLIC S16 maDecExtSeqOf (ctlp)
MaMsgCtl      *ctlp;        /* message control pointer */
#endif
{
  MaTknElmtDef  *teDef;
  MaTknElmtDef  **stTelDef;
  Buffer        *mBuf;
  MsgLen        seqLen;
  MsgLen        msgLen;
  MsgLen        tmpLen;
  MsgLen        lfLen;
  Bool          remEocFlg;
  Data          data;
  U8            swtch;
  Bool          eocFlg;
  S32           cntr;       /* Counter */
  Data          unPkArray[MA_MAX_PKARRAY_LEN];
  MsgLen        orgMsgLen;
  MsgLen        newMsgLen;
  S16           ret;

  TRC2(maDecExtSeqOf)

  mBuf = ctlp->mBuf;
  teDef = *ctlp->sTelDef;
  eocFlg = FALSE;
  swtch = (U8)ctlp->swtch;
  cntr = teDef->repCntr;

  if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
  {
    if (ret == ROKDNA)
    {
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make them as not present */
        maSkipSeqOf(ctlp);
        RETVALUE(ROK);
      }
    }
    else
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }
  }
  if (data != teDef->tag)
  {
    /* check whether Map versions are compatible */
    if ((ret = maChkEleMand(ctlp) == FALSE))
    {
      /* skip the element in the data base and make as not present in event str */
      maSkipSeqOf(ctlp);
      RETVALUE(ROK);
    }
    else
    {
       ctlp->errCode = MAT_DATA_MISSING;
       MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
       "maDecExtSeqOf() failed, mand. data error.\n"));  
       RETVALUE(RFAILED);
    }

  }

  /* Find the length of sequence */

  if ((ret = maFindLen(mBuf,0,&seqLen,&eocFlg, &lfLen)) != ROK)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    RETVALUE(ret);
  }
 
  (Void)SFndLenMsg (mBuf, &msgLen);

  if (msgLen < seqLen)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maDecExtSeqOf() failed, invalid msgLen(%d).\n", msgLen));  
    RETVALUE(RFAILED);
  }

  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
  "maDecExtSeqOf: Decoding Extend Sequence Of ...... \n \
  %s Tag [%x] \n", maEleType[teDef->type], data));

  /* decode the sequence */
  (Void)SRemPreMsg(&data, mBuf); 

  /* remove the length byte */


  if ((ret = maRemLen(mBuf, &remEocFlg)) != ROK)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    RETVALUE(ret);
  }

  ctlp->sTelDef++;
  stTelDef = ctlp->sTelDef;
  while(((ctlp->maVer == LMA_VER2P) && (cntr)) || 
        ((ctlp->maVer < LMA_VER2P) && 
         (cntr > (MAT_MAX_EXT_BASIC_SERV-MAT_MAX_BASIC_SERV))))
  {
    ctlp->sTelDef = stTelDef;
    teDef = *ctlp->sTelDef;
    SFndLenMsg(ctlp->mBuf, &orgMsgLen);
    if (seqLen == 0)
    {
       if ( (ret = maChkEleMand(ctlp)) != ROK)
       {
         if (msgLen == orgMsgLen)
         {
            ctlp->errCode = MAT_DATA_MISSING;
            MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
            "maDecExtSeqOf() failed, mand. data missing.\n"));  
            RETVALUE(RFAILED);
         }
       }
       break;
    }
    switch (teDef->type)
    {
      case MA_TET_U8:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecExtSeqOf() failed, fail to decode el type(%d).\n",
           teDef->type));  
           RETVALUE(ret);
        }
        ret = maDecOctet(ctlp,FALSE);
        break;
      case MA_TET_U8_ENUM:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecExtSeqOf() failed, fail to decode el type(%d).\n",
           teDef->type));  
           RETVALUE(ret);
        }
        ret = maDecOctet(ctlp,TRUE);
        break;
      case MA_TET_NULL:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecExtSeqOf() failed, fail to decode el type(%d).\n",
           teDef->type));  
           RETVALUE(ret);
        }
        ret = maDecNull(ctlp);
        break;
        case MA_TET_INT:
          if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPE_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecExtSeqOf() failed, fail to decode el type(%d).\n",
             teDef->type));  
             RETVALUE(ret);
          }
          ret = maDecInt(ctlp);
          break;
      case MA_TET_STR:
      case MA_TET_STRS:
      case MA_TET_STRM:
      case MA_TET_STRE:
#ifdef XWEXT
      case MA_TET_STR4:
#endif
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecExtSeqOf() failed, fail to decode el type(%d).\n",
           teDef->type));  
           RETVALUE(ret);
        }
        ret = maDecStr(ctlp);
        break;
      case MA_TET_STRUL:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecExtSeqOf() failed, fail to decode el type(%d).\n",
           teDef->type));  
           RETVALUE(ret);
        }
        ret = maDecStrUL(ctlp);
        break;
      case MA_TET_BITSTR:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecExtSeqOf() failed, fail to decode el type(%d).\n",
           teDef->type));  
           RETVALUE(ret);
        }
        ret = maDecBitStr(ctlp);
        break;
      case MA_TET_SEQ:
      case MA_TET_EXT_CONT:
        if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPED_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecExtSeqOf() failed, fail to find len.\n"));  
           RETVALUE(ret);
        }
        ret = maDecSeq(ctlp);
        break;
      case MA_TET_SEQ_OF:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecExtSeqOf() failed, fail to decode el type(%d).\n",
           teDef->type));  
           RETVALUE(ret);
        }
        ret = maDecSeqOf(ctlp);
        break;
      case MA_TET_CHOICE:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecExtSeqOf() failed, fail to decode el type(%d).\n",
           teDef->type));  
           RETVALUE(ret);
        }
        ret = maDecChoice(ctlp);
        break;
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
        MALOGERROR(ERRCLS_DEBUG, EMA326, (ErrVal)teDef->type, "maDecExtSeqOf () Failed");
#endif
         break;
    }
    if (ret != ROK)
    {
       MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
       "maDecExtSeqOf() failed, fail to decode el type(%d).\n", teDef->type));  
       RETVALUE(RFAILED);
    }
    SFndLenMsg(ctlp->mBuf, &newMsgLen);
    if (orgMsgLen != newMsgLen)
    {
       seqLen -= orgMsgLen - newMsgLen;
    }
    cntr--;
  }
  while(cntr)
  {
    ctlp->sTelDef = stTelDef;
    maSkipTkns(ctlp);
    cntr--;
  }
  if (remEocFlg == TRUE)
  {
    /* remove the two EOC bytes */
    if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPE_PARAM;
       MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
       "maDecExtSeqOf() failed, fail to remove eoc byte.\n"));  
       RETVALUE(RFAILED);
    }
  }

  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
  "maDecExtSeqOf: decode Extend SequenceOf  Successfully.\n"));
  /* skip the End of Seq Of pointer */
  ctlp->sTelDef++;
  RETVALUE(ROK);
} /* end of MaDecExtSeqOf */

#if MAP_REL99
/*
*
*       Fun:   maChkMinSeqOf    
*
*       Desc:  This function encodes/decodes/skip RadioResSeqof
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkMinSeqOf 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkMinSeqOf (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{
  S16           ret;       /* return value */
  MaTknElmtDef  *teDef;    /* element definition */
  S32           minSize;   /* Minimum value of counter */

  TRC2 (maChkMinSeqOf)

  teDef = *ctlp->sTelDef;
  minSize = teDef->minLen;

  if (ctlp->encode == TRUE)
  {

     ret = maEncMinSeqOf(ctlp,teDef->repCntr,ctlp->sTelDef, minSize);
     if (ret != ROK)
     {
        MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
        "maChkMinSeqOf() failed, fail to encode MinSeqOf.\n"));  
        RETVALUE(RFAILED);
     }

     RETVALUE(ROK);
  }

  if (ctlp->decode == TRUE)
  {
     ret = maDecMinSeqOf(ctlp, minSize);
     if (ret != ROK)
     {
        MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
        "maChkMinSeqOf() failed, fail to decode MinSeqOf.\n"));  
        RETVALUE(RFAILED);
     }
  
     RETVALUE(ROK);
  }

  RETVALUE(ROK);
} /* maChkMinSeqOf  */


/*
*
*       Fun:   maEncMinSeqOf  
*
*       Desc:  This function encodes the repeatable sequence. If soze of 
*              SeqOf less than MAT_MIN_NMB_RADIO_RES, return failed.
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maEncMinSeqOf 
(
MaMsgCtl      *ctlp,         /* message control pointer */
S32           cntr,          /* Counter */
MaTknElmtDef  **stTelDef,    /* token element pointer */
S32           minCntr        /* minimum size of array */
)
#else
PUBLIC S16 maEncMinSeqOf (ctlp,cntr,stTelDef, minCntr)
MaMsgCtl      *ctlp;        /* message control pointer */
S32           cntr;         /* Counter */
MaTknElmtDef  **stTelDef;   /* token element pointer */
S32           minCntr;      /* minimum size of array */
#endif
{
  MaTknElmtDef  *teDef;
  Data          pkArray[MA_MAX_PKARRAY_LEN];
  S16           ret; 
  S16           seqMand; 
  MsgLen        orgLen;
  MsgLen        curLen;
  MsgLen        initLen;
  S32           counter;

  TRC2(maEncMinSeqOf)

  counter = 0;
  teDef = *ctlp->sTelDef;

  /* encode the sequence tag and EOC length tag */
  pkArray[0] = teDef->tag;
  pkArray[1] = MA_EOC_LEN;

  ret = SAddPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
  if (ret != ROK)
  {
     MALOGERROR(ERRCLS_ADD_RES, EMA327, (ErrVal)ret, "SAddPstMsgMult() Failed");
     RETVALUE(ret);
  }
#endif

  #ifndef ALIGN_64BIT

  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maEncMinSeqOf: Encoding Sequence Of ......\n \
          %s Tag [%x] Len [%x] Counter %ld \n",
          maEleType[teDef->type], pkArray[0], pkArray[1], cntr));

  #else
 
  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maEncMinSeqOf: Encoding Sequence Of ......\n \
          %s Tag [%x] Len [%x] Counter %d \n",
          maEleType[teDef->type], pkArray[0], pkArray[1], cntr));
 
  #endif /* ALIGN_64BIT */ 
  SFndLenMsg(ctlp->mBuf, &initLen);
  seqMand = maChkEleMand(ctlp);
  while(cntr)
  {
    ctlp->sTelDef = stTelDef;
    ctlp->sTelDef++;
    teDef = *ctlp->sTelDef;
    /* Start encoding the tokens */
    SFndLenMsg(ctlp->mBuf, &orgLen);
    MA_INCREASE_LEVEL;
    switch(teDef->type)
    {
        case MA_TET_U8:
          ret = maEncOctet(ctlp,FALSE);
          break;
        case MA_TET_U8_ENUM:
          ret = maEncOctet(ctlp,TRUE);
          break;
        case MA_TET_NULL:
          ret = maEncNull(ctlp);
          break;
        case MA_TET_INT:
          ret = maEncInt(ctlp);
          break;
        case MA_TET_STR:
        case MA_TET_STRS:
        case MA_TET_STRM:
        case MA_TET_STRE:
#ifdef XWEXT
        case MA_TET_STR4:
#endif
          ret = maEncStr(ctlp);
          break;
        case MA_TET_STRUL:
          ret = maEncStrUL(ctlp);
          break;
        case MA_TET_BITSTR:
          ret = maEncBitStr(ctlp);
          break;
        case MA_TET_SEQ:
        case MA_TET_EXT_CONT:
          ret = maEncSeq(ctlp);
          break;
        case MA_TET_SEQ_OF:
          ret = maEncSeqOf(ctlp,teDef->repCntr, ctlp->sTelDef);
          break;
        case MA_TET_CHOICE:
          ret = maEncChoice(ctlp);
          break;
        default:
#if (ERRCLASS & ERRCLS_DEBUG)
          MALOGERROR(ERRCLS_DEBUG, EMA328, (ErrVal)teDef->type, "maEncMinSeqOf () Failed");
#endif
          break;
    }
    MA_DECREASE_LEVEL;
    SFndLenMsg(ctlp->mBuf, &curLen);
    if((ret != ROK) && (ret != EMP_SEQ) && (ret != NON_EMP_SEQ))
    {
      if (ctlp->errCode == MAT_DATA_MISSING)
      {
         if ((initLen == curLen) && (seqMand == TRUE))
         {
            /* nothing was encoded, so mandatory info missing */
            SRemPstMsgMult(&pkArray[0], (MsgLen)2, ctlp->mBuf);
            while(cntr)
            {
              ctlp->sTelDef = stTelDef;
              ctlp->sTelDef++;
              maSkipTkns(ctlp);
              cntr--;
            }
            ctlp->sTelDef++;
            RETVALUE(ret);
         }
         else
         {
            break;
         }
      }
      else
      {
         RETVALUE(ret);
      }
    }
    cntr--;
    if (orgLen == curLen)
    {
      break;
    }
    counter++;
  }

  if ((initLen == curLen) && (seqMand == FALSE))
  {
    SRemPstMsgMult(&pkArray[0], (MsgLen)2, ctlp->mBuf);
  }
  else if ((initLen == curLen) && (seqMand == TRUE))
  {
    SRemPstMsgMult(&pkArray[0], (MsgLen)2, ctlp->mBuf);
    while(cntr)
    {
      ctlp->sTelDef = stTelDef;
      ctlp->sTelDef++;
      maSkipTkns(ctlp);
      cntr--;
    }

    ctlp->sTelDef++;
    ctlp->errCode = MAT_DATA_MISSING;
    MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
    "maEncMinSeqOf() failed, mand. data missing.\n"));  
    RETVALUE(RFAILED);
  }
  else if (counter < minCntr)
  {
    ctlp->errCode = MAT_DATA_MISSING;
    MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
    "maEncMinSeqOf() failed, mand. data missing.\n"));  
    RETVALUE(RFAILED);
  }
  else
  {
#ifdef MA_ASN_NO_INDEF_LEN
     MA_ENC_DEF_LEN(curLen, initLen)
#else /* MA_ASN_NO_INDEF_LEN */
     /* Encode the TWo EOC tag to indicate end of sequence */
     pkArray[0] = MA_TAG_EOC;
     pkArray[1] = MA_TAG_EOC;

     ret = SAddPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
     if (ret != ROK)
     {
        MALOGERROR(ERRCLS_ADD_RES, EMA329, (ErrVal)ret, "SAddPstMsgMult() Failed");
        RETVALUE(ret);
     }
#endif
#endif /* MA_ASN_NO_INDEF_LEN */
  }

  while(cntr)
  {
    ctlp->sTelDef = stTelDef;
    ctlp->sTelDef++;
    maSkipTkns(ctlp);
    cntr--;
  }

  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         "maEncMinSeqOf: Encoding Sequence Of Successfully.\n"));

  ctlp->sTelDef++;
  RETVALUE(ROK);
} /* end of maEncMinSeqOf */


/*
*
*       Fun:   maDecMinSeqOf  
*
*       Desc:  This function decodes the repeatable sequence 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maDecMinSeqOf 
(
MaMsgCtl      *ctlp,         /* message control pointer */
S32           minCntr        /* minimum size of array */
)
#else
PUBLIC S16 maDecMinSeqOf (ctlp, minCntr)
MaMsgCtl      *ctlp;         /* message control pointer */
S32           minCntr;       /* minimum size of array */
#endif
{
  MaTknElmtDef  *teDef;
  MaTknElmtDef  **stTelDef;
  Buffer        *mBuf;
  MsgLen        seqLen;
  MsgLen        msgLen;
  MsgLen        tmpLen;
  MsgLen        lfLen;
  Bool          remEocFlg;
  Data          data;
  U8            swtch;
  Bool          eocFlg;
  S32           cntr;       /* Counter */
  Data          unPkArray[MA_MAX_PKARRAY_LEN];
  MsgLen        orgMsgLen;
  MsgLen        newMsgLen;
  S16           ret;
  S32           counter;

  TRC2(maDecMinSeqOf)

  mBuf = ctlp->mBuf;
  teDef = *ctlp->sTelDef;
  cntr = teDef->repCntr;
  eocFlg = FALSE;
  swtch = (U8)ctlp->swtch;
  counter = 0;

  if ((ret = SExamMsg(&data, mBuf, 0)) != ROK)
  {
    if (ret == ROKDNA)
    {
      if ((ret = maChkEleMand(ctlp) == FALSE))
      {
        /* skip the element in the data base and make them as not present */
        maSkipSeqOf(ctlp);
        RETVALUE(ROK);
      }
    }
    else
    {
      ctlp->errCode = MAT_MISTYPE_PARAM;
      RETVALUE(ret);
    }
  }
  if (data != teDef->tag)
  {
    /* check whether Map versions are compatible */
    if ((ret = maChkEleMand(ctlp) == FALSE))
    {
      /* skip the element in the data base */
      maSkipSeqOf(ctlp);
      RETVALUE(ROK);
    }
    else
    {
       ctlp->errCode = MAT_DATA_MISSING;
       MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
       "maDecMinSeqOf() failed, mand. data error.\n"));  
       RETVALUE(RFAILED);
    }
  }
  else
  {
     if ( (ctlp->maVer == LMA_VER1  && !(IS_EQUAL_VER1(teDef->verFlg))) ||
       (ctlp->maVer == LMA_VER2  && !(IS_EQUAL_VER2(teDef->verFlg))) ||
       (ctlp->maVer == LMA_VER2P && !(IS_EQUAL_VER2P(teDef->verFlg)))||
       (ctlp->maVer == LMA_VER4  && !(IS_EQUAL_VER4(teDef->verFlg)))
        )
     {
        /*skip the elmnt in data base and make as not present in event str */
        maSkipSeqOf(ctlp);
        RETVALUE(ROK);
     }

  }

  /* Find the length of sequence */

  if ((ret = maFindLen(mBuf,0,&seqLen,&eocFlg, &lfLen)) != ROK)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    RETVALUE(ret);
  }
 
  (Void)SFndLenMsg (mBuf, &msgLen);

  if (msgLen < seqLen)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maDecMinSeqOf() failed, invalid msgLen(%d).\n", msgLen));  
    RETVALUE(RFAILED);
  }

  #ifndef ALIGN_64BIT

  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecMinSeqOf: Decoding Sequence Of ......\n \
          %s Tag [%x] Len [%x] Counter %ld \n",
          maEleType[teDef->type], data, seqLen, cntr));

  #else
 
  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecMinSeqOf: Decoding Sequence Of ......\n \
          %s Tag [%x] Len [%x] Counter %d \n",
          maEleType[teDef->type], data, seqLen, cntr));
  
  #endif /* ALIGN_64BIT */ 
  /* decode the sequence */
  (Void)SRemPreMsg(&data, mBuf); 

  /* remove the length byte */
  if ((ret = maRemLen(mBuf, &remEocFlg)) != ROK)
  {
    ctlp->errCode = MAT_MISTYPE_PARAM;
    RETVALUE(ret);
  }

  ctlp->sTelDef++;
  stTelDef = ctlp->sTelDef;
  while (cntr)
  {
    ctlp->sTelDef = stTelDef;
    teDef = *ctlp->sTelDef;
    SFndLenMsg(ctlp->mBuf, &orgMsgLen);
    if (seqLen == 0)
    {
       if ( (ret = maChkEleMand(ctlp)) != ROK)
       {
         if (msgLen == orgMsgLen)
         {
            ctlp->errCode = MAT_DATA_MISSING;
            MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
            "maDecMinSeqOf() failed, mand. data missing.\n"));  
            RETVALUE(RFAILED);
         }
       }
       break;
    }
    switch (teDef->type)
    {
      case MA_TET_U8:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecMinSeqOf() failed at token(%d), fail to find len.\n", teDef->type));  
           RETVALUE(ret);
        }
        ret = maDecOctet(ctlp,FALSE);
        break;
      case MA_TET_U8_ENUM:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecMinSeqOf() failed at token(%d), fail to find len.\n", teDef->type));  
           RETVALUE(ret);
        }
        ret = maDecOctet(ctlp,TRUE);
        break;
      case MA_TET_NULL:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecMinSeqOf() failed at token(%d), fail to find len.\n", teDef->type));  
           RETVALUE(ret);
        }
        ret = maDecNull(ctlp);
        break;
        case MA_TET_INT:
          if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
          {
             ctlp->errCode = MAT_MISTYPE_PARAM;
             MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
             "maDecMinSeqOf() failed at token(%d), fail to find len.\n", teDef->type));  
             RETVALUE(ret);
          }
          ret = maDecInt(ctlp);
          break;
      case MA_TET_STR:
      case MA_TET_STRS:
      case MA_TET_STRM:
      case MA_TET_STRE:
#ifdef XWEXT
      case MA_TET_STR4:
#endif
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecMinSeqOf() failed at token(%d), fail to find len.\n", teDef->type));  
           RETVALUE(ret);
        }
        ret = maDecStr(ctlp);
        break;
      case MA_TET_STRUL:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecMinSeqOf() failed at token(%d), fail to find len.\n", teDef->type));  
           RETVALUE(ret);
        }
        ret = maDecStrUL(ctlp);
        break;
      case MA_TET_BITSTR:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecMinSeqOf() failed at token(%d), fail to find len.\n", teDef->type));  
           RETVALUE(ret);
        }
        ret = maDecBitStr(ctlp);
        break;
      case MA_TET_SEQ:
      case MA_TET_EXT_CONT:
        if ((ret = maFindLen(ctlp->mBuf, 0, &tmpLen, &eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPED_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecMinSeqOf() failed, fail to find len.\n"));  
           RETVALUE(ret);
        }
        ret = maDecSeq(ctlp);
        break;
      case MA_TET_SEQ_OF:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecMinSeqOf() failed at token(%d), fail to find len.\n", teDef->type));  
           RETVALUE(ret);
        }
        ret = maDecSeqOf(ctlp);
        break;
      case MA_TET_CHOICE:
        if ((ret = maFindLen(mBuf,0,&tmpLen,&eocFlg, &lfLen)) != ROK)
        {
           ctlp->errCode = MAT_MISTYPE_PARAM;
           MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
           "maDecMinSeqOf() failed at token(%d), fail to find len.\n", teDef->type));  
           RETVALUE(ret);
        }
        ret = maDecChoice(ctlp);
        break;
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
        MALOGERROR(ERRCLS_DEBUG, EMA330, (ErrVal)teDef->type, "maDecMinSeqOf () Failed");
#endif
         break;
    }
    if (ret != ROK)
    {
       MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
       "maDecMinSeqOf() failed, fail to decode el. type(%d).\n", teDef->type));  
       RETVALUE(RFAILED);
    }
    SFndLenMsg(ctlp->mBuf, &newMsgLen);
    if (orgMsgLen != newMsgLen)
    {
       seqLen -= orgMsgLen - newMsgLen;
       counter++;
    }
    cntr--;
  }
  if (counter < minCntr)
  {
    ctlp->errCode = MAT_DATA_MISSING;
    MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
    "maDecMinSeqOf() failed, mand. data missing.\n"));  
    RETVALUE(RFAILED);
  }
  while(cntr)
  {
    ctlp->sTelDef = stTelDef;
    maSkipTkns(ctlp);
    cntr--;
  }
  if (remEocFlg == TRUE)
  {
    /* remove the two EOC bytes */
    if ((ret = SRemPreMsgMult(unPkArray, (MsgLen)2, mBuf)) != ROK)
    {
       ctlp->errCode = MAT_MISTYPE_PARAM;
       MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
       "maDecMinSeqOf() failed, fail to remove two eoc byte.\n"));  
       RETVALUE(RFAILED);
    }
  }

  MADBGP(MA_DBGMASK_DECODE, (maCb.maInit.prntBuf, 
         "maDecMinSeqOf: decode Sequence Of Successfully.\n"));

  /* skip the End of Seq Of pointer */
  ctlp->sTelDef++;
  RETVALUE(ROK);
} /* end of MaDecMinSeqOf */

#endif /* MAP_REL99 */


/*
*
*       Fun:   maDecExtCont
*
*       Desc:  This function  decodes the parameters for MAP
*              Service Specific request 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC  S16 maDecExtCont
(
MaSap        *s,        /* Map SAP pointer */
U8           *sSt,      /* pointer to source structure */
U8           maVer,     /* Map version used for encoding */
U8           swtch,     /* switch */ 
U16          idx        /* Source message index */
)
#else
PUBLIC  S16 maDecExtCont(s, sSt, maVer, swtch, idx)
MaSap        *s;        /* Map SAP pointer */
U8           *sSt;      /* pointer to source structure */
U8           maVer;     /* Map version used for encoding */
U8           swtch;     /* switch */ 
U16          idx;       /* Source message index */
#endif
{
  MaMsgCtl *ctlp;
  S16    ret;

  TRC2(maDecExtCont)
  ctlp = &s->ctlp;
  maInitMsgCtl(ctlp);
  ctlp->mBuf = s->crntRxMsg;
  ctlp->sSt = sSt;  
  ctlp->maVer = maVer;
  ctlp->swtch = swtch;
  ctlp->skip = FALSE;
  ctlp->encode = FALSE;
  ctlp->decode = TRUE;
  ctlp->errCode = 0;

  /* get the appropriate database definition based on database type */

  ctlp->sTelDef = maAllSSErrPduDefs[idx];

  /* decode the message parameters */
  ret = maDecSeq(ctlp);

  RETVALUE(ret);

} /* maDecExtCont*/

#if MAP_REL99
#if (MAP_SEC && LMAV2)
/*
*
*       Fun:   maChkObjId    
*
*       Desc:  This function encodes/decodes/skip Object Id
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkObjId 
(
MaMsgCtl    *ctlp        /* message contro pointer */
)
#else
PUBLIC S16 maChkObjId (ctlp)
MaMsgCtl    *ctlp;        /* message contro pointer */
#endif
{

  TRC2 (maChkObjId)
  
  MADBGP(LMA_DBGMASK_GEN, (maCb.maInit.prntBuf, 
         "maChkObjId() failed: wrong element type\n" ));

  RETVALUE(RFAILED);
} /* maChkObjId  */
#endif
#endif

#ifdef MA_ASN_NO_INDEF_LEN
/*
*
*       Fun:   maEncLen    
*
*       Desc:  This function encodes message in definite form, if the message
*              length is more than 128 bytes
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_mf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maEncLen 
(
Buffer      *mBuf,        /* message buffer */
MsgLen      orgLen,       /* original length */
MsgLen      curLen        /* current length */
)
#else
PUBLIC S16 maEncLen (mBuf, orgLen, curLen)
Buffer      *mBuf;        /* message buffer */
MsgLen      orgLen;       /* original length */
MsgLen      curLen;       /* current length */
#endif
{
  MsgLen  tmpLen;      /* temporary length variable */
  U16     numBytes;    /* number of bytes copied */
  Buffer  *tmpBuf;     /* temp buffer */
  Data    pkArray[10];
  S16     ret;         /* return value */
  Data    data;        /* tmp data */
  U8      i;           /* counter */

  TRC2 (maEncLen)
  
  /* length will not fit in one byte */

  tmpLen = curLen - orgLen;    /* store the length */ 
  i = 0;                       /* initialize the loop counter */

  /* find the number bytes to encode in length */
  while (tmpLen != 0)
  {
     tmpLen = (tmpLen >> MA_NUMBITS_BYTE);
     i++; 
  }

  numBytes = (i+1);    /* indicate number of bytes, include 1st byte also */
  tmpLen = curLen - orgLen;   /* store the length */ 

  /* encode the length now. The first byte contains the EOC_FLAG
     and the number of bytes in the length field */

  /* Check we should include the first byte here or not */

  pkArray[0] = (MA_EOC_LEN | i);

  for (; i > 0; i--)
  {
     pkArray[i] = (tmpLen & 0xff);        /* copy the LSB */
     tmpLen = (tmpLen >> MA_NUMBITS_BYTE);   /* shift out the LSB */
  }

  /* split the encoded buffer at the appropriate index */
  ret = SSegMsg(mBuf, orgLen-1, &tmpBuf);
  if (ret != ROK)
  {
     MADBGP(MA_DBGMASK_ENCODE,(maCb.maInit.prntBuf, "maEncLen:SSegMsg failed.\n"));
     /* mBuf will be freed by the parent function */
     if(tmpBuf != (Buffer *)NULLP)
     {
        SPutMsg(tmpBuf);
     }
     RETVALUE(RFAILED);
  }

  /* copy the static encoded string to message buffer */
  if ((ret = SAddPstMsgMult((Data *)pkArray, numBytes, mBuf)) != ROK)
  {
     MADBGP(MA_DBGMASK_ENCODE,(maCb.maInit.prntBuf, 
        "maEncLen:SAddPstMsgMult failed.\n"));
     if(tmpBuf != (Buffer *)NULLP)
     {
        SPutMsg(tmpBuf);
     }
     RETVALUE(RFAILED);
  }

  if ((ret = SRemPreMsg(&data, tmpBuf)) != ROK)
  {
     MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
        "maEncLen: SRemPreMsg failed.\n"));
     if(tmpBuf != (Buffer *)NULLP)
     {
        SPutMsg(tmpBuf);
     }
     RETVALUE(RFAILED);
  }

  if ((ret = SCatMsg(mBuf, tmpBuf, M1M2)) != ROK)
  {
     MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf,"maEncLen: SCatMsg failed.\n"));
     if(tmpBuf != (Buffer *)NULLP)
     {
        SPutMsg(tmpBuf);
     }
     RETVALUE(RFAILED);
  }

  SPutMsg(tmpBuf);

  MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
         " maEncLen: Len [%x]\n", (curLen - orgLen)));

  RETVALUE(ROK);
} /* maEncLen  */
#endif /* MA_ASN_NO_INDEF_LEN */

#ifdef XWEXT
PUBLIC S16 maEncStart(MaMsgCtl *ctlp)
{
   S16 ret;
   
   /* encode the message parameters */
   ret = maEncTknElmts(ctlp);
   RETVALUE(ret);	
}

PUBLIC S16 maDecStart(MaMsgCtl *ctlp)
{
   S16 ret;
   
   /* encode the message parameters */
   ret = maDecTknElmts(ctlp);
   RETVALUE(ret);	
}
#endif
/********************************************************************30**

         End of file:     ca_mf.c@@/main/11 - Fri Sep 16 02:48:20 2005

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/


/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  aa    1. initial release

1.2          ---  aa    1. text changes

*********************************************************************81*/
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.3          ---      aa   1. Fixed the bug in maChkBasicServ (while decoding 
                              the bearer service ENUM falg was set to TRUE 
             ---      aa   2. Fixed the bug in maDecSeq and maDecSeqOf (the 
                              length of sequence (remaining) was calculated
                              wrongly if any optional parameter is missing in
                              the sequence)
             ---      aa   3. Corrcetd the bug in the if statement for checking
                              the element is mandatory or not in functions 
                              maEnc*.
 
             ---      aa   4. Fixed the bug in maChkBasicServ and maDecSeqOf
 
1.4          ---      aa   1. Fix the bug in maChkBasicServ
             ---      aa   2. Fixed the bug in maSkipSeqOf
             ---      sg   3. Fixed bug in maDecSeq.
             ---      sg   4. Fixed bug in maEncSeqOf.
                               Fixed bug in maDecSeqOf.
                               Fixed bug in maEncSeq.
                               Fixed bug in maSkipSeqOf.
             ---      sg   5. Fixed bug in maDecStr.
             ---      sg   6. Fixed bugs in maChkISSRsp
             ---      ssk  7. Fixed SSInfo Choice bug in maChkSSInfo.
             ---      ssk  8. Added MAP Phase 2+ variant.            

1.5          ---      ssk  1. phase 2+ gpr release.          
 
1.6          ---      ssk  1. Decoding of choice is made sophisticated to 
                              decode choice within choices.
             ---      ssk  1. Decoding & Encoding of Bit String is 
                              generalized.
             ---      ssk  1. length of length field removal problem 
                              in maRemLen() is corrected.
             ---      ssk  2. Extension marker(ellipsis) related change 
                              in the decode sequence function().
 
             ---      ssk  3. Version flag check is written without     
                              assuming the individual bit for the version
                              concept.
 
             ---      ssk  4. Integer ASN.1 Primitive related change.
                              Eoc flag is initialized in maRemLen() fn.
 
             ---      ssk  5. maDecInt() function is corrected.
 
             ---      ssk  6. Numeric string related Decode/Encode is 
                              performed.
 
             ---      ssk  7. Added Decode and Encode routines for tagged
                              choice type. 
 
             ---      ssk  8. Corrected the declarations inside maDecTag
                              Choice routine. 
 
             ---      ssk  9. Corrected the problem in EncTagChoice for 
                              Phase-2 messages. 

/main/6      ---      jie  1. update for MAP 1.5 release.
 
             ---      jie  1. Addition - if veriosn is not compatible, 
                              skips it in maDecNull function 

             ---      jie  1. Rolling Upgrade compliance.

             ---      jie  1. Change for 3.9.0 REL_99 support.

             ---      yz   1. Adding debug print for RFAILED case. 

             ---      yz   1. Correct an error param in DBUGP. 
                           2. Correct an function params.

             ---      yz   1. Correct return errCode for data miss.
                           2. Correct return errCode for certain data 
                              error.

             ---      jie  1. Change for MAP REL4 support without the MAPsec 
                              feature.

             ---      yz   2. Change to add extCont to dlgPdu.

             ---      jie  1. Changed to TRC2 for layer support functions.

             ---      jie  1. Changes for performance improvement.

/main/7      ---      jie  1. update for MAP 1.6 release.

             ---      yz   1. Addition of MAP segmentation feature from 1.5.

             ---      yz   2. Change to avoid encoding empty mand seq.

             ---      jie  3. Change for 2002/09 rel99/rel4 release.

/main/8      ---      jie  1. update for MAP 1.7 release.

             ---      jie  1. maChkSeq2() corrected for ellipsis decoding
                           2. Addition for definite length encoding

             ---      jie  1. Phase-1 changes for June-03 specifications 
                              for release 4 & 5

             ---      jie  1. Phase-2 changes for June-03 specifications 
                              for release 4 & 5

/main/10     ---      zj   1. Update for MAP 2.1 release
             ---      st   1. Remove unused parameter in maChkSeq3()
             ---      st   2. Error code should be returned when 
                              mandatory element is missing.
                           3. Error code should be returned when
                              integer is out of range.
             ---      st   1. Added exceptional handling for 
                              Unavailable Cause parameter. Done as a 
                              part of Rel 5 upgrade.
/main/11     ---     rbabu 1. Update for MAP 2.3 release
ma001.203		---		st   1. Added Tag information in debug prints 
         ma002.203    dv   1. Introduced maCb global control block.
                           2. Moved global variables to maCb.
                           3. Introduced SS_MULTIPLE_PROCS to aid
                              in internal testing.
                           4. Added check in maDecSeq and maDecSeqOf to
                              return failure if seqLen is 0 and any of its
                              mandatory elements is missing.Introduced 
                              MA_ASN_DEC_SEQ flag for this.
/main/11  ma005.203  rb     1.Corrected the Extension Marker
                              Decoder issue.
                             a)Length information is copied to token
/main/11  ma007.203  dm    1. If extra element is coming in message, 
			      print the extra buffer  
*********************************************************************91*/

