#ifdef CP_OAM_SUPPORT
/**********************************************************************

    Name:   ma_nms.c 

    Type:   C source file

    Desc:   

    File:   ma_nms.c

    Sid:    

    Created by: 

**********************************************************************/
/*#include <stdio.h>
#include <string.h>
#include <stdlib.h>
*/

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_err.h"        /* common error */
#include "cm_llist.h"      /* common llist */
#include "cm_ss7.h"        /* common ss7 */

#include "ss_err.h"        /* system services error code*/
#include "ss_queue.h"      /* queues */
#include "ss_task.h"       /* tasking */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */
#include "stu.h"
#include "mat.h"
#include "lma.h"
#include "ma.h"

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* common timer */
#include "cm_lib.x"        /* Common Portable Library */
#include "cm_llist.x"      /* common llist */
#include "cm_ss7.x"        /* common ss7 */

#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */
#include "stu.x"
#include "lma.x"
#include "mat.x"
#include "ma.x"

#include "xosshell.h"
#include "oam_interface.h"
#include "ma_nms.h"
#include "cp_tab_def.h"
#include "cp_oam_stru.x"
#include "cp_oam_stru.h"
#include "sm.h"
#include "sm.x"
#include "ma_oam.x"
#include "ma_cfg.h"
#include "ma_bind.h"

EXTERN MaCb maCb;

void TestPrintGen()
{
#ifdef MA_SEG 
   printf("\r\n[MAP general config]\n");

   printf("[MAP]Gen Cfg Table row number :%d\n", gMaCfgData.maGenCfgNum);
   printf("---------------------------------\r\n");
   printf("\tsigFrameSz\r\n");
   printf("\t%d\r\n", maCb.maCP.sigFrameSz);
   printf("---------------------------------\r\n");
#else
   printf("MA_SEC is not supported!\r\n\r\n");
#endif
}

void TestPrintSap()
{
	U8		i,num = 0;
	MaSap	*s = NULLP;
	
	printf("[MAP sap attribute config]\n");
	for (i=0; i<maCb.maCP.nmbMAUSaps; i++)
	{
		if ((s=*(maCb.maSapLmaPtr+i)) != NULLP )
		{
			printf("[MAP]sap :%d\n", i);
			printf("\tmaGrdTmr\r\n");
			printf("---------------------------------\r\n");
			printf("\t%d\n", s->cfg.maGrdTmr.val);
			printf("---------------------------------\r\n\r\n");
			num++;
		}
	}
	printf("[MAP]total num: %d\n\r\n", num);
}

void TestPrintAcn()
{
	U8		i,num = 0;
	MaSap	*s = NULLP;
	
	printf("[MAP ACN Cfg Table]\n");
	for (i=0; i<maCb.maCP.nmbMAUSaps; i++)
	{
		if ((s=*(maCb.maSapLmaPtr+i)) != NULLP )
		{
				printf("[MAP]sap :%d\n", gMaCfgData.maAcnCfgNum);
				printf("\tmaVer\n");
				printf("---------------------------------\r\n");
				printf("\t%d\n", s->cfg.apnCfg[0].maVer);
				printf("---------------------------------\r\n");
				num++;
		}
	}
	printf("[MAP]total num: %d\n\r\n", num);
}

void maInitCfgData(void)
{
	TRC2(maInitCfgData);

	gMaCfgData.maGenCfgNum= 0;
	gMaCfgData.maSapCfgNum = 0;
}

VOID maResetCfgData( )
{
    /*the static cfg data never dbe used after cfg completion*/
    /*because MAP have not dynamic cfg data, so the reset function will do nothing*/
}

S16 maRecvInitCfg(tb_record* prow)
{
	MaGenCfgTab				*pmaGenCfg = NULLP;
	MaMAUCfgTab				*pmaSapCfg = NULLP;
	MaACNCfgTab				*pmaAcnCfg = NULLP;
	CP_OAM_SS7_SSN_TAB		*pmaSsnCfg = NULLP;
	CP_OAM_SS7_UP_TAB		*pmaUpCfg  = NULLP;
	CP_OAM_SS7_NETWORK_TAB	*pmaNwkCfg = NULLP;
        
	while(prow)
	{
		switch(prow->tableid)
		{
			case APP_TABLE_ID_SS7_MAP_GEN:
				pmaGenCfg = (MaGenCfgTab *) prow->panytbrow;
				
				gMaCfgData.maGenCfgNum++;
				gMaCfgData.maGenCfg.sigFrameSz = pmaGenCfg->sigFrameSz;
				break;

			case APP_TABLE_ID_SS7_MAP_SAP:
				pmaSapCfg = (MaMAUCfgTab*) prow->panytbrow;
            if(pmaSapCfg->maGrdTmr<0)
            {
                printf("\r\n***********SAP cfg val is unavailable!********\r\n");
                RETVALUE(RFAILED);                    
            }
				gMaCfgData.maSapCfgNum++;
				gMaCfgData.maSapCfg.maGrdTmr = pmaSapCfg->maGrdTmr;
/*            gMaCfgData.maSapCfg[gMaCfgData.maSapCfgNum-1].sapId= pmaSapCfg->sapId;*/

				break;

			case APP_TABLE_ID_SS7_MAP_ACN:
	            pmaAcnCfg = (MaACNCfgTab*) prow->panytbrow;
	            gMaCfgData.maAcnCfgNum++;
	            gMaCfgData.maAcnCfg.maVer= pmaAcnCfg->maVer;

	            break;

            
			case APP_TABLE_ID_SS7_SSN:
				pmaSsnCfg = (CP_OAM_SS7_SSN_TAB*)prow->panytbrow;
				CpSs7SetOneSsnTab(EN_CP_OPR_ADD, pmaSsnCfg);

				break;
			
			case APP_TABLE_ID_SS7_UP:
				pmaUpCfg = (CP_OAM_SS7_UP_TAB*)prow->panytbrow;
				CpSs7SetOneUpTab(EN_CP_OPR_ADD, pmaUpCfg);

				break;

			case APP_TABLE_ID_SS7_NWK:
				pmaNwkCfg = (CP_OAM_SS7_NETWORK_TAB*)prow->panytbrow;
				CpSs7SetOneNwkTab(EN_CP_OPR_ADD, pmaNwkCfg);

				break;
         default:
				break;
		}

		prow = prow->next;
	}

	RETVALUE(ROK);
}


S16 maCfgMsg()
{
	U16 i;
	S16 ret = ROK;

    /* static config data only be done in config start phase, and it would not change after system started*/
	if( gSmCb[ENTMA].smStatus == SM_INIT_CFG_STATE)
    {
        ret  =  maGenCfg(0);
        if( ROK != ret)
        {
            RETVALUE(ret);
        }

        /* create tsap config msg */
        for( i = 0; i < gstCpSs7Global.SSNTabNum; i++)
        {
            ret = maSapCfg(i);
            if(ROK != ret)
            {
                RETVALUE(ret);
            }            
        }

        RETVALUE(ROK);
    }
    printf("it is not in SM_INIT_CFG_STATE\r\n");
    RETVALUE(ROK);
}

unsigned char maInitCfgCallback(unsigned short msgtype, unsigned int sepuense, unsigned char pack_end, tb_record* prow)
{

	if(ROK != maRecvInitCfg(prow))
	{
		opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
		RETVALUE(RFAILED);
	} 	

	if(TRUE == pack_end)
	{
		if(ROK != maCfgMsg())
		{
			opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
		  RETVALUE(RFAILED);
		} 	

		/* send out a config req message to sm*/
		if( ROK != smSendCfgReq(ENTMA, SM_INIT_CFG_STATE))
		{
			opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
	    RETVALUE(RFAILED);                         
		}

		/* wait initial cofiguration finished*/
		ssWaitSema(&gSmCb[ENTMA].sema);

		/* send response to subagent*/
		if(SM_SUCCESS_STATE ==  gSmCb[ENTMA].smStatus)
		{
			/* All the initialization configuration data is processed successfully */
			opt_response_batch(sepuense, OAM_RESPONSE_OK);
            #ifndef MATST
			maBndStReq();            /* MAP BND TCAP  */
            #endif
		}
		else 
		{
			opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
		}

    smReset(ENTMA);
	
	}

#ifdef CP_OAM_DATA_SHOW   
    TestPrintGen();
    TestPrintSap();
    TestPrintAcn();
#endif
   
    RETVALUE(ROK);
}


#endif /*CP_OAM_SUPPORT*/
