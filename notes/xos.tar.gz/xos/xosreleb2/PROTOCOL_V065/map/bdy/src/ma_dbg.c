/* header include files (.h) */
#ifdef SSI_WITH_CLI_ENABLED

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "ss_err.h"        /* errors */
#include "ss_dep.h"        /* implementation-specific */
#include "ss_queue.h"      /* queues */
#include "ss_task.h"       /* tasking */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */

#include "cm5.h"
#include "cm_ss7.h"
#include "cm_err.h"        /* common error */
#include "cm_llist.h"

#include "stu.h"           /* tcap upper interface */
#include "mat.h"           /* inap upper interface */
#include "lma.h"           /* layer management interface */
#include "mat.h"
#include "ma.h"

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "ss_dep.x"        /* implementation-specific */
#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */

#include "cm5.x"
#include "cm_ss7.x"        /* Common */
#include "cm_lib.x"        /* Common library headers */
#include "cm_llist.x"

#include "stu.x"           /* tcap upper interface */
#include "lma.x"           /* layer management interface */
#include "mat.x"           /* inap upper interface */
#include "ma.x"

/* header include files (.h) */

#ifdef MA_FTHA
#include "sht.h"           /* SHT interface */
#endif /* MA_FTHA */
#ifdef MA_CLI_ACCDBG
#include "ma_acc.h"        /* acceptance test defines */
#endif
#include "ma.h"
#include "ma_err.h"        /* error defines */
#include "ma_mf.h"

#ifdef MA_FTHA
#include "sht.x"           /* SHT interface */
#endif /* MA_FTHA */
#ifdef MA_CLI_ACCDBG
#include "ma.x"
#include "ma_acc.x"        /* acceptance test defines */
#endif
#ifdef CP_OAM_SUPPORT
#include "xosshell.h"
#include "oam_interface.h"
#include "oam_tab_def.h"
#include "cp_oam_stru.x"
#include "ma_nms.h"
#include "cp_tab_def.h"
#include "cp_oam_stru.x"
#include "cp_oam_stru.h"
#include "sm.h"
#include "sm.x"
#include "ma_oam.x"
#include "ma_cfg.h"
#endif

#include "clishell.h"
#include "ma_dbg.h"

/******************************************************
 *SSI_WITH_CLI_ENABLED : macro for link XOS platform code
 *
 *MA_CLI_ACCDBG : macro for use trilllium ACC test code
 *
 *******************************************************/

#ifdef MA_CLI_ACCDBG
EXTERN MaAccCb     maAccCb;   /* MAP Acceptance Test control block */
EXTERN SsOs osCp;
EXTERN Cntr     cfgNumRegs;
EXTERN SsRegCfg cfgRegInfo[SS_MAX_REGS];
EXTERN U8        maAccOprCode;  /* Sample Operation code  */

EXTERN PUBLIC  S16 maInitAccCb(Void);
EXTERN PUBLIC   S16  maAccCfgMaTst(Void);
EXTERN PUBLIC   S16   maDispTstInfo(U16 tstId);
#endif /*MA_CLI_ACCDBG*/

EXTERN PUBLIC S16 ssiInit();

#define DBGPrntCntr(x) \
   if(s->sts.x > 0)\
   {\
   sprintf(prntBuf, "\t%-21s \t %10ld\n", #x,s->sts.x);\
   XOS_CliExtPrintf(pCliEnv, prntBuf);\
   }

XS16 MaDbgPstInit(Pst *smPst)
{
	smPst->region    = MADBG_REGION;
	smPst->pool      = MADBG_POOL;
	smPst->prior     = PRIOR0;
	smPst->route     = RTESPEC;
#ifdef SS_MULTIPLE_PROCS
	smPst->dstProcId = MADBG_PROCID0;
#else
	smPst->dstProcId = SFndProcId();
#endif
	smPst->dstEnt    = ENTMA;
	smPst->dstInst   = MADBG_INST_0;
#ifdef SS_MULTIPLE_PROCS
	smPst->srcProcId = MADBG_PROCID0;
#else
	smPst->srcProcId = SFndProcId();
#endif
	smPst->srcEnt    = ENTSM;
	smPst->srcInst   = MADBG_INST_0;

#ifdef LCSMMAMILMA
       smPst->selector  = MADBG_SEL_LC;
#else
	smPst->selector  = MADBG_SEL_TC;
#endif
	smPst->event = 0;
	smPst->intfVer = 0;

	return(XSUCC);
}

XS16 maDbgHdrInit(Header * hdr, TranId transId)
{
	hdr->msgType          = 0;
	hdr->msgLen           = 0;
	hdr->entId.ent        = 0;
	hdr->entId.inst       = 0;
	hdr->elmId.elmnt      = 0;
	hdr->elmId.elmntInst1 = 0;
	hdr->elmId.elmntInst2 = 0;
	hdr->elmId.elmntInst3 = 0;
	hdr->seqNmb           = 0;
	hdr->version          = 0;

#ifdef LMINT3
	hdr->transId             = transId;
	hdr->response.prior      = PRIOR0;
	hdr->response.route      = RTESPEC;
	hdr->response.mem.region = MADBG_REGION;
	hdr->response.mem.pool   = MADBG_POOL;
	hdr->response.selector   = MADBG_SEL_TC;
#endif

	return(XSUCC);
}

XS16 maPrntSts(MaSts *sts)
{
	return(XSUCC);
}

XS16 maPrntPost(CLI_ENV *pCliEnv, Pst *pst)
{
	XOS_CliExtPrintf(pCliEnv, "\tselector    :(%d)\r\n", pst->selector);	
	XOS_CliExtPrintf(pCliEnv, "\tregion      :(%d)\n\tpool        :(%d)\
                                 \n\tprior       :(%d)\n\tintfVer     :(%#x)\
                                 \n\troute       :(%d)\r\n", 
                    pst->region, pst->pool, pst->prior, pst->intfVer, pst->route);
	XOS_CliExtPrintf(pCliEnv, "\tdstProcId   :(%d)\n\tsrcProcId   :(%d)\r\n",
                                                 pst->dstProcId, pst->srcProcId);
	XOS_CliExtPrintf(pCliEnv, "\tdstEnt      :(%d)\n\tsrcEnt      :(%d)\r\n",
                                                pst->dstEnt, pst->srcEnt);
	XOS_CliExtPrintf(pCliEnv, "\tdstInst     :(%d)\n\tsrcInst     :(%d)\r\n",
                                                 pst->dstInst, pst->srcInst);

	return(XSUCC);
}

#ifdef MA_CLI_ACCDBG
XS16 tstCaseRun(CLI_ENV *pCliEnv, U16 caseid)
{
	static U16 nTests  = 0;
	static U16 nPTests = 0;
	static U16 nFTests = 0;
	Txt    prntBuf[1024];
	U16    idx;

	if(caseid >= MA_ACC_MAX_TESTS)
	{
		XOS_CliExtPrintf(pCliEnv, "\r\n\r\nthe case id is too large!\r\n\r\n");
	}
      /* Initialize the current test context */
      maAccCb.curTst.init     = FALSE;
      maAccCb.curTst.end      = FALSE;
      maAccCb.curTst.state    = 0;
      maAccCb.curTst.result   = 0;
      maAccCb.curTst.tstOnOff = TRUE;
      maAccCb.curTst.onOffCntr= 0;

      /* Initialize the corruption flag..it is set inside the test case
         function if the message is to be corrupted */
      maAccCb.curTst.cptFlag  = FALSE;
      maAccCb.curTst.idx      = 0;
      maAccCb.curTst.data     = 0;

      /* By default loopback the messages at the lower interface of TCAP,
         it can be changed within the test case routine to drop the message */
      maAccCb.curTst.loopBack = TRUE;

      /* By default enable the prints, can be disabled inside the test case */
      maAccCb.curTst.prntFlag = TRUE;

      /* Initialize the dialogues */
      for (idx = 0; idx < (U16) (MA_ACC_MAX_DLGS * 2); idx++)
      {
          maAccCb.dlgCp[idx].spId     = 0;
          maAccCb.dlgCp[idx].auDlgId  = 0;
          maAccCb.dlgCp[idx].smaDlgId = 0;
          maAccCb.dlgCp[idx].sstDlgId = 0;
          maAccCb.dlgCp[idx].dmaDlgId = 0;
          maAccCb.dlgCp[idx].dstDlgId = 0;
          (Void) maAccFlushCmpQ(idx);
      }

      /* Free the invokes */
      for ( idx = 1; idx <= MA_ACC_MAX_OPRS; idx++)
      {
         maAccCb.invTbl[idx-1] = FALSE;
      }

      /* Initialize the Message Queue */
      (Void)maAccFlushQ();

      maAccCb.curTst.id = caseid;
      if (maAccCb.curTst.id == 0xffff)
      {
         return(XSUCC);
      }

      /* Display the Information about the test case */
      maDispTstInfo(maAccCb.curTst.id);

      /* Invoke a test */
      if (maAccCb.tstTbl[maAccCb.curTst.id] != NULL)
      {
		while(maAccCb.curTst.end != TRUE)
		{
			(Void)(*maAccCb.tstTbl[maAccCb.curTst.id])();
		}

		/* Print the result of the last test */
		if (maAccCb.curTst.result == MA_TST_OK)
		{
			maAccCb.curTst.end = TRUE;
			sprintf(prntBuf, "\nTest Case %d has PASSED\n\n", (maAccCb.curTst.id + 1));
			XOS_CliExtPrintf(pCliEnv, prntBuf);
			nPTests++;
		}
		else if (maAccCb.curTst.result == MA_TST_FAILED)
		{
			maAccCb.curTst.end = TRUE;
			sprintf(prntBuf, "\nTest Case %d has FAILED\n\n", (maAccCb.curTst.id + 1));
			MALOGERROR(ERRCLS_DEBUG, EMA332, (ErrVal) (maAccCb.curTst.id + 1), 
			"Test has Failed");
			XOS_CliExtPrintf(pCliEnv, prntBuf);
		}
      }
      else
      {
         sprintf(prntBuf, "\r\n\r\nYou can not execute this test case as this test\n\
                 is not supposed to run under current configuration\r\n\r\n");
         SPrint(prntBuf);
         return(XERROR);
      }

	/*if config the map protocol*/
	while(!maAccCb.cfgDone)
	{
		if(maAccCfgMaTst() != ROK)
		{
			return(RFAILED);
		}
	}
   
   return(ROK);
}
#endif/*MA_CLI_ACCDBG*/

/* 
 * Function name: maFillAcn
 * Des:		      Fill ACN for according operation 
 * Return Value : ROK or RFAILED
 */
S16 maDbgFillAcn(U8 opCode, MaApConName *acn, MaApConName *altAcn, U8 *oprClass, U8 *maVer, U8 maSwtch)
{

   U8 cntxt;     
   U8 ver;     
   U8 altCntxt;     
   U8 altVer;     

   cntxt = ver = altCntxt = altVer = 0;
   acn->pres = TRUE;
   acn->len = 8;
   acn->val[0] = 0;
   acn->val[1] = 4;
   acn->val[2] = 0;
   acn->val[3] = 0;
   acn->val[4] = 1;
   acn->val[5] = 0;

   altAcn->pres = FALSE;
   altAcn->len = 0;
   altAcn->val[0] = 0;
   altAcn->val[1] = 4;
   altAcn->val[2] = 0;
   altAcn->val[3] = 0;
   altAcn->val[4] = 1;
   altAcn->val[5] = 0;

   switch(opCode)

   {

#if (MAP_MSC || MAP_VLR)  /*  B Interface */
   case MA_DET_IMSI:         /* MaDetIMSI */
   {
      *maVer   = LMA_VER1;
      *oprClass = MA_OPRCLASS4;
      RETVALUE(RFAILED);
   }

   case MA_TRACESUBSACTV:    /* MaTrSubsActv */
   {
      cntxt = MA_HO_CONTROL_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER1;
      *oprClass = MA_OPRCLASS4;
      break;
   }
#endif

#if MAP_VLR                   /*  G Interface */
   case MA_SNDID:             /* MaSendId */
   {
      cntxt = MA_INTVLRINFO_RET_AC;

#ifdef MAP_VER_V2   /* added by adam for SM v2/v3 2003-10-13 */
      ver   = 2; 
      *maVer   = LMA_VER2;
#else
      ver   =maSwtch;
#if 0 /* added by adam 2003-10-08 */
      *maVer   = LMA_VER1;
#else
      *maVer   = LMA_VER_ALL;
#endif
#endif

      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif


#if MAP_MSC
   case MA_NOTEINTERHO:      /* MaNotInterHo */
   {
      cntxt = MA_HO_CONTROL_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER1;
      *oprClass = MA_OPRCLASS4;
      break;
   }
   case MA_PER_HO:           /* MaPerHo */
   case MA_PER_SUBSHO:       /* MaPerSubHo */
   {
      cntxt = MA_HO_CONTROL_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER1;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_SNDENDSIG:        /* MaSndEndSig */
   {
      cntxt = MA_HO_CONTROL_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
/* modified by Bruce for MAPE 2003/6/19 */	  
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_PRE_HO:           /* MaPreHo */
   case MA_PRE_SUBSHO:       /* MaPreSubHo */
   {
      cntxt = MA_HO_CONTROL_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2AND2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_PROCACCSIG:       /* MaProcAccSig */
   case MA_FWDACCSIG:        /* MaFwdAccSig */
   {
      cntxt = MA_HO_CONTROL_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS4;
      break;
   }
   case MA_RESCALLHANDL:     /* MaResCallHandl */
   {
      cntxt = MA_CALL_CNTRL_TRANS_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_SND_GRPCALLENDSIG: /* MaSndGrpCallEndSig */
   {
      cntxt = MA_GRP_CALL_CNTRL_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS3;
      break;
   }
   case MA_PREP_GRPCALL:     /* MaPrepGrpCall */
   {
      cntxt = MA_GRP_CALL_CNTRL_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_PRO_GRPCALLSIG:   /* MaProGrpCallSig */
   case MA_FWD_GRPCALLSIG:   /* MaFwdGrpCallSig */
   {
      cntxt = MA_GRP_CALL_CNTRL_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS4;
      break;
   }
   case MA_PROV_SIWFS_NMB:   /* MaProvSiwfsNmb */
   case MA_SIWFS_SIGMOD:     /* MaSiwfsSigMod */
   {
      cntxt = MA_SIWFS_ALLOC_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif 

#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)
   case MA_SMRDY:            /* MaRdySM */
   {
      cntxt = MA_MWD_MNGMT_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2AND2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_PROVROAMNMB:      /* MaRoamNmb  */
   {
      cntxt = MA_ROAM_NMB_ENQUIRY_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }

   
#endif /* MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_MSC || MAP_VLR || MAP_HLR)  /* D Interface */
   case MA_REGSS:            /* MaRegSS */
   case MA_ERASESS:          /* MaEraseSS */
   case MA_ACTVSS:           /* MaActvSS */
   case MA_DACTVSS:          /* MaDactvSS */
   case MA_INTERSS:          /* MaInterSS */
   case MA_REGPASSWD:        /* MaRegPasswd */
   case MA_GETPASSWD:        /* MaGetPasswd */
   {
      cntxt = MA_NETFUNC_SS_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_PROCUSSREQ:       /* MaProcUSSReq */
   case MA_USSREQ:           /* MaUSSReq */
   case MA_USSNOTIFY:        /* MaUSSNotify */
   {
      cntxt = MA_NETWORK_USS_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2AND2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_PROCUSSDATA:      /* MaProcUSSDat */
   {
      cntxt = MA_NETFUNC_SS_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif /* MAP_MSC || MAP_VLR || MAP_HLR */

#if ( MAP_VLR || MAP_HLR)  /* D Interface */
   case MA_UPLOC:            /* MaUpLoc */
   {
      cntxt = MA_NETWORK_LOCUP_AC;
	  
#ifdef MAP_VER_V2   /* added by adam for v2/v3 2003-10-13 */
      ver   = 2; 
      *maVer   = LMA_VER2;
#else
       ver   = maSwtch;
	*maVer   = LMA_VER_ALL;
#endif
	  
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif 

#if ( MAP_VLR || MAP_HLR)  /* D Interface */
   case MA_SNDPARAM:         /* MaSndParam */
   {
      cntxt = MA_NETFUNC_SS_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_RESTOREDATA:      /* MaRestDat */
   {
      cntxt = MA_NETWORK_LOCUP_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER1;
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif

#if (MAP_MSC || MAP_VLR || MAP_HLR)
   case MA_FWDCHKSSIND:      /* NULL    */
   {
      cntxt = MA_NETWORK_LOCUP_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS4;
      break;
  }
#endif

#if (MAP_VLR || MAP_HLR)
   case MA_SNDIMSI:          /* MaSndIMSI */
   {
      cntxt = MA_IMSI_RET_AC;
      ver   =maSwtch;
      /* modified by shu.bu 2002/06/13 according to HLR request */
      #if 0
      *maVer   = LMA_VER2AND2P;
      #else
      *maVer   =  LMA_VER_ALL;
      #endif
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_BEGIN_SUBS_ACTV:  /* MaBgnSubActv */
   {
      cntxt = MA_NETFUNC_SS_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS4;
      break;
   }
   case MA_NOTSUBPRES:       /* MaNotSubPres */
   {
      cntxt = MA_MWD_MNGMT_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER1;
      *oprClass = MA_OPRCLASS4;
      break;
   }
   case MA_SETRPTSTATE:      /* MaSetRptState */
   case MA_STARPT:              /* MaStaRpt */
   case MA_RMTUSRFREE:       /* MaRmtUsrFree */
   {
      cntxt = MA_REPORTING_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif

#if (MAP_MSC || MAP_VLR || MAP_HLR)
   case MA_REGCCENT:         /* MaRegCcEnt */
   case MA_ERASECCENT:       /* MaEraseCcEnt */
   {
      cntxt = MA_CALL_COMP_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif  /* MSC || (VLR) || (HLR) */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MA_CANCELLOC:        /* MaCancelLoc */
   {
      cntxt = MA_CANCEL_LOC_AC;

#ifdef MAP_VER_V2   /* added by adam for v2/v3 2003-10-13 */
      ver   = 2; 
      *maVer   = LMA_VER2;
#else
       ver   = maSwtch;
	*maVer   = LMA_VER_ALL;
#endif
	  
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_RESET:            /* MaReset */
   {
      cntxt = MA_RESET_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS4;
      break;
   }
   case MA_PURGE:            /* MaPurgeMs */
   {
      cntxt = MA_MS_PURGING_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_INSSUBSDATA:      /* MaInsSubsDat */
   {
      cntxt = MA_NETWORK_LOCUP_AC;
      ver   =maSwtch;

      altCntxt = MA_GPRS_UPLOC_AC;
      altVer   = LMA_VER2P;

      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_DELSUBSDATA:      /* MaDelSubsDat */
   {
      cntxt = MA_SUBS_DATA_MNGMT_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_AUTHINFO:            /* MaAuthInfo */
   {
      cntxt = MA_INFO_RET_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_AUTHFAILRPT:            /* MaAuthFailRpt */
   {
      cntxt = MA_AUTH_FAILRPT_AC ;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   
#endif
#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MA_ACTVTRACE:        /* MaActvTr */
   {
      cntxt = MA_NETWORK_LOCUP_AC;
      ver   =maSwtch;

  
      altCntxt = MA_GPRS_UPLOC_AC;
      altVer = LMA_VER2P;
  
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_DACTVTRACE:       /* MaDactvTr */
   {
      cntxt = MA_TRACING_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MA_PROVSUBSINFO:     /* MaProvSubsInfo */
   {
      cntxt = MA_SUBS_INFO_ENQ_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif
/* added by Bruce for LCS 2003/7/3*/
    case MA_SENDROUTINFOFORLCS:          /* RoutInfo For LCS */
        {
           cntxt = MA_LOC_SVC_GATEWAY;
           ver   = maSwtch;
           *maVer   = LMA_VER2AND2P;
           *oprClass = MA_OPRCLASS1;
           break;
        }
    case MA_PROVSUBSLOC:          /* Provide Subscriber Location */
        {
           cntxt = MA_LOC_SVC_ENQUIRY;
           ver   = maSwtch;
           *maVer   = LMA_VER2AND2P;
           *oprClass = MA_OPRCLASS1;
           break;
        }
   case MA_SUBSLOCRPT:          /* Subscriber Location Report */
        {
           cntxt = MA_LOC_SVC_ENQUIRY;
           ver   = maSwtch;
           *maVer   = LMA_VER2AND2P;
           *oprClass = MA_OPRCLASS1;
           break;
        }

#if (MAP_MSC || MAP_HLR)     /* C Interface */
   case MA_ROUTINFO:         /* MaSndRoutInfo */
   {

      cntxt = MA_LOCINFO_RET_AC;
      ver   =maSwtch;

      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_ROUTINFOSM:       /* MaRoutInfoSM */
   {
      cntxt = MA_SM_GATEWAY_AC;
	  
#ifdef MAP_VER_V2   /* added by adam for SM v2/v3 2003-09-23 */
      ver   = 2; 
      *maVer   = LMA_VER2;
#else
       ver   = maSwtch;
	*maVer   = LMA_VER_ALL;
#endif

      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_SMDEL:            /* MaRepSMDel */
   {
      cntxt = MA_SM_GATEWAY_AC;
       ver   = maSwtch;
	*maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }

   case MA_INFSC:            /* MaInformSC */
   {
      cntxt = MA_SM_GATEWAY_AC;
	  
#ifdef MAP_VER_V2   /* added by adam for SM v2/v3 2003-10-14 */
      ver   = 2; 
      *maVer   = LMA_VER2;
#else
       ver   = maSwtch;
	*maVer   = LMA_VER2AND2P;
#endif

      *oprClass = MA_OPRCLASS4;
      break;
   }
   case MA_ALRTSC:           /* MaAlrtSC */
   {
      cntxt = MA_SM_ALERT_AC;
#if 0 /* added by adam 2003-11-27 */
      ver   =maSwtch;
      *maVer   = LMA_VER2AND2P;
#else
      ver   = 2; 
      *maVer   = LMA_VER2;
#endif
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_ALRTSCWRSLT:      /* MaAlrtSCWRslt */
   {
      cntxt = MA_SM_ALERT_AC;
#if 0 /* added by adam 2003-11-27 */
      ver   =maSwtch;
      *maVer   = LMA_VER1;
#else
      ver   = 2; 
      *maVer   = LMA_VER2;
#endif
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif

#if (MAP_MSC || MAP_HLR)
   case MA_SSINV_NOTIFY:     /* MaSSInvNot */
   {
      cntxt = MA_SSINV_NOTIFY_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }

#endif

#if (MAP_HLR || MAP_GSN)        /* Gr Interface */
   case MA_GPRS_UPLOC:        /*   MaGprsUpLoc */
   {
      cntxt = MA_GPRS_UPLOC_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_GPRS_ROUTINFO:     /* MaGprsRoutInfo */
   {
      cntxt = MA_GPRS_LOCINFO_RET_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_FAILRPT:           /*  MaFailRpt */
   {
      cntxt = MA_FAILRPT_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_GPRS_NOTEMSPRES:   /* MaGprsNoteMsPres */
   {
      cntxt = MA_GPRS_NOTIFY_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif 

#if (MAP_MSC || MAP_GSN)     /* Gd Interface */

   case MA_FWDSM:            /* MaFwdSM */
   {
      cntxt = MA_SM_MO_RELAY_AC;
	  
#ifdef MAP_VER_V2   /* added by adam for SM v2/v3 2003-11-19 */
      ver   = 2; 
      *maVer   = LMA_VER2;
#else
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
#endif

      *oprClass = MA_OPRCLASS1;
      break;
   }

   case MA_MT_FWDSM:          /* MaMoFwdSM */
   {
      cntxt = MA_SM_MT_RELAY_AC;
	  
#ifdef MAP_VER_V2   /* added by adam for SM v2/v3 2003-09-23 */
      ver   = 2; 
      *maVer   = LMA_VER2;
#else
       ver   = maSwtch;
	*maVer   = LMA_VER_ALL;
#endif

      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif  

#if (MAP_MSC || MAP_VLR || MAP_GSN)
   case MA_CHKIMEI:          /* MaChkIMEI */
   {
      cntxt = MA_EQP_MNGMT_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif


#if MAP_HLR
   case MA_ANY_INTER:           /* MaAnyInter */
   {
      cntxt = MA_ANY_TIME_ENQUIRY_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
    
    #ifdef MAP_29_002 /* Added by Felix for CAMEL */   
    case MA_ANYSUBSINTER:            /* maAnySubsInter */   
    {   
       cntxt = MA_ANY_INFO_HNDL_AC ;   
       ver   =maSwtch;   
       *maVer   = LMA_VER2P;   
       *oprClass = MA_OPRCLASS1;   
       break;   
    }   
    #endif 

#endif /* MAP_HLR */

#ifdef MAP_3G_R4   
    case MA_ANY_MOD:            /* maAnySubsInter */   
    {   
       cntxt = MA_ANY_INFO_HNDL_AC ;   
       ver   =maSwtch;   
       *maVer   = LMA_VER2P;   
       *oprClass = MA_OPRCLASS1;   
       break;   
    }
	
    case MA_NOTE_SUBSDATA_MOD:            /* maAnySubsInter */   
    {   
       cntxt =  MA_SUBS_DATA_MODI_NOT;   
       ver   =maSwtch;   
       *maVer   = LMA_VER2P;   
       *oprClass = MA_OPRCLASS1;   
       break;   
    }   
	
#endif 

   default: 
   {
      RETVALUE(RFAILED);
   }
  }

   acn->val[6] = cntxt;
   acn->val[7] = ver;

   RETVALUE(ROK);
} /* maAccFillAcn */


/* 
 * Function name: maFillAcnCfg
 * Des:		      Fill ACN for all Operation for Map layer 
 * Return Value : ROK or RFAILED
 */
S16 maDbgFillAcnCfg(MaApnCfg *apnCfg, U8 swtch)
{
   U8 i=0;
   U8 j=0;
   U8 k=0;
   MaApConName apn;
   MaApConName altApn;
   
   for (i=0; i < MA_MAX_OPR; i++)
   {
      cmZero((PTR)&apnCfg[i],sizeof(MaApnCfg));
   }

   for(i = 0;i<MA_MAX_OPR;i++)
   {
#if MA_LMINT3
      if(maDbgFillAcn(i,&apn,&altApn,&apnCfg[j].oprClass, &apnCfg[j].maVer, swtch) 
                     == RFAILED)
#else /* MA_LMINT3 */
      if(maDbgFillAcn(i,&apn,&altApn,&apnCfg[j].class, &apnCfg[j].maVer, swtch) 
                     == RFAILED)
#endif /* MA_LMINT3 */
      {
         continue;
      }

      apnCfg[j].pres = TRUE;
      apnCfg[j].oprCode = i;
      apnCfg[j].oprTmr.enb = TRUE;
#if 0 /* added by adam 2003-04-10 */      
      apnCfg[j].oprTmr.val = 100; /* 50 */
#else
      switch (i)
      {
            /* Timer m */
            default: 
                  apnCfg[j].oprTmr.val = 200; /* 20 seconds */
            break;

            /* Timer s */
            case MA_SNDID: 
            case MA_SMDEL:
            case MA_ALRTSC:
                  apnCfg[j].oprTmr.val = 70; /* 7 seconds */
            break;
     
            /* Timer ml */
            case MA_RMTUSRFREE: 
            case MA_USSREQ:
            case MA_USSNOTIFY:
            case MA_REGPASSWD:
            case MA_MO_FWDSM:
            case MA_MT_FWDSM:
                  apnCfg[j].oprTmr.val = 3000; /* 5 minutes */
            break;

            /* 10 minutes */
            case MA_PROCUSSDATA: 
                  apnCfg[j].oprTmr.val = 6000; /* 10 minutes */
            break;
            
            /* Timer l */
            case MA_PROCACCSIG:
            case MA_FWDACCSIG:
            case MA_SNDENDSIG: 
                  apnCfg[j].oprTmr.val = 65535; /* 30 hours */
            break;
           
       }
#endif /* #if 0  added by adam 2003-04-10  */

      cmZero((PTR)&apnCfg[j].altApn,sizeof(MaApnStr));
      cmZero((PTR)&apnCfg[j].apn,sizeof(MaApnStr));
      apnCfg[j].apn.string[7] = swtch;
      apnCfg[j].altApn.string[7]= swtch;

      if(apn.pres == TRUE)
      {
         apnCfg[j].apn.len  = apn.len;
         for (k=0; k<apn.len; k++)
         {
            apnCfg[j].apn.string[k]=apn.val[k];
         }
      }

      j++;
   }
   RETVALUE(ROK);
}


/* 
 * Function name: maStsReq
 * Des:  		 send statistic req to ma
 * Return Value : XSUCC or XERROR
 */
XS16 maDbgStsReq(SuId	suId, U8 action, TranId transId)
{
	MaMngmt	sts;         /* Statistics */
	Pst	smMaPst;
   
	TRC2(maDbgStsReq)

	MaDbgPstInit(&smMaPst);
	memset(&sts, 0, sizeof(MaMngmt));
	maDbgHdrInit(&sts.hdr, transId);
	
	sts.hdr.msgType          = TSTS;       	/* Statistics */
	sts.hdr.entId.ent          = ENTMA;      	/* entity */
	sts.hdr.entId.inst          = MAINST;    	/* instance */
	sts.hdr.elmId.elmnt        = STMATSAP;  	/* MAP User sap */
	sts.hdr.elmId.elmntInst1 = suId;       	/* sap id */

	smMaPst.event = 0;
	/* give Statistics request to layer */
	(void)SmMiLmaStsReq(&smMaPst, (Action)action, &sts);

	return(XSUCC);
} /* end of maStsReq */

/* 
 * Function name: maCntrlReq
 * Des:		      Send Control Req to MAP
 * Return Value : XSUCC or XERROR
 */
XS16 maDbgCntrlReq(SuId suId, Elmnt elmnt, U8 action, U8 subAction,  U32 dbgMask, TranId transId)
{
	MaMngmt		cntrl;       /* Control */
	Pst			smMaPst;
   
	TRC2(maDbgCntrlReq)
		
	MaDbgPstInit(&smMaPst);	
	memset(&cntrl, 0, sizeof(MaMngmt));
	maDbgHdrInit(&cntrl.hdr, 0);
	
	cntrl.hdr.msgType			= TCNTRL;    	/* Control */
	cntrl.hdr.entId.ent			= ENTMA;      	/* entity */
	cntrl.hdr.entId.inst		= MAINST;     /* instance */
	cntrl.hdr.elmId.elmnt		= elmnt;      	/* TC User sap */
	cntrl.hdr.elmId.elmntInst1	= suId;       	/* sap id */
	cntrl.t.cntrl.action		= action;	
	cntrl.t.cntrl.subAction		= subAction;

#ifdef DEBUGP
   	cntrl.t.cntrl.s.dbg.dbgMask = dbgMask;
#else
   	UNUSED(dbgMask);
#endif 
	SmMiLmaCntrlReq(&smMaPst, &cntrl);
	
	return(XSUCC);
}

/* 
 * Function name: maStaReq
 * Des:  		 send status req to ma
 * Return Value : XSUCC or XERROR
 */
XS16 maDbgStaReq(SuId suId, Elmnt	elmnt, TranId transId)
{
	MaMngmt	sta;         /* Status */
/* disable this function for systemId->ptNmb not init */
#if 0
	Txt		ptNmb[LQC_SID_SIZE];
#endif
	Pst		smMaPst;
   
	TRC2(maStaReq)

	MaDbgPstInit(&smMaPst);
	memset(&sta, 0, sizeof(MaMngmt));
	maDbgHdrInit(&sta.hdr, 0);

	sta.hdr.msgType         = TSSTA;      	/* Status */
	sta.hdr.entId.ent         = ENTMA;      	/* entity */
	sta.hdr.entId.inst         = MAINST;    	/* instance */
	sta.hdr.elmId.elmnt       = elmnt;      	/* TC User sap */
	sta.hdr.elmId.elmntInst1   = suId;       	/* sap id */

/* disable this function for systemId->ptNmb not init */
#if 0
	if (elmnt == STSID)
	{
		memset(&ptNmb, 0, LQC_SID_SIZE);
		sta.t.ssta.s.sysId.ptNmb = ptNmb;
	}
#endif

   /* give Status request to layer */
   (Void) SmMiLmaStaReq(&smMaPst, &sta);

   return(XSUCC);
} /* end of maStaReq */ 

XS16 maDbgSapCfgReq
(
SuId   suId,               /* Sap Id */
SuId spId,			/*tcap sap id*/
Swtch  swtch,              /* Protocol switch */
U16    grdTmr,             /* Guard  timer */
U16    stDlgId,            /* Start dialogue Id */
U16    range,              /* Dialogue Id Range */
TranId transId             /* Transaction Id */
)
{
   MaMngmt    cfg;         /* configuration */
   Header    *hdr;         /* pointer to header */
   Pst smPst;

   MaDbgPstInit(&smPst);
   hdr = &cfg.hdr;
   maDbgHdrInit(hdr, transId);
   hdr->msgType          = TCFG;          /* configuration */
   hdr->entId.ent        = ENTMA;         /* entity */
   hdr->entId.inst       = MADBG_INST_0;     /* instance */
   hdr->elmId.elmnt      = STMATSAP;       /* MAP User sap */
   hdr->elmId.elmntInst1 = suId;          /* sap id */

   /* update the upper interface parameters */

   cmZero((U8 *)&(cfg.t.cfg.s.maMAU), sizeof(MaMAUCfg));
   /* configuration parameters */
   cfg.t.cfg.s.maMAU.swtch  = swtch; /* LMA_SW_GSM_0902 */
   cfg.t.cfg.s.maMAU.selectorMU  = MADBG_SEL_TC;
   cfg.t.cfg.s.maMAU.memMU.region = DFLT_REGION;  /* defualt priority */
   cfg.t.cfg.s.maMAU.memMU.pool   = DFLT_POOL; /* defualt priority */
   cfg.t.cfg.s.maMAU.priorMU        = PRIOR0;  /* defualt priority */
   cfg.t.cfg.s.maMAU.routeMU        = RTESPEC; /* default route */

   cfg.t.cfg.s.maMAU.maPrior = 1;         /* MAP priority */
   if(suId == MADBG_SAP_0)
   {
      cfg.t.cfg.s.maMAU.ssn = SS_HLR;        /* Sub Sytem Numer  */
   }

   else if(suId == MADBG_SAP_1)
   {
      cfg.t.cfg.s.maMAU.ssn = SS_MSC;        /* Sub Sytem Numer  */
   }

   if(suId == MADBG_SAP_2)
   {
      cfg.t.cfg.s.maMAU.ssn = SS_VLR;        /* Sub Sytem Numer  */
   }
 
   if(grdTmr > 0)
   {
      cfg.t.cfg.s.maMAU.maGrdTmr.enb = TRUE;     /* MAP Gaurd Timer */
      cfg.t.cfg.s.maMAU.maGrdTmr.val = grdTmr;   /* MAP Gaurd Timer */
   }
   else
   {
      cfg.t.cfg.s.maMAU.maGrdTmr.enb = FALSE;    /* MAP Gaurd Timer */
   }
   cfg.t.cfg.s.maMAU.maxDlg = MADBG_MAX_DLGS;         /* Maximum dialogues */
   maDbgFillAcnCfg(&cfg.t.cfg.s.maMAU.apnCfg[0], LMA_VER2P);

   /* configuartion parameters for lower sap */
   cfg.t.cfg.s.maMAU.selectorTC = MADBG_SEL_TC;
   cfg.t.cfg.s.maMAU.memTC.region = DFLT_REGION;    /* Memory region 0 */
   cfg.t.cfg.s.maMAU.memTC.pool = DFLT_POOL;     /* Memory pool 1 */
#ifdef SS_MULTIPLE_PROCS
   cfg.t.cfg.s.maMAU.procIdTC = TSTPROCID0;
#else
   cfg.t.cfg.s.maMAU.procIdTC = SFndProcId();  /* provider processorId */
#endif
   cfg.t.cfg.s.maMAU.entTC = ENTST;            /* provider entity */
   cfg.t.cfg.s.maMAU.instTC = MADBG_INST_0;         /* provider inst */
   cfg.t.cfg.s.maMAU.routeTC = RTESPEC;        /* provider route */
   cfg.t.cfg.s.maMAU.priorTC = PRIOR0;         /* provider priority */
   cfg.t.cfg.s.maMAU.spIdTC = spId;      /* provider id */

   /* Dialogue Id range */
   cfg.t.cfg.s.maMAU.stDlgId = stDlgId;
   cfg.t.cfg.s.maMAU.range   = range;

#if (MAP_SEC && LMAV2)
   cfg.t.cfg.s.maMAU.secSapCfg.neId.length = 6;
   cfg.t.cfg.s.maMAU.secSapCfg.neId.strg[0] = 0x01;
   cfg.t.cfg.s.maMAU.secSapCfg.neId.strg[1] = 0x02;
   cfg.t.cfg.s.maMAU.secSapCfg.neId.strg[2] = 0x03;
   cfg.t.cfg.s.maMAU.secSapCfg.neId.strg[3] = 0x04;
   cfg.t.cfg.s.maMAU.secSapCfg.neId.strg[4] = 0x05;
   cfg.t.cfg.s.maMAU.secSapCfg.neId.strg[5] = 0x06;
#endif

   /* give configuration request to layer */
   (Void) SmMiLmaCfgReq(&smPst, &cfg);

   return (XSUCC);
}

XS16 maDbgGenCfgReq
(
Ent     ent,             /* entity id */
Inst    inst,            /* instance id */
U16     nmbSap,          /* Number of SAPS */
U16     nmbDlg,          /* Number of dialogues  - system wide */
U16     nmbOpr,          /* Number of Operations - system wide */
TranId  transId,         /* Transaction Id */
U32     range           /* Dialogue Id Range */
)
{
   MaMngmt    cfg;       /* configuration */
   Header    *hdr;       /* pointer to header */
   Pst smPst;

   /* Prepare header */
   hdr = &cfg.hdr;

   MaDbgPstInit(&smPst);
   cmZero((Data *)&cfg,sizeof(MaMngmt));

   maDbgHdrInit(hdr, transId);
   hdr->msgType     = TCFG;                      /* configuration */
   hdr->entId.ent   = ent;                       /* entity */
   hdr->entId.inst  = inst;                      /* instance */
   hdr->elmId.elmnt = STMATGEN;                     /* general */

   /* set configuration parameters */
   cfg.t.cfg.s.maGen.nmbMAUSaps = nmbSap;    /* number of saps */    
   cfg.t.cfg.s.maGen.nmbDlgs = nmbDlg;    /* number of dlg - sys wide */
   cfg.t.cfg.s.maGen.nmbOpr  = nmbOpr;    /* number of opr - sys wide */
   cfg.t.cfg.s.maGen.timeRes = MA_PERIOD; /* timer resolution */
   cfg.t.cfg.s.maGen.range = range; /* Dialogue range   */
#if (MAP_SEC && LMAV2)
   cfg.t.cfg.s.maGen.secGenCfg.rxFbInd   = LMA_FB_ENABLED;
   cfg.t.cfg.s.maGen.secGenCfg.nmbOpCmp  = 1; /* number of operation comp */
   cfg.t.cfg.s.maGen.secGenCfg.opCmp[0].acName  = MA_RESET_AC;
   cfg.t.cfg.s.maGen.secGenCfg.opCmp[0].acVer   = AC_VER2;
   cfg.t.cfg.s.maGen.secGenCfg.opCmp[0].oprCode = MAT_RESET;
   cfg.t.cfg.s.maGen.secGenCfg.opCmp[0].cmpCmb  = LMA_CMP_INVK;
   cfg.t.cfg.s.maGen.secGenCfg.tvpWinSz  = 1000;  /* TVP window size */
   cfg.t.cfg.s.maGen.secGenCfg.tvPeriod  = 1;     /* TVP Period */
   cfg.t.cfg.s.maGen.secGenCfg.maxPlmn   = MADBG_MAX_PLMN; 
   cfg.t.cfg.s.maGen.secGenCfg.maxpp     = MADBG_MAX_PP; 
   /* Only sec plmn cfgd,other plmn are map*/
   cfg.t.cfg.s.maGen.secGenCfg.secPlmnsOnly = FALSE;
   /* Self Plmn Identifier */
   cfg.t.cfg.s.maGen.secGenCfg.plmnId.mcc.pres = TRUE;
   cfg.t.cfg.s.maGen.secGenCfg.plmnId.mcc.val = 0xf321;
   cfg.t.cfg.s.maGen.secGenCfg.plmnId.mnc.pres = TRUE;
   cfg.t.cfg.s.maGen.secGenCfg.plmnId.mnc.val = 0xff54;
#endif /* MAP_SEC && LMAV2 */


   /* layer manager */
   cfg.t.cfg.s.maGen.smPst.selector  = MADBG_SEL_TC;
   cfg.t.cfg.s.maGen.smPst.region    = DFLT_REGION;        /* region */
   cfg.t.cfg.s.maGen.smPst.pool      = DFLT_REGION;       /* pool */
   cfg.t.cfg.s.maGen.smPst.prior     = PRIOR0;        /* priority */
   cfg.t.cfg.s.maGen.smPst.route     = RTESPEC;       /* route */
#ifdef SS_MULTIPLE_PROCS
   cfg.t.cfg.s.maGen.smPst.dstProcId = maCb.maInit.procId;  /* dst proc id */
#else
   cfg.t.cfg.s.maGen.smPst.dstProcId = SFndProcId();  /* dst proc id */
#endif
   cfg.t.cfg.s.maGen.smPst.dstEnt    = ENTSM;         /* dst entity */
   cfg.t.cfg.s.maGen.smPst.dstInst   = MADBG_INST_0;     /* dst inst */
#ifdef SS_MULTIPLE_PROCS
   cfg.t.cfg.s.maGen.smPst.srcProcId = maCb.maInit.procId;  /* src proc id */
#else
   cfg.t.cfg.s.maGen.smPst.srcProcId = SFndProcId();  /* src proc id */
#endif
   cfg.t.cfg.s.maGen.smPst.srcEnt    = ENTMA;         /* src entity */
   cfg.t.cfg.s.maGen.smPst.srcInst   = MADBG_INST_0;     /* src inst */
   
#ifdef MA_CLI_ACCDBG
   cmCpy((U8 *)&cfg.t.cfg.s.maGen.smPst, (U8 *)&maAccCb.init.lmPst,
          (U32)sizeof(Pst));
#endif

   (XVOID)SmMiLmaCfgReq(&smPst, &cfg);

   return(XSUCC);
}

XS16 PtFunc
(
Pst      *pst,              /* post structure */
SuId     suId,              /* service user id */
SpId     spId,               /* service provider id */
Ssn ssn
)
{
	printf("the PT FUNC!\r\n");
	return XSUCC;
}

XS16 maDbgMatBndReq(Pst *pst, SuId suId, SuId spId, Ssn ssn)
{
   /* MAP Bind Request primitive */
	StuBndReq stuBndReqMt [2] =
	{
	 #ifdef LCMALISTU
		cmPkStuBndReq,      /* 0 - loosely coupled  */
	 #else
		PtFunc,        /* 0 - loosely coupled, portable */
	  #endif
	 #if(defined(ST) ||defined(L4))/*xqc add L4 for map test*/
		StUiStuBndReq         /* 1 - tightly coupled, TCAP */
	 #else
		PtFunc/* 1 - tightly coupled, portable */
	 #endif
	};
   
	return((*stuBndReqMt[pst->selector])(pst, suId, spId, ssn));
} /* end of AuLiMatBndReq */

XVOID maDbgGenCfg(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv)
{
	XS16 ret;
	
	if(maArgc != 2)
	{
		XOS_CliExtPrintf(pCliEnv,"please input correct parameters!\r\n");
		return;
	}
	else
	{
		ret = maDbgGenCfgReq(ENTMA, (Inst)atoi(ppArgv[1]), MAX_NMB_SAP, MAX_NMB_DLG, MAX_NMB_OPR, 0, MADBG_DLGID_RANGE);
		if(ret != XSUCC)
		{
			XOS_CliExtPrintf(pCliEnv,"maDbgGenCfg FAILED!\r\n");
			return;
		}
	}
}

XVOID maDbgSapCfg(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv)
{
	XS16 ret;
	
	if(maArgc != 4)
	{
		XOS_CliExtPrintf(pCliEnv,"please input correct parameters!\r\n");
		return;
	}
	else
	{	   
		ret = maDbgSapCfgReq((SuId)atoi(ppArgv[1]), (SpId)atoi(ppArgv[2]), (Swtch)atoi(ppArgv[3]), 0, MADBG_START_DLGID, MADBG_DLGID_RANGE, 0);
		if(ret != XSUCC)
		{
			XOS_CliExtPrintf(pCliEnv,"maDbgSapCfg FAILED!\r\n");
			return;
		}
	}
}

XVOID maDbgCntr(CLI_ENV *pCliEnv, XS32 maArgc, XCHAR **ppArgv)
{
	XS16 ret;
	
	if(maArgc != 5)
	{
		XOS_CliExtPrintf(pCliEnv,"please input correct parameters!\r\n");
		return;
	}
	else
	{
		ret = maDbgCntrlReq((SuId)atoi(ppArgv[1]), (Elmnt)atoi(ppArgv[2]), (U8)atoi(ppArgv[3]), (U8)atoi(ppArgv[4]), 0, 0);
		if(ret != XSUCC)
		{
			XOS_CliExtPrintf(pCliEnv,"maDbgCntrReq FAILED!\r\n");
			return;
		}
	}
}

XVOID maDbgBnd(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv)
{
	XS16 ret;
	Pst stPst;/*from MA to ST*/
	
	MaDbgPstInit(&stPst);
	stPst.srcEnt  = ENTMA;
	stPst.dstEnt = ENTST;
	if(maArgc != 2)
	{
		XOS_CliExtPrintf(pCliEnv,"please input correct parameters!\r\n");
		return;
	}
	else
	{
		SuId sapId=(SuId)atoi(ppArgv[1]);
		MaSap *s;
	       if (sapId >= (SuId)maCb.maCP.nmbMAUSaps || sapId < 0 || 
	           ((s = *(maCb.maSapLmaPtr + sapId)) == NULLP))
	       {
			XOS_CliExtPrintf(pCliEnv, "[MAP] Invalid sap Id\r\n");
			RETVOID;
	       }
		   
		ret = maDbgMatBndReq(&stPst, sapId, s->spIdTC, s->ssn);
		if(ret != XSUCC)
		{
			XOS_CliExtPrintf(pCliEnv,"maDbgCntrReq FAILED!\r\n");
			return;
		}
	}
}

XVOID maDbgMAPCfg(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv)
{
	Pst stPst;/*post to ST*/
	XS16 ret;
	MaDbgPstInit(&stPst);
	stPst.srcEnt  = ENTAU;
	stPst.dstEnt = ENTMA;

#ifndef MA_CLI_ACCDBG
	/*general cfg*/
	ret = maDbgGenCfgReq(ENTMA, MAINST, MAX_NMB_SAP, 0, MADBG_START_DLGID, MADBG_DLGID_RANGE, 0);
	if(ret != XSUCC)
	{
		XOS_CliExtPrintf(pCliEnv,"maDbgGenCfg FAILED!\r\n");
		return;
	}
	/*sap cfg*/
	maDbgSapCfgReq(MADBG_SAP_0, MADBG_SAP_0, LMA_VER2P, 0,
	       MADBG_START_DLGID, MADBG_DLGID_RANGE, 0);

	maDbgSapCfgReq(MADBG_SAP_1, MADBG_SAP_1, LMA_VER2P, 0,
	       MADBG_START_DLGID, MADBG_DLGID_RANGE, 0);

	/* Send control request to MAP to enable the alarms */
	maDbgCntrlReq(0, STGEN, AENA, SAUSTA, 0, 0);

	/* Send control request to MAP to enable the lower SAPS */
	maDbgCntrlReq(0, STGRSPSAP, ABND_ENA, SAGR_DSTPROCID, 0, 0);

	/* Bind to Sap_0 */
/*	maDbgMatBndReq(&stPst, (SuId)MADBG_SAP_0, (SpId)MADBG_SAP_0, maCb->maSapLmaPtr+);*/
	
#else
   maAccOprCode = MAT_INSSUBSDATA; 
		 
   while(!maAccCb.cfgDone)
   {
      ret = maAccCfgMaTst();
	  if(ret != ROK)
	  {
	  	return;
	  }
   }
#endif

}

/*
dbgmsk:
0 : no dbg
ssi : enable ssi dbg
mi : enable lma dbg
ui : enable ui dbg
li : enable li dbg
dec : enable decode dbg
enc : enable encode dbg
skp : enable skip dbg
*/
void maDbgSetDbgmsk(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv)
{
    U32 dbgmsk=0x00;
    U8 i = 0;
    
    if(maArgc != 2)
    {
        XOS_CliExtPrintf(pCliEnv, "[MAP] please input correct parameters!\r\n");
        RETVOID;
    }
    if(strncmp(ppArgv[1], "0x", 2) ==0)
    {
        while((ppArgv[1])[i+2])
        {
            if(isxdigit((int)(ppArgv[1])[i+2]) == 0)
            {
                XOS_CliExtPrintf(pCliEnv, "[MAP] please input correct parameters!\r\n");
                RETVOID;
            }
            i++;
        }
    }
    else
    {
        while((ppArgv[1])[i])
        {
            if(isdigit((int)(ppArgv[1])[i]) == 0)
            {
                XOS_CliExtPrintf(pCliEnv, "[MAP] please input correct parameters!\r\n");
                RETVOID;
            }
            i++;
        }
    }

    dbgmsk = strtoul((ppArgv[1]), (U8**)NULL, 0);
    if(dbgmsk < 0)
    {
        XOS_CliExtPrintf(pCliEnv, "[MAP] please input correct parameters!\r\n");
        RETVOID;
    }
#ifdef DEBUGP
    maCb.maInit.dbgMask = dbgmsk;
#else
    XOS_CliExtPrintf(pCliEnv, "[MAP] there is no debug function!\r\n");
#endif

    RETVOID;
}

VOID maShowDbgStat(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv)
{
    U32 dbgmask;
    U32 encmask = MA_DBGMASK_ENCODE;
    U32 decmask = MA_DBGMASK_DECODE;
    U32 skpmask = MA_DBGMASK_SKIP;

    dbgmask = maCb.maInit.dbgMask;

/*GENERAL */
XOS_CliExtPrintf(pCliEnv, "\r\nDebug Mask Info:\r\n");
XOS_CliExtPrintf(pCliEnv, "----------------------------\r\n");
    XOS_CliExtPrintf(pCliEnv, "\t%-12s", "DBGMASK_GEN");
    if(dbgmask & LMA_DBGMASK_GEN)
    {
        XOS_CliExtPrintf(pCliEnv, ":   on\r\n");
    }
    else
    {
        XOS_CliExtPrintf(pCliEnv, ":   off\r\n");
    }
/*upper IF*/
    XOS_CliExtPrintf(pCliEnv, "\t%-12s", "DBGMASK_UI");
    if(dbgmask & DBGMASK_UI)
    {

        XOS_CliExtPrintf(pCliEnv, ":   on\r\n");
    }
    else
    {
        XOS_CliExtPrintf(pCliEnv, ":   off\r\n");
    }
/*lower if*/
    XOS_CliExtPrintf(pCliEnv, "\t%-12s", "DBGMASK_LI");
    if(dbgmask & DBGMASK_LI)
    {
        XOS_CliExtPrintf(pCliEnv, ":   on\r\n");
    }
    else
    {
        XOS_CliExtPrintf(pCliEnv, ":   off\r\n");
    }
/*layer manager if*/
    XOS_CliExtPrintf(pCliEnv, "\t%-12s", "DBGMASK_MI");
    if(dbgmask & DBGMASK_MI)
    {
        XOS_CliExtPrintf(pCliEnv, ":   on\r\n");
    }    
    else
    {
        XOS_CliExtPrintf(pCliEnv, ":   off\r\n");
    }
/*SSI IF*/
    XOS_CliExtPrintf(pCliEnv, "\t%-12s", "DBGMASK_SI");
    if(dbgmask & DBGMASK_SI)
    {

        XOS_CliExtPrintf(pCliEnv, ":   on\r\n");
    }    
    else
    {
        XOS_CliExtPrintf(pCliEnv, ":   off\r\n");
    }

/*encode */
    XOS_CliExtPrintf(pCliEnv, "\t%-12s", "DBGMASK_ENC");
    if((dbgmask & encmask)&&(dbgmask & skpmask))
    {

        XOS_CliExtPrintf(pCliEnv, ":   on\r\n");
    }
    else
    {
        XOS_CliExtPrintf(pCliEnv, ":   off\r\n");
    }
/*decode */
    XOS_CliExtPrintf(pCliEnv, "\t%-12s", "DBGMASK_DEC");
    if((dbgmask & decmask)&&(dbgmask & skpmask))
    {

        XOS_CliExtPrintf(pCliEnv, ":   on\r\n");
    }
    else
    {
        XOS_CliExtPrintf(pCliEnv, ":   off\r\n");
    }
/*peer if*/
    XOS_CliExtPrintf(pCliEnv, "\t%-12s", "DBGMASK_PI");
    if(dbgmask & DBGMASK_PI)
    {

        XOS_CliExtPrintf(pCliEnv, ":   on\r\n");
    }
    else
    {
        XOS_CliExtPrintf(pCliEnv, ":   off\r\n");
    }

    XOS_CliExtPrintf(pCliEnv, "\t%-12s", "DBGMASK_PLI");
    if(dbgmask & DBGMASK_PLI)
    {

        XOS_CliExtPrintf(pCliEnv, ":   on\r\n");
    }
    else
    {
        XOS_CliExtPrintf(pCliEnv, ":   off\r\n");
    }
    

}

/* 
 * Function name: maGetSts
 * Des:  		 get statistic from ma
 * Return Value : XSUCC or XERROR
 */
XS16 maShowOprSts(CLI_ENV *pCliEnv, SuId sapId, U16 action)
{
	MaSap	*s;
	SuId		suId = 0;
	
	suId = sapId;
	if (suId >= (SuId)maCb.maCP.nmbMAUSaps || suId < 0 || 
       ((s = *(maCb.maSapLmaPtr + suId)) == (MaSap *)NULLP))
	{
		return(XERROR);
	}

	if (action != MADBG_ZERO_STS)
	{
		Txt  prntBuf[PRNTSZE];

        XOS_CliExtPrintf(pCliEnv, "\r\n[MAP] SAP(%d) statistics Info :\r\n\r\n", sapId);
        XOS_CliExtPrintf(pCliEnv, "-------------------------------------------------------------\n");
        sprintf(prntBuf, "[MAP]\tType             \t     Rx    \t     Tx \n");
        XOS_CliExtPrintf(pCliEnv, prntBuf);
        sprintf(prntBuf, "------------------      \t----------  \t  ----------\n");
        XOS_CliExtPrintf(pCliEnv, prntBuf);
        sprintf(prntBuf, "\tOPEN REQ              \t%10ld  \t  %10ld\n",
        s->sts.openReqRx, s->sts.openReqTx);
        XOS_CliExtPrintf(pCliEnv, prntBuf);
        sprintf(prntBuf, "\tCLOSE REQ             \t%10ld  \t  %10ld\n",
        s->sts.closeRx, s->sts.closeTx);
        XOS_CliExtPrintf(pCliEnv, prntBuf);
        sprintf(prntBuf, "\tOPEN RSP              \t%10ld  \t  %10ld\n",
        s->sts.openRspRx, s->sts.openRspTx);
        XOS_CliExtPrintf(pCliEnv, prntBuf);
        sprintf(prntBuf, "\tABRT REQ              \t%10ld  \t  %10ld\n",
        s->sts.abrtRx, s->sts.abrtRx);
        XOS_CliExtPrintf(pCliEnv, prntBuf);


#if (MAP_MSC || MAP_VLR || MAP_HLR)
        DBGPrntCntr(regSSReqTx);     /* Register SS request transmitted */
        DBGPrntCntr(regSSReqRx);     /* Register SS request Received */
        DBGPrntCntr(regSSRspTx);     /* Register SS response transmitted */
        DBGPrntCntr(regSSRspRx);     /* Register SS response Received */
        DBGPrntCntr(regSSReTx);      /* Register SS ret.error transmitted */
        DBGPrntCntr(regSSReRx);      /* Register SS ret.error Received */

        DBGPrntCntr(eraseSSReqTx);    /* Erase SS request transmitted */
        DBGPrntCntr(eraseSSReqRx);    /* Erase SS request Received */
        DBGPrntCntr(eraseSSRspTx);    /* Erase SS response transmitted */
        DBGPrntCntr(eraseSSRspRx);    /* Erase SS response Received */
        DBGPrntCntr(eraseSSReTx);     /* Erase SS ret.error transmitted */
        DBGPrntCntr(eraseSSReRx);     /* Erase SS ret.error Received */

        DBGPrntCntr(actvSSReqTx);     /* Activate SS request transmitted */
        DBGPrntCntr(actvSSReqRx);     /* Activate SS request Received */
        DBGPrntCntr(actvSSRspTx);     /* Activate SS response transmitted */
        DBGPrntCntr(actvSSRspRx);     /* Activate SS response Received */
        DBGPrntCntr(actvSSReTx);      /* Activate SS ret.error transmitted */
        DBGPrntCntr(actvSSReRx);      /* Activate SS ret.error Received */

        DBGPrntCntr(dactvSSReqTx);     /* Deactivate SS request transmitted */
        DBGPrntCntr(dactvSSReqRx);     /* Deactivate SS request Received */
        DBGPrntCntr(dactvSSRspTx);     /* Deactivate SS response transmitted */
        DBGPrntCntr(dactvSSRspRx);     /* Deactivate SS response Received */
        DBGPrntCntr(dactvSSReTx);      /* Deactivate SS ret.error transmitted */
        DBGPrntCntr(dactvSSReRx);      /* Deactivate SS ret.error Received */

        DBGPrntCntr(interSSReqTx);     /* Interogate SS request transmitted */
        DBGPrntCntr(interSSReqRx);     /* Interogate SS request Received */
        DBGPrntCntr(interSSRspTx);     /* Interogate SS response transmitted */
        DBGPrntCntr(interSSRspRx);     /* Interogate SS response Received */
        DBGPrntCntr(interSSReTx);      /* Interrogate SS ret.error transmitted */
        DBGPrntCntr(interSSReRx);      /* Interrogate SS ret.error Received */

        DBGPrntCntr(regPasswdReqTx);    /* Register Password request transmitted */
        DBGPrntCntr(regPasswdReqRx);    /* Register Password request Received */
        DBGPrntCntr(regPasswdRspTx);    /* Register Password response transmitted */
        DBGPrntCntr(regPasswdRspRx);    /* Register Password response Received */
        DBGPrntCntr(regPasswdReTx);     /* Register Password ret.error transmitted */
        DBGPrntCntr(regPasswdReRx);     /* Register Password ret.error Received */

        DBGPrntCntr(getPasswdReqTx);    /* Get Password request transmitted */
        DBGPrntCntr(getPasswdReqRx);    /* Get Password request Received */
        DBGPrntCntr(getPasswdRspTx);    /* Get Password response transmitted */
        DBGPrntCntr(getPasswdRspRx);    /* Get Password response Received */
        DBGPrntCntr(getPasswdReTx);     /* Get Password ret.error transmitted */
        DBGPrntCntr(getPasswdReRx);     /* Get Password ret.error Received */

        DBGPrntCntr(procUSSDatReqTx);   /* Process USS  request transmitted */
        DBGPrntCntr(procUSSDatReqRx);   /* Process USS request Received */
        DBGPrntCntr(procUSSDatRspTx);   /* Process USS response transmitted */
        DBGPrntCntr(procUSSDatRspRx);   /* Process USS response Received */
        DBGPrntCntr(procUSSDatReTx);    /* Process USS ret.error transmitted */
        DBGPrntCntr(procUSSDatReRx);    /* Process USS ret.error Received */

        DBGPrntCntr(procUSSReqTx);      /* Process USS  Data request transmitted */
        DBGPrntCntr(procUSSReqRx);      /* Process USS Data request Received */
        DBGPrntCntr(procUSSRspTx);      /* Process USS Data response transmitted */
        DBGPrntCntr(procUSSRspRx);      /* Process USS Data response Received */
        DBGPrntCntr(procUSSReTx);      /* Process USS Data ret.error transmitted */
        DBGPrntCntr(procUSSReRx);     /* Process USS Data ret.error Received */

        DBGPrntCntr(ussReqTx);          /* USS  request transmitted */
        DBGPrntCntr(ussReqRx);          /* USS request Received */
        DBGPrntCntr(ussRspTx);          /* USS response transmitted */
        DBGPrntCntr(ussRspRx);          /* USS response Received */
        DBGPrntCntr(ussReTx);         /* USS ret.error transmitted */
        DBGPrntCntr(ussReRx);           /* USS ret.error Received */

        DBGPrntCntr(ussNotReqTx);       /* USS Notify request transmitted */
        DBGPrntCntr(ussNotReqRx);       /* USS Notify request Received */
        DBGPrntCntr(ussNotRspTx);       /* USS Notify response transmitted */
        DBGPrntCntr(ussNotRspRx);       /* USS Notify response Received */
        DBGPrntCntr(ussNotReTx);        /* USS Notify Ret.Err transmitted */
        DBGPrntCntr(ussNotReRx);        /* USS Notify Ret.Err Received */

        DBGPrntCntr(fwdChkSSIndReqTx);     /* Forward Chk SS Ind. request transmitted */
        DBGPrntCntr(fwdChkSSIndReqRx);     /* Forward Chk SS Ind. request Received */

        DBGPrntCntr(regCcEntReqTx);     /*reg Cc Ent req Tx */
        DBGPrntCntr(regCcEntReqRx);     /*reg Cc Ent req Rx */
        DBGPrntCntr(regCcEntRspTx);     /*reg Cc Ent rsp Tx */
        DBGPrntCntr(regCcEntRspRx);     /*reg Cc Ent rsp Rx */
        DBGPrntCntr(regCcEntReTx);      /*reg Cc Ent re Tx */
        DBGPrntCntr(regCcEntReRx);      /*reg Cc Ent re Rx */

        DBGPrntCntr(eraseCcEntReqTx);     /*erase Cc Ent req Tx */
        DBGPrntCntr(eraseCcEntReqRx);     /*erase Cc Ent req Rx */
        DBGPrntCntr(eraseCcEntRspTx);     /*erase Cc Ent rsp Tx */
        DBGPrntCntr(eraseCcEntRspRx);     /*erase Cc Ent rsp Rx */
        DBGPrntCntr(eraseCcEntReTx);      /*erase Cc Ent re Tx */
        DBGPrntCntr(eraseCcEntReRx);      /*erase Cc Ent re Rx */
	   
#endif /* MSC || VLR || HLR */
   
#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)
        DBGPrntCntr(smRdyReqTx);       /* SM Ready request transmitted */
        DBGPrntCntr(smRdyReqRx);       /* SM Ready request Received */
        DBGPrntCntr(smRdyRspTx);       /* SM Ready response transmitted */
        DBGPrntCntr(smRdyRspRx);       /* SM Ready response Received */
        DBGPrntCntr(smRdyReTx);       /* SM Ready re. transmitted */
        DBGPrntCntr(smRdyReRx);       /* SM Ready re. Received */
#endif /* (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN) */


#if (MAP_MSC || MAP_VLR)
        DBGPrntCntr(detIMSIReqTx);         /* Detach IMSI request transmitted */
        DBGPrntCntr(detIMSIReqRx);         /* Detach IMSI request Received */


        DBGPrntCntr(trSubReqTx);           /* Trace Sub Activity request transmitted */
        DBGPrntCntr(trSubReqRx);           /* Trace Sub Activity request Received */

#endif /* MAP_MSC || MAP_VLR */

#if (MAP_MSC || MAP_VLR || MAP_GSN)
        DBGPrntCntr(chkIMEIReqTx);         /* Check IMEI request transmitted */
        DBGPrntCntr(chkIMEIReqRx);         /* Check IMEI request Received */
        DBGPrntCntr(chkIMEIRspTx);         /* Check IMEI response transmitted */
        DBGPrntCntr(chkIMEIRspRx);         /* Check IMEI response Received */
        DBGPrntCntr(chkIMEIReTx);          /* Check IMEI ret.err Tx */
        DBGPrntCntr(chkIMEIReRx);          /* Check IMEI ret.err Rx */
	   
#endif /* (MAP_MSC || MAP_VLR || MAP_GSN) */

#if (MAP_MSC || MAP_HLR)
        DBGPrntCntr(routInfoReqTx);        /* Send Rout Info request transmitted */
        DBGPrntCntr(routInfoReqRx);        /* Send Rout Info request Received */
        DBGPrntCntr(routInfoRspTx);        /* Send Rout Info response transmitted */
        DBGPrntCntr(routInfoRspRx);        /* Send Rout Info response Received */
        DBGPrntCntr(routInfoReTx);         /* Send Rout Info ret.error transmitted */
        DBGPrntCntr(routInfoReRx);         /* Send Rout Info ret.error Received */

        DBGPrntCntr(routInfoSMReqTx);      /* Send Rout Info for SM request transmitted */
        DBGPrntCntr(routInfoSMReqRx);      /* Send Rout Info for SM request Received */
        DBGPrntCntr(routInfoSMRspTx);      /* Send Rout Info for SM response transmitted */
        DBGPrntCntr(routInfoSMRspRx);      /* Send Rout Info for SM response Received */
        DBGPrntCntr(routInfoSMReTx);        /* Send Rout Info  ret.error transmitted */
        DBGPrntCntr(routInfoSMReRx);        /* Send Rout Info  ret.error Received */

        DBGPrntCntr(smDelReqTx);           /* SM Delivery request transmitted */
        DBGPrntCntr(smDelReqRx);           /* SM Delivery request Received */
        DBGPrntCntr(smDelRspTx);           /* SM Delivery response transmitted */
        DBGPrntCntr(smDelRspRx);           /* SM Delivery response Received */
        DBGPrntCntr(smDelReTx);            /* SM Delivery  ret.error transmitted */
        DBGPrntCntr(smDelReRx);            /* SM Delivery  ret.error Received */

        DBGPrntCntr(alrtSCReqTx);           /* Alert Service Center request transmitted */
        DBGPrntCntr(alrtSCReqRx);           /* Alert Service Center request Received */
        DBGPrntCntr(alrtSCRspTx);           /* Alert Service Center response transmitted */
        DBGPrntCntr(alrtSCRspRx);           /* Alert Service Center response Received */
        DBGPrntCntr(alrtSCReTx);            /* Alert Service Center re transmitted */
        DBGPrntCntr(alrtSCReRx);            /* Alert Service Center re Received */
        DBGPrntCntr(alrtSCWRsltReqTx);      /* Alert SC Without Result request tx */
        DBGPrntCntr(alrtSCWRsltReqRx);      /* Alert SC Without Result request Received */

        DBGPrntCntr(infSCReqTx);           /* Inform Service Center request transmitted */
        DBGPrntCntr(infSCReqRx);           /* Inform Service Center request Received */

#endif

#if (MAP_VLR || MAP_HLR || MAP_GSN )
        DBGPrntCntr(canLocReqTx);        /* Cancel Location request transmitted */
        DBGPrntCntr(canLocReqRx);        /* Cancel Location request Received */
        DBGPrntCntr(canLocRspTx);        /* Cancel Location request transmitted */
        DBGPrntCntr(canLocRspRx);        /* Cancel Location request Received */
        DBGPrntCntr(canLocReTx);        /* Cancel Location re. transmitted */
        DBGPrntCntr(canLocReRx);        /* Cancel Location re. Received */

        DBGPrntCntr(purgMsReqTx);        /* Purge Ms request transmitted */
        DBGPrntCntr(purgMsReqRx);        /* Purge Ms request Received */
        DBGPrntCntr(purgMsRspTx);        /* Purge Ms response transmitted */
        DBGPrntCntr(purgMsRspRx);        /* Purge Ms response Received */
        DBGPrntCntr(purgMsReTx);        /* Purge Ms re. transmitted */
        DBGPrntCntr(purgMsReRx);        /* Purge Ms re. Received */

        DBGPrntCntr(authInfReqTx);       /* Authintication Info request transmitted */
        DBGPrntCntr(authInfReqRx);       /* Authintication Info request Received */
        DBGPrntCntr(authInfRspTx);       /* Authintication Info response transmitted */
        DBGPrntCntr(authInfRspRx);       /* Authintication Info response Received */
        DBGPrntCntr(authInfReTx);        /* Authentication Info ret.error transmitte*/
        DBGPrntCntr(authInfReRx);        /* Authentication Info ret.error Received */

        DBGPrntCntr(insSubReqTx);        /* Insert Subscriber Data request transmitted */
        DBGPrntCntr(insSubReqRx);        /* Insert Subscriber Data request Received */
        DBGPrntCntr(insSubRspTx);        /* Insert Subscriber Data response transmitted */
        DBGPrntCntr(insSubRspRx);        /* Insert Subscriber Data response Received */
        DBGPrntCntr(insSubReTx);      /* Insert Subscriber Data ret.error tx */
        DBGPrntCntr(insSubReRx);      /* Insert Subscriber Data ret.error Received */

        DBGPrntCntr(delSubReqTx);        /* Delete Subscriber Data request transmitted */
        DBGPrntCntr(delSubReqRx);        /* Delete Subscriber Data request Received */
        DBGPrntCntr(delSubRspTx);        /* Delete Subscriber Data response transmitted */
        DBGPrntCntr(delSubRspRx);        /* Delete Subscriber Data response Received */
        DBGPrntCntr(delSubReTx);         /* Delete Subscriber Data ret err transmitted */
        DBGPrntCntr(delSubReRx);         /* Delete Subscriber Data ret err Received*/

        DBGPrntCntr(resetReqTx);         /* Reset request transmitted */
        DBGPrntCntr(resetReqRx);         /* Reset request Received */

        DBGPrntCntr(actvTrReqTx);         /* Activate trace request transmitted */
        DBGPrntCntr(actvTrReqRx);         /* Activate trace request Received */
        DBGPrntCntr(actvTrRspTx);         /* Activate trace Response transmitted */
        DBGPrntCntr(actvTrRspRx);         /* Activate trace response Received */
        DBGPrntCntr(actvTrReTx);         /* Activate trace re. transmitted */
        DBGPrntCntr(actvTrReRx);         /* Activate trace re. Received */

        DBGPrntCntr(dactvTrReqTx);         /* Deactivate trace request transmitted */
        DBGPrntCntr(dactvTrReqRx);         /* Deactivate trace request Received */
        DBGPrntCntr(dactvTrRspTx);         /* Deactivate trace response transmitted */
        DBGPrntCntr(dactvTrRspRx);         /* Deactivate trace response Received */
        DBGPrntCntr(dactvTrReTx);         /* Deactivate trace re. transmitted */
        DBGPrntCntr(dactvTrReRx);         /* Deactivate trace re. Received */

#if MAP_REL99

        /* Auth Failure Report */
        DBGPrntCntr(authFailRptReqTx);    /* Inv. Tx */
        DBGPrntCntr(authFailRptReqRx);    /* Inv. Rx */
        DBGPrntCntr(authFailRptRspTx);   /* RR Tx */
        DBGPrntCntr(authFailRptRspRx);   /* RR Rx */
        DBGPrntCntr(authFailRptReTx);     /* RE Tx */
        DBGPrntCntr(authFailRptReRx);     /* RE Rx */ 

#endif /* MAP_REL99 */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */
#if (MAP_VLR || MAP_HLR)
        DBGPrntCntr(upLocReqTx);         /* Update Location request transmitted */
        DBGPrntCntr(upLocReqRx);         /* Update Location request Received */
        DBGPrntCntr(upLocRspTx);         /* Update Location response transmitted */
        DBGPrntCntr(upLocRspRx);         /* Update Location response Received */
        DBGPrntCntr(upLocReTx);          /* Update Location ret.error transmitted */
        DBGPrntCntr(upLocReRx);          /* Update Location ret.error Received */

        DBGPrntCntr(sndParamReqTx);      /* Send Parameter request transmitted */
        DBGPrntCntr(sndParamReqRx);      /* Send Parameter request Received */
        DBGPrntCntr(sndParamRspTx);      /* Send Parameter response transmitted */
        DBGPrntCntr(sndParamRspRx);      /* Send Parameter response Received */
        DBGPrntCntr(sndParamReTx);       /* Send Parameter response transmitted */
        DBGPrntCntr(sndParamReRx);       /* Send Parameter response Received */

        DBGPrntCntr(restoreReqTx);         /* Restore request transmitted */
        DBGPrntCntr(restoreReqRx);         /* Restore request Received */
        DBGPrntCntr(restoreRspTx);         /* Restore response transmitted */
        DBGPrntCntr(restoreRspRx);         /* Restore response Received */
        DBGPrntCntr(restoreReTx);          /* Restore ret.error transmitted */
        DBGPrntCntr(restoreReRx);          /* Restore SS ret.error Received */

        DBGPrntCntr(sndIMSIReqTx);         /* Send IMSI request transmitted */
        DBGPrntCntr(sndIMSIReqRx);         /* Send IMSI request Received */
        DBGPrntCntr(sndIMSIRspTx);         /* Send IMSI response transmitted */
        DBGPrntCntr(sndIMSIRspRx);         /* Send IMSI response Received */
        DBGPrntCntr(sndIMSIReTx);          /* Send IMSI ret.error transmitted */
        DBGPrntCntr(sndIMSIReRx);          /* Send IMSI ret.error Received */

        DBGPrntCntr(provRoamNmbReqTx); /* Provide Roaming Number request transmitted */
        DBGPrntCntr(provRoamNmbReqRx); /* Provide Roaming Number request Received */
        DBGPrntCntr(provRoamNmbRspTx); /* Provide Roaming Number response transmitted */
        DBGPrntCntr(provRoamNmbRspRx); /* Provide Roaming Number response Received */
        DBGPrntCntr(provRoamNmbReTx);  /* Prov. Roaming Nmb. ret.error transmitted */
        DBGPrntCntr(provRoamNmbReRx);  /* Prov. Roaming Nmb. ret.error Received */

        DBGPrntCntr(bgnSubActvReqTx);  /* Begin Subs. Activity  request transmitted */
        DBGPrntCntr(bgnSubActvReqRx);  /* Begin Subs. Activity  request Received */
        DBGPrntCntr(notSubPresReqTx);  /* Note Subscriber Present request transmitted */
        DBGPrntCntr(notSubPresReqRx);  /* Note Subscriber Present request Received */


        DBGPrntCntr(setRptStateReqTx);     /* req Tx */
        DBGPrntCntr(setRptStateReqRx);     /* req Rx */
        DBGPrntCntr(setRptStateRspTx);     /* rsp Tx */
        DBGPrntCntr(setRptStateRspRx);     /* rsp Rx */
        DBGPrntCntr(setRptStateReTx);      /* set rpt state ret.error transmitted */
        DBGPrntCntr(setRptStateReRx);      /* set rpt state ret.error Received */

        DBGPrntCntr(rmtUsrFreeReqTx);     /* req Tx */
        DBGPrntCntr(rmtUsrFreeReqRx);     /* req Rx */
        DBGPrntCntr(rmtUsrFreeRspTx);     /* rsp Tx */
        DBGPrntCntr(rmtUsrFreeRspRx);     /* rsp Rx */
        DBGPrntCntr(rmtUsrFreeReTx);      /*rmt usr free ret.error transmitted */
        DBGPrntCntr(rmtUsrFreeReRx);      /* rmt usr free ret.error Received */

        DBGPrntCntr(staRptReqTx);         /*   req Tx */
        DBGPrntCntr(staRptReqRx);         /*   req Rx */
        DBGPrntCntr(staRptRspTx);         /*   rsp Tx */
        DBGPrntCntr(staRptRspRx);         /*   rsp Rx */
        DBGPrntCntr(staRptReTx);          /*   re Tx */
        DBGPrntCntr(staRptReRx);          /*   re Rx */

#if MAP_REL99

        /* Note MM Event  */
        DBGPrntCntr(notMmEvReqTx);          /* Inv. Tx */
        DBGPrntCntr(notMmEvReqRx);          /* Inv. Rx */
        DBGPrntCntr(notMmEvRspTx);          /* rsp Tx */
        DBGPrntCntr(notMmEvRspRx);          /* rsp Rx */
        DBGPrntCntr(notMmEvReTx);           /* re Tx */
        DBGPrntCntr(notMmEvReRx);           /* re Rx */

#endif /* MAP_REL99 */

#endif

#if MAP_VLR
        DBGPrntCntr(sndIdReqTx);         /* Send Identification request transmitted */
        DBGPrntCntr(sndIdReqRx);         /* Send Identification request Received */
        DBGPrntCntr(sndIdRspTx);         /* Send Identification response transmitted */
        DBGPrntCntr(sndIdRspRx);         /* Send Identification response Received */
        DBGPrntCntr(sndIdReTx);          /* Send Identification ret.error transmitted */
        DBGPrntCntr(sndIdReRx);          /* Send Identification ret.error Received */

#endif

#if MAP_MSC
        DBGPrntCntr(preHoReqTx);         /* Prepare Handover request transmitted */
        DBGPrntCntr(preHoReqRx);         /* Prepare Handover request Received */
        DBGPrntCntr(preHoRspTx);         /* Prepare Handover response transmitted */
        DBGPrntCntr(preHoRspRx);         /* Prepare Handover response Received */
        DBGPrntCntr(preHoReTx);          /* Prepare Handover ret.error transmitted */
        DBGPrntCntr(preHoReRx);          /* Prepare Handover ret.error Received */

        DBGPrntCntr(preSubHoReqTx);      /* Prepare Subsequest Handover request tx */
        DBGPrntCntr(preSubHoReqRx);      /* Prepare Subsequent Handover request Received */
        DBGPrntCntr(preSubHoRspTx);      /* Prepare Subsequent Handover response tx */
        DBGPrntCntr(preSubHoRspRx);      /* Prepare Subsequent Handover response Received */
        DBGPrntCntr(preSubHoReTx);       /* Prepare Subsequent ret.error transmitted */
        DBGPrntCntr(preSubHoReRx);       /* Prepare Subsequent ret.error Received */

        DBGPrntCntr(perHoReqTx);         /* Perform Handover request transmitted */
        DBGPrntCntr(perHoReqRx);         /* Perform Handover request Received */
        DBGPrntCntr(perHoRspTx);         /* Perform Handover response transmitted */
        DBGPrntCntr(perHoRspRx);         /* Perform Handover response Received */
        DBGPrntCntr(perHoReTx);          /* Perform Handover ret.error transmitted */
        DBGPrntCntr(perHoReRx);          /* Perform Handover ret.error Received */

        DBGPrntCntr(perSubHoReqTx);      /* Perform Subsequest Handover request tx */
        DBGPrntCntr(perSubHoReqRx);      /* Perform Subsequent Handover request Received */
        DBGPrntCntr(perSubHoRspTx);      /* Perform Subsequent Handover response tx */
        DBGPrntCntr(perSubHoRspRx);      /* Perform Subsequent Handover response Received */
        DBGPrntCntr(perSubHoReTx);      /* Perform Subsequent Handover re tx */
        DBGPrntCntr(perSubHoReRx);      /* Perform Subsequent Handover re Received */

        DBGPrntCntr(sndEndSigReqTx);      /* Send End Signal request tx */
        DBGPrntCntr(sndEndSigReqRx);      /* Send End Signal request Received */
        DBGPrntCntr(sndEndSigRspTx);      /* Send End Signal request tx */
        DBGPrntCntr(sndEndSigRspRx);      /* Send End Signal request Received */

        DBGPrntCntr(procAccSigReqTx);     /* Process Access Signalling request tx */
        DBGPrntCntr(procAccSigReqRx);     /* Process Access Signalling request Received */

        DBGPrntCntr(fwdAccSigReqTx);      /* Forward Access Signalling request tx */
        DBGPrntCntr(fwdAccSigReqRx);      /* Forward Access Signalling request Received */

        DBGPrntCntr(notInterHoReqTx);     /* Note Internal Handover request tx */
        DBGPrntCntr(notInterHoReqRx);     /* Note Internal Handover request Received */

        DBGPrntCntr(resCallHandlReqTx);     /* Resume Call Handling  req Tx */
        DBGPrntCntr(resCallHandlReqRx);     /* Resume Call Handling  req Rx */
        DBGPrntCntr(resCallHandlRspTx);     /* resume Call Handling response tx*/
        DBGPrntCntr(resCallHandlRspRx);     /* resume Call Handling response Rx*/
        DBGPrntCntr(resCallHandlReTx);      /* Res. Call Handl ret.error transmitted */
        DBGPrntCntr(resCallHandlReRx);      /* Res. Call Handl ret.error Received */

        DBGPrntCntr(prepGrpCallReqTx);     /*  Prepare Grp call req Tx */
        DBGPrntCntr(prepGrpCallReqRx);     /* Prepare Grp call req Rx */
        DBGPrntCntr(prepGrpCallRspTx);     /* Prepare Grp call rsp Tx */
        DBGPrntCntr(prepGrpCallRspRx);     /*  Prepare Grp call rsp Rx */
        DBGPrntCntr(prepGrpCallReTx);     /* Prep Grp Call ret.error transmitted */
        DBGPrntCntr(prepGrpCallReRx);     /* Prep Grp Call ret.error Received */

        DBGPrntCntr(proGrpCallSigReqTx);     /* Pro Grp Call Sig  req Tx */
        DBGPrntCntr(proGrpCallSigReqRx);     /* Pro Grp Call Sig  req Rx */
        DBGPrntCntr(proGrpCallRspTx);        /* Process Group Call response tx*/
        DBGPrntCntr(proGrpCallRspRx);        /* Process Group Call  response Rx*/
        DBGPrntCntr(proGrpCallReTx);         /* Process Group Call ret.error transmitted*/
        DBGPrntCntr(proGrpCallReRx);         /* Process Group Call ret.error Received*/

        DBGPrntCntr(fwdGrpCallSigReqTx);     /* Fwd Grp Call Sig req Tx */
        DBGPrntCntr(fwdGrpCallSigReqRx);     /* Fwd Grp Call Sig req Rx */

        DBGPrntCntr(sndGrpCallEndSigReqTx);     /* Snd Grp Call End Sig req Tx */
        DBGPrntCntr(sndGrpCallEndSigReqRx);     /* Snd Grp Call End Sig req Rx */
        DBGPrntCntr(sndGrpCallEndSigRspTx);     /* snd. Grp. Call End Sig response tx*/
        DBGPrntCntr(sndGrpCallEndSigRspRx);     /* snd. Grp. Call End Sig response Rx*/
        DBGPrntCntr(sndGrpCallEndSigReTx);      /* snd. Grp. Call End Sig ret.error tx */
        DBGPrntCntr(sndGrpCallEndSigReRx);      /* snd. Grp. Call End Sig ret.error Rx */

        DBGPrntCntr(provSiwfsNmbReqTx);     /* prov Siwfs Nmb req Tx */
        DBGPrntCntr(provSiwfsNmbReqRx);     /* prov Siwfs Nmb req Rx */
        DBGPrntCntr(provSiwfsNmbRspTx);     /* prov Siwfs Nmb rsp Tx */
        DBGPrntCntr(provSiwfsNmbRspRx);     /* prov Siwfs Nmb rsp Rx */
        DBGPrntCntr(provSiwfsNmbReTx);      /* Provide Siwfs Number ret.error tx */
        DBGPrntCntr(provSiwfsNmbReRx);      /* Prov.Siwfs.Nmb ret.error Received */

        DBGPrntCntr(siwfsSigModReqTx);     /*  siwfs Sig Mod req Tx */
        DBGPrntCntr(siwfsSigModReqRx);     /*  siwfs Sig Mod req Rx */
        DBGPrntCntr(siwfsSigModRspTx);     /*  siwfs Sig Mod rsp Tx */
        DBGPrntCntr(siwfsSigModRspRx);     /*  siwfs Sig Mod rsp Rx */
        DBGPrntCntr(siwfsSigModReTx);      /*  Siwfs Sig Mod ret.error tx */
        DBGPrntCntr(siwfsSigModReRx);      /*  Siwfs.Sig Mod ret.error Received */

#endif
   
#if (MAP_MSC || MAP_GSN)
        DBGPrntCntr(fwdSMReqTx);          /* Forward SM request tx */
        DBGPrntCntr(fwdSMReqRx);          /* Forward SM request Received */
        DBGPrntCntr(fwdSMRspTx);          /* Forward SM Response tx*/
        DBGPrntCntr(fwdSMRspRx);          /* Forward SM Response Rx*/
        DBGPrntCntr(fwdSMReTx);           /* Forward SM ret.error transmitted */
        DBGPrntCntr(fwdSMReRx);           /* Forward SM ret.error Received */

        DBGPrntCntr(mtFwdSMReqTx);          /* mo Forward SM request tx */
        DBGPrntCntr(mtFwdSMReqRx);          /* mo Forward SM request Received */
        DBGPrntCntr(mtFwdSMRspTx);          /* mo Forward SM rsp tx */
        DBGPrntCntr(mtFwdSMRspRx);          /* mo Forward SM rsp Received */
        DBGPrntCntr(mtFwdSMReTx);           /* mo Forward SM ret.error transmitted */
        DBGPrntCntr(mtFwdSMReRx);           /* mo Forward SM ret.error Received */

#endif /* MAP_MSC || MAP_GSN */
#if MAP_HLR
        DBGPrntCntr(anyInterReqTx);     /* any Inter req Tx */
        DBGPrntCntr(anyInterReqRx);     /* any Inter req Rx */
        DBGPrntCntr(anyInterRspTx);     /* any Inter rsp Tx */
        DBGPrntCntr(anyInterRspRx);     /* any Inter rsp Rx */
        DBGPrntCntr(anyInterReTx);     /* any Inter re Tx */
        DBGPrntCntr(anyInterReRx);     /* any Inter re Rx */

#endif
#if (MAP_MSC || MAP_HLR)
        DBGPrntCntr(ssInvNotReqTx);     /*  ss Inv Not req Tx */
        DBGPrntCntr(ssInvNotReqRx);     /*  ss Inv Not req Rx */
        DBGPrntCntr(ssInvNotRspTx);     /*  ss Inv Not rsp Tx */
        DBGPrntCntr(ssInvNotRspRx);     /*  ss Inv Not rsp Rx */
        DBGPrntCntr(ssInvNotReTx);      /*  ss Inv Not re Tx  */
        DBGPrntCntr(ssInvNotReRx);      /*  ss Inv Not re Rx  */

#if MAP_REL99

        /* IST Alert  */
        DBGPrntCntr(istAlrtReqTx);        /* Inv. Tx */
        DBGPrntCntr(istAlrtReqRx);        /* Inv. Rx */
        DBGPrntCntr(istAlrtRspTx);        /* RR Tx */
        DBGPrntCntr(istAlrtRspRx);        /* RR Rx */
        DBGPrntCntr(istAlrtReTx);         /* RE Tx  */
        DBGPrntCntr(istAlrtReRx);         /* RE Rx  */

        /* IST Command  */
        DBGPrntCntr(istCmdReqTx);        /* Inv. Tx */
        DBGPrntCntr(istCmdReqRx);        /* Inv. Rx */
        DBGPrntCntr(istCmdRspTx);        /* RR Tx */
        DBGPrntCntr(istCmdRspRx);        /* RR Rx */
        DBGPrntCntr(istCmdReTx);         /* RE Tx  */
        DBGPrntCntr(istCmdReRx);         /* RE Rx  */

#endif /* MAP_REL99 */

#endif 

#if MAP_MSC
#if MAP_REL99
#if MAP_REL6

        /* Release Resources  */
        DBGPrntCntr(relResReqTx);        /* Inv. Tx */
        DBGPrntCntr(relResReqRx);        /* Inv. Rx */
        DBGPrntCntr(relResRspTx);        /* RR Tx */
        DBGPrntCntr(relResRspRx);        /* RR Rx */
        DBGPrntCntr(relResReTx);         /* RE Tx  */
        DBGPrntCntr(relResReRx);         /* RE Rx  */

#endif /* MAP_REL6 */
#endif /* MAP_REL99 */
#endif /* MAP_MSC */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
        DBGPrntCntr(provSubsInfoReqTx);     /* prov Subs Info req Tx */
        DBGPrntCntr(provSubsInfoReqRx);     /* prov Subs Info req Rx */
        DBGPrntCntr(provSubsInfoRspTx);     /* prov Subs Info rsp Tx */
        DBGPrntCntr(provSubsInfoRspRx);     /* prov Subs Info rsp Rx */
        DBGPrntCntr(provSubsInfoReTx);      /* prov.Subs Info ret.error transmitte*/
        DBGPrntCntr(provSubsInfoReRx);      /* prov.Subs Info ret.error Received */

#endif

#if (MAP_HLR || MAP_GSN)
        DBGPrntCntr(gprsUpLocReqTx);     /* Gprs Up. Loc req Tx */
        DBGPrntCntr(gprsUpLocReqRx);     /* Gprs Up. Loc req Rx */
        DBGPrntCntr(gprsUpLocRspTx);     /* Gprs Up. Loc rsp Tx */
        DBGPrntCntr(gprsUpLocRspRx);     /* Gprs Up. Loc rsp Rx */
        DBGPrntCntr(gprsUpLocReTx);     /* Update Gprs Location ret.error Tx*/
        DBGPrntCntr(gprsUpLocReRx);     /* Update Gprs Location  ret.error Rx */

        DBGPrntCntr(gprsRoutInfoReqTx);  /* Gprs Rout Info req Tx */
        DBGPrntCntr(gprsRoutInfoReqRx);  /* Gprs Rout Info req Rx */
        DBGPrntCntr(gprsRoutInfoRspTx);  /* Gprs Rout Info rsp Tx */
        DBGPrntCntr(gprsRoutInfoRspRx);  /* Gprs Rout Info rsp Rx */
        DBGPrntCntr(gprsRoutInfoReTx);  /* Gprs Rout Info  ret.error transmitted */
        DBGPrntCntr(gprsRoutInfoReRx);  /* Gprs Rout Info  ret.error Received */

        DBGPrntCntr(failRptReqTx);     /* Fail Rpt  req Tx */
        DBGPrntCntr(failRptReqRx);     /* Fail Rpt  req Rx */
        DBGPrntCntr(failRptRspTx);     /* Fail Rpt  rsp Tx */
        DBGPrntCntr(failRptRspRx);     /* Fail Rpt  rsp Rx */
        DBGPrntCntr(failRptReTx);     /* Fail Rpt  re Tx */
        DBGPrntCntr(failRptReRx);     /* Fail Rpt  re Rx */

        DBGPrntCntr(gprsNoteMsPresReqTx);     /* Gprs Note Ms Pres  req Tx */
        DBGPrntCntr(gprsNoteMsPresReqRx);     /* Gprs Note Ms Pres  req Rx */
        DBGPrntCntr(gprsNoteMsPresRspTx);     /* Gprs Note Ms Pres  rsp Tx */
        DBGPrntCntr(gprsNoteMsPresRspRx);     /* Gprs Note Ms Pres  rsp Rx */
        DBGPrntCntr(gprsNoteMsPresReTx);     /* Gprs Note Ms Pres  re Tx */
        DBGPrntCntr(gprsNoteMsPresReRx);     /* Gprs Note Ms Pres  re Rx */

#endif /* MAP_HLR || MAP_GSN */

#if MAP_REL99

#if MAP_HLR
        /* anytime Subscriber Interrogation */
        DBGPrntCntr(anySubsInterReqTx);    /* Inv. tx*/
        DBGPrntCntr(anySubsInterReqRx);    /* Inv. Rx*/
        DBGPrntCntr(anySubsInterRspTx);    /* RR tx*/
        DBGPrntCntr(anySubsInterRspRx);    /* RR Rx*/
        DBGPrntCntr(anySubsInterReTx);     /* RE Tx */
        DBGPrntCntr(anySubsInterReRx);     /* RE Rx */

        /* anytime Modification */
        DBGPrntCntr(anyModReqTx);    /* Inv. tx*/
        DBGPrntCntr(anyModReqRx);    /* Inv. Rx*/
        DBGPrntCntr(anyModRspTx);    /* RR tx*/
        DBGPrntCntr(anyModRspRx);    /* RR Rx*/
        DBGPrntCntr(anyModReTx);     /* RE Tx */
        DBGPrntCntr(anyModReRx);     /* RE Rx */

        /* Note Subscriber Modification */
        DBGPrntCntr(notSubsModReqTx);    /* Inv. tx*/
        DBGPrntCntr(notSubsModReqRx);    /* Inv. Rx*/
        DBGPrntCntr(notSubsModRspTx);    /* RR tx*/
        DBGPrntCntr(notSubsModRspRx);    /* RR Rx*/
        DBGPrntCntr(notSubsModReTx);     /* RE Tx */
        DBGPrntCntr(notSubsModReRx);     /* RE Rx */
#endif /* MAP_HLR */

#endif /* MAP_REL99 */

#if (MAP_REL98 || MAP_REL99)
#if (MAP_MSC || MAP_MLC)
        /* provide subscriber location */
        DBGPrntCntr(provSubsLocReqTx);    /* Inv. tx*/
        DBGPrntCntr(provSubsLocReqRx);    /* Inv. Rx*/
        DBGPrntCntr(provSubsLocRspTx);    /* RR tx*/
        DBGPrntCntr(provSubsLocRspRx);    /* RR Rx*/
        DBGPrntCntr(provSubsLocReTx);     /* RE Tx */
        DBGPrntCntr(provSubsLocReRx);     /* RE Rx */

        /* subscriber Location */
        DBGPrntCntr(subsLocReqTx);    /* Inv. tx*/
        DBGPrntCntr(subsLocReqRx);    /* Inv. Rx*/
        DBGPrntCntr(subsLocRspTx);    /* RR tx*/
        DBGPrntCntr(subsLocRspRx);    /* RR Rx*/
        DBGPrntCntr(subsLocReTx);     /* RE Tx */
        DBGPrntCntr(subsLocReRx);     /* RE Rx */
#endif /* MAP_MSC || MAP_MLC */
#endif /* MAP_REL98 || MAP_REL99 */

#if (MAP_HLR || MAP_MLC)
		DBGPrntCntr(anyTimeInterReqTx);  /* Any Time Interrogation request tx*/
		DBGPrntCntr(anyTimeInterReqRx);  /* Any Time Interrogation request Rx*/
		DBGPrntCntr(anyTimeInterRspTx);  /* Any Time Interrogation response tx*/
		DBGPrntCntr(anyTimeInterRspRx);  /* Any Time Interrogation response Rx*/
		DBGPrntCntr(anyTimeInterReTx);   /* Any Time Interrogation ret.err Tx */
		DBGPrntCntr(anyTimeInterReRx);   /* Any Time Interrogation ret.err Rx */

#if (MAP_REL98 || MAP_REL99)
		/* send routing info for LCS */
		DBGPrntCntr(lcsSndRoutInfoReqTx);    /* Inv. tx*/
		DBGPrntCntr(lcsSndRoutInfoReqRx);    /* Inv. Rx*/
		DBGPrntCntr(lcsSndRoutInfoRspTx);    /* RR tx*/
		DBGPrntCntr(lcsSndRoutInfoRspRx);    /* RR Rx*/
		DBGPrntCntr(lcsSndRoutInfoReTx);     /* RE Tx */
		DBGPrntCntr(lcsSndRoutInfoReRx);     /* RE Rx */
#endif /* MAP_REL98 || MAP_REL99 */

#endif /* MAP_HLR || MAP_MLC */
	}
    
	if(action == MADBG_PRNT_ZERO_STS)
	{
		cmZero(&(s->sts), sizeof(s->sts));
	}
	else if (action == MADBG_ZERO_STS)
	{
		cmZero(&(s->sts), sizeof(s->sts));
	}
	
	return(XSUCC);
}


XS16  maShowGenSts(CLI_ENV *pCliEnv, SuId sapid, U16 action)
{
	MaSap 	*s;
	SuId		suId = sapid;
	
	if (suId >= (SuId)maCb.maCP.nmbMAUSaps || suId < 0 || 
       ((s = *(maCb.maSapLmaPtr + suId)) == (MaSap *)NULLP))
	{
		return(XERROR);
	}

	if(action != MADBG_ZERO_STS)
	{
		XOS_CliExtPrintf(pCliEnv, "\tUiOpenReq   :%d\r\n", s->sts.openReqTx);
		XOS_CliExtPrintf(pCliEnv, "\tUiOpenInd   :%d\r\n", s->sts.openReqRx);
		XOS_CliExtPrintf(pCliEnv, "\tUiOpenRsp   :%d\r\n", s->sts.openRspTx);
		XOS_CliExtPrintf(pCliEnv, "\tUiOpenCfm   :%d\r\n", s->sts.openRspRx);
		XOS_CliExtPrintf(pCliEnv, "\tUiCloseReq  :%d\r\n", s->sts.closeTx);	
		XOS_CliExtPrintf(pCliEnv, "\tUiCloseInd  :%d\r\n", s->sts.closeRx);
		XOS_CliExtPrintf(pCliEnv, "\tUiAbrtReq   :%d\r\n", s->sts.abrtTx);
		XOS_CliExtPrintf(pCliEnv, "\tUiAbrtInd   :%d\r\n", s->sts.abrtRx);

		if (action == MADBG_PRNT_ZERO_STS)
		{
			cmZero(&(s->sts), sizeof(s->sts));
		}
	}
	else	if (action == MADBG_ZERO_STS)
	{
		cmZero(&(s->sts), sizeof(s->sts));
	}

	return(XSUCC);
}

#ifdef ZJ
XVOID maShowZJRsetLstCB(CLI_ENV *pCliEnv, CmPFthaRsetMap *pZjCb)
{
    XOS_CliExtPrintf(pCliEnv, "\tcbType      :(%d)\n\tRsetId      :(%d)\r\n",pZjCb->cbType, pZjCb->rsetId);
    return;
}
#endif

/*print MaDlgCp block*/
XS16 maDbgShDlgInfo(CLI_ENV *pCliEnv, MaDlgCp  *pDlg)
{
	if(pDlg == NULLP)
	{
		XOS_CliExtPrintf(pCliEnv, "[MAP] NULL Dlg pointer\r\n");
		return(XERROR);
	}
	
	XOS_CliExtPrintf(pCliEnv, "[MAP] the dialog info :\r\n\r\n");

	/*apn, sudlgid, apdlgid*/
	XOS_CliExtPrintf(pCliEnv, "\tApp context :(%s)\n\tsuDlgId     :(%d)\n\tspDlgId     :(%d)\r\n", pDlg->apn.val, pDlg->suDlgId, pDlg->spDlgId);

	/*dest reference, src reference*/
	if(pDlg->destRef.pres == TRUE)
	{
		XOS_CliExtPrintf(pCliEnv, "\tdest ref    :(%s)\r\n", pDlg->destRef.val);
	}
	if(pDlg->srcRef.pres == TRUE)
	{
		XOS_CliExtPrintf(pCliEnv, "\tresource ref:(%s)\r\n", pDlg->srcRef.val);
	}
	/*dialog state*/
	XOS_CliExtPrintf(pCliEnv, "[MAP] [dialog state (0):idle (1):wait user req\n\t(2):wait init data (3):dlg initiated\n\t(4):dlg accepted (5):dlg pending\n\t(6):dlg established (7):max state]\r\n");
	XOS_CliExtPrintf(pCliEnv, "\tdialog state:(%d)\r\n", pDlg->dsmState);
	/*end flag*/
	XOS_CliExtPrintf(pCliEnv, "\tpre-arr term:(%s)\r\n", (pDlg->endFlg)?"TRUE":"FALSE");
	/*tc abort type*/
	XOS_CliExtPrintf(pCliEnv, "\tTC Abrt type:(%d)[(4):uAbort (13):pAbort]", pDlg->tcAbrtType);
	/*abort cause*/
	if(pDlg->tcAbrtCause.pres == TRUE)
	{
		XOS_CliExtPrintf(pCliEnv, "\tTC Abrt caus:(%#x)[(4):uAbort (13):pAbort]\r\n", pDlg->tcAbrtCause.octet);
	}
	else
		XOS_CliExtPrintf(pCliEnv, "\tTC Abrt caus:nothing\r\n");

	/*user info*/
	XOS_CliExtPrintf(pCliEnv, "\tUsrInfo pres:(%s)\r\n", (pDlg->usrInfoPres)?"TRUE":"FALSE");

	/*close pdu*/
	XOS_CliExtPrintf(pCliEnv, "\tClsePDU recv:(%s)\r\n", (pDlg->closePduPres)?"TRUE":"FALSE");
	
	XOS_CliExtPrintf(pCliEnv, "\tCompo pres  :(%d)\r\n", (pDlg->cmpPresFlg)?"TRUE":"FALSE");

#if (MATV2 && STUV2)
	XOS_CliExtPrintf(pCliEnv, "\tMAP Msgimprt :(%d)\r\n", pDlg->imp);
#endif
	  
#ifdef MATV3
	XOS_CliExtPrintf(pCliEnv, "\tMTP3 msg pri :(%d)\r\n", pDlg->maPrior);
	XOS_CliExtPrintf(pCliEnv, "\tSCCP prot typ:(%d)\r\n", pDlg->pClass);
#endif /* MATV3 */

#ifdef LMAV3
	XOS_CliExtPrintf(pCliEnv, "\tlast upd stamp:(%d)\r\n", pDlg->tmStmp);
#endif

#ifdef ZJ
{
    CmPFthaRsetMap *pZjCb;
    pZjCb = &pDlg->zjMaCb;
    XOS_CliExtPrintf(pCliEnv, "MAP PSF(ZJ) list Info:\r\n");
    XOS_CliExtPrintf(pCliEnv, "----------------------------\r\n");

	XOS_CliExtPrintf(pCliEnv, "\tlast upd stamp:(%d)\r\n", (pDlg->upd)?"TRUE":"FALSE");
    while(pZjCb != NULL)
    {
        maShowZJRsetLstCB(pCliEnv, pZjCb);
        pZjCb = pZjCb->next;
    }
}
#endif
	
	return(XSUCC);
}

/* print MaMAUCfg block*/
XS16 maDbgShowSapCfg(CLI_ENV *pCliEnv, MaMAUCfg *cfg)
{
	if(cfg == NULLP)
	{
		XOS_CliExtPrintf(pCliEnv, "[MAP] NULL pointer\r\n%s:%d\r\n", __FILE__, __LINE__);
		return(XERROR);
	}
	
	XOS_CliExtPrintf(pCliEnv, "[MAP] upper(AU) SAP cfg:\r\n");
	XOS_CliExtPrintf(pCliEnv, "\tswtch       :(%d)\n\tsel to AU   :(%d)\n\tpriority    :(%d)\n\trouteMU     :(%d) \r\n", cfg->swtch, cfg->selectorMU, cfg->priorMU, cfg->routeMU);
	XOS_CliExtPrintf(pCliEnv, "\tssn         :(%d)\n\tpri for SP  :(%d)\n\tmax dialog  :(%d)\r\n", cfg->ssn, cfg->maPrior,cfg->maxDlg);
	XOS_CliExtPrintf(pCliEnv, "[MAP] memory info:\r\n");
	XOS_CliExtPrintf(pCliEnv, "\tregion      :(%d)\n\tpool        :(%d)\r\n", cfg->memMU.region, cfg->memMU.pool);
	XOS_CliExtPrintf(pCliEnv, "\tgrd tmr enb :(%d)\r\n", cfg->maGrdTmr.enb);
	if(cfg->maGrdTmr.enb == TRUE)
	{
		XOS_CliExtPrintf(pCliEnv, "\tguard time  :(%d)\r\n", cfg->maGrdTmr.val);
	}

	XOS_CliExtPrintf(pCliEnv, "[MAP] lower(TC) SAP cfg:\r\n");
	XOS_CliExtPrintf(pCliEnv, "\tsel to TC   :(%d)\n\tpriority    :(%d)\n\trouteTC     :(%d)\r\n", cfg->selectorTC, cfg->priorTC, cfg->routeTC);
	XOS_CliExtPrintf(pCliEnv, "\tprocIdTC    :(%d)\n\tentTC       :(%d)\n\tinstTC      :(%d)\r\n", cfg->procIdTC, cfg->entTC,cfg->instTC);
	XOS_CliExtPrintf(pCliEnv, "\tsapid TC    :(%d)\n\tstart dlg id:(%d)\n\trange of dlg:(%d) \r\n", cfg->spIdTC, cfg->stDlgId, cfg->range);
	XOS_CliExtPrintf(pCliEnv, "[MAP] memory info:\r\n");
	XOS_CliExtPrintf(pCliEnv, "\tregion      :(%d)\n\tpool        :(%d)\r\n", cfg->memTC.region, cfg->memTC.pool);	
	XOS_CliExtPrintf(pCliEnv, "\tretrytmr enb:(%d)\r\n", cfg->tIntTmr.enb);
	if(cfg->tIntTmr.enb == TRUE)
	{
		XOS_CliExtPrintf(pCliEnv, "\tretry time  :(%d)\r\n", cfg->tIntTmr.val);
	}
	
	XOS_CliExtPrintf(pCliEnv, "\tret option  :(%d)\n\tSCCP type   :(%d)\r\n", cfg->retOpt, cfg->pClass);	

	return(XSUCC);
}

VOID maShowDlg(CLI_ENV *pCliEnv, SuId sapId)
{
    U16		i;
    MaSap 	*s;
    MaDlgCp  *pDlg;
    U32	dlgNmb;

    if (sapId >= (SuId)maCb.maCP.nmbMAUSaps || sapId < 0 || 
        ((s = *(maCb.maSapLmaPtr + sapId)) == NULLP))
    {
        XOS_CliExtPrintf(pCliEnv, "[MAP] show dialog info : Invalid sap Id\r\n");
        RETVOID;
    }

	/*current dialog info*/
/*
	pDlg = s->curDlgCp;
	if(pDlg == NULLP)
	{
		XOS_CliExtPrintf(pCliEnv, "[MAP] there is nothing for the current dialog info!\r\n\r\n");
		RETVOID;
	}
	else
	{
		maDbgShDlgInfo(pCliEnv, pDlg);
	}
*/
	/*all dialog info*/
	for(i=0,dlgNmb=0;i<MA_DLG_HASH_SIZE;i++)
	{
		if(s->maDlgTbl[i] != NULLP)
		{
         for(pDlg = s->maDlgTbl[i];pDlg !=NULLP;pDlg = pDlg->next)
         {
				maDbgShDlgInfo(pCliEnv, pDlg);
				++dlgNmb;
         }
		}
	}
	
	XOS_CliExtPrintf(pCliEnv, "[MAP] sap (%d) actived dialog number (%ld)\r\n", sapId, dlgNmb);/*s->nmbActvDlg*/
	
	RETVOID;
}


/*print MaSap block*/
VOID maGetSapStat(CLI_ENV* pCliEnv, SuId sapId)
{
	MaSap 	*s;
	MaDlgCp  *pDlg;
/*
	MaDlgCp  *pDlg;
	U16 i=0;
	U32	dlgNmb;
*/
       if (sapId >= (SuId)maCb.maCP.nmbMAUSaps || sapId < 0 || 
           ((s = *(maCb.maSapLmaPtr + sapId)) == NULLP))
       {
		XOS_CliExtPrintf(pCliEnv, "[MAP] show SAP state : Invalid sap Id\r\n");
		RETVOID;
       }
       /*16 space Width*/
	XOS_CliExtPrintf(pCliEnv, "\r\n[MAP]  SAP (%d) state info :\r\n", sapId);
    XOS_CliExtPrintf(pCliEnv, "-------------------------------------------\r\n");
	XOS_CliExtPrintf(pCliEnv, "\tsuId        :(%d)\n\tspId        :(%d)\n\tssn         :(%d)\r\n", s->suId, s->spIdTC, s->ssn);
    XOS_CliExtPrintf(pCliEnv, "\tUser state : (0):unbound (1):configured\n\t(2):bound but disable (3): bound and enable\n\t(4):wait for bound conf\r\n");
	XOS_CliExtPrintf(pCliEnv, "\tsap status  :(%d)\n\tupper state :(%d)\n\tlower state :(%d)\r\n", s->maState, s->uiState, s->liState);
	XOS_CliExtPrintf(pCliEnv, "\tactv dlg num:(%d)\n\tmsg priority:(%d)\r\n", s->nmbActvDlg, s->maPrior);

	/*post to AU*/
	XOS_CliExtPrintf(pCliEnv, "\tpost to AU:\r\n");
	maPrntPost(pCliEnv, &s->maPstMU);

	/*post to TC*/
	XOS_CliExtPrintf(pCliEnv, "\tpost to TC:\r\n");
	maPrntPost(pCliEnv, &s->maPstST);
	
	/*bitmap*/
	XOS_CliExtPrintf(pCliEnv, "\tbitmap size :(%d)\n\tbitmap      :(%s)\r\n", s->bitMap.size, s->bitMap.map);

	XOS_CliExtPrintf(pCliEnv, "\tbind retry  :(%d)\r\n", s->bndRetryCnt);
	XOS_CliExtPrintf(pCliEnv, "\ttrace state :(%d)\r\n", s->trc);
	/*qos info*/
	XOS_CliExtPrintf(pCliEnv, "\tQOS info:\n\tmsg priority:(%d)\n\tretOpt      :(%d)\n\tseqCtl      :(%d)\r\n", s->qosSet.msgPrior, s->qosSet.retOpt,s->qosSet.seqCtl);

	/*sap cfg*/
	maDbgShowSapCfg(pCliEnv, &s->cfg);
		
	/*current dialog info*/
	pDlg = s->curDlgCp;
	/*apn, sudlgid, spdlgid*/
	if(pDlg == NULLP)
	{
		XOS_CliExtPrintf(pCliEnv, "[MAP] the current dialog is NULL!\r\n"); 
	}
	else
	{
		XOS_CliExtPrintf(pCliEnv, "[MAP] the current dialog info :\r\n");
		maDbgShDlgInfo(pCliEnv, pDlg);
	}
	
	/*All dialog info(when there are a lot of dialogs in the SAp, it is too much to get debug)*/
/*
	XOS_CliExtPrintf(pCliEnv, "[MAP] ALL dialog info :\r\n\r\n");
	maShowDlg(pCliEnv, sapId);
*/
	/*sap sts*/
 	if(maShowGenSts(pCliEnv, sapId, MADBG_PRNT_STS) != XSUCC)
		XOS_CliExtPrintf(pCliEnv, "[MAP] show statistics : FAILED\r\n");
	if(maShowOprSts(pCliEnv, sapId, MADBG_PRNT_STS) != XSUCC)
		XOS_CliExtPrintf(pCliEnv, "[MAP] show statistics : FAILED\r\n");
	
	RETVOID;
}

VOID maGetAllSapStat(CLI_ENV *pCliEnv)
{
	SuId sapid;
    if(maCb.maInit.cfgDone != TRUE)
    {
        XOS_CliExtPrintf(pCliEnv, "[MAP] the MAP stack DO NOT Cfg!\r\n");
        return;
    }

	for(sapid=0 ; sapid<(SuId)maCb.maCP.nmbMAUSaps ; sapid++)
	{
        if (*(maCb.maSapLmaPtr + sapid) == NULLP)
        {
            if(sapid >= (SuId)maCb.maCP.nmbMAUSaps)
            {
                XOS_CliExtPrintf(pCliEnv, "[MAP] show All SAP state : NO SAP be configured!");
                return;
            }
            else
            {
                continue;
            }
        }
		maGetSapStat(pCliEnv,sapid);
	}
}

VOID maShowSapStat(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv)
{

	if(maArgc == 1)
	{
		maGetAllSapStat(pCliEnv);
	}
	else if(maArgc == 2)
	{
		maGetSapStat(pCliEnv,(S16)atoi(ppArgv[1]));
	}
    else
    {
        XOS_CliExtPrintf(pCliEnv, "[MAP] show SAP state : parameters number error!\r\n");
    }
}

VOID maShowDlgStat(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv)
{
	SuId sapid;
	if(maArgc == 1)
	{
		for(sapid=0 ; sapid<(SuId)maCb.maCP.nmbMAUSaps ; sapid++)
		{
            if (sapid >= (SuId)maCb.maCP.nmbMAUSaps || sapid < 0 || 
               (*(maCb.maSapLmaPtr + sapid) == NULLP))
            {
            	break;
            }
            maShowDlg(pCliEnv,sapid);
		}
	}
	else if(maArgc == 2)
	{
		maShowDlg(pCliEnv,(S16)atoi(ppArgv[1]));
	}
    else
    {
        XOS_CliExtPrintf(pCliEnv, "[MAP] show dialog info : parameters number error!\r\n");
    }
}

/* print MaGenCfg block*/
XS16 maShowGenCfg(CLI_ENV *pCliEnv, MaGenCfg *gencfg)
{
	XOS_CliExtPrintf(pCliEnv, "[MAP] MAP general configuration Info :\r\n");	
	XOS_CliExtPrintf(pCliEnv, "\tmax sap num :(%d)\r\n", gencfg->nmbMAUSaps);
	XOS_CliExtPrintf(pCliEnv, "\tmax oper num:(%d)\r\n", gencfg->nmbOpr);
	XOS_CliExtPrintf(pCliEnv, "\tmax dlg num :(%d)\r\n", gencfg->nmbDlgs);
	XOS_CliExtPrintf(pCliEnv, "\ttime res    :(%d)\r\n", gencfg->timeRes);
	XOS_CliExtPrintf(pCliEnv, "\tdlg id range:(%d)\r\n", gencfg->range);
	/*post to SM*/
	XOS_CliExtPrintf(pCliEnv, "\tpst to SM :\r\n");
	maPrntPost(pCliEnv, &gencfg->smPst);

	return(XSUCC);
}

/*print MaCb block*/
VOID maShowMaCfg(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv)
{
	U16 i=0;

    XOS_CliExtPrintf(pCliEnv, "\r\n[MAP] MAP Config Info:\r\n");
    XOS_CliExtPrintf(pCliEnv, "---------------------------------\r\n");
	for(i=0 ; i < SS_MAX_TTSKS ; i++)
	{
		if(ENTMA == osCp.tTskTbl[i].ent)
		{
            XOS_CliExtPrintf(pCliEnv, "[MAP] MAP SYS Task Info:\r\n");
			XOS_CliExtPrintf(pCliEnv, "\tentity ID   :(%d)\n\tinstance ID :(%d)\n\ttask type   :(%d)\n\ttsk priority:(%d)\r\n", osCp.tTskTbl[i].ent, osCp.tTskTbl[i].inst, osCp.tTskTbl[i].tskType, osCp.tTskTbl[i].tskPrior);
			if(osCp.tTskTbl[i].sTsk != NULLP)
				XOS_CliExtPrintf(pCliEnv, "\tsys task id :(%d)\n\tsystsk prior:(%d)\r\n", osCp.tTskTbl[i].sTsk->tskId, osCp.tTskTbl[i].sTsk->tskPrior);
			else
				XOS_CliExtPrintf(pCliEnv, "[MAP] system task (NULL)!\r\n");
			break;
		}
	}
	if(i >= SS_MAX_TTSKS)
		XOS_CliExtPrintf(pCliEnv, "[MAP] MAP SYS Task Info is NULL\r\n");
	else
	{
        XOS_CliExtPrintf(pCliEnv, "[MAP] MAP TAPA task Info :\r\n");
        XOS_CliExtPrintf(pCliEnv, "\tMAP ent Id  :(%d)\n\tMAP ins Id  :(%d)\r\n", maCb.maInit.ent, maCb.maInit.inst);
        XOS_CliExtPrintf(pCliEnv, "\tMAP region  :(%d)\n\tMAP pool    :(%d)\r\n", maCb.maInit.region, maCb.maInit.pool);
#ifdef DEBUGP
        XOS_CliExtPrintf(pCliEnv, "\tdebug mask  :(%#x)\r\n", maCb.maInit.dbgMask);
#endif
        XOS_CliExtPrintf(pCliEnv, "\tConfig Done :(%s)\n\taccouting   :(%s)\n\tunsolic sta :(%s)\n\ttrace       :(%s)\r\n\treason      :(%d)\r\n", (maCb.maInit.cfgDone)?"TRUE":"FALSE", (maCb.maInit.acnt)?"TRUE":"FALSE", (maCb.maInit.usta)?"TRUE":"FALSE", (maCb.maInit.trc)?"TRUE":"FALSE", maCb.maInit.reason);

        if(maCb.maInit.cfgDone == TRUE)
        {
            /*general cfg*/
            maShowGenCfg(pCliEnv, &maCb.maCP);
            /*all sap state*/
            /*	maGetAllSapStat(pCliEnv);	*/
        }
		else
		{
			XOS_CliExtPrintf(pCliEnv, "[MAP] the MAP stack NOT CONFIGURED!\r\n");
		}
	}
}

VOID maTstCaseRun(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv)
{
#ifdef MA_CLI_ACCDBG
	if(maArgc == 2)
	{
		tstCaseRun(pCliEnv,(U16)atoi(ppArgv[1]));
	}
	else
	{
		XOS_CliExtPrintf(pCliEnv, "[MAP] please input case id:\r\n");
	}
#else
    XOS_CliExtPrintf(pCliEnv, "TEST DO NOT INIT!\r\n");
#endif	
}

XVOID maShowSts(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv)
{
	SuId sapid;
	U16 action;

	if(maArgc == 1)
	{
		for(sapid=0 ; sapid<(SuId)maCb.maCP.nmbMAUSaps ; sapid++)
		{
                if (sapid >= (SuId)maCb.maCP.nmbMAUSaps || sapid < 0 || 
                   (*(maCb.maSapLmaPtr + sapid) == NULLP))
                {
                	break;
                }
                /*
                if(maShowGenSts(pCliEnv, sapid, MADBG_PRNT_STS) != XSUCC)
                XOS_CliExtPrintf(pCliEnv, "[MAP] show statistics ========>FAILED\r\n");
                */
                if(maShowOprSts(pCliEnv, sapid, MADBG_PRNT_STS) != XSUCC)
                XOS_CliExtPrintf(pCliEnv, "[MAP] show statistics : FAILED\r\n");
		}
	}
	else if(maArgc == 2)
	{
		sapid = atoi(ppArgv[1]);

    	if (sapid >= (SuId)maCb.maCP.nmbMAUSaps || sapid < 0 || 
           ((*(maCb.maSapLmaPtr + sapid)) == (MaSap *)NULLP))
    	{
            XOS_CliExtPrintf(pCliEnv, "[MAP] show statistic : Invalid SAP ID\r\n");
    		return;
    	}

		if(maShowOprSts(pCliEnv, sapid, MADBG_PRNT_STS) != XSUCC)
		{
			XOS_CliExtPrintf(pCliEnv, "[MAP] show statistics : FAILED\r\n");
		}
	}
    else if(maArgc == 3)
	{
		sapid = atoi(ppArgv[1]);
		action = atoi(ppArgv[2]);
		if((action != MADBG_PRNT_STS) && (action != MADBG_PRNT_ZERO_STS) && (action!= MADBG_ZERO_STS))
		{
			XOS_CliExtPrintf(pCliEnv, "[MAP] show statistic : Invalid action type\r\n");
			RETVOID;
		}
    	if (sapid >= (SuId)maCb.maCP.nmbMAUSaps || sapid < 0 || 
           ((*(maCb.maSapLmaPtr + sapid)) == (MaSap *)NULLP))
    	{
            XOS_CliExtPrintf(pCliEnv, "[MAP] show statistic : Invalid SAP ID\r\n");
    		return;
    	}

		if(maShowOprSts(pCliEnv, sapid, action) != XSUCC)
		{
			XOS_CliExtPrintf(pCliEnv, "[MAP] show statistics : FAILED\r\n");
		}
	}
	else
	{
		XOS_CliExtPrintf(pCliEnv, "[MAP] show statistic : parameters number error\r\n");
	}
		
}

XVOID maDbgControl(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv)
{
	XOS_CliExtPrintf(pCliEnv, "[MAP] this is the control command!\r\n");

}

#ifdef ANSI
PUBLIC XS16 MapStart
(
SSTskId tskId
)
#else
PUBLIC XS16 MapStart(tskId)
SSTskId tskId;
#endif
{
#if (!defined(MATST) && !defined(MA_CLI_ACCDBG))
   SSTskId *pTskId = NULLP;
#endif

#ifdef SS_MULTIPLE_PROCS
   XS16   i;
   ProcId   pIdLst[MA_MAX_INSTANCES];
#endif

   TRC1(MapStart)

#ifdef MA_CLI_ACCDBG

/* default ACC test assignments */
   maAccCb.pSwtch = LMA_VER2P;

   /* upper selector assignment */
   maAccMaUiSel=1;
   maAccAuUiSel=1;

   /* lower layer selector assignment */
   maAccMaLiSel=1;
   maAccStLiSel=1;

   /* management layer selector assignment */
   maAccMaMiSel=0;
   maAccSmMiSel=0;

#ifdef ZJ
   /* management layer selector assignment for PSF MAP */
   maAccMaZjMiSel=1;
   maAccSmZjMiSel=1;
#endif

   /* Mark the Acceptance Test is ON */
   maAccCb.testFlg = TRUE;

   /* initialise the loop counter */
   maAccCb.nmbLoops = 0;

#ifdef SS_MULTIPLE_PROCS
   for (i=0; i<MA_MAX_INSTANCES;i++)
      pIdLst[i]=i;
   SAddProcIdLst(2,pIdLst);
#endif


   /* initialize the TU layer control block */
   maInitAccCb();

#endif/*MA_CLI_ACCDBG*/

   /****** create all tapa tasks ******/
  
#ifdef SS_MULTIPLE_PROCS
   /* Register MAP task */
   SRegTTsk(TSTPROCID0, ENTMA, MADBG_INST_0, TTNORM, 0, maActvInit, maActvTsk);

   /* Register Layer Management tasks */
   SRegTTsk(TSTPROCID0, ENTSM, MADBG_INST_0, TTNORM, 0, smActvInit, smActvTsk);

   /* Register Layer Management tasks */
   SRegTTsk(TSTPROCID0, ENTST, MADBG_INST_0, TTNORM, 0, stActvInit, stActvTsk);

   /* Register MAP User tasks */
   SRegTTsk(TSTPROCID0, ENTAU, MADBG_INST_0, TTNORM, 0, auActvInit, auActvTsk);

#ifdef STMA        
   /* Register Layer 3 (SCCP) tasks */
   SRegTTsk(TSTPROCID0, ENTSP, MADBG_INST_0, TTNORM, 0, spActvInit, spActvTsk);
#endif /* SCCP    */

#ifdef MA_FTHA
   /* Register dummy System Agent  Management tasks */
   SRegTTsk(TSTPROCID0, ENTSH, MADBG_INST_0, TTNORM, 0, shActvInit, shActvTsk);
#endif /* MA_FTHA */

#ifdef ZJ
   /* Register Message Router task*/
   SRegTTsk(TSTPROCID0, ENTMR, MADBG_INST_0, TTNORM, 0, mrActvInit, mrActvTsk);
#endif /* ZJ */

   /* Register a permanent task for TCAP user */
   SRegTTsk(TSTPROCID0, ENTAU, MADBG_INST_1, TTPERM, 0, maPermTskInit, maPermTsk);
#else /*SS_MULTIPLE_PROCS*/

#ifdef MATST
   /* Register Layer Management tasks */
   SRegTTsk(ENTSM, MADBG_INST_0, TTNORM, 0, smActvInit, smActvTsk);
#endif

   /* Register MAP task */
   SRegTTsk(ENTMA, MADBG_INST_0, TTNORM, 0, maActvInit, maActvTsk);

#ifdef MA_CLI_ACCDBG
   /* Register Layer Management tasks */
   SRegTTsk(ENTST, MADBG_INST_0, TTNORM, 0, stActvInit, stActvTsk);

    /* Register MAP User tasks */
   SRegTTsk(ENTAU, MADBG_INST_0, TTNORM, 0, auActvInit, auActvTsk);
#endif

#ifdef STMA        
   /* Register Layer 3 (SCCP) tasks */
   SRegTTsk(ENTSP, MADBG_INST_0, TTNORM, 0, spActvInit, spActvTsk);
#endif /* SCCP    */

#ifdef MA_FTHA
   /* Register dummy System Agent  Management tasks */
   SRegTTsk(ENTSH, MADBG_INST_0, TTNORM, 0, shActvInit, shActvTsk);
#endif /* MA_FTHA */

#ifdef ZJ
   /* Register Message Router task*/
   SRegTTsk(ENTMR, MADBG_INST_0, TTNORM, 0, mrActvInit, mrActvTsk);
#endif /* ZJ */

   /* Register a permanent task for TCAP user */
#if (!defined(MA_CLI_ACCDBG) && defined(MATST))
   SRegTTsk(ENTAU, MADBG_INST_1, TTPERM, 0, maPermTskInit, maPermTsk);
#endif
#endif

   /* create a single system thread */
#ifdef MATST
   if(tskId == 0)
   {
       SCreateSTsk(PRIOR0, &tskId);
   }
#else
	if (tskId == 0) /* if the globle task not exsit, create */
	{
		SCreateSTsk(0, &tskId);
#ifdef DEBUGP
		printf("\nMAP Get TASK ID: %x\n", tskId);
#endif
	}
#endif /* MATST */

   /****** attach all TAPA tasks to the same system thread ******/

#ifdef SS_MULTIPLE_PROCS
   SAttachTTsk(TSTPROCID0, ENTMA, MADBG_INST_0, tskId);
   SAttachTTsk(TSTPROCID0, ENTAU, MADBG_INST_0, tskId);
   SAttachTTsk(TSTPROCID0, ENTSM, MADBG_INST_0, tskId);

#ifdef MA_FTHA
   SAttachTTsk(TSTPROCID0, ENTSH, MADBG_INST_0, tskId);
#endif

   SAttachTTsk(TSTPROCID0, ENTST, MADBG_INST_0, tskId);
   SAttachTTsk(TSTPROCID0, ENTAU, MADBG_INST_1, tskId);
#else /*SS_MULTIPLE_PROCS*/

#ifdef MATST
	SAttachTTsk(ENTSM, MADBG_INST_0, tskId);
	SAttachTTsk(ENTMA, MADBG_INST_0, tskId);
#else	
	SAttachTTsk(ENTMA, MADBG_INST_0, tskId);
#endif

#ifdef MA_FTHA
   SAttachTTsk(ENTSH, MADBG_INST_0, tskId);
#endif

#ifdef MA_CLI_ACCDBG
   SAttachTTsk(ENTST, MADBG_INST_0, tskId);
   SAttachTTsk(ENTAU, MADBG_INST_0, tskId);
#endif
#if (!defined(MA_CLI_ACCDBG) && defined(MATST))
   SAttachTTsk(ENTAU, MADBG_INST_1, tskId);
#endif
#endif

/*config the map protocol*/
/*
   while(!maAccCb.cfgDone)
   {
   	XS16 ret;
      ret = maAccCfgMaTst();
	  if(ret != ROK)
	  {
	  	return(RFAILED);
	  }
   }
*/
   SPrint("\r\n\r\nconfig MAP protocol finished!\r\n\r\n");

#ifdef CP_OAM_SUPPORT
   maInitCfgData();

   if( ROK != smRegCb((Ent)ENTMA, gMaSmQ, sizeof(gMaSmQ)/sizeof(CmLListCp), smMaSendReqQ, maResetCfgData))
   {
      RETVALUE(RFAILED);
   }

	if( OAM_CALL_SUCC != register_msg_proc(CP_MODULE_ID_SS7_MAP,  APP_SYNC_MSG,  maInitCfgCallback, NULL))
	{
      RETVALUE(RFAILED);
   } 	

   if( OAM_CALL_SUCC != app_register(CP_MODULE_ID_SS7_MAP, &maCfgTbl[0], 6))/*sizeof(maCfgTbl)/sizeof(maCfgTbl[0])*/
   {
      RETVALUE(RFAILED);
   }
#endif

   return(ROK);
}


PUBLIC VOID Test_Init_MAP(CLI_ENV *pCliEnv)
{
    if (ssiInit() !=XSUCC)
    {
        XOS_CliExtPrintf(pCliEnv, "[MAP] MAP Init Failed!\n");
        exit(0);
    }
	if(MapStart(0) != XSUCC)
	{
        XOS_CliExtPrintf(pCliEnv, "[MAP] MAP Init Failed!\n");
        exit(0);		
	}
}

 #endif/*SSI_WITH_CLI_ENABLED*/

/*added by wanglijun for set dbgmask from shell*/
#ifdef MA_DEBUG
U32 g_maDbgMask = DBGMASK_LI|DBGMASK_UI|DBGMASK_MI;
#else
U32 g_maDbgMask = 0;
#endif

Void maSetDbgMaskFromShell(U32 dbgMask)
{
  g_maDbgMask = dbgMask;
#ifdef DEBUGP
  maCb.maInit.dbgMask = dbgMask;
#endif
  RETVOID;
}


 
