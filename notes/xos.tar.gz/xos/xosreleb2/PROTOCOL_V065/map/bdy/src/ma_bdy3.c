/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     map
  
     Type:     C Source file
  
     Desc:     This file contains the C source code for MAP specific 
               services. (Request and Responses ) 
  
     File:     ca_bdy3.c
  
     Sid:      ca_bdy3.c@@/main/13 - Fri Sep 16 02:47:20 2005
  
     Prg:      ssk
  
*********************************************************************21*/
  

/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#if MAP_MSC
#if MAP_VLR
#if MAP_HLR
      -05      MSC, VLR and HLR
#else
#endif
#else
#if MAP_HLR
#else
      -01      MSC
#endif
#endif
#else
#if MAP_VLR
#if MAP_HLR
      -04      VLR and HLR
#else
      -02      VLR
#endif
#else
#if MAP_HLR
      -03      HLR
#else
#endif
#endif
#endif

************************************************************************/
 

/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "lma.h"           /* layer management, MAP */
#include "cm_err.h"        /* common error */
#include "stu.h"           /* tcap layer */
#include "mat.h"           /* map layer */
#ifdef MA_RUG
#include "sht.h"
#endif /* MA_RUG */
#include "cm5.h"
#include "ma.h"            /* map */
#include "ma_mf.h"
#include "ma_err.h"        /* map error */
#ifdef ZJ
#include "cm_ftha.h"       /* Common FTHA */
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#include "cm_tupsf.h"      /* Common TCAP user PSF */
#include "zj.h"            /* Tcap PSF defines */
#include "lzj.h"
#endif /* ZJ */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"
#include "cm_ss7.x"        /* SS7 Common */
#include "stu.x"           /* tcap layer */
#include "lma.x"           /* layer management, TCAP */
#include "mat.x"           /* map  layer */
#ifdef MA_FTHA
#include "sht.x"
#endif /* MA_FTHA */
#ifdef ZJ
#include "cm_ftha.x"       /* Common FTHA */
#include "cm_pftha.x"      /* Common PSF defines */
#include "cm_psfft.x"
#include "cm_tupsf.x"      /* Common TCAP user PSF */
#endif /* ZJ */
#include "ma.x"            /* map */
#ifdef ZJ
#include "zj.x"            /* Tcap PSF defines */
#include "lzj.x"
#endif /* ZJ */

/* Forward reference */
  
#if (MAP_MSC || MAP_HLR || MAP_GSN)
PRIVATE Buffer  *maEncSMErr ARGS((MaSap *s, MaUsrErr *usrErr));
#endif /* MAP_MSC || MAP_HLR || MAP_GSN */
#if (MAP_VLR || MAP_HLR)
PRIVATE Buffer  *maEncSSErr ARGS((MaSap *s, MaUsrErr *usrErr));
#endif

PRIVATE Buffer  *maMkErrMsg ARGS((MaSap *s, U8 tag, U8 errVal));
PRIVATE Void maUpdatTxSts ARGS((MaSap *s, U8 oprType, U8 type));

#ifdef MA_SEG
PRIVATE S16 maRRNLSegment ARGS((MaSap *s,MaDlgCp *dlgCp,
                                StComps *cmpEv, MaCmpCp *cmpCp));
#endif /* MA_SEG */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
/* 
* 
*       Fun:   MaUiMatLocMgmtReq 
*  
*       Desc:  This function handles the request for Location Management 
*              services from the MAP user.
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatLocMgmtReq
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaLocEv    *locEv           /* Location Event Structure */              
)
#else
PUBLIC S16 MaUiMatLocMgmtReq(pst, spId, suDlgId, spDlgId, invkId, oprType, locEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaLocEv    *locEv;          /* Location Event Structure */              
#endif
{
 MaSap    *s;           /* Sap pointer */
 MaDlgCp  *dlgCp;       /* dialogue control point pointer */
 MaCmpCp  *cmpCp;       /* component control point pointer */
 U8       oprClass;        /* operation class */
 U16      tmrVal;       /* invoke timer value */
 StComps  cmpEv;        /* component event structure */ 
 S16      ret;          /* return value */

   TRC3(MaUiMatLocMgmtReq)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (locEv);

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatLocMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
    invkId(%d),oprType(%d),locEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) locEv));

#else
 
   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatLocMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
    invkId(%d),oprType(%d),locEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) locEv));

#endif/*ALIGN_64BIT*/
   maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));

   if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
       ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),locEv(0x%lx))failed, invalid spId(%d)\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) locEv, spId));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),locEv(0x%lx))failed, invalid spId(%d)\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) locEv, spId));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
   }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatLocMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),locEv(0x%lx))failed, invalid SAP state(%d)\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) locEv, s->maState));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),locEv(0x%lx))failed, invalid SAP state(%d)\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) locEv, s->maState));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
   }

   /* Find out the dialogue control point */
    dlgCp = maFindHashDlg(s, spDlgId);
    /* 
     * Addition - added MA_DLG_IDLE and MA_DLG_PENDING state, 
     * operation requests which are meant for responses should be allowed 
     * in these two states 
     */
    if ((dlgCp == NULLP) || 
       ((dlgCp->dsmState != MA_DLG_WAIT_USER_REQ) &&
       (dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTLOCMGMTREQ, MAT_INVALID_DLGID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),locEv(0x%lx))failed, invalid SpDlgId(%ld) ).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) locEv, spDlgId));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),locEv(0x%lx))failed, invalid SpDlgId(%d) ).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) locEv, spDlgId));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
    }

    /* check whether operation is supported */
  
    if ( (ret = maIsOprSupp(s, oprType, &oprClass, &tmrVal, dlgCp->apn.val[dlgCp->apn.len -1])) != ROK)
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTLOCMGMTREQ, MAT_OPR_NOT_SUPP);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),locEv(0x%lx))failed, OprType(%d) not supported.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) locEv, oprType));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),locEv(0x%lx))failed, OprType(%d) not supported.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) locEv, oprType));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/ 
    }

    if( (cmpCp = maFindHashInvk(dlgCp, invkId,TRUE)) != (MaCmpCp *)NULLP)
    {
        /* duplicate invoke id */
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTLOCMGMTREQ, MAT_DUP_INVKID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),locEv(0x%lx))failed, duplicate invoke Id(%d)\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) locEv, invkId->octet));
      RETVALUE(RFAILED);
     
#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),locEv(0x%lx))failed, duplicate invoke Id(%d)\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) locEv, invkId->octet));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
    }

    ret = maEncOpr(s, (U8 *)locEv, oprType, MAT_SS_REQ);
    if (ret != ROK)
    {
       if (s->ctlp.mBuf != NULLP)
       {
         SPutMsg(s->ctlp.mBuf);
       }
       maSndPrvErrCfm(oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTLOCMGMTREQ, MAT_INCORRECT_PARAM);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatLocMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),locEv(0x%lx))failed, encoding operatioin failed.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) locEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatLocMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),locEv(0x%lx))failed, encoding operatioin failed.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) locEv));
       RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
    }
    

    if ( oprClass != MAT_OPRCLASS4)
    {
       /* create a new Component control point */
       if(maCb.maCP.nmbOpr  == maCb.maInvCnt)
       {
         if (s->ctlp.mBuf != NULLP)
         {
           SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTLOCMGMTREQ, MAT_INVOKE_LIMIT_RCHD);
#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatLocMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d),locEv(0x%lx))failed, maximun number of opr reached(%ld).\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) locEv,maCb.maInvCnt));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatLocMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d),locEv(0x%lx))failed, maximun number of opr reached(%d).\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) locEv,maCb.maInvCnt));
         RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
      
       }

       cmpCp = maInsHashInv(s, invkId,TRUE);
       if (cmpCp == (MaCmpCp *)NULLP)
       {
         if (s->ctlp.mBuf != NULLP)
         {
           SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTLOCMGMTREQ, MAT_OUT_OF_RSRS);
#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatLocMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d),locEv(0x%lx))failed, unable to allocate cmpCb,out of resource.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) locEv));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatLocMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d),locEv(0x%lx))failed, unable to allocate cmpCb,out of resource.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) locEv));
         RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
       }


       cmpCp->oprCode = oprType; 
       cmpCp->oprClass = oprClass;
       cmpCp->invkTmr = tmrVal;
       cmpCp->spDlgId = spDlgId;
       cmpCp->sap = s;
 
      /* Start the timer */
      cmpCp->ssmState = MA_SSM_WAITCFM;
#ifdef ZJ
      MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_ADD)
#endif
    }
  
#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_REQ);
#endif

    /* send the invoke request to TCAP */

    cmpEv.stCompType = STU_INVOKE;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stInvokeTimer = tmrVal; 
    cmpEv.stLinkedId.pres = FALSE;
    cmpEv.stOpCode.string[0] = oprType;
    cmpEv.stOpCode.len = 1;
    cmpEv.stOpCodeFlg = STU_LOCAL;
    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
   if (s->trc == TRUE)
   {
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);
   }
   
#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprReq(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          maSndPrvErrCfm(oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTLOCMGMTREQ, MAT_MESS_PROT_FAILED);
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_REQ);
    }

#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
#ifdef ZJ
    if ( oprClass != MAT_OPRCLASS4)
    {
       MA_UPD_PEER(dlgCp->upd)
    }
#endif /* ZJ */
    RETVALUE(ROK);
} /* end of MaUiMatLocMgmtReq */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */ 

#if (MAP_VLR || MAP_HLR || MAP_GSN)
/* 
* 
*       Fun:  MaUiMatLocMgmtRsp 
*  
*       Desc:  This function handles the  Response for Location Management 
*              services from the MAP user.
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatLocMgmtRsp
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaLocEv    *locEv           /* Location Event Structure */              
)
#else
PUBLIC S16 MaUiMatLocMgmtRsp(pst, spId, suDlgId, spDlgId, invkId, oprType, usrErr, locEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaUsrErr  *usrErr;          /* User Error */
MaLocEv    *locEv;          /* Location Event Structure */              
#endif
{
  MaSap    *s;          /* Sap pointer */
  MaDlgCp  *dlgCp;      /* dialogue control point pointer */
  MaCmpCp  *cmpCp;      /* component control point pointer */
  U8       oprClass;       /* operation class */
  StComps  cmpEv;       /* component event structure */ 
  StStr    errStr;      /* Error string */
  U8       maVer;       /* Map Version */
  Buffer   *mBuf;       /* Message Buffer */
  S16      ret;         /* return value */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
  MsgLen   len;

  TRC3(MaUiMatLocMgmtRsp)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (usrErr);
   MA_CHK_FOR_NULLP (locEv);

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
    invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv));

#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
    invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv));

#endif/*ALIGN_64BIT*/
  mBuf = (Buffer *)NULLP;
  maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
  if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
     ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
     
#ifndef ALIGN_64BIT
   
     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv, spId));
     

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv, spId));

#endif/*ALIGN_64BIT*/
     RETVALUE(RFAILED);
  }

  

  if (s->maState != MA_BND_ENABLED)
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatLocMgmtRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv, s->maState));
     RETVALUE(RFAILED);
 
#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv, s->maState));
     RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
  }

  

  /* Find out the dialogue control point */
  dlgCp = maFindHashDlg(s, spDlgId);
  if ((dlgCp == NULLP) || ((dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
  {
    MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTLOCMGMTRSP,
                   (Status)MAT_BAD_SPDLGID);
#ifndef ALIGN_64BIT

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), invkId(%d),\
    oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed,invalid spDlgId.\n", \
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv));
    RETVALUE(RFAILED);

#else

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), invkId(%d),\
    oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed,invalid spDlgId.\n", \
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv));
    RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
  }
 
  if( (((cmpCp = maFindHashInvk(dlgCp, invkId,FALSE)) == (MaCmpCp *)NULLP)) || 
      (cmpCp->ssmState != MA_SSM_WAITRSP))
  {
      /* invalid  invoke id */
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTLOCMGMTRSP,
                     (Status)MAT_BAD_INVKID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv, invkId->octet));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
  }
  
  oprClass = cmpCp->oprClass;
  /* update the version number */
  maVer = dlgCp->apn.val[dlgCp->apn.len -1];

  if (usrErr->pres == TRUE)
  {
    if (cmpCp->oprClass == MAT_OPRCLASS3)
    {
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       RETVALUE(ROK);
    }


    /* check if it is service specific error */
    if (usrErr->usrSpecErr.pres == FALSE)
    {
      ret = maChkErr(s,oprType, usrErr->errCode, maVer);

      if (ret != ROK)
      {
        MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTLOCMGMTRSP,
                       (Status)MAT_BAD_USRERR_PARAM);
        maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
#ifdef ZJ
        MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
        MA_UPD_PEER(dlgCp->upd)
#endif
        /* remove the component control point */
        maRemHashInv(dlgCp, invkId,FALSE);
        
#ifndef ALIGN_64BIT 

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
        invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, invalid user error.\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv));
        RETVALUE(RFAILED);

#else

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
        invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, invalid user error.\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv));
        RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/ 
      

      }

      /* Send a TCAP Error */

      errStr.len =1;
      errStr.string[0] = usrErr->errCode;

      if (maVer < LMA_VER2P)
      {
         /* For MAP version 1 & 2, continue coding the error the old way */ 

         switch (usrErr->errCode)
         {
            case MAT_SYS_FAILURE:
            case MAT_ROAM_NOTALLOWED:
               if (usrErr->val != MAT_INV_USR_ERRVAL)
               {
                  if ((mBuf = maMkErrMsg(s, MA_TAG_ENUM, usrErr->val)) 
                                                         == (Buffer *)NULLP)
                  {
#ifndef ALIGN_64BIT

                       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                     "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
                     invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, unable to make error msg.\n",
                     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv));
                     RETVALUE(RFAILED);

#else

                     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                     "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
                     invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, unable to make error msg.\n",
                     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv));
                     RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
                 
               
                  }
               }
               break;
            default:
               break;

         } /* end switch */

      }
      else
      {
         /* MAP version 2+, code the return error by using the database */

         if (maEncVer2PErrParam(s, usrErr, MAT_SS_RETERR, maVer) != ROK)
         {
#ifndef ALIGN_64BIT

             MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
            invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, fail to encode version 2P error.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv));
            RETVALUE(RFAILED);

#else

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
            invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, fail to encode version 2P error.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv));
            RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
         
   
         }
   
         /* get the encoded message buffer */
         mBuf = s->ctlp.mBuf;

      }

      /* send TCAP return error component */
      maSndTcErr(s,invkId, &errStr, cmpCp, mBuf);
    }
    else
    {
      /* Send the TC U - Reject */
       cmpEv.stInvokeId.pres = TRUE;
       cmpEv.stInvokeId.octet = invkId->octet;
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.opClass = cmpCp->oprClass;
       if (usrErr->usrSpecErr.val == MAT_USR_INIT_RLS)
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_INIT_RELEASE);
       }
       else
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_RESOURCE_LIMIT);
       }
    }
  }
  else
  {
     ret = maEncOpr(s, (U8 *)locEv, oprType, MAT_SS_RSP);
     if (ret != ROK)
     {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTLOCMGMTRSP,
                      (Status)MAT_BAD_RSP_PARAM);
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       if (s->ctlp.mBuf != NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, fail to encode operation.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, fail to encode operation.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv));
       RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
     
     }

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_RSP);
#endif

    /* send the return result to TCAP */
    cmpEv.stCompType = STU_RET_RES_L;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stLinkedId.pres = FALSE;

    /*
    ** If the message does not have any parameters then
    ** the operation code must not be filled.
    */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
    if((s->ctlp.mBuf != NULLP)  && (SFndLenMsg(s->ctlp.mBuf,&len) != ROK))
    {
       /*
       ** If the SFndLenMsg fails then free the mBuf and return
       */
       if (s->ctlp.mBuf != NULLP)
       {
          (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, incorrectly fill opr code when no msg param in msg.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, incorrectly fill opr code when no msg param in msg.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) locEv));
       RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
    }

    
    if(s->ctlp.mBuf != NULLP && len > 0)
    {
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.stOpCodeFlg = STU_LOCAL;
    }
    else
    {
       cmpEv.stOpCode.len = 0;
    }


    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
#ifdef MA_SEG 
    cmpEv.stOpCode.string[0] = oprType;
    ret = maRRNLSegment(s,dlgCp,&cmpEv, cmpCp);
    if (ret != ROK)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
			/* ma001.203: Modification. Error code has been changed.*/
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, 
                      MAT_EVTLOCMGMTRSP,(Status)MAT_BAD_RSP_SEG_PARAM);
       /* remove the component control point */
       (Void)maInvkIdle(dlgCp, cmpCp);
       if (s->ctlp.mBuf != (Buffer *) NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed: \
       Invalid segmentation attempt\n", spId, suDlgId, spDlgId, 
       invkId->octet, oprType,(PTR)usrErr,(PTR) locEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatLocMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed: \
       Invalid segmentation attempt\n", spId, suDlgId, spDlgId, 
       invkId->octet, oprType,(PTR)usrErr,(PTR) locEv));
       RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
    }
#endif /* MA_SEG */
   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprRsp(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_RSP);
    }
#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
  }

#ifdef ZJ
  MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
  MA_UPD_PEER(dlgCp->upd)
#endif
  maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
  /* remove the component control point */
  maRemHashInv(dlgCp, invkId,FALSE);
  RETVALUE(ROK);
} /* end of MaUiMatLocMgmtRsp */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if MAP_MSC

/* 
* 
*       Fun:   upper interface - Handover Management Request
*  
*       Desc:  This function handles the  request for Handover 
*              services from the MAP user.
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatHOMgmtReq
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaHoEv     *hoEv            /* Handover Event Structure */              
)
#else
PUBLIC S16 MaUiMatHOMgmtReq(pst, spId, suDlgId, spDlgId, invkId, oprType, hoEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaHoEv *hoEv;               /* Handover Event Structure */              
#endif
{
 MaSap    *s;           /* Sap pointer */
 MaDlgCp  *dlgCp;       /* dialogue control point pointer */
 MaCmpCp  *cmpCp;       /* component control point pointer */
 U8       oprClass;        /* operation class */
 U16      tmrVal;       /* invoke timer value */
 StComps  cmpEv;        /* component event structure */ 
 S16      ret;          /* return value */

   TRC3(MaUiMatHOMgmtReq)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (hoEv);

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatHOMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
    invkId(%d),oprType(%d),hoEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) hoEv));
   maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));

#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatHOMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
    invkId(%d),oprType(%d),hoEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) hoEv));
   maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));

#endif/*ALIGN_64BIT*/
   if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
       ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatHOMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),hoEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) hoEv, spId));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatHOMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),hoEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) hoEv, spId));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
   }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatHOMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatHOMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),hoEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) hoEv, s->maState));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatHOMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),hoEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) hoEv, s->maState));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
   }

   /* Find out the dialogue control point */
    dlgCp = maFindHashDlg(s, spDlgId);

   /* 
    * Addition - added MA_DLG_IDLE and MA_DLG_PENDING state, 
    * operation requests which are meant for responses should be allowed 
    * in these two states 
    */
   if ((dlgCp == NULLP) || 
       ((dlgCp->dsmState != MA_DLG_WAIT_USER_REQ) &&
       (dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
   {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTHOMGMTREQ, MAT_INVALID_DLGID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatHOMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),hoEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) hoEv));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatHOMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),hoEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) hoEv));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
   }


    /* check whether operation is supported */
  
    if ( (ret = maIsOprSupp(s, oprType, &oprClass, &tmrVal, dlgCp->apn.val[dlgCp->apn.len -1])) != ROK)
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTHOMGMTREQ, MAT_OPR_NOT_SUPP);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatHOMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),hoEv(0x%lx))failed, oprType not supported(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) hoEv, oprType));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatHOMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),hoEv(0x%lx))failed, oprType not supported(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) hoEv, oprType));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
    }

    if( (cmpCp = maFindHashInvk(dlgCp, invkId,TRUE)) != (MaCmpCp *)NULLP)
    {
        /* duplicate invoke id */
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTHOMGMTREQ, MAT_DUP_INVKID);
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatHOMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),hoEv(0x%lx))failed, duplicate invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) hoEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatHOMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),hoEv(0x%lx))failed, duplicate invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) hoEv, invkId->octet));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
    }
    

    ret = maEncOpr(s, (U8 *)hoEv, oprType, MAT_SS_REQ);
    if (ret != ROK)
    {
      if (s->ctlp.mBuf != NULLP)
      {
         SPutMsg(s->ctlp.mBuf);
      }
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTHOMGMTREQ, MAT_INCORRECT_PARAM);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatHOMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),hoEv(0x%lx))failed, encoding opr failed.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) hoEv));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatHOMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),hoEv(0x%lx))failed, encoding opr failed.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) hoEv));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
    }

    if ( oprClass != MAT_OPRCLASS4)
    {
    /* create a new Component control point */
       if(maCb.maCP.nmbOpr  == maCb.maInvCnt)
       {
         if (s->ctlp.mBuf != NULLP)
         {
           SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTHOMGMTREQ, MAT_INVOKE_LIMIT_RCHD);
#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatHOMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d),hoEv(0x%lx))failed, maximun number of invoke reached(%ld).\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) hoEv, maCb.maInvCnt));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatHOMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d),hoEv(0x%lx))failed, maximun number of invoke reached(%d).\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) hoEv, maCb.maInvCnt));
         RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
       }
       

      cmpCp = maInsHashInv(s, invkId,TRUE);
      if (cmpCp == (MaCmpCp *)NULLP)
      {
        if (s->ctlp.mBuf != NULLP)
        {
           SPutMsg(s->ctlp.mBuf);
        }
        maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                        MAT_EVTHOMGMTREQ, MAT_OUT_OF_RSRS);
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatHOMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
        invkId(%d),oprType(%d),hoEv(0x%lx))failed, unable to allocate cmpCp.\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) hoEv));
        RETVALUE(RFAILED);

#else

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatHOMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
        invkId(%d),oprType(%d),hoEv(0x%lx))failed, unable to allocate cmpCp.\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) hoEv));
        RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
      }

      cmpCp->oprCode = oprType; 
      cmpCp->oprClass = oprClass;
      cmpCp->invkTmr = tmrVal;
      cmpCp->spDlgId = spDlgId;
      cmpCp->sap = s;
 
      /* Start the timer */
      cmpCp->ssmState = MA_SSM_WAITCFM;
#ifdef ZJ
      MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_ADD)
#endif
    }

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_REQ);
#endif

    /* send the invoke request to TCAP */

    cmpEv.stCompType = STU_INVOKE;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stInvokeTimer = tmrVal; 
    cmpEv.stLinkedId.pres = FALSE;
    cmpEv.stOpCode.string[0] = oprType;
    cmpEv.stOpCode.len = 1;
    cmpEv.stOpCodeFlg = STU_LOCAL;
    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprReq(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          maSndPrvErrCfm(oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTHOMGMTREQ, MAT_MESS_PROT_FAILED);
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_REQ);
    }

#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
#ifdef ZJ
    if ( oprClass != MAT_OPRCLASS4)
    {
       MA_UPD_PEER(dlgCp->upd)
    }
#endif /* ZJ */
    RETVALUE(ROK);
} /* end of MaUiMatHOMgmtReq */


/* 
* 
*       Fun:   upper interface - Handover Management Response
*  
*       Desc:  This function handles the Response for Handover 
*              services from the MAP user 
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatHOMgmtRsp
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaHoEv     *hoEv            /* Handover Event Structure */              
)
#else
PUBLIC S16 MaUiMatHOMgmtRsp(pst, spId, suDlgId, spDlgId, invkId, oprType, usrErr, hoEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaUsrErr  *usrErr;          /* User Error */
MaHoEv     *hoEv;           /* Handover Event Structure */              
#endif
{
  MaSap    *s;          /* Sap pointer */
  MaDlgCp  *dlgCp;      /* dialogue control point pointer */
  MaCmpCp  *cmpCp;      /* component control point pointer */
  U8       oprClass;       /* operation class */
  StComps  cmpEv;       /* component event structure */ 
  StStr    errStr;      /* Error string */
  U8       maVer;       /* Map Version */
  Buffer   *mBuf;       /* Message Buffer */
  S16      ret;         /* return value */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
  MsgLen   len;		/* Message length */

  TRC3(MaUiMatHOMgmtRsp)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (usrErr);
   MA_CHK_FOR_NULLP (hoEv);

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
   invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv));


#else

  MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
   invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv));

#endif/*ALIGN_64BIT*/
  mBuf = (Buffer *)NULLP;
  maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));

  if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
     ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv, spId));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv, spId));
     RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
  }

  

  if (s->maState != MA_BND_ENABLED)
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatHoMgmtRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv, s->maState));
     RETVALUE(RFAILED);

#else
 
     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv, s->maState));
     RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
  }

  

  /* Find out the dialogue control point */
  dlgCp = maFindHashDlg(s, spDlgId);
  if ((dlgCp == NULLP) || ((dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
  {
    MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTHOMGMTRSP,
                   (Status)MAT_BAD_SPDLGID);
#ifndef ALIGN_64BIT

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), invkId(%d),\
    oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv));
    RETVALUE(RFAILED);

#else

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), invkId(%d),\
    oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv));
    RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
  }
 
  if( (((cmpCp = maFindHashInvk(dlgCp, invkId,FALSE)) == (MaCmpCp *)NULLP)) ||
      (cmpCp->ssmState != MA_SSM_WAITRSP))
  {
      /* invalid  invoke id */
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTHOMGMTRSP,
                     (Status)MAT_BAD_INVKID);

#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv, invkId->octet));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
  }
  oprClass = cmpCp->oprClass;

  /* Update the Map Version */
  maVer = dlgCp->apn.val[dlgCp->apn.len -1];

  if (usrErr->pres == TRUE)
  {
    if (cmpCp->oprClass == MAT_OPRCLASS3)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       RETVALUE(ROK);
    }


    /* check if it is service specific error */
    if (usrErr->usrSpecErr.pres == FALSE)
    {
      ret = maChkErr(s,oprType, usrErr->errCode, maVer);
      if (ret != ROK)
      {
#ifdef ZJ
        MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
        MA_UPD_PEER(dlgCp->upd)
#endif
        MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTHOMGMTRSP,
                       (Status)MAT_BAD_USRERR_PARAM);
        maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
        /* remove the component control point */
        maRemHashInv(dlgCp, invkId,FALSE);
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
        invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, invalid user error.\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv));
        RETVALUE(RFAILED);

#else

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
        invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, invalid user error.\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv));
        RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
      }

      /* send the TC U Error */
      errStr.len =1;
      errStr.string[0] = usrErr->errCode;

      if (maVer < LMA_VER2P)
      {
         /* For MAP version 1 & 2, continue coding the error the old way */ 

         switch (usrErr->errCode)
         {
            case MAT_SYS_FAILURE:
              if (usrErr->val != MAT_INV_USR_ERRVAL)
              {
                 if ((mBuf = maMkErrMsg(s, MA_TAG_ENUM, usrErr->val)) 
                                                       == (Buffer *)NULLP)
                 {
#ifndef ALIGN_64BIT

                    

                  MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
                   invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, unable to make error msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv));
                   RETVALUE(RFAILED);

#else

                   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
                   invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, unable to make error msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv));
                   RETVALUE(RFAILED);
#endif 
                 }
              }
              break;
            default:
              break;
         }
      }
      else
      {
         /* MAP version 2+, code the return error by using the database */

         if (maEncVer2PErrParam(s, usrErr, MAT_SS_RETERR, maVer) != ROK)
         {
#ifndef ALIGN_64BIT

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
            invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, fail to encode version 2P error.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv));
            RETVALUE(RFAILED);

#else
            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
            invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, fail to encode version 2P error.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv));
            RETVALUE(RFAILED);
#endif/*ALIGN_64BIT*/

         }
   
         /* get the encoded message buffer */
         mBuf = s->ctlp.mBuf;
      }

      maSndTcErr(s,invkId, &errStr, cmpCp, mBuf);
    }
    else
    {
      /* Send the TC U - Reject */
       cmpEv.stInvokeId.pres = TRUE;
       cmpEv.stInvokeId.octet = invkId->octet;
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.opClass = cmpCp->oprClass;
       if (usrErr->usrSpecErr.val == MAT_USR_INIT_RLS)
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_INIT_RELEASE);
       }
       else
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_RESOURCE_LIMIT);
       }
    }
  }
  else
  {
     ret = maEncOpr(s, (U8 *)hoEv, oprType, MAT_SS_RSP);
     if (ret != ROK)
     {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTHOMGMTRSP,
                      (Status)MAT_BAD_RSP_PARAM);
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       if (s->ctlp.mBuf != NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, encoding opr(%d)failed.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv, oprType));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, encoding opr(%d)failed.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv, oprType));
       RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/

     }

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_RSP);
#endif

    /* send the return result to TCAP */
    cmpEv.stCompType = STU_RET_RES_L;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stLinkedId.pres = FALSE;

    /*
    ** If the message does not have any parameters then
    ** the operation code must not be filled.
    */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
    if((s->ctlp.mBuf != NULLP)  && (SFndLenMsg(s->ctlp.mBuf,&len) != ROK))
    {
       /*
       ** If the SFndLenMsg fails then free the mBuf and return
       */
       if (s->ctlp.mBuf != NULLP)
       {
          (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, incorrectly \
       fill opr code while there is no param in msg.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),locEv(0x%lx))failed, incorrectly \
       fill opr code while there is no param in msg.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) hoEv));
       RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/ 
    }
    if(s->ctlp.mBuf != NULLP && len > 0)
    {
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.stOpCodeFlg = STU_LOCAL;
    }
    else
    {
       cmpEv.stOpCode.len = 0;
    }

    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
#ifdef MA_SEG
    cmpEv.stOpCode.string[0] = oprType;
    ret = maRRNLSegment(s,dlgCp,&cmpEv, cmpCp);
    if (ret != ROK)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
			/* ma001.203: Modification. Error code has been changed.*/
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, 
                 MAT_EVTHOMGMTRSP,(Status)MAT_BAD_RSP_SEG_PARAM);
       /* remove the component control point */
       (Void)maInvkIdle(dlgCp, cmpCp);
       if (s->ctlp.mBuf != (Buffer *)NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),hoEv(0x%lx))failed:\
       Invalid segmentation attempt.\n", spId, suDlgId, spDlgId, 
       invkId->octet,oprType,(PTR)usrErr,(PTR) hoEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatHOMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),hoEv(0x%lx))failed:\
       Invalid segmentation attempt.\n", spId, suDlgId, spDlgId, 
       invkId->octet,oprType,(PTR)usrErr,(PTR) hoEv));
       RETVALUE(RFAILED);
  
#endif/*ALIGN_64BIT*/
    }
#endif /* MA_SEG */
   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprRsp(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_RSP);
    }
#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
  }

#ifdef ZJ
  MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
  MA_UPD_PEER(dlgCp->upd)
#endif
  maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
  /* remove the component control point */
  maRemHashInv(dlgCp, invkId,FALSE);
  RETVALUE(ROK);
} /* end of MaUiMatHOMgmtRsp */

#endif /* MAP_MSC */

#ifdef XWEXT /* xingzhou.xu: xinwei management definition 2006/10/16 */
/*-------------------------------------*/
/*   XINWEI Management Interface       */
/*-------------------------------------*/
/* 
* 
*       Fun:   upper interface - XINWEI Management Request
*  
*       Desc:  This function handles the  request for XINWEI 
*              services from the MAP user.
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatXWMgmtReq
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaXWDetectEv *detectEv      /* Authintication Event Structure */                
)
#else
PUBLIC S16 MaUiMatXWMgmtReq(pst, spId, suDlgId, spDlgId, invkId, oprType, detectEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaXWDetectEv    *detectEv;  /* Authintication Event Structure */                
#endif
{
 MaSap    *s;           /* Sap pointer */
 MaDlgCp  *dlgCp;       /* dialogue control point pointer */
 MaCmpCp  *cmpCp;       /* component control point pointer */
 U8       oprClass;        /* operation class */
 U16      tmrVal;       /* invoke timer value */
 StComps  cmpEv;        /* component event structure */ 
 S16      ret;          /* return value */

   TRC3(MaUiMatXWMgmtReq)

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Entered MaUiMatXWMgmtReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif
   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (detectEv);

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatXWMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
    invkId(%d),oprType(%d),authEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) detectEv));

#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatXWMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
    invkId(%d),oprType(%d),authEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) detectEv));

#endif/*ALIGN_64BIT*/
   maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
   if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
       ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatXWMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatXWMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) detectEv, spId));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatXWMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) detectEv, spId));
      RETVALUE(RFAILED);
       
#endif/*ALIGN_64BIT*/
   }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatXWMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatXWMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) detectEv, s->maState));
      RETVALUE(RFAILED);

#else
  
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatXWMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) detectEv, s->maState));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/  
   
   }

   /* Find out the dialogue control point */
    dlgCp = maFindHashDlg(s, spDlgId);

   /* 
    * Addition - added MA_DLG_IDLE and MA_DLG_PENDING state, 
    * operation requests which are meant for responses should be allowed 
    * in these two states 
    */
   if ((dlgCp == NULLP) || 
       ((dlgCp->dsmState != MA_DLG_WAIT_USER_REQ) &&
       (dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTDETCTREQ, MAT_INVALID_DLGID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatXWMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) detectEv));
      RETVALUE(RFAILED);

#else
 
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatXWMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) detectEv));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
    }

    /* check whether operation is supported */
  
    if ( (ret = maIsOprSupp(s, oprType, &oprClass, &tmrVal, dlgCp->apn.val[dlgCp->apn.len -1])) != ROK)
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTDETCTREQ, MAT_OPR_NOT_SUPP);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatXWMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, oprType not supported(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) detectEv, oprType));
      RETVALUE(RFAILED);

#else
 
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatXWMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, oprType not supported(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) detectEv, oprType));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
    
    }

    if( (cmpCp = maFindHashInvk(dlgCp, invkId,TRUE)) != (MaCmpCp *)NULLP)
    {
        /* duplicate invoke id */
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTDETCTREQ, MAT_DUP_INVKID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatXWMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) detectEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatXWMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) detectEv, invkId->octet));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
    
    }

    ret = maEncOpr(s, (U8 *)detectEv, oprType, MAT_SS_REQ);
    if (ret != ROK)
    {
      if (s->ctlp.mBuf != NULLP)
      {
         SPutMsg(s->ctlp.mBuf);
      }
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTDETCTREQ, MAT_INCORRECT_PARAM);
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatXWMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, encoding operation failed.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) detectEv));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatXWMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, encoding operation failed.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) detectEv));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
    
    }

    if ( oprClass != MAT_OPRCLASS4)
    {
       /* create a new Component control point */
       if(maCb.maCP.nmbOpr  == maCb.maInvCnt)
       {
         if (s->ctlp.mBuf != NULLP)
         {
           SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTDETCTREQ, MAT_INVOKE_LIMIT_RCHD);
#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatXWMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d),authEv(0x%lx))failed, maximum number of invoke reached.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) detectEv));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatXWMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d),authEv(0x%lx))failed, maximum number of invoke reached.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) detectEv));
         RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
       
       }

       cmpCp = maInsHashInv(s, invkId,TRUE);
       if (cmpCp == (MaCmpCp *)NULLP)
       {
          
         if (s->ctlp.mBuf != NULLP)
         {
            SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTDETCTREQ, MAT_OUT_OF_RSRS);
#ifndef ALIGN_64BIT

          MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatXWMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d),authEv(0x%lx))failed, unable to allocate cmpCp.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) detectEv));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatXWMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d),authEv(0x%lx))failed, unable to allocate cmpCp.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) detectEv));
         RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
       
       }

       cmpCp->oprCode = oprType; 
       cmpCp->oprClass = oprClass;
       cmpCp->invkTmr = tmrVal;
       cmpCp->spDlgId = spDlgId;
       cmpCp->sap = s;
 
      /* Start the timer */
      cmpCp->ssmState = MA_SSM_WAITCFM;
#ifdef ZJ
      MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_ADD)
#endif
    }

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_REQ);
#endif

    /* send the invoke request to TCAP */

    cmpEv.stCompType = STU_INVOKE;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stInvokeTimer = tmrVal; 
    cmpEv.stLinkedId.pres = FALSE;
    cmpEv.stOpCode.string[0] = oprType;
    cmpEv.stOpCode.len = 1;
    cmpEv.stOpCodeFlg = STU_LOCAL;
    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprReq(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTDETCTREQ, MAT_MESS_PROT_FAILED);
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_REQ);
    }

#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
#ifdef ZJ
    if ( oprClass != MAT_OPRCLASS4)
    {
       MA_UPD_PEER(dlgCp->upd)
    }
#endif /* ZJ */

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Leaving MaUiMatXWMgmtReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif
    RETVALUE(ROK);
} /* end of MaUiMatXWMgmtReq */

/* 
* 
*       Fun:   upper interface - XINWEI Management Response
*  
*       Desc:  This function handles the Response for XINWEI 
*              services from the MAP user 
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatXWMgmtRsp
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaXWDetectEv *detectEv      /* Authintication Event Structure */                
)
#else
PUBLIC S16 MaUiMatXWMgmtRsp(pst, spId, suDlgId, spDlgId, invkId, oprType, usrErr, detectEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaUsrErr  *usrErr;          /* User Error */
MaXWDetectEv *detectEv;     /* Authintication Event Structure */                
#endif
{
  MaSap    *s;          /* Sap pointer */
  MaDlgCp  *dlgCp;      /* dialogue control point pointer */
  MaCmpCp  *cmpCp;      /* component control point pointer */
  U8       oprClass;       /* operation class */
  StComps  cmpEv;       /* component event structure */ 
  StStr    errStr;      /* Error string */
  U8       maVer;       /* Map Version */
  Buffer   *mBuf;       /* Message Buffer */
  S16      ret;         /* return value */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
  MsgLen   len;		/* Message length */

  TRC3(MaUiMatXWMgmtRsp)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (usrErr);
   MA_CHK_FOR_NULLP (detectEv);

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
   invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv));

#else

  MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
   invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv));

#endif/*ALIGN_64BIT*/
  mBuf = (Buffer *)NULLP;
  maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
  if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
     ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatXWMgmtRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv, spId));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv, spId));
     RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
  

  }

  if (s->maState != MA_BND_ENABLED)
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatXWMgmtRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv, s->maState));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv, s->maState));
     RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
  

  }

  /* Find out the dialogue control point */
  dlgCp = maFindHashDlg(s, spDlgId);
  if ((dlgCp == NULLP) || ((dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
  {
    MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTDETCTRSP,
                   (Status)MAT_BAD_SPDLGID);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), invkId(%d),\
    oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv));
    RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), invkId(%d),\
    oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv));
    RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
      
  }
 
  if( (((cmpCp = maFindHashInvk(dlgCp, invkId,FALSE)) == (MaCmpCp *)NULLP)) ||
      (cmpCp->ssmState != MA_SSM_WAITRSP))
  {
      /* invalid  invoke id */
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTDETCTRSP,
                     (Status)MAT_BAD_INVKID);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv, invkId->octet));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
  }
  oprClass = cmpCp->oprClass;

  maVer = dlgCp->apn.val[dlgCp->apn.len -1];

  if (usrErr->pres == TRUE)
  {
    if (cmpCp->oprClass == MAT_OPRCLASS3)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       RETVALUE(ROK);
    }


    /* check if it is service specific error */
    if (usrErr->usrSpecErr.pres == FALSE)
    {
      ret = maChkErr(s,oprType, usrErr->errCode, maVer);
      if (ret != ROK)
      {
#ifdef ZJ
        MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
        MA_UPD_PEER(dlgCp->upd)
#endif
        MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTDETCTRSP,
                       (Status)MAT_BAD_USRERR_PARAM);
        maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
        /* remove the component control point */
        maRemHashInv(dlgCp, invkId,FALSE);
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
        invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid user error.\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv));
        RETVALUE(RFAILED);

#else

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
        invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid user error.\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv));
        RETVALUE(RFAILED);
 
#endif/*ALIGN_64BIT*/
      }

      

      /* send the TC U Error */
      errStr.len =1;
      errStr.string[0] = usrErr->errCode;

      if (maVer < LMA_VER2P)
      {
         /* For MAP version 1 & 2, continue coding the error the old way */ 

         switch (usrErr->errCode)
         {
            case MAT_SYS_FAILURE:

              if (usrErr->val != MAT_INV_USR_ERRVAL)
              {
                 if ((mBuf = maMkErrMsg(s, MA_TAG_ENUM, usrErr->val)) == 
                                                               (Buffer *)NULLP)
                 {
#ifndef ALIGN_64BIT

                   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
                   invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, failed to make error msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv));
                   RETVALUE(RFAILED);

#else

                   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
                   invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, failed to make error msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv));
                   RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
                  }
               }
              break;

            default:
              break;

          } /* end switch */
      }
      else
      {
         /* MAP version 2+, code the return error by using the database */

         if (maEncVer2PErrParam(s, usrErr, MAT_SS_RETERR, maVer) != ROK)
         {
#ifndef ALIGN_64BIT

             MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
            invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, failed to encode Version 2P error.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv));
            RETVALUE(RFAILED);

#else

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
            invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, failed to encode Version 2P error.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv));
            RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
         
   
         }
   
         /* get the encoded message buffer */
         mBuf = s->ctlp.mBuf;

      }

      (Void) maSndTcErr(s,invkId, &errStr, cmpCp, mBuf);

    }
    else
    {
      /* Send the TC U - Reject */
       cmpEv.stInvokeId.pres = TRUE;
       cmpEv.stInvokeId.octet = invkId->octet;
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.opClass = cmpCp->oprClass;
       if (usrErr->usrSpecErr.val == MAT_USR_INIT_RLS)
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_INIT_RELEASE);
       }
       else
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_RESOURCE_LIMIT);
       }
    }
}
  else
  {
     ret = maEncOpr(s, (U8 *)detectEv, oprType, MAT_SS_RSP);
     if (ret != ROK)
     {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTDETCTRSP,
                      (Status)MAT_BAD_RSP_PARAM);
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       if (s->ctlp.mBuf != NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT
       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, failed to make error msg.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv));
#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, failed to make error msg.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv));
#endif
       RETVALUE(RFAILED);
     }
#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_RSP);
#endif

    /* send the return result to TCAP */
    cmpEv.stCompType = STU_RET_RES_L;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stLinkedId.pres = FALSE;

    /*
    ** If the message does not have any parameters then
    ** the operation code must not be filled.
    */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
    if((s->ctlp.mBuf != NULLP)  && (SFndLenMsg(s->ctlp.mBuf,&len) != ROK))
    {
       /*
       ** If the SFndLenMsg fails then free the mBuf and return
       */
       if (s->ctlp.mBuf != NULLP)
       {
          (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, incorrectly fill the opration code.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, incorrectly fill the opration code.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)detectEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
    
    if(s->ctlp.mBuf != NULLP && len > 0)
    {
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.stOpCodeFlg = STU_LOCAL;
    }
    else
    {
       cmpEv.stOpCode.len = 0;
    }

    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
#ifdef MA_SEG 
    cmpEv.stOpCode.string[0] = oprType;
    ret = maRRNLSegment(s,dlgCp,&cmpEv, cmpCp);
    if (ret != ROK)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
			/* ma001.203: Modification. Error code has been changed.*/
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, 
               MAT_EVTDETCTRSP,(Status)MAT_BAD_RSP_SEG_PARAM);
       /* remove the component control point */
       (Void)maInvkIdle(dlgCp, cmpCp);
       if (s->ctlp.mBuf != (Buffer *)NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed: \
       Invalid segmentation attempt.\n", spId, suDlgId, spDlgId, invkId->octet, 
       oprType,(PTR)usrErr,(PTR)detectEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatXWMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed: \
       Invalid segmentation attempt.\n", spId, suDlgId, spDlgId, invkId->octet, 
       oprType,(PTR)usrErr,(PTR)detectEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
#endif /* MA_SEG */
   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprRsp(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_RSP);
    }
#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
  }

#ifdef ZJ
  MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
  MA_UPD_PEER(dlgCp->upd)
#endif
  maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
  /* remove the component control point */
  maRemHashInv(dlgCp, invkId,FALSE);
  RETVALUE(ROK);
} /* end of MaUiMatXWMgmtRsp */

#endif /* XWEXT */
#if (MAP_VLR || MAP_GSN)
/* 
* 
*       Fun:   upper interface - Authintication Management Request
*  
*       Desc:  This function handles the  request for Authintication 
*              services from the MAP user.
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatAuthMgmtReq
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaAuthEv    *authEv         /* Authintication Event Structure */                
)
#else
PUBLIC S16 MaUiMatAuthMgmtReq(pst, spId, suDlgId, spDlgId, invkId, oprType, authEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaAuthEv    *authEv;        /* Authintication Event Structure */                
#endif
{
 MaSap    *s;           /* Sap pointer */
 MaDlgCp  *dlgCp;       /* dialogue control point pointer */
 MaCmpCp  *cmpCp;       /* component control point pointer */
 U8       oprClass;        /* operation class */
 U16      tmrVal;       /* invoke timer value */
 StComps  cmpEv;        /* component event structure */ 
 S16      ret;          /* return value */

   TRC3(MaUiMatAuthMgmtReq)

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Entered MaUiMatAuthMgmtReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif
   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (authEv);

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatAuthMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
    invkId(%d),oprType(%d),authEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) authEv));

#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatAuthMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
    invkId(%d),oprType(%d),authEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) authEv));

#endif/*ALIGN_64BIT*/
   maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
   if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
       ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAuthMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) authEv, spId));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAuthMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) authEv, spId));
      RETVALUE(RFAILED);
       
#endif/*ALIGN_64BIT*/
   }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatAuthMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAuthMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) authEv, s->maState));
      RETVALUE(RFAILED);

#else
  
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAuthMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) authEv, s->maState));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/  
   
   }

   /* Find out the dialogue control point */
    dlgCp = maFindHashDlg(s, spDlgId);

   /* 
    * Addition - added MA_DLG_IDLE and MA_DLG_PENDING state, 
    * operation requests which are meant for responses should be allowed 
    * in these two states 
    */
   if ((dlgCp == NULLP) || 
       ((dlgCp->dsmState != MA_DLG_WAIT_USER_REQ) &&
       (dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTAUTHMGMTREQ, MAT_INVALID_DLGID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAuthMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) authEv));
      RETVALUE(RFAILED);

#else
 
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAuthMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) authEv));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
    }

    /* check whether operation is supported */
  
    if ( (ret = maIsOprSupp(s, oprType, &oprClass, &tmrVal, dlgCp->apn.val[dlgCp->apn.len -1])) != ROK)
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTAUTHMGMTREQ, MAT_OPR_NOT_SUPP);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAuthMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, oprType not supported(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) authEv, oprType));
      RETVALUE(RFAILED);

#else
 
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAuthMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, oprType not supported(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) authEv, oprType));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
    
    }

    if( (cmpCp = maFindHashInvk(dlgCp, invkId,TRUE)) != (MaCmpCp *)NULLP)
    {
        /* duplicate invoke id */
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTAUTHMGMTREQ, MAT_DUP_INVKID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAuthMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) authEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAuthMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) authEv, invkId->octet));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
    
    }

    ret = maEncOpr(s, (U8 *)authEv, oprType, MAT_SS_REQ);
    if (ret != ROK)
    {
      if (s->ctlp.mBuf != NULLP)
      {
         SPutMsg(s->ctlp.mBuf);
      }
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTAUTHMGMTREQ, MAT_INCORRECT_PARAM);
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAuthMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, encoding operation failed.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) authEv));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAuthMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),authEv(0x%lx))failed, encoding operation failed.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) authEv));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
    
    }

    if ( oprClass != MAT_OPRCLASS4)
    {
       /* create a new Component control point */
       if(maCb.maCP.nmbOpr  == maCb.maInvCnt)
       {
         if (s->ctlp.mBuf != NULLP)
         {
           SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTAUTHMGMTREQ, MAT_INVOKE_LIMIT_RCHD);
#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatAuthMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d),authEv(0x%lx))failed, maximum number of invoke reached.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) authEv));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatAuthMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d),authEv(0x%lx))failed, maximum number of invoke reached.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) authEv));
         RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
       
       }

       cmpCp = maInsHashInv(s, invkId,TRUE);
       if (cmpCp == (MaCmpCp *)NULLP)
       {
          
         if (s->ctlp.mBuf != NULLP)
         {
            SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTAUTHMGMTREQ, MAT_OUT_OF_RSRS);
#ifndef ALIGN_64BIT

          MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatAuthMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d),authEv(0x%lx))failed, unable to allocate cmpCp.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) authEv));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatAuthMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d),authEv(0x%lx))failed, unable to allocate cmpCp.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) authEv));
         RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
       
       }

       cmpCp->oprCode = oprType; 
       cmpCp->oprClass = oprClass;
       cmpCp->invkTmr = tmrVal;
       cmpCp->spDlgId = spDlgId;
       cmpCp->sap = s;
 
      /* Start the timer */
      cmpCp->ssmState = MA_SSM_WAITCFM;
#ifdef ZJ
      MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_ADD)
#endif
    }

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_REQ);
#endif

    /* send the invoke request to TCAP */

    cmpEv.stCompType = STU_INVOKE;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stInvokeTimer = tmrVal; 
    cmpEv.stLinkedId.pres = FALSE;
    cmpEv.stOpCode.string[0] = oprType;
    cmpEv.stOpCode.len = 1;
    cmpEv.stOpCodeFlg = STU_LOCAL;
    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprReq(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTAUTHMGMTREQ, MAT_MESS_PROT_FAILED);
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_REQ);
    }

#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
#ifdef ZJ
    if ( oprClass != MAT_OPRCLASS4)
    {
       MA_UPD_PEER(dlgCp->upd)
    }
#endif /* ZJ */

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Leaving MaUiMatAuthMgmtReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif
    RETVALUE(ROK);
} /* end of MaUiMatAuthMgmtReq */


#endif /* MAP_VLR || MAP_GSN */

#if MAP_HLR

/* 
* 
*       Fun:   upper interface - Authintication Management Response
*  
*       Desc:  This function handles the Response for Authintication 
*              services from the MAP user 
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatAuthMgmtRsp
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaAuthEv    *authEv         /* Authintication Event Structure */                
)
#else
PUBLIC S16 MaUiMatAuthMgmtRsp(pst, spId, suDlgId, spDlgId, invkId, oprType, usrErr, authEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaUsrErr  *usrErr;          /* User Error */
MaAuthEv    *authEv;        /* Authintication Event Structure */                
#endif
{
  MaSap    *s;          /* Sap pointer */
  MaDlgCp  *dlgCp;      /* dialogue control point pointer */
  MaCmpCp  *cmpCp;      /* component control point pointer */
  U8       oprClass;       /* operation class */
  StComps  cmpEv;       /* component event structure */ 
  StStr    errStr;      /* Error string */
  U8       maVer;       /* Map Version */
  Buffer   *mBuf;       /* Message Buffer */
  S16      ret;         /* return value */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
  MsgLen   len;		/* Message length */

  TRC3(MaUiMatAuthMgmtRsp)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (usrErr);
   MA_CHK_FOR_NULLP (authEv);

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
   invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv));

#else

  MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
   invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv));

#endif/*ALIGN_64BIT*/
  mBuf = (Buffer *)NULLP;
  maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
  if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
     ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv, spId));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv, spId));
     RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
  

  }

  if (s->maState != MA_BND_ENABLED)
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatAuthMgmtRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv, s->maState));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv, s->maState));
     RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
  

  }

  /* Find out the dialogue control point */
  dlgCp = maFindHashDlg(s, spDlgId);
  if ((dlgCp == NULLP) || ((dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
  {
    MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTAUTHMGMTRSP,
                   (Status)MAT_BAD_SPDLGID);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), invkId(%d),\
    oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv));
    RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), invkId(%d),\
    oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv));
    RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
      
  }
 
  if( (((cmpCp = maFindHashInvk(dlgCp, invkId,FALSE)) == (MaCmpCp *)NULLP)) ||
      (cmpCp->ssmState != MA_SSM_WAITRSP))
  {
      /* invalid  invoke id */
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTAUTHMGMTRSP,
                     (Status)MAT_BAD_INVKID);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv, invkId->octet));
      RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
  }
  oprClass = cmpCp->oprClass;

  maVer = dlgCp->apn.val[dlgCp->apn.len -1];

  if (usrErr->pres == TRUE)
  {
    if (cmpCp->oprClass == MAT_OPRCLASS3)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       RETVALUE(ROK);
    }


    /* check if it is service specific error */
    if (usrErr->usrSpecErr.pres == FALSE)
    {
      ret = maChkErr(s,oprType, usrErr->errCode, maVer);
      if (ret != ROK)
      {
#ifdef ZJ
        MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
        MA_UPD_PEER(dlgCp->upd)
#endif
        MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTAUTHMGMTRSP,
                       (Status)MAT_BAD_USRERR_PARAM);
        maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
        /* remove the component control point */
        maRemHashInv(dlgCp, invkId,FALSE);
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
        invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid user error.\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv));
        RETVALUE(RFAILED);

#else

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
        invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, invalid user error.\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv));
        RETVALUE(RFAILED);
 
#endif/*ALIGN_64BIT*/
      }

      

      /* send the TC U Error */
      errStr.len =1;
      errStr.string[0] = usrErr->errCode;

      if (maVer < LMA_VER2P)
      {
         /* For MAP version 1 & 2, continue coding the error the old way */ 

         switch (usrErr->errCode)
         {
            case MAT_SYS_FAILURE:

              if (usrErr->val != MAT_INV_USR_ERRVAL)
              {
                 if ((mBuf = maMkErrMsg(s, MA_TAG_ENUM, usrErr->val)) == 
                                                               (Buffer *)NULLP)
                 {
#ifndef ALIGN_64BIT

                   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
                   invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, failed to make error msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv));
                   RETVALUE(RFAILED);

#else

                   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
                   invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, failed to make error msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv));
                   RETVALUE(RFAILED);

#endif/*ALIGN_64BIT*/
                  }
               }
              break;

            default:
              break;

          } /* end switch */
      }
      else
      {
         /* MAP version 2+, code the return error by using the database */

         if (maEncVer2PErrParam(s, usrErr, MAT_SS_RETERR, maVer) != ROK)
         {
#ifndef ALIGN_64BIT

             MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
            invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, failed to encode Version 2P error.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv));
            RETVALUE(RFAILED);

#else

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
            invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, failed to encode Version 2P error.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv));
            RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
         
   
         }
   
         /* get the encoded message buffer */
         mBuf = s->ctlp.mBuf;

      }

      (Void) maSndTcErr(s,invkId, &errStr, cmpCp, mBuf);

    }
    else
    {
      /* Send the TC U - Reject */
       cmpEv.stInvokeId.pres = TRUE;
       cmpEv.stInvokeId.octet = invkId->octet;
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.opClass = cmpCp->oprClass;
       if (usrErr->usrSpecErr.val == MAT_USR_INIT_RLS)
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_INIT_RELEASE);
       }
       else
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_RESOURCE_LIMIT);
       }
    }
}
  else
  {
     ret = maEncOpr(s, (U8 *)authEv, oprType, MAT_SS_RSP);
     if (ret != ROK)
     {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTAUTHMGMTRSP,
                      (Status)MAT_BAD_RSP_PARAM);
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       if (s->ctlp.mBuf != NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT
       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, failed to make error msg.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv));
#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, failed to make error msg.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv));
#endif
       RETVALUE(RFAILED);
     }
#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_RSP);
#endif

    /* send the return result to TCAP */
    cmpEv.stCompType = STU_RET_RES_L;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stLinkedId.pres = FALSE;

    /*
    ** If the message does not have any parameters then
    ** the operation code must not be filled.
    */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
    if((s->ctlp.mBuf != NULLP)  && (SFndLenMsg(s->ctlp.mBuf,&len) != ROK))
    {
       /*
       ** If the SFndLenMsg fails then free the mBuf and return
       */
       if (s->ctlp.mBuf != NULLP)
       {
          (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, incorrectly fill the opration code.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed, incorrectly fill the opration code.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)authEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
    
    if(s->ctlp.mBuf != NULLP && len > 0)
    {
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.stOpCodeFlg = STU_LOCAL;
    }
    else
    {
       cmpEv.stOpCode.len = 0;
    }

    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
#ifdef MA_SEG 
    cmpEv.stOpCode.string[0] = oprType;
    ret = maRRNLSegment(s,dlgCp,&cmpEv, cmpCp);
    if (ret != ROK)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
			/* ma001.203: Modification. Error code has been changed.*/
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, 
               MAT_EVTAUTHMGMTRSP,(Status)MAT_BAD_RSP_SEG_PARAM);
       /* remove the component control point */
       (Void)maInvkIdle(dlgCp, cmpCp);
       if (s->ctlp.mBuf != (Buffer *)NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed: \
       Invalid segmentation attempt.\n", spId, suDlgId, spDlgId, invkId->octet, 
       oprType,(PTR)usrErr,(PTR)authEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatAuthMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),authEv(0x%lx))failed: \
       Invalid segmentation attempt.\n", spId, suDlgId, spDlgId, invkId->octet, 
       oprType,(PTR)usrErr,(PTR)authEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
#endif /* MA_SEG */
   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprRsp(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_RSP);
    }
#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
  }

#ifdef ZJ
  MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
  MA_UPD_PEER(dlgCp->upd)
#endif
  maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
  /* remove the component control point */
  maRemHashInv(dlgCp, invkId,FALSE);
  RETVALUE(ROK);
} /* end of MaUiMatAuthMgmtRsp */

#endif /* MAP_MSC */

#if (MAP_MSC || MAP_GSN)

/* 
* 
*       Fun:   upper interface - IMEI Management Request
*  
*       Desc:  This function handles the  request for IMEI Management 
*              services from the MAP user.
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatIMEIMgmtReq
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaIMEIEv    *imeiEv         /* IMEI Event Structure */          
)
#else
PUBLIC S16 MaUiMatIMEIMgmtReq(pst, spId, suDlgId, spDlgId, invkId, oprType, imeiEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaIMEIEv    *imeiEv;        /* IMEI Event Structure */          
#endif
{
 MaSap    *s;           /* Sap pointer */
 MaDlgCp  *dlgCp;       /* dialogue control point pointer */
 MaCmpCp  *cmpCp;       /* component control point pointer */
 U8       oprClass;        /* operation class */
 U16      tmrVal;       /* invoke timer value */
 StComps  cmpEv;        /* component event structure */ 
 S16      ret;          /* return value */

   TRC3(MaUiMatIMEIMgmtReq)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (imeiEv);

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatIMEIMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
    invkId(%d),oprType(%d),imeiEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) imeiEv));

#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatIMEIMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
    invkId(%d),oprType(%d),imeiEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) imeiEv));

#endif /*ALIGN_64BIT */
   maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
   if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
       ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatIMEIMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),imeiEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) imeiEv, spId));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatIMEIMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),imeiEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) imeiEv, spId));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatIMEIMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatIMEIMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),imeiEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) imeiEv, s->maState));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatIMEIMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),imeiEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) imeiEv, s->maState));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   
   }

   /* Find out the dialogue control point */
    dlgCp = maFindHashDlg(s, spDlgId);

   /* 
    * Addition - added MA_DLG_IDLE and MA_DLG_PENDING state, 
    * operation requests which are meant for responses should be allowed 
    * in these two states 
    */
   if ((dlgCp == NULLP) || 
       ((dlgCp->dsmState != MA_DLG_WAIT_USER_REQ) &&
       (dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTIMEIMGMTREQ, MAT_INVALID_DLGID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatIMEIMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),imeiEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) imeiEv));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatIMEIMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),imeiEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) imeiEv));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */

    }

    /* check whether operation is supported */
  
    if ( (ret = maIsOprSupp(s, oprType, &oprClass, &tmrVal, dlgCp->apn.val[dlgCp->apn.len -1])) != ROK)
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTIMEIMGMTREQ, MAT_OPR_NOT_SUPP);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatIMEIMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),imeiEv(0x%lx))failed, operation not supported(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) imeiEv, oprType));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatIMEIMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),imeiEv(0x%lx))failed, operation not supported(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) imeiEv, oprType));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT  */ 
    
    }

    if( (cmpCp = maFindHashInvk(dlgCp, invkId,TRUE)) != (MaCmpCp *)NULLP)
    {
        /* duplicate invoke id */
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTIMEIMGMTREQ, MAT_DUP_INVKID);
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatIMEIMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),imeiEv(0x%lx))failed, invalid invokeId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) imeiEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatIMEIMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),imeiEv(0x%lx))failed, invalid invokeId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) imeiEv, invkId->octet));
      RETVALUE(RFAILED);

#endif /*ALIGN_64BIT */

    
    }

    ret = maEncOpr(s, (U8 *)imeiEv, oprType, MAT_SS_REQ);
    if (ret != ROK)
    {
      if (s->ctlp.mBuf != NULLP)
      {
         SPutMsg(s->ctlp.mBuf);
      }
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTIMEIMGMTREQ, MAT_INCORRECT_PARAM);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatIMEIMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),imeiEv(0x%lx))failed, failed to encode operation(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) imeiEv, oprType));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatIMEIMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),imeiEv(0x%lx))failed, failed to encode operation(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) imeiEv, oprType));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    
    }

    if ( oprClass != MAT_OPRCLASS4)
    {
       /* create a new Component control point */
       if(maCb.maCP.nmbOpr  == maCb.maInvCnt)
       {
         if (s->ctlp.mBuf != NULLP)
         {
           SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTIMEIMGMTREQ, MAT_INVOKE_LIMIT_RCHD);

#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatIMEIMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d),imeiEv(0x%lx))failed, invalid spId(%d).\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) imeiEv, spId));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatIMEIMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d),imeiEv(0x%lx))failed, invalid spId(%d).\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) imeiEv, spId));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
       }

       cmpCp = maInsHashInv(s, invkId,TRUE);
       if (cmpCp == (MaCmpCp *)NULLP)
       {
         if (s->ctlp.mBuf != NULLP)
         {
            SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTIMEIMGMTREQ, MAT_OUT_OF_RSRS);
#ifndef ALIGN_64BIT

          MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatIMEIMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d),imeiEv(0x%lx))failed, unable to allocate cmpCp.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) imeiEv));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatIMEIMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d),imeiEv(0x%lx))failed, unable to allocate cmpCp.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) imeiEv));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
       
       }

       cmpCp->oprCode = oprType; 
       cmpCp->oprClass = oprClass;
       cmpCp->invkTmr = tmrVal;
       cmpCp->spDlgId = spDlgId;
       cmpCp->sap = s;
 
      /* Start the timer */
      cmpCp->ssmState = MA_SSM_WAITCFM;
#ifdef ZJ
      MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_ADD)
#endif
    }

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_REQ);
#endif

    /* send the invoke request to TCAP */

    cmpEv.stCompType = STU_INVOKE;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stInvokeTimer = tmrVal; 
    cmpEv.stLinkedId.pres = FALSE;
    cmpEv.stOpCode.string[0] = oprType;
    cmpEv.stOpCode.len = 1;
    cmpEv.stOpCodeFlg = STU_LOCAL;
    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprReq(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                          MAT_EVTIMEIMGMTREQ, MAT_MESS_PROT_FAILED);
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_REQ);
    }

#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
#ifdef ZJ
    if ( oprClass != MAT_OPRCLASS4)
    {
       MA_UPD_PEER(dlgCp->upd)
    }
#endif /* ZJ */
    RETVALUE(ROK);
} /* end of MaUiMatIMEIMgmtReq */

#endif /* MAP_MSC || MAP_GSN */

#if MAP_VLR

/* 
* 
*       Fun:   upper interface - IMEI Management Response
*  
*       Desc:  This function handles the  response for IMEI Management 
*              services from the MAP user.
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatIMEIMgmtRsp
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaUsrErr  *usrErr,          /* User Error */
MaIMEIEv    *imeiEv         /* IMEI Event Structure */          
)
#else
PUBLIC S16 MaUiMatIMEIMgmtRsp(pst, spId, suDlgId, spDlgId, invkId, oprType, usrErr, imeiEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaUsrErr  *usrErr;          /* User Error */
MaIMEIEv    *imeiEv;        /* IMEI Event Structure */          
#endif
{
  MaSap    *s;          /* Sap pointer */
  MaDlgCp  *dlgCp;      /* dialogue control point pointer */
  MaCmpCp  *cmpCp;      /* component control point pointer */
  U8       oprClass;       /* operation class */
  StComps  cmpEv;       /* component event structure */ 
  StStr    errStr;      /* Error string */
  U8       maVer;       /* Map Version */
  Buffer   *mBuf;       /* Message Buffer */
  S16      ret;         /* return value */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
  MsgLen   len;         /* message length */

  TRC3(MaUiMatIMEIMgmtRsp)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (usrErr);
   MA_CHK_FOR_NULLP (imeiEv);

#ifndef ALIGN_64BIT


   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
   invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))\n",


   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv));

#else 

  MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
   invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv));

#endif /* ALIGN_64BIT */   
  mBuf = (Buffer *)NULLP;
  maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
  if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
     ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv, spId));
     RETVALUE(RFAILED);

#else

 MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv, spId));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  

  }

  if (s->maState != MA_BND_ENABLED)
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatIMEIMgmtRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv, s->maState));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv, s->maState));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  

  }

  /* Find out the dialogue control point */
  dlgCp = maFindHashDlg(s, spDlgId);
  if ((dlgCp == NULLP) || ((dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
  {
    MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTIMEIMGMTRSP,
                   (Status)MAT_BAD_SPDLGID);
#ifndef ALIGN_64BIT

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), invkId(%d),\
    oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))failed,invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv));
    RETVALUE(RFAILED);

#else 

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), invkId(%d),\
    oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))failed,invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv));
    RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }
  if( (((cmpCp = maFindHashInvk(dlgCp, invkId,FALSE)) == (MaCmpCp *)NULLP)) ||
      (cmpCp->ssmState != MA_SSM_WAITRSP))
  {
      /* invalid  invoke id */
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTIMEIMGMTRSP,
                     (Status)MAT_BAD_INVKID);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv, invkId->octet));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }
  oprClass = cmpCp->oprClass;
 
  /* Update the Map version */
  maVer = dlgCp->apn.val[dlgCp->apn.len -1];

  if (usrErr->pres == TRUE)
  {
    if (cmpCp->oprClass == MAT_OPRCLASS3)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       RETVALUE(ROK);
    }


    /* check if it is service specific error */
    if (usrErr->usrSpecErr.pres == FALSE)
    {
      ret = maChkErr(s,oprType, usrErr->errCode, maVer);
      if (ret != ROK)
      {
#ifdef ZJ
        MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
        MA_UPD_PEER(dlgCp->upd)
#endif
        MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTIMEIMGMTRSP,
                       (Status)MAT_BAD_USRERR_PARAM);
        maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
        /* remove the component control point */
        maRemHashInv(dlgCp, invkId,FALSE);
        
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
        invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx)), invalid user error.\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv));
        RETVALUE(RFAILED);

#else

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
        invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx)), invalid user error.\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv));
        RETVALUE(RFAILED);

#endif /*ALIGN_64BIT */
      }

      

      /* send the TC U Error */
      errStr.len =1;
      errStr.string[0] = usrErr->errCode;

      if (maVer < LMA_VER2P)
      {
         /* For MAP version 1 & 2, continue coding the error the old way */ 

         switch (usrErr->errCode)
         {
            case MAT_SYS_FAILURE:
              if (usrErr->val != MAT_INV_USR_ERRVAL)
              {
                 if ((mBuf = maMkErrMsg(s, MA_TAG_ENUM, usrErr->val)) 
                                                      == (Buffer *)NULLP)
                 {
#ifndef ALIGN_64BIT

                      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
                   invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))failed, failed to make error msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv));
                   RETVALUE(RFAILED);

#else

                   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
                   invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))failed, failed to make error msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv));
                   RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
                 }
              }
              break;
            default:
              break;
        }
      }
      else
      {
         /* MAP version 2+, code the return error by using the database */

         if (maEncVer2PErrParam(s, usrErr, MAT_SS_RETERR, maVer) != ROK)
         {
#ifndef ALIGN_64BIT

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
            invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))failed, failed to encode version 2P error param.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv));
            RETVALUE(RFAILED);

#else

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
            invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))failed, failed to encode version 2P error param.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv));
            RETVALUE(RFAILED);
 
#endif /* ALIGN_64BIT */
         }
   
         
   
         /* get the encoded message buffer */
         mBuf = s->ctlp.mBuf;
      }

      maSndTcErr(s,invkId, &errStr, cmpCp, mBuf);
    }
    else
    {
      /* Send the TC U - Reject */
       cmpEv.stInvokeId.pres = TRUE;
       cmpEv.stInvokeId.octet = invkId->octet;
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.opClass = cmpCp->oprClass;
       if (usrErr->usrSpecErr.val == MAT_USR_INIT_RLS)
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_INIT_RELEASE);
       }
       else
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_RESOURCE_LIMIT);
       }
    }
  }
  else
  {
     ret = maEncOpr(s, (U8 *)imeiEv, oprType, MAT_SS_RSP);
     if (ret != ROK)
     {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTIMEIMGMTRSP,
                      (Status)MAT_BAD_RSP_PARAM);
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       if (s->ctlp.mBuf != NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
       
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))failed, failed to encope operation.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))failed, failed to encope operation.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */ 
     }
     

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_RSP);
#endif

    /* send the return result to TCAP */
    cmpEv.stCompType = STU_RET_RES_L;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stLinkedId.pres = FALSE;

    /*
    ** If the message does not have any parameters then
    ** the operation code must not be filled.
    */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
    if((s->ctlp.mBuf != NULLP)  && (SFndLenMsg(s->ctlp.mBuf,&len) != ROK))
    {
       /*
       ** If the SFndLenMsg fails then free the mBuf and return
       */
       if (s->ctlp.mBuf != NULLP)
       {
          (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))failed, incorrectly fill operation code.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))failed, incorrectly fill operation code.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)imeiEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
    
    if(s->ctlp.mBuf != NULLP && len > 0)
    {
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.stOpCodeFlg = STU_LOCAL;
    }
    else
    {
       cmpEv.stOpCode.len = 0;
    }

    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
#ifdef MA_SEG 
    cmpEv.stOpCode.string[0] = oprType;
    ret = maRRNLSegment(s,dlgCp,&cmpEv, cmpCp);
    if (ret != ROK)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
			/* ma001.203: Modification. Error code has been changed.*/
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, 
              MAT_EVTIMEIMGMTRSP,(Status)MAT_BAD_RSP_SEG_PARAM);
       /* remove the component control point */
       (Void)maInvkIdle(dlgCp,cmpCp);
       if (s->ctlp.mBuf != (Buffer *)NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifdef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))failed:,\
       Invalid segmentation attempt.\n", spId, suDlgId, spDlgId, invkId->octet, 
       oprType,(PTR)usrErr,(PTR)imeiEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatIMEIMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),imeiEv(0x%lx))failed:,\
       Invalid segmentation attempt.\n", spId, suDlgId, spDlgId, invkId->octet, 
       oprType,(PTR)usrErr,(PTR)imeiEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
#endif /* MA_SEG */

   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprRsp(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_RSP);
    }
#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
  }

#ifdef ZJ
  MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
  MA_UPD_PEER(dlgCp->upd)
#endif
  maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
  /* remove the component control point */
  maRemHashInv(dlgCp, invkId,FALSE);
  RETVALUE(ROK);
} /* end of MaUiMatIMEIMgmtRsp */

#endif /* VLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)

/* 
* 
*       Fun:   MaUiMatSubMgmtReq 
*  
*       Desc:  This function handles the  request for Subscriber Management 
*              services from the MAP user.
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatSubMgmtReq
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaSubEv    *subEv           /* Subscriber Event Structure */            
)
#else
PUBLIC S16 MaUiMatSubMgmtReq(pst, spId, suDlgId, spDlgId, invkId, oprType, subEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaSubEv    *subEv;          /* Subscriber Event Structure */            
#endif
{
 MaSap    *s;           /* Sap pointer */
 MaDlgCp  *dlgCp;       /* dialogue control point pointer */
 MaCmpCp  *cmpCp;       /* component control point pointer */
 U8       oprClass;        /* operation class */
 U16      tmrVal;       /* invoke timer value */
 StComps  cmpEv;        /* component event structure */ 
 S16      ret;          /* return value */

   TRC3(MaUiMatSubMgmtReq)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (subEv);

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatSubMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
    invkId(%d),oprType(%d),subEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) subEv));

#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatSubMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
    invkId(%d),oprType(%d),subEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) subEv));

#endif /* ALIGN_64BIT */
   maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
   if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
       ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSubMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),subEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) subEv, spId));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSubMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),subEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) subEv, spId));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   }

   if (s->maState != MA_BND_ENABLED)
   { 
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatSubMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT 

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSubMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),subEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) subEv,s->maState));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSubMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),subEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) subEv,s->maState));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   }

   /* Find out the dialogue control point */
    dlgCp = maFindHashDlg(s, spDlgId);

   /* 
    * Addition - added MA_DLG_IDLE and MA_DLG_PENDING state, 
    * operation requests which are meant for responses should be allowed 
    * in these two states 
    */
   if ((dlgCp == NULLP) || 
       ((dlgCp->dsmState != MA_DLG_WAIT_USER_REQ) &&
       (dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTSUBMGMTREQ, MAT_INVALID_DLGID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSubMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),subEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) subEv));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSubMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),subEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) subEv));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */ 
    }

    /* check whether operation is supported */
  
    if ( (ret = maIsOprSupp(s, oprType, &oprClass, &tmrVal, dlgCp->apn.val[dlgCp->apn.len -1])) != ROK)
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTSUBMGMTREQ, MAT_OPR_NOT_SUPP);
#ifndef ALIGN_64BIT
 
        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSubMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),subEv(0x%lx))failed, operation not supported(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) subEv, oprType));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSubMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),subEv(0x%lx))failed, operation not supported(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) subEv, oprType));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    
    }

    if( (cmpCp = maFindHashInvk(dlgCp, invkId,TRUE)) != (MaCmpCp *)NULLP)
    {
        /* duplicate invoke id */
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTSUBMGMTREQ, MAT_DUP_INVKID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSubMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),subEv(0x%lx))failed, invalid invole Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) subEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSubMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),subEv(0x%lx))failed, invalid invole Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) subEv, invkId->octet));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    
    }

    ret = maEncOpr(s, (U8 *)subEv, oprType, MAT_SS_REQ);
    if (ret != ROK)
    {
      if (s->ctlp.mBuf != NULLP)
      {
         SPutMsg(s->ctlp.mBuf);
      }
      
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTSUBMGMTREQ, MAT_INCORRECT_PARAM);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSubMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),subEv(0x%lx))failed, encode operation failed.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) subEv));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSubMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),subEv(0x%lx))failed, encode operation failed.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) subEv));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }

    if ( oprClass != MAT_OPRCLASS4)
    {
       /* create a new Component control point */
       if(maCb.maCP.nmbOpr  == maCb.maInvCnt)
       {
         if (s->ctlp.mBuf != NULLP)
         {
           SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTSUBMGMTREQ, MAT_INVOKE_LIMIT_RCHD);
#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatSubMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d),subEv(0x%lx))failed, invoke limit reached(%ld).\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) subEv,maCb.maInvCnt));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatSubMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d),subEv(0x%lx))failed, invoke limit reached(%d).\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) subEv,maCb.maInvCnt));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
       
       }

       cmpCp = maInsHashInv(s, invkId,TRUE);
       if (cmpCp == (MaCmpCp *)NULLP)
       {
        
         if (s->ctlp.mBuf != NULLP)
         {
            SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTSUBMGMTREQ, MAT_OUT_OF_RSRS);
#ifndef ALIGN_64BIT

          MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatSubMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d),subEv(0x%lx)) failed, unable to allocate cmpCp.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) subEv));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatSubMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d),subEv(0x%lx)) failed, unable to allocate cmpCp.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) subEv));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
       
       }

       cmpCp->oprCode = oprType; 
       cmpCp->oprClass = oprClass;
       cmpCp->invkTmr = tmrVal;
       cmpCp->spDlgId = spDlgId;
       cmpCp->sap = s;
 
       /* Start the timer */
       cmpCp->ssmState = MA_SSM_WAITCFM;
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_ADD)
#endif
    }

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_REQ);
#endif

    /* send the invoke request to TCAP */

    cmpEv.stCompType = STU_INVOKE;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stInvokeTimer = tmrVal; 
    cmpEv.stLinkedId.pres = FALSE;
    cmpEv.stOpCode.string[0] = oprType;
    cmpEv.stOpCode.len = 1;
    cmpEv.stOpCodeFlg = STU_LOCAL;
    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprReq(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          maSndPrvErrCfm(oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTSUBMGMTREQ, MAT_MESS_PROT_FAILED);
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_REQ);
    }

#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
#ifdef ZJ
    if ( oprClass != MAT_OPRCLASS4)
    {
       MA_UPD_PEER(dlgCp->upd)
    }
#endif /* ZJ */
    RETVALUE(ROK);
} /* end of MaUiMatSubMgmtReq */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR || MAP_GSN || MAP_MLC)

/* 
* 
*       Fun:   MaUiMatSubMgmtRsp 
*  
*       Desc:  This function handles the Response for Subscriber Management 
*              services from the MAP user 
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatSubMgmtRsp
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaSubEv    *subEv           /* Subscriber Management Event Structure */         
)
#else
PUBLIC S16 MaUiMatSubMgmtRsp(pst, spId, suDlgId, spDlgId, invkId, oprType, usrErr, subEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaUsrErr  *usrErr;          /* User Error */
MaSubEv    *subEv;          /* Subscriber Management Event Structure */         
#endif
{
  MaSap    *s;          /* Sap pointer */
  MaDlgCp  *dlgCp;      /* dialogue control point pointer */
  MaCmpCp  *cmpCp;      /* component control point pointer */
  U8       oprClass;       /* operation class */
  StComps  cmpEv;       /* component event structure */ 
  StStr    errStr;  /* Error string */
  U8       maVer;   /* MAP Version */
  S16      ret;         /* return value */
  Buffer   *mBuf;   /* message buffer */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
  MsgLen   len;      /* Message length */

   TRC3(MaUiMatSubMgmtRsp)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (usrErr);
   MA_CHK_FOR_NULLP (subEv);

#ifndef ALIGN_64BIT

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
    invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv));

#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
    invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv));

#endif /* ALIGN_64BIT */
   maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));

  /*
  ** This is needed for phase-2  responses
  ** For Phase 2+ responses mBuf is initialized from s->ctlp.mBuf.
  */
  mBuf = (Buffer *)NULLP;

  if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
     ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv, spId));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv, spId));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }

  

  if (s->maState != MA_BND_ENABLED)
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatSubMgmtRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv, s->maState));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv, s->maState));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  

  }

  /* Find out the dialogue control point */
  dlgCp = maFindHashDlg(s, spDlgId);
  if ((dlgCp == NULLP) || ((dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
  {
    MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTSUBMGMTRSP,
                   (Status)MAT_BAD_SPDLGID);
    
#ifndef ALIGN_64BIT

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), invkId(%d),\
    oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed, invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv));
    RETVALUE(RFAILED);

#else

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), invkId(%d),\
    oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed, invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv));
    RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }
 
  if( (((cmpCp = maFindHashInvk(dlgCp, invkId,FALSE)) == (MaCmpCp *)NULLP)) ||
      (cmpCp->ssmState != MA_SSM_WAITRSP))
  {
      /* invalid  invoke id */
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTSUBMGMTRSP,
                     (Status)MAT_BAD_INVKID);
#ifndef ALIGN_64BIT
  
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv, invkId->octet));
      RETVALUE(RFAILED);
 
#endif /* ALIGN_64BIT */
  }
  oprClass = cmpCp->oprClass;

  /* Update the Map Version */
  maVer = dlgCp->apn.val[dlgCp->apn.len -1];

  if (usrErr->pres == TRUE)
  {
    if (cmpCp->oprClass == MAT_OPRCLASS3)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       RETVALUE(ROK);
    }
    /* check if it is service specific error */
    if (usrErr->usrSpecErr.pres == FALSE)
    {

      ret = maChkErr(s,oprType, usrErr->errCode, maVer);

      if (ret != ROK)
      {
#ifdef ZJ
        MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
        MA_UPD_PEER(dlgCp->upd)
#endif
        MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTSUBMGMTRSP,
                       (Status)MAT_BAD_USRERR_PARAM);
        maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
        /* remove the component control point */
        maRemHashInv(dlgCp, invkId,FALSE);
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
        invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed, invalid errorCode(%d).\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv, usrErr->errCode));
        RETVALUE(RFAILED);

#else

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
        invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed, invalid errorCode(%d).\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv, usrErr->errCode));
        RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */ 
      }

      

      /* send the TC U Error */
      errStr.len =1;
      errStr.string[0] = usrErr->errCode;

      if (maVer < LMA_VER2P)
      {
         /* For MAP version 1 & 2, continue coding the error the old way */ 

         switch (usrErr->errCode)
         {
            case MAT_SYS_FAILURE:
              if (usrErr->val != MAT_INV_USR_ERRVAL)
              {
                 if ((mBuf = maMkErrMsg(s, MA_TAG_ENUM, usrErr->val)) 
                                                      == (Buffer *)NULLP)
                 {
                   
#ifndef ALIGN_64BIT

                  MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
                   invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed, invalid user error val.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv));
                   RETVALUE(RFAILED);

#else

                   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
                   invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed, invalid user error val.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv));
                   RETVALUE(RFAILED);
                    
#endif /* ALIGN_64BIT */
                 }
              }
              break;
            default:
              break;
        }
      }
      else 
      {
         /* MAP version 2+, code the return error by using the database */

         if (maEncVer2PErrParam(s, usrErr, MAT_SS_RETERR, maVer) != ROK)
         {
#ifndef ALIGN_64BIT

             MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
            invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed, invalid user error param.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv));
            RETVALUE(RFAILED);

#else

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
            invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed, invalid user error param.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv));
            RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
         }
   
         
   
         /* get the encoded message buffer */
         mBuf = s->ctlp.mBuf;
      }
 
      maSndTcErr(s,invkId, &errStr, cmpCp, mBuf);
    }
    else
    {
      /* Send the TC U - Reject */
       cmpEv.stInvokeId.pres = TRUE;
       cmpEv.stInvokeId.octet = invkId->octet;
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.opClass = cmpCp->oprClass;
       if (usrErr->usrSpecErr.val == MAT_USR_INIT_RLS)
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_INIT_RELEASE);
       }
       else
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_RESOURCE_LIMIT);
       }
    }
  }
  else
  {
    ret = maEncOpr(s, (U8 *)subEv, oprType, MAT_SS_RSP);
    if (ret != ROK)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTSUBMGMTRSP,
                      (Status)MAT_BAD_RSP_PARAM);
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       if (s->ctlp.mBuf != NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }

#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed, invalid rsp param.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed, invalid rsp param.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv));
       RETVALUE(RFAILED);
       
#endif /* ALIGN_64BIT */
    }

    

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_RSP);
#endif

    /* send the invoke request to TCAP */
    cmpEv.stCompType = STU_RET_RES_L;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stLinkedId.pres = FALSE;

    /*
    ** If the message does not have any parameters then
    ** the operation code must not be filled.
    */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
    if((s->ctlp.mBuf != NULLP)  && (SFndLenMsg(s->ctlp.mBuf,&len) != ROK))
    {
       /*
       ** If the SFndLenMsg fails then free the mBuf and return
       */
       if (s->ctlp.mBuf != NULLP)
       {
          (Void)SPutMsg(s->ctlp.mBuf);
       }
       
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed, incorrectly fill the operation code.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv));
       RETVALUE(RFAILED);

#else

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed, incorrectly fill the operation code.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) subEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
    if(s->ctlp.mBuf != NULLP && len > 0)
    {
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.stOpCodeFlg = STU_LOCAL;
    }
    else
    {
       cmpEv.stOpCode.len = 0;
    }

    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
#ifdef MA_SEG
    cmpEv.stOpCode.string[0] = oprType;
    ret = maRRNLSegment(s,dlgCp,&cmpEv, cmpCp);
    if (ret != ROK)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
			/* ma001.203: Modification. Error code has been changed.*/
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, 
                MAT_EVTSUBMGMTRSP,(Status)MAT_BAD_RSP_SEG_PARAM);
       /* remove the component control point */
       (Void)maInvkIdle(dlgCp, cmpCp);
       if (s->ctlp.mBuf != (Buffer *)NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
       
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed:, \
       invalid segmentation attempt.\n",spId, suDlgId, spDlgId, 
       invkId->octet, oprType,(PTR)usrErr,(PTR) subEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatSubMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),subEv(0x%lx))failed:, \
       invalid segmentation attempt.\n",spId, suDlgId, spDlgId, 
       invkId->octet, oprType,(PTR)usrErr,(PTR) subEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
#endif /* MA_SEG */

   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprRsp(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_RSP);
    }
#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
  }

#ifdef ZJ
  MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
  MA_UPD_PEER(dlgCp->upd)
#endif
  maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
  /* remove the component control point */
  maRemHashInv(dlgCp, invkId,FALSE);
  RETVALUE(ROK);
} /* end of MaUiMatSubMgmtRsp */

#endif /* MAP_HLR || MAP_VLR || MAP_GSN || MAP_MLC */

#if (MAP_VLR || MAP_HLR)
/* 
* 
*       Fun:   MaUiMatFRMgmtReq 
*  
*       Desc:  This function handles the  request for Fault and Recovery 
*              services from the MAP user.
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatFRMgmtReq
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaFREv    *frEv             /* Fault and Recovery Event Structure */            
)
#else
PUBLIC S16 MaUiMatFRMgmtReq(pst, spId, suDlgId, spDlgId, invkId, oprType, frEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaFREv    *frEv;            /* Fault and Recovery Event Structure */            
#endif
{
 MaSap    *s;           /* Sap pointer */
 MaDlgCp  *dlgCp;       /* dialogue control point pointer */
 MaCmpCp  *cmpCp;       /* component control point pointer */
 U8       oprClass;        /* operation class */
 U16      tmrVal;       /* invoke timer value */
 StComps  cmpEv;        /* component event structure */ 
 S16      ret;          /* return value */

   TRC3(MaUiMatFRMgmtReq)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (frEv);

#ifndef ALIGN_64BIT

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatFRMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
    invkId(%d),oprType(%d), frEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  frEv));

#else 

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatFRMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
    invkId(%d),oprType(%d), frEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  frEv));

#endif /* ALIGN_64BIT */
   maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
   if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
       ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatFRMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), frEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  frEv, spId));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatFRMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), frEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  frEv, spId));
      RETVALUE(RFAILED);
     
#endif /* ALIGN_64BIT */ 
   }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatFRMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatFRMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), frEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  frEv, s->maState));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatFRMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), frEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  frEv, s->maState));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   }

   /* Find out the dialogue control point */
    dlgCp = maFindHashDlg(s, spDlgId);

   /* 
    * Addition - added MA_DLG_IDLE and MA_DLG_PENDING state, 
    * operation requests which are meant for responses should be allowed 
    * in these two states 
    */
   if ((dlgCp == NULLP) || 
       ((dlgCp->dsmState != MA_DLG_WAIT_USER_REQ) &&
       (dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTFRMGMTREQ, MAT_INVALID_DLGID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatFRMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), frEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  frEv));
      RETVALUE(RFAILED);

#else
    
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatFRMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), frEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  frEv));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }


    /* check whether operation is supported */
  
    if ( (ret = maIsOprSupp(s, oprType, &oprClass, &tmrVal, dlgCp->apn.val[dlgCp->apn.len -1])) != ROK)
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTFRMGMTREQ, MAT_OPR_NOT_SUPP);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatFRMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), frEv(0x%lx))failed, operation not supported(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  frEv, oprType));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatFRMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), frEv(0x%lx))failed, operation not supported(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  frEv, oprType));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    
    }

    if( (cmpCp = maFindHashInvk(dlgCp, invkId,TRUE)) != (MaCmpCp *)NULLP)
    {
        /* duplicate invoke id */
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTFRMGMTREQ, MAT_DUP_INVKID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatFRMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), frEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  frEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatFRMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), frEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  frEv, invkId->octet));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
    

    ret = maEncOpr(s, (U8 *)frEv, oprType, MAT_SS_REQ);
    if (ret != ROK)
    {
      if (s->ctlp.mBuf != NULLP)
      {
         SPutMsg(s->ctlp.mBuf);
      }
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTFRMGMTREQ, MAT_OUT_OF_RSRS);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatFRMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), frEv(0x%lx))failed, failed to encode operation(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  frEv, oprType));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatFRMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), frEv(0x%lx))failed, failed to encode operation(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  frEv, oprType));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
    

    if ( oprClass != MAT_OPRCLASS4)
    {
       /* create a new Component control point */
       if(maCb.maCP.nmbOpr  == maCb.maInvCnt)
       {
         if (s->ctlp.mBuf != NULLP)
         {
           SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTFRMGMTREQ, MAT_INVOKE_LIMIT_RCHD);
#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatFRMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d), frEv(0x%lx))failed, invoke limit reached(%ld).\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  frEv, maCb.maInvCnt));
         RETVALUE(RFAILED);
  
#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatFRMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d), frEv(0x%lx))failed, invoke limit reached(%d).\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  frEv, maCb.maInvCnt));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
       }

       

       cmpCp = maInsHashInv(s, invkId,TRUE);
       if (cmpCp == (MaCmpCp *)NULLP)
       {
          
         if (s->ctlp.mBuf != NULLP)
         {
            SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTFRMGMTREQ, MAT_OUT_OF_RSRS);
#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatFRMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d), frEv(0x%lx))failed, unable allocate cmpCp.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  frEv));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatFRMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d), frEv(0x%lx))failed, unable allocate cmpCp.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  frEv));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
       }
       cmpCp->oprCode = oprType; 
       cmpCp->oprClass = oprClass;
       cmpCp->invkTmr = tmrVal;
       cmpCp->spDlgId = spDlgId;
       cmpCp->sap = s;
 
       /* Start the timer */
       cmpCp->ssmState = MA_SSM_WAITCFM;
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_ADD)
#endif
    }

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_REQ);
#endif

    /* send the invoke request to TCAP */

    cmpEv.stCompType = STU_INVOKE;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stInvokeTimer = tmrVal; 
    cmpEv.stLinkedId.pres = FALSE;
    cmpEv.stOpCode.string[0] = oprType;
    cmpEv.stOpCode.len = 1;
    cmpEv.stOpCodeFlg = STU_LOCAL;
    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
    if (s->trc == TRUE)
       maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprReq(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
         if (s->ctlp.mBuf != NULLP)
         {
            SPutMsg(s->ctlp.mBuf);

         }
          maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTFRMGMTREQ, MAT_MESS_PROT_FAILED);
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_REQ);
    }

#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);

#ifdef ZJ
    if ( oprClass != MAT_OPRCLASS4)
    {
       MA_UPD_PEER(dlgCp->upd)
    }
#endif /* ZJ */
    RETVALUE(ROK);
} /* end of MaUiMatFRMgmtReq */

#endif /* (MAP_VLR || MAP_HLR ) */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
/* 
* 
*       Fun:   upper interface - Fault and Recovery Management Response
*  
*       Desc:  This function handles the Response for Fault and Recovery 
*              services from the MAP user 
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatFRMgmtRsp
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaFREv    *frEv             /* Fault and Recovery Management Event Structure */         
)
#else
PUBLIC S16 MaUiMatFRMgmtRsp(pst, spId, suDlgId, spDlgId, invkId, oprType, usrErr, frEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaUsrErr  *usrErr;          /* User Error */
MaFREv    *frEv;            /* Fault and Recovery Management Event Structure */         
#endif
{
  MaSap    *s;          /* Sap pointer */
  MaDlgCp  *dlgCp;      /* dialogue control point pointer */
  MaCmpCp  *cmpCp;      /* component control point pointer */
  U8       oprClass;       /* operation class */
  StComps  cmpEv;       /* component event structure */ 
  StStr    errStr;      /* Error string */
  U8       maVer;       /* Map Version */
  Buffer   *mBuf;       /* Message Buffer */
  S16      ret;         /* return value */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
  MsgLen   len;         /* Message Length */

  TRC3(MaUiMatFRMgmtRsp)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (usrErr);
   MA_CHK_FOR_NULLP (frEv);

#ifndef ALIGN_64BIT

  MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
   invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv));

#else

  MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
   invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv));

#endif /* ALIGN_64BIT */

  mBuf = (Buffer *)NULLP;
  maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
  if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
     ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv, spId));
     RETVALUE(RFAILED);
#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv, spId));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }

  if (s->maState != MA_BND_ENABLED)
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatFRMgmtRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv, s->maState));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv, s->maState));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT*/
  } 
  /* Find out the dialogue control point */
  dlgCp = maFindHashDlg(s, spDlgId);
  if ((dlgCp == NULLP) || ((dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
  {
    MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTFRMGMTRSP,
                   (Status)MAT_BAD_SPDLGID);
#ifndef ALIGN_64BIT

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), invkId(%d),\
    oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed, invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv));
    RETVALUE(RFAILED);

#else

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), invkId(%d),\
    oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed, invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv));
    RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }
 
  if( (((cmpCp = maFindHashInvk(dlgCp, invkId,FALSE)) == (MaCmpCp *)NULLP)) ||
      (cmpCp->ssmState != MA_SSM_WAITRSP))
  {
      /* invalid  invoke id */
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTFRMGMTRSP,
                     (Status)MAT_BAD_INVKID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv, invkId->octet));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }
  oprClass = cmpCp->oprClass;

  /* Update the Map version */
  maVer = dlgCp->apn.val[dlgCp->apn.len -1];

  if (usrErr->pres == TRUE)
  {
    if (cmpCp->oprClass == MAT_OPRCLASS3)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       RETVALUE(ROK);
    }

    /* check if it is service specific error */
    if (usrErr->usrSpecErr.pres == FALSE)
    {
      ret = maChkErr(s,oprType, usrErr->errCode, maVer);
      if (ret != ROK)
      {
#ifdef ZJ
        MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
        MA_UPD_PEER(dlgCp->upd)
#endif
        MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTFRMGMTRSP,
                       (Status)MAT_BAD_USRERR_PARAM);
        maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
        /* remove the component control point */
        maRemHashInv(dlgCp, invkId,FALSE);
#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
        invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed, invalid errCode(%d).\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv, usrErr->errCode));
        RETVALUE(RFAILED);

#else

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
        invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed, invalid errCode(%d).\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv, usrErr->errCode));
        RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
      }

      

      /* send the TC U Error */
      errStr.len =1;
      errStr.string[0] = usrErr->errCode;

      if (maVer < LMA_VER2P)
      {
         /* For MAP version 1 & 2, continue coding the error the old way */ 

         switch (usrErr->errCode)
         {
            case MAT_SYS_FAILURE:
              if (usrErr->val != MAT_INV_USR_ERRVAL)
              {
                 if ((mBuf = maMkErrMsg(s, MA_TAG_ENUM, usrErr->val)) == 
                                                           (Buffer *)NULLP)
                 {
#ifndef ALIGN_64BIT

                    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
                   invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed, unable to make error msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv));
                   RETVALUE(RFAILED);

#else

                   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
                   invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed, unable to make error msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv));
                   RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
                 }
              }
              break;
            default:
              break;
        }
      }
      else
      {
         /* MAP version 2+, code the return error by using the database */

         if (maEncVer2PErrParam(s, usrErr, MAT_SS_RETERR, maVer) != ROK)
         {
#ifndef ALIGN_64BIT

             MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
            invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed, invalid usrErr param.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv));
            RETVALUE(RFAILED);

#else

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
            invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed, invalid usrErr param.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv));
            RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
         }
   
         
   
         /* get the encoded message buffer */
         mBuf = s->ctlp.mBuf;

      }

      maSndTcErr(s,invkId, &errStr, cmpCp, mBuf);
    }
    else
    {
      /* Send the TC U - Reject */
       cmpEv.stInvokeId.pres = TRUE;
       cmpEv.stInvokeId.octet = invkId->octet;
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.opClass = cmpCp->oprClass;
       if (usrErr->usrSpecErr.val == MAT_USR_INIT_RLS)
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_INIT_RELEASE);
       }
       else
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_RESOURCE_LIMIT);
       }
    }
  }
  else
  {
     ret = maEncOpr(s, (U8 *)frEv, oprType, MAT_SS_RSP);
     if (ret != ROK)
     {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTFRMGMTRSP,
                      (Status)MAT_BAD_RSP_PARAM);
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       if (s->ctlp.mBuf != NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed, invalid rsp param.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed, invalid rsp param.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */ 
     }
     

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_RSP);
#endif

    /* send the return result to TCAP */
    cmpEv.stCompType = STU_RET_RES_L;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stLinkedId.pres = FALSE;

    /*
    ** If the message does not have any parameters then
    ** the operation code must not be filled.
    */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
    if((s->ctlp.mBuf != NULLP)  && (SFndLenMsg(s->ctlp.mBuf,&len) != ROK))
    {
       /*
       ** If the SFndLenMsg fails then free the mBuf and return
       */
       if (s->ctlp.mBuf != NULLP)
       {
          (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed, incorrectly fill the oprCode.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed, incorrectly fill the oprCode.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  frEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
    
    if(s->ctlp.mBuf != NULLP && len > 0)
    {
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.stOpCodeFlg = STU_LOCAL;
    }
    else
    {
       cmpEv.stOpCode.len = 0;
    }

    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
#ifdef MA_SEG
    cmpEv.stOpCode.string[0] = oprType;
    ret = maRRNLSegment(s,dlgCp,&cmpEv, cmpCp);
    if (ret != ROK)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
			/* ma001.203: Modification. Error code has been changed.*/
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, 
                MAT_EVTFRMGMTRSP,(Status)MAT_BAD_RSP_SEG_PARAM);
       /* remove the component control point */
       (Void)maInvkIdle(dlgCp, cmpCp);
       if (s->ctlp.mBuf != (Buffer *)NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed: \
       Invalid segmentation attempt .\n", spId, suDlgId, spDlgId, 
       invkId->octet,oprType,(PTR)usrErr,(PTR)  frEv));
       RETVALUE(RFAILED);

#else
   
       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatFRMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx), frEv(0x%lx))failed: \
       Invalid segmentation attempt .\n", spId, suDlgId, spDlgId, 
       invkId->octet,oprType,(PTR)usrErr,(PTR)  frEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
#endif /* MA_SEG */
   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprRsp(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_RSP);
    }
#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
  }

#ifdef ZJ
  MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
  MA_UPD_PEER(dlgCp->upd)
#endif
  maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
  /* remove the component control point */
  maRemHashInv(dlgCp, invkId,FALSE);
  RETVALUE(ROK);
} /* end of MaUiMatFRMgmtRsp */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_MSC || MAP_VLR || MAP_HLR)

/* 
* 
*       Fun:   MaUiMatOAMReq 
*  
*       Desc:  This function handles the  request for Operation and Maintenance
*              services from the MAP user.
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatOAMReq
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaOAMEv    *oamEv           /* Operation and Maintenance Event Structure */             
)
#else
PUBLIC S16 MaUiMatOAMReq(pst, spId, suDlgId, spDlgId, invkId, oprType, oamEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaOAMEv    *oamEv;          /* Operation and Maintenance Event Structure */             
#endif
{
 MaSap    *s;           /* Sap pointer */
 MaDlgCp  *dlgCp;       /* dialogue control point pointer */
 MaCmpCp  *cmpCp;       /* component control point pointer */
 U8       oprClass;        /* operation class */
 U16      tmrVal;       /* invoke timer value */
 StComps  cmpEv;        /* component event structure */ 
 S16      ret;          /* return value */

   TRC3(MaUiMatOAMReq)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (oamEv);

#ifndef ALIGN_64BIT

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatOAMReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
    invkId(%d),oprType(%d),oamEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) oamEv));

#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatOAMReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
    invkId(%d),oprType(%d),oamEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) oamEv));


#endif /* ALIGN_64BIT */
   maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
   if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
       ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOAMReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),oamEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) oamEv, spId));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOAMReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),oamEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) oamEv, spId));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatOAMReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOAMReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),oamEv(0x%lx))failed, invalid sap State(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) oamEv, s->maState));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOAMReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),oamEv(0x%lx))failed, invalid sap State(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) oamEv, s->maState));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   }

   /* Find out the dialogue control point */
    dlgCp = maFindHashDlg(s, spDlgId);

   /* 
    * Addition - added MA_DLG_IDLE and MA_DLG_PENDING state, 
    * operation requests which are meant for responses should be allowed 
    * in these two states 
    */
   if ((dlgCp == NULLP) || 
       ((dlgCp->dsmState != MA_DLG_WAIT_USER_REQ) &&
       (dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTOAMMGMTREQ, MAT_INVALID_DLGID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOAMReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),oamEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) oamEv));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOAMReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),oamEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) oamEv));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }

    /* check whether operation is supported */
  
    if ( (ret = maIsOprSupp(s, oprType, &oprClass, &tmrVal, dlgCp->apn.val[dlgCp->apn.len -1])) != ROK)
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTOAMMGMTREQ, MAT_OPR_NOT_SUPP);
      
#ifndef ALIGN_64BIT
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOAMReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),oamEv(0x%lx))failed, operation not supported(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) oamEv, oprType));
      RETVALUE(RFAILED);

#else
 
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOAMReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),oamEv(0x%lx))failed, operation not supported(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) oamEv, oprType));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
    

    if( (cmpCp = maFindHashInvk(dlgCp, invkId,TRUE)) != (MaCmpCp *)NULLP)
    {
        /* duplicate invoke id */
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTOAMMGMTREQ, MAT_DUP_INVKID);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOAMReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),oamEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) oamEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOAMReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),oamEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) oamEv, invkId->octet));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    
    }

 
    ret = maEncOpr(s, (U8 *)oamEv, oprType, MAT_SS_REQ);
    if (ret != ROK)
    {
      if (s->ctlp.mBuf != NULLP)
      {
         SPutMsg(s->ctlp.mBuf);
      }
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTOAMMGMTREQ, MAT_INCORRECT_PARAM);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOAMReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),oamEv(0x%lx))failed, error in opr param.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) oamEv));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOAMReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),oamEv(0x%lx))failed, error in opr param.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) oamEv));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }

    if ( oprClass != MAT_OPRCLASS4)
    {
       /* create a new Component control point */
       if(maCb.maCP.nmbOpr  == maCb.maInvCnt)
       {
         if (s->ctlp.mBuf != NULLP)
         {
           SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTOAMMGMTREQ, MAT_INVOKE_LIMIT_RCHD);
#ifndef ALIGN_64BIT

          MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatOAMReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d),oamEv(0x%lx))failed, invoke limit reached(%ld).\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) oamEv, maCb.maInvCnt));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatOAMReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d),oamEv(0x%lx))failed, invoke limit reached(%d).\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) oamEv, maCb.maInvCnt));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
       

       }

       cmpCp = maInsHashInv(s, invkId,TRUE);
       if (cmpCp == (MaCmpCp *)NULLP)
       {
         if (s->ctlp.mBuf != NULLP)
         {
            SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTOAMMGMTREQ, MAT_OUT_OF_RSRS);
#ifndef ALIGN_64BIT 

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatOAMReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d),oamEv(0x%lx))failed, unable to allocate cmpCp.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) oamEv));
         RETVALUE(RFAILED);

#else
  
         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatOAMReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d),oamEv(0x%lx))failed, unable to allocate cmpCp.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) oamEv));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
       
       }

       cmpCp->oprCode = oprType; 
       cmpCp->oprClass = oprClass;
       cmpCp->invkTmr = tmrVal;
       cmpCp->spDlgId = spDlgId;
       cmpCp->sap = s;
       /* Start the timer */
       cmpCp->ssmState = MA_SSM_WAITCFM;
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_ADD)
#endif
    }

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_REQ);
#endif

    /* send the invoke request to TCAP */

    cmpEv.stCompType = STU_INVOKE;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stInvokeTimer = tmrVal; 
    cmpEv.stLinkedId.pres = FALSE;
    cmpEv.stOpCode.string[0] = oprType;
    cmpEv.stOpCode.len = 1;
    cmpEv.stOpCodeFlg = STU_LOCAL;
    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  

   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprReq(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                          MAT_EVTOAMMGMTREQ, MAT_MESS_PROT_FAILED);
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_REQ);
    }

#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);

#ifdef ZJ
    if ( oprClass != MAT_OPRCLASS4)
    {
       MA_UPD_PEER(dlgCp->upd)
    }
#endif /* ZJ */
    RETVALUE(ROK);
} /* end of MaUiMatOAMReq */

#endif /* MAP_VLR || MAP_HLR || MAP_MSC */

#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)
/* 
* 
*       Fun:   MaUiMatOAMRsp 
*  
*       Desc:  This function handles the Response for Operation and Maintenance
*              services from the MAP user 
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatOAMRsp
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaOAMEv    *oamEv           /* Operation and Maintenance Event Structure */             
)
#else
PUBLIC S16 MaUiMatOAMRsp(pst, spId, suDlgId, spDlgId, invkId, oprType, usrErr, oamEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaUsrErr  *usrErr;          /* User Error */
MaOAMEv    *oamEv;          /* Operation and Maintenance Event Structure */             
#endif
{
  MaSap    *s;          /* Sap pointer */
  MaDlgCp  *dlgCp;      /* dialogue control point pointer */
  MaCmpCp  *cmpCp;      /* component control point pointer */
  U8       oprClass;    /* operation class */
  StComps  cmpEv;       /* component event structure */ 
  StStr    errStr;      /* Error string */
  U8       maVer;       /* Map Version */
  Buffer   *mBuf;       /* Message Buffer */
  S16      ret;         /* return value */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
  MsgLen   len;         /* Message Length */

  TRC3(MaUiMatOAMRsp)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (usrErr);
   MA_CHK_FOR_NULLP (oamEv);

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
   invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv));

#else

  MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
   invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv));

#endif /* ALIGN_64BIT */
  mBuf = (Buffer *)NULLP;
  maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
  if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
     ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatOAMRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);

#ifndef ALIGN_64BIT

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv, spId));
     RETVALUE(RFAILED);

#else
     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv, spId));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }

  if (s->maState != MA_BND_ENABLED)
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatOAMRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed, invalid sap state(%d)\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv, s->maState));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed, invalid sap state(%d)\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv, s->maState));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  

  }

  /* Find out the dialogue control point */
  dlgCp = maFindHashDlg(s, spDlgId);
  if ((dlgCp == NULLP) || ((dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
  {
    MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTOAMMGMTRSP,
                   (Status)MAT_BAD_SPDLGID);
#ifndef ALIGN_64BIT

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), invkId(%d),\
    oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed, invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv));
    RETVALUE(RFAILED);

#else

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), invkId(%d),\
    oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed, invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv));
    RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }
 
  if( (((cmpCp = maFindHashInvk(dlgCp, invkId,FALSE)) == (MaCmpCp *)NULLP)) ||
      (cmpCp->ssmState != MA_SSM_WAITRSP))
  {
      /* invalid  invoke id */
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTOAMMGMTRSP,
                     (Status)MAT_BAD_INVKID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv, invkId->octet));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }
  oprClass = cmpCp->oprClass;

  /* Update the Map version */
  maVer = dlgCp->apn.val[dlgCp->apn.len -1];

  if (usrErr->pres == TRUE)
  {
    if (cmpCp->oprClass == MAT_OPRCLASS3)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       RETVALUE(ROK);
    }


    /* check if it is service specific error */
    if (usrErr->usrSpecErr.pres == FALSE)
    {
      ret = maChkErr(s,oprType, usrErr->errCode, maVer);
      if (ret != ROK)
      {
#ifdef ZJ
        MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
        MA_UPD_PEER(dlgCp->upd)
#endif
        MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTOAMMGMTRSP,
                       (Status)MAT_BAD_USRERR_PARAM);
        maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
        /* remove the component control point */
        maRemHashInv(dlgCp, invkId,FALSE);
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
        invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed, invalid errCode(%d).\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv, usrErr->errCode));
        RETVALUE(RFAILED);

#else

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
        invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed, invalid errCode(%d).\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv, usrErr->errCode));
        RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
      }
      /* send the TC U Error */
      errStr.len =1;
      errStr.string[0] = usrErr->errCode;

      if (maVer < LMA_VER2P)
      {
         /* For MAP version 1 & 2, continue coding the error the old way */ 

         switch (usrErr->errCode)
         {
            case MAT_SYS_FAILURE:
              if (usrErr->val != MAT_INV_USR_ERRVAL)
              {
                 if ((mBuf = maMkErrMsg(s, MA_TAG_ENUM, usrErr->val)) == 
                                                          (Buffer *)NULLP)
                 {
#ifndef ALIGN_64BIT

                      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
                   invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed, fail to make error msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv));
                   RETVALUE(RFAILED);

#else

                   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
                   invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed, fail to make error msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv));
                   RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
                 }
              }
              break;
            default:
              break;
        }
      }
      else
      {
         /* MAP version 2+, code the return error by using the database */

         if (maEncVer2PErrParam(s, usrErr, MAT_SS_RETERR, maVer) != ROK)
         {
#ifndef ALIGN_64BIT

               MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
            invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed, invalid usrErr.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv));
            RETVALUE(RFAILED);

#else

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
            invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed, invalid usrErr.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv));
            RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
         }
   
         
   
         /* get the encoded message buffer */
         mBuf = s->ctlp.mBuf;

      }

      maSndTcErr(s,invkId, &errStr, cmpCp, mBuf);
    }
    else
    {
      /* Send the TC U - Reject */
       cmpEv.stInvokeId.pres = TRUE;
       cmpEv.stInvokeId.octet = invkId->octet;
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.opClass = cmpCp->oprClass;
       if (usrErr->usrSpecErr.val == MAT_USR_INIT_RLS)
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_INIT_RELEASE);
       }
       else
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_RESOURCE_LIMIT);
       }
    }
  }
  else
  {
     ret = maEncOpr(s, (U8 *)oamEv, oprType, MAT_SS_RSP);
     if (ret != ROK)
     {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTOAMMGMTRSP,
                      (Status)MAT_BAD_RSP_PARAM);
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       if (s->ctlp.mBuf != NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed,invalid invoke Id(%d).\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv,invkId->octet));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed,invalid invoke Id(%d).\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv,invkId->octet));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
     }

     

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_RSP);
#endif

    /* send the return result to TCAP */
    cmpEv.stCompType = STU_RET_RES_L;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stLinkedId.pres = FALSE;

    /*
    ** If the message does not have any parameters then
    ** the operation code must not be filled.
    */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
    if((s->ctlp.mBuf != NULLP)  && (SFndLenMsg(s->ctlp.mBuf,&len) != ROK))
    {
       /*
       ** If the SFndLenMsg fails then free the mBuf and return
       */
       if (s->ctlp.mBuf != NULLP)
       {
          (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed, incorrectly fill oprCpde.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed, incorrectly fill oprCpde.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) oamEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
    
    if(s->ctlp.mBuf != NULLP && len > 0)
    {
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.stOpCodeFlg = STU_LOCAL;
    }
    else
    {
       cmpEv.stOpCode.len = 0;
    }

    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
#ifdef MA_SEG
    cmpEv.stOpCode.string[0] = oprType;
    ret = maRRNLSegment(s,dlgCp,&cmpEv, cmpCp);
    if (ret != ROK)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
			/* ma001.203: Modification. Error code has been changed.*/
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, 
                 MAT_EVTOAMMGMTRSP,(Status)MAT_BAD_RSP_SEG_PARAM);
       /* remove the component control point */
       (Void)maInvkIdle(dlgCp, cmpCp);
       if (s->ctlp.mBuf != (Buffer *)NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed:\
       Invalid segmentation attempt.\n", spId, suDlgId, spDlgId, 
       invkId->octet,oprType,(PTR)usrErr,(PTR) oamEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatOAMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),oamEv(0x%lx))failed:\
       Invalid segmentation attempt.\n", spId, suDlgId, spDlgId, 
       invkId->octet,oprType,(PTR)usrErr,(PTR) oamEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */

    }
#endif /* MA_SEG */
   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprRsp(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_RSP);
    }
#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
  }

#ifdef ZJ
  MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
  MA_UPD_PEER(dlgCp->upd)
#endif
  maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
  /* remove the component control point */
  maRemHashInv(dlgCp, invkId,FALSE);
  RETVALUE(ROK);
} /* end of MaUiMatOAMRsp */

#endif /* MAP_MSC || MAP_HLR || MAP_VLR || MAP_GSN */

#if (MAP_MSC || MAP_VLR || MAP_HLR) 
/* 
* 
*       Fun:   MaUiMatCallMgmtReq 
*  
*       Desc:  This function handles the  request for Call Management 
*              services from the MAP user.
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatCallMgmtReq
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaCallEv    *callEv         /* Call Event Structure */          
)
#else
PUBLIC S16 MaUiMatCallMgmtReq(pst, spId, suDlgId, spDlgId, invkId, oprType, callEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaCallEv    *callEv;        /* Call Event Structure */          
#endif
{
 MaSap    *s;           /* Sap pointer */
 MaDlgCp  *dlgCp;       /* dialogue control point pointer */
 MaCmpCp  *cmpCp;       /* component control point pointer */
 U8       oprClass;        /* operation class */
 U16      tmrVal;       /* invoke timer value */
 StComps  cmpEv;        /* component event structure */ 
 S16      ret;          /* return value */

   TRC3(MaUiMatCallMgmtReq)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (callEv);

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatCallMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
    invkId(%d),oprType(%d),callEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) callEv));

#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatCallMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
    invkId(%d),oprType(%d),callEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) callEv));

#endif /* ALIGN_64BIT */
   maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
   if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
       ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCallMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),callEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) callEv, spId));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCallMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),callEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) callEv, spId));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatCallMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCallMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),callEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) callEv, s->maState));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCallMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),callEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) callEv, s->maState));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   
   }

   /* Find out the dialogue control point */
    dlgCp = maFindHashDlg(s, spDlgId);

   /* 
    * Addition - added MA_DLG_IDLE and MA_DLG_PENDING state, 
    * operation requests which are meant for responses should be allowed 
    * in these two states 
    */
   if ((dlgCp == NULLP) || 
       ((dlgCp->dsmState != MA_DLG_WAIT_USER_REQ) &&
       (dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTCALLMGMTREQ, MAT_INVALID_DLGID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCallMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),callEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) callEv));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCallMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),callEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) callEv));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }

    /* check whether operation is supported */
  
    if ( (ret = maIsOprSupp(s, oprType, &oprClass, &tmrVal, dlgCp->apn.val[dlgCp->apn.len -1])) != ROK)
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTCALLMGMTREQ, MAT_OPR_NOT_SUPP);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCallMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),callEv(0x%lx))failed, opr not supported(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) callEv,oprType));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCallMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),callEv(0x%lx))failed, opr not supported(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) callEv,oprType));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }

    if( (cmpCp = maFindHashInvk(dlgCp, invkId,TRUE)) != (MaCmpCp *)NULLP)
    {
        /* duplicate invoke id */
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTCALLMGMTREQ, MAT_DUP_INVKID);
#ifndef ALIGN_64BIT     
 
    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCallMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),callEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) callEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCallMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),callEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) callEv, invkId->octet));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    
    }

    ret = maEncOpr(s, (U8 *)callEv, oprType, MAT_SS_REQ);
    if (ret != ROK)
    {
      if (s->ctlp.mBuf != NULLP)
      {
         SPutMsg(s->ctlp.mBuf);
      }
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTCALLMGMTREQ, MAT_INCORRECT_PARAM);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCallMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),callEv(0x%lx))failed, incorrect param in opr(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) callEv, oprType));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCallMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),callEv(0x%lx))failed, incorrect param in opr(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) callEv, oprType));
      RETVALUE(RFAILED);

#endif /* LIGN_64BIT */
    
    }

    if ( oprClass != MAT_OPRCLASS4)
    {
       /* create a new Component control point */
       if(maCb.maCP.nmbOpr  == maCb.maInvCnt)
       {
         if (s->ctlp.mBuf != NULLP)
         {
           SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTCALLMGMTREQ, MAT_INVOKE_LIMIT_RCHD);
#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatCallMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d),callEv(0x%lx))failed, invke linit reached(%ld).\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) callEv, maCb.maInvCnt));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatCallMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d),callEv(0x%lx))failed, invke linit reached(%d).\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) callEv, maCb.maInvCnt));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
       }
       cmpCp = maInsHashInv(s, invkId,TRUE);
       if (cmpCp == (MaCmpCp *)NULLP)
       {
         if (s->ctlp.mBuf != NULLP)
         {
            SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTCALLMGMTREQ, MAT_OUT_OF_RSRS);
#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatCallMgmtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d),callEv(0x%lx))failed, unable to allocate cmpCp.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) callEv));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatCallMgmtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d),callEv(0x%lx))failed, unable to allocate cmpCp.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR) callEv));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
       
       }

       cmpCp->oprCode = oprType; 
       cmpCp->oprClass = oprClass;
       cmpCp->invkTmr = tmrVal;
       cmpCp->spDlgId = spDlgId;
       cmpCp->sap = s;
 
       /* Start the timer */
       cmpCp->ssmState = MA_SSM_WAITCFM;
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_ADD)
#endif
    }

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_REQ);
#endif

    /* send the invoke request to TCAP */

    cmpEv.stCompType = STU_INVOKE;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stInvokeTimer = tmrVal; 
    cmpEv.stLinkedId.pres = FALSE;
    cmpEv.stOpCode.string[0] = oprType;
    cmpEv.stOpCode.len = 1;
    cmpEv.stOpCodeFlg = STU_LOCAL;
    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  

    if (s->trc == TRUE)
       maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprReq(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                          MAT_EVTCALLMGMTREQ, MAT_MESS_PROT_FAILED);
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_REQ);
    }

#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);

#ifdef ZJ
    if ( oprClass != MAT_OPRCLASS4)
    {
       MA_UPD_PEER(dlgCp->upd)
    }
#endif /* ZJ */
    RETVALUE(ROK);
} /* end of MaUiMatCallMgmtReq */

#endif /* (MAP_MSC || MAP_VLR || MAP_HLR)  */

#if (MAP_MSC || MAP_VLR || MAP_HLR) 
/* 
* 
*       Fun:   MaUiMatCallMgmtRsp 
*  
*       Desc:  This function handles the Response for Call Management 
*              services from the MAP user 
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatCallMgmtRsp
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaCallEv    *callEv         /* Call Management Event Structure */               
)
#else
PUBLIC S16 MaUiMatCallMgmtRsp(pst, spId, suDlgId, spDlgId, invkId, oprType, usrErr, callEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaUsrErr  *usrErr;          /* User Error */
MaCallEv    *callEv;        /* call Management Event Structure */               
#endif
{
  MaSap    *s;          /* Sap pointer */
  MaDlgCp  *dlgCp;      /* dialogue control point pointer */
  MaCmpCp  *cmpCp;      /* component control point pointer */
  U8       oprClass;       /* operation class */
  StComps  cmpEv;       /* component event structure */ 
  StStr    errStr;      /* Error string */
  U8       maVer;       /* Map Version */
  Buffer   *mBuf;       /* Message Buffer */
  S16      ret;         /* return value */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
  MsgLen   len;         /* Message Length */

  TRC3(MaUiMatCallMgmtRsp)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (usrErr);
   MA_CHK_FOR_NULLP (callEv);

#ifndef ALIGN_64BIT
 
    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
   invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv));
#else
  
    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
   invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv));

#endif /* ALIGN_64BIT */
  mBuf = (Buffer *)NULLP;
  maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
  if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
     ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv,spId));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv,spId));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  

  }

  if (s->maState != MA_BND_ENABLED)
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatCallMgmtRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv, s->maState));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv, s->maState));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }


  /* Find out the dialogue control point */
  dlgCp = maFindHashDlg(s, spDlgId);
  if ((dlgCp == NULLP) || ((dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
  {
    MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTCALLMGMTRSP,
                   (Status)MAT_BAD_SPDLGID);
#ifndef ALIGN_64BIT

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), invkId(%d),\
    oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv));
    RETVALUE(RFAILED);

#else

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), invkId(%d),\
    oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv));
    RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }
 
  if( (((cmpCp = maFindHashInvk(dlgCp, invkId,FALSE)) == (MaCmpCp *)NULLP)) ||
      (cmpCp->ssmState != MA_SSM_WAITRSP))
  {
      /* invalid  invoke id */
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTCALLMGMTRSP,
                     (Status)MAT_BAD_INVKID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv, invkId->octet));
      RETVALUE(RFAILED);
 
#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv, invkId->octet));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }
  oprClass = cmpCp->oprClass;

  /* Update the map version */
  maVer = dlgCp->apn.val[dlgCp->apn.len -1];

  if (usrErr->pres == TRUE)
  {
    if (cmpCp->oprClass == MAT_OPRCLASS3)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       RETVALUE(ROK);
    }

    /* check if it is service specific error */
    if (usrErr->usrSpecErr.pres == FALSE)
    {
      ret = maChkErr(s,oprType, usrErr->errCode, maVer);
      if (ret != ROK)
      {
#ifdef ZJ
        MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
        MA_UPD_PEER(dlgCp->upd)
#endif
        MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTCALLMGMTRSP,
                       (Status)MAT_BAD_USRERR_PARAM);
        maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
        /* remove the component control point */
        maRemHashInv(dlgCp, invkId,FALSE);
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
        invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, invalid usrErr.\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv));
        RETVALUE(RFAILED);

#else

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
        invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, invalid usrErr.\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv));
        RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
      }
      /* send the TC U Error */
      errStr.len =1;
      errStr.string[0] = usrErr->errCode;

      if (maVer < LMA_VER2P)
      {
         /* For MAP version 1 & 2, continue coding the error the old way */ 

         switch (usrErr->errCode)
         {
            case MAT_SYS_FAILURE:
            case MAT_CALL_BARRED:
            case MAT_CUG_REJECT:
              if (usrErr->val != MAT_INV_USR_ERRVAL)
              {
                 if ((mBuf = maMkErrMsg(s, MA_TAG_ENUM, usrErr->val)) == 
                                                            (Buffer *)NULLP)
                 {
#ifndef ALIGN_64BIT

                   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
                   invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, unable to make error msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv));
                   RETVALUE(RFAILED);

#else

                   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
                   invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, unable to make error msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv));
                   RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
                 }
              }
              break;

            case MAT_ABSENT_SUBS:
              if ((maVer == LMA_VER1) && (usrErr->val != MAT_INV_USR_ERRVAL))
              {
                 if ((mBuf = maMkErrMsg(s, MA_TAG_BOOL, usrErr->val)) == 
                                                           (Buffer *)NULLP)
                 {
#ifndef ALIGN_64BIT

                    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
                   invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, unable to make error msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv));
                   RETVALUE(RFAILED);

#else

                   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
                   invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, unable to make error msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv));
                   RETVALUE(RFAILED);
 
#endif /* ALIGN_64BIT */
                 }
              }
            default:
              break;
           }
      }
      else
      {
         /* MAP version 2+, code the return error by using the database */

         if (maEncVer2PErrParam(s, usrErr, MAT_SS_RETERR, maVer) != ROK)
         {
#ifndef ALIGN_64BIT

             MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
            invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, invalid usrErr.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv));
            RETVALUE(RFAILED);

#else

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
            invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, invalid usrErr.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv));
            RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
         }
   
         
   
         /* get the encoded message buffer */
         mBuf = s->ctlp.mBuf;

      }

      maSndTcErr(s,invkId, &errStr, cmpCp, mBuf);
    }
    else
    {
      /* Send the TC U - Reject */
       cmpEv.stInvokeId.pres = TRUE;
       cmpEv.stInvokeId.octet = invkId->octet;
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.opClass = cmpCp->oprClass;
       if (usrErr->usrSpecErr.val == MAT_USR_INIT_RLS)
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_INIT_RELEASE);
       }
       else
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_RESOURCE_LIMIT);
       }
    }
  }
  else
  {
     ret = maEncOpr(s, (U8 *)callEv, oprType, MAT_SS_RSP);
     if (ret != ROK)
     {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTCALLMGMTRSP,
                      (Status)MAT_BAD_RSP_PARAM);
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);

       if (s->ctlp.mBuf != NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, invalid rsp param(%d).\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv, oprType));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, invalid rsp param(%d).\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv, oprType));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
     }

     

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_RSP);
#endif

    /* send the return result to TCAP */
    cmpEv.stCompType = STU_RET_RES_L;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stLinkedId.pres = FALSE;

    /*
    ** If the message does not have any parameters then
    ** the operation code must not be filled.
    */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
    if((s->ctlp.mBuf != NULLP)  && (SFndLenMsg(s->ctlp.mBuf,&len) != ROK))
    {
       /*
       ** If the SFndLenMsg fails then free the mBuf and return
       */
       if (s->ctlp.mBuf != NULLP)
       {
          (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT 

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, incorrectly fill oprCode.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed, incorrectly fill oprCode.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) callEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
    if(s->ctlp.mBuf != NULLP && len > 0)
    {
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.stOpCodeFlg = STU_LOCAL;
    }
    else
    {
       cmpEv.stOpCode.len = 0;
    }

    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
#ifdef MA_SEG 
    cmpEv.stOpCode.string[0] = oprType;
    ret = maRRNLSegment(s,dlgCp,&cmpEv, cmpCp);
    if (ret != ROK)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
			/* ma001.203: Modification. Error code has been changed.*/
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, 
              MAT_EVTCALLMGMTRSP,(Status)MAT_BAD_RSP_SEG_PARAM);
       /* remove the component control point */
       (Void)maInvkIdle(dlgCp, cmpCp);
       if (s->ctlp.mBuf != (Buffer *)NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed:\
       invalid segmentation attempt.\n",spId, suDlgId, spDlgId,
       invkId->octet, oprType,(PTR)usrErr,(PTR)callEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatCallMgmtRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx),callEv(0x%lx))failed:\
       invalid segmentation attempt.\n",spId, suDlgId, spDlgId,
       invkId->octet, oprType,(PTR)usrErr,(PTR)callEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
#endif /* MA_SEG */
   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprRsp(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_RSP);
    }
#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
  }

#ifdef ZJ
  MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
  MA_UPD_PEER(dlgCp->upd)
#endif
  maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
  /* remove the component control point */
  maRemHashInv(dlgCp, invkId,FALSE);
  RETVALUE(ROK);
} /* end of MaUiMatCallMgmtRsp */

#endif /* MAP_MSC || MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR)
/* 
* 
*       Fun:   MaUiMatSSReq 
*  
*       Desc:  This function handles the  request for Supplementry services 
*              services from the MAP user.
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatSSReq
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaInvokeId *lnkId,          /* Linked Invoke Id */
MaSSEv    *ssEv             /* Supplementry Services Event Structure */         
)
#else
PUBLIC S16 MaUiMatSSReq(pst, spId, suDlgId, spDlgId, invkId, oprType, lnkId, ssEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaInvokeId *lnkId;          /* Linked Invoke Id */
MaSSEv    *ssEv;            /* Supplementry Services Event Structure */         
#endif
{
   MaSap    *s;         /* Sap pointer */
   MaDlgCp  *dlgCp;     /* dialogue control point pointer */
   MaCmpCp  *cmpCp;     /* component control point pointer */
   U8       oprClass;      /* operation class */
   U16      tmrVal;     /* invoke timer value */
   StComps  cmpEv;      /* component event structure */ 
   MaCmpCp  *lcmpCp;    /* Component Control point */   
   S16      ret;        /* return value */

   TRC3(MaUiMatSSReq)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (lnkId);
   MA_CHK_FOR_NULLP (ssEv);

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatSSReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
    invkId(%d),oprType(%d), ssEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv));

#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatSSReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
    invkId(%d),oprType(%d), ssEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv));


#endif /* ALIGN_64BIT */
   maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
   if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
       ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSSReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), ssEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv, spId));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSSReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), ssEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv, spId));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatSSReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSSReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), ssEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv, s->maState));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSSReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), ssEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv, s->maState));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   }

   /* Find out the dialogue control point */
    dlgCp = maFindHashDlg(s, spDlgId);

   /* 
    * Addition - added MA_DLG_IDLE and MA_DLG_PENDING state, 
    * operation requests which are meant for responses should be allowed 
    * in these two states 
    */
   if ((dlgCp == NULLP) || 
       ((dlgCp->dsmState != MA_DLG_WAIT_USER_REQ) &&
       (dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTSSMGMTREQ, MAT_INVALID_DLGID);
#ifndef ALIGN_64BIT
      
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSSReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), ssEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSSReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), ssEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }

    /* check whether operation is supported */
  
    if ( (ret = maIsOprSupp(s, oprType, &oprClass, &tmrVal, dlgCp->apn.val[dlgCp->apn.len -1])) != ROK)
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTSSMGMTREQ, MAT_OPR_NOT_SUPP);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSSReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), ssEv(0x%lx))failed, opr not supported(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv, oprType));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSSReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), ssEv(0x%lx))failed, opr not supported(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv, oprType));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
    if (lnkId->pres == TRUE)
    {
      if( (lcmpCp = maFindHashInvk(dlgCp, lnkId,FALSE)) == (MaCmpCp *)NULLP)
      {
         maSndPrvErrCfm(oprType, invkId, spDlgId, suDlgId, s,
                        MAT_EVTSSMGMTREQ, MAT_INVALID_LNKID);
#ifndef ALIGN_64BIT
 
         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatSSReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d), ssEv(0x%lx))failed, invalid link Id.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatSSReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d), ssEv(0x%lx))failed, invalid link Id.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv));
         RETVALUE(RFAILED);

#endif /*ALIGN_64BIT */

      }
      if ( (ret = maIsLinkedOpr(lcmpCp->oprCode, oprType, TRUE)) != ROK)
      {
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTSSMGMTREQ, MAT_INVALID_LNK_OPR);
#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatSSReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d), ssEv(0x%lx))failed, invalid link opr(%d).\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv, lcmpCp->oprCode));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatSSReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d), ssEv(0x%lx))failed, invalid link opr(%d).\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv, lcmpCp->oprCode));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
      
      }
    }
    if( (cmpCp = maFindHashInvk(dlgCp, invkId,TRUE)) != (MaCmpCp *)NULLP)
    {
        /* duplicate invoke id */
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTSSMGMTREQ, MAT_DUP_INVKID);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSSReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), ssEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSSReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), ssEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv, invkId->octet));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    
    }


    ret = maEncOpr(s, (U8 *)ssEv, oprType, MAT_SS_REQ);
    if (ret != ROK)
    {
      if (s->ctlp.mBuf != NULLP)
      {
         SPutMsg(s->ctlp.mBuf);
      }
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTSSMGMTREQ, MAT_INCORRECT_PARAM);
      
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSSReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), ssEv(0x%lx))failed, invalid opr param.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSSReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), ssEv(0x%lx))failed, invalid opr param.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }

    if ( oprClass != MAT_OPRCLASS4)
    {
       /* create a new Component control point */
       if(maCb.maCP.nmbOpr  == maCb.maInvCnt)
       {
         if (s->ctlp.mBuf != NULLP)
         {
           SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTSSMGMTREQ, MAT_INVOKE_LIMIT_RCHD);
#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatSSReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d), ssEv(0x%lx))failed, invoke limit reached(%ld).\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv, maCb.maInvCnt));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatSSReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d), ssEv(0x%lx))failed, invoke limit reached(%d).\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv, maCb.maInvCnt));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
       

       }

       cmpCp = maInsHashInv(s, invkId,TRUE);
       if (cmpCp == (MaCmpCp *)NULLP)
       {
        if (s->ctlp.mBuf != NULLP)
        {
           SPutMsg(s->ctlp.mBuf);
        }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTSSMGMTREQ, MAT_OUT_OF_RSRS);
#ifndef ALIGN_64BIT        
 
          MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatSSReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d), ssEv(0x%lx))failed, unable allocate cmpCp.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv));
         RETVALUE(RFAILED);
 
#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatSSReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d), ssEv(0x%lx))failed, unable allocate cmpCp.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  ssEv));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
       }

       cmpCp->oprCode = oprType; 
       cmpCp->oprClass = oprClass;
       cmpCp->invkTmr = tmrVal;
       cmpCp->spDlgId = spDlgId;
       cmpCp->sap = s;
 
       /* Start the timer */
       cmpCp->ssmState = MA_SSM_WAITCFM;
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_ADD)
#endif
    }

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_REQ);
#endif

    /* send the invoke request to TCAP */

    cmpEv.stCompType = STU_INVOKE;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stInvokeTimer = tmrVal; 
    cmpEv.stLinkedId.pres = lnkId->pres;
    cmpEv.stLinkedId.octet = lnkId->octet;
    cmpEv.stOpCode.string[0] = oprType;
    cmpEv.stOpCode.len = 1;
    cmpEv.stOpCodeFlg = STU_LOCAL;
    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  

   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprReq(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                          MAT_EVTSSMGMTREQ, MAT_MESS_PROT_FAILED);
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_REQ);
    }

#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
#ifdef ZJ
    if ( oprClass != MAT_OPRCLASS4)
    {
       MA_UPD_PEER(dlgCp->upd)
    }
#endif /* ZJ */
    RETVALUE(ROK);
} /* end of MaUiMatSSReq */

#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR)

/* 
* 
*       Fun:   MaUiMatSSRsp 
*  
*       Desc:  This function handles the Response for Supplementry services 
*              services from the MAP user 
*
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatSSRsp
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaSSEv    *ssEv             /* Supplementry Services Event Structure */         
)
#else
PUBLIC S16 MaUiMatSSRsp(pst, spId, suDlgId, spDlgId, invkId, oprType, usrErr, ssEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaUsrErr  *usrErr;          /* User Error */
MaSSEv    *ssEv;            /* Supplementry Services Event Structure */         
#endif
{
  MaSap    *s;          /* Sap pointer */
  MaDlgCp  *dlgCp;      /* dialogue control point pointer */
  MaCmpCp  *cmpCp;      /* component control point pointer */
  U8       oprClass;       /* operation class */
  StComps  cmpEv;       /* component event structure */ 
  S16      ret;         /* return value */
  Buffer   *mBuf;       /* message buffer */
  U8       maVer;
  StStr    errStr;
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
  MsgLen   len;         /* Message Length */

  TRC3(MaUiMatSSRsp)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (usrErr);
   MA_CHK_FOR_NULLP (ssEv);

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatSSRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
   invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv));

#else

  MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatSSRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
   invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv));


#endif /* ALIGN_64BIT */
  mBuf = (Buffer *)NULLP;
  maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
  if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
     ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatSSRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv, spId));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatSSRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv, spId));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  

  }

  if (s->maState != MA_BND_ENABLED)
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatSSRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatSSRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, invalid sap State(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv, s->maState));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatSSRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, invalid sap State(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv, s->maState));
     RETVALUE(RFAILED);


#endif /* ALIGN_64BIT */
       
  }

  /* Find out the dialogue control point */
  dlgCp = maFindHashDlg(s, spDlgId);
  if ((dlgCp == NULLP) || ((dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
  {
    MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTSSMGMTRSP,
                   (Status)MAT_BAD_SPDLGID);
#ifndef ALIGN_64BIT

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatSSRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), invkId(%d),\
    oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv));
    RETVALUE(RFAILED);

#else

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatSSRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), invkId(%d),\
    oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv));
    RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }
 
  if( (((cmpCp = maFindHashInvk(dlgCp, invkId,FALSE)) == (MaCmpCp *)NULLP)) ||
      (cmpCp->ssmState != MA_SSM_WAITRSP))
  {
      /* invalid  invoke id */
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTSSMGMTRSP,
                     (Status)MAT_BAD_INVKID);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSSRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSSRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv, invkId->octet));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }
  oprClass = cmpCp->oprClass;

  /* Update the Map version */
  maVer = dlgCp->apn.val[dlgCp->apn.len -1];

  if (usrErr->pres == TRUE)
  {
    if (cmpCp->oprClass == MAT_OPRCLASS3)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       RETVALUE(ROK);
    }
    if (usrErr->usrSpecErr.pres == TRUE)
    {
       /* Send the TC U - Reject */
       cmpEv.stInvokeId.pres = TRUE;
       cmpEv.stInvokeId.octet = invkId->octet;
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.opClass = cmpCp->oprClass;
       if (usrErr->usrSpecErr.val == MAT_USR_INIT_RLS)
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_INIT_RELEASE);
       }
       else
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_RESOURCE_LIMIT);
       }
    }
    else
    {


      ret = maChkErr(s,oprType, usrErr->errCode, maVer);
      if (ret != ROK)
      {
#ifdef ZJ
        MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
        MA_UPD_PEER(dlgCp->upd)
#endif
        MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTSSMGMTRSP,
                       (Status)MAT_BAD_USRERR_PARAM);
        maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
        /* remove the component control point */
        maRemHashInv(dlgCp, invkId,FALSE);
        
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatSSRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
        invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, invalid useErr.\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv));
        RETVALUE(RFAILED);

#else

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatSSRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
        invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, invalid useErr.\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv));
        RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
      }

      

      if (maVer < LMA_VER2P)
      {
         /* For MAP version 1 & 2, continue coding the error the old way */ 

          /* send the TC U Error */
          switch(usrErr->errCode)
          {
            case MAT_SYS_FAILURE:
            case MAT_PASSWD_REG_ERR:
            case MAT_CALL_BARRED:
              if (usrErr->val != MAT_INV_USR_ERRVAL)
              {
                 if ((mBuf = maMkErrMsg(s, MA_TAG_ENUM, usrErr->val)) == 
                                                             (Buffer *)NULLP)
                 {
#ifndef ALIGN_64BIT

                     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatSSRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
                   invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, unable to make error msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv));
                   RETVALUE(RFAILED);

#else

                   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatSSRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
                   invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, unable to make error msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv));
                   RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
                 }
              }
              break;
            case MAT_SS_STATUS_ERR:
              if (usrErr->ssErr.ssStatus.pres)
              {
                 if (usrErr->ssErr.ssStatus.val != MAT_INV_USR_ERRVAL)
                 {
                    if ((mBuf = maMkErrMsg(s, MA_TAG_OCTSTR, 
                                usrErr->ssErr.ssStatus.val))==(Buffer *)NULLP)
                    {
#ifndef ALIGN_64BIT

                       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                      "MaUiMatSSRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
                      invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, unable to make error msg.\n",
                      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv));
                      RETVALUE(RFAILED);

#else

                      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                      "MaUiMatSSRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
                      invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, unable to make error msg.\n",
                      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv));
                      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
                    
                 
                    }
                 }
              }              
              break;
            case MAT_SS_SUBSVIOL_ERR:           
            case MAT_SS_INCOMP_ERR:
             if ((mBuf =  maEncSSErr(s, usrErr)) == (Buffer *)NULLP)
             {
                if (usrErr->errCode == MAT_PASSWD_REG_ERR)
                {
#ifndef ALIGN_64BIT

                   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                  "MaUiMatSSRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
                  invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, invalid errCode.\n",
                  spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv));
                  RETVALUE(RFAILED);

#else

                  MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                  "MaUiMatSSRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
                  invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, invalid errCode.\n",
                  spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv));
                  RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
                }
             } 
                
             
             break;
            default:
             break;
          }
      }
      else
      {
         /* MAP version 2+, code the return error by using the database */

         if (maEncVer2PErrParam(s, usrErr, MAT_SS_RETERR, maVer) != ROK)
         {
#ifndef ALIGN_64BIT

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatSSRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
            invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, invalid useErr.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv));
            RETVALUE(RFAILED);

#else

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatSSRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
            invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, invalid useErr.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv));
            RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
         
   
         }
   
         /* get the encoded message buffer */
         mBuf = s->ctlp.mBuf;

      }

      errStr.len = 1;
      errStr.string[0] = usrErr->errCode;

      maSndTcErr(s,invkId, &errStr, cmpCp, mBuf);
    }
  }
  else
  {
    ret = maEncOpr(s, (U8 *)ssEv, oprType, MAT_SS_RSP);
    if (ret != ROK)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTSSMGMTRSP,
                      (Status)MAT_BAD_RSP_PARAM);
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       if (s->ctlp.mBuf != NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatSSRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, invalid rsp param.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatSSRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, invalid rsp param.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
    

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_RSP);
#endif

    /* send the return result to TCAP */
    cmpEv.stCompType = STU_RET_RES_L;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;

    /*
    ** If the message does not have any parameters then
    ** the operation code must not be filled.
    */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
    if((s->ctlp.mBuf != NULLP)  && (SFndLenMsg(s->ctlp.mBuf,&len) != ROK))
    {
       /*
       ** If the SFndLenMsg fails then free the mBuf and return
       */
       if (s->ctlp.mBuf != NULLP)
       {
          (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatSSRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, incorrectly fill oprCode.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatSSRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed, incorrectly fill oprCode.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  ssEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
    
    if(s->ctlp.mBuf != NULLP && len > 0)
    {
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.stOpCodeFlg = STU_LOCAL;
    }
    else
    {
       cmpEv.stOpCode.len = 0;
    }

    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
#ifdef MA_SEG
    cmpEv.stOpCode.string[0] = oprType;
    ret = maRRNLSegment(s,dlgCp,&cmpEv, cmpCp);
    if (ret != ROK)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
			/* ma001.203: Modification. Error code has been changed.*/
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, 
                MAT_EVTSSMGMTRSP,(Status)MAT_BAD_RSP_SEG_PARAM);
       /* remove the component control point */
       (Void)maInvkIdle(dlgCp, cmpCp);
       if (s->ctlp.mBuf != (Buffer *)NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatSSRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed:\
       Invalid segmentation attempt.\n", spId, suDlgId, spDlgId, 
       invkId->octet,oprType,(PTR)usrErr,(PTR)  ssEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatSSRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx), ssEv(0x%lx))failed:\
       Invalid segmentation attempt.\n", spId, suDlgId, spDlgId, 
       invkId->octet,oprType,(PTR)usrErr,(PTR)  ssEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
#endif /* MA_SEG */

   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprRsp(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_RSP);
    }
#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
  }

#ifdef ZJ
  MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
  MA_UPD_PEER(dlgCp->upd)
#endif
  maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
  /* remove the component control point */
  maRemHashInv(dlgCp, invkId,FALSE);
  RETVALUE(ROK);
} /* end of MaUiMatSSRsp */

#endif /* MAP_HLR */

#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)

/* 
* 
*       Fun:   MaUiMatSMReq 
*  
*       Desc:  This function handles the  request for Short Message 
*              services from the MAP user.
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatSMReq
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaSMEv    *smEv             /* Short Message Event Structure */         
)
#else
PUBLIC S16 MaUiMatSMReq(pst, spId, suDlgId, spDlgId, invkId, oprType, smEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaSMEv    *smEv;            /* Short Message Event Structure */         
#endif
{
 MaSap    *s;           /* Sap pointer */
 MaDlgCp  *dlgCp;       /* dialogue control point pointer */
 MaCmpCp  *cmpCp;       /* component control point pointer */
 U8       oprClass;        /* operation class */
 U16      tmrVal;       /* invoke timer value */
 StComps  cmpEv;        /* component event structure */ 
 S16      ret;          /* return value */

   TRC3(MaUiMatSMReq)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (smEv);

#ifndef ALIGN_64BIT

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatSMReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
    invkId(%d),oprType(%d), smEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  smEv));

#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatSMReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
    invkId(%d),oprType(%d), smEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  smEv));

#endif /* ALIGN_64BIT */
 
   maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
   if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
       ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT 

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSMReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), smEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  smEv, spId));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSMReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), smEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  smEv, spId));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatSMMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSMReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), smEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  smEv, s->maState));
      RETVALUE(RFAILED);

#else
  
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSMReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), smEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  smEv, s->maState));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   }

   /* Find out the dialogue control point */
    dlgCp = maFindHashDlg(s, spDlgId);

   /* 
    * Addition - added MA_DLG_IDLE and MA_DLG_PENDING state, 
    * operation requests which are meant for responses should be allowed 
    * in these two states 
    */
   if ((dlgCp == NULLP) || 
       ((dlgCp->dsmState != MA_DLG_WAIT_USER_REQ) &&
       (dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTSMMGMTREQ, MAT_INVALID_DLGID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSMReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), smEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  smEv));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSMReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), smEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  smEv));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }


    /* check whether operation is supported */
  
    if ( (ret = maIsOprSupp(s, oprType, &oprClass, &tmrVal, dlgCp->apn.val[dlgCp->apn.len -1])) != ROK)
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTSMMGMTREQ, MAT_OPR_NOT_SUPP);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSMReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), smEv(0x%lx))failed, oprType(%d) not supported.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  smEv, oprType));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSMReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), smEv(0x%lx))failed, oprType(%d) not supported.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  smEv, oprType));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }

    if( (cmpCp = maFindHashInvk(dlgCp, invkId,TRUE)) != (MaCmpCp *)NULLP)
    {
        /* duplicate invoke id */
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTSMMGMTREQ, MAT_DUP_INVKID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSMReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), smEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  smEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSMReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), smEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  smEv, invkId->octet));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    
    }

    ret = maEncOpr(s, (U8 *)smEv, oprType, MAT_SS_REQ);
    if (ret != ROK)
    {
      if (s->ctlp.mBuf != NULLP)
      {
         SPutMsg(s->ctlp.mBuf);
      }
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTSMMGMTREQ, MAT_INCORRECT_PARAM);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSMReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), smEv(0x%lx))failed, invalid smEv param.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  smEv));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSMReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), smEv(0x%lx))failed, invalid smEv param.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  smEv));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }

    if ( oprClass != MAT_OPRCLASS4)
    {
       /* create a new Component control point */
       if(maCb.maCP.nmbOpr  == maCb.maInvCnt)
       {
         if (s->ctlp.mBuf != NULLP)
         {
           SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTSMMGMTREQ, MAT_INVOKE_LIMIT_RCHD);

#ifndef ALIGN_64BIT

          MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatSMReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d), smEv(0x%lx))failed, invoke limit(%ld) reached.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  smEv, maCb.maInvCnt));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatSMReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d), smEv(0x%lx))failed, invoke limit(%d) reached.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  smEv, maCb.maInvCnt));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
       
       }

       cmpCp = maInsHashInv(s, invkId,TRUE);
       if (cmpCp == (MaCmpCp *)NULLP)
       {
         if (s->ctlp.mBuf != NULLP)
         {
            SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTSMMGMTREQ, MAT_OUT_OF_RSRS);
#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatSMReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d), smEv(0x%lx))failed, fail to insert hash table.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  smEv));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatSMReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d), smEv(0x%lx))failed, fail to insert hash table.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  smEv));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
       
       }
       cmpCp->oprCode = oprType; 
       cmpCp->oprClass = oprClass;
       cmpCp->invkTmr = tmrVal;
       cmpCp->spDlgId = spDlgId;
       cmpCp->sap = s;
 
       /* Start the timer */
       cmpCp->ssmState = MA_SSM_WAITCFM;
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_ADD)
#endif
    }

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_REQ);
#endif

    /* send the invoke request to TCAP */

    cmpEv.stCompType = STU_INVOKE;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stInvokeTimer = tmrVal; 
    cmpEv.stLinkedId.pres = FALSE;
    cmpEv.stOpCode.string[0] = oprType;
    cmpEv.stOpCode.len = 1;
    cmpEv.stOpCodeFlg = STU_LOCAL;
    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  

   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprReq(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                          MAT_EVTSMMGMTREQ, MAT_MESS_PROT_FAILED);
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_REQ);
    }

#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);

#ifdef ZJ
    if ( oprClass != MAT_OPRCLASS4)
    {
       MA_UPD_PEER(dlgCp->upd)
    }
#endif /* ZJ */
    RETVALUE(ROK);
} /* end of MaUiMatSMReq */

#endif /* MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_MSC || MAP_HLR || MAP_GSN)

/* 
* 
*       Fun:   MaUiMatSMRsp   
*  
*       Desc:  This function handles the Response for Short Message 
*              services from the MAP user 
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatSMRsp
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaSMEv    *smEv             /* Short Message Event Structure */         
)
#else
PUBLIC S16 MaUiMatSMRsp(pst, spId, suDlgId, spDlgId, invkId, oprType, usrErr, smEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaUsrErr  *usrErr;          /* User Error */
MaSMEv    *smEv;            /* Short Message Event Structure */         
#endif
{
  MaSap    *s;          /* Sap pointer */
  MaDlgCp  *dlgCp;      /* dialogue control point pointer */
  MaCmpCp  *cmpCp;      /* component control point pointer */
  StStr    errStr;      /* Error string */
  U8       oprClass;       /* operation class */
  StComps  cmpEv;       /* component event structure */ 
  U8       maVer;       /* MAP Version */
  S16      ret;         /* return value */
  Buffer   *mBuf;       /* message buffer */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
  MsgLen   len;         /* Message Length */

  TRC3(MaUiMatSMRsp)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (usrErr);
   MA_CHK_FOR_NULLP (smEv);

#ifndef ALIGN_64BIT  

MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatSMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
   invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv));

#else

  MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatSMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
   invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv));

#endif /* ALIGN_64BIT */
  mBuf = (Buffer *)NULLP;
  maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));

  if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
     ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatSMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv, spId));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatSMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv, spId));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  

  }

  if (s->maState != MA_BND_ENABLED)
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatSMMgmtRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatSMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv, s->maState));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatSMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv, s->maState));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  

  }

  /* Find out the dialogue control point */
  dlgCp = maFindHashDlg(s, spDlgId);
  if ((dlgCp == NULLP) || ((dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
  {
    MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTSMMGMTRSP,
                   (Status)MAT_BAD_SPDLGID);
#ifndef ALIGN_64BIT

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatSMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), invkId(%d),\
    oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) smEv));
    RETVALUE(RFAILED);

#else

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
    "MaUiMatSMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), invkId(%d),\
    oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, invalid spDlgId.\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR) smEv));
    RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }
 
  if( (((cmpCp = maFindHashInvk(dlgCp, invkId,FALSE)) == (MaCmpCp *)NULLP)) ||
      (cmpCp->ssmState != MA_SSM_WAITRSP))
  {
     /* invalid  invoke id */
     MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTSMMGMTRSP,
                    (Status)MAT_BAD_INVKID);

#ifndef ALIGN_64BIT

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatSMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, invalid invoke Id(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv, invkId->octet));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatSMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, invalid invoke Id(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv, invkId->octet));
     RETVALUE(RFAILED);
 
#endif /* ALIGN_64BIT */
  }
  oprClass = cmpCp->oprClass;

  /* Update the Map version */
  maVer = dlgCp->apn.val[dlgCp->apn.len -1];

  if (usrErr->pres == TRUE)
  {
    if (cmpCp->oprClass == MAT_OPRCLASS3)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       RETVALUE(ROK);
    }
    if (usrErr->usrSpecErr.pres == FALSE)
    {


      ret = maChkErr(s,oprType, usrErr->errCode, maVer);

      if (ret != ROK)
      {
#ifdef ZJ
        MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
        MA_UPD_PEER(dlgCp->upd)
#endif
        MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTSMMGMTRSP,
                       (Status)MAT_BAD_USRERR_PARAM);
        maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
        /* remove the component control point */
        maRemHashInv(dlgCp, invkId,FALSE);

#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatSMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
        invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, invalid useErr\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv));
        RETVALUE(RFAILED);

#else

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatSMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
        invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, invalid useErr\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv));
        RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
      }

      

      if (maVer < LMA_VER2P)
      {
         /* For MAP version 1 & 2, continue coding the error the old way */ 

          /* send the TC U Error */
          switch (usrErr->errCode)
          {
            case MAT_SYS_FAILURE:
            case MAT_CALL_BARRED:
              if (usrErr->val != MAT_INV_USR_ERRVAL)
              {
                 if ((mBuf = maMkErrMsg(s, MA_TAG_ENUM, usrErr->val)) == 
                                                            (Buffer *)NULLP)
                 {
#ifndef ALIGN_64BIT

                   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatSMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
                   invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, fail to make msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv));
                   RETVALUE(RFAILED);

#else

                   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatSMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
                   invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, fail to make msg.\n",
                   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv));
                   RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
                 }
              }
                 
              
              break;
            case MAT_ABSENT_SUBS:
              if ((maVer == LMA_VER1) && (usrErr->val != MAT_INV_USR_ERRVAL))
              {
                 if ((mBuf = maMkErrMsg(s, MA_TAG_BOOL, usrErr->val)) == 
                                                        (Buffer *)NULLP)
                 {
#ifndef ALIGN_64BIT

                     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                    "MaUiMatSMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
                    invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, fail to make msg.\n",
                    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv));
                    RETVALUE(RFAILED);
              
#else

                    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                    "MaUiMatSMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
                    invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, fail to make msg.\n",
                    spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv));
                    RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
                 
              
                 }
              }
              break;
            case MAT_SM_DEL_FAIL:
             if ((mBuf =  maEncSMErr(s, usrErr)) == (Buffer *)NULLP)
             {
#ifndef ALIGN_64BIT

                 MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                "MaUiMatSMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
                invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, invalid usrErr\n",
                spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv));
                RETVALUE(RFAILED);

#else

                MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                "MaUiMatSMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
                invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, invalid usrErr\n",
                spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv));
                RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
             }
             break;
             default:
               break;
          }
      }
      else
      {
         /* MAP version 2+, code the return error by using the database */

         if (maEncVer2PErrParam(s, usrErr, MAT_SS_RETERR, maVer) != ROK)
         {
#ifndef ALIGN_64BIT

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatSMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
            invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, invalid usrErr.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv));
            RETVALUE(RFAILED);

#else

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatSMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
            invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, invalid usrErr.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv));
            RETVALUE(RFAILED);
     
#endif /* ALIGN_64BIT */
         
   
         }
   
         /* get the encoded message buffer */
         mBuf = s->ctlp.mBuf;

      }

       errStr.len = (U16)1;
       errStr.string[0] = usrErr->errCode;
       maSndTcErr(s, invkId, &errStr, cmpCp, mBuf);
    }
    else
    {
      /* Send the TC U - Reject */
       cmpEv.stInvokeId.pres = TRUE;
       cmpEv.stInvokeId.octet = invkId->octet;
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.opClass = cmpCp->oprClass;
       if (usrErr->usrSpecErr.val == MAT_USR_INIT_RLS)
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_INIT_RELEASE);
       }
       else
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_RESOURCE_LIMIT);
       }
    }
  }
  else
  {
    ret = maEncOpr(s, (U8 *)smEv, oprType, MAT_SS_RSP);
    if (ret != ROK)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTSMMGMTRSP,
                      (Status)MAT_BAD_RSP_PARAM);
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       if (s->ctlp.mBuf != NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }

#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatSMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, invalid opr param.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatSMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, invalid opr param.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
    

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_RSP);
#endif

    /* send the invoke request to TCAP */
    cmpEv.stCompType = STU_RET_RES_L;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stLinkedId.pres = FALSE;

    /*
    ** If the message does not have any parameters then
    ** the operation code must not be filled.
    */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
    if((s->ctlp.mBuf != NULLP)  && (SFndLenMsg(s->ctlp.mBuf,&len) != ROK))
    {
       /*
       ** If the SFndLenMsg fails then free the mBuf and return
       */
       if (s->ctlp.mBuf != NULLP)
       {
          (Void)SPutMsg(s->ctlp.mBuf);
       }

#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatSMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, incorrectly fill oprCode\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatSMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed, incorrectly fill oprCode\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  smEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
    
    if(s->ctlp.mBuf != NULLP && len > 0)
    {
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.stOpCodeFlg = STU_LOCAL;
    }
    else
    {
       cmpEv.stOpCode.len = 0;
    }

    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
#ifdef MA_SEG
    cmpEv.stOpCode.string[0] = oprType;
    ret = maRRNLSegment(s,dlgCp,&cmpEv, cmpCp);
    if (ret != ROK)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
			/* ma001.202: Modification. Error code has been changed.*/
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, 
                MAT_EVTSMMGMTRSP,(Status)MAT_BAD_RSP_SEG_PARAM);
       /* remove the component control point */
       (Void)maInvkIdle(dlgCp, cmpCp);
       if (s->ctlp.mBuf != (Buffer *)NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }

#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatSMRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed:\
       Invalid segmentation attempt\n", spId, suDlgId, spDlgId, 
       invkId->octet,oprType,(PTR)usrErr,(PTR)  smEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatSMRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx), smEv(0x%lx))failed:\
       Invalid segmentation attempt\n", spId, suDlgId, spDlgId, 
       invkId->octet,oprType,(PTR)usrErr,(PTR)  smEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
#endif /* MA_SEG */

   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprRsp(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_RSP);
    }
#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
  }

#ifdef ZJ
  MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
  MA_UPD_PEER(dlgCp->upd)
#endif
  maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
  /* remove the component control point */
  maRemHashInv(dlgCp, invkId,FALSE);
  RETVALUE(ROK);
} /* end of MaUiMatSMRsp */

#endif /* MAP_MSC || MAP_HLR || MAP_GSN */

#if (MAP_HLR || MAP_GSN)
/* 
* 
*       Fun:   MaUiMatNwReqPdpCntxtActvReq 
*  
*       Desc:  This function handles the  request for Pdp Cntxt Act.
*              services from the MAP user.
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatNwReqPdpCntxtActvReq
(
Pst         *pst,            /* post structure */
SpId        spId,            /* service user id */
MaDlgId     suDlgId,        /* Service user dialogue Id */
MaDlgId     spDlgId,        /* Service provider dialogue Id */
MaInvokeId  *invkId,        /* Invoke Id */
MaOprType   oprType,        /* Operation type */
MaPdpActvEv *pdpActvEv      /* Short Message Event Structure */         
)
#else
PUBLIC S16 MaUiMatNwReqPdpCntxtActvReq(pst, spId, suDlgId, spDlgId, invkId, oprType, pdpActvEv)
Pst         *pst;       /* post structure */
SpId        spId;       /* service user id */
MaDlgId     suDlgId;    /* Service user dialogue Id */
MaDlgId     spDlgId;    /* Service provider dialogue Id */
MaInvokeId  *invkId;    /* Invoke Id */
MaOprType   oprType;    /* Operation type */
MaPdpActvEv *pdpActvEv; /* Short Message Event Structure */             
#endif
{
 MaSap    *s;           /* Sap pointer */
 MaDlgCp  *dlgCp;       /* dialogue control point pointer */
 MaCmpCp  *cmpCp;       /* component control point pointer */
 U8       oprClass;        /* operation class */
 U16      tmrVal;       /* invoke timer value */
 StComps  cmpEv;        /* component event structure */ 
 S16      ret;          /* return value */

   TRC3(MaUiMatNwReqPdpCntxtActvReq)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (pdpActvEv);

#ifndef ALIGN_64BIT

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatNwReqPdpCntxtActvReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
    invkId(%d),oprType(%d), pdpActvEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  pdpActvEv));
#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatNwReqPdpCntxtActvReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
    invkId(%d),oprType(%d), pdpActvEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  pdpActvEv));


#endif /* ALIGN_64BIT */
   maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
   if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
       ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatNwReqPdpCntxtActvReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), pdpActvEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  pdpActvEv,spId));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatNwReqPdpCntxtActvReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), pdpActvEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  pdpActvEv,spId));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatPdpActvMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatNwReqPdpCntxtActvReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), pdpActvEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  pdpActvEv, s->maState));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatNwReqPdpCntxtActvReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), pdpActvEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  pdpActvEv, s->maState));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   

   }

   /* Find out the dialogue control point */
    dlgCp = maFindHashDlg(s, spDlgId);

   /* 
    * Addition - added MA_DLG_IDLE and MA_DLG_PENDING state, 
    * operation requests which are meant for responses should be allowed 
    * in these two states 
    */
   if ((dlgCp == NULLP) || 
       ((dlgCp->dsmState != MA_DLG_WAIT_USER_REQ) &&
       (dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTPDPACTVREQ, MAT_INVALID_DLGID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatNwReqPdpCntxtActvReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), pdpActvEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  pdpActvEv));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatNwReqPdpCntxtActvReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), pdpActvEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  pdpActvEv));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }


    /* check whether operation is supported */
  
    if ( (ret = maIsOprSupp(s, oprType, &oprClass, &tmrVal, dlgCp->apn.val[dlgCp->apn.len -1])) != ROK)
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTPDPACTVREQ, MAT_OPR_NOT_SUPP);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatNwReqPdpCntxtActvReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), pdpActvEv(0x%lx))failed, oprType(%d) not supported.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  pdpActvEv, oprType));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatNwReqPdpCntxtActvReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), pdpActvEv(0x%lx))failed, oprType(%d) not supported.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  pdpActvEv, oprType));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    

    }

    if( (cmpCp = maFindHashInvk(dlgCp, invkId,TRUE)) != (MaCmpCp *)NULLP)
    {
        /* duplicate invoke id */
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTPDPACTVREQ, MAT_DUP_INVKID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatNwReqPdpCntxtActvReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), pdpActvEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  pdpActvEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatNwReqPdpCntxtActvReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), pdpActvEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  pdpActvEv, invkId->octet));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    

    }

    ret = maEncOpr(s, (U8 *)pdpActvEv, oprType, MAT_SS_REQ);
    if (ret != ROK)
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTPDPACTVREQ, MAT_INCORRECT_PARAM);
      if (s->ctlp.mBuf != NULLP)
      {
         SPutMsg(s->ctlp.mBuf);
      }
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatNwReqPdpCntxtActvReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), pdpActvEv(0x%lx))failed, incorrect param in oprEvt(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  pdpActvEv, oprType));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatNwReqPdpCntxtActvReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), pdpActvEv(0x%lx))failed, incorrect param in oprEvt(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  pdpActvEv, oprType));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    

    }

    if ( oprClass != MAT_OPRCLASS4)
    {
       /* create a new Component control point */
       if(maCb.maCP.nmbOpr  == maCb.maInvCnt)
       {
         if (s->ctlp.mBuf != NULLP)
         {
           SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTPDPACTVREQ, MAT_INVOKE_LIMIT_RCHD);
         
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatNwReqPdpCntxtActvReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d), pdpActvEv(0x%lx))failed, max invoke limit(%ld) reached\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  pdpActvEv, maCb.maInvCnt));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatNwReqPdpCntxtActvReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d), pdpActvEv(0x%lx))failed, max invoke limit(%d) reached\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  pdpActvEv, maCb.maInvCnt));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
       }

       cmpCp = maInsHashInv(s, invkId,TRUE);
       if (cmpCp == (MaCmpCp *)NULLP)
       {
         if (s->ctlp.mBuf != NULLP)
         {
            SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTPDPACTVREQ, MAT_OUT_OF_RSRS);
         
#ifndef ALIGN_64BIT

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatNwReqPdpCntxtActvReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d), pdpActvEv(0x%lx))failed, fail to insert cmp(%d) in hash.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  pdpActvEv, invkId->octet));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatNwReqPdpCntxtActvReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d), pdpActvEv(0x%lx))failed, fail to insert cmp(%d) in hash.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)  pdpActvEv, invkId->octet));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
       }
       cmpCp->oprCode = oprType; 
       cmpCp->oprClass = oprClass;
       cmpCp->invkTmr = tmrVal;
       cmpCp->spDlgId = spDlgId;
       cmpCp->sap = s;
 
       /* Start the timer */
       cmpCp->ssmState = MA_SSM_WAITCFM;
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_ADD)
#endif
    }

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_REQ);
#endif

    /* send the invoke request to TCAP */

    cmpEv.stCompType = STU_INVOKE;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stInvokeTimer = tmrVal; 
    cmpEv.stLinkedId.pres = FALSE;
    cmpEv.stOpCode.string[0] = oprType;
    cmpEv.stOpCode.len = 1;
    cmpEv.stOpCodeFlg = STU_LOCAL;
    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  

    if (s->trc == TRUE)
       maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprReq(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                          MAT_EVTPDPACTVREQ, MAT_MESS_PROT_FAILED);
          RETVALUE(RFAILED);
       }
    } else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_REQ);
    }

#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);

#ifdef ZJ
    if ( oprClass != MAT_OPRCLASS4)
    {
       MA_UPD_PEER(dlgCp->upd)
    }
#endif /* ZJ */
    RETVALUE(ROK);
} /* end of MaUiMatNwReqPdpCntxtActvReq */

/* 
* 
*       Fun:   MaUiMatNwReqPdpCntxtActvRsp   
*  
*       Desc:  This function handles the Response for Pdp Cntxt Act.
*              services from the MAP user 
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatNwReqPdpCntxtActvRsp
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaPdpActvEv    *pdpActvEv                   /* Short Message Event Structure */         
)
#else
PUBLIC S16 MaUiMatNwReqPdpCntxtActvRsp(pst, spId, suDlgId, spDlgId, invkId, oprType, usrErr, pdpActvEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaUsrErr  *usrErr;          /* User Error */
MaPdpActvEv    *pdpActvEv;          /* Short Message Event Structure */         
#endif
{
  MaSap    *s;          /* Sap pointer */
  MaDlgCp  *dlgCp;      /* dialogue control point pointer */
  MaCmpCp  *cmpCp;      /* component control point pointer */
  StStr    errStr;      /* Error string */
  U8       oprClass;       /* operation class */
  StComps  cmpEv;       /* component event structure */ 
  U8       maVer;       /* MAP Version */
  S16      ret;         /* return value */
  Buffer   *mBuf;       /* message buffer */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
  MsgLen   len;         /* Message Length */

  TRC3(MaUiMatNwReqPdpCntxtActvRsp)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (usrErr);
   MA_CHK_FOR_NULLP (pdpActvEv);

#ifndef ALIGN_64BIT  

MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
   invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  pdpActvEv));

#else

  MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
   invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  pdpActvEv));

#endif /* ALIGN_64BIT */

  mBuf = (Buffer *)NULLP;
  maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
  if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
     ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatPdpActvMgmtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))failed, invalid spId(%d)\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  pdpActvEv, spId));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))failed, invalid spId(%d)\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  pdpActvEv, spId));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  

  }

  if (s->maState != MA_BND_ENABLED)
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatPdpActvMgmtRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  pdpActvEv, s->maState));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  pdpActvEv, s->maState));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  


  }

  /* Find out the dialogue control point */
  dlgCp = maFindHashDlg(s, spDlgId);
  if ((dlgCp == NULLP) || ((dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
  {
     MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTPDPACTVRSP,
                    (Status)MAT_BAD_SPDLGID);
     
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))failed, \
     invalid spDlgId.\n", spId, suDlgId, spDlgId, invkId->octet, oprType,\
     (PTR)usrErr,(PTR)  pdpActvEv));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))failed, \
     invalid spDlgId.\n", spId, suDlgId, spDlgId, invkId->octet, oprType,\
     (PTR)usrErr,(PTR)  pdpActvEv));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }
 
  if( (((cmpCp = maFindHashInvk(dlgCp, invkId,FALSE)) == (MaCmpCp *)NULLP)) ||
      (cmpCp->ssmState != MA_SSM_WAITRSP))
  {
      /* invalid  invoke id */
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTPDPACTVRSP,
                     (Status)MAT_BAD_INVKID);
      
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  pdpActvEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  pdpActvEv, invkId->octet));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }
  oprClass = cmpCp->oprClass;

  /* Update the Map version */
  maVer = dlgCp->apn.val[dlgCp->apn.len -1];

  if (usrErr->pres == TRUE)
  {
    if (cmpCp->oprClass == MAT_OPRCLASS3)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       RETVALUE(ROK);
    }
    if (usrErr->usrSpecErr.pres == FALSE)
    {

      ret = maChkErr(s,oprType, usrErr->errCode, maVer);

      if (ret != ROK)
      {
#ifdef ZJ
        MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
        MA_UPD_PEER(dlgCp->upd)
#endif
        MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTPDPACTVRSP,
                       (Status)MAT_BAD_USRERR_PARAM);
        maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
        /* remove the component control point */
        maRemHashInv(dlgCp, invkId,FALSE);

        
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
        invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))failed, invalid \n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  pdpActvEv));
        RETVALUE(RFAILED);

#else

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
        invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))failed, invalid \n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  pdpActvEv));
        RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
      }


      if (maVer >= LMA_VER2P)
      {
         /* MAP version 2+, code the return error by using the database */

         if (maEncVer2PErrParam(s, usrErr, MAT_SS_RETERR, maVer) != ROK)
         {

            
#ifndef ALIGN_64BIT

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
            invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))failed, invalid useErr.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  pdpActvEv));
            RETVALUE(RFAILED);

#else

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
            invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))failed, invalid useErr.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  pdpActvEv));
            RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
         }
   
         /* get the encoded message buffer */
         mBuf = s->ctlp.mBuf;

      }

      errStr.len = (U16)1;
      errStr.string[0] = usrErr->errCode;
      maSndTcErr(s, invkId, &errStr, cmpCp, mBuf);
    }
    else
    {
      /* Send the TC U - Reject */
       cmpEv.stInvokeId.pres = TRUE;
       cmpEv.stInvokeId.octet = invkId->octet;
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.opClass = cmpCp->oprClass;
       if (usrErr->usrSpecErr.val == MAT_USR_INIT_RLS)
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_INIT_RELEASE);
       }
       else
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_RESOURCE_LIMIT);
       }
    }
  }
  else
  {
    ret = maEncOpr(s, (U8 *)pdpActvEv, oprType, MAT_SS_RSP);
    if (ret != ROK)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTPDPACTVRSP,
                      (Status)MAT_BAD_RSP_PARAM);
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       if (s->ctlp.mBuf != NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
       
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))failed, invalid param.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  pdpActvEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))failed, invalid param.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  pdpActvEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }

    

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_RSP);
#endif

    /* send the invoke request to TCAP */
    cmpEv.stCompType = STU_RET_RES_L;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stLinkedId.pres = FALSE;

    /*
    ** If the message does not have any parameters then
    ** the operation code must not be filled.
    */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
    if((s->ctlp.mBuf != NULLP)  && (SFndLenMsg(s->ctlp.mBuf,&len) != ROK))
    {
       /*
       ** If the SFndLenMsg fails then free the mBuf and return
       */
       if (s->ctlp.mBuf != NULLP)
       {
          (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT       

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))failed, incorrectly fill oprCode.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  pdpActvEv));
       RETVALUE(RFAILED);

#else


       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))failed, incorrectly fill oprCode.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  pdpActvEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
    if(s->ctlp.mBuf != NULLP && len > 0)
    {
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.stOpCodeFlg = STU_LOCAL;
    }
    else
    {
       cmpEv.stOpCode.len = 0;
    } 
    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
#ifdef MA_SEG
    cmpEv.stOpCode.string[0] = oprType;
    ret = maRRNLSegment(s,dlgCp,&cmpEv, cmpCp);
    if (ret != ROK)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
			/* ma001.202: Modification. Error code has been changed.*/
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, 
                MAT_EVTPDPACTVRSP,(Status)MAT_BAD_RSP_SEG_PARAM);
       /* remove the component control point */
       (Void)maInvkIdle(dlgCp, cmpCp);
       if (s->ctlp.mBuf != (Buffer *)NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
       
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))failed: \
       Invalid segmentation attempt.\n", spId, suDlgId, spDlgId, 
       invkId->octet,oprType,(PTR)usrErr,(PTR)  pdpActvEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatNwReqPdpCntxtActvRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx), pdpActvEv(0x%lx))failed: \
       Invalid segmentation attempt.\n", spId, suDlgId, spDlgId, 
       invkId->octet,oprType,(PTR)usrErr,(PTR)  pdpActvEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
#endif /* MA_SEG */
    if (s->trc == TRUE)
       maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_REL99
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprRsp(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_RSP);
    }
#endif /* MAP_SEC */
#endif

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
  }

#ifdef ZJ
  MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
  MA_UPD_PEER(dlgCp->upd)
#endif
  maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
  /* remove the component control point */
  maRemHashInv(dlgCp, invkId,FALSE);
  RETVALUE(ROK);
} /* end of MaUiMatNwReqPdpCntxtActvRsp */

#endif /* MAP_HLR || MAP_GSN */

#if (MAP_REL98 || MAP_REL99)

#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL4 && MAP_GSN))

/* 
* 
*       Fun:   MaUiMatLocServReq 
*  
*       Desc:  This function handles the  request for Location
*              services from the MAP user.
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatLocServReq
(
Pst         *pst,            /* post structure */
SpId        spId,            /* service user id */
MaDlgId     suDlgId,        /* Service user dialogue Id */
MaDlgId     spDlgId,        /* Service provider dialogue Id */
MaInvokeId  *invkId,        /* Invoke Id */
MaOprType   oprType,        /* Operation type */
MaLocServEv *locServEv      /* Loc. Service Event Structure */         
)
#else
PUBLIC S16 MaUiMatLocServReq(pst, spId, suDlgId, spDlgId, invkId, oprType, locServEv)
Pst         *pst;       /* post structure */
SpId        spId;       /* service user id */
MaDlgId     suDlgId;    /* Service user dialogue Id */
MaDlgId     spDlgId;    /* Service provider dialogue Id */
MaInvokeId  *invkId;    /* Invoke Id */
MaOprType   oprType;    /* Operation type */
MaLocServEv *locServEv; /* Loc. Service Event Structure */             
#endif
{
 MaSap    *s;           /* Sap pointer */
 MaDlgCp  *dlgCp;       /* dialogue control point pointer */
 MaCmpCp  *cmpCp;       /* component control point pointer */
 U8       oprClass;        /* operation class */
 U16      tmrVal;       /* invoke timer value */
 StComps  cmpEv;        /* component event structure */ 
 S16      ret;          /* return value */

   TRC3(MaUiMatLocServReq)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (locServEv);

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatLocServReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
    invkId(%d),oprType(%d), locServEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)locServEv));

#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatLocServReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
    invkId(%d),oprType(%d), locServEv(0x%lx))\n",
    spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)locServEv));

#endif /* ALIGN_64BIT */
   maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
   if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
       ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocServReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocServReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), locServEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)locServEv, spId));
      RETVALUE(RFAILED);

#else

       
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocServReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), locServEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)locServEv, spId));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatLocServReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
      

#ifndef  ALIGN_64BIT
       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocServReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), locServEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)locServEv, s->maState));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocServReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), locServEv(0x%lx))failed, invalid sap state(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)locServEv, s->maState));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   

   }

   /* Find out the dialogue control point */
    dlgCp = maFindHashDlg(s, spDlgId);

   /* 
    * Addition - added MA_DLG_IDLE and MA_DLG_PENDING state, 
    * operation requests which are meant for responses should be allowed 
    * in these two states 
    */
   if ((dlgCp == NULLP) || 
       ((dlgCp->dsmState != MA_DLG_WAIT_USER_REQ) &&
       (dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTLOCSERVREQ, MAT_INVALID_DLGID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocServReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), locServEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)locServEv));
      RETVALUE(RFAILED);
#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocServReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), locServEv(0x%lx))failed, invalid spDlgId.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)locServEv));
      RETVALUE(RFAILED);
        
#endif /* ALIGN_64BIT */
    }

    /* check whether operation is supported */
  
    if ( (ret = maIsOprSupp(s, oprType, &oprClass, &tmrVal, dlgCp->apn.val[dlgCp->apn.len -1])) != ROK)
    {
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTLOCSERVREQ, MAT_OPR_NOT_SUPP);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocServReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), locServEv(0x%lx))failed, oprType(%d) not supported.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)locServEv, oprType));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocServReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), locServEv(0x%lx))failed, oprType(%d) not supported.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)locServEv, oprType));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    
    }

    if( (cmpCp = maFindHashInvk(dlgCp, invkId,TRUE)) != (MaCmpCp *)NULLP)
    {
        /* duplicate invoke id */
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTLOCSERVREQ, MAT_DUP_INVKID);
      
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocServReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), locServEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)locServEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocServReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), locServEv(0x%lx))failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)locServEv, invkId->octet));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    

    }

    ret = maEncOpr(s, (U8 *)locServEv, oprType, MAT_SS_REQ);
    if (ret != ROK)
    {
      if (s->ctlp.mBuf != NULLP)
      {
         SPutMsg(s->ctlp.mBuf);
      }
      maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                      MAT_EVTLOCSERVREQ, MAT_INCORRECT_PARAM);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocServReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d), locServEv(0x%lx))failed, invalid param in locSerEv.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)locServEv));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocServReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d), locServEv(0x%lx))failed, invalid param in locSerEv.\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)locServEv));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    
    }

    if ( oprClass != MAT_OPRCLASS4)
    {
       /* create a new Component control point */
       if(maCb.maCP.nmbOpr  == maCb.maInvCnt)
       {
         if (s->ctlp.mBuf != NULLP)
         {
           SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTLOCSERVREQ, MAT_INVOKE_LIMIT_RCHD);
#ifndef ALIGN_64BIT

          MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatLocServReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d), locServEv(0x%lx))failed, invoke limit(%ld) reached.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)locServEv, maCb.maInvCnt));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatLocServReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d), locServEv(0x%lx))failed, invoke limit(%d) reached.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)locServEv, maCb.maInvCnt));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
       

       }

       cmpCp = maInsHashInv(s, invkId,TRUE);
       if (cmpCp == (MaCmpCp *)NULLP)
       {
         if (s->ctlp.mBuf != NULLP)
         {
            SPutMsg(s->ctlp.mBuf);
         }
         maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                         MAT_EVTLOCSERVREQ, MAT_OUT_OF_RSRS);
         
#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatLocServReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
         invkId(%d),oprType(%d), locServEv(0x%lx))failed, fail to insert hash table.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)locServEv));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatLocServReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
         invkId(%d),oprType(%d), locServEv(0x%lx))failed, fail to insert hash table.\n",
         spId, suDlgId, spDlgId, invkId->octet, oprType, (PTR)locServEv));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
       
       }
       cmpCp->oprCode = oprType; 
       cmpCp->oprClass = oprClass;
       cmpCp->invkTmr = tmrVal;
       cmpCp->spDlgId = spDlgId;
       cmpCp->sap = s;
 
       /* Start the timer */
       cmpCp->ssmState = MA_SSM_WAITCFM;
#ifdef ZJ
      MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_ADD)
#endif
    }

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_REQ);
#endif

    /* send the invoke request to TCAP */

    cmpEv.stCompType = STU_INVOKE;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stInvokeTimer = tmrVal; 
    cmpEv.stLinkedId.pres = FALSE;
    cmpEv.stOpCode.string[0] = oprType;
    cmpEv.stOpCode.len = 1;
    cmpEv.stOpCodeFlg = STU_LOCAL;
    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  

    if (s->trc == TRUE)
       maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprReq(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
           if (s->ctlp.mBuf != NULLP)
           {
              SPutMsg(s->ctlp.mBuf);
           }
           
          maSndPrvErrCfm( oprType, invkId, spDlgId, suDlgId, s,
                          MAT_EVTLOCSERVREQ, MAT_MESS_PROT_FAILED);
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_REQ);
    }

#endif /* MAP_SEC */

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);

#ifdef ZJ
    if ( oprClass != MAT_OPRCLASS4)
    {
       MA_UPD_PEER(dlgCp->upd)
    }
#endif /* ZJ */
    RETVALUE(ROK);
} /* end of MaUiMatLocServReq */

#endif
#endif

#if (MAP_MSC || MAP_HLR || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_HLR || MAP_MLC || (MAP_REL4 && MAP_GSN))

/* 
* 
*       Fun:   MaUiMatLocServRsp   
*  
*       Desc:  This function handles the Response for location
*              services from the MAP user 
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatLocServRsp
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaLocServEv    *locServEv   /* Loc. Service Event Structure */         
)
#else
PUBLIC S16 MaUiMatLocServRsp(pst, spId, suDlgId, spDlgId, invkId, oprType, usrErr, locServEv)
Pst      *pst;              /* post structure */
SpId     spId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaUsrErr  *usrErr;          /* User Error */
MaLocServEv    *locServEv;  /* Loc. Service Event Structure */         
#endif
{
  MaSap    *s;          /* Sap pointer */
  MaDlgCp  *dlgCp;      /* dialogue control point pointer */
  MaCmpCp  *cmpCp;      /* component control point pointer */
  StStr    errStr;      /* Error string */
  U8       oprClass;       /* operation class */
  StComps  cmpEv;       /* component event structure */ 
  U8       maVer;       /* MAP Version */
  S16      ret;         /* return value */
  Buffer   *mBuf;       /* message buffer */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
  MsgLen   len;         /* Message Length */

  TRC3(MaUiMatLocServRsp)

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (invkId);
   MA_CHK_FOR_NULLP (usrErr);
   MA_CHK_FOR_NULLP (locServEv);

#ifndef ALIGN_64BIT

    MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
   invkId(%d),oprType(%d),usrErr(0x%lx), locServEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  locServEv));
#else

  MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
  "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
   invkId(%d),oprType(%d),usrErr(0x%lx), locServEv(0x%lx))\n",
   spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  locServEv));


#endif /* ALIGN_64BIT */
  mBuf = (Buffer *)NULLP;
  maBZero((U8 *)(&cmpEv),(U32)sizeof(StComps));
  if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
     ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatLocServRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx), locServEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  locServEv, spId));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx), locServEv(0x%lx))failed, invalid spId(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  locServEv, spId));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  

  }

  if (s->maState != MA_BND_ENABLED)
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatLocServRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
     invkId(%d),oprType(%d),usrErr(0x%lx), locServEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  locServEv, s->maState));
     RETVALUE(RFAILED);
#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
     invkId(%d),oprType(%d),usrErr(0x%lx), locServEv(0x%lx))failed, invalid sap state(%d).\n",
     spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  locServEv, s->maState));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  

  }

  /* Find out the dialogue control point */
  dlgCp = maFindHashDlg(s, spDlgId);
  if ((dlgCp == NULLP) || ((dlgCp->dsmState != MA_DLG_ACCEPTED) &&
       (dlgCp->dsmState != MA_DLG_ESTABLISHED) && 
       (dlgCp->dsmState != MA_DLG_IDLE) && 
       (dlgCp->dsmState != MA_DLG_PENDING)))
  {
     MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTLOCSERVRSP,
                   (Status)MAT_BAD_SPDLGID);
#ifndef ALIGN_64BIT  

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), invkId(%d),\
     oprType(%d),usrErr(0x%lx), locServEv(0x%lx))failed, invalid spDlgId.\n",
     spId,suDlgId,spDlgId,invkId->octet,oprType,(PTR)usrErr,(PTR) locServEv));
     RETVALUE(RFAILED);

#else

     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), invkId(%d),\
     oprType(%d),usrErr(0x%lx), locServEv(0x%lx))failed, invalid spDlgId.\n",
     spId,suDlgId,spDlgId,invkId->octet,oprType,(PTR)usrErr,(PTR) locServEv));
     RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
  }
 
  if( (((cmpCp = maFindHashInvk(dlgCp, invkId,FALSE)) == (MaCmpCp *)NULLP)) ||
      (cmpCp->ssmState != MA_SSM_WAITRSP))
  {
      /* invalid  invoke id */
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTLOCSERVRSP,
                     (Status)MAT_BAD_INVKID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
      invkId(%d),oprType(%d),usrErr(0x%lx), locServEv(0x%lx).)failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  locServEv, invkId->octet));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
      invkId(%d),oprType(%d),usrErr(0x%lx), locServEv(0x%lx).)failed, invalid invoke Id(%d).\n",
      spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  locServEv, invkId->octet));
      RETVALUE(RFAILED);

#endif /*ALIGN_64BIT */
  }
  oprClass = cmpCp->oprClass;

  /* Update the Map version */
  maVer = dlgCp->apn.val[dlgCp->apn.len -1];

  if (usrErr->pres == TRUE)
  {
    if (cmpCp->oprClass == MAT_OPRCLASS3)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       RETVALUE(ROK);
    }
    if (usrErr->usrSpecErr.pres == FALSE)
    {
      ret = maChkErr(s,oprType, usrErr->errCode, maVer);

      if (ret != ROK)
      {
#ifdef ZJ
        MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
        MA_UPD_PEER(dlgCp->upd)
#endif
        MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTLOCSERVRSP,
                       (Status)MAT_BAD_USRERR_PARAM);
        maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
        /* remove the component control point */
        maRemHashInv(dlgCp, invkId,FALSE);
#ifndef ALIGN_64BIT  

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
        invkId(%d),oprType(%d),usrErr(0x%lx), locServEv(0x%lx))failed, invalid locServEv param.\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  locServEv));
        RETVALUE(RFAILED);

#else

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
        "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
        invkId(%d),oprType(%d),usrErr(0x%lx), locServEv(0x%lx))failed, invalid locServEv param.\n",
        spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  locServEv));
        RETVALUE(RFAILED);
              
          
#endif /* ALIGN_64BIT */
      }

      

      if (maVer >= LMA_VER2P)
      {
         /* MAP version 2+, code the return error by using the database */

         if (maEncVer2PErrParam(s, usrErr, MAT_SS_RETERR, maVer) != ROK)
         {
#ifndef ALIGN_64BIT

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
            invkId(%d),oprType(%d),usrErr(0x%lx), locServEv(0x%lx))failed, invalid uerErr.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  locServEv));
            RETVALUE(RFAILED);

#else

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
            invkId(%d),oprType(%d),usrErr(0x%lx), locServEv(0x%lx))failed, invalid uerErr.\n",
            spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  locServEv));
            RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
         
   
         }
   
         /* get the encoded message buffer */
         mBuf = s->ctlp.mBuf;

      }

      errStr.len = (U16)1;
      errStr.string[0] = usrErr->errCode;
      maSndTcErr(s, invkId, &errStr, cmpCp, mBuf);
    }
    else
    {
      /* Send the TC U - Reject */
       cmpEv.stInvokeId.pres = TRUE;
       cmpEv.stInvokeId.octet = invkId->octet;
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.opClass = cmpCp->oprClass;
       if (usrErr->usrSpecErr.val == MAT_USR_INIT_RLS)
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_INIT_RELEASE);
       }
       else
       {
          maSndTcRej(s, &cmpEv, STU_PROB_INVOKE, STU_RESOURCE_LIMIT);
       }
    }
  }
  else
  {
    ret = maEncOpr(s, (U8 *)locServEv, oprType, MAT_SS_RSP);
    if (ret != ROK)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, MAT_EVTLOCSERVRSP,
                      (Status)MAT_BAD_RSP_PARAM);
       maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
       /* remove the component control point */
       maRemHashInv(dlgCp, invkId,FALSE);
       if (s->ctlp.mBuf != NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx), locServEv(0x%lx))failed, invalid locSerEv param.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  locServEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx), locServEv(0x%lx))failed, invalid locSerEv param.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  locServEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }

    

#ifndef MAP_SEC
    /* Update the Stat. */
    maUpdatTxSts(s,oprType, MAT_SS_RSP);
#endif

    /* send the invoke request to TCAP */
    cmpEv.stCompType = STU_RET_RES_L;
    cmpEv.stInvokeId.pres = TRUE;
    cmpEv.stInvokeId.octet = invkId->octet;
    cmpEv.stLinkedId.pres = FALSE;

    /*
    ** If the message does not have any parameters then
    ** the operation code must not be filled.
    */
/* ma002.203 - SFndLenMsg requires 2nd arg of type MsgLen */
    if((s->ctlp.mBuf != NULLP)  && (SFndLenMsg(s->ctlp.mBuf,&len) != ROK))
    {
       /*
       ** If the SFndLenMsg fails then free the mBuf and return
       */
       if (s->ctlp.mBuf != NULLP)
       {
          (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT 

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx), locServEv(0x%lx))failed, incorrectly fill oprCode.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  locServEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx), locServEv(0x%lx))failed, incorrectly fill oprCode.\n",
       spId, suDlgId, spDlgId, invkId->octet, oprType,(PTR)usrErr,(PTR)  locServEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
    if(s->ctlp.mBuf != NULLP && len > 0)
    {
       cmpEv.stOpCode.string[0] = oprType;
       cmpEv.stOpCode.len = 1;
       cmpEv.stOpCodeFlg = STU_LOCAL;
    }
    else
    {
       cmpEv.stOpCode.len = 0;
    }

    cmpEv.stErrorCode.len = 0;
    cmpEv.stErrorCodeFlg = STU_NONE;
    cmpEv.stProbCode.len = 0;
    cmpEv.cancelFlg = FALSE;  
    cmpEv.opClass = oprClass;  
#ifdef MA_SEG
    cmpEv.stOpCode.string[0] = oprType;
    ret = maRRNLSegment(s,dlgCp,&cmpEv, cmpCp);
    if (ret != ROK)
    {
#ifdef ZJ
       MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
       MA_UPD_PEER(dlgCp->upd)
#endif
			/* ma001.202: Modification. Error code has been changed.*/
       MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, invkId, 
               MAT_EVTLOCSERVRSP,(Status)MAT_BAD_RSP_SEG_PARAM);
       /* remove the component control point */
       (Void)maInvkIdle(dlgCp, cmpCp);
       if (s->ctlp.mBuf != (Buffer *)NULLP)
       {
         (Void)SPutMsg(s->ctlp.mBuf);
       }
#ifndef ALIGN_64BIT

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
       invkId(%d),oprType(%d),usrErr(0x%lx), locServEv(0x%lx))failed:\
       Invalid segmentation attempt.\n", spId, suDlgId, spDlgId, 
       invkId->octet, oprType,(PTR)usrErr,(PTR)  locServEv));
       RETVALUE(RFAILED);

#else

       MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
       "MaUiMatLocServRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
       invkId(%d),oprType(%d),usrErr(0x%lx), locServEv(0x%lx))failed:\
       Invalid segmentation attempt.\n", spId, suDlgId, spDlgId, 
       invkId->octet, oprType,(PTR)usrErr,(PTR)  locServEv));
       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
    }
#endif /* MA_SEG */

    if (s->trc == TRUE)
       maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);
    
#if MAP_SEC
    if(dlgCp->mapSec == TRUE)
    {
       ret = maProcSecOprRsp(s,dlgCp,&cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId);
       if(ret != ROK)
       {
          if (s->ctlp.mBuf != NULLP)
          {
             SPutMsg(s->ctlp.mBuf);
          }
          RETVALUE(RFAILED);
       }
    }
    else
    {
       /* Update the Stat. */
       maUpdatTxSts(s,oprType, MAT_SS_RSP);
    }
#endif /* MAP_SEC */

    MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpEv, s->ctlp.mBuf);
  }

#ifdef ZJ
  MA_UPD_INV(dlgCp, cmpCp, CMPFTHA_ACTN_DEL)
  MA_UPD_PEER(dlgCp->upd)
#endif
  maStopTmr(MA_GAURD_TMR,(MaSap *)NULLP,cmpCp);
  /* remove the component control point */
  maRemHashInv(dlgCp, invkId,FALSE);
  RETVALUE(ROK);
} /* end of MaUiMatLocServRsp */

#endif
#endif

#endif /* (MAP_REL98 || MAP_REL99) */

#if (MAP_MSC || MAP_HLR || MAP_GSN)
/*
*
*       Fun:   maEncSMErr    
*
*       Desc:  This function encodes the SM Error parameter  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy3.c
*
*/
  
#ifdef ANSI
PRIVATE Buffer *maEncSMErr 
(
MaSap    *s,            /* MAp Sap */
MaUsrErr *usrErr        /* User Error */
)
#else
PRIVATE Buffer *maEncSMErr (s, usrErr)
MaSap    *s;                /* MAp Sap */
MaUsrErr *usrErr;       /* User Error event structure */
#endif
{
  MaDlgCp    *dlgCp;
  MaSMErr    *errEvnt;        
  U8         maVer;
  U8         i;
  S16        ret;
  MsgLen     msgLen;
  Buffer     *mBuf;
  Data       pkArray[MF_SIZE_TKNSTRE + 20];

  TRC2(maEncSMErr)

  msgLen = 0;
  if((ret = SGetMsg(s->maPstST.region, s->maPstST.pool, &mBuf)) != ROK)
  {
     RETVALUE(NULLP);
  }
  dlgCp = s->curDlgCp;

  if ((dlgCp->apn.pres == FALSE) || 
      (dlgCp->apn.val[dlgCp->apn.len-1] == LMA_VER1))
  {
     maVer = LMA_VER1;
  }
  else
  {
     maVer = LMA_VER2;
  } 
  errEvnt = &usrErr->smErr;
  if (maVer == LMA_VER1)
  {
    if (errEvnt->smFailCause.pres == TRUE)
    {
       pkArray[0] = (Data)MA_TAG_ENUM;
       pkArray[1] = (Data)1;
       pkArray[2] = errEvnt->smFailCause.val;
       ret = SAddPstMsgMult(pkArray, (MsgLen)3, mBuf);
       if (ret != ROK)
       {
#if (ERRCLASS & ERRCLS_ADD_RES)
          MALOGERROR(ERRCLS_ADD_RES, EMA171, (ErrVal)ret, "SAddPstMsgMult () Failed");
#endif
          (Void)SPutMsg(mBuf);
          RETVALUE(NULLP);
       }
       RETVALUE(mBuf);
    }
    else
    {
      SPutMsg(mBuf);
      RETVALUE(NULLP); 
    }
  }
  else
  {
    pkArray[0] = (Data)MA_TAG_SEQ;
    pkArray[1] = (Data)MA_EOC_LEN;
    msgLen = 2;
    if (errEvnt->smFailCause.pres == TRUE)
    {
       pkArray[2] = MA_TAG_ENUM;
       pkArray[3] = (Data)1;
       pkArray[4] = (Data)errEvnt->smFailCause.val;
       msgLen = 5;
    }
    else
    {
      (Void)SPutMsg(mBuf);
      RETVALUE(NULLP);
    }

    if (errEvnt->diagInfo.pres == TRUE)
    {
      pkArray[msgLen] = (Data)MA_TAG_OCTSTR;
      msgLen++;
      if (errEvnt->diagInfo.len <= 127)
      {
         pkArray[msgLen] = (Data)errEvnt->diagInfo.len;
         msgLen++;
      } 
      else
      {
         pkArray[msgLen] = (Data)MA_LEN_1_BYTE;
         pkArray[msgLen+1] = (Data)errEvnt->diagInfo.len;
         msgLen += 2;
      }
      /* encode the value */

      for (i=0; i< errEvnt->diagInfo.len; i++)
      {
         pkArray[msgLen] = (Data)errEvnt->diagInfo.val[i];
         msgLen++;
      } 
    }
#ifndef MA_ASN_NO_INDEF_LEN
    pkArray[msgLen] = (Data)MA_TAG_EOC;
    pkArray[msgLen+1] = (Data)MA_TAG_EOC;
    msgLen += 2;
#endif
  }
  ret = SAddPstMsgMult(pkArray, (MsgLen)msgLen, mBuf);
  if (ret != ROK)
  {
#if (ERRCLASS & ERRCLS_ADD_RES)
     MALOGERROR(ERRCLS_ADD_RES, EMA172, (ErrVal)ret, "SAddPstMsgMult () Failed");
#endif
     (Void)SPutMsg(mBuf);
     RETVALUE(NULLP);
  }
#ifdef MA_ASN_NO_INDEF_LEN
  /* check the maximum value that can fit in a signed byte value */
  if ((msgLen-2) <= MA_MAX_SBYTE_VAL)
  {
     ret = SRepMsg((U8)(msgLen-2), mBuf, 1);
     if (ret != ROK)
     {
#if (ERRCLASS & ERRCLS_ADD_RES)
        MALOGERROR(ERRCLS_DEBUG, EMA173, (ErrVal)ret, "SRepMsg() Failed");
#endif
        (Void)SPutMsg(mBuf);
        RETVALUE(NULLP);
     }
  }
  else
  {
     if ((ret = maEncLen(mBuf, 2, msgLen)) != ROK)
     {
        (Void)SPutMsg(mBuf);
        MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, 
              "maEncSMErr(): maEncLen failed, Len(%d).\n", (msgLen)));
        RETVALUE(NULLP);
     }
  }
#endif /* MA_ASN_NO_INDEF_LEN */

  RETVALUE(mBuf);
} /* maEncSMErr  */
#endif /* MAP_MSC || MAP_HLR || MAP_GSN */


#if (MAP_VLR || MAP_HLR)
/*
*
*       Fun:   maEncSSErr    
*
*       Desc:  This function encodes the SS Error parameter  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy3.c
*
*/
  
#ifdef ANSI
PRIVATE Buffer *maEncSSErr 
(
MaSap   *s,               /* MAp Sap */
MaUsrErr *usrErr          /* User Error */
)
#else
PRIVATE Buffer *maEncSSErr (s, usrErr )
MaSap   *s;               /* MAp Sap */
MaUsrErr *usrErr;         /* User Error */
#endif
{
  MaDlgCp    *dlgCp;
  MaSSErr *errEvnt;
  Buffer     *mBuf;
  S16        ret;
  MsgLen     msgLen;
  Data       pkArray[20];  /* Note: the max. length required is for MA_SS_INCOMP_ERR
                            * error (16) when all the optional elements are 
                            * present 
                            */

  TRC2(maEncSSErr)
  msgLen = 0; 
  if((ret = SGetMsg(s->maPstST.region, s->maPstST.pool, &mBuf)) != ROK)
  {
     RETVALUE(NULLP);
  }

  dlgCp = s->curDlgCp;


  errEvnt = &usrErr->ssErr;

  switch (usrErr->errCode)
  {
    case MAT_SS_STATUS_ERR:
      if (errEvnt->ssStatus.pres == TRUE)
      {
         pkArray[0] = (Data)MA_TAG_OCTSTR;
         pkArray[1] = (Data)1;
         pkArray[2] = (Data)errEvnt->ssStatus.val;
         msgLen = 3;
      }
      else
      {
        (Void)SPutMsg(mBuf);
        RETVALUE(NULLP);
        
      }
      break;
    case MAT_SS_SUBSVIOL_ERR:
      if ((errEvnt->cliRestOpt.pres == TRUE) ||
         (errEvnt->ovrRideCat.pres == TRUE))
      {
         pkArray[0] = (Data)MA_TAG_OCTSTR;
         pkArray[1] = (Data)1;
         if (errEvnt->cliRestOpt.pres == TRUE)
         {
            pkArray[2] = (Data)errEvnt->cliRestOpt.val;
         }
         else
         {
            pkArray[2] = (Data)errEvnt->ovrRideCat.val;
         }
         msgLen = 3;
      }
      else
      {
        (Void)SPutMsg(mBuf);
        RETVALUE(NULLP);
      }
      break;
    case MAT_SS_INCOMP_ERR:

     if( (errEvnt->ssStatus.pres == TRUE) || (errEvnt->bearServ.pres == TRUE) ||
         (errEvnt->teleServ.pres == TRUE) || (errEvnt->ssCode.pres == TRUE))
     {
       pkArray[0] = (Data)MA_TAG_SEQ;
       pkArray[1] = (Data)MA_EOC_LEN;
       msgLen = 2;
       if (errEvnt->ssCode.pres == TRUE)
       {
           pkArray[msgLen] = (Data)MA_TAG_CSPRIM1;
           pkArray[msgLen + 1] = (Data)1;
           pkArray[msgLen + 2] = (Data)errEvnt->ssCode.val;
           msgLen += 3;

       }

       if (errEvnt->bearServ.pres == TRUE)
       {
           pkArray[msgLen] = (Data)MA_TAG_CSPRIM2;
           pkArray[msgLen + 1] = (Data)1;
           pkArray[msgLen + 2] = (Data)errEvnt->bearServ.val;
           msgLen += 3;
          
       }
       if (errEvnt->teleServ.pres == TRUE)
       {
           pkArray[msgLen] = (Data)MA_TAG_CSPRIM3;
           pkArray[msgLen + 1] = (Data)1;
           pkArray[msgLen + 2] = (Data)errEvnt->teleServ.val;
           msgLen += 3;
          
       }
       if (errEvnt->ssStatus.pres == TRUE)
       {
           pkArray[msgLen] = (Data)MA_TAG_CSPRIM4;
           pkArray[msgLen + 1] = (Data)1;
           pkArray[msgLen + 2] = (Data)errEvnt->ssStatus.val;
           msgLen += 3;
       }
#ifdef MA_ASN_NO_INDEF_LEN
       /* Note: the max. length required for MA_SS_INCOMP_ERR
        * can not ne more than 128, so we don't need to consider 
        * long form length encoding here.
        */
       pkArray[1] = (Data)(msgLen-2);
#else
       pkArray[msgLen] = (Data)MA_TAG_EOC;
       pkArray[msgLen +1] = (Data)MA_TAG_EOC;
       msgLen += 2;
#endif
     }
     else
     {
        (Void)SPutMsg(mBuf);
        RETVALUE(NULLP);
     }
     break;
    case MAT_PASSWD_REG_ERR:
     if (usrErr->val != MAT_INV_USR_ERRVAL)
     {
        pkArray[0] = (Data)MA_TAG_ENUM;
        pkArray[1] = (Data)1;
        pkArray[2] = (Data)usrErr->val; 
        msgLen = 3;
     }
     else
     {
        (Void)SPutMsg(mBuf);
        RETVALUE(NULLP);
     }
     break;
  }
  ret = SAddPstMsgMult(pkArray, (MsgLen)msgLen, mBuf);
  if (ret != ROK)
  {
#if (ERRCLASS & ERRCLS_ADD_RES)
     MALOGERROR(ERRCLS_ADD_RES, EMA174, (ErrVal)ret, "SAddPstMsgMult () Failed");
#endif
     (Void)SPutMsg(mBuf);
     RETVALUE(NULLP);
  }
  RETVALUE(mBuf);
} /* maEncSSErr  */

#endif /* MAP_HLR */


/*
*
*       Fun:   maEncOpr    
*
*       Desc:  This function encodes the operation   
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy3.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maEncOpr 
(
MaSap  *s,              /* MAP Sap */
U8     *evPtr,          /* Pointer to event structure */
U8     oprType,         /* Operation to be encoded */
U8     encType          /* Encode type */
)
#else
PUBLIC S16 maEncOpr (s,evPtr, oprType, encType)
MaSap  *s;              /* MAP Sap */
U8     *evPtr;          /* Pointer to event structure */
U8     oprType;         /* Operation to be encoded */
U8     encType;         /* Encode type */
#endif
{
  MaDlgCp   *dlgCp;
  U8        maVer;
  S16       ret;

  TRC2(maEncOpr)

  dlgCp = s->curDlgCp;
  ret = RFAILED;
  maVer = dlgCp->apn.val[dlgCp->apn.len-1];

#ifdef MA_SEG
  /* For responses, initializing the segment size based on the oprType */
  if(encType == MAT_SS_RSP)
  { 
     /* Check for the segmentation rules if any */
     ret = maChkSegRules(s,(PTR)evPtr,oprType,maVer);
     if(ret != ROK)
     {
        RETVALUE(ret);
     }
     /* configured segment sizes are assigned to the encoder control struct */
#if MAP_REL99
#if MAP_SEC
     /* The worst case, encoding for security header and message 
      * authentication code (MAC) will introduce 44 byte overhead for 
      * return result component. If segmentation is used in a secure 
      * dialogue, the length has to be subtracted from maximum frame 
      * size configured.
      */
     if ((dlgCp->mapSec == TRUE) && (maCb.maCP.sigFrameSz != 0))
     {
       if (maCb.maCP.sigFrameSz <= MA_MAX_SEC_HDR_LEN)
        {
#if (ERRCLASS & ERRCLS_DEBUG)
           MALOGERROR(ERRCLS_DEBUG, EMA175, (ErrVal)oprType, 
                      "maEncOpr () Failed, can not segnent the message");
#endif
           RETVALUE(ret);
        }
        s->ctlp.segSz = (maCb.maCP.sigFrameSz - MA_MAX_SEC_HDR_LEN);
     }
     else
#endif /* MAP_SEC */
#endif /* MAP_REL99 */
     {
        s->ctlp.segSz = maCb.maCP.sigFrameSz;      
     }
  }
  else
  {
     s->ctlp.segSz = 0;
  }
#endif /* MA_SEG */

  switch (oprType)
  {
#ifdef XWEXT 
   case MAT_PAGING_DETECT:
   {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaXWDetectEv *)evPtr)->pagingDetectReq)), maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_XW_DETECT_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaXWDetectEv *)evPtr)->pagingDetectRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_XW_DETECT_RSP);
       }
   }
   break;
#endif

#if (MAP_VLR || MAP_HLR)
   case MAT_REGSS:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->regSSReq)), maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_REGSS_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->regSSRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_REGSS_RSP);
       }
     }
     break;
   case MAT_ERASESS:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s, (U8 *)(&(((MaSSEv *)evPtr)->eraseSSReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_ERASESS_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->eraseSSRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_ERASE_SS_RSP);
       }
     }
     break;
   case MAT_ACTVSS:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->actvSSReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_ACTVSS_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->actvSSRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_ACTVSS_RSP);
       }
     }
     break;
   case MAT_DACTVSS:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->dactvSSReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_DACTVSS_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->dactvSSRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_DACTVSS_RSP);
       }
     }
     break;
   case MAT_INTERSS:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->interSSReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_INTERSS_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->interSSRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_INTERSS_RSP);
       }
     }
     break;
   case MAT_REGPASSWD:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->regPasswdReq)), maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_REGPASSWD_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->regPasswdRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_REGPASSWD_RSP);
       }
     }
     break;
   case MAT_GETPASSWD:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->getPasswdReq)), maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_GETPASSWD_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->getPasswdRsp)), maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_GETPASSWD_RSP);
       }
     }
     break;
   case MAT_PROCUSSREQ:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->procUssReqReq)),maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_PROCUSS_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->procUssReqRsp)),maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_PROCUSS_RSP);
       }
     }
     break;
   case MAT_PROCUSSDATA:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->procUssDatReq)),maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_PROCUSSDAT_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->procUssDatRsp)),maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_PROCUSSDAT_RSP);
       }
     }
     break;
   case MAT_USSREQ:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->ussReqReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_USS_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->ussReqRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_USS_RSP);
       }
     }
     break;
   case MAT_USSNOTIFY:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->ussNotifyReq)), maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_USSNOTIFY_REQ);
       }
       else
       {
         ret = ROK;
         s->ctlp.mBuf = NULLP;
       }
     }
     break;
#endif /* VLR || HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_SMRDY:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSMEv *)evPtr)->smRdyReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_SMRDY_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaSMEv *)evPtr)->smRdyRsp)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_SMRDY_RSP);
       }
     }
     break;
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if MAP_MSC
   case MAT_DET_IMSI:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaLocEv *)evPtr)->detIMSIReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_DET_IMSI_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA176, (ErrVal)oprType, "maEncOpr () Failed");
#endif
       }
     }
     break;
#endif   /* MSC */
 
#if (MAP_MSC || MAP_VLR || MAP_GSN)

   case MAT_CHKIMEI:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaIMEIEv *)evPtr)->imeiReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_CHKIMEI_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaIMEIEv *)evPtr)->imeiRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_CHKIMEI_RSP);
       }
     }
     break;
#endif /* MAP_MSC || MAP_VLR || MAP_GSN */
 
#if MAP_MSC

   case MAT_TRACESUBSACTV:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaOAMEv *)evPtr)->trSubsActvReq)),maVer,
                            (U8)s->cfg.swtch, encType, MA_MI_TRACESUBSACTV_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA177, (ErrVal)oprType, "maEncOpr () Failed");
#endif
       }
     }
     break;
#endif   /* MSC */

#if (MAP_MSC || MAP_HLR)
   case MAT_ROUTINFO:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->sndRoutInfoReq)),
                           maVer, (U8)s->cfg.swtch, encType, MA_MI_ROUTINFO_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->sndRoutInfoRsp)),  
                           maVer, (U8)s->cfg.swtch, encType, MA_MI_ROUTINFO_RSP);
       }
     }
     break;
   case MAT_ROUTINFOSM:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSMEv *)evPtr)->routInfoSMReq)),maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_ROUTINFOSM_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaSMEv *)evPtr)->routInfoSMRsp)),maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_ROUTINFOSM_RSP);
       }
     }
     break;
   case MAT_SMDEL:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSMEv *)evPtr)->repSMDelReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_SMDEL_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaSMEv *)evPtr)->repSMDelRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_SMDEL_RSP);
       }
     }
     break;
   case MAT_ALRTSC:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSMEv *)evPtr)->alrtSCReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_ALRTSC_REQ);
       }
       else
       {
         ret = ROK;
         s->ctlp.mBuf = NULLP;
       }

     }
     break;
   case MAT_ALRTSCWRSLT:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSMEv *)evPtr)->alrtSCWRsltReq)), maVer,
                            (U8)s->cfg.swtch, encType, MA_MI_ALRTSCWRSLT_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA178, (ErrVal)oprType, "maEncOpr () Failed");
#endif
       }
     }
     break;
   case MAT_INFSC:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSMEv *)evPtr)->infSCReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_INFSC_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA179, (ErrVal)oprType, "maEncOpr () Failed");
#endif
       }
     }
     break;

   case MAT_SSINV_NOTIFY:
     {
/* ma013.203 : Correction SS_INVOKE_NOTIFY is moved in SS Service */
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->ssInvNotReq)),maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_SSINV_NOTIFY_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaSSEv *)evPtr)->ssInvNotRsp)),maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_SSINV_NOTIFY_RSP);
       }
     }
     break;
#endif  /* MSC || HLR */


#if MAP_REL99
#if (MAP_MSC || MAP_HLR)

   case MAT_IST_ALERT:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->istAlertReq)),maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_ISTALRT_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->istAlertRsp)),maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_ISTALRT_RSP);
       }
     }
     break;

   case MAT_IST_COMMAND:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->istCmdReq)),maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_ISTCMD_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->istCmdRsp)),maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_ISTCMD_RSP);
       }
     }
     break;

#endif /* MAP_MSC || MAP_HLR */

#if MAP_MSC
#if MAP_REL6 
     
   case MAT_REL_RES:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->relResReq)),maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_RELRES_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->relResRsp)),maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_RELRES_RSP);
       }
     }
     break;

#endif /* MAP_REL6 */
#endif /* MAP_MSC */

#endif /* MAP_REL99 */

#if (MAP_VLR || MAP_HLR)
   case MAT_UPLOC:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaLocEv *)evPtr)->upLocReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_UPLOC_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaLocEv *)evPtr)->upLocRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_UPLOC_RSP);
       }
     }
     break;
#endif /* MAP_VLR || MAP_HLR */
 
#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_CANCELLOC:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaLocEv *)evPtr)->canLocReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_CANCELLOC_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaLocEv *)evPtr)->canLocRsp)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_CANCELLOC_RSP);
       }
     }
     break;
   case MAT_PURGE:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaLocEv *)evPtr)->purgeMsReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_PURGE_REQ);
       }
       else
       {
           ret = maEncOprPar(s,(U8 *)(&(((MaLocEv *)evPtr)->purgeMsRsp)),maVer, 
                              (U8)s->cfg.swtch, encType, MA_MI_PURGE_RSP);

       }
     }
     break;
     
   case MAT_AUTHINFO:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaAuthEv *)evPtr)->authInfoReq)),maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_AUTHINFO_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaAuthEv *)evPtr)->authInfoRsp)),maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_AUTHINFO_RSP);
       }
     }
     break;
   case MAT_INSSUBSDATA:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s, (U8 *)(&(((MaSubEv *)evPtr)->isdReq)), maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_INSSUBSDATA_REQ);
       }
       else
       {
         ret = maEncOprPar(s, (U8 *)(&(((MaSubEv *)evPtr)->isdRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_INSSUBSDATA_RSP);
       }
     }
     break;
   case MAT_DELSUBSDATA:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s, (U8 *)(&(((MaSubEv *)evPtr)->dsdReq)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_DELSUBSDATA_REQ);
       }
       else
       {
         ret = maEncOprPar(s, (U8 *)(&(((MaSubEv *)evPtr)->dsdRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_DELSUBSDATA_RSP);
       }
     }
     break;

   case MAT_RESET:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s, (U8 *)(&(((MaFREv *)evPtr)->resetReq)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_RESET_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA180, (ErrVal)oprType, "maEncOpr () Failed");
#endif
       }
     }
     break;

   case MAT_SNDPARAM:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s, (U8 *)(&(((MaSubEv *)evPtr)->sndParamReq)), maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_SNDPARAM_REQ);
       }
       else
       {
         ret = maEncOprPar(s, (U8 *)(&(((MaSubEv *)evPtr)->sndParamRsp)), maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_SNDPARAM_RSP);
       }
     }
     break;
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */
 
#if (MAP_VLR || MAP_HLR)
  case MAT_RESTOREDATA:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaFREv *)evPtr)->restDatReq)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_RESTOREDATA_REQ);
       }
       else
       {
         ret = maEncOprPar(s, (U8 *)(&(((MaFREv *)evPtr)->restDatRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_RESTOREDATA_RSP);
       }
     }
     break;
#endif /* MAP_VLR || MAP_HLR */
 
#if (MAP_VLR || MAP_HLR)
   case MAT_FWDCHKSSIND:
     s->ctlp.mBuf = NULLP;
     ret = ROK;
     break;
#endif /* VLR || HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)

   case MAT_ACTVTRACE:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s, (U8 *)(&(((MaOAMEv *)evPtr)->actvTrReq)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_ACTVTRACE_REQ);
       }
       else
       {
         ret = maEncOprPar(s, (U8 *)(&(((MaOAMEv *)evPtr)->actvTrRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_ACTVTRACE_RSP);
       }
     }
     break;
   case MAT_DACTVTRACE:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s, (U8 *)(&(((MaOAMEv *)evPtr)->dactvTrReq)), maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_DACTVTRACE_REQ);
       }
       else
       {
         ret = maEncOprPar(s, (U8 *)(&(((MaOAMEv *)evPtr)->dactvTrReq)), maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_DACTVTRACE_RSP);
       }
     }
     break;

#if MAP_REL99

  case MAT_AUTHFAILRPT:

     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s, (U8 *)(&(((MaAuthEv *)evPtr)->authFailRptReq)), maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_AUTHFAILRPT_REQ);
       }
       else
       {
         ret = maEncOprPar(s, (U8 *)(&(((MaAuthEv *)evPtr)->authFailRptRsp)), maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_AUTHFAILRPT_RSP);
       }
     }
     break;

   case MAT_NOTE_MMEVT:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaLocEv *)evPtr)->noteMmEventReq)),
               maVer,(U8)s->cfg.swtch, encType, MA_MI_NOTMMEV_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaLocEv *)evPtr)->noteMmEventRsp)),
               maVer,(U8)s->cfg.swtch, encType, MA_MI_NOTMMEV_RSP);
       }
     }
     break;

#endif /* MAP_REL99 */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */
 
#if (MAP_VLR || MAP_HLR)

   case MAT_SNDIMSI:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s, (U8 *)(&(((MaOAMEv *)evPtr)->sndImsiReq)), maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_SNDIMSI_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaOAMEv *)evPtr)->sndImsiRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_SNDIMSI_RSP);
       }
     }
     break;

   case MAT_BEGIN_SUBS_ACTV:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s, (U8 *)(&(((MaSSEv *)evPtr)->bgnSubActvReq)),maVer,
                           (U8)s->cfg.swtch, encType, MA_MI_BGNSUBSACTV_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA181, (ErrVal)oprType, "maEncOpr () Failed");
#endif
       }
     }
     break;
   case MAT_PROVROAMNMB:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s, (U8 *)(&(((MaCallEv *)evPtr)->roamNmbReq)), maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_PROVROAMNMB_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->roamNmbRsp)), maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_PROVROAMNMB_RSP);
       }
     }
     break;

   case MAT_NOTSUBPRES:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s, (U8 *)(&(((MaSMEv *)evPtr)->notSubPresReq)),maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_NOTSUBPRES_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA182, (ErrVal)oprType, "maEncOpr () Failed");
#endif
       }
     }
     break;
   case MAT_SETRPTSTATE:
     {
       if (encType == MAT_SS_REQ)
       {

         ret=maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->setRptStateReq)),
               maVer,(U8)s->cfg.swtch, encType, MA_MI_SETRPTSTATE_REQ);
       }
       else
       {
         ret=maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->setRptStateRsp)),
               maVer,(U8)s->cfg.swtch, encType, MA_MI_SETRPTSTATE_RSP);
       }
     }
     break;
   case MAT_STARPT:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s, (U8 *)(&(((MaCallEv *)evPtr)->staRptReq)),
               maVer,(U8)s->cfg.swtch, encType, MA_MI_STARPT_REQ);
       }
       else
       {
         ret = maEncOprPar(s, (U8 *)(&(((MaCallEv *)evPtr)->staRptRsp)),
               maVer,(U8)s->cfg.swtch, encType, MA_MI_STARPT_RSP);
       }
     }
     break;
   case MAT_RMTUSRFREE:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->rmtUsrFreeReq)),
               maVer,(U8)s->cfg.swtch, encType, MA_MI_RMTUSRFREE_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->rmtUsrFreeRsp)),
               maVer,(U8)s->cfg.swtch, encType, MA_MI_RMTUSRFREE_RSP);
       }
     }
     break;

#endif  /* VLR || HLR */

#if (MAP_VLR || MAP_HLR)
   case MAT_REGCCENT:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s, (U8 *)(&(((MaSSEv *)evPtr)->regCcEntReq)),
               maVer,(U8)s->cfg.swtch, encType, MA_MI_REGCCENT_REQ);
       }
       else
       {
         ret = maEncOprPar(s, (U8 *)(&(((MaSSEv *)evPtr)->regCcEntRsp)),
               maVer,(U8)s->cfg.swtch, encType, MA_MI_REGCCENT_RSP);
       }
     }
     break;
   case MAT_ERASECCENT:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s, (U8 *)(&(((MaSSEv *)evPtr)->eraseCcEntReq)),
               maVer,(U8)s->cfg.swtch, encType, MA_MI_ERASECCENT_REQ);
       }
       else
       {
         ret = maEncOprPar(s, (U8 *)(&(((MaSSEv *)evPtr)->eraseCcEntRsp)),
               maVer,(U8)s->cfg.swtch, encType, MA_MI_ERASECCENT_RSP);
       }
     }
     break;
#endif /* VLR || HLR */

#if MAP_MSC
   case MAT_PRE_HO:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaHoEv *)evPtr)->preHoReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_PREHO_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaHoEv *)evPtr)->preHoRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_PREHO_RSP);
       }
     }
     break;
   case MAT_PER_HO:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaHoEv *)evPtr)->perHoReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_PERHO_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaHoEv *)evPtr)->perHoRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_PERHO_RSP);
       }
     }
     break;
   case MAT_SNDENDSIG:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaHoEv *)evPtr)->sndEndSigReq)), maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_SNDENDSIG_REQ);
       }
       else
       {
#if MAP_REL99

         ret = maEncOprPar(s,(U8 *)(&(((MaHoEv *)evPtr)->sndEndSigRsp)), maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_SNDENDSIG_RSP);

#else /* MAP_REL99 */
         s->ctlp.mBuf = NULLP;
         ret = ROK; 
#endif /* MAP_REL99 */
       }
     }
     break;
   case MAT_PROCACCSIG:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaHoEv *)evPtr)->procAccSigReq)),maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_PROCACCSIG_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA183, (ErrVal)oprType, "maEncOpr () Failed");
#endif
       }
     }
     break;
   case MAT_FWDACCSIG:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaHoEv *)evPtr)->fwdAccSigReq)), maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_FWDACCSIG_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA184, (ErrVal)oprType, "maEncOpr () Failed");
#endif
       }
     }
     break;
   case MAT_PRE_SUBSHO:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaHoEv *)evPtr)->preSubHoReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_PRESUBSHO_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaHoEv *)evPtr)->preSubHoRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_PRESUBSHO_RSP);
       }
     }
     break;
   case MAT_PER_SUBSHO:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaHoEv *)evPtr)->perSubHoReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_PERSUBSHO_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaHoEv *)evPtr)->perSubHoReq)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_PERSUBSHO_RSP);
       }
     }
     break;
   case MAT_NOTEINTERHO:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaOAMEv *)evPtr)->interHoReq)), maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_NOTEINTERHO_REQ);
       }
       else
       {
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA185, (ErrVal)oprType, "maEncOpr () Failed");
#endif
       }
     }
     break;

#endif /* MAP_MSC */
 
#if (MAP_MSC || MAP_GSN)

   case MAT_FWDSM:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSMEv *)evPtr)->fwdSMReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_FWDSM_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaSMEv *)evPtr)->fwdSMRsp)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_FWDSM_RSP);
       }
     }
     break;
   case MAT_MT_FWDSM:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSMEv *)evPtr)->mtFwdSMReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_MTFWDSM_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaSMEv *)evPtr)->mtFwdSMRsp)),  maVer, 
                           (U8)s->cfg.swtch, encType, MA_MI_MTFWDSM_RSP);
       }
     }
     break;

#endif /* MAP_MSC || MAP_GSN */
 
#if MAP_MSC

   case MAT_RESCALLHANDL:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->resCallHandlReq)),  
                        maVer,(U8)s->cfg.swtch, encType, MA_MI_RESCALLHANDL_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->resCallHandlRsp)),  
                        maVer,(U8)s->cfg.swtch, encType, MA_MI_RESCALLHANDL_RSP);
       }
     }
     break;
   case MAT_PREP_GRPCALL:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->prepGrpCallReq)),  
                     maVer,(U8)s->cfg.swtch, encType, MA_MI_PREPGRPCALL_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->prepGrpCallRsp)),  
                     maVer,(U8)s->cfg.swtch, encType, MA_MI_PREPGRPCALL_RSP);
       }
     }
     break;
   case MAT_PRO_GRPCALLSIG:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->proGrpCallSigReq)),  
                    maVer,(U8)s->cfg.swtch, encType, MA_MI_PROGRPCALLSIG_REQ);
       }
       else
       {
         ret = ROK;
         s->ctlp.mBuf = NULLP;
       }
     }
     break;
   case MAT_FWD_GRPCALLSIG:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->fwdGrpCallSigReq)),  
                      maVer,(U8)s->cfg.swtch, encType, MA_MI_FWDGRPCALLSIG_REQ);
       }
       else
       {
         ret = ROK;
         s->ctlp.mBuf = NULLP;
       }
     }
     break;
   case MAT_SND_GRPCALLENDSIG:
     {
       if (encType == MAT_SS_REQ)
       {

         ret=maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->sndGrpCallEndSigReq)),  
                      maVer,(U8)s->cfg.swtch, encType, MA_MI_SNDGRPCALLENDSIG_REQ);
       }
       else
       {
         ret=maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->sndGrpCallEndSigRsp)),  
                      maVer,(U8)s->cfg.swtch, encType, MA_MI_SNDGRPCALLENDSIG_RSP);
       }
     }
     break;
   case MAT_PROV_SIWFS_NMB:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->provSiwfsNmbReq)),  
                      maVer,(U8)s->cfg.swtch, encType, MA_MI_PROVSIWFSNMB_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->provSiwfsNmbRsp)),  
                     maVer,(U8)s->cfg.swtch, encType, MA_MI_PROVSIWFSNMB_RSP);
       }
     }
     break;
   case MAT_SIWFS_SIGMOD:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->siwfsSigModReq)),  
                      maVer, (U8)s->cfg.swtch, encType, MA_MI_SIWFSSIGMOD_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaCallEv *)evPtr)->siwfsSigModRsp)),  
                     maVer, (U8)s->cfg.swtch, encType, MA_MI_SIWFSSIGMOD_RSP);
       }
     }
     break;
#endif  /* MSC */

#if MAP_VLR
  /* Send Identification Request */
  case MAT_SNDID:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaLocEv *)evPtr)->sendIdReq)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_SNDID_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaLocEv *)evPtr)->sendIdRsp)),  maVer, 
                            (U8)s->cfg.swtch, encType, MA_MI_SNDID_RSP);
       }
     }
     break;
#endif  /* MAP_VLR */

#if (MAP_HLR || MAP_MLC)

   case MAT_ANY_INTER:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSubEv *)evPtr)->anyInterReq)),  
                      maVer, (U8)s->cfg.swtch, encType, MA_MI_ANYINTER_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaSubEv *)evPtr)->anyInterRsp)),  
                     maVer, (U8)s->cfg.swtch, encType, MA_MI_ANYINTER_RSP);
       }
     }
     break;

#if (MAP_REL98 || MAP_REL99)

   case MAT_SENDROUTINFOFORLCS:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaLocServEv *)evPtr)->routInfoForLcsReq)),  
                      maVer, (U8)s->cfg.swtch, encType, MA_MI_ROUTINFOFORLCS_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaLocServEv *)evPtr)->routInfoForLcsRsp)),  
                     maVer, (U8)s->cfg.swtch, encType, MA_MI_ROUTINFOFORLCS_RSP);
       }
     }
     break; 

#endif /* MAP_REL98 || MAP_REL99 */
#endif /* MAP_HLR || MAP_MLC */

#if (MAP_HLR || MAP_GSN)
   case MAT_GPRS_UPLOC:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaLocEv *)evPtr)->gprsUpLocReq)),  
                      maVer, (U8)s->cfg.swtch, encType, MA_MI_GPRSUPLOC_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaLocEv *)evPtr)->gprsUpLocRsp)),  
                     maVer, (U8)s->cfg.swtch, encType, MA_MI_GPRSUPLOC_RSP);
       }
     }
     break;
   case MAT_GPRS_ROUTINFO:
     {
       if (encType == MAT_SS_REQ)
       {

         ret=maEncOprPar(s,(U8 *)(&(((MaPdpActvEv *)evPtr)->gprsRoutInfoReq)),  
                      maVer, (U8)s->cfg.swtch, encType, MA_MI_GPRSROUTINFO_REQ);
       }
       else
       {
         ret=maEncOprPar(s,(U8 *)(&(((MaPdpActvEv *)evPtr)->gprsRoutInfoRsp)),  
                     maVer, (U8)s->cfg.swtch, encType, MA_MI_GPRSROUTINFO_RSP);
       }
     }
     break;
   case MAT_GPRS_NOTEMSPRES:
     {
       if (encType == MAT_SS_REQ)
       {

        ret=maEncOprPar(s,(U8 *)(&(((MaPdpActvEv *)evPtr)->gprsNoteMsPresReq)), 
                      maVer, (U8)s->cfg.swtch, encType, MA_MI_GPRSNOTEMSPRES_REQ);
       }
       else
       {
         ret=maEncOprPar(s,(U8 *)(&(((MaPdpActvEv *)evPtr)->gprsNoteMsPresRsp)),  
                     maVer, (U8)s->cfg.swtch, encType, MA_MI_GPRSNOTEMSPRES_RSP);
       }
     }
     break;
   case MAT_FAILRPT:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaPdpActvEv *)evPtr)->failRptReq)),  
                      maVer, (U8)s->cfg.swtch, encType, MA_MI_FAILRPT_REQ);
       }
       else
       {
         ret=maEncOprPar(s,(U8 *)(&(((MaPdpActvEv *)evPtr)->failRptRsp)),  
                     maVer, (U8)s->cfg.swtch, encType, MA_MI_FAILRPT_RSP);
       }
     }
     break;
#endif  /*(MAP_HLR || MAP_GSN)*/

#if (MAP_VLR || MAP_HLR || MAP_GSN)
#if (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5))
   case MAT_PROVSUBSINFO:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSubEv *)evPtr)->provSubsInfoReq)),  
                      maVer, (U8)s->cfg.swtch, encType, MA_MI_PROVSUBSINFO_REQ);
       }
       else
       {
         ret = maEncOprPar(s,(U8 *)(&(((MaSubEv *)evPtr)->provSubsInfoRsp)),  
                     maVer, (U8)s->cfg.swtch, encType, MA_MI_PROVSUBSINFO_RSP);
       }
     }
     break;
#endif  /* (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5)) */ 
#endif  /*(MAP_VLR || MAP_HLR)*/

#if MAP_REL99

#if MAP_HLR

   case MAT_ANY_SUBSDATA_INTER:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSubEv *)evPtr)->anySubsInterReq)),  
                      maVer, (U8)s->cfg.swtch, encType, MA_MI_ANYSUBSINTER_REQ);
       }
       else
       {
         ret=maEncOprPar(s,(U8 *)(&(((MaSubEv *)evPtr)->anySubsInterRsp)),  
                     maVer, (U8)s->cfg.swtch, encType, MA_MI_ANYSUBSINTER_RSP);
       }
     }
     break;

   case MAT_ANY_MOD:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSubEv *)evPtr)->anyModReq)),  
                      maVer, (U8)s->cfg.swtch, encType, MA_MI_ANYMOD_REQ);
       }
       else
       {
         ret=maEncOprPar(s,(U8 *)(&(((MaSubEv *)evPtr)->anyModRsp)),  
                     maVer, (U8)s->cfg.swtch, encType, MA_MI_ANYMOD_RSP);
       }
     }
     break;

   case MAT_NOTE_SUBSDATA_MOD:
     {
       if (encType == MAT_SS_REQ)
       {

         ret = maEncOprPar(s,(U8 *)(&(((MaSubEv *)evPtr)->noteSubsDataModReq)),  
                      maVer, (U8)s->cfg.swtch, encType, MA_MI_NOTSUBSMOD_REQ);
       }
       else
       {
         ret=maEncOprPar(s,(U8 *)(&(((MaSubEv *)evPtr)->noteSubsDataModRsp)),  
                     maVer, (U8)s->cfg.swtch, encType, MA_MI_NOTSUBSMOD_RSP);
       }
     }
     break;

#endif /* MAP_HLR */
   
#endif /* MAP_REL99 */

#if (MAP_REL98 || MAP_REL99)
#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL4 && MAP_GSN))
   case MAT_PROVSUBSLOC:
     {
       if (encType == MAT_SS_REQ)
       {

         ret=maEncOprPar(s,(U8 *)(&(((MaLocServEv *)evPtr)->prvSubsLocReq)),  
                      maVer, (U8)s->cfg.swtch, encType, MA_MI_PRVSUBSLOC_REQ);
       }
       else
       {
         ret=maEncOprPar(s,(U8 *)(&(((MaLocServEv *)evPtr)->prvSubsLocRsp)),  
                     maVer, (U8)s->cfg.swtch, encType, MA_MI_PRVSUBSLOC_RSP);
       }
     }
     break;

   case MAT_SUBSLOCRPT:
     {
       if (encType == MAT_SS_REQ)
       {

         ret=maEncOprPar(s,(U8 *)(&(((MaLocServEv *)evPtr)->subsLocRptReq)),  
                      maVer, (U8)s->cfg.swtch, encType, MA_MI_SUBSLOCRPT_REQ);
       }
       else
       {
         ret=maEncOprPar(s,(U8 *)(&(((MaLocServEv *)evPtr)->subsLocRptRsp)),  
                     maVer, (U8)s->cfg.swtch, encType, MA_MI_SUBSLOCRPT_RSP);
       }
     }
     break;
#endif  /*(MAP_MSC || MAP_MLC || (MAP_REL4 && MAP_GSN))*/
#endif

#endif /* (MAP_REL98 || MAP_REL99) */

   default:
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA186, (ErrVal)oprType, "maEncOpr () Failed");
#endif
     ret = RFAILED;
     break;
  }
#if (ERRCLASS & ERRCLS_INT_PAR)
  if (ret != ROK)
  {
     MALOGERROR(ERRCLS_INT_PAR, EMA187, (ErrVal)oprType, " maEncOpr() Failed in encoding");
  }
#endif
  RETVALUE(ret);

} /* maEncOpr  */

/*
*
*       Fun:   maUpdatTxSts    
*
*       Desc:  This function updates the Statistics for service specific 
               requests and responses transmitted.
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy3.c
*
*/
  
#ifdef ANSI
PRIVATE Void maUpdatTxSts 
(
MaSap  *s,              /* MAP Sap */
U8     oprType,         /* Operation to be encoded */
U8     type             /* Request or Response */
)
#else
PRIVATE Void maUpdatTxSts (s,oprType, type)
MaSap  *s;              /* MAP Sap */
U8     oprType;         /* Operation to be encoded */
U8     type;            /* Request or Response */
#endif
{
  TRC2(maUpdatTxSts)
  switch (oprType)
  {
#ifdef XWEXT
   case MAT_PAGING_DETECT:
     if (type == MAT_SS_REQ)
     {
       s->sts.detectReqTx++;
     }
     else
     {
       s->sts.detectRspTx++;
     }
     break;
#endif
#if (MAP_VLR || MAP_HLR)
   case MAT_REGSS:
     if (type == MAT_SS_REQ)
     {
       s->sts.regSSReqTx++;
     }
     else
     {
       s->sts.regSSRspTx++;
     }
     break;
   case MAT_ERASESS:
     if (type == MAT_SS_REQ)
     {
       s->sts.eraseSSReqTx++;

     }
     else
     {
       s->sts.eraseSSRspTx++;
     }
     break;
   case MAT_ACTVSS:
     if (type == MAT_SS_REQ)
     {
       s->sts.actvSSReqTx++;

     }
     else
     {
       s->sts.actvSSRspTx++;
     }
     break;
   case MAT_DACTVSS:
     if (type == MAT_SS_REQ)
     {
       s->sts.dactvSSReqTx++;
     }
     else
     {
       s->sts.dactvSSRspTx++;
     }
     break;
   case MAT_INTERSS:
     if (type == MAT_SS_REQ)
     {
       s->sts.interSSReqTx++;
     }
     else
     {
       s->sts.interSSRspTx++;
     }
     break;
   case MAT_REGPASSWD:
     if (type == MAT_SS_REQ)
     {
       s->sts.regPasswdReqTx++;
     }
     else
     {
       s->sts.regPasswdRspTx++;
     }
     break;
   case MAT_GETPASSWD:
     if (type == MAT_SS_REQ)
     {
       s->sts.getPasswdReqTx++;
     }
     else
     {
       s->sts.getPasswdRspTx++;
     }
     break;
   case MAT_PROCUSSREQ:
     if (type == MAT_SS_REQ)
     {
       s->sts.procUSSReqTx++;
     }
     else
     {
       s->sts.procUSSRspTx++;
     }
     break;
   case MAT_PROCUSSDATA:
     if (type == MAT_SS_REQ)
     {
       s->sts.procUSSDatReqTx++;
     }
     else
     {
       s->sts.procUSSDatRspTx++;
     }
     break;
   case MAT_USSREQ:
     if (type == MAT_SS_REQ)
     {
       s->sts.ussReqTx++;
     }
     else
     {
       s->sts.ussRspTx++;
     }
     break;
   case MAT_USSNOTIFY:
     if (type == MAT_SS_REQ)
     {
       s->sts.ussNotReqTx++;
     }
     else
     {
       s->sts.ussNotRspTx++;
     }
     break;
#endif /* VLR || HLR */
 
#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_SMRDY:
     if (type == MA_SS_REQ)
     {
        s->sts.smRdyReqTx++;
     }
     else
     {
        s->sts.smRdyRspTx++;
     }
     break;
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */


#if MAP_MSC
   case MAT_DET_IMSI:
     s->sts.detIMSIReqTx++;
     break;
#endif   /* MSC */
 
#if (MAP_MSC || MAP_VLR || MAP_GSN)
   case MAT_CHKIMEI:
     if (type == MAT_SS_REQ)
     {
       s->sts.chkIMEIReqTx++;
     }
     else
     {
       s->sts.chkIMEIRspTx++;
     }
     break;
#endif /* MAP_MSC || MAP_VLR || MAP_GSN */
 
#if MAP_MSC
   case MAT_TRACESUBSACTV:
     s->sts.trSubReqTx++;
     break;
#endif   /* MSC */

#if (MAP_MSC || MAP_HLR)
   case MAT_ROUTINFO:
     if (type == MAT_SS_REQ)
     {
       s->sts.routInfoReqTx++;
     }
     else
     {
       s->sts.routInfoRspTx++;
     }
     break;
#endif   /* MAP_MSC || MAP_HLR */
 
#if (MAP_MSC || MAP_HLR)
   case MAT_ROUTINFOSM:
     if (type == MAT_SS_REQ)
     {
       s->sts.routInfoSMReqTx++;
     }
     else
     {
       s->sts.routInfoSMRspTx++;
     }
     break;
   case MAT_SMDEL:
     if (type == MAT_SS_REQ)
     {
       s->sts.smDelReqTx++;
     }
     else
     {
       s->sts.smDelRspTx++;
     }
     break;
   case MAT_ALRTSC:
     if (type == MAT_SS_REQ)
     {
       s->sts.alrtSCReqTx++;
     }
     else
     {
       s->sts.alrtSCRspTx++;
     }
     break;
   case MAT_ALRTSCWRSLT:
     s->sts.alrtSCWRsltReqTx++;
     break;
   case MAT_INFSC:
     s->sts.infSCReqTx++;
     break;
#endif  /* MSC || HLR */

#if (MAP_VLR || MAP_HLR)
   case MAT_UPLOC:
     if (type == MAT_SS_REQ)
     {
       s->sts.upLocReqTx++;
     }
     else
     {
       s->sts.upLocRspTx++;
     }
     break;
#endif /* MAP_VLR || MAP_HLR */
 
#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_CANCELLOC:
     if (type == MAT_SS_REQ)
     {
       s->sts.canLocReqTx++;
     }
     else
     {
       s->sts.canLocRspTx++;
     }
     break;
   case MAT_PURGE:
     if (type == MAT_SS_REQ)
     {
       s->sts.purgMsReqTx++;
     }
     else
     {
       s->sts.purgMsRspTx++;
     }
     break;
     
   case MAT_AUTHINFO:
     if (type == MAT_SS_REQ)
     {
       s->sts.authInfReqTx++;
     }
     else
     {
       s->sts.authInfRspTx++;
     }
     break;
   case MAT_INSSUBSDATA:
     if (type == MAT_SS_REQ)
     {
       s->sts.insSubReqTx++;
     }
     else
     {
       s->sts.insSubRspTx++;
     }
     break;
   case MAT_DELSUBSDATA:
     if (type == MAT_SS_REQ)
     {
       s->sts.delSubReqTx++;
     }
     else
     {
       s->sts.delSubRspTx++;
     }
     break;

   case MAT_RESET:
     s->sts.resetReqTx++;
     break;
   case MAT_SNDPARAM: 
     if (type == MAT_SS_REQ)
     {
       s->sts.sndParamReqTx++;
     }
     else
     {
       s->sts.sndParamRspTx++;
     }
     break;
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */
 
#if (MAP_VLR || MAP_HLR)

   case MAT_RESTOREDATA:
     if (type == MAT_SS_REQ)
     {
       s->sts.restoreReqTx++;
     }
     else
     {
       s->sts.restoreRspTx++;
     }
     break;
#endif /* MAP_VLR || MAP_HLR */
 
#if (MAP_VLR || MAP_HLR)
   case MAT_FWDCHKSSIND:
     s->sts.fwdChkSSIndReqTx++;
     break;
#endif /* VLR || HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_ACTVTRACE:
     if (type == MAT_SS_REQ)
     {
       s->sts.actvTrReqTx++;
     }
     else
     {
       s->sts.actvTrRspTx++;
     }
     break;
   case MAT_DACTVTRACE:
     if (type == MAT_SS_REQ)
     {
       s->sts.dactvTrReqTx++;
     }
     else
     {
       s->sts.dactvTrRspTx++;
     }
     break;
#if MAP_REL99

  /* Note MM event */
  case MAT_NOTE_MMEVT:
     if (type == MAT_SS_REQ)
     {
        s->sts.notMmEvReqTx++;     /* req Rx */
     }
     else
     {
        s->sts.notMmEvRspTx++;     /* rsp Rx */
     }
     break;

#endif /* MAP_REL99 */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */
 
#if (MAP_VLR || MAP_HLR)

   case MAT_SNDIMSI:
     if (type == MAT_SS_REQ)
     {
       s->sts.sndIMSIReqTx++;
     }
     else
     {
       s->sts.sndIMSIRspTx++;
     }
     break;

   case MAT_PROVROAMNMB:
     if (type == MAT_SS_REQ)
     {
       s->sts.provRoamNmbReqTx++;
     }
     else
     {
       s->sts.provRoamNmbRspTx++;
     }
     break;

   case MAT_NOTSUBPRES:
     s->sts.notSubPresReqTx++;
     break;

   case MAT_BEGIN_SUBS_ACTV:
     s->sts.bgnSubActvReqTx++;
     break;

   case MAT_SETRPTSTATE:
   if(type == MAT_SS_REQ)
   {
      s->sts.setRptStateReqTx++;     /* req Tx */
   }
   else
   {
      s->sts.setRptStateRspTx++;     /* rsp Tx */
   }
   break;

   case MAT_RMTUSRFREE:
   if(type == MAT_SS_REQ)
   {
      s->sts.rmtUsrFreeReqTx++;     /* req Tx */
   }
   else
   {
      s->sts.rmtUsrFreeRspTx++;     /* rsp Tx */
   }
   break;

   case MAT_STARPT:
     if (type == MA_SS_REQ)
     {
        s->sts.staRptReqTx++;     /*   req Tx */
     }
     else
     {
        s->sts.staRptRspTx++;     /*   rsp Tx */
     }
     break;

#endif  /* (VLR || HLR) */

#if (MAP_VLR || MAP_HLR)
   case MAT_REGCCENT:
   if(type == MAT_SS_REQ)
   {
      s->sts.regCcEntReqTx++;     /*reg Cc Ent req Tx */
   }
   else
   {
      s->sts.regCcEntRspTx++;     /*reg Cc Ent rsp Tx */
   }
   break;

   case MAT_ERASECCENT:
   if(type == MAT_SS_REQ)
   {
      s->sts.eraseCcEntReqTx++;     /*erase Cc Ent req Tx */
   }
   else
   {
      s->sts.eraseCcEntRspTx++;     /*erase Cc Ent rsp Tx */
   }
   break;
#endif /* VLR || HLR */

#if MAP_MSC
   case MAT_PRE_HO:
     if (type == MAT_SS_REQ)
     {
       s->sts.preHoReqTx++;
     }
     else
     {
       s->sts.preHoRspTx++;
     }
     break;
   case MAT_PER_HO:
     if (type == MAT_SS_REQ)
     {
       s->sts.perHoReqTx++;
     }
     else
     {
       s->sts.perHoRspTx++;
     }
     break;
   case MAT_SNDENDSIG:
     if (type == MAT_SS_REQ)
     {
        s->sts.sndEndSigReqTx++;
     }
     else
     {
        s->sts.sndEndSigRspTx++;
     }
     break;
   case MAT_PROCACCSIG:
     s->sts.procAccSigReqTx++;
     break;
   case MAT_FWDACCSIG:
     s->sts.fwdAccSigReqTx++;
     break;
   case MAT_PRE_SUBSHO:
     if (type == MAT_SS_REQ)
     {
       s->sts.preSubHoReqTx++;
     }
     else
     {
       s->sts.preSubHoRspTx++;
     }
     break;
   case MAT_PER_SUBSHO:
     if (type == MAT_SS_REQ)
     {
       s->sts.perSubHoReqTx++;
     }
     else
     {
       s->sts.perSubHoRspTx++;
     }
     break;
   case MAT_NOTEINTERHO:
     s->sts.notInterHoReqTx++;
     break;
#endif /* MAP_MSC */
 
#if (MAP_MSC || MAP_GSN)
   case MAT_FWDSM:
   if(type == MAT_SS_REQ)
   {
      s->sts. fwdSMReqTx++;          /* mo Forward SM request tx */
   }
   else
   {
      s->sts. fwdSMRspTx++;          /* mo Forward SM rsp tx */
   }
     break;

   case MAT_MT_FWDSM:
   if(type == MAT_SS_REQ)
   {
      s->sts. mtFwdSMReqTx++;          /* mo Forward SM request tx */
   }
   else
   {
      s->sts. mtFwdSMRspTx++;          /* mo Forward SM rsp tx */
   }
   break;
#endif /* MAP_MSC || MAP_GSN */
 
#if MAP_MSC
   case MAT_RESCALLHANDL:
   if(type == MAT_SS_REQ)
   {
      s->sts. resCallHandlReqTx++;          /* mo Forward SM request tx */
   }
   else
   {
      s->sts. resCallHandlRspTx++;          /* mo Forward SM rsp tx */
   }
   break;

   case MAT_PREP_GRPCALL:
   if(type == MAT_SS_REQ)
   {
      s->sts.prepGrpCallReqTx++;     /*  Prepare Grp call req Tx */
   }
   else
   {
      s->sts.prepGrpCallRspTx++;     /* Prepare Grp call rsp Tx */
   }
   break;

   case MAT_PRO_GRPCALLSIG:
   s->sts.proGrpCallSigReqTx++;     /* Pro Grp Call Sig  req Tx */
   break;

   case MAT_FWD_GRPCALLSIG:
   s->sts.fwdGrpCallSigReqTx++;     /* Fwd Grp Call Sig req Tx */
   break;

   case MAT_SND_GRPCALLENDSIG:
   if(type == MAT_SS_REQ)
   {
      s->sts.sndGrpCallEndSigReqTx++;     /* prov Siwfs Nmb req Tx */
   }
   else
   {
      s->sts.sndGrpCallEndSigRspTx++;     /* prov Siwfs Nmb rsp Tx */
   }
   break;

   case MAT_PROV_SIWFS_NMB:
   if(type == MAT_SS_REQ)
   {
      s->sts.provSiwfsNmbReqTx++;     /* prov Siwfs Nmb req Tx */
   }
   else
   {
      s->sts.provSiwfsNmbRspTx++;     /* prov Siwfs Nmb rsp Tx */
   }
   break;

   case MAT_SIWFS_SIGMOD:
   if(type == MAT_SS_REQ)
   {
      s->sts.siwfsSigModReqTx++;     /*  siwfs Sig Mod req Tx */
   }
   else
   {
      s->sts.siwfsSigModRspTx++;     /*  siwfs Sig Mod rsp Tx */
   }
   break;

#endif  /* MSC */

#if MAP_VLR
  /* Send Identification Request */
   case MAT_SNDID:
     if (type == MAT_SS_REQ)
     {
       s->sts.sndIdReqTx++;
     }
     else
     {
       s->sts.sndIdRspTx++;
     }
     break;
#endif  /* MAP_VLR */

#if (MAP_HLR || MAP_MLC)
   case MAT_ANY_INTER:
   if(type == MAT_SS_REQ)
   {
      s->sts.anyInterReqTx++;     /* any Inter req Tx */
   }
   else
   {
      s->sts.anyInterRspTx++;     /* any Inter rsp Tx */
   }
   break;

#endif /* MAP_HLR || MAP_MLC */

#if (MAP_MSC || MAP_HLR)
   case MAT_SSINV_NOTIFY:
     if (type == MA_SS_REQ)
     {
        s->sts.ssInvNotReqTx++;     /*  ss Inv Not req Tx */
     }
     else
     {
        s->sts.ssInvNotRspTx++;     /*  ss Inv Not rsp Tx */
     }
     break;

#if MAP_REL99

  case MAT_IST_ALERT:
     if (type == MAT_SS_REQ)
     {
        s->sts.istAlrtReqTx++;     /* any Inter req Rx */
     }
     else
     {
        s->sts.istAlrtRspTx++;     /* any Inter rsp Rx */
     }
     break;
  case MAT_IST_COMMAND:
     if (type == MAT_SS_REQ)
     {
        s->sts.istCmdReqTx++;     /* any Inter req Rx */
     }
     else
     {
        s->sts.istCmdRspTx++;     /* any Inter rsp Rx */
     }
     break;

#endif /* MAP_REL99 */

#endif 

#if MAP_MSC
#if MAP_REL6
     
  case MAT_REL_RES:
     if (type == MAT_SS_REQ)
     {
        s->sts.relResReqTx++;     /* any Inter req Rx */
     }
     else
     {
        s->sts.relResRspTx++;     /* any Inter rsp Rx */
     }
    break;

#endif /* MAP_REL6 */
#endif /* MAP_MSC */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
#if (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5))
   case MAT_PROVSUBSINFO:
   if(type == MAT_SS_REQ)
   {
      s->sts.provSubsInfoReqTx++;     /*prov Subs Info req Tx */
   }
   else
   {
      s->sts.provSubsInfoRspTx++;     /*prov Subs Info rsp Tx */
   }
   break;
#endif /* (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5)) */
#endif /* MAP_VLR || MAP_HLR */

#if MAP_REL99

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_AUTHFAILRPT:
     if (type == MAT_SS_REQ)
     {
       s->sts.authFailRptReqTx++;
     }
     else
     {
       s->sts.authFailRptRspTx++;
     }

     break;
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#endif /* MAP_REL99 */

#if (MAP_HLR || MAP_GSN)

   case MAT_GPRS_UPLOC:
   if(type == MAT_SS_REQ)
   {
      s->sts.gprsUpLocReqTx++;     /* Gprs Up. Loc req Tx */
   }
   else
   {
      s->sts.gprsUpLocRspTx++;     /* Gprs Up. Loc rsp Tx */
   }
   break;
   case MAT_GPRS_ROUTINFO:
   if(type == MAT_SS_REQ)
   {
      s->sts.gprsRoutInfoReqTx++;  /* Gprs Rout Info req Tx */
   }
   else
   {
      s->sts.gprsRoutInfoRspTx++;  /* Gprs Rout Info rsp Tx */
   }
   break;
   case MAT_FAILRPT:
      if (type == MA_SS_REQ)
      {
         s->sts.failRptReqTx++;     /* Fail Rpt  req Tx */
      }
      else
      {
         s->sts.failRptRspTx++;     /* Fail Rpt  rsp Tx */
      }
      break;
   case MAT_GPRS_NOTEMSPRES:
     if (type == MA_SS_REQ)
     {
        s->sts.gprsNoteMsPresReqTx++;     /* Gprs Note Ms Pres  req Tx */
     }
     else
     {
        s->sts.gprsNoteMsPresRspTx++;     /* Gprs Note Ms Pres  rsp Tx */
     }
     break;
   
#endif

#if (MAP_REL98 || MAP_REL99)

#if (MAP_HLR || MAP_MLC)
   case MAT_SENDROUTINFOFORLCS:
     if (type == MAT_SS_REQ)
     {
        s->sts.lcsSndRoutInfoReqTx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->sts.lcsSndRoutInfoRspTx++;  /* Gprs Rout Info rsp Rx */
     }

     break;
#endif /* MAP_HLR || MAP_MLC */

#endif /* MAP_REL98 || MAP_REL99 */

#if (MAP_REL98 || MAP_REL99)

#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL4 && MAP_GSN))
   case MAT_PROVSUBSLOC:
     if (type == MAT_SS_REQ)
     {
        s->sts.provSubsLocReqTx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->sts.provSubsLocRspTx++;  /* Gprs Rout Info rsp Rx */
     }

     break;
   case MAT_SUBSLOCRPT:
     if (type == MAT_SS_REQ)
     {
        s->sts.subsLocReqTx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->sts.subsLocRspTx++;  /* Gprs Rout Info rsp Rx */
     }

     break;
#endif
#endif
#endif /* (MAP_REL98 || MAP_REL99) */

#if MAP_REL99
#if MAP_HLR
   case MAT_ANY_SUBSDATA_INTER:
     if (type == MAT_SS_REQ)
     {
        s->sts.anySubsInterReqTx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->sts.anySubsInterRspTx++;  /* Gprs Rout Info rsp Rx */
     }

     break;
   case MAT_ANY_MOD:
     if (type == MAT_SS_REQ)
     {
        s->sts.anyModReqTx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->sts.anyModRspTx++;  /* Gprs Rout Info rsp Rx */
     }

     break;
   case MAT_NOTE_SUBSDATA_MOD:
     if (type == MAT_SS_REQ)
     {
        s->sts.notSubsModReqTx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->sts.notSubsModRspTx++;  /* Gprs Rout Info rsp Rx */
     }

     break;
#endif /* MAP_HLR */

#endif /* (MAP_REL98 || MAP_REL99) */

   default:
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA188, (ErrVal)oprType, "maUpdatTxSts () Failed");
#endif
     break;
  }
} /* maUpdatTxSts */

/*
*
*       Fun:   maSndPrvErrCfm    
*
*       Desc:  This function sends the confirm primitive whenever the received
*              request primitive is in error.
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy3.c
*
*/
  
#ifdef ANSI
PUBLIC Void maSndPrvErrCfm 
(
U8           oprCode,       /* Operation code */
MaInvokeId   *invkId,       /* Invoke Id */
MaDlgId      spDlgId,       /* Service Provider Dialogue Id */
MaDlgId      suDlgId,       /* Service User Dialogue Id */
MaSap        *s,            /* MAP Sap structure */
U8           primType,      /* primitive type */
U8           errCause       /* Error Cause */
)
#else
PUBLIC Void maSndPrvErrCfm (oprCode, invkId, spDlgId, suDlgId, s, primType, errCause)
U8           oprCode;       /* Operation code */
MaInvokeId   *invkId;       /* Invoke Id */
MaDlgId      spDlgId;       /* Service Provider Dialogue Id */
MaDlgId      suDlgId;       /* Service User Dialogue Id */
MaSap        *s;            /* MAP Sap structure */
U8           primType;      /* primitive type */
U8           errCause;      /* Error Cause */
#endif
{
  MaUsrErr    usrErr;
  MaPrvErr    prvErr;

  TRC2(maSndPrvErrCfm)

  usrErr.pres = FALSE;
  prvErr.pres = TRUE;
  prvErr.errSrc = MAT_LOCAL_PRV_ERR;
  prvErr.errCode = errCause;

  switch (primType)
  {
#if (MAP_VLR || MAP_HLR || MAP_GSN)
      case MAT_EVTLOCMGMTREQ:
       {
         MaLocEv  *evt;

#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaLocEv *) maAlloc(sizeof(MaLocEv))) == NULLP)
         {
            RETVOID;
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocEv *)&(maGlobDecEv->locEv);
       cmZero((Data *)evt,sizeof(MaLocEv));
#endif  /* MA_STATIC_EVT_STRUCT */
 

         maBZero((U8 *)evt, (U16)sizeof (MaLocEv));
         MaUiMatLocMgmtCfm(&s->maPstMU, s->suId, suDlgId, spDlgId, invkId, oprCode, 
                           &usrErr, &prvErr, evt);
#ifndef MA_STATIC_EVT_STRUCT
         if(s->maPstMU.selector != MALWLCSEL)
         {
            (Void) maFree((Data *)evt, sizeof(MaLocEv));
         }
#endif  /* MA_STATIC_EVT_STRUCT */
 
       }

       break;

      case MAT_EVTSUBMGMTREQ:

       {
         MaSubEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSubEv *) maAlloc(sizeof(MaSubEv))) == NULLP)
         {
            RETVOID;
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSubEv *)&(maGlobDecEv->subEv);
       cmZero((Data *)evt,sizeof(MaSubEv));
#endif  /* MA_STATIC_EVT_STRUCT */
         maBZero((U8 *)evt, (U16)sizeof (MaSubEv));

         MaUiMatSubMgmtCfm(&s->maPstMU, s->suId, suDlgId, spDlgId, invkId, oprCode, 
                           &usrErr, &prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
         if(s->maPstMU.selector != MALWLCSEL)
         {
            (Void) maFree((Data *)evt, sizeof(MaSubEv));
         }
#endif  /* MA_STATIC_EVT_STRUCT */
 
       }
       break;
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_MSC || MAP_VLR || MAP_HLR)
      case MAT_EVTOAMMGMTREQ:
       {
         MaOAMEv   *evt;

#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaOAMEv *) maAlloc(sizeof(MaOAMEv))) == NULLP)
         {
            RETVOID;
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaOAMEv *)&(maGlobDecEv->oamEv);
       cmZero((Data *)evt,sizeof(MaOAMEv));
#endif  /* MA_STATIC_EVT_STRUCT */
         maBZero((U8 *)evt, (U16)sizeof (MaOAMEv));

         MaUiMatOAMCfm(&s->maPstMU, s->suId, suDlgId, spDlgId, invkId, oprCode,
                       &usrErr, &prvErr, evt);
#ifndef MA_STATIC_EVT_STRUCT
         if(s->maPstMU.selector != MALWLCSEL)
         {
            (Void) maFree((Data *)evt, sizeof(MaOAMEv));
         }
#endif  /* MA_STATIC_EVT_STRUCT */
 
       }
       break;
#endif /* MAP_MSC || MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR)
      case MAT_EVTSSMGMTREQ:
       {
         MaSSEv   *evt;

#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSSEv *) maAlloc(sizeof(MaSSEv))) == NULLP)
         {
            RETVOID;
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSSEv *)&(maGlobDecEv->ssEv);
       cmZero((Data *)evt,sizeof(MaSSEv));
#endif  /* MA_STATIC_EVT_STRUCT */
         maBZero((U8 *)evt, (U16)sizeof (MaSSEv));

         MaUiMatSSCfm(&s->maPstMU, s->suId, suDlgId, spDlgId, invkId, oprCode, 
                      &usrErr, &prvErr, evt);
#ifndef MA_STATIC_EVT_STRUCT
         if(s->maPstMU.selector != MALWLCSEL)
         {
            (Void) maFree((Data *)evt, sizeof(MaSSEv));
         }
#endif  /* MA_STATIC_EVT_STRUCT */
 
       }
       break;
#endif /* MAP_VLR || MAP_HLR */

#if MAP_MSC
      case MAT_EVTHOMGMTREQ:

       {
         MaHoEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaHoEv *) maAlloc(sizeof(MaHoEv))) == NULLP)
         {
            RETVOID;
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaHoEv *)&(maGlobDecEv->hoEv);
       cmZero((Data *)evt,sizeof(MaHoEv));
#endif  /* MA_STATIC_EVT_STRUCT */
         maBZero((U8 *)evt, (U16)sizeof(MaHoEv));
         MaUiMatHOMgmtCfm(&s->maPstMU, s->suId, suDlgId, spDlgId, invkId, oprCode, 
                          &usrErr, &prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
         if(s->maPstMU.selector != MALWLCSEL)
         {
            (Void) maFree((Data *)evt, sizeof(MaHoEv));
         }
#endif  /* MA_STATIC_EVT_STRUCT */
 
       }
       break;
#endif

#if (MAP_VLR || MAP_GSN)
      case MAT_EVTAUTHMGMTREQ:
       {
         MaAuthEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaAuthEv *) maAlloc(sizeof(MaAuthEv))) == NULLP)
         {
            RETVOID;
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaAuthEv *)&(maGlobDecEv->authEv);
       cmZero((Data *)evt,sizeof(MaAuthEv));
#endif  /* MA_STATIC_EVT_STRUCT */
         maBZero((U8 *)evt, (U16)sizeof(MaAuthEv));
 
         MaUiMatAuthMgmtCfm(&s->maPstMU, s->suId, suDlgId, spDlgId, invkId, oprCode, 
                            &usrErr, &prvErr, evt);

#ifndef MA_STATIC_EVT_STRUCT
         if(s->maPstMU.selector != MALWLCSEL)
         {
            (Void) maFree((Data *)evt, sizeof(MaAuthEv));
         }
#endif  /* MA_STATIC_EVT_STRUCT */
 
       }
       break;
#endif /* MAP_VLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR)

      case MAT_EVTFRMGMTREQ:
       {
         MaFREv   *evt;

#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaFREv *) maAlloc(sizeof(MaFREv))) == NULLP)
         {
            RETVOID;
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaFREv *)&(maGlobDecEv->frEv);
       cmZero((Data *)evt,sizeof(MaFREv));
#endif  /* MA_STATIC_EVT_STRUCT */
         maBZero((U8 *)evt, (U16)sizeof (MaFREv));
         MaUiMatFRMgmtCfm(&s->maPstMU, s->suId, suDlgId, spDlgId, invkId, oprCode, 
                          &usrErr, &prvErr, evt);
#ifndef MA_STATIC_EVT_STRUCT
         if(s->maPstMU.selector != MALWLCSEL)
         {
          (Void) maFree((Data *)evt, sizeof(MaFREv));
         }
#endif  /* MA_STATIC_EVT_STRUCT */
 
       }
       break;
#endif

#if (MAP_MSC || MAP_GSN)

      case MAT_EVTIMEIMGMTREQ:
       
       {
         MaIMEIEv *evt;

#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaIMEIEv *) maAlloc(sizeof(MaIMEIEv))) == NULLP)
         {
            RETVOID;
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaIMEIEv *)&(maGlobDecEv->imeiEv);
       cmZero((Data *)evt,sizeof(MaIMEIEv));
#endif  /* MA_STATIC_EVT_STRUCT */
         maBZero((U8 *)evt, (U16)sizeof(MaIMEIEv));
         MaUiMatIMEIMgmtCfm(&s->maPstMU, s->suId, suDlgId, spDlgId, invkId, oprCode, 
                            &usrErr, &prvErr, evt);
#ifndef MA_STATIC_EVT_STRUCT
         if(s->maPstMU.selector != MALWLCSEL)
         {
          (Void) maFree((Data *)evt, sizeof(MaIMEIEv));
         }
#endif  /* MA_STATIC_EVT_STRUCT */
 
       }
       break;
#endif

#if (MAP_MSC || MAP_VLR || MAP_HLR)
      case MAT_EVTCALLMGMTREQ:
       {
         MaCallEv   *evt;

#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaCallEv *) maAlloc(sizeof(MaCallEv))) == NULLP)
         {
            RETVOID;
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaCallEv *)&(maGlobDecEv->callEv);
       cmZero((Data *)evt,sizeof(MaCallEv));
#endif  /* MA_STATIC_EVT_STRUCT */
         maBZero((U8 *)evt, (U16)sizeof (MaCallEv));

         MaUiMatCallMgmtCfm(&s->maPstMU, s->suId, suDlgId, spDlgId, invkId, oprCode, 
                            &usrErr, &prvErr, evt);
#ifndef MA_STATIC_EVT_STRUCT
         if(s->maPstMU.selector != MALWLCSEL)
         {
          (Void) maFree((Data *)evt, sizeof(MaCallEv));
         }
#endif  /* MA_STATIC_EVT_STRUCT */
 
       }
       break;
#endif

#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)
      case MAT_EVTSMMGMTREQ:
       {
         MaSMEv   *evt;

#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaSMEv *) maAlloc(sizeof(MaSMEv))) == NULLP)
         {
            RETVOID;
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaSMEv *)&(maGlobDecEv->smEv);
       cmZero((Data *)evt,sizeof(MaSMEv));
#endif  /* MA_STATIC_EVT_STRUCT */
         maBZero((U8 *)evt, (U16)sizeof (MaSMEv));
         MaUiMatSMCfm(&s->maPstMU, s->suId, suDlgId, spDlgId, invkId, oprCode, 
                      &usrErr, &prvErr, evt);
#ifndef MA_STATIC_EVT_STRUCT
         if(s->maPstMU.selector != MALWLCSEL)
         {
            (Void) maFree((Data *)evt, sizeof(MaSMEv));
         }
#endif  /* MA_STATIC_EVT_STRUCT */
 
       }
       break;
#endif

#if (MAP_HLR || MAP_GSN)
      case MAT_EVTPDPACTVREQ:
       {
         MaPdpActvEv   *evt;

#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaPdpActvEv *) maAlloc(sizeof(MaPdpActvEv))) == NULLP)
         {
            RETVOID;
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaPdpActvEv *)&(maGlobDecEv->pdpActvEv);
       cmZero((Data *)evt,sizeof(MaPdpActvEv));
#endif  /* MA_STATIC_EVT_STRUCT */
         maBZero((U8 *)evt, (U16)sizeof (MaPdpActvEv));
         MaUiMatNwReqPdpCntxtActvCfm(&s->maPstMU, s->suId, suDlgId, spDlgId, invkId, oprCode, 
                      &usrErr, &prvErr, evt);
#ifndef MA_STATIC_EVT_STRUCT
         if(s->maPstMU.selector != MALWLCSEL)
         {
            (Void) maFree((Data *)evt, sizeof(MaPdpActvEv));
         }
#endif  /* MA_STATIC_EVT_STRUCT */
 
       }
       break;
#endif

#if (MAP_REL98 || MAP_REL99)

#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL4 && MAP_GSN))
      case MAT_EVTLOCSERVREQ:
       {
         MaLocServEv   *evt;

#ifndef MA_STATIC_EVT_STRUCT
         if ((evt = (MaLocServEv *) maAlloc(sizeof(MaLocServEv))) == NULLP)
         {
            RETVOID;
         }
#else   /* MA_STATIC_EVT_STRUCT */
       evt = (MaLocServEv *)&(maGlobDecEv->pdpActvEv);
       cmZero((Data *)evt,sizeof(MaLocServEv));
#endif  /* MA_STATIC_EVT_STRUCT */
         maBZero((U8 *)evt, (U16)sizeof (MaLocServEv));
         MaUiMatLocServCfm(&s->maPstMU, s->suId, suDlgId, spDlgId, invkId, 
                      oprCode, &usrErr, &prvErr, evt);
#ifndef MA_STATIC_EVT_STRUCT
         if(s->maPstMU.selector != MALWLCSEL)
         {
            (Void) maFree((Data *)evt, sizeof(MaLocServEv));
         }
#endif  /* MA_STATIC_EVT_STRUCT */
 
       }
       break;
#endif
#endif

#endif /* (MAP_REL98 || MAP_REL99) */

      default:
        break;
  }

} /* maSndPrvErrCfm */

/*
*
*       Fun:   maMkErrMsg  
*
*       Desc:  This function encodes the parameters for TC_ERROR component.
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy3.c
*
*/
  
#ifdef ANSI
PRIVATE Buffer *maMkErrMsg 
(
MaSap        *s,       /* MAP SAP */ 
U8           tag,      /* tag */
U8           errVal    /* error value */
)
#else
PRIVATE Buffer *maMkErrMsg (s, tag, errVal)
MaSap        *s;       /* MAP SAP */ 
U8           tag;      /* tag */
U8           errVal;   /* error value */
#endif
{
   Data     pkArray[3];
   S16      ret;
   Buffer   *mBuf;

   TRC2(maMkErrMsg);

   if((ret = SGetMsg(s->maPstST.region, s->maPstST.pool, &mBuf)) != ROK)
   {
       RETVALUE(NULLP);
   }
   pkArray[0] = (Data)tag;
   pkArray[1] = (Data)1;
   pkArray[2] = (Data)errVal;
   ret = SAddPstMsgMult(pkArray, (MsgLen)3, mBuf);
   if (ret != ROK)
   {
#if (ERRCLASS & ERRCLS_ADD_RES)
       MALOGERROR(ERRCLS_ADD_RES, EMA189, (ErrVal)ret, "SAddPstMsgMult () Failed");
#endif
       (Void)SPutMsg(mBuf);
       RETVALUE(NULLP);
   }
   RETVALUE(mBuf);

} /* maMkErrMsg */

#ifdef MA_SEG
/* 
* 
*       Fun:   maRRNLSegment 
*  
*       Desc:  This function handles the MAP RR NL segmentation
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ca_bdy3.c
* 
*/
#ifdef ANSI
PRIVATE S16 maRRNLSegment
(
MaSap      *s,              /* sap control point */
MaDlgCp    *dlgCp,          /* dialogue control point */
StComps    *cmpEv,          /* component event structure */
MaCmpCp    *cmpCp           /* component control point pointer */
)
#else
PRIVATE S16 maRRNLSegment(s, dlgCp, cmpEv, cmpCp)
MaSap      *s;              /* sap control point */
MaDlgCp    *dlgCp;          /* dialogue control point */
StComps    *cmpEv;          /* component event structure */
MaCmpCp    *cmpCp;          /* component control point pointer */
#endif
{
   U16    segNo;  /* segment number */
   Data   data1;  /* dummy data - 1 */
   Data   data2;  /* dummy data - 2 */
   S16    ret;    /* return value   */
   Buffer *mBuf;  /* msg buf        */
   U8     oprType; /* operation type */
   MaDlgId spDlgId; /* sp Dialogue id */

   /* Initialize operation type and dlgId */
   oprType = cmpEv->stOpCode.string[0];
   spDlgId = dlgCp->spDlgId;

   if((maCb.maCP.sigFrameSz == 0) || (s->ctlp.offIdx == 0))
   {
      /* no segmentation requested / needed */
      RETVALUE(ROK);
   }
   if(s->ctlp.offIdx < 0)
   {
      /* raise error */
      MADBGP(LMA_DBGMASK_GEN, (maCb.maInit.prntBuf,
      "maRRNLSegment:single parameter exceeding the segment size\n"));
      RETVALUE(RFAILED);
   }
   if(((s->ctlp.offLevel == 1)&&(s->ctlp.mandFlg1 == TRUE))||
       ((s->ctlp.offLevel == 2)&&(s->ctlp.mandFlg2 == TRUE)))
   {
      /* raise error */
      MADBGP(LMA_DBGMASK_GEN, (maCb.maInit.prntBuf, "maRRNLSegment:\
      segmentation prohibited due to presence of mandatory params\n"));
      RETVALUE(RFAILED);
   }
   /* Take sequence tag & length octets and verify */
   if(s->ctlp.offLevel > 1)
   {
      /* This is the constructed type */
      SExamMsg(&data1,s->ctlp.mBuf,0);
      SExamMsg(&data2,s->ctlp.mBuf,1);
   }

   /* Update the offsets */
   for(segNo=s->ctlp.offIdx-1;(segNo>0);segNo--)
   {
      s->ctlp.offset[segNo] -= s->ctlp.offset[segNo-1];
   }

   /* start firing the RRNL segments based on the offset array */
   while(segNo < s->ctlp.offIdx)
   { 
      /* split the encoded buffer at the appropriate index */
      ret = SSegMsg(s->ctlp.mBuf,(MsgLen)s->ctlp.offset[(segNo++)],&mBuf);
      if (ret != ROK)
      {
         MADBGP(LMA_DBGMASK_GEN,(maCb.maInit.prntBuf,
         "maRRNLSegment:SSegMsg failed.\n"));
         /* s->ctlp.mBuf will be freed by the parent function */
         if(mBuf != (Buffer *)NULLP)
         {
            SPutMsg(mBuf);
         }
         RETVALUE(RFAILED);
      } 

      /* Adding header & trailers appropriately for the segments */
      if(s->ctlp.offLevel > 1)
      {
         if(segNo > 1)
         {
            /* Add the sequence tag and length octet except for the first */
            SAddPreMsg(data2,s->ctlp.mBuf);
            SAddPreMsg(data1,s->ctlp.mBuf);
         }

         if(segNo <= s->ctlp.offIdx)
         {
            /* Add EOC contents except for the last one */
            SAddPstMsg(0x0,s->ctlp.mBuf);
            SAddPstMsg(0x0,s->ctlp.mBuf);
         }
      }

      /* Provide trace for the segment which is being transmitted */
      if (s->trc == TRUE) 
      {
         maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);
      }
      cmpEv->stCompType = STU_RET_RES_NL;
#if MAP_REL99
#if MAP_SEC
      if(dlgCp->mapSec == TRUE)
      {
         ret = maProcSecOprRsp(s,dlgCp,cmpEv,cmpCp,s->sapId,dlgCp->suDlgId,spDlgId,&cmpEv->stInvokeId);
         if(ret != ROK)
         {
            if (s->ctlp.mBuf != NULLP)
            {
               SPutMsg(s->ctlp.mBuf);
            }
            RETVALUE(RFAILED);
         }
      }
#endif /* MAP_SEC */
#endif
      MaLiStuCmpReq (&s->maPstST, s->spIdTC, spDlgId,dlgCp->lowerSpDlgId,
                   cmpEv, s->ctlp.mBuf);
      /* Tranmit the TC-CONTINUE along with the NL component */
      s->ctlp.mBuf = (Buffer *)NULLP;
      ret = (*maDSMTbl[MA_EV_DELIM_REQ][dlgCp->dsmState]) (s);
      s->ctlp.mBuf = mBuf;
      if(ret != ROK)
      {
         MADBGP(LMA_DBGMASK_GEN, (maCb.maInit.prntBuf,
         "maRRNLSegment:TC-CONTINUE data request  failed.\n"));
         RETVALUE(RFAILED);
      }
   }/* end of while loop */

   if(s->ctlp.offLevel > 1)
   {
      /* Add the sequence tag and length octet except for the first */
      SAddPreMsg(data2,s->ctlp.mBuf);
      SAddPreMsg(data1,s->ctlp.mBuf);
   }
   cmpEv->stCompType = STU_RET_RES_L;
   RETVALUE(ROK);
}/* maRRNLSegment */
#endif /* MA_SEG */

/********************************************************************30**

         End of file:     ca_bdy3.c@@/main/13 - Fri Sep 16 02:47:20 2005

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:

*********************************************************************61*/
/********************************************************************80**
 
  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  aa    1. initial release
 
1.2          ---  aa    1. text changes
 
*********************************************************************81*/
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.3          ---      aa   1. Removed the Linked ID as parameter from 
                              MaUiMatSSRsp.
             ---      aa   2. Linked Id is no more passed as parameter in 
                              MaUiMatSSCfm function.
             ---      aa   3. Removed the parameter lnkId from maSndPrvErrCfm
             ---      aa   4. Pass pointer to Component Event structure in
                              subroutine maSndTcRej intead of storing it in
                              SAP structure. 
             ---      aa   5. Gaurd timer is not started in case of Request 
                              primitives.
             ---      aa   6. class field in stu.x is changed to opClass (made changes
                              related to that)
1.4          ---      aa   1. Moved XXYYMatAuthMgmtRsp from #ifdef MSC to HLR.
             ---      aa   2. Corrected the function maEncOpr for the following 
                              operation codes,MAT_CANCELLOC, MAT_PURGE,
                              MAT_SNDENDSIG, MA_ACTVTRMODE, MA_DACTVTRMODE,
                              MA_USSNOT, MAT_FWDSM, MAT_ALRTSC, MAT_SMRDY 
             ---     aa    3. break was missing in function maEncOpr for MAT_RESTOREDATA
                              operation code. 
             ---     sg    4. bug in MaUiMatSubMgmtRsp and MaUiMatSMRsp
 
             ---     ssk   5. In maEncOpr(), for Insert subscriber data case
                              request field is passed instead of response field.
 
             ---     ssk   6. Added MAP Phase 2+ variant                     
 
1.5          ---      sg   1. Removed a space character from an extraction
                              flag

1.6          ---      sg   1. Miscellaneous changes

1.7          ---      ssk  1. maSndPrvErrCfm parameters are aligned with 
                              the calling sequence.

             ---      ssk  2. For the Return result component opcode must
                              not be filled when the message does not have
                              any parameters.

             ---      ssk  3. phase 2+ gpr release.                      

             ---      ssk  3. Global Decode event structure related 
                              change.

             ---      ssk  4. Component Event structure has to be zeroed in 
                              all the Request& Response primitives.
 
             ---      ssk  5. Parameter error is reported when the encode 
                              fails instead of DEBUG error.          
 
             ---      ssk  6. Invoke id hashing is modified to include
                              duplicate keys with different initiator values.

             ---      ssk  7. mBuf is initialized to NULLP in SubMgmtRsp().

             ---      ssk  8. max Invoke count is checked before trying to 
                              allocate the invoke control block.

/main/8      ---      jie  1. update for MAP 1.5 release.

             ---      jie  1. Allowed operation response in dialogue idle 
                              and dialogue pending state.

             ---      jie  1. Rolling Upgrade compliance.

             ---      yz   1. Initialize empty mBuf.
                           2. Remove REL99 flag.

             ---      jie  1. Change for 3.9.0 REL_99 support.

             ---      yz   1. Adding debug print for RFAILED case. 

             ---      jie  1. Change for MAP REL4 support without the MAPsec 
                              feature.

             ---      yz   1. Correct typoes in MADBGP macro.

/main/9      ---      jie  1. update for MAP 1.6 release.

             ---      yz   1. Addition of MAP segmentation feature from 1.5. 

             ---      yz  1. Correct 2 encoding error in maSSEncErr().

             ---      jz   1. Correct encoding error for Absent subscriber.
                           2. Allowed operation request in dialogue idle 
                              and dialogue pending state.

/main/10     ---      jie  1. update for MAP 1.7 release.

             ---      jie  1. Fixed the version calculation logic in maSMEncErr
                           2. Addition for definite length encoding
                           3. added optionality to decode MAT_ABSENT_SUBS.

             ---      ssk  1. Passed the correct argument to the debug print.  

/main/12     ---      zj   1. PSF-MAP changes.
             ---      st   1. added counters for AlrtSC and USSNot.
                           2. Added checks for NULL ptr on MAT i/f.
                           3. Enabled MA_MI_PROVSUBSINFO_RSP for REL5
                              GSN.
                           4. Modified the maIsOprSuppr function 
                              prototype to enforce stricter checking.
             ---     st    1.Modified the instances where ctlp.mBuf
                             was getting freed after maSndPrvErrCfm.
/main/13     ---     st    1. Updated for MAP sotware release 2.3
ma001.203		---	  st	  1. Modified the error code in status
										  indication in case segmentation issues.
/main/13    ma002.203  dv  1. Changed the type of 2nd arg in calls to 
                              SFndLenMsg to MsgLen.
/main/13    ma013.203  dm  1. Correction SS_INVOKE_NOTIFY is moved in SS Service 
*********************************************************************91*/

