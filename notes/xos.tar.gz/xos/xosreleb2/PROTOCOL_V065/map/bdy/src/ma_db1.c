/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     map
  
     Type:     C Source file
  
     Desc:     C source code for data base defination
  
     File:     ca_db1.c
  
     Sid:      ca_db1.c@@/main/8 - Fri Sep 16 02:47:35 2005
  
     Prg:      aa
  
*********************************************************************21*/


/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#if MAP_MSC
#if MAP_VLR
#if MAP_HLR
      -05      MSC, VLR and HLR
#else
#endif
#else
#if MAP_HLR
#else
      -01      MSC
#endif
#endif
#else
#if MAP_VLR
#if MAP_HLR
      -04      VLR and HLR
#else
      -02      VLR
#endif
#else
#if MAP_HLR
      -03      HLR
#else
#endif
#endif
#endif

************************************************************************/
 

/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "lma.h"           /* layer management, MAP */
#include "cm_err.h"        /* common error */
#include "stu.h"           /* tcap layer */
#include "mat.h"           /* map layer */
#ifdef MA_FTHA
#include "sht.h"
#endif /* MA_FTHA */
#include "cm5.h"
#include "ma.h"            /* map */
#include "ma_mf.h"
#include "ma_err.h"        /* map error */
#ifdef ZJ
#include "cm_ftha.h"       /* Common FTHA */
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#include "cm_tupsf.h"      /* Common TCAP user PSF */
#endif /* ZJ */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"
#include "cm_ss7.x"        /* SS7 common */
#include "stu.x"           /* tcap layer */
#include "lma.x"           /* layer management, TCAP */
#include "mat.x"           /* map  layer */
#ifdef MA_FTHA
#include "sht.x"
#endif /* MA_FTHA */
#ifdef ZJ
#include "cm_ftha.x"       /* Common FTHA */
#include "cm_pftha.x"      /* Common PSF defines */
#include "cm_psfft.x"
#include "cm_tupsf.x"      /* Common TCAP user PSF */
#endif /* ZJ */
#include "ma.x"            /* map */


/* Message defination Flag */

PUBLIC U32 maMsgFlgs0[MA_MAX_SWITCH] = 
{
 0,                     /* GSM 9.02 */
};


/* token validation enumerated list */

PRIVATE MaTknEnum maCancelTypeEnums0[] =
{
#ifndef XWEXT /* xingzhou.xu: pirated reason added --2006/10/13 */
   2,
#else
   3,
#endif /* XWEXT */   
   MAT_UPDATE_PROC,
   MAT_SUBS_WITHDRAW,
#ifdef XWEXT /* xingzhou.xu: pirated reason */   
   MAT_PIRATED_CANCEL,
#endif   
};

PRIVATE MaTknEnum maNetResEnums0[] =
{
 8, MAT_NETRSRS_PLMN, MAT_NETRSRS_HLR, MAT_NETRSRS_VLR, MAT_NETRSRS_PVLR, 
 MAT_NETRSRS_CONTR_MSC, MAT_NETRSRS_VMSC, MAT_NETRSRS_EIR, MAT_NETRSRS_RSS, 
};

PRIVATE MaTknEnum maProtIdEnums0[] =
{
 4, MAT_GSM_0408, MAT_GSM_0806, MAT_GSM_BSSMAP, MAT_ETS300102_1,
};

PRIVATE MaTknEnum maEqupStatEnums0[] =
{
 3, MAT_WHITE_LISTED, MAT_BLACK_LISTED, MAT_GREY_LISTED,
};

PRIVATE MaTknEnum maInterHoTypeEnums0[] =
{
 2, MAT_INTERBSS, MAT_INTRABSS,
};

PRIVATE MaTknEnum maIntraCugOptEnums0[] =
{
 3, MAT_NOCUG_RESTRICTIONS, MAT_CUGIC_CALLBARRED, MAT_CUGOG_CALLBARRED,
};

PRIVATE MaTknEnum maCliRestOptEnums0[] =
{
 3, MAT_PERMANENT_REST, MAT_TEMP_DEFAULT_REST, MAT_TEMP_DEFAULT_ALLOWED,
};

PRIVATE MaTknEnum maOvrRideCatEnums0[] =
{
 2, MAT_OVRRIDE_ENABLED, MAT_OVRRIDE_DISABLED, 
};

PRIVATE MaTknEnum maHntGrpAccSelOdrEnums0[] =
{
 2, MAT_RANDOM, MAT_SEQUENTIAL, 
};

PRIVATE MaTknEnum maRegSubsRspEnums0[] =
{
 4, MAT_MSC_AREA_REST, MAT_TOOMANY_ZONE_CODES, MAT_ZONE_CODE_CONFLICT,
 MAT_REG_SUBS_NOTSUPPORTED, 
};

PRIVATE MaTknEnum maFwdReasonEnums0[] =
{
 3, MAT_NOT_REACHABLE, MAT_BUSY, MAT_NO_REPLY,
};

PRIVATE MaTknEnum maSMDelStatEnums0[] =
{
 3, MAT_MEM_EXCEEDED, MAT_ABS_SUBS, MAT_SUCCESSFUL_TRANSFER,
};

PRIVATE MaTknEnum maAlrtReasonEnums0[] =
{
 2, MAT_MS_PRESENT, MAT_MEM_AVAIL,
};

PRIVATE MaTknEnum maSubsStatEnums0[] =
{
 2, MAT_SERV_GRANTED, MAT_OPR_DETERMINED_BARRING,
};

PRIVATE MaTknEnum maGuidInfoEnums0[] =
{
 5, MAT_ENTER_PW, MAT_ENTER_NEW_PW, MAT_ENTER_NEW_PW_AGAIN, 
    MAT_BAD_PW_TRY_AGAIN, MAT_BAD_PWFORMAT_TRY_AGAIN,
};

PRIVATE MaTknEnum maRufOutcomeEnums0[] =
{
 6, MAT_ACCEPTED,MAT_REJECTED,MAT_NO_RESP_FROM_FREE_MS,
    MAT_NO_RESP_FROM_BUSY_MS, MAT_UDUB_FROM_FREE_MS,MAT_UDUB_FROM_BUSY_MS,
};

PRIVATE MaTknEnum maReqParamEnums0[] =
{
 4, MAT_REQ_IMSI, MAT_REQ_AUTHSET, MAT_REQ_SUBSDATA, MAT_REQ_KI,
};

PRIVATE MaTknEnum maCallTypeCritEnums0[] =
{
 2, MAT_FORWARDED, MAT_NOT_FORWARDED,
};

PRIVATE MaTknEnum maDefCallHandlEnums0[] =
{
 2, MAT_CONTINUE_CALL, MAT_RELEASE_CALL,
};

/* ma001.203: Addition. Additional value */
#ifndef MAP_CH_PLUS
PRIVATE MaTknEnum maInterroTypeEnums0[] = /* Interrogation type */
{
#ifndef XWEXT
 2, MAT_BASIC_CALL, MAT_FORWARDING,
#else /* xingzhou.xu: added according to V1.30 2006/09/30 */
 3, MAT_BASIC_CALL, MAT_FORWARDING, MAT_HANDOVER
#endif
};
#else
PRIVATE MaTknEnum maInterroTypeEnums0[] = /* Interrogation type */
{
 3, MAT_BASIC_CALL, MAT_FORWARDING, MAT_NLR_INTERRO,
};
#endif

#if MAP_REL99
PRIVATE MaTknEnum maOBcsmTrigDetPtEnums0[] =
{
 2, MAT_COLLECTED_INFO, MAT_ROUTE_SELECT_FAILURE,
};
#else  /* MAP_REL99 */
PRIVATE MaTknEnum maOBcsmTrigDetPtEnums0[] =
{
 1, MAT_COLLECTED_INFO,
};
#endif /* MAP_REL99 */

#if MAP_REL99
PRIVATE MaTknEnum maTBcsmTrigDetPtEnums0[] =
{
 3, MAT_TERM_ATTEMPT_AUTH, MAT_T_BUSY, MAT_T_NO_ANSWER,
};
#else  /* MAP_REL99 */
PRIVATE MaTknEnum maTBcsmTrigDetPtEnums0[] =
{
 1, MAT_TERM_ATTEMPT_AUTH,
};
#endif /* MAP_REL99 */

PRIVATE MaTknEnum maSMDelOutComeEnums0[] =
{
 3, MAT_MEMORY_CAP_EXCEEDED,MAT_ABSENT_SUBSCRIBER,MAT_SUCCESSFUL_TRANSFER,
};
PRIVATE MaTknEnum maNetAccModeEnums0[] =
{
 3, MAT_BOTH_MSC_SGSN,MAT_ONLY_MSC,MAT_ONLY_SGSN,
};
PRIVATE MaTknEnum maCcbsSubsStatusEnums0[] =
{
 3, MAT_CCBS_NOT_IDLE,MAT_CCBS_IDLE,MAT_CCBS_NOT_REACHABLE,
};
PRIVATE MaTknEnum maRptStateEnums0[] =
{
 2, MAT_STOP_MONITORING,MAT_START_MONITORING,
};

PRIVATE MaTknEnum maMatchTypeEnums0[] =
{
 2, MAT_INHIBITING, MAT_ENABLING,
};

PRIVATE MaTknEnum maMonModeEnums0[] =
{
 2, MAT_A_SIDE,MAT_B_SIDE,
};

PRIVATE MaTknEnum maCallOutcomeEnums0[] =
{
 3, MAT_CALL_SUCCESS, MAT_CALL_FAILURE,MAT_CALL_BUSY,
};

PRIVATE MaTknEnum maNotRchRsnEnums0[] =
{
 4, MAT_MS_PURGED, MAT_IMSI_DETACHED,MAT_RESTRICTED_AREA,MAT_NOT_REGISTERED,
};

#if (MAP_REL98 || MAP_REL99)

#if MAP_REL5
PRIVATE MaTknEnum maNmbPortStatEnums0[] =
{
 5, MAT_NOT_KNOWN_TO_BE_PORTED, MAT_OWN_NMB_PORTED_OUT,
    MAT_FRGN_NMB_PORTED_TO_FRGN_NET, MAT_OWN_NMB_NOT_PORTED_OUT, MAT_FRGN_NMB_PORTED_IN,

};
#else
PRIVATE MaTknEnum maNmbPortStatEnums0[] =
{
 3, MAT_NOT_KNOWN_TO_BE_PORTED, MAT_OWN_NMB_PORTED_OUT, 
    MAT_FRGN_NMB_PORTED_TO_FRGN_NET,
    
};
#endif

PRIVATE MaTknEnum maExtProtIdEnums0[] =
{
 1, MAT_ETS_300356,
};

#if MAP_REL4
#if MAP_REL99
PRIVATE MaTknEnum maLcsEventEnums0[] =
{
 4, MAT_EMERG_CALL_OR_ORIG, MAT_EMERG_CALL_RELEASE, MAT_MO_LR,
    MAT_DEFER_MT_RES,
};
#endif
#else  /* MAP_REL4 */
PRIVATE MaTknEnum maLcsEventEnums0[] =
{
 3, MAT_EMERG_CALL_OR_ORIG, MAT_EMERG_CALL_RELEASE, MAT_MO_LR,
};
#endif /* MAP_REL4 */

PRIVATE MaTknEnum maPosiMethFailDiagEnums0[] =
{
 9, MAT_CONGESTION, MAT_INSUFFICIENT_RESOUSES, MAT_INSUFFICIENT_MEAS_DATA, 
    MAT_INCONSISTENT_MEAS_DATA, MAT_LOC_PROC_NOT_COMPLETED, 
    MAT_LOC_PROC_NOT_SUP_BY_TARGT_MS, MAT_QOS_NOT_ATTAINABLE,
    MAT_POSI_METH_NOT_AVAI_NET, MAT_POSI_METH_NOT_AVAI_IN_LOC_AREA,
};

#if MAP_REL5
PRIVATE MaTknEnum maUnAuthLcsClientParamEnums0[] =
{
 8, MAT_NO_ADDI_INFO, MAT_CLIENT_NOT_IN_MS_PRIV_EXCEP, 
    MAT_CALL_TO_CLIENT_NOT_SETUP, MAT_PRIV_OVERRIDE_NOT_APP,
    MAT_DISALLOWED_BY_LOCAL_REG_REQ, MAT_UNAUTH_PRIVACY_CLASS,
    MAT_UNAUTH_CALL_SESSION_UNRELATED_EXT_CLIENT,
    MAT_UNAUTH_CALL_SESSION_RELATED_EXT_CLIENT,
};
#else
PRIVATE MaTknEnum maUnAuthLcsClientParamEnums0[] =
{
 5, MAT_NO_ADDI_INFO, MAT_CLIENT_NOT_IN_MS_PRIV_EXCEP, 
    MAT_CALL_TO_CLIENT_NOT_SETUP, MAT_PRIV_OVERRIDE_NOT_APP,
    MAT_DISALLOWED_BY_LOCAL_REG_REQ,
};
#endif

PRIVATE MaTknEnum maResponseTimeEnums0[] =
{
 2, MAT_LOW_DELAY, MAT_DELAY_TOLERANT,
};

PRIVATE MaTknEnum maLcsClientTypeEnums0[] =
{
 4, MAT_EMERGENCY_SERVICES, MAT_VALUE_ADDED_SERVICE, MAT_PLMN_OPERATOR_SERVICE,
   MAT_LAWFUL_INTERCEPT_SERVICES,
};

#if MAP_REL4
#if MAP_REL99
PRIVATE MaTknEnum maLocEstiTypeEnums0[] =
{
 5, MAT_CURRENT_LOCATION, MAT_CURRENT_OR_LAST_KNOWN_LOCATION, 
    MAT_INITIA_LOCATION, MAT_ACTV_DEFER_LOCATION, MAT_CANCEL_DEFER_LOCATION,
};
#endif
#else  /* MAP_REL4 */
PRIVATE MaTknEnum maLocEstiTypeEnums0[] =
{
 3, MAT_CURRENT_LOCATION, MAT_CURRENT_OR_LAST_KNOWN_LOCATION, MAT_INITIA_LOCATION,
};
#endif /* MAP_REL4 */

PRIVATE MaTknEnum maLsaOnlyAccessIndEnums0[] =
{
 2, MAT_ACCESS_OUTSIDE_LSA_ALLOWED, MAT_ACCESS_OUTSIDE_LSA_RESTRICTED,
};

PRIVATE MaTknEnum maGmlcRestEnums0[] =
{
 2, MAT_GMLC_LIST, MAT_HOME_COUNTRY,
};

PRIVATE MaTknEnum maLcsClientIntIdEnums0[] =
{
 5, MAT_BROADCAST_SERVICE, MAT_O_AND_M_HPLMN, MAT_O_AND_M_VPLMN, MAT_ANONYMOUS_LOC,
    MAT_TARGT_MS_SUBS_SERV,
};

#if MAP_REL4
#if MAP_REL99
PRIVATE MaTknEnum maNotifcationToMsUsrEnums0[] =
{
 4, MAT_NOTIFY_LOC_ALLOW, MAT_NOTIFY_VERIFY_LOC_ALLOW_NO_RESP,
    MAT_NOTIFY_VERIFY_LOC_NOT_ALLOW_NO_RESP, MAT_LOC_NOT_ALLOWED,
};
#endif
#else /* MAP_REL4 */
PRIVATE MaTknEnum maNotifcationToMsUsrEnums0[] =
{
 3, MAT_NOTIFY_LOC_ALLOW, MAT_NOTIFY_VERIFY_LOC_ALLOW_NO_RESP,
    MAT_NOTIFY_VERIFY_LOC_NOT_ALLOW_NO_RESP,
};
#endif /* MAP_REL4 */

#endif /* MAP_REL98 || MAP_REL99 */

#if MAP_REL99
#if MAP_REL4

PRIVATE MaTknEnum maReqNodeTypeEnums0[] =
{
 2, MAT_VLR, MAT_SGSN,
};

PRIVATE MaTknEnum maTermCauseEnums0[] =
{
 7, MAT_NORMAL, MAT_ERROR_UNDEFINED, MAT_INTERNAL_TIMEOUT, MAT_TC_CONGESTION,
    MAT_MT_LR_RESTART, MAT_PRIVACY_VIOLATION, MAT_SHAPE_OF_LOC_ESTI_NOT_SUPP,
};

/* Added value for GPRS detach */
PRIVATE MaTknEnum maAccessTypeEnums0[] =
{
 11, MAT_CALL, MAT_EMERGENCY_CALL, MAT_LOCATION_UPDATING, 
     MAT_SUPPLEMENTARY_SERVICE, MAT_SHORT_MESSAGE, MAT_GPRS_ATTACH,
     MAT_ROUTING_AREA_UPDATING, MAT_SERVICE_REQUEST,
     MAT_PDP_CONTEXT_ACTIVATION, MAT_PDP_CONTEXT_DEACTIVATION, MAT_GPRS_DETACH,
};

#if MAP_REL5

PRIVATE MaTknEnum maMtSmsTpduTypeEnums0[] =
{
 3, MAT_SMS_DELIVER, MAT_SMS_SUBMIT_REPORT, MAT_SMS_STATUS_REPORT,
};

PRIVATE MaTknEnum maDomainTypeEnums0[] =
{
 2, MAT_CS_DOMAIN, MAT_PS_DOMAIN,
};

PRIVATE MaTknEnum maAddReqCamSubsInfoEnums0[] =
{
 5, MAT_MT_SMS_CSI, MAT_MG_CSI, MAT_O_IM_CSI, MAT_D_IM_CSI, MAT_VT_IM_CSI,
};

#endif /* MAP_REL5 */

#endif 

/* Addition: upgrade for MAP release 6 */
#if MAP_REL6
PRIVATE MaTknEnum maLcsFormatIndEnums0[] =
{
5, MAT_LOGICAL_NAME, MAT_EML_ADDRES, MAT_MS_ISDN, MAT_URL, MAP_SIP_URL
,
};

PRIVATE MaTknEnum maPrivacyChkRelActionEnums0[] = 
{
5,MAT_ALLOWED_WITHOUT_NOTIFICATION, MAT_ALLOWED_WITH_NOTIFICATION,
MAT_ALLOWED_IF_NO_RSP, MAT_RST_IF_NO_RSP, MAT_NOT_ALLOWED,
};

PRIVATE MaTknEnum maAreaTypeEnums0[] = 
{
 5, MAT_CNT_CODE, MAT_PLMN_ID, MAT_LOCA_ID, MAT_ROUT_AREA_ID, MAT_CELL_GLOB_ID,
};

 PRIVATE MaTknEnum maOccurInfoEnums0[] = 
 {
 2, MAT_ONE_TIME_EVNT, MAP_MULTI_TIME_EVNT,
 };

PRIVATE MaTknEnum maAddNetResEnums0[] =
{
6, MAT_SQSN, MAT_QQSN, MAT_QMLC, MAT_QSM_SCF, MAT_NPLR, MAT_AUC,
};
#endif /* MAP_REL6 */

/* ma001.203: Addition. Additional value */
#ifdef MAP_REL99
#ifdef MAP_CH_PLUS
/* Operate Type Enums */
PUBLIC MaTknEnum maOperateTypeEnums0[] =
{
   4,
   MAT_REDIRECTION,
   MAT_INS_PREFIX,
   MAT_ORIG_CALLED_NMB_EMPTY,
   MAT_ORG_CLD_AND_CLD_NMB_EMPTY,
};
#endif
#endif

PRIVATE MaTknEnum maCcbsReqStateEnums0[] =
{
 7, MAT_REQUEST, MAT_RECALL, MAT_ACTIVE, MAT_COMPLETED, MAT_SUSPENDED,
    MAT_FROZEN, MAT_DELETED,
};

PRIVATE MaTknEnum maAccNetProtIdEnums0[] =
{
 2, MAT_ACC_GSM_0806, MAT_TS3G_25413,
};

PRIVATE MaTknEnum maKeyStatusEnums0[] =
{
 2, MAT_OLD, MAT_NEW,
};

PRIVATE MaTknEnum maIstSupIndEnums0[] =
{
 2, MAT_BASIC_IST_SUPPORTED, MAT_IST_COMMAND_SUPPORTED,
};

PRIVATE MaTknEnum maModificationInstrEnums0[] =
{
 2, MAT_DEACTIVATE, MAT_ACTIVATE,
};

PRIVATE MaTknEnum maGprsTrgDetPtEnums0[] =
{
 5, MAT_ATTACH, MAT_ATTACH_CHANGE_OF_POSITION, MAT_PDP_CONTEXT_ESTABLISHMENT,
 MAT_PDP_CONTEXT_ESTABLISHMENT_ACK, MAT_PDP_CONTEXT_CHANGE_OF_POSITION,
};

PRIVATE MaTknEnum maReqCamSubsInfoEnums0[] =
{
 9, MAT_O_CSI, MAT_T_CSI, MAT_VT_CSI, MAT_TIF_CSI, MAT_GPRS_CSI, MAT_SMS_CSI,
    MAT_SS_CSI, MAT_M_CSI, MAT_D_CSI,
};

PRIVATE MaTknEnum maCallTermIndEnums0[] =
{
 2, MAT_TERM_CALL_ACTV_REF, MAT_TERM_ALL_ACTV,
};

PRIVATE MaTknEnum maFailureCauseEnums0[] =
{
2, MAT_WRONG_RSP, MAT_WRONG_NET_SIG,
};

#if MAP_REL5
PRIVATE MaTknEnum maSmsTrgDetPtEnums0[] =
{
 2, MAT_SMS_COLLECTED_INFO, MAT_SMS_DELIVERY_REQUEST,
};
#else
PRIVATE MaTknEnum maSmsTrgDetPtEnums0[] =
{
 1, MAT_SMS_COLLECTED_INFO,
};
#endif

PRIVATE MaTknEnum maDefSmsHandlEnums0[] =
{
 2, MAT_CONTINUE_TRANSACTION, MAT_RELEASE_TRANSACTION,
};

PRIVATE MaTknEnum maDefGprsHandlEnums0[] =
{
2, MAT_GPRS_CONTINUE_TRANSACTION, MAT_GPRS_RELEASE_TRANSACTION,
};

#if MAP_REL5
PRIVATE MaTknEnum maUnavailCauseEnums0[] =
{
6, MAT_BEAR_NOT_PROV, MAT_TELE_NOT_PROV, MAT_ABSENT_SUBS, MAT_BUSY_SUBS, MAT_CALL_BARRED, MAT_CUG_REJECT,
};
#endif /* MAP_REL5 */
#endif /* MAP_REL99 */

#if (MAP_REL98 || MAP_REL99)

PUBLIC MaTknEnum *maNmbPortStatEnums[MA_MAX_SWITCH] = 
{
 maNmbPortStatEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maExtProtIdEnums[MA_MAX_SWITCH] = 
{
 maExtProtIdEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maLcsEventEnums[MA_MAX_SWITCH] = 
{
 maLcsEventEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maUnAuthLcsClientParamEnums[MA_MAX_SWITCH] = 
{
 maUnAuthLcsClientParamEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maPosiMethFailDiagEnums[MA_MAX_SWITCH] = 
{
 maPosiMethFailDiagEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maResponseTimeEnums[MA_MAX_SWITCH] = 
{
 maResponseTimeEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maLcsClientTypeEnums[MA_MAX_SWITCH] = 
{
 maLcsClientTypeEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maLocEstiTypeEnums[MA_MAX_SWITCH] = 
{
 maLocEstiTypeEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maLsaOnlyAccessIndEnums[MA_MAX_SWITCH] = 
{
 maLsaOnlyAccessIndEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maGmlcRestEnums[MA_MAX_SWITCH] = 
{
 maGmlcRestEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maLcsClientIntIdEnums[MA_MAX_SWITCH] = 
{
 maLcsClientIntIdEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maNotifcationToMsUsrEnums[MA_MAX_SWITCH] = 
{
 maNotifcationToMsUsrEnums0,
 NULLP,
};

#endif /* MAP_REL98 || MAP_REL99 */

#if MAP_REL99
#if MAP_REL4

PUBLIC MaTknEnum *maReqNodeTypeEnums[MA_MAX_SWITCH] =
{
   maReqNodeTypeEnums0,
   NULLP,
};

PUBLIC MaTknEnum *maTermCauseEnums[MA_MAX_SWITCH] =
{
   maTermCauseEnums0,
   NULLP,
};

PUBLIC MaTknEnum *maAccessTypeEnums[MA_MAX_SWITCH] =
{
   maAccessTypeEnums0,
   NULLP,
};

#if MAP_REL5

PUBLIC MaTknEnum *maMtSmsTpduTypeEnums[MA_MAX_SWITCH] =
{
   maMtSmsTpduTypeEnums0,
   NULLP,
};

PUBLIC MaTknEnum *maDomainTypeEnums[MA_MAX_SWITCH] =
{
   maDomainTypeEnums0,
   NULLP,
};

PUBLIC MaTknEnum *maAddReqCamSubsInfoEnums[MA_MAX_SWITCH] =
{
   maAddReqCamSubsInfoEnums0,
   NULLP,
};

#endif /* MAP_REL5 */

#endif

/* Addition: Upgrade for MAP release 6 */

#if MAP_REL6

/* LCS Format Indicator Enums */
 PUBLIC MaTknEnum *maLcsFormatIndEnums[MA_MAX_SWITCH] =
{ 
 maLcsFormatIndEnums0,
 NULLP,
};

/* Area Type Enums */
PUBLIC MaTknEnum  *maAreaTypeEnums[MA_MAX_SWITCH] =
{
  maAreaTypeEnums0,
  NULLP,
};

/* Privacy Check Related Action */
PUBLIC MaTknEnum *maPrivacyChkRelActionEnums[MA_MAX_SWITCH] =
{
  maPrivacyChkRelActionEnums0,
  NULLP,
};

/* Occurnace info Enums */
PUBLIC MaTknEnum *maOccurInfoEnums[MA_MAX_SWITCH] =
{
  maOccurInfoEnums0,
  NULLP,
};

PUBLIC  MaTknEnum *maAddNetResEnums[MA_MAX_SWITCH] =
{
   maAddNetResEnums0,
   NULLP,
};
#endif /* MAP_REL6 */

PUBLIC MaTknEnum *maReqCamSubsInfoEnums[MA_MAX_SWITCH] =
{
   maReqCamSubsInfoEnums0,
   NULLP,
};

PUBLIC MaTknEnum *maCallTermIndEnums[MA_MAX_SWITCH] =
{
   maCallTermIndEnums0,
   NULLP,
};

PUBLIC MaTknEnum *maSmsTrgDetPtEnums[MA_MAX_SWITCH] = 
{
 maSmsTrgDetPtEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maDefSmsHandlEnums[MA_MAX_SWITCH] = 
{
 maDefSmsHandlEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maCcbsReqStateEnums[MA_MAX_SWITCH] = 
{
 maCcbsReqStateEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maAccNetProtIdEnums[MA_MAX_SWITCH] = 
{
 maAccNetProtIdEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maKeyStatusEnums[MA_MAX_SWITCH] = 
{
 maKeyStatusEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maIstSupIndEnums[MA_MAX_SWITCH] = 
{
 maIstSupIndEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maModificationInstrEnums[MA_MAX_SWITCH] = 
{
 maModificationInstrEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maGprsTrgDetPtEnums[MA_MAX_SWITCH] = 
{
 maGprsTrgDetPtEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maDefGprsHandlEnums[MA_MAX_SWITCH] = 
{
 maDefGprsHandlEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maFailureCauseEnums[MA_MAX_SWITCH] = 
{
 maFailureCauseEnums0,
 NULLP,
};

#endif /* MAP_REL99 */

PUBLIC MaTknEnum *maNetResEnums[MA_MAX_SWITCH] = 
{
 maNetResEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maProtIdEnums[MA_MAX_SWITCH] = 
{
 maProtIdEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maCancelTypeEnums[MA_MAX_SWITCH] = 
{
 maCancelTypeEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maEqupStatEnums[MA_MAX_SWITCH] = 
{
 maEqupStatEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maInterHoTypeEnums[MA_MAX_SWITCH] = 
{
 maInterHoTypeEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maIntraCugOptEnums[MA_MAX_SWITCH] = 
{
 maIntraCugOptEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maCliRestOptEnums[MA_MAX_SWITCH] = 
{
 maCliRestOptEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maOvrRideCatEnums[MA_MAX_SWITCH] = 
{
 maOvrRideCatEnums0,
 NULLP,
};
PUBLIC MaTknEnum *maHntGrpAccSelOdrEnums[MA_MAX_SWITCH] = 
{
 maHntGrpAccSelOdrEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maRegSubsRspEnums[MA_MAX_SWITCH] = 
{
 maRegSubsRspEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maSMDelStatEnums[MA_MAX_SWITCH] = 
{
 maSMDelStatEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maAlrtReasonEnums[MA_MAX_SWITCH] = 
{
 maAlrtReasonEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maSubsStatEnums[MA_MAX_SWITCH] = 
{
 maSubsStatEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maGuidInfoEnums[MA_MAX_SWITCH] = 
{
 maGuidInfoEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maReqParamEnums[MA_MAX_SWITCH] = 
{
 maReqParamEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maCallTypeCritEnums[MA_MAX_SWITCH] = 
{
 maCallTypeCritEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maMatchTypeEnums[MA_MAX_SWITCH] = 
{
 maMatchTypeEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maDefCallHandlEnums[MA_MAX_SWITCH] = 
{
 maDefCallHandlEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maOBcsmTrigDetPtEnums[MA_MAX_SWITCH] = 
{
 maOBcsmTrigDetPtEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maTBcsmTrigDetPtEnums[MA_MAX_SWITCH] =
{
 maTBcsmTrigDetPtEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maRptStateEnums[MA_MAX_SWITCH] = 
{
 maRptStateEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maRufOutcomeEnums[MA_MAX_SWITCH] = 
{
 maRufOutcomeEnums0,
 NULLP,
};
PUBLIC MaTknEnum *maCcbsSubsStatusEnums[MA_MAX_SWITCH] = 
{
 maCcbsSubsStatusEnums0,
 NULLP,
};
PUBLIC MaTknEnum *maMonModeEnums[MA_MAX_SWITCH] = 
{
 maMonModeEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maCallOutComeEnums[MA_MAX_SWITCH] = 
{
 maCallOutcomeEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maNotRchRsnEnums[MA_MAX_SWITCH] = 
{
 maNotRchRsnEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maInterroTypeEnums[MA_MAX_SWITCH] = 
{
 maInterroTypeEnums0,
 NULLP,
};


PUBLIC MaTknEnum *maFwdReasonEnums[MA_MAX_SWITCH] = 
{
 maFwdReasonEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maSMDelOutComeEnums[MA_MAX_SWITCH] = 
{
 maSMDelOutComeEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maNetAccModeEnums[MA_MAX_SWITCH] = 
{
 maNetAccModeEnums0,
 NULLP,
};

/* ma001.203: Addition. Additional value */
#if MAP_REL99
#ifdef MAP_CH_PLUS
PUBLIC MaTknEnum *maOperateTypeEnums[MA_MAX_SWITCH] =
{
 maOperateTypeEnums0,
 NULLP,
};
#endif
#endif

/* Roam Not Allowed Enumeration */
PUBLIC MaTknEnum maRoamNotAllCauseEnums0[] =
{
   2,
   MAT_PLMN_ROAM_NOTALLOWED,
   MAT_OPR_DET_BARRING,
};


/* Call Barring Cause Enums */
PUBLIC MaTknEnum maCallBarrCauseEnums0[] =
{
#ifndef XWEXT	
   2,
#else
   3,
#endif /* XWEXT */   
   MAT_BARRING_SERV_ACTV,
   MAT_OPR_BARRING,
#ifdef XWEXT
   MAT_PIRATED_BARRING,
#endif   
};

/* Cug Reject Cause Enums */
PUBLIC MaTknEnum maCugRejectCauseEnums0[] =
{
   4,
   MAT_INCALL_BARR_CUG,
   MAT_SUBS_NOT_MEM_CUG,
   MAT_RBS_VIOL_CUG,
   MAT_CPTY_INTER_VIOL,
};


/* Password Registration  Failure Cause Enums */
PUBLIC MaTknEnum maPwRegFailCauseEnums0[] =
{
   3,
   MAT_UNDETERMINED,
   MAT_INV_FRMT,
   MAT_NEW_PASSWD_MISMATCH,
};

/* SM Delivery Failure Cause Enums */
PUBLIC MaTknEnum maSMDlvyFailCauseEnums0[] =
{
   7,
   MAT_MEM_EXCEEDED,
   MAT_EQP_PROT_ERR,
   MAT_EQP_NOTSM_EQUIPPED,
   MAT_UNK_SC,
   MAT_SC_CONGESTION,
   MAT_INV_SME_ADDR,
   MAT_SUBS_NOT_SC_SUBS,
};

/* Unknown Subscriber Diagnostics Enums */

#if MAP_REL99
#else /* MAP_REL99 */
PUBLIC MaTknEnum maUnknownSubsDiagEnums0[] =
{
   2,
   MAT_IMSI_UNKNOWN,
   MAT_GPRS_SUBSCRIPTION_OPTION,
};

PUBLIC MaTknEnum maAbsSubsRsnEnums0[] =
{
   3,
   MAT_IMSI_DETACH,
   MAT_ASR_RESTRICTED_AREA,
   MAT_NO_PAGE_RESPONSE,
};
#endif /* MAP_REL99 */
#if MAP_REL99            
PUBLIC MaTknEnum maUnknownSubsDiagEnums0[] =
{
#ifndef XWEXT /* xingzhou.xu: dirated reason 2006/10/13 */
   3,
#else
   4,
#endif   
   MAT_IMSI_UNKNOWN,
   MAT_GPRS_SUBSCRIPTION_OPTION,
   MAT_NPDB_MISMATCH,
#ifdef XWEXT /* xingzhou.xu: dirated reason 2006/10/13 */
   MAT_DIA_PIRATED_REASON,
#endif
};

PUBLIC MaTknEnum maAbsSubsRsnEnums0[] =
{
   /* ma001.203 : modification, no of elements should be 4 */
   4,
   MAT_IMSI_DETACH,
   MAT_ASR_RESTRICTED_AREA,
   MAT_NO_PAGE_RESPONSE,
   MAT_PURGED_MS,
};

#endif /* MAP_REL99 */

/* Absent Subscriber Reason Enums */

/* Unknown Subscriber Diagnostics Enums */
PUBLIC MaTknEnum *maUnknownSubsDiagEnums[MA_MAX_SWITCH] =
{
   &maUnknownSubsDiagEnums0[0],
   NULLP,
};

/* Absent Subscriber Reason Enums */
PUBLIC MaTknEnum *maAbsSubsRsnEnums[MA_MAX_SWITCH] =
{
   &maAbsSubsRsnEnums0[0],
   NULLP,
};

/* Roaming Not Allowed Cause Enums */
PUBLIC MaTknEnum *maRoamNotAllCauseEnums[MA_MAX_SWITCH] =
{
   &maRoamNotAllCauseEnums0[0],
   NULLP,
};

/* Call Barring Cause Enums */
PUBLIC MaTknEnum *maCallBarrCauseEnums[MA_MAX_SWITCH] =
{
   &maCallBarrCauseEnums0[0],
   NULLP,
};

/* Cug Reject Cause Enums */
PUBLIC MaTknEnum *maCugRejectCauseEnums[MA_MAX_SWITCH] =
{
   &maCugRejectCauseEnums0[0],
   NULLP,
};

/* Password Registration Failure Cause Enums */
PUBLIC MaTknEnum *maPwRegFailCauseEnums[MA_MAX_SWITCH] =
{
   &maPwRegFailCauseEnums0[0],
   NULLP,
};

/* SM Delivery Failure Cause Enums */
PUBLIC MaTknEnum *maSMDlvyFailCauseEnums[MA_MAX_SWITCH] =
{
   &maSMDlvyFailCauseEnums0[0],
   NULLP,
};

#if MAP_REL5
/* Unavailability Cause Enums */
PUBLIC MaTknEnum *maUnavailCauseEnums[MA_MAX_SWITCH] =
{
   &maUnavailCauseEnums0[0],
   NULLP,
};
#endif /* MAP_REL5 */

#ifdef XWEXT
/*for xinwei*/

PUBLIC MaTknEnum maXWExtUpdateTypeEnums0[] =
{
	5, 
 	MA_XINWEI_POWER_ON_UD,
 	MA_XINWEI_OVER_AREA_UD,
 	MA_XINWEI_HANDOFF_UD,
 	MA_XINWEI_IMPLICITED_UD,
 	MA_XINWEI_POWER_OFF_UD
};

PUBLIC MaTknEnum maXWExtCallOutRigtEnums0[] =
{
	4,						/* xingzhou.xu: length modified from 5 to 4*/
	MA_XINWEI_ALLOUT_PER,
	MA_XINWEI_ALLOUT_RES, 
	MA_XINWEI_LONGCALL_RES,
	MA_XINWEI_INTCALL_RES,
#if 0/*xinghzou.xu: deleted according to criterion V1.23 2006/09/30 */	
	MA_XINWEI_IPCALL_RES,
#endif	
};

PUBLIC MaTknEnum *maXWExtUpdateTypeEnums[MA_MAX_SWITCH] = 
{
 maXWExtUpdateTypeEnums0,
 NULLP,
};

PUBLIC MaTknEnum *maXWExtCallOutRigtEnums[MA_MAX_SWITCH] = 
{
 maXWExtCallOutRigtEnums0,
 NULLP,
};

PUBLIC MaTknEnum maXWExtDetectModeEnums0[] =
{
	4,
	MA_XINWEI_DETECT_RESERVED1,
	MA_XINWEI_DETECT_ALL_AREA, 
	MA_XINWEI_DETECT_RESERVED3,
	MA_XINWEI_DETECT_RESERVED4,
};

PUBLIC MaTknEnum *maXWExtDetectModeEnums[MA_MAX_SWITCH] = 
{
 maXWExtDetectModeEnums0,
 NULLP,
};

PUBLIC MaTknEnum maXWExtDetectRsltEnums0[] =
{
	2,
	MA_XINWEI_DETECT_SUCC,
	MA_XINWEI_DETECT_FAIL, 

};

PUBLIC MaTknEnum *maXWExtDetectRsltEnums[MA_MAX_SWITCH] = 
{
 maXWExtDetectRsltEnums0,
 NULLP,
};
#endif /* XWEXT */

/********************************************************************30**

         End of file:     ca_db1.c@@/main/8 - Fri Sep 16 02:47:35 2005

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/


/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  aa    1. initial release

*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.2          ---      aa   1. Changed the maTeDefDlg* definations

1.3          ---      ssk  1. Added Phase 2+ variant

/main/4      ---      jie  1. update for MAP 1.5 release.

             ---      jie  1. Rolling Upgrade compliance.

             ---      jie  1. Change for MAP REL4 support without the MAPsec 
                              feature.

/main/5      ---      jie  1. update for MAP 1.6 release.

             ---      yz   1. Adding Phase 1 choice component.

             ---      jie  3. Change for 2002/09 rel99/rel4 release.

/main/6      ---      jie  1. update for MAP 1.7 release.

             ---      jie  1. Phase-1 changes for June-03 specifications 
                              for release 4 & 5
/main/7      ---      zj   1. Update for MAP 2.1 release
             ---      st   1. Updated the enum valued for maNmbPortStatEnums0
                           2. Introduced maUnavailCauseEnums0 Enum.

/main/8      ---      rbabu 1.Update for MAP 2.3 release
ma001.203    ---      st   1. Fix for the no of elements  in maAbsSubsRsnEnums0
									  2. Added values for Interrogation type  
*********************************************************************91*/
