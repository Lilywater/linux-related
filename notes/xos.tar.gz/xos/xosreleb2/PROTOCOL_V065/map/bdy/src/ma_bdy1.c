/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     map
  
     Type:     C Source file
  
     Desc:     C source code for MAP Upper Layer, Lower Layer,
               System Service and Layer Management primitives 
               supplied by TRILLIUM.
  
     File:     ca_bdy1.c
  
     Sid:      ca_bdy1.c@@/main/11 - Fri Sep 16 02:46:32 2005
  
     Prg:      ssk
  
*********************************************************************21*/


/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#if MAP_MSC
#if MAP_VLR
#if MAP_HLR
      -05      MSC, VLR and HLR
#else
#endif
#else
#if MAP_HLR
#else
      -01      MSC
#endif
#endif
#else
#if MAP_VLR
#if MAP_HLR
      -04      VLR and HLR
#else
      -02      VLR
#endif
#else
#if MAP_HLR
      -03      HLR
#else
#endif
#endif
#endif

************************************************************************/
 

/* 
Upper Layer functions interface to the MAP user.

The following functions are provided in this file:

Upper layer functions

    MaUiMatBndReq       Bind Request
    MaUiMatUbndReq      Unbind Request
    MaUiMatOpenReq      MAP Open Request
    MaUiMatOpenRsp              MAP Open Response
    MaUiMatCloseReq             MAP Close Request
    MaUiMatDelimReq             MAP Delimeter request 
    MaUiMatAbrtReq              MAP abort dialogue request 

Lower layer functions

    MaLiStuDatInd               Data Indication
    MaLiStuCmpInd               Component indication
    MaLiStuCmpCfm               Component confirm
    MaLiStuNotInd               Notice indication
    MaLiStuStaInd               Status Indication
    MaLiStuSteInd               State Indication
    MaLiStuSteCfm               State Confirm

Layer Management functions

    MaMiLmaCfgReq               Configuration request
    MaMiLmaStaReq               Status Request
    MaMiLmaStsReq               Statistics Request
    MaMiLmaCntrlReq             Control Request

System Services

    maActvInit                  Activate task - initialize
    maActvTmr                   Activate task - timer

The following function are expected from the interface providers

Upper Interface (ma_ptui.c)

    MaUiMatOpenInd              MAP Open Indication
    MaUiMatOpenCfm              MAP Open Confirm
    MaUiMatCloseInd             MAP Close Indication
    MaUiMatDelimInd             MAP Delimeter Indication 
    MaUiMatAbrtInd              MAP abort dialogue Indication 
    MaUiMatNotInd               MAP Notice Indication

Lower Interface
    MaLiStuBndReq               Bind Request
    MaLiStuDatReq               Data Request
    MaLiStuCmpReq               Component Rqeuest

Layer Management (ma_ptmi.c)
    MaMiLmsStaInd               Status Indication
    MaMiLmaTrcInd               Trcae Indication
    MaMiLmaStaCfm               Status confirm
    MaMiLmaStsCfm               Statistics confirm

System Services

    SInitQueue     Initialize Queue
    SQueueFirst    Queue to First Place
    SQueueLast     Queue to Last Place
    SDequeueFirst  Dequeue from First Place
    SDequeueLast   Dequeue from Last Place
    SFndLenQueue   Find Length of Queue
  
    SGetMsg        Get Message
    SPutMsg        Put Message
  
    SAddPreMsg     Add Pre Message
    SAddPstMsg     Add Post Message
    SRemPreMsg     Remove Pre Message
    SRemPstMsg     Remove Post Message
    SFndLenMsg     Find Length of Message
  
    SGetSBuf       Get Static Buffer
  
    SChkRes        Check Resources
    SGetDateTime   Get Date and Time
    SGetSysTime    Get System Time
  
    SRegTmr        Register Activate Task - timer
*/

/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "lma.h"           /* layer management, MAP */
#include "cm_err.h"        /* common error */
#include "stu.h"           /* tcap layer */
#include "mat.h"           /* MAT Interface */
#ifdef MA_FTHA
#include  "sht.h"
#endif /* MA_FTHA */
#include "cm5.h"           /* common timer */
#include "ma_err.h"        /* map error */
#include "cm_ss7.h"
#include "ma.h"            /* map */
#ifdef ZJ
#include "cm_ftha.h"       /* Common FTHA */
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#include "cm_tupsf.h"      /* Common TCAP user PSF */
#include "zj.h"            /* Tcap PSF defines */
#include "lzj.h"
#endif /* ZJ */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* common timer */
#include "cm_lib.x"        /* Common Portable Library */
#include "cm_ss7.x"        /* common SS7 */
#include "stu.x"           /* tcap layer */
#include "lma.x"           /* layer management, TCAP */
#include "mat.x"           /* MAT Interface */
#ifdef MA_FTHA
#include  "sht.x"
#endif /* MA_FTHA */
#ifdef ZJ
#include "cm_ftha.x"       /* Common FTHA */
#include "cm_pftha.x"      /* Common PSF defines */
#include "cm_psfft.x"
#include "cm_tupsf.x"      /* Common TCAP user PSF */
#endif /* ZJ */
#include "ma.x"            /* map */
#ifdef ZJ
#include "zj.x"            /* Tcap PSF defines */
#include "lzj.x"
#endif /* ZJ */
  
/* Public variable declarations */
/* ma002.203 : Addition. list of control blocks. */
#ifdef SS_MULTIPLE_PROCS
/* Array of control blocks */
MaCb maCbLst[MA_MAX_INSTANCES] ;
MaCb *maCbPtr ;
#else
MaCb  maCb;
#endif

EXTERN U32 g_maDbgMask;

#ifdef MA_STATIC_EVT_STRUCT

/* 
** One  global encode evt structure buffer and one global 
** decode buffer structure are declared here.
*/

#if ( defined(LCMAUIMAT) || defined(LWLCMAUIMAT))
MaAllSSEv *maGlobEncEv; /* Global Encode event structure */
#endif /* LCMAUIMAT */
MaAllSSEv *maGlobDecEv; /* Global Decode event structure */

#endif /* MA_STATIC_EVT_STRUCT */

/*
*
*       Fun:   Configuration Request
*
*       Desc:  This function is used by the Layer Management to
*              configure the layer.
*
*       Ret:   ROK      - ok
*
*       Notes: Configuration must be performed in the following sequence:
*              1) general configuration (STGEN);
*              2) MAP sap configuration (STMAUSAP).
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaMiLmaCfgReq
(
Pst *pst,                    /* post structure */
MaMngmt *cfg                 /* configuration structure */
)
#else
PUBLIC S16 MaMiLmaCfgReq(pst, cfg)
Pst *pst;                    /* post structure */
MaMngmt *cfg;                /* configuration structure */
#endif
{
   Size memSize;           /* memory size */
   U32 i;                  /* index */
   U16 j;                  /* index */
   U8 *tmp;                /* temporary memory pointer */
   S16 ret;                /* return code */
   MaSap *s;               /* MAP sap */
   U32 bitMapSize;         /* dlgId bitmap */
   U32 bits;               /* bits for bitmap */
#ifdef MA_RUG
   U16  maxSaps;           /* Maximum number of upper * 
                              and lower Saps together */ 
   Size maxIntfSize;       /* Maximum interface version info size */
   Data *pData;            /* pointer to data allocated by system */
#endif /* MA_RUG */
#if MAP_REL99
#if (MAP_SEC && LMAV2)
   Size maxSecSize;        /* memory size for MAPsec*/
   MaSaCp *saCp;           /* dialog control point */
   LmaSecPgCfg  *pgCp;     /* PG control point */
   LmaSecPpCfg  *ppCp;     /* PG control point */
   Data *pgPtr;            /* pointer to data allocated by system for PG */
   Data *ppPtr;            /* pointer to data allocated by system for PP */
   Data *saPtr;            /* pointer to data allocated by system for SA */
   Data *saMapPtr;         /* pointer to data allocated for SA mapping Tbl */
   MaSaMapCp *saMapCp;     /* Sa Mapping control point */
#endif
#endif

   Pst     sender;
   MaMngmt cfm_msg;
/* ma012.203: Addition to support Dlg Hash Size configuration through Layer manager
 * */
#ifdef MAP_NSRP
  Data *dlgHshPtr; /* pointer to data allocated by system for Dlg Tbl */
#endif /*MAP_NSRP */

   TRC3(MaMiLmaCfgReq)
/* ma002.203 : Addition. Control block retreival. */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
                ERRCLS_DEBUG, EMA383, 0," MaMiLmaCfgReq() failed, cannot derive maCb");
          RETVALUE(RFAILED);

   }

   MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif

   MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                      "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d))\n", 
                       cfg->hdr.elmId.elmnt, 
                       cfg->hdr.elmId.elmntInst1));

   maFillReplyPst(pst,cfg,&cfm_msg,MA_EVTLMACFGCFM,&sender);

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((cfg->hdr.msgType != TCFG) || (cfg->hdr.entId.ent != maCb.maInit.ent) ||
       (cfg->hdr.entId.inst != maCb.maInit.inst) ||
      ((cfg->hdr.elmId.elmnt != STMATGEN) && 
      (cfg->hdr.elmId.elmnt != STMATSAP)
#if MAP_REL99
#if (MAP_SEC && LMAV2)
      && (cfg->hdr.elmId.elmnt != STMATPG)
      && (cfg->hdr.elmId.elmnt != STMATPP)
      && (cfg->hdr.elmId.elmnt != STMATSA)
#endif
#endif
      ))
   {
      cfm_msg.cfm.status = LCM_PRIM_NOK;
      cfm_msg.cfm.reason = LCM_REASON_INVALID_PAR_VAL;
      MaMiLmaCfgCfm(&sender,&cfm_msg);

     MALOGERROR(ERRCLS_INT_PAR, EMA001, (ErrVal)LMA_CFG_BAD_PARAM, 
                "MaMiLmaCfgReq() Failed, invalid paramrter.");
     RETVALUE(RFAILED);
   }
#endif

   /* elmnt contains the type type of configuration requested */  
   switch (cfg->hdr.elmId.elmnt)
   {
      /* general configuration */
      case STMATGEN:

         /* layer manager interface could range only 0 to 1 */
         if (cfg->t.cfg.s.maGen.smPst.selector >= MAXMAMI)
         {
            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LCM_REASON_INVALID_PAR_VAL;
            MaMiLmaCfgCfm(&sender,&cfm_msg);

            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
            "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed,\
            invaid layer manager interface selector.\n", 
            cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));

            MALOGERROR(ERRCLS_INT_PAR, EMA002, 
                       (ErrVal)cfg->t.cfg.s.maGen.smPst.selector, 
                       "MaMiLmaCfgReq () Failed, invalid selector.");
            RETVALUE(RFAILED);
         }

         /* validate configuration parameters */
         if (cfg->t.cfg.s.maGen.nmbMAUSaps > MA_MAX_USAPS)
         {
            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LCM_REASON_INVALID_PAR_VAL;
            MaMiLmaCfgCfm(&sender,&cfm_msg);

            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
            "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed,\
            max number of saps exceeded.\n", 
            cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));

            MALOGERROR(ERRCLS_INT_PAR, EMA003, (ErrVal)maCb.maInit.cfgDone, 
                       "MaMiLmaCfgReq() Failed, max number of saps exceeded.");
            RETVALUE(RFAILED);
         }

#if MAP_REL99
#if (MAP_SEC && LMAV2)
/* ma012.203: Addition, to support Security feature as configurable */
#ifdef MAP_SEC_RECFG
      if (cfg->t.cfg.s.maGen.secGenCfg.mapSecFlg == TRUE) 
      {
#endif /*MAP_SEC_RECFG */
         /* validate MAPsec configuration parameters */
         if ((ret = maChkSecParam(cfg, &cfm_msg.cfm.reason)) != ROK)
         {
            cfm_msg.cfm.status = LCM_PRIM_NOK;
            MaMiLmaCfgCfm(&sender,&cfm_msg);
            RETVALUE(RFAILED);
         }

/* ma012.203: Addition, to support Security feature as configurable */
#ifdef MAP_SEC_RECFG
     }
#endif /* MAP_SEC_RECFG */
#endif /* MAP_SEC */
#endif
#ifdef MA_SEG
         /* validate signalling frame size for MAP-segmentation */
         if ((cfg->t.cfg.s.maGen.sigFrameSz > 0) && 
             (cfg->t.cfg.s.maGen.sigFrameSz <= MA_OPRRSP_OFFSET))
         {
            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LCM_REASON_INVALID_PAR_VAL;
            MaMiLmaCfgCfm(&sender,&cfm_msg);

            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
            "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed,\
            first segment offset exceeded signalling frame size.\n", 
            cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));

            MALOGERROR(ERRCLS_INT_PAR, EMA004, (ErrVal)maCb.maInit.cfgDone, 
                       "MaMiLmaCfgReq() Failed, first segment offset \
                        exceeded signalling frame size.");
            RETVALUE(RFAILED);
         }
#endif
         /* Re-Configuration of lmPst structure is allowed */
         if (maCb.maInit.cfgDone == TRUE)
         {
            maCb.maInit.lmPst.selector  = cfg->t.cfg.s.maGen.smPst.selector;
            maCb.maInit.lmPst.region = cfg->t.cfg.s.maGen.smPst.region;
            maCb.maInit.lmPst.pool = cfg->t.cfg.s.maGen.smPst.pool;
            maCb.maInit.lmPst.dstProcId = cfg->t.cfg.s.maGen.smPst.dstProcId;
            maCb.maInit.lmPst.dstEnt = cfg->t.cfg.s.maGen.smPst.dstEnt;
            maCb.maInit.lmPst.dstInst = cfg->t.cfg.s.maGen.smPst.dstInst;
            maCb.maInit.lmPst.srcProcId = maCb.maInit.procId;
            maCb.maInit.lmPst.srcEnt = cfg->t.cfg.s.maGen.smPst.srcEnt;
            maCb.maInit.lmPst.srcInst = cfg->t.cfg.s.maGen.smPst.srcInst;
            maCb.maInit.lmPst.prior = cfg->t.cfg.s.maGen.smPst.prior;
            maCb.maInit.lmPst.route = cfg->t.cfg.s.maGen.smPst.route;
            maCb.maInit.lmPst.event = EVTNONE;
#ifdef MA_RUG
            /*  LM interface version number will be used *        
             *  by MAP to  generate alarms and trace     *
             *  indications                              */
            maCb.maInit.lmPst.intfVer = cfg->t.cfg.s.maGen.smPst.intfVer;
#endif /* MA_RUG */
            cmCopy((U8 *) &maCb.maInit.lmPst, (U8 *)&maCb.maCP.smPst,sizeof(Pst));

#if MAP_REL99
#if (MAP_SEC && LMAV2)
            /* reconfiguration of MAPsec general parameters */
/*ma012.203: Added to support Security feature as configurable */
#ifdef MAP_SEC_RECFG
          if (((maCb.maCP.secGenCfg.mapSecFlg != TRUE) ||
             (cfg->t.cfg.s.maGen.secGenCfg.mapSecFlg !=FALSE)))
          {
#endif /* MAP_SEC_RECFG */
            maInitOpCmpTbl(&cfg->t.cfg.s.maGen.secGenCfg);

            maCb.maCP.secGenCfg.tvpWinSz = cfg->t.cfg.s.maGen.secGenCfg.tvpWinSz;
            maCb.maCP.secGenCfg.tvPeriod = cfg->t.cfg.s.maGen.secGenCfg.tvPeriod;
            maCb.maCP.secGenCfg.secPlmnsOnly = 
                              cfg->t.cfg.s.maGen.secGenCfg.secPlmnsOnly;
/*ma012.203: Added to support Security feature as configurable */
#ifdef MAP_SEC_RECFG
           maCb.maCP.secGenCfg.plmnId = cfg->t.cfg.s.maGen.secGenCfg.plmnId;
           maCb.maCP.secGenCfg.rxFbInd = cfg->t.cfg.s.maGen.secGenCfg.rxFbInd;
         }
#endif /* MAP_SEC_RECFG  */
#endif /* MAP_SEC */
#endif

            maCb.maInit.cfgDone = TRUE;

#ifdef MA_SEG 
            maCb.maCP.sigFrameSz = cfg->t.cfg.s.maGen.sigFrameSz;
#endif /* MA_SEG */
            cfm_msg.cfm.status = LCM_PRIM_OK;
            cfm_msg.cfm.reason = LCM_REASON_NOT_APPL;
            MaMiLmaCfgCfm(&sender,&cfm_msg);

            RETVALUE(ROK);
         }
/* ma012.203: Addition, To support Security feature as configurable */
#ifdef MAP_SEC
#ifdef MAP_SEC_RECFG
         maCb.maCP.secGenCfg.mapSecFlg = cfg->t.cfg.s.maGen.secGenCfg.mapSecFlg; 
#endif /* MAP_SEC_RECFG */
#endif /* MAP_SEC */
         /* copy general configuration parameters */
         cmCopy( (U8 *)&cfg->t.cfg.s.maGen,(U8 *)&maCb.maCP, sizeof(MaGenCfg) );

         /* Initialize the counter for Number of Invokes allocated */
         maCb.maInvCnt = 0;

         /* compute memory necessary for the bit maps */
         bitMapSize    = (cfg->t.cfg.s.maGen.range >>  3) +
                         ((cfg->t.cfg.s.maGen.range & 0x7)?(1):(0));

#ifdef LCMAUIMAT
         /* compute memory necessary to run */
         /* determine total number of MAP saps */
         /* add max number of MAP Dialogs, and Operations */
         memSize = (Size)(maCb.maCP.nmbMAUSaps * SBUFSIZE(sizeof(MaSap)) +
                          SBUFSIZE(maCb.maCP.nmbMAUSaps * sizeof(MaSap *)) + 
                          maCb.maCP.nmbDlgs * SBUFSIZE(sizeof(MaDlgCp)) + 
                          2*sizeof(MaAllSSEv)                      +
                          bitMapSize                               + 
                          maCb.maCP.nmbOpr * SBUFSIZE(sizeof(MaCmpCp)));
#else
#ifdef LWLCMAUIMAT
         /* compute memory necessary to run */
         /* determine total number of MAP saps */
         /* add max number of MAP Dialogs, and Operations */
         memSize = (Size)(maCb.maCP.nmbMAUSaps * SBUFSIZE(sizeof(MaSap)) +
                          SBUFSIZE(maCb.maCP.nmbMAUSaps * sizeof(MaSap *)) + 
                          maCb.maCP.nmbDlgs * SBUFSIZE(sizeof(MaDlgCp)) + 
                          bitMapSize                               + 
                          2*sizeof(MaAllSSEv)                        +
                          maCb.maCP.nmbOpr * SBUFSIZE(sizeof(MaCmpCp)));
#else /* LWLCMAUIMAT */
         /* compute memory necessary to run */
         /* determine total number of MAP saps */
         /* add max number of MAP Dialogs, and Operations */
         memSize = (Size)(maCb.maCP.nmbMAUSaps * SBUFSIZE(sizeof(MaSap)) +
                          SBUFSIZE(maCb.maCP.nmbMAUSaps * sizeof(MaSap *)) + 
                          maCb.maCP.nmbDlgs * SBUFSIZE(sizeof(MaDlgCp)) + 
                          bitMapSize                               + 
                          sizeof(MaAllSSEv)                        +
                          maCb.maCP.nmbOpr * SBUFSIZE(sizeof(MaCmpCp)));
#endif /* LWLCMAUIMAT */
#endif /* LCMAUIMAT */

#ifdef MA_RUG            
         /* Memory is calculated by taking into account max
          * number of SAPs and size of Version Information */
         maxSaps = 2 * maCb.maCP.nmbMAUSaps;
         maxIntfSize = maxSaps * sizeof(ShtVerInfo);

         /* Add memory for interface version information */
         memSize += maxIntfSize;
#endif /* MA_RUG */

#if MAP_REL99
#if (MAP_SEC && LMAV2)
         /* Add memory for MAPsec */
         maxSecSize = maCb.maCP.secGenCfg.maxPlmn * SBUFSIZE(sizeof(MaSaCp)) +
                      SBUFSIZE(maCb.maCP.secGenCfg.maxPlmn * sizeof(MaSaCp *)) + 
                      maCb.maCP.secGenCfg.maxpp * SBUFSIZE(sizeof(LmaSecPpCfg)) +
                      SBUFSIZE(maCb.maCP.secGenCfg.maxpp * sizeof(LmaSecPpCfg *)) + 
                      MA_MAX_PGTABLE_SIZE * SBUFSIZE(sizeof(LmaSecPgCfg)) +
                      SBUFSIZE(MA_MAX_PGTABLE_SIZE * sizeof(LmaSecPgCfg *) +
                      SBUFSIZE(maCb.maCP.nmbOpr * sizeof(MaCmpStd *)));
         memSize += maxSecSize;
         memSize += maCb.maCP.secGenCfg.maxPlmn * SBUFSIZE(sizeof(MaSaMapCp)) +
                    SBUFSIZE(maCb.maCP.secGenCfg.maxPlmn * sizeof(MaSaMapCp *));
#endif /* MAP_SEC */
#endif

         /* get static memory needed for all control blocks and tables */
         if ((ret = SGetSMem(maCb.maInit.region, (Size)memSize, 
               &maCb.maInit.pool)) != ROK)
          {
             cfm_msg.cfm.status = LCM_PRIM_NOK;
             cfm_msg.cfm.reason = LCM_REASON_MEM_NOAVAIL;
             MaMiLmaCfgCfm(&sender,&cfm_msg);
             MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
             "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed,\
             static mem allocation failed. \n", 
             cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
             RETVALUE(RFAILED);
          }
         /* allocate SAP list */

         if ((ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, (Data **)&tmp, 
            (Size)(maCb.maCP.nmbMAUSaps * sizeof(MaSap *)))) != ROK)
         {
            SPutSMem(maCb.maInit.region, maCb.maInit.pool);

            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LCM_REASON_MEM_NOAVAIL;
            MaMiLmaCfgCfm(&sender,&cfm_msg);

            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
            "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
             sap list mem allocation failed.\n", 
            cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            RETVALUE(RFAILED);
         }
         
         maCb.maSapLmaPtr = (MaSap **)tmp;

         /* initialize cb list */
         for (i = 0; i < maCb.maCP.nmbMAUSaps; i++)
         {
            *(maCb.maSapLmaPtr + i) = NULLP;
         }
#ifdef MA_STATIC_EVT_STRUCT
#ifdef LCMAUIMAT
         /* allocate global encode event structure buffer */
         if ((ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, (Data **)&maGlobEncEv, 
                            (Size) sizeof(MaAllSSEv))) != ROK)
         {
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)tmp, 
                     maCb.maCP.nmbMAUSaps * sizeof(MaSap *));
            SPutSMem(maCb.maInit.region, maCb.maInit.pool);
            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LCM_REASON_REGTMR_FAIL;
            MaMiLmaCfgCfm(&sender,&cfm_msg);
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
            "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
            global encode evt structure mem allocation failed.\n", 
            cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            RETVALUE(RFAILED);
         }
#endif /* LCMAUIMAT */

         /* allocate global decode event structure buffer */
         if ((ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, (Data **)&maGlobDecEv, 
                            (Size) sizeof(MaAllSSEv))) != ROK)
         {
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)tmp, 
                     maCb.maCP.nmbMAUSaps * sizeof(MaSap *));
#ifdef LCMAUIMAT
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)maGlobEncEv, 
                      sizeof(MaAllSSEv));
#endif /* LCMAUIMAT */
            SPutSMem(maCb.maInit.region, maCb.maInit.pool);

            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LCM_REASON_REGTMR_FAIL;
            MaMiLmaCfgCfm(&sender,&cfm_msg);
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
            "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
            global decode evt structure mem allocation failed.\n", 
            cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            RETVALUE(RFAILED);
         }
#endif /* MA_STATIC_EVT_STRUCT */

#ifdef MA_RUG
         /* Allocate memory for interface version info. */
         if ((ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, &pData, 
                            (Size)maxIntfSize)) != ROK)
         {    
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)tmp, 
                     maCb.maCP.nmbMAUSaps * sizeof(MaSap *));
#ifdef MA_STATIC_EVT_STRUCT
#ifdef LCMAUIMAT
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)maGlobEncEv, 
                      sizeof(MaAllSSEv));
#endif /* LCMAUIMAT */
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)maGlobDecEv, 
                      sizeof(MaAllSSEv));
#endif /* MA_STATIC_EVT_STRUCT */
            /* free static memory */
            (Void) SPutSMem(maCb.maInit.region, maCb.maInit.pool);

            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LCM_REASON_MEM_NOAVAIL;
            MaMiLmaCfgCfm(&sender,&cfm_msg);
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
            "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed,\
            intf version info mem allocation failed.\n", 
            cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));

            RETVALUE(RFAILED);
         }

         cmZero(pData, (Size)maxIntfSize);
         maCb.maIntfInfo =(ShtVerInfo *)pData;
#endif /* MA_RUG */

#if MAP_REL99
#if (MAP_SEC && LMAV2)

         /* allocate PG control block table */

         if ((ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, &pgPtr, 
            (Size)(MA_MAX_PGTABLE_SIZE * sizeof(LmaSecPgCfg *)))) != ROK)
         {
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)tmp, 
                     maCb.maCP.nmbMAUSaps * sizeof(MaSap *));
#ifdef MA_STATIC_EVT_STRUCT
#ifdef LCMAUIMAT
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)maGlobEncEv, 
                      sizeof(MaAllSSEv));
#endif /* LCMAUIMAT */
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)maGlobDecEv, 
                      sizeof(MaAllSSEv));
#endif /* MA_STATIC_EVT_STRUCT */
#ifdef MA_RUG
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)pData,
                     (Size)maxIntfSize);
#endif /* MA_RUG */
            /* free static memory */
            (Void) SPutSMem(maCb.maInit.region, maCb.maInit.pool);

            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LMA_REASON_PG_MEM_NOAVAIL;
            MaMiLmaCfgCfm(&sender,&cfm_msg);
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
            "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
            PG table memory allocation failed.\n", 
            cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));

            RETVALUE(RFAILED);
         }
         
         maCb.maSecCp.maPgTbl = (LmaSecPgCfg **)pgPtr;

         if ((ret = maInitPgTbl()) != ROK)
         {
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)tmp, 
                     maCb.maCP.nmbMAUSaps * sizeof(MaSap *));
#ifdef MA_STATIC_EVT_STRUCT
#ifdef LCMAUIMAT
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)maGlobEncEv, 
                      sizeof(MaAllSSEv));
#endif /* LCMAUIMAT */
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)maGlobDecEv, 
                      sizeof(MaAllSSEv));
#endif /* MA_STATIC_EVT_STRUCT */
#ifdef MA_RUG
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)pData,
                     (Size)maxIntfSize);
#endif /* MA_RUG */
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)pgPtr, 
                     MA_MAX_PGTABLE_SIZE * sizeof(LmaSecPgCfg *));
            /* free static memory */
            (Void) SPutSMem(maCb.maInit.region, maCb.maInit.pool);

            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LMA_REASON_PG_INIT_FAIL;
            MaMiLmaCfgCfm(&sender,&cfm_msg);
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
            "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
            PG control block memory allocation failed.\n", 
            cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));

            RETVALUE(RFAILED);
         }

         /* allocate PP control block table */

         if ((ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, &ppPtr, 
             (Size)(maCb.maCP.secGenCfg.maxpp * sizeof(LmaSecPpCfg *)))) != ROK)
         {
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)tmp, 
                     maCb.maCP.nmbMAUSaps * sizeof(MaSap *));
#ifdef MA_STATIC_EVT_STRUCT
#ifdef LCMAUIMAT
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)maGlobEncEv, 
                      sizeof(MaAllSSEv));
#endif /* LCMAUIMAT */
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)maGlobDecEv, 
                      sizeof(MaAllSSEv));
#endif /* MA_STATIC_EVT_STRUCT */
#ifdef MA_RUG
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)pData,
                     (Size)maxIntfSize);
#endif /* MA_RUG */
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)pgPtr, 
                     MA_MAX_PGTABLE_SIZE * sizeof(LmaSecPgCfg *));
            maFreePgTbl();
            /* free static memory */
            (Void) SPutSMem(maCb.maInit.region, maCb.maInit.pool);

            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LMA_REASON_PP_MEM_NOAVAIL;
            MaMiLmaCfgCfm(&sender,&cfm_msg);
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
            "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
            PP table memory allocation failed.\n", 
            cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));

            RETVALUE(RFAILED);
         }
         
         maCb.maSecCp.maPpTbl = (LmaSecPpCfg **)ppPtr;

         if ((ret = maInitPpTbl()) != ROK)
         {
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)tmp, 
                     maCb.maCP.nmbMAUSaps * sizeof(MaSap *));
#ifdef MA_STATIC_EVT_STRUCT
#ifdef LCMAUIMAT
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)maGlobEncEv, 
                      sizeof(MaAllSSEv));
#endif /* LCMAUIMAT */
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)maGlobDecEv, 
                      sizeof(MaAllSSEv));
#endif /* MA_STATIC_EVT_STRUCT */
#ifdef MA_RUG
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)pData,
                     (Size)maxIntfSize);
#endif /* MA_RUG */
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)pgPtr, 
                     MA_MAX_PGTABLE_SIZE * sizeof(LmaSecPgCfg *));
            maFreePgTbl();
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)ppPtr, 
                     maCb.maCP.secGenCfg.maxpp * sizeof(LmaSecPpCfg *));
            /* free static memory */
            (Void) SPutSMem(maCb.maInit.region, maCb.maInit.pool);

            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LMA_REASON_PP_INIT_FAIL;
            MaMiLmaCfgCfm(&sender,&cfm_msg);
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
            "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
            PP control block memory allocation failed.\n", 
            cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));

            RETVALUE(RFAILED);
         }
         maCb.maSecPpiMask = 0x001f;

         /* allocate SA control block list */

         if ((ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, &saPtr, 
            (Size)(maCb.maCP.secGenCfg.maxPlmn * sizeof(MaSaCp *)))) != ROK)
         {
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)tmp, 
                     maCb.maCP.nmbMAUSaps * sizeof(MaSap *));
#ifdef MA_STATIC_EVT_STRUCT
#ifdef LCMAUIMAT
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)maGlobEncEv, 
                      sizeof(MaAllSSEv));
#endif /* LCMAUIMAT */
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)maGlobDecEv, 
                      sizeof(MaAllSSEv));
#endif /* MA_STATIC_EVT_STRUCT */
#ifdef MA_RUG
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)pData,
                     (Size)maxIntfSize);
#endif /* MA_RUG */
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)pgPtr, 
                     MA_MAX_PGTABLE_SIZE * sizeof(LmaSecPgCfg *));
            maFreePgTbl();
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)ppPtr, 
                     maCb.maCP.secGenCfg.maxpp * sizeof(LmaSecPpCfg *));
            maFreePpTbl();
            /* free static memory */
            (Void) SPutSMem(maCb.maInit.region, maCb.maInit.pool);

            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LMA_REASON_SA_MEM_NOAVAIL;
            MaMiLmaCfgCfm(&sender,&cfm_msg);
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
            "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
            SA control list mem allocation failed.\n", 
            cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));

            RETVALUE(RFAILED);
         }
         
         maCb.maSecCp.maSaCbPtr = (MaSaCp **)saPtr;

         /* initialize SA list */
         for (i = 0; i < maCb.maCP.secGenCfg.maxPlmn; i++)
         {
            *(maCb.maSecCp.maSaCbPtr + i) = NULLP;
         }

         /* allocate SA control block Mapping table */

         if ((ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, &saMapPtr, 
            (Size)(maCb.maCP.secGenCfg.maxPlmn * sizeof(MaSaMapCp *)))) != ROK)
         {
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)tmp, 
                     maCb.maCP.nmbMAUSaps * sizeof(MaSap *));
#ifdef MA_STATIC_EVT_STRUCT
#ifdef LCMAUIMAT
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)maGlobEncEv, 
                      sizeof(MaAllSSEv));
#endif /* LCMAUIMAT */
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)maGlobDecEv, 
                      sizeof(MaAllSSEv));
#endif /* MA_STATIC_EVT_STRUCT */
#ifdef MA_RUG
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)pData,
                     (Size)maxIntfSize);
#endif /* MA_RUG */
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)pgPtr, 
                     MA_MAX_PGTABLE_SIZE * sizeof(LmaSecPgCfg *));
            maFreePgTbl();
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)ppPtr, 
                     maCb.maCP.secGenCfg.maxpp * sizeof(LmaSecPpCfg *));
            maFreePpTbl();

            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)saPtr, 
                     (Size)(maCb.maCP.secGenCfg.maxPlmn * sizeof(MaSaCp *)));

            /* free static memory */
            (Void) SPutSMem(maCb.maInit.region, maCb.maInit.pool);

            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LMA_REASON_SA_MEM_NOAVAIL;
            MaMiLmaCfgCfm(&sender,&cfm_msg);
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
            "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
            SA mapping table mem allocation failed.\n", 
            cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));

            RETVALUE(RFAILED);
         }
         
         maCb.maSecCp.maSaMapTbl = (MaSaMapCp **)saMapPtr;

         /* initialize SA list */
         for (i = 0; i < maCb.maCP.secGenCfg.maxPlmn; i++)
         {
            *(maCb.maSecCp.maSaMapTbl + i) = NULLP;
         }

         maInitOpCmpTbl(&cfg->t.cfg.s.maGen.secGenCfg);

#endif /* MAP_SEC */
#endif /* MAP_REL99 */

         /* register timer: */
/* ma002.203 : Addition. procId support */
#ifdef SS_MULTIPLE_PROCS
         if ((ret = SRegTmr(maCb.maInit.procId, maCb.maInit.ent, maCb.maInit.inst, maCb.maCP.timeRes, 
                            maActvTmr)) != ROK)
#else
         if ((ret = SRegTmr(maCb.maInit.ent, maCb.maInit.inst, maCb.maCP.timeRes, 
                            maActvTmr)) != ROK)
#endif
         {
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)tmp, 
                     maCb.maCP.nmbMAUSaps * sizeof(MaSap *));

#ifdef MA_STATIC_EVT_STRUCT
#ifdef LCMAUIMAT
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)&maGlobEncEv, 
                     sizeof(MaAllSSEv));
#endif /* LCMAUIMAT */

            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)&maGlobDecEv, 
                     sizeof(MaAllSSEv));
#endif /* MA_STATIC_EVT_STRUCT */
#ifdef MA_RUG
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)pData,
                     (Size)maxIntfSize);
#endif /* MA_RUG */

#if MAP_REL99
#if (MAP_SEC && LMAV2)
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)pgPtr, 
                     MA_MAX_PGTABLE_SIZE * sizeof(LmaSecPgCfg *));
            maFreePgTbl();
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)ppPtr, 
                     maCb.maCP.secGenCfg.maxpp * sizeof(LmaSecPpCfg *));
            maFreePpTbl();
            SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)saPtr,
                     maCb.maCP.secGenCfg.maxPlmn * sizeof(MaSaCp));
#endif /* MAP_SEC */
#endif
            SPutSMem(maCb.maInit.region, maCb.maInit.pool);

            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LCM_REASON_REGTMR_FAIL;
            MaMiLmaCfgCfm(&sender,&cfm_msg);
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
            "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
            register timer failed.\n", 
            cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            RETVALUE(RFAILED);
         }

         /* initialize layer manager bind cfg block.
          * this code is needed in case of loosely coupled interface
          * with the layer manager 
          */

         maCb.maInit.lmPst.selector  = cfg->t.cfg.s.maGen.smPst.selector;
         maCb.maInit.lmPst.region = cfg->t.cfg.s.maGen.smPst.region;
         maCb.maInit.lmPst.pool = cfg->t.cfg.s.maGen.smPst.pool;
         maCb.maInit.lmPst.dstProcId = cfg->t.cfg.s.maGen.smPst.dstProcId;
         maCb.maInit.lmPst.dstEnt = cfg->t.cfg.s.maGen.smPst.dstEnt;
         maCb.maInit.lmPst.dstInst = cfg->t.cfg.s.maGen.smPst.dstInst;
         maCb.maInit.lmPst.srcProcId = maCb.maInit.procId;
         maCb.maInit.lmPst.srcEnt = cfg->t.cfg.s.maGen.smPst.srcEnt;
         maCb.maInit.lmPst.srcInst = cfg->t.cfg.s.maGen.smPst.srcInst;
         maCb.maInit.lmPst.prior = cfg->t.cfg.s.maGen.smPst.prior;
         maCb.maInit.lmPst.route = cfg->t.cfg.s.maGen.smPst.route;
         maCb.maInit.lmPst.event = EVTNONE;
#ifdef MA_RUG
         /*  LM interface version number will be used *        
          *  by MAP to  generate alarms and trace     *
          *  indications                              */
          maCb.maInit.lmPst.intfVer = cfg->t.cfg.s.maGen.smPst.intfVer;
#endif /* MA_RUG */
         maCb.maInit.cfgDone = TRUE;

         cfm_msg.cfm.status = LCM_PRIM_OK;
         cfm_msg.cfm.reason = LCM_REASON_NOT_APPL;
         MaMiLmaCfgCfm(&sender,&cfm_msg);

         break;
      /* end of general configuration */

      /* MAP sap configuration */
      case STMATSAP:

         /* cfg->hdr.elmId.elmntInst1 contains user (SAP) id */
         if (((U32)(cfg->hdr.elmId.elmntInst1) >= maCb.maCP.nmbMAUSaps) ||
             (cfg->hdr.elmId.elmntInst1 < 0))
         {
            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LCM_REASON_INVALID_PAR_VAL;
            MaMiLmaCfgCfm(&sender,&cfm_msg);

            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
            "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, invalid SAP ID\n", 
            cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));

            MALOGERROR(ERRCLS_INT_PAR, EMA005, 
                       (ErrVal)cfg->hdr.elmId.elmntInst1, 
                       "MaMiLmaCfgReq() Failed, invalid SAP ID.");
            RETVALUE(RFAILED);
         }

         /* get MAP sap */
         if ((s = *(maCb.maSapLmaPtr + cfg->hdr.elmId.elmntInst1)) == NULLP)
         {
            if ((ret = maChkSapParam(cfg)) != ROK)
            {
               cfm_msg.cfm.status = LCM_PRIM_NOK;
               cfm_msg.cfm.reason = LCM_REASON_INVALID_PAR_VAL;
               MaMiLmaCfgCfm(&sender,&cfm_msg);
               MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
               "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, invalid sap cfg param.\n", 
               cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
               RETVALUE(RFAILED);
            }
#if MAP_REL99
#if (MAP_SEC && LMAV2)
            if ((ret = maChkSecParam(cfg, &cfm_msg.cfm.reason)) != ROK)
            {
               cfm_msg.cfm.status = LCM_PRIM_NOK;
               MaMiLmaCfgCfm(&sender,&cfm_msg);
               RETVALUE(RFAILED);
            }
#endif /* MAP_SEC */
#endif

            /* assume that this is first time through */
            ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, (Data **) &tmp, 
                           sizeof(MaSap));
            if (ret != ROK)
            {
               cfm_msg.cfm.status = LCM_PRIM_NOK;
               cfm_msg.cfm.reason = LCM_REASON_MEM_NOAVAIL;
               MaMiLmaCfgCfm(&sender,&cfm_msg);

               MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
               "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, fail to allocate mem for SAP.\n", 
               cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
               RETVALUE(RFAILED);
            }
            s = (MaSap *)tmp;
            cmZero((Data *)s, sizeof(MaSap));
            *(maCb.maSapLmaPtr + cfg->hdr.elmId.elmntInst1) = s;

            /* initialize new MAP sap */

            s->sapId = (SuId)cfg->hdr.elmId.elmntInst1;
            s->suId = 0; /* will be sent to us later, in BndReq from MAP user */
            s->spIdTC = (SpId)cfg->t.cfg.s.maMAU.spIdTC;
            s->ssn = cfg->t.cfg.s.maMAU.ssn;
            s->maState = MA_CONFIGURED; /* MAP Upper User state */
            s->uiState = MA_CONFIGURED;
            s->liState = MA_CONFIGURED;

#ifdef MA_FTHA
#ifdef MA_DIS_SAP
            s->contEnt = ENTSM;   /* stack manager controlling entity */
#else  /* MA_DIS_SAP */
            s->contEnt = ENTNC;   /* unknown controlling entity */
#endif /* MA_DIS_SAP */
#endif /* MA_FTHA */

            s->crntTxMsg = NULLP;
            s->crntRxMsg = NULLP;

            /* selector, region, pool configured everytime down there */
            /* dstXXXX passed in BndReq */

            s->maPstMU.srcProcId = maCb.maInit.procId;
            s->maPstMU.srcEnt = maCb.maInit.ent;
            s->maPstMU.srcInst = maCb.maInit.inst;
            s->maPstMU.prior = cfg->t.cfg.s.maMAU.priorMU;
            s->maPstMU.route = cfg->t.cfg.s.maMAU.routeMU;
/*ma012.203: Adddition, to support Dlg Hash size configuration through layer
 * manager  */
#ifdef MAP_NSRP
            s->dlgHshSize = cfg->t.cfg.s.maMAU.dlgHshSize;
            /* Allocate memory to Hsh Tbl */
            if (SGetSBuf(maCb.maInit.region, maCb.maInit.pool, &dlgHshPtr,
                         ((sizeof(MaDlgCp *)) * (s->dlgHshSize))) != ROK)
            {
                 /* Free the memory associated with this SAP */
                 SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)s,
                          sizeof(MaSap));
                /* make the sap pointer null */
                *(maCb.maSapLmaPtr + cfg->hdr.elmId.elmntInst1) = NULLP;
               
                cfm_msg.cfm.status = LCM_PRIM_NOK;
                cfm_msg.cfm.reason = LCM_REASON_MEM_NOAVAIL;
                MaMiLmaCfgCfm(&sender,&cfm_msg);
                MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
                "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed,\
                allocate mem for dlg Hsh table failed.\n",
                cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
              
                RETVALUE(RFAILED);
            }
            s->maDlgTbl = (MaDlgCp **)dlgHshPtr; 

#endif /* MAP_NSRP */
#ifdef MAP_NSRP
            /* clear dialog control points */
            for(i=0;i<s->dlgHshSize;i++)
#else
            /* clear dialog control points */
            for(i=0;i<MA_DLG_HASH_SIZE;i++)
#endif
            {
               s->maDlgTbl[i] = (struct maDlgCp *)NULLP;
            }
            /* Initialize the Statistics */
            s->sts.swtch = cfg->t.cfg.s.maMAU.swtch;
            maZeroSts(s);
#ifdef MA_RUG
            /* Initialize remote intreface version to be unknown */
            s->remIntfValidMU = FALSE;
            s->remIntfValidST = FALSE;
#endif /* MA_RUG */
#ifdef STUV2
            s->ril = MAT_DEF_RIL;
#endif
         }
         else
         {
            /* reconfiguration of MAP sap */

            /* reconfiguration for gaurd timer */
            s->cfg.maGrdTmr.enb = cfg->t.cfg.s.maMAU.maGrdTmr.enb;
            s->cfg.maGrdTmr.val = cfg->t.cfg.s.maMAU.maGrdTmr.val;

            /* reconfiguration for opreation timer, user can reconfigure */
            /* multiple entries of APN database */
            for (i=0; i< MA_MAX_OPR; i++)
            {
               if (cfg->t.cfg.s.maMAU.apnCfg[i].pres == TRUE)
               {
                  for (j=0; j< MA_MAX_OPR; j++)
                  {
                     if ((s->cfg.apnCfg[j].pres == TRUE) &&
                         (s->cfg.apnCfg[j].oprCode == cfg->t.cfg.s.maMAU.apnCfg[i].oprCode))
                     {
                        s->cfg.apnCfg[j].oprTmr.enb = cfg->t.cfg.s.maMAU.apnCfg[i].oprTmr.enb; 
                        s->cfg.apnCfg[j].oprTmr.val = cfg->t.cfg.s.maMAU.apnCfg[i].oprTmr.val; 
                     }
                  }
               }
            }

            /* reconfiguration for binding retry timer */
            s->cfg.tIntTmr.enb = cfg->t.cfg.s.maMAU.tIntTmr.enb;
            s->cfg.tIntTmr.val = cfg->t.cfg.s.maMAU.tIntTmr.val;

            /* reconfiguration for MAP message priority */
            if (cfg->t.cfg.s.maMAU.maPrior > MA_PRI3)
            {
               MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                      "MaMiLmaCfgReq() reconfiguration failed, \
                       invalid message priority (%d)\n", 
                       cfg->t.cfg.s.maMAU.maPrior));
#if (ERRCLASS & ERRCLS_INT_PAR)
               MALOGERROR(ERRCLS_INT_PAR, EMA006, 
                          (ErrVal)cfg->t.cfg.s.maMAU.maPrior,
                          "MaMiLmaCfgReq() reconfiguration Failed,\
                           invalid message priority.");
#endif
               RETVALUE(RFAILED);
            }
            else
            {
               s->maPrior = cfg->t.cfg.s.maMAU.maPrior;
               s->qosSet.msgPrior = cfg->t.cfg.s.maMAU.maPrior;
            }  

            /* reconfiguration for Return/Drop on error option */
            if (( cfg->t.cfg.s.maMAU.retOpt != LMA_REC_ROE ) &&
                ( cfg->t.cfg.s.maMAU.retOpt != LMA_REC_DOE ))
            {
               MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                      "MaMiLmaCfgReq() reconfiguration failed,\
                       invalid return option(%d)\n", 
                       cfg->t.cfg.s.maMAU.retOpt));
#if (ERRCLASS & ERRCLS_INT_PAR)
               MALOGERROR(ERRCLS_INT_PAR, EMA007, 
                          (ErrVal)cfg->t.cfg.s.maMAU.retOpt,
                          "MaMiLmaCfgReq() reconfiguration Failed,\
                           invalid return option.");
#endif
               RETVALUE(RFAILED);
            }
            else
            {
               s->cfg.retOpt = cfg->t.cfg.s.maMAU.retOpt;
               s->qosSet.retOpt = cfg->t.cfg.s.maMAU.retOpt; 
            }

            /* reconfiguration for Sequencing requested/not-requested option.*/
            if (( cfg->t.cfg.s.maMAU.pClass != PCLASS0 ) &&
                ( cfg->t.cfg.s.maMAU.pClass != PCLASS1 ))
            {
               MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                  "MaMiLmaCfgReq() reconfiguration failed, \
                   invalid SCCP protocol class(%d)\n", 
                   cfg->t.cfg.s.maMAU.pClass));
#if (ERRCLASS & ERRCLS_INT_PAR)
               MALOGERROR(ERRCLS_INT_PAR, EMA008, 
                          (ErrVal)cfg->t.cfg.s.maMAU.pClass,
                          "MaMiLmaCfgReq() reconfiguration Failed, \
                           invalid SCCP protocl class.");
#endif
               RETVALUE(RFAILED);
            }
            else
            {
               s->cfg.pClass = cfg->t.cfg.s.maMAU.pClass;
               s->qosSet.seqCtl = cfg->t.cfg.s.maMAU.pClass;
            }

#ifdef MA_RUG
            /* re-configure interface version, if SAP Config structure 
             * contains valid interface version number.
             */
            if(cfg->t.cfg.s.maMAU.remIntfValidMU == TRUE)
            {
               s->remIntfValidMU = cfg->t.cfg.s.maMAU.remIntfValidMU;
               s->maPstMU.intfVer  =  cfg->t.cfg.s.maMAU.intfVerMU;
               s->verContEntMU = ENTSM; /* version controller is SM */
            } 
            else
            {
               s->verContEntMU = ENTNC; /* version controller unknown */
            }
            if(cfg->t.cfg.s.maMAU.remIntfValidTC == TRUE)
            {
               s->remIntfValidST = cfg->t.cfg.s.maMAU.remIntfValidTC;
               s->maPstST.intfVer  =  cfg->t.cfg.s.maMAU.intfVerTC;
            } 
#endif /* MA_RUG */

            cfm_msg.cfm.status = LCM_PRIM_OK;
            cfm_msg.cfm.reason = LCM_REASON_NOT_APPL;
            MaMiLmaCfgCfm(&sender,&cfm_msg);

            RETVALUE(ROK);
         }

         /* Only allocate memory to bitmap when range specified on this *
          * SAP is less than system-wide dialogue Id range.             */


         if ((cfg->t.cfg.s.maMAU.stDlgId > 0) && 
             (cfg->t.cfg.s.maMAU.range <= maCb.maCP.range))
         {
            s->maDlgIdPool = cfg->t.cfg.s.maMAU.stDlgId;/* start dialogue id */
            s->cfg.range = cfg->t.cfg.s.maMAU.range;
    
            /* get the size of the bitmap */
            bits = cfg->t.cfg.s.maMAU.range;
 
            /* Compute the number of octets required for bitmap */
            s->bitMap.size = (bits >> 3) + ((bits & 0x7)?(1):(0));
 
            /* Allocate memory to bitmap */
            if (SGetSBuf(maCb.maInit.region, maCb.maInit.pool, (Data **) &s->bitMap.map, 
                         s->bitMap.size) != ROK)
            {
               /* Free the memory associated with this SAP */
               SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)s, 
                     sizeof(MaSap));

               /* make the sap pointer null */
               *(maCb.maSapLmaPtr + cfg->hdr.elmId.elmntInst1) = NULLP;

               cfm_msg.cfm.status = LCM_PRIM_NOK;
               cfm_msg.cfm.reason = LCM_REASON_MEM_NOAVAIL;
               MaMiLmaCfgCfm(&sender,&cfm_msg);
               MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
               "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
               allocate mem for bitmap failed.\n", 
               cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));

               RETVALUE(RFAILED);
            }

            /* Zero the memory allocated for the bit map */
            cmZero((Data *)s->bitMap.map,s->bitMap.size);
            
            /* compute memory available for other SAP bitmap */
            maCb.maCP.range = maCb.maCP.range - cfg->t.cfg.s.maMAU.range;
 
         } /* end if */
         else 
         {
            /* do not allocate the dialogue id pool */

            /* initialize the bit map pointer */
            s->bitMap.map = NULLP;
            if(cfg->t.cfg.s.maMAU.stDlgId > 0)
            {
               s->maDlgIdPool = cfg->t.cfg.s.maMAU.stDlgId +
                                cfg->t.cfg.s.maMAU.range - 1;
            }
            else
            {
               s->maDlgIdPool = MA_MAX_DLG_ID;
            }
         }

         s->maPstMU.selector = cfg->t.cfg.s.maMAU.selectorMU;

         /* update configuration values */
         s->maPstMU.region = cfg->t.cfg.s.maMAU.memMU.region;
         s->maPstMU.pool = cfg->t.cfg.s.maMAU.memMU.pool;

         /* update lower sap values */

         s->maPstST.selector = cfg->t.cfg.s.maMAU.selectorTC;
         s->maPstST.region = cfg->t.cfg.s.maMAU.memTC.region;
         s->maPstST.pool = cfg->t.cfg.s.maMAU.memTC.pool;
         s->maPstST.dstProcId = cfg->t.cfg.s.maMAU.procIdTC;
         s->maPstST.dstEnt = cfg->t.cfg.s.maMAU.entTC;
         s->maPstST.dstInst = cfg->t.cfg.s.maMAU.instTC;
         s->maPstST.srcProcId = maCb.maInit.procId;
         s->maPstST.srcEnt = maCb.maInit.ent;
         s->maPstST.srcInst = maCb.maInit.inst;
         s->maPstST.prior = cfg->t.cfg.s.maMAU.priorTC;
         s->maPstST.route = cfg->t.cfg.s.maMAU.routeTC;

         /* copy new configuration paramters */
         s->cfg.swtch = cfg->t.cfg.s.maMAU.swtch;
         s->cfg.selectorTC = cfg->t.cfg.s.maMAU.selectorTC;
         s->cfg.memTC.region = cfg->t.cfg.s.maMAU.memTC.region;
         s->cfg.memTC.pool = cfg->t.cfg.s.maMAU.memTC.pool;
         s->cfg.entTC = cfg->t.cfg.s.maMAU.entTC;
         s->cfg.instTC = cfg->t.cfg.s.maMAU.instTC;
         s->cfg.procIdTC = cfg->t.cfg.s.maMAU.procIdTC;
         s->cfg.routeTC = cfg->t.cfg.s.maMAU.routeTC;
         s->cfg.priorTC = cfg->t.cfg.s.maMAU.priorTC;
         s->cfg.spIdTC = cfg->t.cfg.s.maMAU.spIdTC;
         s->cfg.maGrdTmr.enb = cfg->t.cfg.s.maMAU.maGrdTmr.enb;
         s->cfg.maGrdTmr.val = cfg->t.cfg.s.maMAU.maGrdTmr.val;
         s->cfg.maxDlg = cfg->t.cfg.s.maMAU.maxDlg;
         s->cfg.stDlgId = cfg->t.cfg.s.maMAU.stDlgId;
         s->cfg.range = cfg->t.cfg.s.maMAU.range;

         /* zero out dialog/transaction pool counter */
         s->nmbActvDlg = 0;

#ifdef MATV3
         s->maPrior    = cfg->t.cfg.s.maMAU.maPrior;
         s->cfg.pClass = cfg->t.cfg.s.maMAU.pClass;
#endif /* MATV3 */
         /* Initialize the qos structure */
         s->qosSet.msgPrior = cfg->t.cfg.s.maMAU.maPrior;
         s->qosSet.retOpt = cfg->t.cfg.s.maMAU.retOpt; 
         s->qosSet.seqCtl = (U8)(cfg->t.cfg.s.maMAU.pClass==PCLASS1)?(TRUE):(FALSE);

         /* Initialize the Application context structure */

         for (i=0; i< MA_MAX_OPR; i++)
         {
           if (cfg->t.cfg.s.maMAU.apnCfg[i].pres == TRUE)
           {
             s->cfg.apnCfg[i].pres = TRUE;
             s->cfg.apnCfg[i].oprCode = cfg->t.cfg.s.maMAU.apnCfg[i].oprCode; 
             s->cfg.apnCfg[i].oprClass =  cfg->t.cfg.s.maMAU.apnCfg[i].oprClass; 
             s->cfg.apnCfg[i].maVer =  cfg->t.cfg.s.maMAU.apnCfg[i].maVer; 
             s->cfg.apnCfg[i].oprTmr = cfg->t.cfg.s.maMAU.apnCfg[i].oprTmr; 
             s->cfg.apnCfg[i].apn.len = cfg->t.cfg.s.maMAU.apnCfg[i].apn.len; 
#ifdef ZJ
             s->cfg.apnCfg[i].upd =  cfg->t.cfg.s.maMAU.apnCfg[i].upd; 
#endif
             for (j=0; j< s->cfg.apnCfg[i].apn.len; j++)
             {
               s->cfg.apnCfg[i].apn.string[j] = cfg->t.cfg.s.maMAU.apnCfg[i].apn.string[j]; 
             }
             s->cfg.apnCfg[i].altApn.len = cfg->t.cfg.s.maMAU.apnCfg[i].altApn.len; 
             for (j=0; j< s->cfg.apnCfg[i].altApn.len; j++)
             {
               s->cfg.apnCfg[i].altApn.string[j] = 
                                cfg->t.cfg.s.maMAU.apnCfg[i].altApn.string[j]; 
             }
           }
           else
           {
             s->cfg.apnCfg[i].pres = FALSE;
           }
         }
         /* initialize the timers */
         cmInitTimers(s->timers, (U8)MA_MAX_TMRS);

#ifdef MA_RUG
         /* If SAP Config structure contains valid interface 
          * version number */

         if(cfg->t.cfg.s.maMAU.remIntfValidMU == TRUE)
         {
            /* SAP Config request contains valid interface 
             * version number remIntfValid and intfVer 
             * fields are reconfigurable */
            s->remIntfValidMU = TRUE;
            s->maPstMU.intfVer  =  cfg->t.cfg.s.maMAU.intfVerMU;
            s->verContEntMU = ENTSM; /* version controller is SM */
         } 
         else
         {
            s->verContEntMU = ENTNC; /* version controller unknown */
         }

         if(cfg->t.cfg.s.maMAU.remIntfValidTC == TRUE)
         {
            /* SAP Config request contains valid interface 
             * version number remIntfValid and intfVer 
             * fields are reconfigurable */
            s->remIntfValidST = TRUE;
            s->maPstST.intfVer  =  cfg->t.cfg.s.maMAU.intfVerTC;
         } 

         /* If remote ver not configured by layer mgr check if we have *
          * information needed to set the version number already       *
          * For upper SAP, the version number will be filled in on     *
          * getting a set version request or on getting a bind request *
          * from service user                                          */
    
         if(cfg->t.cfg.s.maMAU.remIntfValidTC == FALSE)
         {
            Bool       found;          /* Used in searching */
      
            found = FALSE;
  
            /* if LM did not configure version, check stored data */      
            for(i=0;((i < maCb.maNumIntfInfo) && (found == FALSE));i++)
            {
               if(maCb.maIntfInfo[i].intf.intfId == STUIF)
               {
                  switch(maCb.maIntfInfo[i].grpType)
                  {
                     case SHT_GRPTYPE_ALL:
                        if ((maCb.maIntfInfo[i].dstProcId == 
                                                cfg->t.cfg.s.maMAU.procIdTC) &&
                             (maCb.maIntfInfo[i].dstEnt.ent == 
                                                cfg->t.cfg.s.maMAU.entTC) &&
                             (maCb.maIntfInfo[i].dstEnt.inst == 
                                                cfg->t.cfg.s.maMAU.instTC))
                           
                            found = TRUE;
                           
                          break;
                     case SHT_GRPTYPE_ENT:
                        if ((maCb.maIntfInfo[i].dstEnt.ent == 
                                                cfg->t.cfg.s.maMAU.entTC) &&
                            (maCb.maIntfInfo[i].dstEnt.inst == 
                                                cfg->t.cfg.s.maMAU.instTC))
                           
                            found = TRUE; 
                     default:
                          /* not possible */
                          break;
                  } /* switch */                    
               } 
            } 
            if(found == TRUE)
            {
               s->remIntfValidST = TRUE;
               s->maPstST.intfVer  = maCb.maIntfInfo[i-1].intf.intfVer;
            } 
         } /* if remIntfVer is FALSE */                       
#endif /* MA_RUG */

#if MAP_REL99
#if (MAP_SEC && LMAV2)
         s->cfg.secSapCfg.neId.length=cfg->t.cfg.s.maMAU.secSapCfg.neId.length;
         for (i=0; i<cfg->t.cfg.s.maMAU.secSapCfg.neId.length; i++)
         {
            s->cfg.secSapCfg.neId.strg[i] = 
                                cfg->t.cfg.s.maMAU.secSapCfg.neId.strg[i];
         }
#endif /* MAP_SEC */
#endif

         cfm_msg.cfm.status = LCM_PRIM_OK;
         cfm_msg.cfm.reason = LCM_REASON_NOT_APPL;
         MaMiLmaCfgCfm(&sender,&cfm_msg);
         
         break;   

#if MAP_REL99
#if (MAP_SEC && LMAV2)

          /* MAPsec protection group configuration */
      case STMATPG:

         if ((ret = maChkSecParam(cfg, &cfm_msg.cfm.reason)) != ROK)
         {
            cfm_msg.cfm.status = LCM_PRIM_NOK;
            MaMiLmaCfgCfm(&sender,&cfm_msg);
            RETVALUE(RFAILED);
         }

         /* if pg is existing and AC matches return successful cfm */
         if ((ret = maIsPgExist(cfg)) != TRUE)
         {
            if ((ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, (Data **) &tmp, 
                 sizeof(LmaSecPgCfg))) != ROK)
            {
                cfm_msg.cfm.status = LCM_PRIM_NOK;
                cfm_msg.cfm.reason = LCM_REASON_MEM_NOAVAIL;
                MaMiLmaCfgCfm(&sender,&cfm_msg);
                MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                       "MaMiLmaCfgReq(pst,elmnt(%d),elmntInst1(%d)) failed,\
                       new PG control block allocation failed.\n", 
                       cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
                RETVALUE(RFAILED);
            }

            pgCp = (LmaSecPgCfg *)tmp;

            *(maCb.maSecCp.maPgTbl + maCb.maSecCp.pgTbSize) = pgCp;

            pgCp->ac = cfg->t.cfg.s.maSecPg.ac;
            pgCp->pgi = cfg->t.cfg.s.maSecPg.pgi;
            pgCp->nmbPgTupleEnt = cfg->t.cfg.s.maSecPg.nmbPgTupleEnt;

            for (i=0; i<cfg->t.cfg.s.maSecPg.nmbPgTupleEnt; i++)
            {
               pgCp->pg[i].pl = cfg->t.cfg.s.maSecPg.pg[i].pl;
               pgCp->pg[i].acVer = cfg->t.cfg.s.maSecPg.pg[i].acVer;
               pgCp->pg[i].oprCode =  cfg->t.cfg.s.maSecPg.pg[i].oprCode;
            }
            maCb.maSecCp.pgTbSize++;

            maCb.maSecPpiMask = maCb.maSecPpiMask | (0x0001 << (pgCp->pgi));

         }
         cfm_msg.cfm.status = LCM_PRIM_OK;
         cfm_msg.cfm.reason = LCM_REASON_NOT_APPL;
         MaMiLmaCfgCfm(&sender,&cfm_msg);

         break;   

          /* MAPsec protection profile configuration */
      case STMATPP:

         if ((ret = maChkSecParam(cfg, &cfm_msg.cfm.reason)) != ROK)
         {
            cfm_msg.cfm.status = LCM_PRIM_NOK;
            MaMiLmaCfgCfm(&sender,&cfm_msg);
            RETVALUE(RFAILED);
         }

         /* if pp is existing return successful cfm */
         if ((ret = maIsPpExist(cfg)) != TRUE)
         {
         if ((ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, (Data **) &tmp, 
              sizeof(LmaSecPpCfg))) != ROK)
         {
             cfm_msg.cfm.status = LCM_PRIM_NOK;
             cfm_msg.cfm.reason = LCM_REASON_MEM_NOAVAIL;
             MaMiLmaCfgCfm(&sender,&cfm_msg);
             MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                    "MaMiLmaCfgReq(pst,elmnt(%d),elmntInst1(%d)) failed,\
                    new PG control block allocation failed.\n", 
                    cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
             RETVALUE(RFAILED);
         }

         ppCp = (LmaSecPpCfg *)tmp;

         *(maCb.maSecCp.maPpTbl + maCb.maSecCp.ppTbSize) = ppCp;

         ppCp->ppid = cfg->t.cfg.s.maSecPp.ppid;
         ppCp->ppri = cfg->t.cfg.s.maSecPp.ppri;
         ppCp->ppi = cfg->t.cfg.s.maSecPp.ppi;
         maCb.maSecCp.ppTbSize++;
         }
         cfm_msg.cfm.status = LCM_PRIM_OK;
         cfm_msg.cfm.reason = LCM_REASON_NOT_APPL;
         MaMiLmaCfgCfm(&sender,&cfm_msg);

         break;   

         /* MAPsec SA configuration */
      case STMATSA:

         if ((ret = maChkSecParam(cfg, &cfm_msg.cfm.reason)) != ROK)
         {
            cfm_msg.cfm.status = LCM_PRIM_NOK;
            MaMiLmaCfgCfm(&sender,&cfm_msg);
            RETVALUE(RFAILED);
         }

         for (i=0; i<cfg->t.cfg.s.maSecSa.nmbPlmns; i++)
         {
            saCp = maFindSa(cfg->t.cfg.s.maSecSa.sa[i].plmnId.mcc.val,
                            cfg->t.cfg.s.maSecSa.sa[i].plmnId.mnc.val);
            if (saCp == NULLP)
            {
               /* assume that this is first time, allocate a new saCp */
               saCp = maInsSa(cfg->t.cfg.s.maSecSa.sa[i].plmnId.mcc.val,
                              cfg->t.cfg.s.maSecSa.sa[i].plmnId.mnc.val);
               if (saCp == NULLP)
               {
                  cfm_msg.cfm.status = LCM_PRIM_NOK;
                  cfm_msg.cfm.reason = LCM_REASON_MEM_NOAVAIL;
                  MaMiLmaCfgCfm(&sender,&cfm_msg);
                  MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                         "MaMiLmaCfgReq(pst,elmnt(%d),elmntInst1(%d)) failed,\
                         SA control block allocation failed.\n", 
                         cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
                  RETVALUE(RFAILED);
               }

               saMapCp = maInsSaMap(cfg->t.cfg.s.maSecSa.sa[i].plmn_164.cc.val,
                                  cfg->t.cfg.s.maSecSa.sa[i].plmn_164.ndc.val);
               if (saMapCp == NULLP)
               {
                  cfm_msg.cfm.status = LCM_PRIM_NOK;
                  cfm_msg.cfm.reason = LCM_REASON_MEM_NOAVAIL;
                  MaMiLmaCfgCfm(&sender,&cfm_msg);
                  MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                         "MaMiLmaCfgReq(pst,elmnt(%d),elmntInst1(%d)) failed,\
                         SA Mapping control block allocation failed.\n", 
                         cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
                  RETVALUE(RFAILED);
               }

               maCb.maSecCp.saTbSize++;

               /* If the SA is to indicate that MAPsec is not to be applied
                * then all the algorithm attributes shall contain a NULL 
                * Value. */
               if (cfg->t.cfg.s.maSecSa.sa[i].mapSec == FALSE)
               {
                  saCp->sa.mapSec = FALSE;
               }
               else
               {
                  cmCopy((Data *)&cfg->t.cfg.s.maSecSa.sa[i],
                         (Data *)&saCp->sa,sizeof(LmaSecSa));
                  if((saCp->ppi = maFindPpi(saCp->sa.ppid, saCp->sa.ppri)) == 
                     MA_INVALID_PPI)
                  {
                     cfm_msg.cfm.status = LCM_PRIM_NOK;
                     cfm_msg.cfm.reason = LMA_REASON_INV_PPI;
                     MaMiLmaCfgCfm(&sender,&cfm_msg);
#ifndef ALIGN_64BIT

                     MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                           "MaMiLmaCfgReq(pst,elmnt(%d),entry(%ld)) failed,\
                            Invalid ppid or ppri.\n",cfg->hdr.elmId.elmnt, i));

#else

                     MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                           "MaMiLmaCfgReq(pst,elmnt(%d),entry(%d)) failed,\
                            Invalid ppid or ppri.\n",cfg->hdr.elmId.elmnt, i));


#endif /* ALIGN_64BIT */
                     RETVALUE(RFAILED);
                  }
               }

               if ((ret = maInitSaMapTbl()) != ROK)
               {
                  cfm_msg.cfm.status = LCM_PRIM_NOK;
                  cfm_msg.cfm.reason = LCM_REASON_MEM_NOAVAIL;
                  MaMiLmaCfgCfm(&sender,&cfm_msg);
                  MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                         "MaMiLmaCfgReq(pst,elmnt(%d),elmntInst1(%d)) failed,\
                          SA mapping control block not found.\n", 
                          cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
                  RETVALUE(RFAILED);
               }
            }
            else
            {
               /* reconfiguration 
                * mapSec and txFbInd are not reconfigurable, 
                */
               if (saCp->sa.mapSec == TRUE)
               {
                  saCp->sa.spi = cfg->t.cfg.s.maSecSa.sa[i].spi;
                  saCp->sa.ppid =  cfg->t.cfg.s.maSecSa.sa[i].ppid;
                  saCp->sa.ppri = cfg->t.cfg.s.maSecSa.sa[i].ppri;
                  saCp->sa.mik.mikLen = cfg->t.cfg.s.maSecSa.sa[i].mik.mikLen;
                  for (j=0; j<(U16)cfg->t.cfg.s.maSecSa.sa[i].mik.mikLen; j++)
                  {
                     saCp->sa.mik.mik[j]=cfg->t.cfg.s.maSecSa.sa[i].mik.mik[j];
                  }
                  saCp->sa.mia = cfg->t.cfg.s.maSecSa.sa[i].mia;
                  saCp->sa.mek.mekLen = cfg->t.cfg.s.maSecSa.sa[i].mek.mekLen;
                  for (j=0; j<(U16)cfg->t.cfg.s.maSecSa.sa[i].mek.mekLen; j++)
                  {
                     saCp->sa.mek.mek[j]=cfg->t.cfg.s.maSecSa.sa[i].mek.mek[j];
                  }
                  saCp->sa.mea = cfg->t.cfg.s.maSecSa.sa[i].mea;
                  if((saCp->ppi = maFindPpi(saCp->sa.ppid, saCp->sa.ppri)) == 
                     MA_INVALID_PPI)
                  {
                     cfm_msg.cfm.status = LCM_PRIM_NOK;
                     cfm_msg.cfm.reason = LMA_REASON_INV_PPI;
                     MaMiLmaCfgCfm(&sender,&cfm_msg);
#ifndef ALIGN_64BIT

                     MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                           "MaMiLmaCfgReq(pst,elmnt(%d),entry(%ld)) failed, \
                            Invalid refigured ppid or ppri.\n",
                            cfg->hdr.elmId.elmnt, i));

#else

                     MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                           "MaMiLmaCfgReq(pst,elmnt(%d),entry(%d)) failed, \
                            Invalid refigured ppid or ppri.\n",
                            cfg->hdr.elmId.elmnt, i));

#endif /* ALIGN_64BIT */
                     RETVALUE(RFAILED);
                  }
               }   
            }
         } /* end for */

         cfm_msg.cfm.status = LCM_PRIM_OK;
         cfm_msg.cfm.reason = LCM_REASON_NOT_APPL;
         MaMiLmaCfgCfm(&sender,&cfm_msg);
         break;
#endif /* MAP_SEC */
#endif
      
          default:

#if (ERRCLASS & ERRCLS_INT_PAR)
         MALOGERROR(ERRCLS_INT_PAR, EMA009, (ErrVal)cfg->hdr.elmId.elmnt,
                    "MaMiLmaCfgReq () Failed, invalid element.");
#endif

         break;

         /* end of MAP SAP Configuration */

   }
   RETVALUE(ROK);
} /* end of MaMiLmaCfgReq */

/*
*
*       Fun:   maChkSapParam
*
*       Desc:  validate sap configuration parameters
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  ca_bdy1.c
*
*/
 
#ifdef ANSI
PUBLIC S16 maChkSapParam
(
MaMngmt *cfg   /* management structure */
)
#else
PUBLIC S16 maChkSapParam (cfg)
MaMngmt *cfg;   /* management structure */
#endif
{
   U32    i;
   MaSap  *s;               /* MAP sap */
   S16    ret;              /* return value */

   TRC2(maChkSapParam)

   /* validate upper and lower interface selector */
   if ((cfg->t.cfg.s.maMAU.selectorMU >= MAXMAUI) ||
       (cfg->t.cfg.s.maMAU.selectorTC >= MAXMAUI-1))
   {
      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
             "maChkSapParam() failed, invalid upper selector(%d)\
              or lower selector(%d))\n", cfg->t.cfg.s.maMAU.selectorMU,
              cfg->t.cfg.s.maMAU.selectorTC));
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_INT_PAR, EMA010, (ErrVal)cfg->hdr.elmId.elmntInst1, 
                 "maChkSapParam() Failed, invalid interface selector.");
#endif 
      RETVALUE(RFAILED);
   }

   /* validate map message priority */
   if (cfg->t.cfg.s.maMAU.maPrior > MA_PRI3)
   {
      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
             "maChkSapParam() failed, invalid message priority (%d)\n", 
              cfg->t.cfg.s.maMAU.maPrior));
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_INT_PAR, EMA011, (ErrVal)cfg->t.cfg.s.maMAU.maPrior,
                 "maChkSapParam() Failed, invalid message priority.");
#endif
      RETVALUE(RFAILED);
   }

   /* validate map message return option */
   if (( cfg->t.cfg.s.maMAU.retOpt != LMA_REC_ROE ) &&
       ( cfg->t.cfg.s.maMAU.retOpt != LMA_REC_DOE ))
   {
      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
             "maChkSapParam() failed, invalid return option(%d)\n", 
              cfg->t.cfg.s.maMAU.retOpt));
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_INT_PAR, EMA012, (ErrVal)cfg->t.cfg.s.maMAU.retOpt,
                 "maChkSapParam() Failed, invalid return option.");
#endif
      RETVALUE(RFAILED);
   }

   /* validate SCCP protocol class */
   if (( cfg->t.cfg.s.maMAU.pClass != PCLASS0 ) &&
       ( cfg->t.cfg.s.maMAU.pClass != PCLASS1 ))
   {
      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
             "maChkSapParam() failed, invalid SCCP protocol class(%d)\n", 
              cfg->t.cfg.s.maMAU.pClass));
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_INT_PAR, EMA013, (ErrVal)cfg->t.cfg.s.maMAU.pClass,
                 "maChkSapParam() Failed, invalid SCCP protocl class.");
#endif
      RETVALUE(RFAILED);
   }

   /* validate subsystem number */
   for (i=0; i < maCb.maCP.nmbMAUSaps; i++)
   {
      if ((s = *(maCb.maSapLmaPtr + i)) == NULLP)
      {
         continue;
      }
      else
      { 
         if (s->ssn == cfg->t.cfg.s.maMAU.ssn)
         {
             MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                    "maChkSapParam() failed, invalid SSN(%d)\n", 
                     cfg->t.cfg.s.maMAU.ssn));
#if (ERRCLASS & ERRCLS_INT_PAR)
             MALOGERROR(ERRCLS_INT_PAR,EMA014,(ErrVal)cfg->t.cfg.s.maMAU.ssn,
                        "maChkSapParam() Failed, invalid subsystem number.");
#endif
             RETVALUE(RFAILED);
         }
      }
   }/* end for */

   for (i=0; i< MA_MAX_OPR; i++)
   {
      if (cfg->t.cfg.s.maMAU.apnCfg[i].pres == TRUE) 
      {
         if (cfg->t.cfg.s.maMAU.apnCfg[i].apn.len != 8 )
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                  "maChkSapParam() failed, invalid APN length(%d)\n", 
                   cfg->t.cfg.s.maMAU.apnCfg[i].apn.len));
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA015, 
                      (ErrVal)cfg->t.cfg.s.maMAU.apnCfg[i].apn.len,
                      "maChkSapParam() Failed, invalid APN length.");
#endif
           RETVALUE(RFAILED);
         }

         if ((cfg->t.cfg.s.maMAU.apnCfg[i].altApn.len != 8) &&
             (cfg->t.cfg.s.maMAU.apnCfg[i].altApn.len != 0))
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
               "maChkSapParam() failed, invalid alternative APN length(%d)\n", 
                cfg->t.cfg.s.maMAU.apnCfg[i].altApn.len));
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA016, 
                   (ErrVal)cfg->t.cfg.s.maMAU.apnCfg[i].altApn.len,
                   "maChkSapParam() Failed, invalid alternative APN length.");
#endif
           RETVALUE(RFAILED);
         }

         if ((ret = maChkOprCode(cfg->t.cfg.s.maMAU.apnCfg[i].oprCode)) != ROK)
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "maChkSapParam() failed, invalid operation code(%d)\n", 
                    cfg->t.cfg.s.maMAU.apnCfg[i].oprCode));
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA017, 
                       (ErrVal)cfg->t.cfg.s.maMAU.apnCfg[i].oprCode,
                       "maChkSapParam() Failed, invalid operation.");
#endif
            RETVALUE(RFAILED);
         }
      }
   }

   RETVALUE(ROK);

} /* maChkSapParam */

/*
*
*       Fun:   maFillReplyPst
*
*       Desc:  Fills the Reply post structure for confirmations.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  ca_bdy1.c
*
*/
 
#ifdef ANSI
PUBLIC S16 maFillReplyPst
(
Pst     *req,        /* Req. Post structure  */
MaMngmt *req_mgmt,   /* management structure */
MaMngmt *cfm_mgmt,   /* management structure */
U8       event,      /* event type           */
Pst     *reply       /* Reply Post structure to be filled */
)
#else
PUBLIC S16 maFillReplyPst (req,req_mgmt,cfm_mgmt,event,reply)
Pst     *req;        /* Req. Post structure  */
MaMngmt *req_mgmt;   /* management structure */
MaMngmt *cfm_mgmt;   /* management structure */
U8       event;      /* event type           */
Pst     *reply;      /* Reply Post structure to be filled */
#endif
{
   TRC2(maFillReplyPst)
 
   cmCopy((Data *) req,(Data *)reply,sizeof(Pst));
   if(cfm_mgmt != req_mgmt)
   {
      cmCopy((Data *) req_mgmt,(Data *)cfm_mgmt,sizeof(MaMngmt));
   }
 
   reply->dstProcId     = req->srcProcId;
   reply->dstEnt        = req->srcEnt;
   reply->dstInst       = req->srcInst;
   reply->prior         = req_mgmt->hdr.response.prior;
   reply->route         = req_mgmt->hdr.response.route;
   reply->selector      = req_mgmt->hdr.response.selector;
   reply->event         = event;
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
   reply->srcProcId     = maCb.maInit.procId;/* This entity's processor Id  */;
#else
   reply->srcProcId     = SFndProcId();/* This entity's processor Id  */;
#endif
   reply->srcEnt        = maCb.maInit.ent;
   reply->srcInst       = maCb.maInit.inst;
#ifdef MA_RUG
   /* Generate reply using same version as one  *
    * used to form the request by the LM        */
   reply->intfVer       = req->intfVer;
#endif  
 

   if(cfm_mgmt != req_mgmt)
   { 
      cfm_mgmt->hdr.transId = req_mgmt->hdr.transId;
   }
   RETVALUE(ROK);
 
} /* maFillReplyPst */



/*
*
*       Fun:   MAP User Bind Request
*
*       Desc:  This function binds an Upper Layer Entity to the MAP
*              Layer software. The MAP layer software will register this 
*              new User and will allocate a Service Access Point for this bind.
*              With this function both Entities will exchange ids to their 
*              respective Control Blocks which will be used for this bind.  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaUiMatBndReq
(
Pst *pst,              /* Post structure */
SuId suId,             /* service user id */
SpId spId              /* service provider id */
)
#else
PUBLIC S16 MaUiMatBndReq(pst, suId, spId)
Pst *pst;              /* Post Structure */
SuId suId;             /* service user id */
SpId spId;             /* service provider id */
#endif
{
   MaSap *s;           /* pointer to current SAP */
   S16   ret;
#ifdef MA_RUG
   Bool       found;       /* flag for search */
   U16        i;           /* Counter */
#endif /* MA_RUG */

   TRC3(MaUiMatBndReq)
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
      		ERRCLS_DEBUG, EMA384, 0," MaUiMatBndReq () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif
   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
          "MaUiMatBndReq(pst, suId(%d), spId(%d))\n", suId, spId));


   /* If not active then don't accept the bind request */
#ifdef ZJ
   if (!cmTuChkRsetStatus(&zjCb.tuCb, TRUE))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_INT_PAR, EMA018, (ErrVal)0, 
                "MaUiMatBndReq(): Invalid PSF state.");
#endif
      maSendAlrm(NEW,spId, MA_UNUSED, MA_UNUSED, "MaUiMatBndReq",
                 LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,
                 LCM_CAUSE_PROT_NOT_ACTIVE);

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatBndReq(pst, suId(%d), spId(%d))failed, Invalid PSF state.\n", 
      suId,spId));

      RETVALUE(RFAILED);
   }
#endif /* ZJ */

   if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
       ((s = *(maCb.maSapLmaPtr + spId)) == NULLP))
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatBndReq",
                 LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatBndReq(pst, suId(%d), spId(%d))failed, invalid spId(%d).\n", 
      suId,spId,spId));
      RETVALUE(RFAILED);
   }
   
#ifdef MA_RUG
   found = FALSE;
  
   /* If Sap structure does not contain version information */
   if(s->remIntfValidMU == FALSE)
   {
      /* Search version information from main control block of MAP */
      for(i=0;((i < maCb.maNumIntfInfo) && (found == FALSE));i++)
      {
         /* For upper interface */
         if(maCb.maIntfInfo[i].intf.intfId == MATIF)
         {
            switch(maCb.maIntfInfo[i].grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if((maCb.maIntfInfo[i].dstProcId == pst->srcProcId) &&
                     (maCb.maIntfInfo[i].dstEnt.ent == pst->srcEnt) &&
                     (maCb.maIntfInfo[i].dstEnt.inst == pst->srcInst))       
                     found = TRUE;
                  break;                               
               case SHT_GRPTYPE_ENT:
                  if((maCb.maIntfInfo[i].dstEnt.ent == pst->srcEnt) &&
                     (maCb.maIntfInfo[i].dstEnt.inst == pst->srcInst))
                    found = TRUE;
                  break;
               default:
                  /* not possible */
                  break; 
            } /* switch */                  
         } /* if */ 
      }  /* for */

      /* Version information found, update sap structure */ 
      if(found == TRUE)
      {         
         s->maPstMU.intfVer = maCb.maIntfInfo[i-1].intf.intfVer;
         s->remIntfValidMU = TRUE;
      } 
      else  /* Not found */
      {
         /*  Sap cannot be bound if remote ver info is not available
          *  Generate NOK to user layer with reason 
          *  LCM_REASON_SWVER_NAVAIL
          */
         maSendAlrm(MA_UNUSED, s->suId, MA_UNUSED, MA_UNUSED, MA_UNUSED,
                    LCM_EVENT_BND_FAIL,LCM_CATEGORY_INTERFACE,
                    LCM_CAUSE_SWVER_NAVAIL);

         (Void)MaUiMatBndCfm(&s->maPstMU, s->suId, CM_BND_NOK);
         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatBndReq(pst, spId(%d))failed, SWVER not available.\n", spId));
         RETVALUE(RFAILED);
      } 
   } 

#endif /* MA_RUG */

   /* Change the state of the upper SAP */
   s->uiState = MA_BND_ENABLED;

   /* copy bind configuration parameters in MAP sap */
   s->suId = suId;                         /* MAP User Id */
#ifdef ZJ
   if ( s->maPstMU.route == RTE_PROTO)
      s->maPstMU.dstProcId = CMFTHA_RES_RSETID;
   else
      s->maPstMU.dstProcId = pst->srcProcId;
#else
   s->maPstMU.dstProcId = pst->srcProcId;
#endif
   s->maPstMU.dstEnt = pst->srcEnt;
   s->maPstMU.dstInst = pst->srcInst;

   if (s->liState == MA_BND_ENABLED)
   {
      s->maState = MA_BND_ENABLED;
   }
   
#ifdef ZJ
   cmTuRunTimeUpd(&zjCb.tuCb, CMTU_UISAP_CB, CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_MOD, (Void *)s);

   cmTuRunTimeUpd(&zjCb.tuCb, CMTU_LISAP_CB, CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_MOD, (Void *)s);

   cmTuUpdPeer(&zjCb.tuCb);
#endif /* ZJ */
   /* Send the Successful Bind Cfm to the user as the req is coming */
   ret = MaUiMatBndCfm(&s->maPstMU,s->suId,CM_BND_OK);

 /* Bind has done succssfully 
 *  Generate OK to stack manger 
 */
     maSendAlrm(NEW,spId, STMATSAP, LMA_BND_PROCESSED, 
                "MaUiMatbndReq from user",
                LMA_EVENT_BND_PROCESSED,LCM_CATEGORY_INTERFACE,LCM_CAUSE_UNKNOWN);
   RETVALUE(ret);

} /* end of MaUiMatBndReq */

 
/*
*
*       Fun:   MaLiStuBndCfm
*
*       Desc:  Confirm for the Lower layer bind
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  ca_bdy1.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaLiStuBndCfm
(
Pst *pst,              /* Post structure */
SuId suId,             /* service user id */
U8   status            /* status */
)
#else
PUBLIC S16 MaLiStuBndCfm (pst,suId,status)
Pst *pst;              /* Post structure */
SuId suId;             /* service user id */
U8   status;           /* status */
#endif
{
   MaSap   *s;         /* MA Sap */
 
   TRC3(MaLiStuBndCfm);
   UNUSED(pst);
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA385, 0," MaLiStuBndCfm () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif
 
   /* If not active then don't accept the bind confirm */
#ifdef ZJ
   if (!cmTuChkRsetStatus(&zjCb.tuCb, TRUE))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_INT_PAR, EMA019, (ErrVal)0, 
                "MaUiMatBndCfm(): Invalid PSF state.");
#endif
      maSendAlrm(NEW,suId, MA_UNUSED, MA_UNUSED, "MaUiMatBndCfm",
                 LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,
                 LCM_CAUSE_PROT_NOT_ACTIVE);

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatBndCfm(pst, suId(%d))failed, Invalid PSF state.\n", suId));

      RETVALUE(RFAILED);
   }
#endif /* ZJ */

   if (suId >= (SuId)maCb.maCP.nmbMAUSaps || suId < 0 || 
       ((s = *(maCb.maSapLmaPtr + suId)) == (MaSap *)NULLP))
   {
      maSendAlrm(NEW,suId, STMATSAP, LMA_BAD_SAPID, "MaLiStuBndCfm"
               ,LCM_EVENT_LI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SUID);
      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "MaUiStuBndCfm(pst, suId(%d), status(%d))failed, invalid suId.\n",
      suId, status));
      RETVALUE(RFAILED);
   }
 
   /* Check for proper state */
   if (s->liState != MA_BND_WAIT_BNDCFM)
   {
      /* Ignore this bind confirm */
      RETVALUE(ROK);
   }
   /* It means the layer is waiting for the bind confirm */
   /* Stop the tIntTmr timer */
   maStopTmr(MA_TINT_TMR,s,(MaCmpCp *)NULLP);
   s->bndRetryCnt = 0;

   /* Confirmation indicates failure */
   if (status == CM_BND_NOK)
   {
      s->liState = MA_BND_DISABLED;
      s->maState = MA_BND_DISABLED;
      maSendAlrm(NEW, suId, MA_UNUSED, MA_UNUSED,NULLP,
                  LCM_EVENT_BND_FAIL,LCM_CATEGORY_INTERFACE,LCM_CAUSE_UNKNOWN);
      RETVALUE(ROK);
   }

   /* change lower sap status */
   s->liState = MA_BND_ENABLED;
   if ( s->uiState == MA_BND_ENABLED)
   {
      s->maState = MA_BND_ENABLED;
   }
#ifdef ZJ
   cmTuRunTimeUpd(&zjCb.tuCb, CMTU_LISAP_CB, CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_MOD, (Void *)s);
   cmTuUpdPeer(&zjCb.tuCb);
#endif /* ZJ */
   RETVALUE(ROK);

} /* end of MaLiStuBndCfm */
 

/*
*
*       Fun:   MaUiMatUbndReq    
*
*       Desc:  This function unbinds the user SAP 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaUiMatUbndReq 
(
Pst *pst,              /* Post structure */
SpId spId,             /* service provider id */
Reason reason          /* Reason for unbinding */
)
#else
PUBLIC S16 MaUiMatUbndReq (pst,spId,reason)
Pst *pst;              /* Post structure */
SpId spId;             /* service provider id */
Reason reason;         /* Reason for unbinding */
#endif
{
  MaSap *s;

  TRC3(MaUiMatUbndReq)
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA386, 0," MaUiMatUbndReq () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif
  MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
          "MaUiMatUbndReq(pst, spId(%d), reason(%d))\n", spId,
          reason));

   /* If not active then don't accept the unbind request */
#ifdef ZJ
   if (!cmTuChkRsetStatus(&zjCb.tuCb, TRUE))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_INT_PAR, EMA020, (ErrVal)0, 
                "MaUiMatUbndReq(): Invalid PSF state.");
#endif
      maSendAlrm(NEW,spId, MA_UNUSED, MA_UNUSED, "MaUiMatUbndReq",
                 LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,
                 LCM_CAUSE_PROT_NOT_ACTIVE);

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatUbndReq(pst, spId(%d))failed, Invalid PSF state.\n", spId));

      RETVALUE(RFAILED);
   }
#endif /* ZJ */

  if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
      ((s = *(maCb.maSapLmaPtr + spId)) == NULLP))
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatUbndReq"
               ,LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatUbndReq(pst, spId(%d), reason(%d))failed, invalid spId\n", 
     spId, reason));
     RETVALUE(RFAILED);
  }
   
  /* copy bind configuration parameters in TCAP sap */
  if (s->maState != MA_BND_DISABLED && s->maState != MA_BND_ENABLED)
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatUbndReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
          "MaUiMatUbndReq(pst, spId(%d), reason(%d))failed, invalid state\n", 
           spId, reason));
     RETVALUE(RFAILED);
  }

   /* Check if upper SAP is already unbound */
   if (s->uiState == MA_BND_DISABLED)
   {
      s->maState = MA_BND_DISABLED;
     maSendAlrm(NEW,spId, STMATSAP, LMA_UBND_PROCESSED, 
                "MaUiMatUbndReq. Upper already unbound",
                LMA_EVENT_UBND_PROCESSED,LCM_CATEGORY_INTERFACE,LCM_CAUSE_UNKNOWN);
      RETVALUE(ROK);
   }

   /* free all dialog control points */
   maFreeAllDlg(s);
   
#ifdef MA_RUG
   /* On SAP being unbound mark the remote interface version *
    * as invalid */
   s->remIntfValidMU = FALSE;
#endif /* MA_RUG */

   s->uiState = MA_BND_DISABLED;
   s->maState = MA_BND_DISABLED;

#ifdef ZJ
   cmTuRunTimeUpd(&zjCb.tuCb, CMTU_UISAP_CB, CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_MOD, (Void *)s);
   cmTuUpdPeer(&zjCb.tuCb);
#endif /* ZJ */
   /* SAP still exists so can be bound again with a BndReq */

  RETVALUE(ROK);
} /* MaUiMatUbndReq  */

/*
*
*       Fun:   MaMiLmaStaReq    
*
*       Desc:  This function is used by the layer management to gather
*              solicited status information. 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaMiLmaStaReq 
(
Pst     *pst,           /* post structure */
MaMngmt *sta            /* management structure */
)
#else
PUBLIC S16 MaMiLmaStaReq (pst,sta)
Pst     *pst;           /* post structure */
MaMngmt *sta;           /* management structure */
#endif
{
   MaSap  *s;
   Pst     sender;

   TRC3(MaMiLmaStaReq)
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA387, 0," MaMiLmaStaReq () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif
   MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
          "MaMiLmaStaReq(pst, elmnt(%d), elmntInst1(%d))\n",
           sta->hdr.elmId.elmnt,
           sta->hdr.elmId.elmntInst1));

   maFillReplyPst(pst,sta,sta,MA_EVTLMASTACFM,&sender);

   /* validate management structure */
   /* message type must be status request */
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sta->hdr.msgType != TSSTA)
   {
       MALOGERROR(ERRCLS_INT_PAR, EMA021, (ErrVal)sta->hdr.msgType, 
                  "MaMiLmaStaReq () Failed, invalid message type.");
      sta->cfm.status = LCM_PRIM_NOK;
      sta->cfm.reason = LCM_REASON_INVALID_MSGTYPE;
      MaMiLmaStaCfm(&sender,sta);
       RETVALUE(RFAILED);
   }

   /* entity must be our entity */
   if (sta->hdr.entId.ent != maCb.maInit.ent)
   {
      MALOGERROR(ERRCLS_INT_PAR, EMA022, (ErrVal)sta->hdr.entId.ent, 
                  "MaMiLmaStaReq () Failed, invalid entity.");
      sta->cfm.status = LCM_PRIM_NOK;
      sta->cfm.reason = LCM_REASON_INVALID_ENTITY;
      MaMiLmaStaCfm(&sender,sta);
       RETVALUE(RFAILED);
   }

   /* instance must be our instance */
   if (sta->hdr.entId.inst != maCb.maInit.inst)
   {
      MALOGERROR(ERRCLS_INT_PAR, EMA023, (ErrVal)sta->hdr.entId.inst, 
                  "MaMiLmaStaReq () Failed, invalid instance.");
      sta->cfm.status = LCM_PRIM_NOK;
      sta->cfm.reason = LCM_REASON_INVALID_INSTANCE;
      MaMiLmaStaCfm(&sender,sta);
       RETVALUE(RFAILED);
   }
   if ((sta->hdr.elmId.elmnt != STMATSAP) && (sta->hdr.elmId.elmnt != STSID))
   {
       MALOGERROR(ERRCLS_INT_PAR, EMA024, (ErrVal)sta->hdr.elmId.elmnt, 
                  "MaMiLmaStaReq () Failed, invalid SAP ID.");
      sta->cfm.status = LCM_PRIM_NOK;
      sta->cfm.reason = LCM_REASON_INVALID_ELMNT;
      MaMiLmaStaCfm(&sender,sta);
       RETVALUE(RFAILED);
   }

   /* validate physical link control block */
   if (((U32)(sta->hdr.elmId.elmntInst1) >= maCb.maCP.nmbMAUSaps)||
       (sta->hdr.elmId.elmntInst1 < 0)||
       ((s = *(maCb.maSapLmaPtr + sta->hdr.elmId.elmntInst1)) == NULLP))
   {
      MALOGERROR(ERRCLS_INT_PAR, EMA025, (ErrVal)sta->hdr.elmId.elmntInst1, 
                 "MaMiLmaStaReq () Failed, invalid parameter.");
      sta->cfm.status = LCM_PRIM_NOK;
      sta->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
      MaMiLmaStaCfm(&sender,sta);
      RETVALUE(RFAILED);
   } 
#endif

   if((s = *(maCb.maSapLmaPtr + sta->hdr.elmId.elmntInst1)) == NULLP)
   {
      sta->cfm.status = LCM_PRIM_NOK;
      sta->cfm.reason = LCM_REASON_INVALID_SAP;
      MaMiLmaStaCfm(&sender,sta);
      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
      "MaMiLmaStaReq(pst, elmnt(%d), elmntInst1(%d))failed, invalid SAPID(%d)\n",
      sta->hdr.elmId.elmnt,sta->hdr.elmId.elmntInst1,
      sta->hdr.elmId.elmntInst1));
      RETVALUE(RFAILED);
   }
   
   /* check which kind of status is requested */
   switch (sta->hdr.elmId.elmnt)
   {
      /* status for MAP Sap */
      case STMATSAP: 
      /* status for MAP Connection */
         sta->t.ssta.s.maUSta.swtch = s->cfg.swtch;
         sta->t.ssta.s.maUSta.maState = s->maState;
#ifdef MA_RUG
         /* Send self and remote version information and remIntfValid flag */
         sta->t.ssta.s.maUSta.maVerStaMU.remIntfValid = s->remIntfValidMU;
         sta->t.ssta.s.maUSta.maVerStaMU.selfIntfVer = MATIFVER;
         sta->t.ssta.s.maUSta.maVerStaMU.remIntfVer = s->maPstMU.intfVer;
         sta->t.ssta.s.maUSta.maVerStaTC.remIntfValid = s->remIntfValidST;
         sta->t.ssta.s.maUSta.maVerStaTC.selfIntfVer = STUIFVER;
         sta->t.ssta.s.maUSta.maVerStaTC.remIntfVer = s->maPstST.intfVer;
#endif /* MA_RUG */
         break;
      /* system id */
      case STSID: 
         (Void) maGetSId(&sta->t.ssta.s.sysId);
         break;

   } 
   SGetDateTime(&sta->t.ssta.dt);
   sta->cfm.status = LCM_PRIM_OK;
   sta->cfm.reason = LCM_REASON_NOT_APPL;
   MaMiLmaStaCfm(&sender,sta);
   RETVALUE(ROK);
} /* MaMiLmaStaReq  */

/*
*
*       Fun:   Statistics Request
*
*       Desc:  This function is used by the Layer Management to
*              gather solicited statistics information from the MAP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaMiLmaStsReq
(
Pst *pst,                   /* post structure */
Action action,              /* action */
MaMngmt *sts                /* management structure */
)
#else
PUBLIC S16 MaMiLmaStsReq(pst, action, sts)
Pst *pst;                   /* post structure */
Action action;              /* action */
MaMngmt *sts;               /* management structure */
#endif
{
   MaSap *s;                /* MAP sap */
   Pst     sender;

   TRC3(MaMiLmaStsReq)
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA388, 0," MaMiLmaStsReq () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif
   MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
          "MaMiLmaStsReq(pst, action(%d), elmnt(%d), elmntInst1(%d))\n",
           action, sts->hdr.elmId.elmnt,
           sts->hdr.elmId.elmntInst1));

   maFillReplyPst(pst,sts,sts,MA_EVTLMASTSCFM,&sender);

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate management structure */
   /* message type must be statistics request */
   if (sts->hdr.msgType != TSTS)
   {
      MALOGERROR(ERRCLS_INT_PAR, EMA026, (ErrVal)sts->hdr.msgType, 
                  "MaMiLmaStsReq () Failed, invalid message type.");
      sts->cfm.status = LCM_PRIM_NOK;
      sts->cfm.reason = LCM_REASON_INVALID_MSGTYPE;
      MaMiLmaStsCfm(&sender,action,sts);
      RETVALUE(RFAILED);
   }
   /* entity must be our entity */
   if (sts->hdr.entId.ent != maCb.maInit.ent)
   {
      MALOGERROR(ERRCLS_INT_PAR, EMA027, (ErrVal)sts->hdr.entId.ent, 
                 "MaMiLmaStsReq () Failed, invalid entity.");
      sts->cfm.status = LCM_PRIM_NOK;
      sts->cfm.reason = LCM_REASON_INVALID_ENTITY;
      MaMiLmaStsCfm(&sender,action,sts);
      RETVALUE(RFAILED);
   }
   /* instance must be our instance */
   if (sts->hdr.entId.inst != maCb.maInit.inst)
   {
      MALOGERROR(ERRCLS_INT_PAR, EMA028, (ErrVal)sts->hdr.entId.inst, 
                 "MaMiLmaStsReq () Failed, invalid instance.");
      sts->cfm.status = LCM_PRIM_NOK;
      sts->cfm.reason = LCM_REASON_INVALID_INSTANCE;
      MaMiLmaStsCfm(&sender,action,sts);
      RETVALUE(RFAILED);
   }
   if (sts->hdr.elmId.elmnt != STMATSAP)
   {
      MALOGERROR(ERRCLS_INT_PAR, EMA029, (ErrVal)sts->hdr.elmId.elmnt, 
                 "MaMiLmaStaReq () Failed, invalid SAP ID.");
      sts->cfm.status = LCM_PRIM_NOK;
      sts->cfm.reason = LCM_REASON_INVALID_ELMNT;
      MaMiLmaStsCfm(&sender,action,sts);
      RETVALUE(RFAILED);
   }
#endif
 
   /* elmnt defines type of statistics */
   switch (sts->hdr.elmId.elmnt)
   {
      /* upper sap */
      case STMATSAP:
        /* validate physical link control block */
        /*  deleted the check for SAP state */
        if (((U32)(sts->hdr.elmId.elmntInst1) >= maCb.maCP.nmbMAUSaps)||
            (sts->hdr.elmId.elmntInst1 < 0) ||
            ((s = *(maCb.maSapLmaPtr + sts->hdr.elmId.elmntInst1)) == NULLP))
        {
           MALOGERROR(ERRCLS_INT_PAR, EMA030, (ErrVal)sts->hdr.elmId.elmnt, 
                      "MaMiLmaStaReq () Failed, invalid parameter.");
           sts->cfm.status = LCM_PRIM_NOK;
           sts->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
           MaMiLmaStsCfm(&sender,action,sts);
           RETVALUE(RFAILED);
        }

        /* copy the statistics information */
        (Void) cmMemcpy((U8 *) &sts->t.sts.maMAUSts,
                        (U8 *) &s->sts.swtch, 
                        (PTR)  sizeof(MaMAUSts));

#if MAP_REL99
#if (MAP_SEC && LMAV2)
        /* copy the MAPsec statistics information */
        (Void) cmMemcpy((U8 *) &sts->t.sts.secSts,
                        (U8 *) &s->secSts,
                        (PTR)  sizeof(LmaSecSapSts));
#endif /* MAP_SEC */
#endif
        /* clear statistics counter if so requested */
        if (action == ZEROSTS)
        {
           maZeroSts(s);
        } 

   } /* end switch */

   /* get the date and time */
   SGetDateTime(&sts->t.sts.dt);

   /* fill the duration */
   sts->t.sts.dura.tenths = 0;
   sts->t.sts.dura.secs = 0;
   sts->t.sts.dura.mins = 0;
   sts->t.sts.dura.hours = 0;
   sts->t.sts.dura.days = 0;
   
   sts->cfm.status = LCM_PRIM_OK;
   sts->cfm.reason = LCM_REASON_NOT_APPL;
   (Void) MaMiLmaStsCfm(&sender,action,sts);

   RETVALUE(ROK);
} /* end of MaMiLmaStsReq */

/*
*
*       Fun:   Control Request
*
*       Desc:  This function is used by the Layer Management to
*              control the MAP layer software
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaMiLmaCntrlReq
(
Pst *pst,                    /* post structure */
MaMngmt *cntrl               /* management structure */
)
#else
PUBLIC S16 MaMiLmaCntrlReq(pst, cntrl)
Pst *pst;                    /* post structure */
MaMngmt *cntrl;              /* management structure */
#endif
{
   MaSap *s;               /* MAP sap */
   U32     i;
   Pst     sender;
   MaMngmt cfm_msg;

   TRC3(MaMiLmaCntrlReq)
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA389, 0," MaMiLmaCntrlReq () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif
   MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
          "MaMiLmaCntrlReq(pst, elmnt(%d), elmntInst1(%d))\n",
           cntrl->hdr.elmId.elmnt, cntrl->hdr.elmId.elmntInst1));

   maFillReplyPst(pst,cntrl,&cfm_msg,MA_EVTLMACNTRLCFM,&sender);

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate management structure */
   /* message type must be control request */
   if (cntrl->hdr.msgType != TCNTRL)
   {
      cfm_msg.cfm.status = LCM_PRIM_NOK;
      cfm_msg.cfm.reason = LCM_REASON_INVALID_MSGTYPE;
      MaMiLmaCntrlCfm(&sender,&cfm_msg);

      MALOGERROR(ERRCLS_INT_PAR, EMA031, (ErrVal)cntrl->hdr.msgType, 
                 "MaLiLmaCntrlReq() Failed, invalid message type.");
      RETVALUE(RFAILED);
   }
   /* entity must be our entity */
   if (cntrl->hdr.entId.ent != maCb.maInit.ent)
   {
      cfm_msg.cfm.status = LCM_PRIM_NOK;
      cfm_msg.cfm.reason = LCM_REASON_INVALID_ENTITY;
      MaMiLmaCntrlCfm(&sender,&cfm_msg);

      MALOGERROR(ERRCLS_INT_PAR, EMA032, (ErrVal)cntrl->hdr.entId.ent, 
                 "MaLiLmaCntrlReq() Failed, invalid entity.");
      RETVALUE(RFAILED);
   }
   /* instance must be our instance */
   if (cntrl->hdr.entId.inst != maCb.maInit.inst)
   {
      cfm_msg.cfm.status = LCM_PRIM_NOK;
      cfm_msg.cfm.reason = LCM_REASON_INVALID_INSTANCE;
      MaMiLmaCntrlCfm(&sender,&cfm_msg);

      MALOGERROR(ERRCLS_INT_PAR, EMA033, (ErrVal)cntrl->hdr.entId.inst, 
                 "MaLiLmaCntrlReq() Failed, invalid instance.");
      RETVALUE(RFAILED);
   }

   if ((cntrl->hdr.elmId.elmnt != STMATSAP) && 
       (cntrl->hdr.elmId.elmnt != STMATGEN) && 
       (cntrl->hdr.elmId.elmnt != STGRSUSAP) && 
       (cntrl->hdr.elmId.elmnt != STGRSPSAP) &&
			(cntrl->hdr.elmId.elmnt != STMATLSAP)
#if MAP_REL99
#if (MAP_SEC && LMAV2)
       && (cntrl->hdr.elmId.elmnt != STMATSA)
#endif
#endif
      )
   {
      MALOGERROR(ERRCLS_INT_PAR, EMA034, (ErrVal)cntrl->hdr.elmId.elmnt, 
                 "MaMiLmaCntrlReq () Failed, invalid element.");
      cfm_msg.cfm.status = LCM_PRIM_NOK;
      cfm_msg.cfm.reason = LCM_REASON_INVALID_ELMNT;
      MaMiLmaCntrlCfm(&sender,&cfm_msg);
       RETVALUE(RFAILED);
   }
#endif

   /* elmnt defines type of control required */
   switch (cntrl->hdr.elmId.elmnt)
   {
      /* general control */
      case STMATGEN:
         switch (cntrl->t.cntrl.action)
         {

            case ADEL:
            {
               S16 ret; /* return value */

               /* delete all the saps and associated dlgs and invokes */
               for (i=0; i < maCb.maCP.nmbMAUSaps; i++)
               {
                  if (maCb.maSapLmaPtr[i] == NULLP)
                  {
                     continue;
                  }
                  ret = maRemMaSap((SpId)i);
#if (ERRCLASS &  ERRCLS_DEBUG)
                  if (ret == RFAILED)
                  {
                     MALOGERROR(ERRCLS_DEBUG, EMA035, 
                     (ErrVal)cntrl->hdr.elmId.elmntInst1,
                     "MaCntrlReq(). Sap Deletion failed");
                     RETVALUE(RFAILED);
                  }
#endif /* ERRCLASS & ERRCLS_INT_PAR */
               } /* end for */

              /* free the memory for the  sap list */
              SPutSBuf(maCb.maInit.region,maCb.maInit.pool,(Data *) maCb.maSapLmaPtr, 
                         (Size) (maCb.maCP.nmbMAUSaps * sizeof(MaSap *)));

              /* Deregister the timer */
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
              ret = SDeregTmr(maCb.maInit.procId,
                           maCb.maInit.ent, 
                           maCb.maInit.inst, 
                           maCb.maCP.timeRes, 
                           maActvTmr);
#else
              ret = SDeregTmr(maCb.maInit.ent, 
                           maCb.maInit.inst, 
                           maCb.maCP.timeRes, 
                           maActvTmr);
#endif

#if (ERRCLASS & ERRCLS_DEBUG)
              if (ret != ROK)
              {
                 MALOGERROR(ERRCLS_DEBUG, EMA036, 
                         (ErrVal) cntrl->t.cntrl.action,
                         "MaCntrlReq(). Deregister timer failed");
              }
#endif /* ERRCLASS & ERRCLS_DEBUG */

#ifdef MA_STATIC_EVT_STRUCT
#ifdef LCMAUIMAT
              /* free the memory for the  global enc.ev structure */
              SPutSBuf(maCb.maInit.region,maCb.maInit.pool,(Data *) maGlobEncEv, 
                         (Size) (sizeof(MaAllSSEv)));
#endif /* LCMAUIMAT */
              /* free the memory for the  globale dec ev structure */
              SPutSBuf(maCb.maInit.region,maCb.maInit.pool,(Data *) maGlobDecEv, 
                         (Size) (sizeof(MaAllSSEv)));
#endif /* MA_STATIC_EVT_STRUCT */

              /* unreserve the reserved memory */
              (Void) SPutSMem(maCb.maInit.region, maCb.maInit.pool);

               /* make the general config done as false */
               maCb.maInit.cfgDone = FALSE;
               /* enable unsolicited alarms */
               break;
            }
            case AENA:           
            {
               switch(cntrl->t.cntrl.subAction)
               {
                  case SAUSTA:
                     maCb.maInit.usta = TRUE;
#ifdef ZF
                     cmTuRunTimeUpd(&zjCb.tuCb, CMTU_PROT_CB, 
                                    CMPFTHA_UPDTYPE_NORMAL,
                                    CMPFTHA_ACTN_MOD, (Void *)&maCb.maInit);
#endif
                     break;
                  case SATRC:
                     for(i=0;i< maCb.maCP.nmbMAUSaps;i++)
                     {
                        if(maCb.maSapLmaPtr[i] == NULLP)
                           continue;
                        maCb.maSapLmaPtr[i]->trc = TRUE;
                     }
                     break;
#ifdef DEBUGP
                  case SADBG:
                     maCb.maInit.dbgMask |= cntrl->t.cntrl.s.dbg.dbgMask;
                     break;
#endif
                  default:
#if (ERRCLASS & ERRCLS_INT_PAR)
                     MALOGERROR(ERRCLS_INT_PAR, EMA037, 
                     (ErrVal)cntrl->t.cntrl.subAction,
                     "MaMiLmaCntrlReq () Failed, invalid subaction.");
#endif
                     break;
                } 
             break;
             }
             /* disable unsolicited alarms */
             case ADISIMM:   
             {
               switch(cntrl->t.cntrl.subAction)
               {
                  case SAUSTA:
                    maCb.maInit.usta = FALSE;
#ifdef ZF
                     cmTuRunTimeUpd(&zjCb.tuCb, CMTU_PROT_CB, 
                                    CMPFTHA_UPDTYPE_NORMAL,
                                    CMPFTHA_ACTN_MOD, (Void *)&maCb.maInit);
#endif
                    break;
                  case SATRC:
                    for(i=0;i<maCb.maCP.nmbMAUSaps;i++)
                    {
                       if(maCb.maSapLmaPtr[i] == NULLP)
                       continue;
                       maCb.maSapLmaPtr[i]->trc = FALSE;
                    }
                    break;
#ifdef DEBUGP
                  case SADBG:
                    maCb.maInit.dbgMask &= ~(cntrl->t.cntrl.s.dbg.dbgMask);
                    break;
#endif
                  default:
#if (ERRCLASS & ERRCLS_INT_PAR)
                    MALOGERROR(ERRCLS_INT_PAR, EMA038, 
                              (ErrVal)cntrl->t.cntrl.subAction, 
                              "MaMiLmaCntrlReq () Failed, subAction invalid");
#endif
                    break;
               } 
               break;
             }
             case ASHUTDOWN:  /* Shutdown the MAP-GSM layer */
               maShutDown();
               break;

             default:
#if (ERRCLASS & ERRCLS_INT_PAR)
               MALOGERROR(ERRCLS_INT_PAR, EMA039, 
                         (ErrVal)cntrl->t.cntrl.action, 
                         "MaMiLmaCntrlReq () Failed, invalid action.");
#endif
               break;
         }
         break;

      /* control a physical link */
      case STMATSAP:

         /* validate physical link control block */
         if (((U32)(cntrl->hdr.elmId.elmntInst1) >= maCb.maCP.nmbMAUSaps)||
             (cntrl->hdr.elmId.elmntInst1  < 0) ||
             ((s = *(maCb.maSapLmaPtr + cntrl->hdr.elmId.elmntInst1)) == NULLP))
         {
            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LCM_REASON_INVALID_PAR_VAL;
            MaMiLmaCntrlCfm(&sender,&cfm_msg);
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
            "MaMiLmaCntrlReq(pst, elmnt(%d), elmntInst1(%d))failed, \
            invalid parameter.\n",
            cntrl->hdr.elmId.elmnt, cntrl->hdr.elmId.elmntInst1));
            RETVALUE(RFAILED);
         }

         switch (cntrl->t.cntrl.action)
         {
            /* action: Enable */
            case AENA:          
               switch (cntrl->t.cntrl.subAction)
               {
                  /* subaction: Specific Element */
                  case SAELMNT:  
                     break;

                  /* subaction: Trace Generation */
                  case SATRC:
                     s->trc = TRUE;
                     break;

                  default:
#if (ERRCLASS & ERRCLS_INT_PAR)
                     MALOGERROR(ERRCLS_INT_PAR, EMA040, 
                                (ErrVal)cntrl->t.cntrl.subAction, 
                                "MaMiLmaCntrlReq () Failed, invalid subaction.");
#endif
                     break;
               }
               break;

            /* action: Disable */
            case ADISIMM:        
               switch (cntrl->t.cntrl.subAction)
               {
                  /* subaction: Specific Element */
                  case SAELMNT:     
                     break;

                  /* subaction: Trace Generation */
                  case SATRC:
                     s->trc = FALSE;
                     break;

                  default:
#if (ERRCLASS & ERRCLS_INT_PAR)
                     MALOGERROR(ERRCLS_INT_PAR, EMA041, 
                                (ErrVal)cntrl->t.cntrl.subAction, 
                                "MaMiLmaCntrlReq () Failed, invalid subaction.");
#endif
                     break;
               }
               break;
#ifdef LMAV3
            /* Run Audits to remove hanging resources */
            case AAUDIT:
               maRunAudits(cntrl->hdr.elmId.elmntInst1, 
                           cntrl->t.cntrl.cbType, 
                           cntrl->t.cntrl.nmbCb,
                           cntrl->t.cntrl.expTime);
               break;
#endif /* LMAV3 */

            case ADEL:
            {
               S16 ret;

               ret = maRemMaSap(cntrl->hdr.elmId.elmntInst1);
#if (ERRCLASS &  ERRCLS_INT_PAR)
               if (ret == RFAILED)
               {
                  MALOGERROR(ERRCLS_INT_PAR, EMA042,
                   (ErrVal)cntrl->hdr.elmId.elmntInst1,
                   "maCntrlMaSap(). Sap Deletion failed");
                   RETVALUE(RFAILED);
               }
#endif /* ERRCLASS & ERRCLS_INT_PAR */
               break;
            }
/* ma001.203 : addition, new action switch case to handle disable single upper sap */
       	 /* Unbind & Disable Upper Single Sap */ 
           case AUBND_DIS:
             {
                 S16 ret;    
                 ret = maDisableSuSap(s);
                 if(ret != ROK )
                 {
#if (ERRCLASS &  ERRCLS_INT_PAR)
                    MALOGERROR(ERRCLS_INT_PAR, EMA042,
                    (ErrVal)cntrl->hdr.elmId.elmntInst1,
                    "MaMiLmaCntrlReq(). Sap Disable failed");
#endif /* ERRCLASS & ERRCLS_INT_PAR */      
                     cfm_msg.cfm.status = LCM_PRIM_NOK;
                     cfm_msg.cfm.reason = LCM_REASON_INVALID_PAR_VAL;
                     MaMiLmaCntrlCfm(&sender,&cfm_msg);
                     RETVALUE(RFAILED);
                   }
#ifdef MA_FTHA
                    s->contEnt = ENTSM;
#endif /* MA_FTHA */
#ifdef ZJ
           cmTuRunTimeUpd(&zjCb.tuCb, CMTU_UISAP_CB, CMPFTHA_UPDTYPE_SYNC,
           CMPFTHA_ACTN_MOD, (Void *)s);

#endif /* ZJ */
               break;
            }

            default:
#if (ERRCLASS & ERRCLS_INT_PAR)
               MALOGERROR(ERRCLS_INT_PAR, EMA043, 
                          (ErrVal)cntrl->t.cntrl.action, 
                          "MaMiLmaCntrlReq () Failed, invalid action.");
#endif
               break;
         }
         break;
      /*  ma001.203: Addition, Added new Header type to take care about
          single lower sap enable/disable */
      case STMATLSAP:
      {

         if (((U32)(cntrl->hdr.elmId.elmntInst1) >= maCb.maCP.nmbMAUSaps)||
             (cntrl->hdr.elmId.elmntInst1  < 0) ||
             ((s = *(maCb.maSapLmaPtr + cntrl->hdr.elmId.elmntInst1)) == NULLP))
         {
            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LCM_REASON_INVALID_PAR_VAL;
            MaMiLmaCntrlCfm(&sender,&cfm_msg);
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
            "MaMiLmaCntrlReq(pst, elmnt(%d), elmntInst1(%d))failed, \
            invalid parameter.\n",
            cntrl->hdr.elmId.elmnt, cntrl->hdr.elmId.elmntInst1));
            RETVALUE(RFAILED);
         }

        switch (cntrl->t.cntrl.action)
        {
           U16 ret;

            case AUBND_DIS:
              {
                 ret = maDisableSpSap(s);

                 if(ret != ROK )
                 {

#if (ERRCLASS &  ERRCLS_INT_PAR)
                  MALOGERROR(ERRCLS_INT_PAR, EMA042,
                   (ErrVal)cntrl->hdr.elmId.elmntInst1,
                   "MaMiLmaCntrlReq(). Sap Disable failed");
#endif /* ERRCLASS & ERRCLS_INT_PAR */
                   cfm_msg.cfm.status = LCM_PRIM_NOK;
                   cfm_msg.cfm.reason = LCM_REASON_INVALID_PAR_VAL;
                   MaMiLmaCntrlCfm(&sender,&cfm_msg);
                   RETVALUE(RFAILED);
                 }
#ifdef MA_FTHA
                  s->contEnt = ENTSM;
#endif /* MA_FTHA */

#ifdef ZJ
                  cmTuRunTimeUpd(&zjCb.tuCb, CMTU_UISAP_CB, CMPFTHA_UPDTYPE_SYNC
,
                CMPFTHA_ACTN_MOD, (Void *)s);

#endif /* ZJ */
                 break;
              }

         case ABND_ENA:
             {
#ifdef MA_RUG
             /* Bind cannot be performed in SAP does not have valid
                 * remote interface version i.e ver sync not done   */
                if(s->remIntfValidST == FALSE)
                {
                  cfm_msg.cfm.status = LCM_PRIM_NOK;
                  cfm_msg.cfm.reason = LCM_REASON_SWVER_NAVAIL;
                  MaMiLmaCntrlCfm(&sender,&cfm_msg);
#if (ERRCLASS &  ERRCLS_INT_PAR)
                  MALOGERROR(ERRCLS_INT_PAR, EMA042,
                  (ErrVal)cntrl->hdr.elmId.elmntInst1,
                  "MaMiLmaCntrlReq(). Sap Enable failed");

#endif /* ERRCLASS & ERRCLS_INT_PAR */
                    RETVALUE(RFAILED);
                 }
#endif /* MA_RUG  */
#ifdef MA_FTHA
                 s->contEnt = ENTNC;
#endif /* MA_FTHA */
                 ret = maEnableSpSap(s);
                 if(ret != ROK )
                 {

#if (ERRCLASS &  ERRCLS_INT_PAR)
                  MALOGERROR(ERRCLS_INT_PAR, EMA042,
                   (ErrVal)cntrl->hdr.elmId.elmntInst1,
                   "MaMiLmaCntrlReq(). Sap Enable failed");
#endif /* ERRCLASS & ERRCLS_INT_PAR */
                   cfm_msg.cfm.status = LCM_PRIM_NOK;
                   cfm_msg.cfm.reason = LCM_REASON_INVALID_PAR_VAL;
                   MaMiLmaCntrlCfm(&sender,&cfm_msg);
                   RETVALUE(RFAILED);
                 }

              break;
           }
        default:
#if (ERRCLASS & ERRCLS_INT_PAR)
             MALOGERROR(ERRCLS_INT_PAR, EMA043,
                          (ErrVal)cntrl->t.cntrl.action,
                          "MaMiLmaCntrlReq () Failed,invalid action.");
#endif
            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LCM_REASON_INVALID_ACTION;
            MaMiLmaCntrlCfm(&sender,&cfm_msg);
            RETVALUE(RFAILED);

            break;
         }

        break;
      }

      /* control the Group of Upper Sap */
      case STGRSUSAP:
      {
         S16 ret;

         if (cntrl->t.cntrl.subAction != SAGR_DSTPROCID)
         {
            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LCM_REASON_INVALID_SUBACTION;
            MaMiLmaCntrlCfm(&sender,&cfm_msg);
#if (ERRCLASS & ERRCLS_DEBUG)
            MALOGERROR(ERRCLS_DEBUG, EMA044, (ErrVal) cntrl->t.cntrl.action,
                     "MaMiLmaCntrlReq(). Upper Group Sap Incorrect subaction");
#endif /* ERRCLASS & ERRCLS_DEBUG */
            RETVALUE(RFAILED);
         }
         ret = maCntrlGrSuSap(cntrl->t.cntrl.action, cntrl);
         if (ret != ROK)
         {
            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LCM_REASON_INVALID_PAR_VAL;
            MaMiLmaCntrlCfm(&sender,&cfm_msg);
#if (ERRCLASS & ERRCLS_DEBUG)
            MALOGERROR(ERRCLS_DEBUG, EMA045, (ErrVal) cntrl->t.cntrl.action,
              "MaMiLmaCntrlReq(). Upper Group Sap control request failed");
#endif /* ERRCLASS & ERRCLS_DEBUG */
            RETVALUE(RFAILED);
         }
         break;
      }
            
      case STGRSPSAP:
      {
         S16 ret;

         if (cntrl->t.cntrl.subAction != SAGR_DSTPROCID)
         {
            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LCM_REASON_INVALID_SUBACTION;
            MaMiLmaCntrlCfm(&sender,&cfm_msg);
#if (ERRCLASS & ERRCLS_DEBUG)
            MALOGERROR(ERRCLS_DEBUG, EMA046, (ErrVal) cntrl->t.cntrl.action,
                     "MaMiLmaCntrlReq(). Lower Group Sap Incorrect subaction");
#endif /* ERRCLASS & ERRCLS_DEBUG */
            RETVALUE(RFAILED);
         }
         ret = maCntrlGrSpSap(cntrl->t.cntrl.action, cntrl);
         if (ret != ROK)
         {
            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LCM_REASON_INVALID_PAR_VAL;
#ifdef MA_RUG
            /* if remote interface version is not valid, confirm reason
             * should be LCM_REASON_SWVER_NAVAIL 
             */
            if (ret == LCM_REASON_SWVER_NAVAIL)
            {
               cfm_msg.cfm.reason = LCM_REASON_SWVER_NAVAIL;
            }
#endif /* MA_RUG */
            MaMiLmaCntrlCfm(&sender,&cfm_msg);
#if (ERRCLASS & ERRCLS_DEBUG)
            MALOGERROR(ERRCLS_INT_PAR, EMA047, (ErrVal) cntrl->t.cntrl.action,
               "MaMiLmaCntrlReq(). Lower Group Sap control request failed");
#endif /* ERRCLASS & ERRCLS_DEBUG */
            RETVALUE(RFAILED);
         }

         break;
      }   

#if MAP_REL99
#if (MAP_SEC && LMAV2)
      /* control a PLMN/SA control block */
      case STMATSA:
      {
         S16 ret;

         /* validate plmn/SA control request parameters */
         if ((ret = maChkPlmnId(&cntrl->t.cntrl.par.plmn.id)) != ROK)
         {
            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LMA_REASON_INV_PLMN;
            MaMiLmaCntrlCfm(&sender,&cfm_msg);
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
                   "MaMiLmaCntrlReq(pst, elmnt(%d))failed, \
                   PLMN ID missing.\n", cntrl->hdr.elmId.elmnt));
            RETVALUE(RFAILED);

         }
         if ((cntrl->t.cntrl.par.plmn.type != LMA_PLMN_SOFT_DELETE &&
              cntrl->t.cntrl.par.plmn.type != LMA_PLMN_SOFT_EXP_SET &&
              cntrl->t.cntrl.par.plmn.type != LMA_PLMN_HARD_DELETE))
         {
            cfm_msg.cfm.status = LCM_PRIM_NOK;
            cfm_msg.cfm.reason = LMA_REASON_INV_PLMN_DEL_TYPE;
            MaMiLmaCntrlCfm(&sender,&cfm_msg);
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
                   "MaMiLmaCntrlReq(pst, elmnt(%d))failed, \
                   wrong Plmn entry deletion type(%d).\n",
                   cntrl->hdr.elmId.elmnt, cntrl->t.cntrl.par.plmn.type));
            RETVALUE(RFAILED);
         }

         switch (cntrl->t.cntrl.action)
         {
            case ADEL:
               ret = maRemSa((LmaCntrlPlmn *)&cntrl->t.cntrl.par.plmn);
               if (ret != ROK)
               {
                  cfm_msg.cfm.status = LCM_PRIM_NOK;
                  cfm_msg.cfm.reason = (U16)ret;
                  MaMiLmaCntrlCfm(&sender,&cfm_msg);
#if (ERRCLASS & ERRCLS_DEBUG)
                  MALOGERROR(ERRCLS_INT_PAR, EMA048, 
                             (ErrVal) cntrl->t.cntrl.action,
                             "MaMiLmaCntrlReq(). SA deletion request failed");
#endif /* ERRCLASS & ERRCLS_DEBUG */
                  MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
                         "MaMiLmaCntrlReq(pst, elmnt(%d))failed, \
                         SA deletion control request failed.\n", 
                         cntrl->hdr.elmId.elmnt));
                  RETVALUE(RFAILED);
               }
               break;

            default:
#if (ERRCLASS & ERRCLS_INT_PAR)
               MALOGERROR(ERRCLS_INT_PAR, EMA049, 
                          (ErrVal)cntrl->t.cntrl.action, 
                          "MaMiLmaCntrlReq () Failed, invalid action.");
#endif
               break;
         }
      }
#endif /* MAP_SEC */
#endif
      default:
         break;
   }

   cfm_msg.cfm.status = LCM_PRIM_OK;
   cfm_msg.cfm.reason = LCM_REASON_NOT_APPL;
   MaMiLmaCntrlCfm(&sender,&cfm_msg);

#ifdef ZJ
   if (cntrl->t.cntrl.action != ASHUTDOWN)
      cmTuUpdPeer(&zjCb.tuCb);
#endif /* ZJ */

   RETVALUE(ROK);
} /* end of MaMiLmaCntrlReq */

#ifdef MA_FTHA
/*
 *
 *       Fun  :  System agent control Request 
 *
 *       Desc :  Processes system agent control request primitive
 *
 *       Ret  :  ROK  - ok
 *
 *       Notes:  None
 *
 *       File :  ca_bdy1.c
 *
 */
#ifdef ANSI
PUBLIC S16 MaMiShtCntrlReq
(
Pst     *pst,                   /* post structure          */
ShtCntrlReqEvnt *reqInfo        /* system agent control request event */
)
#else
PUBLIC S16 MaMiShtCntrlReq(pst, reqInfo)
Pst     *pst;                   /* post structure          */
ShtCntrlReqEvnt *reqInfo;       /* system agent control request event */
#endif
{
   S32                   i;     /* counter */
   MaSap                *s;     /* MAP-GSM Lower sap */
   Pst              repPst;     /* reply post structure */
   ShtCntrlCfmEvnt cfmInfo;     /* system agent control confirm event */
   
   TRC3(MaMiShtCntrlReq)
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA390, 0," MaMiShtCntrlReq () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif

#ifdef ZJ
#ifdef MA_RUG
   /* checking critical resource set is not required for getver
    * and setver, as these control requests can come before
    * critical resource set is made active
    */
   if ((reqInfo->reqType != SHT_REQTYPE_GETVER) &&
       (reqInfo->reqType != SHT_REQTYPE_SETVER))
#endif /* MA_RUG */
   {
      if (!cmTuChkRsetStatus(&zjCb.tuCb, TRUE))
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         MALOGERROR(ERRCLS_INT_PAR, EMA050, (ErrVal)0, 
                    "MaMiShtCntrlReq(): Invalid PSF state.");
#endif
         maSendAlrm(NEW, MA_UNUSED, MA_UNUSED, MA_UNUSED, 
                    "MaMiShtCntrlReq", LCM_EVENT_UI_INV_EVT, 
                    LCM_CATEGORY_INTERFACE, LCM_CAUSE_PROT_NOT_ACTIVE);

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaMiShtCntrlReq()failed, reqType (%d)\n", reqInfo->reqType));

         RETVALUE(RFAILED);
      }
   }
#endif /* ZJ */

   cmZero((Data *)&cfmInfo, sizeof(ShtCntrlCfmEvnt));

   /* fill reply pst structure */
   cmCopy((Data *) pst,(Data *)&repPst,sizeof(Pst));

   repPst.dstProcId = pst->srcProcId;
   repPst.dstEnt    = pst->srcEnt;
   repPst.dstInst   = pst->srcInst;
   repPst.prior     = reqInfo->hdr.response.prior;
   repPst.route     = reqInfo->hdr.response.route;
   repPst.selector  = reqInfo->hdr.response.selector;
   repPst.region    = reqInfo->hdr.response.mem.region;
   repPst.pool      = reqInfo->hdr.response.mem.pool;
   repPst.event     = EVTSHTCNTRLCFM;
   repPst.srcProcId = maCb.maInit.procId; /* This entity's processor Id  */
   repPst.srcEnt    = maCb.maInit.ent;
   repPst.srcInst   = maCb.maInit.inst;

   /* fill reply transaction Id */
   cfmInfo.transId = reqInfo->hdr.transId;
#ifdef MA_RUG
   /* fill request type in reply */
   cfmInfo.reqType = reqInfo->reqType;
#endif

   /* check if general configuration done */
   if (maCb.maInit.cfgDone != TRUE)
   {
      cfmInfo.status.status = LCM_PRIM_NOK;
      cfmInfo.status.reason = LCM_REASON_GENCFG_NOT_DONE;

      MaMiShtCntrlCfm(&repPst, &cfmInfo);
      RETVALUE(ROK);
   }
   
   /* fill status value */
   cfmInfo.status.reason = LCM_REASON_NOT_APPL;
   
   switch (reqInfo->reqType)
   {
      case SHT_REQTYPE_BND_ENA:   /* system agent control bind enable */
         switch (reqInfo->s.bndEna.grpType)
         {
            case SHT_GRPTYPE_ALL:
               /* go through all the sap control blocks and start bind  *
                * enable procedure on those SAPs for which              *
                * (pst->dstProcId == reqInfo->s.bndEna.dstProcId) && *
                * (pst->dstEnt == reqInfo->s.bndEna.dstEnt) &&       *
                * (pst->dstInst == reqInfo->s.bndEna.dstInst)        */
               
               /* call function for all SAPs */
               for (i = 0; i < (S32)maCb.maCP.nmbMAUSaps; i++)
               {
                  if ((s = *(maCb.maSapLmaPtr + (SuId)i)) != NULLP)
                   {
                      if ((s->maPstST.dstProcId == reqInfo->s.bndEna.dstProcId) &&
                          (s->maPstST.dstEnt == reqInfo->s.bndEna.dstEnt.ent) &&
                          (s->maPstST.dstInst == reqInfo->s.bndEna.dstEnt.inst))
                      {
#ifdef MA_RUG  
                         /* Bind cannot be performed in SAP does not have 
                          * valid remote interface version i.e ver sync not
                          * done.
                          */
                         if(s->remIntfValidST == FALSE)
                         {
                            cfmInfo.status.reason = LCM_REASON_SWVER_NAVAIL;
                            break;
                         }
#endif /* MA_RUG */
                         if (s->contEnt != ENTSM)
                            (Void) maEnableSpSap(s);
#ifdef ZJ
                         cmTuRunTimeUpd(&zjCb.tuCb, CMTU_LISAP_CB,
                                        CMPFTHA_UPDTYPE_SYNC,
                                        CMPFTHA_ACTN_MOD,
                                        (Void *)s);
#endif /* ZJ */
                      }
                   }
               }
               break;
               
            case SHT_GRPTYPE_ENT:
               /* go through all the sap control blocks and start bind  *
                * enable procedure on those SAPs for which              *
                * (pst->dstEnt == reqInfo->s.bndEna.dstEnt) &&       *
                * (pst->dstInst == reqInfo-.s.bndEna.dstInst)        */
               
               /* call function for all SAPs */
               for (i = 0; i < (S32)maCb.maCP.nmbMAUSaps; i++)
               {
                  if ((s = *(maCb.maSapLmaPtr + (SuId)i)) != NULLP)
                  {
                     if ((s->maPstST.dstEnt == reqInfo->s.bndEna.dstEnt.ent) &&
                         (s->maPstST.dstInst == reqInfo->s.bndEna.dstEnt.inst))
                     {
#ifdef MA_RUG  
                        /* Bind cannot be performed in SAP does not have 
                         * valid remote interface version i.e ver sync not
                         * done.
                         */
                        if(s->remIntfValidST == FALSE)
                        {
                           cfmInfo.status.reason = LCM_REASON_SWVER_NAVAIL;
                           break;
                        }
#endif /* MA_RUG */
                        if (s->contEnt != ENTSM)
                           (Void) maEnableSpSap(s);
#ifdef ZJ
                         cmTuRunTimeUpd(&zjCb.tuCb, CMTU_LISAP_CB,
                                        CMPFTHA_UPDTYPE_SYNC,
                                        CMPFTHA_ACTN_MOD,
                                        (Void *)s);
#endif /* ZJ */
                     }
                  }
               }               
               break;
               
            default:
               cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
               break;
         }
         break;
         
      case SHT_REQTYPE_UBND_DIS:  /* system agent control unbind disable */
#ifdef MA_RUG
         /* Delete the stored version information for that SAP *
          * Loop in the stored version information store and   *
          * delete all version information entries to the dest */ 
         for(i = maCb.maNumIntfInfo -1; i >= 0; i--)
         {
            if(maCb.maIntfInfo[i].grpType == reqInfo->s.ubndDis.grpType)
            {
               switch(maCb.maIntfInfo[i].grpType)
               {
                  case SHT_GRPTYPE_ALL:
                     if(maCb.maIntfInfo[i].dstProcId == 
                                    reqInfo->s.ubndDis.dstProcId &&
                        maCb.maIntfInfo[i].dstEnt.ent == 
                                    reqInfo->s.ubndDis.dstEnt.ent &&
                        maCb.maIntfInfo[i].dstEnt.inst == 
                                    reqInfo->s.ubndDis.dstEnt.inst)
                     {
#ifdef ZJ
                        /* Delete The interface version at standby */
                        cmTuRunTimeUpd(&zjCb.tuCb, CMTU_VERINFO_CB, 
                                       CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_DEL,
                                       (Void *)&maCb.maIntfInfo[i]);
#endif /* ZJ */
                        /* delete the version information by*
                         * copying the last version infor   *
                         * into current location            */
                        cmMemcpy((U8 *)&(maCb.maIntfInfo[i]), 
                                 (U8 *)&(maCb.maIntfInfo[maCb.maNumIntfInfo-1]),
                                              sizeof(ShtVerInfo)); 
                        maCb.maNumIntfInfo--;
                     }
                     break;
                             
                  case SHT_GRPTYPE_ENT:
                     if(maCb.maIntfInfo[i].dstEnt.ent ==
                                    reqInfo->s.ubndDis.dstEnt.ent &&
                        maCb.maIntfInfo[i].dstEnt.inst == 
                                    reqInfo->s.ubndDis.dstEnt.inst)
                     {
#ifdef ZJ
                        /* Delete The interface version at standby */
                        cmTuRunTimeUpd(&zjCb.tuCb, CMTU_VERINFO_CB, 
                                       CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_DEL,
                                       (Void *)&maCb.maIntfInfo[i]);
#endif /* ZJ */
                        /* delete the version information by*
                         * copying the last version infor   *
                         * into current location            */
                        cmMemcpy((U8 *)&(maCb.maIntfInfo[i]), 
                                 (U8 *)&(maCb.maIntfInfo[maCb.maNumIntfInfo-1]),
                                              sizeof(ShtVerInfo));
                        maCb.maNumIntfInfo--;
                     }
                     break;
               } /* switch */ 
            } /* if */
         } /* for */
#endif /* MA_RUG */

         switch (reqInfo->s.ubndDis.grpType)
         {
            case SHT_GRPTYPE_ALL:
               /* go through all the sap control blocks and start unbind *
                * disable procedure on those SAPs for which              *
                * (pst->dstProcId == reqInfo->s.ubndDis.dstProcId) && *
                * (pst->dstEnt == reqInfo->s.ubndDis.dstEnt) &&       *
                * (pst->dstInst == reqInfo->s.ubndDis.dstInst)        */
               
               /* call function for all service user SAPs */
               for (i = 0; i < (S32)maCb.maCP.nmbMAUSaps; i++)
               {
                  if ((s = *(maCb.maSapLmaPtr + (SuId)i)) != NULLP)
                  {
                     if ((s->maPstMU.dstProcId == reqInfo->s.ubndDis.dstProcId) &&
                         (s->maPstMU.dstEnt == reqInfo->s.ubndDis.dstEnt.ent) &&
                         (s->maPstMU.dstInst == reqInfo->s.ubndDis.dstEnt.inst))
                     {
                        (Void) maDisableSuSap(s);
#ifdef MA_RUG
                        s->remIntfValidMU = FALSE;
#endif /* MA_RUG */
#ifdef ZJ
                        cmTuRunTimeUpd(&zjCb.tuCb, CMTU_UISAP_CB, 
                                       CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD, 
                                       (Void *)s);
#endif /* ZJ */

                     }
                  }
               } /* end for */                
               /* call function for all service provider SAPs */               
               for (i = 0; i < (S32)maCb.maCP.nmbMAUSaps; i++)
               {
                  if ((s = *(maCb.maSapLmaPtr + (SuId)i)) != NULLP)
                  {
                     if ((s->maPstST.dstProcId == reqInfo->s.ubndDis.dstProcId) &&
                         (s->maPstST.dstEnt == reqInfo->s.ubndDis.dstEnt.ent) &&
                         (s->maPstST.dstInst == reqInfo->s.ubndDis.dstEnt.inst))
                     {
                        (Void) maDisableSpSap(s);
#ifdef MA_RUG
                        s->remIntfValidST = FALSE;
#endif /* MA_RUG */
#ifdef ZJ
                        cmTuRunTimeUpd(&zjCb.tuCb, CMTU_LISAP_CB, 
                                       CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD, 
                                      (Void *)s);
#endif /* ZJ */
                     }
                  }
               } /* end for */                
        
               break;
               
            case SHT_GRPTYPE_ENT:
               /* go through all the sap control blocks and start unbind *
                * disable procedure on those SAPs for which              *
                * (pst->dstEnt == reqInfo->s.ubndDis.dstEnt) &&       *
                * (pst->dstInst == reqInfo-.s.ubndDis.dstInst)        */
               
               /* call function for all service user SAPs */
               for (i = 0; i < (S32)maCb.maCP.nmbMAUSaps; i++)
               {
                  if ((s = *(maCb.maSapLmaPtr + (SuId)i)) != NULLP)
                  {
                     if ((s->maPstMU.dstEnt == reqInfo->s.ubndDis.dstEnt.ent) &&
                         (s->maPstMU.dstInst == reqInfo->s.ubndDis.dstEnt.inst))
                     {
                        (Void) maDisableSuSap(s);
#ifdef MA_RUG
                        s->remIntfValidMU = FALSE;
#endif /* MA_RUG */
#ifdef ZJ
                        cmTuRunTimeUpd(&zjCb.tuCb, CMTU_UISAP_CB, 
                                       CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD, 
                                       (Void *)s);
#endif /* ZJ */
                     }
                  }
               } /* end for */                
               /* call function for all service provider SAPs */       
               for (i = 0; i < (S32)maCb.maCP.nmbMAUSaps; i++)
               {
                  if ((s = *(maCb.maSapLmaPtr + (SuId)i)) != NULLP)
                  {
                     if ((s->maPstST.dstEnt == reqInfo->s.ubndDis.dstEnt.ent) &&
                         (s->maPstST.dstInst == reqInfo->s.ubndDis.dstEnt.inst))
                     {
                        (Void) maDisableSpSap(s);
#ifdef MA_RUG
                        s->remIntfValidST = FALSE;
#endif /* MA_RUG */
#ifdef ZJ
                        cmTuRunTimeUpd(&zjCb.tuCb, CMTU_UISAP_CB, 
                                       CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD, 
                                       (Void *)s);
#endif /* ZJ */
                     }
                  }
               } /* end for */                
                     
                break;
 
             default:
                cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
                break;
           }
           break;

#ifdef MA_RUG
       case SHT_REQTYPE_GETVER:   /* system agent control Get Version */
          maGetVer(&cfmInfo.t.gvCfm);
          break;
   
       case SHT_REQTYPE_SETVER:  /* system agent control Set Version */
          maSetVer(&reqInfo->s.svReq, &cfmInfo.status); 
#ifdef ZJ
          /* Send The interface version to standby/shadows  */
          if(cfmInfo.status.reason == LCM_REASON_NOT_APPL)
          {
             cmTuRunTimeUpd(&zjCb.tuCb, CMTU_VERINFO_CB, CMPFTHA_UPDTYPE_SYNC, 
                            CMPFTHA_ACTN_MOD, (Void *)&reqInfo->s.svReq);
          }                             
#endif /* ZJ */

          break; 
#endif /* MA_RUG */

       default:
          cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
          break;
    }

    /* response is sent without waiting for bind or unbind to complete */
    /* if we are not able to find any SAP to start bind enable or unbind
       disable, still a sucess response is returned by the protocol layer */

    if (cfmInfo.status.reason != LCM_REASON_NOT_APPL)
       cfmInfo.status.status = LCM_PRIM_NOK;
    else
       cfmInfo.status.status = LCM_PRIM_OK;

#ifdef ZJ
    cmTuUpdPeer(&zjCb.tuCb);
#endif /* ZJ */

#ifdef MA_RUG
    /* Fill in request type */
    cfmInfo.reqType = reqInfo->reqType;
#endif /* MA_RUG */

    /* send the response */
    MaMiShtCntrlCfm(&repPst, &cfmInfo);
       
    RETVALUE(ROK);
} /* end MaMiShtCntrlReq */
#endif /* MA_FTHA */

/*
*
*       Fun:   MAP User Open Request
*
*       Desc:  This function handles the MAP Open request from the MAP User 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaUiMatOpenReq
(
Pst              *pst,           /* Post Structure */
SpId             spId,           /* Service provider Id */
MaDlgId          suDlgId,        /* Service user Dlg Id */
MaDlgId          spDlgId,        /* Service provider Dlg Id */
MaOpenEv         *openEv         /* MAP-OPEN event */
)
#else
PUBLIC S16 MaUiMatOpenReq (pst, spId, suDlgId, spDlgId, openEv)
Pst              *pst;           /* Post Structure */
SpId             spId;           /* Service provider Id */
MaDlgId          suDlgId;        /* Service user Dlg Id */
MaDlgId          spDlgId;        /* Service provider Dlg Id */
MaOpenEv         *openEv;        /* MAP-OPEN event */
#endif
{
   MaSap   *s;        /* MAP sap */
   MaDlgCp *dlgCp;    /* dialog control point */
   S16     ret;       /* Return value */
   U32     i;
   MaInvokeId invkId;
#if MAP_REL99
#if (MAP_SEC && LMAV2)
   MaSaCp  *saCp;
#endif
#endif
   
   TRC3(MaUiMatOpenReq)
   
#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Entered MaUiMatOpenReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA391, 0," MaUiMatOpenReq () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif

   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (openEv);

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatOpenReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), openEv(0x%lx))\n"
   , spId, suDlgId, spDlgId, (PTR) openEv));

#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatOpenReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), openEv(0x%lx))\n"
   , spId, suDlgId, spDlgId, (PTR) openEv));

#endif /* ALIGN_64BIT */  
   /* If not active then don't accept the open request */
#ifdef ZJ
   if (!cmTuChkRsetStatus(&zjCb.tuCb, FALSE))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_INT_PAR, EMA051, (ErrVal)0, 
                "MaUiMatOpenReq(): Invalid PSF state.");
#endif

      maSendAlrm(NEW,spId, MA_UNUSED, MA_UNUSED, "MaUiMatOpenReq",
                 LCM_EVENT_UI_INV_EVT, LCM_CATEGORY_INTERFACE,
                 LCM_CAUSE_PROT_NOT_ACTIVE);

#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenReq(spId(%d), spDlgId (%ld))failed, Invalid PSF state.\n", 
      spId, spDlgId));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenReq(spId(%d), spDlgId (%d))failed, Invalid PSF state.\n", 
      spId, spDlgId));


#endif /* ALIGN_64BIT */ 
      RETVALUE(RFAILED);
   }

   /* check if recovery is going on */
   if (zjCb.tuCb.rsetCbLst[CMFTHA_RES_RSETID]->recovery)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatOpenReq",
                 LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_PROTOCOL,
                 LCM_CAUSE_DLGFAIL_DUETO_RECOVERY);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld),\
      openEv(0x%lx))failed, PSF in recovery state(%d).\n",
      spId, suDlgId, spDlgId, (PTR) openEv, spId));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenReq(pst, spId(%d), suDlgId(%d), spDlgId(%d),\
      openEv(0x%lx))failed, PSF in recovery state(%d).\n",
      spId, suDlgId, spDlgId, (PTR) openEv, spId));

#endif /* ALIGN_64BIT */
      RETVALUE(RFAILED);
   }
#endif /* ZJ */

   if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
       ((s = *(maCb.maSapLmaPtr + spId)) == NULLP))
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatOpenReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
      
#ifndef ALIGN_64BIT            

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld),\
      openEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, (PTR) openEv, spId));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenReq(pst, spId(%d), suDlgId(%d), spDlgId(%d),\
      openEv(0x%lx))failed, invalid spId(%d).\n",
      spId, suDlgId, spDlgId, (PTR) openEv, spId));

#endif /* ALIGN_64BIT */  

      RETVALUE(RFAILED);
   }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatOpenReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
      
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld),\
      openEv(0x%lx))failed, invalid SAP state(%d).\n",
      spId, suDlgId, spDlgId, (PTR) openEv, s->maState));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenReq(pst, spId(%d), suDlgId(%d), spDlgId(%d),\
      openEv(0x%lx))failed, invalid SAP state(%d).\n",
      spId, suDlgId, spDlgId, (PTR) openEv, s->maState));

#endif /* ALIGN_64BIT */

      RETVALUE(RFAILED);
   }

   if (s->nmbActvDlg >= s->cfg.maxDlg)
   {
      /* Send the Notice indication to the MAP user that dialogue not exist */
      MaUiMatNotInd(&s->maPstMU, s->suId, suDlgId, 0, MAT_DLG_NOT_EXIST);
      
#ifndef ALIGN_64BIT  

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld),\
      openEv(0x%lx))failed, active dialogue reach up limit(%ld).\n",
      spId, suDlgId, spDlgId, (PTR) openEv, s->nmbActvDlg));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenReq(pst, spId(%d), suDlgId(%d), spDlgId(%d),\
      openEv(0x%lx))failed, active dialogue reach up limit(%d).\n",
      spId, suDlgId, spDlgId, (PTR) openEv, s->nmbActvDlg));

#endif /* ALIGN_64BIT */
      RETVALUE(RFAILED);
   }
 
   s->nmbActvDlg++;

   /* allocate a new spDlgId, check if we need to use a bit map */

   if (s->bitMap.map == NULLP)
   {
      /* use hash list to allocate dlgId */
      s->maDlgIdPool = maGetDlgId(s);
   }
   else
   {
      /* use a bit map to allocate dlgId */
      s->maDlgIdPool = maAllocDlgId(s);
   }

   /* check to see if the dialogue id is allocated */
   if (s->maDlgIdPool == 0)
   {
      /* dialogue allocation failed, point the start of the next serach */
      /* for a free dialogue id to the start of the bit map             */

      s->maDlgIdPool = s->cfg.stDlgId;

      s->nmbActvDlg--;

      /* Notice indication to the MAP user that dialogue id not exist */
      MaUiMatNotInd(&s->maPstMU, s->suId, suDlgId, 0, MAT_DLG_NOT_EXIST);
      
#ifndef ALIGN_64BIT  

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld),\
      openEv(0x%lx))failed, can not allocate dialogue ID.\n",
      spId, suDlgId, spDlgId, (PTR) openEv));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenReq(pst, spId(%d), suDlgId(%d), spDlgId(%d),\
      openEv(0x%lx))failed, can not allocate dialogue ID.\n",
      spId, suDlgId, spDlgId, (PTR) openEv));

#endif /* ALIGN_64BIT */
      RETVALUE(RFAILED);      
   }

   /* Create a new MAP dialogue Control point */
   dlgCp = maInsHashDlg(s, s->maDlgIdPool, suDlgId);

   if (dlgCp == (MaDlgCp *)NULLP)
   {
      maSendAlrm(NEW,s->sapId, STMATSAP, LMAT_OUT_OF_RSRS, "MaUiMatOpenReq",
                 LMA_EVENT_DLGCB_ALLOC_FAIL,LCM_CATEGORY_RESOURCE,
                 LCM_CAUSE_INV_PAR_VAL);
      s->nmbActvDlg--;
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld),\
      openEv(0x%lx))failed, resource unavailable.\n",
      spId, suDlgId, spDlgId, (PTR) openEv));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenReq(pst, spId(%d), suDlgId(%d), spDlgId(%d),\
      openEv(0x%lx))failed, resource unavailable.\n",
      spId, suDlgId, spDlgId, (PTR) openEv));

#endif /* ALIGN_64BIT */   

      RETVALUE(RFAILED);
   }
   dlgCp->suDlgId = suDlgId;
   dlgCp->spDlgId = s->maDlgIdPool;
   
   /* Store the Application context name and destination and source reference 
    * in dialogue control point
    */

   if (openEv->apn.pres == TRUE)
   {
      cmCopy((U8 *)&openEv->apn, (U8 *)&dlgCp->apn, sizeof (MaApConName));
   }
   else
   {
      maBZero((U8 *)openEv, (S16)sizeof (MaOpenEv));
      openEv->result = MAT_DLG_REFUSED;
      openEv->refReason.pres = TRUE;
      openEv->refReason.val = MAT_BAD_OPENREQ;
      maDlgIdle(s);
      MaUiMatOpenCfm(&s->maPstMU, s->suId, suDlgId, spDlgId, openEv);
      
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
             "MaUiMatOpenReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld),\
             openEv(0x%lx))failed, acn missing.\n",
             spId, suDlgId, spDlgId, (PTR) openEv));

#else
 
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
             "MaUiMatOpenReq(pst, spId(%d), suDlgId(%d), spDlgId(%d),\
             openEv(0x%lx))failed, acn missing.\n",
             spId, suDlgId, spDlgId, (PTR) openEv));

#endif /* ALIGN_64BIT */
      RETVALUE(RFAILED);
   }
   if (openEv->srcRef.pres == TRUE)
   {
      cmCopy((U8 *)&openEv->srcRef, (U8 *)&dlgCp->srcRef, sizeof (MaSrcRef));
   }
   if (openEv->destRef.pres == TRUE)
   {
      cmCopy((U8 *)&openEv->destRef,(U8 *)&dlgCp->destRef,sizeof (MaDestRef));
   }

   if (openEv->usrInfo.pres == TRUE)  
   {
      if ((openEv->usrInfo.len <= MF_SIZE_TKNSTRS) && 
          (dlgCp->apn.val[dlgCp->apn.len -1] > LMA_VER1))
      {
         cmCopy((U8 *)&openEv->usrInfo, (U8 *)&dlgCp->usrInfo, 
                sizeof (MaUsrInfo));
      }
      else
      {
         invkId.pres = FALSE;
         maDlgIdle(s);
         MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId,&invkId, 
                        MAT_EVTOPENREQ,(Status)MAT_BAD_USR_PARAM);
         
#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf, 
                "MaUiMatOpenReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
                openEv(0x%lx))failed,invalid usrInfo.\n", 
                spId, suDlgId, spDlgId, (PTR) openEv));

#else
 
         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf, 
                "MaUiMatOpenReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
                openEv(0x%lx))failed,invalid usrInfo.\n", 
                spId, suDlgId, spDlgId, (PTR) openEv));

#endif /* ALIGN_64BIT */

         RETVALUE(RFAILED);
      }
   }
   if (openEv->extCont.priExtLst[0].pres == TRUE)  
   {
      for ( i = 0; i < MA_MAX_NMB_PRI_EXT; i++)
      {
         if (openEv->extCont.priExtLst[i].pres == TRUE)
         {
            if ((openEv->extCont.priExtLst[i].len <= MF_SIZE_TKNSTRE)&&
                (dlgCp->apn.val[dlgCp->apn.len-1] > LMA_VER2))
            {
               cmCopy((U8 *)&openEv->extCont.priExtLst[i],
                      (U8 *)&dlgCp->extCont.priExtLst[i], sizeof (TknStrE));
            }
            else
            {
               invkId.pres = FALSE;
               maDlgIdle(s);
               MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, &invkId, 
                              MAT_EVTOPENREQ,(Status)MAT_BAD_USR_PARAM);
               
#ifndef ALIGN_64BIT

               MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                      "MaUiMatOpenReq(pst, spId(%d), suDlgId(%ld), \
                      spDlgId(%ld),openEv(0x%lx))failed, invalid extCont.\n",
                      spId, suDlgId, spDlgId, (PTR) openEv));

#else

               MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                      "MaUiMatOpenReq(pst, spId(%d), suDlgId(%d), \
                      spDlgId(%d),openEv(0x%lx))failed, invalid extCont.\n",
                      spId, suDlgId, spDlgId, (PTR) openEv));

#endif /* ALIGN_64BIT */

               RETVALUE(RFAILED);
            }
         }
      }
   }

   /* Copy src and destination address */
   s->curDlgCp = dlgCp;
   cmCopySpAddr(&openEv->destAddr, &dlgCp->destAddr);
   cmCopySpAddr(&openEv->srcAddr, &dlgCp->srcAddr);

#ifdef MATV3
   dlgCp->maPrior.pres = FALSE;
   if ((openEv->maPrior.pres == TRUE) && (openEv->maPrior.val <= MA_PRI3))
   {
      cmCopy((U8 *)&openEv->maPrior,(U8 *)&dlgCp->maPrior, sizeof(TknU8));
   }
   dlgCp->pClass.pres = FALSE;
   if ((openEv->pClass.pres == TRUE) && (openEv->pClass.val <= PCLASS1))
   {
      cmCopy((U8 *)&openEv->pClass,(U8 *)&dlgCp->pClass, sizeof(TknU8));
   }
#endif

#if (MATV2 && STUV2)
   if (openEv->imp.pres == TRUE)
   {
      dlgCp->imp.pres = TRUE;
      dlgCp->imp.val = openEv->imp.val;
   }
   else
   {
      dlgCp->imp.pres = FALSE;
   }
#endif

#if MAP_REL99
#if (MAP_SEC && LMAV2)
/* ma012.203: Added to support Security feature as configurable */
#ifdef MAP_SEC_RECFG
   if ((dlgCp->apn.val[dlgCp->apn.len-1] > LMA_VER1) &&
        (maCb.maCP.secGenCfg.mapSecFlg == TRUE))
#else
   if (dlgCp->apn.val[dlgCp->apn.len-1] > LMA_VER1)
#endif /* MAP_SEC_RECFG */
   {
      if ((openEv->plmnId.mcc.pres == TRUE) && 
          (openEv->plmnId.mnc.pres == TRUE))
      {
         /* Plmn id is mandatory parameter, even for intra-domain case */
         cmCopy((U8 *)&openEv->plmnId,(U8 *)&dlgCp->peerId, sizeof(LmaPlmnId));
      }
      else
      {
         /* Plmn id is optional for intra-domain case */
         cmCopy((U8 *)&maCb.maCP.secGenCfg.plmnId,(U8 *)&dlgCp->peerId, 
                sizeof(LmaPlmnId));
      }
      cmCopy((U8 *)&maCb.maCP.secGenCfg.plmnId,(U8 *)&dlgCp->selfId, 
             sizeof(LmaPlmnId));

      saCp = maFindSa(dlgCp->peerId.mcc.val, dlgCp->peerId.mnc.val);
      if (saCp == NULLP)
      {
         if (maCb.maCP.secGenCfg.secPlmnsOnly == TRUE)
         {
            /* SA can not be found, only configured PLMN is allowed. */
            maSendAlrm(NEW,s->sapId, STMATSAP, LMA_BAD_PLMN_PARAM, 
                       "MaUiMatOpenReq", LMA_EVENT_MAPSEC_INITIATOR,
                       LCM_CATEGORY_INTERFACE, LMA_CAUSE_INV_DST_PLMN);
            invkId.pres = FALSE;
            maDlgIdle(s);
            MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, &invkId, 
                           MAT_EVTOPENREQ,(Status)MAT_BAD_DST_PLMNID);
            /* removed the call code that decremented nmbActvDlg twice*/
            s->secSts.nmbInvDstPlmn++;
            
#ifndef ALIGN_64BIT

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatOpenReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld),\
                   openEv(0x%lx))failed, invalid GT len.\n",
                   spId, suDlgId, spDlgId, (PTR) openEv));

#else

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatOpenReq(pst, spId(%d), suDlgId(%d), spDlgId(%d),\
                   openEv(0x%lx))failed, invalid GT len.\n",
                   spId, suDlgId, spDlgId, (PTR) openEv));

#endif /* ALIGN_64BIT */

            RETVALUE(RFAILED);
         }
         else
         {
            /* SA can not be found, normal communication is used if allowed. */
            dlgCp->mapSec = FALSE;
         }
      }
      else
      {
         if (saCp->softExp == TRUE)
         {
            /* SA expired */
            maSendAlrm(NEW,s->sapId, STMATSAP, LMA_BAD_PLMN_PARAM, 
                       "MaUiMatOpenReq", LMA_EVENT_MAPSEC_INITIATOR,
                       LCM_CATEGORY_INTERFACE, LMA_CAUSE_SA_EXPIRED);
            invkId.pres = FALSE;
            maDlgIdle(s);
            MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, &invkId, 
                           MAT_EVTOPENREQ,(Status)MAT_SA_EXPIRED);
            /*removed the call code that decremented nmbActvDlg twice */
            s->secSts.nmbInvDstPlmn++;
            
#ifndef ALIGN_64BIT

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatOpenReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld),\
                   openEv(0x%lx))failed, security association expired.\n",
                   spId, suDlgId, spDlgId, (PTR) openEv));

#else

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                   "MaUiMatOpenReq(pst, spId(%d), suDlgId(%d), spDlgId(%d),\
                   openEv(0x%lx))failed, security association expired.\n",
                   spId, suDlgId, spDlgId, (PTR) openEv));

#endif  /* ALIGN_64BIT */

            RETVALUE(RFAILED);
         }
         /* check if secure transport required */
         if ((saCp->sa.mapSec == TRUE) && (maIsSecReq(saCp,dlgCp) == TRUE))
         {
            /* insert this dlgCp into the head of linked list */
            maInsSaDlg(dlgCp, saCp);
            dlgCp->saCp = saCp;
            dlgCp->mapSec = TRUE;
            s->secSts.secSapSts.openReqTx++;
         }
         else
         {
            dlgCp->mapSec = FALSE;
         }
      }
   }
   else
   {
      /* secure transport is not supported for version 1 */
      dlgCp->mapSec = FALSE;
   }
#endif /* MAP_SEC */
#endif

#ifdef ZJ
   if (zjCb.tuCb.genCfg.updAllDlg == TRUE)
   {
      dlgCp->upd = TRUE;
   }
   else
   {
      if (maIsUpdReq(s, dlgCp) == TRUE)
      {
         dlgCp->upd = TRUE;
         cmTuAddMapping (&zjCb.tuCb, (PTR)dlgCp);
      }
   }
#endif

   if ( (ret = ( *maDSMTbl[MA_EV_OPEN_REQ][dlgCp->dsmState])(s)) != ROK)
   {
      maBZero((U8 *)openEv, (S16)sizeof (MaOpenEv));
      openEv->result = MAT_DLG_REFUSED;
      openEv->refReason.pres = TRUE;
      openEv->refReason.val = MAT_BAD_OPENREQ;
       maDlgIdle(s);
      MaUiMatOpenCfm(&s->maPstMU, s->suId, suDlgId, spDlgId, openEv);
      
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld),\
      openEv(0x%lx))failed, bad open request.\n",
      spId, suDlgId, spDlgId, (PTR) openEv));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenReq(pst, spId(%d), suDlgId(%d), spDlgId(%d),\
      openEv(0x%lx))failed, bad open request.\n",
      spId, suDlgId, spDlgId, (PTR) openEv));

#endif /* ALIGN_64BIT */
      RETVALUE(RFAILED);
   }
#if MAP_REL99
#if (MAP_SEC && LMAV2)
   if (dlgCp->mapSec == FALSE)
#endif
#endif
   s->sts.openReqTx++;
#ifdef ZJ
   MA_UPD_PEER(dlgCp->upd)
#endif /* ZJ */
   MaUiMatDlgCfm(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId);

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Leaving MaUiMatOpenReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif
   RETVALUE (ROK);

} /* end of MaUiMatOpenReq */


/*
*
*       Fun:   MAP User Open Response
*
*       Desc:  This function handles the MAP Open response from the MAP User 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaUiMatOpenRsp
(
Pst              *pst,           /* Post Structure */
SpId             spId,           /* Service provider Id */
MaDlgId          suDlgId,      /* Service user Dlg Id */
MaDlgId          spDlgId,        /* Service provider Dlg Id */
MaOpenEv         *openEv       /* MAP-OPEN event */
)
#else
PUBLIC S16 MaUiMatOpenRsp (pst, spId, suDlgId, spDlgId, openEv)
Pst              *pst;           /* Post Structure */
SpId             spId;           /* Service provider Id */
MaDlgId          suDlgId;      /* Service user Dlg Id */
MaDlgId          spDlgId;        /* Service provider Dlg Id */
MaOpenEv         *openEv;      /* MAP-OPEN event */
#endif
{
   MaSap   *s;        /* MAP sap */
   MaDlgCp *dlgCp;    /* dialog control point */
   MaInvokeId invkId;
   S16     ret;       /* Return value */
   U32     i;
#if MAP_REL99
#if (MAP_SEC && LMAV2)
   Bool    mapSec;
#endif
#endif
#ifdef STUV2
   StDataParam    dataParam;
#endif
#ifdef ZJ
   Bool rtUpd;
#endif
 
   TRC3(MaUiMatOpenRsp)

/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP ))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA392, 0," MaUiMatOpenRsp () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }
   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif
   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (openEv);

/* ma001.203 : Addition. Initialized dataParam */       
#ifdef STUV2
   cmZero((Data *) &dataParam, sizeof(StDataParam));
#endif
   
#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatOpenRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), openEv(0x%lx))\n", 
                       spId, suDlgId, spDlgId, (PTR) openEv));


#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatOpenRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d), openEv(0x%lx))\n", 
                       spId, suDlgId, spDlgId, (PTR) openEv));


#endif /* ALIGN_64BIT */
   /* If not active then don't accept the open request */
#ifdef ZJ

   if (!cmTuChkRsetStatus(&zjCb.tuCb, FALSE))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_INT_PAR, EMA052, (ErrVal)0, 
                "MaUiMatOpenRsp(): Invalid PSF state.");
#endif

      maSendAlrm(NEW,spId, MA_UNUSED, MA_UNUSED, "MaUiMatOpenRsp",
                 LCM_EVENT_UI_INV_EVT, LCM_CATEGORY_INTERFACE,
                 LCM_CAUSE_PROT_NOT_ACTIVE);

#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenRsp(spId(%d), spDlgId (%ld))failed, Invalid PSF state.\n", 
      spId, spDlgId));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenRsp(spId(%d), spDlgId (%d))failed, Invalid PSF state.\n", 
      spId, spDlgId));

#endif /* ALIGN_64BIT */

      RETVALUE(RFAILED);
   }
#endif /* ZJ */

   if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
       ((s = *(maCb.maSapLmaPtr + spId)) == NULLP))
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatOpenRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
      
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld),\
      openEv(0x%lx))failed, invalid spId(%d)\n",
      spId, suDlgId, spDlgId, (PTR) openEv, spId));
      
      #else
 
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d),\
      openEv(0x%lx))failed, invalid spId(%d)\n",
      spId, suDlgId, spDlgId, (PTR) openEv, spId));
     
#endif /* ALIGN_64BIT */  
      RETVALUE(RFAILED);
   }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatOpenRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
      
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld),\
      openEv(0x%lx))failed, invalid SAP state(%d)\n",
      spId, suDlgId, spDlgId, (PTR) openEv, s->maState));
      
#else
 
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d),\
      openEv(0x%lx))failed, invalid SAP state(%d)\n",
      spId, suDlgId, spDlgId, (PTR) openEv, s->maState));

#endif /* ALIGN_64BIT */

      RETVALUE(RFAILED);
   }

   dlgCp = maFindHashDlg(s, spDlgId);

   if (dlgCp == (MaDlgCp *)NULLP)
   {
      invkId.pres = FALSE;
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, &invkId, MAT_EVTOPENRSP, 
                     (Status)MAT_BAD_SPDLGID);
      
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld),\
      openEv(0x%lx))failed, invalid dialogue Id(%ld)\n",\
      spId, suDlgId, spDlgId, (PTR) openEv, spDlgId));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d),\
      openEv(0x%lx))failed, invalid dialogue Id(%d)\n",\
      spId, suDlgId, spDlgId, (PTR) openEv, spDlgId));

#endif /* ALIGN_64BIT */
      RETVALUE(RFAILED);
   }
#ifdef ZJ
   rtUpd = dlgCp->upd;
#endif
   /* check cmpPresFlg and dsmState, store early OK open
    * response when dsmState in idle or cmpPresFlg is TRUE
    */
   if ((dlgCp->cmpPresFlg == TRUE) || (dlgCp->dsmState == MA_DLG_IDLE)) 
   {
      /*Processing immediately following OpenRsp*/ 
      if (dlgCp->openRspRcvd.pres != TRUE) 
      {
         if (openEv->result == MA_DLG_OK) 
         {
            /* First OK OpenRsp from user and store OpenRspRcvd*/ 
            if ((openEv->usrInfo.pres == TRUE) &&
                ((openEv->usrInfo.len > MF_SIZE_TKNSTRS) ||
                 (dlgCp->apn.val[dlgCp->apn.len -1] == LMA_VER1))) 
            {
#ifdef ZJ
               MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
               MA_UPD_PEER(rtUpd)
#endif /* ZJ */
               invkId.pres = FALSE;
                maDlgIdle(s);
               MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId,&invkId, 
                              MAT_EVTOPENRSP,(Status)MAT_BAD_USR_PARAM);
               MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf, 
                      "MaUiMatOpenRsp() failed, invalid usrInfo.\n"));
               RETVALUE(RFAILED);
            }
            if (openEv->extCont.priExtLst[0].pres == TRUE)
            {
               for ( i = 0; i < MA_MAX_NMB_PRI_EXT; i++)
               {
                  if ((openEv->extCont.priExtLst[i].pres == TRUE) &&
                      ((dlgCp->apn.val[dlgCp->apn.len -1] <= LMA_VER2)||
                       (openEv->extCont.priExtLst[i].len > MF_SIZE_TKNSTRE)))
                  {
#ifdef ZJ
                     MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
                     MA_UPD_PEER(rtUpd)
#endif /* ZJ */
                     invkId.pres = FALSE;
                     maDlgIdle(s); 
                     MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId,&invkId, 
                                    MAT_EVTOPENRSP,(Status)MAT_BAD_USR_PARAM);
                     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf, 
                            "MaUiMatOpenRsp() failed, invalid extCont.\n"));
                     RETVALUE(RFAILED);
                  }
               }
            }
            maStoreOpenRsp(s, suDlgId, dlgCp, openEv);
            RETVALUE(ROK);
         }
         /* Negative OpenRsp will get processed */
      }
      else
      {
          /* Only first  OpenRsp is honored, following OpenRsp should
           * be ignored. 
           */
           RETVALUE(ROK);
      }
   }

#if MAP_REL99
#if (MAP_SEC && LMAV2)
   mapSec = dlgCp->mapSec;
#endif
#endif
   s->curDlgCp = dlgCp;
   /* update the service user dialogue Id */
   dlgCp->suDlgId = suDlgId;
   s->evtPtr = (U8 *)openEv;
   if(openEv->rspAddr.pres == TRUE)
   {
      /* copy the response address to the source address of the dialogue */
      cmCopySpAddr(&openEv->rspAddr,&dlgCp->srcAddr);
   }

   if (openEv->usrInfo.pres == TRUE) 
   {
      if ((openEv->usrInfo.len <= MF_SIZE_TKNSTRS) &&
          (dlgCp->apn.val[dlgCp->apn.len -1] > LMA_VER1))
      {
         cmCopy((U8 *)&openEv->usrInfo, (U8 *)&dlgCp->usrInfo,
                sizeof (MaUsrInfo));
      }
      else
      {
#ifdef ZJ
         MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
         MA_UPD_PEER(rtUpd)
#endif /* ZJ */
         invkId.pres = FALSE;
         maDlgIdle(s);
         MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, &invkId,
                        MAT_EVTOPENRSP, (Status)MAT_BAD_USR_PARAM);
         
#ifndef ALIGN_64BIT

         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                "MaUiMatOpenRsp(pst, spId(%d), suDlgId(%ld), \
                spDlgId(%ld),openEv(0x%lx))failed, invalid extCont\n",
                spId, suDlgId, spDlgId, (PTR) openEv));
         
#else
  
         MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                "MaUiMatOpenRsp(pst, spId(%d), suDlgId(%d), \
                spDlgId(%d),openEv(0x%lx))failed, invalid extCont\n",
                spId, suDlgId, spDlgId, (PTR) openEv));

#endif /* ALIGN_64BIT */
         RETVALUE(RFAILED);
      }
   }

   if (openEv->extCont.priExtLst[0].pres == TRUE)  
   {
      for ( i = 0; i < MA_MAX_NMB_PRI_EXT; i++)
      {
         if (openEv->extCont.priExtLst[i].pres == TRUE)
         {
            if ((openEv->extCont.priExtLst[i].len <= MF_SIZE_TKNSTRE) &&
                 (dlgCp->apn.val[dlgCp->apn.len-1] > LMA_VER2))
            {
               cmCopy((U8 *)&openEv->extCont.priExtLst[i],
                      (U8 *)&dlgCp->extCont.priExtLst[i], sizeof (TknStrE));
            }
            else
            {
#ifdef ZJ
               MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
               MA_UPD_PEER(rtUpd)
#endif /* ZJ */
               invkId.pres = FALSE;
               maDlgIdle(s);
               MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, &invkId,
                              MAT_EVTOPENRSP, (Status)MAT_BAD_USR_PARAM);
               
#ifndef ALIGN_64BIT 

               MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                      "MaUiMatOpenRsp(pst, spId(%d), suDlgId(%ld), \
                      spDlgId(%ld),openEv(0x%lx))failed, invalid extCont\n",
                      spId, suDlgId, spDlgId, (PTR) openEv));

#else

               MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
                      "MaUiMatOpenRsp(pst, spId(%d), suDlgId(%d), \
                      spDlgId(%d),openEv(0x%lx))failed, invalid extCont\n",
                      spId, suDlgId, spDlgId, (PTR) openEv));

#endif /* ALIGN_64BIT */
               RETVALUE(RFAILED);
            }
         }
      }
   }

#ifdef MATV3
   dlgCp->maPrior.pres = FALSE;
   if ((openEv->maPrior.pres == TRUE) && (openEv->maPrior.val <= MA_PRI3))
   {
      cmCopy((U8 *)&openEv->maPrior,(U8 *)&dlgCp->maPrior, sizeof(TknU8));
   }
   dlgCp->pClass.pres = FALSE;
   if ((openEv->pClass.pres == TRUE) && (openEv->pClass.val <= PCLASS1))
   {
      cmCopy((U8 *)&openEv->pClass,(U8 *)&dlgCp->pClass, sizeof(TknU8));
   }
#endif

#if (MATV2 && STUV2)
   if(openEv->imp.pres == TRUE)
   {
      dlgCp->imp.pres = TRUE;
      dlgCp->imp.val = openEv->imp.val;
   }
   else
   {
      dlgCp->imp.pres = FALSE;
   }
#endif
   
   /*
   ** User Over load check failed .
   ** So silently clean the dialogue and dont send abort to the 
   ** remote end.
   */
   if(openEv->result == MAT_DLG_OVERLOADED)
   {
      /*
      ** Send the Pre arranged release to the TCAP to release the
      ** dialogue instance in the TCAP .
      */
      StDlgEv rspDlgEv;

      rspDlgEv.pres = FALSE;

#ifdef ZJ
      MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
      MA_UPD_PEER(rtUpd)
#endif /* ZJ */
#ifdef STUV2
      dataParam.imp.pres = FALSE;

      MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_END, dlgCp->spDlgId, 
                 dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                 TRUE, &s->qosSet, &rspDlgEv, &dataParam, NULLP);
#else
      MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_END, dlgCp->spDlgId, 
                 dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                 TRUE, &s->qosSet, &rspDlgEv, NULLP);
#endif /* STUV2 */

      maDlgIdle(s);
      RETVALUE (ROK);
   }
 
   if ( (ret = ( *maDSMTbl[MA_EV_OPEN_RSP][dlgCp->dsmState])(s)) != ROK)
   {
#ifdef ZJ
      MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
      MA_UPD_PEER(rtUpd)
#endif /* ZJ */
      maDlgIdle(s);
      invkId.pres = FALSE;
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, &invkId, MAT_EVTOPENRSP,
                     (Status)MAT_BAD_DLG_STATE);
      
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenRsp(pst, spId(%d), suDlgId(%ld), spDlgId(%ld),\
      openEv(0x%lx))failed, invalid dialogue state(%d)\n",
      spId, suDlgId, spDlgId, (PTR) openEv, dlgCp->dsmState));
      
#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatOpenRsp(pst, spId(%d), suDlgId(%d), spDlgId(%d),\
      openEv(0x%lx))failed, invalid dialogue state(%d)\n",
      spId, suDlgId, spDlgId, (PTR) openEv, dlgCp->dsmState));

#endif /* ALIGN_64BIT */

      RETVALUE(RFAILED);
   }

   /* Increment the Statistics */
#if MAP_REL99
#if (MAP_SEC && LMAV2)
   if (mapSec == FALSE)
#endif
#endif
   s->sts.openRspTx++;

#ifdef ZJ
   MA_UPD_PEER(rtUpd)
#endif /* ZJ */

   RETVALUE (ROK);

} /* end of MaUiMatOpenRsp */

/*
*
*       Fun:   MAP User Delimeter Request
*
*       Desc:  This function handles the MAP Delimeter request from the MAP 
*              User. On getting Delimeter request MAP sends the rqeuest to
*              TCAP to send TC primitive.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaUiMatDelimReq
(
Pst              *pst,           /* Post Structure */
SpId             spId,           /* Service provider Id */
MaDlgId          suDlgId,        /* Service user Dlg Id */
MaDlgId          spDlgId         /* Service provider Dlg Id */
#ifdef MATV2
,MaDelimReqEv    delimReqEv      /* importance level */
#endif
)
#else
#ifdef MATV2
PUBLIC S16 MaUiMatDelimReq( pst, spId, suDlgId, spDlgId, delimReqEv)
#else
PUBLIC S16 MaUiMatDelimReq( pst, spId, suDlgId, spDlgId)
#endif
Pst              *pst;           /* Post Structure */
SpId             spId;           /* Service provider Id */
MaDlgId          suDlgId;        /* Service user Dlg Id */
MaDlgId          spDlgId;        /* Service provider Dlg Id */
#ifdef MATV2
MaDelimReqEv     delimReqEv;     /* importance level */
#endif
#endif
{

   MaSap       *s;          /* MAP sap */
   MaDlgCp     *dlgCp;    /* dialog control point */
   MaInvokeId  invkId;
   S16         ret;
#ifdef ZJ
   Bool        rtUpd;
#endif
 
   TRC3(MaUiMatDelimReq)

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Entered MaUiMatDelimReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA393, 0," MaUiMatDelimReq () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif
   MA_CHK_FOR_NULLP (pst);

   
#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatDelimReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld))\n",
    spId, suDlgId, spDlgId));

#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatDelimReq(pst, spId(%d), suDlgId(%d), spDlgId(%d))\n",
    spId, suDlgId, spDlgId));

#endif /* ALIGN_64BIT */

   /* If not active then don't accept the open request */
#ifdef ZJ
   /* The local variable is required because dlgCp may be dellocated
    * if TCAP abort the dialogue in a tightly coupled system */

   if (!cmTuChkRsetStatus(&zjCb.tuCb, FALSE))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_INT_PAR, EMA053, (ErrVal)0, 
                "MaUiMatDelimReq(): Invalid PSF state.");
#endif

      maSendAlrm(NEW,spId, MA_UNUSED, MA_UNUSED, "MaUiMatDelimReq",
                 LCM_EVENT_UI_INV_EVT, LCM_CATEGORY_INTERFACE,
                 LCM_CAUSE_PROT_NOT_ACTIVE);

#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatDelimReq(spId(%d), spDlgId (%ld))failed, Invalid PSF state.\n", 
      spId, spDlgId));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatDelimReq(spId(%d), spDlgId (%d))failed, Invalid PSF state.\n", 
      spId, spDlgId));

#endif /* ALIGN_64BIT */

      RETVALUE(RFAILED);
   }
#endif /* ZJ */

   if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
       ((s = *(maCb.maSapLmaPtr + spId)) == NULLP))
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatDelimReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
      
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatDelimReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld))failed,\
      invalid spId(%d).\n", spId, suDlgId, spDlgId, spId));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatDelimReq(pst, spId(%d), suDlgId(%d), spDlgId(%d))failed,\
      invalid spId(%d).\n", spId, suDlgId, spDlgId, spId));

#endif /* ALIGN_64BIT */
      RETVALUE(RFAILED);
   }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatDelimReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
      
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatDelimReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld))failed,\
      invalid SAP state(%d).\n", spId, suDlgId, spDlgId, s->maState));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatDelimReq(pst, spId(%d), suDlgId(%d), spDlgId(%d))failed,\
      invalid SAP state(%d).\n", spId, suDlgId, spDlgId, s->maState));
      
#endif /* ALIGN_64BIT */

      RETVALUE(RFAILED);
   }

   /* Get the dialog control point */

   dlgCp = maFindHashDlg(s, spDlgId);
   if (dlgCp == (MaDlgCp *)NULLP)
   {
      invkId.pres = FALSE;
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, &invkId, MAT_EVTDELIMREQ,
                     (Status)MAT_BAD_SPDLGID);
      
#ifndef ALIGN_64BIT 

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatDelimReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld))failed,\
      invalid dialog Id(%ld).\n", spId, suDlgId, spDlgId, spDlgId));
      
#else
  
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatDelimReq(pst, spId(%d), suDlgId(%d), spDlgId(%d))failed,\
      invalid dialog Id(%d).\n", spId, suDlgId, spDlgId, spDlgId));
      
#endif /* ALIGN_64BIT */
      RETVALUE(RFAILED);
   }

   s->curDlgCp = dlgCp;
#ifdef MATV3
   dlgCp->maPrior.pres = FALSE;
   if ((delimReqEv.maPrior.pres == TRUE) && (delimReqEv.maPrior.val <= MA_PRI3))
   {
      cmCopy((U8 *)&delimReqEv.maPrior,(U8 *)&dlgCp->maPrior, sizeof(TknU8));
   }
   dlgCp->pClass.pres = FALSE;
   if ((delimReqEv.pClass.pres == TRUE) && (delimReqEv.pClass.val <= PCLASS1))
   {
      cmCopy((U8 *)&delimReqEv.pClass,(U8 *)&dlgCp->pClass, sizeof(TknU8));
   }
#endif

#if (MATV2 && STUV2)
   if (delimReqEv.imp.pres == TRUE)
   {
      dlgCp->imp.pres = TRUE;
      dlgCp->imp.val = delimReqEv.imp.val;
   }
   else
   {
      dlgCp->imp.pres = FALSE;
   }
#endif

#ifdef ZJ
   rtUpd = dlgCp->upd;
#endif
   if ( (ret = ( *maDSMTbl[MA_EV_DELIM_REQ][dlgCp->dsmState]) (s)) != ROK)
   {
#ifdef ZJ
      MA_UPD_PEER(rtUpd)
#endif /* ZJ */
      invkId.pres = FALSE;
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, &invkId, MAT_EVTDELIMREQ,
                     (Status)MAT_BAD_DLG_STATE);
      
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatDelimReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld))failed,\
      invalid dialog state(%d).\n", spId, suDlgId, spDlgId, dlgCp->dsmState));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatDelimReq(pst, spId(%d), suDlgId(%d), spDlgId(%d))failed,\
      invalid dialog state(%d).\n", spId, suDlgId, spDlgId, dlgCp->dsmState));

#endif /* ALIGN_64BIT */
      RETVALUE(RFAILED);
   }

#ifdef ZJ
   MA_UPD_PEER(rtUpd)
#endif /* ZJ */

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Leaving MaUiMatDelimReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif
   RETVALUE(ROK); 

} /* end of MaUiMatDelimReq */

/*
*
*       Fun:   MaUiMatCloseReq    
*
*       Desc:  This functions handles the MAp dialogue close
*              from its user. 
*
*       Ret:   ROK  
*
*       Notes: None 
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaUiMatCloseReq 
(
Pst              *pst,           /* Post Structure */
SpId             spId,           /* Service provider Id */
MaDlgId          suDlgId,        /* Service user Dlg Id */
MaDlgId          spDlgId,        /* Service provider Dlg Id */
MaCloseEv        *closeEv        /* Close Event structure */ 
)
#else
PUBLIC S16 MaUiMatCloseReq(pst,spId,suDlgId,spDlgId,closeEv)
Pst              *pst;           /* Post Structure */
SpId             spId;           /* Service provider Id */
MaDlgId          suDlgId;        /* Service user Dlg Id */
MaDlgId          spDlgId;        /* Service provider Dlg Id */
MaCloseEv        *closeEv;       /* Close Event structure */ 
#endif
{
   MaSap  *s;
   MaDlgCp *dlgCp;
   MaInvokeId invkId;
   S16     ret;
   U32     i;
#ifdef ZJ
   Bool        rtUpd;
#endif

   TRC3(MaUiMatCloseReq)

/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA394, 0," MaUiMatCloseReq () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif
   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (closeEv);

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatCloseReq(pst,spId(%d),suDlgId(%ld),spDlgId(%ld), closeEv(0x%lx))\n",
    spId, suDlgId, spDlgId, (PTR) closeEv));

#else

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatCloseReq(pst,spId(%d),suDlgId(%d),spDlgId(%d), closeEv(0x%lx))\n",
    spId, suDlgId, spDlgId, (PTR) closeEv));

#endif /* ALIGN_64BIT */

   /* If not active then don't accept the close request */
#ifdef ZJ
   /* The local variable is required because dlgCp may be dellocated
    * if TCAP abort the dialogue in a tightly coupled system */

   if (!cmTuChkRsetStatus(&zjCb.tuCb, FALSE))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_INT_PAR, EMA054, (ErrVal)0, 
                "MaUiMatCloseReq(): Invalid PSF state.");
#endif

      maSendAlrm(NEW,spId, MA_UNUSED, MA_UNUSED, "MaUiMatCloseReq",
                 LCM_EVENT_UI_INV_EVT, LCM_CATEGORY_INTERFACE,
                 LCM_CAUSE_PROT_NOT_ACTIVE);

#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCloseReq(spId(%d), spDlgId (%ld))failed, Invalid PSF state.\n", 
      spId, spDlgId));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCloseReq(spId(%d), spDlgId (%d))failed, Invalid PSF state.\n", 
      spId, spDlgId));

#endif /* ALIGN_64BIT */

      RETVALUE(RFAILED);
   }
#endif /* ZJ */

   if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
       ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatCloseReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCloseReq(pst,spId(%d),suDlgId(%ld),spDlgId(%ld), closeEv(0x%lx))failed,\
      invalid spId(%d)\n",spId, suDlgId, spDlgId, (PTR) closeEv, spId));
      

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCloseReq(pst,spId(%d),suDlgId(%d),spDlgId(%d), closeEv(0x%lx))failed,\
      invalid spId(%d)\n",spId, suDlgId, spDlgId, (PTR) closeEv, spId));

#endif /* ALIGN_64BIT */


      RETVALUE(RFAILED);
   }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatCloseReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
      
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCloseReq(pst,spId(%d),suDlgId(%ld),spDlgId(%ld), closeEv(0x%lx))failed,\
      invalid SAP state(%d)\n",spId, suDlgId, spDlgId, (PTR) closeEv, s->maState));
      
#else
 
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCloseReq(pst,spId(%d),suDlgId(%d),spDlgId(%d), closeEv(0x%lx))failed,\
      invalid SAP state(%d)\n",spId, suDlgId, spDlgId, (PTR) closeEv, s->maState));


#endif /* ALIGN_64BIT */

     RETVALUE(RFAILED);
   }

   /* Get the dialog control point */

   dlgCp = maFindHashDlg(s, spDlgId);
   if (dlgCp == (MaDlgCp *)NULLP)
   {
      RETVALUE(ROK);
   }

#ifdef ZJ
   rtUpd = dlgCp->upd;
#endif

   s->curDlgCp = dlgCp;
   s->evtPtr = (U8 *)closeEv;

   if ((closeEv->usrInfo.pres == TRUE) &&
       ((closeEv->usrInfo.len > MF_SIZE_TKNSTRS)||
        (dlgCp->apn.val[dlgCp->apn.len -1] == LMA_VER1))) 
   {
      invkId.pres = FALSE;
#ifdef ZJ
      MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
      MA_UPD_PEER(rtUpd)
#endif /* ZJ */
      maDlgIdle(s);
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId,&invkId, 
                     MAT_EVTCLOSEREQ,(Status)MAT_BAD_USR_PARAM);
      
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf, 
             "MaUiMatCloseReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
             closeEv(0x%lx))failed,invalid usrInfo.\n", 
             spId, suDlgId, spDlgId, (PTR) closeEv));


#else
 
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf, 
             "MaUiMatCloseReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
             closeEv(0x%lx))failed,invalid usrInfo.\n", 
             spId, suDlgId, spDlgId, (PTR) closeEv));

#endif /* ALIGN_64BIT */
      RETVALUE(RFAILED);
   }

   if (closeEv->extCont.priExtLst[0].pres == TRUE) 
   {
      for ( i = 0; i < MA_MAX_NMB_PRI_EXT; i++)
      {
         if ((closeEv->extCont.priExtLst[i].pres == TRUE) &&
             ((dlgCp->apn.val[dlgCp->apn.len - 1] <= LMA_VER2) ||
              (closeEv->extCont.priExtLst[i].len > MF_SIZE_TKNSTRE )))
         {
            invkId.pres = FALSE;
#ifdef ZJ
            MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
            MA_UPD_PEER(rtUpd)
#endif /* ZJ */
            maDlgIdle(s);
            MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId,&invkId, 
                           MAT_EVTCLOSEREQ,(Status)MAT_BAD_USR_PARAM);
            
#ifndef ALIGN_64BIT 

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf, 
                   "MaUiMatCloseReq(pst, spId(%d), suDlgId(%ld), \
                   spDlgId(%ld), closeEv(0x%lx))failed,invalid ExtCont.\n", 
                   spId, suDlgId, spDlgId, (PTR) closeEv));

#else

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf, 
                   "MaUiMatCloseReq(pst, spId(%d), suDlgId(%d), \
                   spDlgId(%d), closeEv(0x%lx))failed,invalid ExtCont.\n", 
                   spId, suDlgId, spDlgId, (PTR) closeEv));

#endif /* ALIGN_64BIT */
            RETVALUE(RFAILED);
         }
      }
   }

#ifdef MATV3
   dlgCp->maPrior.pres = FALSE;
   if ((closeEv->maPrior.pres == TRUE) && (closeEv->maPrior.val <= MA_PRI3))
   {
      cmCopy((U8 *)&closeEv->maPrior,(U8 *)&dlgCp->maPrior, sizeof(TknU8));
   }
   dlgCp->pClass.pres = FALSE;
   if ((closeEv->pClass.pres == TRUE) && (closeEv->pClass.val <= PCLASS1))
   {
      cmCopy((U8 *)&closeEv->pClass,(U8 *)&dlgCp->pClass, sizeof(TknU8));
   }
#endif

#if (MATV2 && STUV2)
   if (closeEv->imp.pres == TRUE)
   {
      dlgCp->imp.pres = TRUE;
      dlgCp->imp.val = closeEv->imp.val;
   }
   else
   {
      dlgCp->imp.pres = FALSE;
   }
#endif

   if ( (ret = ( *maDSMTbl[MA_EV_CLOSE_REQ][dlgCp->dsmState]) (s)) != ROK)
   {
      invkId.pres = FALSE;
#ifdef ZJ
      MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
      MA_UPD_PEER(rtUpd)
#endif /* ZJ */
      maDlgIdle(s);
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, &invkId, MAT_EVTCLOSEREQ,
                     (Status)MAT_BAD_DLG_STATE);
      
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCloseReq(pst,spId(%d),suDlgId(%ld),spDlgId(%ld),\
      closeEv(0x%lx))failed,  invalid dialog state(%d) \n",
      spId, suDlgId, spDlgId, (PTR) closeEv, dlgCp->dsmState));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatCloseReq(pst,spId(%d),suDlgId(%d),spDlgId(%d),\
      closeEv(0x%lx))failed,  invalid dialog state(%d) \n",
      spId, suDlgId, spDlgId, (PTR) closeEv, dlgCp->dsmState));

#endif /* ALIGN_64BIT */ 
      RETVALUE(RFAILED);
   }
#if MAP_REL99
#if (MAP_SEC && LMAV2)
   if (dlgCp->mapSec == FALSE)
#endif
#endif
   s->sts.closeTx++;

#ifdef ZJ
   MA_UPD_PEER(rtUpd)
#endif /* ZJ */
   maDlgIdle(s);
   RETVALUE (ROK);
} /* end of MaUiMatCloseReq */


/*
*
*       Fun:   MaUiMatAbrtReq    
*
*       Desc:  This functions handles the MAp dialogue Abort
*              from its user. 
*
*       Ret:   ROK  
*
*       Notes: None 
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaUiMatAbrtReq 
(
Pst              *pst,           /* Post Structure */
SpId             spId,           /* Service provider Id */
MaDlgId          suDlgId,      /* Service user Dlg Id */
MaDlgId          spDlgId,        /* Service provider Dlg Id */
MaAbrtEv         *abrtEv         /* Abort Event structure */ 
)
#else
PUBLIC S16 MaUiMatAbrtReq(pst,spId,suDlgId,spDlgId,abrtEv)
Pst              *pst;           /* Post Structure */
SpId             spId;           /* Service provider Id */
MaDlgId          suDlgId;        /* Service user Dlg Id */
MaDlgId          spDlgId;        /* Service provider Dlg Id */
MaAbrtEv         *abrtEv;        /* Abort Event structure */ 
#endif
{
   MaSap   *s;
   MaDlgCp *dlgCp;
   MaInvokeId invkId;
   S16     ret;
   U32     i;
#ifdef ZJ
   Bool        rtUpd;
#endif

   TRC3(MaUiMatAbrtReq)

/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA395, 0," MaUiMatAbrtReq () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif
   MA_CHK_FOR_NULLP (pst);
   MA_CHK_FOR_NULLP (abrtEv);

#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatAbrtReq(pst,spId(%d),suDlgId(%ld), spDlgId(%ld), abrtEv(0x%lx)) \n",
    spId, suDlgId, spDlgId, (PTR) abrtEv));


#else
 
   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
   "MaUiMatAbrtReq(pst,spId(%d),suDlgId(%d), spDlgId(%d), abrtEv(0x%lx)) \n",
    spId, suDlgId, spDlgId, (PTR) abrtEv));

#endif /* ALIGN_64BIT */

   /* If not active then don't accept the close request */
#ifdef ZJ
   /* The local variable is required because dlgCp may be dellocated
    * if TCAP abort the dialogue in a tightly coupled system */

   if (!cmTuChkRsetStatus(&zjCb.tuCb, FALSE))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_INT_PAR, EMA055, (ErrVal)0, 
                "MaUiMatAbrtReq(): Invalid PSF state.");
#endif

      maSendAlrm(NEW,spId, MA_UNUSED, MA_UNUSED, "MaUiMatAbrtReq",
                 LCM_EVENT_UI_INV_EVT, LCM_CATEGORY_INTERFACE,
                 LCM_CAUSE_PROT_NOT_ACTIVE);

#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAbrtReq(spId(%d), spDlgId (%ld))failed, Invalid PSF state.\n", 
      spId, spDlgId));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAbrtReq(spId(%d), spDlgId (%d))failed, Invalid PSF state.\n", 
      spId, spDlgId));

#endif /* ALIGN_64BIT */

      RETVALUE(RFAILED);
   }
#endif /* ZJ */

   if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
       ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatAbrtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
     
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAbrtReq(pst,spId(%d),suDlgId(%ld), spDlgId(%ld),\
      abrtEv(0x%lx)) failed, invalid spId(%d). \n",
      spId, suDlgId, spDlgId, (PTR) abrtEv, spId));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAbrtReq(pst,spId(%d),suDlgId(%d), spDlgId(%d),\
      abrtEv(0x%lx)) failed, invalid spId(%d). \n",
      spId, suDlgId, spDlgId, (PTR) abrtEv, spId));

#endif /* ALIGN_64BIT */

      RETVALUE(RFAILED);
   }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatAbrtReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
      
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAbrtReq(pst,spId(%d),suDlgId(%ld), spDlgId(%ld),\
      abrtEv(0x%lx)) failed, invalid SAP state(%d). \n",
      spId, suDlgId, spDlgId, (PTR) abrtEv, s->maState));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAbrtReq(pst,spId(%d),suDlgId(%d), spDlgId(%d),\
      abrtEv(0x%lx)) failed, invalid SAP state(%d). \n",
      spId, suDlgId, spDlgId, (PTR) abrtEv, s->maState));

   #endif /* ALIGN_64BIT */
      RETVALUE(RFAILED);
   }

   /* Get the dialog control point */

   dlgCp = maFindHashDlg(s, spDlgId);
   if (dlgCp == (MaDlgCp *)NULLP)
   {
      RETVALUE(ROK);
   }

#ifdef ZJ
   rtUpd = dlgCp->upd;
#endif

   s->curDlgCp = dlgCp;
   s->evtPtr = (U8 *)abrtEv;

   if ((abrtEv->usrInfo.pres) &&
       ((abrtEv->usrInfo.len > MF_SIZE_TKNSTRS) ||
        (dlgCp->apn.val[dlgCp->apn.len -1] == LMA_VER1))) 
   {
      invkId.pres = FALSE;
#ifdef ZJ
      MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
      MA_UPD_PEER(rtUpd)
#endif /* ZJ */
      maDlgIdle(s);
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId,&invkId, 
                     MAT_EVTABRTREQ,(Status)MAT_BAD_USR_PARAM);
      
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf, 
             "MaUiMatAbrtReq(pst, spId(%d), suDlgId(%ld), spDlgId(%ld), \
             AbortEv(0x%lx))failed,invalid usrInfo.\n", 
             spId, suDlgId, spDlgId, (PTR) abrtEv));
      
#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf, 
             "MaUiMatAbrtReq(pst, spId(%d), suDlgId(%d), spDlgId(%d), \
             AbortEv(0x%lx))failed,invalid usrInfo.\n", 
             spId, suDlgId, spDlgId, (PTR) abrtEv));

#endif /* ALIGN_64BIT */
      RETVALUE(RFAILED);



   }

   if (abrtEv->extCont.priExtLst[0].pres == TRUE)
   {
      for ( i = 0; i < MA_MAX_NMB_PRI_EXT; i++)
      {
         if ((abrtEv->extCont.priExtLst[i].pres == TRUE) &&
             ((dlgCp->apn.val[dlgCp->apn.len -1] <= LMA_VER2)||
              (abrtEv->extCont.priExtLst[i].len > MF_SIZE_TKNSTRE)))
         {
            invkId.pres = FALSE;
#ifdef ZJ
            MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
            MA_UPD_PEER(rtUpd)
#endif /* ZJ */
            maDlgIdle(s);
            MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId,&invkId, 
                           MAT_EVTABRTREQ,(Status)MAT_BAD_USR_PARAM);
            
#ifndef ALIGN_64BIT

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf, 
                   "MaUiMatAbrtReq(pst, spId(%d), suDlgId(%ld),spDlgId(%ld), \
                   AbortEv(0x%lx))failed,invalid extCont.\n", 
                   spId, suDlgId, spDlgId, (PTR) abrtEv));

#else

            MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf, 
                   "MaUiMatAbrtReq(pst, spId(%d), suDlgId(%d),spDlgId(%d), \
                   AbortEv(0x%lx))failed,invalid extCont.\n", 
                   spId, suDlgId, spDlgId, (PTR) abrtEv));
 
#endif /* ALIGN_64BIT */
            RETVALUE(RFAILED);
         }
      }
   }
#ifdef MATV3
   dlgCp->maPrior.pres = FALSE;
   if ((abrtEv->maPrior.pres == TRUE) && (abrtEv->maPrior.val <= MA_PRI3))
   {
      cmCopy((U8 *)&abrtEv->maPrior,(U8 *)&dlgCp->maPrior, sizeof(TknU8));
   }
   dlgCp->pClass.pres = FALSE;
   if ((abrtEv->pClass.pres == TRUE) && (abrtEv->pClass.val <= PCLASS1))
   {
      cmCopy((U8 *)&abrtEv->pClass,(U8 *)&dlgCp->pClass, sizeof(TknU8));
   }
#endif

#if (MATV2 && STUV2)
   if (abrtEv->imp.pres == TRUE)
   {
      dlgCp->imp.pres = TRUE;
      dlgCp->imp.val = abrtEv->imp.val;
   }
   else
   {
      dlgCp->imp.pres = FALSE;
   }
#endif

   if ( (ret = ( *maDSMTbl[MA_EV_ABRT_REQ][dlgCp->dsmState]) (s)) != ROK)
   {
      invkId.pres = FALSE;
#ifdef ZJ
      MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
      MA_UPD_PEER(rtUpd)
#endif /* ZJ */
      maDlgIdle(s);
      MaUiMatStatInd(&s->maPstMU, s->suId, suDlgId, &invkId, MAT_EVTABRTREQ,
                     (Status)MAT_BAD_DLG_STATE);
      
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAbrtReq(pst,spId(%d),suDlgId(%ld), spDlgId(%ld),\
      abrtEv(0x%lx)) failed, invalid dialog state(%d). \n",
      spId, suDlgId, spDlgId, (PTR) abrtEv, dlgCp->dsmState));

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatAbrtReq(pst,spId(%d),suDlgId(%d), spDlgId(%d),\
      abrtEv(0x%lx)) failed, invalid dialog state(%d). \n",
      spId, suDlgId, spDlgId, (PTR) abrtEv, dlgCp->dsmState));

#endif /* ALIGN_64BIT */
      RETVALUE(RFAILED);
   }
#if MAP_REL99
#if (MAP_SEC && LMAV2)
   if (dlgCp->mapSec == FALSE)
#endif
#endif
   s->sts.abrtTx++;
#ifdef ZJ
   MA_UPD_PEER(rtUpd)
#endif /* ZJ */
   maDlgIdle(s);
   RETVALUE (ROK);
} /* end of MaUiMatAbrtReq */

/*
*
*       Fun:   MaUiMatSteReq
*
*       Desc:  This function handles the State chnage request for SSN or
*              Point Code. 
*
*       Ret:   ROK 
*
*       Notes: NONE 
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaUiMatSteReq 
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
CmSS7SteMgmt *steMgmt       /* SS7 State Management structure */
)
#else
PUBLIC S16  MaUiMatSteReq (pst, spId, steMgmt)
Pst        *pst;            /* post structure */
SpId       spId;            /* service user id */
CmSS7SteMgmt *steMgmt;      /* SS7 State Management structure */
#endif
{
  MaSap *s;

  TRC3(MaUiMatSteReq)

/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA396, 0," MaUiMatSteReq () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif


  MA_CHK_FOR_NULLP (pst);
  MA_CHK_FOR_NULLP (steMgmt);

  MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
          "MaUiMatSteReq(pst, spId(%d), steMgmt(0x%lx))\n",
           spId, (PTR) steMgmt));

   /* If not active then don't accept the state change request */
#ifdef ZJ
   if (!cmTuChkRsetStatus(&zjCb.tuCb, TRUE))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_INT_PAR, EMA056, (ErrVal)0, 
                "MaUiMatSteReq(): Invalid PSF state.");
#endif
      maSendAlrm(NEW,spId, MA_UNUSED, MA_UNUSED, "MaUiMatSteReq",
                 LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,
                 LCM_CAUSE_PROT_NOT_ACTIVE);

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSteReq(pst, spId(%d))failed, Invalid PSF state.\n", spId));

      RETVALUE(RFAILED);
   }
#endif /* ZJ */

  if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
      ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatSteReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatSteReq(pst, spId(%d), steMgmt(0x%lx))failed, invalid spId(%d)\n",
     spId, (PTR) steMgmt, spId));
     RETVALUE(RFAILED);
  }
   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatSteReq",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSteReq(pst, spId(%d), steMgmt(0x%lx))failed, invalid SAP state(%d)\n",
      spId, (PTR) steMgmt, s->maState));
      RETVALUE(RFAILED);
   }

  MaLiStuSteReq(&s->maPstST, s->spIdTC, steMgmt);
  RETVALUE(ROK);
} /* MaUiMatSteReq */ 

/*
*
*       Fun:   MaUiMatSteRsp
*
*       Desc:  This function handles the State chnage response for SSN 
*
*       Ret:   ROK 
*
*       Notes: NONE 
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaUiMatSteRsp 
(
Pst        *pst,            /* post structure */
SpId       spId,            /* service user id */
CmSS7SteMgmt *steMgmt       /* SS7 State Management structure */
)
#else
PUBLIC S16  MaUiMatSteRsp (pst, spId, steMgmt)
Pst        *pst;            /* post structure */
SpId       spId;            /* service user id */
CmSS7SteMgmt *steMgmt;      /* SS7 State Management structure */
#endif
{
  MaSap *s;

  TRC3(MaUiMatSteRsp)

/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA397, 0," MaUiMatSteRsp () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif

  MA_CHK_FOR_NULLP (pst);
  MA_CHK_FOR_NULLP (steMgmt);

  MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
         "MaUiMatSteRsp(pst, spId(%d), steMgmt(0x%lx))\n",
          spId, (PTR) steMgmt));

   /* If not active then don't accept the state change request */
#ifdef ZJ
   if (!cmTuChkRsetStatus(&zjCb.tuCb, TRUE))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_INT_PAR, EMA057, (ErrVal)0, 
                "MaUiMatSteRsp(): Invalid PSF state.");
#endif
      maSendAlrm(NEW,spId, MA_UNUSED, MA_UNUSED, "MaUiMatSteRsp",
                 LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,
                 LCM_CAUSE_PROT_NOT_ACTIVE);

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSteRsp(pst, spId(%d))failed, Invalid PSF state.\n", spId));

      RETVALUE(RFAILED);
   }
#endif /* ZJ */

  if (spId >= (SpId)maCb.maCP.nmbMAUSaps || spId < 0 || 
      ((s = *(maCb.maSapLmaPtr + spId)) == (MaSap *)NULLP))
  {
     maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAPID, "MaUiMatSteRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SPID);
     MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
     "MaUiMatSteRsp(pst, spId(%d), steMgmt(0x%lx))failed, invalid spId(%d)\n",
     spId, (PTR) steMgmt, spId));
     RETVALUE(RFAILED);
  }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,spId, STMATSAP, LMA_BAD_SAP_STATE, "MaUiMatSteRsp",
               LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSteRsp(pst, spId(%d), steMgmt(0x%lx))failed, invalid SAP state(%d)\n",
      spId, (PTR) steMgmt, s->maState));
      RETVALUE(RFAILED);
   }

  MaLiStuSteRsp(&s->maPstST, s->spIdTC, steMgmt);
  RETVALUE(ROK);
} /* MaUiMatSteRsp */ 

/*
*
*       Fun:   MaLiStuDatInd    
*
*       Desc:  This functions handles the data indication 
*              from TCAP. 
*
*       Ret:   ROK  
*
*       Notes: None 
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaLiStuDatInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
U8         msgType,         /* message type id */
StDlgId    suDlgId,         /* Service userDialog id */
StDlgId    spDlgId,         /* Service Dialog id */
SpAddr     *destAddr,       /* destination SCCP address */
SpAddr     *srcAddr,        /* source SCCP address */
Bool       compsPres,       /* components present */
StOctet    *prvAbrtCause,   /* provider abort cause if abort component */
StQosSet   *stQosSet,         /* Quality of Service */
Dpc        opc,             /* originating point code */
StDlgEv    *dlgEv,          /* Dialogue Event Structure */
#ifdef STUV2
StDataParam *dataParam,     /* data parameter */
#endif /* STUV2 */
Buffer     *mBuf            /* Dialog portion of the TCAP message */
)
#else
#ifdef STUV2
PUBLIC S16 MaLiStuDatInd(pst, suId, msgType, suDlgId, spDlgId, destAddr, srcAddr, compsPres, prvAbrtCause, stQosSet, opc, dlgEv, dataParam, mBuf)
#else
PUBLIC S16 MaLiStuDatInd(pst, suId, msgType, suDlgId, spDlgId, destAddr, srcAddr, compsPres, prvAbrtCause, stQosSet, opc, dlgEv, mBuf)
#endif /* STUV2 */
Pst        *pst;            /* post structure */
SuId       suId;            /* service user id */
U8         msgType;         /* message type id */
StDlgId    suDlgId;         /* Service userDialog id */
StDlgId    spDlgId;         /* Service Dialog id */
SpAddr     *destAddr;       /* destination SCCP address */
SpAddr     *srcAddr;        /* source SCCP address */
Bool       compsPres;       /* components present */
StOctet    *prvAbrtCause;   /* abort information if abort component */
StQosSet   *stQosSet;         /* Quality of Service */
Dpc        opc;             /* originating point code */
StDlgEv    *dlgEv;          /* Dialogue Event Structure */
#ifdef STUV2
StDataParam *dataParam;     /* data Parameter */
#endif /* STUV2 */
Buffer     *mBuf;           /* Dialog portion of the TCAP message */
#endif
{
   S16 ret;
   MaDlgCp  *dlgCp;
   MaSap    *s;
   MaDlgId  maSpDlgId;
   U8       maMsgType;
#ifdef STUV2
   StDataParam  dataPar;
#endif

   TRC3(MaLiStuDatInd)

/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA398, 0," MaLiStuDatInd () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif
/* ma001.203 : Addition. Initialized dataParam */
#ifdef STUV2
   cmZero((Data *) &dataPar, sizeof(StDataParam));
#endif

   
#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
   "MaLiStuDatInd(pst, suId(%d), msgType(%d), suDlgId(%ld), \
    spDlgId(%ld), destAddr(0x%lx), srcAddr(0x%lx), compsPres(%d),\
    prvAbrtCause(%d), stQosSet(%d), opc(%ld), dlgEv(0x%lx), mBuf(0x%lx))\n", \
    suId, msgType, suDlgId, spDlgId, (PTR) destAddr, (PTR) srcAddr, \
    compsPres, ((prvAbrtCause != (StOctet *)NULLP)?(prvAbrtCause->octet):(0)),\
    stQosSet->msgPrior, opc, (PTR)dlgEv, (PTR) mBuf));

#else
 
   MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
   "MaLiStuDatInd(pst, suId(%d), msgType(%d), suDlgId(%d), \
    spDlgId(%d), destAddr(0x%lx), srcAddr(0x%lx), compsPres(%d),\
    prvAbrtCause(%d), stQosSet(%d), opc(%d), dlgEv(0x%lx), mBuf(0x%lx))\n", \
    suId, msgType, suDlgId, spDlgId, (PTR) destAddr, (PTR) srcAddr, \
    compsPres, ((prvAbrtCause != (StOctet *)NULLP)?(prvAbrtCause->octet):(0)),\
    stQosSet->msgPrior, opc, (PTR)dlgEv, (PTR) mBuf));

#endif /* ALIGN_64BIT */

   /* If not active then don't accept the data indication */
#ifdef ZJ
   if (!cmTuChkRsetStatus(&zjCb.tuCb, FALSE))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_INT_PAR, EMA058, (ErrVal)0, 
                "MaLiStuDatInd(): Invalid PSF state.");
#endif
      CMTU_FREE_BUF(mBuf);
      maSendAlrm(NEW,suId, MA_UNUSED, MA_UNUSED, "MaLiStuDatInd",
                 LCM_EVENT_UI_INV_EVT, LCM_CATEGORY_INTERFACE,
                 LCM_CAUSE_PROT_NOT_ACTIVE);

      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
             "MaLiStuDatInd()failed, Invalid PSF state.\n"));

      RETVALUE(RFAILED);
   }
#endif /* ZJ */

   if (dlgEv == (StDlgEv *)NULLP)
   {
      if (mBuf != NULLP)
      {
         (Void)SPutMsg(mBuf);
      }
      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "MaLiStuDatInd() failed, dlgEv(0x%lx) is NULLP.\n",(PTR)dlgEv));
      RETVALUE(RFAILED);
   }

   if (suId >= (SuId)maCb.maCP.nmbMAUSaps || suId < 0 || 
       ((s = *(maCb.maSapLmaPtr + suId)) == (MaSap *)NULLP))
   {
      maSendAlrm(NEW,suId, STMATSAP, LMA_BAD_SAPID, "MaLiStuDatInd",
               LCM_EVENT_LI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SUID);
      if (mBuf != NULLP)
      {
         (Void)SPutMsg(mBuf);
      }
      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "MaLiStuDatInd() failed, invalid suId(%d).\n",suId));
      RETVALUE(RFAILED);
   }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,suId, STMATSAP, LMA_BAD_SAP_STATE, "MaLiStuDatInd",
               LCM_EVENT_LI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
      if (mBuf != NULLP)
      {
        (Void)SPutMsg(mBuf);
      }
      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "MaLiStuDatInd() failed, invalid SAP state(%d).\n",s->maState));
      RETVALUE(RFAILED);
   }

   /* increment statistics */
   /* initialize pointer to user Information */ 
   s->crntRxMsg = mBuf;
   s->evtPtr = (U8 *)dlgEv;

   if (s->trc == TRUE)
   {
     maGenTrc(s, LMA_DATA_RECVD, mBuf);
   }

   switch (msgType)
   {
      case STU_BEGIN:

        /* allocate a new spDlgId, check if we need to use a bit map */

         if (s->bitMap.map == NULLP)
         {
            /* use hash list to allocate dlgId */
            s->maDlgIdPool = maGetDlgId(s);
         }
         else
         {
            /* use a bit map to allocate dlgId */
            s->maDlgIdPool = maAllocDlgId(s);
         }

         /* check to see if the dialogue id is allocated */
         if (s->maDlgIdPool == 0)
         {
            StDlgEv rspDlgEv;
            if (mBuf != NULLP)
            {
               (Void)SPutMsg(mBuf);
            }
            s->maDlgIdPool = s->cfg.stDlgId;
 
            /* pre arranged close for the dialogue instance in TCAP */
            rspDlgEv.pres = FALSE;
#ifdef STUV2
            dataPar.imp.pres = FALSE;

            MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_END, 0, spDlgId, 
                          destAddr, srcAddr,TRUE, &s->qosSet, &rspDlgEv, 
                          &dataPar, NULLP);
#else
            MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_END, 0, spDlgId, 
                 destAddr, srcAddr,TRUE, &s->qosSet, &rspDlgEv, NULLP);
#endif /* STUV2 */
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "MaLiStuDatInd() failed, dialog id can not be allocated.\n"));
            RETVALUE(RFAILED);      
         }

         maSpDlgId = s->maDlgIdPool;

         /* insert into transaction table */
         dlgCp = maInsHashDlg(s, maSpDlgId, 0);
         if(dlgCp == NULLP)
         {
            StDlgEv rspDlgEv;
            if (mBuf != NULLP)
            {
               (Void)SPutMsg(mBuf);
            }
 
            /* pre arranged close for the dialogue instance in TCAP */
            rspDlgEv.pres = FALSE;
#ifdef STUV2
            dataPar.imp.pres = FALSE;

            MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_END, 0, spDlgId, 
                          destAddr, srcAddr,TRUE, &s->qosSet, &rspDlgEv, 
                          &dataPar, NULLP);
#else
            MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_END, 0, spDlgId, 
                 destAddr, srcAddr,TRUE, &s->qosSet, &rspDlgEv, NULLP);
#endif
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "MaLiStuDatInd() failed, can not insert dlgCp into hash list.\n"));

            RETVALUE(RFAILED);      
         }
         dlgCp->lowerSpDlgId = spDlgId;
         s->curDlgCp = dlgCp;
         dlgCp->cmpPresFlg =  compsPres;

         /* save current destination address for outgoing packets */
         cmCopySpAddr(destAddr, &dlgCp->destAddr);

         /* save current source address for outgoing packets */
         cmCopySpAddr(srcAddr, &dlgCp->srcAddr);

         break;

      case STU_CONTINUE:
      case STU_END:
      case STU_P_ABORT:
      case STU_U_ABORT:
         /* Find the dialogue control point */
         dlgCp = maFindHashDlg(s, suDlgId);
         if (dlgCp == NULLP)
         {
            if (mBuf != NULLP)
            {
               SPutMsg(mBuf);
            }
#ifndef ALIGN_64BIT

            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "MaLiStuDatInd() failed, invalid suDlgId(%ld).\n", suDlgId));
            
#else

            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "MaLiStuDatInd() failed, invalid suDlgId(%d).\n", suDlgId));

#endif /* ALIGN_64BIT */

            RETVALUE(RFAILED);
         }
         if (dlgCp->cmpPresFlg == TRUE)
         {
            if (mBuf != NULLP)
            {
               (Void)SPutMsg(mBuf);
            }
            MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "MaLiStuDatInd() failed, cmpPresFlg set.\n"));
            RETVALUE(RFAILED);
         }
         if(msgType == STU_CONTINUE && destAddr->pres == TRUE)
         {
            /* copy the destination address coming from the TCAP */
            cmCopySpAddr(destAddr,&dlgCp->destAddr);
         }
         s->curDlgCp = dlgCp;
         dlgCp->cmpPresFlg = compsPres;
         dlgCp->tcAbrtType = msgType; 
         if(prvAbrtCause != NULLP)
         {
            dlgCp->tcAbrtCause.pres = prvAbrtCause->pres;
            if (dlgCp->tcAbrtCause.pres)
              dlgCp->tcAbrtCause.octet = prvAbrtCause->octet;
         }
         break;
      default :
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA059, (ErrVal)msgType, 
                    "MaLiStuDatInd () Failed, invalid message type.");
#endif
         if (mBuf != NULLP)
         {
            SPutMsg(mBuf);
         } 
         RETVALUE(RFAILED);
   }
   switch(msgType)
   {
      case STU_BEGIN:
         maMsgType = MA_BEGIN;
         break;
      case STU_CONTINUE:
         maMsgType = MA_CONTINUE;
         break;
      case STU_END:
         maMsgType = MA_END;
         break;
      case STU_U_ABORT:
         maMsgType = MA_ABRT;
         break;
      case STU_P_ABORT:
         maMsgType = MA_ABRT;
         break;
      default:
         if (mBuf)
            (Void)SPutMsg(mBuf);
         MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
         "MaLiStuDatInd() failed, invalid message type.\n"));
         RETVALUE(RFAILED);
   }

   /* process the PDU */
   if ( (ret = ( *maDSMTbl[maMsgType][dlgCp->dsmState]) (s)) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
        MALOGERROR(ERRCLS_DEBUG, EMA060, (ErrVal)msgType, 
                   "MaLiStuDatInd () Failed, state machine ");
#endif
   }
#if MAP_REL99
#if (MAP_SEC && LMAV2)
   /* If dialogue is still existing after calling state machine , check 
    * the mapSec flag. If it is TRUE then unsecure operation related 
    * statistics are not to be updated.
    * If dialogue control block is not existing or it is existing and
    * it is not a secure dialogue then update the unsecure operation 
    * statistics.
    * If dialogue is cleared in state machine then the curDlgCp shall be
    * made NULLP
    */
   if (!((s->curDlgCp) && (s->curDlgCp->mapSec)))
#endif
#endif
   switch(msgType)
   {
      case STU_BEGIN:
         s->sts.openReqRx++;
         break;
      case STU_END:
         s->sts.closeRx++;
         break;
      case STU_U_ABORT:
         s->sts.abrtRx++;
         break;
      case STU_P_ABORT:
         s->sts.abrtRx++;
         break;
   }

   if (mBuf != NULLP)
   {
      (Void)SPutMsg(mBuf);
   }
   RETVALUE(ROK);
} /* end of MaLiStuDatInd */

/*
*
*       Fun:   MaLiStuUDatInd    
*
*       Desc:  This functions handles the unit data indication 
*              from TCAP. 
*
*       Ret:   ROK  
*
*       Notes: MAP doesn't use the unit data primitive.  
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaLiStuUDatInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
#ifdef STUV3
MaDlgId   suDlgId,
MaDlgId   spDlgId,
#endif
SpAddr     *destAddr,       /* destination SCCP address */
SpAddr     *srcAddr,        /* source SCCP address */
StQosSet   *stQosSet,       /* Quality of Service */
Dpc        opc,             /* originating point code */
StDlgEv    *dlgEv,          /* Dialogue Event Structure */
#ifdef STUV2
StDataParam *dataParam,     /* data parameter */
#endif /* STUV2 */
Buffer     *mBuf            /* Dialog portion of the TCAP message */
)
#else
#ifdef STUV2
#ifdef STUV3
PUBLIC S16 MaLiStuUDatInd(pst, suId, suDlgId, spDlgId, destAddr, srcAddr, stQosSet, opc, dlgEv, dataParam, mBuf)
#else
PUBLIC S16 MaLiStuUDatInd(pst, suId, destAddr, srcAddr, stQosSet, opc, dlgEv, dataParam, mBuf)
#endif /* STUV3 */
#else
PUBLIC S16 MaLiStuUDatInd(pst, suId, destAddr, srcAddr, stQosSet, opc, dlgEv, mBuf)
#endif /* STUV2 */
Pst        *pst;            /* post structure */
SuId       suId;            /* service user id */
#ifdef STUV3
MaDlgId    suDlgId;
MaDlgId    spDlgId;
#endif
SpAddr     *destAddr;       /* destination SCCP address */
SpAddr     *srcAddr;        /* source SCCP address */
StQosSet   *stQosSet;       /* Quality of Service */
Dpc        opc;             /* originating point code */
StDlgEv    *dlgEv;          /* Dialogue Event Structure */
#ifdef STUV2
StDataParam *dataParam;     /* data parameter */
#endif /* STUV2 */
Buffer     *mBuf;           /* Dialog portion of the TCAP message */
#endif
{
   TRC3(MaLiStuUDatInd)
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA399, 0," MaLiStuUDatInd () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif
   SPutMsg(mBuf);
   RETVALUE(ROK);
} /* end of MaLiStuUDatInd */

/*
*
*       Fun:   MaLiStuCmpInd    
*
*       Desc:  This functions handles the component indication 
*              from TCAP. 
*
*       Ret:   ROK  
*
*       Notes: None 
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaLiStuCmpInd
(
Pst *pst,                   /* post structure */
SuId suId,                  /* service user id */
StDlgId suDlgId,            /* dialog Id */
StDlgId spDlgId,            /* dialog Id */
StComps *cmpEv,             /* TCAP component */
Dpc opc,                    /* originating point code */
Status status,              /* Status */
Buffer *mBuf                /* Component parameter buffer */
)
#else
PUBLIC S16 MaLiStuCmpInd(pst, suId, suDlgId, spDlgId, cmpEv, opc, status,mBuf)
Pst *pst;                   /* post structure */
SuId suId;                  /* service user id */
StDlgId suDlgId;            /* dialog Id */
StDlgId spDlgId;            /* dialog Id */
StComps *cmpEv;             /* TCAP component */
Dpc opc;                    /* originating point code */
Status status;              /* Status */
Buffer *mBuf;               /* Component parameter buffer */
#endif
{
   MaDlgCp  *dlgCp;
   MaCloseEv closeEv;
   MaSap    *s;
   MaDlgId   tmpSuDlgId;        /* temporary Service user Dlg Id */
   MaDlgId   tmpSpDlgId;        /* temporary Service provider Dlg Id */
   U32       i;
   MaDlgCp  *tmpdlgCp;
#ifdef ZJ
   Bool  rtUpd;
#endif

   TRC3(MaLiStuCmpInd)
   
/* * xqc memset the struct, for aviod paking(close Ind) error
 * * modify based protocol v2.1
 * */
   cmMemset((U8 *)&closeEv, 0, sizeof(closeEv));

/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA400, 0," MaLiStuCmpInd () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif
#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
   "MaLiStuCmpInd(pst, suId(%d), suDlgId(%ld), spDlgId(%ld), \
    cmpEv(0x%lx), opc(%ld), status(%d), mBuf(0x%lx))\n",     \
    suId, suDlgId, spDlgId, (PTR) cmpEv, opc, status, (PTR) mBuf));

#else
 
   MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
   "MaLiStuCmpInd(pst, suId(%d), suDlgId(%d), spDlgId(%d), \
    cmpEv(0x%lx), opc(%d), status(%d), mBuf(0x%lx))\n",     \
    suId, suDlgId, spDlgId, (PTR) cmpEv, opc, status, (PTR) mBuf));

#endif /* ALIGN_64BIT */
   /* If not active then don't accept the component indication */
#ifdef ZJ
   if (!cmTuChkRsetStatus(&zjCb.tuCb, FALSE))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_INT_PAR, EMA061, (ErrVal)0, 
                "MaLiStuCmpInd(): Invalid PSF state.");
#endif
      CMTU_FREE_BUF(mBuf);
      maSendAlrm(NEW,suId, MA_UNUSED, MA_UNUSED, "MaLiStuCmpInd",
                 LCM_EVENT_UI_INV_EVT, LCM_CATEGORY_INTERFACE,
                 LCM_CAUSE_PROT_NOT_ACTIVE);

      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
             "MaLiStuCmpInd()failed, Invalid PSF state.\n"));

      RETVALUE(RFAILED);
   }
#endif /* ZJ */

   if (suId >= (SuId)maCb.maCP.nmbMAUSaps || suId < 0 || 
       ((s = *(maCb.maSapLmaPtr + suId)) == (MaSap *)NULLP))
   {
      maSendAlrm(NEW,suId, STMATSAP, LMA_BAD_SAPID, "MaLiStuCmpInd",
               LCM_EVENT_LI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SUID);
      if (mBuf != NULLP)
      {
         SPutMsg(mBuf);
      }
      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "MaLiStuCmpInd() failed, invalid suId(%d)\n", suId));
      RETVALUE(RFAILED);
   }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,suId, STMATSAP, LMA_BAD_SAP_STATE, "MaLiMatCmpInd",
               LCM_EVENT_LI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
      if (mBuf != NULLP)
      {
        SPutMsg(mBuf);
      }
      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "MaLiStuCmpInd() failed, invalid SAP state(%d)\n", s->maState));
      RETVALUE(RFAILED);
   }

   /* increment statistics */
   /* initialize pointer to current Invoke Component Parameter Buffer */
   s->crntRxMsg = mBuf;

   if (s->trc == TRUE)
   {
     maGenTrc(s, LMA_CMP_RECVD, mBuf);
   }

   /* Find out the dialogue control point */
    if (suDlgId == 0)
      dlgCp = maFindHashDlgLower(s, spDlgId);
    else
      dlgCp = maFindHashDlg(s, suDlgId);
    if (dlgCp == (MaDlgCp *)NULLP)
    {
      if (mBuf != NULLP)
      {
         (Void)SPutMsg(mBuf);
      }
      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "MaLiStuCmpInd() failed, unable to find dialog Id\n"));
      RETVALUE(RFAILED);
    }
    s->curDlgCp = dlgCp;
#ifdef ZJ
    rtUpd = dlgCp->upd;
#endif
    /* process the PDU */
   switch(cmpEv->stCompType)
   {
      case STU_INVOKE:
         if ((cmpEv->stCompType == STU_INVOKE) && 
            (dlgCp->dsmState == MA_DLG_WAIT_INIT_DATA))
            maProcessInvM02(s, dlgCp, cmpEv );
         else
           maProcessInvk(s, dlgCp, cmpEv);
         break;
      case STU_RET_RES_L:
         maProcessRetRsltL(s, dlgCp, cmpEv);
         break;
      case STU_RET_RES_NL:
         maProcessRetRsltNL(s, dlgCp, cmpEv);
         break;
      case STU_RET_ERR:
         maProcessRetErr(s, dlgCp, cmpEv);
         break;
      case STU_REJECT:
         if (cmpEv->cancelFlg == TRUE)
         {
            maProcessCan(s, dlgCp, cmpEv);
         }
         else
         {
            maProcessRej(s,dlgCp, cmpEv, (U8)status);
         }
         break;
      default :
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA062, (ErrVal)cmpEv->stCompType, 
                   "MaLiStuCmpInd () Failed, invalid component type.");
#endif
          break;
   }

   if (mBuf != NULLP)
   {
     (Void)SPutMsg(mBuf);
   }
   /* In tightly mode, when the above procedure return, dlgCp and curDlgCp
    * could be changed, find out the dialogue control point again*/
   if (s->curDlgCp != dlgCp )
   {
      if (suDlgId == 0)
      {
         tmpdlgCp = maFindHashDlgLower(s, spDlgId);
      }
      else
      {
         tmpdlgCp = maFindHashDlg(s, suDlgId);
      }
      if (tmpdlgCp == dlgCp)
      {
         s->curDlgCp = dlgCp;
      }
      else
      {
         RETVALUE(ROK);
      }
   }
   if (cmpEv->stLastCmp == TRUE)
   {
     if (dlgCp->endFlg == TRUE)
     {
        /* Send Close Indication to the user */
        closeEv.rlsCause = MAT_NORMAL_RELEASE;
        if (dlgCp->closePduPres == TRUE)
        {
           if( dlgCp->closePdu.usrInfo.pres == TRUE)
           {
              cmCopy((U8 *)&dlgCp->closePdu.usrInfo, 
                     (U8 *)&closeEv.usrInfo,sizeof(TknStrS));
           }
           if (dlgCp->closePdu.extCont.priExtLst[0].pres == TRUE)
           {
              for ( i = 0; i < MA_MAX_NMB_PRI_EXT; i++)
              {
                 if (dlgCp->closePdu.extCont.priExtLst[i].pres == TRUE)
                 {
                    cmCopy((U8 *)&dlgCp->closePdu.extCont.priExtLst[i],
                          (U8 *)&closeEv.extCont.priExtLst[i],sizeof(TknStrE));
                 }
              }
           }
        }
#if MAP_REL99
#if (MAP_SEC && LMAV2)
        if (dlgCp->mapSec == FALSE)
#endif
#endif
        s->sts.closeRx++;
        tmpSuDlgId = dlgCp->suDlgId;    
        tmpSpDlgId = dlgCp->spDlgId;    
#ifdef ZJ
        MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_DEL)
        MA_UPD_PEER(rtUpd)
#endif /* ZJ */
        maDlgIdle(s);
        MaUiMatCloseInd(&s->maPstMU, s->suId, tmpSuDlgId, tmpSpDlgId, &closeEv);
        RETVALUE(ROK);
     }

     if((dlgCp->dsmState == MA_DLG_IDLE) && (dlgCp->cmpPresFlg == TRUE))
     {
        /* change the state of DSM state machine */
        dlgCp->dsmState = MA_DLG_PENDING;
     }
     dlgCp->cmpPresFlg = FALSE;

     /* check early openrsp and restore the impact*/ 
     if (dlgCp->openRspRcvd.pres == TRUE )
     {
         maRestoreOpenRsp(dlgCp);
     }
#ifdef ZJ
     MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_MOD)
     MA_UPD_PEER(rtUpd)
#endif /* ZJ */
     /* send the delimeter indication to the map user */  
    /*stop the delimeter ind*/
#ifdef XW_IND_OPTIMIZE
#ifndef MA_STATIC_EVT_STRUCT
      if((dlgCp->suDlgId != 0)||(dlgCp->dsmState != MA_DLG_PENDING))
#endif
#endif
      {
         MaUiMatDelimInd(&s->maPstMU, s->suId, dlgCp->suDlgId, dlgCp->spDlgId);
      }
   }
   RETVALUE(ROK);
} /* end of MaLiStuCmpInd */


/*
*
*       Fun:   MaLiStuCmpCfm    
*
*       Desc:  This functions handles the Component confirm 
*              from TCAP. 
*
*       Ret:   ROK  
*
*       Notes: None 
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaLiStuCmpCfm
(
Pst *pst,                   /* post structure */
SuId suId,                  /* service user id */
StDlgId suDlgId,            /* dialog Id */
StDlgId spDlgId             /* dialog Id */
)
#else
PUBLIC S16 MaLiStuCmpCfm(pst, suId, suDlgId, spDlgId)
Pst *pst;                   /* post structure */
SuId suId;                  /* service user id */
StDlgId suDlgId;            /* dialog Id */
StDlgId spDlgId;            /* dialog Id */
#endif
{
  MaSap *s;
  MaDlgCp *dlgCp;

  TRC3(MaLiStuCmpCfm)
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA401, 0," MaLiStuCmpCfm () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif
  
#ifndef ALIGN_64BIT

  MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
  "MaLiStuCmpCfm(pst, suId(%d), suDlgId(%ld), suDlgId(%ld))\n",
   suId, suDlgId, spDlgId));

#else

  MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
  "MaLiStuCmpCfm(pst, suId(%d), suDlgId(%d), suDlgId(%d))\n",
   suId, suDlgId, spDlgId));

#endif /* ALIGN_64BIT */

   /* If not active then don't accept the component confirm */
#ifdef ZJ
   if (!cmTuChkRsetStatus(&zjCb.tuCb, FALSE))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_INT_PAR, EMA063, (ErrVal)0, 
                "MaLiStuCmpCfm(): Invalid PSF state.");
#endif
      maSendAlrm(NEW,suId, MA_UNUSED, MA_UNUSED, "MaLiStuCmpCfm",
                 LCM_EVENT_UI_INV_EVT, LCM_CATEGORY_INTERFACE,
                 LCM_CAUSE_PROT_NOT_ACTIVE);

      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
             "MaLiStuCmpCfm()failed, Invalid PSF state.\n"));

      RETVALUE(RFAILED);
   }
#endif /* ZJ */

   if (suId >= (SuId)maCb.maCP.nmbMAUSaps || suId < 0 || 
       ((s = *(maCb.maSapLmaPtr + suId)) == (MaSap *)NULLP))
   {
      maSendAlrm(NEW,suId, STMATSAP, LMA_BAD_SAPID, "MaLiStuCmpCfm",
               LCM_EVENT_LI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SUID);
      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "MaLiStuCmpCfm() failed, invalid suId(%d).\n", suId));
      RETVALUE(RFAILED);
   }

  dlgCp = maFindHashDlg(s,suDlgId);
  if (dlgCp == NULLP)
  {
#ifndef ALIGN_64BIT

    MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
    "MaLiStuCmpCfm() failed, invalid suDlgId(%ld).\n", suDlgId));

#else
 
    MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
    "MaLiStuCmpCfm() failed, invalid suDlgId(%d).\n", suDlgId));

#endif /* ALIGN_64BIT */
    RETVALUE(RFAILED);
  }
  dlgCp->lowerSpDlgId = spDlgId;
#ifdef ZJ
  MA_UPD_DLG(dlgCp, CMPFTHA_ACTN_MOD)
  MA_UPD_PEER(dlgCp->upd)
#endif
  RETVALUE(ROK);
} /* end of MaLiStuCmpCfm */

/*  
*  
*       Fun:  MaLiStuStaInd 
*   
*       Desc: This function handles the status indication from TCAP 
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  ca_bdy1.c
*  
*/ 
 
#ifdef ANSI
PUBLIC S16 MaLiStuStaInd
(
Pst *pst,                   /* post structure */
SuId suId,                  /* service user id */
Status status
)
#else
PUBLIC S16 MaLiStuStaInd(pst, suId, status)
Pst *pst;                   /* post structure */
SuId suId;                  /* service user id */
Status status;
#endif
{
  MaSap *s;

  TRC3(MaLiStuStaInd)
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA402, 0," MaLiStuStaInd () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif
  MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
        "MaLiStuStaInd(pst, suId(%d), status(%d))\n", suId, status));

  if (suId >= (SuId)maCb.maCP.nmbMAUSaps || suId < 0 || 
      ((s = *(maCb.maSapLmaPtr + suId)) == (MaSap *)NULLP))
  {
     maSendAlrm(NEW,suId, STMATSAP, LMA_BAD_SAPID, "MaLiStuStaInd",
               LCM_EVENT_LI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SUID);
     MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
     "MaLiStuStaInd() failed,invalid suId(%d).\n", suId));
     RETVALUE(RFAILED);
  }
  RETVALUE(ROK);
} /* end of MaLiStuStaInd */

/*
*
*       Fun:   MaLiStuNotInd    
*
*       Desc:  This function handles the Notice Indication from TCAP  
*
*       Ret:   ROK 
*
*       Notes: NONE 
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaLiStuNotInd 
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
StDlgId    suDlgId,         /* Service userDialog id */
StDlgId    spDlgId,         /* Service Dialog id */
SpAddr     *destAddr,       /* destination SCCP address */
SpAddr     *srcAddr,        /* source SCCP address */
#ifdef STUV2
StDataParam *dataParam,     /* Data Parameter */
#endif /* STUV2 */
RCause     cause            /* Cause of Notice Indication */
)
#else
#ifdef STUV2
PUBLIC S16  MaLiStuNotInd (pst, suId, suDlgId, spDlgId, destAddr, srcAddr, 
                           dataParam, cause)
#else
PUBLIC S16  MaLiStuNotInd (pst, suId, suDlgId, spDlgId, destAddr, srcAddr, cause)
#endif /* STUV2 */
Pst        *pst;            /* post structure */
SuId       suId;            /* service user id */
StDlgId    suDlgId;         /* Service userDialog id */
StDlgId    spDlgId;         /* Service Dialog id */
SpAddr     *destAddr;       /* destination SCCP address */
SpAddr     *srcAddr;        /* source SCCP address */
#ifdef STUV2
StDataParam *dataParam;     /* Data Parameter */
#endif /* STUV2 */
RCause     cause;           /* Cause of Notice Indication */
#endif
{
  MaSap *s;
  MaDlgCp    *dlgCp;      /* dialogue control point */
  S16 ret;                /* return code */
 /* ma014.203 : tmpdlgCp is decleared */
 
  MaDlgCp  *tmpdlgCp;

  TRC3(MaLiStuNotInd)
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA403, 0," MaLiStuNotInd () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif
  
#ifndef ALIGN_64BIT

   MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
   "MaLiStuNotInd(pst, suId(%d), suDlgId(%ld), spDlgId(%ld),\
    destAddr(0x%lx), srcAddr(0x%lx), cause(%d))\n",
    suId, suDlgId, spDlgId, (PTR) destAddr, (PTR) srcAddr, cause));
 
#else

  MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
   "MaLiStuNotInd(pst, suId(%d), suDlgId(%d), spDlgId(%d),\
    destAddr(0x%lx), srcAddr(0x%lx), cause(%d))\n",
    suId, suDlgId, spDlgId, (PTR) destAddr, (PTR) srcAddr, cause));

#endif /* ALIGN_64BIT */ 
  

  if (suId >= (SuId)maCb.maCP.nmbMAUSaps || suId < 0 || 
      ((s = *(maCb.maSapLmaPtr + suId)) == (MaSap *)NULLP))
  {
     maSendAlrm(NEW,suId, STMATSAP, LMA_BAD_SAPID, "MaLiStuNotInd",
               LCM_EVENT_LI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SUID);
     MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
     "MaLiStuNotInd() failed, invalid suId(%d).\n", suId));
     RETVALUE(RFAILED);
  }

   /* Find out the dialogue control point */

   if (suDlgId == 0)
   {
    /* ma014.203 : To avoid searching Hash List, if spDlgid is invalid */
      if(spDlgId == 0)
      {
 	 /* no dialogue CB for the indicated dialogue id, ignore the
         notice indication */

         MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
         "MaLiStuNotInd() failed, Invalid spDlgId(0) .\n"));
         RETVALUE(RFAILED);

      }
      /* TCAP does not know MAP's dialogue id, find out the dialogue 
         CB from TCAP dialogue id */

      dlgCp = maFindHashDlgLower(s, spDlgId);
   }
   else
   {

      /* TCAP knows MAP's dialogue id, find out the dialogue 
         CB from MAP's dialogue id */

      dlgCp = maFindHashDlg(s, suDlgId);
   }

   if (dlgCp == (MaDlgCp *)NULLP)
   {
      /* no dialogue CB for the indicated dialogue id, ignore the
         notice indication */

      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "MaLiStuNotInd() failed, no dialog CB for the dialog Id.\n"));
      RETVALUE(RFAILED);
   }
   
   /* ma014.203 : After Reteriving  dlgCp assign it to curDlgCp */
   s->curDlgCp = dlgCp;

   if(dlgCp->dsmState != MA_DLG_INITIATED)
   {
      /* 
      ** if the state is dialogue initiated then according the 
      ** SDL description open confirm with refuse reason set 
      ** to node not reachable. 
      ** only if the state is not equal to Dlg initiated we 
      ** send the notice indication to the MAP user with the 
      ** cause as failure reason given by SCCP or-ed with the SPMASK. 
      */
      MaUiMatNotInd(&s->maPstMU,                    /* pst */
                 s->suId,                        /* service user ID */
                 dlgCp->suDlgId,                 /* user dialogue id */
                 dlgCp->spDlgId,                 /* provider dialogue id */
                 (RCause)(cause | MAT_SPCAUSE_MASK));/* cause for notice ind.*/
                         
         /* ma014.203 : In tightly mode, when the above procedure 
                           return, dlgCp and curDlgCp could be changed 
                           find out the dialogue control point again */
     if (s->curDlgCp != dlgCp )
    {
      if (suDlgId == 0)
      {
         tmpdlgCp = maFindHashDlgLower(s, spDlgId);
      }
      else
      {
         tmpdlgCp = maFindHashDlg(s, suDlgId);
      }
      if (tmpdlgCp == dlgCp)
      {
         s->curDlgCp = dlgCp;
      }
    }
 
        RETVALUE(ROK);
   }

   if ( (ret = ( *maDSMTbl[MA_EV_NOT_IND][dlgCp->dsmState])(s)) != ROK)
   {
      /* now generate a notice indication to the MAP user and apply a 
      mask to the cause value to differentiate between local causes
      of notice indication */

      MaUiMatNotInd(&s->maPstMU,                    /* pst */
                 s->suId,                        /* service user ID */
                 dlgCp->suDlgId,                 /* user dialogue id */
                 dlgCp->spDlgId,                 /* provider dialogue id */
                 (RCause)(cause | MAT_SPCAUSE_MASK));/* cause for notice ind.*/
   }
   
     /* ma014.203 : In tightly mode, when the above procedure 
                           return, dlgCp and curDlgCp could be changed 
                           find out the dialogue control point again */
    if (s->curDlgCp != dlgCp )
    {
      if (suDlgId == 0)
      {
         tmpdlgCp = maFindHashDlgLower(s, spDlgId);
      }
      else
      {
         tmpdlgCp = maFindHashDlg(s, suDlgId);
      }
      if (tmpdlgCp == dlgCp)
      {
         s->curDlgCp = dlgCp;
      }
    }


  RETVALUE(ROK);
} /* MaLiStuNotInd */ 

/*
*
*       Fun:   MaLiStuSteInd    
*
*       Desc:  This function handles the State Indication from TCAP  
*
*       Ret:   ROK 
*
*       Notes: NONE 
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaLiStuSteInd 
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
CmSS7SteMgmt *steMgmt       /* SS7 State Management structure */
#ifdef STUV2
,StMgmntParam *mgmntParam
#endif /* STUV2 */
)
#else
#ifdef STUV2
PUBLIC S16  MaLiStuSteInd (pst, suId, steMgmt, mgmntParam)
#else  /* STUV2 */
PUBLIC S16  MaLiStuSteInd (pst, suId, steMgmt)
#endif /* STUV2 */
Pst        *pst;            /* post structure */
SuId       suId;            /* service user id */
CmSS7SteMgmt *steMgmt;      /* SS7 State Management structure */
#ifdef STUV2
StMgmntParam *mgmntParam;
#endif /* STUV2 */
#endif
{
  MaSap *s;
#ifdef MATV2
  MatSteMgmtEv matSteMgmtEv;          /* ril and SCCP state */
#endif

  TRC3(MaLiStuSteInd)
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA404, 0," MaLiStuSteInd () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif
  MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
        "MaLiStuSteInd(pst, suId(%d), steMgmt(0x%lx))\n",
        suId, (PTR) steMgmt));

   /* If not active then don't accept the state change indication */
#ifdef ZJ
   if (!cmTuChkRsetStatus(&zjCb.tuCb, TRUE))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_INT_PAR, EMA064, (ErrVal)0, 
                "MaUiMatSteInd(): Invalid PSF state.");
#endif
      maSendAlrm(NEW,suId, MA_UNUSED, MA_UNUSED, "MaUiMatSteInd",
                 LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,
                 LCM_CAUSE_PROT_NOT_ACTIVE);

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSteInd(pst, suId(%d))failed, Invalid PSF state.\n", suId));

      RETVALUE(RFAILED);
   }
#endif /* ZJ */

  if (suId >= (SuId)maCb.maCP.nmbMAUSaps || suId < 0 || 
      ((s = *(maCb.maSapLmaPtr + suId)) == (MaSap *)NULLP))
  {
     maSendAlrm(NEW,suId, STMATSAP, LMA_BAD_SAPID, "MaLiStuSteInd",
               LCM_EVENT_LI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SUID);
     MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
     "MaLiStuSteInd() failed, invalid suId(%d).\n", suId));
     RETVALUE(RFAILED);
  }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,suId, STMATSAP, LMA_BAD_SAP_STATE, "MaLiStuSteInd",
               LCM_EVENT_LI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "MaLiStuSteInd() failed, invalid SAP state(%d).\n", s->maState));
      RETVALUE(RFAILED);
   }

#ifdef STUV2
   s->ril = mgmntParam->ril;
#endif

#ifdef MATV2
#ifdef STUV2
   matSteMgmtEv.ril = mgmntParam->ril;
   matSteMgmtEv.sccpState = mgmntParam->sccpState;
#else
   matSteMgmtEv.ril = MAT_DEF_RIL;
   matSteMgmtEv.sccpState = MAT_DEF_SCCP_STATE;
#endif /* STUV2 */

  MaUiMatSteInd(&s->maPstMU, s->suId, steMgmt, matSteMgmtEv);
#else  /* MATV2 */
  MaUiMatSteInd(&s->maPstMU, s->suId, steMgmt);
#endif /* MATV2 */

#ifdef STUV2
#ifdef ZJ
   cmTuRunTimeUpd(&zjCb.tuCb, CMTU_LISAP_CB, CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_MOD, (Void *)s);
   cmTuUpdPeer(&zjCb.tuCb);
#endif /* ZJ */
#endif

  RETVALUE(ROK);
} /* MaLiStuSteInd */ 

/*
*
*       Fun:   MaLiStuSteCfm    
*
*       Desc:  This function handles the State Confirm from TCAP  
*
*       Ret:   ROK 
*
*       Notes: NONE 
*
*       File:  ca_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaLiStuSteCfm 
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
CmSS7SteMgmt *steMgmt       /* SS7 State Management structure */
#ifdef STUV2
, StMgmntParam *mgmntParam
#endif /* STUV2 */
)
#else
#ifdef STUV2
PUBLIC S16  MaLiStuSteCfm (pst, suId, steMgmt, mgmntParam)
#else
PUBLIC S16  MaLiStuSteCfm (pst, suId, steMgmt)
#endif
Pst        *pst;            /* post structure */
SuId       suId;            /* service user id */
CmSS7SteMgmt *steMgmt;      /* SS7 State Management structure */
#ifdef STUV2
StMgmntParam *mgmntParam;
#endif /* STUV2 */
#endif
{
  MaSap *s;
#ifdef MATV2
  MatSteMgmtEv matSteMgmtEv;          /* ril and SCCP state */
#endif

  TRC3(MaLiStuSteCfm)
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if ((SGetXxCb (pst->dstProcId, pst->dstEnt, pst->dstInst, (Void *) &maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA405, 0," MaLiStuSteCfm () failed, cannot derive maCb");
          RETVALUE(RFAILED);
   }

   MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
            "----------MAP-------(Proc (%d), Ent(%d), Inst(%d)) ------------\n",
            pst->dstProcId, pst->dstEnt, pst->dstInst));

#endif
  MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
         "MaLiStuSteCfm(pst, suId(%d), steMgmt(0x%lx))\n",
          suId, (PTR) steMgmt));

   /* If not active then don't accept the state change confirm */
#ifdef ZJ
   if (!cmTuChkRsetStatus(&zjCb.tuCb, TRUE))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_INT_PAR, EMA065, (ErrVal)0, 
                "MaUiMatSteCfm(): Invalid PSF state.");
#endif
      maSendAlrm(NEW,suId, MA_UNUSED, MA_UNUSED, "MaUiMatSteCfm",
                 LCM_EVENT_UI_INV_EVT,LCM_CATEGORY_INTERFACE,
                 LCM_CAUSE_PROT_NOT_ACTIVE);

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
      "MaUiMatSteCfm(pst, suId(%d))failed, Invalid PSF state.\n", suId));

      RETVALUE(RFAILED);
   }
#endif /* ZJ */

  if (suId >= (SuId)maCb.maCP.nmbMAUSaps || suId < 0 || 
      ((s = *(maCb.maSapLmaPtr + suId)) == (MaSap *)NULLP))
  {
     maSendAlrm(NEW,suId, STMATSAP, LMA_BAD_SAPID, "MaLiStuSteCfm",
               LCM_EVENT_LI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_SUID);
     MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
     "MaLiStuSteCfm() failed, invalid suId(%d).\n",suId));
     RETVALUE(RFAILED);
  }

   if (s->maState != MA_BND_ENABLED)
   {
      maSendAlrm(NEW,suId, STMATSAP, LMA_BAD_SAP_STATE, "MaLiStuSteCfm",
               LCM_EVENT_LI_INV_EVT,LCM_CATEGORY_INTERFACE,LCM_CAUSE_INV_STATE);
      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
      "MaLiStuSteCfm() failed, invalid SAP state(%d).\n",s->maState));
      RETVALUE(RFAILED);
   }

#ifdef STUV2
   s->ril = mgmntParam->ril;
#endif

#ifdef MATV2
#ifdef STUV2
   matSteMgmtEv.ril = mgmntParam->ril;
   matSteMgmtEv.sccpState = mgmntParam->sccpState;
#else
   matSteMgmtEv.ril = MAT_DEF_RIL;
   matSteMgmtEv.sccpState = MAT_DEF_SCCP_STATE;
#endif /* STUV2 */

  MaUiMatSteCfm(&s->maPstMU, s->suId, steMgmt, matSteMgmtEv);
#else  /* MATV2 */
  MaUiMatSteCfm(&s->maPstMU, s->suId, steMgmt);
#endif /* MATV2 */

#ifdef STUV2
#ifdef ZJ
   cmTuRunTimeUpd(&zjCb.tuCb, CMTU_LISAP_CB, CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_MOD, (Void *)s);
   cmTuUpdPeer(&zjCb.tuCb);
#endif /* ZJ */
#endif

  RETVALUE(ROK);
} /* MaLiStuSteCfm */ 

/*
*     interface functions to system services
*/
  
/*
*
*       Fun:   Activate Task - timer
*
*       Desc:  Invoked by system services to activate a task with
*              a timer tick.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ca_bdy1.c
*
*/
  
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
#ifdef ANSI
PUBLIC S16 maActvTmr
(
ProcId  proc,
Ent     ent,    
Inst    inst    
)
#else
PUBLIC S16 maActvTmr(proc, ent, inst)
ProcId  proc;
Ent     ent;    
Inst    inst;   
#endif
#else  
#ifdef ANSI
PUBLIC S16 maActvTmr
(
void
)
#else
PUBLIC S16 maActvTmr()
#endif
#endif
{
   TRC2(maActvTmr)  
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Addition of check for maCbptr for NULLP */
   if((SGetXxCb(proc, ent, inst, (Void **)&maCbPtr) != ROK) || (maCbPtr == NULLP))
   {
    /* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
	avoid core dump in case of maCbPtr is NULL */ 
     SLOGERROR(ent,inst, proc, __FILE__, __LINE__,
               ERRCLS_DEBUG, EMA383, 0, "maActvTmr() failed, cannot derive maCb");
       RETVALUE(RFAILED);
    }
#endif
   cmPrcTmr(&maCb.maTqCp, maCb.maTq, (PFV) maTmrEvnt);
   RETVALUE(ROK);
} /* end of maActvTmr */
  
/*
*
*       Fun:   Activate Task - initialize
*
*       Desc:  Invoked by system services to initialize a task.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ca_bdy1.c
*
*/
  
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef ANSI
PUBLIC S16 maActvInit
(
#ifdef SS_MULTIPLE_PROCS
ProcId   procId,
#endif
Ent ent,                      /* entity */
Inst inst,                    /* instance */
Region region,                /* region */
#ifdef SS_MULTIPLE_PROCS
Reason reason,                /* reason */
Void  **xxCb                  /* Control Block */
#else
Reason reason                 /* reason */
#endif
)
#else
#ifdef SS_MULTIPLE_PROCS
PUBLIC S16 maActvInit(procId, ent, inst, region, reason, xxCb)
#else
PUBLIC S16 maActvInit(ent, inst, region, reason)
#endif
#ifdef SS_MULTIPLE_PROCS
ProcId   procId;
#endif
Ent ent;                      /* entity */
Inst inst;                    /* instance */
Region region;                /* region */
Reason reason;                /* reason */
#ifdef SS_MULTIPLE_PROCS
Void  **xxCb;
#endif
#endif
{
   S16 i = 0;                     /* loop counter */
#ifdef SS_MULTIPLE_PROCS

/* ma013.203 : Modification,maNumCallsToInit is removed and maFirstCall is added
               "used" flag should true after layer shutdown
               SSI will call maActvInit with reason NRM_TERM in SDRegTTsk
              */
   PRIVATE Bool maFirstCall = FALSE;
   U16 idx=0;
   TRC2(maActvInit)
   if(reason == SHUTDOWN)
   {
#ifdef ZJ
      Void *tempPsfCb = maCb.psfCb;
#endif
      cmMemset((U8 * )&maCb, 0, sizeof(MaCb));
      maCb.used = TRUE;
      maCb.maInit.procId = procId;
#ifdef ZJ
      maCb.psfCb = tempPsfCb;
#endif
   }
   else if(reason == NRM_TERM)
   {
      cmMemset ((U8 *)*xxCb, 0,sizeof(MaCb));
      ((MaCb*)(*xxCb))->used = FALSE;
      RETVALUE(ROK);
    
   }
   else 
   {
	   if (!maFirstCall)
	   {
               maFirstCall = TRUE;
	      for (i=0; i< MA_MAX_INSTANCES; i++)
	         cmZero ((Data *)&maCbLst[i], sizeof (MaCb));
              idx = 0;
	   }
           else
              for(i=0; i<MA_MAX_INSTANCES; i++)
              {
                 if(maCbLst[i].used == FALSE)
                 {
                     maCbPtr = &maCbLst[i];
                     idx = i; 
                     break;  
                 } 
              }  	
            if(idx == MA_MAX_INSTANCES)
                 RETVALUE(FALSE);
            maCbLst[idx].used = TRUE;
            maCbPtr = &maCbLst[idx];
	   *xxCb = (Void *)&maCbLst[idx];
	   maCb.maInit.procId = procId;
#ifdef ZJ
           maCbPtr->psfCb = (Void *)&(zjCbLst[idx]);
#endif
   }

#endif
   

   /* zero out the layer control block */
   cmZero((Data *) &maCb.maInit, sizeof(TskInit));

   /* save initialization parameters */
   maCb.maInit.ent = ent;
   maCb.maInit.inst = inst;
   maCb.maInit.region = region;
   maCb.maInit.reason = reason;
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
   maCb.maInit.procId = procId;
#else
   maCb.maInit.procId = SFndProcId();
#endif


   /* timing queue control point for layer */
   (maCb.maTqCp).nxtEnt = 0;
   (maCb.maTqCp).tmrLen = MATQNUMENT;

   /* timing queue table: array of MATQNUMENT pointers */
   for(i=0;i<MATQNUMENT;i++)
   {
      maCb.maTq[i].first = (CmTimer *)NULLP;
      maCb.maTq[i].tail = (CmTimer *)NULLP;
   }

#ifdef MA_USTA
   maCb.maInit.usta = TRUE;
#else
   maCb.maInit.usta = FALSE;
#endif 

#ifdef DEBUGP
#ifdef MA_DEBUG
   maCb.maInit.dbgMask = g_maDbgMask;
#endif
#endif

   maCb.maSapLmaPtr = (MaSap **)NULLP;
   /* Initialize the General configuration structure */
   cmZero((Data *)&maCb.maCP, sizeof(MaGenCfg));
   maCb.maInvCnt = 0;

#ifdef MA_RUG
   /* Initialize fields related to interface version */   
   maCb.maNumIntfInfo = 0;
   maCb.maIntfInfo = (ShtVerInfo *)NULLP;
#endif /* MA_RUG */

#if MAP_REL99
#if (MAP_SEC && LMAV2)
   maCb.maSecPpiMask = 0;
   maCb.maPropCounter = 1;
   maCb.maNumOpCmp = 0;
   cmZero((Data *)&maCb.maOpCmp, MA_MAX_SEC_COMPS * sizeof(LmaSecOpComp));
   (void) maInitSecCp();
#endif /* MAP_SEC */
#endif

#ifdef ZJ
/* ma002.203 : Addition. Addnl support to aid in internal testing */
#ifdef SS_MULTIPLE_PROCS
/* ma013.203 : Modification idx contains the index of Cb */ 
   zjActvInit(procId, ent, inst, region, reason, xxCb);
#else
   zjActvInit(ent, inst, region, reason);
#endif
#endif /* ZJ */

   /* perform external initialization, if needed */
   /* (maInitExt is in file ma_ex_ms.c) */
   (Void) maInitExt();

   RETVALUE(ROK);
} /* end of maActvInit */

/********************************************************************30**

         End of file:     ca_bdy1.c@@/main/11 - Fri Sep 16 02:46:32 2005

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  aa    1. initial release

1.2          ---  aa    1. text changes

*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.3          ---      aa   1. Changed the internals of functions (now passing
                              explicit paramters required by the each function 
                              instead of passing just the pointer to SAP structure.
             ---      aa   2. Don't send the Delimeter Indication on receipt of
                              TC_END.ind
 
             ---      aa   3. Fixed the bug in MaLiLmaCfgReq
 
1.4          ---      sg   1. Fixed a bug in MaUiMatOpenReq
 
             ---      sg   2. Added code to generate MaUiMatNotInd in
                              MaLiStuNotInd
 
             ---      sg   3. Fixed dialogue state changes to be done before
                              requests or indications. 
 
             ---      sg   4. Incorrect parameter to maSendAlarm in abort request

             ---      ssk  5. Added MAP GSM Phase 2+ variant                     
1.5          ---      ssk  1. maInvCnt global definition.
             ---           2. Initialization for maInvCnt.
             ---           3. Reconfiguration stuff for the gaurd timer.
             ---           4. message buffer has to be freed before 
                              returning from the StuDatInd() because
                              of the failure in allocating the dialogue
                              identifier 
             ---      ssk  5. Zero the dialogue map memory allocated.
             ---      ssk  6. phase 2+ gpr release .                  
             ---      ssk  7. User Over load check failed response code 
                              related change.

             ---      ssk  7. Static memory allocation for the huge    
                              event structures used during encode &
                              decode.

             ---      ssk  8. dstInst must be assigned to src Instance 
                              of the pst structure.                 

             ---      ssk  9. number of active dialogues incremented at the
                              MaUiMatOpenReq() function.
 
             ---      ssk 10. max. dialogue check must be made after the state
                              check inside the MaUiMatOpenReq().


             ---      ssk 11. Responding address in the open Response related 
                              change.                             

             ---      ssk 12. endif preprocessor directive flag is commented .

             ---      ssk 13. Normal close request from the dialogue which 
                              is in dialogue initiated state will be processed 
                              by the GSM state machine. 

             ---      ssk 14. Fixed the selector problem in SteInd & Cfm.  
                              Added State bound check to the Ste primitives.   

             ---      ssk 15. Sent the pre arranged close when the 
                              dlg.Id allocation Fails in the open 
                              indication. Sent a notice Indication when 
                              the dialogue id allocation 
                              Fails in the open request. 

             ---      ssk 16. retOpt configurable option related change. 
                              retOpt configured by the LM in the SAP
                              configuration structure is copied in to 
                              the Qos Set structure of SAP structure. 

             ---      ssk 17. reion and pool passed correctly for SGetSBuf.

             ---      jz  18. pClass configurable option related change. 
                              pClass configured by the LM in the SAP
                              configuration structure is copied in to 
                              the Qos Set structure of SAP structure. 

             ---      jz  19. tmpSuDlgId and tmpSpDlgId were added to avoid
                              losing newly opened dialogs.

             ---      jz   1. Added group SAP enable/disable control request.
                           2. Modified IaUiIatBndReq, IaUiIatUbndReq and 
                              IaLiStuBndCfm for upper and lower state.
                           3. Changes for TCR18,
                           4. Extern definition of ItMiShtCntrlReq and 
                              ItMiShtCntrlCfm added
                           5. System agent cntrl Rqst function added.

/main/6      ---      jie  1. update for MAP 1.5 release.

             ---      jie  1. change usta value when MA_USTA is defined.
                           2. SAP pst structure is used in MaMiShtCntrlReq.
                           3. Return value check from bind enable and 
                              unbind disable functions are removed after
                              referring appropriate post structure field
                              for comparision inside MaMiShtCntrlReq(). 

             ---      ssk  1. Moved SPutSMem after all SPutSBufs inside  
                              two failure cases with CfgReq().
                           2. maInit.lmPst is copied to maCP.smPst  in 
                              the re-configuration of general kind. 
                           3. uiState and liState are initialize inside 
                              SAP configuration. 

             ---      jie  1. Rolling Upgrade compliance.

             ---      yz   1. Change code to accept OpenRsp immiediately 
                              after send OpenInd and store the Open response
                              impact.

             ---      yz   1. Adding debug print for RFAILED case. 
                           2. Modify code in MaUiMatCloseReq() to allow
                              close request at dialog idle state.

             ---      yz   1. Modify some DBGP to compliant with SUN CC.

             ---      jie  1. Added initialization for the debug mask.

             ---      yz   2. Change to add extCont to dlgPdu.

             ---      yz   1. Idle dialogue due to error open rsp.
                           2. Checking dlgCp after procedure return 
                              in MaLiStuCmpInd().

             ---      jie  1. Changed to TRC3 for layer interface functions.
                           2. bitmap size calculation is corrected.

/main/7      ---      jie  1. update for MAP 1.6 release.

             ---      yz   1. Addition of MAP segmentation feature from 1.5

                           2. Reset maDlgIdPool value after maAllocDlgId
                              return failure.

             ---      yz   1. Addition of MAP Segmentation feature.

             ---      jie  1. Change for 2002/09 rel99/rel4 release.

/main/8      ---      jie  1. update for MAP 1.7 release.

             ---      jie  1. Moved the delimiter ind after restoreOpenRsp.

             ---      ssk  1. Changes related to flexibly tune the MTP3    
                              priority and SCCP class.

/main/10     ---      zj   1. PSF-MAP changes.
                      cp   2. Removed STU2 and MAT_INTF2 flags
             ---      st   1. Introduced checking for NULLP on MAT interface.
                           2. Removed code that was decrementing nmbActvdlg twice.  
             ---      st   3. dlg state in MaUiMatOpenReq MaUiMatOpenRsp
                              MaUiMatCloseReq and MaUiMatAbrtReq might
                              change in case of tightly coupled calls
                              for the same dialogue. Calls to maDlgIdle
                              were placed before calling interface
                              primitives (MaUiMatOpenCfm,MaUiMatStatInd)

/main/11     ---    rbabu  1. Update for MAP 2.3 release.
ma001.203	      st   1. Added Single Sap Enable/Disable 
			      functionality in MaMiLmaCntrlReq.
			   2. Initialized dataParam element.
ma002.203             dv   1. Introduced maCb global control block.
                           2. Moved global variables to maCb.
                           3. Introduced SS_MULTIPLE_PROCS to aid
                              in internal testing.
/main/11  ma009.203   dm   1. Modification :Changed MALOGERROR macro to SLOGERRO                              R to avoid core dump in case of maCbPtr is NULL 
/main/11  ma012.203   dm   1. Added to support Dlg Hash Size as configurator
                              paramater through layer manager.
                           2. Introduced MAP_NSRP flag.
                           3. MAP security feature supported as configurable
                           4. Introduced MAP_SEC_RECFG.
   
/main/11 ma013.203   dm    1. Modification,maNumCallsToInit is removed and
                              maFirstCall is added
                              "used" flag should true after layer shutdown
                               SSI will call maActvInit with reason NRM_TERM 
                              in SDRegTTsk.
                           2. Addition of check for maCbptr for NULLP. 
/main/11 ma014.203   dm    1. After Reteriving  dlgCp, assign it to curDlgCp.
                           2. Validate the dlgCp after sending Notice Ind.
                           3. If spDlgId is 0 in Notice Ind return RFAILED.  
*********************************************************************91*/
