/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     map - portable - upper interface
  
     Type:     C source file
  
     Desc:     C source code for the map upper interface primitives.

     File:     ma_ptui.c
  
     Sid:      ma_ptui.c@@/main/9 - Fri Sep 16 02:45:58 2005
  
     Prg:      aa
  
*********************************************************************21*/


/*
  
The following functions are provided in this file:

     MaUiMatOpenInd      ma - upper inteface - MAP Open Indication
     MaUiMatCloseInd     ma - upper inteface - MAP Close Indication
     MaUiMatDelimInd     ma - upper inteface - MAP Delimeter Indication
     MaUiMatNotInd       ma - upper inteface - MAP Notice Indication
     MaUiMatAbrtInd      ma - upper inteface - MAP Abrt Indication
     MaUiMatOpenCfm      ma - upper inteface - MAP Open Confirm
     MaUiMatStatInd      ma - upper inteface - Status Indication   

     Service specific functions 

     MaUiMatLocMgmtInd     ma - upper inteface - Location Management Indication
     MaUiMatLocMgmtCfm     ma - upper inteface - Location Management Confirm
     MaUiMatHOMgmtInd      ma - upper inteface - Handover Management Indication
     MaUiMatHOMgmtCfm      ma - upper inteface - Handover Management Confirm
     MaUiMatAuthMgmtInd    ma - upper inteface - Authintication Management Indication
     MaUiMatAuthMgmtCfm    ma - upper inteface - Authintication Management Confirm
     MaUiMatIMEIMgmtInd    ma - upper inteface - IMEI Indication
     MaUiMatIMEIMgmtCfm    ma - upper inteface - IMEI Confirm
     MaUiMatSubMgmtInd    ma - upper inteface - Subscriber Management Indication
     MaUiMatSubMgmtCfm    ma - upper inteface - Subscriber Management Confirm
     MaUiMatFRMgmtInd      ma - upper inteface - Fault/Recovery Management Indication
     MaUiMatFRMgmtCfm      ma - upper inteface - Fault/Recovery Management Confirm
     MaUiMatOAMInd         ma - upper inteface - OAM Management Indication
     MaUiMatOAMCfm         ma - upper inteface - OAM Management Confirm
     MaUiMatCallMgmtInd    ma - upper inteface - Call Management Indication
     MaUiMatCallMgmtCfm    ma - upper inteface - Call Management Confirm
     MaUiMatSSInd          ma - upper inteface - Supplementry Services Indication
     MaUiMatSSCfm          ma - upper inteface - Supplementry Services Confirm
     MaUiMatSMInd          ma - upper inteface - Short Messages  Indication
     MaUiMatSMCfm          ma - upper inteface - Short Message Confirm
     MaUiMatNwReqPdpCntxtActvInd          ma - upper inteface - Pdp Cntxt Act.  Indication
     MaUiMatNwReqPdpCntxtActvCfm           ma - upper inteface - Pdp Cntxt Act.Confirm

It should be noted that not all of these functions may be required
by a particular MAP layer service user.

It is assumed that the following functions are provided in the MAP level:

     MaUiMatBndReq       ma - upper interface - Bind Request
     MaUiMatUbndReq      ma - upper interface - Unbind Request
  
     MaUiMatOpenReq      ma - upper interface - Open Request
     MaUiMatOpenRsp      ma - upper interface - Open Response
     MaUiMatCloseReq     ma - upper interface - Close Request
     MaUiMatDelimReq     ma - upper interface - Delimeter Request
     MaUiMatAbrtReq      ma - upper interface - Abort Request

     Service specific 
  
     MaUiMatLocMgmtReq     ma - upper inteface - Location Management Request
     MaUiMatLocMgmtRsp     ma - upper inteface - Location Management Response
     MaUiMatHOMgmtReq      ma - upper inteface - Handover Management Request
     MaUiMatHOMgmtRsp      ma - upper inteface - Handover Management Response
     MaUiMatAuthMgmtReq    ma - upper inteface - Authintication Management Request
     MaUiMatAuthMgmtRsp    ma - upper inteface - Authintication Management Response
     MaUiMatIMEIMgmtReq    ma - upper inteface - IMEI Request
     MaUiMatIMEIMgmtReq    ma - upper inteface - IMEI Response
     MaUiMatSubMgmtReq    ma - upper inteface - Subscriber Management Request
     MaUiMatSubMgmtRsp    ma - upper inteface - Subscriber Management Response
     MaUiMatFRMgmtReq      ma - upper inteface - Fault/Recovery Management Request
     MaUiMatFRMgmtRsp      ma - upper inteface - Fault/Recovery Management Response
     MaUiMatOAMReq         ma - upper inteface - OAM Management Request
     MaUiMatOAMRsp         ma - upper inteface - OAM Management Response
     MaUiMatCallMgmtReq    ma - upper inteface - Call Management Request
     MaUiMatCallMgmtRsp    ma - upper inteface - Call Management Response
     MaUiMatSSReq          ma - upper inteface - Supplementry Services Request
     MaUiMatSSRsp          ma - upper inteface - Supplementry Services Response
     MaUiMatSMReq          ma - upper inteface - Short Messages  Request
     MaUiMatSMRsp          ma - upper inteface - Short Message Response
     MaUiMatNwReqPdpCntxtActvReq          ma - upper inteface - Pdp Cntxt Act.  Request
     MaUiMatNwReqPdpCntxtActvRsp           ma - upper inteface - Pdp Cntxt Act.Response
*/


/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common SS7 */
#include "lma.h"           /* layer management, MAP */
#ifdef MA_FTHA
#include "sht.h"
#endif /* MA_FTHA */
#include "cm5.h"
#include "cm_err.h"        /* common error */
#include "stu.h"           /* tcap layer */
#include "mat.h"           /* map layer */
#include "ma.h"            /* map */
#include "ma_mf.h"         /* map */
#include "ma_err.h"        /* map error */
#ifdef ZJ
#include "cm_ftha.h"       /* Common FTHA */
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#include "cm_tupsf.h"      /* Common TCAP user PSF */
#endif /* ZJ */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"
#include "cm_ss7.x"        /* ss7 layer */
#include "stu.x"           /* tcap layer */
#include "lma.x"           /* layer management, TCAP */
#include "mat.x"           /* map  layer */
#ifdef MA_FTHA
#include "sht.x"
#endif /* MA_FTHA */
#ifdef ZJ
#include "cm_ftha.x"       /* Common FTHA */
#include "cm_pftha.x"      /* Common PSF defines */
#include "cm_psfft.x"
#include "cm_tupsf.x"      /* Common TCAP user PSF */
#endif /* ZJ */
#include "ma.x"            /* map  layer */
  

/* local defines */

/* local typedefs */
  
/* local externs */
 
/* forward references */

/* portable functions */
#if (!(defined(LCMAUIMAT) && defined(AU) && defined(LWLCMAUIMAT)))

PRIVATE S16 PtUiMatOpenInd  ARGS((Pst *pst, 
                                  SuId suId,
                                  MaDlgId suDlgId,
                                  MaDlgId spDlgId,
                                  MaOpenEv *openEv));

PRIVATE S16 PtUiMatOpenCfm  ARGS((Pst *pst, 
                                  SuId suId,
                                  MaDlgId suDlgId,
                                  MaDlgId spDlgId,
                                  MaOpenEv *openEv));

PRIVATE S16 PtUiMatDelimInd ARGS((Pst *pst, 
                                  SuId suId,
                                  MaDlgId suDlgId,
                                  MaDlgId spDlgId));

PRIVATE S16 PtUiMatCloseInd ARGS((Pst *pst, 
                                  SuId suId,
                                  MaDlgId suDlgId,
                                  MaDlgId spDlgId,
                                  MaCloseEv *closeEv));

PRIVATE S16 PtUiMatAbrtInd  ARGS((Pst *pst, 
                                  SuId suId,
                                  MaDlgId suDlgId,
                                  MaDlgId spDlgId,
                                  MaAbrtEv *abrtEv));

PRIVATE S16 PtUiMatNotInd   ARGS((Pst *pst, 
                                  SuId suId,
                                  MaDlgId suDlgId,
                                  MaDlgId spDlgId,
                                  RCause  cause));

PRIVATE S16 PtUiMatDlgCfm   ARGS((Pst *pst, 
                                  SuId suId,
                                  MaDlgId suDlgId,
                                  MaDlgId spDlgId));

PRIVATE S16 PtUiMatStatInd ARGS((Pst *pst,
                                SuId suId,
                                MaDlgId  suDlgId,
                                MaInvokeId *invkId,
                                U8         primType,
                                Status status));

#ifdef MATV2
PRIVATE S16 PtUiMatSteInd   ARGS((Pst *pst, 
                                  SuId suId,
                                  CmSS7SteMgmt *steMgmt,
                                  MatSteMgmtEv matSteMgmtEv));

PRIVATE S16 PtUiMatSteCfm   ARGS((Pst *pst, 
                                  SuId suId,
                                  CmSS7SteMgmt *steMgmt,
                                  MatSteMgmtEv matSteMgmtEv));
#else
PRIVATE S16 PtUiMatSteInd   ARGS((Pst *pst, 
                                  SuId suId,
                                  CmSS7SteMgmt *steMgmt));

PRIVATE S16 PtUiMatSteCfm   ARGS((Pst *pst, 
                                  SuId suId,
                                  CmSS7SteMgmt *steMgmt));
#endif /* MATV2 */

PRIVATE S16 PtUiMatBndCfm ARGS(( Pst *pst , SuId suId, U8 status));

/* --------------- Handover Management ----------------------------- */
#if MAP_MSC
/* Handover Indication and Confirm */

PRIVATE S16 PtUiMatHOMgmtInd ARGS  ((Pst *pst,
                                     SuId suId,
                                     MaDlgId suDlgId,
                                     MaDlgId spDlgId,
                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                     MaHoEv *hoEv));

PRIVATE S16 PtUiMatHOMgmtCfm ARGS  ((Pst *pst,
                                     SuId suId,
                                     MaDlgId suDlgId,
                                     MaDlgId spDlgId,
                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                     MaUsrErr   *usrErr,
                                     MaPrvErr   *prvErr,
                                     MaHoEv     *hoEv));
#endif /* MAP_MSC */

/* --------------- Location Management ----------------------------- */
#if (MAP_VLR || MAP_HLR || MAP_GSN)
/* Location Management Confirm */
PRIVATE S16 PtUiMatLocMgmtCfm ARGS ((Pst *pst,
                                     SuId suId,
                                                     MaDlgId suDlgId,
                                                     MaDlgId spDlgId,
                                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                                     MaUsrErr   *usrErr,
                                                     MaPrvErr   *prvErr,
                                                     MaLocEv *locEv));

/* Location Management Indication */
PRIVATE S16 PtUiMatLocMgmtInd ARGS ((Pst *pst,
                                     SuId suId,
                                                     MaDlgId suDlgId,
                                                     MaDlgId spDlgId,
                                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                                     MaLocEv *locEv));


#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#ifdef XWEXT /* xingzhou.xu: xinwei management */
PRIVATE S16 PtUiMatXWMgmtCfm ARGS (
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,          /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaXWDetectEv *dectecthEv     /* Authintication Event Structure */
));

PRIVATE S16 PtUiMatXWMgmtInd ARGS (
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaXWDetectEv *detectEv     /* Detect Event Structure */
));

#endif /* XWEXT */
/* --------------- Authentication Management ------------------------ */
#if (MAP_VLR || MAP_GSN)
/* Authentication Management Confirm */
PRIVATE S16 PtUiMatAuthMgmtCfm ARGS ((Pst *pst,
                                     SuId suId,
                                                     MaDlgId suDlgId,
                                                     MaDlgId spDlgId,
                                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                                     MaUsrErr   *usrErr,
                                                     MaPrvErr   *prvErr,
                                                     MaAuthEv *authEv));


#endif /* MAP_VLR || MAP_GSN */

#if MAP_HLR
/* Authentication Management Indication */
PRIVATE S16 PtUiMatAuthMgmtInd ARGS ((Pst *pst,
                                     SuId suId,
                                     MaDlgId suDlgId,
                                     MaDlgId spDlgId,
                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                     MaAuthEv *authEv));
#endif /* MAP_HLR */

/* --------------- Identification Management ------------------------ */
#if MAP_VLR
/* IMEI Management Indication and Confirm */
PRIVATE S16 PtUiMatIMEIMgmtInd ARGS((Pst *pst,
                                     SuId suId,
                                     MaDlgId suDlgId,
                                     MaDlgId spDlgId,
                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                     MaIMEIEv *imeiEv));
#endif /* MAP_VLR */

#if (MAP_MSC || MAP_GSN)
PRIVATE S16 PtUiMatIMEIMgmtCfm ARGS ((Pst *pst,
                                     SuId suId,
                                     MaDlgId suDlgId,
                                     MaDlgId spDlgId,
                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                     MaUsrErr   *usrErr,
                                     MaPrvErr   *prvErr,
                                     MaIMEIEv *imeiEv));

#endif /* MAP_MSC || MAP_GSN */

/* --------------- Fault and Recovery Management -------------------- */
#if (MAP_VLR || MAP_HLR)
/* Fault and Revovery Management Request and Confirm */
PRIVATE S16 PtUiMatFRMgmtCfm ARGS  ((Pst *pst,
                                     SuId suId,
                                     MaDlgId suDlgId,
                                     MaDlgId spDlgId,
                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                     MaUsrErr   *usrErr,
                                     MaPrvErr   *prvErr,
                                     MaFREv     *frEv));


#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
/* Fault and Revovery Management Indication and Response */
PRIVATE S16 PtUiMatFRMgmtInd ARGS  ((Pst *pst,
                                     SuId suId,
                                     MaDlgId suDlgId,
                                     MaDlgId spDlgId,
                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                     MaFREv     *frEv));

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

/* --------------- OAM Management ----------------------------------- */
#if (MAP_MSC || MAP_VLR || MAP_HLR)
/* OAM Confirm */
PRIVATE S16 PtUiMatOAMCfm ARGS     ((Pst *pst,
                                     SuId suId,
                                     MaDlgId suDlgId,
                                     MaDlgId spDlgId,
                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                     MaUsrErr   *usrErr,
                                     MaPrvErr   *prvErr,
                                     MaOAMEv *oamEv));

#endif /* MAP_MSC || MAP_VLR || MAP_HLR */

#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)
/* OAM Indication */
PRIVATE S16 PtUiMatOAMInd ARGS     ((Pst *pst,
                                     SuId suId,
                                     MaDlgId suDlgId,
                                     MaDlgId spDlgId,
                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                     MaOAMEv     *oamEv));
#endif /* MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN */

/* --------------- Call Management ----------------------------------- */
#if (MAP_MSC || MAP_VLR || MAP_HLR)
/* Call Management Indication and Confirm */
PRIVATE S16 PtUiMatCallMgmtInd ARGS ((Pst *pst,
                                     SuId suId,
                                     MaDlgId suDlgId,
                                     MaDlgId spDlgId,
                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                     MaCallEv *callEv));

PRIVATE S16 PtUiMatCallMgmtCfm ARGS ((Pst *pst,
                                     SuId suId,
                                     MaDlgId suDlgId,
                                     MaDlgId spDlgId,
                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                     MaUsrErr   *usrErr,
                                     MaPrvErr   *prvErr,
                                     MaCallEv *callEv));
#endif /* MAP_MSC || MAP_VLR || MAP_HLR */

/* --------------- Supplementary Services Management ----------------- */
/* Supplementary Services Indication and Confirm */
#if (MAP_VLR || MAP_HLR)
PRIVATE S16 PtUiMatSSInd ARGS      ((Pst *pst,
                                     SuId suId,
                                     MaDlgId suDlgId,
                                     MaDlgId spDlgId,
                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                     MaInvokeId *lnkId,
                                     MaSSEv *ssEv));
#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR)
PRIVATE S16 PtUiMatSSCfm ARGS      ((Pst *pst,
                                     SuId suId,
                                     MaDlgId suDlgId,
                                     MaDlgId spDlgId,
                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                     MaUsrErr   *usrErr,
                                     MaPrvErr   *prvErr,
                                     MaSSEv *ssEv));
#endif /* MAP_HLR */

/* --------------- Short Message Services Management ------------------ */
#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)
/* Short Message Services Confirm */
PRIVATE S16 PtUiMatSMCfm ARGS      ((Pst *pst,
                                     SuId suId,
                                     MaDlgId suDlgId,
                                     MaDlgId spDlgId,
                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                     MaUsrErr   *usrErr,
                                     MaPrvErr   *prvErr,
                                     MaSMEv *smEv));

#endif /* MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_MSC || MAP_HLR || MAP_GSN)
/* Short Message Services Indication */
PRIVATE S16 PtUiMatSMInd ARGS      ((Pst *pst,
                                     SuId suId,
                                     MaDlgId suDlgId,
                                     MaDlgId spDlgId,
                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                     MaSMEv *smEv));
#endif /* MAP_MSC || MAP_HLR || MAP_GSN */

/* --------------- Subscriber Management ------------------------------ */
#if (MAP_VLR || MAP_HLR || MAP_GSN || MAP_MLC)
/* Subscriber Management Request, Indication, Response and Confirm */
PRIVATE S16 PtUiMatSubMgmtInd ARGS ((Pst *pst,
                                     SuId suId,
                                     MaDlgId suDlgId,
                                     MaDlgId spDlgId,
                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                     MaSubEv *subEv));
#endif /* MAP_VLR || MAP_HLR || MAP_GSN  || MAP_MLC*/

#if (MAP_VLR || MAP_HLR || MAP_GSN)
PRIVATE S16 PtUiMatSubMgmtCfm ARGS ((Pst *pst,
                                     SuId suId,
                                     MaDlgId suDlgId,
                                     MaDlgId spDlgId,
                                     MaInvokeId *invkId,
                                     MaOprType  locOpr,
                                     MaUsrErr   *usrErr,
                                     MaPrvErr   *prvErr,
                                     MaSubEv *subEv));

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

/* --------------- PDP Context Activation Management ------------------ */
#if (MAP_HLR || MAP_GSN)
/* PDP Context Activation Indication and Confirm */
PRIVATE S16 PtUiMatNwReqPdpCntxtActvInd ARGS ((Pst *pst,
                                               SuId suId,
                                               MaDlgId suDlgId,
                                               MaDlgId spDlgId,
                                               MaInvokeId *invkId,
                                               MaOprType  locOpr,
                                               MaPdpActvEv *pdpActvEv));
 
PRIVATE S16 PtUiMatNwReqPdpCntxtActvCfm ARGS      ((Pst *pst,
                                                    SuId suId,
                                                    MaDlgId suDlgId,
                                                    MaDlgId spDlgId,
                                                    MaInvokeId *invkId,
                                                    MaOprType  locOpr,
                                                    MaUsrErr   *usrErr,
                                                    MaPrvErr   *prvErr,
                                                    MaPdpActvEv *pdpActvEv));
#endif /* MAP_HLR || MAP_GSN */

#if (MAP_REL98 || MAP_REL99)

/* --------------- Location Services Management ------------------ */
/* Location Services Indication and Confirm */
#if (MAP_MSC || MAP_HLR || MAP_MLC || (MAP_REL99 && MAP_REL4 && MAP_GSN))
PRIVATE S16 PtUiMatLocServInd ARGS ((Pst *pst,
                                               SuId suId,
                                               MaDlgId suDlgId,
                                               MaDlgId spDlgId,
                                               MaInvokeId *invkId,
                                               MaOprType  locOpr,
                                               MaLocServEv *locServvEv));

#endif /* MAP_MSC || MAP_HLR */

#if (MAP_MSC || MAP_MLC || (MAP_REL99 && MAP_REL4 && MAP_GSN))
PRIVATE S16 PtUiMatLocServCfm ARGS      ((Pst *pst,
                                                    SuId suId,
                                                    MaDlgId suDlgId,
                                                    MaDlgId spDlgId,
                                                    MaInvokeId *invkId,
                                                    MaOprType  locOpr,
                                                    MaUsrErr   *usrErr,
                                                    MaPrvErr   *prvErr,
                                                    MaLocServEv *locServEv));
#endif /* MAP_MLC */
#endif /* MAP_REL98 || MAP_REL99 */
#endif /* (!(defined(LCMAUIMAT) && defined(AU) && defined(LWLCMAUIMAT))) */

#ifdef AU
EXTERN S16 AuLiMatBndCfm ARGS(( Pst *pst,
                                SuId suId,
                                U8   status));
#endif


/* functions in other modules */
  
/* public variable declarations */
  
 
/*

the following matrices define the mapping between the primitives
called by the upper interface of MAP and the corresponding
primitives of the MAP service user(s).

The parameter MAXMAUI defines the maximum number of service users on
top of MAP. There is an array of functions per primitive
invoked by MAP. Every array is MAXMAUI long (i.e. there
are as many functions as the number of service users).

The dispatching is performed by the configurable variable: selector.
The selector is configured on a per SAP basis.

The selectors are:

   0 - loosely coupled -new interface-forward compatibility(#define LCMAUIMAT)
   1 - MAP USER (#define AU)
   2 - light weight loosely coupled (#define LWLCMAUIMAT)
*/

/* MAP Open Indication primitive */

PUBLIC MatOpenInd maUiOpenIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatOpenInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatOpenInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatOpenInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatOpenInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatOpenInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatOpenInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT/*for soft switch*/
   cmPkMatOpenInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatOpenInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT/*for hlr*/
   cmPkMatOpenInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatOpenInd,      /* 4 - loosely coupled, portable */
#endif
};

/* MAP Open Confirm primitive */

PUBLIC MatOpenCfm maUiOpenCfmMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatOpenCfm,      /* 0 - loosely coupled -fc */
#else
   PtUiMatOpenCfm,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatOpenCfm,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatOpenCfm,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatOpenCfm,      /* 2 - light weight loosely coupled */
#else
   PtUiMatOpenCfm,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatOpenCfm,      /* 3 - loosely coupled -fc */
#else
   PtUiMatOpenCfm,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatOpenCfm,      /* 4 - loosely coupled -fc */
#else
   PtUiMatOpenCfm,      /* 4 - loosely coupled, portable */
#endif
};

/* MAP Close Indication primitive */

PUBLIC MatCloseInd maUiCloseIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatCloseInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatCloseInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatCloseInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatCloseInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatCloseInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatCloseInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatCloseInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatCloseInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatCloseInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatCloseInd,      /* 4 - loosely coupled, portable */
#endif
};

/* MAP Delimeter Indication primitive */

PUBLIC MatDelimInd maUiDelimIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatDelimInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatDelimInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatDelimInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatDelimInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatDelimInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatDelimInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatDelimInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatDelimInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatDelimInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatDelimInd,      /* 4 - loosely coupled, portable */
#endif
};

/* MAP Abort Indication primitive */

PUBLIC MatAbrtInd maUiAbrtIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatAbrtInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatAbrtInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatAbrtInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatAbrtInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatAbrtInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatAbrtInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatAbrtInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatAbrtInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatAbrtInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatAbrtInd,      /* 4 - loosely coupled, portable */
#endif
};

/* MAP Notice Indication primitive */

PUBLIC MatNotInd maUiNotIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatNotInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatNotInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatNotInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatNotInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatNotInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatNotInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatNotInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatNotInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatNotInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatNotInd,      /* 4 - loosely coupled, portable */
#endif
};

/* MAP Dialogue Confirm primitive */

PUBLIC MatDlgCfm maUiDlgCfmMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatDlgCfm,      /* 0 - loosely coupled -fc */
#else
   PtUiMatDlgCfm,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatDlgCfm,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatDlgCfm,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatDlgCfm,      /* 2 - light weight loosely coupled */
#else
   PtUiMatDlgCfm,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatDlgCfm,      /* 3 - loosely coupled -fc */
#else
   PtUiMatDlgCfm,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatDlgCfm,      /* 4 - loosely coupled -fc */
#else
   PtUiMatDlgCfm,      /* 4 - loosely coupled, portable */
#endif
};

/* MAP Status Indication primitive */

PUBLIC MatStatInd maUiStatIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatStatInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatStatInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatStatInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatStatInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatStatInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatStatInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatStatInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatStatInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatStatInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatStatInd,      /* 4 - loosely coupled, portable */
#endif
};

/* MAP State Indication primitive */

PUBLIC MatSteInd maUiSteIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatSteInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatSteInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatSteInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatSteInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatSteInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatSteInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatSteInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatSteInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatSteInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatSteInd,      /* 4 - loosely coupled, portable */
#endif
};

/* MAP State Confirm primitive */

PUBLIC MatSteCfm maUiSteCfmMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatSteCfm,      /* 0 - loosely coupled -fc */
#else
   PtUiMatSteCfm,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatSteCfm,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatSteCfm,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatSteCfm,      /* 2 - light weight loosely coupled */
#else
   PtUiMatSteCfm,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatSteCfm,      /* 3 - loosely coupled -fc */
#else
   PtUiMatSteCfm,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatSteCfm,      /* 4 - loosely coupled -fc */
#else
   PtUiMatSteCfm,      /* 4 - loosely coupled, portable */
#endif
};

/* MAP Bind Confirm primitive */ 
PUBLIC MatBndCfm maUiBndCfmMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatBndCfm,      /* 0 - loosely coupled -fc */
#else
   PtUiMatBndCfm,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatBndCfm,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatBndCfm,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatBndCfm,      /* 2 - light weight loosely coupled */
#else
   PtUiMatBndCfm,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatBndCfm,      /* 3 - loosely coupled -fc */
#else
   PtUiMatBndCfm,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatBndCfm,      /* 4 - loosely coupled -fc */
#else
   PtUiMatBndCfm,      /* 4 - loosely coupled, portable */
#endif
};

/* ----------------------------------------------------------------- */
/*                 Service Specific Primitives                       */
/* ----------------------------------------------------------------- */

/* --------------- Handover Management ----------------------------- */
#if MAP_MSC
/* Handover Management Indication primitive */
 
PUBLIC MatHOMgmtInd maUiHOMgmtIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatHOMgmtInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatHOMgmtInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatHOMgmtInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatHOMgmtInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatHOMgmtInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatHOMgmtInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatHOMgmtInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatHOMgmtInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatHOMgmtInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatHOMgmtInd,      /* 4 - loosely coupled, portable */
#endif
};
 
/* Handover Management confirm primitive */
 
PUBLIC MatHOMgmtCfm maUiHOMgmtCfmMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatHOMgmtCfm,      /* 0 - loosely coupled -fc */
#else
   PtUiMatHOMgmtCfm,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatHOMgmtCfm,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatHOMgmtCfm,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatHOMgmtCfm,      /* 2 - light weight loosely coupled */
#else
   PtUiMatHOMgmtCfm,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatHOMgmtCfm,      /* 3 - loosely coupled -fc */
#else
   PtUiMatHOMgmtCfm,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatHOMgmtCfm,      /* 4 - loosely coupled -fc */
#else
   PtUiMatHOMgmtCfm,      /* 4 - loosely coupled, portable */
#endif
};

#endif /* MAP_MSC */

/* --------------- Location Management ----------------------------- */
#if (MAP_VLR || MAP_HLR || MAP_GSN)
/* Location Management Confirm primitive */
 
PUBLIC MatLocMgmtCfm maUiLocMgmtCfmMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatLocMgmtCfm,      /* 0 - loosely coupled -fc */
#else
   PtUiMatLocMgmtCfm,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatLocMgmtCfm,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatLocMgmtCfm,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatLocMgmtCfm,      /* 2 - light weight loosely coupled */
#else
   PtUiMatLocMgmtCfm,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT/*for soft switch*/
   cmPkMatLocMgmtCfm,      /* 3 - loosely coupled -fc */
#else
   PtUiMatLocMgmtCfm,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT /*for HLR*/
   cmPkMatLocMgmtCfm,      /* 4 - loosely coupled -fc */
#else
   PtUiMatLocMgmtCfm,      /* 4 - loosely coupled, portable */
#endif
};

/* Location Management Indication primitive */
 
PUBLIC MatLocMgmtInd maUiLocMgmtIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatLocMgmtInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatLocMgmtInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatLocMgmtInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatLocMgmtInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatLocMgmtInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatLocMgmtInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatLocMgmtInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatLocMgmtInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatLocMgmtInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatLocMgmtInd,      /* 4 - loosely coupled, portable */
#endif
};
 
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#ifdef XWEXT /* xingzhou.xu: xinwei management definition */
/*----------------- XINWEI Management -----------------------*/
/* XINWEI Management confirm primitive */
PUBLIC MatXWMgmtCfm maUiXWMgmtCfmMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatXWMgmtCfm,      /* 0 - loosely coupled -fc */
#else
   PtUiMatXWMgmtCfm,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatXWMgmtCfm,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatXWMgmtCfm,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatXWMgmtCfm,      /* 2 - light weight loosely coupled */
#else
   PtUiMatXWMgmtCfm,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatXWMgmtCfm,      /* 3 - loosely coupled -fc */
#else
   PtUiMatXWMgmtCfm,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatXWMgmtCfm,      /* 4 - loosely coupled -fc */
#else
   PtUiMatXWMgmtCfm,        /* 4 - loosely coupled, portable */
#endif
};

/* XINWEI Management Indication primitive */
 
PUBLIC MatXWMgmtInd maUiXWMgmtIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatXWMgmtInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatXWMgmtInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatXWMgmtInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatXWMgmtInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatXWMgmtInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatXWMgmtInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatXWMgmtInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatXWMgmtInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatXWMgmtInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatXWMgmtInd,      /* 4 - loosely coupled, portable */
#endif
};

#endif /* XWEXT */

/* --------------- Authentication Management ------------------------ */
#if (MAP_VLR || MAP_GSN)
/* Authentication Management confirm primitive */
 
PUBLIC MatAuthMgmtCfm maUiAuthMgmtCfmMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatAuthMgmtCfm,      /* 0 - loosely coupled -fc */
#else
   PtUiMatAuthMgmtCfm,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatAuthMgmtCfm,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatAuthMgmtCfm,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatAuthMgmtCfm,      /* 2 - light weight loosely coupled */
#else
   PtUiMatAuthMgmtCfm,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatAuthMgmtCfm,      /* 3 - loosely coupled -fc */
#else
   PtUiMatAuthMgmtCfm,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatAuthMgmtCfm,      /* 4 - loosely coupled -fc */
#else
   PtUiMatAuthMgmtCfm,      /* 4 - loosely coupled, portable */
#endif
};
#endif /* MAP_VLR || MAP_GSN */

#if MAP_HLR
/* Auth Management Indication primitive */
 
PUBLIC MatAuthMgmtInd maUiAuthMgmtIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatAuthMgmtInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatAuthMgmtInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatAuthMgmtInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatAuthMgmtInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatAuthMgmtInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatAuthMgmtInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatAuthMgmtInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatAuthMgmtInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatAuthMgmtInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatAuthMgmtInd,      /* 4 - loosely coupled, portable */
#endif
};
#endif /* MAP_HLR */

/* --------------- Identification Management ------------------------ */
#if MAP_VLR
/* IMEI Management indication primitive */
 
PUBLIC MatIMEIMgmtInd maUiIMEIMgmtIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatIMEIMgmtInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatIMEIMgmtInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatIMEIMgmtInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatIMEIMgmtInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatIMEIMgmtInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatIMEIMgmtInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatIMEIMgmtInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatIMEIMgmtInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatIMEIMgmtInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatIMEIMgmtInd,      /* 4 - loosely coupled, portable */
#endif
};
#endif /* MAP_VLR */

#if (MAP_MSC || MAP_GSN)
/* IMEI Management Confirm primitive */
 
PUBLIC MatIMEIMgmtCfm maUiIMEIMgmtCfmMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatIMEIMgmtCfm,      /* 0 - loosely coupled -fc */
#else
   PtUiMatIMEIMgmtCfm,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatIMEIMgmtCfm,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatIMEIMgmtCfm,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatIMEIMgmtCfm,      /* 2 - light weight loosely coupled */
#else
   PtUiMatIMEIMgmtCfm,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatIMEIMgmtCfm,      /* 3 - loosely coupled -fc */
#else
   PtUiMatIMEIMgmtCfm,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatIMEIMgmtCfm,      /* 4 - loosely coupled -fc */
#else
   PtUiMatIMEIMgmtCfm,      /* 4 - loosely coupled, portable */
#endif
};

#endif /* MAP_MSC || MAP_GSN */

/* --------------- Fault and Recovery Management -------------------- */
#if (MAP_VLR || MAP_HLR)
/* Fault and Recovery Management confirm primitive */
 
PUBLIC MatFRMgmtCfm maUiFRMgmtCfmMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatFRMgmtCfm,      /* 0 - loosely coupled -fc */
#else
   PtUiMatFRMgmtCfm,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatFRMgmtCfm,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatFRMgmtCfm,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatFRMgmtCfm,      /* 2 - light weight loosely coupled */
#else
   PtUiMatFRMgmtCfm,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatFRMgmtCfm,      /* 3 - loosely coupled -fc */
#else
   PtUiMatFRMgmtCfm,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatFRMgmtCfm,      /* 4 - loosely coupled -fc */
#else
   PtUiMatFRMgmtCfm,      /* 4 - loosely coupled, portable */
#endif
};

#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
/* Fault and Recovery Management Indication primitive */
 
PUBLIC MatFRMgmtInd maUiFRMgmtIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatFRMgmtInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatFRMgmtInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatFRMgmtInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatFRMgmtInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatFRMgmtInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatFRMgmtInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatFRMgmtInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatFRMgmtInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatFRMgmtInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatFRMgmtInd,      /* 4 - loosely coupled, portable */
#endif
};
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

/* --------------- OAM Management ----------------------------------- */
#if (MAP_MSC || MAP_VLR || MAP_HLR)
/* Operation and Maintenance confirm primitive */
 
PUBLIC MatOAMCfm maUiOAMCfmMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatOAMCfm,      /* 0 - loosely coupled -fc */
#else
   PtUiMatOAMCfm,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatOAMCfm,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatOAMCfm,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatOAMCfm,      /* 2 - light weight loosely coupled */
#else
   PtUiMatOAMCfm,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatOAMCfm,      /* 3 - loosely coupled -fc */
#else
   PtUiMatOAMCfm,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatOAMCfm,      /* 4 - loosely coupled -fc */
#else
   PtUiMatOAMCfm,      /* 4 - loosely coupled, portable */
#endif
};
#endif /* MAP_MSC || MAP_VLR || MAP_HLR */

#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)
/* Operation and Maintenance Indication primitive */
 
PUBLIC MatOAMInd maUiOAMIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatOAMInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatOAMInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatOAMInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatOAMInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatOAMInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatOAMInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatOAMInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatOAMInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatOAMInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatOAMInd,      /* 4 - loosely coupled, portable */
#endif
};
#endif /* MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN */

/* --------------- Call Management ----------------------------------- */
#if (MAP_MSC || MAP_VLR || MAP_HLR)
/* Call Management Indication primitive */
 
PUBLIC MatCallMgmtInd maUiCallMgmtIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatCallMgmtInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatCallMgmtInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatCallMgmtInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatCallMgmtInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatCallMgmtInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatCallMgmtInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatCallMgmtInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatCallMgmtInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatCallMgmtInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatCallMgmtInd,      /* 4 - loosely coupled, portable */
#endif
};

/* Call Management confirm primitive */
PUBLIC MatCallMgmtCfm maUiCallMgmtCfmMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatCallMgmtCfm,      /* 0 - loosely coupled -fc */
#else
   PtUiMatCallMgmtCfm,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatCallMgmtCfm,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatCallMgmtCfm,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatCallMgmtCfm,      /* 2 - light weight loosely coupled */
#else
   PtUiMatCallMgmtCfm,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatCallMgmtCfm,      /* 3 - loosely coupled -fc */
#else
   PtUiMatCallMgmtCfm,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatCallMgmtCfm,      /* 4 - loosely coupled -fc */
#else
   PtUiMatCallMgmtCfm,      /* 4 - loosely coupled, portable */
#endif
};


#endif /* MAP_MSC || MAP_VLR || MAP_HLR */

/* --------------- Supplementary Services Management ----------------- */
#if (MAP_VLR || MAP_HLR)
/* Supplementry Services Indication primitive */
 
PUBLIC MatSSInd maUiSSIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatSSInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatSSInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatSSInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatSSInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatSSInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatSSInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatSSInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatSSInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatSSInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatSSInd,      /* 4 - loosely coupled, portable */
#endif
};
#endif /* MAP_HLR */
 
#if (MAP_VLR || MAP_HLR)
/* Supplementry Services confirm primitive */
 
PUBLIC MatSSCfm maUiSSCfmMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatSSCfm,      /* 0 - loosely coupled -fc */
#else
   PtUiMatSSCfm,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatSSCfm,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatSSCfm,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatSSCfm,      /* 2 - light weight loosely coupled */
#else
   PtUiMatSSCfm,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatSSCfm,      /* 3 - loosely coupled -fc */
#else
   PtUiMatSSCfm,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatSSCfm,      /* 4 - loosely coupled -fc */
#else
   PtUiMatSSCfm,      /* 4 - loosely coupled, portable */
#endif
};

#endif /* MAP_VLR || MAP_HLR */

/* --------------- Short Message Services Management ------------------ */
#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)
/* Short Message confirm primitive */
 
PUBLIC MatSMCfm maUiSMCfmMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatSMCfm,      /* 0 - loosely coupled -fc */
#else
   PtUiMatSMCfm,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatSMCfm,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatSMCfm,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatSMCfm,      /* 2 - light weight loosely coupled */
#else
   PtUiMatSMCfm,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatSMCfm,      /* 3 - loosely coupled -fc */
#else
   PtUiMatSMCfm,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatSMCfm,      /* 4 - loosely coupled -fc */
#else
   PtUiMatSMCfm,      /* 4 - loosely coupled, portable */
#endif
};
#endif /* MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_MSC || MAP_HLR || MAP_GSN)

/* Short Message Services Indication */
PUBLIC MatSMInd maUiSMIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatSMInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatSMInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatSMInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatSMInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatSMInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatSMInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatSMInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatSMInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatSMInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatSMInd,      /* 4 - loosely coupled, portable */
#endif
};
#endif /* MAP_MSC || MAP_HLR || MAP_GSN */

/* --------------- Subscriber Management ------------------------------ */
#if (MAP_VLR || MAP_HLR || MAP_GSN || MAP_MLC)
/* Subscriber Management Indication primitive */
 
PUBLIC MatSubMgmtInd maUiSubMgmtIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatSubMgmtInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatSubMgmtInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatSubMgmtInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatSubMgmtInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatSubMgmtInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatSubMgmtInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatSubMgmtInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatSubMgmtInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatSubMgmtInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatSubMgmtInd,      /* 4 - loosely coupled, portable */
#endif
};
#endif /* MAP_VLR || MAP_HLR || MAP_GSN || MAP_MLC */
 
#if (MAP_VLR || MAP_HLR || MAP_GSN)
/* Subscriber Management confirm primitive */
 
PUBLIC MatSubMgmtCfm maUiSubMgmtCfmMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatSubMgmtCfm,      /* 0 - loosely coupled -fc */
#else
   PtUiMatSubMgmtCfm,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatSubMgmtCfm,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatSubMgmtCfm,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatSubMgmtCfm,      /* 2 - light weight loosely coupled */
#else
   PtUiMatSubMgmtCfm,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatSubMgmtCfm,      /* 3 - loosely coupled -fc */
#else
   PtUiMatSubMgmtCfm,      /* 3- loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatSubMgmtCfm,      /* 4 - loosely coupled -fc */
#else
   PtUiMatSubMgmtCfm,      /* 4 - loosely coupled, portable */
#endif
};

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

/* --------------- PDP Context Activation Management ------------------ */
#if (MAP_HLR || MAP_GSN)
/* Pdp Cntxt Act.Indication primitive */
 
PUBLIC MatNwReqPdpCntxtActvInd maUiNwReqPdpCntxtActvIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatNwReqPdpCntxtActvInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatNwReqPdpCntxtActvInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatNwReqPdpCntxtActvInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatNwReqPdpCntxtActvInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatNwReqPdpCntxtActvInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatNwReqPdpCntxtActvInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatNwReqPdpCntxtActvInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatNwReqPdpCntxtActvInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatNwReqPdpCntxtActvInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatNwReqPdpCntxtActvInd,      /* 4 - loosely coupled, portable */
#endif
};
 
/* Pdp Cntxt Act.confirm primitive */
 
PUBLIC MatNwReqPdpCntxtActvCfm maUiNwReqPdpCntxtActvCfmMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatNwReqPdpCntxtActvCfm,      /* 0 - loosely coupled -fc */
#else
   PtUiMatNwReqPdpCntxtActvCfm,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatNwReqPdpCntxtActvCfm,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatNwReqPdpCntxtActvCfm,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatNwReqPdpCntxtActvCfm,      /* 2 - light weight loosely coupled */
#else
   PtUiMatNwReqPdpCntxtActvCfm,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatNwReqPdpCntxtActvCfm,      /* 3 - loosely coupled -fc */
#else
   PtUiMatNwReqPdpCntxtActvCfm,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatNwReqPdpCntxtActvCfm,      /* 4 - loosely coupled -fc */
#else
   PtUiMatNwReqPdpCntxtActvCfm,      /* 4 - loosely coupled, portable */
#endif
};
#endif /* MAP_HLR || MAP_GSN */

#if (MAP_REL98 || MAP_REL99)

/* --------------- Location Services Management ------------------ */
#if (MAP_MSC || MAP_HLR || MAP_MLC || (MAP_REL99 && MAP_REL4 && MAP_GSN))
/* Loc. Serv. Indication primitive */
 
PUBLIC MatLocServInd maUiLocServIndMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatLocServInd,      /* 0 - loosely coupled -fc */
#else
   PtUiMatLocServInd,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatLocServInd,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatLocServInd,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatLocServInd,      /* 2 - light weight loosely coupled */
#else
   PtUiMatLocServInd,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatLocServInd,      /* 3 - loosely coupled -fc */
#else
   PtUiMatLocServInd,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatLocServInd,      /* 4 - loosely coupled -fc */
#else
   PtUiMatLocServInd,      /* 4 - loosely coupled, portable */
#endif
};
#endif /* MAP_HLR || MAP_MSC */

#if (MAP_MSC || MAP_MLC || (MAP_REL99 && MAP_REL4 && MAP_GSN))
/* Loc. Serv. confirm primitive */
 
PUBLIC MatLocServCfm maUiLocServCfmMt [MAXMAUI] =
{
#ifdef LCMAUIMAT
   cmPkMatLocServCfm,      /* 0 - loosely coupled -fc */
#else
   PtUiMatLocServCfm,      /* 0 - loosely coupled, portable */
#endif
#ifdef AU
   AuLiMatLocServCfm,      /* 1 - tightly coupled, MAP user */
#else
   PtUiMatLocServCfm,      /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMAUIMAT
   cmPkMatLocServCfm,      /* 2 - light weight loosely coupled */
#else
   PtUiMatLocServCfm,      /* 2 - light weight loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatLocServCfm,      /* 3 - loosely coupled -fc */
#else
   PtUiMatLocServCfm,      /* 3 - loosely coupled, portable */
#endif
#ifdef LCMAUIMAT
   cmPkMatLocServCfm,      /* 4 - loosely coupled -fc */
#else
   PtUiMatLocServCfm,      /* 4 - loosely coupled, portable */
#endif
};
#endif /* MAP_MLC */

#endif /* MAP_REL98 || MAP_REL99 */

/*
*     upper interface functions
*/
  
/* 
* 
*       Fun:   upper interface - MAP Open Indication
*  
*       Desc:  This function indicates the receipt of a TCAP Begin PDU 
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatOpenInd
(
Pst      *pst,              /* post structure */
SuId     suId,              /* service user id */
MaDlgId  suDlgId,           /* Service user dialogue Id */
MaDlgId  spDlgId,           /* Service provider dialogue Id */
MaOpenEv *openEv            /* Open Event Structure */          
)
#else
PUBLIC S16 MaUiMatOpenInd(pst, suId, suDlgId, spDlgId, openEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaOpenEv *openEv;           /* Open Event Structure */          
#endif
{
   TRC2(MaUiMatOpenInd)
   RETVALUE((*maUiOpenIndMt[pst->selector])(pst, suId, suDlgId, spDlgId, 
                                            openEv));
} /* end of MaUiMatOpenInd */

/* 
* 
*       Fun:   upper interface - MAP Open Confirm
*  
*       Desc:  This function indicates the receipt of TCAP Continue/Begin PDU 
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatOpenCfm
(
Pst      *pst,              /* post structure */
SuId     suId,              /* service user id */
MaDlgId  suDlgId,           /* Service user dialogue Id */
MaDlgId  spDlgId,           /* Service provider dialogue Id */
MaOpenEv *openEv            /* Open Event Structure */          
)
#else
PUBLIC S16 MaUiMatOpenCfm(pst, suId, suDlgId, spDlgId, openEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaOpenEv *openEv;           /* Open Event Structure */          
#endif
{
   TRC2(MaUiMatOpenCfm)
   RETVALUE((*maUiOpenCfmMt[pst->selector])(pst, suId, suDlgId, spDlgId, 
                                            openEv));
} /* end of MaUiMatOpenCfm */

/* 
* 
*       Fun:   upper interface - MAP Close Indication
*  
*       Desc:  This function indicates the receipt of TCAP Close/REJ. PDU 
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatCloseInd
(
Pst       *pst,             /* post structure */
SuId      suId,             /* service user id */
MaDlgId   suDlgId,          /* Service user dialogue Id */
MaDlgId   spDlgId,          /* Service provider dialogue Id */
MaCloseEv *closeEv          /* Close Event Structure */         
)
#else
PUBLIC S16 MaUiMatCloseInd(pst, suId, suDlgId, spDlgId, closeEv)
Pst       *pst;             /* post structure */
SuId      suId;             /* service user id */
MaDlgId   suDlgId;          /* Service user dialogue Id */
MaDlgId   spDlgId;          /* Service provider dialogue Id */
MaCloseEv *closeEv;         /* Close Event Structure */         
#endif
{
   TRC2(MaUiMatOpenInd)
   RETVALUE((*maUiCloseIndMt[pst->selector])(pst, suId, suDlgId, spDlgId, 
                                            closeEv));
} /* end of MaUiMatCloseInd */

/* 
* 
*       Fun:   upper interface - MAP Delimeter Indication
*  
*       Desc:  This function indicates the receipt of last component. 
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatDelimInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId          /* Service provider dialogue Id */
)
#else
PUBLIC S16 MaUiMatDelimInd(pst, suId, suDlgId, spDlgId)
Pst       *pst;             /* post structure */
SuId      suId;             /* service user id */
MaDlgId   suDlgId;          /* Service user dialogue Id */
MaDlgId   spDlgId;          /* Service provider dialogue Id */
#endif
{
   TRC2(MaUiMatDelimInd)
   RETVALUE((*maUiDelimIndMt[pst->selector])(pst, suId, suDlgId, spDlgId));
} /* end of MaUiMatDelimInd */

/* 
* 
*       Fun:   upper interface - MAP Abort Indication
*  
*       Desc:  This function indicates the receipt of TCAP Abort PDU 
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatAbrtInd
(
Pst      *pst,              /* post structure */
SuId     suId,              /* service user id */
MaDlgId  suDlgId,           /* Service user dialogue Id */
MaDlgId  spDlgId,           /* Service provider dialogue Id */
MaAbrtEv *abrtEv            /* Abort Event Structure */         
)
#else
PUBLIC S16 MaUiMatAbrtInd(pst, suId, suDlgId, spDlgId, abrtEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaAbrtEv *abrtEv;           /* Abort Event Structure */         
#endif
{
   TRC2(MaUiMatAbrtInd)
   RETVALUE((*maUiAbrtIndMt[pst->selector])(pst, suId, suDlgId, spDlgId, 
                                            abrtEv));
} /* end of MaUiMatAbrtInd */

/* 
* 
*       Fun:   upper interface - MAP Notice Indication
*  
*       Desc:  This function indicates teh internal protocal problem. 
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatNotInd
(
Pst      *pst,              /* post structure */
SuId     suId,              /* service user id */
MaDlgId  suDlgId,           /* Service user dialogue Id */
MaDlgId  spDlgId,           /* Service provider dialogue Id */
RCause   cause              /* Notice Indication cause */
)
#else
PUBLIC S16 MaUiMatNotInd(pst, suId, suDlgId, spDlgId,cause)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
RCause   cause;             /* Notice Indication cause */
#endif
{
   TRC2(MaUiMatNotInd)
   RETVALUE((*maUiNotIndMt[pst->selector])(pst, suId, suDlgId, spDlgId,cause));
} /* end of MaUiMatNotInd */

/* 
* 
*       Fun:   upper interface - MAP Dialogue Confirm
*  
*       Desc:  This function confirms the dialogue.  
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatDlgCfm
(
Pst      *pst,              /* post structure */
SuId     suId,              /* service user id */
MaDlgId  suDlgId,           /* Service user dialogue Id */
MaDlgId  spDlgId            /* Service provider dialogue Id */
)
#else
PUBLIC S16 MaUiMatDlgCfm(pst, suId, suDlgId, spDlgId)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
#endif
{
   TRC2(MaUiMatDlgCfm)
   RETVALUE((*maUiDlgCfmMt[pst->selector])(pst, suId, suDlgId, spDlgId));
} /* end of MaUiMatDlgCfm */

/* 
* 
*       Fun:   upper interface - MAP Status Indication
*  
*       Desc:  This function indicates errors in processing an upper layer
*              primitive and point code status. 
*  
*       Ret:   ROK      - ok
* 
*       Notes: Destination point code is used for passing the status of
*              point code to the user. In other cases the this feild is
*              not used. 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatStatInd
(
Pst      *pst,              /* post structure */
SuId     suId,              /* service user id */
MaDlgId  suDlgId,           /* Service user dialogue Id */
MaInvokeId  *invkId,         /* Invoke Id */
U8         primType,        /* Primitive Type */
Status   status             /* Status of MAP layer */           
)
#else
PUBLIC S16 MaUiMatStatInd(pst, suId, suDlgId, invkId, primType, status)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaInvokeId  *invkId;         /* Invoke Id */
U8         primType;        /* Primitive Type */
Status   status;            /* Status of MAP layer */
#endif
{
   TRC2(MaUiMatStatInd)
   RETVALUE((*maUiStatIndMt[pst->selector])(pst, suId, suDlgId, invkId, 
                                            primType, status)); 
} /* end of MaUiMatStatInd */

 
/*  
*  
*       Fun:   upper interface - MAP SSN and PC state Indication
*   
*       Desc:  call Ste Indication through matrix selector
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  ma_ptui.c
*  
*/ 
 
#ifdef ANSI
PUBLIC S16 MaUiMatSteInd
(
Pst *pst,                   /* post structure */
SuId suId,                  /* service user id */
CmSS7SteMgmt  *steMgmt      /* SSN and PC Status Management */
#ifdef MATV2
,MatSteMgmtEv matSteMgmtEv          /* ril and SCCP state */
#endif
)
#else
#ifdef MATV2
PUBLIC S16 MaUiMatSteInd(pst, suId, steMgmt, matSteMgmtEv)
#else
PUBLIC S16 MaUiMatSteInd(pst, suId, steMgmt)
#endif /* MATV2 */
Pst *pst;                   /* post structure */
SuId suId;                  /* service user id */
CmSS7SteMgmt  *steMgmt;     /* SSN and PC Status Management */
#ifdef MATV2
MatSteMgmtEv matSteMgmtEv;          /* ril and SCCP state */
#endif
#endif
{
   TRC2(MaUiMatSteInd)
#ifdef MATV2
   RETVALUE((*maUiSteIndMt[pst->selector])(pst, suId, steMgmt, matSteMgmtEv));
#else
   RETVALUE((*maUiSteIndMt[pst->selector])(pst, suId, steMgmt));
#endif /* MATV2 */
} /* end of MaUiMatSteInd */

 
/*  
*  
*       Fun:   upper interface - MAP SSN and PC state Confirm 
*   
*       Desc:  call Ste Confirm through matrix selector
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  ma_ptui.c
*  
*/ 
 
#ifdef ANSI
PUBLIC S16 MaUiMatSteCfm
(
Pst *pst,                   /* post structure */
SuId suId,                  /* service user id */
CmSS7SteMgmt  *steMgmt      /* SSN and PC Status Management */
#ifdef MATV2
,MatSteMgmtEv matSteMgmtEv          /* ril and SCCP state */
#endif
)
#else
#ifdef MATV2
PUBLIC S16 MaUiMatSteCfm(pst, suId, steMgmt, matSteMgmtEv)
#else
PUBLIC S16 MaUiMatSteCfm(pst, suId, steMgmt)
#endif /* MATV2 */
Pst *pst;                   /* post structure */
SuId suId;                  /* service user id */
CmSS7SteMgmt  *steMgmt;     /* SSN and PC Status Management */
#ifdef MATV2
MatSteMgmtEv matSteMgmtEv;          /* ril and SCCP state */
#endif
#endif
{
   TRC2(MaUiMatSteCfm)
#ifdef MATV2
   RETVALUE((*maUiSteCfmMt[pst->selector])(pst, suId, steMgmt, matSteMgmtEv));
#else
   RETVALUE((*maUiSteCfmMt[pst->selector])(pst, suId, steMgmt));
#endif /* MATV2 */
} /* end of MaUiMatSteCfm */

/* 
*
*       Fun:   upper interface - MAP Bind Confirm
*  
*       Desc:  Bind Confirm through matrix selector
*  
*       Ret:   ROK      - ok
* 
*       Notes: None
* 
*       File:  ma_ptui.c
* 
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatBndCfm
(
Pst *pst,                   /* post structure */
SuId suId,                  /* service user id */
U8   status                  /* status */
)
#else
PUBLIC S16 MaUiMatBndCfm(pst, suId, status)
Pst *pst;                   /* post structure */
SuId suId;                  /* service user id */
U8   status;                /* status */
#endif
{
   TRC2(MaUiMatBndCfm)
   RETVALUE((*maUiBndCfmMt[pst->selector])(pst, suId, status));
} /* end of MaUiMatBndCfm */


/* Service Specific */

/* --------------- Handover Management ----------------------------- */
#if MAP_MSC

/* 
* 
*       Fun:   upper interface - Handover Management Indication
*  
*       Desc:  This function indicates the receipt of Handover management
*              request. 
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatHOMgmtInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaHoEv     *hoEv            /* Handover Event Structure */              
)
#else
PUBLIC S16 MaUiMatHOMgmtInd(pst, suId, suDlgId, spDlgId, invkId, oprType, hoEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaHoEv     *hoEv;           /* Handover Event Structure */              
#endif
{
   TRC2(MaUiMatHOMgmtInd)
   RETVALUE((*maUiHOMgmtIndMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,hoEv)); 
} /* end of MaUiMatHOMgmtInd */

/* 
* 
*       Fun:   upper interface - Handover Management Confirm
*  
*       Desc:  This function indicates the receipt of  result of 
*              Handover management request. 
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PUBLIC S16 MaUiMatHOMgmtCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaUsrErr   *usrErr,          /* User Error */
MaPrvErr   *prvErr,         /* Provider Error */
MaHoEv     *hoEv            /* Handover Event Structure */              
)
#else
PUBLIC S16 MaUiMatHOMgmtCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr, prvErr, hoEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaUsrErr   *usrErr;          /* User Error */
MaPrvErr   *prvErr;         /* Provider Error */
MaHoEv     *hoEv;           /* Handover Event Structure */              
#endif
{
   TRC2(MaUiMatHOMgmtCfm)
   RETVALUE((*maUiHOMgmtCfmMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,usrErr, prvErr, 
                                               hoEv)); 
} /* end of MaUiMatHOMgmtCfm */

#endif /* MAP_MSC */

/* --------------- Location Management ----------------------------- */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
/*
*
*       Fun:   upper interface - Location Management Confirm
*
*       Desc:  This function indicates the receipt of  result of
*              location management request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatLocMgmtCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,          /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaLocEv    *locEv       /* Location Event Structure */
)
#else
PUBLIC S16 MaUiMatLocMgmtCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr, prvErr, locEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;          /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaLocEv    *locEv;      /* Location Event Structure */
#endif
{
   TRC2(MaUiMatLocMgmtInd)
   RETVALUE((*maUiLocMgmtCfmMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,usrErr, prvErr,
                                               locEv));
} /* end of MaUiMatLocMgmtCfm */

/* Location Management Indication */
/*
*
*       Fun:   upper interface - Location Management Indication
*
*       Desc:  This function indicates the receipt of location management
*          request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatLocMgmtInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaLocEv    *locEv       /* Location Event Structure */
)
#else
PUBLIC S16 MaUiMatLocMgmtInd(pst, suId, suDlgId, spDlgId, invkId, oprType, locEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaLocEv    *locEv;      /* Location Event Structure */
#endif
{
   TRC2(MaUiMatLocMgmtInd)
   RETVALUE((*maUiLocMgmtIndMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,locEv));
} /* end of MaUiMatLocMgmtInd */
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

/* --------------- Authentication Management ------------------------ */
#if (MAP_VLR || MAP_GSN)
/*
*
*       Fun:   upper interface - Authintication Management Confirm
* 
*       Desc:  This function indicates the receipt of  result of
*              Authintication management request.
* 
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatAuthMgmtCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,          /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaAuthEv    *authEv     /* Authintication Event Structure */
)
#else
PUBLIC S16 MaUiMatAuthMgmtCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr,
prvErr, authEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;          /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaAuthEv    *authEv;        /* Authintication Event Structure */
#endif
{
   TRC2(MaUiMatAuthMgmtCfm)
   RETVALUE((*maUiAuthMgmtCfmMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,usrErr, prvErr,
                                               authEv));
} /* end of MaUiMatAuthMgmtCfm */
#endif /* MAP_VLR || MAP_GSN */

#ifdef XWEXT /* xuxingzhou: xinwei */
/*
*
*       Fun:   upper interface - Xinwei Management Confirm
* 
*       Desc:  This function indicates the receipt of  result of
*              Xinwei management request.
* 
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatXWMgmtCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,          /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaXWDetectEv *detectEv     /* Detect Event Structure */
)
#else
PUBLIC S16 MaUiMatXWMgmtCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr,
prvErr, detectEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;          /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaXWDetectEv    *detectEv;        /* Detect Event Structure */
#endif
{
   TRC2(MaUiMatXWMgmtCfm)
   RETVALUE((*maUiXWMgmtCfmMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,usrErr, prvErr,
                                               detectEv));
} /* end of MaUiMatXWMgmtCfm */

/*
*
*       Fun:   upper interface - Xinwei Management Indication
*
*       Desc:  This function indicates the receipt of Xinwei management
*          request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatXWMgmtInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaXWDetectEv *detectEv     /* Authintication Event Structure */
)
#else
PUBLIC S16 MaUiMatXWMgmtInd(pst, suId, suDlgId, spDlgId, invkId, oprType, detectEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaXWDetectEv    *detectEv;        /* Authintication Event Structure */
#endif
{
   TRC2(MaUiMatXWMgmtInd)
   RETVALUE((*maUiXWMgmtIndMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,detectEv));
} /* end of MaUiMatAuthMgmtInd */

#endif

#if MAP_HLR
/*
*
*       Fun:   upper interface - Authintication Management Indication
*
*       Desc:  This function indicates the receipt of Authintiaction management
*          request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatAuthMgmtInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaAuthEv    *authEv     /* Authintication Event Structure */
)
#else
PUBLIC S16 MaUiMatAuthMgmtInd(pst, suId, suDlgId, spDlgId, invkId, oprType, authEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaAuthEv    *authEv;        /* Authintication Event Structure */
#endif
{
   TRC2(MaUiMatAuthMgmtInd)
   RETVALUE((*maUiAuthMgmtIndMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,authEv));
} /* end of MaUiMatAuthMgmtInd */
#endif /* MAP_HLR */

/* --------------- Identification Management ------------------------ */
#if MAP_VLR
/*
*
*       Fun:   upper interface - IMEI Management Indication
* 
*       Desc:  This function indicates the receipt of IMEI management
*          request.
* 
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatIMEIMgmtInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaIMEIEv    *imeiEv     /* IMEI Event Structure */
)
#else
PUBLIC S16 MaUiMatIMEIMgmtInd(pst, suId, suDlgId, spDlgId, invkId, oprType, imeiEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaIMEIEv    *imeiEv;        /* IMEI Event Structure */
#endif
{
   TRC2(MaUiMatIMEIMgmtInd)
   RETVALUE((*maUiIMEIMgmtIndMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,imeiEv));
} /* end of MaUiMatIMEIMgmtInd */
#endif /* MAP_VLR */

#if (MAP_MSC || MAP_GSN)
/*
*
*       Fun:   upper interface - IMEI Management Confirm
* 
*       Desc:  This function indicates the receipt of IMEI management
*          response.
* 
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatIMEIMgmtCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,          /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaIMEIEv    *imeiEv     /* IMEI Event Structure */
)
#else
PUBLIC S16 MaUiMatIMEIMgmtCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr,
prvErr, imeiEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;         /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaIMEIEv    *imeiEv;        /* IMEI Event Structure */
#endif
{
   TRC2(MaUiMatIMEIMgmtCfm)
   RETVALUE((*maUiIMEIMgmtCfmMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,usrErr, prvErr,
                                               imeiEv));
} /* end of MaUiMatIMEIMgmtCfm */

#endif /* MAP_MSC || MAP_GSN */

/* --------------- Fault and Recovery Management -------------------- */
#if (MAP_VLR || MAP_HLR)
/*
*
*       Fun:   upper interface - Fault and Recovery Management Confirm
* 
*       Desc:  This function indicates the receipt of  result of
*              Fault/Recovery management request.
* 
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatFRMgmtCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,          /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaFREv    *frEv             /* Fault and Recovery Management Event Structure */
)
#else
PUBLIC S16 MaUiMatFRMgmtCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr, prvErr, frEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;          /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaFREv    *frEv;        /* Fault and Recovery Management Event Structure */
#endif
{
   TRC2(MaUiMatFRMgmtCfm)
   RETVALUE((*maUiFRMgmtCfmMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,usrErr, prvErr,
                                               frEv));
} /* end of MaUiMatFRMgmtCfm */

#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
/*
*
*       Fun:   upper interface - Fault and Recovery Management Indication
*
*       Desc:  This function indicates the receipt of Fault/Recovery management
*          request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatFRMgmtInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaFREv    *frEv             /* Fault and Recovery Event Structure */
)
#else
PUBLIC S16 MaUiMatFRMgmtInd(pst, suId, suDlgId, spDlgId, invkId, oprType, frEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaFREv    *frEv;        /* Fault and Recovery Event Structure */
#endif
{
   TRC2(MaUiMatFRMgmtInd)
   RETVALUE((*maUiFRMgmtIndMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,frEv));
} /* end of MaUiMatFRMgmtInd */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

/* --------------- OAM Management ----------------------------------- */
#if (MAP_MSC || MAP_VLR || MAP_HLR)
/*
*
*       Fun:   upper interface - Operation and Maintenance Confirm
* 
*       Desc:  This function indicates the receipt of  result of
*              Operation and Management management request.
* 
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatOAMCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,          /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaOAMEv    *oamEv       /* Operation and Maintenance Event Structure */
)
#else
PUBLIC S16 MaUiMatOAMCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr, prvErr, oamEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;          /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaOAMEv    *oamEv;      /* Operation and Maintenance Event Structure */
#endif
{
   TRC2(MaUiMatOAMCfm)
   RETVALUE((*maUiOAMCfmMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,usrErr, prvErr,
                                               oamEv));
} /* end of MaUiMatOAMCfm */

#endif /* MAP_MSC || MAP_VLR || MAP_HLR */

#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)

/*
*
*       Fun:   upper interface - Operation and Maintenance Indication
*
*       Desc:  This function indicates the receipt of Operation and Maintenance
*               management request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatOAMInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaOAMEv    *oamEv       /* Operation and Maintenance Event Structure */
)
#else
PUBLIC S16 MaUiMatOAMInd(pst, suId, suDlgId, spDlgId, invkId, oprType, oamEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaOAMEv    *oamEv;      /* Operation and Maintenance Event Structure */
#endif
{
   TRC2(MaUiMatOAMInd)
   RETVALUE((*maUiOAMIndMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,oamEv));
} /* end of MaUiMatOAMInd */

#endif /* MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN */

/* --------------- Call Management ----------------------------------- */
#if (MAP_MSC || MAP_VLR || MAP_HLR)
/*
*
*       Fun:   upper interface - Call Management Indication
*
*       Desc:  This function indicates the receipt of Call management
*          request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatCallMgmtInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaCallEv    *callEv     /* Call Event Structure */
)
#else
PUBLIC S16 MaUiMatCallMgmtInd(pst, suId, suDlgId, spDlgId, invkId, oprType, callEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaCallEv    *callEv;        /* Call Event Structure */
#endif
{
   TRC2(MaUiMatCallMgmtInd)
   RETVALUE((*maUiCallMgmtIndMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,callEv));
} /* end of MaUiMatCallMgmtInd */

/*
*
*       Fun:   upper interface - call Management Confirm
* 
*       Desc:  This function indicates the receipt of  result of
*              Call management request.
* 
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatCallMgmtCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,          /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaCallEv    *callEv     /* Call Management Event Structure */
)
#else
PUBLIC S16 MaUiMatCallMgmtCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr, prvErr, callEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;          /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaCallEv    *callEv;        /* call Management Event Structure */
#endif
{
   TRC2(MaUiMatCallMgmtCfm)
   RETVALUE((*maUiCallMgmtCfmMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,usrErr, prvErr,
                                               callEv));
} /* end of MaUiMatCallMgmtCfm */

#endif /* MAP_MSC || MAP_VLR || MAP_HLR */

/* --------------- Supplementary Services Management ----------------- */
#if (MAP_VLR || MAP_HLR)

/*
*
*       Fun:   upper interface - Supplementry Services Indication
*
*       Desc:  This function indicates the receipt of Supplementry Services
*          request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatSSInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaInvokeId *lnkId,      /* Linked Invoke Id */
MaSSEv    *ssEv             /* Supplementry Services Event Structure */
)
#else
PUBLIC S16 MaUiMatSSInd(pst, suId, suDlgId, spDlgId, invkId, oprType, lnkId, ssEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaInvokeId *lnkId;      /* Linked Invoke Id */
MaSSEv    *ssEv;        /* Supplementry Services Event Structure */
#endif
{
   TRC2(MaUiMatSSInd)
   RETVALUE((*maUiSSIndMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,lnkId,ssEv));
} /* end of MaUiMatSSInd */
#endif /* MAP_HLR */

#if (MAP_VLR || MAP_HLR)
/*
*
*       Fun:   upper interface - Supplementry Services Confirm
* 
*       Desc:  This function indicates the receipt of  result of
*              Supplementry services request.
* 
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatSSCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaSSEv    *ssEv             /* Supplementry Services Event Structure */
)
#else
PUBLIC S16 MaUiMatSSCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr, prvErr
, ssEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;         /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaSSEv    *ssEv;        /* Supplementry Services Event Structure */
#endif
{
   TRC2(MaUiMatSSCfm)
   RETVALUE((*maUiSSCfmMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                          invkId,oprType,usrErr,
                                          prvErr, ssEv));
} /* end of MaUiMatSSCfm */

#endif /* MAP_VLR || MAP_HLR */

/* --------------- Short Message Services Management ------------------ */
#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)
/*
*
*       Fun:   upper interface - Short Message Confirm
*
*       Desc:  This function indicates the receipt of  result of
*              Short messages request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatSMCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaSMEv    *smEv             /* Short Message Event Structure */
)
#else
PUBLIC S16 MaUiMatSMCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr, prvErr
, smEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;         /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaSMEv    *smEv;        /* Short Message Event Structure */
#endif
{
   TRC2(MaUiMatSMCfm)
   RETVALUE((*maUiSMCfmMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                         invkId,oprType,usrErr, prvErr, smEv));
} /* end of MaUiMatSMCfm */


#endif /* MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_MSC || MAP_HLR || MAP_GSN)
/*
*
*       Fun:   upper interface - Short Message Indication
*
*       Desc:  This function indicates the receipt of Short messages
*          request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatSMInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaSMEv    *smEv             /* Short Message Event Structure */
)
#else
PUBLIC S16 MaUiMatSMInd(pst, suId, suDlgId, spDlgId, invkId, oprType, smEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaSMEv    *smEv;        /* Short Message Event Structure */
#endif
{
   TRC2(MaUiMatSMInd)
   RETVALUE((*maUiSMIndMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,smEv));
} /* end of MaUiMatSMInd */


#endif /* MAP_MSC || MAP_HLR || MAP_GSN */

/* --------------- Subscriber Management ------------------------------ */
#if (MAP_VLR || MAP_HLR || MAP_GSN || MAP_MLC)
/* Subscriber Management Request, Indication, Response and Confirm */
/*
*
*       Fun:   upper interface - Subscriber Management Indication
*
*       Desc:  This function indicates the receipt of Subscriber management
*          request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatSubMgmtInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaSubEv    *subEv       /* Subscriber Event Structure */
)
#else
PUBLIC S16 MaUiMatSubMgmtInd(pst, suId, suDlgId, spDlgId, invkId, oprType, subEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaSubEv    *subEv;      /* Subscriber Event Structure */
#endif
{
   TRC2(MaUiMatSubMgmtInd)
   RETVALUE((*maUiSubMgmtIndMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,subEv));
} /* end of MaUiMatSubMgmtInd */
#endif /* MAP_VLR || MAP_HLR || MAP_GSN || MAP_MLC */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
/*
*
*       Fun:   upper interface - Subscriber Management Confirm
*
*       Desc:  This function indicates the receipt of  result of
*              Subscriber management request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatSubMgmtCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaSubEv    *subEv       /* Subscriber Management Event Structure */
)
#else
PUBLIC S16 MaUiMatSubMgmtCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr, prvErr, subEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;      /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;         /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaSubEv    *subEv;      /* Subscriber Management Event Structure */
#endif
{
   TRC2(MaUiMatSubMgmtCfm)
   RETVALUE((*maUiSubMgmtCfmMt[pst->selector])(pst, suId, suDlgId, spDlgId,
                                               invkId,oprType,usrErr, prvErr,
                                               subEv));
} /* end of MaUiMatSubMgmtCfm */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

/* --------------- PDP Context Activation Management ------------------ */
#if (MAP_HLR || MAP_GSN)
/*
*
*       Fun:   upper interface - Pdp Cntxt Act.Indication
*
*       Desc:  This function indicates the receipt of Short messages
*          request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatNwReqPdpCntxtActvInd
(
Pst        *pst,        /* post structure */
SuId       suId,        /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaPdpActvEv    *pdpActvEv  /* Event Structure */
)
#else
PUBLIC S16 MaUiMatNwReqPdpCntxtActvInd(pst, suId, suDlgId, spDlgId, invkId, oprType,
 pdpActvEv)
Pst      *pst;          /* post structure */
SuId     suId;          /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaPdpActvEv    *pdpActvEv;      /* Event Structure */
#endif
{
   TRC2(MaUiMatNwReqPdpCntxtActvInd)

   RETVALUE((*maUiNwReqPdpCntxtActvIndMt[pst->selector])(pst, suId, suDlgId, 
                                                         spDlgId, invkId,oprType,
                                                         pdpActvEv));
} /* end of MaUiMatNwReqPdpCntxtActvInd */

/*
*
*       Fun:   upper interface - Pdp Cntxt Act.Confirm
*
*       Desc:  This function indicates the receipt of  result of
*              Short messages request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatNwReqPdpCntxtActvCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaPrvErr   *prvErr,         /* Provider Error */
MaPdpActvEv    *pdpActvEv   /* Event Structure */
)
#else
PUBLIC S16 MaUiMatNwReqPdpCntxtActvCfm(pst, suId, suDlgId, spDlgId, invkId, oprType,
 usrErr, prvErr, pdpActvEv)
Pst      *pst;                  /* post structure */
SuId     suId;                  /* service user id */
MaDlgId  suDlgId;               /* Service user dialogue Id */
MaDlgId  spDlgId;               /* Service provider dialogue Id */
MaInvokeId *invkId;             /* Invoke Id */
MaOprType  oprType;             /* Operation type */
MaUsrErr   *usrErr;             /* User Error */
MaPrvErr   *prvErr;             /* Provider Error */
MaPdpActvEv    *pdpActvEv;      /* Event Structure */
#endif
{
   TRC2(MaUiMatNwReqPdpCntxtActvCfm)
   RETVALUE((*maUiNwReqPdpCntxtActvCfmMt[pst->selector])(pst, suId, suDlgId, 
                                                         spDlgId, invkId,oprType,
                                                         usrErr, prvErr, 
                                                         pdpActvEv));
} /* end of MaUiMatNwReqPdpCntxtActvCfm */

#endif /* MAP_HLR || MAP_GSN */

#if (MAP_REL98 || MAP_REL99)

/* --------------- Location Services Management ------------------ */

#if (MAP_MSC || MAP_HLR || MAP_MLC || (MAP_REL99 && MAP_REL4 && MAP_GSN))
/*
*
*       Fun:   upper interface - Loc. Serv. Indication
*
*       Desc:  This function indicates the receipt of Loc. Serv.
*              request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatLocServInd
(
Pst        *pst,        /* post structure */
SuId       suId,        /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaLocServEv    *locServEv  /* Event Structure */
)
#else
PUBLIC S16 MaUiMatLocServInd(pst, suId, suDlgId, spDlgId, invkId, oprType,
 locServEv)
Pst      *pst;          /* post structure */
SuId     suId;          /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaLocServEv    *locServEv;      /* Event Structure */
#endif
{
   TRC2(MaUiMatLocServInd)

   RETVALUE((*maUiLocServIndMt[pst->selector])(pst, suId, suDlgId, spDlgId, 
                                               invkId,oprType, locServEv));
} /* end of MaUiMatLocServInd */
#endif /* MAP_HLR || MAP_MSC */

#if (MAP_MSC || MAP_MLC || (MAP_REL99 && MAP_REL4 && MAP_GSN))
/*
*
*       Fun:   upper interface - Loc. Serv. Confirm
*
*       Desc:  This function indicates the receipt of  result of
*              Loc. Serv. request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 MaUiMatLocServCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId,         /* Service provider dialogue Id */
MaInvokeId *invkId,         /* Invoke Id */
MaOprType  oprType,         /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaPrvErr   *prvErr,         /* Provider Error */
MaLocServEv    *locServEv   /* Event Structure */
)
#else
PUBLIC S16 MaUiMatLocServCfm(pst, suId, suDlgId, spDlgId, invkId, oprType,
 usrErr, prvErr, locServEv)
Pst      *pst;                  /* post structure */
SuId     suId;                  /* service user id */
MaDlgId  suDlgId;               /* Service user dialogue Id */
MaDlgId  spDlgId;               /* Service provider dialogue Id */
MaInvokeId *invkId;             /* Invoke Id */
MaOprType  oprType;             /* Operation type */
MaUsrErr   *usrErr;             /* User Error */
MaPrvErr   *prvErr;             /* Provider Error */
MaLocServEv    *locServEv;      /* Event Structure */
#endif
{
   TRC2(MaUiMatLocServCfm)
   RETVALUE((*maUiLocServCfmMt[pst->selector])(pst, suId, suDlgId, spDlgId, 
                                               invkId,oprType, usrErr, prvErr, 
                                               locServEv));
} /* end of MaUiMatLocServCfm */

#endif /* MAP_MLC */

#endif /* MAP_REL98 || MAP_REL99 */

#if (!(defined(LCMAUIMAT) && defined(AU) && defined(LWLCMAUIMAT)))
/*
*     portable functions
*/
  
/* 
* 
*       Fun:   portable interface - MAP Open Indication
*  
*       Desc:  call MAP Open Indication through matrix selector
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PRIVATE S16 PtUiMatOpenInd
(
Pst      *pst,              /* post structure */
SuId     suId,              /* service user id */
MaDlgId  suDlgId,           /* Service user dialogue Id */
MaDlgId  spDlgId,           /* Service provider dialogue Id */
MaOpenEv *openEv            /* Open Event Structure */          
)
#else
PRIVATE S16 PtUiMatOpenInd(pst, suId, suDlgId, spDlgId, openEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaOpenEv *openEv;           /* Open Event Structure */          
#endif
{
   TRC2(PtUiMatOpenInd)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA349, (ErrVal)0, "PtUiMatOpenInd () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatOpenInd */

/* 
* 
*       Fun:   portable interface - MAP Open Confirm
*  
*       Desc:  call MAP Open Confirm through matrix selector
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PRIVATE S16 PtUiMatOpenCfm
(
Pst      *pst,              /* post structure */
SuId     suId,              /* service user id */
MaDlgId  suDlgId,           /* Service user dialogue Id */
MaDlgId  spDlgId,           /* Service provider dialogue Id */
MaOpenEv *openEv            /* Open Event Structure */          
)
#else
PRIVATE S16 PtUiMatOpenCfm(pst, suId, suDlgId, spDlgId, openEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaOpenEv *openEv;           /* Open Event Structure */          
#endif
{
   TRC2(PtUiMatOpenCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA350, (ErrVal)0, "PtUiMatOpenCfm () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatOpenCfm */

/* 
* 
*       Fun:   portable interface - MAP Close Indication
*  
*       Desc:  call MAP Close Indication through matrix selector
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PRIVATE S16 PtUiMatCloseInd
(
Pst       *pst,             /* post structure */
SuId      suId,             /* service user id */
MaDlgId   suDlgId,          /* Service user dialogue Id */
MaDlgId   spDlgId,          /* Service provider dialogue Id */
MaCloseEv *closeEv          /* Close Event Structure */         
)
#else
PRIVATE S16 PtUiMatCloseInd(pst, suId, suDlgId, spDlgId, closeEv)
Pst       *pst;             /* post structure */
SuId      suId;             /* service user id */
MaDlgId   suDlgId;          /* Service user dialogue Id */
MaDlgId   spDlgId;          /* Service provider dialogue Id */
MaCloseEv *closeEv;         /* Close Event Structure */         
#endif
{
   TRC2(PtUiMatCloseInd)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA351, (ErrVal)0, "PtUiMatCloseInd () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatCloseInd */

/* 
* 
*       Fun:   portable interface - MAP Delimeter Indication
*  
*       Desc:  call MAP Delimeter Indication through matrix selector
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PRIVATE S16 PtUiMatDelimInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,         /* Service user dialogue Id */
MaDlgId    spDlgId          /* Service provider dialogue Id */
)
#else
PRIVATE S16 PtUiMatDelimInd(pst, suId, suDlgId, spDlgId)
Pst       *pst;             /* post structure */
SuId      suId;             /* service user id */
MaDlgId   suDlgId;          /* Service user dialogue Id */
MaDlgId   spDlgId;          /* Service provider dialogue Id */
#endif
{
   TRC2(PtUiMatDelimInd)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA352, (ErrVal)0, "PtUiMatDelimInd () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatDelimInd */

/* 
* 
*       Fun:   portable interface - MAP Abort Indication
*  
*       Desc:  call MAP Abort Indication through matrix selector
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PRIVATE S16 PtUiMatAbrtInd
(
Pst      *pst,              /* post structure */
SuId     suId,              /* service user id */
MaDlgId  suDlgId,           /* Service user dialogue Id */
MaDlgId  spDlgId,           /* Service provider dialogue Id */
MaAbrtEv *abrtEv            /* Abort Event Structure */         
)
#else
PRIVATE S16 PtUiMatAbrtInd(pst, suId, suDlgId, spDlgId, abrtEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaAbrtEv *abrtEv;           /* Abort Event Structure */         
#endif
{
   TRC2(PtUiMatAbrtInd)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA353, (ErrVal)0, "PtUiMatAbrtInd () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatAbrtInd */

/* 
* 
*       Fun:   portable interface - MAP Notice Indication
*  
*       Desc:  call MAP Notice Indication through matrix selector
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PRIVATE S16 PtUiMatNotInd
(
Pst      *pst,              /* post structure */
SuId     suId,              /* service user id */
MaDlgId  suDlgId,           /* Service user dialogue Id */
MaDlgId  spDlgId,           /* Service provider dialogue Id */
RCause   cause              /* Notice Indication cause */
)
#else
PRIVATE S16 PtUiMatNotInd(pst, suId, suDlgId, spDlgId,cause)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
RCause   cause;             /* Notice Indication cause */
#endif
{
   TRC2(PtUiMatNotInd)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA354, (ErrVal)0, "PtUiMatNotInd () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatNotInd */

/* 
* 
*       Fun:   portable interface - MAP Dialogue confirm
*  
*       Desc:  call MAP Dialogue confirm through matrix selector
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PRIVATE S16 PtUiMatDlgCfm
(
Pst      *pst,              /* post structure */
SuId     suId,              /* service user id */
MaDlgId  suDlgId,           /* Service user dialogue Id */
MaDlgId  spDlgId            /* Service provider dialogue Id */
)
#else
PRIVATE S16 PtUiMatDlgCfm(pst, suId, suDlgId, spDlgId)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
#endif
{
   TRC2(PtUiMatDlgCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA355, (ErrVal)0, "PtUiMatDlgCfm () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatDlgCfm */

/* 
* 
*       Fun:   portable interface - MAP Status Indication
*  
*       Desc:  call MAP Status Indication through matrix selector
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PRIVATE S16 PtUiMatStatInd
(
Pst      *pst,              /* post structure */
SuId     suId,              /* service user id */
MaDlgId  suDlgId,           /* MAP Service user dialogue Id */
MaInvokeId  *invkId,         /* Invoke Id */
U8         primType,        /* Primitive Type */
Status   status             /* Status of MAP layer */           
)
#else
PRIVATE S16 PtUiMatStatInd(pst, suId, suDlgId, invkId, primType, status)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;           /* MAP Service user dialogue Id */
MaInvokeId  *invkId;         /* Invoke Id */
U8         primType;        /* Primitive Type */
Status   status;            /* Status of MAP layer */
#endif
{
   TRC2(PtUiMatStatInd)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA356, (ErrVal)0, "PtUiMatStatInd () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatStatInd */


/* 
* 
*       Fun:   portable - MAP State Indication
*  
*       Desc:  user defined state indication
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PRIVATE S16 PtUiMatSteInd
(
Pst *pst,                   /* post structure */
SuId suId,                  /* service user id */
CmSS7SteMgmt  *steMgmt      /* SSN and PC management structure */
#ifdef MATV2
,MatSteMgmtEv matSteMgmtEv          /* ril and SCCP state */
#endif
)
#else
#ifdef MATV2
PRIVATE S16 PtUiMatSteInd(pst, suId, steMgmt, matSteMgmtEv)
#else
PRIVATE S16 PtUiMatSteInd(pst, suId, steMgmt)
#endif /* MATV2 */
Pst *pst;                   /* post structure */
SuId suId;                  /* service user id */
CmSS7SteMgmt  *steMgmt;     /* SSN and PC management structure */
#ifdef MATV2
MatSteMgmtEv matSteMgmtEv;          /* ril and SCCP state */
#endif
#endif
{
   TRC2(PtUiMatSteInd)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(steMgmt);
#ifdef MATV2
   UNUSED(matSteMgmtEv);
#endif
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA357, (ErrVal)0, "PtUiMatSteInd () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatSteInd */


/* 
* 
*       Fun:   portable - MAP State Confirm 
*  
*       Desc:  user defined state confirm
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  ma_ptui.c
* 
*/

#ifdef ANSI
PRIVATE S16 PtUiMatSteCfm
(
Pst *pst,                   /* post structure */
SuId suId,                  /* service user id */
CmSS7SteMgmt  *steMgmt      /* SSN and PC management structure */
#ifdef MATV2
,MatSteMgmtEv matSteMgmtEv          /* ril and SCCP state */
#endif
)
#else
#ifdef MATV2
PRIVATE S16 PtUiMatSteCfm(pst, suId, steMgmt, matSteMgmtEv)
#else
PRIVATE S16 PtUiMatSteCfm(pst, suId, steMgmt)
#endif /* MATV2 */
Pst *pst;                   /* post structure */
SuId suId;                  /* service user id */
CmSS7SteMgmt  *steMgmt;     /* SSN and PC management structure */
#ifdef MATV2
MatSteMgmtEv matSteMgmtEv;          /* ril and SCCP state */
#endif
#endif
{
   TRC2(PtUiMatSteCfm)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(steMgmt);
#ifdef MATV2
   UNUSED(matSteMgmtEv);
#endif
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA358, (ErrVal)0, "PtUiMatSteCfm () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatSteCfm */


/*
*
*       Fun:   portable - MAP Bind Confirm
* 
*       Desc:  user defined Bind confirm
* 
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatBndCfm
(
Pst *pst,                   /* post structure */
SuId suId,                  /* service user id */
U8   status                 /* status */
)
#else
PRIVATE S16 PtUiMatBndCfm(pst, suId, status)
Pst *pst;                   /* post structure */
SuId suId;                  /* service user id */
U8   status;                /* status */
#endif
{
   TRC2(PtUiMatBndCfm)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(status);
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA359, (ErrVal)0, "PtUiMatBndCfm () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatBndCfm */

/* Service Specific */


/* ----------------------------------------------------------------- */
/*                 Service Specific Primitives                       */
/* ----------------------------------------------------------------- */

/* --------------- Handover Management ----------------------------- */
#if MAP_MSC
/*
*
*       Fun:   upper interface - Handover Management Indication
*
*       Desc:  call Handover Management Indication through matrix selector
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatHOMgmtInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaHoEv     *hoEv        /* Handover Event Structure */
)
#else
PRIVATE S16 PtUiMatHOMgmtInd(pst, suId, suDlgId, spDlgId, invkId, oprType, hoEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaHoEv     *hoEv;       /* Handover Event Structure */
#endif
{
   TRC2(PtUiMatHOMgmtInd)
#if (ERRCLASS & ERRCLS_DEBUG)
   MALOGERROR(ERRCLS_DEBUG, EMA360, (ErrVal)0, "PtUiMatHOMgmtInd () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatHOMgmtInd */

/*
*
*       Fun:   upper interface - Handover Management Confirm
*
*       Desc:  call Handover Management Confirm through matrix selector
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatHOMgmtCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,          /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaHoEv     *hoEv        /* Handover Event Structure */
)
#else
PRIVATE S16 PtUiMatHOMgmtCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr, prvErr, hoEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;          /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaHoEv     *hoEv;       /* Handover Event Structure */
#endif
{
   TRC2(PtUiMatHOMgmtCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA361, (ErrVal)0, "PtUiMatHOMgmtCfm () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatHOMgmtCfm */


#endif /* MAP_MSC */

/* --------------- Location Management ----------------------------- */
#if (MAP_VLR || MAP_HLR || MAP_GSN)

/*
*
*       Fun:   upper interface - Location Management Confirm
* 
*       Desc:  call Location Management Confirm through matrix selector
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatLocMgmtCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,          /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaLocEv    *locEv       /* Location Event Structure */
)
#else
PRIVATE S16 PtUiMatLocMgmtCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr, prvErr, locEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;          /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaLocEv    *locEv;      /* Location Event Structure */
#endif
{
   TRC2(PtUiMatLocMgmtCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA362, (ErrVal)0, "PtUiMatLocMgmtCfm () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatLocMgmtCfm */

/*
*
*       Fun:   upper interface - Location Management Indication
*
*       Desc:  call Location Management Indication through matrix selector
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatLocMgmtInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaLocEv    *locEv       /* Location Event Structure */
)
#else
PRIVATE S16 PtUiMatLocMgmtInd(pst, suId, suDlgId, spDlgId, invkId, oprType, locEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaLocEv    *locEv;      /* Location Event Structure */
#endif
{
   TRC2(PtUiMatLocMgmtInd)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA363, (ErrVal)0, "PtUiMatLocMgmtInd () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatLocMgmtInd */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#ifdef XWEXT /* xingzhou.xu: XINWEI management definition */
/*
*
*       Fun:   upper interface - Authintication Management Confirm
*
*       Desc:  call Authintication Management Confirm through matrix selector
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatXWMgmtCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,          /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaXWDetectEv *dectecthEv     /* Authintication Event Structure */
)
#else
PRIVATE S16 PtUiMatXWMgmtCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr, prvErr, dectecthEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;          /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaXWDetectEv    *dectecthEv;        /* Authintication Event Structure */
#endif
{
   TRC2(PtUiMatXWMgmtCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
     MALOGERROR(ERRCLS_DEBUG, EMA364, (ErrVal)0, "PtUiMatXWMgmtCfm () Failed");
#endif
     RETVALUE(ROK);
} /* end of PtUiMatXWMgmtCfm */

/*
*
*       Fun:   upper interface - Xinwei Management Indication
*
*       Desc:  This function indicates the receipt of XINWEI management
*          request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatXWMgmtInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaXWDetectEv *detectEv     /* Detect Event Structure */
)
#else
PRIVATE S16 PtUiMatXWMgmtInd(pst, suId, suDlgId, spDlgId, invkId, oprType, detectEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaXWDetectEv    *detectEv;        /* Detect Event Structure */
#endif
{
   TRC2(PtUiMatXWMgmtInd)
 
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA365, (ErrVal)0, "PtUiMatXWMgmtInd () Failed");
#endif
    RETVALUE(ROK);
 
} /* end of PtUiMatXWMgmtInd */
#endif /* XWEXT */

/* --------------- Authentication Management ------------------------ */
#if (MAP_VLR || MAP_GSN)

/*
*
*       Fun:   upper interface - Authintication Management Confirm
*
*       Desc:  call Authintication Management Confirm through matrix selector
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatAuthMgmtCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,          /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaAuthEv    *authEv     /* Authintication Event Structure */
)
#else
PRIVATE S16 PtUiMatAuthMgmtCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr, prvErr, authEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;          /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaAuthEv    *authEv;        /* Authintication Event Structure */
#endif
{
   TRC2(PtUiMatAuthMgmtCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
     MALOGERROR(ERRCLS_DEBUG, EMA364, (ErrVal)0, "PtUiMatAuthMgmtCfm () Failed");
#endif
     RETVALUE(ROK);
} /* end of PtUiMatAuthMgmtCfm */

#endif /* MAP_VLR || MAP_GSN */

#if MAP_HLR
/*
*
*       Fun:   upper interface - Authintication Management Indication
*
*       Desc:  This function indicates the receipt of Authintiaction management
*          request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatAuthMgmtInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaAuthEv    *authEv     /* Authintication Event Structure */
)
#else
PRIVATE S16 PtUiMatAuthMgmtInd(pst, suId, suDlgId, spDlgId, invkId, oprType, authEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaAuthEv    *authEv;        /* Authintication Event Structure */
#endif
{
   TRC2(PtUiMatAuthMgmtInd)
 
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA365, (ErrVal)0, "PtUiMatAuthMgmtInd () Failed");
#endif
    RETVALUE(ROK);
 
} /* end of PtUiMatAuthMgmtInd */

#endif /* MAP_HLR */

/* --------------- Identification Management ------------------------ */
#if MAP_VLR
/*
*
*       Fun:   upper interface - IMEI Management Indication
* 
*       Desc:  call IMEI Management Indication through matrix selector
* 
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatIMEIMgmtInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaIMEIEv    *imeiEv     /* IMEI Event Structure */
)
#else
PRIVATE S16 PtUiMatIMEIMgmtInd(pst, suId, suDlgId, spDlgId, invkId, oprType, imeiEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaIMEIEv    *imeiEv;        /* IMEI Event Structure */
#endif
{
   TRC2(PtUiMatIMEIMgmtInd)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA366, (ErrVal)0, "PtUiMatIMEIMgmtInd () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatIMEIMgmtInd */
#endif /* MAP_VLR */

#if (MAP_MSC || MAP_GSN)
/*
*
*       Fun:   upper interface - IMEI Management Confirm
* 
*       Desc:  call IMEI Management Confirm through matrix selector
* 
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatIMEIMgmtCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,          /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaIMEIEv    *imeiEv     /* IMEI Event Structure */
)
#else
PRIVATE S16 PtUiMatIMEIMgmtCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr, prvErr, imeiEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;          /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaIMEIEv    *imeiEv;        /* IMEI Event Structure */
#endif
{
   TRC2(PtUiMatIMEIMgmtCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA367, (ErrVal)0, "PtUiMatIMEIMgmtCfm () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatIMEIMgmtCfm */
#endif /* MAP_MSC || MAP_GSN */

/* --------------- Fault and Recovery Management -------------------- */
#if (MAP_VLR || MAP_HLR)

/*
*
*       Fun:   upper interface - Fault and Recovery Management Confirm
* 
*       Desc:  call Fault and Recovery Management Confirm through matrix
*          selector
* 
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatFRMgmtCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaFREv    *frEv             /* Fault and Recovery Management Event Structure */
)
#else
PRIVATE S16 PtUiMatFRMgmtCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr, prvErr, frEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;         /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaFREv    *frEv;        /* Fault and Recovery Management Event Structure */
#endif
{
   TRC2(PtUiMatFRMgmtCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA368, (ErrVal)0, "PtUiMatFRMgmtCfm () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatFRMgmtCfm */

#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)

/*
*
*       Fun:   upper interface - Fault and Recovery Management Indication
*
*       Desc:  call Fault and Recovery Management Indication through matrix
*          selector
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatFRMgmtInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaFREv    *frEv             /* Fault and Recovery Event Structure */
)
#else
PRIVATE S16 PtUiMatFRMgmtInd(pst, suId, suDlgId, spDlgId, invkId, oprType, frEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaFREv    *frEv;        /* Fault and Recovery Event Structure */
#endif
{
   TRC2(PtUiMatFRMgmtInd)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA369, (ErrVal)0, "PtUiMatFRMgmtInd () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatFRMgmtInd */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

/* --------------- OAM Management ----------------------------------- */
#if (MAP_MSC || MAP_VLR || MAP_HLR)

/*
*
*       Fun:   upper interface - Operation and Maintenance Confirm
*
*       Desc:  call Operation and Maintenance Confirm through matrix selector
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatOAMCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaOAMEv    *oamEv       /* Operation and Maintenance Event Structure */
)
#else
PRIVATE S16 PtUiMatOAMCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr, prvErr, oamEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;         /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaOAMEv    *oamEv;      /* Operation and Maintenance Event Structure */
#endif
{
   TRC2(PtUiMatOAMCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA370, (ErrVal)0, "PtUiMatOAMCfm () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatOAMCfm */

#endif /* MAP_MSC || MAP_VLR || MAP_HLR */

#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)

/*
*
*       Fun:   upper interface - Operation and Maintenance Indication
*
*       Desc:  call Operation and Maintenance Indication through matrix selector
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatOAMInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaOAMEv    *oamEv       /* Operation and Maintenance Event Structure */
)
#else
PRIVATE S16 PtUiMatOAMInd(pst, suId, suDlgId, spDlgId, invkId, oprType, oamEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaOAMEv    *oamEv;      /* Operation and Maintenance Event Structure */
#endif
{
   TRC2(PtUiMatOAMInd)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA371, (ErrVal)0, "PtUiMatOAMInd () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatOAMInd */

#endif /* MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN */

/* --------------- Call Management ----------------------------------- */
#if (MAP_MSC || MAP_VLR || MAP_HLR)
/*
*
*       Fun:   upper interface - Call Management Indication
*
*       Desc:  call Call Management Indication through matrix selector
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatCallMgmtInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaCallEv    *callEv     /* Call Event Structure */
)
#else
PRIVATE S16 PtUiMatCallMgmtInd(pst, suId, suDlgId, spDlgId, invkId, oprType, callEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaCallEv    *callEv;        /* Call Event Structure */
#endif
{
   TRC2(PtUiMatCallMgmtInd)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA372, (ErrVal)0, "PtUiMatCallMgmtInd () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatCallMgmtInd */

/*
*
*       Fun:   upper interface - call Management Confirm
*
*       Desc:  call call Management Confirm through matrix selector
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatCallMgmtCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaCallEv    *callEv     /* Call Management Event Structure */
)
#else
PRIVATE S16 PtUiMatCallMgmtCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr, prvErr, callEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;         /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaCallEv    *callEv;        /* call Management Event Structure */
#endif
{
   TRC2(PtUiMatCallMgmtCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
    MALOGERROR(ERRCLS_DEBUG, EMA373, (ErrVal)0, "PtUiMatCallMgmtCfm () Failed");
#endif
    RETVALUE(ROK);
} /* end of PtUiMatCallMgmtCfm */

#endif /* MAP_MSC || MAP_VLR || MAP_HLR */

/* --------------- Supplementary Services Management ----------------- */
#if (MAP_VLR || MAP_HLR)

/*
*
*       Fun:   upper interface - Supplementry Services Indication
*
*       Desc:  call Supplementry Services Indication through matrix selector
* 
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatSSInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaInvokeId *lnkId,      /* Linked Invoke Id */
MaSSEv    *ssEv             /* Supplementry Services Event Structure */
)
#else
PRIVATE S16 PtUiMatSSInd(pst, suId, suDlgId, spDlgId, invkId, oprType, lnkId, ssEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaInvokeId *lnkId;      /* Linked Invoke Id */
MaSSEv    *ssEv;        /* Supplementry Services Event Structure */
#endif
{
   TRC2(PtUiMatSSInd)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA374, (ErrVal)0, "PtUiMatSSInd () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatSSInd */
#endif /* MAP_HLR */

#if (MAP_VLR || MAP_HLR)
/*
*
*       Fun:   upper interface - Supplementry Services Confirm
*
*       Desc:  call Supplementry Services Confirm through matrix selector
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatSSCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,         /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaSSEv    *ssEv             /* Supplementry Services Event Structure */
)
#else
PRIVATE S16 PtUiMatSSCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr, prvErr, ssEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;         /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaSSEv    *ssEv;        /* Supplementry Services Event Structure */
#endif
{
   TRC2(PtUiMatSSCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA375, (ErrVal)0, "PtUiMatSSCfm () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatSSCfm */

#endif /* MAP_VLR || MAP_HLR */

/* --------------- Short Message Services Management ------------------ */
#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)

/*
*
*       Fun:   upper interface - Short Message Confirm
*
*       Desc:  call Short Message Confirm through matrix selector
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatSMCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,          /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaSMEv    *smEv             /* Short Message Event Structure */
)
#else
PRIVATE S16 PtUiMatSMCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr, prvErr, smEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;         /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaSMEv    *smEv;        /* Short Message Event Structure */
#endif
{
   TRC2(PtUiMatSMCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA376, (ErrVal)0, "PtUiMatSMCfm () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatSMCfm */

#endif /* MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_MSC || MAP_HLR || MAP_GSN)

/*
*
*       Fun:   upper interface - Short Message Indication
*
*       Desc:  call Short Message Indication through matrix selector
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatSMInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaSMEv    *smEv             /* Short Message Event Structure */
)
#else
PRIVATE S16 PtUiMatSMInd(pst, suId, suDlgId, spDlgId, invkId, oprType, smEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaSMEv    *smEv;        /* Short Message Event Structure */
#endif
{
   TRC2(PtUiMatSMInd)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA377, (ErrVal)0, "PtUiMatSMInd () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatSMInd */
#endif /* MAP_MSC || MAP_HLR || MAP_GSN */

/* --------------- Subscriber Management ------------------------------ */
#if (MAP_VLR || MAP_HLR || MAP_GSN || MAP_MLC)

/*
*
*       Fun:   upper interface - Subscriber Management Indication
*
*       Desc:  call Subscriber Management Indication through matrix selector
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatSubMgmtInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaSubEv    *subEv       /* Subscriber Event Structure */
)
#else
PRIVATE S16 PtUiMatSubMgmtInd(pst, suId, suDlgId, spDlgId, invkId, oprType, subEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaSubEv    *subEv;      /* Subscriber Event Structure */
#endif
{
   TRC2(PtUiMatSubMgmtInd)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA378, (ErrVal)0, "PtUiMatSubMgmtInd () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatSubMgmtInd */
#endif /* MAP_VLR || MAP_HLR || MAP_GSN || MAP_MLC */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
/*
*
*       Fun:   upper interface - Subscriber Management Confirm
* 
*       Desc:  call Subscriber Management Confirm through matrix selector
* 
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatSubMgmtCfm
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaUsrErr   *usrErr,          /* User Error */
MaPrvErr   *prvErr,     /* Provider Error */
MaSubEv    *subEv       /* Subscriber Management Event Structure */
)
#else
PRIVATE S16 PtUiMatSubMgmtCfm(pst, suId, suDlgId, spDlgId, invkId, oprType, usrErr, prvErr, subEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaUsrErr   *usrErr;         /* User Error */
MaPrvErr   *prvErr;     /* Provider Error */
MaSubEv    *subEv;      /* Subscriber Management Event Structure */
#endif
{
   TRC2(PtUiMatSubMgmtCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA379, (ErrVal)0, "PtUiMatSubMgmtCfm () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatSubMgmtCfm */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

/* --------------- PDP Context Activation Management ------------------ */
#if (MAP_HLR || MAP_GSN)

/*
*
*       Fun:   upper interface - Pdp Cntxt Act.Indication
*
*       Desc:  call Short Message Indication through matrix selector
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatNwReqPdpCntxtActvInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaPdpActvEv    *pdpActvEv               /* Short Message Event Structure */
)
#else
PRIVATE S16 PtUiMatNwReqPdpCntxtActvInd(pst, suId, suDlgId, spDlgId, invkId, oprType
, pdpActvEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaPdpActvEv    *pdpActvEv;      /* Short Message Event Structure */
#endif
{
   TRC2(PtUiMatNwReqPdpCntxtActvInd)
#if (ERRCLASS & ERRCLS_DEBUG)
   MALOGERROR(ERRCLS_DEBUG, EMA380, (ErrVal)0, 
              "PtUiMatNwReqPdpCntxtActvInd () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatNwReqPdpCntxtActvInd */

/*
*
*       Fun:   upper interface - Pdp Cntxt Act.Confirm
* 
*       Desc:  call Short Message Confirm through matrix selector
* 
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatNwReqPdpCntxtActvCfm
(
Pst        *pst,             /* post structure */
SuId       suId,             /* service user id */
MaDlgId    suDlgId,          /* Service user dialogue Id */
MaDlgId    spDlgId,          /* Service provider dialogue Id */
MaInvokeId *invkId,          /* Invoke Id */
MaOprType  oprType,          /* Operation type */
MaUsrErr   *usrErr,          /* User Error */
MaPrvErr   *prvErr,          /* Provider Error */
MaPdpActvEv    *pdpActvEv    /* Short Message Event Structure */
)
#else
PRIVATE S16 PtUiMatNwReqPdpCntxtActvCfm(pst, suId, suDlgId, spDlgId, invkId, oprType
, usrErr, prvErr, pdpActvEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaUsrErr   *usrErr;         /* User Error */
MaPrvErr   *prvErr;         /* Provider Error */
MaPdpActvEv    *pdpActvEv;  /* Event Structure */
#endif
{
   TRC2(PtUiMatNwReqPdpCntxtActvCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
   MALOGERROR(ERRCLS_DEBUG, EMA381, (ErrVal)0, 
           "PtUiMatNwReqPdpCntxtActvCfm () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatNwReqPdpCntxtActvCfm */

#endif /* MAP_HLR || MAP_GSN */

#if (MAP_REL98 || MAP_REL99)

/* --------------- Location Services Management ------------------ */
#if (MAP_MSC || MAP_HLR || MAP_MLC || (MAP_REL99 && MAP_REL4 && MAP_GSN))

/*
*
*       Fun:   upper interface - Loc. Serv.Indication
*
*       Desc:  call Location Serv. Indication through matrix selector
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatLocServInd
(
Pst        *pst,            /* post structure */
SuId       suId,            /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId,     /* Invoke Id */
MaOprType  oprType,     /* Operation type */
MaLocServEv    *locServEv   /* Location Service Event Structure */
)
#else
PRIVATE S16 PtUiMatLocServInd(pst, suId, suDlgId, spDlgId, invkId, oprType
, locServEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;       /* Service user dialogue Id */
MaDlgId  spDlgId;       /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
MaOprType  oprType;     /* Operation type */
MaLocServEv    *locServEv;      /* Location Service Event Structure */
#endif
{
   TRC2(PtUiMatLocServInd)
#if (ERRCLASS & ERRCLS_DEBUG)
   MALOGERROR(ERRCLS_DEBUG, EMA382, (ErrVal)0, 
              "PtUiMatLocServInd () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatLocServInd */
#endif /* MAP_HLR || MAP_MSC */

#if (MAP_MSC || MAP_MLC || (MAP_REL99 && MAP_REL4 && MAP_GSN))
/*
*
*       Fun:   upper interface - Loc. Serv.Confirm
* 
*       Desc:  call Loc. Serv. Confirm through matrix selector
* 
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiMatLocServCfm
(
Pst        *pst,             /* post structure */
SuId       suId,             /* service user id */
MaDlgId    suDlgId,          /* Service user dialogue Id */
MaDlgId    spDlgId,          /* Service provider dialogue Id */
MaInvokeId *invkId,          /* Invoke Id */
MaOprType  oprType,          /* Operation type */
MaUsrErr   *usrErr,          /* User Error */
MaPrvErr   *prvErr,          /* Provider Error */
MaLocServEv    *locServEv    /* Loc. Serv. Event Structure */
)
#else
PRIVATE S16 PtUiMatLocServCfm(pst, suId, suDlgId, spDlgId, invkId, oprType
, usrErr, prvErr, locServEv)
Pst      *pst;              /* post structure */
SuId     suId;              /* service user id */
MaDlgId  suDlgId;           /* Service user dialogue Id */
MaDlgId  spDlgId;           /* Service provider dialogue Id */
MaInvokeId *invkId;         /* Invoke Id */
MaOprType  oprType;         /* Operation type */
MaUsrErr   *usrErr;         /* User Error */
MaPrvErr   *prvErr;         /* Provider Error */
MaLocServEv    *locServEv;  /* Loc. Serv. Event Structure */
#endif
{
   TRC2(PtUiMatLocServCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
   MALOGERROR(ERRCLS_DEBUG, EMA383, (ErrVal)0, 
           "PtUiMatLocServCfm () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtUiMatLocServCfm */

#endif /* MAP_MLC */

#endif /* MAP_REL98 || MAP_REL99 */
#endif /* (!(defined(LCMAUIMAT) && defined(AU) && defined(LWLCMAUIMAT))) */


/********************************************************************30**
  
         End of file:     ma_ptui.c@@/main/9 - Fri Sep 16 02:45:58 2005
  
*********************************************************************31*/
  

/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

 
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  aa   1. initial release

*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.2          ---      aa   1. Removed the lnkId parameter from SSCfm primtives
             ---      aa   2. Include cm_ss7.h

1.3          ---      aa   1. Moved XXYYMatAuthMgmtInd from #ifdef MSC to HLR.
             ---      ssk  2. Added MAP Phase 2+ variant                     

/main/4      ---      jie  1. update for MAP 1.5 release.
 
             ---      jie  1. Rolling Upgrade compliance.

             ---      jie  1. Change for 3.9.0 REL_99 support.

             ---      jie  1. Change for MAP REL4 support without the MAPsec 
                              feature.

/main/5      ---      jie  1. update for MAP 1.6 release.

/main/6      ---      jie  1. update for MAP 1.7 release.

/main/8      ---       cp  1. Removed MAT_INTF2 flag
/main/9      ---     rbabu 1. update for MAP 2.3 release.
*********************************************************************91*/
