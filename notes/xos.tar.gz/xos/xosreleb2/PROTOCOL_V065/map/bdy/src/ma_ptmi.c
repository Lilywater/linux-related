/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     MAP - layer management interface - portable
  
     Type:     C source file
  
     Desc:     C source code for the MAP Layer Manager interface
               primitives, mapping to layer manager.

     File:     ma_ptmi.c
  
     Sid:      ma_ptmi.c@@/main/9 - Fri Sep 16 02:45:44 2005
  
     Prg:      aa
  
*********************************************************************21*/
  

/*
  
The following functions are provided in this file:

     MaMiLmaStaInd      Status Indication
     MaMiLmaStaCfm      Status Confirm
     MaMiLmaStsCfm      Statistics Confirm
     MaMiLmaTrcInd      Trace Indication
   
It should be noted that not all of these functions may be required
by a particular layer management service user.

It is assumed that the following functions are provided in MAP.

     MaMiLmaCfgReq      Configure Request
     MaMiLmaStaReq      Status Request
     MaMiLmaStsReq      Statistics Request
     MaMiLmaCntrlReq    Control Request
   
*/
  

/* header include files (.h) */
  
#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common SS7 */
#include "lma.h"           /* layer management, MAP */
#include "stu.h"           /* TCAP interface */
#include "cm5.h"
#include "mat.h"           /* MAP user interface */
#ifdef MA_FTHA             /* fault tolerance */
#include "sht.h"           /* SHT Interface header file */
#endif /* MA_FTHA */
#include "ma.h"            /* layer management, MAP */
#include "ma_err.h"        /* tcap error defines */  
#ifdef ZJ
#include "cm_ftha.h"       /* Common FTHA */
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#include "cm_tupsf.h"      /* Common TCAP user PSF */
#endif /* ZJ */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* ss7 layer */
#include "lma.x"           /* layer management, MAP */
#include "cm5.x"
#include "stu.x"           /* TCAP interface */
#include "mat.x"           /* MAP user interface */
#ifdef MA_FTHA             /* fault tolerance */
#include "sht.x"           /* SHT Interface */
#ifdef ZJ
#include "cm_ftha.x"       /* Common FTHA */
#include "cm_pftha.x"      /* Common PSF defines */
#include "cm_psfft.x"
#include "cm_tupsf.x"      /* Common TCAP user PSF */
#endif /* ZJ */
#endif /* MA_FTHA */
#include "ma.x"            /* Product header     */

/* forward references */
#if (!(defined(SM) && defined(LCMAMILMA)))
PRIVATE S16 PtMiLmaStaInd ARGS((Pst *pst,   MaMngmt *usta));
PRIVATE S16 PtMiLmaStaCfm ARGS((Pst *pst, MaMngmt *sta));
PRIVATE S16 PtMiLmaStsCfm ARGS((Pst *pst, Action action, MaMngmt *sts)); 
PRIVATE S16 PtMiLmaTrcInd ARGS((Pst *pst, MaMngmt *trc));
PRIVATE S16 PtMiLmaCfgCfm ARGS((Pst *pst,   MaMngmt *cfm));
PRIVATE S16 PtMiLmaCntrlCfm ARGS((Pst *pst, MaMngmt *cfm)); 
#endif /* (!(defined(SM) && defined(LCMAMILMA))) */
#ifndef SH
#ifdef MA_FTHA            
PRIVATE S16 PtMaMiShtCntrlCfm    ARGS((Pst *pst, ShtCntrlCfmEvnt *cfmInfo));
#endif /* MA_FTHA */
#endif /* ndef SH */


/* local externs */

/*
 
the following matrices define the mapping between the primitives
called by the layer management interface of MAP and the corresponding
primitives of the MAP service user(s).
 
The parameter MAXMAMI defines the maximum number of service users on
top of MAP. There is an array of functions per primitive
invoked by MAP. Every array is MAXMAMI long (i.e. there
are as many functions as the number of service users).
 
The dispatching is performed by the configurable variable: selector.
The selector is configured during general configuration.
 
The selectors are:
 
   0 - loosely coupled (#define LCMAMILMA)
   1 - Lma (#define SM)
 
*/

/* Status Indication primitive */
 
PRIVATE LmaStaInd MaMiLmaStaIndMt[MAXMAMI] =
{
#ifdef LCMAMILMA
   cmPkLmaStaInd,        /* 0 - loosely coupled  */
#else
   PtMiLmaStaInd,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SmMiLmaStaInd,          /* 1 - tightly coupled, layer management */
#else
   PtMiLmaStaInd,          /* 1 - tightly coupled, portable */
#endif
};

/* Config confirm primitive */
 
PRIVATE LmaCfgCfm MaMiLmaCfgCfmMt[MAXMAMI] =
{
#ifdef LCMAMILMA
   cmPkLmaCfgCfm,        /* 0 - loosely coupled  */
#else
   PtMiLmaCfgCfm,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SmMiLmaCfgCfm,          /* 1 - tightly coupled, layer management */
#else
   PtMiLmaCfgCfm,          /* 1 - tightly coupled, portable */
#endif
};

/* Control Confirm primitive */
 
PRIVATE LmaCntrlCfm MaMiLmaCntrlCfmMt[MAXMAMI] =
{
#ifdef LCMAMILMA
   cmPkLmaCntrlCfm,        /* 0 - loosely coupled  */
#else
   PtMiLmaCntrlCfm,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SmMiLmaCntrlCfm,          /* 1 - tightly coupled, layer management */
#else
   PtMiLmaCntrlCfm,          /* 1 - tightly coupled, portable */
#endif
};

/* Status confirm primitive */
 
PRIVATE LmaStaCfm MaMiLmaStaCfmMt[MAXMAMI] =
{
#ifdef LCMAMILMA
   cmPkLmaStaCfm,        /* 0 - loosely coupled  */
#else
   PtMiLmaStaCfm,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SmMiLmaStaCfm,          /* 1 - tightly coupled, layer management */
#else
   PtMiLmaStaCfm,          /* 1 - tightly coupled, portable */
#endif
};

/* Statistics confirm primitive */
 
PRIVATE LmaStsCfm MaMiLmaStsCfmMt[MAXMAMI] =
{
#ifdef LCMAMILMA
   cmPkLmaStsCfm,        /* 0 - loosely coupled  */
#else
   PtMiLmaStsCfm,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SmMiLmaStsCfm,          /* 1 - tightly coupled, layer management */
#else
   PtMiLmaStsCfm,          /* 1 - tightly coupled, portable */
#endif
};
 
/* Trace Indication primitive */
 
PRIVATE LmaTrcInd MaMiLmaTrcIndMt[MAXMAMI] =
{
#ifdef LCMAMILMA
   cmPkLmaTrcInd,        /* 0 - loosely coupled  */
#else
   PtMiLmaTrcInd,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SmMiLmaTrcInd,          /* 1 - tightly coupled, layer management */
#else
   PtMiLmaTrcInd,          /* 1 - tightly coupled, portable */
#endif
};

#ifdef MA_FTHA
/* System agent control Confirm primitive */
PRIVATE ShtCntrlCfm MaMiShtCntrlCfmMt[MAXMAMI] =
{
   cmPkMiShtCntrlCfm,               /* 0 - loosely coupled          */
#ifdef SH
   ShMiShtCntrlCfm,                 /* 1 - tightly coupled system agent */
#else
   PtMaMiShtCntrlCfm,               /* 1 - tightly coupled, portable*/
#endif
};
#endif /* MA_FTHA */

/*
*     layer management interface functions 
*/
 
#ifdef MA_FTHA
/*
*
*       Fun:   System agent control Confirm
*
*       Desc:  This function is used to send the system agent control confirm 
*              primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 MaMiShtCntrlCfm
(
Pst *pst,                /* post structure */
ShtCntrlCfmEvnt *cfmInfo     /* system agent control confirm event */
)
#else
PUBLIC S16 MaMiShtCntrlCfm(pst, cfmInfo)
Pst *pst;                /* post structure */
ShtCntrlCfmEvnt *cfmInfo;    /* system agent control confirm event */
#endif
{
   TRC3(MaMiShtCntrlCfm)

   /* jump to specific primitive depending on configured selector */
   (*MaMiShtCntrlCfmMt[pst->selector])(pst, cfmInfo); 

   RETVALUE(ROK);
} /* end of MaMiShtCntrlCfm */ 
#endif /* MA_FTHA */

/*
*
*       Fun:   Status Indication
*
*       Desc:  This function is used to indicate the status of MAP
*              to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaMiLmaStaInd
(
Pst *pst,                 /* post structure */
MaMngmt *usta             /* unsolicited status */
)
#else
PUBLIC S16 MaMiLmaStaInd(pst, usta)
Pst *pst;                 /* post structure */   
MaMngmt *usta;            /* unsolicited status */
#endif
{
   TRC3(MaMiLmaStaInd)
   /* jump to specific primitive depending on configured selector */
   RETVALUE((*MaMiLmaStaIndMt[pst->selector])(pst, usta)); 
} /* end of MaMiLmaStaInd */


/*
*
*       Fun:   config Confirm
*
*       Desc:  This function is used to return the config req. status of MAP
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaMiLmaCfgCfm
(
Pst *pst,                 /* post structure */     
MaMngmt *cfm              /* config.   confirm */
)
#else
PUBLIC S16 MaMiLmaCfgCfm(pst, cfm)
Pst *pst;                 /* post structure */     
MaMngmt *cfm;             /* config.  confirm */
#endif
{
   TRC3(MaMiLmaCfgCfm)
   /* jump to specific primitive depending on configured selector */
   RETVALUE((*MaMiLmaCfgCfmMt[pst->selector])(pst, cfm)); 
} /* end of MaMiLmaCfgCfm */

/*
*
*       Fun:   Control Confirm
*
*       Desc:  This function is used to return the status of MAP
*              control req. to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaMiLmaCntrlCfm
(
Pst *pst,                 /* post structure */     
MaMngmt *cfm              /* Confirm          */
)
#else
PUBLIC S16 MaMiLmaCntrlCfm(pst, cfm)
Pst *pst;                 /* post structure */     
MaMngmt *cfm;             /* Confirm          */
#endif
{
   TRC3(MaMiLmaCntrlCfm)
   /* jump to specific primitive depending on configured selector */
   RETVALUE((*MaMiLmaCntrlCfmMt[pst->selector])(pst, cfm)); 
} /* end of MaMiLmaCntrlCfm */

/*
*
*       Fun:   Status Confirm
*
*       Desc:  This function is used to return the status of MAP
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaMiLmaStaCfm
(
Pst *pst,                 /* post structure */     
MaMngmt *sta              /* solicited status */
)
#else
PUBLIC S16 MaMiLmaStaCfm(pst, sta)
Pst *pst;                 /* post structure */     
MaMngmt *sta;             /* solicited status */
#endif
{
   TRC3(MaMiLmaStaCfm)
   /* jump to specific primitive depending on configured selector */
   RETVALUE((*MaMiLmaStaCfmMt[pst->selector])(pst, sta)); 
} /* end of MaMiLmaStaCfm */

/*
*
*       Fun:   Statistics Confirm
*
*       Desc:  This function is used to return the statistics of MAP
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaMiLmaStsCfm
(
Pst *pst,                 /* post structure */    
Action action,            /* action */
MaMngmt *sts              /* statistics */
)
#else
PUBLIC S16 MaMiLmaStsCfm(pst, action, sts)
Pst *pst;                 /* post structure */    
Action action;            /* action */
MaMngmt *sts;             /* statistics */
#endif
{
   TRC3(MaMiLmaStsCfm)
   /* jump to specific primitive depending on configured selector */
   RETVALUE((*MaMiLmaStsCfmMt[pst->selector])(pst, action, sts)); 
} /* end of MaMiLmaStsCfm */


/*
*
*       Fun:   Trace Indication
*
*       Desc:  This function is used to indicate the trace of MAP
*              to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MaMiLmaTrcInd
(
Pst *pst,                 /* post structure */
MaMngmt *trc              /* unsolicited status */
)
#else
PUBLIC S16 MaMiLmaTrcInd(pst, trc)
Pst *pst;                 /* post structure */   
MaMngmt *trc;             /* unsolicited status */
#endif
{
   TRC3(MaMiLmaTrcInd)
   /* jump to specific primitive depending on configured selector */
   RETVALUE((*MaMiLmaTrcIndMt[pst->selector])(pst, trc)); 
} /* end of MaMiLmaTrcInd */ 

#if (!(defined(SM) && defined(LCMAMILMA)))

/* portable functions */

/*
*
*       Fun:   Portable Status Confirm
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLmaStaCfm
(
Pst *pst,                   /* post structure */
MaMngmt *sta                /* solicited status */
)
#else
PRIVATE S16 PtMiLmaStaCfm(pst, sta)
Pst *pst;                   /* post structure */
MaMngmt *sta;               /* solicited status */
#endif
{
  TRC3(PtMiLmaStaCfm);
#if (ERRCLASS & ERRCLS_DEBUG)
  MALOGERROR(ERRCLS_DEBUG, EMA342, (ErrVal)0, "PtMiLmaStaCfm () Failed");
#endif
  RETVALUE(ROK);
} /* end of PtMiLmaStaCfm */


/*
*
*       Fun:   Portable Status Indication
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLmaStaInd
(
Pst *pst,                    /* post structure */
MaMngmt *usta                /* unsolicited status */
)
#else
PRIVATE S16 PtMiLmaStaInd(pst, usta)
Pst *pst;                    /* post structure */
MaMngmt *usta;               /* unsolicited status */
#endif
{
  TRC3(PtMiLmaStaInd);
#if (ERRCLASS & ERRCLS_DEBUG)
  MALOGERROR(ERRCLS_DEBUG, EMA343, (ErrVal)0, "PtMiLmaStaInd () Failed");
#endif
  RETVALUE(ROK);
} /* end of PtMiLmaStaInd */


/*
*
*       Fun:   Portable Statistics Confirm
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ma_ptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLmaStsCfm
(
Pst *pst,           /* post structure */
Action action,            /* action */
MaMngmt *sts                /* statistics */
)
#else
PRIVATE S16 PtMiLmaStsCfm(pst, action, sts)
Pst *pst;           /* post structure */
Action action;            /* action */
MaMngmt *sts;               /* statistics */
#endif
{
  TRC3(PtMiLmaStsCfm);
#if (ERRCLASS & ERRCLS_DEBUG)
  MALOGERROR(ERRCLS_DEBUG, EMA344, (ErrVal)0, "PtMiLmaStsCfm () Failed");
#endif
  RETVALUE(ROK);
} /* end of PtMiLmaStsCfm */


/*
*
*       Fun:   Portable Trace Indication
*
*       Desc:  
*
*       Ret:   None
*
*       Notes: None
*
*       File:  ma_ptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLmaTrcInd
(
Pst *pst,           /* post structure */
MaMngmt *trc                /* trace */
)
#else
PRIVATE S16 PtMiLmaTrcInd(pst, trc)
Pst *pst;           /* post structure */
MaMngmt *trc;               /* trace */
#endif
{
  TRC3(PtMiLmaTrcInd);
#if (ERRCLASS & ERRCLS_DEBUG)
  MALOGERROR(ERRCLS_DEBUG, EMA345, (ErrVal)0, "PtMiLmaTrcInd () Failed");
#endif
  RETVALUE(ROK);
} /* end of PtMiLmaTrcInd */




/*
*
*       Fun:   Portable Configuration Confirm
*
*       Desc:  
*
*       Ret:   None
*
*       Notes: None
*
*       File:  ma_ptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLmaCfgCfm
(
Pst *pst,           /* post structure */
MaMngmt *trc                /* trace */
)
#else
PRIVATE S16 PtMiLmaCfgCfm(pst, trc)
Pst *pst;           /* post structure */
MaMngmt *trc;               /* trace */
#endif
{
  TRC3(PtMiLmaCfgCfm);
#if (ERRCLASS & ERRCLS_DEBUG)
  MALOGERROR(ERRCLS_DEBUG, EMA346, (ErrVal)0, "PtMiLmaCfgCfm () Failed");
#endif
  RETVALUE(ROK);
} /* end of PtMiLmaCfgCfm */



/*
*
*       Fun:   Portable Control Confirm
*
*       Desc:  
*
*       Ret:   None
*
*       Notes: None
*
*       File:  ma_ptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLmaCntrlCfm
(
Pst *pst,           /* post structure */
MaMngmt *trc                /* trace */
)
#else
PRIVATE S16 PtMiLmaCntrlCfm(pst, trc)
Pst *pst;           /* post structure */
MaMngmt *trc;               /* trace */
#endif
{
  TRC3(PtMiLmaCntrlCfm);
#if (ERRCLASS & ERRCLS_DEBUG)
  MALOGERROR(ERRCLS_DEBUG, EMA347, (ErrVal)0, "PtMiLmaCntrlCfm () Failed");
#endif
  RETVALUE(ROK);
} /* end of PtMiLmaCntrlCfm */
#endif /* (!(defined(SM) && defined(LCMAMILMA))) */

#ifndef SH
#ifdef MA_FTHA
/*
 *
 *       Fun:    PtIaMiShtCntrlCfm
 *
 *       Desc:   Dummy SHT Contrl Confirm, customize if neccessary.
 *
 *       Ret:    ROK     - succeeded
 *               RFAILED - failed
 *
 *       Notes:  None
 *
 *       File:   ma_ptmi.c
 *
 */

#ifdef ANSI
PRIVATE S16 PtMaMiShtCntrlCfm
(
Pst         *pst,
ShtCntrlCfmEvnt *cfmInfo
)
#else
PRIVATE S16 PtMaMiShtCntrlCfm(pst, cfmInfo)
Pst         *pst;
ShtCntrlCfmEvnt *cfmInfo;
#endif /* ANSI */
{
   TRC3(PtMaMiShtCntrlCfm)

   UNUSED(pst);
   UNUSED(cfmInfo);
#if (ERRCLASS & ERRCLS_DEBUG)
  MALOGERROR(ERRCLS_DEBUG, EMA348, (ErrVal)0, "PtMiShtCntrlCfm () Failed");
#endif

   RETVALUE(ROK);
} /* end of PtMaMiShtCntrlCfm() */
#endif /* MA_FTHA */
#endif /* ndef SH */

/********************************************************************30**
  
         End of file:     ma_ptmi.c@@/main/9 - Fri Sep 16 02:45:44 2005

*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

 
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  aa    1. initial release

*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.2          ---      aa   1. Change the packing order in StaInd to make it
                              consistent with other packing routines.
             ---      aa   2. Moved cm_ss7.x above lma.x

1.3          ---      ssk  1. Added Phase 2+ variant

1.4          ---      jz   1. Changes for TCR0018,  System agent cntrl Cfm 
                              primitive added

/main/4      ---      jie  1. update for MAP 1.5 release.

             ---      jie  1. MaMiShtCntrlCfm prototype is moved to ma.x.
                           2. error log is added and return value is changed
                              to OK inside PtMaMiShtCntrlCfm.

             ---      jie  1. removed extern maInit.

             ---      yz   1. add extern maInit within error class flag.

             ---      yz   1. Add MA_FTHA flag to avoid warning.

/main/5      ---      jie  1. update for MAP 1.6 release.

/main/6      ---      jie  1. update for MAP 1.7 release.

/main/8      ---      cp   1. update for MAP release 2.2
/main/9      ---       st  1. Updated for MAP sotware release 2.3
         ma002.203    dv   1. Introduced maCb global control block.
                           2. Moved global variables to maCb.
                           3. Introduced SS_MULTIPLE_PROCS to aid
                              in internal testing.
*********************************************************************91*/
