#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "lma.h"           /* layer management, MAP */
#include "cm_err.h"        /* common error */
#include "stu.h"           /* tcap layer */
#include "mat.h"           /* MAT Interface */
#ifdef MA_FTHA
#include  "sht.h"
#endif /* MA_FTHA */
#include "cm5.h"           /* common timer */
#include "ma_err.h"        /* map error */
#include "cm_ss7.h"
#include "ma.h"            /* map */
#ifdef ZJ
#include "cm_ftha.h"       /* Common FTHA */
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#include "cm_tupsf.h"      /* Common TCAP user PSF */
#include "zj.h"            /* Tcap PSF defines */
#include "lzj.h"
#endif /* ZJ */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* common timer */
#include "cm_lib.x"        /* Common Portable Library */
#include "cm_ss7.x"        /* common SS7 */
#include "stu.x"           /* tcap layer */
#include "lma.x"           /* layer management, TCAP */
#include "mat.x"           /* MAT Interface */
#ifdef MA_FTHA
#include  "sht.x"
#endif /* MA_FTHA */
#ifdef ZJ
#include "cm_ftha.x"       /* Common FTHA */
#include "cm_pftha.x"      /* Common PSF defines */
#include "cm_psfft.x"
#include "cm_tupsf.x"      /* Common TCAP user PSF */
#endif /* ZJ */
#include "ma.x"            /* map */
#ifdef ZJ
#include "zj.x"            /* Tcap PSF defines */
#include "lzj.x"
#endif /* ZJ */

EXTERN S16 smMaPstInit(Pst *smMaPst);
EXTERN S16 maHdrInit(Header *hdr);

void maBndStReq(void)
{
    Pst      maStPst;   /* post structure */
    MaMngmt  cntrl;  /* management structure */
	
	cmMemset((U8*)&cntrl, 0, sizeof(MaMngmt));
	
	maHdrInit(&cntrl.hdr);
	smMaPstInit(&maStPst);
	
	maStPst.event  =  MAT_EVTBNDREQ;
	cntrl.hdr.msgType = TCNTRL;
	cntrl.hdr.entId.ent = ENTMA;
	cntrl.hdr.entId.inst = 0;

	cntrl.hdr.elmId.elmnt = STGRSPSAP;
	cntrl.t.cntrl.action = ABND_ENA;
	cntrl.t.cntrl.subAction = SAGR_DSTPROCID;
	//cntrl.hdr.elmId.elmntInst1 = 0;
	
	(Void)MaMiLmaCntrlReq(&maStPst, &cntrl);

}

