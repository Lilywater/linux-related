/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     map
  
     Type:     C Source file
  
     Desc:     This file contains the C source code for MAP specific 
               services. (Request and Responses ) 
  
     File:     ca_bdy4.c
  
     Sid:      ca_bdy4.c@@/main/5 - Fri Sep 16 02:48:35 2005
  
     Prg:      jz
  
*********************************************************************21*/
  

/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#if MAP_MSC
#if MAP_VLR
#if MAP_HLR
      -05      MSC, VLR and HLR
#else
#endif
#else
#if MAP_HLR
#else
      -01      MSC
#endif
#endif
#else
#if MAP_VLR
#if MAP_HLR
      -04      VLR and HLR
#else
      -02      VLR
#endif
#else
#if MAP_HLR
      -03      HLR
#else
#endif
#endif
#endif

************************************************************************/
 

/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "lma.h"           /* layer management, MAP */
#include "cm_err.h"        /* common error */
#include "stu.h"           /* tcap layer */
#include "mat.h"           /* map layer */
#ifdef MA_FTHA
#include "sht.h"
#endif /* MA_FTHA */
#include "cm5.h"
#include "ma.h"            /* map */
#include "ma_mf.h"         /* map */
#include "ma_err.h"        /* map error */
#ifdef MATST
#ifdef ZJTST
#include "zj_acc.h"
#endif
#include "ma_acc.h"
#endif
#include "cm_ss7.h"
#ifdef ZJ
#include "cm_ftha.h"       /* Common FTHA */
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#include "cm_tupsf.h"      /* Common TCAP user PSF */
#include "zj.h"            /* Tcap PSF defines */
#include "lzj.h"
#endif /* ZJ */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"
#include "cm_ss7.x"           /* common */
#include "stu.x"           /* tcap layer */
#include "lma.x"           /* layer management, TCAP */
#include "mat.x"           /* map  layer */
#ifdef MA_FTHA
#include "sht.x"
#endif /* MA_FTHA */
#ifdef ZJ
#include "cm_ftha.x"       /* Common FTHA */
#include "cm_pftha.x"      /* Common PSF defines */
#include "cm_psfft.x"
#include "cm_tupsf.x"      /* Common TCAP user PSF */
#endif /* ZJ */
#include "ma.x"            /* map */
#include "cm_lib.x"        /* Common Portable Library */
#ifdef MATST
#include "ma_acc.x"
#endif
#ifdef ZJ
#include "zj.x"            /* Tcap PSF defines */
#include "lzj.x"
#endif /* ZJ */

#if MAP_REL99
#if MAP_SEC

/* Forward reference */

/* Private functions */
PRIVATE S16   maChkPpTbl ARGS((U16 ppid, U8 ppri, U16 *reason));
PRIVATE MaSaCp *maBinFindSa ARGS((U32 val, S32 low, S32 high, U32 *entry));
PRIVATE U32   maFindSaPosi ARGS((U32 *val));
PRIVATE S16   maChkAcName ARGS((U8 acName));
PRIVATE S16   maChkAcOprCode ARGS((U8 acName, U8 acVer, U8 oprCode));
PRIVATE S16   maIsSecOpr ARGS((MaDlgCp *dlgCp, U8 oprCode, LmaSecPl *pl));
PRIVATE S16   maEncSecTransTkns ARGS((MaSap *s, Buffer *hdBuf, Buffer *cpBuf, 
                                      Buffer **dstBuf));
PRIVATE S16   maDecSecTransTkns ARGS((MaSap *s, Buffer *mBuf, 
                                      MaSecHeader *secHdr, Buffer **cpBuf));
PRIVATE S16   maDecProtPayload ARGS((MaSap *s, MaDlgCp *dlgCp, StComps *cmpEv,
                                     MaSecHeader *secHdr, Buffer *cipherBuf,
                                     U8 protMode));
PRIVATE S16   maEncProtPayload ARGS((MaSap *s, MaDlgCp *dlgCp, U8 cmpType,
                                     U8 oprCode, U8 errCode, U8 mode));
PRIVATE Void  maGetPlmnStr ARGS((U8  *str, U32 val));
PRIVATE S16       maChkPlmnId164 ARGS((LmaPlmnId_E164  *plmnId164));
PRIVATE U32       maFindSaMapPosi ARGS((U32 val));
PRIVATE MaSaMapCp *maBinFindSaMap ARGS((U32 val,S32 low,S32 high,U32 *entry));
PRIVATE MaSaMapCp *maFindSaMap ARGS((U16 cc, U32 ndc));
PRIVATE S16       maGetPidFromSrcAddr ARGS((MaDlgCp *dlgCp));
PRIVATE Void      maGetE164fromGT ARGS((U16 *cc, U32 *ndc, ShrtAddrs *addr));

/* Globals variables */

/* Private variables */

/* Initialization of MAPsec PG */
PRIVATE MaPgCp   maInitPg[] = 
{
   {                    /* PG 0: No protection */
      0,          
      0xff,
      0xff,
      (LmaAcVer)0xff,
      (LmaSecPl)0xff,
   },
   {                    /* PG 1: */
      1,                /* Protection group identifier */
      MA_RESET_AC,      /* Application context name */
      MAT_RESET,        /* Operation code */
      AC_VER2,                /* Application context version */
      MAPSEC_LEVEL1,    /* Protection level */
   },
   {                    /* PG 1: */
      1,     
      MA_RESET_AC,
      MAT_RESET,
      AC_VER1,
      MAPSEC_LEVEL1,
   },
   {                    /* PG 2: */
      2, 
      MA_INTVLRINFO_RET_AC,
      MAT_SNDID,
      AC_VER3,
      MAPSEC_LEVEL3,
   },
   {                    /* PG 2: */
      2,
      MA_INTVLRINFO_RET_AC,
      MAT_SNDID,
      AC_VER2,
      MAPSEC_LEVEL3,
   },
   {                    /* PG 2: */
      2,   
      MA_INFO_RET_AC,
      MAT_AUTHINFO,
      AC_VER3,
      MAPSEC_LEVEL3,
   },
   {                    /* PG 2: */
      2, 
      MA_INFO_RET_AC,
      MAT_AUTHINFO,
      AC_VER2,
      MAPSEC_LEVEL3,
   },
   {                    /* PG 2: */
      2,
      MA_INFO_RET_AC,
      MAT_SNDPARAM,
      AC_VER1,
      MAPSEC_LEVEL3,
   },
   {                   /* PG 3: */
      3,
      MA_HO_CONTROL_AC,
      MAT_PRE_HO,
      AC_VER3,
      MAPSEC_LEVEL4,
   },
   {                   /* PG 3: */
      3, 
      MA_HO_CONTROL_AC,
      MAT_FWDACCSIG,
      AC_VER3,
      MAPSEC_LEVEL4,
   },
   {                   /* PG 3: */
      3,
      MA_HO_CONTROL_AC,
      MAT_PRE_HO,
      AC_VER2,
      MAPSEC_LEVEL4,
   },
   {                   /* PG 3: */
      3,
      MA_HO_CONTROL_AC,
      MAT_FWDACCSIG,
      AC_VER2,
      MAPSEC_LEVEL4,
   },
   {                   /* PG 3: */
      3,
      MA_HO_CONTROL_AC,
      MAT_PER_HO,
      AC_VER1,
      MAPSEC_LEVEL4,
   },
   {                   /* PG 3: */
      3,
      MA_HO_CONTROL_AC,
      MAT_FWDACCSIG,
      AC_VER1,
      MAPSEC_LEVEL4,
   },
   {                   /* PG 4: */
      4,
      MA_ANYTIME_INFO_HANDL,
      MAT_ANY_MOD,
      AC_VER3,
      MAPSEC_LEVEL1,
   },
};

/* Initialization protection profile */
PRIVATE LmaSecPpCfg maInitPp[] = 
{
   {                   /* protection profile A */
      LMA_PP_A,        /* protection profile identifier */
      0,               /* protection profile revision identifier */
      0x01,            /* protection Profile Indicator */
   },

   {                   /* protection profile B */
      LMA_PP_B,
      0,
      0x06,
   },

   {                   /* protection profile C */
      LMA_PP_C,
      0,
      0x0e,
   },

   {                   /* protection profile D */
      LMA_PP_D,
      0,
      0x1e,
   },

   {                   /* protection profile E */
      LMA_PP_E,
      0,
      0x16,
   },
};


/*
*
*       Fun:   maChkPlmnId
*
*       Desc:  validate Plmn ID parameters, it should be TBCD string format
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  ca_bdy4.c
*
*/
 
#ifdef ANSI
PUBLIC S16 maChkPlmnId
(
LmaPlmnId      *plmnId    /* self Plmn Identifier */
)
#else
PUBLIC S16 maChkPlmnId (plmnId)
LmaPlmnId      *plmnId;   /* self Plmn Identifier */
#endif
{
   U16 mcc;
   U16 mnc;
   U8  i;

   TRC2(maChkPlmnId)
  
   if ((plmnId->mcc.pres == FALSE) || (plmnId->mnc.pres == FALSE))
   {
      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
             "maChkPlmnId() failed, Plmn Id missing.\n"));
      RETVALUE(RFAILED);
   }

   mcc = plmnId->mcc.val;
   mnc = plmnId->mnc.val;

   /* mcc contains 3 digits */
   for (i=0; i<3; i++)
   {
      if ((mcc & 0x000f) > 9)
      {
         MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                "maChkPlmnId(mcc(%d)) failed, PlmnId mcc out of range.\n", 
                plmnId->mcc.val));
         RETVALUE(RFAILED);
      }
      mcc = mcc >> 4;
   }
   /* The fourth digit should be 1111 for mcc */
   if ((mcc & 0x000f) != 0x000f)
   {
      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
             "maChkPlmnId(mcc(%d)) failed, PlmnId mcc has wrong filler.\n", 
             plmnId->mcc.val));
      RETVALUE(RFAILED);
   }

   /* mnc contains 2 or 3 digits */
   for (i=0; i<2; i++)
   {
      if ((mnc & 0x000f) > 9)
      {
         MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                "maChkPlmnId(mnc(%d)) failed, PlmnId mnc out of range.\n", 
                plmnId->mnc.val));
         RETVALUE(RFAILED);
      }
      mnc = mnc >> 4;
   }

   /* The third digit can be a valid digit or a filler */
   if (((mnc & 0x000f) != 0x000f) && ((mnc & 0x000f) > 9))
   {
      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
             "maChkPlmnId(mnc(%d)) failed, the third digit of mnc wrong.\n", 
             plmnId->mnc.val));
      RETVALUE(RFAILED);
   }

   mnc = mnc >> 4;
   /* The fourth digit should be 1111 for mnc */
   if ((mnc & 0x000f) != 0x000f)
   {
      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
             "maChkPlmnId(mnc(%d)) failed, PlmnId mnc has wrong filler.\n", 
             plmnId->mnc.val));
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* maChkPlmnId */

/*
*
*       Fun:   maChkPlmnId164
*
*       Desc:  validate Plmn ID parameters, it should be TBCD string format
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  ca_bdy4.c
*
*/
 
#ifdef ANSI
PRIVATE S16 maChkPlmnId164
(
LmaPlmnId_E164  *plmnId164    /* self Plmn Identifier */
)
#else
PRIVATE S16 maChkPlmnId164 (plmnId164)
LmaPlmnId_E164   *plmnId164;   /* self Plmn Identifier */
#endif
{
   U16 cc;
   U32 ndc;
   U8  i;

   TRC2(maChkPlmnId164)
  
   if ((plmnId164->cc.pres == FALSE) || (plmnId164->ndc.pres == FALSE))
   {
      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
             "maChkPlmnId164() failed, E.164 Plmn Id missing.\n"));
      RETVALUE(RFAILED);
   }

   cc  = plmnId164->cc.val;
   ndc = plmnId164->ndc.val;

   /* mcc contains 1 ~ 3 digits */

   /* The first digit should be a valid digit */

   if (GET_U16_LSB(cc) >= BASE10)
   {
      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
             "maChkPlmnId164(cc(%d)) failed, PlmnId cc out of range.\n", 
             plmnId164->cc.val));
      RETVALUE(RFAILED);
   }
   cc = cc >> 4;

   /* The second and third digits can be a valid digit or a filler */
   for (i=2; i<4; i++)
   {
      if ((GET_U16_LSB(cc) != 0x000f) && (GET_U16_LSB(cc) >= BASE10))
      {
         MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                "maChkPlmnId164(cc(%d)) failed, the %d digit of cc wrong.\n", 
                plmnId164->cc.val, i));
         RETVALUE(RFAILED);
      }
      cc = cc >> 4;
   }

   /* The fourth digit should be 1111 for cc */
   if (GET_U16_LSB(cc) != 0x000f)
   {
      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
             "maChkPlmnId164(cc(%d)) failed, PlmnId cc has wrong filler.\n", 
             plmnId164->cc.val));
      RETVALUE(RFAILED);
   }

   /* ndc contains 1 ~ 5 digits */

   /* The first digit should be a valid digit */
   if (GET_U32_LSB(ndc) >= BASE10)
   {
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
             "maChkPlmnId164(ndc(%ld)) failed, PlmnId ndc out of range.\n", 
             plmnId164->ndc.val));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
             "maChkPlmnId164(ndc(%d)) failed, PlmnId ndc out of range.\n", 
             plmnId164->ndc.val));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   }
   ndc = ndc >> 4;

   /* The 2nd to 5th digits can be a valid digit or a filler */
   for (i=2; i<6; i++)
   {
      if ((GET_U32_LSB(ndc) != 0x0000000f) && (GET_U32_LSB(ndc) >= BASE10))
      {
#ifndef ALIGN_64BIT

            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                "maChkPlmnId164(ndc(%ld)) failed,the %d digit of ndc wrong.\n",
                plmnId164->ndc.val, i));
         RETVALUE(RFAILED);

#else
  
         MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                "maChkPlmnId164(ndc(%d)) failed,the %d digit of ndc wrong.\n",
                plmnId164->ndc.val, i));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
      }
      ndc = ndc >> 4;
   }

   /* The 6th to 8th digit should be 1111 for ndc */
   for (i=6; i<9; i++)
   {
      if (GET_U32_LSB(ndc) != 0x0000000f)
      {
#ifndef ALIGN_64BIT

           MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                "maChkPlmnId164(ndc(%ld))failed PlmnId ndc has wrong filler\n",
                plmnId164->ndc.val));
         RETVALUE(RFAILED);

#else

         MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                "maChkPlmnId164(ndc(%d))failed PlmnId ndc has wrong filler\n",
                plmnId164->ndc.val));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
      }
      ndc = ndc >> 4;
   }
   RETVALUE(ROK);

} /* maChkPlmnId164 */

/*
*
*       Fun:    maFindSaMapPosi
*
*       Desc:   Find index of SA mapping control point in SA mapping table
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PRIVATE U32 maFindSaMapPosi
(
U32        val
)
#else
PRIVATE U32 maFindSaMapPosi(val)
U32        val;
#endif
{
   U32    idx;     /* index in SA table */
   U32    plmnId;  /* Plmn id */
   S16    ret;     /* return value */
   MaSaMapCp *saMap;  /* SA mapping control block */
   U8     plmn1[4];   /* plmn id string */
   U8     plmn2[4];   /* plmn id string */

   TRC2(maFindSaMapPosi)

   maGetPlmnStr(&plmn2[0], val);

   /* This searching is needed at the configuration time, so  
    * use sequential search to find the position at which new 
    * control block is to be inserted. */

   for (idx=0; idx < maCb.maSecCp.saTbSize; idx++)
   {
      saMap = *(maCb.maSecCp.maSaMapTbl + idx);
      plmnId = saMap->plid_164;
      maGetPlmnStr(&plmn1[0], plmnId);
      ret = cmMemcmp((U8 *)&plmn1[0], (U8 *)&plmn2[0], 4);
      if (ret > 0)
      {
         /* new plmn id is less than plmnId */
         RETVALUE(idx);
      }
   }

   /* The new plmn id is the bigest */
   RETVALUE(idx);

} /* maFindSaMapPosi */

/*
*
*       Fun:    maBinFindSaMap
*
*       Desc:   Binary search a SA mapping control point in SA mapping table
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PRIVATE MaSaMapCp *maBinFindSaMap
(
U32        val,
S32        low,
S32        high,
U32        *entry
)
#else
PRIVATE MaSaMapCp *maBinFindSaMap(val, low, high,entry)
U32        val;
S32        low;
S32        high;
U32        *entry;
#endif
{
   S32    mid;
   S16    ret;   /* return value */
   MaSaMapCp *saMap;
   U8    tmp1[4];
   U8    tmp2[4];

   TRC2(maBinFindSaMap)

   if (low > high)
   {
      *entry = NULLD;
      RETVALUE((MaSaMapCp *)NULLP);
   }

   mid = (low+high)/2;
   saMap = *(maCb.maSecCp.maSaMapTbl+mid);
   maGetPlmnStr(&tmp1[0], saMap->plid_164);
   maGetPlmnStr(&tmp2[0], val);

   ret = cmMemcmp((U8 *)&tmp1[0], (U8 *)&tmp2[0], 4);

   /* Match, return item found */
   if (ret == 0)
   {
      *entry = mid;
      RETVALUE(saMap);
   }

   /* plmnId val is less than mid, search lower half */
   if (ret > 0)
   {
      RETVALUE(maBinFindSaMap(val, low, mid-1, entry));
   }
   
   /* plmnId val is greater than mid, search upper half */
   RETVALUE(maBinFindSaMap(val, mid+1, high, entry));

} /* maBinFindSaMap */

/*
*
*       Fun:    maInsSaMap
*
*       Desc:   Inserts SA mapping control point into the SA mapping table
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PUBLIC MaSaMapCp *maInsSaMap
(
U16        cc,     /* Country code */
U32        ndc     /* National destination code */
)
#else
PUBLIC MaSaMapCp *maInsSaMap(cc, ndc)
U16        cc;     /* Mobile country code */
U32        ndc;    /* National destination code */
#endif
{
   S16    ret;   /* return value */
   U32    val;   /* U32 plmnId value */
   MaSaMapCp *saMap;
   Data   *tmpBuf;
   U32    posi;  /* SA position in SA table */
   U32    i;

   TRC2(maInsSaMap)

   CAT_PLMNID_164_VAL(val, cc, ndc)

   if ((ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, &tmpBuf, 
        sizeof(MaSaMapCp))) != ROK)
   {
      RETVALUE((MaSaMapCp *)NULLP);
   }
   saMap = (MaSaMapCp *)tmpBuf;

   posi = maFindSaMapPosi(val);

   /* shift SA mapping table */
   for (i=maCb.maSecCp.saTbSize; i>posi; i--)
   {
       *(maCb.maSecCp.maSaMapTbl+i) = *(maCb.maSecCp.maSaMapTbl+i-1);
   }

   *(maCb.maSecCp.maSaMapTbl+posi) = saMap;
   saMap->plid_164 = val;
   RETVALUE(saMap);

} /* maInsSaMap */

/*
*
*       Fun:    maFindSaMap
*
*       Desc:   Find SA mapping control point in the SA mapping table
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PRIVATE MaSaMapCp *maFindSaMap
(
U16        cc,      /* Country code */
U32        ndc      /* National destination code */
)
#else
PRIVATE MaSaMapCp *maFindSaMap(cc, ndc)
U16        cc;     /* Country code */
U32        ndc;   /* National destination code */
#endif
{
   U32    val;      /* U32 plmnId value */
   U32    low;      /* lower index in SA table */
   U32    high;     /* upper index in SA table */
   U32    entry;    /* entry in SA table */
   MaSaMapCp *saMap;/* SA mapping control block */

   TRC2(maFindSaMap)

   if (maCb.maSecCp.saTbSize == 0)
   {
      RETVALUE((MaSaMapCp *)NULLP);
   }

   low = 0;
   high = maCb.maSecCp.saTbSize-1;
   CAT_PLMNID_164_VAL(val, cc, ndc)

   saMap = maBinFindSaMap(val, low, high, &entry);

   if (saMap == (MaSaMapCp *)NULLP)
   {
      RETVALUE((MaSaMapCp *)NULLP);
   }

   RETVALUE(saMap);

} /* maFindSaMap */

/*
*
*       Fun:    maInitSaMapTbl
*
*       Desc:   Initliaized SA mapping table
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maInitSaMapTbl
(
)
#else
PUBLIC S16 maInitSaMapTbl(Void)
#endif
{
   MaSaMapCp *saMap;   /* Sa mapping control block */
   MaSaCp    *sa;      /* SA control block */
   U32       idx;      /* index in SA table */

   TRC2(maInitSaMapTbl)

   for (idx = 0; idx < maCb.maSecCp.saTbSize; idx++)
   {
      sa = *(maCb.maSecCp.maSaCbPtr + idx);
      saMap = maFindSaMap(sa->sa.plmn_164.cc.val, sa->sa.plmn_164.ndc.val);
      if (saMap == (MaSaMapCp *)NULLP)
      {
         RETVALUE(RFAILED);
      }
      saMap->indx = idx;
   }

   RETVALUE(ROK);

} /* end of maInitSaMapTbl */

/*
*
*       Fun:   maChkAcOprCode    
*
*       Desc:  This function checks whether an operation is supported 
*              within Application context
*
*       Ret:   ROK  if operation supported
*
*       Notes: None 
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maChkAcOprCode 
(
U8      acName,         /* application context name */
U8      acVer,          /* application context version */
U8      oprCode         /* Operation code */
)
#else
PRIVATE S16 maChkAcOprCode (acName, acVer, oprCode)
U8      acName;         /* application context name */
U8      acVer;          /* application context version */
U8      oprCode;        /* Operation code */
#endif
{
  S16   i, idx;
  U16    len;
  MaSap  *s;         /* Pointer to the MA layer sap */

  TRC2(maChkAcOprCode)


  for (idx=0; idx < (S16) maCb.maCP.nmbMAUSaps; idx++)
  {
     if (maCb.maSapLmaPtr[idx] == NULLP) 
     {
        continue;
     }

     s = maCb.maSapLmaPtr[idx];

     for (i=0; i< MA_MAX_OPR; i++)
     {
        if (s->cfg.apnCfg[i].pres == TRUE)
        {
           len =  s->cfg.apnCfg[i].apn.len;
           if ((oprCode == s->cfg.apnCfg[i].oprCode) &&
               (acName == s->cfg.apnCfg[i].apn.string[len - 2]))
           {
              RETVALUE(ROK);
           }
        }
     }
  }

  MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
         "maChkAcOprCode() failed, Operation is not within Apn.\n"));
  RETVALUE(RFAILED);
} /* maChkAcOprCode  */

/*
*
*       Fun:   maChkSecParam
*
*       Desc:  validate MAPsec gen/sap/pg/pp/sa configuration parameters
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  ca_bdy4.c
*
*/
 
#ifdef ANSI
PUBLIC S16 maChkSecParam
(
MaMngmt *cfg,       /* management structure */
U16     *reason     /* failure reason */
)
#else
PUBLIC S16 maChkSecParam (cfg,reason)
MaMngmt *cfg;      /* management structure */
U16     *reason;   /* failure reason */
#endif
{
   U8     nmbPgTupleEnt;
   S16    ret;            /* return code */
   U32    i;              /* index */
   U8     acName;         /* application context name */
   U8     acVer;          /* application context version */
   U8     oprCode;        /* operation code */
   U8     tmp;
   U16    rsn;            /* reason */
   U16    ppid;           /* sec Ppi */
   U8     ppri;           /* sec Ppri */

   TRC2(maChkSecParam)


   switch (cfg->hdr.elmId.elmnt)
   {
      case STMATGEN:

         if ((ret = maChkPlmnId(&cfg->t.cfg.s.maGen.secGenCfg.plmnId)) != ROK)
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed,\
                   Invalid self Plmn Id.\n", 
                   cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            *reason = LMA_REASON_INV_PLMN;
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA190, 
                   (ErrVal)cfg->t.cfg.s.maGen.secGenCfg.plmnId.mcc.val,
                  "MaMiLmaCfgReq() Failed, Invalid self Plmn Id.");
#endif 
            RETVALUE(RFAILED);
         }

         if ((cfg->t.cfg.s.maGen.secGenCfg.rxFbInd != LMA_FB_DISABLED) &&
             (cfg->t.cfg.s.maGen.secGenCfg.rxFbInd != LMA_FB_ENABLED))
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed,\
                   Invalid fall back indicator.\n", 
                   cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            *reason = LMA_REASON_INV_FB_IND;
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA191, 
                       (ErrVal)cfg->t.cfg.s.maGen.secGenCfg.rxFbInd, 
                       "MaMiLmaCfgReq() Failed, Invalid fall back indicator.");
#endif 
            RETVALUE(RFAILED);
         }

         if ((maCb.maInit.cfgDone == TRUE) && 
             (maCb.maCP.secGenCfg.secPlmnsOnly == FALSE) &&
             (cfg->t.cfg.s.maGen.secGenCfg.secPlmnsOnly == TRUE))
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed,\
                   Invalid secPlmnOnly recongifuration.\n", 
                   cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            *reason = LMA_REASON_INV_SEC_PLMN_ONLY;
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA192, 
                       (ErrVal)cfg->t.cfg.s.maGen.secGenCfg.secPlmnsOnly,
                       "MaMiLmaCfgReq() Failed, Invalid secPlmnOnly recfg.");
#endif 
            RETVALUE(RFAILED);

         }

         if (cfg->t.cfg.s.maGen.secGenCfg.nmbOpCmp == 0)
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed,\
                   MAPsec operation component missing.\n", 
                   cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            *reason = LMA_REASON_OPR_CMPS_MISSING;
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA193, 
                   (ErrVal)cfg->t.cfg.s.maGen.secGenCfg.nmbOpCmp,
                   "MaMiLmaCfgReq() Failed, MAPsec opr cmp missing.");
#endif 
            RETVALUE(RFAILED);
         }

         if (cfg->t.cfg.s.maGen.secGenCfg.nmbOpCmp > LMA_MAX_SEC_COMPS)
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed,\
                   max number of MAPsec operation component exceeded.\n", 
                   cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            *reason = LMA_REASON_MAX_MAPSEC_OPR_CMPS;
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA194, 
                   (ErrVal)cfg->t.cfg.s.maGen.secGenCfg.nmbOpCmp,
                   "MaMiLmaCfgReq() Failed, max MAPsec opr cmp exceeded.");
#endif 
            RETVALUE(RFAILED);
         }

         for (i=0; i<cfg->t.cfg.s.maGen.secGenCfg.nmbOpCmp; i++)
         {
            if (cfg->t.cfg.s.maGen.secGenCfg.opCmp[i].cmpCmb >= LMA_CMP_USR)
            {
               MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                      "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed,\
                      Invalid component combination type.\n", 
                      cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
               *reason = LMA_REASON_INV_OPR_CMP_TYPE;
#if (ERRCLASS & ERRCLS_INT_PAR)
               MALOGERROR(ERRCLS_INT_PAR, EMA195, 
                     (ErrVal)cfg->t.cfg.s.maGen.secGenCfg.opCmp[i].cmpCmb,
                     "MaMiLmaCfgReq() Failed, Invalid comp combination type.");
#endif 
               RETVALUE(RFAILED);
            }
         }

         if (maChkCmpTbl(&cfg->t.cfg.s.maGen.secGenCfg) != ROK)
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                   max number of operation components exceeded.\n", 
                   cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            *reason = LMA_REASON_OPR_CMP_EXCEEDED;
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA196, 
                       (ErrVal)cfg->t.cfg.s.maGen.secGenCfg.nmbOpCmp, 
                       "MaMiLmaCfgReq() Failed, max num of opr cmp exceeded.");
#endif 
            RETVALUE(RFAILED);
         }

         break;

      case STMATSAP:

         if (cfg->t.cfg.s.maMAU.secSapCfg.neId.length > LMA_NEID_SIZE)
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                   invalid NE ID length.\n", 
                   cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            *reason = LMA_REASON_INV_NEID_LENGTH;
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA197, 
                       (ErrVal)cfg->hdr.elmId.elmntInst1, \
                       "MaMiLmaCfgReq() Failed, invalid NE ID length.");
#endif
            RETVALUE(RFAILED);
         }

         /* Ne id can not be zero */
         for (i=0; i<cfg->t.cfg.s.maMAU.secSapCfg.neId.length; i++)
         {
            tmp = cfg->t.cfg.s.maMAU.secSapCfg.neId.strg[i];
            if (tmp > 0)
            {
               break;
            }
         }

         if (i == cfg->t.cfg.s.maMAU.secSapCfg.neId.length)
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                   NE ID out of range.\n", 
                   cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            *reason = LMA_REASON_INV_NEID;
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA198, 
                       (ErrVal)cfg->hdr.elmId.elmntInst1, \
                       "MaMiLmaCfgReq() Failed, Invalid NE ID ");
#endif
            RETVALUE(RFAILED);
         }

         /* Ne id should be TBCD string */
         for (i=0; i<cfg->t.cfg.s.maMAU.secSapCfg.neId.length; i++)
         {
            tmp = cfg->t.cfg.s.maMAU.secSapCfg.neId.strg[i];
            if (((tmp & 0x0f) > 9) || (((tmp >> 4) & 0x0f) > 9))
            {
               MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                      "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                      NE ID out of range.\n", 
                      cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
               *reason = LMA_REASON_INV_NEID;
#if (ERRCLASS & ERRCLS_INT_PAR)
               MALOGERROR(ERRCLS_INT_PAR, EMA199, 
                          (ErrVal)cfg->hdr.elmId.elmntInst1, \
                          "MaMiLmaCfgReq() Failed, NE ID out of range.");
#endif
               RETVALUE(RFAILED);
            }
         }

         break;

      case STMATPG:

         acName = cfg->t.cfg.s.maSecPg.ac;

         if ((cfg->t.cfg.s.maSecPg.pgi < MA_NMB_INIT_PG) || 
             (cfg->t.cfg.s.maSecPg.pgi >= MA_MAX_PGTABLE_SIZE))
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                    invalid PG identifier.\n", 
                    cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            *reason = LMA_REASON_INV_PGI;
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA200, 
                       (ErrVal)cfg->hdr.elmId.elmntInst1, 
                       "MaMiLmaCfgReq() Failed, invalid PG identifier.");
#endif 
            RETVALUE(RFAILED);
         }

         if ((ret = maChkAcName(acName)) != ROK)
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                    invalid AC name.\n", 
                    cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            *reason = LMA_REASON_INV_AC;
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA201, 
                       (ErrVal)cfg->hdr.elmId.elmntInst1, 
                       "MaMiLmaCfgReq() Failed, invalid AC name.");
#endif 
            RETVALUE(RFAILED);
         }

         nmbPgTupleEnt = cfg->t.cfg.s.maSecPg.nmbPgTupleEnt;
         if (nmbPgTupleEnt> LMA_MAX_PG_TUPLES)
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                    invalid PG tuple entry.\n", 
                    cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            *reason = LMA_REASON_INV_PG_ENTRIES;
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA202, 
                       (ErrVal)cfg->hdr.elmId.elmntInst1, 
                       "MaMiLmaCfgReq() Failed, invalid PG tuple entry.");
#endif 
            RETVALUE(RFAILED);
         }

         for (i=0; i<cfg->t.cfg.s.maSecPg.nmbPgTupleEnt; i++)
         {
            acVer = cfg->t.cfg.s.maSecPg.pg[i].acVer;
            oprCode = cfg->t.cfg.s.maSecPg.pg[i].oprCode;
            if (!IS_VALID_VERSION(acVer))
            {
               MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                      "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                       invalid AC version.\n", 
                       cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
               *reason = LMA_REASON_INV_AC_VERSION;
#if (ERRCLASS & ERRCLS_INT_PAR)
               MALOGERROR(ERRCLS_INT_PAR, EMA203, 
                          (ErrVal)cfg->hdr.elmId.elmntInst1, 
                          "MaMiLmaCfgReq() Failed, invalid AC version.");
#endif 
               RETVALUE(RFAILED);
            }
            if ((ret=maChkOprCode(oprCode)) != ROK)
            {
               MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                      "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                       invalid operation code.\n", 
                       cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
               *reason = LMA_REASON_INV_OPERATION;
#if (ERRCLASS & ERRCLS_INT_PAR)
               MALOGERROR(ERRCLS_INT_PAR, EMA204, 
                          (ErrVal)cfg->hdr.elmId.elmntInst1, 
                          "MaMiLmaCfgReq() Failed, invalid operation code.");
#endif 
               RETVALUE(RFAILED);
            }

            if ((ret = maChkAcOprCode(acName, acVer, oprCode)) != ROK)
            {
               MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                      "MaMiLmaCfgReq(pst,elmnt(%d),elmntInst1(%d)) failed,\
                      invalid operation code within AC.\n", 
                      cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
               *reason = LMA_REASON_INV_AC_OPERATION;
#if (ERRCLASS & ERRCLS_INT_PAR)
               MALOGERROR(ERRCLS_INT_PAR, EMA205, 
                          (ErrVal)cfg->hdr.elmId.elmntInst1, 
                          "MaMiLmaCfgReq() Failed, invalid AC operation.");
#endif 
               RETVALUE(RFAILED);
            }
         }

         if ((maCb.maSecCp.pgTbSize+1) > MA_MAX_PGTABLE_SIZE)
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                   max number of PG exceeded.\n", 
                   cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            *reason = LMA_REASON_PG_TABLE_EXCEEDED;
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA206, 
                       (ErrVal)cfg->hdr.elmId.elmntInst1, 
                       "MaMiLmaCfgReq() Failed, max num of PG exceeded.");
#endif 
            RETVALUE(RFAILED);
         }

         break;

      case STMATPP:

         if ((cfg->t.cfg.s.maSecPp.ppid == 0) || 
             (cfg->t.cfg.s.maSecPp.ppid > maCb.maCP.secGenCfg.maxpp))
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                    invalid protection profile identifier.\n", 
                    cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            *reason = LMA_REASON_INV_PPID;
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA207, 
                       (ErrVal)cfg->hdr.elmId.elmntInst1, 
                       "MaMiLmaCfgReq() Failed, invalid PP identifier.");
#endif 
            RETVALUE(RFAILED);
         }

         ppid = cfg->t.cfg.s.maSecPp.ppid;
         ppri = cfg->t.cfg.s.maSecPp.ppri;
         ret = maChkPpTbl(ppid, ppri, &rsn);
         if (ret == ROK)
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                    invalid protection profile revision id.\n", 
                    cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            *reason = LMA_REASON_INV_PPRI;
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA208, 
                       (ErrVal)cfg->hdr.elmId.elmntInst1, 
                       "MaMiLmaCfgReq() Failed, invalid PP revision Id.");
#endif 
            RETVALUE(RFAILED);
         }

         if ((cfg->t.cfg.s.maSecPp.ppi & (~(maCb.maSecPpiMask))) > 0)
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                    invalid protection profile Indicator.\n", 
                    cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            *reason = LMA_REASON_INV_PPI;
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA209, 
                       (ErrVal)cfg->hdr.elmId.elmntInst1, 
                       "MaMiLmaCfgReq() Failed, invalid PP Indicator.");
#endif 
            RETVALUE(RFAILED);
         }

         if ((maCb.maSecCp.ppTbSize+1) > maCb.maCP.secGenCfg.maxpp)
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                    max number of PP exceeded.\n", 
                    cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            *reason = LMA_REASON_PP_TABLE_EXCEEDED;
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA210, 
                       (ErrVal)cfg->hdr.elmId.elmntInst1, 
                       "MaMiLmaCfgReq() Failed, max number of PP exceeded.");
#endif 
            RETVALUE(RFAILED);
         }
         break;

      case STMATSA:
      {
         U32 nmbDistPlmns; /* distinct plmns in the configuration */

         if (cfg->t.cfg.s.maSecSa.nmbPlmns > LMA_MAX_SA_PLMNS)
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                    max number of Plmn exceeded.\n", 
                    cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            *reason = LMA_REASON_INV_PLMN_NMB;
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA211, 
                       (ErrVal)cfg->hdr.elmId.elmntInst1, 
                       "MaMiLmaCfgReq() Failed, max number of plmn exceeded.");
#endif 
            RETVALUE(RFAILED);
         }

         nmbDistPlmns = 0;
         for (i=0; i<cfg->t.cfg.s.maSecSa.nmbPlmns; i++)
         {
            if ((ret = maChkPlmnId(&cfg->t.cfg.s.maSecSa.sa[i].plmnId)) != ROK)
            {
#ifndef ALIGN_64BIT

               MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                      "MaMiLmaCfgReq(pst, elmnt(%d)) failed,\
                      Invalid self Plmn Id at entry(%ld).\n", 
                      cfg->hdr.elmId.elmnt, i));

#else

               MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                      "MaMiLmaCfgReq(pst, elmnt(%d)) failed,\
                      Invalid self Plmn Id at entry(%d).\n", 
                      cfg->hdr.elmId.elmnt, i));

#endif /* ALIGN_64BIT */
            *reason = LMA_REASON_INV_PLMN;
#if (ERRCLASS & ERRCLS_INT_PAR)
               MALOGERROR(ERRCLS_INT_PAR, EMA212, (ErrVal)i,
                      "MaMiLmaCfgReq() Failed, Invalid self Plmn Id.");
#endif 
               RETVALUE(RFAILED);
            }

            if ((ret = maChkPlmnId164(&cfg->t.cfg.s.maSecSa.sa[i].plmn_164)) != ROK)
            {
#ifndef ALIGN_64BIT

                MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                      "MaMiLmaCfgReq(pst, elmnt(%d)) failed,\
                      Invalid self Plmn Id E.164 numner at entry(%ld).\n", 
                      cfg->hdr.elmId.elmnt, i));

#else
  
               MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                      "MaMiLmaCfgReq(pst, elmnt(%d)) failed,\
                      Invalid self Plmn Id E.164 numner at entry(%d).\n", 
                      cfg->hdr.elmId.elmnt, i));

#endif /* ALIGN_64BIT */
            *reason = LMA_REASON_INV_PLMN_164;
#if (ERRCLASS & ERRCLS_INT_PAR)
               MALOGERROR(ERRCLS_INT_PAR, EMA213, (ErrVal)i,
                      "MaMiLmaCfgReq() Failed, Invalid self E.164 Plmn Id.");
#endif 
               RETVALUE(RFAILED);
            }

            ppid = cfg->t.cfg.s.maSecSa.sa[i].ppid;
            ppri = cfg->t.cfg.s.maSecSa.sa[i].ppri;

            if ((ret = maChkPpTbl(ppid, ppri, &rsn)) != ROK)
            {
               if (rsn == LMA_REASON_INV_PPID)
               {
                  MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                      "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                       invalid protection profile  id.\n", 
                       cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
                  *reason = LMA_REASON_INV_PPID;
#if (ERRCLASS & ERRCLS_INT_PAR)
                 MALOGERROR(ERRCLS_INT_PAR, EMA214, 
                          (ErrVal)cfg->hdr.elmId.elmntInst1, 
                          "MaMiLmaCfgReq() Failed, invalid PP  Id.");
#endif 
                 RETVALUE(RFAILED);
               }
               else
               {
                  MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                      "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                       invalid protection profile revision id.\n", 
                       cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
                  *reason = LMA_REASON_INV_PPRI;
#if (ERRCLASS & ERRCLS_INT_PAR)
                  MALOGERROR(ERRCLS_INT_PAR, EMA215, 
                          (ErrVal)cfg->hdr.elmId.elmntInst1, 
                          "MaMiLmaCfgReq() Failed, invalid PP revision Id.");
#endif 
                  RETVALUE(RFAILED);
               }
            }

            if ((cfg->t.cfg.s.maSecSa.sa[i].mia != MAPSEC_MIA_NULL) && 
                (cfg->t.cfg.s.maSecSa.sa[i].mia != MAPSEC_MIA_AES))
            {
               MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                      "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                       invalid Sec MIA.\n", 
                       cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
               *reason = LMA_REASON_INV_MIA;
#if (ERRCLASS & ERRCLS_INT_PAR)
               MALOGERROR(ERRCLS_INT_PAR, EMA216, 
                          (ErrVal)cfg->hdr.elmId.elmntInst1, 
                          "MaMiLmaCfgReq() Failed, invalid Sec MIA.");
#endif 
               RETVALUE(RFAILED);
            }

            if ((cfg->t.cfg.s.maSecSa.sa[i].mea != MAPSEC_MEA_NULL) && 
                (cfg->t.cfg.s.maSecSa.sa[i].mea != MAPSEC_MEA_AES))
            {
               MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                      "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                       invalid Sec MEA.\n", 
                       cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
               *reason = LMA_REASON_INV_MEA;
#if (ERRCLASS & ERRCLS_INT_PAR)
               MALOGERROR(ERRCLS_INT_PAR, EMA217, 
                          (ErrVal)cfg->hdr.elmId.elmntInst1, 
                          "MaMiLmaCfgReq() Failed, invalid Sec MEA.");
#endif 
               RETVALUE(RFAILED);
            }

            if (cfg->t.cfg.s.maSecSa.sa[i].mik.mikLen > LMA_SEC_MIK_SIZE)
            {
               MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                      "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                       invalid Sec MIK length.\n", 
                       cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
               *reason = LMA_REASON_INV_MIK;
#if (ERRCLASS & ERRCLS_INT_PAR)
               MALOGERROR(ERRCLS_INT_PAR, EMA218, 
                          (ErrVal)cfg->hdr.elmId.elmntInst1, 
                          "MaMiLmaCfgReq() Failed, invalid Sec MIK length.");
#endif 
               RETVALUE(RFAILED);
            }

            if (cfg->t.cfg.s.maSecSa.sa[i].mek.mekLen > LMA_SEC_MEK_SIZE)
            {
               MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                      "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                       invalid Sec MEK length.\n", 
                       cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
               *reason = LMA_REASON_INV_MEK;
#if (ERRCLASS & ERRCLS_INT_PAR)
               MALOGERROR(ERRCLS_INT_PAR, EMA219, 
                          (ErrVal)cfg->hdr.elmId.elmntInst1, 
                          "MaMiLmaCfgReq() Failed, invalid Sec MEK length.");
#endif 
               RETVALUE(RFAILED);
            }

            if (maFindSa(cfg->t.cfg.s.maSecSa.sa[i].plmnId.mcc.val,
                cfg->t.cfg.s.maSecSa.sa[i].plmnId.mnc.val) == NULLP)
            {
               nmbDistPlmns++;
            }

         }
         if ((maCb.maSecCp.saTbSize+nmbDistPlmns) > maCb.maCP.secGenCfg.maxPlmn)
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "MaMiLmaCfgReq(pst, elmnt(%d), elmntInst1(%d)) failed, \
                    max number of SA exceeded.\n", 
                    cfg->hdr.elmId.elmnt, cfg->hdr.elmId.elmntInst1));
            *reason = LMA_REASON_SA_TABLE_EXCEEDED;
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA220, 
                       (ErrVal)cfg->hdr.elmId.elmntInst1, 
                       "MaMiLmaCfgReq() Failed, max number of SA exceeded.");
#endif 
            RETVALUE(RFAILED);
         }

         break;
      }
      default:

#if (ERRCLASS & ERRCLS_INT_PAR)
         MALOGERROR(ERRCLS_INT_PAR, EMA221, (ErrVal)cfg->hdr.elmId.elmnt,
                    "maChkSecParam () Failed, invalid element.");
#endif

         break;
   }
   RETVALUE(ROK);

} /* maChkSecParam */

/*
*
*       Fun:   maChkAcName
*
*       Desc:  This function is used to validate acn name
*
*       Ret:   ROK , if the acn exits
*              RFAILED , if the acn does not exist.  
*
*       Notes: None
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maChkAcName
(
U8        acName
)
#else
PRIVATE S16 maChkAcName (acName)
U8        acName;
#endif
{
   TRC2(maChkAcName)

   switch(acName)
   {
#if (MAP_REL98 || MAP_REL99)
#if (MAP_HLR || MAP_MLC)
      case MA_LOC_SVC_GATEWAY:
#endif
#endif
#if ((MAP_MSC || (MAP_REL99 && MAP_REL4 && MAP_GSN)) || MAP_MLC)
      case MA_LOC_SVC_ENQUIRY:
#endif
#if MAP_REL99
#if (MAP_VLR || MAP_HLR || MAP_GSN)
      case MA_AUTH_FAIL_RPT:
      case MA_NOTE_MMEVT_REPORT:
#endif
#if (MAP_MSC || MAP_HLR)
      case MA_IST_ALERTING:
      case MA_SVC_TERMINATION:
#endif
#if MAP_HLR
      case MA_ANYTIME_INFO_HANDL:
      case MA_SUBS_MOD_NOTIFY:
#endif
#endif

#if (MAP_VLR || MAP_HLR)
      case MA_REPORTING_AC:
      case MA_CALL_COMP_AC:
#endif  

#if (MAP_MSC || MAP_HLR)
      case MA_SSINV_NOTIFY_AC:
#endif

#if (MAP_HLR || MAP_GSN)
      case MA_GPRS_UPLOC_AC:
      case MA_GPRS_LOCINFO_RET_AC:
      case MA_FAILRPT_AC:
      case MA_GPRS_NOTIFY_AC:
#endif 
#if MAP_MSC
      case MA_SIWFS_ALLOC_AC:
      case MA_GRP_CALL_CNTRL_AC:
#endif
#if (MAP_HLR || MAP_MLC)
      case MA_ANY_TIME_ENQUIRY_AC:
#endif /* MAP_HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
      case MA_SUBS_INFO_ENQ_AC:
#endif
#if (MAP_VLR || MAP_HLR || MAP_GSN)
      case MA_MS_PURGING_AC:
#endif
#if (MAP_VLR || MAP_HLR)
      case MA_NETWORK_LOCUP_AC:
#endif
#if (MAP_MSC || MAP_HLR)
      case MA_SM_ALERT_AC:
#endif
#if (MAP_VLR || MAP_HLR || MAP_GSN)
      case MA_MWD_MNGMT_AC:
#endif
#if (MAP_MSC || MAP_HLR)
      case MA_SM_GATEWAY_AC:
#endif
#if (MAP_MSC || MAP_GSN)
      case MA_SM_MO_RELAY_AC:
      case MA_SM_MT_RELAY_AC:
#endif  
#if (MAP_VLR || MAP_HLR)
      case MA_NETWORK_USS_AC:
#endif
#if (MAP_VLR || MAP_HLR || MAP_GSN)
      case MA_TRACING_AC:
#endif
#if (MAP_VLR || MAP_HLR || MAP_GSN)
      case MA_RESET_AC:
#endif
#if (MAP_MSC ||  MAP_VLR || MAP_GSN)
      case MA_EQP_MNGMT_AC:
#endif
#if (MAP_VLR || MAP_HLR || MAP_GSN)
      case MA_SUBS_DATA_MNGMT_AC:
#endif
#if MAP_MSC
      case MA_HO_CONTROL_AC:
#endif
#if (MAP_HLR || MAP_MSC)
      case MA_LOCINFO_RET_AC:
#endif
#if MAP_MSC
      case MA_CALL_CNTRL_TRANS_AC:
#endif
#if (MAP_VLR || MAP_HLR)
      case MA_IMSI_RET_AC:
#endif

#if MAP_VLR 
      case MA_INTVLRINFO_RET_AC:
#endif
#if (MAP_VLR || MAP_HLR || MAP_GSN)
      case MA_NETFUNC_SS_AC:
#endif
#if (MAP_VLR || MAP_HLR || MAP_GSN)
      case MA_INFO_RET_AC:
#endif
#if (MAP_VLR || MAP_HLR)
      case MA_ROAM_NMB_ENQUIRY_AC:
#endif 
#if (MAP_VLR || MAP_HLR || MAP_GSN)
      case MA_CANCEL_LOC_AC:
#endif
      {
         /* opearion is valid */
         break;
      }

      default: 
      {
         RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
}

/*
*
*       Fun:    initialize MAPSec control block
*
*       Desc:   Initializes variables used by SA, PG, PP
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 maInitSecCp
(
void
)
#else
PUBLIC S16 maInitSecCp()
#endif
{

   TRC2(maInitSecCp)

   /* Initialize the MAPsec control block */
   cmZero((Data *)&maCb.maSecCp, sizeof(MaSecCp));

   /* Initialize the MAPsec PG control block */
   maCb.maSecCp.maPgTbl = (LmaSecPgCfg **)NULLP;
   maCb.maSecCp.pgTbSize = 0;

   /* Initialize the MAPsec PP control block */
   maCb.maSecCp.maPpTbl = (LmaSecPpCfg **)NULLP;
   maCb.maSecCp.ppTbSize = 0;

   /* Initialize the MAPsec SA control block */
   maCb.maSecCp.maSaCbPtr = (MaSaCp **)NULLP;
   maCb.maSecCp.maSaMapTbl = (MaSaMapCp **)NULLP;

   maCb.maSecCp.saTbSize = 0;
   
   RETVALUE(ROK);
} /* end of maInitSecCp */

/*
*
*       Fun:    maInitPgTbl
*
*       Desc:   Initialized PG table
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maInitPgTbl
(
Void
)
#else
PUBLIC S16 maInitPgTbl(Void)
#endif
{
   LmaSecPgCfg *pg;
   Data  *tmpBuf;
   U8    i,j;
   S16   ret;
   Bool  found;
   U8    size;

   TRC2(maInitPgTbl)

   size = sizeof(maInitPg)/sizeof(MaPgCp);

   for (i=0; i<sizeof(maInitPg)/sizeof(MaPgCp); i++)
   {
      found = FALSE;
      for (j=0; j<maCb.maSecCp.pgTbSize; j++)
      {
         pg = *(maCb.maSecCp.maPgTbl + j);
         if (pg->ac == maInitPg[i].ac)
         {
            pg->ac = maInitPg[i].ac;
            pg->pgi = maInitPg[i].pgi;
            pg->pg[pg->nmbPgTupleEnt].oprCode = maInitPg[i].oprCode;
            pg->pg[pg->nmbPgTupleEnt].acVer = maInitPg[i].acVer;
            pg->pg[pg->nmbPgTupleEnt].pl = maInitPg[i].pl;
            pg->nmbPgTupleEnt++;
            found = TRUE;
         }
      }

      if (found == FALSE)
      {
         if ((ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, &tmpBuf, 
              sizeof(LmaSecPgCfg))) != ROK)
         {
            RETVALUE(ret);
         }

         pg = (LmaSecPgCfg *)tmpBuf;
         *(maCb.maSecCp.maPgTbl + maCb.maSecCp.pgTbSize) = pg;
         pg->nmbPgTupleEnt = 0;
         pg->ac = maInitPg[i].ac;
         pg->pgi = maInitPg[i].pgi;
         pg->pg[pg->nmbPgTupleEnt].oprCode = maInitPg[i].oprCode;
         pg->pg[pg->nmbPgTupleEnt].acVer = maInitPg[i].acVer;
         pg->pg[pg->nmbPgTupleEnt].pl = maInitPg[i].pl;
         pg->nmbPgTupleEnt++;
         maCb.maSecCp.pgTbSize++;
      }
   }

   for (i=maCb.maSecCp.pgTbSize; i<MA_MAX_PGTABLE_SIZE; i++)
   {
      *(maCb.maSecCp.maPgTbl + i) = NULLP;
   }


   RETVALUE(ROK);

} /* end of maInitPgTbl */

/*
*
*       Fun:    maIsPgExist
*
*       Desc:   check if pg is existing in PG table
*
*       Ret:    TRUE/FALSE
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maIsPgExist
(
MaMngmt *cfg        /* management structure */
)
#else
PUBLIC S16 maIsPgExist(cfg)
MaMngmt *cfg;       /* management structure */
#endif
{
   LmaSecPgCfg *pg;
   U8    i;

   TRC2(maIsPgExist)

   for (i=1; i<maCb.maSecCp.pgTbSize; i++)
   {
      pg = *(maCb.maSecCp.maPgTbl + i);
      if ((pg->pgi == cfg->t.cfg.s.maSecPg.pgi) && 
          (pg->ac == cfg->t.cfg.s.maSecPg.ac))
      {
         RETVALUE(TRUE);
      }
   }

   RETVALUE(FALSE);
} /* end of maIsPgExist */

/*
*
*       Fun:    maFreePgTbl
*
*       Desc:   Free memory for PG group 1 to 4
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void maFreePgTbl
(
Void
)
#else
PUBLIC Void maFreePgTbl(Void)
#endif
{
   U8    idx;

   TRC2(maFreePgTbl)

   /* delete all the PGs */

   for (idx=0; idx < MA_MAX_PGTABLE_SIZE; idx++)
   {
      if (maCb.maSecCp.maPgTbl[idx] == NULLP) 
      {
         continue;
      }
      maRemMaPg(idx);
   } /* end for */

   maCb.maSecCp.pgTbSize = 0;

   RETVOID;

} /* end of maFreePgTbl */

/*
*
*       Fun:    maRemMaPg
*
*       Desc:   Free memory for PG group 1 to 4
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maRemMaPg
(
U32   idx
)
#else
PUBLIC S16 maRemMaPg(idx)
U32   idx;
#endif
{
   LmaSecPgCfg *pg;

   TRC2(maRemMaPg)

   pg = *(maCb.maSecCp.maPgTbl + idx);

   if (pg != (LmaSecPgCfg *)NULLP)
   {
      /* Free the memory associated with this SA */
      maFree((Data *)pg, sizeof(LmaSecPgCfg));
      pg = (LmaSecPgCfg *)NULLP;
   }

   RETVALUE(ROK);

} /* end of maRemMaPg */

/*
*
*       Fun:    maInitPpTbl
*
*       Desc:   Initliaized PP table
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maInitPpTbl
(
Void
)
#else
PUBLIC S16 maInitPpTbl(Void)
#endif
{
   LmaSecPpCfg *pp;
   Data  *tmpBuf;
   U8    i;
   S16   ret;

   TRC2(maInitPpTbl)

   /* initialization of PP control block */
   for (i=0; i<sizeof(maInitPp)/sizeof(LmaSecPpCfg); i++)
   {
      if ((ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, &tmpBuf, 
           sizeof(LmaSecPpCfg))) != ROK)
      {
         RETVALUE(ret);
      }

      pp = (LmaSecPpCfg *)tmpBuf;
      *(maCb.maSecCp.maPpTbl + i) = pp;
      pp->ppid = maInitPp[i].ppid;
      pp->ppri = maInitPp[i].ppri;
      pp->ppi = maInitPp[i].ppi;
   }

   maCb.maSecCp.ppTbSize = sizeof(maInitPp)/sizeof(LmaSecPpCfg);

   for (i=sizeof(maInitPp)/sizeof(LmaSecPpCfg); i<maCb.maCP.secGenCfg.maxpp; i++)
   {
      *(maCb.maSecCp.maPpTbl + i) = NULLP;
   }

   RETVALUE(ROK);

} /* end of maInitPpTbl */

/*
*
*       Fun:    maIsPpExist
*
*       Desc:   check if pp is existing in PP table
*
*       Ret:    TRUE/FALSE
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maIsPpExist
(
MaMngmt *cfg        /* management structure */
)
#else
PUBLIC S16 maIsPpExist(cfg)
MaMngmt *cfg;       /* management structure */
#endif
{
   LmaSecPpCfg *pp;
   U32         i;

   TRC2(maIsPpExist)

   for (i=0; i<maCb.maSecCp.ppTbSize; i++)
   {
      pp = *(maCb.maSecCp.maPpTbl + i);
      if ((pp->ppid == cfg->t.cfg.s.maSecPp.ppid) &&
          (pp->ppri == cfg->t.cfg.s.maSecPp.ppri) &&
          (pp->ppi == cfg->t.cfg.s.maSecPp.ppi))
      {
         RETVALUE(TRUE);
      }
   }

   RETVALUE(FALSE);
} /* end of maIsPpExist */

/*
*
*       Fun:    maChkPpTbl
*
*       Desc:   check if ppid and ppri are existing in PP table
*
*       Ret:    ROK
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maChkPpTbl
(
U16         ppid,
U8          ppri,
U16         *reason   /* failure reason */
)
#else
PRIVATE S16 maChkPpTbl(ppid, ppri, reason)
U16         ppid;
U8          ppri;
U16         *reason;  /* failure reason */
#endif
{
   LmaSecPpCfg *pp;
   Bool        found;
   U32         i;

   TRC2(maChkPpTbl)

   found = FALSE;
   for (i=0; i<maCb.maSecCp.ppTbSize; i++)
   {
      pp = *(maCb.maSecCp.maPpTbl + i);
      if (pp->ppid == ppid)
      {
         if (pp->ppri == ppri)
         {
            break;
         }
         found = TRUE;
      }
   }

   if(i < maCb.maSecCp.ppTbSize)
   {
      RETVALUE(ROK);
   }
   if (found == FALSE)
   {
      *reason = LMA_REASON_INV_PPID;
      RETVALUE(RFAILED);
   }
   else
   {
      *reason = LMA_REASON_INV_PPRI;
      RETVALUE(RFAILED);
   }

} /* end of maChkPpTbl */

/*
*
*       Fun:    maFreePpTbl
*
*       Desc:   Free memory for PG group 1 to 4
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void maFreePpTbl
(
Void
)
#else
PUBLIC Void maFreePpTbl(Void)
#endif
{
   U32    idx;

   TRC2(maFreePpTbl)

   /* dellocate PP control block */

   for (idx=0; idx < maCb.maCP.secGenCfg.maxpp; idx++)
   {
      if (maCb.maSecCp.maPpTbl[idx] == NULLP) 
      {
         continue;
      }
      maRemMaPp(idx);
   } /* end for */

   maCb.maSecCp.ppTbSize = 0;

   RETVOID;

} /* end of maFreePpTbl */

/*
*
*       Fun:    maInitOpCmpTbl
*
*       Desc:   Initliaized operation component table
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void maInitOpCmpTbl
(
LmaSecGenCfg  *secGenCfg
)
#else
PUBLIC Void maInitOpCmpTbl(secGenCfg)
LmaSecGenCfg  *secGenCfg;
#endif
{
   U16   i, j;
   Bool  found;

   TRC2(maInitOpCmpTbl)

   for (i=0; i<secGenCfg->nmbOpCmp; i++)
   {
      found = FALSE;

      for (j=0; j<maCb.maNumOpCmp; j++)
      {
         if ((maCb.maOpCmp[j].acName == secGenCfg->opCmp[i].acName) &&
             (maCb.maOpCmp[j].acVer == secGenCfg->opCmp[i].acVer) &&
             (maCb.maOpCmp[j].oprCode == secGenCfg->opCmp[i].oprCode))
         {
            maCb.maOpCmp[j].cmpCmb = 
              (LmaCmpTypeCmb)(maCb.maOpCmp[j].cmpCmb | secGenCfg->opCmp[i].cmpCmb);
            found = TRUE;
            break;
         }
      }

      if (found == FALSE)
      {
         maCb.maOpCmp[maCb.maNumOpCmp].acName = secGenCfg->opCmp[i].acName;
         maCb.maOpCmp[maCb.maNumOpCmp].acVer = secGenCfg->opCmp[i].acVer;
         maCb.maOpCmp[maCb.maNumOpCmp].oprCode = secGenCfg->opCmp[i].oprCode;
         maCb.maOpCmp[maCb.maNumOpCmp].cmpCmb = secGenCfg->opCmp[i].cmpCmb;
         maCb.maNumOpCmp++;
      }
   }
   RETVOID;

} /* end of maInitOpCmpTbl */

/*
*
*       Fun:    maChkCmpTbl
*
*       Desc:   Initliaized operation component table
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkCmpTbl
(
LmaSecGenCfg  *secGenCfg
)
#else
PUBLIC S16 maChkCmpTbl(secGenCfg)
LmaSecGenCfg  *secGenCfg;
#endif
{
   S32   i, j;
   S32   counter;
   Bool  found;

   TRC2(maChkCmpTbl)

   counter = 0;

   for (i=0; i<secGenCfg->nmbOpCmp; i++)
   {
      found = FALSE;

      for (j=0; j<maCb.maNumOpCmp; j++)
      {
         if ((maCb.maOpCmp[j].acName == secGenCfg->opCmp[i].acName) &&
             (maCb.maOpCmp[j].acVer == secGenCfg->opCmp[i].acVer) &&
             (maCb.maOpCmp[j].oprCode == secGenCfg->opCmp[i].oprCode))
         {
            found = TRUE;
            break;
         }
      }

      if (found == FALSE)
      {
         counter++;
      }
   }
   if ((maCb.maNumOpCmp + counter) >= MA_MAX_SEC_COMPS)
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* end of maChkCmpTbl */

/*
*
*       Fun:    maRemMaPp
*
*       Desc:   Free memory for PG group 1 to 4
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maRemMaPp
(
U32   idx
)
#else
PUBLIC S16 maRemMaPp(idx)
U32   idx;
#endif
{

   LmaSecPpCfg *pp;

   TRC2(maRemMaPp)

   pp = *(maCb.maSecCp.maPpTbl + idx);

   if (pp != (LmaSecPpCfg *)NULLP)
   {
      /* Free the memory associated with this PP */
      maFree((Data *)pp, sizeof(LmaSecPpCfg));
      pp = (LmaSecPpCfg *)NULLP;
   }

   RETVALUE(ROK);

} /* end of maRemMaPp */

/*
*
*       Fun:    maGetPlmnStr
*
*       Desc:   Load a U32 value into a string in order
*
*       Ret:    Void
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PRIVATE Void maGetPlmnStr
(
U8       *str,      /* destination string */
U32      val        /* value */
)
#else
PRIVATE Void maGetPlmnStr(str, val)
U8       *str;      /* destination string */
U32      val;       /* value */
#endif
{
   TRC2(maGetPlmnStr)

   str[0] = GetHiByte(GetHiWord(val));;
   str[1] = GetLoByte(GetHiWord(val));;
   str[2] = GetHiByte(GetLoWord(val));;
   str[3] = GetLoByte(GetLoWord(val));;

   RETVOID;
} /* maGetPlmnStr */


/*
*
*       Fun:    maFindSaPosi
*
*       Desc:   Binary search a SA control point in SA table
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PUBLIC U32 maFindSaPosi
(
U32        *val
)
#else
PUBLIC U32 maFindSaPosi(val)
U32        *val;
#endif
{
   U32    idx;     /* index in SA table */
   U32    plmnId;  /* Plmn id */
   S16    ret;     /* return value */
   MaSaCp *sa;     /* SA control block */
   U8    tmp1[4];
   U8    tmp2[4];

   TRC2(maFindSaPosi)

   maGetPlmnStr(&tmp2[0], *val);

   /* This searching is needed at the configuration time, so  
    * use sequential search to find the position at which new 
    * control block is to be inserted. */

   for (idx=0; idx < maCb.maSecCp.saTbSize; idx++)
   {
      sa = *(maCb.maSecCp.maSaCbPtr+idx);
      plmnId = sa->plid | (U32)(sa->dig6);
      maGetPlmnStr(&tmp1[0], plmnId);
      ret = cmMemcmp((U8 *)&tmp1[0], (U8 *)&tmp2[0], 4);
      if (ret > 0)
      {
         /* new plmn id is less than plmnId */
         RETVALUE(idx);
      }
   }

   /* The new plmn id is the bigest */
   RETVALUE(idx);

} /* maFindSaPosi */

/*
*
*       Fun:    maBinFindSa
*
*       Desc:   Binary search a SA control point in SA table
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PUBLIC MaSaCp *maBinFindSa
(
U32        val,
S32        low,
S32        high,
U32        *entry
)
#else
PUBLIC MaSaCp *maBinFindSa(val, low, high,entry)
U32        val;
S32        low;
S32        high;
U32        *entry;
#endif
{
   S32    mid;
   S16    ret;   /* return value */
   MaSaCp *sa;
   U8    tmp1[4];
   U8    tmp2[4];

   TRC2(maBinFindSa)

   if (low > high)
   {
      *entry = NULLD;
      RETVALUE((MaSaCp *)NULLP);
   }

   mid = (low+high)/2;
   sa = *(maCb.maSecCp.maSaCbPtr+mid);
   maGetPlmnStr(&tmp1[0], sa->plid);
   maGetPlmnStr(&tmp2[0], val);

   ret = cmMemcmp((U8 *)&tmp1[0], (U8 *)&tmp2[0], 4);

   /* Match, return item found */
   if (ret == 0)
   {
      *entry = mid;
      RETVALUE(sa);
   }

   /* plmnId val is less than mid, search lower half */
   if (ret > 0)
   {
      RETVALUE(maBinFindSa(val, low, mid-1, entry));
   }
   
   /* plmnId val is greater than mid, search upper half */
   RETVALUE(maBinFindSa(val, mid+1, high, entry));

} /* maBinFindSa */

/*
*
*       Fun:    maInsSa
*
*       Desc:   Inserts SA control point into the SA table
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PUBLIC MaSaCp *maInsSa
(
U16        mcc,     /* Mobile country code */
U16        mnc      /* Mobile network code */
)
#else
PUBLIC MaSaCp *maInsSa(mcc, mnc)
U16        mcc;     /* Mobile country code */
U16        mnc;     /* Mobile network code */
#endif
{
   S16    ret;   /* return value */
   U32    val;   /* U32 plmnId value */
   MaSaCp *sa;
   Data   *tmpBuf;
   U32    posi;  /* SA position in SA table */
   U32    i;

   TRC2(maInsSa)

   CAT_PLMNID_VAL(val, mcc, mnc)

   if ((ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, &tmpBuf, 
        sizeof(MaSaCp))) != ROK)
   {
      RETVALUE((MaSaCp *)NULLP);
   }
   sa = (MaSaCp *)tmpBuf;

   posi = maFindSaPosi(&val);

   /* shift SA table */
   for (i=maCb.maSecCp.saTbSize; i>posi; i--)
   {
      *(maCb.maSecCp.maSaCbPtr+i) = *(maCb.maSecCp.maSaCbPtr+i-1);
   }

   *(maCb.maSecCp.maSaCbPtr+posi) = sa;
   sa->plid = val & MA_PLMN_ID_MASK;     /* save five digits in plid */
   sa->dig6 = GetLoByte(GetLoWord(val)); /* save one digit in dig6 */
   sa->dlgLst = NULLP;
   sa->ppi = NULLD;
   cmZero((U8 *)&sa->sa,sizeof(LmaSecSa));
   sa->softExp = FALSE;

   RETVALUE(sa);

} /* maInsSa */

/*
*
*       Fun:    maFindSa
*
*       Desc:   Find SA control point in the SA table
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PUBLIC MaSaCp *maFindSa
(
U16        mcc,     /* Mobile country code */
U16        mnc      /* Mobile network code */
)
#else
PUBLIC MaSaCp *maFindSa(mcc, mnc)
U16        mcc;     /* Mobile country code */
U16        mnc;     /* Mobile network code */
#endif
{
   U32    val;      /* U32 plmnId value */
   U32    low;      /* lower index in SA table */
   U32    high;     /* upper index in SA table */
   U32    entry;    /* entry in SA table */
   MaSaCp *sa;      /* SA control block */
   U8     digSix;   /* The sixth digit of plmn id */
   U32    diff;
   U32    idx;

   TRC2(maFindSa)

   if (maCb.maSecCp.saTbSize == 0)
   {
      RETVALUE((MaSaCp *)NULLP);
   }

   low = 0;
   high = maCb.maSecCp.saTbSize-1;
   CAT_PLMNID_VAL(val, mcc, mnc)

   /* search SA table with 5 digits of plmn id */
   digSix = GetLoByte(GetLoWord(val));
   val &= MA_PLMN_ID_MASK;
   sa = maBinFindSa(val, low, high, &entry);

   if (sa == (MaSaCp *)NULLP)
   {
      RETVALUE((MaSaCp *)NULLP);
   }

   if (sa->dig6 == digSix)
   {
      RETVALUE(sa);
   }

   if (digSix > sa->dig6)
   {
      /* The entry searched must be higher than the current entry.
       * The worse case, we need to loop 9 times, which is the max 
       * number of the sixth digit. */

      diff = (U32)(digSix - sa->dig6);

      for (idx=1; idx <= diff; idx++)
      {
         if (*(maCb.maSecCp.maSaCbPtr+entry+idx) == (MaSaCp *)NULLP)
         {
            RETVALUE((MaSaCp *)NULLP);
         }
         if ((*(maCb.maSecCp.maSaCbPtr+entry+idx))->dig6 == digSix)
         {
            RETVALUE(*(maCb.maSecCp.maSaCbPtr+entry+idx));
         }
      }
   }
   else
   {
      /* The entry searched must be lower than the current entry.
       * The worse case, we need to loop 9 times, which is the max 
       * number of the sixth digit. */

      diff = (U32)(sa->dig6 - digSix );

      for (idx=1; idx <= diff; idx++)
      {
         if (*(maCb.maSecCp.maSaCbPtr+entry-idx) == (MaSaCp *)NULLP)
         {
            RETVALUE((MaSaCp *)NULLP);
         }

         if ((*(maCb.maSecCp.maSaCbPtr+entry-idx))->dig6 == digSix)
         {
            RETVALUE(*(maCb.maSecCp.maSaCbPtr+entry+idx));
         }
      }
   }

   RETVALUE((MaSaCp *)NULLP);

} /* maFindSa */

/*
*
*       Fun:    maRemSa
*
*       Desc:   Remove a SA control point from the SA table
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 maRemSa
(
LmaCntrlPlmn  *plmn
)
#else
PUBLIC S16 maRemSa(plmn)
LmaCntrlPlmn  *plmn;
#endif
{
   U32     val;   /* U32 plmnId value */
   MaSaCp  *sa;
   U32     i;
   U32     low;
   U32     high;
   U32     entry;
   MaSaMapCp  *saMap;
   U32     entry1; /* entry in SA mapping table */

   TRC2(maRemSa)

   low = 0;
   high = maCb.maSecCp.saTbSize-1;
   CAT_PLMNID_VAL(val, plmn->id.mcc.val, plmn->id.mnc.val)

   /* binary sreach in SA table to find the SA */
   if ((sa = maFindSa(plmn->id.mcc.val, plmn->id.mnc.val)) == (MaSaCp *)NULLP)
   {
      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
             "maRemSa() failed, invalid PLMN Id mcc(%d), mnc(%d))\n", 
             plmn->id.mcc.val, plmn->id.mnc.val));
      RETVALUE(LMA_REASON_INV_PLMN);
   }

   if (sa->sa.spi != plmn->spi)
   {
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
             "maRemSa() failed, invalid PLMN SPI(%ld))\n", plmn->spi));
      RETVALUE(LMA_REASON_INV_SPI);

#else

      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
             "maRemSa() failed, invalid PLMN SPI(%d))\n", plmn->spi));
      RETVALUE(LMA_REASON_INV_SPI);

#endif /* ALIGN_64BIT */
   }

   for(entry =0; (entry < maCb.maSecCp.saTbSize)&&(maCb.maSecCp.maSaCbPtr[entry] != sa);)
   {
      entry++;
   }

   /* binary sreach in SA mapping table to find the SA mapping block */
   saMap = maFindSaMap(sa->sa.plmn_164.cc.val, sa->sa.plmn_164.ndc.val);
   if ((saMap == (MaSaMapCp *)NULLP) || (saMap->indx != entry))
   {
#ifndef ALIGN_64BIT

        MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
             "maRemSa() failed, invalid PLMN Id cc(%d), ndc(%ld))\n", 
             sa->sa.plmn_164.cc.val, sa->sa.plmn_164.ndc.val));
      RETVALUE(LMA_REASON_INV_PLMN);

#else

      MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
             "maRemSa() failed, invalid PLMN Id cc(%d), ndc(%d))\n", 
             sa->sa.plmn_164.cc.val, sa->sa.plmn_164.ndc.val));
      RETVALUE(LMA_REASON_INV_PLMN);

#endif /* ALIGN_64BIT */
   }

   for(entry1=0;(entry1<maCb.maSecCp.saTbSize)&&(maCb.maSecCp.maSaMapTbl[entry1]!=saMap);)
   {
      entry1++;
   }

   switch(plmn->type)
   {
      case LMA_PLMN_SOFT_EXP_SET:

         sa->softExp = TRUE;
         RETVALUE(ROK);

         break;

      case LMA_PLMN_SOFT_DELETE: 

         /* If the SA is being used, can not delete it */
         if (sa->dlgLst != NULLP)
         {
            MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf, 
                   "maRemSa() failed, SA is being used, deletion type(%d))\n",
                   plmn->type));
            RETVALUE(LMA_REASON_SOFT_DEL_FAIL);
         }
         /* Free the memory associated with this SA */
         maFree((Data *)sa, sizeof(MaSaCp));
         maCb.maSecCp.maSaCbPtr[entry] = NULLP;
 
         break;

      case LMA_PLMN_HARD_DELETE: 
         maRemMaSa(entry);

         break;
   }

   /* remove the PLMN/SA entry from SA mapping table */
   for (i=entry; i<maCb.maSecCp.saTbSize-1; i++)
   {
      *(maCb.maSecCp.maSaCbPtr+i) = *(maCb.maSecCp.maSaCbPtr+i+1);
   }
   *(maCb.maSecCp.maSaCbPtr+i) = NULLP;

   maRemMaSaMap(entry1);

   /* remove the PLMN/SA entry from SA mapping table */
   for (i=entry1; i<maCb.maSecCp.saTbSize-1; i++)
   {
      *(maCb.maSecCp.maSaMapTbl+i) = *(maCb.maSecCp.maSaMapTbl+i+1);
   }
   *(maCb.maSecCp.maSaMapTbl+i) = NULLP;
   maCb.maSecCp.saTbSize--;

   maInitSaMapTbl();

   RETVALUE(ROK);

} /* maRemSa */

/*
*
*       Fun:    maRemMaSa
*
*       Desc:   Remove a SA control point from the SA table
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 maRemMaSa
(
U32        idx
)
#else
PUBLIC S16 maRemMaSa(idx)
U32        idx;
#endif
{
   MaSaCp  *sa;
   MaDlgCp *current;
   MaDlgCp *next;

   TRC2(maRemMaSa)

   sa = *(maCb.maSecCp.maSaCbPtr + idx);

   /* If the SA is being used, scan the dlgCb linked list in the SA
    * and clean them */
   if (sa->dlgLst != NULLP)
   {
      current = sa->dlgLst;
      while(current != NULLP)
      {
         next = current->nextInSa;
         maForcedIdleSaDlg(current);
         current = next;
      }
      sa->dlgLst = NULLP;
   }

   /* Free the memory associated with this SA */
   maFree((Data *)sa, sizeof(MaSaCp));
   maCb.maSecCp.maSaCbPtr[idx] = NULLP;

   RETVALUE(ROK);

} /* maRemMaSa */

/*
*
*       Fun:    maRemMaSaMap
*
*       Desc:   Remove a SA control point index from the SA mapping table
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 maRemMaSaMap
(
U32        idx
)
#else
PUBLIC S16 maRemMaSaMap(idx)
U32        idx;
#endif
{
   MaSaMapCp  *saMap;

   TRC2(maRemMaSaMap)

   saMap = *(maCb.maSecCp.maSaMapTbl + idx);

   /* Free the memory associated with this SA */
   maFree((Data *)saMap, sizeof(MaSaMapCp));
   maCb.maSecCp.maSaMapTbl[idx] = NULLP;

   RETVALUE(ROK);

} /* maRemMaSaMap */

/*
*
*       Fun:    maIdleSaDlg
*
*       Desc:   delete dialog control point to set idle in SA
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void maIdleSaDlg
(
MaDlgCp *dlgCp               /* Dialogue control block */
)
#else
PUBLIC Void maIdleSaDlg(dlgCp)
MaDlgCp *dlgCp;              /* Dialogue control block */
#endif
{
   MaCmpCp *p;
   MaCmpCp *d;
   MaSap   *s;          /* associated service point */
   StDlgEv txDlgEv;
   S16     i;           /* loop counter */

   TRC2(maIdleSaDlg)

   if (dlgCp == (MaDlgCp *)NULLP)
   {
     RETVOID;
   }

   s = dlgCp->sap;
   s->curDlgCp = dlgCp;

   /* Abort the dialogue, status indication to MAP user will be given
    * when an upper layer primitive is called on this dialogue. */
   txDlgEv.pres = FALSE;
   maAbrtDlg(s, &txDlgEv, MAT_P_ABNORMAL_DLG); 

   if (dlgCp->cmpLst != (MaCmpStd *)NULLP)
   {
      maReqIdle(dlgCp);
   }

   /* free all operation CB's, loop through invokes to free them */

   for(i=0;i<MA_INVOKE_HASH_SIZE;i++)
   {
      if(dlgCp->invkTbl[i] != (MaCmpCp *)NULLP)
      {
         p = dlgCp->invkTbl[i];
         do
         {
            d = p->next;
            maInvkIdle(dlgCp, p);
            p = d;
         }  while (d);
      }
   }

   /* remove the dialogue from the hash list */
   dlgCp = maRemHashDlg(s, dlgCp->spDlgId);

   if (s->bitMap.map != NULLP)
   {
      /* free the dialogue id */
      (Void) maFreeDlgId(s, dlgCp->spDlgId);
   }

   /* free the dialogue memory */
   SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)dlgCp, sizeof(MaDlgCp));

   /* decrement the number of active dialogues */
   if (s->nmbActvDlg != 0)
   {
     s->nmbActvDlg--;
   }

   RETVOID;

} /* end of maIdleSaDlg */

/*
*
*       Fun:    maForcedIdleSaDlg
*
*       Desc:   delete dialog control point to set idle in SA
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void maForcedIdleSaDlg
(
MaDlgCp *dlgCp               /* Dialogue control block */
)
#else
PUBLIC Void maForcedIdleSaDlg(dlgCp)
MaDlgCp *dlgCp;              /* Dialogue control block */
#endif
{
   MaCmpCp *p;
   MaCmpCp *d;
   MaSap   *s;          /* associated service point */
   StDlgEv txDlgEv;
   S16     i;           /* loop counter */

   TRC2(maForcedIdleSaDlg)

   if (dlgCp == (MaDlgCp *)NULLP)
   {
     RETVOID;
   }

   s = dlgCp->sap;
   s->curDlgCp = dlgCp;

   /* Abort the dialogue, status indication to MAP user will be given
    * when an upper layer primitive is called on this dialogue. */
   txDlgEv.pres = FALSE;

   /* maAbrtDlg(s, &txDlgEv, MAT_P_ABNORMAL_DLG);  */

   if (dlgCp->cmpLst != (MaCmpStd *)NULLP)
   {
      maReqIdle(dlgCp);
   }

   /* free all operation CB's, loop through invokes to free them */

   for(i=0;i<MA_INVOKE_HASH_SIZE;i++)
   {
      if(dlgCp->invkTbl[i] != (MaCmpCp *)NULLP)
      {
         p = dlgCp->invkTbl[i];
         do
         {
            d = p->next;
            maInvkIdle(dlgCp, p);
            p = d;
         }  while (d);
      }
   }

   /* remove the dialogue from the hash list */
   dlgCp = maRemHashDlg(s, dlgCp->spDlgId);

   if (s->bitMap.map != NULLP)
   {
      /* free the dialogue id */
      (Void) maFreeDlgId(s, dlgCp->spDlgId);
   }

   /* free the dialogue memory */
   SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)dlgCp, sizeof(MaDlgCp));

   /* decrement the number of active dialogues */
   if (s->nmbActvDlg != 0)
   {
     s->nmbActvDlg--;
   }

   RETVOID;

} /* end of maForcedIdleSaDlg */

/*
*
*       Fun:    maInsSaDlg
*
*       Desc:   delete dialog control point to set idle in SA
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void maInsSaDlg
(
MaDlgCp *dlgCp,            /* Dialogue control block */
MaSaCp  *saCp              /* SA control block */
)
#else
PUBLIC Void maInsSaDlg(dlgCp, saCp)
MaDlgCp *dlgCp;              /* Dialogue control block */
MaSaCp  *saCp;               /* SA control block */
#endif
{

   TRC2(maInsSaDlg)

   if (saCp->dlgLst == NULLP)
   {
      saCp->dlgLst = dlgCp;
      dlgCp->nextInSa = NULLP;
      dlgCp->prevInSa = NULLP;
   }
   else
   {
      saCp->dlgLst->prevInSa = dlgCp;
      dlgCp->nextInSa = saCp->dlgLst;
      dlgCp->prevInSa = NULLP;
      saCp->dlgLst = dlgCp;
   }

   RETVOID;

} /* end of maInsSaDlg */


/*
*
*       Fun:    maRemSaDlg
*
*       Desc:   delete dialog control point to set idle in SA
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void maRemSaDlg
(
MaDlgCp *dlgCp,            /* Dialogue control block */
MaSaCp  *saCp              /* SA control block */
)
#else
PUBLIC Void maRemSaDlg(dlgCp, saCp)
MaDlgCp *dlgCp;              /* Dialogue control block */
MaSaCp  *saCp;               /* SA control block */
#endif
{

   TRC2(maRemSaDlg)

   if (saCp->dlgLst != (MaDlgCp *)NULLP)
   {
      if (dlgCp == saCp->dlgLst) 
      {
         /* entry to be removed is the first entry in the 
          * linked list */
         if (dlgCp->nextInSa ==(MaDlgCp *) NULLP)
         {
            /* entry to be removed is the only entry in the 
             * linked list so make the head of the linked 
             * list as null */
            saCp->dlgLst = (MaDlgCp *) NULLP;
         }
         else
         {
            /* entry to be removed is not the only one in 
             * the list since first entry to be removed, make 
             * the head of the linked list point to the next 
             * entry in the linked list */
            saCp->dlgLst = dlgCp->nextInSa;
            dlgCp->nextInSa->prevInSa = (MaDlgCp *)NULLP;
         }
      }
      else
      {
         if (dlgCp->nextInSa)
         {
            dlgCp->nextInSa->prevInSa = dlgCp->prevInSa;
         }
         if (dlgCp->prevInSa)
         {
            dlgCp->prevInSa->nextInSa = dlgCp->nextInSa;
         }
      }
   }

   dlgCp->saCp = (MaSaCp *)NULLP;
   dlgCp->nextInSa = (MaDlgCp *)NULLP;
   dlgCp->prevInSa = (MaDlgCp *)NULLP;

   RETVOID;

} /* end of maRemSaDlg */


/*
*
*       Fun:    maFindPpi
*
*       Desc:   Find ppi in PP table
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PUBLIC U16 maFindPpi
(
U32       ppid,   /* sec Ppi */
U8        ppri    /* sec Ppri */
)
#else
PUBLIC U16 maFindPpi(ppid, ppri)
U32       ppid;   /* sec Ppi */
U8        ppri;   /* sec Ppri */
#endif
{
   U32    i;
   U16    ppi;    /* protection group combination */

   TRC2(maFindPpi)

   for (i=0; i<maCb.maSecCp.ppTbSize; i++)
   {
      if ((ppid == maCb.maSecCp.maPpTbl[i]->ppid) && 
          (ppri == maCb.maSecCp.maPpTbl[i]->ppri))
      {
         ppi = maCb.maSecCp.maPpTbl[i]->ppi;
         RETVALUE(ppi);
      }
   }
   RETVALUE(MA_INVALID_PPI);

} /* maFindPpi */

/*
*
*       Fun:    maIsSecReq
*
*       Desc:   check if secure transport required based on ACN and PPI
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 maIsSecReq
(
MaSaCp  *sa,      /* MAPsec SA control block */
MaDlgCp *dlg      /* Dialogue control block */
)
#else
PUBLIC S16 maIsSecReq(sa, dlg)
MaSaCp  *sa;      /* MAPsec SA control block */
MaDlgCp *dlg;     /* Dialogue control block */
#endif
{
   U8   g;   /* protection group number */
   U8   i;
   U16  ppi; /* protection profile */

   TRC2(maIsSecReq)

   ppi = sa->ppi;

   /* No protection for group 0 */
   if (ppi == 0x01)
   {
      RETVALUE(FALSE);
   }

   for (g=1; g<maCb.maSecCp.pgTbSize; g++)
   {

      if (ppi & (1<<maCb.maSecCp.maPgTbl[g]->pgi))
      {
         if (maCb.maSecCp.maPgTbl[g]->ac == dlg->apn.val[dlg->apn.len -2])
         {
            for(i=0; i<maCb.maSecCp.maPgTbl[g]->nmbPgTupleEnt; i++)
            {
               if (maCb.maSecCp.maPgTbl[g]->pg[i].acVer == 
                   dlg->apn.val[dlg->apn.len -1])
               {
                  /* save the protection group in dlgCp */
                  dlg->maPg = maCb.maSecCp.maPgTbl[g];
                  RETVALUE(TRUE);
               }
            }
         }
      }
   }
   /* No protection is required for this AC */
   RETVALUE(FALSE);
} /* maIsSecReq */

/*
*
*       Fun:   maBldProtDlgPdu
*
*       Desc:  Builds the protected MAP dialogue PDU  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File: ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maBldProtDlgPdu 
(
MaSap    *s,            /* MAP SAP pointer */
Buffer   *mBuf          /* Message pointer */
)
#else
PUBLIC S16 maBldProtDlgPdu(s, mBuf)
MaSap    *s;            /* MAP SAP pointer */
Buffer   *mBuf;         /* Message buffer */
#endif
{
   MsgLen      curLen;
   Data        pkArray[20];
   S16         ret;          /* return value */
   Data        idx;
   Buffer      *hdBuf;       /* Message buffer to encode security header */
   MaDlgCp     *dlgCp;       /* MAP SAP pointer */
   MaSecHeader secHdr;       /* security header src structure */

   TRC2(maBldProtDlgPdu)

   cmZero((Data *)&secHdr, sizeof(MaSecHeader));
   idx = 0;
   dlgCp = s->curDlgCp;
   (Void)SFndLenMsg(mBuf, &curLen);

   if(curLen > 0)
   {
      /* encode protected payload, use protection mode 0 for dialogue PDU, 
       * In protection mode 0, the ProtectedPayload carries the transfer 
       * syntax value of MAP-openInfo */

      /* encode the length */
      MA_ENCODE_LEN(curLen,idx)
      /* encode the tag for protected payload */
      pkArray[idx++] = (Data)MA_TAG_OCTSTR;

      ret = SAddPreMsgMult(pkArray, (MsgLen)idx, mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
      if (ret != ROK)
      {
         MALOGERROR(ERRCLS_ADD_RES, EMA222, (ErrVal)ret, 
                    "maBldProtDlgPdu () Failed");
         RETVALUE(RFAILED);
      }
#endif
   }/* curLen > 0 */

   /* encode secutiry header */

   maUpdSecHeader(s, &secHdr, MA_ORIG_CMP_USR, MA_PROT_MODE_0, NULLD, NULLD);

   if ((ret = SGetMsg(s->maPstST.region, s->maPstST.pool, &hdBuf )) != ROK)
   {
#ifndef ALIGN_64BIT

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
             "maBldProtDlgPdu () failed, fail to allocate mBuf,\
              suId(%d), sapId(%d), suDlgId(%ld), spDlgId(%ld))\n", 
              s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
      RETVALUE(RFAILED);

#else

      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
             "maBldProtDlgPdu () failed, fail to allocate mBuf,\
              suId(%d), sapId(%d), suDlgId(%d), spDlgId(%d))\n", 
              s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   }

   if ((ret = maEncSecHeader(hdBuf, &secHdr)) != ROK)
   {
      SPutMsg(hdBuf);
#ifndef ALIGN_64BIT

      MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
             "maOpenReqM00() failed, fail to encode security header,\
             suId(%d), sapId(%d), suDlgId(%ld), spDlgId(%ld))\n", 
             s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
      RETVALUE(RFAILED);

#else

      MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
             "maOpenReqM00() failed, fail to encode security header,\
             suId(%d), sapId(%d), suDlgId(%d), spDlgId(%d))\n", 
             s->suId, s->sapId, dlgCp->suDlgId, dlgCp->spDlgId));
      RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
   }
   /* Concatenate security header and protected payload */
   (Void)SCatMsg(mBuf, hdBuf, M2M1);
   (Void)SPutMsg(hdBuf);

   /* encode encapsulated AC */

   idx = 0;
   pkArray[idx++] = (Data)dlgCp->apn.val[7];
   pkArray[idx++] = (Data)dlgCp->apn.val[6];
   pkArray[idx++] = (Data)dlgCp->apn.val[5];
   pkArray[idx++] = (Data)dlgCp->apn.val[4];
   pkArray[idx++] = (Data)dlgCp->apn.val[3];
   pkArray[idx++] = (Data)dlgCp->apn.val[2];
   pkArray[idx++] = (Data)(40*dlgCp->apn.val[0] + dlgCp->apn.val[1]);
   pkArray[idx++] = (Data)7;
   pkArray[idx++] = (Data)MA_TAG_OBJID;

   ret = SAddPreMsgMult(pkArray, (MsgLen)idx, mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
   if (ret != ROK)
   {
      MALOGERROR(ERRCLS_ADD_RES, EMA223, (ErrVal)ret, 
                 "maBldProtDlgPdu() Failed");
      RETVALUE(RFAILED);
   }
#endif

   /* Add the length and tag of the MAP protected dialogue PDU */
    idx = 0;
   (Void)SFndLenMsg(mBuf, &curLen);

   /* encode the length */
   MA_ENCODE_LEN(curLen,idx)
   /* encode the tag for protected dialogue PDU */
   pkArray[idx++] = (Data)MA_TAG_SEQ;

   ret = SAddPreMsgMult(pkArray, (MsgLen)idx, mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
   if (ret != ROK)
   {
      MALOGERROR(ERRCLS_ADD_RES, EMA224, (ErrVal)ret, 
                 "maBldProtDlgPdu () Failed");
      RETVALUE(RFAILED);
   }
#endif

   if ((ret = maBldDlgId (mBuf, TRUE)) != ROK)
   {
      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
             "maBldProtDlgPdu() failed, unable to build dialog Id.\n"));
      RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /* end of maBldProtDlgPdu */

/*
*
*       Fun:   maDecProtDlgPdu
*
*       Desc:  decode the protected MAP dialogue PDU
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File: ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maDecProtDlgPdu 
(
MaSap    *s,            /* MAP SAP pointer */
Buffer   *mBuf,         /* Message pointer */
Bool     openPdu        /* if open pdu */
)
#else
PUBLIC S16 maDecProtDlgPdu(s, mBuf, openPdu)
MaSap    *s;            /* MAP SAP pointer */
Buffer   *mBuf;         /* Message buffer */
Bool     openPdu;       /* if open pdu */
#endif
{
   MsgLen   len;
   Data     tag, data;
   Bool     eocFlg;
   S16      ret;
   StStr    str;
   MaDlgCp  *dlgCp;
   MaSecHeader secHdr;       /* security header src structure */

   TRC2(maDecProtDlgPdu)

   cmZero((Data *)&secHdr, sizeof(MaSecHeader));
   eocFlg = FALSE;
   dlgCp = s->curDlgCp;

   if ( (ret = maDecDlgId(mBuf)) != ROK)
   {
      MADBGP(DBGMASK_LI, (maCb.maInit.prntBuf,
             "maDecProtDlgPdu() failed, unable to decode dialog Id.\n"));
      RETVALUE(RFAILED);
   }

   if ((ret = SExamMsg(&tag, mBuf, 0)) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA225, (ErrVal)tag, 
                "maDecProtDlgPdu() failed, Bad Protected PDU received");
#endif
      RETVALUE(RFAILED);
   }
   /* unprotected Abort PDU is allowed */
   if ((tag == MA_TAG_REFUSE_PDU) ||
       (tag == MA_TAG_CLOSE_PDU) ||
       (tag == MA_TAG_USRABRT_PDU) ||
       (tag == MA_TAG_PRVABRT_PDU))
   {
      RETVALUE(ROK);
   }

   (Void)SRemPreMsg(&tag, mBuf);
   if (tag != MA_TAG_SEQ)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA226, (ErrVal)tag, \
                 "maDecProtDlgPdu() failed, Bad Protected PDU received");
#endif
      RETVALUE(RFAILED);
   }
   if ((ret = maRemLen(mBuf, &eocFlg)) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA227, (ErrVal)ret, \
                 "maDecProtDlgPdu() failed, Bad protected PDU received");
#endif
      RETVALUE(RFAILED);
   }

   /* remove 2 bytes of EOC flag */
   if (eocFlg == TRUE)
   {
      (Void)SRemPstMsg(&data, mBuf);
      (Void)SRemPstMsg(&data, mBuf);
      RETVALUE(ROK);
   }
   /* remove encapsulated AC  */

   if ((ret = maRemPrim(mBuf, NULLP, &str.string[0], (U8 *)&(data))) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA228, (ErrVal)ret, \
                 "maDecProtDlgPdu() failed, Bad encapsulated AC received");
#endif
      RETVALUE(RFAILED);
   }
   str.len = data;

   if (openPdu == TRUE)
   {
      /* for Open PDU, we need to save encapsulated AC in dialogue 
       * control block */
      maConvertACN(&str);
      /* updated the application context name in dlg control point */
      dlgCp->apn.pres = TRUE;
      dlgCp->apn.len = (U8)str.len;
      cmCopy(&str.string[0],&dlgCp->apn.val[0], str.len);
   }

   /* security header and protected payload are optional for 
    * MAP protected dialogue PDU */
   (Void)SFndLenMsg(mBuf,&len);
   if (len == 0)
   {
      RETVALUE(ROK);
   }


   /* remove security header */
   if ((ret = maDecDlgSecHdr(s, mBuf, &secHdr)) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA229, (ErrVal)ret, \
                 "maDecProtDlgPdu() failed, Bad security header received");
#endif
      RETVALUE(RFAILED);
   }

   (Void)SFndLenMsg(mBuf,&len);
   if (len == 0)
   {
      RETVALUE(ROK);
   }

   (Void)SRemPreMsg(&tag, mBuf);
   if (tag != MA_TAG_OCTSTR)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA230, (ErrVal)tag, \
                 "maDecProtDlgPdu() failed, Bad Protected PDU received");
#endif
      RETVALUE(RFAILED);
   }
   if ((ret = maRemLen(mBuf, &eocFlg)) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA231, (ErrVal)ret, \
                 "maDecProtDlgPdu() failed, Bad protected PDU received");
#endif
      RETVALUE(RFAILED);
   }
   /* remove 2 bytes of EOC flag */
   if (eocFlg == TRUE)
   {
      (Void)SRemPstMsg(&data, mBuf);
      (Void)SRemPstMsg(&data, mBuf);
      RETVALUE(ROK);
   }

   RETVALUE(ROK);
} /* end of maDecProtDlgPdu */

/*
*
*       Fun:   maGetIntFromTkn
*
*       Desc:  Get a U32 integer from Token string
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File: ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void maGetIntFromTkn 
(
U32         *value,
TknStrS     *tkn
)
#else
PUBLIC Void maGetIntFromTkn(value, tkn)
U32         *value;
TknStrS     *tkn;
#endif
{
   TRC2(maGetIntFromTkn)

   *value = 0;
   *value = tkn->val[0];
   *value |= (tkn->val[1] << 8);
   *value |= (tkn->val[2] << 16);
   *value |= (tkn->val[3] << 24);

   RETVOID;

} /* maGetIntFromTkn */

/*
*
*       Fun:   maGetTknFromInt
*
*       Desc:  Get token string from a U32 integer
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File: ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void maGetTknFromInt 
(
U32         value,
U8          *arr
)
#else
PUBLIC Void maGetTknFromInt(value, arr)
U32         value;
U8          *arr;
#endif
{
   U8  i;

   TRC2(maGetTknFromInt)

   for (i=0; i<4; i++)
   {
      arr[i] = GetLoByte(GetLoWord(value));
      value = value >> 8;
   }
   /* set token length and pres field outside of this function */

   RETVOID;

} /* maGetTknFromInt */


/*
*
*       Fun:   maUpdSecHeader
*
*       Desc:  Builds the MAPsec security header
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File: ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maUpdSecHeader 
(
MaSap       *s,      /* MAP sap pointer */ 
MaSecHeader *hdr,    /* security header */
U8          cmpType, /* original component type */
U8          mode,    /* protection mode */
U8          oprCode, /* operation code */
U8          errCode  /* error code */
)
#else
PUBLIC S16 maUpdSecHeader(s, hdr, cmpType, mode, oprCode, errCode)
MaSap       *s;      /* MAP sap pointer */ 
MaSecHeader *hdr;    /* security header */
U8          cmpType; /* original component type */
U8          mode;    /* protection mode */
U8          oprCode; /* operation code */
U8          errCode; /* error code */
#endif
{
   U8      i;
   U32     tvp;
   U32     prop;   
   MaDlgCp *dlgCp;

   TRC2(maUpdSecHeader)

   dlgCp = s->curDlgCp;

   if (mode != MA_PROT_MODE_0)
   {
      maGetCurTvp(&tvp);
      tvp = (U32)(tvp / maCb.maCP.secGenCfg.tvPeriod) * maCb.maCP.secGenCfg.tvPeriod;

      maGetTknFromInt(tvp, &hdr->initVec.val[0]);
      hdr->initVec.len = 4;

      for (i=0; i<MA_NEID_LENGTH; i++)
      {
         if (s->cfg.secSapCfg.neId.length > i)
         {
            hdr->initVec.val[hdr->initVec.len] = s->cfg.secSapCfg.neId.strg[i];
         }
         else
         {
            /* padded with zeros */
            hdr->initVec.val[hdr->initVec.len] = 0x00;
         }
         hdr->initVec.len++;
      }

      /* update the next available proprietary value */
      prop = (maCb.maPropCounter > 0xfffffffe)?1:(maCb.maPropCounter++);
      maGetTknFromInt(prop, &hdr->initVec.val[hdr->initVec.len]);

      hdr->initVec.pres = TRUE;
      hdr->initVec.len = 14;
   }

   /* update SPI for secure header */
   maGetTknFromInt(dlgCp->saCp->sa.spi, &hdr->spi.val[0]);
   hdr->spi.pres = TRUE;
   hdr->spi.len = 4;

   /* update original component identifier for secure header */
   switch(cmpType)
   {
      case MA_ORIG_CMP_OPR:
         hdr->origCmpId.elmntPres.pres = TRUE;
         hdr->origCmpId.elmntPres.val = MA_ORIG_CMP_OPR;
         hdr->origCmpId.t.oprCode.elmntPres.pres = TRUE; 
         /* always use local value */
         hdr->origCmpId.t.oprCode.elmntPres.val = 1; 
         hdr->origCmpId.t.oprCode.s.locVal.pres = TRUE; 
         /* max value is 89 for oprCode */
         hdr->origCmpId.t.oprCode.s.locVal.len = 1; 
         hdr->origCmpId.t.oprCode.s.locVal.val[0] = oprCode; 

         break;

      case MA_ORIG_CMP_ERR:
         hdr->origCmpId.elmntPres.pres = TRUE;
         hdr->origCmpId.elmntPres.val = MA_ORIG_CMP_ERR;
         hdr->origCmpId.t.errCode.elmntPres.pres = TRUE; 
         /* always use local value */
         hdr->origCmpId.t.errCode.elmntPres.val = 1; 
         hdr->origCmpId.t.errCode.s.locVal.pres = TRUE; 
         /* max value is 72 for oprCode */
         hdr->origCmpId.t.errCode.s.locVal.len = 1; 
         hdr->origCmpId.t.errCode.s.locVal.val[0] = errCode; 

         break;   

      case MA_ORIG_CMP_USR:
         hdr->origCmpId.elmntPres.pres = TRUE;
         hdr->origCmpId.elmntPres.val = MA_ORIG_CMP_USR;
         hdr->origCmpId.t.usrInfo.pres = TRUE; 

         break;
   }

   RETVALUE(ROK);

} /* maUpdSecHeader */

/*
*
*       Fun:   maEncSecHeader
*
*       Desc:  encode MAPsec security header
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File: ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maEncSecHeader 
(
Buffer   *mBuf,         /* Message pointer */
MaSecHeader *secHdr     /* security header src structure */
)
#else
PUBLIC S16 maEncSecHeader(mBuf,secHdr)
Buffer   *mBuf;         /* Message buffer */
MaSecHeader *secHdr;    /* security header src structure */
#endif
{
   MaMsgCtl    ctlp;    /* security header message control block */    

   TRC2(maEncSecHeader)

   cmZero((Data *)&ctlp,sizeof(MaMsgCtl));

   ctlp.encode = TRUE;          /* encode flag */
   ctlp.decode = FALSE;         /* decode flag */
   ctlp.skip   = FALSE;         /* skip flag */
   ctlp.swtch  = 0;             /* switch type */
   ctlp.mBuf   = mBuf;          /* msg buffer */
   ctlp.sSt    = (U8 *)secHdr;       /* src structure */ 
   ctlp.sTelDef= &maDlgSecHeaderTkns[0];
   ctlp.maVer  = LMA_VER3;
   ctlp.errCode = 0;            /* error code */

   if (maEncSeq(&ctlp) == RFAILED)
   {
      MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
             "maEncSecHeader() failed.\n"));

      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* maEncSecHeader */

/*
*
*       Fun:   maDecSecHeader
*
*       Desc:  decode MAPsec security header
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File: ca_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 maDecSecHeader 
(
Buffer   *mBuf,         /* Message pointer */
MaSecHeader *secHdr,    /* security header src structure */
U8   *errCode            /* errCode */
)
#else
PUBLIC S16 maDecSecHeader(mBuf,secHdr,errCode)
Buffer   *mBuf;         /* Message buffer */
MaSecHeader *secHdr;    /* security header src structure */
U8   *errCode;           /* errCode */
#endif
{
   MaMsgCtl    ctlp;    /* security header message control block */    

   TRC2(maDecSecHeader)

   cmZero((Data *)&ctlp,sizeof(MaMsgCtl));

   ctlp.encode = FALSE;          /* encode flag */
   ctlp.decode = TRUE;         /* decode flag */
   ctlp.skip   = FALSE;         /* skip flag */
   ctlp.swtch  = 0;             /* switch type */
   ctlp.mBuf   = mBuf;          /* msg buffer */
   ctlp.sSt    = (U8 *)secHdr;       /* src structure */ 
   ctlp.sTelDef= &maDlgSecHeaderTkns[0];
   ctlp.maVer  = LMA_VER3;
   ctlp.errCode = 0;            /* error code */

   if (maDecSeq(&ctlp) != ROK)
   {
      MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
             "maDecSecHeader() failed.\n"));
      *errCode = ctlp.errCode;

      RETVALUE(RFAILED);
   }


  
   RETVALUE(ROK);

} /* maDecSecHeader */

/*
*
*       Fun:   maDecDlgSecHdr
*
*       Desc:  decode MAPsec security header for dialogue PDU
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maDecDlgSecHdr 
(
MaSap    *s,            /* MAP SAP pointer */
Buffer   *mBuf,         /* Message pointer */
MaSecHeader *secHdr     /* security header src structure */
)
#else
PUBLIC S16 maDecDlgSecHdr(s, mBuf,secHdr)
MaSap    *s;            /* MAP SAP pointer */
Buffer   *mBuf;         /* Message buffer */
MaSecHeader *secHdr;    /* security header src structure */
#endif
{
   MaDlgCp   *dlgCp;
   U32       spi;
   Data      data, tag;
   S16       ret;
   Bool      eocFlg;
   MaSaCp    *saCp;
   MsgLen    len;

   TRC2(maDecDlgSecHdr)

   eocFlg = FALSE;
   dlgCp = s->curDlgCp;

   /* remove tag for security header */
   (Void)SRemPreMsg(&tag, mBuf);
   if (tag != MA_TAG_SEQ)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA232, (ErrVal)tag, \
                 "maDecDlgSecHdr() failed, Bad security header tag");
#endif
      RETVALUE(RFAILED);
   }
   if ((ret = maRemLen(mBuf, &eocFlg)) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA233, (ErrVal)ret, \
                 "maDecDlgSecHdr() failed, Bad security header length");
#endif
      RETVALUE(RFAILED);
   }

   if ((ret = maGetPidFromSrcAddr(dlgCp) != ROK))
   {
      /* SA can not be found, an error is reported to MAP user. */
      s->secSts.nmbInvDstPlmn++;
      maDropSecDlg(s, dlgCp, LMA_CAUSE_INV_SRC_PLMN);   

#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA234, (ErrVal)ret, \
                 "maDecDlgSecHdr() failed, Bad sending PLMN Id received");
#endif
      RETVALUE(RFAILED);
   }

   cmCopy((U8 *)&maCb.maCP.secGenCfg.plmnId,(U8 *)&dlgCp->selfId,sizeof(LmaPlmnId));

   /* remove security parameter index */
   if ((ret = maRemPrim(mBuf, NULLP, &secHdr->spi.val[0], 
                            (U8 *)&(secHdr->spi.len))) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA235, (ErrVal)ret, \
                 "maDecDlgSecHdr() failed, Bad sending PLMN Id received");
#endif
      RETVALUE(RFAILED);
   }

   maGetIntFromTkn(&spi, &secHdr->spi);

   if (dlgCp->saCp == (MaSaCp *)NULLP)
   {
      saCp = maFindSa(dlgCp->peerId.mcc.val, dlgCp->peerId.mnc.val);
      if (saCp == (MaSaCp *)NULLP)
      {
         /* SA can not be found, an error is reported to MAP user. */

         s->secSts.nmbInvDstPlmn++;

         maDropSecDlg(s, dlgCp, LMA_CAUSE_INV_SRC_PLMN);   
#if (ERRCLASS & ERRCLS_DEBUG)
         SPrntMsg(mBuf,0,0);
         MALOGERROR(ERRCLS_DEBUG, EMA236, (ErrVal)ret, \
                 "maDecDlgSecHdr() failed, SA can't be found.");
#endif
         RETVALUE(RFAILED);
      }
   }
   else
   {
      saCp = dlgCp->saCp;
   }

   if (spi != saCp->sa.spi)
   {
      /* SPI mimatched, an error is reported to MAP user. */

      s->secSts.nmbInvSpiAtmpt++;

      maDropSecDlg(s, dlgCp, LMA_CAUSE_INV_SPI_ATMPT);   
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      /* MALOGERROR(ERRCLS_DEBUG, EMA237, (ErrVal)ret, \
                 "maDecDlgSecHdr() failed, SPI mismatched.");*/
#endif
      RETVALUE(RFAILED);
   }
   /* protection group is saved in dlgCp if secure transport is required */
   if ((saCp->sa.mapSec == FALSE) || (maIsSecReq(saCp,dlgCp) == FALSE))
   {
      /* MAPsec is not to be used */

      s->secSts.nmbInvSecOpenReq++;
      maDropSecDlg(s, dlgCp, LMA_CAUSE_INV_SEC_OPEN);   
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA238, (ErrVal)ret, \
                 "maDecDlgSecHdr() failed, MAPsec is not to be used.");
#endif
      RETVALUE(RFAILED);
   }

   if(dlgCp->saCp == (MaSaCp *)NULLP)
   {
      /* insert this dlgCp into the head of saCp linked list */
      maInsSaDlg(dlgCp, saCp);
      dlgCp->saCp = saCp;
   }

   /* remove tag for original component identifier */
   (Void)SRemPreMsg(&tag, mBuf);
   if (tag != MA_TAG_CSPRIM2)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA239, (ErrVal)tag, \
                 "maDecDlgSecHdr() failed, wrong original comp identifier");
#endif
      RETVALUE(RFAILED);
   }
   /* remove the length of userInfo */
   (Void)SRemPreMsg(&data, mBuf);

   (Void)SFndLenMsg(mBuf,&len);
   /* remove 2 bytes of EOC flag */
   if (eocFlg == TRUE)
   {
      if (len >= 2)
      {
         (Void)SRemPreMsg(&data, mBuf);
         (Void)SRemPreMsg(&data, mBuf);
      }
      else
      {
         RETVALUE(RFAILED);
      }
   }

   RETVALUE(ROK);

} /* maDecDlgSecHdr */

/*
*
*       Fun:   maSndRefPdu   
*
*       Desc:  This function encodes and sends MAP refuse PDU  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maSndRefPdu 
(
MaSap    *s,           /* MAP sap */
U8       refReason,    /* refuse reason */
Bool     altAcPres     /* alternative AC present */
)
#else
PUBLIC S16 maSndRefPdu (s, refReason,altAcPres)
MaSap    *s;           /* MAP sap */
U8       refReason;    /* Refuse reason */
Bool     altAcPres;    /* alternative AC present */
#endif
{
   StDlgEv  dlgEv;
   MaDlgCp  *dlgCp;
   Buffer   *mBuf;
   Data     pkArray[20];
   MsgLen   len;
   S16      ret;
#ifdef STUV2
   StDataParam dataParam;
#endif

   TRC2(maSndRefPdu)

/* ma001.203 : Addition. Initialized dataParam */
#ifdef STUV2
   cmZero((Data *) &dataParam, sizeof(StDataParam));
#endif


   dlgCp = s->curDlgCp;
   dlgEv.pres = TRUE;
   maBldDlgEv(s, &dlgEv, STU_DLGP_ABT);

   if ((ret = SGetMsg(s->maPstST.region, s->maPstST.pool, &mBuf )) != ROK)
   {
      RETVALUE(ret);
   }

   len = 0;
   if (altAcPres == TRUE)
   {
      pkArray[len++] = (Data)dlgCp->apn.val[7];
      pkArray[len++] = (Data)dlgCp->apn.val[6];
      pkArray[len++] = (Data)dlgCp->apn.val[5];
      pkArray[len++] = (Data)dlgCp->apn.val[4];
      pkArray[len++] = (Data)dlgCp->apn.val[3];
      pkArray[len++] = (Data)dlgCp->apn.val[2];
      pkArray[len++] = (Data)(40*dlgCp->apn.val[0] + dlgCp->apn.val[1]);
      pkArray[len++] = (Data)7;
      pkArray[len++] = (Data)MA_TAG_OBJID;
   }
   pkArray[len++] = refReason;
   pkArray[len++] = (Data)1;
   pkArray[len++] = MA_TAG_ENUM;
   pkArray[len] = (Data)len;
   len++;
   pkArray[len++] = MA_TAG_REFUSE_PDU; 

   ret = SAddPreMsgMult(pkArray, (MsgLen)len, mBuf);
   if (ret != ROK)
   {
#if (ERRCLASS & ERRCLS_ADD_RES)
      MALOGERROR(ERRCLS_ADD_RES, EMA240, (ErrVal)ret, 
                 "maSndRefPdu () Failed");
#endif
      (Void)SPutMsg(mBuf);
       RETVALUE(RFAILED);
    }
   if ((ret = maBldDlgId(mBuf, FALSE)) != ROK)
   {
      (Void)SPutMsg(mBuf);
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
             "maOpenRspM05() failed,unable to build dialog Id.\n")); 
      RETVALUE(RFAILED);
   }

   if (s->trc == TRUE)
      maGenTrc(s, LMA_DATA_TXED, mBuf);

#ifdef MATV3
   MA_UPD_DEFAULT_QOS_PARAMS(s,dlgCp);
#endif

#ifdef STUV2
   /* this is a MAP self-generated TC-ABORT, highest imp is used */
   dataParam.imp.val = MAT_IMP_VAL_7;
   dataParam.imp.pres = TRUE;

   MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_U_ABORT, dlgCp->spDlgId, 
                  dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                  FALSE, &s->qosSet, &dlgEv, &dataParam, mBuf);
#else
   MaLiStuDatReq(&s->maPstST, s->spIdTC, STU_U_ABORT, dlgCp->spDlgId, 
                  dlgCp->lowerSpDlgId, &dlgCp->destAddr, &dlgCp->srcAddr,
                  FALSE, &s->qosSet, &dlgEv, mBuf);
#endif /* STUV2 */

   RETVALUE(ROK);
} /* end of maSndRefPdu */

/*
*
*       Fun:   maChkProtMode   
*
*       Desc:  This function verify protection mode for incoming message
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkProtMode 
(
MaDlgCp  *dlgCp,         /* MAP dialogue control block */
LmaSecPl protLevel,      /* protection level */
U8       IVPres,         /* IV present */
U8       cmpType         /* component type */
)
#else
PUBLIC S16 maChkProtMode (dlgCp, protLevel, IVPres, cmpType)
MaDlgCp  *dlgCp;         /* MAP dialogue control block */
LmaSecPl protLevel;      /* protection level */
U8       IVPres;         /* IV present */
U8       cmpType;        /* component type */
#endif
{

   TRC2(maChkProtMode)

   UNUSED(dlgCp);

   switch(cmpType)
   {
      case LMA_CMP_INVK:
         /* invoke component require protection mode 1 or 2 */
         if (IVPres != TRUE)
         {
            RETVALUE(RFAILED);
         }
        break;

      case LMA_CMP_RES:
         if ((IVPres != TRUE) && 
             ((protLevel > MAPSEC_LEVEL1) && (protLevel < MAPSEC_LEVEL6)))
         {
            RETVALUE(RFAILED);
         }

        break;

      case LMA_CMP_ERR:
      case LMA_CMP_USR:
         /* protection mode 0 is used for return error and user info */

       break;

   }

#ifdef MATST
   {
      S16 ret;
      /* The following funciton is used for acceptance tests only */
      ret = maAccChkProtMode(cmpType);
      RETVALUE(ret);
   }
#else
   RETVALUE(ROK);
#endif /* MATST */

} /* end of maChkProtMode */


/*
*
*       Fun:    maIsSecOpr
*
*       Desc:   check if secure transport required based on ACN and PPI
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PRIVATE S16 maIsSecOpr
(
MaDlgCp  *dlgCp,         /* MAP dialogue control block */
U8       oprCode,        /* Operation code */
LmaSecPl *pl             /* protection level */
)
#else
PRIVATE S16 maIsSecOpr(dlgCp, oprCode, pl)
MaDlgCp  *dlgCp;         /* MAP dialogue control block */
U8       oprCode;        /* Operation code */
LmaSecPl *pl;            /* protection level */
#endif
{
   U8   i;

   TRC2(maIsSecOpr)

   for(i=0; i<dlgCp->maPg->nmbPgTupleEnt; i++)
   {
      if ((oprCode == dlgCp->maPg->pg[i].oprCode) && 
          (dlgCp->apn.val[dlgCp->apn.len -1] == dlgCp->maPg->pg[i].acVer))
      {
         *pl = dlgCp->maPg->pg[i].pl;      /* protection level */
             RETVALUE(TRUE);
      }
   }
   /* No protection is required for this operation */
   RETVALUE(FALSE);
} /* maIsSecOpr */

/*
*
*       Fun:    maStoreReq
*
*       Desc:   This function store component event (for Fallback)
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 maStoreReq
(
MaSap    *s,            /* MAP sap control block */
MaDlgCp  *dlgCp,        /* MAP dialogue control block */
StComps  *cmpEv,        /* component event structure */ 
Buffer   *mBuf          /* Message Buffer */
)
#else
PUBLIC S16 maStoreReq(s,dlgCp, cmpEv, mBuf)
MaSap    *s;            /* MAP sap control block */
MaDlgCp  *dlgCp;        /* MAP dialogue control block */
StComps  *cmpEv;        /* component event structure */ 
Buffer   *mBuf;         /* Message Buffer */
#endif
{
   S16      ret;
   Data     *tmpBuf;
   MaCmpStd *cmpStd;

   TRC2(maStoreReq)

   if ((ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, &tmpBuf, 
        sizeof(MaCmpStd))) != ROK)
   {
      MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
             "maStoreReq() failed, can not allocate cmp stored block.\n"));
      RETVALUE(RFAILED);
   }
   cmpStd = (MaCmpStd *)tmpBuf;

   /* store cmpEv */
   cmCopy((U8 *)cmpEv, (U8 *)&cmpStd->cmpEv, sizeof(StComps)); 

   /* store message buffer */
   ret = SCpyMsgMsg(mBuf, s->maPstST.region, s->maPstST.pool, &cmpStd->mBuf);
   if (ret != ROK)
   {
      SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)tmpBuf, sizeof(MaCmpStd));
      MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
             "maStoreReq() failed, can not store mBuf.\n"));
      RETVALUE(RFAILED);
   }

   /* insert this cmpStd into the head of linked list */
   if (dlgCp->cmpLst == (MaCmpStd *)NULLP)
   {
      dlgCp->cmpLst = cmpStd;
      cmpStd->next = (MaCmpStd *)NULLP;
   }
   else
   {
      MaCmpStd *cmpStd1;

      cmpStd1 = dlgCp->cmpLst;
      while(cmpStd1->next != (MaCmpStd *)NULLP)
      {
         cmpStd1 = cmpStd1->next;
      }
      cmpStd1->next = cmpStd;
      cmpStd->next = (MaCmpStd *)NULLP;
   }

   RETVALUE(ROK);
} /* maStoreReq */

/*
*
*       Fun:    maReStoreReq
*
*       Desc:   restore component for fallback
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PUBLIC Void maRestoreReq
(
MaSap    *s,            /* MAP sap control block */
MaDlgCp  *dlgCp         /* MAP dialogue control block */
)
#else
PUBLIC Void maRestoreReq(s, dlgCp)
MaSap    *s;            /* MAP sap control block */
MaDlgCp  *dlgCp;        /* MAP dialogue control block */
#endif
{
   MaCmpStd *cmpStd;

   TRC2(maRestoreReq)

   /* restore cmpStdv */
   cmpStd = dlgCp->cmpLst;
   /* remove this cmpStd from the head of linked list */
   dlgCp->cmpLst = dlgCp->cmpLst->next;

   MaLiStuCmpReq (&s->maPstST, s->spIdTC, dlgCp->spDlgId, dlgCp->lowerSpDlgId, 
                   &cmpStd->cmpEv, cmpStd->mBuf);

   /* free the dialogue memory */
   SPutSBuf(maCb.maInit.region, maCb.maInit.pool,(Data *)cmpStd,sizeof(MaCmpStd));

   RETVOID;

} /* maRestoreReq */

/*
*
*       Fun:    maReqIdle
*
*       Desc:   remove stored component for fallback
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PUBLIC Void maReqIdle
(
MaDlgCp  *dlgCp         /* MAP dialogue control block */
)
#else
PUBLIC Void maReqIdle(dlgCp)
MaDlgCp  *dlgCp;        /* MAP dialogue control block */
#endif
{
   MaCmpStd *cmpStd;
   Buffer   *mBuf;

   TRC2(maReqIdle)

   while(dlgCp->cmpLst != (MaCmpStd *)NULLP)
   {
      cmpStd = dlgCp->cmpLst;
      mBuf = cmpStd->mBuf;
      if (mBuf != NULLP)
      {
         SPutMsg(mBuf);
      } 
      /* remove this cmpStd from the head of linked list */
      dlgCp->cmpLst = dlgCp->cmpLst->next;

      /* free the dialogue memory */
      SPutSBuf(maCb.maInit.region, maCb.maInit.pool,(Data *)cmpStd,sizeof(MaCmpStd));
   }

   RETVOID;

} /* maReqIdle */

/*
*
*       Fun:    maGetE164fromGT
*
*       Desc:   Find E.164 number from GT
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PRIVATE Void maGetE164fromGT
(
U16        *cc,      /* Country code */
U32        *ndc,     /* National destination code */
ShrtAddrs  *addr     /* address digits (BCD) */
)
#else
PRIVATE Void maGetE164fromGT(cc, ndc, addr)
U16        *cc;     /* Country code */
U32        *ndc;    /* National destination code */
ShrtAddrs  *addr;   /* address digits (BCD) */
#endif
{

   TRC2(maGetE164fromGT)

   /* Get country code form GT */
   *cc = (addr->strg[0] | ((addr->strg[1] & 0x0f) << 8));
   if (((addr->strg[0] & 0xf0) >> 4) >= BASE10)
   {
      /* one digit cc */
      *cc |= 0xfff0;
   }
   else if ((addr->strg[1] & 0x0f) >= BASE10)
   {
      /* two digits cc */
      *cc |= 0xff00;
   }
   else
   {
      /* three digits cc */
      *cc |= 0xf000;
   }

   /* Get National destination code form GT */
   *ndc = (U32)(addr->strg[1] >> 4) | 
          (U32)(addr->strg[2] << 4) |
          (U32)(addr->strg[3] << 12);

   if((addr->strg[2] & 0x0f) >= BASE10)
   {
      /* 1 Digit NDC case */
      *ndc |= 0xfffffff0;
   }
   else if (((addr->strg[2] & 0xf0) >> 4) >= BASE10)
   {
      /* 2 Digit NDC case */
      *ndc |= 0xffffff00;
   }
   else if ((addr->strg[3] & 0x0f) >= BASE10)
   {
      /* 3 Digit NDC case */
      *ndc |= 0xfffff000;
   }
   else if (((addr->strg[3] & 0xf0) >> 4) >= BASE10)
   {
      /* 4 Digit NDC case */
      *ndc |= 0xffff0000;
   }
   else
   {
      /* 5 Digit NDC case */
      *ndc |= 0xfff00000;
   }

   RETVOID;

} /* maGetE164fromGT */

/*
*
*       Fun:   maGetPidFromSrcAddr
*
*       Desc:  Get plmn id from imcoming source SCCP address
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File: ca_bdy4.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maGetPidFromSrcAddr 
(
MaDlgCp    *dlgCp       /* Dialogue control block */
)
#else
PRIVATE S16 maGetPidFromSrcAddr(dlgCp)
MaDlgCp    *dlgCp;      /* Dialogue control block */
#endif
{
   SpAddr     *destAddr;       /* destination SCCP address */
   SpAddr     *srcAddr;        /* source SCCP address */
   MaSaCp     *sa;             /* SA control block */
   MaSaMapCp  *saMap;          /* SA mapping control block */
   TknStrS    addrStr;
   U16        cc;
   U32        ndc;

   TRC2(maGetPidFromSrcAddr)

   destAddr = &dlgCp->destAddr;
   srcAddr  = &dlgCp->srcAddr;

   if (destAddr->rtgInd == RTE_GT)
   {
      /* inter-plmn case */
      switch (destAddr->sw)
      {
         case SW_ITU:
            /* Global title includes translation type, numbering plan,
             * encoding scheme and address indicator
             * Numbering plan for ITU case is E.164
             */
            if ((destAddr->gt.format == GTFRMT_4) && 
                (destAddr->gt.gt.f4.numPlan == NP_ISDN) &&
                (destAddr->gt.addr.length >= MA_MIN_GT_ADDR_LEN))
            {
               maGetE164fromGT(&cc, &ndc, &destAddr->gt.addr);
 
               /* binary sreach in SA mapping table to find the mapping block*/
               saMap = maFindSaMap(cc, ndc);
               if(saMap == (MaSaMapCp *)NULLP)
               {
#ifndef ALIGN_64BIT

                  MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                  "maGetPidFromSrcAddr() failed,invalid cc(%d) or ndc(%ld))\n",
                  cc, ndc));
                  RETVALUE(RFAILED);

#else

                  MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                  "maGetPidFromSrcAddr() failed,invalid cc(%d) or ndc(%d))\n",
                  cc, ndc));
                  RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
               }
               sa = *(maCb.maSecCp.maSaCbPtr + saMap->indx);
               dlgCp->saCp = sa;

               /* copy plmn id */
               cmCopy((U8 *)&sa->sa.plmnId, (U8 *)&dlgCp->peerId,
                      sizeof(LmaPlmnId));
            }
            else
            {
               MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                     "maGetPidFromSrcAddr() failed, invalid GT format (%d) or \
                      invalid numbering plan (%d) or address length (%d)\n",
                      destAddr->gt.format, destAddr->gt.gt.f4.numPlan, 
                      destAddr->gt.addr.length));
               RETVALUE(RFAILED);
            }

            break;

         case SW_ANSI:
            /* Global title includes translation type,
             * Numbering plan for ITU case is E.164 or E.212
             */
            if ((destAddr->gt.format == GTFRMT_2) &&
                (destAddr->gt.addr.length >= MA_MIN_GT_ADDR_LEN))
            {
               switch (destAddr->gt.gt.f2.tType)
               {
                  case 9:
                    /* IMSI included, E.212 */
                    addrStr.pres = TRUE;
                    addrStr.len = destAddr->gt.addr.length;
                    cmCopy(&destAddr->gt.addr.strg[0], &addrStr.val[0],
                           destAddr->gt.addr.length);
                    maGetPidFromStr(&dlgCp->peerId, &addrStr);

                    break;

                  case 10: 
                  case 14:
                    /* MSISND included. E.164 */
                    maGetE164fromGT(&cc, &ndc, &destAddr->gt.addr);
                    /* binary sreach to find the mapping block*/
                    saMap = maFindSaMap(cc, ndc);
                    if(saMap == (MaSaMapCp *)NULLP)
                    {
#ifndef ALIGN_64BIT

                       MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                       "maGetPidFromSrcAddr() failed, cc(%d) or ndc(%ld))\n",
                       cc, ndc));
                       RETVALUE(RFAILED);

#else

                       MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                       "maGetPidFromSrcAddr() failed, cc(%d) or ndc(%d))\n",
                       cc, ndc));
                       RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */  
                    }
                    sa = *(maCb.maSecCp.maSaCbPtr + saMap->indx);
                    dlgCp->saCp = sa;

                    /* copy plmn id */
                    cmCopy((U8 *)&sa->sa.plmnId, (U8 *)&dlgCp->peerId,
                           sizeof(LmaPlmnId));

                    break;
 
                  default:
#if (ERRCLASS & ERRCLS_INT_PAR)
                    MALOGERROR(ERRCLS_INT_PAR, EMA241, (ErrVal)destAddr->sw, 
                               "maGetPidFromSrcAddr() Failed, invalid tType");
#endif
                    MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                    "maGetPidFromSrcAddr() failed, invalid tType (%d)\n",
                    destAddr->gt.gt.f2.tType));
                    RETVALUE(RFAILED);

               }
            }
            else
            {
               MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                     "maGetPidFromSrcAddr() failed, invalid GT format (%d)\n",
                     destAddr->gt.format));
               RETVALUE(RFAILED);
            }
            break;

         default:
#if (ERRCLASS & ERRCLS_INT_PAR)
            MALOGERROR(ERRCLS_INT_PAR, EMA242, (ErrVal)destAddr->sw, 
            "maGetPidFromSrcAddr() Failed, invalid switch");
#endif
            MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                   "maGetPidFromSrcAddr() failed, protocol switch (%d)\n",
                   destAddr->sw));
            RETVALUE(RFAILED);
      }
   }
   else
   {
      /* intra-plmn case */
      cmCopy((U8 *)&maCb.maCP.secGenCfg.plmnId,(U8 *)&dlgCp->peerId,
             sizeof(LmaPlmnId));
   }

   RETVALUE(ROK);

} /* maGetPidFromSrcAddr */

/*
*
*       Fun:   maGetPidFromStr
*
*       Desc:  Get plmn id from token string
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File: ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void maGetPidFromStr 
(
LmaPlmnId   *plmnId,   /* self Plmn Identifier */
TknStrS     *tkn       /* TBCD string of plmnId */
)
#else
PUBLIC Void maGetPidFromStr(plmnId, tkn)
LmaPlmnId   *plmnId;   /* self Plmn Identifier */
TknStrS     *tkn;      /* TBCD string of plmnId */
#endif
{

   TRC2(maGetPidFromStr)

   plmnId->mcc.val = ((tkn->val[1] & 0x0f) << 8) | (tkn->val[0]);
   plmnId->mcc.val |= 0xf000;
   plmnId->mcc.pres = TRUE;

   if((tkn->val[1] >> 4) == 0x0f)
   {
      /* 2 Digit MNC case */
      plmnId->mnc.val = (U16)(tkn->val[2]);
      plmnId->mnc.val |= 0xff00;
   }
   else
   {
      /* 3 digit MNC case */
      plmnId->mnc.val = (tkn->val[2] | (tkn->val[1] << 12));
      plmnId->mnc.val |= 0xf000;
   }

   plmnId->mnc.pres = TRUE;

   RETVOID;

} /* maGetPidFromStr */

/*
*
*       Fun:   maGetStrFromPid
*
*       Desc:  get token string from plmn id
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File: ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void maGetStrFromPid 
(
LmaPlmnId   *plmnId,   /* self Plmn Identifier */
TknStrS     *tkn       /* TBCD string of plmnId */
)
#else
PUBLIC Void maGetStrFromPid(plmnId, tkn)
LmaPlmnId   *plmnId;   /* self Plmn Identifier */
TknStrS     *tkn;      /* TBCD string of plmnId */
#endif
{
   U8 tmp;

   TRC2(maGetStrFromPid)

   tmp = (GetHiByte(plmnId->mcc.val)) & 0x0f;
   tkn->val[0] = tmp | (GetLoByte(plmnId->mcc.val) & 0xf0);
   tmp = (GetLoByte(plmnId->mcc.val)) & 0x0f;

   if((GetHiByte(plmnId->mnc.val) & 0x0f) == 0xf)
   {
      /* 2 Digit MNC case */
      tkn->val[1] = tmp | 0xf0;
      tkn->val[2] =  GetLoByte(plmnId->mnc.val) >> 4;
      tkn->val[2] |= GetLoByte(plmnId->mnc.val) << 4;
   }
   else
   {
      /* 3 Digit MNC case */
      tkn->val[1] = tmp | (GetLoByte(plmnId->mnc.val) << 4);
      tkn->val[2] =  GetHiByte(plmnId->mnc.val) & 0x0f;
      tkn->val[2] |= (GetLoByte(plmnId->mnc.val) & 0xf0);
   }

   tkn->pres = TRUE;
   tkn->len = 3;

   RETVOID;

} /* maGetStrFromPid */

/*
*
*       Fun:   maGetCurTvp
*
*       Desc:  Get current TVP stamp
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File: ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void maGetCurTvp 
(
U32     *tvp       /* TVP */
)
#else
PUBLIC Void maGetCurTvp(tvp)
U32     *tvp;      /* TVP */
#endif
{
   S16        ret;
   U32        sec;
   U32        usec;

   TRC2(maGetCurTvp)

   sec = 0;
   usec = 0;

   ret = SGetRefTime(SS_REFTIME_01_01_2002, &sec, &usec);
   if (ret != ROK)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MALOGERROR(ERRCLS_DEBUG, EMA243, (ErrVal)0,
                 "SGetRefTime() Failed, Invalid return time.");
#endif 
      RETVOID;
   }

   *tvp = (sec * 10) + (usec / 1000000);

   RETVOID;

} /* maGetCurTvp */

/*
*
*       Fun:   maDropSecDlg
*
*       Desc:  this function has the actions required to drop a secure
*              dialogue.
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File: ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void maDropSecDlg 
(
MaSap       *s,        /* MAP sap */
MaDlgCp     *dlgCp,    /* dialogue control block */
U16          cause      /* alarm cause */
)
#else
PUBLIC Void maDropSecDlg(s, dlgCp,cause)
MaSap       *s;        /* MAP sap */
MaDlgCp     *dlgCp;    /* dialogue control block */
U16          cause;     /* alarm cause */
#endif
{

   TRC2(maDropSecDlg)

   maSendAlrm(NEW,s->sapId, STMATSA, LMA_BAD_PLMN_PARAM, 
              "maDecDlgSecHdr", LMA_EVENT_MAPSEC_RESPONDER,
              LCM_CATEGORY_INTERFACE, cause);

   /* send notice indication to the map user */
   MaUiMatNotInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                 dlgCp->spDlgId, MAT_ABEVT_RCVD_PEER);

   s->nmbActvDlg--;

   RETVOID;

} /* maDropSecDlg */

/*
*
*       Fun:   maDropSecOprReq
*
*       Desc:  This function contains actions require to drop a secure
*              transport operation request.
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File: ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void maDropSecOprReq 
(
MaSap       *s,        /* MAP sap */
StComps     *cmpEv,    /* Component Event Structure */
MaDlgCp     *dlgCp,    /* dialogue control block */
U16          cause     /* alarm cause */
)
#else
PUBLIC Void maDropSecOprReq(s, cmpEv, dlgCp,cause)
MaSap       *s;        /* MAP sap */
StComps     *cmpEv;    /* Component Event Structure */
MaDlgCp     *dlgCp;    /* dialogue control block */
U16          cause;     /* alarm cause */
#endif
{

   TRC2(maDropSecOprReq)

   /* MAP standard does not specify the problem code to be used. 
    * We use STU_MISTYPED_PARAM for now. */

   maSndTcRej(s, cmpEv, STU_PROB_INVOKE, STU_MISTYPED_PARAM);

   /* send notice indication to the map user */
   MaUiMatNotInd(&s->maPstMU, s->suId, dlgCp->suDlgId, 
                            dlgCp->spDlgId, MAT_ABEVT_RCVD_PEER);

   dlgCp->cmpId.cmpType = LMA_INVOKE_COMP;
   dlgCp->cmpId.cmpVal.oprCode = cmpEv->stOpCode.string[0];

   maSendAlrm(NEW,s->sapId, STMATSA, LMA_BAD_PLMN_PARAM, 
              "maDropSecOprReq", LMA_EVENT_MAPSEC_RESPONDER,
               LCM_CATEGORY_INTERFACE, cause);

   /* remove the component control point */
   maRemHashInv(dlgCp, &cmpEv->stInvokeId,FALSE);

   RETVOID;

} /* maDropSecOprReq */

/*
*
*       Fun:   maDropSecOprRsp
*
*       Desc:  This function contains actions require to drop a secure
*              transport operation response.
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File: ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void maDropSecOprRsp 
(
MaSap       *s,        /* MAP sap */
StComps     *cmpEv,    /* Component Event Structure */
MaCmpCp     *cmpCp,    /* Component control block */
U16          cause      /* alarm cause */
)
#else
PUBLIC Void maDropSecOprRsp(s, cmpEv, cmpCp,cause)
MaSap       *s;        /* MAP sap */
StComps     *cmpEv;    /* Component Event Structure */
MaCmpCp     *cmpCp;    /* Component control block */
U16          cause;     /* alarm cause */
#endif
{
   MaUsrErr    usrErr;
   MaPrvErr    prvErr;
   MaDlgCp     *tmpCurDlgCp;

   TRC2(maDropSecOprRsp)

   usrErr.pres = FALSE;
   prvErr.pres = FALSE;

   s->curDlgCp->cmpId.cmpType = LMA_RESULT_COMP;
   s->curDlgCp->cmpId.cmpVal.oprCode = cmpEv->stOpCode.string[0];
   maSendAlrm(NEW,s->sapId, STMATSA, LMA_BAD_PLMN_PARAM, 
              "maProcSecRetRsltL", LMA_EVENT_MAPSEC_INITIATOR,
              LCM_CATEGORY_INTERFACE, cause);

   tmpCurDlgCp =  s->curDlgCp;
   /* send confirm to the map user */
   prvErr.pres = TRUE;
   prvErr.errSrc = MAT_REMOTE_PRV_ERR;
   prvErr.errCode = MAT_INVRSP_RCVD;
   maSndSSCfm(s, cmpCp, &prvErr, &usrErr);

   /* remove the component control point */
   maRemHashInv(tmpCurDlgCp, &cmpEv->stInvokeId,TRUE);

   RETVOID;

} /* maDropSecOprRsp */

/*
*
*       Fun:   maDropSecOprErr
*
*       Desc:  This function contains actions require to drop a secure
*              transport reture error.
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File: ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void maDropSecOprErr 
(
MaSap       *s,        /* MAP sap */
StComps     *cmpEv,    /* Component Event Structure */
MaCmpCp     *cmpCp,    /* Component control block */
U16          cause      /* alarm cause */
)
#else
PUBLIC Void maDropSecOprErr(s, cmpEv, cmpCp,cause)
MaSap       *s;        /* MAP sap */
StComps     *cmpEv;    /* Component Event Structure */
MaCmpCp     *cmpCp;    /* Component control block */
U16          cause;     /* alarm cause */
#endif
{
   MaPrvErr    prvErr;
   MaUsrErr    usrErr;

   TRC2(maDropSecOprErr)

   usrErr.pres = FALSE;
   prvErr.pres = FALSE;

   /* Error not correct send the Tc-U Reject */
   maSndTcRej(s, cmpEv, STU_PROB_RET_ERR, STU_UNREC_ERROR);

   s->curDlgCp->cmpId.cmpType = LMA_RESULT_COMP;
   s->curDlgCp->cmpId.cmpVal.oprCode = cmpEv->stOpCode.string[0];
   maSendAlrm(NEW,s->sapId, STMATSA, LMA_BAD_PLMN_PARAM, 
              "maProcSecRetErr", LMA_EVENT_MAPSEC_INITIATOR,
              LCM_CATEGORY_INTERFACE, cause);

   /* send confirm to the map user */
   usrErr.pres = FALSE;
   prvErr.pres = TRUE;
   prvErr.errSrc = MAT_REMOTE_PRV_ERR;
   prvErr.errCode = MAT_INVRSP_RCVD;
   maSndSSCfm(s, cmpCp, &prvErr, &usrErr);

   RETVOID;

} /* maDropSecOprErr */


/*
*
*       Fun:   maCmpSecAcn    
*
*       Desc:  This function compares the secure transport ACN 
*
*       Ret:   0 if both the strings are same. 
*
*       Notes: None 
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maCmpSecAcn 
(
U8 *s1,         /* string 1 */
U8 *s2,         /* String 2 */
S16 len1,       /* length of string1 */
S16 len2        /* length of string2 */
)
#else
PUBLIC S16 maCmpSecAcn (s1,s2,len1,len2)
U8 *s1;         /* string 1 */
U8 *s2;         /* String 2 */
S16 len1;       /* length of string1 */
S16 len2;       /* length of string2 */
#endif
{
   S16 i;

   TRC2(maCmpSecAcn)

   if (len1 != len2)
   {
      RETVALUE(len1 - len2);
   }
   for(i=0;i<len1-2;i++)
   {
      if (s1[i] != s2[i])
      {
         RETVALUE(s1[i] - s2[i]);
      }
   }
   if (s2[len2-2] != MA_SEC_TRANS_HANDL_AC)
   {
      RETVALUE(MA_SEC_TRANS_HANDL_AC - s2[len2-2]);
   }
   if (s2[len2-1] != LMA_VER3)
   {
      RETVALUE(LMA_VER3 - s2[len2-1]);
   }

   /* equal strings */
   RETVALUE(0);
} /* end of maCmpSecAcn */

/*
*
*       Fun:   maGetEncapAcn    
*
*       Desc:  This decodes encapsulated AC from protected PDU
*
*       Ret:   0 if both the strings are same. 
*
*       Notes: None 
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maGetEncapAcn 
(
Buffer   *mBuf,
StStr    *acn
)
#else
PUBLIC S16 maGetEncapAcn (mBuf, acn)
Buffer   *mBuf;
StStr    *acn;
#endif
{
   Bool     eocFlg;
   MsgLen   len;
   Data     tag, data;
   S16      ret;
   MaSecHeader secHdr;       /* security header src structure */

   TRC2(maGetEncapAcn)

   cmZero((Data *)&secHdr, sizeof(MaSecHeader));
   tag = 0;
   eocFlg = FALSE;

   if ((ret = maDecDlgId(mBuf)) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA244, (ErrVal)tag, "Bad PDU received in maEndM03");
#endif
      RETVALUE(RFAILED);
   }

   (Void)SRemPreMsg(&tag, mBuf);
   if (tag != MA_TAG_SEQ)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA245, (ErrVal)tag, \
                 "maGetEncapAcn() failed, Bad Protected PDU received");
#endif
      RETVALUE(RFAILED);
   }

   if ((ret = maRemLen(mBuf, &eocFlg)) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA246, (ErrVal)ret, \
                 "maGetEncapAcn() failed, Bad protected PDU received");
#endif
      RETVALUE(RFAILED);
   }

   /* remove 2 bytes of EOC flag */
   (Void)SFndLenMsg(mBuf,&len);
   if ((len >= 2) && (eocFlg == TRUE))
   {
      (Void)SRemPstMsg(&data, mBuf);
      (Void)SRemPstMsg(&data, mBuf);
   }

   /* remove encapsulated AC  */

   if ((ret = maRemPrim(mBuf,NULLP,&acn->string[0],(U8 *)&(data))) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA247, (ErrVal)ret, \
                 "maGetEncapAcn() failed, Bad encapsulated AC received");
#endif
      RETVALUE(RFAILED);
   }
   acn->len = data;
   maConvertACN(acn);

   /* security header and protected payload are optional for 
    * MAP protected dialogue PDU */
   (Void)SFndLenMsg(mBuf,&len);
   if (len == 0)
   {
      RETVALUE(ROK);
   }


   /* remove security header */
   /* remove tag for security header */
   (Void)SRemPreMsg(&tag, mBuf);
   if (tag != MA_TAG_SEQ)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA248, (ErrVal)tag, \
                 "maDecDlgSecHdr() failed, Bad security header tag");
#endif
      RETVALUE(RFAILED);
   }

   if ((ret = maRemLen(mBuf, &eocFlg)) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA249, (ErrVal)ret, \
                 "maDecDlgSecHdr() failed, Bad security header length");
#endif
      RETVALUE(RFAILED);
   }

   /* remove security parameter index */
   if ((ret = maRemPrim(mBuf, NULLP, &secHdr.spi.val[0], 
                            (U8 *)&(secHdr.spi.len))) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA250, (ErrVal)ret, \
                 "maDecDlgSecHdr() failed, Bad sending PLMN Id received");
#endif
      RETVALUE(RFAILED);
   }

   /* remove tag for original component identifier */
   (Void)SRemPreMsg(&tag, mBuf);
   if (tag != MA_TAG_CSPRIM2)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA251, (ErrVal)tag, \
                 "maDecDlgSecHdr() failed, wrong original comp identifier");
#endif
      RETVALUE(RFAILED);
   }

   /* remove the length of original component identifier (userInfo) */
   (Void)SRemPreMsg(&data, mBuf);

   /* remove 2 bytes of EOC flag */
   if ((len >= 2) && (eocFlg == TRUE))
   {
      (Void)SRemPreMsg(&data, mBuf);
      (Void)SRemPreMsg(&data, mBuf);
   }

   /* protected payload is optional */
   (Void)SFndLenMsg(mBuf,&len);
   if (len == 0)
   {
      RETVALUE(ROK);
   }

   (Void)SRemPreMsg(&tag, mBuf);
   if (tag != MA_TAG_OCTSTR)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA252, (ErrVal)tag, \
                 "maGetEncapAcn() failed, Bad PPL Tag");
#endif
      RETVALUE(RFAILED);
   }

   if ((ret = maRemLen(mBuf, &eocFlg)) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA253, (ErrVal)ret, \
                 "maGetEncapAcn() failed, Bad protected PDU received");
#endif
      RETVALUE(RFAILED);
   }

   /* remove 2 bytes of EOC flag */
   (Void)SFndLenMsg(mBuf,&len);
   if ((len >= 2) && (eocFlg == TRUE))
   {
      (Void)SRemPstMsg(&data, mBuf);
      (Void)SRemPstMsg(&data, mBuf);
   }


   RETVALUE(ROK);
} /* end of maGetEncapAcn */

/*
*
*       Fun:   maDecProtPayload 
*
*       Desc:  This function decode protected payload
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maDecProtPayload 
(
MaSap       *s,            /* SAP pointer */
MaDlgCp     *dlgCp,        /* Dialogue Control Point */
StComps     *cmpEv,        /* Component Event */
MaSecHeader *secHdr,       /* security header */
Buffer      *cipherBuf,    /* message buffer for ciphertext */
U8          protMode       /* protection mode */
)
#else
PRIVATE S16 maDecProtPayload (s, dlgCp, cmpEv, secHdr, cipherBuf, protMode)
MaSap       *s;          /* SAP pointer */
MaDlgCp     *dlgCp;      /* Dialogue Control Point */
StComps     *cmpEv;      /* Component Event */
MaSecHeader *secHdr;     /* security header */
Buffer      *cipherBuf;  /* message buffer for ciphertext */
U8          protMode;    /* protection mode */
#endif
{
   TknStrS       mac;         /* message authentication code */
   U32           rxdTvp;       /* time variant parameter received*/
   U32           curTvp;       /* current TVP */
   S16           ret;

   TRC2(maDecProtPayload)

   /* check freshness of protected message */
   maGetIntFromTkn(&rxdTvp, &secHdr->initVec);
   maGetCurTvp(&curTvp);
   if ((curTvp - rxdTvp) > maCb.maCP.secGenCfg.tvpWinSz)
   {
      s->secSts.nmbTvpChkFail++;
      maDropSecOprReq(s, cmpEv, dlgCp, LMA_CAUSE_TVP_CHK_FAIL);
      RETVALUE(RFAILED);
   }

   switch(protMode)
   {
      case MA_PROT_MODE_1:   /* Integrity checksum for invoke */

         /* protection mode 1 is required. call intergrity hook 
          * function and cleartext should be writen in s->crntRxMsg */

         ret = maF7Dec(dlgCp->saCp->sa.mia, &dlgCp->saCp->sa.mik, 
                       secHdr, s->crntRxMsg);
         if (ret != ROK)
         {
            s->secSts.nmbExtractFail++;
            maDropSecOprReq(s, cmpEv, dlgCp, LMA_CAUSE_EXTRACT_FAIL);
            RETVALUE(RFAILED);
         }

         /* remove MAC from protected payload */
         ret = SRemPstMsgMult((Data*)&mac.val[0], (MsgLen)4, s->crntRxMsg);
         if (ret != ROK)
         {
            MADBGP(MA_DBGMASK_SEC_RESP, (maCb.maInit.prntBuf,
                   "maDecProtPayload() failed to get MAC .\n"));
            RETVALUE(RFAILED);
         }

         break;

      case MA_PROT_MODE_2: /* invoke-encryption and integrity-result*/

         /* protection mode 2 is required. call intergrity hook 
          * function first and s->crntRxMsg should not be re-writen */

         ret = maF7Dec(dlgCp->saCp->sa.mia, &dlgCp->saCp->sa.mik, 
                       secHdr, cipherBuf);
         if (ret != ROK)
         {
            s->secSts.nmbExtractFail++;
            maDropSecOprReq(s, cmpEv, dlgCp, LMA_CAUSE_EXTRACT_FAIL);
            RETVALUE(RFAILED);
         }

         /* remove MAC from protected payload */
         ret = SRemPstMsgMult((Data*)&mac.val[0], (MsgLen)4, cipherBuf);
         if (ret != ROK)
         {
            MADBGP(MA_DBGMASK_SEC_RESP, (maCb.maInit.prntBuf,
                   "maDecProtPayload() failed to get MAC .\n"));
            RETVALUE(RFAILED);
         }

         SInitMsg(s->crntRxMsg);
         /* call confidentiality hook function, cleartext should 
          * be writen in s->crntRxMsg. */
         ret = maF6Dec(dlgCp->saCp->sa.mea, &dlgCp->saCp->sa.mek, 
                       secHdr, s->crntRxMsg, cipherBuf);
         if (ret != ROK)
         {
            s->secSts.nmbExtractFail++;
            maDropSecOprReq(s, cmpEv, dlgCp, LMA_CAUSE_EXTRACT_FAIL);
            RETVALUE(RFAILED);
         }
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA254, (ErrVal)protMode, \
                    "maDecProtPayload() Failed");
#endif
         RETVALUE(RFAILED);
         break;
   }

   RETVALUE(ROK);

} /* maDecProtPayload */

/*
*
*       Fun:   maProcSecInvk 
*
*       Desc:  This function process the secure invoke component  
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maProcSecInvk 
(
MaSap   *s,             /* SAP pointer */
MaDlgCp *dlgCp,         /* Dialogue Control Point */
StComps *cmpEv,         /* Component Event */
MaCmpCp *cmpCp          /* Componebt control block */
)
#else
PUBLIC S16 maProcSecInvk (s, dlgCp, cmpEv, cmpCp)
MaSap      *s;          /* SAP pointer */
MaDlgCp    *dlgCp;      /* Dialogue Control Point */
StComps    *cmpEv;      /* Component Event */
MaCmpCp    *cmpCp;      /* Componebt control block */
#endif
{
   StStr         errStr;
   MaSaCp        *saCp;
   U32           spi;
   LmaSecPl      protLevel;    /* protection level */
   U8            oprType;      /* operation code */
   S16           ret;
   MaSecHeader   secHdr;       /* security header */
   Buffer        *cipherBuf;   /* message buffer for ciphertext */

   TRC2(maProcSecInvk)

   oprType = NULLD;
   cipherBuf = NULLP;
   cmZero((Data *)&secHdr, sizeof(MaSecHeader));

   /* a protected message is received */

   /* decode secure transport argumnet */
   ret = maDecSecTransTkns(s, s->crntRxMsg, &secHdr, &cipherBuf);
   if(ret == ROK)
   {
      if (secHdr.origCmpId.t.oprCode.s.locVal.pres != TRUE)
      {
         /* received component type is not correct. the message is 
          * discarded and report an error back to sending user. */
         s->ctlp.errCode = MAT_DATA_MISSING;
         ret = RFAILED;
      }
      else 
      {
         oprType = secHdr.origCmpId.t.oprCode.s.locVal.val[0];
         ret = maChkOprCode(oprType);
         if (ret != ROK)
         {
            s->ctlp.errCode = MAT_UNX_DATA_VALUE;
         }
      }
   }
   if (ret != ROK)
   {
      if (s->ctlp.errCode == MAT_MISTYPE_PARAM)
      {
         maSndTcRej(s, cmpEv, STU_PROB_INVOKE, STU_MISTYPED_PARAM);
      }
      else if((cmpCp->oprCode == MAT_SEC_TRANS_CLASS1) || 
              (cmpCp->oprCode == MAT_SEC_TRANS_CLASS2))
      {
         /* operation parameter not supported send the Tc-U Error */
         errStr.len = 1;
         errStr.string[0] = s->ctlp.errCode;
         maSndTcErr(s, &cmpEv->stInvokeId, &errStr, cmpCp, NULLP);
      }

      /* send notice indication to the map user */
      MaUiMatNotInd(&s->maPstMU,s->suId, dlgCp->suDlgId,dlgCp->spDlgId, 
                    MAT_ABEVT_RCVD_PEER);

      /* remove the component control point */
      maRemHashInv(dlgCp, &cmpEv->stInvokeId,FALSE);
      if (cipherBuf != NULLP)
      {
         (Void)SPutMsg(cipherBuf);
      }
      RETVALUE(RFAILED);
   }

   /* update the operation code with original operation */
   cmpCp->oprCode = oprType; 

   /* SA control block may have been found when DSM processed MAP
    * protected dialogue PDU in which security header is present. 
    */
   if (dlgCp->saCp == (MaSaCp *)NULLP)
   {
      if ((ret = maGetPidFromSrcAddr(dlgCp) != ROK))
      {
         /* SA entry can not be found, the message is discarded and
          * report an error back to sending user.
          */
         s->secSts.nmbInvDstPlmn++;
         maDropSecOprReq(s, cmpEv, dlgCp, LMA_CAUSE_INV_SRC_PLMN);
         if (cipherBuf != NULLP)
         {
            (Void)SPutMsg(cipherBuf);
         }
         RETVALUE(RFAILED);
      }
      saCp = dlgCp->saCp;

      cmCopy((U8 *)&maCb.maCP.secGenCfg.plmnId, (U8 *)&dlgCp->selfId,
             sizeof(LmaPlmnId));
      maGetIntFromTkn(&spi, &secHdr.spi);

      if (saCp == (MaSaCp *)NULLP)
      {
         saCp = maFindSa(dlgCp->peerId.mcc.val, dlgCp->peerId.mnc.val);
      }
      if (saCp == (MaSaCp *)NULLP)
      {
         /* SA entry can not be found, the message is discarded and
          * report an error back to sending user. */

         s->secSts.nmbInvDstPlmn++;
         maDropSecOprReq(s, cmpEv, dlgCp, LMA_CAUSE_INV_SRC_PLMN);
         if (cipherBuf != NULLP)
         {
            (Void)SPutMsg(cipherBuf);
         }
         RETVALUE(RFAILED);
      }
      if (saCp->sa.spi != spi)
      {
         /* SPI does not match */

         s->secSts.nmbInvSpiAtmpt++;
         maDropSecOprReq(s, cmpEv, dlgCp, LMA_CAUSE_INV_SPI_ATMPT);
         if (cipherBuf != NULLP)
         {
            (Void)SPutMsg(cipherBuf);
         }
         RETVALUE(RFAILED);
      }
      /* protection group is saved in dlgCp if secure transport 
       * is required */
      if ((saCp->sa.mapSec == FALSE)||(maIsSecReq(saCp,dlgCp) == FALSE))
      {
         /* MAPsec is not to be used */

         maDropSecOprReq(s, cmpEv, dlgCp, LMA_CAUSE_INV_SEC_OPEN);
         if (cipherBuf != NULLP)
         {
            (Void)SPutMsg(cipherBuf);
         }
         RETVALUE(RFAILED);
      }

      /* insert this dlgCp into the head of saCp linked list */
      maInsSaDlg(dlgCp, saCp);
      dlgCp->saCp = saCp;
   }

   /* precessing MAPsec message */

   /* If secure transport is required for this operation,
    * protection level will be saved in protLevel. */
   if (maIsSecOpr(dlgCp, oprType, &protLevel) != TRUE)
   {
      /* protection mode 0 is to be used */

      goto EXIT_FUN;
   }

   if (maChkProtMode(dlgCp,protLevel,secHdr.initVec.pres,LMA_CMP_INVK) != ROK)
   {
      /* if protection mode is not correct, abort the dialogue
       * with refuse reason transport protection not adequate
       */
      maDropSecOprReq(s, cmpEv, dlgCp, LMA_CAUSE_INV_PROT_MODE);
      if (cipherBuf != NULLP)
      {
         (Void)SPutMsg(cipherBuf);
      }
      RETVALUE(RFAILED);
   }

   switch(protLevel)
   {
      case MAPSEC_LEVEL1:
      case MAPSEC_LEVEL2:
      case MAPSEC_LEVEL3:

         /* protection mode 1 is required. call intergrity hook 
          * function and cleartext should be writen in s->crntRxMsg */

         ret = maDecProtPayload(s, dlgCp, cmpEv, &secHdr, cipherBuf,
                                MA_PROT_MODE_1);
         if (ret != ROK)
         {
            s->secSts.nmbExtractFail++;
            maDropSecOprReq(s, cmpEv, dlgCp, LMA_CAUSE_EXTRACT_FAIL);
            if (cipherBuf != NULLP)
            {
               (Void)SPutMsg(cipherBuf);
            }
            RETVALUE(RFAILED);
         }

         break;

      case MAPSEC_LEVEL4:
      case MAPSEC_LEVEL5:
      case MAPSEC_LEVEL6:

         /* protection mode 2 is required. call intergrity hook 
          * function first and s->crntRxMsg should not be re-writen */

         ret = maDecProtPayload(s, dlgCp, cmpEv, &secHdr, cipherBuf,
                                MA_PROT_MODE_2);
         if (ret != ROK)
         {
            s->secSts.nmbExtractFail++;
            maDropSecOprReq(s, cmpEv, dlgCp, LMA_CAUSE_EXTRACT_FAIL);
            if (cipherBuf != NULLP)
            {
               (Void)SPutMsg(cipherBuf);
            }
            RETVALUE(RFAILED);
         }

         break;


      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA255, (ErrVal)protLevel, \
                    "maProcSecInvk() Failed");
#endif
         if (cipherBuf != NULLP)
         {
            (Void)SPutMsg(cipherBuf);
         }
         RETVALUE(RFAILED);
         break;
   }

EXIT_FUN:
   /* Update the Stat. */
   maUpdatSecRxSts(s, oprType, MAT_SS_REQ);

   if (s->trc == TRUE)
      maGenTrc(s, LMA_DATA_RECVD, s->crntRxMsg);

   if (cipherBuf != NULLP)
   {
      (Void)SPutMsg(cipherBuf);
   }

   RETVALUE(ROK);

} /* maProcSecInvk */

/*
*
*       Fun:   maProcSecRetRsltL    
*
*       Desc:  This function process the secure return result last 
*              componet from TCAP. 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maProcSecRetRsltL 
(
MaSap   *s,             /* MAP SAP */
MaDlgCp *dlgCp,         /* Dialogue Control Point */
StComps *cmpEv,         /* Component Event */
MaCmpCp *cmpCp          /* Componebt control block */
)
#else
PUBLIC S16 maProcSecRetRsltL (s, dlgCp, cmpEv, cmpCp)
MaSap     *s;           /* MAP SAP */
MaDlgCp   *dlgCp;       /* Dialogue Control Point */
StComps   *cmpEv;       /* Component Event */
MaCmpCp   *cmpCp;       /* Componebt control block */
#endif
{
   MaUsrErr      usrErr;
   MaPrvErr      prvErr;
   S16           ret;
   LmaSecPl      protLevel;    /* protection level */
   U8            oprType;      /* operation code */
   MaSecHeader   secHdr;       /* security header */
   Buffer        *cipherBuf;   /* message buffer for ciphertext */

   TRC2(maProcSecRetRsltL)

   oprType = NULLD;
   cipherBuf = NULLP;
   usrErr.pres = FALSE;
   prvErr.pres = FALSE;
   cmZero((Data *)&secHdr, sizeof(MaSecHeader));

   /* a protected message is received */
   ret = maDecSecTransTkns(s, s->crntRxMsg, &secHdr, &cipherBuf);
   if(ret == ROK)
   {
      if (secHdr.origCmpId.t.oprCode.s.locVal.pres != TRUE)
      {
         /* received component type is not correct. the message is 
          * discarded and report an error to user. */
         s->ctlp.errCode = MAT_DATA_MISSING;
         ret = RFAILED;
      }
      else 
      {
         oprType = secHdr.origCmpId.t.oprCode.s.locVal.val[0];
         ret = maChkOprCode(oprType);
         if ((ret != ROK) || (oprType != cmpCp->oprCode))
         {
            ret = RFAILED;
            s->ctlp.errCode = MAT_UNX_DATA_VALUE;
         }
       }
   }
   if (ret != ROK)
   {
      if (s->ctlp.errCode == MAT_MISTYPE_PARAM)   
      {
         maSndTcRej(s, cmpEv, STU_PROB_RET_RES, STU_RR_MISTYPED_PAR);
      }
      /* send confirm to the map user */
      prvErr.pres = TRUE;
      prvErr.errSrc = MAT_REMOTE_PRV_ERR;
      prvErr.errCode = MAT_INVRSP_RCVD;
      maSndSSCfm(s, cmpCp, &prvErr, &usrErr);

      /* remove the component control point */
      maRemHashInv(dlgCp, &cmpEv->stInvokeId,TRUE);
      if (cipherBuf != NULLP)
      {
         (Void)SPutMsg(cipherBuf);
      }
      RETVALUE(RFAILED);
   }
   oprType = secHdr.origCmpId.t.oprCode.s.locVal.val[0];

   /* precessing MAPsec message */

   /* If secure transport is required for this operation,
    * protection level will be saved in protLevel. */
   if (maIsSecOpr(dlgCp, oprType, &protLevel) != TRUE)
   {
      /* protection mode 0 is to be used */

      goto EXIT_FUN;
   }

   if (maChkProtMode(dlgCp, protLevel,secHdr.initVec.pres,LMA_CMP_RES) != ROK)
   {
      /* if protection mode is not correct, abort the dialogue
       * with refuse reason transport protection not adequate
       */
      maDropSecOprRsp(s, cmpEv, cmpCp, LMA_CAUSE_INV_PROT_MODE);
      if (cipherBuf != NULLP)
      {
        (Void)SPutMsg(cipherBuf);
      }
      RETVALUE(RFAILED);
   }

   switch(protLevel)
   {
      case MAPSEC_LEVEL1:
      case MAPSEC_LEVEL6:

         break;
      case MAPSEC_LEVEL2:
      case MAPSEC_LEVEL4:

         /* protection mode 1 is required. call intergrity hook 
          * function and cleartext should be writen in s->crntRxMsg */

         ret = maDecProtPayload(s, dlgCp, cmpEv, &secHdr, cipherBuf,
                                MA_PROT_MODE_1);
         if (ret != ROK)
         {
            s->secSts.nmbExtractFail++;
            maDropSecOprRsp(s, cmpEv, cmpCp, LMA_CAUSE_EXTRACT_FAIL);
            if (cipherBuf != NULLP)
            {
              (Void)SPutMsg(cipherBuf);
            }
            RETVALUE(RFAILED);
         }

         break;

      case MAPSEC_LEVEL3:
      case MAPSEC_LEVEL5:

         /* protection mode 2 is required. call intergrity hook 
          * function first and s->crntRxMsg should not be re-writen */

         ret = maDecProtPayload(s, dlgCp, cmpEv, &secHdr, cipherBuf,
                                MA_PROT_MODE_2);
         if (ret != ROK)
         {
            s->secSts.nmbExtractFail++;
            maDropSecOprRsp(s, cmpEv, cmpCp, LMA_CAUSE_EXTRACT_FAIL);
            if (cipherBuf != NULLP)
            {
              (Void)SPutMsg(cipherBuf);
            }
            RETVALUE(RFAILED);
         }

         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA256, (ErrVal)protLevel, \
                    "maProcSecRetRsltL() Failed, wrong protection level.");
#endif
         if (cipherBuf != NULLP)
         {
           (Void)SPutMsg(cipherBuf);
         }
         RETVALUE(RFAILED);
         break;
   }

EXIT_FUN:
   if(cmpEv->stCompType == STU_RET_RES_L) 
   /* Update the Stat. */
   maUpdatSecRxSts(s, oprType, MAT_SS_RSP);

   if (s->trc == TRUE)
      maGenTrc(s, LMA_DATA_RECVD, s->crntRxMsg);

   if (cipherBuf != NULLP)
   {
     (Void)SPutMsg(cipherBuf);
   }

   RETVALUE(ROK);

} /* maProcSecRetRsltL */

/*
*
*       Fun:   maProcSecRetErr    
*
*       Desc:  This function process the secure TC Error component 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maProcSecRetErr 
(
MaSap  *s,              /* MAP SAP pointer */
MaDlgCp *dlgCp,         /* Dialogue Control Point */
StComps *cmpEv,         /* Component Event */
MaCmpCp *cmpCp          /* Componebt control block */
)
#else
PUBLIC S16 maProcSecRetErr (s, dlgCp, cmpEv, cmpCp)
MaSap      *s;          /* MAP SAP pointer */
MaDlgCp    *dlgCp;      /* Dialogue Control Point */
StComps    *cmpEv;      /* Component Event */
MaCmpCp    *cmpCp;      /* Componebt control block */
#endif
{
   MaUsrErr    usrErr;
   MaPrvErr    prvErr;
   S16         ret;
   LmaSecPl      protLevel;    /* protection level */
   MaSecHeader   secHdr;       /* security header */
   Buffer        *cipherBuf;   /* message buffer for ciphertext */
   U8            errCode;      /* error code */

   TRC2(maProcSecRetErr)

   ret = ROK;
   cipherBuf = NULLP;
   usrErr.pres = FALSE;
   prvErr.pres = FALSE;
   cmZero((Data *)&secHdr, sizeof(MaSecHeader));

   /* decode secure transport argumnet */
   ret = maDecSecTransTkns(s, s->crntRxMsg, &secHdr, &cipherBuf);
   if(ret == ROK)
   {
      if (secHdr.origCmpId.t.errCode.s.locVal.pres != TRUE)
      {
         /* received component type is not correct. the message is 
          * discarded and report an error to user. */
         s->ctlp.errCode = MAT_DATA_MISSING;
         ret = RFAILED;
      }
      else 
      {
         errCode  = secHdr.origCmpId.t.errCode.s.locVal.val[0];
         if((errCode < MAT_USR_INIT_RLS) || (errCode > MAT_USSD_BUSY))
         {
            ret = RFAILED;
            s->ctlp.errCode = MAT_UNX_DATA_VALUE;
         }
       }
   }
   if (ret != ROK)
   {
      if (s->ctlp.errCode == MAT_MISTYPE_PARAM)   
      {
         maSndTcRej(s, cmpEv, STU_PROB_RET_RES, STU_RR_MISTYPED_PAR);
      }
      /* send confirm to the map user */
      prvErr.pres = TRUE;
      prvErr.errSrc = MAT_REMOTE_PRV_ERR;
      prvErr.errCode = MAT_INVRSP_RCVD;
      maSndSSCfm(s, cmpCp, &prvErr, &usrErr);
      if (cipherBuf != NULLP)
      {
        (Void)SPutMsg(cipherBuf);
      }
      MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
             "maProcSecRetErr() failed to decode SecureTransportError.\n"));
      RETVALUE(RFAILED);
   }

   if (secHdr.origCmpId.t.errCode.s.locVal.pres != TRUE)
   {
      maDropSecOprErr(s, cmpEv, cmpCp, LMA_CAUSE_INV_ORIG_CMP);
      if (cipherBuf != NULLP)
      {
        (Void)SPutMsg(cipherBuf);
      }
      MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
             "maProcSecRetErr() failed, wrong original component.\n"));
      RETVALUE(RFAILED);
   }
   /* Update the real error code */
   cmpCp->errCode = secHdr.origCmpId.t.errCode.s.locVal.val[0];

   /* precessing MAPsec message */

   /* If secure transport is required for this operation,
    * protection level will be saved in protLevel. */
   if (maIsSecOpr(dlgCp, cmpCp->oprCode, &protLevel) != TRUE)
   {
      /* protection mode 0 is to be used */

      goto EXIT_FUN;
   }

   if (maChkProtMode(dlgCp, protLevel,secHdr.initVec.pres, LMA_CMP_ERR) != ROK)
   {
      /* if protection mode is not correct, abort the dialogue
       * with refuse reason transport protection not adequate
       */
      maDropSecOprErr(s, cmpEv, cmpCp, LMA_CAUSE_INV_PROT_MODE);
      if (cipherBuf != NULLP)
      {
        (Void)SPutMsg(cipherBuf);
      }
      MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
             "maProcSecRetErr() failed, protection mode isn't correct.\n"));
      RETVALUE(RFAILED);
   }

   switch(protLevel)
   {
      case MAPSEC_LEVEL1:
      case MAPSEC_LEVEL2:
      case MAPSEC_LEVEL3:
      case MAPSEC_LEVEL4:
      case MAPSEC_LEVEL5:
      case MAPSEC_LEVEL6:
         /* Protection mode 0 is used for all return error */

         break;
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA257, (ErrVal)protLevel, \
                    "maProcSecRetErr() Failed, wrong protection level.");
#endif
         if (cipherBuf != NULLP)
         {
           (Void)SPutMsg(cipherBuf);
         }
         RETVALUE(RFAILED);
         break;
   }

EXIT_FUN:
   maUpdatSecErrSts(s,cmpCp->oprCode,MAT_SS_RSP);

   if (s->trc == TRUE)
      maGenTrc(s, LMA_DATA_RECVD, s->crntRxMsg);

   if (cipherBuf != NULLP)
   {
     (Void)SPutMsg(cipherBuf);
   }

   RETVALUE(ROK);

} /* maProcSecRetErr */


/*
*
*       Fun:   maEncProtPayload    
*
*       Desc:  This function encode protected payload
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PRIVATE S16 maEncProtPayload 
(
MaSap      *s,          /* MAP SAP pointer */
MaDlgCp    *dlgCp,      /* Dialogue Control Point */
U8         cmpType,     /* original component type */
U8         oprCode,     /* operation code */
U8         errCode,     /* error code */
U8         mode         /* protection mode */
)
#else
PRIVATE S16 maEncProtPayload (s,dlgCp,cmpType,oprCode,errCode,mode)
MaSap      *s;          /* MAP SAP pointer */
MaDlgCp    *dlgCp;      /* Dialogue Control Point */
U8         cmpType;     /* original component type */
U8         oprCode;     /* operation code */
U8         errCode;     /* error code */
U8         mode;        /* protection mode */
#endif
{
   MaSecHeader secHdr;       /* security header */
   Buffer      *hdBuf;       /* message buffer for security header */
   Buffer      *cipherBuf;   /* message buffer for ciphertext */
   TknStrS     mac;         /* message authentication code */
   S16         ret;

   TRC2(maEncProtPayload)

   cmZero((Data *)&secHdr, sizeof(MaSecHeader));
   maUpdSecHeader(s, &secHdr, cmpType, mode, oprCode, errCode);

   if ((ret = SGetMsg(s->maPstST.region, s->maPstST.pool, &hdBuf )) != ROK)
   {
      MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
             "maEncProtPayload()failed, \
             unable to allocate message buffer for security header.\n"));
      RETVALUE(RFAILED);
   }

   if ((ret = maEncSecHeader(hdBuf, &secHdr)) != ROK)
   {
      SPutMsg(hdBuf);
      MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
             "maEncProtPayload()failed, fail to encode security header.\n"));
      RETVALUE(RFAILED);
   }

   switch(mode)
   {
      case MA_PROT_MODE_0: 

         ret = SCpyMsgMsg(s->ctlp.mBuf, s->maPstST.region, s->maPstST.pool, 
                          &cipherBuf);
         if (ret != ROK)
         {
            s->secSts.nmbProtFail++;
            SPutMsg(hdBuf);
            MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                   "maEncProtPayload() failed, \
                   copy cipertext failed. protection mode (%d)\n", mode));
            RETVALUE(RFAILED);

         }
         break;

      case MA_PROT_MODE_1: 
 
         /* call intergrity hook function */
         ret = maF7Enc(dlgCp->saCp->sa.mia, &dlgCp->saCp->sa.mik, &secHdr, 
                          hdBuf, s->ctlp.mBuf, &mac);
         if (ret != ROK)
         {
            s->secSts.nmbProtFail++;
            SPutMsg(hdBuf);
            MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                   "maEncProtPayload() failed, integrity function \
                   f7 failed. protection mode (%d)\n", mode));
            RETVALUE(RFAILED);
         }

         ret = SCpyMsgMsg(s->ctlp.mBuf, s->maPstST.region, s->maPstST.pool, 
                          &cipherBuf);
         if (ret != ROK)
         {
            SPutMsg(hdBuf);
            MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                   "maEncProtPayload() failed, copy cipertext failed.\
                   protection mode (%d)\n", mode));
            RETVALUE(RFAILED);
         }

         /* concatenation of cleartext and MAC */
         ret = SAddPstMsgMult(&mac.val[0], (MsgLen)4, cipherBuf);
         if (ret != ROK)
         {
            SPutMsg(hdBuf);
            SPutMsg(cipherBuf);
            MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                   "maEncProtPayload() failed, concatenation of \
                   cleartext and MAC failed. protection mode (%d)\n", mode));
            RETVALUE(RFAILED);
         }

         break;

      case MA_PROT_MODE_2:

         ret = SGetMsg(s->maPstST.region, s->maPstST.pool, &cipherBuf);
         if (ret != ROK)
         {
            SPutMsg(hdBuf);
            MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                   "maEncProtPayload() failed, unable to allocate \
                   message buffer for protected payload.\n"));
            RETVALUE(RFAILED);
         }

         /* call confidentiality hook function, 
          * return ciphertext in cipherBuf */
         ret = maF6Enc(dlgCp->saCp->sa.mea, &dlgCp->saCp->sa.mek, &secHdr, 
                       s->ctlp.mBuf, cipherBuf);
         if (ret != ROK)
         {
            s->secSts.nmbProtFail++;
            SPutMsg(hdBuf);
            SPutMsg(cipherBuf);
            MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                   "maEncProtPayload() failed, confidentiality function\
                   f6 failed. Protection mode (%d)\n", mode));
            RETVALUE(RFAILED);
         }

         ret = maF7Enc(dlgCp->saCp->sa.mia, &dlgCp->saCp->sa.mik, &secHdr, 
                       hdBuf, cipherBuf, &mac);
         if (ret != ROK)
         {
            SPutMsg(hdBuf);
            SPutMsg(cipherBuf);
            s->secSts.nmbProtFail++;
            MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                   "maEncProtPayload() failed, integrity function \
                   f7 failed. protection mode (%d)\n", mode));
            RETVALUE(RFAILED);
         }

         /* concatenation of cleartext and MAC */
         ret = SAddPstMsgMult(&mac.val[0], (MsgLen)4, cipherBuf);
         if (ret != ROK)
         {
            SPutMsg(hdBuf);
            SPutMsg(cipherBuf);
            MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                   "maEncProtPayload() failed, concatenation of \
                   cleartext and MAC failed. protection mode (%d)\n", mode));
            RETVALUE(RFAILED);
         }

         break;
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA258, (ErrVal)mode, \
                    "maEncProtPayload() Failed");
#endif
         SPutMsg(hdBuf);
         RETVALUE(RFAILED);
         break;
   }

   /* Now we have protected payload and security header, we can 
    * encode secure transport component */

   SPutMsg(s->ctlp.mBuf);
   s->ctlp.mBuf = NULLP;
   ret = maEncSecTransTkns(s, hdBuf, cipherBuf, &s->ctlp.mBuf);
   if (ret != ROK)
   {
      MADBGP(DBGMASK_UI, (maCb.maInit.prntBuf,
             "maEncProtPayload()failed, encoding secure \
             transport operatioin failed.\n"));
      if (s->ctlp.mBuf != NULLP)
      {
        (Void)SPutMsg(s->ctlp.mBuf);
        s->ctlp.mBuf = NULLP;
      }
      (Void)SPutMsg(hdBuf);
      (Void)SPutMsg(cipherBuf);
      RETVALUE(RFAILED);
   }

   (Void)SPutMsg(hdBuf);
   (Void)SPutMsg(cipherBuf);

   RETVALUE(ROK);

} /* maEncProtPayload */

/*
*
*       Fun:   maProcSecOprReq    
*
*       Desc:  This function process the secure operation request
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maProcSecOprReq 
(
MaSap      *s,          /* MAP SAP pointer */
MaDlgCp    *dlgCp,      /* Dialogue Control Point */
StComps    *cmpEv,      /* Component Event */
MaCmpCp    *cmpCp,      /* component control point pointer */
SpId       spId,        /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId      /* Invoke Id */
)
#else
PUBLIC S16 maProcSecOprReq (s,dlgCp,cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId)
MaSap      *s;          /* MAP SAP pointer */
MaDlgCp    *dlgCp;      /* Dialogue Control Point */
StComps    *cmpEv;      /* Component Event */
MaCmpCp    *cmpCp;      /* component control point pointer */
SpId       spId;        /* service user id */
MaDlgId    suDlgId;     /* Service user dialogue Id */
MaDlgId    spDlgId;     /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
#endif
{
   LmaSecPl    protLevel;    /* protection level */
   MaOprType   oprType;      /* Operation type */
   S16         ret;
   U8          oprClass;     /* operation class */

   TRC2(maProcSecOprReq)

   if(cmpCp != (MaCmpCp *)NULLP)
   {
      oprType = cmpCp->oprCode;
      oprClass= cmpCp->oprClass;
   }
   else
   {
      oprType = cmpEv->stOpCode.string[0];
      oprClass = MAT_OPRCLASS4;
   }


   if (dlgCp->dsmState == MA_DLG_WAIT_USER_REQ)
   {
      if ((ret = maStoreReq(s,dlgCp, cmpEv,s->ctlp.mBuf)) != ROK)
      {
#ifndef ALIGN_64BIT

         MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                "maProcSecOprReq(pst, spId(%d),suDlgId(%ld),spDlgId(%ld),\
                invkId(%d),oprType(%d))failed, \
                unable to allocate stored cmp block, out of resource.\n",
                spId, suDlgId, spDlgId, invkId->octet, oprType));
         RETVALUE(RFAILED);

#else

         MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                "maProcSecOprReq(pst, spId(%d),suDlgId(%d),spDlgId(%d),\
                invkId(%d),oprType(%d))failed, \
                unable to allocate stored cmp block, out of resource.\n",
                spId, suDlgId, spDlgId, invkId->octet, oprType));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
      }
   }

   if (maIsSecOpr(dlgCp, oprType, &protLevel) == TRUE)
   {
      switch(protLevel)
      {
         case MAPSEC_LEVEL1: /* Integrity checksum for invoke */
         case MAPSEC_LEVEL2: /* Integrity for invoke & result */
         case MAPSEC_LEVEL3: /* integrity-invoke & result-encryption */
 
            /* call intergrity hook function */
            ret = maEncProtPayload(s, dlgCp, MA_ORIG_CMP_OPR, oprType, NULLD,
                                   MA_PROT_MODE_1);
            if (ret != ROK)
            {
               dlgCp->cmpId.cmpType = LMA_INVOKE_COMP;
               dlgCp->cmpId.cmpVal.oprCode = oprType;
               maSendAlrm(NEW,s->sapId, STMATSA, LMA_BAD_PLMN_PARAM, 
                          "maProcSecOprReq", LMA_EVENT_MAPSEC_INITIATOR,
                           LCM_CATEGORY_INTERFACE, LMA_CAUSE_PROT_FAIL);

#ifndef ALIGN_64BIT

               MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                      "maProcSecOprReq(pst, spId(%d),suDlgId(%ld),\
                       spDlgId(%ld), invkId(%d),oprType(%d)) \
                       failed, hook function failed. protection \
                       level (%d)\n", spId, suDlgId, spDlgId, invkId->octet,
                       oprType, protLevel));
               RETVALUE(RFAILED);

#else
 
               MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                      "maProcSecOprReq(pst, spId(%d),suDlgId(%d),\
                       spDlgId(%d), invkId(%d),oprType(%d)) \
                       failed, hook function failed. protection \
                       level (%d)\n", spId, suDlgId, spDlgId, invkId->octet,
                       oprType, protLevel));
               RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
            }

            break;

         case MAPSEC_LEVEL4: /* invoke-encryption and integrity-result*/
         case MAPSEC_LEVEL5: /* invoke and resut encrypted */
         case MAPSEC_LEVEL6: /* invoke encrypted */

            /* call confidentiality hook function, 
             * return ciphertext in cipherBuf */
            ret = maEncProtPayload(s, dlgCp, MA_ORIG_CMP_OPR, oprType, NULLD,
                                   MA_PROT_MODE_2);
            if (ret != ROK)
            {
               dlgCp->cmpId.cmpType = LMA_INVOKE_COMP;
               dlgCp->cmpId.cmpVal.oprCode = oprType;
               maSendAlrm(NEW,s->sapId, STMATSA, LMA_BAD_PLMN_PARAM, 
                          "maProcSecOprReq", LMA_EVENT_MAPSEC_INITIATOR,
                           LCM_CATEGORY_INTERFACE, LMA_CAUSE_PROT_FAIL);

#ifndef ALIGN_64BIT

               MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                      "maProcSecOprReq(pst, spId(%d),suDlgId(%ld),\
                       spDlgId(%ld), invkId(%d),oprType(%d)) \
                       failed, hook function failed. Protection level (%d)\n",
                       spId, suDlgId, spDlgId, invkId->octet, oprType, 
                       protLevel));
               RETVALUE(RFAILED);

#else
 
               MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                      "maProcSecOprReq(pst, spId(%d),suDlgId(%d),\
                       spDlgId(%d), invkId(%d),oprType(%d)) \
                       failed, hook function failed. Protection level (%d)\n",
                       spId, suDlgId, spDlgId, invkId->octet, oprType, 
                       protLevel));
               RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
            }

            break;
        default:
#if (ERRCLASS & ERRCLS_DEBUG)
            MALOGERROR(ERRCLS_DEBUG, EMA259, (ErrVal)protLevel, \
                       "maProcSecOprReq() Failed");
#endif
            RETVALUE(RFAILED);
            break;
      }
   }
   else
   {
      /* protection mode 0 is used */
      ret = maEncProtPayload(s, dlgCp, MA_ORIG_CMP_OPR, oprType, NULLD,
                             MA_PROT_MODE_0);
      if (ret != ROK)
      {
#ifndef ALIGN_64BIT

         MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                "maProcSecOprReq(pst, spId(%d),suDlgId(%ld),\
                 spDlgId(%ld), invkId(%d),oprType(%d)) \
                 failed, copy cipertext failed. \
                 protection level (%d)\n", spId, suDlgId, spDlgId, 
                 invkId->octet, oprType, protLevel));
         RETVALUE(RFAILED);

#else

         MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                "maProcSecOprReq(pst, spId(%d),suDlgId(%d),\
                 spDlgId(%d), invkId(%d),oprType(%d)) \
                 failed, copy cipertext failed. \
                 protection level (%d)\n", spId, suDlgId, spDlgId, 
                 invkId->octet, oprType, protLevel));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
      }
   }

   switch(oprClass)
   {
      case MAT_OPRCLASS1:
         cmpEv->stOpCode.string[0] = MAT_SEC_TRANS_CLASS1;  
         break;
      case MAT_OPRCLASS2:
         cmpEv->stOpCode.string[0] = MAT_SEC_TRANS_CLASS2;  
         break;
      case MAT_OPRCLASS3:
         cmpEv->stOpCode.string[0] = MAT_SEC_TRANS_CLASS3;  
         break;
      case MAT_OPRCLASS4:
         cmpEv->stOpCode.string[0] = MAT_SEC_TRANS_CLASS4;  
         break;
   }

    /* Update the Stat. */
   maUpdatSecTxSts(s,oprType, MAT_SS_REQ);

   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

   RETVALUE(ROK);
} /* maProcSecOprReq */

/*
*
*       Fun:   maProcSecOprRsp    
*
*       Desc:  This function process the secure operation response
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maProcSecOprRsp 
(
MaSap      *s,          /* MAP SAP pointer */
MaDlgCp    *dlgCp,      /* Dialogue Control Point */
StComps    *cmpEv,      /* Component Event */
MaCmpCp    *cmpCp,      /* component control point pointer */
SpId       spId,        /* service user id */
MaDlgId    suDlgId,     /* Service user dialogue Id */
MaDlgId    spDlgId,     /* Service provider dialogue Id */
MaInvokeId *invkId      /* Invoke Id */
)
#else
PUBLIC S16 maProcSecOprRsp (s,dlgCp,cmpEv,cmpCp,spId,suDlgId,spDlgId,invkId)
MaSap      *s;          /* MAP SAP pointer */
MaDlgCp    *dlgCp;      /* Dialogue Control Point */
StComps    *cmpEv;      /* Component Event */
MaCmpCp    *cmpCp;      /* component control point pointer */
SpId       spId;        /* service user id */
MaDlgId    suDlgId;     /* Service user dialogue Id */
MaDlgId    spDlgId;     /* Service provider dialogue Id */
MaInvokeId *invkId;     /* Invoke Id */
#endif
{
   LmaSecPl    protLevel;    /* protection level */
   MaOprType   oprType;      /* Operation type */
   S16         ret;

   TRC2(maProcSecOprRsp)

   ret = ROK;
   oprType = cmpCp->oprCode;

   if (maIsSecOpr(dlgCp, oprType, &protLevel) == TRUE)
   {
      switch(protLevel)
      {
         case MAPSEC_LEVEL1:
         case MAPSEC_LEVEL6:
            /* Protection mode 0 is used */
            ret = maEncProtPayload(s, dlgCp, MA_ORIG_CMP_OPR, oprType, NULLD,
                                   MA_PROT_MODE_0);
            if(ret != ROK)
            {
#ifndef ALIGN_64BIT

               MADBGP(MA_DBGMASK_SEC_RESP, (maCb.maInit.prntBuf,
                      "maProcSecOprRsp(pst, spId(%d),suDlgId(%ld),\
                       spDlgId(%ld), invkId(%d),oprType(%d)) \
                       failed, copy security payload failed. protection \
                       level (%d)\n", spId, suDlgId, spDlgId, invkId->octet,\
                       oprType, protLevel));
               RETVALUE(RFAILED);

#else

               MADBGP(MA_DBGMASK_SEC_RESP, (maCb.maInit.prntBuf,
                      "maProcSecOprRsp(pst, spId(%d),suDlgId(%d),\
                       spDlgId(%d), invkId(%d),oprType(%d)) \
                       failed, copy security payload failed. protection \
                       level (%d)\n", spId, suDlgId, spDlgId, invkId->octet,\
                       oprType, protLevel));
               RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
            }

            break;
         case MAPSEC_LEVEL2:
         case MAPSEC_LEVEL4:

            /* call intergrity hook function */
            ret = maEncProtPayload(s, dlgCp, MA_ORIG_CMP_OPR, oprType, NULLD,
                                   MA_PROT_MODE_1);
            if (ret != ROK)
            {
               dlgCp->cmpId.cmpType = LMA_RESULT_COMP;
               dlgCp->cmpId.cmpVal.oprCode = oprType;
               maSendAlrm(NEW,s->sapId, STMATSA, LMA_BAD_PLMN_PARAM, 
                          "maProcSecOprRsp", LMA_EVENT_MAPSEC_RESPONDER,
                           LCM_CATEGORY_INTERFACE, LMA_CAUSE_PROT_FAIL);

#ifndef ALIGN_64BIT

               MADBGP(MA_DBGMASK_SEC_RESP, (maCb.maInit.prntBuf,
                      "maProcSecOprRsp(pst, spId(%d),suDlgId(%ld),\
                       spDlgId(%ld), invkId(%d),oprType(%d)) \
                       failed, hook function failed. protection \
                       level (%d)\n", spId, suDlgId, spDlgId, invkId->octet,\
                       oprType, protLevel));
               RETVALUE(RFAILED);

#else

               MADBGP(MA_DBGMASK_SEC_RESP, (maCb.maInit.prntBuf,
                      "maProcSecOprRsp(pst, spId(%d),suDlgId(%d),\
                       spDlgId(%d), invkId(%d),oprType(%d)) \
                       failed, hook function failed. protection \
                       level (%d)\n", spId, suDlgId, spDlgId, invkId->octet,\
                       oprType, protLevel));
               RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
            }

            break;

         case MAPSEC_LEVEL3: 
         case MAPSEC_LEVEL5: 

            /* call confidentiality hook function, 
             * return ciphertext in cipherBuf */
            ret = maEncProtPayload(s, dlgCp, MA_ORIG_CMP_OPR, oprType, NULLD,
                                   MA_PROT_MODE_2);
            if (ret != ROK)
            {
               dlgCp->cmpId.cmpType = LMA_RESULT_COMP;
               dlgCp->cmpId.cmpVal.oprCode = oprType;
               maSendAlrm(NEW,s->sapId, STMATSA, LMA_BAD_PLMN_PARAM, 
                          "maProcSecOprRsp", LMA_EVENT_MAPSEC_RESPONDER,
                          LCM_CATEGORY_INTERFACE, LMA_CAUSE_PROT_FAIL);

#ifndef ALIGN_64BIT

               MADBGP(MA_DBGMASK_SEC_RESP, (maCb.maInit.prntBuf,
                      "maProcSecOprRsp(pst, spId(%d),suDlgId(%ld),\
                       spDlgId(%ld), invkId(%d),oprType(%d)) \
                       failed, Hook  function failed. \
                       Protection level (%d)\n", spId, suDlgId, spDlgId, \
                       invkId->octet, oprType, protLevel));
               RETVALUE(RFAILED);

#else

               MADBGP(MA_DBGMASK_SEC_RESP, (maCb.maInit.prntBuf,
                      "maProcSecOprRsp(pst, spId(%d),suDlgId(%d),\
                       spDlgId(%d), invkId(%d),oprType(%d)) \
                       failed, Hook  function failed. \
                       Protection level (%d)\n", spId, suDlgId, spDlgId, \
                       invkId->octet, oprType, protLevel));
               RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
            }

            break;

         default:
#if (ERRCLASS & ERRCLS_DEBUG)
            MALOGERROR(ERRCLS_DEBUG, EMA260, (ErrVal)protLevel, \
                       "maProcSecOprRsp() Failed");
#endif
           RETVALUE(RFAILED);
           break;
      }
   }
   else
   {
      /* Protection mode 0 is used */
      ret = maEncProtPayload(s, dlgCp, MA_ORIG_CMP_OPR, oprType, NULLD,
                             MA_PROT_MODE_0);
      if(ret != ROK)
      {
#ifndef ALIGN_64BIT

         MADBGP(MA_DBGMASK_SEC_RESP, (maCb.maInit.prntBuf,
                "maProcSecOprRsp(pst, spId(%d),suDlgId(%ld),\
                spDlgId(%ld), invkId(%d),oprType(%d)) \
                failed, copy security payload failed. protection \
                level (%d)\n", spId, suDlgId, spDlgId, invkId->octet,\
                oprType, protLevel));
         RETVALUE(RFAILED);

#else

         MADBGP(MA_DBGMASK_SEC_RESP, (maCb.maInit.prntBuf,
                "maProcSecOprRsp(pst, spId(%d),suDlgId(%d),\
                spDlgId(%d), invkId(%d),oprType(%d)) \
                failed, copy security payload failed. protection \
                level (%d)\n", spId, suDlgId, spDlgId, invkId->octet,\
                oprType, protLevel));
         RETVALUE(RFAILED);

#endif /* ALIGN_64BIT */
     }
   }

   cmpEv->stOpCode.len = 1;  
   switch(cmpCp->oprClass)
   {
      case MAT_OPRCLASS1:
         cmpEv->stOpCode.string[0] = MAT_SEC_TRANS_CLASS1;  
         break;
      case MAT_OPRCLASS2:
         cmpEv->stOpCode.string[0] = MAT_SEC_TRANS_CLASS2;  
         break;
      case MAT_OPRCLASS3:
         cmpEv->stOpCode.string[0] = MAT_SEC_TRANS_CLASS3;  
         break;
      case MAT_OPRCLASS4:
         cmpEv->stOpCode.string[0] = MAT_SEC_TRANS_CLASS4;  
         break;
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         MALOGERROR(ERRCLS_DEBUG, EMA261, (ErrVal)cmpCp->oprClass, \
                    "maProcSecOprRsp() Failed");
#endif
        RETVALUE(RFAILED);
        break;
   }

   /* Update the Stat. */
   maUpdatSecTxSts(s,oprType, MAT_SS_RSP);

   if (s->trc == TRUE)
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);

   RETVALUE(ROK);
} /* maProcSecOprRsp */

/*
*
*       Fun:   maProcSecOprErr    
*
*       Desc:  This function process the secure return error
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maProcSecOprErr 
(
MaSap      *s,          /* MAP SAP pointer */
MaDlgCp    *dlgCp,      /* Dialogue Control Point */
StComps    *cmpEv,      /* Component Event */
MaCmpCp    *cmpCp,      /* component control point pointer */
Buffer     *mBuf
)
#else
PUBLIC S16 maProcSecOprErr (s,dlgCp,cmpEv,cmpCp,mBuf)
MaSap      *s;          /* MAP SAP pointer */
MaDlgCp    *dlgCp;      /* Dialogue Control Point */
StComps    *cmpEv;      /* Component Event */
MaCmpCp    *cmpCp;      /* component control point pointer */
Buffer     *mBuf;
#endif
{
   LmaSecPl    protLevel;    /* protection level */
   MaOprType   oprType;      /* Operation type */
   U8          errCode;
   S16         ret;

   TRC2(maProcSecOprErr)

   ret = ROK;
   oprType = cmpCp->oprCode;
   errCode = cmpEv->stErrorCode.string[0];

   if (maIsSecOpr(dlgCp, oprType, &protLevel) == TRUE)
   {
      /* Now, protection mode 0 is used for all the errors of secure 
       * transport component */

      switch(protLevel)
      {
         case MAPSEC_LEVEL1:
         case MAPSEC_LEVEL2:
         case MAPSEC_LEVEL3:
         case MAPSEC_LEVEL4:
         case MAPSEC_LEVEL5: 
         case MAPSEC_LEVEL6: 
            /* Protection mode 0 is used */
            ret = maEncProtPayload(s, dlgCp, MA_ORIG_CMP_ERR, NULLD, errCode,
                                   MA_PROT_MODE_0);
            if (ret != ROK)
            {
               MADBGP(MA_DBGMASK_SEC_RESP, (maCb.maInit.prntBuf,
                      "maProcSecOprErr(pst, error code(%d))failed, \
                      copy security payload failed.\n",\
                      errCode ));
               RETVALUE(RFAILED);
            }
 
            break;

         default:
#if (ERRCLASS & ERRCLS_DEBUG)
            MALOGERROR(ERRCLS_DEBUG, EMA262, (ErrVal)protLevel, \
                       "maProcSecOprErr() Failed");
#endif
           RETVALUE(RFAILED);
           break;
      }
   }
   else
   {
      /* Protection mode 0 is used */
      ret = maEncProtPayload(s, dlgCp, MA_ORIG_CMP_ERR, NULLD, errCode,
                             MA_PROT_MODE_0);
      if (ret != ROK)
      {
         MADBGP(MA_DBGMASK_SEC_RESP, (maCb.maInit.prntBuf,
                "maProcSecOprErr(pst, error code(%d))failed, \
                copy security payload failed.\n", errCode ));
         RETVALUE(RFAILED);
      }
   }

   mBuf = s->ctlp.mBuf;
   /* For the Return Error component we should not
    * fill the operation code
    */
   cmpEv->stOpCode.len = 0;
   cmpEv->stErrorCode.len = 1;
   cmpEv->stErrorCode.string[0] = MAT_SEC_TRANS_ERROR;

   maUpdatSecErrSts(s,cmpCp->oprCode,MAT_SS_REQ);

   if (s->trc == TRUE)
   {
      maGenTrc(s, LMA_CMP_TXED, s->ctlp.mBuf);
   }

   RETVALUE(ROK);
} /* maProcSecOprErr */


/*
*
*       Fun:   maEncSecTransTkns    
*
*       Desc:  This function encodes secure transport component
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maEncSecTransTkns 
(
MaSap   *s,
Buffer  *hdBuf,
Buffer  *cpBuf,
Buffer  **dstBuf
)
#else
PUBLIC S16 maEncSecTransTkns (s, hdBuf, cpBuf, dstBuf)
MaSap   *s;
Buffer  *hdBuf;
Buffer  *cpBuf;
Buffer  **dstBuf;
#endif
{
   S16         ret;
   MsgLen      len;
   MsgLen      msglen;
   U8          pkArray[20];

   TRC2(maEncSecTransTkns)

   len = 0;
   msglen = 0;
   ret = SCpyMsgMsg(cpBuf, s->maPstST.region, s->maPstST.pool, 
                    dstBuf);
   if (ret != ROK)
   {
      MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
             "maEncSecTransTkns() failed, copy Msg failed.\n"));
      RETVALUE(RFAILED);
   }

   /* write a size check for 1..3438 for the protected payload here */
   /* length encoding can not be this simple , put the proper code here */
   (Void)SFndLenMsg(cpBuf, &msglen);
   if(msglen > 0)
   {
      MA_ENCODE_LEN(msglen,len)
      /* encode the tag for protected payload */
      pkArray[len++] = MA_TAG_OCTSTR;
      ret = SAddPreMsgMult(pkArray, (MsgLen)len, *dstBuf);
      if (ret != ROK)
      {
         MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
                "maEncSecTransTkns() failed, TAG and len of ciphertext.\n"));
         RETVALUE(RFAILED);
      }
   } /* msglen > 0 */
   /* Concatenate security header and protected payload */

   ret = SCatMsg(*dstBuf, hdBuf, M2M1);
   if (ret != ROK)
   {
      MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
             "maEncSecTransTkns() failed, adding security header.\n"));
      RETVALUE(RFAILED);
   }
   SFndLenMsg(*dstBuf,&msglen);
   len = 0;
#ifdef MA_ASN_NO_INDEF_LEN
   /* encode the length */
   MA_ENCODE_LEN(msglen,len)
   /* encode the tag for protected payload */
   pkArray[len++] = MA_TAG_SEQ;

   ret = SAddPreMsgMult(pkArray, (MsgLen)len, *dstBuf);
   if (ret != ROK)
   {
      MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
             "maEncSecTransTkns() failed, TAG and len of security header.\n"));
      RETVALUE(RFAILED);
   }
#else /* MA_ASN_NO_INDEF_LEN */
   pkArray[len++] = (Data)0x80; 
   pkArray[len++] = MA_TAG_SEQ;
   ret = SAddPreMsgMult(pkArray, (MsgLen)len, *dstBuf);
   if (ret != ROK)
   {
      MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
             "maEncSecTransTkns() failed, TAG and len of security header.\n"));
      RETVALUE(RFAILED);
   }
   len = 0;
   pkArray[len++] = (Data)0x0; 
   pkArray[len++] = (Data)0x0; 
   ret = SAddPstMsgMult(pkArray, (MsgLen)len, *dstBuf);
   if (ret != ROK)
   {
      MADBGP(MA_DBGMASK_SEC_INIT, (maCb.maInit.prntBuf,
             "maEncSecTransTkns() failed, TAG and len of security header.\n"));
      RETVALUE(RFAILED);
   }
#endif /* MA_ASN_NO_INDEF_LEN */

   RETVALUE(ROK);
} /* maEncSecTransTkns */

/*
*
*       Fun:   maDecSecTransTkns    
*
*       Desc:  This function decodes secure transport component
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maDecSecTransTkns 
(
MaSap       *s,
Buffer      *mBuf,      /* Message buffer */
MaSecHeader *secHdr,    /* security header src structure */
Buffer      **cpBuf     /* protected payload buffer */  
)
#else
PUBLIC S16 maDecSecTransTkns (s, mBuf, secHdr, cpBuf)
MaSap       *s;
Buffer      *mBuf;      /* Message buffer */
MaSecHeader *secHdr;    /* security header src structure */
Buffer      **cpBuf;
#endif
{
   S16         ret;
   Bool        eocFlg;
   Data        tag, data;
   MsgLen      len;

   TRC2(maDecSecTransTkns)

   eocFlg = FALSE;
   s->ctlp.errCode = MAT_MISTYPE_PARAM;

   /* remove tag for security header */
   (Void)SRemPreMsg(&tag, mBuf);
   if (tag != MA_TAG_SEQ)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA263, (ErrVal)tag, \
                 "maDecSecTransTkns() failed, Bad protected payload tag");
#endif
      RETVALUE(RFAILED);
   }

   if ((ret = maRemLen(mBuf, &eocFlg)) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA264, (ErrVal)ret, \
                 "maDecSecTransTkns() failed, Bad protected payload length");
#endif
      RETVALUE(RFAILED);
   }

   /* remove 2 bytes of EOC flag from the end of message 
    * if indeterminate form of length used */
   if (eocFlg == TRUE)
   {
      (Void)SRemPstMsg(&data, mBuf);
      (Void)SRemPstMsg(&data, mBuf);
   }

   if ((ret = maDecSecHeader(mBuf, secHdr,&s->ctlp.errCode)) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA265, (ErrVal)ret, \
                 "maDecSecTransTkns() failed, Bad security header");
#endif
      RETVALUE(RFAILED);
   }

   SFndLenMsg(mBuf,&len);
   if(len > 0)
   {
   /* remove tag for protected payload */
   (Void)SRemPreMsg(&tag, mBuf);
   if (tag != MA_TAG_OCTSTR)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA266, (ErrVal)tag, \
                 "maDecSecTransTkns() failed, Bad protected payload tag");
#endif
      RETVALUE(RFAILED);
   }

   if ((ret = maRemLen(mBuf, &eocFlg)) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA267, (ErrVal)ret, \
                 "maDecSecTransTkns() failed, Bad protected payload length");
#endif
      RETVALUE(RFAILED);
   }

   /* remove 2 bytes of EOC flag from the end of message 
    * if indeterminate form of length used */
   if (eocFlg == TRUE)
   {
      (Void)SRemPstMsg(&data, mBuf);
      (Void)SRemPstMsg(&data, mBuf);
   }
   } /* len > 0 */
   ret = SCpyMsgMsg(mBuf, s->maPstST.region, s->maPstST.pool, cpBuf);
   if (ret != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPrntMsg(mBuf,0,0);
      MALOGERROR(ERRCLS_DEBUG, EMA268, (ErrVal)ret, \
                 "maDecSecTransTkns() failed, Bad security header");
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* maDecSecTransTkns */

/*
*
*       Fun:   maUpdatSecTxSts    
*
*       Desc:  This function updates the Statistics for service specific 
*              requests and responses transmitted within secure dialoguex.
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void maUpdatSecTxSts 
(
MaSap  *s,              /* MAP Sap */
U8     oprType,         /* Operation to be encoded */
U8     type             /* Request or Response */
)
#else
PUBLIC Void maUpdatSecTxSts (s,oprType, type)
MaSap  *s;              /* MAP Sap */
U8     oprType;         /* Operation to be encoded */
U8     type;            /* Request or Response */
#endif
{
  TRC2(maUpdatSecTxSts)
  switch (oprType)
  {
#if (MAP_VLR || MAP_HLR)
   case MAT_REGSS:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.regSSReqTx++;
     }
     else
     {
       s->secSts.secSapSts.regSSRspTx++;
     }
     break;
   case MAT_ERASESS:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.eraseSSReqTx++;

     }
     else
     {
       s->secSts.secSapSts.eraseSSRspTx++;
     }
     break;
   case MAT_ACTVSS:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.actvSSReqTx++;

     }
     else
     {
       s->secSts.secSapSts.actvSSRspTx++;
     }
     break;
   case MAT_DACTVSS:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.dactvSSReqTx++;
     }
     else
     {
       s->secSts.secSapSts.dactvSSRspTx++;
     }
     break;
   case MAT_INTERSS:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.interSSReqTx++;
     }
     else
     {
       s->secSts.secSapSts.interSSRspTx++;
     }
     break;
   case MAT_REGPASSWD:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.regPasswdReqTx++;
     }
     else
     {
       s->secSts.secSapSts.regPasswdRspTx++;
     }
     break;
   case MAT_GETPASSWD:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.getPasswdReqTx++;
     }
     else
     {
       s->secSts.secSapSts.getPasswdRspTx++;
     }
     break;
   case MAT_PROCUSSREQ:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.procUSSReqTx++;
     }
     else
     {
       s->secSts.secSapSts.procUSSRspTx++;
     }
     break;
   case MAT_PROCUSSDATA:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.procUSSDatReqTx++;
     }
     else
     {
       s->secSts.secSapSts.procUSSDatRspTx++;
     }
     break;
   case MAT_USSREQ:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.ussReqTx++;
     }
     else
     {
       s->secSts.secSapSts.ussRspTx++;
     }
     break;
   case MAT_USSNOTIFY:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.ussNotReqTx++;
     }
     else
     {
       s->secSts.secSapSts.ussNotRspTx++;
     }
     break;
#endif /* VLR || HLR */
 
#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_SMRDY:
     if (type == MA_SS_REQ)
     {
        s->secSts.secSapSts.smRdyReqTx++;
     }
     else
     {
        s->secSts.secSapSts.smRdyRspTx++;
     }
     break;
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */


#if MAP_MSC
   case MAT_DET_IMSI:
     s->secSts.secSapSts.detIMSIReqTx++;
     break;
#endif   /* MSC */
 
#if (MAP_MSC || MAP_VLR || MAP_GSN)
   case MAT_CHKIMEI:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.chkIMEIReqTx++;
     }
     else
     {
       s->secSts.secSapSts.chkIMEIRspTx++;
     }
     break;
#endif /* MAP_MSC || MAP_VLR || MAP_GSN */
 
#if MAP_MSC
   case MAT_TRACESUBSACTV:
     s->secSts.secSapSts.trSubReqTx++;
     break;
#endif   /* MSC */

#if (MAP_MSC || MAP_HLR)
   case MAT_ROUTINFO:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.routInfoReqTx++;
     }
     else
     {
       s->secSts.secSapSts.routInfoRspTx++;
     }
     break;
#endif   /* MAP_MSC || MAP_HLR */
 
#if (MAP_MSC || MAP_HLR)
   case MAT_ROUTINFOSM:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.routInfoSMReqTx++;
     }
     else
     {
       s->secSts.secSapSts.routInfoSMRspTx++;
     }
     break;
   case MAT_SMDEL:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.smDelReqTx++;
     }
     else
     {
       s->secSts.secSapSts.smDelRspTx++;
     }
     break;
   case MAT_ALRTSC:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.alrtSCReqTx++;
     }
     else
     {
       s->secSts.secSapSts.alrtSCRspTx++;
     }
     break;
   case MAT_ALRTSCWRSLT:
     s->secSts.secSapSts.alrtSCWRsltReqTx++;
     break;
   case MAT_INFSC:
     s->secSts.secSapSts.infSCReqTx++;
     break;
#endif  /* MSC || HLR */

#if (MAP_VLR || MAP_HLR)
   case MAT_UPLOC:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.upLocReqTx++;
     }
     else
     {
       s->secSts.secSapSts.upLocRspTx++;
     }
     break;
#endif /* MAP_VLR || MAP_HLR */
 
#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_CANCELLOC:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.canLocReqTx++;
     }
     else
     {
       s->secSts.secSapSts.canLocRspTx++;
     }
     break;
   case MAT_PURGE:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.purgMsReqTx++;
     }
     else
     {
       s->secSts.secSapSts.purgMsRspTx++;
     }
     break;
     
   case MAT_AUTHINFO:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.authInfReqTx++;
     }
     else
     {
       s->secSts.secSapSts.authInfRspTx++;
     }
     break;
   case MAT_INSSUBSDATA:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.insSubReqTx++;
     }
     else
     {
       s->secSts.secSapSts.insSubRspTx++;
     }
     break;
   case MAT_DELSUBSDATA:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.delSubReqTx++;
     }
     else
     {
       s->secSts.secSapSts.delSubRspTx++;
     }
     break;

   case MAT_RESET:
     s->secSts.secSapSts.resetReqTx++;
     break;
   case MAT_SNDPARAM: 
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.sndParamReqTx++;
     }
     else
     {
       s->secSts.secSapSts.sndParamRspTx++;
     }
     break;
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */
 
#if (MAP_VLR || MAP_HLR)

   case MAT_RESTOREDATA:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.restoreReqTx++;
     }
     else
     {
       s->secSts.secSapSts.restoreRspTx++;
     }
     break;
#endif /* MAP_VLR || MAP_HLR */
 
#if (MAP_VLR || MAP_HLR)
   case MAT_FWDCHKSSIND:
     s->secSts.secSapSts.fwdChkSSIndReqTx++;
     break;
#endif /* VLR || HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_ACTVTRACE:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.actvTrReqTx++;
     }
     else
     {
       s->secSts.secSapSts.actvTrRspTx++;
     }
     break;
   case MAT_DACTVTRACE:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.dactvTrReqTx++;
     }
     else
     {
       s->secSts.secSapSts.dactvTrRspTx++;
     }
     break;
#if MAP_REL99

  /* Note MM event */
  case MAT_NOTE_MMEVT:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.notMmEvReqTx++;   
     }
     else
     {
        s->secSts.secSapSts.notMmEvRspTx++;   
     }
     break;

#endif /* MAP_REL99 */
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */
 
#if (MAP_VLR || MAP_HLR)

   case MAT_SNDIMSI:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.sndIMSIReqTx++;
     }
     else
     {
       s->secSts.secSapSts.sndIMSIRspTx++;
     }
     break;

   case MAT_PROVROAMNMB:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.provRoamNmbReqTx++;
     }
     else
     {
       s->secSts.secSapSts.provRoamNmbRspTx++;
     }
     break;

   case MAT_NOTSUBPRES:
     s->secSts.secSapSts.notSubPresReqTx++;
     break;

   case MAT_BEGIN_SUBS_ACTV:
     s->secSts.secSapSts.bgnSubActvReqTx++;
     break;

   case MAT_SETRPTSTATE:
      if(type == MAT_SS_REQ)
      {
         s->secSts.secSapSts.setRptStateReqTx++;   
      }
      else
      {
         s->secSts.secSapSts.setRptStateRspTx++;   
      }
      break;

   case MAT_RMTUSRFREE:
      if(type == MAT_SS_REQ)
      {
         s->secSts.secSapSts.rmtUsrFreeReqTx++;  
      }
      else
      {
         s->secSts.secSapSts.rmtUsrFreeRspTx++;  
      }
      break;

   case MAT_STARPT:
     if (type == MA_SS_REQ)
     {
        s->secSts.secSapSts.staRptReqTx++;    
     }
     else
     {
        s->secSts.secSapSts.staRptRspTx++;    
     }
     break;

#endif  /* (VLR || HLR) */


#if (MAP_VLR || MAP_HLR)
   case MAT_REGCCENT:
   if(type == MAT_SS_REQ)
   {
      s->secSts.secSapSts.regCcEntReqTx++;    
   }
   else
   {
      s->secSts.secSapSts.regCcEntRspTx++;    
   }
   break;

   case MAT_ERASECCENT:
   if(type == MAT_SS_REQ)
   {
      s->secSts.secSapSts.eraseCcEntReqTx++;  
   }
   else
   {
      s->secSts.secSapSts.eraseCcEntRspTx++;  
   }
   break;
#endif /* VLR || HLR */

#if MAP_MSC
   case MAT_PRE_HO:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.preHoReqTx++;
     }
     else
     {
       s->secSts.secSapSts.preHoRspTx++;
     }
     break;
   case MAT_PER_HO:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.perHoReqTx++;
     }
     else
     {
       s->secSts.secSapSts.perHoRspTx++;
     }
     break;
   case MAT_SNDENDSIG:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.sndEndSigReqTx++;
     }
     else
     {
        s->secSts.secSapSts.sndEndSigRspTx++;
     }
     break;
   case MAT_PROCACCSIG:
     s->secSts.secSapSts.procAccSigReqTx++;
     break;
   case MAT_FWDACCSIG:
     s->secSts.secSapSts.fwdAccSigReqTx++;
     break;
   case MAT_PRE_SUBSHO:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.preSubHoReqTx++;
     }
     else
     {
       s->secSts.secSapSts.preSubHoRspTx++;
     }
     break;
   case MAT_PER_SUBSHO:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.perSubHoReqTx++;
     }
     else
     {
       s->secSts.secSapSts.perSubHoRspTx++;
     }
     break;
   case MAT_NOTEINTERHO:
     s->secSts.secSapSts.notInterHoReqTx++;
     break;
#endif /* MAP_MSC */
 
#if (MAP_MSC || MAP_GSN)
   case MAT_FWDSM:
   if(type == MAT_SS_REQ)
   {
      s->secSts.secSapSts. fwdSMReqTx++;      
   }
   else
   {
      s->secSts.secSapSts. fwdSMRspTx++;      
   }
     break;

   case MAT_MT_FWDSM:
   if(type == MAT_SS_REQ)
   {
      s->secSts.secSapSts. mtFwdSMReqTx++;    
   }
   else
   {
      s->secSts.secSapSts. mtFwdSMRspTx++;    
   }
   break;
#endif /* MAP_MSC || MAP_GSN */
 
#if MAP_MSC
   case MAT_RESCALLHANDL:
   if(type == MAT_SS_REQ)
   {
      s->secSts.secSapSts. resCallHandlReqTx++;   
   }
   else
   {
      s->secSts.secSapSts. resCallHandlRspTx++;   
   }
   break;

   case MAT_PREP_GRPCALL:
   if(type == MAT_SS_REQ)
   {
      s->secSts.secSapSts.prepGrpCallReqTx++; 
   }
   else
   {
      s->secSts.secSapSts.prepGrpCallRspTx++; 
   }
   break;

   case MAT_PRO_GRPCALLSIG:
   s->secSts.secSapSts.proGrpCallSigReqTx++;  
   break;

   case MAT_FWD_GRPCALLSIG:
   s->secSts.secSapSts.fwdGrpCallSigReqTx++;  
   break;

   case MAT_SND_GRPCALLENDSIG:
   if(type == MAT_SS_REQ)
   {
      s->secSts.secSapSts.sndGrpCallEndSigReqTx++; 
   }
   else
   {
      s->secSts.secSapSts.sndGrpCallEndSigRspTx++; 
   }
   break;

   case MAT_PROV_SIWFS_NMB:
   if(type == MAT_SS_REQ)
   {
      s->secSts.secSapSts.provSiwfsNmbReqTx++;  
   }
   else
   {
      s->secSts.secSapSts.provSiwfsNmbRspTx++;  
   }
   break;

   case MAT_SIWFS_SIGMOD:
   if(type == MAT_SS_REQ)
   {
      s->secSts.secSapSts.siwfsSigModReqTx++;   
   }
   else
   {
      s->secSts.secSapSts.siwfsSigModRspTx++;   
   }
   break;

#endif  /* MSC */

#if MAP_VLR
  /* Send Identification Request */
   case MAT_SNDID:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.sndIdReqTx++;
     }
     else
     {
       s->secSts.secSapSts.sndIdRspTx++;
     }
     break;
#endif  /* MAP_VLR */

#if (MAP_HLR || MAP_MLC)
   case MAT_ANY_INTER:
   if(type == MAT_SS_REQ)
   {
      s->secSts.secSapSts.anyInterReqTx++;    
   }
   else
   {
      s->secSts.secSapSts.anyInterRspTx++;     
   }
   break;

#endif /* MAP_HLR || MAP_MLC */

#if (MAP_MSC || MAP_HLR)
   case MAT_SSINV_NOTIFY:
     if (type == MA_SS_REQ)
     {
        s->secSts.secSapSts.ssInvNotReqTx++;    
     }
     else
     {
        s->secSts.secSapSts.ssInvNotRspTx++;    
     }
     break;

#if MAP_REL99

  case MAT_IST_ALERT:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.istAlrtReqTx++;     
     }
     else
     {
        s->secSts.secSapSts.istAlrtRspTx++;  
     }
     break;
  case MAT_IST_COMMAND:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.istCmdReqTx++;    
     }
     else
     {
        s->secSts.secSapSts.istCmdRspTx++;    
     }
     break;

#endif /* MAP_REL99 */

#endif 

#if MAP_MSC
#if MAP_REL6
       
  case MAT_REL_RES:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.relResReqTx++;    
     }
     else
     {
        s->secSts.secSapSts.relResRspTx++;    
     }
     break;

#endif /* MAP_REL6 */
#endif /* MAP_MSC */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_PROVSUBSINFO:
   if(type == MAT_SS_REQ)
   {
      s->secSts.secSapSts.provSubsInfoReqTx++;     
   }
   else
   {
      s->secSts.secSapSts.provSubsInfoRspTx++;     
   }
   break;
#endif /* MAP_VLR || MAP_HLR */

#if MAP_REL99

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_AUTHFAILRPT:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.authFailRptReqTx++;
     }
     else
     {
       s->secSts.secSapSts.authFailRptRspTx++;
     }

     break;
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#endif /* MAP_REL99 */

#if (MAP_HLR || MAP_GSN)

   case MAT_GPRS_UPLOC:
   if(type == MAT_SS_REQ)
   {
      s->secSts.secSapSts.gprsUpLocReqTx++;     
   }
   else
   {
      s->secSts.secSapSts.gprsUpLocRspTx++;     
   }
   break;
   case MAT_GPRS_ROUTINFO:
   if(type == MAT_SS_REQ)
   {
      s->secSts.secSapSts.gprsRoutInfoReqTx++;  
   }
   else
   {
      s->secSts.secSapSts.gprsRoutInfoRspTx++;
   }
   break;
   case MAT_FAILRPT:
      if (type == MA_SS_REQ)
      {
         s->secSts.secSapSts.failRptReqTx++;     
      }
      else
      {
         s->secSts.secSapSts.failRptRspTx++;     
      }
      break;
   case MAT_GPRS_NOTEMSPRES:
     if (type == MA_SS_REQ)
     {
        s->secSts.secSapSts.gprsNoteMsPresReqTx++;     
     }
     else
     {
        s->secSts.secSapSts.gprsNoteMsPresRspTx++;     
     }
     break;
   
#endif

#if (MAP_REL98 || MAP_REL99)

#if (MAP_HLR || MAP_MLC)
   case MAT_SENDROUTINFOFORLCS:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.lcsSndRoutInfoReqTx++;  
     }
     else
     {
        s->secSts.secSapSts.lcsSndRoutInfoRspTx++;  
     }

     break;
#endif /* MAP_HLR || MAP_MLC */

#endif /* MAP_REL98 || MAP_REL99 */

#if (MAP_REL98 || MAP_REL99)

#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL4 && MAP_GSN))
   case MAT_PROVSUBSLOC:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.provSubsLocReqTx++;  
     }
     else
     {
        s->secSts.secSapSts.provSubsLocRspTx++;  
     }

     break;
   case MAT_SUBSLOCRPT:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.subsLocReqTx++;  
     }
     else
     {
        s->secSts.secSapSts.subsLocRspTx++;  
     }

     break;
#endif
#endif

#if MAP_HLR
   case MAT_ANY_SUBSDATA_INTER:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.anySubsInterReqTx++;  
     }
     else
     {
        s->secSts.secSapSts.anySubsInterRspTx++;  
     }

     break;
   case MAT_ANY_MOD:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.anyModReqTx++;  
     }
     else
     {
        s->secSts.secSapSts.anyModRspTx++;
     }

     break;
   case MAT_NOTE_SUBSDATA_MOD:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.notSubsModReqTx++; 
     }
     else
     {
        s->secSts.secSapSts.notSubsModRspTx++; 
     }

     break;
#endif /* MAP_HLR */

#endif /* (MAP_REL98 || MAP_REL99) */

   default:
#if (ERRCLASS & ERRCLS_DEBUG)
      MALOGERROR(ERRCLS_DEBUG, EMA269, (ErrVal)oprType, "maUpdatSecTxSts () Failed");
#endif
     break;
  }
} /* maUpdatSecTxSts */


/*
*
*       Fun:   maUpdatSecRxSts    
*
*       Desc:  This function updates the Statistics for service specific 
               requests and responses received within a secure dialogue.
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void maUpdatSecRxSts 
(
MaSap  *s,              /* MAP Sap */
U8     oprType,         /* Operation to be encoded */
U8     type             /* Request or Response */
)
#else
PUBLIC Void maUpdatSecRxSts (s,oprType, type)
MaSap  *s;              /* MAP Sap */
U8     oprType;         /* Operation to be encoded */
U8     type;            /* Request or Response */
#endif
{
  TRC2(maUpdatSecRxSts)
  switch (oprType)
  {
#if (MAP_VLR || MAP_HLR)
   case MAT_REGSS:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.regSSReqRx++;
     }
     else
     {
       s->secSts.secSapSts.regSSRspRx++;
     }
     break;
   case MAT_ERASESS:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.eraseSSReqRx++;

     }
     else
     {
       s->secSts.secSapSts.eraseSSRspRx++;
     }
     break;
   case MAT_ACTVSS:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.actvSSReqRx++;

     }
     else
     {
       s->secSts.secSapSts.actvSSRspRx++;
     }
     break;
   case MAT_DACTVSS:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.dactvSSReqRx++;
     }
     else
     {
       s->secSts.secSapSts.dactvSSRspRx++;
     }
     break;
   case MAT_INTERSS:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.interSSReqRx++;
     }
     else
     {
       s->secSts.secSapSts.interSSRspRx++;
     }
     break;
   case MAT_REGPASSWD:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.regPasswdReqRx++;
     }
     else
     {
       s->secSts.secSapSts.regPasswdRspRx++;
     }
     break;
   case MAT_GETPASSWD:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.getPasswdReqRx++;
     }
     else
     {
       s->secSts.secSapSts.getPasswdRspRx++;
     }
     break;
   case MAT_PROCUSSREQ:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.procUSSReqRx++;
     }
     else
     {
       s->secSts.secSapSts.procUSSRspRx++;
     }
     break;
   case MAT_PROCUSSDATA:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.procUSSDatReqRx++;
     }
     else
     {
       s->secSts.secSapSts.procUSSDatRspRx++;
     }
     break;
   case MAT_USSREQ:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.ussReqRx++;
     }
     else
     {
       s->secSts.secSapSts.ussRspRx++;
     }
     break;
   case MAT_USSNOTIFY:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.ussNotReqRx++;
     }
     else
     {
       s->secSts.secSapSts.ussNotRspRx++;
     }
     break;
#endif /* VLR || HLR */

#if (MAP_VLR || MAP_HLR)
   case MAT_FWDCHKSSIND:
     s->secSts.secSapSts.fwdChkSSIndReqRx++;
     break;
#endif /* VLR || HLR */

#if MAP_MSC
   case MAT_DET_IMSI:
     s->secSts.secSapSts.detIMSIReqRx++;
     break;
   case MAT_TRACESUBSACTV:
     s->secSts.secSapSts.trSubReqRx++;
     break;
#endif   /* MSC */

#if (MAP_MSC || MAP_HLR)
   case MAT_ROUTINFO:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.routInfoReqRx++;
     }
     else
     {
       s->secSts.secSapSts.routInfoRspRx++;
     }
     break;
   case MAT_ROUTINFOSM:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.routInfoSMReqRx++;
     }
     else
     {
       s->secSts.secSapSts.routInfoSMRspRx++;
     }
     break;
   case MAT_SMDEL:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.smDelReqRx++;
     }
     else
     {
       s->secSts.secSapSts.smDelRspRx++;
     }
     break;
   case MAT_ALRTSC:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.alrtSCReqRx++;
     }
     else
     {
       s->secSts.secSapSts.alrtSCRspRx++;
     }
     break;
   case MAT_ALRTSCWRSLT:
     s->secSts.secSapSts.alrtSCWRsltReqRx++;
     break;
   case MAT_INFSC:
     s->secSts.secSapSts.infSCReqRx++;
     break;
#endif  /* MSC || HLR */

#if (MAP_VLR || MAP_HLR)
   case MAT_UPLOC:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.upLocReqRx++;
     }
     else
     {
       s->secSts.secSapSts.upLocRspRx++;
     }
     break;
#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_SNDPARAM:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.sndParamReqRx++;
     }
     else
     {
       s->secSts.secSapSts.sndParamRspRx++;
     }
     break;
   case MAT_PROVSUBSINFO:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.provSubsInfoReqRx++;   
     }
     else
     {
        s->secSts.secSapSts.provSubsInfoRspRx++;   
     }
     break;

#if MAP_REL99

  /* Note MM event */
  case MAT_NOTE_MMEVT:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.notMmEvReqRx++;   
     }
     else
     {
        s->secSts.secSapSts.notMmEvRspRx++;   
     }
     break;

#endif /* MAP_REL99 */
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR)
   case MAT_RESTOREDATA:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.restoreReqRx++;
     }
     else
     {
       s->secSts.secSapSts.restoreRspRx++;
     }
     break;
   case MAT_SNDIMSI:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.sndIMSIReqRx++;
     }
     else
     {
       s->secSts.secSapSts.sndIMSIRspRx++;
     }
     break;

   case MAT_NOTSUBPRES:
     s->secSts.secSapSts.notSubPresReqRx++;
     break;

   case MAT_BEGIN_SUBS_ACTV:
     s->secSts.secSapSts.bgnSubActvReqRx++;
     break;
   case MAT_PROVROAMNMB:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.provRoamNmbReqRx++;
     }
     else
     {
       s->secSts.secSapSts.provRoamNmbRspRx++;
     }
     break;

   case MAT_SETRPTSTATE:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.setRptStateReqRx++;    
     }
     else
     {
        s->secSts.secSapSts.setRptStateRspRx++;    
     }
     break;

   case MAT_RMTUSRFREE:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.rmtUsrFreeReqRx++;    
     }
     else
     {
        s->secSts.secSapSts.rmtUsrFreeRspRx++;    
     }
     break;

   case MAT_STARPT:
     if (type == MA_SS_REQ)
     {
        s->secSts.secSapSts.staRptReqRx++;    
     }
     break;

#endif  /* (VLR) || (HLR) */

#if (MAP_VLR || MAP_HLR)
   case MAT_REGCCENT:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.regCcEntReqRx++;   
     }
     else
     {
        s->secSts.secSapSts.regCcEntRspRx++;   
     }
     break;

   case MAT_ERASECCENT:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.eraseCcEntReqRx++;   
     }
     else
     {
        s->secSts.secSapSts.eraseCcEntRspRx++;   
     }
     break;

#endif /* VLR || HLR */

#if MAP_MSC
   case MAT_PRE_HO:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.preHoReqRx++;
     }
     else
     {
       s->secSts.secSapSts.preHoRspRx++;
     }
     break;
   case MAT_PER_HO:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.perHoReqRx++;
     }
     else
     {
       s->secSts.secSapSts.perHoRspRx++;
     }
     break;
   case MAT_SNDENDSIG:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.sndEndSigReqRx++;
     }
     else
     {
        s->secSts.secSapSts.sndEndSigRspRx++;
     }
     break;
   case MAT_PROCACCSIG:
     s->secSts.secSapSts.procAccSigReqRx++;
     break;
   case MAT_FWDACCSIG:
     s->secSts.secSapSts.fwdAccSigReqRx++;
     break;
   case MAT_PRE_SUBSHO:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.preSubHoReqRx++;
     }
     else
     {
       s->secSts.secSapSts.preSubHoRspRx++;
     }
     break;
   case MAT_PER_SUBSHO:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.perSubHoReqRx++;
     }
     else
     {
       s->secSts.secSapSts.perSubHoRspRx++;
     }
     break;
   case MAT_NOTEINTERHO:
     s->secSts.secSapSts.notInterHoReqRx++;
     break;
   case MAT_PREP_GRPCALL:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.prepGrpCallReqRx++;   
     }
     else
     {
        s->secSts.secSapSts.prepGrpCallRspRx++;   
     }
     break;


   case MAT_PROV_SIWFS_NMB:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.provSiwfsNmbReqRx++;   
     }
     else
     {
        s->secSts.secSapSts.provSiwfsNmbRspRx++;   
     }
     break;

   case MAT_SIWFS_SIGMOD:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.siwfsSigModReqRx++;   
     }
     else
     {
        s->secSts.secSapSts.siwfsSigModRspRx++;   
     }
     break;

   case MAT_RESCALLHANDL:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.resCallHandlReqRx++;   
     }
     else
     {
        s->secSts.secSapSts.resCallHandlRspRx++;   
     }
      break;
   case MAT_PRO_GRPCALLSIG:
      s->secSts.secSapSts.proGrpCallSigReqRx++;   
      break;
   case MAT_FWD_GRPCALLSIG:
      s->secSts.secSapSts.fwdGrpCallSigReqRx++;   
      break;
   case MAT_SND_GRPCALLENDSIG:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.sndGrpCallEndSigReqRx++;
     }
     else
     {
       s->secSts.secSapSts.sndGrpCallEndSigRspRx++;
     }
      break;

#endif  /* MSC */

#if MAP_VLR
  /* Send Identification Request */
   case MAT_SNDID:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.sndIdReqRx++;
     }
     else
     {
       s->secSts.secSapSts.sndIdRspRx++;
     }
     break;
#endif  /* MAP_VLR */

#if (MAP_MSC || MAP_HLR)
   case MAT_SSINV_NOTIFY:
      if (type == MA_SS_REQ)
      {
         s->secSts.secSapSts.ssInvNotReqRx++;   
      }
      else
      {
         s->secSts.secSapSts.ssInvNotRspRx++;   
      }
      break;
#if MAP_REL99

  case MAT_IST_ALERT:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.istAlrtReqRx++;   
     }
     else
     {
        s->secSts.secSapSts.istAlrtRspRx++;   
     }
     break;
  case MAT_IST_COMMAND:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.istCmdReqRx++;   
     }
     else
     {
        s->secSts.secSapSts.istCmdRspRx++;   
     }
     break;

#endif /* MAP_REL99 */

#endif 

#if MAP_MSC
#if MAP_REL6
        
  case MAT_REL_RES:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.relResReqRx++;   
     }
     else
     {
        s->secSts.secSapSts.relResRspRx++;   
     }
     break;

#endif /* MAP_REL6 */
#endif /* MAP_MSC */

#if (MAP_HLR || MAP_MLC)
   case MAT_ANY_INTER:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.anyInterReqRx++;   
     }
     else
     {
        s->secSts.secSapSts.anyInterRspRx++;   
     }
     break;

#endif /* MAP_HLR || MAP_MLC */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_SMRDY:
     if (type == MA_SS_REQ)
     {
        s->secSts.secSapSts.smRdyReqRx++;
     }
     else
     {
        s->secSts.secSapSts.smRdyRspRx++;
     }
     break;
#endif

#if (MAP_MSC || MAP_VLR || MAP_GSN)
   case MAT_CHKIMEI:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.chkIMEIReqRx++;
     }
     else
     {
       s->secSts.secSapSts.chkIMEIRspRx++;
     }
     break;
#endif

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_CANCELLOC:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.canLocReqRx++;
     }
     else
     {
       s->secSts.secSapSts.canLocRspRx++;
     }
     break;
   case MAT_PURGE:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.purgMsReqRx++;
     }
     else
     {
       s->secSts.secSapSts.purgMsRspRx++;
     }
     break;
     
   case MAT_AUTHINFO:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.authInfReqRx++;
     }
     else
     {
       s->secSts.secSapSts.authInfRspRx++;
     }
     break;
   case MAT_INSSUBSDATA:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.insSubReqRx++;
     }
     else
     {
       s->secSts.secSapSts.insSubRspRx++;
     }
     break;
   case MAT_DELSUBSDATA:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.delSubReqRx++;
     }
     else
     {
       s->secSts.secSapSts.delSubRspRx++;
     }
     break;
   case MAT_RESET:
     s->secSts.secSapSts.resetReqRx++;
     break;
   case MAT_ACTVTRACE:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.actvTrReqRx++;
     }
     else
     {
       s->secSts.secSapSts.actvTrRspRx++;
     }
     break;
   case MAT_DACTVTRACE:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.dactvTrReqRx++;
     }
     else
     {
       s->secSts.secSapSts.dactvTrRspRx++;
     }
     break;

#if MAP_REL99

   case MAT_AUTHFAILRPT:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.authFailRptReqRx++;
     }
     else
     {
       s->secSts.secSapSts.authFailRptRspRx++;
     }

     break;

#endif /* MAP_REL99 */

#endif

#if (MAP_MSC || MAP_GSN)
   case MAT_FWDSM:
     if(type  == MAT_SS_REQ)
     {
        s->secSts.secSapSts.fwdSMReqRx++;
     }
     else
     {
        s->secSts.secSapSts.fwdSMRspRx++; 
     }
     break;

   case MAT_MT_FWDSM:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.mtFwdSMReqRx++;
     }
     else
     {
        s->secSts.secSapSts.mtFwdSMRspRx++; 
     }
     break;

#endif

#if (MAP_HLR || MAP_GSN)
   case MAT_GPRS_UPLOC:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.gprsUpLocReqRx++;   
     }
     else
     {
        s->secSts.secSapSts.gprsUpLocRspRx++;   
     }
     break;

   case MAT_GPRS_ROUTINFO:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.gprsRoutInfoReqRx++;
     }
     else
     {
        s->secSts.secSapSts.gprsRoutInfoRspRx++;
     }
     break;
   case MAT_FAILRPT:
     if (type == MA_SS_REQ)
     {
        s->secSts.secSapSts.failRptReqRx++;   
     }
     else
     {
        s->secSts.secSapSts.failRptRspRx++;   
     }
     break;
   case MAT_GPRS_NOTEMSPRES:
     if (type == MA_SS_REQ)
     {
        s->secSts.secSapSts.gprsNoteMsPresReqRx++;   
     }
     else
     {
        s->secSts.secSapSts.gprsNoteMsPresRspRx++;   
     }
     break;
   
#endif

#if (MAP_REL98 || MAP_REL99)

#if (MAP_HLR || MAP_MLC)
   case MAT_SENDROUTINFOFORLCS:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.lcsSndRoutInfoReqRx++;
     }
     else
     {
        s->secSts.secSapSts.lcsSndRoutInfoRspRx++;
     }

     break;
#endif /* MAP_HLR || MAP_MLC */

#endif /* MAP_REL98 || MAP_REL99 */

#if (MAP_REL98 || MAP_REL99)

#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL4 && MAP_GSN))
   case MAT_PROVSUBSLOC:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.provSubsLocReqRx++;
     }
     else
     {
        s->secSts.secSapSts.provSubsLocRspRx++;
     }

     break;
   case MAT_SUBSLOCRPT:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.subsLocReqRx++;
     }
     else
     {
        s->secSts.secSapSts.subsLocRspRx++;
     }

     break;
#endif
#endif

#if MAP_HLR
   case MAT_ANY_SUBSDATA_INTER:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.anySubsInterReqRx++;
     }
     else
     {
        s->secSts.secSapSts.anySubsInterRspRx++;
     }

     break;
   case MAT_ANY_MOD:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.anyModReqRx++;
     }
     else
     {
        s->secSts.secSapSts.anyModRspRx++;
     }

     break;
   case MAT_NOTE_SUBSDATA_MOD:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.notSubsModReqRx++;
     }
     else
     {
        s->secSts.secSapSts.notSubsModRspRx++;
     }

     break;
#endif /* MAP_HLR */

#endif /* (MAP_REL98 || MAP_REL99) */

   default:
#if (ERRCLASS & ERRCLS_DEBUG)
     MALOGERROR(ERRCLS_DEBUG, EMA270, (ErrVal)oprType, "maUpdatSecRxSts () bad opr type");
#endif
     break;
  }
} /* maUpdatSecRxSts */


/*
*
*       Fun:   maUpdatSecErrSts    
*
*       Desc:  This function updates the Statistics for reture error
*              received with in a secure dialogue.
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void maUpdatSecErrSts 
(
MaSap  *s,              /* MAP Sap */
U8     oprType,         /* Operation to be encoded */
U8     type             /* Request or Response */
)
#else
PUBLIC Void maUpdatSecErrSts (s,oprType, type)
MaSap  *s;              /* MAP Sap */
U8     oprType;         /* Operation to be encoded */
U8     type;            /* Request or Response */
#endif
{
  TRC2(maUpdatSecErrSts)
  switch (oprType)
  {
#if (MAP_VLR || MAP_HLR)
   case MAT_REGSS:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.regSSReTx++;
     }
     else
     {
       s->secSts.secSapSts.regSSReRx++;
     }
     break;
   case MAT_ERASESS:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.eraseSSReTx++;

     }
     else
     {
       s->secSts.secSapSts.eraseSSReRx++;
     }
     break;
   case MAT_ACTVSS:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.actvSSReTx++;

     }
     else
     {
       s->secSts.secSapSts.actvSSReRx++;
     }
     break;
   case MAT_DACTVSS:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.dactvSSReTx++;
     }
     else
     {
       s->secSts.secSapSts.dactvSSReRx++;
     }
     break;
   case MAT_INTERSS:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.interSSReTx++;
     }
     else
     {
       s->secSts.secSapSts.interSSReRx++;
     }
     break;
   case MAT_REGPASSWD:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.regPasswdReTx++;
     }
     else
     {
       s->secSts.secSapSts.regPasswdReRx++;
     }
     break;
   case MAT_GETPASSWD:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.getPasswdReTx++;
     }
     else
     {
       s->secSts.secSapSts.getPasswdReRx++;
     }
     break;
   case MAT_PROCUSSREQ:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.procUSSReTx++;
     }
     else
     {
       s->secSts.secSapSts.procUSSReRx++;
     }
     break;
   case MAT_PROCUSSDATA:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.procUSSDatReTx++;
     }
     else
     {
       s->secSts.secSapSts.procUSSDatReRx++;
     }
     break;
   case MAT_USSREQ:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.ussReTx++;
     }
     else
     {
       s->secSts.secSapSts.ussReRx++;
     }
     break;
   case MAT_USSNOTIFY:
     s->secSts.secSapSts.ussNotReTx++;
     break;
#endif /* VLR || HLR */

#if (MAP_MSC || MAP_HLR)
   case MAT_ROUTINFO:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.routInfoReTx++;
     }
     else
     {
       s->secSts.secSapSts.routInfoReRx++;
     }
     break;
   case MAT_ROUTINFOSM:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.routInfoSMReTx++;
     }
     else
     {
       s->secSts.secSapSts.routInfoSMReRx++;
     }
     break;
   case MAT_SMDEL:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.smDelReTx++;
     }
     else
     {
       s->secSts.secSapSts.smDelReRx++;
     }
     break;
   case MAT_ALRTSC:
     s->secSts.secSapSts.alrtSCReTx++;
     break;
#endif  /* MSC || HLR */

#if (MAP_VLR || MAP_HLR)
   case MAT_UPLOC:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.upLocReTx++;
     }
     else
     {
       s->secSts.secSapSts.upLocReRx++;
     }
     break;
#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_SNDPARAM:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.sndParamReTx++;
     }
     else
     {
       s->secSts.secSapSts.sndParamReRx++;
     }
     break;

   case MAT_PROVSUBSINFO:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.provSubsInfoReTx++;     /*prov Subs Info req Rx */
     }
     else
     {
        s->secSts.secSapSts.provSubsInfoReRx++;     /*prov Subs Info rsp Rx */
     }
     break;

#if MAP_REL99

  /* Note MM event */
  case MAT_NOTE_MMEVT:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.notMmEvReTx++;     /* req Rx */
     }
     else
     {
        s->secSts.secSapSts.notMmEvReRx++;     /* rsp Rx */
     }
     break;

#endif /* MAP_REL99 */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR)
   case MAT_RESTOREDATA:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.restoreReTx++;
     }
     else
     {
       s->secSts.secSapSts.restoreReRx++;
     }
     break;
   case MAT_SNDIMSI:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.sndIMSIReTx++;
     }
     else
     {
       s->secSts.secSapSts.sndIMSIReRx++;
     }
     break;
   case MAT_PROVROAMNMB:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.provRoamNmbReTx++;
     }
     else
     {
       s->secSts.secSapSts.provRoamNmbReRx++;
     }
     break;

   case MAT_SETRPTSTATE:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.setRptStateReTx++;     /* req Rx */
     }
     else
     {
        s->secSts.secSapSts.setRptStateReRx++;     /* rsp Rx */
     }
     break;

   case MAT_RMTUSRFREE:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.rmtUsrFreeReTx++;     /* req Rx */
     }
     else
     {
        s->secSts.secSapSts.rmtUsrFreeReRx++;     /* rsp Rx */
     }
     break;

   case MAT_STARPT:
     if (type == MA_SS_REQ)
     {
        s->secSts.secSapSts.staRptReTx++;     /*   req Rx */
     }
     else
     {
        s->secSts.secSapSts.staRptReRx++;     /*   rsp Rx */
     }
     break;

#endif  /* (VLR) || (HLR) */

#if (MAP_VLR || MAP_HLR)
   case MAT_REGCCENT:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.regCcEntReTx++;     /*reg Cc Ent req Rx */
     }
     else
     {
        s->secSts.secSapSts.regCcEntReRx++;     /*reg Cc Ent rsp Rx */
     }
     break;

   case MAT_ERASECCENT:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.eraseCcEntReTx++;     /*erase Cc Ent req Rx */
     }
     else
     {
        s->secSts.secSapSts.eraseCcEntReRx++;     /*erase Cc Ent rsp Rx */
     }
     break;

#endif /* VLR || HLR */

#if MAP_MSC
   case MAT_PRE_HO:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.preHoReTx++;
     }
     else
     {
       s->secSts.secSapSts.preHoReRx++;
     }
     break;
   case MAT_PER_HO:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.perHoReTx++;
     }
     else
     {
       s->secSts.secSapSts.perHoReRx++;
     }
     break;
   case MAT_PRE_SUBSHO:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.preSubHoReTx++;
     }
     else
     {
       s->secSts.secSapSts.preSubHoReRx++;
     }
     break;
   case MAT_PER_SUBSHO:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.perSubHoReTx++;
     }
     else
     {
       s->secSts.secSapSts.perSubHoReRx++;
     }
     break;

   case MAT_PREP_GRPCALL:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.prepGrpCallReTx++; 
     }
     else
     {
        s->secSts.secSapSts.prepGrpCallReRx++; 
     }
     break;

   case MAT_PRO_GRPCALLSIG:
     if(type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.proGrpCallReTx++;  
     }
     else
     {
        s->secSts.secSapSts.proGrpCallReTx++;  
     }
     break;

   case MAT_PROV_SIWFS_NMB:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.provSiwfsNmbReTx++;     /* prov Siwfs Nmb req Rx */
     }
     else
     {
        s->secSts.secSapSts.provSiwfsNmbReRx++;     /* prov Siwfs Nmb rsp Rx */
     }
     break;

   case MAT_SIWFS_SIGMOD:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.siwfsSigModReTx++;     /*  siwfs Sig Mod req Rx */
     }
     else
     {
        s->secSts.secSapSts.siwfsSigModReRx++;     /*  siwfs Sig Mod rsp Rx */
     }
     break;

   case MAT_RESCALLHANDL:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.resCallHandlReTx++;     /*  siwfs Sig Mod req Rx */
     }
     else
     {
        s->secSts.secSapSts.resCallHandlReRx++;     /*  siwfs Sig Mod rsp Rx */
     }
      break;
   case MAT_SND_GRPCALLENDSIG:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.sndGrpCallEndSigReTx++;
     }
     else
     {
       s->secSts.secSapSts.sndGrpCallEndSigReRx++;
     }
      break;

#endif  /* MSC */

#if MAP_VLR
  /* Send Identification Request */
   case MAT_SNDID:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.sndIdReTx++;
     }
     else
     {
       s->secSts.secSapSts.sndIdReRx++;
     }
     break;
#endif  /* MAP_VLR */

#if (MAP_MSC || MAP_HLR)
   case MAT_SSINV_NOTIFY:
      if (type == MA_SS_REQ)
      {
         s->secSts.secSapSts.ssInvNotReTx++;     /*  ss Inv Not req Rx */
      }
      else
      {
         s->secSts.secSapSts.ssInvNotReRx++;     /*  ss Inv Not rsp Rx */
      }
      break;
#if MAP_REL99

  case MAT_IST_ALERT:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.istAlrtReTx++;     /* any Inter req Rx */
     }
     else
     {
        s->secSts.secSapSts.istAlrtReRx++;     /* any Inter rsp Rx */
     }
     break;
  case MAT_IST_COMMAND:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.istCmdReTx++;     /* any Inter req Rx */
     }
     else
     {
        s->secSts.secSapSts.istCmdReRx++;     /* any Inter rsp Rx */
     }
     break;

#endif /* MAP_REL99 */

#endif 

#if MAP_MSC
#if MAP_REL6
      
  case MAT_REL_RES:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.relResReTx++;     /* any Inter req Rx */
     }
     else
     {
        s->secSts.secSapSts.relResReRx++;     /* any Inter rsp Rx */
     }
     break;

#endif /* MAP_REL6 */
#endif /* MAP_MSC */

#if (MAP_HLR || MAP_MLC)
   case MAT_ANY_INTER:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.anyInterReTx++;     /* any Inter req Rx */
     }
     else
     {
        s->secSts.secSapSts.anyInterReRx++;     /* any Inter rsp Rx */
     }
     break;

#endif /* MAP_HLR || MAP_MLC */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_SMRDY:
     if (type == MA_SS_REQ)
     {
        s->secSts.secSapSts.smRdyReTx++;
     }
     else
     {
        s->secSts.secSapSts.smRdyReRx++;
     }
     break;
#endif

#if (MAP_MSC || MAP_VLR || MAP_GSN)
   case MAT_CHKIMEI:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.chkIMEIReTx++;
     }
     else
     {
       s->secSts.secSapSts.chkIMEIReRx++;
     }
     break;
#endif

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MAT_CANCELLOC:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.canLocReTx++;
     }
     else
     {
       s->secSts.secSapSts.canLocReRx++;
     }
     break;
   case MAT_PURGE:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.purgMsReTx++;
     }
     else
     {
       s->secSts.secSapSts.purgMsReRx++;
     }
     break;
     
   case MAT_AUTHINFO:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.authInfReTx++;
     }
     else
     {
       s->secSts.secSapSts.authInfReRx++;
     }
     break;
   case MAT_INSSUBSDATA:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.insSubReTx++;
     }
     else
     {
       s->secSts.secSapSts.insSubReRx++;
     }
     break;
   case MAT_DELSUBSDATA:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.delSubReTx++;
     }
     else
     {
       s->secSts.secSapSts.delSubReRx++;
     }
     break;
   case MAT_ACTVTRACE:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.actvTrReTx++;
     }
     else
     {
       s->secSts.secSapSts.actvTrReRx++;
     }
     break;
   case MAT_DACTVTRACE:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.dactvTrReTx++;
     }
     else
     {
       s->secSts.secSapSts.dactvTrReRx++;
     }
     break;

#if MAP_REL99

   case MAT_AUTHFAILRPT:
     if (type == MAT_SS_REQ)
     {
       s->secSts.secSapSts.authFailRptReTx++;
     }
     else
     {
       s->secSts.secSapSts.authFailRptReRx++;
     }

     break;

#endif /* MAP_REL99 */

#endif

#if (MAP_MSC || MAP_GSN)
   case MAT_FWDSM:
     if(type  == MAT_SS_REQ)
     {
        s->secSts.secSapSts.fwdSMReTx++;
     }
     else
     {
        s->secSts.secSapSts.fwdSMReRx++; /* mt Forward SM rsp Received */
     }
     break;

   case MAT_MT_FWDSM:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.mtFwdSMReTx++;  /* mt Forward SM request Received */
     }
     else
     {
        s->secSts.secSapSts.mtFwdSMReRx++; /* mt Forward SM rsp Received */
     }
     break;

#endif

#if (MAP_HLR || MAP_GSN)
   case MAT_GPRS_UPLOC:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.gprsUpLocReTx++;     /* Gprs Up. Loc req Rx */
     }
     else
     {
        s->secSts.secSapSts.gprsUpLocReRx++;     /* Gprs Up. Loc rsp Rx */
     }
     break;

   case MAT_GPRS_ROUTINFO:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.gprsRoutInfoReTx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->secSts.secSapSts.gprsRoutInfoReRx++;  /* Gprs Rout Info rsp Rx */
     }
     break;
   case MAT_FAILRPT:
     if (type == MA_SS_REQ)
     {
        s->secSts.secSapSts.failRptReTx++;     /* Fail Rpt  req Rx */
     }
     else
     {
        s->secSts.secSapSts.failRptReRx++;     /* Fail Rpt  rsp Rx */
     }
     break;
   case MAT_GPRS_NOTEMSPRES:
     if (type == MA_SS_REQ)
     {
        s->secSts.secSapSts.gprsNoteMsPresReTx++;     /* Gprs Note Ms Pres  req Rx */
     }
     else
     {
        s->secSts.secSapSts.gprsNoteMsPresReRx++;     /* Gprs Note Ms Pres  rsp Rx */
     }
     break;
   
#endif

#if (MAP_REL98 || MAP_REL99)

#if (MAP_HLR || MAP_MLC)
   case MAT_SENDROUTINFOFORLCS:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.lcsSndRoutInfoReTx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->secSts.secSapSts.lcsSndRoutInfoReRx++;  /* Gprs Rout Info rsp Rx */
     }

     break;
#endif /* MAP_HLR || MAP_MLC */

#endif /* MAP_REL98 || MAP_REL99 */

#if (MAP_REL98 || MAP_REL99)

#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL4 && MAP_GSN))
   case MAT_PROVSUBSLOC:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.provSubsLocReTx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->secSts.secSapSts.provSubsLocReRx++;  /* Gprs Rout Info rsp Rx */
     }

     break;
   case MAT_SUBSLOCRPT:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.subsLocReTx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->secSts.secSapSts.subsLocReRx++;  /* Gprs Rout Info rsp Rx */
     }

     break;
#endif
#endif

#if MAP_HLR
   case MAT_ANY_SUBSDATA_INTER:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.anySubsInterReTx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->secSts.secSapSts.anySubsInterReRx++;  /* Gprs Rout Info rsp Rx */
     }

     break;
   case MAT_ANY_MOD:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.anyModReTx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->secSts.secSapSts.anyModReRx++;  /* Gprs Rout Info rsp Rx */
     }

     break;
   case MAT_NOTE_SUBSDATA_MOD:
     if (type == MAT_SS_REQ)
     {
        s->secSts.secSapSts.notSubsModReTx++;  /* Gprs Rout Info req Rx */
     }
     else
     {
        s->secSts.secSapSts.notSubsModReRx++;  /* Gprs Rout Info rsp Rx */
     }

     break;
#endif /* MAP_HLR */

#endif /* (MAP_REL98 || MAP_REL99) */

   default:
#if (ERRCLASS & ERRCLS_DEBUG)
     MALOGERROR(ERRCLS_DEBUG, EMA271, (ErrVal)oprType, "maUpdatSecErrSts () bad opr type");
#endif
     break;
  }
} /* maUpdatSecErrSts */

#ifndef MA_CUSTOM_HOOK
/*
*
*       Fun:    maF7Enc
*
*       Desc:   MAP integrity algorithm function (encode)
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 maF7Enc
(
LmaSecMia      mia,       /* mia */  
LmaSecMik      *mik,      /* mik */
MaSecHeader    *secHdr,   /* security header */
Buffer         *secHdBuf, /* security header message buffer */ 
Buffer         *clTxBuf,  /* clear text buffer */
TknStrS        *mac       /* message authentication code */  
)
#else
PUBLIC S16 maF7Enc(mia, mik, secHdr, secHdBuf, clTxBuf, mac)
LmaSecMia      mia;       /* mia */  
LmaSecMik      *mik;      /* mik */
MaSecHeader    *secHdr;   /* security header */
Buffer         *secHdBuf; /* security header message buffer */ 
Buffer         *clTxBuf;  /* clear text buffer */
TknStrS        *mac;      /* message authentication code */  
#endif
{

   TRC3(maF7Enc)

#if (ERRCLASS & ERRCLS_DEBUG)
   MALOGERROR(ERRCLS_DEBUG, EMA272, (ErrVal)0, "maF7Enc () Failed");
#endif

   RETVALUE(ROK);
} /* maF7Enc */

/*
*
*       Fun:    maF6Enc
*
*       Desc:   MAP encryption algorithm function
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 maF6Enc
(
LmaSecMea      mea,       /* mea */  
LmaSecMek      *mek,      /* mek */
MaSecHeader    *secHdr,   /* security header */
Buffer         *clTxBuf,  /* cleartext buffer */
Buffer         *cpTxBuf   /* ciphertext buffer */
)
#else
PUBLIC S16 maF6Enc(mea, mek, secHdr, clTxBuf, cpTxBuf)
LmaSecMea      mea;       /* mea */  
LmaSecMek      *mek;      /* mek */
MaSecHeader    *secHdr;   /* security header */
Buffer         *clTxBuf;  /* cleartext buffer */
Buffer         *cpTxBuf;  /* ciphertext buffer */
#endif
{

   TRC3(maF6Enc)

#if (ERRCLASS & ERRCLS_DEBUG)
   MALOGERROR(ERRCLS_DEBUG, EMA273, (ErrVal)0, "maF6Enc () Failed");
#endif

   RETVALUE(ROK);
} /* maF6Enc */

/*
*
*       Fun:    maF7Dec
*
*       Desc:   MAP integrity algorithm function (decode)
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 maF7Dec
(
LmaSecMia      mia,       /* mia */  
LmaSecMik      *mik,      /* mik */
MaSecHeader    *secHdr,   /* security header */
Buffer         *cpTxBuf   /* ciphertext buffer */
)
#else
PUBLIC S16 maF7Dec(mia, mik, secHdr, cpTxBuf)
LmaSecMia      mia;       /* mia */  
LmaSecMik      *mik;      /* mik */
MaSecHeader    *secHdr;   /* security header */
Buffer         *cpTxBuf;  /* ciphertext buffer */
#endif
{

   TRC3(maF7Dec)

#if (ERRCLASS & ERRCLS_DEBUG)
   MALOGERROR(ERRCLS_DEBUG, EMA274, (ErrVal)0, "maF7Dec () Failed");
#endif

   RETVALUE(ROK);
} /* maF7Dec */

/*
*
*       Fun:    maF6Dec
*
*       Desc:   MAP encryption algorithm function (decode)
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ca_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 maF6Dec
(
LmaSecMea      mea,       /* mea */  
LmaSecMek      *mek,      /* mek */
MaSecHeader    *secHdr,   /* security header */
Buffer         *clTxBuf,  /* cleartext buffer */
Buffer         *cpTxBuf   /* ciphertext buffer */
)
#else
PUBLIC S16 maF6Dec(mea, mek, secHdr, clTxBuf, cpTxBuf)
LmaSecMea      mea;       /* mea */  
LmaSecMek      *mek;      /* mek */
MaSecHeader    *secHdr;   /* security header */
Buffer         *clTxBuf;  /* ciphertext buffer */
Buffer         *cpTxBuf;  /* ciphertext buffer */
#endif
{

   TRC3(maF6Dec)

#if (ERRCLASS & ERRCLS_DEBUG)
   MALOGERROR(ERRCLS_DEBUG, EMA275, (ErrVal)0, "maF6Dec () Failed");
#endif

   RETVALUE(ROK);
} /* maF6Dec */
#endif /* MA_CUSTOM_HOOK */


#endif /* MAP_SEC */
#endif /* MAP_REL99 */


/*
*
*       Fun:   maChkOprCode
*
*       Desc:  This function is used to validate operaion code
*
*       Ret:   ROK , if the operation exits
*              RFAILED , if the operation does not exist.  
*
*       Notes: None
*
*       File:  ca_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC S16 maChkOprCode
(
U8        opCode     /* operation code */
)
#else
PUBLIC S16 maChkOprCode (opCode)
U8        opCode;    /* operation code */
#endif
{
   TRC2(maChkOprCode)

   switch(opCode)
   {
#ifdef XWEXT 
		case MAT_PAGING_DETECT:
#endif
/* New Operations */
#if (MAP_REL98 || MAP_REL99)
#if (MAP_HLR || MAP_MLC)
        case MAT_SENDROUTINFOFORLCS:          /* RoutInfo For LCS */
#endif

#if MAP_REL99
#if (MAP_VLR || MAP_HLR || MAP_GSN)
        case MAT_AUTHFAILRPT:         /* MaAuthFailRpt */
        case MAT_NOTE_MMEVT:          /* Note Mm Event  */
#endif
#if (MAP_MSC || MAP_HLR)
        case MAT_IST_ALERT:           /* IST Alert     */
        case MAT_IST_COMMAND:         /* IST Command   */
#endif
#if MAP_HLR
        case MAT_ANY_SUBSDATA_INTER:  /* AnyTime Subscriber Interro */
        case MAT_ANY_MOD:             /* AnyTime Modification */
        case MAT_NOTE_SUBSDATA_MOD:   /* Note Subs Data Modified */
#endif
#if MAP_REL6
#if MAP_MSC
        case MAT_REL_RES:             /* Release Resources */
#endif /* MAP_MSC */
#endif /* MAP_REL6 */

#endif
#endif

#if (MAP_REL98 || MAP_REL99)
#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL4 && MAP_GSN))
        case MAT_PROVSUBSLOC:         /* Provide Subscriber Location */
        case MAT_SUBSLOCRPT:          /* Subscriber Location Report */
#endif 
#endif
#endif

#if (MAP_VLR || MAP_HLR)
      case MAT_SETRPTSTATE:           /* MaSetRptState */
      case MAT_STARPT:                /* MaStaRpt */
      case MAT_RMTUSRFREE:            /* MaRmtUsrFree */
      case MAT_REGCCENT:              /* MaRegCcEnt */
      case MAT_ERASECCENT:            /* MaEraseCcEnt */
#endif  
#if (MAP_MSC || MAP_HLR)
      case MAT_SSINV_NOTIFY:          /* MaSSInvNot */
#endif

#if (MAP_HLR || MAP_GSN)
      case MAT_GPRS_UPLOC:            /* MaGprsUpLoc */
      case MAT_GPRS_ROUTINFO:         /* MaGprsRoutInfo */
      case MAT_FAILRPT:               /*  MaFailRpt */
      case MAT_GPRS_NOTEMSPRES:       /* MaGprsNoteMsPres */
#endif 

#if MAP_MSC
      case MAT_PROV_SIWFS_NMB:        /* MaProvSiwfsNmb */
      case MAT_SIWFS_SIGMOD:          /* MaSiwfsSigMod */
      case MAT_SND_GRPCALLENDSIG:     /* MaSndGrpCallEndSig */
      case MAT_PREP_GRPCALL:          /* MaPrepGrpCall */
      case MAT_PRO_GRPCALLSIG:        /* MaProGrpCallSig */
      case MAT_FWD_GRPCALLSIG:        /* MaFwdGrpCallSig */
#endif
#if (MAP_HLR || MAP_MLC)
      case MAT_ANY_INTER:             /* MaAnyInter */
#endif 
#if (MAP_VLR || MAP_HLR || MAP_GSN)
      case MAT_PROVSUBSINFO:          /* MaProvSubsInfo */
#endif
#if (MAP_VLR || MAP_HLR || MAP_GSN)
      case MAT_PURGE:                 /* MaPurgeMs */
#endif
#if (MAP_VLR || MAP_HLR)
      case MAT_RESTOREDATA:           /* MaRestDat */
#endif
#if (MAP_MSC || MAP_HLR)
      case MAT_ALRTSC:                /* MaAlrtSC */
      case MAT_ALRTSCWRSLT:           /* MaAlrtSCWRslt */
#endif
#if (MAP_VLR || MAP_HLR)
      case MAT_NOTSUBPRES:            /* MaNotSubPres */
#endif
#if (MAP_VLR || MAP_HLR || MAP_GSN)
      case MAT_SMRDY:                 /* MaRdySM */
#endif
#if (MAP_MSC || MAP_HLR)
      case MAT_ROUTINFOSM:            /* MaRoutInfoSM */
      case MAT_SMDEL:                 /* MaRepSMDel */
      case MAT_INFSC:                 /* MaInformSC */
#endif
#if (MAP_MSC || MAP_GSN)
      case MAT_FWDSM:                 /* MaFwdSM */
      case MAT_MT_FWDSM:              /* MaMoFwdSM */
#endif  
#if (MAP_VLR || MAP_HLR)
      case MAT_PROCUSSREQ:       /* MaProcUSSReq */
      case MAT_USSREQ:           /* MaUSSReq */
      case MAT_USSNOTIFY:        /* MaUSSNotify */
      case MAT_PROCUSSDATA:      /* MaProcUSSDat */
#endif
#if (MAP_VLR || MAP_HLR)
      case MAT_BEGIN_SUBS_ACTV:  /* MaBgnSubActv */
#endif
#if (MAP_VLR || MAP_HLR)
      case MAT_REGSS:            /* MaRegSS */
      case MAT_ERASESS:          /* MaEraseSS */
      case MAT_ACTVSS:           /* MaActvSS */
      case MAT_DACTVSS:          /* MaDactvSS */
      case MAT_INTERSS:          /* MaInterSS */
      case MAT_REGPASSWD:        /* MaRegPasswd */
      case MAT_GETPASSWD:        /* MaGetPasswd */
#endif
#if (MAP_VLR || MAP_HLR || MAP_GSN)
      case MAT_DACTVTRACE:       /* MaDactvTr */
      case MAT_ACTVTRACE:        /* MaActvTr */
#endif
#if (MAP_VLR || MAP_HLR || MAP_GSN)
      case MAT_RESET:            /* MaReset */
#endif
#if (MAP_MSC || MAP_VLR || MAP_GSN)
      case MAT_CHKIMEI:          /* MaChkIMEI */
#endif
#if (MAP_VLR || MAP_HLR || MAP_GSN)
      case MAT_INSSUBSDATA:      /* MaInsSubsDat */
      case MAT_DELSUBSDATA:      /* MaDelSubsDat */
#endif
#if MAP_MSC
      case MAT_TRACESUBSACTV:    /* MaTrSubsActv */
      case MAT_NOTEINTERHO:      /* MaNotInterHo */
      case MAT_PER_HO:           /* MaPerHo */
      case MAT_PER_SUBSHO:       /* MaPerSubHo */
      case MAT_PRE_HO:           /* MaPreHo */
      case MAT_PRE_SUBSHO:       /* MaPreSubHo */
      case MAT_SNDENDSIG:        /* MaSndEndSig */
      case MAT_PROCACCSIG:       /* MaProcAccSig */
      case MAT_FWDACCSIG:        /* MaFwdAccSig */
#endif
#if (MAP_MSC || MAP_HLR)
      case MAT_ROUTINFO:         /* MaSndRoutInfo */
#endif
#if MAP_MSC
      case MAT_RESCALLHANDL:     /* MaResCallHandl */
#endif
#if (MAP_VLR || MAP_HLR)
      case MAT_SNDIMSI:          /* MaSndIMSI */
#endif
#if MAP_VLR 
      /* Version-1 equivalent package is Send Parameters */
      /* Send Identification is applicable only to 2 and 2P */
      case MAT_SNDID:             /* MaSendId */
#endif

#if (MAP_VLR || MAP_HLR || MAP_GSN)
      /* Version-1 Equivalent for Auth Info */
      case MAT_SNDPARAM:             /* MaSndParam */
      /* Auth Info is applicable only to 2 and 2P */
      case MAT_AUTHINFO:             /* MaAuthInfo */
#endif
#if (MAP_VLR || MAP_HLR)
      case MAT_PROVROAMNMB:          /* MaRoamNmb  */
#endif 
#if (MAP_VLR || MAP_HLR)
      case MAT_FWDCHKSSIND:          /* NULL    */
      case MAT_UPLOC:                /* MaUpLoc */
#endif 
#if (MAP_VLR || MAP_HLR || MAP_GSN)
      case MAT_CANCELLOC:            /* MaCancelLoc */
#endif
#if MAP_REL99
#if (MAP_SEC && MAP_REL4 && LMAV2)
      case MAT_SEC_TRANS_CLASS1:
      case MAT_SEC_TRANS_CLASS2:
      case MAT_SEC_TRANS_CLASS3:
      case MAT_SEC_TRANS_CLASS4:
#endif
#endif
      {
         /* opearion is valid */
         break;
      }

/** End of Operations */

      default: 
      {
         MADBGP(DBGMASK_MI, (maCb.maInit.prntBuf,
         "maChkOprCode() failed, invalid oprCode(%d).\n", opCode));
         RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /* maChkOprCode */



/********************************************************************30**

         End of file:     ca_bdy4.c@@/main/5 - Fri Sep 16 02:48:35 2005

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  jz    1. initial release

*********************************************************************81*/
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------

/main/1      ---      jie  1. initial release

             ---      yz   1. Correct the division value error.
                           2. Correct stastics update error.

             ---      jie  3. Change for 2002/09 rel99/rel4 release.

/main/2      ---      jie  1. update for MAP 1.7 release.

             ---      jie  1. Addition for definite length encoding

             ---      ssk  1. Changes related to flexibly tune the 
                              MTP3 priority and SCCP class. 
/main/4      ---      zj   1. PSF-MAP changes.
             ---      st   1. Modified the instances of freeing the msg
                              in errorneous scenarios wherever it was 
                              guarded by ERRCLS_ADD_RES.
/main/5      ---      st   1. Updated for MAP sotware release 2.3
				ma001.203 	st	  1. Initialized dataParam element.
/main/5     ma003.203 rb   1. Introduced maCb global control block.
                           2. Moved global variables to maCb.
*********************************************************************91*/
