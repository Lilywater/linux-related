/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     map
  
     Type:     C Source file
  
     Desc:     C source code for data base defination
  
     File:     ca_db2.c
  
     Sid:      ca_db2.c@@/main/12 - Fri Sep 16 02:48:04 2005
  
     Prg:      ssk
  
*********************************************************************21*/


/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#if MAP_MSC
#if MAP_VLR
#if MAP_HLR
      -05      MSC, VLR and HLR
#else
#endif
#else
#if MAP_HLR
#else
      -01      MSC
#endif
#endif
#else
#if MAP_VLR
#if MAP_HLR
      -04      VLR and HLR
#else
      -02      VLR
#endif
#else
#if MAP_HLR
      -03      HLR
#else
#endif
#endif
#endif

************************************************************************/
 

/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "lma.h"           /* layer management, MAP */
#include "cm_err.h"        /* common error */
#include "stu.h"           /* tcap layer */
#include "mat.h"           /* map layer */
#ifdef MA_FTHA
#include "sht.h"
#endif /* MA_FTHA */
#include "cm5.h"
#include "ma.h"            /* map */
#include "ma_mf.h"
#include "ma_err.h"        /* map error */
#ifdef ZJ
#include "cm_ftha.h"       /* Common FTHA */
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#include "cm_tupsf.h"      /* Common TCAP user PSF */
#endif /* ZJ */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"
#include "cm_ss7.x"        /* SS7 common */
#include "stu.x"           /* tcap layer */
#include "lma.x"           /* layer management, TCAP */
#include "mat.x"           /* map  layer */
#ifdef MA_FTHA
#include "sht.x"
#endif /* MA_FTHA */
#ifdef ZJ
#include "cm_ftha.x"       /* Common FTHA */
#include "cm_pftha.x"      /* Common PSF defines */
#include "cm_psfft.x"
#include "cm_tupsf.x"      /* Common TCAP user PSF */
#endif /* ZJ */
#include "ma.x"            /* map */

/* forward references */  
/* Message Flags */
EXTERN    U32    maMsgFlgs0[];


/* token enumerated values for invokes and return results */

EXTERN MaTknEnum *maNetResEnums[];
EXTERN MaTknEnum *maProtIdEnums[];
EXTERN MaTknEnum *maEqupStatEnums[];
EXTERN MaTknEnum *maInterHoTypeEnums[];
EXTERN MaTknEnum *maIntraCugOptEnums[];
EXTERN MaTknEnum *maCliRestOptEnums[];
EXTERN MaTknEnum *maOvrRideCatEnums[];
EXTERN MaTknEnum *maHntGrpAccSelOdrEnums[];
EXTERN MaTknEnum *maRegSubsRspEnums[];
EXTERN MaTknEnum *maSMDelStatEnums[];
EXTERN MaTknEnum *maSMDelOutComeEnums[];
EXTERN MaTknEnum *maAlrtReasonEnums[];
EXTERN MaTknEnum *maSubsStatEnums[];     
EXTERN MaTknEnum *maGuidInfoEnums[];     
EXTERN MaTknEnum *maReqParamEnums[];     
EXTERN MaTknEnum *maCallTypeCritEnums[];     
EXTERN MaTknEnum *maDefCallHandlEnums[];     
EXTERN MaTknEnum *maMatchTypeEnums[];     
EXTERN MaTknEnum *maOBcsmTrigDetPtEnums[];     
EXTERN MaTknEnum *maTBcsmTrigDetPtEnums[];
EXTERN MaTknEnum *maMonModeEnums[];     
EXTERN MaTknEnum *maCallOutComeEnums[];     
EXTERN MaTknEnum *maRufOutcomeEnums[];     
EXTERN MaTknEnum *maNotRchRsnEnums[];     
EXTERN MaTknEnum *maInterroTypeEnums[];     
EXTERN MaTknEnum *maFwdReasonEnums[];     
EXTERN MaTknEnum *maCcbsSubsStatusEnums[];     
EXTERN MaTknEnum *maCancelTypeEnums[];     
EXTERN MaTknEnum *maRptStateEnums[];     
EXTERN MaTknEnum *maNetAccModeEnums[];
#ifdef XWEXT /* xingzhou.xu: paging detect 2006/10/16 */
EXTERN MaTknEnum *maXWExtDetectModeEnums[];     
EXTERN MaTknEnum *maXWExtDetectRsltEnums[];     
#endif

#if (MAP_REL98 || MAP_REL99)

EXTERN MaTknEnum *maLsaOnlyAccessIndEnums[];    
EXTERN MaTknEnum *maGmlcRestEnums[];     
EXTERN MaTknEnum *maNotifcationToMsUsrEnums[];     
EXTERN MaTknEnum *maLcsClientIntIdEnums[];    
EXTERN MaTknEnum *maLocEstiTypeEnums[];
EXTERN MaTknEnum *maLcsClientTypeEnums[];
EXTERN MaTknEnum *maResponseTimeEnums[];
EXTERN MaTknEnum *maPosiMethFailDiagEnums[];
EXTERN MaTknEnum *maUnAuthLcsClientParamEnums[];
EXTERN MaTknEnum *maLcsEventEnums[];
EXTERN MaTknEnum *maExtProtIdEnums[];
EXTERN MaTknEnum *maNmbPortStatEnums[];

#endif /* MAP_REL98 || MAP_REL99 */

#if MAP_REL99

EXTERN MaTknEnum *maSmsTrgDetPtEnums[];     
EXTERN MaTknEnum *maDefSmsHandlEnums[];     
EXTERN MaTknEnum *maGprsTrgDetPtEnums[];     
EXTERN MaTknEnum *maDefGprsHandlEnums[];     
EXTERN MaTknEnum *maFailureCauseEnums[];     
EXTERN MaTknEnum *maCallTermIndEnums[];
EXTERN MaTknEnum *maReqCamSubsInfoEnums[];
EXTERN MaTknEnum *maModificationInstrEnums[];
EXTERN MaTknEnum *maIstSupIndEnums[];
EXTERN MaTknEnum *maAccNetProtIdEnums[];
EXTERN MaTknEnum *maKeyStatusEnums[];
EXTERN MaTknEnum *maCcbsReqStateEnums[];
#if MAP_REL4
EXTERN MaTknEnum *maReqNodeTypeEnums[];
EXTERN MaTknEnum *maTermCauseEnums[];
EXTERN MaTknEnum *maAccessTypeEnums[];
#if MAP_REL5
EXTERN MaTknEnum *maMtSmsTpduTypeEnums[];
EXTERN MaTknEnum *maDomainTypeEnums[];
EXTERN MaTknEnum *maAddReqCamSubsInfoEnums[];
#endif /* MAP_REL5 */
#endif /* MAP_REL4 */
#endif /* MAP_REL99 */

/* token enumerated values for return errors */

EXTERN MaTknEnum *maRoamNotAllCauseEnums[];
EXTERN MaTknEnum *maCallBarrCauseEnums[];
EXTERN MaTknEnum *maCugRejCauseEnums[];
EXTERN MaTknEnum *maPwRegFailCauseEnums[];
EXTERN MaTknEnum *maSMDlvyFailCauseEnums[];
EXTERN MaTknEnum *maAbsSubsRsnEnums[];
EXTERN MaTknEnum *maUnknownSubsDiagEnums[];
EXTERN MaTknEnum *maCugRejectCauseEnums[];
#if MAP_REL99
#if MAP_REL5
EXTERN MaTknEnum *maUnavailCauseEnums[];
#if MAP_REL6
EXTERN MaTknEnum  *maLcsFormatIndEnums[];
EXTERN MaTknEnum  *maPrivacyChkRelActionEnums[];
EXTERN MaTknEnum  *maAreaTypeEnums[];
EXTERN MaTknEnum  *maOccurInfoEnums[];
EXTERN MaTknEnum  *maAddNetResEnums[];
#endif /* MAP_REL6 */
#endif /* MAP_REL5 */
/* ma001.203 : Addition: Adding Operate Type */
#ifdef MAP_CH_PLUS
EXTERN MaTknEnum  *maOperateTypeEnums[];
#endif
#endif /* MAP_REL99 */

/*for xinwei*/
#ifdef XWEXT
EXTERN MaTknEnum *maXWExtUpdateTypeEnums[];
EXTERN MaTknEnum *maXWExtCallOutRigtEnums[];
#endif
/* Generalized define for STRE type */
#define   DEFINE_STRUL(minLen,maxLen,ver,optMand) \
{\
 MA_TET_STRUL,          \
 MA_TAG_OCTSTR,          \
 minLen,              \
 maxLen,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}

/* Generalized define for ENUM type, user function is used */
#define   DEFINE_U_ENUM(ver,optMand,func,enums) \
{\
 MA_TET_U8_ENUM,      \
 MA_TAG_ENUM,         \
 1     ,              \
 1     ,              \
 ver,                 \
 MA_NA,               \
 optMand,             \
 func,                \
 &enums[0],           \
}


/* Generalized define for Tagged ENUM type, user function */
#define   DEFINE_TAG_U_ENUM(tag,ver,optMand,func,enums) \
{\
 MA_TET_U8_ENUM,      \
 tag        ,         \
 1     ,              \
 1     ,              \
 ver,                 \
 MA_NA,               \
 optMand,             \
 func,                \
 &enums[0],           \
}

/* Generalized define for  SEQ type */
#define   DEFINE_U_SEQ(ver,optMand,func) \
{\
 MA_TET_SEQ,          \
 MA_TAG_SEQ,          \
 MA_NA ,              \
 MA_NA ,              \
 ver,                 \
 MA_NA,               \
 optMand,             \
 func,                \
 NULLP,               \
}

/* Generalized define for  SEQ type */
#define   DEFINE_TAG_U_SEQ(tag,ver,optMand,func) \
{\
 MA_TET_SEQ,          \
 tag,                 \
 MA_NA ,              \
 MA_NA ,              \
 ver,                 \
 MA_NA,               \
 optMand,             \
 func,                \
 NULLP,               \
}

/* Generalized define for  STRS type */
#define   DEFINE_U_STRS(minLen,maxLen,ver,optMand,func) \
{\
 MA_TET_STRS,          \
 MA_TAG_OCTSTR,          \
 minLen,              \
 maxLen,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 func,                  \
 NULLP,                \
}

/* Generalized define for Tagged STRS type */
#define   DEFINE_TAG_U_STRS(tag,minLen,maxLen,ver,optMand,func) \
{\
 MA_TET_STRS,          \
 tag,                  \
 minLen,               \
 maxLen,               \
 ver,                  \
 MA_NA,                \
 optMand,              \
 func,                 \
 NULLP,                \
}

/* Generalized define for SEQOF type */
#define   DEFINE_U_SEQOF(ver,size,optMand,func) \
{\
 MA_TET_SEQ_OF,          \
 MA_TAG_SEQ,          \
 MA_NA ,              \
 MA_NA ,              \
 ver,                  \
 size,                  \
 optMand,  \
 func,                  \
 NULLP,                \
}

#define   DEFINE_TAG_MINSEQOF(tag,ver,min,max,optMand,func) \
{\
 MA_TET_SEQ,          \
 tag,                 \
 min ,                \
 MA_NA ,              \
 ver,                 \
 max,                \
 optMand,             \
 func,                \
 NULLP,               \
}

/* Generalized define for Tagged STRE type */
#define   DEFINE_TAG_STRE(tag,minLen,maxLen,ver,optMand) \
{\
 MA_TET_STRE,\
 tag        ,\
 minLen     ,\
 maxLen,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}

/* Generalized define for Tagged STRS type */
#define   DEFINE_TAG_STRS(tag,minLen,maxLen,ver,optMand) \
{\
 MA_TET_STRS,          \
 tag          ,          \
 minLen,              \
 maxLen,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}
/* Generalized define for Tagged U8   type */
#define   DEFINE_TAG_U8(tag,ver,optMand) \
{\
 MA_TET_U8,          \
 tag          ,          \
 1     ,              \
 1     ,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}

/* Generalized define for Tagged NULL type */
#define   DEFINE_TAG_NULL(tag,ver,optMand) \
{\
 MA_TET_NULL, \
 tag        ,            \
 0     ,              \
 0     ,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,           \
}
/* Generalized define for Tagged ENUM type */
#define   DEFINE_TAG_ENUM(tag,ver,optMand,enums) \
{\
 MA_TET_U8_ENUM, \
 tag        ,            \
 1     ,              \
 1     ,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 &enums[0],           \
}
/* Generalized define for Tagged INT  type */
#define   DEFINE_TAG_INT(tag,minLen,maxLen,ver,optMand) \
{\
 MA_TET_INT,          \
 tag,                 \
 minLen,              \
 maxLen,              \
 ver,                 \
 MA_NA,               \
 optMand,             \
 NULLP,               \
 NULLP,               \
}
/* Generalized define for Tagged BOOLEAN type */
#define   DEFINE_TAG_BOOL(tag,ver,optMand) \
{\
 MA_TET_U8  ,          \
 tag          ,          \
 1     ,              \
 1     ,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}
/* Generalized define for Tagged BITSTR type */
#define   DEFINE_TAG_BITSTR(tag,minLen,maxLen,ver,optMand) \
{\
 MA_TET_BITSTR,          \
 tag          ,          \
 minLen,              \
 maxLen,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}

#if MAP_REL99
#if MAP_REL4
#define   DEFINE_TAG_U_BITSTR(tag,minLen,maxLen,ver,optMand,func) \
{\
 MA_TET_BITSTR,          \
 tag          ,          \
 minLen,              \
 maxLen,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 func,                  \
 NULLP,                \
}
#endif
#endif

/* Generalized define for Choice   type */
#define   DEFINE_TAG_CHOICE(size,tag,ver,optMand) \
{\
 MA_TET_CHOICE,          \
 tag   ,                 \
 MA_NA ,              \
 size  ,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}
/* Generalized define for Tagged SEQ  type */
#define   DEFINE_TAG_SEQ(tag,ver,optMand) \
{\
 MA_TET_SEQ,          \
 tag          ,          \
 MA_NA ,              \
 MA_NA ,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}
/* Generalized define for Tagged SEQOF type */
#define   DEFINE_TAG_SEQOF(tag,ver,size,optMand) \
{\
 MA_TET_SEQ_OF,          \
 tag       ,          \
 MA_NA ,              \
 MA_NA ,              \
 ver,                  \
 size,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}

/* Generalized define for  SEQ type */
#define   DEFINE_TAG_U_SEQOF(tag,ver,size,optMand,func) \
{\
 MA_TET_SEQ_OF,       \
 tag,                 \
 MA_NA ,              \
 MA_NA ,              \
 ver,                 \
 size,                \
 optMand,             \
 func,                \
 NULLP,               \
}

/* Generalized define for STRE type */
#define   DEFINE_STRE(minLen,maxLen,ver,optMand) \
{\
 MA_TET_STRE,          \
 MA_TAG_OCTSTR,          \
 minLen,              \
 maxLen,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}
/* Generalized define for  STRS type */
#define   DEFINE_STRS(minLen,maxLen,ver,optMand) \
{\
 MA_TET_STRS,          \
 MA_TAG_OCTSTR,          \
 minLen,              \
 maxLen,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}
#ifdef XWEXT
/* Generalized define for  STR12 type */
#define   DEFINE_STR4(minLen,maxLen,ver,optMand) \
{\
 MA_TET_STR4,          \
 MA_TAG_OCTSTR,          \
 minLen,              \
 maxLen,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}

/* Generalized define for  STR12 type */
#define   DEFINE_TAG_STR4(tag,minLen,maxLen,ver,optMand) \
{\
 MA_TET_STR4,          \
 tag,          \
 minLen,              \
 maxLen,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}
#endif

/* Generalized define for OBJECT ID type */
#define   DEFINE_OBJID(minLen,maxLen,ver,optMand, func) \
{\
 MA_TET_STRS,           \
 MA_TAG_OBJID,          \
 minLen,              \
 maxLen,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 func,                \
 NULLP,                \
}

/* Generalized define for  U8 type */
#define   DEFINE_U8(ver,optMand) \
{\
 MA_TET_U8,              \
 MA_TAG_OCTSTR,          \
 1     ,              \
 1     ,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}
/* Generalized define for NULL type */
#define   DEFINE_NULL(ver,optMand) \
{\
 MA_TET_NULL, \
 MA_TAG_NULL,            \
 0     ,              \
 0     ,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,           \
}

/* Generalized define for  ENUM type */
#define   DEFINE_ENUM(ver,optMand,enums) \
{\
 MA_TET_U8_ENUM, \
 MA_TAG_ENUM,            \
 1     ,              \
 1     ,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 &enums[0],           \
}
/* Generalized define for  INT type */
#define   DEFINE_INT(minLen,maxLen,ver,optMand) \
{\
 MA_TET_INT,          \
 MA_TAG_INTEGER,      \
 minLen,              \
 maxLen,              \
 ver,                 \
 MA_NA,               \
 optMand,             \
 NULLP,               \
 NULLP,               \
}
/* Generalized define for  BOOL type */
#define   DEFINE_BOOL(ver,optMand) \
{\
 MA_TET_U8  ,          \
 MA_TAG_BOOL  ,          \
 1     ,              \
 1     ,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}
/* Generalized define for  BITSTR type */
#define   DEFINE_BITSTR(minLen,maxLen,ver,optMand) \
{\
 MA_TET_BITSTR,          \
 MA_TAG_BITSTR,          \
 minLen,              \
 maxLen,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}
/* Generalized define for Choice   type */
#define   DEFINE_CHOICE(size,ver,optMand) \
{\
 MA_TET_CHOICE,          \
 MA_TAG_NA   ,          \
 MA_NA ,              \
 size  ,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}
/* Generalized define for  SEQ type */
#define   DEFINE_SEQ(ver,optMand) \
{\
 MA_TET_SEQ,          \
 MA_TAG_SEQ   ,          \
 MA_NA ,              \
 MA_NA ,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}
/* Generalized define for SEQOF type */
#define   DEFINE_SEQOF(ver,size,optMand) \
{\
 MA_TET_SEQ_OF,          \
 MA_TAG_SEQ,          \
 MA_NA ,              \
 MA_NA ,              \
 ver,                  \
 size,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}

PRIVATE MaTknElmtDef maTeSeqTerm  =  /* Sequence terminator */
{
 MA_TET_SEQ_TERM,         /* Token Element type */
 MA_TAG_NA,               /* tag value */       
 MA_LEN_NA,               /* minimum length */
 MA_LEN_NA,               /* maximum length */
 LMA_VER_ALL,             /* Map version */
 MA_NA,                   /* counter for repeatable elements */
 NULLP,                   /* token defination flags */
 NULLP,                   /* user function */
 NULLP,                   /* list of enumerated values */ 
};

#define   DEFINE_TAG_EXTCONT(tag,ver,optMand) \
{\
 MA_TET_EXT_CONT,          \
 tag          ,          \
 MA_NA ,              \
 MA_NA ,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 NULLP,                  \
 NULLP,                \
}

#ifdef MAP_PHASE2_EXT_MARK
#define   DEFINE_EXTMARK(ver,optMand,func) \
{\
 MA_TET_EXT_MARK,          \
 MA_TAG_NA          ,          \
 MA_NA ,              \
 MA_NA ,              \
 ver,                  \
 MA_NA,                  \
 optMand,  \
 func,                  \
 NULLP,                \
}

 PRIVATE MaTknElmtDef
 maTeExtMark   = DEFINE_EXTMARK(LMA_VER2,MA_TF_VER1AND2_OPT3,maHndlExtMark);
#endif

#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)
 PRIVATE MaTknElmtDef 
 maTeSeqMand   = DEFINE_SEQ(LMA_VER_ALL,MA_TF_ALL_OPT0);

 PRIVATE MaTknElmtDef 
 maTeSeqOpt   = DEFINE_SEQ(LMA_VER_ALL,MA_TF_ALL_OPT7);
#endif /* MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN */ 

 PRIVATE MaTknElmtDef 
 maTeSeqMandVer2P   = DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_MAND);

 PRIVATE MaTknElmtDef 
 maTeSeqOptVer2P   = DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE MaTknElmtDef
 maTeSeqOptVer2PAnd4   = DEFINE_SEQ(LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3);

 PRIVATE MaTknElmtDef
 maTeEcPriExtLst = DEFINE_TAG_SEQOF(MA_TAG_CSCONST0, LMA_VER2P,\
                                    MAT_MAX_NMB_PRI_EXT, MA_TF_VER2P_OPT);
#ifdef XWEXT
 PRIVATE MaTknElmtDef
 maTeEcPriExt = DEFINE_TAG_STR4(MA_TAG_SEQ,0,4,LMA_VER2P,MA_TF_VER2P_OPT);
#else
 PRIVATE MaTknElmtDef
 maTeEcPriExt = DEFINE_TAG_STRE(MA_TAG_SEQ,0,255,LMA_VER2P,MA_TF_VER2P_OPT);
#endif
 PRIVATE MaTknElmtDef
 maTeExtConSeq   = DEFINE_TAG_EXTCONT(MA_TAG_SEQ, LMA_VER2P,MA_TF_VER2P_OPT);

#ifdef XWEXT
 PRIVATE MaTknElmtDef
 maXWPriExtLst = DEFINE_TAG_SEQOF(MA_TAG_CSCONST0, LMA_VER2P,\
                                    MAT_XW_MAX_NMB_PRI_EXT, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maXWExtId = DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,16,LMA_VER1AND2AND2P, MA_TF_VER1AND2AND2P_OPT7);/*ID �ǿ�ѡ��*/

PRIVATE MaTknElmtDef maXWExtType = DEFINE_SEQ(LMA_VER1AND2AND2P, MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtParaChoic = DEFINE_CHOICE(sizeof(MaExtType),LMA_VER1AND2AND2P, MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtDataService = /* dataservice 1 octet string*/
        DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,1,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

/*************location info**********/
PRIVATE MaTknElmtDef maXWExtLoctionSeq= /* loction info sequence*/
        DEFINE_TAG_SEQ(MA_TAG_CSCONST2,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtEbscNumber  =  /* ebsc number octet string (4)*/
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,4,4,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWEbscNumber  =  /* ebsc number octet string (4) for detect*/
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,4,4,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT3);

PRIVATE MaTknElmtDef maXWExtbtsNumber  =  /* bts number octet string (2)*/
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,2,2,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtLai = /* lai 3 octet string*/
        DEFINE_TAG_STRS(MA_TAG_CSPRIM3,3,3,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWLai = /* lai 3 octet string for detect */
        DEFINE_TAG_STRS(MA_TAG_CSPRIM3,3,3,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT3);


/****************centrex group***************/

PRIVATE MaTknElmtDef maXWExtCentrexSeq= /* centrex sequence*/
        DEFINE_TAG_SEQ(MA_TAG_CSCONST3,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtCentrexGroupNumber= /* CentrexGroupNumber 3 octet string;
                                                 * xingzhou.xu: modifie size from 1-3 octet 
                                                 * to 2 octet according to V1.24 2006/09/30*/
        DEFINE_TAG_STRS(MA_TAG_CSPRIM1,2,2,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtCentrexGroupPrefix= /* CentrexGroupPrefix 3 octet string*/
        DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,3,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtCentrexSubsShortNum= /* centrex subscriber short number 3 octet string*/
        DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,3,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtCentrexGroupRight= /* CentrexGroupRight 1 octet string*/
        DEFINE_TAG_STRS(MA_TAG_CSPRIM4,1,1,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

/******************************************************/

PRIVATE MaTknElmtDef maXWExtUpdateType =   /* updatelocation type enum      */
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM4,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7,maXWExtUpdateTypeEnums);

PRIVATE MaTknElmtDef maXWExtAuthType =   /* authtype enum      */
     DEFINE_TAG_U8(MA_TAG_CSPRIM5,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

/************shrink dial number*******************/

PRIVATE MaTknElmtDef maXWExtShrinkDialNumSeqOf= /* shrink dail sequence*/
        DEFINE_TAG_SEQOF(MA_TAG_CSCONST6,LMA_VER1AND2AND2P,MAX_SHRINK_DIAL,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtShrinkDialNumSeq= /* shrink dail sequence*/
        DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtShrinkDialRealNum= /* shrink dail -- real number 1-9 octet string*/
        DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtShrinkDialShrinkNum= /* shrink dail -- shrink number 1-3 octet string*/
        DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,3,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

/**********************************************/

PRIVATE MaTknElmtDef maXWExtPaswdCall= /* password call 1-8 octet string*/
        DEFINE_TAG_STRS(MA_TAG_CSPRIM7,1,8,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtHotlineNum= /* hotline number 1-9 octet string*/
        DEFINE_TAG_STRS(MA_TAG_CSPRIM8,1,9,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtSmartCall= /* smart call service BOOLEAN*/
        DEFINE_TAG_BOOL(MA_TAG_CSPRIM9,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtUtType= /* hotline number 1-9 octet string*/
        DEFINE_TAG_STRS(MA_TAG_CSPRIM10,2,2,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWUtType= /* hotline number 1-9 octet string for detect */
        DEFINE_TAG_STRS(MA_TAG_CSPRIM10,2,2,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT3);

PRIVATE MaTknElmtDef maXWExtUid= /* UID 2 octet string*/
        DEFINE_TAG_STRS(MA_TAG_CSPRIM11,4,4,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWUid= /* UID 2 octet stringfor detect */
        DEFINE_TAG_STRS(MA_TAG_CSPRIM11,4,4,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT3);

PRIVATE MaTknElmtDef maXWExtHoNum= /* handover number 1-9 octet string*/
        DEFINE_TAG_STRS(MA_TAG_CSPRIM12,1,9,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtInsrtInd= /* insert data indication BOOLEAN*/
        DEFINE_TAG_BOOL(MA_TAG_CSPRIM13,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtUpdateInd= /* update location indication BOOLEAN*/
        DEFINE_TAG_U8(MA_TAG_CSPRIM14,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtIsOriginating= /* if O updatelocation BOOLEAN*/
        DEFINE_TAG_U8(MA_TAG_CSPRIM15,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtCallingNumber= /* update location indication BOOLEAN*/
        DEFINE_TAG_STRS(MA_TAG_CSPRIM16,1,9,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtNumber= /* update location indication BOOLEAN*/
        DEFINE_STRS(1,9,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtRestrictNumSeqof= /* update location indication BOOLEAN*/
        DEFINE_TAG_SEQOF(MA_TAG_CSCONST17,LMA_VER1AND2AND2P,10,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtCallOutNumSeqof= /* update location indication BOOLEAN*/
        DEFINE_TAG_SEQOF(MA_TAG_CSCONST18,LMA_VER1AND2AND2P,10,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maXWExtCallOutRigt =   /* call out right enum      */
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM19,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7,maXWExtCallOutRigtEnums);


#define DEFINE_XW_EXTCONT_SEQ(seqHeader)      		\
  seqHeader,            /*SQUENCE*/                   		\
     &maXWPriExtLst,/*SEQUENCEOF*/                    	\
        &maXWExtType,   /*SEQUENCE*/                   	\
           &maXWExtId,    /*ID*/						\
           &maXWExtParaChoic, /*PARAMETER 	CHOICE*/\
              &maXWExtDataService,					\
              &maXWExtLoctionSeq,					\
                 &maXWExtEbscNumber,				\
                 &maXWExtbtsNumber,					\
                 &maXWExtLai,							\
              &maTeSeqTerm,							\
              &maXWExtCentrexSeq,					\
                  &maXWExtCentrexGroupNumber,		\
/*                &maXWExtCentrexGroupPrefix,	   //xingzhou.xu: deleted according to V1.23  2006/09/30 \ */\
                  &maXWExtCentrexSubsShortNum,		\
                  &maXWExtCentrexGroupRight,			\
              &maTeSeqTerm,							\
              &maXWExtUpdateType,					\
              &maXWExtAuthType,						\
              &maXWExtShrinkDialNumSeqOf,			\
                 &maXWExtShrinkDialNumSeq,				\
			           &maXWExtShrinkDialShrinkNum,		\
			           &maXWExtShrinkDialRealNum,			\
		           &maTeSeqTerm,							\
		        &maTeSeqTerm,							\
              &maXWExtPaswdCall,                                \
              &maXWExtHotlineNum,					\
              &maXWExtSmartCall,					\
              &maXWExtUtType,						\
              &maXWExtUid,							\
              &maXWExtHoNum,						\
              &maXWExtInsrtInd,						\
              &maXWExtUpdateInd,					\
              &maXWExtIsOriginating,					\
              &maXWExtCallingNumber,				\
              &maXWExtRestrictNumSeqof,				\
                   &maXWExtNumber,					\
              &maTeSeqTerm,							\
              &maXWExtCallOutNumSeqof,				\
                   &maXWExtNumber,					\
              &maTeSeqTerm,							\
              &maXWExtCallOutRigt,					\
              &maXWExtHotlineNum,					\
           &maTeSeqTerm,							\
        &maTeSeqTerm,								\
     &maTeSeqTerm,                          				\
  &maTeSeqTerm

#endif

#define DEFINE_EXTCONT_SEQ(seqHeader)      \
  seqHeader,                               \
     &maTeEcPriExtLst,                      \
        &maTeEcPriExt,                      \
     &maTeSeqTerm,                          \
  &maTeSeqTerm

#define maTeExtContSeq    DEFINE_EXTCONT_SEQ(maTeExtConSeq)

/* Since Extension Container is defined to be a sequence */

 PRIVATE MaTknElmtDef
 maTeExtCon   = DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)
 PRIVATE MaTknElmtDef
 maTeExtCon0   = DEFINE_TAG_EXTCONT(MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN */

 PRIVATE MaTknElmtDef
 maTeExtCon1   = DEFINE_TAG_EXTCONT(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE MaTknElmtDef
 maTeExtCon2   = DEFINE_TAG_EXTCONT(MA_TAG_CSCONST2,LMA_VER2P,MA_TF_VER2P_OPT);
/* ma008.203 : Gaurded Under Flag to Remove Warning */
#if ((MAP_MSC && MAP_REL99 )|| MAP_VLR || MAP_HLR || MAP_GSN)
 PRIVATE MaTknElmtDef
 maTeExtCon3   = DEFINE_TAG_EXTCONT(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN */

 PRIVATE MaTknElmtDef
 maTeExtCon4   = DEFINE_TAG_EXTCONT(MA_TAG_CSCONST4,LMA_VER2P,MA_TF_VER2P_OPT);
/* ma008.203 : Gaurded under Flag to remove Warning */
#if ((MAP_MSC && MAP_REL99) || MAP_VLR || MAP_HLR || MAP_GSN || MAP_MLC && MAP_REL5)
 PRIVATE MaTknElmtDef
 maTeExtCon5   = DEFINE_TAG_EXTCONT(MA_TAG_CSCONST5,LMA_VER2P,MA_TF_VER2P_OPT);
#endif
#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)
 PRIVATE MaTknElmtDef
 maTeExtCon6   = DEFINE_TAG_EXTCONT(MA_TAG_CSCONST6,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN */
/* ma008.203 : Gaurded under flag to remove warning */
#if(MAP_MLC && !(MAP_REL99 || MAP_REL4 || MAP_REL5 || MAP_REL6) || MAP_MSC || MAP_VLR|| MAP_HLR || MAP_GSN)
 PRIVATE MaTknElmtDef
 maTeExtCon7   = DEFINE_TAG_EXTCONT(MA_TAG_CSCONST7,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL99 && MAP_REL4 && MAP_GSN))
 PRIVATE MaTknElmtDef
 maTeExtCon8   = DEFINE_TAG_EXTCONT(MA_TAG_CSCONST8,LMA_VER2P,MA_TF_VER2P_OPT);
#endif
#endif
/* ma008.203 : Added MSC and REL5  flag to remove warning */
/*#if (MAP_VLR || MAP_HLR || MAP_GSN)*/
#if ((MAP_MSC && MAP_REL5)|| MAP_VLR || MAP_HLR || MAP_GSN)
PRIVATE MaTknElmtDef
 maTeExtCon9   = DEFINE_TAG_EXTCONT(MA_TAG_CSCONST9,LMA_VER2P,MA_TF_VER2P_OPT);
#endif 

#if (MAP_VLR || MAP_HLR)
 PRIVATE MaTknElmtDef
 maTeExtCon11   = DEFINE_TAG_EXTCONT(MA_TAG_CSCONST11,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#if (MAP_MSC || MAP_HLR)
 PRIVATE MaTknElmtDef
 maTeExtCon13   = DEFINE_TAG_EXTCONT(MA_TAG_CSCONST13,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#if (MAP_VLR || MAP_HLR || MAP_GSN)
 PRIVATE MaTknElmtDef
 maTeExtCon14   = DEFINE_TAG_EXTCONT(MA_TAG_CSCONST14,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE MaTknElmtDef
 maTeExtCon21   = DEFINE_TAG_EXTCONT(MA_TAG_CSCONST21,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#if MAP_REL99
#if MAP_REL5
 PRIVATE MaTknElmtDef
 maTeExtCon17   = DEFINE_TAG_EXTCONT(MA_TAG_CSCONST17,LMA_VER2P,MA_TF_VER2P_OPT);
#endif
#endif

#ifdef XWEXT
#define maXWExtCont    DEFINE_XW_EXTCONT_SEQ(maTeExtCon)
#define maXWExtCont0   DEFINE_XW_EXTCONT_SEQ(maTeExtCon0)
#define maXWExtCont1   DEFINE_XW_EXTCONT_SEQ(maTeExtCon1)
#define maXWExtCont2   DEFINE_XW_EXTCONT_SEQ(maTeExtCon2)
#define maXWExtCont3   DEFINE_XW_EXTCONT_SEQ(maTeExtCon3)
#define maXWExtCont4   DEFINE_XW_EXTCONT_SEQ(maTeExtCon4)
#define maXWExtCont5   DEFINE_XW_EXTCONT_SEQ(maTeExtCon5)
#define maXWExtCont6   DEFINE_XW_EXTCONT_SEQ(maTeExtCon6)
#define maXWExtCont7   DEFINE_XW_EXTCONT_SEQ(maTeExtCon7)
#define maXWExtCont8   DEFINE_XW_EXTCONT_SEQ(maTeExtCon8)
#define maXWExtCont9   DEFINE_XW_EXTCONT_SEQ(maTeExtCon9)
#define maXWExtCont11  DEFINE_XW_EXTCONT_SEQ(maTeExtCon11)
#define maXWExtCont13  DEFINE_XW_EXTCONT_SEQ(maTeExtCon13)
#define maXWExtCont14  DEFINE_XW_EXTCONT_SEQ(maTeExtCon14)
#if MAP_REL99
#if MAP_REL5
#define maXWExtCont17  DEFINE_XW_EXTCONT_SEQ(maTeExtCon17)
#endif
#endif
#define maXWExtCont21  DEFINE_XW_EXTCONT_SEQ(maTeExtCon21)
#endif /*XWEXT*/

#define maTeExtCont    DEFINE_EXTCONT_SEQ(maTeExtCon)
#define maTeExtCont0   DEFINE_EXTCONT_SEQ(maTeExtCon0)
#define maTeExtCont1   DEFINE_EXTCONT_SEQ(maTeExtCon1)
#define maTeExtCont2   DEFINE_EXTCONT_SEQ(maTeExtCon2)
#define maTeExtCont3   DEFINE_EXTCONT_SEQ(maTeExtCon3)
#define maTeExtCont4   DEFINE_EXTCONT_SEQ(maTeExtCon4)
#define maTeExtCont5   DEFINE_EXTCONT_SEQ(maTeExtCon5)
#define maTeExtCont6   DEFINE_EXTCONT_SEQ(maTeExtCon6)
#define maTeExtCont7   DEFINE_EXTCONT_SEQ(maTeExtCon7)
#define maTeExtCont8   DEFINE_EXTCONT_SEQ(maTeExtCon8)
#define maTeExtCont9   DEFINE_EXTCONT_SEQ(maTeExtCon9)
#define maTeExtCont11  DEFINE_EXTCONT_SEQ(maTeExtCon11)
#define maTeExtCont13  DEFINE_EXTCONT_SEQ(maTeExtCon13)
#define maTeExtCont14  DEFINE_EXTCONT_SEQ(maTeExtCon14)
#if MAP_REL99
#if MAP_REL5
#define maTeExtCont17  DEFINE_EXTCONT_SEQ(maTeExtCon17)
#endif
#endif
#define maTeExtCont21  DEFINE_EXTCONT_SEQ(maTeExtCon21)

/* ma008.203 : MAP_REL4 flag is added to remove warning */
#if (MAP_MSC || MAP_MLC ||  (MAP_GSN && MAP_REL4) )
/* SLR Arg extension container introduced in SLR message in place of extension container in REL 5 */
#if (MAP_REL99  || MAP_REL4 || MAP_REL5 || MAP_REL6) 
 PRIVATE MaTknElmtDef
 maTeSlrArgExtCont7   = DEFINE_TAG_EXTCONT(MA_TAG_CSCONST7,LMA_VER2P,MA_TF_VER2P_OPT);



PRIVATE MaTknElmtDef maTeSlrNaEsrkReq =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE MaTknElmtDef
 maTeSlrArgPcsExtSeq   = DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_OPT);
#define DEFINE_SLR_ARG_EXTCONT_SEQ(seqHeader)     \
  seqHeader,                            \
     &maTeEcPriExtLst,                  \
        &maTeEcPriExt,                  \
     &maTeSeqTerm,                      \
     &maTeSlrArgPcsExtSeq,              \
        &maTeSlrNaEsrkReq,              \
     &maTeSeqTerm,                      \
  &maTeSeqTerm

#define maTeSlrArgExtCont7   DEFINE_SLR_ARG_EXTCONT_SEQ(maTeSlrArgExtCont7)
#endif /* MAP_REL99 || MAP_REL4 || MAP_REL5 || MAP_REL6 */

#endif /* MAP_MSC */
/* Since Extension Container is defined to be a sequence */
/* ma008.203 : Gaurded under Flag to remove warning */
#if (MAP_MSC || (MAP_HLR && MAP_REL4) || (MAP_GSN && MAP_REL4))
 PRIVATE MaTknElmtDef maTeExt4Con3   = 
         DEFINE_TAG_SEQ(MA_TAG_CSCONST3,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3);
#endif
 PRIVATE MaTknElmtDef maTeEcPri4ExtLst = 
         DEFINE_TAG_SEQOF(MA_TAG_CSCONST0, LMA_VER2PAND4,
                          MAT_MAX_NMB_PRI_EXT, MA_TF_VER2PAND4_OPT3);
#ifndef XWEXT 
 PRIVATE MaTknElmtDef maTeEcPri4Ext    = 
         DEFINE_STRE(0, 255, LMA_VER2PAND4, MA_TF_VER2PAND4_OPT3);
#else
 PRIVATE MaTknElmtDef maTeEcPri4Ext    = 
         DEFINE_STR4(0, 255, LMA_VER2PAND4, MA_TF_VER2PAND4_OPT3);
#endif

 PRIVATE MaTknElmtDef maTeExt4Con    = 
         DEFINE_SEQ(LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3);

/* ma002.203:Guarded with flag to remove warning */
#if MAP_MSC
 PRIVATE MaTknElmtDef maTeExt4Con0   = 
         DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3);

 PRIVATE MaTknElmtDef maTeExt4Con2   = 
         DEFINE_TAG_SEQ(MA_TAG_CSCONST2,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3);

 PRIVATE MaTknElmtDef maTeExt4Con7   = 
         DEFINE_TAG_SEQ(MA_TAG_CSCONST7,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3);

#if MAP_REL5
 PRIVATE MaTknElmtDef maTeExt4Con4   = 
         DEFINE_TAG_SEQ(MA_TAG_CSCONST4,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3);
#endif
#endif /* MAP_MSC */

#define DEFINE_EXT4CONT_SEQ(seqHeader)      \
  seqHeader,                               \
     &maTeEcPri4ExtLst,                      \
        &maTeEcPri4Ext,                      \
     &maTeSeqTerm,                          \
  &maTeSeqTerm

#define maTeExt4Cont    DEFINE_EXT4CONT_SEQ(maTeExt4Con)
#define maTeExt4Cont0   DEFINE_EXT4CONT_SEQ(maTeExt4Con0)
#define maTeExt4Cont2   DEFINE_EXT4CONT_SEQ(maTeExt4Con2)
#define maTeExt4Cont3   DEFINE_EXT4CONT_SEQ(maTeExt4Con3)
#define maTeExt4Cont7   DEFINE_EXT4CONT_SEQ(maTeExt4Con7)
#if MAP_REL5
#define maTeExt4Cont4   DEFINE_EXT4CONT_SEQ(maTeExt4Con4)
#endif

/* ReqInfo, sequence */            
/*****************************/
#if (MAP_VLR || MAP_HLR || MAP_GSN || MAP_MLC)
/*  Modification, enable ReqInfo for REL5 GSN */
#if (MAP_VLR || MAP_HLR || MAP_MLC || (MAP_GSN && MAP_REL5))
 PRIVATE MaTknElmtDef 
 maTeRiLocInfo   = DEFINE_TAG_NULL(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE MaTknElmtDef 
 maTeRiSubsState = DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);
#endif  /* (MAP_VLR || MAP_HLR || MAP_MLC || (MAP_GSN && MAP_REL5)) */
#endif

#if MAP_REL99     
#else

#define DEFINE_REQINFO_SEQ(SeqHeader)       \
 &SeqHeader,                                \
    &maTeRiLocInfo,                         \
    &maTeRiSubsState,                       \
    &maTeExtCont2,                          \
 &maTeSeqTerm      

#endif
#if MAP_REL99          

/*  Modification, enable ReqInfo for REL5 GSN */
#if (MAP_VLR || MAP_HLR || MAP_MLC || (MAP_GSN && MAP_REL5))
 PRIVATE MaTknElmtDef 
 maTeRiCurLoc   = DEFINE_TAG_NULL(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_OPT);
#endif  /* (MAP_VLR || MAP_HLR || MAP_MLC || (MAP_GSN && MAP_REL5)) */

#if MAP_REL5
#if (MAP_VLR || MAP_HLR || MAP_GSN || MAP_MLC)
PRIVATE MaTknElmtDef maTeRiReqDomain = 
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM4,LMA_VER2P,MA_TF_VER2P_OPT,
                       maChkDomainType, maDomainTypeEnums);

PRIVATE MaTknElmtDef maTeRiImei = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM6,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRiMsClassMark = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM5,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRiMnpReqInfo =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM7,LMA_VER2P,MA_TF_VER2P_OPT);
#endif  /* (MAP_VLR || MAP_HLR || MAP_MLC || (MAP_GSN ) */

#define DEFINE_REQINFO_SEQ(SeqHeader)       \
 &SeqHeader,                                \
    &maTeRiLocInfo,                         \
    &maTeRiSubsState,                       \
    &maTeExtCont2,                          \
    &maTeRiCurLoc,                          \
    &maTeRiReqDomain,                       \
    &maTeRiImei,                            \
    &maTeRiMsClassMark,                     \
    &maTeRiMnpReqInfo,                     \
&maTeSeqTerm      
#else /* MAP_REL5 */
#define DEFINE_REQINFO_SEQ(SeqHeader)       \
 &SeqHeader,                                \
    &maTeRiLocInfo,                         \
    &maTeRiSubsState,                       \
    &maTeExtCont2,                          \
    &maTeRiCurLoc,                          \
&maTeSeqTerm      
#endif /* MAP_REL5 */

#endif /* MAP_REL99 */

/* Subscriber State     , choice */   
/********************************************/
#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_MLC || (MAP_GSN && MAP_REL5))
 PRIVATE MaTknElmtDef 
 maTeSsAssIdle          = DEFINE_TAG_NULL(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_MAND);

 PRIVATE MaTknElmtDef 
 maTeSsCamBusy          = DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_MAND);

 PRIVATE MaTknElmtDef 
 maTeSsNetDetNotRch     = DEFINE_ENUM(LMA_VER2P,MA_TF_VER2P_MAND,maNotRchRsnEnums);

 PRIVATE MaTknElmtDef 
 maTeSsNotProvFromVlr   = DEFINE_TAG_NULL(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_MAND);
#endif

#define DEFINE_SUBSSTATE_CHOICE(choiceHeader)        \
    &choiceHeader  ,                                 \
       &maTeSsAssIdle,                               \
       &maTeSsCamBusy,                               \
       &maTeSsNetDetNotRch,                          \
       &maTeSsNotProvFromVlr,                        \
    &maTeSeqTerm                                    

/* CellIdOrLai , sequence (313,2+) */         
/***********************************/
#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_MLC || MAP_REL99)
 PRIVATE MaTknElmtDef
 maTeClCellIdFixLen     = DEFINE_TAG_STRS(MA_TAG_CSPRIM0,7,7,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE MaTknElmtDef
 maTeClLaiFixLen        = DEFINE_TAG_STRS(MA_TAG_CSPRIM1,5,5,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#define DEFINE_CELLIDORLAI_CHOICE(choiceHeader)      \
       &choiceHeader           ,                     \
          &maTeClCellIdFixLen,                       \
          &maTeClLaiFixLen,                          \
       &maTeSeqTerm                                 

/* Location Information , sequence */ 
/********************************************/
#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_MLC || MAP_REL99)
 PRIVATE MaTknElmtDef 
 maTeLiAgeOfLocInfo     = DEFINE_INT(0,32767,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE MaTknElmtDef 
 maTeLiGeographicalInfo = DEFINE_TAG_STRS(MA_TAG_CSPRIM0,8,8,LMA_VER2P,MA_TF_VER2P_OPT);
 PRIVATE MaTknElmtDef 
 maTeLiVlrNmb           = DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1, 9,LMA_VER2P,MA_TF_VER2P_OPT);
 PRIVATE MaTknElmtDef 
 maTeLiLocNmb           = DEFINE_TAG_STRS(MA_TAG_CSPRIM2,2,10,LMA_VER2P,MA_TF_VER2P_OPT);
 PRIVATE MaTknElmtDef 
 maTeLiCellIdOrLAIChoice= DEFINE_TAG_CHOICE(sizeof(MaCellIdOrLAI),
                         MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#if MAP_REL99     
#else

#define DEFINE_LOCINFO_SEQ(seqHeader)                         \
    &seqHeader       ,                                        \
       &maTeLiAgeOfLocInfo,                                   \
       &maTeLiGeographicalInfo,                               \
       &maTeLiVlrNmb,                                         \
       &maTeLiLocNmb,                                         \
       DEFINE_CELLIDORLAI_CHOICE(maTeLiCellIdOrLAIChoice),    \
       &maTeExtCont4,                                         \
    &maTeSeqTerm

#endif
#if MAP_REL99          

PRIVATE MaTknElmtDef maTeLiLsaIdentity  =  /* LSA identity */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM5,3,3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeLiMscNmb = /* location info Msc number */
        DEFINE_TAG_STRS(MA_TAG_CSPRIM6,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeLiGeoDetInfo = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM7,10,10,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeLiCurLocRetr = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM8,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeLiSaiPres = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM9,LMA_VER2P,MA_TF_VER2P_OPT);

#define DEFINE_LOCINFO_SEQ(seqHeader)                         \
    &seqHeader       ,                                        \
       &maTeLiAgeOfLocInfo,                                   \
       &maTeLiGeographicalInfo,                               \
       &maTeLiVlrNmb,                                         \
       &maTeLiLocNmb,                                         \
       DEFINE_CELLIDORLAI_CHOICE(maTeLiCellIdOrLAIChoice),    \
       &maTeExtCont4,                                         \
       &maTeLiLsaIdentity,                                    \
       &maTeLiMscNmb,                                         \
       &maTeLiGeoDetInfo,                                     \
       &maTeLiCurLocRetr,                                     \
       &maTeLiSaiPres,                                        \
    &maTeSeqTerm

#endif /* MAP_REL99 */

/* SubsInfo,sequence */         
/******************************/
 
#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_MLC || (MAP_GSN && MAP_REL5))
 PRIVATE MaTknElmtDef 
 maTeSiLocInfoSeq       = DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_OPT);
 PRIVATE MaTknElmtDef 
 maTeSiRspSubsStaChoice = DEFINE_TAG_CHOICE(sizeof(MaSubsState),
                         MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#if MAP_REL99
#if MAP_REL5

PRIVATE MaTknElmtDef maTeLigCellIdOrLAIChoice = 
     DEFINE_TAG_CHOICE(sizeof(MaCellIdOrLAI), MA_TAG_CSCONST0,
                       LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeLigRaIdentity = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,6,6,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeLigGeographicalInfo = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,8,8,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeLigSgsnNmb = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeLigLsaIdentity  = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,3,3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeLigSaiPres = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM6,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeLigGeoDetInfo = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM7,10,10,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeLigCurrLocRet = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM8,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeLigAgeOfLocInfo = 
     DEFINE_TAG_INT(MA_TAG_CSPRIM9, 0,32767,LMA_VER2P,MA_TF_VER2P_OPT);

#define DEFINE_LOC_INFO_GPRS_SEQ(seqHeader) \
 &seqHeader, \
    DEFINE_CELLIDORLAI_CHOICE(maTeLigCellIdOrLAIChoice), \
    &maTeLigRaIdentity, \
    &maTeLigGeographicalInfo, \
    &maTeLigSgsnNmb, \
    &maTeLigLsaIdentity, \
    &maTeExtCont5, \
    &maTeLigSaiPres, \
    &maTeLigGeoDetInfo, \
    &maTeLigCurrLocRet, \
    &maTeLigAgeOfLocInfo, \
 &maTeSeqTerm

#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_MLC || (MAP_GSN && MAP_REL5))
PRIVATE MaTknElmtDef maTePssNotPrvFromSgsn = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePssPsDetached = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePssPsAttaNotRchForPaging = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePssPsAttaRchForPaging = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePciContextId =
     DEFINE_TAG_INT(MA_TAG_CSPRIM0, 1, MAT_MAXNUMOFPDP_CONTEXT,
                    LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTePciPdpContextAct = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePciPdpType = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,2,2,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTePciPdpAddr = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,16,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePciApnSubs = 
     DEFINE_TAG_STRE(MA_TAG_CSPRIM4,2,63,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePciApnInUsed = 
     DEFINE_TAG_STRE(MA_TAG_CSPRIM5,2,63,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePciNsApi = 
     DEFINE_TAG_INT(MA_TAG_CSPRIM6,0,15,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePciTransId = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM7,1,2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePciTeIdForGnAndGp = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM8,4,4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePciTeIdForIu = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM9,4,4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePciGgsnAddr = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM10,5,17,LMA_VER2P,MA_TF_VER2P_OPT); 

PRIVATE MaTknElmtDef maTePciExtQosSubs  = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM11,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePciExtQosReq  = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM12,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePciExtQosNeg  = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM13,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePciChargId  = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM14,4,4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePciChargingChar =
     DEFINE_TAG_STRS(MA_TAG_CSPRIM15,2,2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePciRncAddr = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM16,5,17,LMA_VER2P,MA_TF_VER2P_OPT); 

PRIVATE MaTknElmtDef maTePciExt2QosSubs  = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM18,1,3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePciExt2QosReq  = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM19,1,3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePciExt2QosNeg  = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM20,1,3,LMA_VER2P,MA_TF_VER2P_OPT);

#endif /* MAP_MSC || MAP_VLR || MAP_HLR || MAP_MLC */

#define DEFINE_PDP_CONTEXT_INFO_SEQOF(seqHeader) \
 &seqHeader, \
    &maTeSeqOptVer2P,\
       &maTePciContextId, \
       &maTePciPdpContextAct, \
       &maTePciPdpType, \
       &maTePciPdpAddr, \
       &maTePciApnSubs, \
       &maTePciApnInUsed, \
       &maTePciNsApi, \
       &maTePciTransId, \
       &maTePciTeIdForGnAndGp, \
       &maTePciTeIdForIu, \
       &maTePciGgsnAddr, \
       &maTePciExtQosSubs , \
       &maTePciExtQosReq , \
       &maTePciExtQosNeg , \
       &maTePciChargId , \
       &maTePciChargingChar, \
       &maTePciRncAddr, \
       &maTeExtCont17, \
       &maTePciExt2QosSubs , \
       &maTePciExt2QosReq , \
       &maTePciExt2QosNeg , \
    &maTeSeqTerm,\
 &maTeSeqTerm

PRIVATE MaTknElmtDef maTePsPdpActvNotRchForPaging =
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST4,LMA_VER2P,MAT_MAXNUMOFPDP_CONTEXT,
                      MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePsPdpActvRchForPaging =
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST5,LMA_VER2P,MAT_MAXNUMOFPDP_CONTEXT,
                      MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePsNetDetNotRch = 
     DEFINE_ENUM(LMA_VER2P,MA_TF_VER2P_OPT,maNotRchRsnEnums);

#define DEFINE_PS_SUBS_STATE_CHOICE(choiceHeader) \
       &choiceHeader, \
          &maTePssNotPrvFromSgsn, \
          &maTePssPsDetached, \
          &maTePssPsAttaNotRchForPaging, \
          &maTePssPsAttaRchForPaging, \
          DEFINE_PDP_CONTEXT_INFO_SEQOF(maTePsPdpActvNotRchForPaging), \
          DEFINE_PDP_CONTEXT_INFO_SEQOF(maTePsPdpActvRchForPaging), \
          &maTePsNetDetNotRch, \
       &maTeSeqTerm                                 

PRIVATE MaTknElmtDef maTeSiLocInfoGprsSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSiPsSubsStateChoice = 
     DEFINE_TAG_CHOICE(sizeof(MaPsSubsState), MA_TAG_CSCONST4, LMA_VER2P,
                       MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSiIMEI = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM5, 8,8,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSiMsClassMark2 = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM6, 3,3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSiGprsMsClassSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST7,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSiGmcMsNetCap = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0, 1,8,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeSiGmcMsRadioAccCap = 
     DEFINE_TAG_STRE(MA_TAG_CSPRIM1, 1,50,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSiMnpInfoResSeq =
     DEFINE_TAG_SEQ(MA_TAG_CSCONST8,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSiMirRoutNmb =  /* Routeing Number */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,5,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSiMirImsi = /* Imsi */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,3,8,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSiMirMsIsdn = /* MSISDN */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSiMirNmbPortStatus = /* Number Portability Status */
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_OPT,maChkNmbPortStatus,maNmbPortStatEnums);


#define DEFINE_SUBSINFO_SEQ(seqHeader)              \
 &seqHeader       ,                                 \
    DEFINE_LOCINFO_SEQ(maTeSiLocInfoSeq),            \
    DEFINE_SUBSSTATE_CHOICE(maTeSiRspSubsStaChoice),\
    &maTeExtCont2,  \
    DEFINE_LOC_INFO_GPRS_SEQ(maTeSiLocInfoGprsSeq), \
    DEFINE_PS_SUBS_STATE_CHOICE(maTeSiPsSubsStateChoice), \
    &maTeSiIMEI, \
    &maTeSiMsClassMark2, \
    &maTeSiGprsMsClassSeq, \
       &maTeSiGmcMsNetCap, \
       &maTeSiGmcMsRadioAccCap, \
    &maTeSeqTerm, \
    &maTeSiMnpInfoResSeq, \
       &maTeSiMirRoutNmb, \
       &maTeSiMirImsi, \
       &maTeSiMirMsIsdn, \
       &maTeSiMirNmbPortStatus, \
       &maTeExtCont4, \
    &maTeSeqTerm, \
 &maTeSeqTerm
#else /* MAP_REL5 */
#define DEFINE_SUBSINFO_SEQ(seqHeader)              \
 &seqHeader       ,                                 \
    DEFINE_LOCINFO_SEQ(maTeSiLocInfoSeq),            \
    DEFINE_SUBSSTATE_CHOICE(maTeSiRspSubsStaChoice),\
    &maTeExtCont2,                                  \
 &maTeSeqTerm
#endif /* MAP_REL5 */
#else /* MAP_REL99 */
#define DEFINE_SUBSINFO_SEQ(seqHeader)              \
 &seqHeader       ,                                 \
    DEFINE_LOCINFO_SEQ(maTeSiLocInfoSeq),            \
    DEFINE_SUBSSTATE_CHOICE(maTeSiRspSubsStaChoice),\
    &maTeExtCont2,                                  \
 &maTeSeqTerm
#endif /* MAP_REL99 */

/* subsId, Choice */                
/***************************/
  
#if (MAP_HLR || MAP_MLC)
 PRIVATE MaTknElmtDef 
 maTeSubsIdImsi        = DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER2P,MA_TF_VER2P_MAND);
 PRIVATE MaTknElmtDef 
 maTeSubsIdMsIsdn      = DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER2P,MA_TF_VER2P_MAND);
#endif

#define DEFINE_SUBSID_CHOICE(choiceHeader)    \
 &choiceHeader       ,                        \
    &maTeSubsIdImsi,                              \
    &maTeSubsIdMsIsdn,                            \
 &maTeSeqTerm                      


/* Choice Ext-BasicService Code (313,2+) */ 
/* ma008.203 : and with MA_SGSN_SPECIFIC to remove warning */ 
#if (MAP_MSC || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
 PRIVATE MaTknElmtDef 
 maTeEbscExtBearServ = DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,5,LMA_VER2P,MA_TF_VER2P_MAND);
 PRIVATE MaTknElmtDef 
 maTeEbscExtTeleServ = DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,5,LMA_VER2P,MA_TF_VER2P_MAND);
#endif

#define DEFINE_EXT_BSC_CHOICE(choiceHeader)   \
 &choiceHeader             ,                  \
    &maTeEbscExtBearServ,                     \
    &maTeEbscExtTeleServ,                     \
 &maTeSeqTerm

/* FwdData, Sequence */       
/*******************************/

#if (MAP_MSC || MAP_HLR)
 PRIVATE MaTknElmtDef 
 maTeFdFwdToNmb     = DEFINE_TAG_STRS(MA_TAG_CSPRIM5,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE MaTknElmtDef 
 maTeFdFwdToSubAddr = DEFINE_TAG_STRS(MA_TAG_CSPRIM4,1,21,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE MaTknElmtDef 
 maTeFdFwdOpt       = DEFINE_TAG_U8(MA_TAG_CSPRIM6,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#if MAP_REL99    
#else

#ifdef MAP_PHASE2_EXT_MARK
/* Extension marker added here is for structure reuse and **
** is not effective for 2P definitions.                   ** 
*/
#define DEFINE_FWDDATA_SEQ(seqHeader)    \
 &seqHeader        ,                     \
    &maTeFdFwdToNmb,                     \
    &maTeFdFwdToSubAddr,                 \
    &maTeFdFwdOpt,                       \
    &maTeExtMark,                         \
    &maTeExtCont7,                       \
 &maTeSeqTerm
#else
#define DEFINE_FWDDATA_SEQ(seqHeader)    \
 &seqHeader        ,                     \
    &maTeFdFwdToNmb,                     \
    &maTeFdFwdToSubAddr,                 \
    &maTeFdFwdOpt,                       \
    &maTeExtCont7,                       \
 &maTeSeqTerm
#endif

#endif
#if MAP_REL99         

#if (MAP_MSC || MAP_HLR)
 PRIVATE MaTknElmtDef 
 maTeLongFwdedToNmb = DEFINE_TAG_STRS(MA_TAG_CSPRIM8,1,15,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#ifdef MAP_PHASE2_EXT_MARK
/* Extension marker added here is for structure reuse and **
** is not effective for 2P definitions.                   ** 
*/
#define DEFINE_FWDDATA_SEQ(seqHeader)    \
 &seqHeader        ,                     \
    &maTeFdFwdToNmb,                     \
    &maTeFdFwdToSubAddr,                 \
    &maTeFdFwdOpt,                       \
    &maTeExtMark,                         \
    &maTeExtCont7,                       \
    &maTeLongFwdedToNmb,                 \
 &maTeSeqTerm
#else
#define DEFINE_FWDDATA_SEQ(seqHeader)    \
 &seqHeader        ,                     \
    &maTeFdFwdToNmb,                     \
    &maTeFdFwdToSubAddr,                 \
    &maTeFdFwdOpt,                       \
    &maTeExtCont7,                       \
    &maTeLongFwdedToNmb,                 \
 &maTeSeqTerm
#endif

#endif /* MAP_REL99 */

#if MAP_MSC
/* CugChkInfo, Sequence */    
/**********************************/
#if (MAP_REL98 || MAP_REL99)
#else
 PRIVATE MaTknElmtDef 
 maTeCciCugIntLck    = DEFINE_STRS(4,4,LMA_VER2P,MA_TF_VER2P_MAND);
 PRIVATE MaTknElmtDef 
 maTeCciCugOutGngAcc = DEFINE_NULL(LMA_VER2P,MA_TF_VER2P_OPT);

#define DEFINE_CUGCHKINFO_SEQ(seqHeader)   \
 &seqHeader           ,                    \
    &maTeCciCugIntLck,                     \
    &maTeCciCugOutGngAcc,                  \
    &maTeExtCont,                          \
 &maTeSeqTerm          
#endif /* MAP_REL98 || MAP_REL99 */
#endif /* MAP_MSC */

/* DstNmbLst, SequenceOf */ 
/************************************/
/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_MSC || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
 PRIVATE MaTknElmtDef 
 maTeDnlIsdnAddrStr = DEFINE_STRS(1,9,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#define DEFINE_DSTNMB_LST(seqHeader)                   \
                &seqHeader       ,                     \
                   &maTeDnlIsdnAddrStr,                \
                &maTeSeqTerm                           

/* DstNmbLenLst, SequenceOf */ 
/***************************************/
/* ma008.203 : To remove Warning */
#if (MAP_MSC || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
 PRIVATE MaTknElmtDef 
 maTeDnllInt = DEFINE_INT(1, MAT_MAX_ISDN_ADDR_DIGITS,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#define DEFINE_DSTNMBLEN_LST(seqHeader)                 \
                &seqHeader          ,                   \
                   &maTeDnllInt,                        \
                &maTeSeqTerm       

/* DstNmbCrit, Sequence */           
/***********************************/

/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_MSC || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
 PRIVATE MaTknElmtDef 
 maTeDncMatchType = DEFINE_TAG_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_MAND,\
                    maMatchTypeEnums);
 PRIVATE MaTknElmtDef 
 maTeDncDstNmbLst = DEFINE_TAG_SEQOF(MA_TAG_CSCONST1,LMA_VER2P, \
                    MAT_MAX_CAMEL_DEST_NMB, MA_TF_VER2P_OPT);
 PRIVATE MaTknElmtDef 
 maTeDncDstNmbLenLst = DEFINE_TAG_SEQOF(MA_TAG_CSCONST2,LMA_VER2P,\
                       MAT_MAX_CAMEL_DEST_NMB_LEN,MA_TF_VER2P_OPT);
#endif

#define DEFINE_DSTNMBCRIT_SEQ(seqHeader)                    \
             &seqHeader             ,                       \
                &maTeDncMatchType,                          \
                DEFINE_DSTNMB_LST(maTeDncDstNmbLst),        \
                DEFINE_DSTNMBLEN_LST(maTeDncDstNmbLenLst), \
             &maTeSeqTerm

/* BasServCritLst, SequenceOf */            \
/*****************************************/
/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_MSC || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
 PRIVATE MaTknElmtDef 
 maTeBsclExtBasSerCodeChoice = DEFINE_CHOICE(sizeof(MaExtBasServCode),\
                               LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#define DEFINE_BASSERVCRIT_LST(seqHeader)                         \
             &seqHeader              ,                              \
                DEFINE_EXT_BSC_CHOICE(maTeBsclExtBasSerCodeChoice), \
             &maTeSeqTerm

/* O-BcsmCamTdpCrit, Sequence */              
/*****************************************/

/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_MSC || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
 PRIVATE MaTknElmtDef 
 maTeObctcDstNmbCritSeq = DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE MaTknElmtDef 
 maTeObctcBasServCritLst = DEFINE_TAG_SEQOF(MA_TAG_CSCONST1,LMA_VER2P,\
                      MAT_MAX_BASIC_SER_CRIT,MA_TF_VER2P_OPT);
 PRIVATE MaTknElmtDef 
 maTeObctcCallTypeCrit = DEFINE_TAG_ENUM(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT,\
                         maCallTypeCritEnums);
#endif

/* O-BcsmCamTdpDat, Sequence */ 
/****************************************/

/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_MSC || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
 PRIVATE MaTknElmtDef 
 maTeObctdOBcsmTrigDetPt = DEFINE_U_ENUM(LMA_VER2P,MA_TF_VER2P_MAND,maChkOBcsmTrigDetPt,maOBcsmTrigDetPtEnums);
#endif
/* ma008.203 : added MAP_REL99 to remove warning */
#if (MAP_MSC || (MAP_VLR && MAP_REL99) || MAP_HLR || (MAP_GSN && MAP_REL99 && !(MA_SGSN_SPECIFIC) ))
 PRIVATE MaTknElmtDef
 maTeObctdTBcsmTrigDetPt = DEFINE_U_ENUM(LMA_VER2P,MA_TF_VER2P_MAND,
                           maChkTBcsmTrigDetPt,maTBcsmTrigDetPtEnums);
#endif
/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_MSC || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC))||(MAP_GSN && MAP_REL5))
 PRIVATE MaTknElmtDef 
 maTeObctdSerKey = DEFINE_INT(0,2147483647,LMA_VER2P,MA_TF_VER2P_MAND);

 PRIVATE MaTknElmtDef 
 maTeObctdGsmSCFAddr = DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER2P,MA_TF_VER2P_MAND);
#endif
/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_MSC || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
 PRIVATE MaTknElmtDef 
 maTeObctdDefHndl = DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_MAND,maChkDefCallHandl,maDefCallHandlEnums);
#endif

#if MAP_REL99     
#else

#define DEFINE_OBCSMCAMTDPCRIT_SEQ(seqHeader)                      \
          &seqHeader,                                              \
             &maTeObctdOBcsmTrigDetPt,                             \
             DEFINE_DSTNMBCRIT_SEQ(maTeObctcDstNmbCritSeq),        \
             /* BasServCritLst, SequenceOf */                      \
             DEFINE_BASSERVCRIT_LST(maTeObctcBasServCritLst),      \
             &maTeObctcCallTypeCrit,                               \
          &maTeSeqTerm

#endif
#if MAP_REL99          

/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_MSC || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
PRIVATE MaTknElmtDef maTeObctcOCauseValueCritLst  =  /*Cause Value Crit List*/
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST3,LMA_VER2P,MAT_MAXNMB_CAM_OCAUSEVALCRIT,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeOcvcCauseValue  =  /* Cause Value */
     DEFINE_U8(LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#define DEFINE_OBCSMCAMTDPCRIT_SEQ(seqHeader)                      \
          &seqHeader,                                              \
             &maTeObctdOBcsmTrigDetPt,                             \
             DEFINE_DSTNMBCRIT_SEQ(maTeObctcDstNmbCritSeq),        \
             /* BasServCritLst, SequenceOf */                      \
             DEFINE_BASSERVCRIT_LST(maTeObctcBasServCritLst),      \
             &maTeObctcCallTypeCrit,                               \
             &maTeObctcOCauseValueCritLst,                     \
                &maTeOcvcCauseValue,                           \
             &maTeSeqTerm,                                     \
             &maTeExtCont4,                                    \
          &maTeSeqTerm

/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_MSC || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
PRIVATE MaTknElmtDef maTeTbcsmTrigDetPt = 
     DEFINE_U_ENUM(LMA_VER2P,MA_TF_VER2P_MAND,maChkTBcsmTrigDetPt,maTBcsmTrigDetPtEnums);

PRIVATE MaTknElmtDef maTeTbcsmcBasicServCritLst = /*Bsc Serv.Criteria List*/
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST0,LMA_VER2P,MAT_MAX_BASIC_SER_CRIT,MA_TF_VER2P_OPT);

/*TCause ValueCriteria List*/
PRIVATE MaTknElmtDef maTeTbcsmcTCauseValueCritLst = 
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST1,LMA_VER2P,MAT_MAXNMB_CAM_OCAUSEVALCRIT,MA_TF_VER2P_OPT);
#endif

#define DEFINE_TBCSMCAMTDPCRIT_SEQ(seqHeader)                    \
          &seqHeader,                                            \
             &maTeTbcsmTrigDetPt,                                \
             DEFINE_BASSERVCRIT_LST(maTeTbcsmcBasicServCritLst), \
             &maTeTbcsmcTCauseValueCritLst,                      \
                &maTeOcvcCauseValue,                             \
             &maTeSeqTerm,                                       \
          &maTeSeqTerm

#endif /* MAP_REL99 */

/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_MSC || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
PRIVATE MaTknElmtDef maTeObctdOBcsmCamTDPCritSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#define DEFINE_OBCSMCAMTDPDAT_SEQ(seqHeader)   \
       &seqHeader                 ,               \
          &maTeObctdOBcsmTrigDetPt,               \
          &maTeObctdSerKey,                       \
          &maTeObctdGsmSCFAddr,                   \
          &maTeObctdDefHndl,                      \
          &maTeExtCont2,                          \
          DEFINE_OBCSMCAMTDPCRIT_SEQ(maTeObctdOBcsmCamTDPCritSeq),\
       &maTeSeqTerm

#define DEFINE_TBCSMCAMTDPDAT_SEQ(seqHeader)   \
       &seqHeader                 ,               \
          &maTeObctdTBcsmTrigDetPt,               \
          &maTeObctdSerKey,                       \
          &maTeObctdGsmSCFAddr,                   \
          &maTeObctdDefHndl,                      \
          &maTeExtCont2,                          \
       &maTeSeqTerm

/* TBcsmCamTdpDatLst, Sequence Of */              
/********************************************/
/* ma008.203 : Added MAP_REL99 to Remove Warning*/
#if (MAP_MSC || (MAP_VLR && MAP_REL99) || MAP_HLR || (MAP_GSN && MAP_REL99 && !(MA_SGSN_SPECIFIC)))
 PRIVATE MaTknElmtDef maTeTBctdlTBcsmCamTdpDatSeq = 
         DEFINE_U_SEQ(LMA_VER2P,MA_TF_VER2P_OPT, maChkIgnoreSeq);
#endif

#define DEFINE_TBCSMCAMTDPDAT_LST(seqHeader)                 \
    &seqHeader               ,                                 \
       DEFINE_TBCSMCAMTDPDAT_SEQ(maTeTBctdlTBcsmCamTdpDatSeq), \
    &maTeSeqTerm

/* OBcsmCamTdpDatLst, Sequence Of */              
/********************************************/
/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_MSC || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
 PRIVATE MaTknElmtDef maTeOBctdlOBcsmCamTdpDatSeq = 
         DEFINE_U_SEQ(LMA_VER2P,MA_TF_VER2P_OPT, maChkIgnoreSeq);
#endif

#define DEFINE_OBCSMCAMTDPDAT_LST(seqHeader)                 \
    &seqHeader               ,                                 \
       DEFINE_OBCSMCAMTDPDAT_SEQ(maTeOBctdlOBcsmCamTdpDatSeq), \
    &maTeSeqTerm

/* O-CSI, Sequence */     
/*****************************/
/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_MSC || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
 PRIVATE MaTknElmtDef maTeOcsiBcsmCamTdpDatLst = 
  DEFINE_SEQOF(LMA_VER2P,MAT_MAXNUMOF_CAMTDPDATA,MA_TF_VER2P_OPT);

 PRIVATE MaTknElmtDef maTeCamCapHandl = 
 DEFINE_TAG_INT(MA_TAG_CSPRIM0,1,16,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#if MAP_REL99
/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_MSC || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
PRIVATE MaTknElmtDef maTeNotificationToCse  =  /*Notification To CSE */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCsiActive  =  /*Csi Active */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#define DEFINE_OCSI_SEQ(seqHeader)   \
 &seqHeader,                         \
    DEFINE_OBCSMCAMTDPDAT_LST(maTeOcsiBcsmCamTdpDatLst), \
    &maTeExtCont,                    \
    &maTeCamCapHandl,                \
    &maTeNotificationToCse,          \
    &maTeCsiActive,                  \
 &maTeSeqTerm

#else /* MAP_REL99 */

#define DEFINE_OCSI_SEQ(seqHeader)   \
 &seqHeader,                         \
    DEFINE_OBCSMCAMTDPDAT_LST(maTeOcsiBcsmCamTdpDatLst), \
    &maTeExtCont,                    \
    &maTeCamCapHandl,                \
 &maTeSeqTerm

#endif /* MAP_REL99 */

/* T-CSI, Sequence */     
/*****************************/
/* ma008.203 : Added MAP_REL99 to remove Warning */
#if (MAP_MSC || (MAP_VLR && MAP_REL99) || MAP_HLR || (MAP_GSN && MAP_REL99 && !(MA_SGSN_SPECIFIC)))
 PRIVATE MaTknElmtDef maTeTcsiBcsmCamTdpDatLst = 
  DEFINE_SEQOF(LMA_VER2P,MAT_MAXNUMOF_CAMTDPDATA,MA_TF_VER2P_MAND);
#endif

#if MAP_REL99
#define DEFINE_TCSI_SEQ(seqHeader)   \
 &seqHeader,                         \
    DEFINE_TBCSMCAMTDPDAT_LST(maTeTcsiBcsmCamTdpDatLst), \
    &maTeExtCont,                    \
    &maTeCamCapHandl,                \
    &maTeNotificationToCse,          \
    &maTeCsiActive,                  \
 &maTeSeqTerm
#else  /* MAP_REL99 */
#define DEFINE_TCSI_SEQ(seqHeader)   \
 &seqHeader,                         \
    DEFINE_TBCSMCAMTDPDAT_LST(maTeTcsiBcsmCamTdpDatLst), \
    &maTeExtCont,                    \
    &maTeCamCapHandl,                \
 &maTeSeqTerm
#endif /* MAP_REL99 */

/* ExtSigInfo Seq (311,2+) */  
/***************************/
#if (MAP_MSC || MAP_VLR || MAP_HLR)
PRIVATE MaTknElmtDef maTeEsiProtId2P = /* protocol id (mand.) */
     DEFINE_ENUM(LMA_VER2P,MA_TF_VER2P_MAND,maProtIdEnums);

PRIVATE MaTknElmtDef maTeEsiSigInfo2P = /* signal info (mand.) */
     DEFINE_STRE(1,200,LMA_VER2P,MA_TF_VER2P_MAND);
#endif

#ifdef MAP_PHASE2_EXT_MARK
/* Extension marker added here is for structure reuse and **
** is not effective for 2P definitions.                   ** 
*/
#define DEFINE_EXTSIGINFO_SEQ(seqHeader)   \
 &seqHeader,                                 \
    &maTeEsiProtId2P,                         \
    &maTeEsiSigInfo2P,                        \
    &maTeExtMark,                            \
    &maTeExtCont,                             \
 &maTeSeqTerm
#else
#define DEFINE_EXTSIGINFO_SEQ(seqHeader)   \
 &seqHeader,                                 \
    &maTeEsiProtId2P,                         \
    &maTeEsiSigInfo2P,                        \
    &maTeExtCont,                             \
 &maTeSeqTerm
#endif

/* EvtRptDat ,  Seq */          
/*****************************/

#if (MAP_VLR || MAP_HLR)
 PRIVATE MaTknElmtDef maTeErdCcbsSubsStat = 
  DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT,maChkCcbsSubsStatus, maCcbsSubsStatusEnums);
#endif

#define DEFINE_EVTRPTDAT_SEQ(seqHeader)   \
 &seqHeader         ,                     \
    &maTeErdCcbsSubsStat,                 \
    &maTeExtCont1,                        \
 &maTeSeqTerm      

 /* CallRptDat ,  Seq */
 /******************************/

#if (MAP_VLR || MAP_HLR)
 PRIVATE MaTknElmtDef maTeCrdMonMode = 
 DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT,maChkMonMode,maMonModeEnums);
 PRIVATE MaTknElmtDef maTeCrdCallOutcome = 
  DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT,maChkCallOutcome,maCallOutComeEnums);
#endif

#define DEFINE_CALLRPTDAT_SEQ(seqHeader)   \
 &seqHeader          ,\
    &maTeCrdMonMode,\
    &maTeCrdCallOutcome,\
    &maTeExtCont2,\
 &maTeSeqTerm

/* BasicServGrp , BasicServCode Choice (313,2+) */
/************************************************/
#if (MAP_VLR || MAP_HLR)
 PRIVATE MaTknElmtDef 
 maTeBscBearServ = DEFINE_TAG_U8(MA_TAG_CSPRIM2,LMA_VER2AND2P,
                                 MA_TF_VER2AND2P_OPT0);
 PRIVATE MaTknElmtDef 
 maTeBscTeleServ = DEFINE_TAG_U8(MA_TAG_CSPRIM3,LMA_VER2AND2P,
                                 MA_TF_VER2AND2P_OPT0);
#endif

#define DEFINE_BASSERVGRP_CHOICE(choiceHeader)   \
    &choiceHeader            ,\
       &maTeBscBearServ,\
       &maTeBscTeleServ,\
    &maTeSeqTerm 

 /* CcbsFtr ,  Seq */
/*****************************/
#if (MAP_VLR || MAP_HLR)
 PRIVATE MaTknElmtDef 
 maTeCfCcbsIdx = DEFINE_TAG_INT(MA_TAG_CSPRIM0,1,MAT_MAX_CCBSREQ,LMA_VER2AND2P,
                                MA_TF_VER2AND2P_OPT3);
 PRIVATE MaTknElmtDef 
 maTeCfBSubsNmb = DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER2AND2P,
                                  MA_TF_VER2AND2P_OPT3);
 PRIVATE MaTknElmtDef 
 maTeCfBSubsSubAddr = DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,21,LMA_VER2AND2P,
                                      MA_TF_VER2AND2P_OPT3);
 PRIVATE MaTknElmtDef 
 maTeCfBasicServGrpChoice = DEFINE_TAG_CHOICE(sizeof(MaBasicServ),
                      MA_TAG_CSCONST3,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);
#endif

#define DEFINE_CCBSFTR_SEQ(seqHeader)   \
 &seqHeader        ,\
    &maTeCfCcbsIdx, \
    &maTeCfBSubsNmb,\
    &maTeCfBSubsSubAddr,\
    DEFINE_BASSERVGRP_CHOICE(maTeCfBasicServGrpChoice),\
 &maTeSeqTerm

/* CcbsFtr List */
/***********************/

#if (MAP_VLR || MAP_HLR)
PRIVATE MaTknElmtDef maTeCflCcbsFtrSeq =   /* Ccbs Feature Sequence */
     DEFINE_SEQ(LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);
#endif

#define DEFINE_CCBSFTR_LST(seqHeader) \
&seqHeader,\
   DEFINE_CCBSFTR_SEQ(maTeCflCcbsFtrSeq),\
&maTeSeqTerm

 /* CcbsData ,  Seq */
 /****************************/
#if (MAP_VLR || MAP_HLR)
 PRIVATE MaTknElmtDef 
 maTeCdCcbsFtrSeq = DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_MAND);

 PRIVATE MaTknElmtDef 
 maTeCdTransBNmb = DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

 PRIVATE MaTknElmtDef 
 maTeCdServInd = DEFINE_TAG_BITSTR(MA_TAG_CSPRIM2,2,32,LMA_VER2P,
                 MA_TF_VER2P_OPT);

 PRIVATE MaTknElmtDef 
 maTeCdCallInfoSeq = DEFINE_TAG_SEQ(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_MAND);

 PRIVATE MaTknElmtDef 
 maTeCdNetSigInfoSeq = DEFINE_TAG_SEQ(MA_TAG_CSCONST4,LMA_VER2P,MA_TF_VER2P_MAND);

#define DEFINE_CCBSDAT_SEQ(seqHeader)   \
 &seqHeader          ,\
    DEFINE_CCBSFTR_SEQ(maTeCdCcbsFtrSeq),\
    &maTeCdTransBNmb,\
    &maTeCdServInd,\
    DEFINE_EXTSIGINFO_SEQ(maTeCdCallInfoSeq),\
    DEFINE_EXTSIGINFO_SEQ(maTeCdNetSigInfoSeq),\
 &maTeSeqTerm
#endif /* MAP_VLR || MAP_HLR */

 /* EvtSpec  - Sequence of */ 
 /***************************************/
#if (MAP_MSC || MAP_HLR)
 PRIVATE MaTknElmtDef 
 maTeEsAddrStr = DEFINE_STRS(1,20,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#define DEFINE_EVTSPEC_SEQ(seqHeader)      \
 &seqHeader             ,                  \
    &maTeEsAddrStr,                        \
 &maTeSeqTerm

/* Gmsc Camel Subscription Information */
/***************************************/
#if (MAP_MSC || MAP_HLR)
PRIVATE MaTknElmtDef maTeGcsiTcsiSeq =   /* TCSI Sequence         */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeGcsiOcsiSeq =   /* OCSI Sequence         */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeGcsiObcsmCamTdpCritLst = /*ObcsmCamelTDPCriteriaList*/
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST3,LMA_VER2P,MAT_MAXNUMOF_CAMTDPDATA,MA_TF_VER2P_OPT);
#endif

#if MAP_REL99
#else    

#define DEFINE_GMSCCAMSUBSINFO_SEQ(seqHeader)    \
&seqHeader,                                      \
   DEFINE_TCSI_SEQ(maTeGcsiTcsiSeq),             \
   DEFINE_OCSI_SEQ(maTeGcsiOcsiSeq),             \
   &maTeExtCont1,                                \
   &maTeGcsiObcsmCamTdpCritLst,                  \
      DEFINE_OBCSMCAMTDPCRIT_SEQ(maTeOctcObcsmCamTdpCritSeq),\
   &maTeSeqTerm, \
&maTeSeqTerm

#endif 
#if MAP_REL99           

#if (MAP_MSC || MAP_HLR)
PRIVATE MaTknElmtDef maTeGcsiTbcsmCamTdpCritLst = /*ObcsmCamelTDPCriteriaList*/
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST4,LMA_VER2P,MAT_MAXNUMOF_CAMTDPDATA,MA_TF_VER2P_OPT);
#endif

/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_MSC || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
PRIVATE MaTknElmtDef maTeTbcsmCamTdpCritSeq  =  /*Tbcsm Criteria Seq*/
     DEFINE_U_SEQ(LMA_VER2P,MA_TF_VER2P_OPT,maChkIgnoreSeq);
#endif

#if (MAP_MSC || MAP_HLR)
PRIVATE MaTknElmtDef maTeGcsiDCsiSeq  =  /* D-CSI*/
     DEFINE_TAG_SEQ(MA_TAG_CSCONST5,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#define DEFINE_GMSCCAMSUBSINFO_SEQ(seqHeader)    \
&seqHeader,                                      \
   DEFINE_TCSI_SEQ(maTeGcsiTcsiSeq),             \
   DEFINE_OCSI_SEQ(maTeGcsiOcsiSeq),             \
   &maTeExtCont1,                                \
   &maTeGcsiObcsmCamTdpCritLst,                  \
      DEFINE_OBCSMCAMTDPCRIT_SEQ(maTeOctcObcsmCamTdpCritSeq),\
   &maTeSeqTerm, \
   &maTeGcsiTbcsmCamTdpCritLst,                  \
      DEFINE_TBCSMCAMTDPCRIT_SEQ(maTeTbcsmCamTdpCritSeq),\
   &maTeSeqTerm, \
   DEFINE_DCSI_SEQ(maTeGcsiDCsiSeq),\
&maTeSeqTerm

#endif /* MAP_REL99 */

/* Routing Information Sequence        */
/***************************************/

#if (MAP_MSC || MAP_HLR)
PRIVATE MaTknElmtDef maTeRiRoamNmb =   /* Isdn Address String   */
     DEFINE_STRS(1,9,LMA_VER2P,MA_TF_VER2P_MAND); 

PRIVATE MaTknElmtDef maTeRiFwdDataSeq =   /* Forwarding Data Seq   */
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_MAND);
#endif


#define DEFINE_ROUTINFO_CHOICE(choiceHeader)    \
&choiceHeader,                                  \
   &maTeRiRoamNmb,                              \
   DEFINE_FWDDATA_SEQ(maTeRiFwdDataSeq),        \
&maTeSeqTerm


/* Extended Routing Information Choice */
/***************************************/
#if (MAP_MSC || MAP_HLR)
PRIVATE MaTknElmtDef maTeCriFwdDataSeq =   /* Forward Data          */
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCriGmscCamSubsInfoSeq = /* Gmsc Camel Subscription */
    DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_MAND);
#endif


#define DEFINE_CAMROUTINFO_SEQ(seqHeader) \
&seqHeader,                                               \
   DEFINE_FWDDATA_SEQ(maTeCriFwdDataSeq),                 \
   DEFINE_GMSCCAMSUBSINFO_SEQ(maTeCriGmscCamSubsInfoSeq), \
   &maTeExtCont1,                                         \
&maTeSeqTerm


/* Extended Routing Information Choice */
/***************************************/
#if (MAP_MSC || MAP_HLR)
PRIVATE MaTknElmtDef maTeEriRoutInfoChoice =   /* Routing Info Choice   */
     DEFINE_CHOICE(sizeof(MaRouteInfo),LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeEriCamRoutInfoSeq = /* Cam. routing Info Seq*/
     DEFINE_TAG_SEQ(MA_TAG_CSCONST8,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#define DEFINE_EXTROUTINFO_CHOICE(choiceHeader)        \
&choiceHeader,                                         \
   DEFINE_ROUTINFO_CHOICE(maTeEriRoutInfoChoice),      \
   DEFINE_CAMROUTINFO_SEQ(maTeEriCamRoutInfoSeq),   \
&maTeSeqTerm

/* NAEA Preferred CI                   */
/***************************************/
/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_MSC || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
PRIVATE MaTknElmtDef maTeNpcNaeaPrefCic =   /* NAEA Pref CIC         */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,3,LMA_VER2P,MA_TF_VER2P_MAND);
#endif

#if (MAP_VLR || MAP_HLR || MAP_GSN)
#ifndef MA_SGSN_SPECIFIC
PRIVATE MaTknElmtDef maTeIsdNaeaPrefCiSeq = /* Naea Pref. CI Seq*/
     DEFINE_TAG_SEQ(MA_TAG_CSCONST15,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MA_SGSN_SPECIFIC */
#endif


#define DEFINE_NAEAPREFCI_SEQ(seqHeader)        \
&seqHeader,                                     \
   &maTeNpcNaeaPrefCic,                         \
   &maTeExtCont1,                               \
&maTeSeqTerm


/* CCBS Indicators                     */
/***************************************/
#if (MAP_MSC || MAP_HLR)
PRIVATE MaTknElmtDef maTeCindCcbsPsbl =   /* NULL              e   */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCindKeepCcbsCallInd = /* NULL                    */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#define DEFINE_CCBSIND_SEQ(seqHeader)        \
&seqHeader,                                  \
   &maTeCindCcbsPsbl,                        \
   &maTeCindKeepCcbsCallInd,                 \
   &maTeExtCont2,                            \
&maTeSeqTerm
/* SS List                            */
/***************************************/

#if (MAP_MSC || MAP_HLR)
PRIVATE MaTknElmtDef maTeSslSsCode = /* SS code                 */
     DEFINE_U8(LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#define DEFINE_SS_LST(seqHeader)                    \
&seqHeader,                                         \
   &maTeSslSsCode,                                  \
&maTeSeqTerm
/* Camel Info Sequence */
/***********************************/
#if (MAP_MSC || MAP_HLR)
PRIVATE MaTknElmtDef maTeCiSupCamPhases =   /* supported Camel phases*/
     DEFINE_BITSTR(1,16,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeCiSuppTcsi =   /* NULL */
     DEFINE_NULL(LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#if MAP_REL5
/* ma008.203 : MAP_VLR is removed to avoid warning */
#if (MAP_MSC || MAP_HLR)
PRIVATE MaTknElmtDef maTeCiOffCam4CSIs =
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM0,7,16,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#define DEFINE_CAMINFO_SEQ(seqHeader)   \
&seqHeader,                             \
   &maTeCiSupCamPhases,                 \
   &maTeCiSuppTcsi,                     \
   &maTeExtCont,                        \
   &maTeCiOffCam4CSIs,                  \
&maTeSeqTerm
#else
#define DEFINE_CAMINFO_SEQ(seqHeader)   \
&seqHeader,                             \
   &maTeCiSupCamPhases,                 \
   &maTeCiSuppTcsi,                     \
   &maTeExtCont,                        \
&maTeSeqTerm
#endif /* MAP_REL5 */

/* SSInfo    */
/*************/

/* Change for merged structure */

/* FwdFeat List                        */
/***************************************/

#if (MAP_VLR || MAP_HLR || MAP_GSN)
PRIVATE MaTknElmtDef maTeSiFwdInfoSeq =   /* Forward Info Sequence */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeSsiFiSSCode =   /* SS Code               */
     DEFINE_U8(LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeSsiFiFwdFeatSeqOf =   /* Forwarding Feature SeqOf */
     DEFINE_U_SEQOF(LMA_VER1AND2AND2P,MAT_MAX_EXT_BASIC_SERV,MA_TF_VER1AND2AND2P_OPT0, maChkExtSeqOf);

PRIVATE MaTknElmtDef maTeFiFfBasServCodeChoice =   /* Basic Service Code */
     DEFINE_CHOICE(sizeof(MaBasicServ),LMA_VER1AND2,MA_TF_VER1AND2_OPT3);

PRIVATE MaTknElmtDef maTeFfBscBearCode =   /* Bearer Code */
     DEFINE_TAG_U8(MA_TAG_CSPRIM2,LMA_VER1AND2,MA_TF_VER1AND2_OPT3);

PRIVATE MaTknElmtDef maTeFfBscTeleCode =   /* Tele Code */
     DEFINE_TAG_U8(MA_TAG_CSPRIM3,LMA_VER1AND2,MA_TF_VER1AND2_OPT3);

PRIVATE MaTknElmtDef maTeFfSsStatus =   /* SS Status */
     DEFINE_TAG_U8(MA_TAG_CSPRIM4,LMA_VER1AND2,MA_TF_VER1AND2_OPT2);

PRIVATE MaTknElmtDef maTeFiFfExtBasServCodeChoice = /* Basic Service Code */
     DEFINE_CHOICE(sizeof(MaExtBasServCode),LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeFfExtBscBearCode =   /* Bearer Code */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,5,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeFfExtBscTeleCode =   /* Tele Code */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,5,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeFfExtSsStatus =   /* SS Status */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,1,5,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeFfFwdToNmb =   /* Forward To Nmb        */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM5,1,9,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeFfFwdToSubAddr =   /* Call Reference number */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM8,1,21,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeFfFwdOpt =   /* Forwarding Options    */
     DEFINE_TAG_U8(MA_TAG_CSPRIM6,LMA_VER1AND2,MA_TF_VER1AND2_OPT3);

PRIVATE MaTknElmtDef maTeFfNoRplyCondTime =   /* No Reply Condition Time */
     DEFINE_TAG_INT(MA_TAG_CSPRIM7,5,30,LMA_VER1AND2,MA_TF_VER1AND2_OPT3);

PRIVATE MaTknElmtDef maTeFfExtFwdOpt =   /* Forwarding Options    */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM6,1,5,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeFfExtNoRplyCondTime =   /* No Reply Condition Time */
     DEFINE_TAG_INT(MA_TAG_CSPRIM7,1,100,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#if MAP_REL99
#else
#ifdef MAP_PHASE2_EXT_MARK
#define DEFINE_FWDFEAT_LST(seqHeader)   \
    &seqHeader,             \
       &maTeSeqOpt,\
          &maTeFiFfBasServCodeChoice,\
             &maTeFfBscBearCode,\
             &maTeFfBscTeleCode,\
          &maTeSeqTerm,\
          &maTeFfSsStatus,\
          &maTeFiFfExtBasServCodeChoice,\
             &maTeFfExtBscBearCode,\
             &maTeFfExtBscTeleCode,\
          &maTeSeqTerm,\
          &maTeFfExtSsStatus,\
          &maTeFfFwdToNmb,\
          &maTeFfFwdToSubAddr,\
          &maTeFfFwdOpt,\
          &maTeFfNoRplyCondTime,\
          &maTeFfExtFwdOpt,\
          &maTeFfExtNoRplyCondTime,\
          &maTeExtMark,                      \
          &maTeExtCont9, \
       &maTeSeqTerm,\
    &maTeSeqTerm  
#else
#define DEFINE_FWDFEAT_LST(seqHeader)   \
    &seqHeader,             \
       &maTeSeqOpt,\
          &maTeFiFfBasServCodeChoice,\
             &maTeFfBscBearCode,\
             &maTeFfBscTeleCode,\
          &maTeSeqTerm,\
          &maTeFfSsStatus,\
          &maTeFiFfExtBasServCodeChoice,\
             &maTeFfExtBscBearCode,\
             &maTeFfExtBscTeleCode,\
          &maTeSeqTerm,\
          &maTeFfExtSsStatus,\
          &maTeFfFwdToNmb,\
          &maTeFfFwdToSubAddr,\
          &maTeFfFwdOpt,\
          &maTeFfNoRplyCondTime,\
          &maTeFfExtFwdOpt,\
          &maTeFfExtNoRplyCondTime,\
          &maTeExtCont9, \
       &maTeSeqTerm,\
    &maTeSeqTerm  
#endif
#endif
#if MAP_REL99         

#if (MAP_VLR || MAP_HLR || MAP_GSN)
/* Version 2: TAG = MA_TAG_CSPRIM9, Version 3: TAG = MA_TAG_CSPRIM10 */
PRIVATE MaTknElmtDef maTeFfLongFwdedToNmb = 
     DEFINE_U_STRS(1,15,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3,maChkFfLongFwdedToNmb);
#endif

#ifdef MAP_PHASE2_EXT_MARK
#define DEFINE_FWDFEAT_LST(seqHeader)   \
    &seqHeader,             \
       &maTeSeqOpt,\
          &maTeFiFfBasServCodeChoice,\
             &maTeFfBscBearCode,\
             &maTeFfBscTeleCode,\
          &maTeSeqTerm,\
          &maTeFfSsStatus,\
          &maTeFiFfExtBasServCodeChoice,\
             &maTeFfExtBscBearCode,\
             &maTeFfExtBscTeleCode,\
          &maTeSeqTerm,\
          &maTeFfExtSsStatus,\
          &maTeFfFwdToNmb,\
          &maTeFfFwdToSubAddr,\
          &maTeFfFwdOpt,\
          &maTeFfNoRplyCondTime,\
          &maTeFfExtFwdOpt,\
          &maTeFfExtNoRplyCondTime,\
          &maTeExtMark,                      \
          &maTeExtCont9, \
          &maTeFfLongFwdedToNmb, \
       &maTeSeqTerm,\
    &maTeSeqTerm  
#else
#define DEFINE_FWDFEAT_LST(seqHeader)   \
    &seqHeader,             \
       &maTeSeqOpt,\
          &maTeFiFfBasServCodeChoice,\
             &maTeFfBscBearCode,\
             &maTeFfBscTeleCode,\
          &maTeSeqTerm,\
          &maTeFfSsStatus,\
          &maTeFiFfExtBasServCodeChoice,\
             &maTeFfExtBscBearCode,\
             &maTeFfExtBscTeleCode,\
          &maTeSeqTerm,\
          &maTeFfExtSsStatus,\
          &maTeFfFwdToNmb,\
          &maTeFfFwdToSubAddr,\
          &maTeFfFwdOpt,\
          &maTeFfNoRplyCondTime,\
          &maTeFfExtFwdOpt,\
          &maTeFfExtNoRplyCondTime,\
          &maTeExtCont9, \
          &maTeFfLongFwdedToNmb, \
       &maTeSeqTerm,\
    &maTeSeqTerm  
#endif
#endif /* MAP_REL99 */

/* CbFeat List                        */
/***************************************/
#if (MAP_VLR || MAP_HLR || MAP_GSN)
PRIVATE MaTknElmtDef maTeSiCallBarrInfoSeq =  /* Call Barr Info Sequence */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeSiCbiSsCode =   /* SS Code               */
     DEFINE_U8(LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT2);

PRIVATE MaTknElmtDef maTeSiCbiFeatSeqOf =   /*Call Barr. Ftr Seq Of  */
     DEFINE_U_SEQOF(LMA_VER1AND2AND2P,MAT_MAX_EXT_BASIC_SERV,MA_TF_VER1AND2AND2P_OPT0,maChkExtSeqOf);

PRIVATE MaTknElmtDef maTeCbflCbfBasServCodeChoice =   /* Bas.Serv.Code */
     DEFINE_CHOICE(sizeof(MaBasicServ),LMA_VER1AND2,MA_TF_VER1AND2_OPT3);

PRIVATE MaTknElmtDef maTeCbfBscBearCode =   /* Bearer Code           */
     DEFINE_TAG_U8(MA_TAG_CSPRIM2,LMA_VER1AND2,MA_TF_VER1AND2_OPT3);

PRIVATE MaTknElmtDef maTeCbfBscTeleCode =   /* Tele Code             */
     DEFINE_TAG_U8(MA_TAG_CSPRIM3,LMA_VER1AND2,MA_TF_VER1AND2_OPT3);

PRIVATE MaTknElmtDef maTeCbflCbfSsStatus =   /* SS Status             */
     DEFINE_TAG_U8(MA_TAG_CSPRIM4,LMA_VER1AND2,MA_TF_VER1AND2_OPT3);


PRIVATE MaTknElmtDef maTeCbflCbfExtBasServCodeChoice =   /* Bas.Serv.Code */
     DEFINE_CHOICE(sizeof(MaExtBasServCode),LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCbfExtBscBearCode =   /* Bearer Code           */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,5,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCbfExtBscTeleCode =   /* Tele Code             */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,5,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCbflCbfExtSsStatus =   /* SS Status             */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,1,5,LMA_VER2P,MA_TF_VER2P_MAND);
#endif


#ifdef MAP_PHASE2_EXT_MARK
#define DEFINE_CBARRFEAT_LST(seqHeader)   \
    &seqHeader,             \
       &maTeSeqOpt,\
          &maTeCbflCbfBasServCodeChoice,\
             &maTeCbfBscBearCode,\
             &maTeCbfBscTeleCode,\
          &maTeSeqTerm,\
          &maTeCbflCbfSsStatus,\
          &maTeExtMark, \
          &maTeCbflCbfExtBasServCodeChoice,\
             &maTeCbfExtBscBearCode,\
             &maTeCbfExtBscTeleCode,\
          &maTeSeqTerm,\
          &maTeCbflCbfExtSsStatus,\
          &maTeExtCont, \
       &maTeSeqTerm,\
    &maTeSeqTerm
#else
#define DEFINE_CBARRFEAT_LST(seqHeader)   \
    &seqHeader,             \
       &maTeSeqOpt,\
          &maTeCbflCbfBasServCodeChoice,\
             &maTeCbfBscBearCode,\
             &maTeCbfBscTeleCode,\
          &maTeSeqTerm,\
          &maTeCbflCbfSsStatus,\
          &maTeCbflCbfExtBasServCodeChoice,\
             &maTeCbfExtBscBearCode,\
             &maTeCbfExtBscTeleCode,\
          &maTeSeqTerm,\
          &maTeCbflCbfExtSsStatus,\
          &maTeExtCont, \
       &maTeSeqTerm,\
    &maTeSeqTerm
#endif

/* Cug Info */
/********************************/

#if (MAP_VLR || MAP_HLR || MAP_GSN)
PRIVATE MaTknElmtDef maTeSiCugInfoSeq =   /* Cug Info Sequence     */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST2,LMA_VER1AND2AND2P,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeCiCugSubsSeqOf =   /* Cug.Subs.Seqof  */
     DEFINE_SEQOF(LMA_VER2AND2P ,MAT_MAX_CUG,MA_TF_VER2AND2P_OPT2);

PRIVATE MaTknElmtDef maTeCiCslCugIndex =   /* Cug Index           r */
     DEFINE_INT(0,32767,LMA_VER2AND2P ,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeCiCslCugInterLock =   /* Cug Inter Lock        */
     DEFINE_STRS(4,4,LMA_VER2AND2P ,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeCiCslIntraCugOpt =   /* Intra Cug Options     */
     DEFINE_ENUM(LMA_VER2AND2P ,MA_TF_VER2AND2P_OPT0,maIntraCugOptEnums);

PRIVATE MaTknElmtDef maTeCiCslBasServGrpLst =   /* Bas Serv Group List   */
     DEFINE_U_SEQOF(LMA_VER2AND2P,MAT_MAX_EXT_BASIC_SERV,MA_TF_VER2AND2P_OPT3,maChkExtSeqOf);

PRIVATE MaTknElmtDef maTeCiCslBsglBscChoice =   /* Bas. Serv. Code Choice */
     DEFINE_CHOICE(sizeof(MaExtBasServCode),LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeCiCslBsglBearCode =   /* Call Reference number */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,5,LMA_VER2AND2P ,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeCiCslBsglTeleCode =   /* Tele Code             */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,5,LMA_VER2AND2P ,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeCiCugFeatSeqOf =   /* Cug Feature Seq Of    */
     DEFINE_U_SEQOF(LMA_VER2AND2P ,MAT_MAX_EXT_BASIC_SERV,MA_TF_VER2AND2P_OPT3,maChkExtSeqOf);

PRIVATE MaTknElmtDef maTeCiCflBasServCodeChoice = /* Basic Service Code    */
     DEFINE_CHOICE(sizeof(MaExtBasServCode),LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeCiCflBscBearCode =   /* Bear Code             */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,5,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeCiCflBscTeleCode =   /* Tele Code            */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,5,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeCiCflPrefCugInd =   /* Pref. Cug. Indicator  */
     DEFINE_INT(0,32767,LMA_VER2AND2P ,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeCiCflInterCugRest =   /*Inter Cug Restrictions */
     DEFINE_U8(LMA_VER2AND2P ,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeCiCugFacilities =   /* CUG Facilities             */
     DEFINE_U8(LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeCiCugFeatureSeq0 =  /* Cug Feature Info Sequence     */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST0, LMA_VER1, MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeCiCugFeatureSeq =   /* Cug Feature Info Sequence     */
     DEFINE_SEQ(LMA_VER1, MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeCiCFInterLock =    /* Cug Interlock */
     DEFINE_STRS(1, 4, LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeCiCFIndex =        /* Cug Index */
     DEFINE_STRS(1, 1, LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeCiCFOptions =      /* Cug Options */
     DEFINE_U8(LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeCiCFSSStatus =     /* SS Status */
     DEFINE_U8(LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeCiCugChoice =       /* CUG Choice    */
     DEFINE_CHOICE(sizeof(MaCUGFeatChoice),LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeCiCugFeatureSeqOf = /* Cug Feature Seq Of    */
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST1, LMA_VER1 ,MAT_MAX_CUG,MA_TF_VER1_MAND);

#endif


/* SS DATA */
/********************************/
#if (MAP_VLR || MAP_HLR || MAP_GSN)
PRIVATE MaTknElmtDef maTeSiSsDatSeq =   /* SS Data  Sequence     */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST3,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeSsdSsCode =   /* SS code O-O-M         */
     DEFINE_U8(LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT2);

PRIVATE MaTknElmtDef maTeSsdSsStatus  =   /* SS Status             */
     DEFINE_TAG_U8(MA_TAG_CSPRIM4,LMA_VER1AND2,MA_TF_VER1AND2_OPT3);

PRIVATE MaTknElmtDef maTeSsdExtSsStatus =   /* SS Status */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,1,5,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeSsdSsSubsChoice =   /* SS Subscription Option*/
     DEFINE_CHOICE(sizeof(MaSSSubsOpt),LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeSsdSsSoCliRestOpt =   /* Call Reference number */
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM2,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0,maCliRestOptEnums);

PRIVATE MaTknElmtDef maTeSsdSsSoOvrRideCat =   /* Call Reference number */
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM1,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0,maOvrRideCatEnums);

PRIVATE MaTknElmtDef maTeSsdSsSubsPhs1Choice =   /* SS Subscription Option*/
     DEFINE_CHOICE(sizeof(MaSSSubsPhs1Opt),LMA_VER1,MA_TF_VER1_OPT);   

PRIVATE MaTknElmtDef maTeSsdSsSoPerCallBas =   /* Per Call Basis*/
     DEFINE_TAG_BOOL(MA_TAG_CSPRIM5,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeSsdSsSoNotToHldRetPty =   /* Notification to Held Ret. Party*/
     DEFINE_TAG_BOOL(MA_TAG_CSPRIM6,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeSsdSsSoUtoUServInd =   /* Usr to Usr Service Ind.*/
     DEFINE_TAG_U8(MA_TAG_CSPRIM7,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeSsdSsSoMaxConfNum =  /* Max Conf Num*/
     DEFINE_TAG_INT(MA_TAG_CSPRIM8,1,10,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeSsdSsSoHntGrpAccSelOdr=   /* Call Reference number */
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM9,LMA_VER1,MA_TF_VER1_OPT,maHntGrpAccSelOdrEnums);     

PRIVATE MaTknElmtDef maTeSsdBasServGrpLst =   /* Bas Serv Group List   */
     DEFINE_SEQOF(LMA_VER2 ,MAT_MAX_BASIC_SERV,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTeBsglBasServCodeChoice =   /* Bas.Serv.Code  */
     DEFINE_CHOICE(sizeof(MaBasicServ),LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTeBsglBscBearCode =   /* Bear code             */
     DEFINE_TAG_U8(MA_TAG_CSPRIM2,LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTeBsglBscTeleCode =   /* Tele Code             */
     DEFINE_TAG_U8(MA_TAG_CSPRIM3,LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTeSsdExtBasServGrpLst =   /* Bas Serv Group List   */
     DEFINE_SEQOF(LMA_VER2P ,MAT_MAX_EXT_BASIC_SERV,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeBsglExtBasServCodeChoice = /* Basic Service Code */
     DEFINE_CHOICE(sizeof(MaExtBasServCode),LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeBsglExtBscBearCode =   /* Bearer Code */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,5,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeBsglExtBscTeleCode =   /* Tele Code */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,5,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSsdDefPri =   /* Default Priority      */
     DEFINE_INT(0,15,LMA_VER2,MA_TF_VER2_OPT);
#endif

#if MAP_REL99
#else

#ifdef MAP_PHASE2_EXT_MARK
#define DEFINE_SSDATA \
 &maTeSiSsDatSeq,\
    &maTeSsdSsCode,\
    &maTeSsdSsStatus ,\
    &maTeSsdExtSsStatus ,\
    &maTeSsdSsSubsChoice,\
       &maTeSsdSsSoCliRestOpt,\
       &maTeSsdSsSoOvrRideCat, \
    &maTeSeqTerm,\
    &maTeSsdSsSubsPhs1Choice,\
       &maTeSsdSsSoPerCallBas,\
       &maTeSsdSsSoNotToHldRetPty,\
       &maTeSsdSsSoUtoUServInd, \
       &maTeSsdSsSoMaxConfNum, \
       &maTeSsdSsSoHntGrpAccSelOdr,\
    &maTeSeqTerm,\
    &maTeSsdBasServGrpLst, \
        &maTeBsglBasServCodeChoice,\
           &maTeBsglBscBearCode,\
           &maTeBsglBscTeleCode,\
        &maTeSeqTerm,\
     &maTeSeqTerm,\
     &maTeExtMark, \
     &maTeSsdExtBasServGrpLst, \
        &maTeBsglExtBasServCodeChoice,\
           &maTeBsglExtBscBearCode,\
           &maTeBsglExtBscTeleCode,\
        &maTeSeqTerm,\
     &maTeSeqTerm,\
     &maTeExtCont5,\
     &maTeSsdDefPri, \
 &maTeSeqTerm
#else
#define DEFINE_SSDATA \
 &maTeSiSsDatSeq,\
    &maTeSsdSsCode,\
    &maTeSsdSsStatus ,\
    &maTeSsdExtSsStatus ,\
    &maTeSsdSsSubsChoice,\
       &maTeSsdSsSoCliRestOpt,\
       &maTeSsdSsSoOvrRideCat, \
    &maTeSeqTerm,\
    &maTeSsdSsSubsPhs1Choice,\
       &maTeSsdSsSoPerCallBas,\
       &maTeSsdSsSoNotToHldRetPty,\
       &maTeSsdSsSoUtoUServInd, \
       &maTeSsdSsSoMaxConfNum, \
       &maTeSsdSsSoHntGrpAccSelOdr,\
    &maTeSeqTerm,\
    &maTeSsdBasServGrpLst, \
        &maTeBsglBasServCodeChoice,\
           &maTeBsglBscBearCode,\
           &maTeBsglBscTeleCode,\
        &maTeSeqTerm,\
     &maTeSeqTerm,\
     &maTeSsdExtBasServGrpLst, \
        &maTeBsglExtBasServCodeChoice,\
           &maTeBsglExtBscBearCode,\
           &maTeBsglExtBscTeleCode,\
        &maTeSeqTerm,\
     &maTeSeqTerm,\
     &maTeExtCont5,\
     &maTeSsdDefPri, \
 &maTeSeqTerm
#endif

#endif
#if MAP_REL99           

#if (MAP_VLR || MAP_HLR || MAP_GSN)
PRIVATE MaTknElmtDef maTeSsdNbrUsr  =  /* Nbr User */
     DEFINE_TAG_INT(MA_TAG_CSPRIM5,1,7,LMA_VER2,MA_TF_VER2_OPT);
#endif

#define DEFINE_SSDATA \
 &maTeSiSsDatSeq,\
    &maTeSsdSsCode,\
    &maTeSsdSsStatus ,\
    &maTeSsdExtSsStatus ,\
    &maTeSsdSsSubsChoice,\
       &maTeSsdSsSoCliRestOpt,\
       &maTeSsdSsSoOvrRideCat, \
    &maTeSeqTerm,\
    &maTeSsdSsSubsPhs1Choice,\
       &maTeSsdSsSoPerCallBas,\
       &maTeSsdSsSoNotToHldRetPty,\
       &maTeSsdSsSoUtoUServInd, \
       &maTeSsdSsSoMaxConfNum, \
       &maTeSsdSsSoHntGrpAccSelOdr,\
    &maTeSeqTerm,\
    &maTeSsdBasServGrpLst, \
        &maTeBsglBasServCodeChoice,\
           &maTeBsglBscBearCode,\
           &maTeBsglBscTeleCode,\
        &maTeSeqTerm,\
     &maTeSeqTerm,\
     &maTeSsdExtBasServGrpLst, \
        &maTeBsglExtBasServCodeChoice,\
           &maTeBsglExtBscBearCode,\
           &maTeBsglExtBscTeleCode,\
        &maTeSeqTerm,\
     &maTeSeqTerm,\
     &maTeExtCont5,\
     &maTeSsdDefPri, \
     &maTeSsdNbrUsr,\
 &maTeSeqTerm

#endif /* MAP_REL99 */

/* EML PP Info */
/***************************************/
#if (MAP_VLR || MAP_HLR || MAP_GSN)
PRIVATE MaTknElmtDef maTeSiEmlppInfoSeq =   /* Emlpp Info Sequence   */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST4,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#if (MAP_VLR || MAP_HLR || MAP_GSN)
/* CUG Info */
/************/



#define DEFINE_CUG_FEATURE(seqHdr) \
 &seqHdr, \
   &maTeCiCFInterLock, \
   &maTeCiCFIndex, \
   &maTeCiCFOptions, \
   &maTeCiCFSSStatus, \
 &maTeSeqTerm

#ifdef MAP_PHASE2_EXT_MARK
#define DEFINE_CUGINFO_SEQ \
 &maTeSiCugInfoSeq,\
    &maTeCiCugSubsSeqOf,\
       &maTeSeqOpt,\
          &maTeCiCslCugIndex,\
          &maTeCiCslCugInterLock,\
          &maTeCiCslIntraCugOpt,\
          &maTeCiCslBasServGrpLst,\
             &maTeCiCslBsglBscChoice,\
                &maTeCiCslBsglBearCode,\
                &maTeCiCslBsglTeleCode,\
             &maTeSeqTerm,\
          &maTeSeqTerm,\
          &maTeExtMark, \
          &maTeExtCont0,\
       &maTeSeqTerm,\
    &maTeSeqTerm,\
    &maTeCiCugFeatSeqOf,\
       &maTeSeqOpt,\
          &maTeCiCflBasServCodeChoice,\
             &maTeCiCflBscBearCode,\
             &maTeCiCflBscTeleCode, \
          &maTeSeqTerm,\
          &maTeCiCflPrefCugInd,\
          &maTeCiCflInterCugRest,\
          &maTeExtMark, \
          &maTeExtCont,\
       &maTeSeqTerm,\
    &maTeSeqTerm,\
    &maTeExtMark, \
    &maTeExtCont0,\
    &maTeCiCugFacilities,\
    &maTeCiCugChoice, \
      DEFINE_CUG_FEATURE (maTeCiCugFeatureSeq0), \
      &maTeCiCugFeatureSeqOf,\
        DEFINE_CUG_FEATURE (maTeCiCugFeatureSeq), \
      &maTeSeqTerm,\
    &maTeSeqTerm,\
 &maTeSeqTerm
#else
#define DEFINE_CUGINFO_SEQ \
 &maTeSiCugInfoSeq,\
    &maTeCiCugSubsSeqOf,\
       &maTeSeqOpt,\
          &maTeCiCslCugIndex,\
          &maTeCiCslCugInterLock,\
          &maTeCiCslIntraCugOpt,\
          &maTeCiCslBasServGrpLst,\
             &maTeCiCslBsglBscChoice,\
                &maTeCiCslBsglBearCode,\
                &maTeCiCslBsglTeleCode,\
             &maTeSeqTerm,\
          &maTeSeqTerm,\
          &maTeExtCont0,\
       &maTeSeqTerm,\
    &maTeSeqTerm,\
    &maTeCiCugFeatSeqOf,\
       &maTeSeqOpt,\
          &maTeCiCflBasServCodeChoice,\
             &maTeCiCflBscBearCode,\
             &maTeCiCflBscTeleCode, \
          &maTeSeqTerm,\
          &maTeCiCflPrefCugInd,\
          &maTeCiCflInterCugRest,\
          &maTeExtCont,\
       &maTeSeqTerm,\
    &maTeSeqTerm,\
    &maTeExtCont0,\
    &maTeCiCugFacilities,\
    &maTeCiCugChoice, \
      DEFINE_CUG_FEATURE (maTeCiCugFeatureSeq0), \
      &maTeCiCugFeatureSeqOf,\
        DEFINE_CUG_FEATURE (maTeCiCugFeatureSeq), \
      &maTeSeqTerm,\
    &maTeSeqTerm,\
 &maTeSeqTerm
#endif


PRIVATE MaTknElmtDef maTeEiMaxEntPri =   /* Max. Ent. Priority    */
     DEFINE_INT(0,15,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeEiDefPri =   /* Default Priority      */
     DEFINE_INT(0,15,LMA_VER2P,MA_TF_VER2P_MAND);

#ifdef MAP_PHASE2_EXT_MARK
#define DEFINE_SSINFO(choiceHeader) \
 &choiceHeader,\
 &maTeSiFwdInfoSeq,\
    &maTeSsiFiSSCode,\
    DEFINE_FWDFEAT_LST(maTeSsiFiFwdFeatSeqOf),\
    &maTeExtMark, \
    &maTeExtCont0,\
 &maTeSeqTerm,\
 &maTeSiCallBarrInfoSeq,\
    &maTeSiCbiSsCode,\
    DEFINE_CBARRFEAT_LST(maTeSiCbiFeatSeqOf), \
    &maTeExtMark, \
    &maTeExtCont, \
 &maTeSeqTerm,\
DEFINE_CUGINFO_SEQ, \
 DEFINE_SSDATA,\
 &maTeSiEmlppInfoSeq,\
    &maTeEiMaxEntPri,\
    &maTeEiDefPri,\
    &maTeExtCont,\
 &maTeSeqTerm,\
&maTeSeqTerm 
#else
#define DEFINE_SSINFO(choiceHeader) \
 &choiceHeader,\
 &maTeSiFwdInfoSeq,\
    &maTeSsiFiSSCode,\
    DEFINE_FWDFEAT_LST(maTeSsiFiFwdFeatSeqOf),\
    &maTeExtCont0,\
 &maTeSeqTerm,\
 &maTeSiCallBarrInfoSeq,\
    &maTeSiCbiSsCode,\
    DEFINE_CBARRFEAT_LST(maTeSiCbiFeatSeqOf), \
    &maTeExtCont, \
 &maTeSeqTerm,\
DEFINE_CUGINFO_SEQ, \
 DEFINE_SSDATA,\
 &maTeSiEmlppInfoSeq,\
    &maTeEiMaxEntPri,\
    &maTeEiDefPri,\
    &maTeExtCont,\
 &maTeSeqTerm,\
&maTeSeqTerm 
#endif
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

/* VBS Data List */
/*****************/


#if (MAP_VLR || MAP_HLR || MAP_GSN)
#ifndef MA_SGSN_SPECIFIC
PRIVATE MaTknElmtDef maTeVdlVoiceBroadcastDatSeq =   /* Voice Broad.Dat Seq */
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeVdlVbdGrpId =   /* Group Id              */
     DEFINE_STRS(3,3,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeVdlVbdBroadInitEnt =   /* Broadcast Init Ent.   */
     DEFINE_NULL(LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MA_SGSN_SPECIFIC */
#endif


#define DEFINE_VBSDAT_LST(seqHeader)   \
&seqHeader,\
   &maTeVdlVoiceBroadcastDatSeq,\
      &maTeVdlVbdGrpId,\
      &maTeVdlVbdBroadInitEnt,\
      &maTeExtCont,\
   &maTeSeqTerm,\
&maTeSeqTerm

/* VGCS Data List */
/******************/

#if (MAP_VLR || MAP_HLR || MAP_GSN)
#ifndef MA_SGSN_SPECIFIC
PRIVATE MaTknElmtDef maTeVgcsdlGrpId =   /* Group Id              */
     DEFINE_STRS(3,3,LMA_VER2P,MA_TF_VER2P_MAND);
#endif /* MA_SGSN_SPECIFIC  */
#endif

#define DEFINE_VGCSDAT_LST(seqHeader)   \
&seqHeader,\
   &maTeSeqOptVer2P,\
      &maTeVgcsdlGrpId,\
      &maTeExtCont,\
   &maTeSeqTerm,\
&maTeSeqTerm


/* SS EVT DAT Lst */
/******************/

/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
PRIVATE MaTknElmtDef maTeSsEvtLstSsCode =   /* SS Code               */
     DEFINE_U8(LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#define DEFINE_SSEVT_LST(seqHeader) \
&seqHeader,\
   &maTeSsEvtLstSsCode,\
&maTeSeqTerm
/* SS CAMEL Data */
/*****************/

/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
PRIVATE MaTknElmtDef maTeSsCamDatSsEvtLst =   /* SS Evt Lst            */
     DEFINE_SEQOF(LMA_VER2P,MAT_MAX_SS_EVENT_LST,MA_TF_VER2P_OPT);
#endif

/* ma008.203 : Added MAP_REL99 with MAP_MSC to remove warning */
#if ((MAP_MSC && MAP_REL99) || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
PRIVATE MaTknElmtDef maTeSsCamDatGsmScfAddr =   /* Gsm Scf Address       */
     DEFINE_STRS(1,9,LMA_VER2P,MA_TF_VER2P_MAND);
#endif /* MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN */

#if MAP_REL99
#define DEFINE_SSCAMDAT_SEQ(seqHeader)  \
&seqHeader,\
   DEFINE_SSEVT_LST(maTeSsCamDatSsEvtLst),\
   &maTeSsCamDatGsmScfAddr,\
   &maTeExtCont0,\
   &maTeNotificationToCse,\
   &maTeCsiActive,\
&maTeSeqTerm
#else  /* MAP_REL99 */
#define DEFINE_SSCAMDAT_SEQ(seqHeader)  \
&seqHeader,\
   DEFINE_SSEVT_LST(maTeSsCamDatSsEvtLst),\
   &maTeSsCamDatGsmScfAddr,\
   &maTeExtCont0,\
&maTeSeqTerm
#endif /* MAP_REL99 */

/* SS-CSI */
/**********/

/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
PRIVATE MaTknElmtDef maTeSsCsiSsCamDatSeq =   /* SS Camel Data Sequence*/
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_MAND);
#endif

#if MAP_REL99
/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
PRIVATE MaTknElmtDef maTeSscsiNotifToCse  =  /*Notification To CSE */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT );

PRIVATE MaTknElmtDef maTeSscsiCsiActive  =  /*Csi Active */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT );
#endif

#define DEFINE_SSCSI_SEQ(seqHeader)   \
&seqHeader,\
   DEFINE_SSCAMDAT_SEQ(maTeSsCsiSsCamDatSeq),\
   &maTeExtCont,\
   &maTeSscsiNotifToCse,\
   &maTeSscsiCsiActive,\
&maTeSeqTerm

#else  /* MAP_REL99 */
#define DEFINE_SSCSI_SEQ(seqHeader)   \
&seqHeader,\
   DEFINE_SSCAMDAT_SEQ(maTeSsCsiSsCamDatSeq),\
   &maTeExtCont,\
&maTeSeqTerm
#endif /* MAP_REL99 */

/* Vlr Camel Subscription Info */
/*******************************/
#if (MAP_VLR || MAP_HLR || MAP_GSN)
#ifndef MA_SGSN_SPECIFIC
PRIVATE MaTknElmtDef maTeVcsiOcsiSeq =   /* O-Csi Sequence        */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeVcsiSsCsiSeq =   /* SS-CSi Seq.           */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeVcsiObcsmCamTdpCritLst = /*ObcsmCamelTDPCriteriaList*/
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST4,LMA_VER2P,MAT_MAXNUMOF_CAMTDPDATA,MA_TF_VER2P_OPT);
#endif /* MA_SGSN_SPECIFIC */
#endif

/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_MSC || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
PRIVATE MaTknElmtDef maTeOctcObcsmCamTdpCritSeq  =  /*ObcsmTdpCriteria Seq*/
     DEFINE_U_SEQ(LMA_VER2P,MA_TF_VER2P_OPT, maChkIgnoreSeq);
#endif

#if (MAP_REL98 || MAP_REL99)

#if (MAP_VLR || MAP_HLR || MAP_GSN)
#ifndef MA_SGSN_SPECIFIC
PRIVATE MaTknElmtDef maTeVcsiTifCsi  =  /* Tif CSI */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_OPT );
#endif /* MA_SGSN_SPECIFIC */
#endif 

#endif /* MAP_REL98 || MAP_REL99 */

#if MAP_REL99

#if (MAP_VLR || MAP_HLR || MAP_GSN)
#ifndef MA_SGSN_SPECIFIC
PRIVATE MaTknElmtDef maTeVcsiMCsiSeq  =  /* M-CSI Seq*/
     DEFINE_TAG_SEQ(MA_TAG_CSCONST5,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MA_SGSN_SPECIFIC */
#endif
/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if ( MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)) ||(MAP_GSN && MAP_REL5) )
PRIVATE MaTknElmtDef maTeMcsiMobilityTrigLst = /*ObcsmCamelTDPCriteriaList*/
     DEFINE_SEQOF(LMA_VER2P,MAT_MAX_NMB_MOBILITY_TRIGGERS,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeMtMmCode  =  /* Cause Value */
     DEFINE_U8(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeMcsiNotificationToCse  =  /*Notification To CSE */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT );

PRIVATE MaTknElmtDef maTeMcsiCsiActive  =  /*Csi Active */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_OPT );
#endif
#if (MAP_VLR || MAP_HLR || MAP_GSN)
#ifndef MA_SGSN_SPECIFIC
PRIVATE MaTknElmtDef maTeVcsiSmsCsiSeq = /* SMS-CSI*/
     DEFINE_TAG_SEQ(MA_TAG_CSCONST6,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MA_SGSN_SPECIFIC */
PRIVATE MaTknElmtDef maTeVcsiScSmsCamTdpDataLst = /*SmsCamelTDPDataList*/
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST0,LMA_VER2P,MAT_MAXNUMOF_CAMTDPDATA,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeStdSmsCamTdpDataSeq  =  /*SmsTdpData Seq*/
     DEFINE_U_SEQ(LMA_VER2P,MA_TF_VER2P_OPT,maChkIgnoreSeq);

PRIVATE MaTknElmtDef maTeScSctdSmsTrgDetPt  =  /*SmsTrigger Det. Pt. */
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_MAND,maChkSmsTrigDetPt,maSmsTrgDetPtEnums);

PRIVATE MaTknElmtDef maTeScSctdSerKey  =  /* Service Key */
     DEFINE_TAG_INT(MA_TAG_CSPRIM1,0,2147483647,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeScSctdGsmScfAddr  =  /* Gsm Scf Address */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeScSctdDefSmsHandl  =  /* Default SMS Hanlding */
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_MAND,maChkDefSmsHandl,maDefSmsHandlEnums);

PRIVATE MaTknElmtDef maTeVcsiCamCapHandl  =  /* Service Key */
     DEFINE_TAG_INT(MA_TAG_CSPRIM1,1,16,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)
PRIVATE MaTknElmtDef maTeVcsiNotificationToCse  =  /*Notification To CSE */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_OPT );

PRIVATE MaTknElmtDef maTeVcsiCsiActive  =  /*Csi Active */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM4,LMA_VER2P,MA_TF_VER2P_OPT );
#endif

#if (MAP_VLR || MAP_HLR || MAP_GSN)
#ifndef MA_SGSN_SPECIFIC
PRIVATE MaTknElmtDef maTeVcsiTcsiSeq  =  /*T CSI Seq*/
     DEFINE_TAG_SEQ(MA_TAG_CSCONST7,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeVcsiTbcsmCamTdpCritLst = /*TbcsmCamelTDPCriteriaList*/
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST8,LMA_VER2P,MAT_MAXNUMOF_CAMTDPDATA,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeVcsiDCsiSeq  =  /* D-CSI*/
     DEFINE_TAG_SEQ(MA_TAG_CSCONST9,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MA_SGSN_SPECIFIC */
#endif

/* ma008.203 : And with MA_SGSN_SPECIFIC to remove warning*/
#if (MAP_MSC || MAP_VLR || MAP_HLR || (MAP_GSN && !(MA_SGSN_SPECIFIC)))
PRIVATE MaTknElmtDef maTeDcsiDpAnalyzdInfoCritLst = 
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST0,LMA_VER2P,MAT_MAX_NMB_DP_ANALYZEDINFO_CRIT,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeDpaicDpAnalyzdInfoCritSeq   = 
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeDpaicDialledNmb  =  /* Dialled Number */
     DEFINE_STRS(1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeDpaicDefCallHandl  =  /* Default Call Handling */
     DEFINE_U_ENUM(LMA_VER2P,MA_TF_VER2P_MAND,maChkDefCallHandl,maDefCallHandlEnums);

PRIVATE MaTknElmtDef maTeDcsiCamCapHandl  =  /* Camel Capability Handling */
    DEFINE_TAG_INT(MA_TAG_CSPRIM1,1,16,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

#define DEFINE_DCSI_SEQ(seqHeader)\
   &seqHeader,\
      &maTeDcsiDpAnalyzdInfoCritLst,\
         &maTeDpaicDpAnalyzdInfoCritSeq,\
            &maTeDpaicDialledNmb,\
            &maTeObctdSerKey,\
            &maTeSsCamDatGsmScfAddr,\
            &maTeDpaicDefCallHandl,\
            &maTeExtCont,\
         &maTeSeqTerm,\
       &maTeSeqTerm,\
      &maTeDcsiCamCapHandl,\
      &maTeExtCont2,\
      &maTeVcsiNotificationToCse,\
      &maTeVcsiCsiActive,\
   &maTeSeqTerm

#endif /* MAP_REL99 */

#if MAP_REL99
#if MAP_REL5
/* ma008.203: Removed MAP_MSC for warnings  */
#if (MAP_VLR || MAP_HLR || MAP_GSN)

#ifndef MA_SGSN_SPECIFIC 
PRIVATE MaTknElmtDef maTeVcsiMtSmsCsiSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST10,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeVcsiSmsTDPCritSeqOf = 
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST11,LMA_VER2P, MAT_MAXNUMOF_CAMTDPDATA,
                      MA_TF_VER2P_OPT);
#endif 
#endif


#define DEFINE_VLRCAMSUBSINFO_SEQ(seqHeader)   \
&seqHeader,\
   DEFINE_OCSI_SEQ(maTeVcsiOcsiSeq),\
   &maTeExtCont1,\
   DEFINE_SSCSI_SEQ(maTeVcsiSsCsiSeq),\
   &maTeVcsiObcsmCamTdpCritLst,\
      DEFINE_OBCSMCAMTDPCRIT_SEQ(maTeOctcObcsmCamTdpCritSeq),\
   &maTeSeqTerm, \
   &maTeVcsiTifCsi,\
   &maTeVcsiMCsiSeq,\
      &maTeMcsiMobilityTrigLst,\
         &maTeMtMmCode,\
      &maTeSeqTerm,\
      &maTeObctdSerKey,\
      &maTeObctdGsmSCFAddr,\
      &maTeExtCont1,\
      &maTeMcsiNotificationToCse,\
      &maTeMcsiCsiActive,\
   &maTeSeqTerm,\
   &maTeVcsiSmsCsiSeq,\
       &maTeVcsiScSmsCamTdpDataLst,\
          &maTeStdSmsCamTdpDataSeq,\
             &maTeScSctdSmsTrgDetPt,\
             &maTeScSctdSerKey,\
             &maTeScSctdGsmScfAddr,\
             &maTeScSctdDefSmsHandl,\
             &maTeExtCont4,\
          &maTeSeqTerm,\
       &maTeSeqTerm,\
       &maTeVcsiCamCapHandl,\
       &maTeExtCont2,\
       &maTeVcsiNotificationToCse,\
       &maTeVcsiCsiActive,\
   &maTeSeqTerm,\
   DEFINE_TCSI_SEQ(maTeVcsiTcsiSeq),\
   &maTeVcsiTbcsmCamTdpCritLst,\
      DEFINE_TBCSMCAMTDPCRIT_SEQ(maTeTbcsmCamTdpCritSeq),\
   &maTeSeqTerm,\
   DEFINE_DCSI_SEQ(maTeVcsiDCsiSeq),\
   DEFINE_SMS_CSI_SEQ(maTeVcsiMtSmsCsiSeq), \
   DEFINE_SMS_CAM_TDP_CRIT_SEQOF(maTeVcsiSmsTDPCritSeqOf), \
&maTeSeqTerm

#else /* MAP_REL5 */

#define DEFINE_VLRCAMSUBSINFO_SEQ(seqHeader)   \
&seqHeader,\
   DEFINE_OCSI_SEQ(maTeVcsiOcsiSeq),\
   &maTeExtCont1,\
   DEFINE_SSCSI_SEQ(maTeVcsiSsCsiSeq),\
   &maTeVcsiObcsmCamTdpCritLst,\
      DEFINE_OBCSMCAMTDPCRIT_SEQ(maTeOctcObcsmCamTdpCritSeq),\
   &maTeSeqTerm, \
   &maTeVcsiTifCsi,\
   &maTeVcsiMCsiSeq,\
      &maTeMcsiMobilityTrigLst,\
         &maTeMtMmCode,\
      &maTeSeqTerm,\
      &maTeObctdSerKey,\
      &maTeObctdGsmSCFAddr,\
      &maTeExtCont1,\
      &maTeMcsiNotificationToCse,\
      &maTeMcsiCsiActive,\
   &maTeSeqTerm,\
   &maTeVcsiSmsCsiSeq,\
       &maTeVcsiScSmsCamTdpDataLst,\
          &maTeStdSmsCamTdpDataSeq,\
             &maTeScSctdSmsTrgDetPt,\
             &maTeScSctdSerKey,\
             &maTeScSctdGsmScfAddr,\
             &maTeScSctdDefSmsHandl,\
             &maTeExtCont4,\
          &maTeSeqTerm,\
       &maTeSeqTerm,\
       &maTeVcsiCamCapHandl,\
       &maTeExtCont2,\
       &maTeVcsiNotificationToCse,\
       &maTeVcsiCsiActive,\
   &maTeSeqTerm,\
   DEFINE_TCSI_SEQ(maTeVcsiTcsiSeq),\
   &maTeVcsiTbcsmCamTdpCritLst,\
      DEFINE_TBCSMCAMTDPCRIT_SEQ(maTeTbcsmCamTdpCritSeq),\
   &maTeSeqTerm,\
   DEFINE_DCSI_SEQ(maTeVcsiDCsiSeq),\
&maTeSeqTerm
#endif /* MAP_REL5 */
#else  /* MAP_REL99 */
#if MAP_REL98
#define DEFINE_VLRCAMSUBSINFO_SEQ(seqHeader)   \
&seqHeader,\
   DEFINE_OCSI_SEQ(maTeVcsiOcsiSeq),\
   &maTeExtCont1,\
   DEFINE_SSCSI_SEQ(maTeVcsiSsCsiSeq),\
   &maTeVcsiObcsmCamTdpCritLst,\
      DEFINE_OBCSMCAMTDPCRIT_SEQ(maTeOctcObcsmCamTdpCritSeq),\
   &maTeSeqTerm, \
   &maTeVcsiTifCsi,\
&maTeSeqTerm
#else  /* MAP_REL98 */
#define DEFINE_VLRCAMSUBSINFO_SEQ(seqHeader)   \
&seqHeader,\
   DEFINE_OCSI_SEQ(maTeVcsiOcsiSeq),\
   &maTeExtCont1,\
   DEFINE_SSCSI_SEQ(maTeVcsiSsCsiSeq),\
   &maTeVcsiObcsmCamTdpCritLst,\
      DEFINE_OBCSMCAMTDPCRIT_SEQ(maTeOctcObcsmCamTdpCritSeq),\
   &maTeSeqTerm, \
&maTeSeqTerm
#endif /* MAP_REL98 */
#endif /* MAP_REL99 */

#if (MAP_VLR || MAP_HLR)
PRIVATE MaTknElmtDef maTeEssSsCode =   /* SS-Code               */
     DEFINE_U8(LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeEssBasServCodeChoice =   /* Basic Service Code    */
     DEFINE_CHOICE(sizeof(MaBasicServ),LMA_VER1AND2,MA_TF_VER1AND2_OPT3);

PRIVATE MaTknElmtDef maTeEssBscBearCode =   /* Bear   code           */
     DEFINE_TAG_U8(MA_TAG_CSPRIM2,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeEssBscTeleCode =   /* Tele Code             */
     DEFINE_TAG_U8(MA_TAG_CSPRIM3,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);
#endif

#if MAP_REL99
#else     

#ifdef MAP_PHASE2_EXT_MARK
#define DEFINE_SSFORBSCODE_SEQ  \
 &maTeSeqMand,  \
    &maTeEssSsCode,  \
    &maTeEssBasServCodeChoice,  \
       &maTeEssBscBearCode,  \
       &maTeEssBscTeleCode,  \
    &maTeSeqTerm,\
    &maTeExtMark,\
 &maTeSeqTerm
#else
#define DEFINE_SSFORBSCODE_SEQ  \
 &maTeSeqMand,  \
    &maTeEssSsCode,  \
    &maTeEssBasServCodeChoice,  \
       &maTeEssBscBearCode,  \
       &maTeEssBscTeleCode,  \
    &maTeSeqTerm,\
 &maTeSeqTerm
#endif
#endif
#if MAP_REL99          

#if (MAP_VLR || MAP_HLR)
PRIVATE MaTknElmtDef maTeEssLongFtnSup =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM4,LMA_VER2,MA_TF_VER2P_OPT);
#endif

#ifdef MAP_PHASE2_EXT_MARK
#define DEFINE_SSFORBSCODE_SEQ  \
 &maTeSeqMand,  \
    &maTeEssSsCode,  \
    &maTeEssBasServCodeChoice,  \
       &maTeEssBscBearCode,  \
       &maTeEssBscTeleCode,  \
    &maTeSeqTerm,\
    &maTeEssLongFtnSup,\
    &maTeExtMark,\
 &maTeSeqTerm
#else
#define DEFINE_SSFORBSCODE_SEQ  \
 &maTeSeqMand,  \
    &maTeEssSsCode,  \
    &maTeEssBasServCodeChoice,  \
       &maTeEssBscBearCode,  \
       &maTeEssBscTeleCode,  \
    &maTeSeqTerm,\
    &maTeEssLongFtnSup,\
 &maTeSeqTerm
#endif

#endif /* MAP_REL99 */

#if (MAP_REL98 || MAP_REL99)
/* Ext. signal Info */
/******************/
#if (MAP_MSC || MAP_VLR || MAP_HLR)
PRIVATE MaTknElmtDef maTeExtProtId =   /* Ext. Protocol Id */
     DEFINE_U_ENUM(LMA_VER2P,MA_TF_VER2P_MAND,maChkExtProtId,maExtProtIdEnums);

PRIVATE MaTknElmtDef maTeSigInfo = /* signal info (mand.) */
     DEFINE_STRE(1,200,LMA_VER2P,MA_TF_VER2P_MAND);
#endif

#define DEFINE_EXTEXTSIGINFO_SEQ(seqHeader) \
 &seqHeader,\
    &maTeExtProtId,\
    &maTeSigInfo,\
    &maTeExtCont,                             \
 &maTeSeqTerm

#endif /* MAP_REL98 || MAP_REL99 */

/************************************************************/
/* End of Defines                                           */
/************************************************************/

#if (MAP_VLR || MAP_HLR || MAP_GSN)
/* ma006.203: Moved the definition of maTeRspAddCap under the above 
   flag combination */
/* Addition: upgrade for MAP release 6 */
#if MAP_REL6
PRIVATE MaTknElmtDef maTeRspAddCap = /* Additional Capability */
     DEFINE_NULL(LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MAP_REL6 */
#endif /* (MAP_VLR || MAP_HLR || MAP_GSN) */


/* -------------------------------------------------------------------- */
/* Update Location Request and Response                                 */
/* -------------------------------------------------------------------- */

#if (MAP_VLR || MAP_HLR)

PRIVATE MaTknElmtDef maTeUlVlrCapSeq =  /* Vlr Capability  sequence */
        DEFINE_TAG_SEQ(MA_TAG_CSCONST6,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeVcSuppCamPhases =  /* Supported camel phases */
        DEFINE_TAG_BITSTR(MA_TAG_CSPRIM0,1,16,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeUlImsi = /* IMSI */
        DEFINE_STRS(3,8,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeUlLocInfoChoice =  /* LocInfo Choice */
        DEFINE_CHOICE(sizeof(MaLocInfoVer1And2),LMA_VER1AND2,MA_TF_VER1AND2_OPT3);

PRIVATE MaTknElmtDef maTeUlLiRoamNmb = /* location info Roaming number */
        DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeUlLiMscNmb = /* location info Msc number */
        DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeUlMscNmb = /*  Msc number */
        DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeUlVlrNmb = /* Vlr Number  */
        DEFINE_STRS(1,9,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeUlLmsi = /* LMSI optional */
        DEFINE_TAG_STRS(MA_TAG_CSPRIM10,4,4,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeUlProtChoice =  /* Protocol Choice */
        DEFINE_CHOICE(sizeof(MaUlLocInfo),LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

#if (MAP_REL98 || MAP_REL99) 

PRIVATE MaTknElmtDef maTeUlSolsaSuppInd  = /* Solsa Support Indicator */
        DEFINE_TAG_NULL(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MAP_REL98 || MAP_REL99 */

#if MAP_REL99  
PRIVATE MaTknElmtDef maTeUlIstSupInd =
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT,maChkIstSupInd,maIstSupIndEnums);

PRIVATE MaTknElmtDef maTeUlSupCharSuppInSerNetEntChoice = 
     DEFINE_TAG_CHOICE(sizeof(MaSupCharSuppInServNetEnt),MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSndSubsData  =  /* Send Subscriber Data */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSubsDataStored  =  /* Subs. Data Stored */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1, 6,LMA_VER2P,MA_TF_VER2P_OPT); 

PRIVATE MaTknElmtDef maTeUlLongFtnSup =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeUlInfPrevNetEnt =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM11,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL4
PRIVATE MaTknElmtDef maTeUlSuppLcsCapSets = 
        DEFINE_TAG_BITSTR(MA_TAG_CSPRIM5,2,16,LMA_VER2P,MA_TF_VER2P_OPT);
#endif 

 /* Addition - upgrade for MAP release 5 */
#if MAP_REL5
PRIVATE MaTknElmtDef maTeUlCsLcsNotSupbyUE =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM12,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeVcOffCam4CSIs =
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM6,7,16,LMA_VER2P,MA_TF_VER2P_OPT);
/* Addition - upgrade for MAP release 6 */
#if MAP_REL6
PRIVATE MaTknElmtDef maTeUlVgmlcAddr =
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,5,17,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeUlAddInfoSeq = 
      DEFINE_TAG_SEQ(MA_TAG_CSCONST13,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeUlAddInfoImeisv =
      DEFINE_TAG_STRS(MA_TAG_CSPRIM0,8,8,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeUlAddInfoSkipSubsDatUp =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);

#endif /* MAP_REL6 */
#endif /* MAP_REL5 */

#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef *maUpLocReqTkns[] = /* update location request */
{
 &maTeSeqMand,
 &maTeUlImsi,
 /* Choice introduced because of the protocol differences */
 &maTeUlProtChoice,
    /* location information choice applicable for Ver 1&2*/
    &maTeUlLocInfoChoice,
       &maTeUlLiRoamNmb,
       &maTeUlLiMscNmb,
    &maTeSeqTerm,
    /* Msc Number applicable for only version 2+ */
    &maTeUlMscNmb,
 &maTeSeqTerm,
 &maTeUlVlrNmb,
 &maTeUlLmsi,
#ifdef MAP_PHASE2_EXT_MARK
 &maTeExtMark,
#endif
 #ifdef XWEXT
 &maXWExtCont,
 #else
 &maTeExtCont,
 #endif
 /* Vlr Capability sequence */
 &maTeUlVlrCapSeq,
    &maTeVcSuppCamPhases,
    &maTeExtCont,
#if (MAP_REL98 || MAP_REL99)
    &maTeUlSolsaSuppInd,
#endif /* MAP_REL98 || MAP_REL99 */
#if MAP_REL99    
    &maTeUlIstSupInd,
    &maTeUlSupCharSuppInSerNetEntChoice,
        &maTeSndSubsData,
        &maTeSubsDataStored,
    &maTeSeqTerm,
    &maTeUlLongFtnSup,
#if MAP_REL4
    &maTeUlSuppLcsCapSets,
    /* Addition - upgrade for MAP release 5 */
#if MAP_REL5
    &maTeVcOffCam4CSIs,
#endif /* MAP_REL5 */
#endif 
#endif /* MAP_REL99 */
 &maTeSeqTerm,
#if MAP_REL99
 &maTeUlInfPrevNetEnt,
 /* Addition - upgrade for MAP release 5 */
#if MAP_REL5
 &maTeUlCsLcsNotSupbyUE,
/* Addition - upgrade for MAP release 6 */
#if MAP_REL6
 &maTeUlVgmlcAddr,
 &maTeUlAddInfoSeq,
    &maTeUlAddInfoImeisv,
    &maTeUlAddInfoSkipSubsDatUp,
  &maTeSeqTerm,
#endif /* MAP_REL6 */
#endif /* MAP_REL5 */
#endif /* MAP_REL99 */
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTeUlRspChoice =  /* Update Location Response Choice */
        DEFINE_CHOICE(sizeof(MaUpLocRsp),LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeUlrHlrNmb  =  /* Update Location Response Choice */
        DEFINE_STRS(1,9,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeExtUlrSeq  =  /* Update Location Response Choice */
        DEFINE_SEQ(LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeEulrHlrNmb =  /* Update Location Response Choice */
        DEFINE_STRS(1,9,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

/* ma006.203: Moved the definition of maTeRspAddCap under the 
   flag combination  MAP_VLR || MAP_HLR || MAP_GSN */

PRIVATE MaTknElmtDef *maUpLocRspTkns[] = /* update location response */
{
 &maTeUlRspChoice,
    &maTeUlrHlrNmb,
    &maTeExtUlrSeq,
       &maTeEulrHlrNmb, 
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
       &maTeExtCont,
/* Addition: upgrade for MAP release 6 */
#if MAP_REL6 
       &maTeRspAddCap,
#endif /* MAP_REL6 */
    &maTeSeqTerm,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_VLR || MAP_HLR */

/* -------------------------------------------------------------------- */
/* Cancel Location Request and Response                                 */
/* -------------------------------------------------------------------- */

#if (MAP_VLR || MAP_HLR || MAP_GSN)

PRIVATE MaTknElmtDef maTeClProtChoice = /* Cancel location protocol choice */
        DEFINE_CHOICE(sizeof(MaCancelLocReq),LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeClVer2pSeq = /* can. loc Ver 2 plus sequence */
        DEFINE_TAG_SEQ(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeV2pIdChoice = /* Ver 2 plus identity choice */
        DEFINE_CHOICE(sizeof(MaCanLocId),LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeIdImsi = /* IMSI */
        DEFINE_STRS(3,8,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeIdImsiWLmsiSeq = /* IMSI with LMSI sequence*/
        DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeV2pIwlImsi = /* IMSI */
        DEFINE_STRS(3,8,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeV2pIwlLmsi = /* LMSI  */
        DEFINE_STRS(4,4,LMA_VER2P,MA_TF_VER2P_MAND);


PRIVATE MaTknElmtDef maTeClCanType =  /* Cancellation Type */
        DEFINE_ENUM(LMA_VER2P,MA_TF_VER2P_OPT,maCancelTypeEnums);

PRIVATE MaTknElmtDef maTeClVer1And2Choice = /* Ver 1 & 2  choice */
       DEFINE_CHOICE(sizeof(MaCanLocVer1And2),LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeV12Imsi = /* IMSI */
        DEFINE_STRS(3,8,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeV12ImsiWLmsiSeq = /* IMSI with LMSI sequence*/
        DEFINE_SEQ(LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeV12IwlImsi = /* IMSI */
        DEFINE_STRS(3,8,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeV12IwlLmsi = /* LMSI  */
        DEFINE_STRS(4,4,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef *maCancelLocReqTkns[] = /* cancel location request */
{
 
 &maTeClProtChoice,

 /* For Version 2+ */
 &maTeClVer2pSeq,
    /* Identity Choice */
    &maTeV2pIdChoice,
       &maTeIdImsi,
       /* ImsiWLmsiSeq */
       &maTeIdImsiWLmsiSeq,
          &maTeV2pIwlImsi,
          &maTeV2pIwlLmsi,
/* Extension marker added here is for structure reuse and **
** is not effective for 2P definitions.                   ** 
*/
#ifdef MAP_PHASE2_EXT_MARK
          &maTeExtMark,
#endif
       &maTeSeqTerm,
    &maTeSeqTerm,
    &maTeClCanType,
    &maTeExtCont,
 &maTeSeqTerm,

 /* For version 1 & 2 */ 
 &maTeClVer1And2Choice,
    &maTeV12Imsi,
    /* ImsiWLmsiSeq */
    &maTeV12ImsiWLmsiSeq,
       &maTeV12IwlImsi,
       &maTeV12IwlLmsi,
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
    &maTeSeqTerm,
 &maTeSeqTerm,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maCancelLocRspTkns[] = /* cancel location response */
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

/* -------------------------------------------------------------------- */
/* Send Identification Request and Response                             */
/* -------------------------------------------------------------------- */

#if MAP_VLR

PRIVATE MaTknElmtDef maTeSiAslAuthSetSeq =   /* Auth Set Seq      */
     DEFINE_SEQ(LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTeSiAslAsRand =   /* Rand                  */
     DEFINE_STRS(16,16,LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef maTeSiAslAsSres =   /* SRes                  */
     DEFINE_STRS(4,4,LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef maTeSiAslAsKc =   /* Kc                    */
     DEFINE_STRS(8,8,LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef maTeSiAuthSetLst =   /* Auth Set Lst          */
     DEFINE_SEQOF(LMA_VER2,MAT_MAX_AUTHSET,MA_TF_VER2_OPT);

#if MAP_REL99
#else

PRIVATE MaTknElmtDef maTeSiTmsi =   /* TMSI                  */
     DEFINE_STRS(1,4,LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef *maSndIdReqTkns[] = /* Send Id request */
{
 &maTeSiTmsi,
 NULLP,
};

PRIVATE MaTknElmtDef maTeSndIdRspSeq =   /* Snd Id Rsp Seq        */
     DEFINE_SEQ(LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef maTeSiImsi =   /* Imsi                       */
     DEFINE_STRS(3,8,LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef *maSndIdRspTkns[] = /* Send Id request */
{
 &maTeSndIdRspSeq,
    &maTeSiImsi,
    &maTeSiAuthSetLst,
       &maTeSiAslAuthSetSeq,
          &maTeSiAslAsRand,
          &maTeSiAslAsSres,
          &maTeSiAslAsKc,
#ifdef MAP_PHASE2_EXT_MARK
          &maTeExtMark,
#endif
       &maTeSeqTerm,
    &maTeSeqTerm,
#ifdef MAP_PHASE2_EXT_MARK
 &maTeExtMark,
#endif
 &maTeSeqTerm,
 NULLP,
};

#endif
#if MAP_REL99            

PRIVATE MaTknElmtDef maTeSndIdReqSeq =   /* Snd Id Rsp Seq        */
     DEFINE_U_SEQ(LMA_VER2P,MA_TF_VER2P_MAND,maChkSeq0);

PRIVATE MaTknElmtDef maTeSiTmsi =   /* TMSI */
     DEFINE_STRS(1,4,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeSiNmbReqVectors  =  /* Number of Requested Vectors */
     DEFINE_INT(1,5,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSiSegProhibited  =  /* Segmentation Prohibited */
     DEFINE_NULL(LMA_VER2P,MA_TF_VER2P_OPT);
/* Addition: upgrade for MAP release 6 */
#if MAP_REL6
PRIVATE MaTknElmtDef maTeSiMscNmb = /* MSC Number */
     DEFINE_STRS(1,MAT_MAX_ISDN_ADDR_LEN,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MAP_REL6 */

PRIVATE MaTknElmtDef *maSndIdReqTkns[] = /* Send Id request */
{
 &maTeSndIdReqSeq,
    &maTeSiTmsi,
    &maTeSiNmbReqVectors,
    &maTeSiSegProhibited,
    &maTeExtCont,
/* Addition: upgrade for MAP release 6 */
#if MAP_REL6
     &maTeSiMscNmb,
#endif /* MAP_REL6 */
 &maTeSeqTerm, 
 NULLP,
};

PRIVATE MaTknElmtDef maTeSndIdRspSeq =   /* Snd Id Rsp Seq        */
     DEFINE_TAG_U_SEQ(MA_TAG_CSCONST3,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0,maChkSeq2);

PRIVATE MaTknElmtDef maTeSiImsi =   /* Imsi */
     DEFINE_STRS(3,8,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT2);

PRIVATE MaTknElmtDef maTeSiAuthSetLstChoice = 
     DEFINE_CHOICE(sizeof(MaAuthSetList),LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSiTripletLst = /* Triple List */
    DEFINE_TAG_SEQOF(MA_TAG_CSCONST0,LMA_VER2P,MAT_MAX_AUTHSET,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSiAuthTripletSeq = /* Triple List */
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSiAiSres  =  /* Sres */
     DEFINE_STRS(4,4,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeSiAikc  =  /* kc */
     DEFINE_STRS(8,8,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeSiQuintupletLst = /* Quintuplet List */
    DEFINE_TAG_SEQOF(MA_TAG_CSCONST1,LMA_VER2P,MAT_MAX_AUTHSET,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSiAuthQuintupletSeq = /* Quintuplet List Seq */
    DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSiAiRand  =  /* Rand */
     DEFINE_STRS(16,16,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeSiAiXres  =  /* Xres */
     DEFINE_STRS(4,16,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeSiAiCk  =  /* Ck */
     DEFINE_STRS(16,16,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeSiAiIk  =  /* Ik */
     DEFINE_STRS(16,16,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeSiAiAutn  =  /* Autn */
     DEFINE_STRS(16,16,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeSiCurSecContextChoice =
     DEFINE_TAG_CHOICE(sizeof(MaCurSecContext),MA_TAG_CSCONST2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSiGsmSecContextData = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSiKc =   /* Kc                    */
     DEFINE_STRS(8,8,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeSiCksn =
     DEFINE_U8(LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeSiUmtsSecContextData = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSiCk  =  /* Ck */
     DEFINE_STRS(16,16,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeSiIk  =  /* Ik */
     DEFINE_STRS(16,16,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeSiKsi =
     DEFINE_U8(LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef *maSndIdRspTkns[] = /* Send Id request */
{
 &maTeSndIdRspSeq,
    &maTeSiImsi,
    &maTeSiAuthSetLst,
       &maTeSiAslAuthSetSeq,
          &maTeSiAslAsRand,
          &maTeSiAslAsSres,
          &maTeSiAslAsKc,
#ifdef MAP_PHASE2_EXT_MARK
          &maTeExtMark,
#endif
       &maTeSeqTerm,
    &maTeSeqTerm,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTeSiAuthSetLstChoice,
       &maTeSiTripletLst,
          &maTeSiAuthTripletSeq,
             &maTeSiAiRand,
             &maTeSiAiSres,
             &maTeSiAikc,
/* Extension marker added here is for structure reuse and **
** is not effective for 2P definitions.                   ** 
*/
#ifdef MAP_PHASE2_EXT_MARK
             &maTeExtMark,
#endif
          &maTeSeqTerm,
       &maTeSeqTerm,
       &maTeSiQuintupletLst,
          &maTeSiAuthQuintupletSeq,
             &maTeSiAiRand,
             &maTeSiAiXres,
             &maTeSiAiCk,
             &maTeSiAiIk,
             &maTeSiAiAutn,
          &maTeSeqTerm,
       &maTeSeqTerm,
    &maTeSeqTerm,
    &maTeSiCurSecContextChoice,
       &maTeSiGsmSecContextData,
          &maTeSiKc,
          &maTeSiCksn,
       &maTeSeqTerm,
       &maTeSiUmtsSecContextData,
          &maTeSiCk,
          &maTeSiIk,
          &maTeSiKsi,
       &maTeSeqTerm,
    &maTeSeqTerm,
    &maTeExtCont3,
 &maTeSeqTerm,
 NULLP,
};
#endif /* MAP_REL99 */

#endif  /* MAP_VLR */

/* -------------------------------------------------------------------- */
/* Purge MS Request and Response                                        */
/* -------------------------------------------------------------------- */

#if (MAP_VLR || MAP_HLR || MAP_GSN)

PRIVATE MaTknElmtDef maTePurgeMsReqChoice =   /* Choice for the prot.diff */
     DEFINE_CHOICE(sizeof(MaPurgeMsReq),LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTePurgeMsVer2Seq =   /* Version 2 Sequence    */
     DEFINE_SEQ(LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTePmsVer2Imsi =   /* Version 2 Imsi        */
     DEFINE_STRS(3,8,LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef maTePmsVer2VlrNmb =   /* Version 2 Vlr Number  */
     DEFINE_STRS(1,9,LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef maTePurgeMsVer2PSeq =   /* Version 2P sequence   */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePmsVer2PImsi =   /* Version 2P Imsi       */
     DEFINE_STRS(3,8,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTePmsVer2PVlrNmb =   /* Version 2P Vlr Nmb       */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePmsVer2PSgsnNmb =   /* Sgsn Number           */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maPurgeReqTkns[] = /* purge Ms request */
{
 &maTePurgeMsReqChoice,
    &maTePurgeMsVer2Seq,
       &maTePmsVer2Imsi,
       &maTePmsVer2VlrNmb,
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
    &maTeSeqTerm,

    &maTePurgeMsVer2PSeq,
       &maTePmsVer2PImsi,
       &maTePmsVer2PVlrNmb,
       &maTePmsVer2PSgsnNmb,
       &maTeExtCont,
    &maTeSeqTerm,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTePmsFrzTmsi =   /* Frz. Tmsi             */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT );

PRIVATE MaTknElmtDef maTePmsFrzPTmsi =   /* Frz PTmsi             */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maPurgeRspTkns[] = /* purge Ms request */
{
 &maTeSeqOptVer2P,
    &maTePmsFrzTmsi,
    &maTePmsFrzPTmsi,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

/* -------------------------------------------------------------------- */
/* Send Authentication Information Request and Response                 */
/* -------------------------------------------------------------------- */

#if (MAP_VLR || MAP_HLR || MAP_GSN)

PRIVATE MaTknElmtDef maTeAiAuthSetLst =   /* Auth Set Lst          */
     DEFINE_SEQOF(LMA_VER2,MAT_MAX_AUTHSET,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTeAiAslAuthSetSeq =   /* Auth Set Sequence     */
     DEFINE_SEQ(LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTeAiAslAsRand =   /* Rand                  */
     DEFINE_STRS(16,16,LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef maTeAiAslAsSres =   /* SRes                  */
     DEFINE_STRS(4,4,LMA_VER2,MA_TF_VER2_MAND);

#ifdef XWEXT
PRIVATE MaTknElmtDef maTeAiAslAsKc =   /* Kc                    */
     DEFINE_STRS(12,12,LMA_VER2,MA_TF_VER2_MAND);
#else
PRIVATE MaTknElmtDef maTeAiAslAsKc =   /* Kc                    */
     DEFINE_STRS(8,8,LMA_VER2,MA_TF_VER2_MAND);
#endif

#if MAP_REL99
#else

PRIVATE MaTknElmtDef maTeAiImsi =   /* Imsi                  */
     DEFINE_STRS(3,8,LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef *maAuthInfoReqTkns[] = /* Authintication info request */
{
 &maTeAiImsi,
 NULLP,
};

PRIVATE MaTknElmtDef *maAuthInfoRspTkns[] = /* Authintication info response */
{
 &maTeAiAuthSetLst,
    &maTeAiAslAuthSetSeq,
       &maTeAiAslAsRand,
       &maTeAiAslAsSres,
       &maTeAiAslAsKc,
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
    &maTeSeqTerm,
 &maTeSeqTerm,
 NULLP,
};

#endif
#if MAP_REL99          

PRIVATE MaTknElmtDef maTeAuthInfoReq = 
     DEFINE_U_SEQ(LMA_VER2P,MA_TF_VER2P_OPT,maChkSeq0);

PRIVATE MaTknElmtDef maTeAiImsi =   /* Imsi                  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeAiNmbReqVectors  =  /* Number of Requested Vectors */
     DEFINE_INT(1,5,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeAiSegProhibited  =  /* Segmentation Prohibited */
     DEFINE_NULL(LMA_VER2P,MA_TF_VER2P_OPT);

/* Immediate response preferred */
PRIVATE MaTknElmtDef maTeAiImmResPreferred  =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAiResyncInfoSeq  =  /* Resynchronisation Info */
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAiRand  =  /* Rand */
     DEFINE_STRS(16,16,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeAiAuts  =  /* Auts */
     DEFINE_STRS(14,14,LMA_VER2P,MA_TF_VER2P_MAND);

#if MAP_REL4
PRIVATE MaTknElmtDef maTeAiReqNodeType = 
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_OPT,maChkReqNodeType,maReqNodeTypeEnums);
#endif
/* Addition : upgrade for MAP release 6 */
#if MAP_REL6
PRIVATE MaTknElmtDef maTeAiReqPlmnId =
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,3,3,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MAP_REL6 */

PRIVATE MaTknElmtDef *maAuthInfoReqTkns[] = /* Authintication info request */
{
 &maTeAuthInfoReq,
    &maTeAiImsi,
    &maTeAiNmbReqVectors,
    &maTeAiSegProhibited,
    &maTeAiImmResPreferred,
    &maTeAiResyncInfoSeq,
       &maTeAiRand,
       &maTeAiAuts,
    &maTeSeqTerm,
    &maTeExtCont2,
#if MAP_REL4
    &maTeAiReqNodeType,
/* Addition : upgrade for MAP release 6 */
#if MAP_REL6
    &maTeAiReqPlmnId,
#endif /* MAP_REL6 */
#endif
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTeSendAuthInfoRspSeq =  /* Version 2P sequence */
     DEFINE_TAG_U_SEQ(MA_TAG_CSCONST3,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3,maChkSeq1);

/*Authentication Set List Choice */
PRIVATE MaTknElmtDef maTeAsAuthSetLstChoice = 
     DEFINE_CHOICE(sizeof(MaAuthSetList),LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAslTripletLst = /* Triple List */
    DEFINE_TAG_SEQOF(MA_TAG_CSCONST0,LMA_VER2P,MAT_MAX_AUTHSET,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeTlAuthTripletSeq = /* Triple List */
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAiSres  =  /* Sres */
     DEFINE_STRS(4,4,LMA_VER2P,MA_TF_VER2P_MAND);

#ifdef XWEXT /* xingzhou.xu: modified according to V1.23 2006/10/16 */
PRIVATE MaTknElmtDef maTeAikc  =  /* kc */
     DEFINE_STRS(12,12,LMA_VER2P,MA_TF_VER2P_MAND);
#else
PRIVATE MaTknElmtDef maTeAikc  =  /* kc */
     DEFINE_STRS(8,8,LMA_VER2P,MA_TF_VER2P_MAND);
#endif /* XWEXT */

PRIVATE MaTknElmtDef maTeAslQuintupletLst = /* Quintuplet List */
    DEFINE_TAG_SEQOF(MA_TAG_CSCONST1,LMA_VER2P,MAT_MAX_AUTHSET,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeTlAuthQuintupletSeq = /* Quintuplet List Seq */
    DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAiXres  =  /* Xres */
     DEFINE_STRS(4,16,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeAiCk  =  /* Ck */
     DEFINE_STRS(16,16,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeAiIk  =  /* Ik */
     DEFINE_STRS(16,16,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeAiAutn  =  /* Autn */
     DEFINE_STRS(16,16,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef *maAuthInfoRspTkns[] = /* Authentication info response */
{
 &maTeSendAuthInfoRspSeq,
    &maTeAiAuthSetLst,
       &maTeAiAslAuthSetSeq,
          &maTeAiAslAsRand,
          &maTeAiAslAsSres,
          &maTeAiAslAsKc,
/* Extension marker added here is for structure reuse and **
** is not effective for 2P definitions.                   ** 
*/
#ifdef MAP_PHASE2_EXT_MARK
          &maTeExtMark,
#endif
       &maTeSeqTerm,
    &maTeSeqTerm,
    &maTeAsAuthSetLstChoice,
       &maTeAslTripletLst,
          &maTeTlAuthTripletSeq,
             &maTeAiRand,
             &maTeAiSres,
             &maTeAikc,
/* Extension marker added here is for structure reuse and **
** is not effective for 2P definitions.                   ** 
*/
#ifdef MAP_PHASE2_EXT_MARK
             &maTeExtMark,
#endif
          &maTeSeqTerm,
       &maTeSeqTerm,
       &maTeAslQuintupletLst,
          &maTeTlAuthQuintupletSeq,
             &maTeAiRand,
             &maTeAiXres,
             &maTeAiCk,
             &maTeAiIk,
             &maTeAiAutn,
          &maTeSeqTerm,
       &maTeSeqTerm,
    &maTeSeqTerm,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_REL99 */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if MAP_REL99
/* -------------------------------------------------------------------- */
/* MAP Authentication Failure Report                                    */
/* -------------------------------------------------------------------- */

#if (MAP_VLR || MAP_HLR || MAP_GSN)

PRIVATE MaTknElmtDef maTeAfrImsi =  /* Imsi */
     DEFINE_STRS(3,8,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeAfrFailureCause =  /* Failure Cause */
    DEFINE_ENUM(LMA_VER2P,MA_TF_VER2P_MAND,maFailureCauseEnums);

#if MAP_REL4
PRIVATE MaTknElmtDef maTeAfrReAttempt = 
     DEFINE_BOOL(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAfrAccessType =
     DEFINE_U_ENUM(LMA_VER2P,MA_TF_VER2P_OPT,maChkAccessType,maAccessTypeEnums);

PRIVATE MaTknElmtDef maTeAfrRand = 
     DEFINE_STRS(16,16,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAfrVlrNmb =
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1, 9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAfrSgsnNmb =
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1, 9,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MAP_REL4 */

PRIVATE MaTknElmtDef *maAuthFailRptReqTkns[] = /* Authentication Failure Rpt req */
{
 &maTeSeqMandVer2P,
  &maTeAfrImsi,
  &maTeAfrFailureCause,
  &maTeExtCont,
#if MAP_REL4
  &maTeAfrReAttempt,
  &maTeAfrAccessType,
  &maTeAfrRand,
  &maTeAfrVlrNmb,
  &maTeAfrSgsnNmb,
#endif /* MAP_REL4 */
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maAuthFailRptRspTkns[] = /* Authentication Failure Rpt resp */
{
 &maTeSeqOptVer2P,
  &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#endif /* MAP_REL99 */

/* -------------------------------------------------------------------- */
/* MAP Reset Request                                                    */
/* -------------------------------------------------------------------- */

#if (MAP_VLR || MAP_HLR || MAP_GSN)

PRIVATE MaTknElmtDef maTeResNetRes =  /* Network resources */
    DEFINE_ENUM(LMA_VER1,MA_TF_VER1_MAND,maNetResEnums);

PRIVATE MaTknElmtDef maTeResHlrIdSeqof =  /* Hlrd Id Sequence */
    DEFINE_SEQOF(LMA_VER1AND2,MAT_MAX_HLRID,MA_TF_VER1AND2_OPT3);

PRIVATE MaTknElmtDef maTeRhiHlrId =  /* Hlrd Id */
    DEFINE_STRS(3,8,LMA_VER1AND2,MA_TF_VER1AND2_OPT3);

PRIVATE MaTknElmtDef maTeResHlrNmb =  /* HLR Nmb  */
    DEFINE_STRS(1,9,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef *maResetReqTkns[] = /* Reset Request */
{
 &maTeSeqMand,
 &maTeResNetRes,
 &maTeResHlrNmb,
 &maTeResHlrIdSeqof,
    &maTeRhiHlrId,
 &maTeSeqTerm,
#ifdef MAP_PHASE2_EXT_MARK
 &maTeExtMark,
#endif
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

/* -------------------------------------------------------------------- */
/* Restore Data Request and Response                                    */
/* -------------------------------------------------------------------- */

#if (MAP_VLR || MAP_HLR)

PRIVATE MaTknElmtDef maTeRdVcSupCamPhase =   /* Supported Camel Phase */
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM0,1,16,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeRestoreDatSeq =   /* Restore Data Seq      */
     DEFINE_SEQ(LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeRdImsi =   /* Imsi                  */
     DEFINE_STRS(3,8,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeRdLmsi =   /* Lmsi                  */
     DEFINE_STRS(4,4,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeRdVlrCapSeq =   /* Vlr Capability        */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST6,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maRestDatReqTkns[] = /* Restore Data Request */
{
 &maTeRestoreDatSeq,
    &maTeRdImsi,
    &maTeRdLmsi,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTeExtCont,
    &maTeRdVlrCapSeq,
       &maTeRdVcSupCamPhase,
       &maTeExtCont,
#if (MAP_REL98 || MAP_REL99)
       &maTeUlSolsaSuppInd,
#endif /* MAP_REL98 || MAP_REL99 */
#if MAP_REL99      
       &maTeUlIstSupInd,
       &maTeUlSupCharSuppInSerNetEntChoice,
          &maTeSndSubsData,
          &maTeSubsDataStored,
       &maTeSeqTerm,
       &maTeUlLongFtnSup,
#if MAP_REL4
       &maTeUlSuppLcsCapSets,
       /* Addition - upgrade for MAP release 5 */
#if MAP_REL5
       &maTeVcOffCam4CSIs,
#endif /* MAP_REL5 */
#endif 
#endif /* MAP_REL99 */
    &maTeSeqTerm,
 &maTeSeqTerm,
 NULLP,
};


PRIVATE MaTknElmtDef maTeRdHlrNmb =   /* Hlr Nmb               */
     DEFINE_STRS(1,9,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeRdMsNotRch =   /* Ms Not Reachable      */
     DEFINE_NULL(LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef *maRestDatRspTkns[] = /* Restore Data Response */
{

 &maTeRestoreDatSeq,
    &maTeRdHlrNmb,
    &maTeRdMsNotRch,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    #ifdef XWEXT
    &maXWExtCont,
    #else
    &maTeExtCont,
    #endif
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_VLR || MAP_HLR */

/* -------------------------------------------------------------------- */
/* Activate & Decactivate Trace Request and Response                    */
/* -------------------------------------------------------------------- */

#if (MAP_VLR || MAP_HLR || MAP_GSN)

PRIVATE MaTknElmtDef maTeAtImsi = /* IMSI */
    DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeAtRef =  /* Trace Reference */
    DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,2,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeAtType =  /* Trace Type */
    DEFINE_TAG_INT(MA_TAG_CSPRIM2,0,255,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeAtOmcId =  /* OMC Id */
    DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,20,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef *maActvTrReqTkns[] = /* Activate Trace request */
{
 &maTeSeqMand,
    &maTeAtImsi,
    &maTeAtRef,
    &maTeAtType,
    &maTeAtOmcId,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTeExtCont4,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maActvTrRspTkns[] = /* Activate Trace response */
{
 &maTeSeqOptVer2P,
    &maTeExtCont0,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maDactvTrReqTkns[] = /* Deactivate Trace request */
{
 &maTeSeqMand,
    &maTeAtImsi,
    &maTeAtRef,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTeExtCont2,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maDactvTrRspTkns[] = /* Deactivate Trace response */
{
 &maTeSeqOptVer2P,
    &maTeExtCont0,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

/* -------------------------------------------------------------------- */
/* Send IMSI Request                                                    */
/* -------------------------------------------------------------------- */

#if (MAP_VLR || MAP_HLR)

PRIVATE MaTknElmtDef maTeSimsiMsIsdn =   /* Ms-Isdn               */
     DEFINE_STRS(1,9,LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef *maSndIMSIReqTkns[] = /* Send IMSI request */
{
 &maTeSimsiMsIsdn,
 NULLP,
};

PRIVATE MaTknElmtDef maTeSimsiImsi =   /* Imsi                  */
     DEFINE_STRS(3,8,LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef *maSndIMSIRspTkns[] = /* Send IMSI response */
{
 &maTeSimsiImsi,
 NULLP,
};

#endif  /* (VLR) || (HLR) */

/* -------------------------------------------------------------------- */
/* Note Subscriber Present & Begin Subscriber Activity Request          */
/* -------------------------------------------------------------------- */

#if (MAP_VLR || MAP_HLR)

PRIVATE MaTknElmtDef maTeNoteSubsImsi =   /* Imsi                  */
     DEFINE_STRS(3,8,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef *maNotSubPresReqTkns[] = /* Note Subscriber pres. */
{ 
 &maTeNoteSubsImsi,
 NULLP,
};


PRIVATE MaTknElmtDef maTeBsaOrgEntNmb =   /* Origination Ent Nmb   */
     DEFINE_STRS(1,9,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeBsaImsi =   /*  Imsi       */
     DEFINE_STRS(3,8,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeBgnSubsActvSeq =   /* Bgn Subs Actv Seq     */
     DEFINE_SEQ(LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef *maBgnSubsActvReqTkns[] = /* Send IMSI request */
{
 &maTeBgnSubsActvSeq,
    &maTeBsaImsi,
    &maTeBsaOrgEntNmb,
 &maTeSeqTerm,
 NULLP,
};

#endif  /* (VLR) || (HLR) */

/* -------------------------------------------------------------------- */
/* Insert Subscriber Data Request and Response &                        */
/* Delete Subscriber Data Request and Response                          */
/* -------------------------------------------------------------------- */

#if (MAP_VLR || MAP_HLR || MAP_GSN)

#ifndef MA_SGSN_SPECIFIC
PRIVATE MaTknElmtDef maTeIsdVlrSubsInfoSeq =   /* Vlr Camel Subscriptoin Info */
  DEFINE_TAG_SEQ(MA_TAG_CSCONST13,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdVgcsDatLst =   /* Vgcs Subscription data */
  DEFINE_TAG_SEQOF(MA_TAG_CSCONST12,LMA_VER2P,MAT_MAX_VGCSSUBSDATA,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdVbsDatLst =   /* Vbs Subscription data */
  DEFINE_TAG_SEQOF(MA_TAG_CSCONST11,LMA_VER2P,MAT_MAX_VBSSUBSDATA,MA_TF_VER2P_OPT);
#endif /* MA_SGSN_SPECIFIC */

PRIVATE MaTknElmtDef maTeIsdZclZoneCode =   /* Zone Code             */
     DEFINE_STRS(2,2,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeIsdZoneCodeLst =   /* Zone Code list        */
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST10,LMA_VER2AND2P,MAT_MAX_ZONES,MA_TF_VER2AND2P_OPT3);
PRIVATE MaTknElmtDef maTeIsdRoamRestUF = /* Roam. Rest. due to unsup. Ftr */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM9,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeIsdOdOdbHplmnDat =   /* Odb. Hplmn data       */
     DEFINE_BITSTR(4,32,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

/*
** Version 2P defines bits upto 32.
** Version 2 defines upto 6.
** so we have defined the maximum to 32.
** So for version 2 also bits 7 to 32 are allowed by MAP.
** a Stricter check should be made by the MAP user.
*/
PRIVATE MaTknElmtDef maTeIsdOdOdbGenDat =   /* Odb. Gen Data         */
     DEFINE_BITSTR(6,32,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeIsdOdbDatSeq =   /* Odb Data Seq          */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST8,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

#ifndef MA_SGSN_SPECIFIC
PRIVATE MaTknElmtDef maTeIsdSsInfoChoice =   /* SS Info Choice        */
     DEFINE_CHOICE(sizeof(MaSSInfo),LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);
#endif /* MA_SGSN_SPECIFIC */
PRIVATE MaTknElmtDef maTeIsdEtslExtTeleServ =   /* Tele Service Code     */
     DEFINE_STRS(1,5,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeIsdExtTeleServLst =   /* Ext. Tele Serv. Lst   */
  DEFINE_TAG_SEQOF(MA_TAG_CSCONST6,LMA_VER1AND2AND2P,MAT_MAX_TELESERV,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeIsdImsi =   /* Imsi                  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeIsdMsIsdn =   /* MS Isdn               */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeIsdSubsStat =   /* Subscriber Status     */
  DEFINE_TAG_ENUM(MA_TAG_CSPRIM3,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7,maSubsStatEnums);

#ifndef MA_SGSN_SPECIFIC
PRIVATE MaTknElmtDef maTeIsdSubsCat =   /* Subscriber Category   */
     DEFINE_TAG_U8(MA_TAG_CSPRIM2,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeIsdExtBearServLst =   /* Ext. Bearer Service lst */
 DEFINE_TAG_SEQOF(MA_TAG_CSCONST4,LMA_VER1AND2AND2P,MAT_MAX_BEARSERV,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeIsdEbslExtBearServ =   /* Bearer Service Code   */
     DEFINE_STRS(1,5,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);
#endif /* MA_SGSN_SPECIFIC */
PRIVATE MaTknElmtDef maTeIsdGprsSubsDatSeq =   /* Gprs Subs DAta Seq   */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST16,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeGsdCompLstIncl =   /* Complete List Included */
     DEFINE_NULL(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeGsdGprsDatLst =   /* Gprs Data List        */
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST1,LMA_VER2P,MAT_MAXNUMOFPDP_CONTEXT,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeGsdGdlPdpCntxtSeq =   /* Pdp Context Seq      */
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeGdlPcPdpCntxtId =   /* Context Id            */
     DEFINE_INT(1, MAT_MAXNUMOFPDP_CONTEXT,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeGdlPcPdpType =   /* Pdp Type              */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM16,2,2,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeGdlPcPdpAddr =   /* Pdp Address           */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM17,1,16,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeGdlPcQosSubs =   /* qos Subscribed        */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM18,3,3,LMA_VER2P,MA_TF_VER2P_MAND);
 
PRIVATE MaTknElmtDef maTeGdlPcVplmnAddrAll =   /* Vplmn Addr All        */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM19,LMA_VER2P,MA_TF_VER2P_OPT);
 
PRIVATE MaTknElmtDef maTeGdlPcApn =   /* Access Point Name     */
     DEFINE_TAG_STRE(MA_TAG_CSPRIM20,2,63,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeIsdRoamRestInSgsnUF =   /* Roam.Rest.In.Sgsn UF  */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM23,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdNetAccMode =   /* Net Access Mode       */
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM24,LMA_VER2P,MA_TF_VER2P_OPT,maNetAccModeEnums);
#ifndef MA_SGSN_SPECIFIC
PRIVATE MaTknElmtDef maTeIsdSsInfoLst =   /* SSInfo List           */
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST7,LMA_VER1AND2AND2P,MAT_MAX_SS,MA_TF_VER1AND2AND2P_OPT7);
#endif /* MA_SGSN_SPECIFIC */

#if (MAP_REL98 || MAP_REL99)

#ifndef MA_SGSN_SPECIFIC
PRIVATE MaTknElmtDef maTeIsdLsaInfoSeq  =  /*LSA INFO Seq */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST25,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdLiCompDataListIncl  =  /* Complete Data List incl.*/
     DEFINE_NULL(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdLiLsaOnlyAccessInd  =  /* LSA only Access indicator */
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT,maLsaOnlyAccessIndEnums);

PRIVATE MaTknElmtDef maTeIsdLiLsaDataLst = /* Lsa Data List */
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST2,LMA_VER2P,MAT_MAX_NMB_LSA,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdLiLsaDataSeq  =  /*Lsa Data Seq */
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdLiLsaIdentity  =  /* LSA identity */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,3,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeIsdLiLsaActiveModeIndicator  =  /* Active Mode ind.*/
     DEFINE_TAG_NULL(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdLiLsaAttributes  =  /* LSA Attributes */
     DEFINE_TAG_U8(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeIsdLmuInd  =  /* LMU ind.*/
     DEFINE_TAG_NULL(MA_TAG_CSPRIM21,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MA_SGSN_SPECIFIC */
PRIVATE MaTknElmtDef maTeIsdLcsInfoSeq  =  /*LCS Info Seq*/
     DEFINE_TAG_SEQ(MA_TAG_CSCONST22,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdLiGmlcLst = /* GMLC List */
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST0,LMA_VER2P,MAT_MAX_NMB_GMLC,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdLiIsdnAddrStr  =  /* Isdn String */
     DEFINE_STRS(1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdLiLcsPrivacyExcepLst = /* LCS Privacy List */
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST1,LMA_VER2P,MAT_MAX_NMB_PRIVACYCLASS,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdLiLcsPrivacyClassSeq  =  /*LCS privacy class Seq*/
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdLiSsCode  =  /* SS code*/
     DEFINE_U8(LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeIsdLiSsStatus  =  /* Ext SS Status */
     DEFINE_STRS(1,5,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeNotificationToMsUser  =  /* Notification to MS user*/
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT,maChkNotificationToMsUsr,maNotifcationToMsUsrEnums);

PRIVATE MaTknElmtDef maTeIsdLiExtClientLst = /*Ext Client List */
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST1,LMA_VER2P,MAT_MAX_NMB_EXT_CLIENT,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdLiExtClientSeq  =  /*ObcsmTdpCriteria Seq*/
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdLiClientIdSeq  =  /*LCS Ext Client Id Seq*/
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_MAND);

/* the externalAddress type is changed from AddressString 
 * to ISDN-AddressString */
#if MAP_REL5
PRIVATE MaTknElmtDef maTeIsdLiExtAddr  =  /* External Address */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER2P,MA_TF_VER2P_OPT);
#else
PRIVATE MaTknElmtDef maTeIsdLiExtAddr  =  /* External Address */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,20,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

PRIVATE MaTknElmtDef maTeIsdLiGmlcRest  =  /*GMLC Rest  */
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT,maChkGmlcRest,maGmlcRestEnums);

PRIVATE MaTknElmtDef maTeIsdLiNotifToMsUsr  =  /* Notification to MS user*/
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT,maChkNotificationToMsUsr,maNotifcationToMsUsrEnums);

PRIVATE MaTknElmtDef maTeIsdLiPlmnClientLst = /*PLMN client list*/
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST2,LMA_VER2P,MAT_MAX_NMB_PLMN_CLIENT,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdLiLcsClientIntId  =  /* LCS Client Int Id*/
     DEFINE_ENUM(LMA_VER2P,MA_TF_VER2P_OPT,maLcsClientIntIdEnums);

PRIVATE MaTknElmtDef maTeIsdLiMolrLst = /*MOLR List*/
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST2,LMA_VER2P,MAT_MAX_NMB_MOLR_CLASS,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdMlMolrClassSeq  =  /*MOLR Class seq */
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdMlSsStatus  =  /* Ext SS Status */
     DEFINE_STRS(1,5,LMA_VER2P,MA_TF_VER2P_MAND);

#endif /* MAP_REL98 || MAP_REL99 */

#if MAP_REL99

#if MAP_REL4
PRIVATE MaTknElmtDef maTeIsdLiExtExtClientList =
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST4,LMA_VER2P,MAT_MAX_NMB_EXT_EXT_CLIENT,MA_TF_VER2P_OPT);
#endif

#ifndef MA_SGSN_SPECIFIC
PRIVATE MaTknElmtDef maTeIsdIstAlertTimer  =  /* Ist Alert Timer */
     DEFINE_TAG_INT(MA_TAG_CSPRIM26,15,255,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdSuperChargerSuppInHlr = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM27,1,6,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdMcSsInfoSeq  =  /*MOLR Class seq */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST28,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdMsiSsCode  =  /* SS code*/
     DEFINE_TAG_U8(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeIsdMsiSsStatus  =  /* Ext SS Status */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,5,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeIsdMsiNbrSb  =  /* nbr Sb */
     DEFINE_TAG_INT(MA_TAG_CSPRIM2,2,7,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeIsdMsiNbrUsr  =  /* Nbr User */
     DEFINE_TAG_INT(MA_TAG_CSPRIM3,1,7,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeIsdCsAllocationRetentionPriority  =
     DEFINE_TAG_U8(MA_TAG_CSPRIM29,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MA_SGSN_SPECIFIC */
PRIVATE MaTknElmtDef maTeGdlPcExtQosSubs  =  /* Ext QOS Subscribed */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

/* Pdp Charging Characteristics */
PRIVATE MaTknElmtDef maTeGdlPcPdpChargingChar =
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,2,2,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL5
PRIVATE MaTknElmtDef maTeGdlPcExt2QosSubs  =  /* Ext QOS Subscribed */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,3,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

PRIVATE MaTknElmtDef maTeIsdSgsnCamSubsInfoSeq   = /*SGSN CAMEL subs info*/
     DEFINE_TAG_SEQ(MA_TAG_CSCONST17,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdScsiGprsCsiSeq   = /*GPRS CSI */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeScsiGcGprsCamelTdpDataLst =
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST0,LMA_VER2P, MAT_MAXNUMOF_CAMTDPDATA, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeGcGctdTdpDataSeq   = /* GPRS CAMEL Tdp Data  */
     DEFINE_U_SEQ(LMA_VER2P,MA_TF_VER2P_OPT, maChkIgnoreSeq);

PRIVATE MaTknElmtDef maTeGctdTdGprsTrgDetPoint  =  /*SmsTrigger Det. Pt. */
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_MAND,maChkGprsTrigDetPt,maGprsTrgDetPtEnums);

PRIVATE MaTknElmtDef maTeGctdTdDefGprsHandl  =  /*Def Gprs Handling*/
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_MAND,maChkDefGprsHandl,maDefGprsHandlEnums);

PRIVATE MaTknElmtDef maTeScsiGcCamCapHandl  =  /* Camel Capability Handling */
     DEFINE_TAG_INT(MA_TAG_CSPRIM1,1,16,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdScsiSmsCsiSeq  =  /*SMS_CSI Seq*/
     DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdChargingChar  =  /* Charging Characteristics */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM18,2,2,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL5
PRIVATE MaTknElmtDef maTeIsdLiAddLcsPrivacyExcepLst = 
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST3,LMA_VER2P,MAT_MAX_NMB_PRIVACYCLASS,
                      MA_TF_VER2P_OPT);

#define  DEFINE_SMS_CSI_SEQ(seqHeader) \
       &seqHeader, \
          &maTeVcsiScSmsCamTdpDataLst, \
             &maTeStdSmsCamTdpDataSeq, \
                &maTeScSctdSmsTrgDetPt, \
                &maTeScSctdSerKey, \
                &maTeScSctdGsmScfAddr, \
                &maTeScSctdDefSmsHandl, \
                &maTeExtCont4, \
             &maTeSeqTerm, \
          &maTeSeqTerm, \
          &maTeVcsiCamCapHandl, \
          &maTeExtCont2, \
          &maTeVcsiNotificationToCse, \
          &maTeVcsiCsiActive, \
       &maTeSeqTerm

PRIVATE MaTknElmtDef maTeIsdScsiMtSmsCsiSeq  = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdScsiSmsTdpCritSeq  =
     DEFINE_U_SEQ(LMA_VER2P,MA_TF_VER2P_OPT,maChkIgnoreSeq);

PRIVATE MaTknElmtDef maTeIsdScsiSmsTrgDetPt  = 
     DEFINE_U_ENUM(LMA_VER2P,MA_TF_VER2P_MAND,maChkSmsTrigDetPt,maSmsTrgDetPtEnums);

PRIVATE MaTknElmtDef maTeTpduTypeCritSeqOf = 
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST0,LMA_VER2P, MAT_MAX_NMB_TPDU_TYPE,
                      MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeMtSmsTpduType = 
     DEFINE_U_ENUM(LMA_VER2P,MA_TF_VER2P_OPT,maChkMtSmsTpduType,maMtSmsTpduTypeEnums);

#define DEFINE_SMS_CAM_TDP_CRIT_SEQOF(seqHeader) \
       &seqHeader, \
          &maTeIsdScsiSmsTdpCritSeq,\
             &maTeIsdScsiSmsTrgDetPt, \
             &maTeTpduTypeCritSeqOf, \
                &maTeMtSmsTpduType, \
             &maTeSeqTerm,\
          &maTeSeqTerm,\
       &maTeSeqTerm

PRIVATE MaTknElmtDef maTeIsdScsiSmsTDPCritSeqOf = 
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST4,LMA_VER2P, MAT_MAXNUMOF_CAMTDPDATA,
                      MA_TF_VER2P_OPT);


#define DEFINE_MG_CSI(seqHeader) \
       &seqHeader, \
          &maTeMcsiMobilityTrigLst,\
              &maTeMtMmCode,\
          &maTeSeqTerm,\
          &maTeObctdSerKey,\
          &maTeObctdGsmSCFAddr,\
          &maTeExtCont1,\
          &maTeMcsiNotificationToCse,\
          &maTeMcsiCsiActive,\
       &maTeSeqTerm

PRIVATE MaTknElmtDef maTeIsdScsiMgCsiSeq  = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST5,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeStLcsServTypeId = 
     DEFINE_INT(0, 127,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeStGmlcRest  =
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT,maChkGmlcRest,maGmlcRestEnums);

PRIVATE MaTknElmtDef maTeStNotifToMsUsr  = 
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT,maChkNotificationToMsUsr,maNotifcationToMsUsrEnums);

#define DEFINE_SERV_TYPE_SEQOF(seqHeader) \
       &seqHeader, \
          &maTeSeqOptVer2P, \
             &maTeStLcsServTypeId, \
             &maTeStGmlcRest, \
             &maTeStNotifToMsUsr, \
             &maTeExtCont2, \
          &maTeSeqTerm,\
       &maTeSeqTerm

PRIVATE MaTknElmtDef maTeLpcServTypeSeqOf = 
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST5,LMA_VER2P, MAT_MAX_SERV_TYPE,
                      MA_TF_VER2P_OPT);
/* Addition: upgrade for MAP release 6 */
#if MAP_REL6
PRIVATE MaTknElmtDef maTeIsdAccRestData = /* Access Restriction Data */
    DEFINE_TAG_BITSTR(MA_TAG_CSPRIM19,2,8,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MAP_REL6 */
#endif
#endif /* MAP_REL99 */

#define DEFINE_EXT_CLIENT_SEQOF(seqHeader) \
             &seqHeader, \
                &maTeIsdLiExtClientSeq, \
                   &maTeIsdLiClientIdSeq, \
                      &maTeIsdLiExtAddr, \
                      &maTeExtCont1, \
                   &maTeSeqTerm, \
                   &maTeIsdLiGmlcRest, \
                   &maTeIsdLiNotifToMsUsr, \
                   &maTeExtCont2, \
                &maTeSeqTerm, \
             &maTeSeqTerm

#ifndef MA_SGSN_SPECIFIC
PRIVATE MaTknElmtDef  *maInsSubsDataReqTkns[] = /* Ins. Subs. data tokens */ 
{
 &maTeSeqOpt,
    &maTeIsdImsi,
    &maTeIsdMsIsdn,
    &maTeIsdSubsCat,
    &maTeIsdSubsStat,
    &maTeIsdExtBearServLst,
       &maTeIsdEbslExtBearServ,
    &maTeSeqTerm,
    &maTeIsdExtTeleServLst,    
       &maTeIsdEtslExtTeleServ,
    &maTeSeqTerm,
    &maTeIsdSsInfoLst,
       DEFINE_SSINFO(maTeIsdSsInfoChoice),
    &maTeSeqTerm,
    &maTeIsdOdbDatSeq,
       &maTeIsdOdOdbGenDat,
       &maTeIsdOdOdbHplmnDat,
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
       &maTeExtCont,
    &maTeSeqTerm,
    &maTeIsdRoamRestUF,
    &maTeIsdZoneCodeLst,
       &maTeIsdZclZoneCode,
    &maTeSeqTerm,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    DEFINE_VBSDAT_LST(maTeIsdVbsDatLst),
    DEFINE_VGCSDAT_LST(maTeIsdVgcsDatLst),
    DEFINE_VLRCAMSUBSINFO_SEQ(maTeIsdVlrSubsInfoSeq),
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    #ifdef XWEXT
    &maXWExtCont14,
    #else
    &maTeExtCont14,
    #endif
    DEFINE_NAEAPREFCI_SEQ(maTeIsdNaeaPrefCiSeq),
    &maTeIsdGprsSubsDatSeq,
       &maTeGsdCompLstIncl,
       &maTeGsdGprsDatLst,
          &maTeGsdGdlPdpCntxtSeq,
             &maTeGdlPcPdpCntxtId,
             &maTeGdlPcPdpType,
             &maTeGdlPcPdpAddr,
             &maTeGdlPcQosSubs,
             &maTeGdlPcVplmnAddrAll,
             &maTeGdlPcApn,
             &maTeExtCont21,
#if MAP_REL99
             &maTeGdlPcExtQosSubs, 
             &maTeGdlPcPdpChargingChar,
#if MAP_REL5
             &maTeGdlPcExt2QosSubs, 
#endif
#endif
          &maTeSeqTerm,
       &maTeSeqTerm,
       &maTeExtCont2,
    &maTeSeqTerm,
    &maTeIsdRoamRestInSgsnUF,
    &maTeIsdNetAccMode,
#if (MAP_REL98 || MAP_REL99)
    /* LSA Information begins */
    &maTeIsdLsaInfoSeq,
       &maTeIsdLiCompDataListIncl,
       &maTeIsdLiLsaOnlyAccessInd,
       &maTeIsdLiLsaDataLst,
          &maTeIsdLiLsaDataSeq,
             &maTeIsdLiLsaIdentity,
             &maTeIsdLiLsaAttributes,
             &maTeIsdLiLsaActiveModeIndicator,
             &maTeExtCont3,
          &maTeSeqTerm,
       &maTeSeqTerm,
       &maTeExtCont3,
    &maTeSeqTerm,
    /* LMU - Indicator begins */
    &maTeIsdLmuInd,
    /* LCS Information begins */
    &maTeIsdLcsInfoSeq,
       &maTeIsdLiGmlcLst,
          &maTeIsdLiIsdnAddrStr,
       &maTeSeqTerm,
       &maTeIsdLiLcsPrivacyExcepLst,
          &maTeIsdLiLcsPrivacyClassSeq,
             &maTeIsdLiSsCode,
             &maTeIsdLiSsStatus,
             &maTeNotificationToMsUser,
             DEFINE_EXT_CLIENT_SEQOF(maTeIsdLiExtClientLst),
             &maTeIsdLiPlmnClientLst,
                &maTeIsdLiLcsClientIntId,
             &maTeSeqTerm,
             &maTeExtCont2,
#if MAP_REL99
#if MAP_REL4
             DEFINE_EXT_CLIENT_SEQOF(maTeIsdLiExtExtClientList),
#if MAP_REL5
             DEFINE_SERV_TYPE_SEQOF(maTeLpcServTypeSeqOf),
#endif /* MAP_REL5 */
#endif /* MAP_REL4 */
#endif /* MAP_REL99 */
          &maTeSeqTerm,
       &maTeSeqTerm,
       &maTeIsdLiMolrLst,
          &maTeIsdMlMolrClassSeq,
             &maTeIsdLiSsCode,
             &maTeIsdMlSsStatus,
             &maTeExtCont0,
          &maTeSeqTerm, 
       &maTeSeqTerm,
       /* Addition - Added 1 parameter for release 5 */
#if MAP_REL99
#if (MAP_REL4 && MAP_REL5)
       &maTeIsdLiAddLcsPrivacyExcepLst,
          &maTeIsdLiLcsPrivacyClassSeq,
             &maTeIsdLiSsCode,
             &maTeIsdLiSsStatus,
             &maTeNotificationToMsUser,
             DEFINE_EXT_CLIENT_SEQOF(maTeIsdLiExtClientLst),
             &maTeIsdLiPlmnClientLst,
                &maTeIsdLiLcsClientIntId,
             &maTeSeqTerm,
             &maTeExtCont2,
             DEFINE_EXT_CLIENT_SEQOF(maTeIsdLiExtExtClientList),
             DEFINE_SERV_TYPE_SEQOF(maTeLpcServTypeSeqOf),
          &maTeSeqTerm,
       &maTeSeqTerm,
#endif /* MAP_REL5 */
#endif /* MAP_REL99 */
    &maTeSeqTerm,
#endif /* MAP_REL98 || MAP_REL99 */
#if MAP_REL99
    &maTeIsdIstAlertTimer, 
    &maTeIsdSuperChargerSuppInHlr,
    &maTeIsdMcSsInfoSeq,
       &maTeIsdMsiSsCode,
       &maTeIsdMsiSsStatus,
       &maTeIsdMsiNbrSb,
       &maTeIsdMsiNbrUsr,
       &maTeExtCont4,
    &maTeSeqTerm,
    &maTeIsdCsAllocationRetentionPriority,
    &maTeIsdSgsnCamSubsInfoSeq,
       &maTeIsdScsiGprsCsiSeq, 
          &maTeScsiGcGprsCamelTdpDataLst,
             &maTeGcGctdTdpDataSeq,
                &maTeGctdTdGprsTrgDetPoint,
                &maTeScSctdSerKey,
                &maTeScSctdGsmScfAddr,
                &maTeGctdTdDefGprsHandl,
                &maTeExtCont4,
             &maTeSeqTerm,
          &maTeSeqTerm,
          &maTeScsiGcCamCapHandl,
          &maTeExtCont2,
          &maTeVcsiNotificationToCse,
          &maTeVcsiCsiActive ,
       &maTeSeqTerm,
       &maTeIsdScsiSmsCsiSeq, 
          &maTeVcsiScSmsCamTdpDataLst,
             &maTeStdSmsCamTdpDataSeq,
                &maTeScSctdSmsTrgDetPt,
                &maTeScSctdSerKey,
                &maTeScSctdGsmScfAddr,
                &maTeScSctdDefSmsHandl,
                &maTeExtCont4,
             &maTeSeqTerm,
          &maTeSeqTerm,
          &maTeVcsiCamCapHandl,
          &maTeExtCont2,
          &maTeVcsiNotificationToCse,
          &maTeVcsiCsiActive,
       &maTeSeqTerm,
       &maTeExtCont2,
       /* Addition - Added 3 parameters for release 5 */
#if (MAP_REL4 && MAP_REL5)
       DEFINE_SMS_CSI_SEQ(maTeIsdScsiMtSmsCsiSeq),
       DEFINE_SMS_CAM_TDP_CRIT_SEQOF(maTeIsdScsiSmsTDPCritSeqOf),
       DEFINE_MG_CSI(maTeIsdScsiMgCsiSeq),
#endif
    &maTeSeqTerm,
    &maTeIsdChargingChar, 
#if MAP_REL6
    &maTeIsdAccRestData,
#endif /* MAP_REL6 */
#endif /* MAP_REL99 */
 &maTeSeqTerm,
 NULLP,
};

#else /* MA_SGSN_SPECIFIC */
PRIVATE MaTknElmtDef  *maInsSubsDataReqTkns[] = /* Ins Subs Data Tokens */
{
 &maTeSeqOpt,
   &maTeIsdImsi,
   &maTeIsdMsIsdn,
   &maTeIsdSubsStat,
   &maTeIsdExtTeleServLst,
       &maTeIsdEtslExtTeleServ,
   &maTeSeqTerm,
   &maTeIsdOdbDatSeq,
      &maTeIsdOdOdbGenDat,
      &maTeIsdOdOdbHplmnDat,
#ifdef MAP_PHASE2_EXT_MARK
      &maTeExtMark,
#endif
      &maTeExtCont,
   &maTeSeqTerm,
   &maTeIsdRoamRestUF,
   &maTeIsdZoneCodeLst,
      &maTeIsdZclZoneCode,
   &maTeSeqTerm,
#ifdef MAP_PHASE2_EXT_MARK
      &maTeExtMark,
#endif
   #ifdef XWEXT
   &maXWExtCont14,
   #else
   &maTeExtCont14,
   #endif
   &maTeIsdGprsSubsDatSeq,
      &maTeGsdCompLstIncl,
      &maTeGsdGprsDatLst,
         &maTeGsdGdlPdpCntxtSeq,
            &maTeGdlPcPdpCntxtId,
            &maTeGdlPcPdpType,
            &maTeGdlPcPdpAddr,
            &maTeGdlPcQosSubs,
            &maTeGdlPcVplmnAddrAll,
            &maTeGdlPcApn,
            &maTeExtCont21,
#if MAP_REL99
            &maTeGdlPcExtQosSubs,
            &maTeGdlPcPdpChargingChar,
#endif /* MAP_REL99 _35 */
#if MAP_REL5
            &maTeGdlPcExt2QosSubs, 
#endif
         &maTeSeqTerm,
      &maTeSeqTerm,
      &maTeExtCont2,
   &maTeSeqTerm,
   &maTeIsdRoamRestInSgsnUF,
   &maTeIsdNetAccMode,
#if (MAP_REL98 || MAP_REL99)
   &maTeIsdLcsInfoSeq,
      &maTeIsdLiGmlcLst,
         &maTeIsdLiIsdnAddrStr,
      &maTeSeqTerm,
      &maTeIsdLiLcsPrivacyExcepLst,
         &maTeIsdLiLcsPrivacyClassSeq,
            &maTeIsdLiSsCode,
            &maTeIsdLiSsStatus,
            &maTeNotificationToMsUser,
            DEFINE_EXT_CLIENT_SEQOF(maTeIsdLiExtClientLst),
            &maTeIsdLiPlmnClientLst,
               &maTeIsdLiLcsClientIntId,
            &maTeSeqTerm,
            &maTeExtCont2,
#if MAP_REL99
#if MAP_REL4
            DEFINE_EXT_CLIENT_SEQOF(maTeIsdLiExtExtClientList),
#if MAP_REL5
            DEFINE_SERV_TYPE_SEQOF(maTeLpcServTypeSeqOf),
#endif /* MAP_REL5 */
#endif /* MAP_REL4 */
#endif /* MAP_REL99 */
          &maTeSeqTerm,
        &maTeSeqTerm,
        &maTeIsdLiMolrLst,
           &maTeIsdMlMolrClassSeq,
              &maTeIsdLiSsCode,
              &maTeIsdMlSsStatus,
              &maTeExtCont0,
           &maTeSeqTerm,
        &maTeSeqTerm,
#if MAP_REL99
#if (MAP_REL4 && MAP_REL5)
       &maTeIsdLiAddLcsPrivacyExcepLst,
           &maTeIsdLiLcsPrivacyClassSeq,
              &maTeIsdLiSsCode,
              &maTeIsdLiSsStatus,
              &maTeNotificationToMsUser,
              DEFINE_EXT_CLIENT_SEQOF(maTeIsdLiExtClientLst),
              &maTeIsdLiPlmnClientLst,
                 &maTeIsdLiLcsClientIntId,
              &maTeSeqTerm,
              &maTeExtCont2,
              DEFINE_EXT_CLIENT_SEQOF(maTeIsdLiExtExtClientList),
              DEFINE_SERV_TYPE_SEQOF(maTeLpcServTypeSeqOf),
           &maTeSeqTerm,
        &maTeSeqTerm,
#endif /* MAP_REL5 */
#endif /* MAP_REL99 */
    &maTeSeqTerm,
#endif /* MAP_REL98 || MAP_REL99 */
#if MAP_REL99
    &maTeIsdSgsnCamSubsInfoSeq,
       &maTeIsdScsiGprsCsiSeq,
          &maTeScsiGcGprsCamelTdpDataLst,
             &maTeGcGctdTdpDataSeq,
                &maTeGctdTdGprsTrgDetPoint,
                &maTeScSctdSerKey,
                &maTeScSctdGsmScfAddr,
                &maTeGctdTdDefGprsHandl,
                &maTeExtCont4,
            &maTeSeqTerm,
         &maTeSeqTerm,
         &maTeScsiGcCamCapHandl,
         &maTeExtCont2,
         &maTeVcsiNotificationToCse,
         &maTeVcsiCsiActive,
     &maTeSeqTerm,
     &maTeIsdScsiSmsCsiSeq,
        &maTeVcsiScSmsCamTdpDataLst,
           &maTeStdSmsCamTdpDataSeq,
             &maTeScSctdSmsTrgDetPt,
             &maTeScSctdSerKey,
             &maTeScSctdGsmScfAddr,
             &maTeScSctdDefSmsHandl,
             &maTeExtCont4,
           &maTeSeqTerm,
        &maTeSeqTerm,
        &maTeVcsiCamCapHandl,
        &maTeExtCont2,
        &maTeVcsiNotificationToCse,
        &maTeVcsiCsiActive,
     &maTeSeqTerm,
     &maTeExtCont2,
#if (MAP_REL4 && MAP_REL5)
     DEFINE_SMS_CSI_SEQ(maTeIsdScsiMtSmsCsiSeq),
     DEFINE_SMS_CAM_TDP_CRIT_SEQOF(maTeIsdScsiSmsTDPCritSeqOf),
     DEFINE_MG_CSI(maTeIsdScsiMgCsiSeq),
#endif
   &maTeSeqTerm,
   &maTeIsdChargingChar,
#if MAP_REL6
   &maTeIsdAccRestData,
#endif /* MAP_REL6 */
#endif /* MAP_REL99 */
 &maTeSeqTerm,
 NULLP,
};
#endif /* MA_SGSN_SPECIFIC */


PRIVATE MaTknElmtDef maTeIsdRspSupCamPhases =   /* Supported Camel Phases */
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM6,1,16,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIsdRspRegSubsRsp =   /* Regional Subs. Resp. */
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM5 ,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3,maRegSubsRspEnums);

/*
** Version 2P defines bits upto 32.
** Version 2 defines upto 6.
** so we have defined the maximum to 32.
** So for version 2 also bits 7 to 32 are allowed by MAP.
** a Stricter check should be made by the MAP user.
*/
PRIVATE MaTknElmtDef maTeIsdRspOdbGenDat =   /* Odb General Data      */
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM4,6,32,LMA_VER1AND2AND2P,
                       MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeIsdRspSsCode =   /* SS Code               */
     DEFINE_U8(LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeIsdRspTeleServSeqOf =   /* Tele Service Sequence */
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST1,LMA_VER1AND2AND2P, MAT_MAX_TELESERV, MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeIsdRspSsCodeSeqOf =   /* SS Code Sequence      */
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST3,LMA_VER1AND2AND2P,MAT_MAX_SS_CODE, MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeIsdRspBearServSeqOf =   /* Bearer Service Sequence */
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST2,LMA_VER1AND2AND2P,MAT_MAX_BEARSERV, MA_TF_VER1AND2AND2P_OPT7);

/* Ext-BasicService Code (313,2+) */  
 PRIVATE MaTknElmtDef 
 maTeIsdRspExtTeleServ = DEFINE_STRS(1,5,LMA_VER1AND2AND2P,MA_TF_VER2P_OPT);
 PRIVATE MaTknElmtDef 
 maTeIsdRspExtBearServ = DEFINE_STRS(1,5,LMA_VER1AND2AND2P,MA_TF_VER2P_OPT);

/* Addition - upgrade for MAP release 5 */
#if MAP_REL5
PRIVATE MaTknElmtDef maTeIsdRspOffCam4CSIs =
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM8,7,16,LMA_VER2P,MA_TF_VER2P_OPT);

#endif

PRIVATE MaTknElmtDef  *maInsSubsDataRspTkns[] = /* Insert Subscriber data Resp. tokens */ 
{
 &maTeSeqOpt,
    &maTeIsdRspTeleServSeqOf,
       &maTeIsdRspExtTeleServ,
    &maTeSeqTerm,
    &maTeIsdRspBearServSeqOf,
       &maTeIsdRspExtBearServ,
    &maTeSeqTerm,
    &maTeIsdRspSsCodeSeqOf,
       &maTeIsdRspSsCode,
    &maTeSeqTerm,
    &maTeIsdRspOdbGenDat,
    &maTeIsdRspRegSubsRsp,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTeIsdRspSupCamPhases,
    &maTeExtCont7,
#if MAP_REL5
    &maTeIsdRspOffCam4CSIs,
#endif
 &maTeSeqTerm,
 NULLP,
};


PRIVATE MaTknElmtDef maTeDsdImsi =   /* Imsi                  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeDsdBasServLst =   /* Bas Serv List         */
 DEFINE_TAG_SEQOF(MA_TAG_CSCONST1,LMA_VER1AND2AND2P,MAT_MAX_NMB_BASIC_SERV,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeDsdBasicServChoice =   /* Basic Serv Choice     */
     DEFINE_CHOICE(sizeof(MaExtBasServCode),LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeDsdBscBasServBearCode =   /* Bas Serv Bear Code    */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,5,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeDsdBscBasServTeleCode =   /* Bas Serv Tele Code    */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,5,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeDsdSsCodeSeq =   /* Ss Code Sequence      */
   DEFINE_TAG_SEQOF(MA_TAG_CSCONST2,LMA_VER1AND2AND2P,MAT_MAX_SS_CODE,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeDsdSscsSsCode =   /* Ss Code               */
     DEFINE_U8(LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeDsdRoamRestUF =   /* Roam Rest UF          */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM4,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeDsdRegSubsId =   /* Reg Subs Id           */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM5,2,2,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeDsdVbsGrpInd =   /* Vbs. Grp. Ind.        */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM7,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeDsdVgcsGrpInd =   /* Vgcs. Grp. Ind.        */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM8,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeDsdCamSubsInfoWithDraw = /* Cam Subs. Info With draw */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeDsdGprsSubsDataWithDraw = /* Gprs Subs. With Draw */
     DEFINE_TAG_CHOICE(sizeof(MaGprsSubsDatWithDraw),MA_TAG_CSCONST10,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeDsdGsdwAllGprsDat =   /* All Gprs Data         */
     DEFINE_NULL(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeDsdGsdwContextIdLst =   /* Context Id List       */
     DEFINE_SEQOF(LMA_VER2P,MAT_MAXNUMOFPDP_CONTEXT,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeDsdGsdwCilContextId =   /* Context Id            */
     DEFINE_INT(1, MAT_MAXNUMOFPDP_CONTEXT,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeDsdRoamRestSgsnUF =   /* Roam. Rest Sgsn UF    */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM11,LMA_VER2P,MA_TF_VER2P_OPT);

#if (MAP_REL98 || MAP_REL99)

PRIVATE MaTknElmtDef maTeDsdLsaInfoWithdrawChoice = /* LSA info Withdraw  */
     DEFINE_TAG_CHOICE(sizeof(MaLsaInfoWithdraw),MA_TAG_CSCONST12,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeLiwAllLsaData  =  /*All LSA data */
     DEFINE_NULL(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeLiwLsaIdentityLst = /*LSA Identity List */
     DEFINE_SEQOF(LMA_VER2P,MAT_MAX_NMB_LSA,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeLilLsaIdentity  =  /* LSA identity */
     DEFINE_STRS(3,3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeDsdGmlcLstWithdraw  =  /*GMLC List Withdraw */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM13,LMA_VER2P,MA_TF_VER2P_OPT);

#endif /* MAP_REL98 || MAP_REL99 */

#if MAP_REL99
PRIVATE MaTknElmtDef maTeDsdIstInfoWithdraw  =  /* IST info Withdraw */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM14,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeDsdSpecCsiWithdraw =   /* Specific CSI withdraw */
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM15,8,32,LMA_VER2P,MA_TF_VER2P_OPT);

#endif /* MAP_REL99 */


PRIVATE MaTknElmtDef  *maDelSubsDataReqTkns[] = /* Delete Subscriber data tokens */ 
{
 &maTeSeqOpt,
    &maTeDsdImsi,
    &maTeDsdBasServLst,
       &maTeDsdBasicServChoice,
          &maTeDsdBscBasServBearCode,
          &maTeDsdBscBasServTeleCode,
       &maTeSeqTerm,
    &maTeSeqTerm,
    &maTeDsdSsCodeSeq,
       &maTeDsdSscsSsCode,
    &maTeSeqTerm,
    &maTeDsdRoamRestUF,
    &maTeDsdRegSubsId,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTeDsdVbsGrpInd,
    &maTeDsdVgcsGrpInd,
    &maTeDsdCamSubsInfoWithDraw,
    #ifdef XWEXT
    &maXWExtCont6,
    #else
    &maTeExtCont6,
    #endif
    &maTeDsdGprsSubsDataWithDraw,
       &maTeDsdGsdwAllGprsDat,
       &maTeDsdGsdwContextIdLst,
          &maTeDsdGsdwCilContextId,
       &maTeSeqTerm,
    &maTeSeqTerm,
    &maTeDsdRoamRestSgsnUF,
#if (MAP_REL98 || MAP_REL99)   
    &maTeDsdLsaInfoWithdrawChoice,
       &maTeLiwAllLsaData,
       &maTeLiwLsaIdentityLst,
          &maTeLilLsaIdentity, 
       &maTeSeqTerm,
    &maTeSeqTerm,
    &maTeDsdGmlcLstWithdraw,
#endif /* MAP_REL98 || MAP_REL99 */
#if MAP_REL99                 
    &maTeDsdIstInfoWithdraw,
    &maTeDsdSpecCsiWithdraw,
#endif /* MAP_REL99 */
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTeDsdRegSubsRsp =   /* reg. Subs. Rsp.       */
  DEFINE_TAG_ENUM(MA_TAG_CSPRIM0,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7,maRegSubsRspEnums);

PRIVATE MaTknElmtDef  *maDelSubsDataRspTkns[] = /* Delete Subscriber data tokens */ 
{
 &maTeSeqOpt,
    &maTeDsdRegSubsRsp,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

/* -------------------------------------------------------------------- */
/* Send Parameters Request and Response                                 */
/* -------------------------------------------------------------------- */

#if (MAP_VLR || MAP_HLR || MAP_GSN)

PRIVATE MaTknElmtDef maTeSndParamSeq =   /* Send Parameter Seq.   */
     DEFINE_SEQ(LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeSpSubsIdChoice =   /* Subscriber Id Choice  */
     DEFINE_CHOICE(sizeof(MaSubsIdent),LMA_VER1,MA_TF_VER1_MAND);

/*
** IMSI is defined as octet string of size 2-8 in Version-1 
*/
PRIVATE MaTknElmtDef maTeSpSiImsi =   /* Imsi                  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,2,8,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeSpSiTmsi =   /* Tmsi                  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,4,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeSpReqParamLst =   /* ReqParamLst           */
     DEFINE_SEQOF(LMA_VER1,MAT_MAX_REQPARAM,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeSpRplReqParam =   /* Req. Param            */
     DEFINE_ENUM(LMA_VER1,MA_TF_VER1_OPT,maReqParamEnums);

PRIVATE MaTknElmtDef  *maSndParamReqTkns[] = /* Send parameters req. tokens */ 
{
 &maTeSndParamSeq,

    &maTeSpSubsIdChoice,
       &maTeSpSiImsi,
       &maTeSpSiTmsi,
    &maTeSeqTerm,

    &maTeSpReqParamLst,
       &maTeSpRplReqParam,
    &maTeSeqTerm,

 &maTeSeqTerm,
 NULLP,
};


PRIVATE MaTknElmtDef maTeSndParamLst =   /* Send Parameters       */
     DEFINE_SEQOF(LMA_VER1,MAT_MAX_SNDPARAM,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeSndParamChoice =   /* Send Parameters Choice*/
     DEFINE_CHOICE(sizeof(MaSndParam),LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeSplSpImsi =   /* Imsi                  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeSplSpAuthSetLst =   /* Auth Set List         */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeAslAsRand =   /* Rand                  */
     DEFINE_STRS(16,16,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeAslAsSRes =   /* SRes                  */
     DEFINE_STRS(4,4,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeAslAsKc =   /* Kc                    */
     DEFINE_STRS(8,8,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeSplSpSubsDatSeq =   /* Zone Code             */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST2,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeSplSpMsIsdn =   /* Ms Isdn               */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeSplSpSubsCat =   /* Subscriber Category   */
     DEFINE_TAG_U8(MA_TAG_CSPRIM2,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeSplSpSubsStat =   /* Subscriber Status     */
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM3,LMA_VER1,MA_TF_VER1_OPT,maSubsStatEnums);

PRIVATE MaTknElmtDef maTeSplSpBearServLst =   /* Bear Serv Lst         */
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST4,LMA_VER1,MAT_MAX_BEARSERV,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeSplSpBearServ =   /* Spl Sp Bear Serv      */
     DEFINE_U8(LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeSplSpTeleServLst =   /* Spl Sp Tele Serv Lst  */
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST6,LMA_VER1,MAT_MAX_TELESERV,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeSplSpTeleServ =   /* Spl Sp Tele Serv      */
     DEFINE_U8(LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeSplSpProvSSLst =   /* Provisioned SS Lst    */
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST7,LMA_VER1,MAT_MAX_SS,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeSplSpSsInfoChoice =   /* SS Info Choice        */
     DEFINE_CHOICE(sizeof(MaSSInfo),LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeSplSdOdOdbHplmnDat =   /* Odb. Hplmn data */
     DEFINE_BITSTR(4,32,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeSplSdOdOdbGenDat =   /* Odb. Gen Data  */
     DEFINE_BITSTR(6,32,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeSplSubsDatOdbDatSeq =   /* Odb Data Seq  */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST8,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeSplSubdDatRoamRestUF = /* Roam. Rest. due to unsup. Ftr */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM9,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeSplSdZclZoneCode =   /* Zone Code             */
     DEFINE_STRS(2,2,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeSplSubsDatZoneCodeLst =   /* Zone Code list        */
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST10,LMA_VER2AND2P,MAT_MAX_ZONES,MA_TF_VER2AND2P_OPT3);


PRIVATE MaTknElmtDef maTeSplSpKi =   /* Ki                    */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,16,16,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef  *maSndParamRspTkns[] = /* Send parameters Resp. tokens */
{
 &maTeSndParamLst,
    &maTeSndParamChoice,
       &maTeSplSpImsi,
       &maTeSplSpAuthSetLst,
          &maTeAslAsRand,
          &maTeAslAsSRes,
          &maTeAslAsKc,
#ifdef MAP_PHASE2_EXT_MARK
          &maTeExtMark,
#endif
       &maTeSeqTerm,
       &maTeSplSpSubsDatSeq,
          &maTeSplSpMsIsdn,
          &maTeSplSpSubsCat,
          &maTeSplSpSubsStat, 
          &maTeSplSpBearServLst,
             &maTeSplSpBearServ,
          &maTeSeqTerm,
          &maTeSplSpTeleServLst,
             &maTeSplSpTeleServ,
          &maTeSeqTerm,
          &maTeSplSpProvSSLst,
             DEFINE_SSINFO(maTeSplSpSsInfoChoice),
          &maTeSeqTerm,
          &maTeSplSubsDatOdbDatSeq,
             &maTeSplSdOdOdbGenDat,
             &maTeSplSdOdOdbHplmnDat,
#ifdef MAP_PHASE2_EXT_MARK
             &maTeExtMark,
#endif
          &maTeSeqTerm,
          &maTeSplSubdDatRoamRestUF,
          &maTeSplSubsDatZoneCodeLst,
             &maTeSplSdZclZoneCode,
          &maTeSeqTerm,
       &maTeSeqTerm,
       &maTeSplSpKi,
    &maTeSeqTerm,
 &maTeSeqTerm,

 NULLP,
};

#endif  /* (VLR) || (HLR) || (GSN) */

/* -------------------------------------------------------------------- */
/* Provide Roaming Number Request and Response                          */
/* -------------------------------------------------------------------- */

#if (MAP_VLR || MAP_HLR)
PRIVATE MaTknElmtDef maTePrnImsi =   /* Mandatory, IMSI       */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTePrnMscNmb =   /* Msc Nmb.O-M-M         */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT1);

PRIVATE MaTknElmtDef maTePrnMsIsdn =   /* MS-ISDN OPTIONAL      */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,9,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTePrnRoamNmb =   /* Roam.Nmb, O-O-*       */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,9,LMA_VER1AND2,MA_TF_VER1AND2_OPT3);

PRIVATE MaTknElmtDef maTePrnLmsi =   /* LMSI   O-O-O */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,4,4,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTePrnGsmBearCapSeq =   /* Gsm Bear Cap Seq */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST5,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTePrnNetSigSeq =   /* Nework Sig Seq O-O-O  */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST6,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTePrnSuppOfAncmt =   /* NULLL                 */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM7,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePrnGmscAddr =   /* Isdn Address String   */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM8,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePrnCallRefNmb =   /* Call Reference number */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM9 ,1,8,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePrnOrInterro =   /* NULL                   */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM10,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePrnCcbsCall =   /* Ccbs Call          */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM13,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePrnAlertPat =   /* Alerting Pattern      */
     DEFINE_TAG_U8(MA_TAG_CSPRIM12,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePrnSigInfo =   /* Signal Info         r */
     DEFINE_STRE(1,200,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTePrnProtId =   /* Protocol Identifier   */
     DEFINE_ENUM(LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0,maProtIdEnums);

PRIVATE MaTknElmtDef maTePrnSupCamPhasesInGmsc =   /* supported Camel phases*/
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM15,1,16,LMA_VER2P,MA_TF_VER2P_OPT);

#if (MAP_REL98 || MAP_REL99)
PRIVATE MaTknElmtDef maTePrnExtExtSigInfoSeq =   /* Ext. Ext.signal Info */
     DEFINE_TAG_U_SEQ(MA_TAG_CSCONST14,LMA_VER2P,MA_TF_VER2P_OPT,maChkIgnoreSeq);

PRIVATE MaTknElmtDef maTePrnOrNotSupInGmsc =  /* Or Not support In GMSC */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM16,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MAP_REL98 || MAP_REL99 */

#if MAP_REL99
PRIVATE MaTknElmtDef maTePrnPrePagingSup = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM17,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePrnLongFtnSup =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM18,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL5
PRIVATE MaTknElmtDef maTePrnSupreVtCsi = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM19,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRrnOffCam4CSIs =
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM20,7,16,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MAP_REL99 */
#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef *maProvRoamNmbReqTkns[] = /* Prov. roaming number req */
{
 &maTeSeqMand,
 &maTePrnImsi,
 &maTePrnMscNmb,
 &maTePrnMsIsdn,
 &maTePrnRoamNmb,
 &maTePrnLmsi,
 &maTePrnGsmBearCapSeq,
     &maTePrnProtId,
     &maTePrnSigInfo,
#ifdef MAP_PHASE2_EXT_MARK
     &maTeExtMark,
#endif
     &maTeExtCont,
 &maTeSeqTerm,
 &maTePrnNetSigSeq,
     &maTePrnProtId,
     &maTePrnSigInfo,
#ifdef MAP_PHASE2_EXT_MARK
     &maTeExtMark,
#endif
     &maTeExtCont,
 &maTeSeqTerm,
#ifdef MAP_PHASE2_EXT_MARK
 &maTeExtMark,
#endif
 &maTePrnSuppOfAncmt,
 &maTePrnGmscAddr,
 &maTePrnCallRefNmb,
 &maTePrnOrInterro,
 &maTeExtCont11,
 &maTePrnAlertPat,
 &maTePrnCcbsCall,
 &maTePrnSupCamPhasesInGmsc,
#if (MAP_REL98 || MAP_REL99)
 DEFINE_EXTEXTSIGINFO_SEQ(maTePrnExtExtSigInfoSeq),
 &maTePrnOrNotSupInGmsc,
#endif /* MAP_REL98 || MAP_REL99 */
#if MAP_REL99
 &maTePrnPrePagingSup,
 &maTePrnLongFtnSup,
#if MAP_REL5
 &maTePrnSupreVtCsi,
 &maTeRrnOffCam4CSIs,
#endif
#endif /* MAP_REL99 */
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTePrnProtDiffChoice =   /* Protocol Diff Choice */
     DEFINE_CHOICE(sizeof(MaRoamNmbRsp),LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTePrnRspRoamNmb12 =   /* Isdn Address String   */
     DEFINE_STRS(1,9,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTePrnRspRoamNmb2P =   /* Isdn Address String   */
     DEFINE_STRS(1,9,LMA_VER2P,MA_TF_VER2P_MAND);

#if MAP_REL99
#if MAP_REL6
/* Suyash */
PRIVATE MaTknElmtDef maTePrnRelResSup = 
   DEFINE_NULL(LMA_VER2P,MA_TF_VER2P_OPT);

#endif /* MAP_REL6 */
#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef *maProvRoamNmbRspTkns[] = /* Prov roaming number rsp */
{
 &maTePrnProtDiffChoice,
    &maTePrnRspRoamNmb12,
    &maTeSeqMandVer2P,
       &maTePrnRspRoamNmb2P,
       &maTeExtCont,
#if MAP_REL99
#if MAP_REL6
       &maTePrnRelResSup,
#endif /* MAP_REL6 */
#endif /* MAP_REL99 */
    &maTeSeqTerm,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_VLR || MAP_HLR */

/* -------------------------------------------------------------------- */
/* Check IMEI Request and Response                                      */
/* -------------------------------------------------------------------- */

#if (MAP_MSC || MAP_VLR || MAP_GSN)

/* Added two new parameter, and added ACN version 3 */
#if MAP_REL99
#if MAP_REL5

PRIVATE MaTknElmtDef maTeChkIMEIReqSeq = 
     DEFINE_U_SEQ(LMA_VER2P,MA_TF_VER2P_MAND,maChkSeq3);

PRIVATE MaTknElmtDef maTeCiIMEI = 
     DEFINE_STRS(8,8,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeCiReqEqpInfo = 
     DEFINE_BITSTR(2,8,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeChkIMEIRspSeq = 
     DEFINE_U_SEQ(LMA_VER2P,MA_TF_VER2P_MAND,maChkSeq3);

PRIVATE MaTknElmtDef maTeCiEqupStat = /* Equipment Status */
     DEFINE_ENUM(LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT4,maEqupStatEnums);

PRIVATE MaTknElmtDef maTeCiBmuefSeq =
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCiBmuefUesbiIuA =
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM0,1,128,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCiBmuefUesbiIuB =
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM1,1,128,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maChkIMEIReqTkns[] = /* Check IMEI request tokens */
{
  &maTeChkIMEIReqSeq,
    &maTeCiIMEI,
    &maTeCiReqEqpInfo,
    &maTeExtCont,
  &maTeSeqTerm, 
  NULLP,
};

PRIVATE MaTknElmtDef *maChkIMEIRspTkns[] = /* Check IMEI request tokens */
{
  &maTeChkIMEIRspSeq,
    &maTeCiEqupStat,
    &maTeCiBmuefSeq,
      &maTeCiBmuefUesbiIuA,
      &maTeCiBmuefUesbiIuB,
    &maTeSeqTerm,
    &maTeExtCont0,
  &maTeSeqTerm, 
  NULLP,
};

#else /* MAP_REL5 */
PRIVATE MaTknElmtDef maTeCiIMEI = /* IMEI (Optional) */
   DEFINE_STRS(8,8,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeCiEqupStat = /* Equipment Status */
   DEFINE_ENUM(LMA_VER1AND2,MA_TF_VER1AND2_OPT0,maEqupStatEnums);

PRIVATE MaTknElmtDef *maChkIMEIReqTkns[] = /* Check IMEI request tokens */
{
 &maTeCiIMEI,
 NULLP,
};

PRIVATE MaTknElmtDef *maChkIMEIRspTkns[] = /* Check IMEI request tokens */
{
 &maTeCiEqupStat,
 NULLP,
};
#endif /* MAP_REL5 */

#else  /* MAP_REL99 */
PRIVATE MaTknElmtDef maTeCiIMEI = /* IMEI (Optional) */
   DEFINE_STRS(8,8,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeCiEqupStat = /* Equipment Status */
   DEFINE_ENUM(LMA_VER1AND2,MA_TF_VER1AND2_OPT0,maEqupStatEnums);

PRIVATE MaTknElmtDef *maChkIMEIReqTkns[] = /* Check IMEI request tokens */
{
 &maTeCiIMEI,
 NULLP,
};

PRIVATE MaTknElmtDef *maChkIMEIRspTkns[] = /* Check IMEI request tokens */
{
 &maTeCiEqupStat,
 NULLP,
};
#endif

#endif   /* MAP_MSC || MAP_VLR || MAP_GSN */

/* -------------------------------------------------------------------- */
/* Trace Subscriber Activity Request                                    */
/* -------------------------------------------------------------------- */

#if MAP_MSC

PRIVATE MaTknElmtDef maTeTrSubsActvSeq =   /* Tr. subs. Actv Seq    */
     DEFINE_SEQ(LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeTsaImsi =   /* Imsi                  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeTsaTrRef =   /* Trace Reference       */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,2,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeTsaTrType =   /* Trace Type            */
     DEFINE_TAG_INT(MA_TAG_CSPRIM2,0,255,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeTsaOmcId =   /* Omc Identifier        */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,20,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeTsaCallRef =   /* Call Reference        */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,1,3,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef *maTrSubsActvReqTkns[] = /* Trace subscriber request */
{
 &maTeTrSubsActvSeq,
    &maTeTsaImsi,
    &maTeTsaTrRef,
    &maTeTsaTrType,
    &maTeTsaOmcId,
    &maTeTsaCallRef,
 &maTeSeqTerm,
 NULLP,
};

#endif   /* MSC */

/* -------------------------------------------------------------------- */
/* Detach IMSI Request                                                  */
/* -------------------------------------------------------------------- */

#if MAP_MSC

PRIVATE MaTknElmtDef maTeDiSubsIdChoice =   /* Subscriber Identifier */
     DEFINE_CHOICE(sizeof(MaSubsIdent),LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeDiSiImsi =   /* Imsi                  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeDiSiTmsi =   /* Tmsi                  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,4,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef *maDetIMSIReqTkns[] = /* Detach IMSI request */
{
 &maTeDiSubsIdChoice,
    &maTeDiSiImsi,
    &maTeDiSiTmsi,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MSC */

/* -------------------------------------------------------------------- */
/* Prepare Handover Request and Response &                              */
/* Prepare Subsequent Handover Request and Response &                   */
/* Perform Handover Request and Response &                              */
/* Perform Subsequent Handover Request and Response &                   */
/* Send End Signal Request &                                            */
/* Process Access Signalling Request &                                  */
/* Forward Access Signalling Request &                                  */
/* Note Internal Handover Request                                       */
/* -------------------------------------------------------------------- */

#if MAP_MSC

#if MAP_REL99
#else

PRIVATE MaTknElmtDef maTePreHoSeq =   /* Pre Ho Seq            */
     DEFINE_SEQ(LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTePreHoTgtCellId =   /* Target Cell Id        */
     DEFINE_STRS(5,7,LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTePreHoNmbNotReq =   /* Hand over Number not required */
     DEFINE_NULL(LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTePreHoBssApduSeq =   /*  Bss Apdu            */
     DEFINE_SEQ(LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTePhBaProtId =   /* Protocol Identifer    */
     DEFINE_ENUM(LMA_VER2,MA_TF_VER2_MAND,maProtIdEnums);

PRIVATE MaTknElmtDef maTePhBaSigInfo =   /* Signal Info           */
     DEFINE_STRE(1,200,LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef *maPreHoReqTkns[] = /* prepare handover request tokens */
{
 &maTePreHoSeq,
    &maTePreHoTgtCellId,
    &maTePreHoNmbNotReq,
    &maTePreHoBssApduSeq,
       &maTePhBaProtId,
       &maTePhBaSigInfo, 
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
       &maTeExtCont,
    &maTeSeqTerm,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTePreHoRspHandOverNmb =   /* Zone Code             */
     DEFINE_STRS(1,9,LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef *maPreHoRspTkns[] = /* prepare handover response tokens */
{
 &maTePreHoSeq,
    &maTePreHoRspHandOverNmb,
    &maTePreHoBssApduSeq,
       &maTePhBaProtId,
       &maTePhBaSigInfo, 
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
       &maTeExtCont,
    &maTeSeqTerm,
#ifdef MAP_PHASE2_EXT_MARK
 &maTeExtMark,
#endif
 &maTeSeqTerm,
 NULLP,
};

#endif
#if MAP_REL99          

PRIVATE MaTknElmtDef maTePreHoSeq =   /* Pre Ho Seq */
     DEFINE_TAG_U_SEQ(MA_TAG_CSCONST3,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3,maChkSeq2);

PRIVATE MaTknElmtDef maTePreHoTgtCellId =   /* Target Cell Id        */
     DEFINE_TAG_U_STRS(MA_TAG_CSPRIM0,5,7,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3,maChkVerStr);

PRIVATE MaTknElmtDef maTePreHoNmbNotReq =   /* Hand over Number not required */
     DEFINE_NULL(LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTePreHoBssApduSeq =   /*  Bss Apdu            */
     DEFINE_SEQ(LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTePhBaProtId =   /* Protocol Identifer    */
     DEFINE_ENUM(LMA_VER2,MA_TF_VER2_MAND,maProtIdEnums);

PRIVATE MaTknElmtDef maTePhBaSigInfo =   /* Signal Info           */
     DEFINE_STRE(1,200,LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef maTePreHoRNCId =   /* RNCId                  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,7,7,LMA_VER2P,MA_TF_VER2P_OPT);

/* Access Network signal */
/*------------------------------*/
PRIVATE MaTknElmtDef maTeAccNetProtId = 
      DEFINE_U_ENUM(LMA_VER2P,MA_TF_VER2P_MAND,maChkAccNetProtId,maAccNetProtIdEnums);

PRIVATE MaTknElmtDef maTeLongSigInfo =
     DEFINE_STRUL(1,2560,LMA_VER2P,MA_TF_VER2P_MAND);

#define DEFINE_ACCNETSIGINFO_SEQ(seqHeader) \
 &seqHeader,\
    &maTeAccNetProtId,\
    &maTeLongSigInfo,\
    &maTeExtCont,\
 &maTeSeqTerm

PRIVATE MaTknElmtDef maTePreHoAccNetSigInfoSeq = 
     DEFINE_TAG_U_SEQ(MA_TAG_CSCONST2,LMA_VER2P,MA_TF_VER2P_OPT, maChkIgnoreSeq);

PRIVATE MaTknElmtDef maTePreHoMultiBearReq = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePreHoImsi =   /* Imsi                  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,3,8,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePreHoIntegProteInfo =
     DEFINE_TAG_STRE(MA_TAG_CSPRIM5,17,100,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePreHoEncrInfo =
     DEFINE_TAG_STRE(MA_TAG_CSPRIM6,17,100,LMA_VER2P,MA_TF_VER2P_OPT);

/* 
** Size was changed from (5~15) to (3~13) in 2002/09 release.
** We have defined the super size length (3~15) 
** So for release before Sep. 2002 size of 5~15 is allowed by MAP.
** a Stricter check should be made by the MAP user.
*/
PRIVATE MaTknElmtDef maTePreHoRadioResInfo = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM7,3,15,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePreHoAlloGsmAlgo = 
     DEFINE_TAG_U8(MA_TAG_CSPRIM9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePreHoAlloUmtsAlgoSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST10,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePermIntegProteAlgo = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePermEncrAlgo = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePreHoRadioResSeqof = 
     DEFINE_TAG_MINSEQOF(MA_TAG_CSCONST11,LMA_VER2P,MAT_MIN_NMB_RADIO_RES,
                         MAT_MAX_NMB_RADIO_RES,MA_TF_VER2P_OPT, maChkMinSeqOf);

/* 
** Size was changed from (5~15) to (3~13) in 2002/09 release.
** We have defined the super size length (3~15) 
** So for release before Sep. 2002 size of 5~15 is allowed by MAP.
** a Stricter check should be made by the MAP user.
*/
PRIVATE MaTknElmtDef maTeRadioResInfo = 
     DEFINE_STRS(3,15,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeRrRabId = 
     DEFINE_INT(1,255,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTePreHoRabId = 
     DEFINE_TAG_INT(MA_TAG_CSPRIM12,1,255,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePreHoBssMapServHo = 
     DEFINE_TAG_U8(MA_TAG_CSPRIM13,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePreHoRANAPServHo = 
     DEFINE_TAG_U8(MA_TAG_CSPRIM14,LMA_VER2P,MA_TF_VER2P_OPT);

#define DEFINE_ALLOUMTSALGO_SEQ(seqHeader) \
 &seqHeader,\
    &maTePermIntegProteAlgo,\
    &maTePermEncrAlgo,\
    &maTeExtCont2,\
 &maTeSeqTerm

#define DEFINE_RADIORES_LST(seqHeader) \
    &seqHeader,\
       &maTeSeqOptVer2P,\
          &maTeRadioResInfo,\
          &maTeRrRabId,\
       &maTeSeqTerm,\
    &maTeSeqTerm

PRIVATE MaTknElmtDef maTeBssMapServHo = 
     DEFINE_U8(LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTePreHoBssMapServHoSeqOf = 
     DEFINE_TAG_MINSEQOF(MA_TAG_CSCONST15, LMA_VER2P,
                         MAT_MIN_NMB_BSSMAP_SERV_HO_INFO, 
                         MAT_MAX_NMB_BSSMAP_SERV_HO_INFO,
                         MA_TF_VER2P_OPT, maChkMinSeqOf);

/* Addition - New data type introduced for 3.g.0 R99_4 */
#define DEFINE_BSSMAP_SERV_HO_LST(seqHeader) \
    &seqHeader,\
       &maTeSeqOptVer2P,\
          &maTeBssMapServHo,\
          &maTeRrRabId,\
       &maTeSeqTerm,\
    &maTeSeqTerm

PRIVATE MaTknElmtDef maTePreHoAscCallRef = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM20, 1, 8, LMA_VER2P, MA_TF_VER2P_OPT);

#if MAP_REL5

PRIVATE MaTknElmtDef maTeCodec1 = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1, 1 ,4, LMA_VER2P, MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeCodec2 = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2, 1 ,4, LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCodec3 = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM3, 1 ,4, LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCodec4 = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4, 1 ,4, LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCodec5 = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM5, 1 ,4, LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCodec6 = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM6, 1 ,4, LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCodec7 = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM7, 1 ,4, LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCodec8 = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM8, 1 ,4, LMA_VER2P, MA_TF_VER2P_OPT);

#define DEFINE_CODE_LIST(seqHeader) \
    &seqHeader, \
       &maTeCodec1, \
       &maTeCodec2, \
       &maTeCodec3, \
       &maTeCodec4, \
       &maTeCodec5, \
       &maTeCodec6, \
       &maTeCodec7, \
       &maTeCodec8, \
       &maTeExtCont9, \
    &maTeSeqTerm

PRIVATE MaTknElmtDef maTeUtranCodecSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST0, LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeGeranCodecSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST1, LMA_VER2P, MA_TF_VER2P_OPT);

#define DEFINE_SUP_CODEC_LIST(seqHeader) \
    &seqHeader,\
       DEFINE_CODE_LIST(maTeUtranCodecSeq),\
       DEFINE_CODE_LIST(maTeGeranCodecSeq),\
       &maTeExtCont2,\
    &maTeSeqTerm

PRIVATE MaTknElmtDef maTePreHoGeranClassMark =
     DEFINE_TAG_STRE(MA_TAG_CSPRIM16, 2, 87, LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePreHoCurrUsedCodec = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM17, 1 ,4, LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePreHoSupCodecsListSeq =
     DEFINE_TAG_SEQ(MA_TAG_CSCONST18, LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePreHoRabConfInd = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM19, LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePreHoUesbiIuSeq =
     DEFINE_TAG_SEQ(MA_TAG_CSCONST21, LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePreHoUesbiIuA =
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM0,1,128,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePreHoUesbiIuB =
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM1,1,128,LMA_VER2P,MA_TF_VER2P_OPT);

#endif /* MAP_REL6 */

PRIVATE MaTknElmtDef *maPreHoReqTkns[] = /* prepare handover request tokens */
{
 &maTePreHoSeq,
    &maTePreHoTgtCellId,
    &maTePreHoNmbNotReq,
    &maTePreHoBssApduSeq,
       &maTePhBaProtId,
       &maTePhBaSigInfo, 
#ifdef MAP_PHASE2_EXT_MARK
 &maTeExtMark,
#endif
       &maTeExtCont,
    &maTeSeqTerm,
#ifdef MAP_PHASE2_EXT_MARK
 &maTeExtMark,
#endif
    &maTePreHoRNCId,
    DEFINE_ACCNETSIGINFO_SEQ(maTePreHoAccNetSigInfoSeq),
    &maTePreHoMultiBearReq,
    &maTePreHoImsi,
    &maTePreHoIntegProteInfo,
    &maTePreHoEncrInfo,
    &maTePreHoRadioResInfo,
    &maTePreHoAlloGsmAlgo,
    DEFINE_ALLOUMTSALGO_SEQ(maTePreHoAlloUmtsAlgoSeq),
    DEFINE_RADIORES_LST(maTePreHoRadioResSeqof),
    #ifdef XWEXT
    &maXWExtCont8,
    #else
    &maTeExtCont8,
    #endif
    &maTePreHoRabId,
    &maTePreHoBssMapServHo,
    &maTePreHoRANAPServHo,
    DEFINE_BSSMAP_SERV_HO_LST(maTePreHoBssMapServHoSeqOf),
    &maTePreHoAscCallRef,
    /* Addition - Added 4 parameters for release 5 */
#if MAP_REL5
    &maTePreHoGeranClassMark,
    &maTePreHoCurrUsedCodec,
    DEFINE_SUP_CODEC_LIST(maTePreHoSupCodecsListSeq),
    &maTePreHoRabConfInd,
    &maTePreHoUesbiIuSeq,
      &maTePreHoUesbiIuA,
      &maTePreHoUesbiIuB,
    &maTeSeqTerm,
#endif /* MAP_REL5 */
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTePreHoRspHandOverNmb =   /* Zone Code             */
     DEFINE_TAG_U_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3,maChkVerStr);

PRIVATE MaTknElmtDef maTePreHoRelocNmbLst = 
  DEFINE_TAG_SEQOF(MA_TAG_CSCONST1,LMA_VER2P,MAT_MAX_NMB_RELOCATION_NMB,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePreHoRelocNmbSeq = 
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeHandOverNmb =   /* Hand over number */
     DEFINE_STRS(1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeRabId = 
     DEFINE_INT(1,255,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTePreHoMultiBearInfo = 
     DEFINE_TAG_INT(MA_TAG_CSPRIM3,1,7,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePreHoMultiBearNotSup = 
     DEFINE_NULL(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePreHoRspSeleUmtsAlgoSeq = 
      DEFINE_TAG_SEQ(MA_TAG_CSCONST5,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeChoIntegProteAlgo = 
     DEFINE_TAG_U8(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeChoEncrAlgo = 
     DEFINE_TAG_U8(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePreHoRspChoRadioResInfoSeq = 
      DEFINE_TAG_SEQ(MA_TAG_CSCONST6,LMA_VER2P,MA_TF_VER2P_OPT);

/* 
** We have defined the maximum to 2.
** So for release before Sep. 2002 size of 2 is allowed by MAP.
** a Stricter check should be made by the MAP user.
*/
PRIVATE MaTknElmtDef maChoChanInfo = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maChoSpeechVer = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,2,LMA_VER2P,MA_TF_VER2P_OPT);

#define DEFINE_SELEUMTSALGO_SEQ(seqHeader) \
 &seqHeader,\
    &maTeChoIntegProteAlgo,\
    &maTeChoEncrAlgo,\
    &maTeExtCont2,\
 &maTeSeqTerm

#if MAP_REL5
PRIVATE MaTknElmtDef maTePreRspSeledCodec = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM7, 1 ,4, LMA_VER2P, MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef maTePreRspAvaCodecLst =
     DEFINE_TAG_SEQ(MA_TAG_CSCONST8, LMA_VER2P, MA_TF_VER2P_OPT);
#endif

#define DEFINE_CHORADIORESINFO_SEQ(seqHeader) \
 &seqHeader,\
    &maChoChanInfo,\
    &maChoSpeechVer,\
 &maTeSeqTerm

PRIVATE MaTknElmtDef *maPreHoRspTkns[] = /* prepare handover response tokens */
{
 &maTePreHoSeq,
    &maTePreHoRspHandOverNmb,
    &maTePreHoBssApduSeq,
       &maTePhBaProtId,
       &maTePhBaSigInfo, 
/* Extension marker added here is for structure reuse and **
** is not effective for 2P definitions.                   ** 
*/
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
       &maTeExtCont,
    &maTeSeqTerm,
/* Extension marker added here is for structure reuse and **
** is not effective for 2P definitions.                   ** 
*/
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTePreHoRelocNmbLst,
       &maTePreHoRelocNmbSeq,
          &maTeHandOverNmb,
          &maTeRabId,
       &maTeSeqTerm,
    &maTeSeqTerm,
    DEFINE_ACCNETSIGINFO_SEQ(maTePreHoAccNetSigInfoSeq),
    &maTePreHoMultiBearInfo,
    &maTePreHoMultiBearNotSup,
    DEFINE_SELEUMTSALGO_SEQ(maTePreHoRspSeleUmtsAlgoSeq),
    DEFINE_CHORADIORESINFO_SEQ(maTePreHoRspChoRadioResInfoSeq),
    #ifdef XWEXT
    &maXWExtCont4,
    #else
    &maTeExtCont4,
    #endif
 /* Addition - Added 1 parameter for release 5 */
#if MAP_REL5
    &maTePreRspSeledCodec,
    DEFINE_CODE_LIST(maTePreRspAvaCodecLst),
#endif
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_REL99 */

#if MAP_REL99
#else
PRIVATE MaTknElmtDef maTePreSubsHoSeq =   /* Pre Ho Seq            */
     DEFINE_SEQ(LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef maTePreSubHoTgtMscNmb =   /* Target Msc Number     */
     DEFINE_STRS(1,9,LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef maTePreSubHoTgtCellId =   /* target Cell Id      */
     DEFINE_STRS(5,7,LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef maTePhSubBssApduSeq =   /* Bss Apdu Seq          */
     DEFINE_SEQ(LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef *maPreSubsHoReqTkns[] = /* prepare Subs. ho requset tokens */
{
 &maTePreSubsHoSeq,
    &maTePreSubHoTgtCellId,
    &maTePreSubHoTgtMscNmb,
    &maTePhSubBssApduSeq,
       &maTePhBaProtId,
       &maTePhBaSigInfo,
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
       &maTeExtCont,
    &maTeSeqTerm, 
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
 &maTeSeqTerm, 
 NULLP,
};

PRIVATE MaTknElmtDef *maPreSubsHoRspTkns[] = /* prepare Subs ho response tokens */
{
 &maTePhSubBssApduSeq,
    &maTePhBaProtId,
    &maTePhBaSigInfo,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTeExtCont,
 &maTeSeqTerm, 
 NULLP,
};
#endif
#if MAP_REL99            
PRIVATE MaTknElmtDef maTePreSubsHoSeq =   /* Pre Ho Seq */
     DEFINE_TAG_U_SEQ(MA_TAG_CSCONST3,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0,maChkSeq2);


PRIVATE MaTknElmtDef maTePreSubHoTgtCellId =   /* target Cell Id      */
     DEFINE_TAG_U_STRS(MA_TAG_CSPRIM0,5,7,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT2,maChkVerStr);

PRIVATE MaTknElmtDef maTePreSubHoTgtMscNmb =   /* Target Msc Number     */
     DEFINE_TAG_U_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0,maChkVerStr);

PRIVATE MaTknElmtDef maTePhSubBssApduSeq =   /* Bss Apdu Seq          */
     DEFINE_SEQ(LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef maTePreSubsHoRNCId =   /* RNCId                  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,7,7,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePreSubsHoAccNetSigInfoSeq = 
     DEFINE_TAG_U_SEQ(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_OPT, maChkIgnoreSeq);

PRIVATE MaTknElmtDef maTePreSubsHoRabId = 
     DEFINE_TAG_INT(MA_TAG_CSPRIM4,1,255,LMA_VER2P,MA_TF_VER2P_OPT);

 /* Addition - Added 2 parameters for release 5 */
#if MAP_REL5
PRIVATE MaTknElmtDef maTePshGeranClassMark = 
     DEFINE_TAG_STRE(MA_TAG_CSPRIM6, 2, 87, LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePshRabConfInd = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM7, LMA_VER2P, MA_TF_VER2P_OPT);
#endif

PRIVATE MaTknElmtDef *maPreSubsHoReqTkns[] = /* prepare Subs. ho requset tokens */
{
 &maTePreSubsHoSeq,
    &maTePreSubHoTgtCellId,
    &maTePreSubHoTgtMscNmb,
    &maTePhSubBssApduSeq,
       &maTePhBaProtId,
       &maTePhBaSigInfo,
/* Extension marker added here is for structure reuse and **
** is not effective for 2P definitions.                   ** 
*/
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
       &maTeExtCont,
    &maTeSeqTerm, 
/* Extension marker added here is for structure reuse and **
** is not effective for 2P definitions.                   ** 
*/
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTePreSubsHoRNCId,
    DEFINE_ACCNETSIGINFO_SEQ(maTePreSubsHoAccNetSigInfoSeq),
    &maTePreSubsHoRabId,
    &maTeExtCont5,
 /* Addition - Added 2 parameters for release 5 */
#if MAP_REL5
    &maTePshGeranClassMark,
    &maTePshRabConfInd,
#endif
 &maTeSeqTerm, 
 NULLP,
};

PRIVATE MaTknElmtDef maTePreSubsHoRspSeq =  
     DEFINE_TAG_U_SEQ(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_MAND,maChkSeq1);

PRIVATE MaTknElmtDef maTePreSubsHoRspAccNetSigInfoSeq = 
     DEFINE_U_SEQ(LMA_VER2P,MA_TF_VER2P_MAND, maChkIgnoreSeq);

PRIVATE MaTknElmtDef *maPreSubsHoRspTkns[] = /* prepare Subs ho response */
{
 &maTePreSubsHoRspSeq,
    &maTePhSubBssApduSeq,
       &maTePhBaProtId,
       &maTePhBaSigInfo,
/* Extension marker added here is for structure reuse and **
** is not effective for 2P definitions.                   ** 
*/
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
       &maTeExtCont,
    &maTeSeqTerm, 
    DEFINE_ACCNETSIGINFO_SEQ(maTePreSubsHoRspAccNetSigInfoSeq),
    &maTeExtCont0,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef maTePerHoSeq =   /* Perform Handover seq  */
     DEFINE_SEQ(LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTePhTgtCellId =   /* Tgt Cell Id           */
     DEFINE_STRS(5,7,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTePhServCellId =   /* Serv Cell Id          */
     DEFINE_STRS(5,7,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTePhChanType =   /* Channel Type          */
     DEFINE_STRS(1,10,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTePhClassMarkInfo =   /* Class Mark Info       */
     DEFINE_STRS(1,2,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTePhHoPri =   /* Hand over Priority   */
     DEFINE_TAG_U8(MA_TAG_CSPRIM11,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTePhKc =   /* Kc                    */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM12,8,8,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef *maPerHoReqTkns[] = /* perform handover request tokens */
{
 &maTePerHoSeq,
    &maTePhTgtCellId,
    &maTePhServCellId,
    &maTePhChanType,
    &maTePhClassMarkInfo,
    &maTePhHoPri,
    &maTePhKc,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTePshTgtMscNmb =   /* Msc Number            */
     DEFINE_STRS(1,9,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTePshClassMarkInfo =   /* Class Mark Info       */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM10,1,2,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef *maPerSubsHoReqTkns[] = /* perform Subs ho request tokens */
{
 &maTePerHoSeq,
    &maTePhTgtCellId,
    &maTePhServCellId,
    &maTePshTgtMscNmb,
    &maTePshClassMarkInfo,
 &maTeSeqTerm,
 NULLP,
};


PRIVATE MaTknElmtDef maTePerHoRspSeq =   /* Perform Handover Seq  */
     DEFINE_SEQ(LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTePhHandNmb =   /* Hand over Number      */
     DEFINE_STRS(1,9,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTePhAccSigInfoSeq =   /* Access Signal info seq*/
     DEFINE_SEQ(LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTePhAsiProtId =   /* Protocol Id           */
     DEFINE_ENUM(LMA_VER1,MA_TF_VER1_MAND,maProtIdEnums);

PRIVATE MaTknElmtDef maTePhAsiSigInfo =   /* Signal Info           */
     DEFINE_STRE(1,200,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef *maPerHoRspTkns[] = /* perform handover response tokens */
{
 &maTePerHoRspSeq,
    &maTePhHandNmb,
    &maTePhAccSigInfoSeq,
       &maTePhAsiProtId,
       &maTePhAsiSigInfo,
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
    &maTeSeqTerm, 
 &maTeSeqTerm, 
 NULLP,
};
PRIVATE MaTknElmtDef *maPerSubsHoRspTkns[] = /* perform Subs ho response tokens */
{
 &maTePhAccSigInfoSeq,
    &maTePhAsiProtId,
    &maTePhAsiSigInfo,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
 &maTeSeqTerm, 
 NULLP,
};

PRIVATE MaTknElmtDef maTeExtSigInfoSeqMand = /* Ext. Sig info seq. (mand) */
     DEFINE_SEQ(LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeEsiProtId = /* protocol id (mand.) */
     DEFINE_ENUM(LMA_VER1AND2,MA_TF_VER1AND2_OPT0,maProtIdEnums);

PRIVATE MaTknElmtDef maTeEsiSigInfo = /* signal info (mand.) */
     DEFINE_STRE(1,200,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

#if MAP_REL99
#else

PRIVATE MaTknElmtDef *maSndEndSigReqTkns[] =  /* Send End signal tokens */
{
 &maTeExtSigInfoSeqMand,
    &maTeEsiProtId,
    &maTeEsiSigInfo,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTeExtCont,
 &maTeSeqTerm, 
 NULLP,
};

PRIVATE MaTknElmtDef *maProcAccSigReqTkns[] =  /* Send End signal tokens */
{
 &maTeExtSigInfoSeqMand,
    &maTeEsiProtId,
    &maTeEsiSigInfo,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTeExtCont,
 &maTeSeqTerm, 
 NULLP,
};

PRIVATE MaTknElmtDef *maFwdAccSigReqTkns[] =  /* Send End signal tokens */
{
 &maTeExtSigInfoSeqMand,
    &maTeEsiProtId,
    &maTeEsiSigInfo,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTeExtCont,
 &maTeSeqTerm, 
 NULLP,
};

#endif
#if MAP_REL99             

PRIVATE MaTknElmtDef maTeFwdAccSigReqSeq = 
     DEFINE_TAG_U_SEQ(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_MAND,maChkSeq1);

PRIVATE MaTknElmtDef maTeFasAccNetSigInfoSeq = 
      DEFINE_U_SEQ(LMA_VER2P,MA_TF_VER2P_MAND, maChkIgnoreSeq);

PRIVATE MaTknElmtDef maTeFasIntegProteInfo =
     DEFINE_TAG_STRE(MA_TAG_CSPRIM0,17,100,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeFasEncrInfo =
     DEFINE_TAG_STRE(MA_TAG_CSPRIM1,17,100,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeFasKeyStatus =
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT,maChkKeyStatus,maKeyStatusEnums);

PRIVATE MaTknElmtDef maTeFasAlloGsmAlgo = 
     DEFINE_TAG_U8(MA_TAG_CSPRIM4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeFasAlloUmtsAlgoSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST5,LMA_VER2P,MA_TF_VER2P_OPT);

/* 
** Size was changed from (5~15) to (3~13) in 2002/09 release.
** We have defined the super size length (3~15) 
** So for release before Sep. 2002 size of 5~15 is allowed by MAP.
** a Stricter check should be made by the MAP user.
*/
PRIVATE MaTknElmtDef maTeFasRadioResInfo = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM6,3,15,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeFwdAccRadioResSeqof = 
     DEFINE_TAG_MINSEQOF(MA_TAG_CSCONST7,LMA_VER2P,MAT_MIN_NMB_RADIO_RES,
                         MAT_MAX_NMB_RADIO_RES,MA_TF_VER2P_OPT, maChkMinSeqOf);

PRIVATE MaTknElmtDef maTeFwdAccBssMapServHo = 
     DEFINE_TAG_U8(MA_TAG_CSPRIM9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeFwdAccRANAPServHo = 
     DEFINE_TAG_U8(MA_TAG_CSPRIM8,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeFwdAccBssMapServHoSeqOf = 
     DEFINE_TAG_MINSEQOF(MA_TAG_CSCONST10, LMA_VER2P,
                         MAT_MIN_NMB_BSSMAP_SERV_HO_INFO, 
                         MAT_MAX_NMB_BSSMAP_SERV_HO_INFO,
                         MA_TF_VER2P_OPT, maChkMinSeqOf);

/* Addition - Added 3 parameters for release 5 */
#if MAP_REL5
PRIVATE MaTknElmtDef maTeFwdAccCurrUsedCodec = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM11, 1 ,4, LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeFwdAccIuSupCodecsListSeq =
     DEFINE_TAG_SEQ(MA_TAG_CSCONST12, LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeFwdAccIuSelectedCodec =
     DEFINE_TAG_STRS(MA_TAG_CSPRIM14, 1 ,4, LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeFwdAccRabConfInd = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM13, LMA_VER2P, MA_TF_VER2P_OPT);
#endif

PRIVATE MaTknElmtDef *maFwdAccSigReqTkns[] =  /* Send End signal tokens */
{
 &maTeFwdAccSigReqSeq,
    &maTeExtSigInfoSeqMand,
       &maTeEsiProtId,
       &maTeEsiSigInfo,
/* Extension marker added here is for structure reuse and **
** is not effective for 2P definitions.                   ** 
*/
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
       &maTeExtCont,
    &maTeSeqTerm, 
    DEFINE_ACCNETSIGINFO_SEQ(maTeFasAccNetSigInfoSeq),
    &maTeFasIntegProteInfo,
    &maTeFasEncrInfo,
    &maTeFasKeyStatus,
    &maTeFasAlloGsmAlgo,
    DEFINE_ALLOUMTSALGO_SEQ(maTeFasAlloUmtsAlgoSeq),
    &maTeFasRadioResInfo,
    &maTeExtCont3,
    DEFINE_RADIORES_LST(maTeFwdAccRadioResSeqof),
    &maTeFwdAccBssMapServHo,
    &maTeFwdAccRANAPServHo,
    DEFINE_BSSMAP_SERV_HO_LST(maTeFwdAccBssMapServHoSeqOf),
    /* Addition - Added 3 parameters for release 5 */
#if MAP_REL5
    &maTeFwdAccCurrUsedCodec,
    DEFINE_SUP_CODEC_LIST(maTeFwdAccIuSupCodecsListSeq),
    &maTeFwdAccRabConfInd,
    &maTeFwdAccIuSelectedCodec,
#endif
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTeProcAccSigReqSeq =  
     DEFINE_TAG_U_SEQ(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_MAND,maChkSeq1);

PRIVATE MaTknElmtDef maTePasSeleUmtsAlgoSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePasSeleGsmAlgo = 
     DEFINE_TAG_U8(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePasChoRadioResInfoSeq = 
      DEFINE_TAG_SEQ(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePasRabId = 
     DEFINE_TAG_INT(MA_TAG_CSPRIM4,1,255,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL5
PRIVATE MaTknElmtDef maTePasSeledCodec = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM5, 1 ,4, LMA_VER2P, MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef maTePasAvaCodecLst =
     DEFINE_TAG_SEQ(MA_TAG_CSCONST6, LMA_VER2P, MA_TF_VER2P_OPT);
#endif

PRIVATE MaTknElmtDef *maProcAccSigReqTkns[] = /* Process Access Signal */
{
 &maTeProcAccSigReqSeq,
    &maTeExtSigInfoSeqMand,
       &maTeEsiProtId,
       &maTeEsiSigInfo,
/* Extension marker added here is for structure reuse and **
** is not effective for 2P definitions.                   ** 
*/
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
       &maTeExtCont,
    &maTeSeqTerm, 
    DEFINE_ACCNETSIGINFO_SEQ(maTePreSubsHoRspAccNetSigInfoSeq),
    DEFINE_SELEUMTSALGO_SEQ(maTePasSeleUmtsAlgoSeq),
    &maTePasSeleGsmAlgo,
    DEFINE_CHORADIORESINFO_SEQ(maTePasChoRadioResInfoSeq),
    &maTePasRabId,
    &maTeExtCont0,
 /* Addition - Added 1 parameter for release 5 */
#if MAP_REL5
    &maTePasSeledCodec,
    DEFINE_CODE_LIST(maTePasAvaCodecLst),
#endif
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTeSndEndSigReqSeq = 
     DEFINE_TAG_U_SEQ(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_MAND,maChkSeq1);

PRIVATE MaTknElmtDef *maSndEndSigReqTkns[] =  /* Send End signal tokens */
{
 &maTeSndEndSigReqSeq,
    &maTeExtSigInfoSeqMand,
       &maTeEsiProtId,
       &maTeEsiSigInfo,
/* Extension marker added here is for structure reuse and **
** is not effective for 2P definitions.                   ** 
*/
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
       &maTeExtCont,
    &maTeSeqTerm, 
    DEFINE_ACCNETSIGINFO_SEQ(maTePreSubsHoRspAccNetSigInfoSeq),
    &maTeExtCont0,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maSndEndSigRspTkns[] =  /* Send End signal tokens */
{
 &maTeSeqOptVer2P,
    #ifdef XWEXT
    &maXWExtCont0,
    #else
    &maTeExtCont0,
    #endif
 &maTeSeqTerm,
 NULLP,
};


#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef maTeNoteInterHoSeq =   /* Note Inter Ho seq     */
     DEFINE_SEQ(LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeNihoHoType =   /* Hand over type        */
     DEFINE_ENUM(LMA_VER1,MA_TF_VER1_MAND,maInterHoTypeEnums);

PRIVATE MaTknElmtDef maTeNihoTgtCellId =   /* Target Cell Id        */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,5,7,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeNihoChanIdSeq =   /* Channel Id Seq.       */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST2,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeNihoCiProtId =   /* Protocol Identifier   */
     DEFINE_ENUM(LMA_VER1,MA_TF_VER1_MAND,maProtIdEnums);

PRIVATE MaTknElmtDef maTeNihoCiSigInfo =   /* Signal Info           */
     DEFINE_STRE(1,200,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef *maNoteInterHoReqTkns[] = 
{
 &maTeNoteInterHoSeq,
    &maTeNihoHoType,
    &maTeNihoTgtCellId,
    &maTeNihoChanIdSeq,
       &maTeNihoCiProtId,
       &maTeNihoCiSigInfo,
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
    &maTeSeqTerm,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_MSC */

/* -------------------------------------------------------------------- */
/* Forward SM Request and Response                                      */
/* -------------------------------------------------------------------- */

#if (MAP_MSC || MAP_GSN)
#ifdef XWEXT/*in XINWEI SCDMA system, this is optional, because there is no SC Address*/
PRIVATE MaTknElmtDef maTeFwdSmRpdaChoice =   /* SM-RP-DA Choice       */
     DEFINE_CHOICE(sizeof(MaSMRPDA),LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT4);
#else
PRIVATE MaTknElmtDef maTeFwdSmRpdaChoice =   /* SM-RP-DA Choice       */
     DEFINE_CHOICE(sizeof(MaSMRPDA),LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);
#endif

PRIVATE MaTknElmtDef maTeFwdSmImsi =   /* Imsi                  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeFwdSmLmsi =   /* LMSI                  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,4,4,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeFwdSmRoamNmb =   /* Roaming number        */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,9,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeFwdSmSCAddrDA =   /* Service Centre Address*/
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,1,20,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeFwdSmNoSmSpda =   /* No Sm Sp da           */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM5,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeFwdSmRpoaChoice =   /* Sm Rp oa choice       */
     DEFINE_CHOICE(sizeof(MaSMRPOA),LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeFwdSmMsIsdn =   /* Ms Isdn               */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,9,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeFwdSmScAddrDA =   /* SC Address DA         */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,1,20,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeFwdSmNoSmSpoa =   /* Zone Code             */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM5,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeFwdSmRpui =   /* Sm Rpui               */
     DEFINE_STRE(1,200,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeFwdSmMsgToSnd =   /* Message to Send       */
     DEFINE_NULL(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeMoFwdSmMsgToSnd =   /* Message to Send       */
     DEFINE_NULL(LMA_VER2,MA_TF_VER2_OPT);

#if (MAP_REL98 || MAP_REL99)
PRIVATE MaTknElmtDef maTeFwdSmImsi1 =  /* Forward SM IMSI */
     DEFINE_STRS(3,8,LMA_VER2P,MA_TF_VER2P_OPT);

#endif /* MAP_REL98 || MAP_REL99 */

PRIVATE MaTknElmtDef *maFwdSMReqTkns[] = 
{
 &maTeSeqMand,
    &maTeFwdSmRpdaChoice,
       &maTeFwdSmImsi,
       &maTeFwdSmLmsi,
       &maTeFwdSmRoamNmb,
       &maTeFwdSmSCAddrDA,
       &maTeFwdSmNoSmSpda,
    &maTeSeqTerm,
    &maTeFwdSmRpoaChoice,
       &maTeFwdSmMsIsdn,
       &maTeFwdSmScAddrDA,
       &maTeFwdSmNoSmSpoa,
    &maTeSeqTerm,
    &maTeFwdSmRpui,
    &maTeMoFwdSmMsgToSnd,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTeExtCont,
#if (MAP_REL98 || MAP_REL99)
    &maTeFwdSmImsi1,
#endif /* MAP_REL98 || MAP_REL99 */
 &maTeSeqTerm,
 NULLP,
};


PRIVATE MaTknElmtDef maTeFwdSmRspRpui =   /* SM - RPUI             */
     DEFINE_STRE(1,200,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maFwdSMRspTkns[] = 
{
 &maTeSeqOptVer2P,
    &maTeFwdSmRspRpui,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};


PRIVATE MaTknElmtDef maTeMoFwdSmRpdaChoice =   /* SM-RP-DA Choice       */
     DEFINE_CHOICE(sizeof(MaSMRPDA),LMA_VER2P,MA_TF_VER2P_MAND);

#ifdef XWEXT
PRIVATE MaTknElmtDef maTeMoFwdSmImsi =   /* for XW SCDMA , this item (Imsi) be filled with MAISDN   */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER2P,MA_TF_VER2P_MAND);
#else
PRIVATE MaTknElmtDef maTeMoFwdSmImsi =   /* Imsi                  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER2P,MA_TF_VER2P_MAND);
#endif

PRIVATE MaTknElmtDef maTeMoFwdSmLmsi =   /* LMSI                  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,4,4,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeMoFwdSmRoamNmb =   /* Roaming Number    */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,9,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeMoFwdSmSCAddrDA =   /* Service Centre Address*/
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,1,20,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeMoFwdSmNoSmSpda =   /* No Sm Sp da           */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM5,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeMoFwdSmRpoaChoice =   /* Sm Rp oa choice       */
     DEFINE_CHOICE(sizeof(MaSMRPOA),LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeMoFwdSmMsIsdn =   /* Ms Isdn               */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeMoFwdSmScAddrDA =   /* SC Address DA         */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,1,20,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeMoFwdSmNoSmSpoa =   /* Zone Code             */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM5,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeMoFwdSmRpui =   /* Sm Rpui               */
     DEFINE_STRE(1,200,LMA_VER2P,MA_TF_VER2P_MAND);


PRIVATE MaTknElmtDef *maMtFwdSMReqTkns[] = 
{
 &maTeSeqMand,
 &maTeMoFwdSmRpdaChoice,
    &maTeMoFwdSmImsi,
    &maTeMoFwdSmLmsi,
    &maTeMoFwdSmRoamNmb,
    &maTeMoFwdSmSCAddrDA,
    &maTeMoFwdSmNoSmSpda,
 &maTeSeqTerm,
 &maTeMoFwdSmRpoaChoice,
    &maTeMoFwdSmMsIsdn,
    &maTeMoFwdSmScAddrDA,
    &maTeMoFwdSmNoSmSpoa,
 &maTeSeqTerm,
 &maTeMoFwdSmRpui,
 &maTeFwdSmMsgToSnd,
 #ifdef XWEXT
 &maXWExtCont,
 #else
 &maTeExtCont,
 #endif
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTeMoFwdSmRspRpui =   /* SM - RPUI             */
     DEFINE_STRE(1,200,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maMtFwdSMRspTkns[] = 
{
 &maTeSeqOpt,
    &maTeMoFwdSmRspRpui,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_MSC || MAP_GSN */

/* -------------------------------------------------------------------- */
/* Route Information Request and Response &                             */
/* Route Information for SM Request and Response &                      */
/* Report SM Delivery Request and Response &                            */
/* Alert Service Centre Request &                                       */
/* Inform Service Centre Request                                        */
/* -------------------------------------------------------------------- */

#if (MAP_MSC || MAP_HLR)

 PRIVATE MaTknElmtDef maTeRiMsIsdn      = 
 DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

 PRIVATE MaTknElmtDef maTeRiCugIntLock      = 
 DEFINE_TAG_STRS(MA_TAG_CSPRIM1,4,4,LMA_VER1,MA_TF_VER1_OPT);

 PRIVATE MaTknElmtDef maTeRiNetSigSeq      = 
 DEFINE_TAG_SEQ(MA_TAG_CSCONST10,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

 PRIVATE MaTknElmtDef maTeRiCugChkInfoSeq      = 
 DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

 PRIVATE MaTknElmtDef maTeRiCciCugIntLck      = 
 DEFINE_STRS(4,4,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

 PRIVATE MaTknElmtDef maTeRiCugOgAcc      = 
 DEFINE_NULL(LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeRiNmbOfFwd =  /* Number of forwarding */
 DEFINE_TAG_INT(MA_TAG_CSPRIM2,1,5,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeRiProtIdOpt = /* protocol id (mand.) */
     DEFINE_ENUM(LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0,maProtIdEnums);

PRIVATE MaTknElmtDef maTeRiSigInfoOpt = /* signal info (mand.) */
     DEFINE_STRE(1,200,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeRiInterroType =  /* Interrogation Type */
 DEFINE_TAG_ENUM(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_MAND,maInterroTypeEnums);

PRIVATE MaTknElmtDef maTeRiOrInterro =    /* NULL */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRiOrPhase =      /* OR- Phase */
     DEFINE_TAG_INT(MA_TAG_CSPRIM5,1,127,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRiGmscAddr =     /* ISDN Address String */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM6,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeRiCallRefNmb =   /* Call Reference number */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM7,1,8,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRiFwdReason =    /* Forwarding Reason */
  DEFINE_TAG_ENUM(MA_TAG_CSPRIM8,LMA_VER2P,MA_TF_VER2P_OPT,maFwdReasonEnums);

PRIVATE MaTknElmtDef maTeRiExtBscChoice =  /* Extended Basic serv code */
     DEFINE_TAG_CHOICE(sizeof(MaExtBasServCode),MA_TAG_CSCONST9,
                       LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRiCamInfoSeq =   /* camel Info sequence */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST11,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRiSuppofAncmt =  /* Supp. of Ancmnt */
    DEFINE_TAG_NULL(MA_TAG_CSPRIM12,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRiAlrtPat =      /* Alerting Pattern */
     DEFINE_TAG_U8(MA_TAG_CSPRIM14,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRiCcbsCall =     /* NULL */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM15,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRiSupCcbsPhase =  /* Supported CCBs phase */
     DEFINE_TAG_INT(MA_TAG_CSPRIM16,1,127,LMA_VER2P,MA_TF_VER2P_OPT);

#if (MAP_REL98 || MAP_REL99)
PRIVATE MaTknElmtDef maTeRiExtExtSigInfoSeq =   /* Ext. Ext.signal Info */
     DEFINE_TAG_U_SEQ(MA_TAG_CSCONST17,LMA_VER2P,MA_TF_VER2P_OPT,maChkIgnoreSeq);
#endif /* MAP_REL98 || MAP_REL99 */

#if MAP_REL99
PRIVATE MaTknElmtDef maTeRiIstSupInd =
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM18,LMA_VER2P,MA_TF_VER2P_OPT,maChkIstSupInd,maIstSupIndEnums);

PRIVATE MaTknElmtDef maTeRiPrePagingSup = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM19,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRiCallDivTreInd = 
     DEFINE_TAG_U8(MA_TAG_CSPRIM20,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRiLongFtnSup =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM21,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MAP_REL99 */

#if MAP_REL5
PRIVATE MaTknElmtDef maTeRiSupreVtCsi = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM22,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRiSupreInCallBar = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM23,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRiGsmScfInitCall = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM24,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRiBasicServGrp2Choice =  /* Extended Basic serv code */
     DEFINE_TAG_CHOICE(sizeof(MaExtBasServCode),MA_TAG_CSCONST25,
                       LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE MaTknElmtDef maTeRiNetSig2Seq      =
 DEFINE_TAG_SEQ(MA_TAG_CSCONST26,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

/* ma001.203 : Addition: Additional elmnts */
#if MAP_REL99
#ifdef MAP_CH_PLUS
PRIVATE MaTknElmtDef maTeRiRedirLrn =   /* Redirecting LRN */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM29,1,MAT_MAX_NLR_NMB_STR_LEN,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRiCallingLrn =   /* Calling LRN */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM30,1,MAT_MAX_NLR_NMB_STR_LEN,LMA_VER2P,MA_TF_VER2P_OPT);
#endif
#endif

PRIVATE MaTknElmtDef *maRoutInfoReqTkns[] = /* Route Info request */
{
 &maTeSeqOpt,
    &maTeRiMsIsdn,
    &maTeRiCugIntLock,
    &maTeRiCugChkInfoSeq,
       &maTeRiCciCugIntLck,
       &maTeRiCugOgAcc,
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
       &maTeExtCont,
    &maTeSeqTerm,
    &maTeRiNmbOfFwd,
    &maTeRiInterroType,
    &maTeRiOrInterro,
    &maTeRiOrPhase,
    &maTeRiGmscAddr,
    &maTeRiCallRefNmb,
    &maTeRiFwdReason,
    DEFINE_EXT_BSC_CHOICE(maTeRiExtBscChoice),
    &maTeRiNetSigSeq,
       &maTeRiProtIdOpt,
       &maTeRiSigInfoOpt,
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
       &maTeExtCont,
    &maTeSeqTerm,
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
    DEFINE_CAMINFO_SEQ(maTeRiCamInfoSeq),
    &maTeRiSuppofAncmt,
    #ifdef XWEXT
    &maXWExtCont13,
    #else
    &maTeExtCont13,
    #endif
    &maTeRiAlrtPat,
    &maTeRiCcbsCall,
    &maTeRiSupCcbsPhase,
#if (MAP_REL98 || MAP_REL99)
    DEFINE_EXTEXTSIGINFO_SEQ(maTeRiExtExtSigInfoSeq),
#endif /* MAP_REL98 || MAP_REL99 */
#if MAP_REL99
    &maTeRiIstSupInd,
    &maTeRiPrePagingSup,
    &maTeRiCallDivTreInd,
    &maTeRiLongFtnSup,
#if MAP_REL5
    &maTeRiSupreVtCsi,
    &maTeRiSupreInCallBar, 
    &maTeRiGsmScfInitCall,
    DEFINE_EXT_BSC_CHOICE(maTeRiBasicServGrp2Choice),
    &maTeRiNetSig2Seq,
       &maTeRiProtIdOpt,
       &maTeRiSigInfoOpt,
/* Extension marker added here is for structure reuse and **
** is not effective for 2P definitions.                   ** 
*/
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
       &maTeExtCont,
    &maTeSeqTerm,
#endif /* MAP_REL5 */
/* ma001.203 : Addition: Additional elmnts */
#ifdef MAP_CH_PLUS
    &maTeRiRedirLrn,
    &maTeRiCallingLrn,
#endif
#endif /* MAP_REL99 */

 &maTeSeqTerm, 
 NULLP,
};


PRIVATE MaTknElmtDef maTeRirImsiChoice =   /* Imsi Choice       */
     DEFINE_CHOICE(sizeof(MaSndRIRspImsi),LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeRirVer1And2Imsi =   /* IMSI                  */
     DEFINE_STRS(3,8,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeRirVer2PImsi =   /* IMSI                  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM9,3,8,LMA_VER2P,MA_TF_VER2P_OPT);


PRIVATE MaTknElmtDef maTeRirProtChoice =  /* Rout Info Choice      */
     DEFINE_CHOICE(sizeof(MaRoutInfo),LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeRirRoutInfoChoice =  /* Rout Info Choice      */
     DEFINE_CHOICE(sizeof(MaRouteInfo),LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeRirRiRoamNmb =   /* Isdn Address String  */
     DEFINE_STRS(1,9,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeRirRiFdFwdToNmb =   /* Isdn Address String  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM5,1,9,LMA_VER1AND2,MA_TF_VER1AND2_OPT2);

PRIVATE MaTknElmtDef maTeRirRiFdFwdToSubAddr =   /* Isdn subAddress String   */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,1,21,LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTeRirRiFdFwdOpt =   /* Forwarding options (U8) */
     DEFINE_TAG_U8(MA_TAG_CSPRIM6,LMA_VER1AND2,MA_TF_VER1AND2_OPT3);

PRIVATE MaTknElmtDef maTeRirExtRIChoice =   /* Extended RI Choice    */
     DEFINE_CHOICE(sizeof(MaExtRoutInfo),LMA_VER2P,MA_TF_VER2P_OPT);

/* need exception to handle different tags in version 2 and version 2p */
PRIVATE MaTknElmtDef maTeRirCugChkInfoSeq =   /* Call Reference number */
     DEFINE_TAG_U_SEQ(MA_TAG_CSCONST3,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3,
                    maChkSeq2);

PRIVATE MaTknElmtDef maTeRirCugSubsFlg =   /* NULLL                 */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM6,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRirSubsInfoSeq =   /* Subscriber Info seq.  */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST7,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRirSsLst =   /* SS List               */
  DEFINE_TAG_SEQOF(MA_TAG_CSCONST1,LMA_VER2P,MAT_MAX_SS,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRirExtBscChoice =   /* Ex. Bsc Choice        */
     DEFINE_TAG_CHOICE(sizeof(MaExtBasServCode),MA_TAG_CSCONST5,
                       LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRirFwdInterroReq =   /* NULL                  */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRirVmscAddr =   /* Isdn Address String   */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRirNaeaPrefCiSeq = /* NAEA-PreferredCI Seq     */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST10,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRirCcbsIndSeq =   /* Ccbs Indicators Seq      */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST11,LMA_VER2P,MA_TF_VER2P_OPT);

#if (MAP_REL98 || MAP_REL99)
PRIVATE MaTknElmtDef maTeRirMsIsdn =   /* Isdn Address String   */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM12,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRirNmbPortStatus =  /* Number portability status */
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM13,LMA_VER2P,MA_TF_VER2P_OPT,maChkNmbPortStatus,maNmbPortStatEnums);
#endif /* MAP_REL98 || MAP_REL99 */

#if MAP_REL99
PRIVATE MaTknElmtDef maTeRirIstAlertTimer  =  /* Ist Alert Timer */
     DEFINE_TAG_INT(MA_TAG_CSPRIM14,15,255,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL5
PRIVATE MaTknElmtDef maTeRirSupCamPhase = 
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM15,1,16,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRirOffCam4CSIs =
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM16,7,16,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRirRI2Choice =   /* Routing Info 2 Choice    */
     DEFINE_TAG_CHOICE(sizeof(MaRouteInfo),MA_TAG_CSCONST17,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRirSsLst2 =   /* SS List    2          */
  DEFINE_TAG_SEQOF(MA_TAG_CSCONST18,LMA_VER2P,MAT_MAX_SS,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRirExtBsc2Choice =   /* Ex. Bsc 2 Choice */
     DEFINE_TAG_CHOICE(sizeof(MaExtBasServCode),MA_TAG_CSCONST19,
                       LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRirAllowedServices = /* Allowed Services */
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM20,2,8,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRirUnavailCause =   /* Unavailability Cause */
  DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM21,LMA_VER2P,MA_TF_VER2P_OPT,maChkUnavailCause,maUnavailCauseEnums);
#if MAP_REL6
PRIVATE MaTknElmtDef MaTknRirRelResSup = 
   DEFINE_TAG_NULL(MA_TAG_CSPRIM22,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MAP_REL6 */
#endif /* MAP_REL5 */

/* ma001.203 : Addition: Additional elmnts */
#ifdef MAP_CH_PLUS
PRIVATE MaTknElmtDef maTeRirOprType =    /* Forwarding Reason */
  DEFINE_TAG_ENUM(MA_TAG_CSPRIM28,LMA_VER2P,MA_TF_VER2P_OPT,maOperateTypeEnums);

PRIVATE MaTknElmtDef maTeRirClgOrRedirDn = /* Calling or Redir DN */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM29,3,MAT_MAX_NLR_NMB_STR_LEN,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRirCalledLrn = /* Called LRN */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM30,3,MAT_MAX_NLR_NMB_STR_LEN,LMA_VER2P,MA_TF_VER2P_OPT);
#endif
#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef maTeRoutInfoRspSeq =   /* Send routing Info Rsp Seq */
     DEFINE_TAG_U_SEQ(MA_TAG_CSCONST3,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3,
                      maChkSeq2);


PRIVATE MaTknElmtDef *maRoutInfoRspTkns[] = /* Route Info response */
{
 &maTeRoutInfoRspSeq,
    &maTeRirImsiChoice,
       &maTeRirVer1And2Imsi,
       &maTeRirVer2PImsi,
    &maTeSeqTerm,
    &maTeRirProtChoice,
       /* For Version 1 & 2 */
       &maTeRirRoutInfoChoice,
          &maTeRirRiRoamNmb,
          &maTeSeqMand,
             &maTeRirRiFdFwdToNmb,
             &maTeRirRiFdFwdToSubAddr,
             &maTeRirRiFdFwdOpt,
#ifdef MAP_PHASE2_EXT_MARK
             &maTeExtMark,
#endif
             &maTeExtCont7,
          &maTeSeqTerm,
       &maTeSeqTerm, 
       /* For Version 2+ */
       DEFINE_EXTROUTINFO_CHOICE(maTeRirExtRIChoice),
    &maTeSeqTerm,
    &maTeRirCugChkInfoSeq,
       &maTeRiCciCugIntLck,
       &maTeRiCugOgAcc,
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
       &maTeExtCont,
    &maTeSeqTerm,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTeRirCugSubsFlg,
    DEFINE_SUBSINFO_SEQ(maTeRirSubsInfoSeq),
    DEFINE_SS_LST(maTeRirSsLst),
    DEFINE_EXT_BSC_CHOICE(maTeRirExtBscChoice),
    &maTeRirFwdInterroReq,
    &maTeRirVmscAddr,
    &maTeExtCont0,
    DEFINE_NAEAPREFCI_SEQ(maTeRirNaeaPrefCiSeq),
    DEFINE_CCBSIND_SEQ(maTeRirCcbsIndSeq),
#if (MAP_REL98 || MAP_REL99)
    &maTeRirMsIsdn,
    &maTeRirNmbPortStatus,
#endif /* MAP_REL98 || MAP_REL99 */
#if MAP_REL99
    &maTeRirIstAlertTimer,
#if MAP_REL5
    &maTeRirSupCamPhase,
    &maTeRirOffCam4CSIs,
    DEFINE_ROUTINFO_CHOICE(maTeRirRI2Choice),
    DEFINE_SS_LST(maTeRirSsLst2),
    DEFINE_EXT_BSC_CHOICE(maTeRirExtBsc2Choice),
    &maTeRirAllowedServices,
    &maTeRirUnavailCause,
#if MAP_REL6
    &MaTknRirRelResSup,
#endif /* MAP_REL6 */
#endif /* MAP_REL5 */
/* ma001.203 : Addition: Additional elmnts */
#ifdef MAP_CH_PLUS
    &maTeRirOprType,
    &maTeRirClgOrRedirDn,
    &maTeRirCalledLrn,
#endif
#endif /* MAP_REL99 */
 &maTeSeqTerm,
 NULLP,
};


PRIVATE MaTknElmtDef maTeRismMsIsdn =   /* Isdn Address String   */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeRismSmRpPri =   /* SM - RP - PRI         */
     DEFINE_TAG_BOOL(MA_TAG_CSPRIM1,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeRismSerCentreAddr =   /* Address String        */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,20,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeRismCugIntLock =   /* Cug Inter Lock        */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM3,4,4,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeRismTeleServCode =   /* Tele Service code      */
     DEFINE_TAG_U8(MA_TAG_CSPRIM5,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeRismGprsSupInd =   /* Gprs Support Indicator*/
     DEFINE_TAG_NULL(MA_TAG_CSPRIM7,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRismSmRpMti =   /* SM - RP - MTI         */
     DEFINE_TAG_INT(MA_TAG_CSPRIM8,0,10,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRismSmRpSmea =   /* SM-RP-SMEA            */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM9,1,12,LMA_VER2P,MA_TF_VER2P_OPT);

/* ma001.203 : Addition: Additional elmnts */
#if MAP_REL99
#ifdef MAP_CH_PLUS
PRIVATE MaTknElmtDef maTeRismCallingLrn =   /* Calling LRN */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM19,3,MAT_MAX_NLR_NMB_STR_LEN,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRismFlagForSpecial =/* Flag for special */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM20,LMA_VER2P,MA_TF_VER2P_OPT);
#endif
#endif

PRIVATE MaTknElmtDef *maRoutInfoSMReqTkns[] = /* Rout Info for SM Request */
{
 &maTeSeqMand,
    &maTeRismMsIsdn,
    &maTeRismSmRpPri,
    &maTeRismSerCentreAddr,
    &maTeRismCugIntLock,
    &maTeRismTeleServCode,
    &maTeExtCont6,
    &maTeRismGprsSupInd,
    &maTeRismSmRpMti,
    &maTeRismSmRpSmea,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
/* ma001.203 : Addition: Additional elmnts */
#if MAP_REL99
#ifdef MAP_CH_PLUS
    &maTeRismCallingLrn,
    &maTeRismFlagForSpecial,
#endif
#endif
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTeRismImsi =   /* IMSI                  */
     DEFINE_STRS(3,8,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeRismLocInfoWithLmsi =   /* Loc. Info With Lmsi*/
     DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeRismProtDiffChoice =   /* Protocol Difference   */
     DEFINE_CHOICE(sizeof(MaRismProtDiff),LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeRismLiwlLocInfoChoice =   /* Location Info */
     DEFINE_CHOICE(sizeof(MaLocationInfo),LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeRismLiwlLiRoamNmb =   /* Roaming Number      r */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeRismLiwlLiMscNmb =   /* Msc Number            */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeRismLiwlNetNodeNmb =   /*Network Node Number*/
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeRismLiwlLmsi =   /* LMSI */
     DEFINE_STRS(4,4,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT7);

PRIVATE MaTknElmtDef maTeRismLiwlGprsNodeInd =   /* Gprs Node Indicator*/
     DEFINE_TAG_NULL(MA_TAG_CSPRIM5,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRismLiwlAddNmbChoice =   /* Additional Number     */
     DEFINE_TAG_CHOICE(sizeof(MaAddNmb),MA_TAG_CSCONST6,LMA_VER2P,
                       MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRismLiwlAnMscNmb =   /* Msc Number            */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeRismLiwlAnSgsnNmb =   /* Sgsn       Number     */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeRismMwdSet =   /* Mwd Set               */
     DEFINE_TAG_BOOL(MA_TAG_CSPRIM2,LMA_VER1,MA_TF_VER1_OPT);

/* ma001.203 : Addition: Additional elmnts */
#if MAP_REL99
#ifdef MAP_CH_PLUS
PRIVATE MaTknElmtDef maTeRismrCallingDn =   /* Calling Dn */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM8,3,MAT_MAX_NLR_NMB_STR_LEN,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRismrSerCentreAddr = /* Address String  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM9,1,20,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRismrCalledLrn =   /* Called LRN */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM10,3,MAT_MAX_NLR_NMB_STR_LEN,LMA_VER2P,MA_TF_VER2P_OPT);
#endif
#endif

PRIVATE MaTknElmtDef *maRoutInfoSMRspTkns[] = /* Rout Info for SM Response */
{
 &maTeSeqMand,
    &maTeRismImsi,
    &maTeRismLocInfoWithLmsi,
       &maTeRismProtDiffChoice,
          &maTeRismLiwlLocInfoChoice,
             &maTeRismLiwlLiRoamNmb,
             &maTeRismLiwlLiMscNmb,
          &maTeSeqTerm,
          &maTeRismLiwlNetNodeNmb,
       &maTeSeqTerm,
       &maTeRismLiwlLmsi,
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
       &maTeExtCont,
       &maTeRismLiwlGprsNodeInd,
       &maTeRismLiwlAddNmbChoice,
          &maTeRismLiwlAnMscNmb,
          &maTeRismLiwlAnSgsnNmb,
       &maTeSeqTerm,
    &maTeSeqTerm,
    &maTeRismMwdSet,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTeExtCont4,
/* ma001.203 : Addition: Additional elmnts */
#if MAP_REL99
#ifdef MAP_CH_PLUS
    &maTeRismrCallingDn,
    &maTeRismrSerCentreAddr,
    &maTeRismrCalledLrn,
#endif
#endif
 &maTeSeqTerm,
 NULLP,
};


PRIVATE MaTknElmtDef maTeSmDelMsIsdn =   /* Ms Isdn               */
     DEFINE_STRS(1,9,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeSmDelSCAddr =   /* Service Centre Addr   */
     DEFINE_STRS(1,20,LMA_VER1AND2AND2P,MA_TF_VER1AND2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeSmDelStat =   /* Report SM Delivery Status */
     DEFINE_ENUM(LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0,maSMDelOutComeEnums);

PRIVATE MaTknElmtDef maTeSmDelAbsSubsDiagSM =   /* Absent Subs.Diag. SM  */
     DEFINE_TAG_INT(MA_TAG_CSPRIM0,0,255,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSmDelGprsSupInd =   /* Gprs Support Indicator*/
     DEFINE_TAG_NULL(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSmDelOutInd =   /* Delivery Outcome Ind  */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSmDelAddSMDelOut =   /* Add. SM Delivery Outcome */
  DEFINE_TAG_ENUM(MA_TAG_CSPRIM4,LMA_VER2P,MA_TF_VER2P_OPT,maSMDelOutComeEnums);

PRIVATE MaTknElmtDef maTeSmDelAddAbsSubsDiagSM =   /* Abs. Subs. Diag. SM   */
     DEFINE_TAG_INT(MA_TAG_CSPRIM5,0,255,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maSMDelReqTkns[] = /* SM Delivery Status Request */
{
 &maTeSeqMand,
    &maTeSmDelMsIsdn,
    &maTeSmDelSCAddr,
    &maTeSmDelStat,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTeSmDelAbsSubsDiagSM,
    &maTeExtCont1,
    &maTeSmDelGprsSupInd,
    &maTeSmDelOutInd,
    &maTeSmDelAddSMDelOut,
    &maTeSmDelAddAbsSubsDiagSM,
 &maTeSeqTerm,
 NULLP,
};


PRIVATE MaTknElmtDef maTeSmDelRspChoice =   /* Sm delivery Rsp Choice*/
     DEFINE_CHOICE(sizeof(MaRepSMDelRsp),LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeSmDelRspMsIsdn =   /* Ms Isdn for ver  2  */
     DEFINE_STRS(1,9,LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTeSmDelRspVer2PSeq =   /* Version 2P sequence   */
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSmDelVer2PMsIsdn =   /* Version 2P Ms Isdn    */
     DEFINE_STRS(1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maSMDelRspTkns[] = /* SM Delivery Status Response */
{
 &maTeSmDelRspChoice,
    &maTeSmDelRspMsIsdn,
    &maTeSmDelRspVer2PSeq,
       &maTeSmDelVer2PMsIsdn,
       &maTeExtCont,
    &maTeSeqTerm,
 &maTeSeqTerm,
 NULLP,
};


PRIVATE MaTknElmtDef maTeAlrtSCAddr =   /* Alrt SC Address       */
     DEFINE_STRS(1,20,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeAlrtSCMsIsdn =   /* Ms Isdn               */
     DEFINE_STRS(1,9,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeAlrtSCSeq =   /* Alrt SC Seq           */
     DEFINE_SEQ(LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef *maAlrtSCReqTkns[] = /* Alert Service Center Req. */
{
 &maTeAlrtSCSeq,
    &maTeAlrtSCMsIsdn,
    &maTeAlrtSCAddr,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTeAlrtSCWRsltSeq =   /* Alrt. SC W Rslt Seq   */
     DEFINE_SEQ(LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeAscwrMsIsdn =   /* Ms Isdn               */
     DEFINE_STRS(1,9,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef maTeAscwrSCAddr =   /* SC Addr               */
     DEFINE_STRS(1,20,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef *maAlrtSCWRsltReqTkns[] = /* Alert Service Center 
                        * without result Req.*/
{
 &maTeAlrtSCWRsltSeq,
    &maTeAscwrMsIsdn,
    &maTeAscwrSCAddr,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
 &maTeSeqTerm,
 NULLP,
};


PRIVATE MaTknElmtDef maTeInfSCMwStatus =   /* Mw Status             */
     DEFINE_BITSTR(6,16,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeInfSCMsIsdn =   /* Ms Isdn               */
     DEFINE_STRS(1,9,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

PRIVATE MaTknElmtDef maTeInfSCSeq =   /* Inf SC Seq           */
     DEFINE_SEQ(LMA_VER2AND2P,MA_TF_VER2AND2P_OPT3);

#if MAP_REL4
PRIVATE MaTknElmtDef maTeInfSCAbsSubsDiagSM =   /* Absent Subs.Diag. SM  */
     DEFINE_INT(0,255,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeInfSCAddAbsSubsDiagSM =   /* Absent Subs.Diag. SM  */
     DEFINE_TAG_INT(MA_TAG_CSPRIM0,0,255,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MAP_REL4 */

PRIVATE MaTknElmtDef *maInfSCReqTkns[] = /* Inform Service Center Request */
{
 &maTeInfSCSeq,
    &maTeInfSCMsIsdn,
    &maTeInfSCMwStatus,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTeExtCont,
#if MAP_REL4
    &maTeInfSCAbsSubsDiagSM,
    &maTeInfSCAddAbsSubsDiagSM,
#endif /* MAP_REL4 */
 &maTeSeqTerm,
 NULLP,
};

#endif  /* MSC || HLR */

/* -------------------------------------------------------------------- */
/* SM Ready Request and Response                                        */
/* -------------------------------------------------------------------- */

#if (MAP_VLR || MAP_HLR || MAP_GSN)

PRIVATE MaTknElmtDef maTeSmRdyAlrtReasonInd =   /* Alert Reason Ind      */
     DEFINE_NULL(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSmRdyAlrtReason =   /* Alert Reason          */
     DEFINE_ENUM(LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0,maAlrtReasonEnums);

PRIVATE MaTknElmtDef maTeSmRdyImsi =   /* Imsi                  */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef maTeSmRdySeq =   /* Sm Rdy Seq            */
     DEFINE_SEQ(LMA_VER2AND2P,MA_TF_VER2AND2P_OPT0);

PRIVATE MaTknElmtDef *maSMRdyReqTkns[] =  /*  SM Ready request tokens */
{
 &maTeSmRdySeq,
    &maTeSmRdyImsi,
    &maTeSmRdyAlrtReason,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTeSmRdyAlrtReasonInd,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maSMRdyRspTkns[] =  /*  SM Ready response tokens */
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

#endif /* VLR || HLR || MAP_GSN */

/* -------------------------------------------------------------------- */
/* Register SS Request and Response &                                   */
/* Erase SS Request and Response &                                      */
/* Activate SS Request and Response &                                   */
/* Deactivate SS Request and Response &                                 */
/* Interrogate SS Request and Response &                                */
/* Process Unstructured SS Data Request and Response &                  */
/* Process Unstructured SS Request and Response &                       */
/* Unstructured SS Request and Response &                               */
/* Unstructured SS Notify Request &                                     */
/* Register Password Request and Response &                             */
/* Get Password Request and Response                                    */
/* -------------------------------------------------------------------- */

#if (MAP_VLR || MAP_HLR)

PRIVATE MaTknElmtDef maTeRssSsCode =   /* SS-Code               */
     DEFINE_U8(LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeRssBasServCodeChoice =   /* Bas.ServCode Choice */
     DEFINE_CHOICE(sizeof(MaBasicServ),LMA_VER1AND2,MA_TF_VER1AND2_OPT3);

PRIVATE MaTknElmtDef maTeRssBscBearCode =   /* Bearer Code           */
     DEFINE_TAG_U8(MA_TAG_CSPRIM2,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeRssBscTeleCode =   /* tele code  */
     DEFINE_TAG_U8(MA_TAG_CSPRIM3,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

/*
** Fwd To Number here is of type AddressString ,so the 
** Size of the string ranges from 1 .. 20.      
*/
PRIVATE MaTknElmtDef maTeRssFwdToNmb =   /* Forward To Number     */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,1,20,LMA_VER1AND2,MA_TF_VER1AND2_OPT3);

PRIVATE MaTknElmtDef maTeRssFwdToSubAddr =   /* Forward To Sub Addr r */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM6,1,21,LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTeRssNoRplyCondTime =   /* Call Reference number */
     DEFINE_TAG_INT(MA_TAG_CSPRIM5,5,30,LMA_VER1AND2,MA_TF_VER1AND2_OPT3);

PRIVATE MaTknElmtDef maTeRssDefPri =   /* Emlpp priority        */
     DEFINE_TAG_INT(MA_TAG_CSPRIM7,0,15,LMA_VER2,MA_TF_VER2_OPT);

#if MAP_REL99
PRIVATE MaTknElmtDef maTeRssNbrUsr  =  /* Nbr User */
     DEFINE_TAG_INT(MA_TAG_CSPRIM8,1,7,LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTeRssLongFtnSup =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM9,LMA_VER2,MA_TF_VER2_OPT);
#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef *maRegSSReqTkns[] = /* Register SS Request */
{
 &maTeSeqMand,
 &maTeRssSsCode,
 &maTeRssBasServCodeChoice,
    &maTeRssBscBearCode,
    &maTeRssBscTeleCode,
 &maTeSeqTerm,
 &maTeRssFwdToNmb,
 &maTeRssFwdToSubAddr,
 &maTeRssNoRplyCondTime,
 &maTeRssDefPri,
#if MAP_REL99
 &maTeRssNbrUsr,
 &maTeRssLongFtnSup,
#endif /* MAP_REL99 */
#ifdef MAP_PHASE2_EXT_MARK
 &maTeExtMark,
#endif
#ifdef XWEXT
 &maXWExtCont,
#endif
 &maTeSeqTerm,
 NULLP,
};


PRIVATE MaTknElmtDef maTeChoiceMand  = 
     DEFINE_CHOICE(sizeof(MaSSInfo),LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef *maRegSSRspTkns[] = /* Register SS Response */
{
 DEFINE_SSINFO(maTeChoiceMand),
 NULLP,
};

PRIVATE MaTknElmtDef *maEraseSSReqTkns[] = /* Erase SS Request */
{
 DEFINE_SSFORBSCODE_SEQ,
 NULLP,
};

PRIVATE MaTknElmtDef *maEraseSSRspTkns[] = /* Erase SS Response */
{
 DEFINE_SSINFO(maTeChoiceMand),
 NULLP,
};

PRIVATE MaTknElmtDef *maActvSSReqTkns[] = /* Activate SS Request */
{
 DEFINE_SSFORBSCODE_SEQ,
 NULLP,
};

PRIVATE MaTknElmtDef *maActvSSRspTkns[] = /* Activate SS Response */
{
 DEFINE_SSINFO(maTeChoiceMand),
 NULLP,
};

PRIVATE MaTknElmtDef *maDactvSSReqTkns[] = /* Deactivate SS Request */
{
 DEFINE_SSFORBSCODE_SEQ,
 NULLP,
};

PRIVATE MaTknElmtDef *maDactvSSRspTkns[] = /* Deactivate SS Response */
{
 DEFINE_SSINFO(maTeChoiceMand),
 NULLP,
};

PRIVATE MaTknElmtDef *maInterSSReqTkns[] = /* Interogate SS Request */
{
 DEFINE_SSFORBSCODE_SEQ,
 NULLP,
};


PRIVATE MaTknElmtDef maTeIssCflSeqOf =   /* Ccbs Ftr List Seq Of  */
  DEFINE_TAG_SEQOF(MA_TAG_CSCONST2,LMA_VER2,MAT_MAX_CCBSREQ,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTeIssChoice =   /* Interr. SS Rsp Choice */
     DEFINE_CHOICE(sizeof(MaInterSSRsp),LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeIssSsStatus =   /* SS Status             */
     DEFINE_TAG_U8(MA_TAG_CSPRIM0,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

/*
** This field MUST not be used in version greater than 1.
*/
PRIVATE MaTknElmtDef maTeIssFwdToNmb =   /* forwarded To Number   */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef maTeIssBasServGrpLst =   /* Bas Serv Grp Lst      */
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST2,LMA_VER1AND2,MAT_MAX_BASIC_SERV,
                      MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeIssBsglBasServCodeChoice =   /* BasServCode */
     DEFINE_CHOICE(sizeof(MaBasicServ),LMA_VER1AND2,MA_TF_VER1AND2_OPT3);

PRIVATE MaTknElmtDef maTeIssBsglBscBearCode =   /* Bear Code             */
     DEFINE_TAG_U8(MA_TAG_CSPRIM2,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeIssBsglBscTeleCode =   /* Tele Code             */
     DEFINE_TAG_U8(MA_TAG_CSPRIM3,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef maTeIssGenSerInfoSeq =   /* Call Reference number */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST4,LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef maTeIssGsiSsStatus =   /* Call Reference number */
     DEFINE_U8(LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef maTeIssGsiCliRestOpt =   /* Cli Restriction Option*/
     DEFINE_ENUM(LMA_VER2,MA_TF_VER2_OPT,maCliRestOptEnums);

PRIVATE MaTknElmtDef maTeIssGsiMaxEntPri =   /* Maxmimum Entitled Pri */
     DEFINE_TAG_INT(MA_TAG_CSPRIM0,0,15,LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTeIssGsiDefPri =   /* Call Reference number */
     DEFINE_TAG_INT(MA_TAG_CSPRIM1,0,15,LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTeIssFwdFeatLst =   /* Forward Feature List  */
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST3,LMA_VER1AND2,MAT_MAX_BASIC_SERV,MA_TF_VER1AND2_OPT0);

#if MAP_REL99

PRIVATE MaTknElmtDef maTeIssGsiNbrSb  =  /* nbr Sb */
     DEFINE_TAG_INT(MA_TAG_CSPRIM3,2,7,LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTeIssGsiNbrUsr  =  /* Nbr User */
     DEFINE_TAG_INT(MA_TAG_CSPRIM4,1,7,LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTeIssGsiNbrSN  =  /* Nbr User */
     DEFINE_TAG_INT(MA_TAG_CSPRIM5,1,7,LMA_VER2,MA_TF_VER2_OPT);

#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef *maInterSSRspTkns[] = /* Interogate SS Response */
{
 &maTeIssChoice,
    &maTeIssSsStatus,
    &maTeIssFwdToNmb,
    &maTeIssBasServGrpLst,
       &maTeIssBsglBasServCodeChoice,
          &maTeIssBsglBscBearCode,
          &maTeIssBsglBscTeleCode,
       &maTeSeqTerm,
    &maTeSeqTerm,
    DEFINE_FWDFEAT_LST(maTeIssFwdFeatLst),
    &maTeIssGenSerInfoSeq,
       &maTeIssGsiSsStatus,
       &maTeIssGsiCliRestOpt,   
       &maTeIssGsiMaxEntPri,
       &maTeIssGsiDefPri,
       DEFINE_CCBSFTR_LST(maTeIssCflSeqOf),
#if MAP_REL99
       &maTeIssGsiNbrSb,
       &maTeIssGsiNbrUsr,
       &maTeIssGsiNbrSN,
#endif /* MAP_REL99 */
#ifdef MAP_PHASE2_EXT_MARK
       &maTeExtMark,
#endif
    &maTeSeqTerm,
 &maTeSeqTerm,
 NULLP,
};


PRIVATE MaTknElmtDef maTePussdUsrDat =   /* Process USSD Usr Data */
     DEFINE_TAG_STRE(MA_TAG_IA5STR,1,200,LMA_VER1,MA_TF_VER1_MAND);

PRIVATE MaTknElmtDef *maProcUSSDatReqTkns[] = /* Process USSD Data Request */
{
 &maTePussdUsrDat,
 NULLP,
};


PRIVATE MaTknElmtDef maTePussdRspUsrDat =   /* Usr Data              */
     DEFINE_TAG_STRE(MA_TAG_IA5STR,1,200,LMA_VER1,MA_TF_VER1_OPT);

PRIVATE MaTknElmtDef *maProcUSSDatRspTkns[] = /* Process USSD Data Request */
{
 &maTePussdRspUsrDat,
 NULLP,
};

PRIVATE MaTknElmtDef maTeUssdSeq =   /* Ussd Seq             */
     DEFINE_SEQ(LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef maTeUssdRspSeq =   /* Ussd response Seq */
     DEFINE_SEQ(LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTeUssdDatCodSch =   /* Ussd Data Coding Sch  */
     DEFINE_U8(LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef maTeUssdString =   /* Ussd String           */
     DEFINE_STRE(1,160,LMA_VER2,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef maTeUssdAlrtPat =   /* alerting Pattern      */
     DEFINE_U8(LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef maTeUssdMsIsdn = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER2,MA_TF_VER2_OPT);

PRIVATE MaTknElmtDef *maProcUSSReqReqTkns[] = /* Process USSD Request Request */
{
 &maTeUssdSeq,
    &maTeUssdDatCodSch,
    &maTeUssdString,
    &maTeUssdAlrtPat,
    &maTeUssdMsIsdn,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maProcUSSReqRspTkns[] =/* Process USSD Request Response */
{
 &maTeUssdSeq,
    &maTeUssdDatCodSch,
    &maTeUssdString,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maUSSReqReqTkns[] =  /*  USSD Request Request */
{
 &maTeUssdSeq,
    &maTeUssdDatCodSch,
    &maTeUssdString,
    &maTeUssdAlrtPat,
    &maTeUssdMsIsdn,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maUSSReqRspTkns[] = /*  USSD Request Response */
{
 &maTeUssdRspSeq,
    &maTeUssdDatCodSch,
    &maTeUssdString,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maUSSNotifyReqTkns[] =  /*  USSD Notify Request */
{
 &maTeUssdSeq,
    &maTeUssdDatCodSch,
    &maTeUssdString,
    &maTeUssdAlrtPat,
    &maTeUssdMsIsdn,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTeRpSsCode    =   /* SS Code               */
     DEFINE_U8(LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef *maRegPasswdReqTkns[] =  /*  Register password Request */
{
 &maTeRpSsCode,
 NULLP,
};

PRIVATE MaTknElmtDef maTePPasswd =   /* Password              */
     DEFINE_TAG_STRS(MA_TAG_NUMSTR,4,4,LMA_VER1AND2,MA_TF_VER1AND2_OPT0);

PRIVATE MaTknElmtDef *maRegPasswdRspTkns[] =/*  Register password Response */
{
 &maTePPasswd,
 NULLP,
};

PRIVATE MaTknElmtDef maTeGpGuidInfo =   /* guidance Info         */
     DEFINE_ENUM(LMA_VER1AND2,MA_TF_VER1AND2_OPT0,maGuidInfoEnums);

PRIVATE MaTknElmtDef *maGetPasswdReqTkns[] =  /*  Get password Request */
{
 &maTeGpGuidInfo,
 NULLP,
};

PRIVATE MaTknElmtDef *maGetPasswdRspTkns[] =  /*  Get password Response */
{
 &maTePPasswd,
 NULLP,
};

#endif /* MAP_VLR || MAP_HLR */


/* -------------------------------------------------------------------- */
/* GPRS Update Location and Response &                                  */
/* Send Routing Information for GPRS Request and Response &             */
/* Failure Report Request and Response &                                */
/* Note MS Present for GPRS Request and Response                        */
/* -------------------------------------------------------------------- */

#if (MAP_HLR || MAP_GSN)

PRIVATE MaTknElmtDef 
 maTeUglImsi    = DEFINE_STRS( 3, 8,LMA_VER2P,MA_TF_VER2P_MAND); /* IMSI */
PRIVATE MaTknElmtDef 
 maTeUglSgsnNmb = DEFINE_STRS( 1, 9,LMA_VER2P,MA_TF_VER2P_MAND); /*Isdn Address String*/

PRIVATE MaTknElmtDef /*Gsn Address */
 maTeUglSgsnAddr= DEFINE_STRS( 5,17,LMA_VER2P,MA_TF_VER2P_MAND); 

#if (MAP_REL98 || MAP_REL99)
PRIVATE MaTknElmtDef  /* SGSN Capability */
 maTeUglSgsnCapSeq = DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef  /* Solsa Support Indicator */
 maTeUglSolsaSuppInd  = DEFINE_NULL(LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MAP_REL98 || MAP_REL99 */

#if MAP_REL99 
/* Super charger supported in Serving Net Entity */
PRIVATE MaTknElmtDef maTeUglsupCharSuppInSerNetEntChoice = 
     DEFINE_TAG_CHOICE(sizeof(MaSupCharSuppInServNetEnt),MA_TAG_CSCONST2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeUglGprsEnhSuppInd  =  /* GPRS Enhancement Supp Ind */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef  maTeUglSuppCamPhases = 
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM4,1,16, LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeUglSndSubsData  =  /* Send Subscriber Data */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeUglSubsDataStored  =  /* Subs. Data Stored */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1, 6,LMA_VER2P,MA_TF_VER2P_OPT); 

PRIVATE MaTknElmtDef maTeUglInfPrevNetEnt =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL4
PRIVATE MaTknElmtDef maTeUglSuppLcsCapSets = 
        DEFINE_TAG_BITSTR(MA_TAG_CSPRIM5,2,16,LMA_VER2P,MA_TF_VER2P_OPT);

 /* Addition - upgrade for MAP release 5 */
#if MAP_REL5
PRIVATE MaTknElmtDef maTeUglPsLcsNotSupbyUE = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM2, LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeScOffCam4CSIs =
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM6,7,16,LMA_VER2P,MA_TF_VER2P_OPT);

/* Addition - upgrade for MAP release 6 */
#if MAP_REL6
PRIVATE MaTknElmtDef maTeUglVgmlcAddr =
    DEFINE_TAG_STRS(MA_TAG_CSPRIM3,5,17,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef maTeUglAddInfoSeq =
     DEFINE_TAG_SEQ(MA_TAG_CSCONST4,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef  maTeUglSmsCbsi =
    DEFINE_TAG_NULL(MA_TAG_CSPRIM7,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeUglAddInfoImeisv =
      DEFINE_TAG_STRS(MA_TAG_CSPRIM0,8,8,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeUglAddInfoSkipSubsDatUp =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);


#endif /* MAP_REL6 */
#endif /* MAP_REL5 */
#endif /* MAP_REL4 */ 

#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef *maGprsUpLocReqTkns[] = /* Update Gprs Location Req.*/
{
 &maTeSeqMandVer2P,
    &maTeUglImsi,
    &maTeUglSgsnNmb,
    &maTeUglSgsnAddr,
    &maTeExtCont,
#if (MAP_REL98 || MAP_REL99)
    &maTeUglSgsnCapSeq,
       &maTeUglSolsaSuppInd,
       &maTeExtCont1,
#if MAP_REL99
       &maTeUglsupCharSuppInSerNetEntChoice,
          &maTeUglSndSubsData,
          &maTeUglSubsDataStored,
       &maTeSeqTerm,
       &maTeUglGprsEnhSuppInd,
       &maTeUglSuppCamPhases,
#if MAP_REL4
       &maTeUglSuppLcsCapSets,
       /* Addition - upgrade for MAP release 5 */
#if MAP_REL5
       &maTeScOffCam4CSIs,
/* Addition - upgrade for MAP release 6 */
#if MAP_REL6
        &maTeUglSmsCbsi,
#endif /* MAP_REL6 */
#endif /* MAP_REL5 */
#endif /* MAP_REL4 */ 
#endif /* MAP_REL99 */
    &maTeSeqTerm,
#endif /* MAP_REL98 || MAP_REL99 */
#if MAP_REL99
 &maTeUglInfPrevNetEnt,
#if MAP_REL5
 &maTeUglPsLcsNotSupbyUE,
/* Addition: upgrade for MAP release 6 */
#if MAP_REL6
 &maTeUglVgmlcAddr,
 &maTeUglAddInfoSeq,
   &maTeUglAddInfoImeisv,
   &maTeUglAddInfoSkipSubsDatUp,
 &maTeSeqTerm,
#endif /* MAP_REL6 */
#endif /* MAP_REL5 */
#endif /* MAP_REL99 */
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef 
 maTeUglHlrNmb  = DEFINE_STRS(1, 9,LMA_VER2P,MA_TF_VER2P_MAND); /*Isdn Addr. Str */

PRIVATE MaTknElmtDef *maGprsUpLocRspTkns[] = /* Update Gprs Location Rsp.*/
{
 &maTeSeqMandVer2P,
 &maTeUglHlrNmb,
 &maTeExtCont,
/* Addition: upgrade for MAP release 6 */
#if MAP_REL6
 &maTeRspAddCap,
#endif /* MAP_REL6 */
 &maTeSeqTerm,
 NULLP,
};

#if MAP_REL99
#if MAP_REL4

PRIVATE MaTknElmtDef maTeGprsRoutInfoSeq =
     DEFINE_SEQ(LMA_VER2PAND4,MA_TF_VER2PAND4_OPT0);

PRIVATE MaTknElmtDef maTeSrifgImsi = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3, 8,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT0); 

PRIVATE MaTknElmtDef maTeSrifgGgsnAddr = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,5,17,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3 ); 

PRIVATE MaTknElmtDef maTeSrifgGgsnNmb = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,9,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT0);

PRIVATE MaTknElmtDef *maGprsRoutInfoReqTkns[] = /* Gprs RI   req*/
{
 &maTeGprsRoutInfoSeq,
 &maTeSrifgImsi,
 &maTeSrifgGgsnAddr,
 &maTeSrifgGgsnNmb,
 &maTeExt4Cont3,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTeSrifgSgsnAddr = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,5,17,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT0); 

PRIVATE MaTknElmtDef maTeSrifgMblNotRchRsn = 
     DEFINE_TAG_INT(MA_TAG_CSPRIM2,0,255,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3); 

PRIVATE MaTknElmtDef *maGprsRoutInfoRspTkns[] = /* send RI for gprs res*/
{
 &maTeGprsRoutInfoSeq,
 &maTeSrifgSgsnAddr,
 &maTeSrifgGgsnAddr,
 &maTeSrifgMblNotRchRsn,
 &maTeExt4Cont3,
 &maTeSeqTerm,
 NULLP,
};

#else  /* MAP_REL4 */

PRIVATE MaTknElmtDef 
maTeSrifgImsi    = DEFINE_TAG_STRS( MA_TAG_CSPRIM0,3, 8,LMA_VER2P,MA_TF_VER2P_MAND); 

PRIVATE MaTknElmtDef 
maTeSrifgGgsnAddr= DEFINE_TAG_STRS( MA_TAG_CSPRIM1,5,17,LMA_VER2P,MA_TF_VER2P_OPT ); 

PRIVATE MaTknElmtDef 
 maTeSrifgGgsnNmb = DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef *maGprsRoutInfoReqTkns[] = /* Gprs RI   req*/
{
 &maTeSeqMandVer2P,
 &maTeSrifgImsi,
 &maTeSrifgGgsnAddr,
 &maTeSrifgGgsnNmb,
 &maTeExtCont3,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef 
maTeSrifgSgsnAddr    = DEFINE_TAG_STRS( MA_TAG_CSPRIM0,5,17,LMA_VER2P,MA_TF_VER2P_MAND); 

PRIVATE MaTknElmtDef 
maTeSrifgMblNotRchRsn=DEFINE_TAG_INT(MA_TAG_CSPRIM2,0,255,LMA_VER2P,MA_TF_VER2P_OPT); 

PRIVATE MaTknElmtDef *maGprsRoutInfoRspTkns[] = /* send RI for gprs res*/
{
 &maTeSeqMandVer2P, 
 &maTeSrifgSgsnAddr,
 &maTeSrifgGgsnAddr,
 &maTeSrifgMblNotRchRsn,
 &maTeExtCont3,
 &maTeSeqTerm,
 NULLP,
};
#endif /* MAP_REL4 */
#else

PRIVATE MaTknElmtDef 
maTeSrifgImsi    = DEFINE_TAG_STRS( MA_TAG_CSPRIM0,3, 8,LMA_VER2P,MA_TF_VER2P_MAND); 
PRIVATE MaTknElmtDef 
maTeSrifgGgsnAddr= DEFINE_TAG_STRS( MA_TAG_CSPRIM1,5,17,LMA_VER2P,MA_TF_VER2P_OPT ); 

PRIVATE MaTknElmtDef 
 maTeSrifgGgsnNmb = DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef *maGprsRoutInfoReqTkns[] = /* Gprs RI   req*/
{
 &maTeSeqMandVer2P,
 &maTeSrifgImsi,
 &maTeSrifgGgsnAddr,
 &maTeSrifgGgsnNmb,
 &maTeExtCont3,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef 
maTeSrifgSgsnAddr    = DEFINE_TAG_STRS( MA_TAG_CSPRIM0,5,17,LMA_VER2P,MA_TF_VER2P_MAND); 

PRIVATE MaTknElmtDef 
maTeSrifgMblNotRchRsn=DEFINE_TAG_INT(MA_TAG_CSPRIM2,0,255,LMA_VER2P,MA_TF_VER2P_OPT); 

PRIVATE MaTknElmtDef *maGprsRoutInfoRspTkns[] = /* send RI for gprs res*/
{
 &maTeSeqMandVer2P, 
 &maTeSrifgSgsnAddr,
 &maTeSrifgGgsnAddr,
 &maTeSrifgMblNotRchRsn,
 &maTeExtCont3,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef 
 maTeFrImsi = DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef 
 maTeFrGgsnNmb = DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER2P,MA_TF_VER2P_MAND);
PRIVATE MaTknElmtDef 
 maTeFrGgsnAddr = DEFINE_TAG_STRS(MA_TAG_CSPRIM2,5,17,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef 
 maTeFrRspGgsnAddr = DEFINE_TAG_STRS(MA_TAG_CSPRIM0,5,17,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maFailRptReqTkns[] = /* failure report req */
{
 &maTeSeqMandVer2P,
 &maTeFrImsi,
 &maTeFrGgsnNmb,
 &maTeFrGgsnAddr,
 &maTeExtCont3,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maFailRptRspTkns[] = /* failure report rsp */
{
 &maTeSeqOptVer2P,
 &maTeFrRspGgsnAddr,
 &maTeExtCont1,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef 
 maTeNmpfgImsi = DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef 
 maTeNmpfgSgsnAddr = DEFINE_TAG_STRS(MA_TAG_CSPRIM1,5,17,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef 
 maTeNmpfgGgsnAddr = DEFINE_TAG_STRS(MA_TAG_CSPRIM2,5,17,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maGprsNoteMsPresReqTkns[] = /*Note MS pr. for gprs req*/
{
 &maTeSeqMandVer2P,
 &maTeNmpfgImsi,
 &maTeNmpfgSgsnAddr,
 &maTeNmpfgGgsnAddr,
 &maTeExtCont3,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maGprsNoteMsPresRspTkns[] = 
{
 &maTeSeqOptVer2P,
    &maTeExtCont0,
 &maTeSeqTerm,
 NULLP,
};

#endif  /* MAP_HLR || MAP_GSN */
 
/* -------------------------------------------------------------------- */
/* Provide Subscriber Information Request and Response                  */
/* -------------------------------------------------------------------- */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
#if (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5))

PRIVATE MaTknElmtDef 
 maTePsiImsi =       DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER2P,MA_TF_VER2P_MAND);
PRIVATE MaTknElmtDef 
 maTePsiLmsi =       DEFINE_TAG_STRS(MA_TAG_CSPRIM1,4,4,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef 
 maTePsiReqInfoSeq = DEFINE_TAG_SEQ(MA_TAG_CSCONST2,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef *maProvSubsInfoReqTkns[] = /* Provide subscriber info */
{
 &maTeSeqMandVer2P,
 &maTePsiImsi,
 &maTePsiLmsi,
 DEFINE_REQINFO_SEQ(maTePsiReqInfoSeq),
 &maTeExtCont3,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maProvSubsInfoRspTkns[] = /* Provide subscriber info */
{
 &maTeSeqMandVer2P,
 DEFINE_SUBSINFO_SEQ(maTeSeqMandVer2P),
 &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

#endif  /* (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5)) */
#endif  /* MAP_VLR || MAP_HLR */

/* -------------------------------------------------------------------- */
/* Any Time Interrogation Request and Response                          */
/* -------------------------------------------------------------------- */

#if (MAP_HLR || MAP_MLC)

PRIVATE MaTknElmtDef 
 maTeAtiSubsIdChoice = DEFINE_TAG_CHOICE(sizeof(MaSubsIdent),MA_TAG_CSCONST0,
                       LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef 
 maTeAtiReqInfoSeq = DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef 
 maTeAtiGsmSCFAddr = DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef *maAnyInterReqTkns[] = /*Any time interrogation req. */
{
 &maTeSeqMandVer2P,
 DEFINE_SUBSID_CHOICE(maTeAtiSubsIdChoice),
 DEFINE_REQINFO_SEQ(maTeAtiReqInfoSeq),
 &maTeAtiGsmSCFAddr,
 &maTeExtCont2,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maAnyInterRspTkns[] = /* Any time interrogation Rsp*/
{
 &maTeSeqMandVer2P,
 DEFINE_SUBSINFO_SEQ(maTeSeqMandVer2P),
 &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_HLR || MAP_MLC */

/* -------------------------------------------------------------------- */
/* Resume Call Handling Request and Response &                          */
/* Provide SIWFS Number Request and Response &                          */
/* SIWFS Signalling Modify Request and Response &                       */
/* Prepare Group Call Request and Response &                            */
/* Process Group Call Signalling Request &                              */
/* Forward Group Call Signalling Request &                              */
/* Send Group Call End Signal Request and Response                      */
/* -------------------------------------------------------------------- */

#if MAP_MSC

#if (MAP_REL98 || MAP_REL99)

PRIVATE MaTknElmtDef maTeResCallHandlReqSeq =
     DEFINE_SEQ(LMA_VER2PAND4,MA_TF_VER2PAND4_OPT2);

PRIVATE MaTknElmtDef maTeRchCallRefNmb = 
      DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,8,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT2);

PRIVATE MaTknElmtDef maTeRchBasicServGrpChoice = 
      DEFINE_TAG_CHOICE(sizeof(MaExtBasServCode),MA_TAG_CSCONST1,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT2);

#if MAP_REL5
PRIVATE MaTknElmtDef maTeRchBasicServGrp2Choice =
      DEFINE_TAG_CHOICE(sizeof(MaExtBasServCode),MA_TAG_CSCONST14,LMA_VER2PAND4,MA_TF_VER2P_OPT);
#endif /* MAP_REL5 */

 MaTknElmtDef maTeRchExtBearServ = 
      DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,5,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT0);

PRIVATE MaTknElmtDef maTeRchExtTeleServ = 
      DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,5,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT0);

PRIVATE MaTknElmtDef maTeRchFwdDataSeq = 
      DEFINE_TAG_SEQ(MA_TAG_CSCONST2,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT2);

PRIVATE MaTknElmtDef maTeRchFwdToNmb = 
      DEFINE_TAG_STRS(MA_TAG_CSPRIM5,1,9,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3);

PRIVATE MaTknElmtDef maTeRchFwdToSubAddr = 
      DEFINE_TAG_STRS(MA_TAG_CSPRIM4,1,21,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3);

PRIVATE MaTknElmtDef maTeRchFwdOpt = 
      DEFINE_TAG_U8(MA_TAG_CSPRIM6,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3);

#if MAP_REL99
PRIVATE MaTknElmtDef maTeRchLongFwdedToNmb = 
      DEFINE_TAG_STRS(MA_TAG_CSPRIM8,1,15,LMA_VER4,MA_TF_VER4_OPT);
#endif

PRIVATE MaTknElmtDef maTeRchImsi = 
      DEFINE_TAG_STRS(MA_TAG_CSPRIM3,3,8,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT2);

PRIVATE MaTknElmtDef maTeRchCugChkInfoSeq = 
      DEFINE_TAG_SEQ(MA_TAG_CSCONST4,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3);

PRIVATE MaTknElmtDef maTeRchCugIntLck = 
      DEFINE_STRS(4,4,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT0);

PRIVATE MaTknElmtDef maTeRchCugOutGngAcc = 
      DEFINE_NULL(LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3);

PRIVATE MaTknElmtDef maTeRchOCsiSeq = 
      DEFINE_TAG_SEQ(MA_TAG_CSCONST5,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3);

PRIVATE MaTknElmtDef maTeRchOBcsmCamTdpDatLst = 
      DEFINE_SEQOF(LMA_VER2PAND4,MAT_MAXNUMOF_CAMTDPDATA,MA_TF_VER2PAND4_OPT3);

PRIVATE MaTknElmtDef maTeRchOBcsmCamTdpDatSeq = 
      DEFINE_U_SEQ(LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3, maChkIgnoreSeq);

PRIVATE MaTknElmtDef maTeRchOBcsmTrigDetPt = 
      DEFINE_U_ENUM(LMA_VER2PAND4,MA_TF_VER2PAND4_OPT0,maChkOBcsmTrigDetPt,maOBcsmTrigDetPtEnums);

PRIVATE MaTknElmtDef maTeRchSerKey = 
      DEFINE_INT(0,2147483647,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT0);

PRIVATE MaTknElmtDef maTeRchGsmSCFAddr = 
      DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT0);

PRIVATE MaTknElmtDef maTeRchDefHndl = 
      DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM1,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT0,maChkDefCallHandl,maDefCallHandlEnums);

PRIVATE MaTknElmtDef maTeRchCamCapHandl = 
      DEFINE_TAG_INT(MA_TAG_CSPRIM0,1,16,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3);

PRIVATE MaTknElmtDef maTeRchCcbsPsbl = 
      DEFINE_TAG_NULL(MA_TAG_CSPRIM8,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3);

PRIVATE MaTknElmtDef maTeRchMsIsdn = 
      DEFINE_TAG_STRS(MA_TAG_CSPRIM9,1,9,LMA_VER4,MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchUuDataSeq = 
      DEFINE_TAG_SEQ(MA_TAG_CSCONST10,LMA_VER4,MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchUuInd = 
      DEFINE_TAG_U8(MA_TAG_CSPRIM0,LMA_VER4,MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchUui = 
     DEFINE_TAG_STRE(MA_TAG_CSPRIM1,1,131,LMA_VER4,MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchUusCFInter =  /* UUS CF interaction */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM2,LMA_VER4,MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchAllInfoSent = /* All Information Sent */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM11,LMA_VER4,MA_TF_VER4_OPT);

#if MAP_REL99

PRIVATE MaTknElmtDef maTeRchNotificationToCse  =  /*Notification To CSE */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER4,MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchCsiActive  =  /*Csi Active */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM2,LMA_VER4,MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchDCsiSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST12,LMA_VER4,MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchdDpAnalyzdInfoCritLst = 
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST0,LMA_VER4,MAT_MAX_NMB_DP_ANALYZEDINFO_CRIT,MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchdDpAnalyzdInfoCritSeq   = 
     DEFINE_SEQ(LMA_VER4,MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchdDialledNmb  =  /* Dialled Number */
     DEFINE_STRS(1,9,LMA_VER4,MA_TF_VER4_MAND);

PRIVATE MaTknElmtDef maTeRchdDefCallHandl  =  /* Default Call Handling */
     DEFINE_U_ENUM(LMA_VER4,MA_TF_VER4_MAND,maChkDefCallHandl,maDefCallHandlEnums);

PRIVATE MaTknElmtDef maTeRchdCamCapHandl  =  /* Camel Capability Handling */
     DEFINE_TAG_INT(MA_TAG_CSPRIM1,1,16,LMA_VER4,MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchdSerKey = 
     DEFINE_INT(0,2147483647,LMA_VER4,MA_TF_VER4_MAND);

PRIVATE MaTknElmtDef maTeRchdCamDatGsmScfAddr =   /* Gsm Scf Address       */
     DEFINE_STRS(1,9,LMA_VER4,MA_TF_VER4_MAND);

PRIVATE MaTknElmtDef maTeRchdNotificationToCse  =  /*Notification To CSE */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM3,LMA_VER4,MA_TF_VER4_OPT );

PRIVATE MaTknElmtDef maTeRchdCsiActive  =  /*Csi Active */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM4,LMA_VER4,MA_TF_VER4_OPT );

#if MAP_REL5
PRIVATE MaTknElmtDef maTeRchdObcsmCamTdpCritLst = 
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST13,LMA_VER4,MAT_MAXNUMOF_CAMTDPDATA,MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchdOctcObcsmCamTdpCritSeq  =
     DEFINE_U_SEQ(LMA_VER4, MA_TF_VER4_OPT, maChkIgnoreSeq);

PRIVATE MaTknElmtDef maTeRchdObctdOBcsmTrigDetPt = 
     DEFINE_U_ENUM(LMA_VER4,MA_TF_VER4_MAND,maChkOBcsmTrigDetPt,maOBcsmTrigDetPtEnums);

PRIVATE MaTknElmtDef maTeRchdObctcDstNmbCritSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER4,MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchdDncMatchType = 
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM0,LMA_VER4,MA_TF_VER4_MAND,maMatchTypeEnums);

PRIVATE MaTknElmtDef maTeRchdDncDstNmbLst = 
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST1,LMA_VER4, MAT_MAX_CAMEL_DEST_NMB, MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchdDnlIsdnAddrStr = 
     DEFINE_STRS(1,9,LMA_VER4,MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchdDncDstNmbLenLst = 
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST2,LMA_VER4, MAT_MAX_CAMEL_DEST_NMB_LEN,MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchdDnllInt = 
     DEFINE_INT(1, MAT_MAX_ISDN_ADDR_DIGITS,LMA_VER4,MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchdObctcBasServCritLst = 
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST1,LMA_VER4, MAT_MAX_BASIC_SER_CRIT,MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchdBsclExtBasSerCodeChoice = 
     DEFINE_CHOICE(sizeof(MaExtBasServCode),LMA_VER4,MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchdEbscExtBearServ = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,5,LMA_VER4,MA_TF_VER4_MAND);

PRIVATE MaTknElmtDef maTeRchdEbscExtTeleServ = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,5,LMA_VER4,MA_TF_VER4_MAND);

PRIVATE MaTknElmtDef maTeRchdObctcCallTypeCrit = 
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM2,LMA_VER4,MA_TF_VER4_OPT,maCallTypeCritEnums);

PRIVATE MaTknElmtDef maTeRchdObctcOCauseValueCritLst  = 
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST3,LMA_VER4,MAT_MAXNMB_CAM_OCAUSEVALCRIT,MA_TF_VER4_OPT);

PRIVATE MaTknElmtDef maTeRchdOcvcCauseValue  =
     DEFINE_U8(LMA_VER4,MA_TF_VER4_OPT);

#endif
#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef *maResCallHandlReqTkns[] = /* resume call handling req*/
{
 &maTeResCallHandlReqSeq,
 &maTeRchCallRefNmb,
 &maTeRchBasicServGrpChoice,
     &maTeRchExtBearServ,
     &maTeRchExtTeleServ,
 &maTeSeqTerm,
 &maTeRchFwdDataSeq,
     &maTeRchFwdToNmb,
     &maTeRchFwdToSubAddr,
     &maTeRchFwdOpt,
/* Extension marker added here is for structure reuse and **
** is not effective for 2P definitions.                   ** 
*/
#ifdef MAP_PHASE2_EXT_MARK
     &maTeExtMark,
#endif
     &maTeExt4Cont7, 
#if MAP_REL99
     &maTeRchLongFwdedToNmb,
#endif /* MAP_REL99 */
 &maTeSeqTerm,
 &maTeRchImsi,
 &maTeRchCugChkInfoSeq,
    &maTeRchCugIntLck, 
    &maTeRchCugOutGngAcc,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTeExt4Cont,
 &maTeSeqTerm,          
 &maTeRchOCsiSeq,
    &maTeRchOBcsmCamTdpDatLst,
        &maTeRchOBcsmCamTdpDatSeq,
            &maTeRchOBcsmTrigDetPt,
            &maTeRchSerKey,
            &maTeRchGsmSCFAddr,
            &maTeRchDefHndl,
            &maTeExt4Cont2,
            DEFINE_OBCSMCAMTDPCRIT_SEQ(maTeObctdOBcsmCamTDPCritSeq),
        &maTeSeqTerm,
    &maTeSeqTerm,
    &maTeExt4Cont,
    &maTeRchCamCapHandl,
#if MAP_REL99
    &maTeRchNotificationToCse,
    &maTeRchCsiActive,
#endif /* MAP_REL99 */
 &maTeSeqTerm,
 &maTeExt4Cont7,
 &maTeRchCcbsPsbl,
 &maTeRchMsIsdn,
 &maTeRchUuDataSeq,
    &maTeRchUuInd,
    &maTeRchUui,
    &maTeRchUusCFInter,
    &maTeExt4Cont3,
 &maTeSeqTerm,
 &maTeRchAllInfoSent,
#if MAP_REL99
 &maTeRchDCsiSeq,
      &maTeRchdDpAnalyzdInfoCritLst,
         &maTeRchdDpAnalyzdInfoCritSeq,
            &maTeRchdDialledNmb,
            &maTeRchdSerKey,
            &maTeRchdCamDatGsmScfAddr,
            &maTeRchdDefCallHandl,
            &maTeExt4Cont,
         &maTeSeqTerm,
       &maTeSeqTerm,
      &maTeRchdCamCapHandl,
      &maTeExt4Cont,
      &maTeRchdNotificationToCse,
      &maTeRchdCsiActive,
 &maTeSeqTerm,
#if MAP_REL5
 &maTeRchdObcsmCamTdpCritLst,
    &maTeRchdOctcObcsmCamTdpCritSeq,
       &maTeRchdObctdOBcsmTrigDetPt,
       &maTeRchdObctcDstNmbCritSeq,
          &maTeRchdDncMatchType,
          &maTeRchdDncDstNmbLst,
             &maTeRchdDnlIsdnAddrStr,
          &maTeSeqTerm,
          &maTeRchdDncDstNmbLenLst,
             &maTeRchdDnllInt,
          &maTeSeqTerm,
       &maTeSeqTerm,
       &maTeRchdObctcBasServCritLst,
          &maTeRchdBsclExtBasSerCodeChoice,
             &maTeRchdEbscExtBearServ,
             &maTeRchdEbscExtTeleServ,
          &maTeSeqTerm,
       &maTeSeqTerm,
       &maTeRchdObctcCallTypeCrit,
       &maTeRchdObctcOCauseValueCritLst,
          &maTeRchdOcvcCauseValue,
       &maTeSeqTerm,
       &maTeExt4Cont4,
    &maTeSeqTerm,
 &maTeSeqTerm, 
 &maTeRchBasicServGrp2Choice,
     &maTeRchExtBearServ,
     &maTeRchExtTeleServ,
 &maTeSeqTerm,
#endif
#endif /* MAP_REL99 */
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTeResCallHandlRspSeq =
     DEFINE_SEQ(LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3);

PRIVATE MaTknElmtDef *maResCallHandlRspTkns[] = 
{
 &maTeResCallHandlRspSeq,
    &maTeExt4Cont0,
 &maTeSeqTerm,
 NULLP,
};


#else /* MAP_REL98 || MAP_REL99 */

PRIVATE MaTknElmtDef 
 maTeRchCallRefNmb       = DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,8,LMA_VER2P,MA_TF_VER2P_MAND);
PRIVATE MaTknElmtDef 
 maTeRchBasicServGrpChoice = DEFINE_TAG_CHOICE(sizeof(MaExtBasServCode),
                            MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_MAND);
PRIVATE MaTknElmtDef 
 maTeRchFwdDataSeq       = DEFINE_TAG_SEQ(MA_TAG_CSCONST2,LMA_VER2P,MA_TF_VER2P_MAND);
PRIVATE MaTknElmtDef 
 maTeRchImsi             = DEFINE_TAG_STRS(MA_TAG_CSPRIM3,3,8,LMA_VER2P,MA_TF_VER2P_MAND);
PRIVATE MaTknElmtDef 
 maTeRchCugChkInfoSeq    = DEFINE_TAG_SEQ(MA_TAG_CSCONST4,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef 
 maTeRchOCsiSeq          = DEFINE_TAG_SEQ(MA_TAG_CSCONST5,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef 
 maTeRchCcbsPsbl         = DEFINE_TAG_NULL(MA_TAG_CSPRIM8,LMA_VER2P,MA_TF_VER2P_OPT);


PRIVATE MaTknElmtDef *maResCallHandlReqTkns[] = /* resume call handling req*/
{
 &maTeSeqMandVer2P,
 &maTeRchCallRefNmb,
 DEFINE_EXT_BSC_CHOICE(maTeRchBasicServGrpChoice),
 DEFINE_FWDDATA_SEQ(maTeRchFwdDataSeq),
 &maTeRchImsi,
 DEFINE_CUGCHKINFO_SEQ(maTeRchCugChkInfoSeq),
 DEFINE_OCSI_SEQ(maTeRchOCsiSeq),
 &maTeExtCont7,
 &maTeRchCcbsPsbl,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maResCallHandlRspTkns[] = 
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};
#endif /* MAP_REL98 || MAP_REL99 */

 PRIVATE MaTknElmtDef maTePsnGsmBearCapSeq = 
         DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_MAND);
 PRIVATE MaTknElmtDef maTePsnIsdnBearCapSeq = 
         DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_MAND);
 PRIVATE MaTknElmtDef maTePsnCallDir = 
         DEFINE_TAG_U8(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_MAND);
 PRIVATE MaTknElmtDef maTePsnBSubsAddr = 
         DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,9,LMA_VER2P,MA_TF_VER2P_MAND);
 PRIVATE MaTknElmtDef maTePsnChosenChnlSeq = 
         DEFINE_TAG_SEQ(MA_TAG_CSCONST4,LMA_VER2P,MA_TF_VER2P_MAND);
 PRIVATE MaTknElmtDef maTePsnLowLyrCmptblSeq = 
         DEFINE_TAG_SEQ(MA_TAG_CSCONST5,LMA_VER2P,MA_TF_VER2P_OPT);
 PRIVATE MaTknElmtDef maTePsnHighLyrCmptblSeq = 
         DEFINE_TAG_SEQ(MA_TAG_CSCONST6,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maProvSiwfsNmbReqTkns[] = /* provide SIWFS number req*/
{
 &maTeSeqMandVer2P, 
 DEFINE_EXTSIGINFO_SEQ(maTePsnGsmBearCapSeq),
 DEFINE_EXTSIGINFO_SEQ(maTePsnIsdnBearCapSeq),
 &maTePsnCallDir,
 &maTePsnBSubsAddr,
 DEFINE_EXTSIGINFO_SEQ(maTePsnChosenChnlSeq),
 DEFINE_EXTSIGINFO_SEQ(maTePsnLowLyrCmptblSeq),
 DEFINE_EXTSIGINFO_SEQ(maTePsnHighLyrCmptblSeq),
 &maTeExtCont7,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef 
 maTePsnSiwfsNmb = DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef *maProvSiwfsNmbRspTkns[] = /* provide SIWFS number res*/
{
 &maTeSeqMandVer2P,
 &maTePsnSiwfsNmb,
 &maTeExtCont1,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef 
 maTeSsmChnlTypeSeq = DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef 
 maTeSSmReqChoChnlSeq = DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef *maSiwfsSigModReqTkns[] = /* SIWFS signalling mod.req*/
{
 &maTeSeqOptVer2P,
 DEFINE_EXTSIGINFO_SEQ(maTeSsmChnlTypeSeq),
 DEFINE_EXTSIGINFO_SEQ(maTeSSmReqChoChnlSeq),
 &maTeExtCont2,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef 
 maTeSsmRspChoChnlSeq = DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef *maSiwfsSigModRspTkns[] = /* SIWFS signalling mod.res*/
{
 &maTeSeqOptVer2P,
 DEFINE_EXTSIGINFO_SEQ(maTeSsmRspChoChnlSeq),
 &maTeExtCont1,
 &maTeSeqTerm,
 NULLP,
};

/* (319,319,2+) */

PRIVATE MaTknElmtDef 
 maTePgcTelSer = DEFINE_STRS(1,5,LMA_VER2P,MA_TF_VER2P_MAND);
PRIVATE MaTknElmtDef 
 maTePgcAscCallRef = DEFINE_STRS(1,8,LMA_VER2P,MA_TF_VER2P_MAND);
PRIVATE MaTknElmtDef 
 maTePgcCodecInfo = DEFINE_STRS(5,10,LMA_VER2P,MA_TF_VER2P_MAND);
PRIVATE MaTknElmtDef 
 maTePgcCipherAlgo = DEFINE_U8(LMA_VER2P,MA_TF_VER2P_MAND);
PRIVATE MaTknElmtDef 
 maTePgcGrpKeyNmb = DEFINE_TAG_INT(MA_TAG_CSPRIM0,0,15,LMA_VER2P,
                                   MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef 
 maTePgcGrpKey = DEFINE_TAG_STRS(MA_TAG_CSPRIM1,8,8,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef 
 maTePgcPri = DEFINE_TAG_INT(MA_TAG_CSPRIM2,0,15,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef 
 maTePgcUpLnkFree = DEFINE_TAG_NULL(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef 
 maTePgcGrpCallNmb = DEFINE_STRS(1,9,LMA_VER2P,MA_TF_VER2P_MAND);
#if MAP_REL99
#if MAP_REL6
PRIVATE MaTknElmtDef 
 maTePgcVstk =  DEFINE_TAG_STRS(MA_TAG_CSPRIM5,16,16,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef
 maTePgcVstkRand  =  DEFINE_TAG_STRS(MA_TAG_CSPRIM6,5,5,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MAP_REL6 */
#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef *maPrepGrpCallReqTkns[] = /* prep. group call     req*/
{
 &maTeSeqMandVer2P,
 &maTePgcTelSer,
 &maTePgcAscCallRef,
 &maTePgcCodecInfo,
 &maTePgcCipherAlgo,
 &maTePgcGrpKeyNmb,
 &maTePgcGrpKey,
 &maTePgcPri,
 &maTePgcUpLnkFree,
 &maTeExtCont4,
#if MAP_REL99
#if MAP_REL6
 &maTePgcVstk,
 &maTePgcVstkRand,
#endif /* MAP_REL6 */
#endif /* MAP_REL99 */
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maPrepGrpCallRspTkns[] = /* prep. group call     res*/
{
 &maTeSeqMandVer2P,
 &maTePgcGrpCallNmb,
 &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

/* (319,-,2+) */
PRIVATE MaTknElmtDef 
 maTePgcsUpLnkReq = DEFINE_TAG_NULL(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef 
 maTePgcsUpLnkRelInd = DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef 
 maTePgcsRelGrpCall = DEFINE_TAG_NULL(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maProGrpCallSigReqTkns[] = /* proc. group call sig.req*/
{
 &maTeSeqMandVer2P,
 &maTePgcsUpLnkReq,
 &maTePgcsUpLnkRelInd,
 &maTePgcsRelGrpCall,
 &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};


/* (319,-,2+) */
 PRIVATE  MaTknElmtDef maTeFgcsImsi = 
          DEFINE_STRS(3,8,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE  MaTknElmtDef maTeFgcsUpLnkReqAck = 
          DEFINE_TAG_NULL(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE  MaTknElmtDef maTeFgcsUpLnkRelInd = 
          DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE MaTknElmtDef maTeFgcsUpLnkRejCmd = 
         DEFINE_TAG_NULL(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE MaTknElmtDef maTeFgcsUpLnkSeizeCmd = 
         DEFINE_TAG_NULL(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE MaTknElmtDef maTeFgcsUpLnkRelCmd = 
         DEFINE_TAG_NULL(MA_TAG_CSPRIM4,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL99
 PRIVATE MaTknElmtDef maTeFgcsStateAttri = 
        DEFINE_TAG_SEQ(MA_TAG_CSCONST5,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE  MaTknElmtDef maTeFgcsDnLnkAtta = 
          DEFINE_TAG_NULL(MA_TAG_CSPRIM5,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE  MaTknElmtDef maTeFgcsUpLnkAtta = 
          DEFINE_TAG_NULL(MA_TAG_CSPRIM6,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE  MaTknElmtDef maTeFgcsDualCommu = 
          DEFINE_TAG_NULL(MA_TAG_CSPRIM7,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE  MaTknElmtDef maTeFgcsCallOrig = 
          DEFINE_TAG_NULL(MA_TAG_CSPRIM8,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef *maFwdGrpCallSigReqTkns[] = /* Fwd. group call sig. req*/
{
 &maTeSeqMandVer2P,
    &maTeFgcsImsi,
    &maTeFgcsUpLnkReqAck,
    &maTeFgcsUpLnkRelInd,
    &maTeFgcsUpLnkRejCmd,
    &maTeFgcsUpLnkSeizeCmd,
    &maTeFgcsUpLnkRelCmd,
    &maTeExtCont,
#if MAP_REL99
    &maTeFgcsStateAttri,
       &maTeFgcsDnLnkAtta,
       &maTeFgcsUpLnkAtta,
       &maTeFgcsDualCommu,
       &maTeFgcsCallOrig,
    &maTeSeqTerm,
#endif /* MAP_REL99 */
 &maTeSeqTerm,
 NULLP,
};

/*
** No Process Group call signalling response exists 
*/

/* (319, 319 , 2+)*/
 PRIVATE MaTknElmtDef maTeSeqGcesImsi = 
         DEFINE_STRS(3,8,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef *maSndGrpCallEndSigReqTkns[] = /* send Gr. call end sigreq*/
{
 &maTeSeqMandVer2P,
 &maTeSeqGcesImsi,
 &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maSndGrpCallEndSigRspTkns[] = 
{
 &maTeSeqOptVer2P,
 &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

#endif  /* MSC */

/* -------------------------------------------------------------------- */
/* Set Reporting State Request and Response &                           */
/* Status Report Request and Response &                                 */
/* Remote User Free Request and Response                                */
/* -------------------------------------------------------------------- */

#if (MAP_VLR || MAP_HLR)

PRIVATE MaTknElmtDef 
 maTeSrsImsi = DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef 
 maTeSrsLmsi = DEFINE_TAG_STRS(MA_TAG_CSPRIM1,4,4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef 
 maTeSrsCcbsMon = DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT,\
                  maChkRptState,maRptStateEnums);

PRIVATE MaTknElmtDef 
 maTeSrsCcbsSubsSta = DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT,maChkCcbsSubsStatus,maCcbsSubsStatusEnums);

PRIVATE MaTknElmtDef *maSetRptStateReqTkns[] = /* set reporting state  req*/
{
 &maTeSeqOptVer2P,
 &maTeSrsImsi,  
 &maTeSrsLmsi,
 &maTeSrsCcbsMon,
 &maTeExtCont3,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maSetRptStateRspTkns[] = /* set reporting state  res*/
{
 &maTeSeqOptVer2P,
 &maTeSrsCcbsSubsSta,
 &maTeExtCont1,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef 
 maTeSrImsi = DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER2P,MA_TF_VER2P_MAND);
PRIVATE MaTknElmtDef 
 maTeSrEvtRptDatSeq = DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef 
 maTeSrCallRptDatSeq = DEFINE_TAG_SEQ(MA_TAG_CSCONST2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maStaRptReqTkns[] = /* status report        req*/
{
 &maTeSeqMandVer2P,
 &maTeSrImsi,
 DEFINE_EVTRPTDAT_SEQ(maTeSrEvtRptDatSeq),
 DEFINE_CALLRPTDAT_SEQ(maTeSrCallRptDatSeq),
 &maTeExtCont3,
 &maTeSeqTerm,
 NULLP,
};


PRIVATE MaTknElmtDef *maStaRptRspTkns[] = 
{
 &maTeSeqOptVer2P,
    &maTeExtCont0,
 &maTeSeqTerm,
 NULLP,
};


PRIVATE MaTknElmtDef 
 maTeRufImsi = DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER2P,MA_TF_VER2P_MAND);
PRIVATE MaTknElmtDef 
 maTeRufCallInfoSeq = DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_MAND);
PRIVATE MaTknElmtDef 
 maTeRufCcbsFtrSeq = DEFINE_TAG_SEQ(MA_TAG_CSCONST2,LMA_VER2P,MA_TF_VER2P_MAND);
PRIVATE MaTknElmtDef 
 maTeRufTransBNmb = DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,9,LMA_VER2P,MA_TF_VER2P_MAND);
PRIVATE MaTknElmtDef 
 maTeRufRplBNmb = DEFINE_TAG_NULL(MA_TAG_CSPRIM4,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef 
 maTeRufAlrtPat = DEFINE_TAG_U8(MA_TAG_CSPRIM5,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maRmtUsrFreeReqTkns[] = /* remote user free     req*/
{
 &maTeSeqMandVer2P,
 &maTeRufImsi,
 DEFINE_EXTSIGINFO_SEQ(maTeRufCallInfoSeq),
 DEFINE_CCBSFTR_SEQ(maTeRufCcbsFtrSeq),
 &maTeRufTransBNmb,
 &maTeRufRplBNmb,
 &maTeRufAlrtPat,
 &maTeExtCont6,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef 
 maTeRufOutCome = DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_MAND,\
                  maChkRufOutcome,maRufOutcomeEnums);

PRIVATE MaTknElmtDef *maRmtUsrFreeRspTkns[] = /* remote user free     res*/
{
 &maTeSeqMandVer2P,
 &maTeRufOutCome,
 &maTeExtCont1,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_VLR || MAP_HLR */

/* -------------------------------------------------------------------- */
/* Register CC Entry Request and Response &                              */
/* Erase CC Entry Request and Response                                  */
/* -------------------------------------------------------------------- */

#if (MAP_VLR || MAP_HLR)

PRIVATE MaTknElmtDef 
 maTeRcceSsCode = DEFINE_TAG_U8(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_MAND);
PRIVATE MaTknElmtDef 
 maTeRcceCcbsDataSeq = DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef *maRegCcEntReqTkns[] = /* Register CC Entry    req*/
{
 &maTeSeqMandVer2P,
 &maTeRcceSsCode,
 DEFINE_CCBSDAT_SEQ(maTeRcceCcbsDataSeq),
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef 
 maTeRcceCcbsFtrSeq = DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef *maRegCcEntRspTkns[] = /* Register CC Entry    res*/
{
 &maTeSeqOptVer2P,
 DEFINE_CCBSFTR_SEQ(maTeRcceCcbsFtrSeq),
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef 
 maTeEcceSsCode = DEFINE_TAG_U8(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef 
 maTeEcceCcbsIndex = DEFINE_TAG_INT(MA_TAG_CSPRIM1,1,MAT_MAX_CCBSREQ,LMA_VER2P,
                     MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maEraseCcEntReqTkns[] = /* Erase CC Entry    req*/
{
 &maTeSeqMandVer2P,
 &maTeEcceSsCode,
 &maTeEcceCcbsIndex,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef 
 maTeEcceSsStatus = DEFINE_TAG_U8(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maEraseCcEntRspTkns[] = /* Erase CC Entry    res*/
{
 &maTeSeqMandVer2P,
 &maTeEcceSsCode,
 &maTeEcceSsStatus,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_VLR || MAP_HLR */

/* -------------------------------------------------------------------- */
/* SS Invocation Nodify Request and Response                            */
/* -------------------------------------------------------------------- */

#if (MAP_MSC || MAP_HLR)

PRIVATE MaTknElmtDef 
 maTeSsinImsi = DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER2P,MA_TF_VER2P_MAND);
PRIVATE MaTknElmtDef 
 maTeSsinMsIsdn = DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER2P,MA_TF_VER2P_MAND);
PRIVATE MaTknElmtDef 
 maTeSsinSsEvnt = DEFINE_TAG_U8(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_MAND);
PRIVATE MaTknElmtDef 
 maTeSsinSsEvtSpecSeqOf = DEFINE_TAG_SEQOF(MA_TAG_CSCONST3,LMA_VER2P,\
                          MAT_MAX_EVT_SPEC,MA_TF_VER2P_OPT);

#if MAP_REL99
PRIVATE MaTknElmtDef maTeSsinBSubsNmb = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM5,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSsinCcbsReqState = 
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM6,LMA_VER2P,MA_TF_VER2P_OPT,maCcbsReqStateEnums);
#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef *maSsInvNotifyReqTkns[] = /* SS Invocation Notify req*/
{
 &maTeSeqMandVer2P,
    &maTeSsinImsi,
    &maTeSsinMsIsdn,
    &maTeSsinSsEvnt,
    DEFINE_EVTSPEC_SEQ(maTeSsinSsEvtSpecSeqOf),
    &maTeExtCont4,
#if MAP_REL99
    &maTeSsinBSubsNmb,
    &maTeSsinCcbsReqState,
#endif /* MAP_REL99 */
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maSsInvNotifyRspTkns[] = 
{
 &maTeSeqOptVer2P,
 &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

#endif  /* MSC || HLR */

#if (MAP_REL98 || MAP_REL99)

/* --------------- Location Service Management ------------------ */

#if (MAP_HLR || MAP_MLC)
/* -------------------------------------------------------------------- */
/* Send Routing Information for LCS Request and Response                */
/* -------------------------------------------------------------------- */

PRIVATE MaTknElmtDef maTeRiflMlcNmb =    /* MLC number */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeRiflSubsIdChoice =   /* Subscriber Id Choice  */
     DEFINE_TAG_CHOICE(sizeof(MaSubsIdent),MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_MAND);


/* Routing Information for LCS */
PRIVATE MaTknElmtDef *maRoutInfoForLcsReqTkns[] = 
{
 &maTeSeqMandVer2P,
    &maTeRiflMlcNmb,
    DEFINE_SUBSID_CHOICE(maTeRiflSubsIdChoice),
    &maTeExtCont2,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTeRifSubsIdChoice =   /* Subscriber Id Choice  */
     DEFINE_TAG_CHOICE(sizeof(MaSubsIdent),MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeRifLcsLocInfoSeq =     /* LCS location information */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeRifMlcNmb =    /* MLC number */
     DEFINE_STRS(1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeRifLmsi = /* LMSI optional */
        DEFINE_TAG_STRS(MA_TAG_CSPRIM0,4,4,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL99
#if MAP_REL4
PRIVATE MaTknElmtDef maTeRifLliGprsNodeInd = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRifLliAddNmbChoice = 
     DEFINE_TAG_CHOICE(sizeof(MaAddNmb),MA_TAG_CSCONST3,LMA_VER2P,
                       MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRifLliAnMscNmb =   /* Msc Number            */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeRifLliAnSgsnNmb =   /* Sgsn       Number     */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

/* Addition: upgrade for MAP release  6 */
#if MAP_REL6

PRIVATE MaTknElmtDef maTeRifLcsVgmlcAddr =  /* v-gmlc Address */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM3,5,17,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRifLcsHgmlcAddr = /* h-gmlc Address */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,5,17,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRifLcsPprAddr = /* ppr Address */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM5,5,17,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef  maTeRifLcsAdlVgmlcAddr = /* Additional v-gmlc addr
 ess */
      DEFINE_TAG_STRS(MA_TAG_CSPRIM6,5,17,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRifSuppLcsCapSets = /* Supported LCS Capability Sets */
      DEFINE_TAG_STRS(MA_TAG_CSPRIM4,2,16,LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeRifAddLcsCapSets = /* Additional LCS Capability Sets */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM5,2,16,LMA_VER2P,MA_TF_VER2P_OPT);

#endif /* MAP_REL6 */
#endif /*  MAP_REL4 */
#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef *maRoutInfoForLcsRspTkns[] = 
{
 &maTeSeqMandVer2P,
    DEFINE_SUBSID_CHOICE(maTeRifSubsIdChoice),
    &maTeRifLcsLocInfoSeq,
       &maTeRifMlcNmb,
       &maTeRifLmsi,
       &maTeExtCont1,
#if MAP_REL99
#if MAP_REL4
       &maTeRifLliGprsNodeInd,
       &maTeRifLliAddNmbChoice,
          &maTeRifLliAnMscNmb,
          &maTeRifLliAnSgsnNmb,
       &maTeSeqTerm,
#if MAP_REL6
       &maTeRifSuppLcsCapSets,
       &maTeRifAddLcsCapSets,
#endif /* MAP_REL6 */
#endif /* MAP_REL4 */
#endif /* MAP_REL99 */
    &maTeSeqTerm,
    &maTeExtCont2,
/* Addition:  upgrade for MAP release 6 */
#if MAP_REL99
#if MAP_REL6
    &maTeRifLcsVgmlcAddr,
    &maTeRifLcsHgmlcAddr,
    &maTeRifLcsPprAddr,
    &maTeRifLcsAdlVgmlcAddr,
#endif /* MAP_REL6 */
#endif /* MAP_REL99 */
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_HLR || MAP_MLC */

#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL99 && MAP_REL4 && MAP_GSN))

/* -------------------------------------------------------------------- */
/* Provide Subscriber Loction Request and Response                      */
/* -------------------------------------------------------------------- */

PRIVATE MaTknElmtDef maTePrvSubsLocReq = 
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTePslLocTypeSeq =  /* Location type */
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_MAND);

#if MAP_REL99
PRIVATE MaTknElmtDef maTePslLocEstiType =  /* Location Estimate type */
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_MAND,
                       maChkLocEstiType,maLocEstiTypeEnums);

#if MAP_REL4
PRIVATE MaTknElmtDef maTePslDefLocEventType =
     DEFINE_TAG_U_BITSTR(MA_TAG_CSPRIM1,1,16,LMA_VER2P,MA_TF_VER2P_OPT,
                         maChkPslDefLocEventType);

#endif
#else
PRIVATE MaTknElmtDef maTePslLocEstiType =  /* Location Estimate type */
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_MAND,
                       NULLP,maLocEstiTypeEnums);
#endif

PRIVATE MaTknElmtDef maTePslMlcNmb =    /* MLC number */
     DEFINE_STRS(1,9,LMA_VER2P,MA_TF_VER2P_MAND);

/* LCS client ID SEQ */
/* --------------------------------------- */
#if MAP_REL99
PRIVATE MaTknElmtDef maTePslLcsClientType =  /* LCS client type */
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_MAND,
                   maChkLcsClientType,maLcsClientTypeEnums);
#else
PRIVATE MaTknElmtDef maTePslLcsClientType =  /* LCS client type */
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_MAND,
                       NULLP,maLcsClientTypeEnums);
#endif

PRIVATE MaTknElmtDef maTePslLcsClientExtIDSeq =   /* LCS client ext. ID */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_OPT);

/* the externalAddress type is changed from AddressString 
 * to ISDN-AddressString */
#if MAP_REL5
PRIVATE MaTknElmtDef maTePslExtAddr = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER2P,MA_TF_VER2P_OPT);
#else
PRIVATE MaTknElmtDef maTePslExtAddr = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,20,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

PRIVATE MaTknElmtDef maTePslLcsClientDiaByMs = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,20,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePslLcsClientIntID =   /* LCS client int.. ID */
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_OPT,maLcsClientIntIdEnums);

PRIVATE MaTknElmtDef maTePslLcsClientNameSeq =   /* LCS client name */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePslUssdDatCodSch =   /* Ussd Data Coding Sch  */
     DEFINE_TAG_U8(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTePslUssdString =   /* Ussd String           */
     DEFINE_TAG_STRE(MA_TAG_CSPRIM2,1,63,LMA_VER2P,MA_TF_VER2P_MAND);

#if MAP_REL99
#if MAP_REL4
PRIVATE MaTknElmtDef maTeLciLcsApn =
     DEFINE_TAG_STRE(MA_TAG_CSPRIM5,2,63,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL5
PRIVATE MaTknElmtDef maTeLciLcsReqIdSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST6,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeLciDatCodSch = 
     DEFINE_TAG_U8(MA_TAG_CSPRIM0, LMA_VER2P,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef maTeLciReqIdStr =
     DEFINE_TAG_STRE(MA_TAG_CSPRIM1, 1,63,LMA_VER2P,MA_TF_VER2P_MAND);
/* Addition: upgrade for MAP release 6 */
#if MAP_REL6
PRIVATE MaTknElmtDef maTeLcsFormatInd =
     DEFINE_ENUM(LMA_VER2P,MA_TF_VER2P_OPT,maLcsFormatIndEnums);

#define DEFINE_LCSCLIENTID_SEQ(seqHeader)    \
&seqHeader,                                  \
   &maTePslLcsClientType,                    \
   &maTePslLcsClientExtIDSeq,                \
       &maTePslExtAddr,                      \
       &maTeExtCont1,                        \
   &maTeSeqTerm,                             \
   &maTePslLcsClientDiaByMs,                 \
   &maTePslLcsClientIntID,                   \
   &maTePslLcsClientNameSeq,                 \
      &maTePslUssdDatCodSch,                 \
      &maTePslUssdString,                    \
      &maTeLcsFormatInd,                     \
   &maTeSeqTerm,                             \
   &maTeLciLcsApn,                           \
   &maTeLciLcsReqIdSeq,                      \
       &maTeLciDatCodSch,                    \
       &maTeLciReqIdStr,                     \
       &maTeLcsFormatInd,                    \
   &maTeSeqTerm,                             \
&maTeSeqTerm

#else /* MAP_REL6 */

#define DEFINE_LCSCLIENTID_SEQ(seqHeader)    \
&seqHeader,                                  \
   &maTePslLcsClientType,                    \
   &maTePslLcsClientExtIDSeq,                \
       &maTePslExtAddr,                      \
       &maTeExtCont1,                        \
   &maTeSeqTerm,                             \
   &maTePslLcsClientDiaByMs,                 \
   &maTePslLcsClientIntID,                   \
   &maTePslLcsClientNameSeq,                 \
       &maTePslUssdDatCodSch,                \
       &maTePslUssdString,                   \
   &maTeSeqTerm,                             \
   &maTeLciLcsApn,                           \
   &maTeLciLcsReqIdSeq,                      \
      &maTeLciDatCodSch,                     \
      &maTeLciReqIdStr,                      \
   &maTeSeqTerm,                             \
&maTeSeqTerm
#endif /* MAP_REL6 */
#else /* MAP_REL5 */
#define DEFINE_LCSCLIENTID_SEQ(seqHeader)    \
&seqHeader,                                  \
   &maTePslLcsClientType,                    \
   &maTePslLcsClientExtIDSeq,                \
       &maTePslExtAddr,                      \
       &maTeExtCont1,                        \
   &maTeSeqTerm,                             \
   &maTePslLcsClientDiaByMs,                 \
   &maTePslLcsClientIntID,                   \
   &maTePslLcsClientNameSeq,                 \
       &maTePslUssdDatCodSch,                \
       &maTePslUssdString,                   \
   &maTeSeqTerm,                             \
   &maTeLciLcsApn,                           \
&maTeSeqTerm
#endif /* MAP_REL5 */
#else /* MAP_REL4 */

#define DEFINE_LCSCLIENTID_SEQ(seqHeader)    \
&seqHeader,                                  \
   &maTePslLcsClientType,                    \
   &maTePslLcsClientExtIDSeq,                \
       &maTePslExtAddr,                      \
       &maTeExtCont1,                        \
   &maTeSeqTerm,                             \
   &maTePslLcsClientDiaByMs,                 \
   &maTePslLcsClientIntID,                   \
   &maTePslLcsClientNameSeq,                 \
       &maTePslUssdDatCodSch,                \
       &maTePslUssdString,                   \
   &maTeSeqTerm,                             \
&maTeSeqTerm
#endif /* MAP_REL4 */

#else  /* MAP_REL99 */

#define DEFINE_LCSCLIENTID_SEQ(seqHeader)    \
&seqHeader,                                  \
   &maTePslLcsClientType,                    \
   &maTePslLcsClientExtIDSeq,                \
       &maTePslExtAddr,                      \
       &maTeExtCont1,                        \
   &maTeSeqTerm,                             \
   &maTePslLcsClientDiaByMs,                 \
   &maTePslLcsClientIntID,                   \
   &maTePslLcsClientNameSeq,                 \
       &maTePslUssdDatCodSch,                \
       &maTePslUssdString,                   \
   &maTeSeqTerm,                             \
&maTeSeqTerm

#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef maTePslLcsClientIDSeq =   /* LCS client ID */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePslPrivacyOverride =  /* privacy override */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePslImsi = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,3,8,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePslMsIsdn = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePslLmsi = /* LMSI optional */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,4,4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePslImei = /* IMEI (Optional) */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM5,8,8,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePslLcsPriority =   /* LCS priority */
     DEFINE_TAG_U8(MA_TAG_CSPRIM6,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePslLcsQosSeq =     /* LCS Qos */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST7,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePslHoriAccuracy =  /* Horizontal accuracy */
     DEFINE_TAG_U8(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePslVertCoordReq =  /* Vertical Coordinate Req */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePslVertAccuracy =  /* Vertical accuracy */
     DEFINE_TAG_U8(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePslRspTimeSeq =     /* Response time */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePslRspTimeCat =     /* Response time category */
     DEFINE_U_ENUM(LMA_VER2P,MA_TF_VER2P_MAND,maChkRspTimeCat,maResponseTimeEnums);

#if MAP_REL99
PRIVATE MaTknElmtDef maTePslSupGADShape = 
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM9,7,16,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL4
PRIVATE MaTknElmtDef maTePslLcsRefNmb =
     DEFINE_TAG_U8(MA_TAG_CSPRIM10,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL5
PRIVATE MaTknElmtDef maTePslLcsServTypeId = 
     DEFINE_TAG_INT(MA_TAG_CSPRIM11, 0, 127,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTePslLcsCodeWordSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST12,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeLcwUssdDatCodSch = 
     DEFINE_TAG_U8(MA_TAG_CSPRIM0, LMA_VER2P,MA_TF_VER2_MAND);

PRIVATE MaTknElmtDef maTeLcwLcsCodeWordStr =
     DEFINE_TAG_STRE(MA_TAG_CSPRIM1, 1,20,LMA_VER2P,MA_TF_VER2P_MAND);
/* Addition: upgrade for MAP release 6 */
#if MAP_REL6 
PRIVATE MaTknElmtDef  maTeLcsPrivChkSeq =
     DEFINE_TAG_SEQ(MA_TAG_CSCONST13,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE MaTknElmtDef  maTeCallSessUnRel =
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_MAND,
                       maChkPrivacyRelAction, maPrivacyChkRelActionEnums);
PRIVATE MaTknElmtDef  maTeCallSessRel =
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT,
                      maChkPrivacyRelAction, maPrivacyChkRelActionEnums);

PRIVATE MaTknElmtDef maTePslLcsHgmlcAddr = /* h-gmlc Address */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM15,5,17,LMA_VER2P,MA_TF_VER2P_OPT);
    
PRIVATE MaTknElmtDef maTeAreaEvntInfoSeq =
    DEFINE_TAG_SEQ(MA_TAG_CSCONST14,LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE MaTknElmtDef maTeAreaDefSeq =
       DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER2P, MA_TF_VER2P_MAND);

PRIVATE  MaTknElmtDef maTeAreaList =
    DEFINE_TAG_SEQOF(MA_TAG_CSCONST0,LMA_VER2P,MAT_MAX_NMB_AREAS,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeAreaType =
      DEFINE_TAG_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_MAND,maAreaTypeEnums);

PRIVATE MaTknElmtDef maAreaIdf =
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,2,7,LMA_VER2P,MA_TF_VER2P_MAND);

 PRIVATE  MaTknElmtDef maTeAreaSeq =
    DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

 PRIVATE MaTknElmtDef maTeOccurInfo =
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2_OPT,maOccurInfoEnums);

 PRIVATE MaTknElmtDef maTeIntTime =
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,32767,LMA_VER2P,MA_TF_VER2P_OPT);


#define DEFINE_AREA_EVNT_INFO_SEQ(seqHeader)\
&seqHeader, \
   &maTeAreaDefSeq, \
     &maTeAreaList, \
       &maTeAreaSeq, \
          &maTeAreaType, \
          &maAreaIdf, \
       &maTeSeqTerm, \
     &maTeSeqTerm, \
    &maTeSeqTerm, \
 &maTeOccurInfo, \
&maTeIntTime,\
&maTeSeqTerm

#endif /* MAP_REL6 */
#endif /* MAP_REL5 */
#endif /* MAP_REL4 */
#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef *maPrvSubsLocReqTkns[] =  
{
 &maTePrvSubsLocReq,
    &maTePslLocTypeSeq,
       &maTePslLocEstiType,
#if MAP_REL99
#if MAP_REL4
       &maTePslDefLocEventType,
#endif
#endif
    &maTeSeqTerm,
    &maTePslMlcNmb,
    DEFINE_LCSCLIENTID_SEQ(maTePslLcsClientIDSeq),
    &maTePslPrivacyOverride,
    &maTePslImsi,
    &maTePslMsIsdn,
    &maTePslLmsi,
    &maTePslImei,
    &maTePslLcsPriority,
    &maTePslLcsQosSeq,
       &maTePslHoriAccuracy,
       &maTePslVertCoordReq,
       &maTePslVertAccuracy,
       &maTePslRspTimeSeq,
          &maTePslRspTimeCat,
       &maTeSeqTerm,
       &maTeExtCont4,
    &maTeSeqTerm,
    &maTeExtCont8,
#if MAP_REL99
    &maTePslSupGADShape,
#if MAP_REL4
    &maTePslLcsRefNmb,
    /* Addition - Added 2 parameters for release 5 */
#if MAP_REL5
    &maTePslLcsServTypeId,
    &maTePslLcsCodeWordSeq,
       &maTeLcwUssdDatCodSch, 
       &maTeLcwLcsCodeWordStr,
    &maTeSeqTerm,
#if MAP_REL6
    &maTeLcsPrivChkSeq,
      &maTeCallSessUnRel,
      &maTeCallSessRel,
    &maTeSeqTerm,   
    DEFINE_AREA_EVNT_INFO_SEQ(maTeAreaEvntInfoSeq),
    &maTePslLcsHgmlcAddr,
#endif /* MAP_REL6 */
#endif /* MAP_REL5 */
#endif /* MAP_REL4 */
#endif /* MAP_REL99 */
 &maTeSeqTerm,
 NULLP,
};


PRIVATE MaTknElmtDef maTePslExtGeogInfo = 
     DEFINE_STRS(1,20,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTePslAgeOfLocInfo = 
     DEFINE_TAG_INT(MA_TAG_CSPRIM0,0,32767,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL99
PRIVATE MaTknElmtDef maTePslAddGeogInfo =
     DEFINE_TAG_STRE(MA_TAG_CSPRIM2,1,91,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL4
PRIVATE MaTknElmtDef maTeDefMtLrResInd =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_OPT);

/* Added a new parameter - Positioning Data information */
#if MAP_REL5
PRIVATE MaTknElmtDef maTePslPosiDatinfo =
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,2,MAT_MAX_POSI_DATA_INFO,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef maTePslUtranPosiDatinfo =
     DEFINE_TAG_STRS(MA_TAG_CSPRIM5,3,MAT_MAX_UTR_POSI_DATA_INFO,LMA_VER2P,MA_TF_VER2P_OPT);

/* Addition : upgrade for MAP release 6 */
#if MAP_REL6
 PRIVATE MaTknElmtDef 
 maTePslCellIdOrLAIChoice= DEFINE_TAG_CHOICE(sizeof(MaCellIdOrLAI),
                         MA_TAG_CSCONST6,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef maTePslSaiPres = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM7,LMA_VER2P,MA_TF_VER2P_OPT);

#endif /* MAP_REL6 */
#endif /* MAP_REL5 */
#endif /* MAP_REL4 */
#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef *maPrvSubsLocRspTkns[] = 
{
 &maTeSeqMandVer2P,
    &maTePslExtGeogInfo,
    &maTePslAgeOfLocInfo,
    &maTeExtCont1,
#if MAP_REL99
    &maTePslAddGeogInfo,
#if MAP_REL4
    &maTeDefMtLrResInd,
    /* Added a new parameter - Positioning Data information */
#if MAP_REL5
    &maTePslPosiDatinfo,
    &maTePslUtranPosiDatinfo,
#if MAP_REL6
    DEFINE_CELLIDORLAI_CHOICE(maTePslCellIdOrLAIChoice),
    &maTePslSaiPres,
#endif /* MAP_REL6 */
#endif /* MAP_REL5 */
#endif /* MAP_REL4 */
#endif /* MAP_REL99 */
 &maTeSeqTerm,
 NULLP,
};


/* -------------------------------------------------------------------- */
/* subscriber location report Request and Response                      */
/* -------------------------------------------------------------------- */

PRIVATE MaTknElmtDef maTeSubsLocRptReq =
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_MAND);

#if MAP_REL99
PRIVATE MaTknElmtDef maTeSlrLcsEvent =  /* LCS event */
     DEFINE_U_ENUM(LMA_VER2P,MA_TF_VER2P_MAND,maChkLcsEvent,maLcsEventEnums);
#else
PRIVATE MaTknElmtDef maTeSlrLcsEvent =  /* LCS event */
     DEFINE_U_ENUM(LMA_VER2P,MA_TF_VER2P_MAND,NULLP,maLcsEventEnums);
#endif

PRIVATE MaTknElmtDef maTeSlrLcsClientIDSeq =   /* LCS client ID */
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeSlrLcsLocInfoSeq =     /* LCS location information */
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeSlrMlcNmb =    /* MLC number */
     DEFINE_STRS(1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeSlrLmsi = /* LMSI optional */
        DEFINE_TAG_STRS(MA_TAG_CSPRIM0,4,4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSlrMsIsdn = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSlrImsi = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,3,8,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSlrImei = /* IMEI (Optional) */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,8,8,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSlrNaEsrd = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSlrNaEsrk = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,1,9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSlrExtGeogInfo = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM5,1,20,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSlrAgeOfLocInfo = 
     DEFINE_TAG_INT(MA_TAG_CSPRIM6,0,32767,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL99
PRIVATE MaTknElmtDef maTeSlrAddGeogInfo =
     DEFINE_TAG_STRE(MA_TAG_CSPRIM8,1,91,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL4
PRIVATE MaTknElmtDef maTeSlrLliGprsNodeInd = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSlrLliAddNmbChoice = 
     DEFINE_TAG_CHOICE(sizeof(MaAddNmb),MA_TAG_CSCONST3,LMA_VER2P,
                       MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSlrLliAnMscNmb =   /* Msc Number            */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeSlrLliAnSgsnNmb =   /* Sgsn       Number     */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeSlrDefMtLrDataSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSlrDefLocEventType = 
     DEFINE_BITSTR(1,16,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeSlrTermCause = 
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT,maChkTermCause,maTermCauseEnums);

PRIVATE MaTknElmtDef maTeDmdLcsLocInfoSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_OPT);

#ifndef MA_REF_NMB_CHANGE
PRIVATE MaTknElmtDef maTeSlrLcsRefNmb =
     DEFINE_TAG_U8(MA_TAG_CSPRIM10,LMA_VER2P,MA_TF_VER2P_OPT);
#else
 /* 
  * Currnet MSC number and Current SGSN number were removed from 2002/09
  * release, they are kept for backward issue 
  */
PRIVATE MaTknElmtDef maTeCurrMscNum =
     DEFINE_TAG_STRS(MA_TAG_CSPRIM10,1, 9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCurrSgsnNum = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM11,1, 9,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MA_REF_NMB_CHANGE */

/* Added a new parameter - Positioning Data information */
#if MAP_REL5
PRIVATE MaTknElmtDef maTeSlrPosiDatinfo = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM11,2,MAT_MAX_POSI_DATA_INFO,LMA_VER2P,MA_TF_VER2P_OPT);
PRIVATE MaTknElmtDef maTeSlrUtranPosiDatinfo =
     DEFINE_TAG_STRS(MA_TAG_CSPRIM12,3,MAT_MAX_UTR_POSI_DATA_INFO,LMA_VER2P,MA_TF_VER2P_OPT);

/* Addition: update for MAP release 6 */
#if MAP_REL6 

PRIVATE MaTknElmtDef maTeSlrSuppLcsCapSets = /* Supported LCS Capability Sets */
      DEFINE_TAG_STRS(MA_TAG_CSPRIM4,2,16,LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSlrAddLcsCapSets = /* Additional LCS Capability Sets */
        DEFINE_TAG_STRS(MA_TAG_CSPRIM5,2,16,LMA_VER2P, MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef  maTeSlrCellIdOrLAIChoice=
     DEFINE_TAG_CHOICE(sizeof(MaCellIdOrLAI),MA_TAG_CSCONST13,LMA_VER2P,MA_TF_VER2P_OPT);


PRIVATE MaTknElmtDef maTeSlrHgmlcAddr = /* h-gmlc Address */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM14,5,17,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSlrServTypeId = 
     DEFINE_TAG_INT(MA_TAG_CSPRIM15, 0, 127,LMA_VER2P,MA_TF_VER2P_OPT);


PRIVATE MaTknElmtDef maTeSlrSaiPres = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM17,LMA_VER2P,MA_TF_VER2P_OPT);


#endif /* MAP_REL6 */
#endif /* MAP_REL5 */
#endif /* MAP_REL4 */
#endif /* MAP_REL99 */


PRIVATE MaTknElmtDef *maSubsLocRptReqTkns[] = 
{
 &maTeSubsLocRptReq,
    &maTeSlrLcsEvent,
    DEFINE_LCSCLIENTID_SEQ(maTeSlrLcsClientIDSeq),
    &maTeSlrLcsLocInfoSeq,
       &maTeSlrMlcNmb,
       &maTeSlrLmsi,
       &maTeExtCont1,
#if MAP_REL99
#if MAP_REL4
       &maTeSlrLliGprsNodeInd,
       &maTeSlrLliAddNmbChoice,
          &maTeSlrLliAnMscNmb,
          &maTeSlrLliAnSgsnNmb,
       &maTeSeqTerm,
#if MAP_REL6
       &maTeSlrSuppLcsCapSets,
       &maTeSlrAddLcsCapSets,
#endif /* MAP_REL6 */
#endif
#endif
    &maTeSeqTerm,
    &maTeSlrMsIsdn,
    &maTeSlrImsi,
    &maTeSlrImei,
    &maTeSlrNaEsrd,
    &maTeSlrNaEsrk,
    &maTeSlrExtGeogInfo,
    &maTeSlrAgeOfLocInfo,
#if (MAP_REL99 || MAP_REL4 || MAP_REL5 || MAP_REL6 )
    &maTeSlrArgExtCont7,
#else
    &maTeExtCont7,
#endif
#if MAP_REL99
    &maTeSlrAddGeogInfo,
#if MAP_REL4
    &maTeSlrDefMtLrDataSeq,
       &maTeSlrDefLocEventType,
       &maTeSlrTermCause,
       &maTeDmdLcsLocInfoSeq,
          &maTeSlrMlcNmb,
          &maTeSlrLmsi,
          &maTeExtCont1,
          &maTeSlrLliGprsNodeInd,
          &maTeSlrLliAddNmbChoice,
             &maTeSlrLliAnMscNmb,
             &maTeSlrLliAnSgsnNmb,
          &maTeSeqTerm,
/* addition: update for MAP release 6 */
#if MAP_REL6
          &maTeSlrSuppLcsCapSets,
          &maTeSlrAddLcsCapSets,
#endif  /* MAP_REL6 */
       &maTeSeqTerm,
    &maTeSeqTerm,
#ifndef MA_REF_NMB_CHANGE
    &maTeSlrLcsRefNmb,
#else
    /* 
     * Currnet MSC number and Current SGSN number were removed from 
     * 2002/09 release, they are kept for backward issue.
     */
    &maTeCurrMscNum,
    &maTeCurrSgsnNum,
#endif /* MA_REF_NMB_CHANGE */

/* Added a new parameter - Positioning Data information */
#if MAP_REL5
    &maTeSlrPosiDatinfo,
    &maTeSlrUtranPosiDatinfo,

/* Addition: upgrade for MAP reelase 6 */
#if MAP_REL6
 DEFINE_CELLIDORLAI_CHOICE(maTeSlrCellIdOrLAIChoice),
 &maTeSlrHgmlcAddr,
 &maTeSlrServTypeId,
 &maTeSlrSaiPres,
#endif /* MAP_REL6 */
#endif /* MAP_REL5 */
#endif /* MAP_REL4 */
#endif /* MAP_REL99 */
 &maTeSeqTerm,
 NULLP,
};


#if MAP_REL99
#if (MAP_REL99 || MAP_REL4 || MAP_REL5 || MAP_REL6 )
PRIVATE MaTknElmtDef maTeSlrRspNaEsrk= 

     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,1,9,LMA_VER2P,MA_TF_VER2P_OPT);
#if MAP_REL6

PRIVATE MaTknElmtDef maTeSlrRspNaEsrd= 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER2P,MA_TF_VER2P_OPT);
#endif /* MAP_REL6 */
#endif /* MAP_REL5 */
#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef *maSubsLocRptRspTkns[] = 
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
#if MAP_REL99
#if (MAP_REL99 || MAP_REL4 || MAP_REL5 || MAP_REL6 )
    &maTeSlrRspNaEsrk,
#if MAP_REL6
    &maTeSlrRspNaEsrd, 
#endif /* MAP_REL6 */
#endif /* MAP_REL5 */
#endif /* MAP_REL99 */
 &maTeSeqTerm,
 NULLP,
};

#endif
#endif /* MAP_MSC || MAP_GSN || MAP_MLC */

#endif /* MAP_REL98 || MAP_REL99 */

#if MAP_REL99

#if (MAP_VLR || MAP_HLR || MAP_GSN)
/* -------------------------------------------------------------------- */
/* Note MM event Request and Response                      */
/* -------------------------------------------------------------------- */


PRIVATE MaTknElmtDef maTeNmeSerKey = 
     DEFINE_INT(0,2147483647,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeNmeMmCode  =  /* Event Met */
     DEFINE_TAG_U8(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeNmeImsi = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM1,3,8,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeNmeMsIsdn = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeNmeLocInfoSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeNmeSupCamPhase =   /* Supported Camel Phase */
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM5,1,16,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL5
PRIVATE MaTknElmtDef maTeNmeLocInfoGprsSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST7,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeNmeOffCam4funcs =
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM8,15,64,LMA_VER2P, MA_TF_VER2P_OPT);

#endif

PRIVATE MaTknElmtDef *maNoteMmEventReqTkns[] = 
{
 &maTeSeqMandVer2P,
    &maTeNmeSerKey,
    &maTeNmeMmCode,
    &maTeNmeImsi,
    &maTeNmeMsIsdn,
    DEFINE_LOCINFO_SEQ(maTeNmeLocInfoSeq),
    &maTeNmeSupCamPhase,
    &maTeExtCont6,
 /* Addition - Added 2 parameters for release 5 */
#if MAP_REL5
    DEFINE_LOC_INFO_GPRS_SEQ(maTeNmeLocInfoGprsSeq),
    &maTeNmeOffCam4funcs,
#endif
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maNoteMmEventRspTkns[] = 
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_VLR || MAP_HLR */

#if (MAP_MSC || MAP_HLR)
/* -------------------------------------------------------------------- */
/* IST Alerting Request                                                 */
/* -------------------------------------------------------------------- */

PRIVATE MaTknElmtDef maTeIaImsi = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef *maIstAlertReqTkns[] =  
{
 &maTeSeqMandVer2P,
    &maTeIaImsi,
    &maTeExtCont1,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTeIaIstAlertTimer  =  /* Ist Alert Timer */
     DEFINE_TAG_INT(MA_TAG_CSPRIM0,15,255,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIaIstInfoWithdraw = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeIaCallTermInd = 
      DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT,maChkCallTermInd,maCallTermIndEnums);

PRIVATE MaTknElmtDef *maIstAlertRspTkns[] = 
{
 &maTeSeqOptVer2P,
    &maTeIaIstAlertTimer,
    &maTeIaIstInfoWithdraw,
    &maTeIaCallTermInd,
    &maTeExtCont3,
 &maTeSeqTerm,
 NULLP,
};

/* -------------------------------------------------------------------- */
/* IST Command Request                                                 */
/* -------------------------------------------------------------------- */

PRIVATE MaTknElmtDef maTeIcImsi = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM0,3,8,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef *maIstCmdReqTkns[] = 
{
 &maTeSeqMandVer2P,
    &maTeIcImsi,
    &maTeExtCont1,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maIstCmdRspTkns[] = 
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_MSC || MAP_HLR */



#if MAP_REL6
#if MAP_MSC

/* -------------------------------------------------------------------- */
/* Release Resources                                                    */
/* -------------------------------------------------------------------- */


PRIVATE MaTknElmtDef maTeMsrn = /* msrn  */
DEFINE_STRS(1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef *maRelResReqTkns[] =
{
&maTeSeqMandVer2P,
 &maTeMsrn,
 &maTeExtCont,
&maTeSeqTerm,
NULLP,
};

PRIVATE MaTknElmtDef *maRelResRspTkns[] = 
{
&maTeSeqOptVer2P,
 &maTeExtCont,
&maTeSeqTerm,
NULLP,
};
#endif /* MAP_MSC */
#endif /* MAP_REL6 */

#if MAP_HLR

/* -------------------------------------------------------------------- */
/* Anytime subscription Interrogation request and response              */
/* -------------------------------------------------------------------- */

PRIVATE MaTknElmtDef maTeAsiSubsIdChoice = 
      DEFINE_TAG_CHOICE(sizeof(MaSubsIdent),MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeAsiReqSubsInfoSeq =
      DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeAsiSsForBsCodeSeq =
      DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiSsCode =   /* SS-Code               */
     DEFINE_U8(LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeAsiBasServCodeChoice =   /* Basic Service Code    */
     DEFINE_CHOICE(sizeof(MaBasicServ),LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiBscBearCode =   /* Bear   code           */
     DEFINE_TAG_U8(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeAsiBscTeleCode =   /* Tele Code             */
     DEFINE_TAG_U8(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeAsiLongFtnSup =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiOdb =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiReqCamSubsInfo =
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_OPT,maReqCamSubsInfoEnums);

PRIVATE MaTknElmtDef maTeAsiSupVlrCamPhase =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiSupSgsnCamPhase =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM5,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiGsmScfAddr  =  /* Gsm Scf Address */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

#if MAP_REL5
PRIVATE MaTknElmtDef maTeAddReqCamSubsInfo = 
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM7,LMA_VER2P,MA_TF_VER2P_OPT,
                       maChkAddReqCamSubsInfo, maAddReqCamSubsInfoEnums);
#endif

PRIVATE MaTknElmtDef *maAnyTimeSubsInterroReqTkns[] = 
{
 &maTeSeqMandVer2P,
    DEFINE_SUBSID_CHOICE(maTeAsiSubsIdChoice),
    &maTeAsiReqSubsInfoSeq,
       &maTeAsiSsForBsCodeSeq,
          &maTeAsiSsCode,
          &maTeAsiBasServCodeChoice,
             &maTeAsiBscBearCode,
             &maTeAsiBscTeleCode,
          &maTeSeqTerm,
          &maTeAsiLongFtnSup,
       &maTeSeqTerm,
       &maTeAsiOdb,
       &maTeAsiReqCamSubsInfo,
       &maTeAsiSupVlrCamPhase,
       &maTeAsiSupSgsnCamPhase,
       &maTeExtCont6,
#if MAP_REL5
       &maTeAddReqCamSubsInfo,
#endif
    &maTeSeqTerm,
    &maTeAsiGsmScfAddr,
    &maTeExtCont3,
    &maTeAsiLongFtnSup,
 &maTeSeqTerm,
 NULLP,
};


PRIVATE MaTknElmtDef maTeAsiCallFwdDataSeq =
     DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiFwdFeatLst =   /* Forwarding Feature SeqOf */
     DEFINE_SEQOF(LMA_VER2P,MAT_MAX_EXT_BASIC_SERV,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiOdbNotificationToCse =
     DEFINE_NULL(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiCallBarrDataSeq =
     DEFINE_TAG_SEQ(MA_TAG_CSCONST2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiCbarrFeatLst =   /* Forwarding Feature SeqOf */
     DEFINE_SEQOF(LMA_VER2P,MAT_MAX_EXT_BASIC_SERV,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeAsiPasswd =   /* Password */
     DEFINE_TAG_STRS(MA_TAG_NUMSTR,4,4,LMA_VER2P,MA_TF_VER2P_OPT); 

PRIVATE MaTknElmtDef maTeAsiWngPwdAtmCntr = 
     DEFINE_INT(0,4,LMA_VER2P,MA_TF_VER2P_OPT);

/* ODB info */
/* --------------------------------------- */
PRIVATE MaTknElmtDef maTeAsiOdbDataSeq =
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeOdbGenDat =   /* Odb. Gen Data         */
     DEFINE_BITSTR(6,32,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeOdbHplmnDat =   /* Odb. Hplmn data       */
     DEFINE_BITSTR(4,32,LMA_VER2P,MA_TF_VER2P_OPT);

#ifdef MAP_PHASE2_EXT_MARK
#define DEFINE_ODBINFO_SEQ(seqHeader)    \
&seqHeader,               \
  &maTeAsiOdbDataSeq,     \
     &maTeOdbGenDat,       \
     &maTeOdbHplmnDat,     \
     &maTeExtMark,         \
     &maTeExtCont,         \
  &maTeSeqTerm,           \
  &maTeAsiOdbNotificationToCse, \
  &maTeExtCont,         \
&maTeSeqTerm
#else
#define DEFINE_ODBINFO_SEQ(seqHeader)    \
&seqHeader,               \
  &maTeAsiOdbDataSeq,     \
     &maTeOdbGenDat,       \
     &maTeOdbHplmnDat,     \
     &maTeExtCont,         \
  &maTeSeqTerm,           \
  &maTeAsiOdbNotificationToCse, \
  &maTeExtCont,         \
&maTeSeqTerm
#endif

PRIVATE MaTknElmtDef maTeAsiOdbInfoSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_OPT);

/* CAMEL Subscription Info Seq */
/* --------------------------------------- */
PRIVATE MaTknElmtDef maTeOCsiSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiObcsmCamTdpCritLst = /*ObcsmCamelTDPCriteriaList*/
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST1,LMA_VER2P,MAT_MAXNUMOF_CAMTDPDATA,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiObcsmCamTdpCritSeq  =  /*ObcsmTdpCriteria Seq*/
     DEFINE_U_SEQ(LMA_VER2P,MA_TF_VER2P_OPT, maChkIgnoreSeq);

PRIVATE MaTknElmtDef maTeAsiDCsiSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiTcsiSeq =   /* TCSI Sequence         */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiTbcsmCamTdpCritLst = /*TbcsmCamelTDPCriteriaList*/
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST4,LMA_VER2P,MAT_MAXNUMOF_CAMTDPDATA,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiVTcsiSeq =   /* TCSI Sequence         */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST5,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiVTbcsmCamTdpCritLst = /*TbcsmCamelTDPCriteriaList*/
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST6,LMA_VER2P,MAT_MAXNUMOF_CAMTDPDATA,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiTifCsi = 
   DEFINE_TAG_NULL(MA_TAG_CSPRIM7,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiNotificationToCse  =  /*Notification To CSE */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM8,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiGprsCsiSeq   = /*GPRS CSI */
     DEFINE_TAG_SEQ(MA_TAG_CSCONST9,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiSmsCsiSeq = /* SMS-CSI*/
     DEFINE_TAG_SEQ(MA_TAG_CSCONST10,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiSsCsiSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST11,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiMCsiSeq  =  /* M-CSI Seq*/
     DEFINE_TAG_SEQ(MA_TAG_CSCONST12,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiSpecCsiList =   /* Specific CSI List */
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM14,8,32,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL5
PRIVATE MaTknElmtDef maTeCsiMtSmsCsiSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST15,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCsiSmsTDPCritSeqOf = 
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST16,LMA_VER2P, MAT_MAXNUMOF_CAMTDPDATA,
                      MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCsiMgCsiSeq  = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST17,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCsiOImCsiSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST18,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCsiOimBcsmCamTdpCritLst = 
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST19,LMA_VER2P,MAT_MAXNUMOF_CAMTDPDATA,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCsiDimCsiSeq  =
     DEFINE_TAG_SEQ(MA_TAG_CSCONST20,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCsiVtImcsiSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST21,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeCsiVtImBcsmCamTdpCritLst =
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST22,LMA_VER2P,MAT_MAXNUMOF_CAMTDPDATA,MA_TF_VER2P_OPT);

#define DEFINE_CAMSUBSINFO_SEQ(seqHeader)    \
&seqHeader,               \
   DEFINE_OCSI_SEQ(maTeOCsiSeq), \
   &maTeAsiObcsmCamTdpCritLst, \
      DEFINE_OBCSMCAMTDPCRIT_SEQ(maTeAsiObcsmCamTdpCritSeq),\
   &maTeSeqTerm, \
   DEFINE_DCSI_SEQ(maTeAsiDCsiSeq),\
   DEFINE_TCSI_SEQ(maTeAsiTcsiSeq),\
   &maTeAsiTbcsmCamTdpCritLst,\
      DEFINE_TBCSMCAMTDPCRIT_SEQ(maTeTbcsmCamTdpCritSeq),\
   &maTeSeqTerm,\
   DEFINE_TCSI_SEQ(maTeAsiVTcsiSeq),\
   &maTeAsiVTbcsmCamTdpCritLst,\
      DEFINE_TBCSMCAMTDPCRIT_SEQ(maTeTbcsmCamTdpCritSeq),\
   &maTeSeqTerm,\
   &maTeAsiTifCsi,\
   &maTeAsiNotificationToCse,\
   &maTeAsiGprsCsiSeq, \
      &maTeScsiGcGprsCamelTdpDataLst,\
         &maTeGcGctdTdpDataSeq,\
            &maTeGctdTdGprsTrgDetPoint,\
            &maTeScSctdSerKey,\
            &maTeScSctdGsmScfAddr,\
            &maTeGctdTdDefGprsHandl,\
            &maTeExtCont4,\
         &maTeSeqTerm,\
      &maTeSeqTerm,\
      &maTeScsiGcCamCapHandl,\
      &maTeExtCont2,\
      &maTeVcsiNotificationToCse,\
      &maTeVcsiCsiActive,\
   &maTeSeqTerm,\
   &maTeAsiSmsCsiSeq,\
       &maTeVcsiScSmsCamTdpDataLst,\
          &maTeStdSmsCamTdpDataSeq,\
             &maTeScSctdSmsTrgDetPt,\
             &maTeScSctdSerKey,\
             &maTeScSctdGsmScfAddr,\
             &maTeScSctdDefSmsHandl,\
             &maTeExtCont4,\
          &maTeSeqTerm,\
       &maTeSeqTerm,\
       &maTeVcsiCamCapHandl,\
       &maTeExtCont2,\
       &maTeVcsiNotificationToCse,\
       &maTeVcsiCsiActive,\
   &maTeSeqTerm,\
   DEFINE_SSCSI_SEQ(maTeAsiSsCsiSeq),\
   &maTeAsiMCsiSeq,\
      &maTeMcsiMobilityTrigLst,\
         &maTeMtMmCode,\
      &maTeSeqTerm,\
      &maTeObctdSerKey,\
      &maTeObctdGsmSCFAddr,\
      &maTeExtCont1,\
      &maTeMcsiNotificationToCse,\
      &maTeMcsiCsiActive,\
   &maTeSeqTerm,\
   &maTeExtCont13,\
   &maTeAsiSpecCsiList,\
   DEFINE_SMS_CSI_SEQ(maTeCsiMtSmsCsiSeq), \
   DEFINE_SMS_CAM_TDP_CRIT_SEQOF(maTeCsiSmsTDPCritSeqOf), \
   DEFINE_MG_CSI(maTeCsiMgCsiSeq), \
   DEFINE_OCSI_SEQ(maTeCsiOImCsiSeq),             \
   &maTeCsiOimBcsmCamTdpCritLst, \
      DEFINE_OBCSMCAMTDPCRIT_SEQ(maTeAsiObcsmCamTdpCritSeq),\
   &maTeSeqTerm, \
   DEFINE_DCSI_SEQ(maTeCsiDimCsiSeq),\
   DEFINE_TCSI_SEQ(maTeCsiVtImcsiSeq),\
   &maTeCsiVtImBcsmCamTdpCritLst,\
      DEFINE_TBCSMCAMTDPCRIT_SEQ(maTeTbcsmCamTdpCritSeq),\
   &maTeSeqTerm,\
&maTeSeqTerm
#else  /* MAP_REL5 */
#define DEFINE_CAMSUBSINFO_SEQ(seqHeader)    \
&seqHeader,               \
   DEFINE_OCSI_SEQ(maTeOCsiSeq), \
   &maTeAsiObcsmCamTdpCritLst, \
      DEFINE_OBCSMCAMTDPCRIT_SEQ(maTeAsiObcsmCamTdpCritSeq),\
   &maTeSeqTerm, \
   DEFINE_DCSI_SEQ(maTeAsiDCsiSeq),\
   DEFINE_TCSI_SEQ(maTeAsiTcsiSeq),\
   &maTeAsiTbcsmCamTdpCritLst,\
      DEFINE_TBCSMCAMTDPCRIT_SEQ(maTeTbcsmCamTdpCritSeq),\
   &maTeSeqTerm,\
   DEFINE_TCSI_SEQ(maTeAsiVTcsiSeq),\
   &maTeAsiVTbcsmCamTdpCritLst,\
      DEFINE_TBCSMCAMTDPCRIT_SEQ(maTeTbcsmCamTdpCritSeq),\
   &maTeSeqTerm,\
   &maTeAsiTifCsi,\
   &maTeAsiNotificationToCse,\
   &maTeAsiGprsCsiSeq, \
      &maTeScsiGcGprsCamelTdpDataLst,\
         &maTeGcGctdTdpDataSeq,\
            &maTeGctdTdGprsTrgDetPoint,\
            &maTeScSctdSerKey,\
            &maTeScSctdGsmScfAddr,\
            &maTeGctdTdDefGprsHandl,\
            &maTeExtCont4,\
         &maTeSeqTerm,\
      &maTeSeqTerm,\
      &maTeScsiGcCamCapHandl,\
      &maTeExtCont2,\
      &maTeVcsiNotificationToCse,\
      &maTeVcsiCsiActive,\
   &maTeSeqTerm,\
   &maTeAsiSmsCsiSeq,\
       &maTeVcsiScSmsCamTdpDataLst,\
          &maTeStdSmsCamTdpDataSeq,\
             &maTeScSctdSmsTrgDetPt,\
             &maTeScSctdSerKey,\
             &maTeScSctdGsmScfAddr,\
             &maTeScSctdDefSmsHandl,\
             &maTeExtCont4,\
          &maTeSeqTerm,\
       &maTeSeqTerm,\
       &maTeVcsiCamCapHandl,\
       &maTeExtCont2,\
       &maTeVcsiNotificationToCse,\
       &maTeVcsiCsiActive,\
   &maTeSeqTerm,\
   DEFINE_SSCSI_SEQ(maTeAsiSsCsiSeq),\
   &maTeAsiMCsiSeq,\
      &maTeMcsiMobilityTrigLst,\
         &maTeMtMmCode,\
      &maTeSeqTerm,\
      &maTeObctdSerKey,\
      &maTeObctdGsmSCFAddr,\
      &maTeExtCont1,\
      &maTeMcsiNotificationToCse,\
      &maTeMcsiCsiActive,\
   &maTeSeqTerm,\
   &maTeExtCont13,\
   &maTeAsiSpecCsiList,\
&maTeSeqTerm
#endif /* MAP_REL5 */

PRIVATE MaTknElmtDef maTeAsiCamSubsInfo =
     DEFINE_TAG_SEQ(MA_TAG_CSCONST4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiSuppVlrCamPhases =  /* Supported camel phases */
        DEFINE_TAG_BITSTR(MA_TAG_CSPRIM5,1,16,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiSuppSgsnCamPhases =  /* Supported camel phases */
        DEFINE_TAG_BITSTR(MA_TAG_CSPRIM6,1,16,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsirNotificationToCse  =  /*Notification To CSE */
     DEFINE_NULL(LMA_VER2P,MA_TF_VER2P_OPT);

 /* Addition - upgrade for MAP release 5 */
#if MAP_REL5
PRIVATE MaTknElmtDef maTeAsiOffCam4CSIsInVlr =
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM8,7,16,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAsiOffCam4CSIsInSgsn =
     DEFINE_TAG_BITSTR(MA_TAG_CSPRIM9,7,16,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

PRIVATE MaTknElmtDef *maAnyTimeSubsInterroRspTkns[] = 
{
 &maTeSeqOptVer2P,
    &maTeAsiCallFwdDataSeq,
       DEFINE_FWDFEAT_LST(maTeAsiFwdFeatLst),
       &maTeAsirNotificationToCse,
       &maTeExtCont0,
    &maTeSeqTerm,
    &maTeAsiCallBarrDataSeq,
       DEFINE_CBARRFEAT_LST(maTeAsiCbarrFeatLst), 
       &maTeAsiPasswd,
       &maTeAsiWngPwdAtmCntr,
       &maTeAsirNotificationToCse,
       &maTeExtCont,
    &maTeSeqTerm,
    DEFINE_ODBINFO_SEQ(maTeAsiOdbInfoSeq),
    DEFINE_CAMSUBSINFO_SEQ(maTeAsiCamSubsInfo),
    &maTeAsiSuppVlrCamPhases,
    &maTeAsiSuppSgsnCamPhases,
    &maTeExtCont7,
#if MAP_REL5
    &maTeAsiOffCam4CSIsInVlr,
    &maTeAsiOffCam4CSIsInSgsn,
#endif
 &maTeSeqTerm,
 NULLP,
};


/* ----------------------------------------------------------------- */
/* Any time Modification                                             */
/* ----------------------------------------------------------------- */

PRIVATE MaTknElmtDef maTeAtmSubsIdChoice = 
      DEFINE_TAG_CHOICE(sizeof(MaSubsIdent),MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeAtmGsmSCFAddr = 
      DEFINE_TAG_STRS(MA_TAG_CSPRIM1,1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeAtmModReqForCfInfoSeq =
     DEFINE_TAG_SEQ(MA_TAG_CSCONST2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAtmSsCode  =  /* SS code*/
     DEFINE_TAG_U8(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeAtmExtBscChoice =  /* Extended Basic serv code */
     DEFINE_TAG_CHOICE(sizeof(MaExtBasServCode),MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_OPT);


PRIVATE MaTknElmtDef maTeAtmExtSsStatus =   /* SS Status */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,1,5,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAtmModPasswd =   /* Password */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM3,4,4,LMA_VER2P,MA_TF_VER2P_OPT); 

PRIVATE MaTknElmtDef maTeAtmFwdToNmb = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM3,1,20,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAtmFwdToSubAddr = 
     DEFINE_TAG_STRS(MA_TAG_CSPRIM4,1,21,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAtmExtNoRplyCondTime =   /* No Reply Condition Time */
     DEFINE_TAG_INT(MA_TAG_CSPRIM5,1,100,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAtmCfModInstrToCse =
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM6,LMA_VER2P,MA_TF_VER2P_OPT,maModificationInstrEnums);

PRIVATE MaTknElmtDef maTeAtmModReqForCbInfoSeq =
     DEFINE_TAG_SEQ(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAtmWngPwdAtmCntr = 
     DEFINE_TAG_INT(MA_TAG_CSPRIM4,0,4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAtmCbModInstrToCse =
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM5,LMA_VER2P,MA_TF_VER2P_OPT,maModificationInstrEnums);

PRIVATE MaTknElmtDef maTeAtmModReqForCsi =
     DEFINE_TAG_SEQ(MA_TAG_CSCONST4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAtmReqCamSubsInfo =
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_MAND,maReqCamSubsInfoEnums);

PRIVATE MaTknElmtDef maTeAtmCsiModInstrToCse =
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT,maModificationInstrEnums);

PRIVATE MaTknElmtDef maTeAtmCsiModCsiState =
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT,maModificationInstrEnums);

PRIVATE MaTknElmtDef maTeAtmLongFtnSup =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM6,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL5
PRIVATE MaTknElmtDef maTeAtmModReqForOdbDataSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST7,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeMrodOdbDataSeq =
     DEFINE_TAG_SEQ(MA_TAG_CSCONST0, LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAtmModNotToCse =
     DEFINE_TAG_ENUM(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT,maModificationInstrEnums);

PRIVATE MaTknElmtDef maTeMrfcAddReqCamSubsInfo = 
     DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM4,LMA_VER2P,MA_TF_VER2P_OPT,
                       maChkAddReqCamSubsInfo, maAddReqCamSubsInfoEnums);
#endif

PRIVATE MaTknElmtDef *maAnyTimeModReqTkns[] =
{
 &maTeSeqMandVer2P,
    DEFINE_SUBSID_CHOICE(maTeAtmSubsIdChoice),
    &maTeAtmGsmSCFAddr,
    &maTeAtmModReqForCfInfoSeq,
       &maTeAtmSsCode,
       &maTeAtmExtBscChoice,
          &maTeFfExtBscBearCode,
          &maTeFfExtBscTeleCode,
       &maTeSeqTerm,
       &maTeAtmExtSsStatus,
       &maTeAtmFwdToNmb,
       &maTeAtmFwdToSubAddr,
       &maTeAtmExtNoRplyCondTime,
       &maTeAtmCfModInstrToCse,
       &maTeExtCont7,
    &maTeSeqTerm,    
    &maTeAtmModReqForCbInfoSeq,
       &maTeAtmSsCode,
       &maTeAtmExtBscChoice,
          &maTeFfExtBscBearCode,
          &maTeFfExtBscTeleCode,
       &maTeSeqTerm,
       &maTeAtmExtSsStatus,
       &maTeAtmModPasswd,
       &maTeAtmWngPwdAtmCntr,
       &maTeAtmCbModInstrToCse,
       &maTeExtCont6,
    &maTeSeqTerm,    
    &maTeAtmModReqForCsi,
       &maTeAtmReqCamSubsInfo,
       &maTeAtmCsiModInstrToCse,
       &maTeAtmCsiModCsiState,
       &maTeExtCont3,
#if MAP_REL5
       &maTeMrfcAddReqCamSubsInfo,
#endif
    &maTeSeqTerm,    
    &maTeExtCont5,
    &maTeAtmLongFtnSup,
#if MAP_REL5
    &maTeAtmModReqForOdbDataSeq,
       &maTeMrodOdbDataSeq,
          &maTeOdbGenDat,
          &maTeOdbHplmnDat,
/* Extension marker added here is for structure reuse and **
** is not effective for 2P definitions.                   ** 
*/
#ifdef MAP_PHASE2_EXT_MARK
          &maTeExtMark,
#endif
          &maTeExtCont,
       &maTeSeqTerm,
       &maTeAtmModNotToCse,
       &maTeExtCont2,
    &maTeSeqTerm,
#endif
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTeAtmExtSsInfoForCseChoice =
     DEFINE_TAG_CHOICE(sizeof(MaExtSsInfoForCse),MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAtmExtFwdInfoForCseSeq=
     DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAtmExtFwdFeatLst = /* Ext. Forwarding Feature SeqOf */
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST1,LMA_VER2P,MAT_MAX_EXT_BASIC_SERV,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeAtmNotificationToCse =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAtmExtCallBarrInfoForCseSeq =
     DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAtmExtCbarrFeatLst =   /* Forwarding Feature SeqOf */
     DEFINE_TAG_SEQOF(MA_TAG_CSCONST1,LMA_VER2P,MAT_MAX_EXT_BASIC_SERV,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeAtmPasswd =   /* Password              */
     DEFINE_TAG_STRS(MA_TAG_CSPRIM2,4,4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAtmWngPwdCntr = 
     DEFINE_TAG_INT(MA_TAG_CSPRIM3,0,4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAtmNotifToCse =
     DEFINE_TAG_NULL(MA_TAG_CSPRIM4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAtmCamSubsInfoSeq = /* Camel Subscription */
    DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL5
PRIVATE MaTknElmtDef maTeAtmOdbInfoSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_OPT);
#endif

PRIVATE MaTknElmtDef *maAnyTimeModRspTkns[] = 
{
 &maTeSeqOptVer2P,
     &maTeAtmExtSsInfoForCseChoice,
         &maTeAtmExtFwdInfoForCseSeq,
            &maTeAtmSsCode,
            DEFINE_FWDFEAT_LST(maTeAtmExtFwdFeatLst),
            &maTeAtmNotificationToCse,
            &maTeExtCont3,
         &maTeSeqTerm,
         &maTeAtmExtCallBarrInfoForCseSeq,
            &maTeAtmSsCode,
            DEFINE_CBARRFEAT_LST(maTeAtmExtCbarrFeatLst),
            &maTeAtmPasswd,
            &maTeAtmWngPwdCntr,
            &maTeAtmNotifToCse,
            &maTeExtCont5,
         &maTeSeqTerm,
     &maTeSeqTerm,
     DEFINE_CAMSUBSINFO_SEQ(maTeAtmCamSubsInfoSeq),
     &maTeExtCont2,
#if MAP_REL5
    DEFINE_ODBINFO_SEQ(maTeAtmOdbInfoSeq),
#endif
 &maTeSeqTerm,
 NULLP,
};

/* ----------------------------------------------------------------- */
/* Note Subscriber Data Modified                                     */
/* ----------------------------------------------------------------- */

PRIVATE MaTknElmtDef maTeNsdmImsi = /* IMSI */
     DEFINE_STRS(3,8,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeNsdmMsIsdn =   /* Ms-Isdn               */
     DEFINE_STRS(1,9,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeNsdmExtFwdInfoForCseSeq=
     DEFINE_TAG_SEQ(MA_TAG_CSCONST0,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeNsdmExtCallBarrInfoForCseSeq =
     DEFINE_TAG_SEQ(MA_TAG_CSCONST1,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeNsdmOdbInfoSeq = 
     DEFINE_TAG_SEQ(MA_TAG_CSCONST2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeNsdmCamSubsInfoSeq = /* Gmsc Camel Subscription */
    DEFINE_TAG_SEQ(MA_TAG_CSCONST3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeNsdmAllInfoSent = /* All Information Sent */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM4,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maNoteSubsDataModReqTkns[] = 
{
 &maTeSeqMandVer2P,
     &maTeNsdmImsi,
     &maTeNsdmMsIsdn,
     &maTeNsdmExtFwdInfoForCseSeq,
         &maTeAtmSsCode,
         DEFINE_FWDFEAT_LST(maTeAtmExtFwdFeatLst),
         &maTeAtmNotificationToCse,
         &maTeExtCont3,
     &maTeSeqTerm,
     &maTeNsdmExtCallBarrInfoForCseSeq,
         &maTeAtmSsCode,
         DEFINE_CBARRFEAT_LST(maTeAtmExtCbarrFeatLst),
         &maTeAtmPasswd,
         &maTeAtmWngPwdCntr,
         &maTeAtmNotifToCse,
         &maTeExtCont5,
     &maTeSeqTerm,
     DEFINE_ODBINFO_SEQ(maTeNsdmOdbInfoSeq),
     DEFINE_CAMSUBSINFO_SEQ(maTeNsdmCamSubsInfoSeq),
     &maTeNsdmAllInfoSent,
     &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};


PRIVATE MaTknElmtDef *maNoteSubsDataModRspTkns[] = 
{
 &maTeSeqOptVer2P,
     &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_HLR */

#if MAP_SEC

/* Value range of operation code and error code is not explicitly 
 * specified by standard. And max value is 89 for oprCode, max 
 * value is 72 for error code.(v4.4.1). Use 1 ~ 255 for forward 
 * compatibility. 
 */
PRIVATE MaTknElmtDef maTeStCmpLocVal = 
     DEFINE_INT(1,255,LMA_VER2P,MA_TF_VER2P_MAND);

/* Global value for operation and error code is type of Object 
 * Identifier, which is not supported on the upper layer 
 * interface. 
 */

PRIVATE MaTknElmtDef maTeStCmpGloVal = 
     DEFINE_OBJID(1,16,LMA_VER2P,MA_TF_VER2P_OPT,maChkObjId);

#define DEFINE_CMPIDVAL_CHOICE(choiceHeader)   \
    &choiceHeader,\
       &maTeStCmpLocVal,\
       &maTeStCmpGloVal,\
    &maTeSeqTerm 

PRIVATE MaTknElmtDef maTeStOprCodeChoice = 
     DEFINE_TAG_CHOICE(sizeof(MaOprCode),MA_TAG_CSCONST0,LMA_VER2P,
                       MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeStErrCodeChoice = 
     DEFINE_TAG_CHOICE(sizeof(MaErrCode),MA_TAG_CSCONST1,LMA_VER2P,
                       MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeStUserInfo = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_MAND);

#define DEFINE_ORIGCMPID_CHOICE(choiceHeader)   \
    &choiceHeader,\
       DEFINE_CMPIDVAL_CHOICE(maTeStOprCodeChoice),\
       DEFINE_CMPIDVAL_CHOICE(maTeStErrCodeChoice),\
       &maTeStUserInfo,\
    &maTeSeqTerm 

PRIVATE MaTknElmtDef maTeStSecHeaderSeq = 
     DEFINE_SEQ(LMA_VER2P,MA_TF_VER2P_MAND);

/* 
** 1. IV Size was changed from (4~14) to 14
** 2. IV is changed to optional
** 3. Sending PLMN-ID is removed from security header
*/
PRIVATE MaTknElmtDef maTeStInitVec = 
     DEFINE_STRS(14,14,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeStSecParamInd = 
     DEFINE_STRS(4,4,LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeStOrigCmpIdChoice = 
     DEFINE_CHOICE(sizeof(MaOrigCmpId),LMA_VER2P,MA_TF_VER2P_MAND);

PRIVATE MaTknElmtDef maTeStProtePload = 
     DEFINE_STRUL(1,MA_SIZE_SECPAYLOAD,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maSecTransTkns[] = 
{
 &maTeSeqMandVer2P,
    &maTeStSecHeaderSeq,
       &maTeStSecParamInd,
       DEFINE_ORIGCMPID_CHOICE(maTeStOrigCmpIdChoice),
       &maTeStInitVec,
    &maTeSeqTerm,
    &maTeStProtePload,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTeDlgSecHeaderSeq = 
     DEFINE_SEQ(LMA_VER2AND2P, MA_TF_VER2AND2P_OPT3);

PUBLIC MaTknElmtDef *maDlgSecHeaderTkns[] = 
{
 &maTeDlgSecHeaderSeq,
    &maTeStSecParamInd,
    DEFINE_ORIGCMPID_CHOICE(maTeStOrigCmpIdChoice),
    &maTeStInitVec,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_SEC */
#endif /* MAP_REL99 */

#ifdef XWEXT /* xingzhou.xu: added for paging detect 2006/10/16 */
/*------------------------------------------*/
/*  Paging Detetct                          */
/*------------------------------------------*/
PRIVATE MaTknElmtDef  maXWDetectMode = /* Paging Detect Mode */
	DEFINE_ENUM(LMA_VER2P,MA_TF_VER2P_MAND, maXWExtDetectModeEnums);

PRIVATE MaTknElmtDef  maXWDetectRslt = /* Paging Detect result */
	DEFINE_ENUM(LMA_VER2P,MA_TF_VER2P_OPT, maXWExtDetectRsltEnums);

PUBLIC MaTknElmtDef  *maXWPagingDetectReqTkns[] = /* Paging Detect Req Tokens */
{
 &maTeSeqMand,
 	&maXWUid,
 	&maXWEbscNumber,
 	&maXWLai,
 	&maXWDetectMode,
 	&maXWUtType,
 &maTeSeqTerm,
 NULLP,
};

PUBLIC MaTknElmtDef  *maXWPagingDetectRspTkns[] = /* Paging Detect Rsp Tokens */
{
 &maTeSeqOpt,
 	&maXWDetectRslt,
 &maTeSeqTerm,
 NULLP,
};
#endif

/* ----------------------------------------------------------------- */
/* Database definitions for parameters of Return error components    */
/* ----------------------------------------------------------------- */


/* Roam Not Allowed Parameter */

PRIVATE MaTknElmtDef maTeRoamNotAllCause = 
   DEFINE_ENUM(LMA_VER2P,MA_TF_VER2P_MAND,maRoamNotAllCauseEnums);

PRIVATE MaTknElmtDef *maRoamNotAllParamTkns[] =
{
   &maTeSeqMandVer2P,
      &maTeRoamNotAllCause,
      &maTeExtCont,
   &maTeSeqTerm,
   NULLP,
};

/* Call Barred Parameter */

PRIVATE MaTknElmtDef maTeCallBarrCause = 
   DEFINE_ENUM(LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3,maCallBarrCauseEnums);

PRIVATE MaTknElmtDef maTeUnAuthMsgOrg = 
   DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3);

PRIVATE MaTknElmtDef *maCallBarredParamTkns[] =
{
   &maTeSeqOptVer2PAnd4,
      &maTeCallBarrCause,
      &maTeExt4Cont,
      &maTeUnAuthMsgOrg,
   &maTeSeqTerm,
   NULLP,
};

/* Cug Reject Param */

PRIVATE MaTknElmtDef
 maTeCugRejectCause = DEFINE_ENUM(LMA_VER2P,MA_TF_VER2P_OPT,maCugRejectCauseEnums);

PRIVATE MaTknElmtDef *maCugRejectParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeCugRejectCause,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTeSicSsCode =   /* SS Code */
     DEFINE_TAG_U8(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSicBasServCodeChoice = /* Basic Service Code */
     DEFINE_CHOICE(sizeof(MaBasicServ),LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSicBscBearCode =   /* Bearer Code */
     DEFINE_TAG_U8(MA_TAG_CSPRIM2,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSicBscTeleCode =   /* Tele Code */
     DEFINE_TAG_U8(MA_TAG_CSPRIM3,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeSicSsStatus =   /* SS Status */
     DEFINE_TAG_U8(MA_TAG_CSPRIM4,LMA_VER2P,MA_TF_VER2P_OPT);

/* SS Incompatibility Cause */
PRIVATE MaTknElmtDef *maSSIncompCauseTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeSicSsCode,
    &maTeSicBasServCodeChoice,
       &maTeSicBscBearCode,
       &maTeSicBscTeleCode,
    &maTeSeqTerm,
    &maTeSicSsStatus,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
 &maTeSeqTerm,
 NULLP,
};

/*
** SS Error Status 
*/

PRIVATE MaTknElmtDef maTeSesSsStatus =   /* SS Status  */
     DEFINE_U8(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maSSErrStatusTkns[] =
{
   &maTeSesSsStatus,
   NULLP,
};

/* SM Delivery Failure Cause */
PRIVATE MaTknElmtDef maTeSdfcSMEnumDlvyFailCause =   
     DEFINE_ENUM(LMA_VER2P,MA_TF_VER2P_MAND,maSMDlvyFailCauseEnums);

PRIVATE MaTknElmtDef maTeSdfcDiagInfo =   
     DEFINE_STRE(1,200,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maSMDlvyFailCauseTkns[] =
{
 &maTeSeqMandVer2P,
    &maTeSdfcSMEnumDlvyFailCause,
    &maTeSdfcDiagInfo,
#ifdef MAP_PHASE2_EXT_MARK
    &maTeExtMark,
#endif
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

/* Absent Subscriber SM Param */
PRIVATE MaTknElmtDef maTeAspAbsSubsDiagSM =
         DEFINE_INT(0,255,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef maTeAspAddAbsSubsDiagSM =
         DEFINE_TAG_INT(MA_TAG_CSPRIM0,0,255,LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maAbsSubsSMParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeAspAbsSubsDiagSM,
    &maTeExtCont,
    &maTeAspAddAbsSubsDiagSM,
 &maTeSeqTerm,
 NULLP,
};


/* Extended System Failure Param */

PRIVATE MaTknElmtDef maTeEsfNwResource =
         DEFINE_ENUM(LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3,maNetResEnums);
#if MAP_REL99
#if  MAP_REL6
PRIVATE MaTknElmtDef  maTeEsfAddNwResource = 
      DEFINE_U_ENUM(LMA_VER2P,MA_TF_VER2P_OPT,maChkAddNwRes, maAddNetResEnums); 

#endif /* MAP_REL6 */
#endif /* MAP_REL99 */
PRIVATE MaTknElmtDef *maExtSysFailParamTkns[] =
{
 &maTeSeqOptVer2PAnd4,
    &maTeEsfNwResource,
    &maTeExt4Cont,
#if MAP_REL99
#if MAP_REL6
    &maTeEsfAddNwResource,
#endif /* MAP_REL6 */
#endif /* MAP_REL99 */
 &maTeSeqTerm,
 NULLP,
};


/* Data Missing Param */
PRIVATE MaTknElmtDef *maDataMissParamTkns[] =
{
 &maTeSeqOptVer2PAnd4,
    &maTeExt4Cont,
 &maTeSeqTerm,
 NULLP,
};


/* Unexpected Data Parameter */
PRIVATE MaTknElmtDef *maUnexDataParamTkns[] =
{
 &maTeSeqOptVer2PAnd4,
    &maTeExt4Cont,
 &maTeSeqTerm,
 NULLP,
};

#if MAP_REL99
#if MAP_REL4
PRIVATE MaTknElmtDef maTeShapeOfLocEstiNotSupp =   /* NULL */
     DEFINE_TAG_NULL(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT);

#if MAP_REL5
PRIVATE MaTknElmtDef maTeNeededLcsCapNotSupInServNode = 
     DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);
#endif
#endif /* MAP_REL4 */
#endif

/* Facility Not Sup Param */
PRIVATE MaTknElmtDef *maFacNotSupParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
#if MAP_REL99
#if MAP_REL4
    &maTeShapeOfLocEstiNotSupp,
#if MAP_REL5
    &maTeNeededLcsCapNotSupInServNode,
#endif
#endif /* MAP_REL4 */
#endif
 &maTeSeqTerm,
 NULLP,
};


/* OR-Not Allowed Param */
PRIVATE MaTknElmtDef *maOrNotAllParamTkns[] =
{
 &maTeSeqOptVer2PAnd4,
    &maTeExt4Cont,
 &maTeSeqTerm,
 NULLP,
};

/* Unknown Subscriber Param */
PRIVATE MaTknElmtDef maTeUnknownSubsDiag = 
   DEFINE_ENUM(LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3,maUnknownSubsDiagEnums);

PRIVATE MaTknElmtDef *maUnknownSubsParamTkns[] =
{
 &maTeSeqOptVer2PAnd4,
    &maTeExt4Cont,
    &maTeUnknownSubsDiag,
 &maTeSeqTerm,
 NULLP,
};


/* Number Changed Param */
PRIVATE MaTknElmtDef *maNumberChangedParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};


/* Unidentified Sub Param */
PRIVATE MaTknElmtDef *maUnidentSubParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

/* Illegal Subscriber Param  */
PRIVATE MaTknElmtDef *maIllegalSubsParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

/* Illegal Equpment param */
PRIVATE MaTknElmtDef *maIllegalEqpParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

/* Bearer Service Not Provided Param */
PRIVATE MaTknElmtDef *maBearServNotProvParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};


/* Tele Service Not Provided  Param */
PRIVATE MaTknElmtDef *maTeleServNotProvParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};


/* Tracing Buffer Full Param */
PRIVATE MaTknElmtDef *maTrcBufferFullParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

/* No Roaming Nb Param    */
PRIVATE MaTknElmtDef *maNoRoamNbParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

/* Absent Subscriber  Param */

PRIVATE MaTknElmtDef
 maTeAbsSubsRsn = DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM0,LMA_VER2PAND4,MA_TF_VER2PAND4_OPT3,
                                    maChkAbsSubsRsn,maAbsSubsRsnEnums);

PRIVATE MaTknElmtDef *maAbsSubsParamTkns[] =
{
 &maTeSeqOptVer2PAnd4,
    &maTeExt4Cont,
    &maTeAbsSubsRsn,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef maTeBspCcbsPsbl =
         DEFINE_TAG_NULL(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT);


PRIVATE MaTknElmtDef maTeBspCcbsBusy =
         DEFINE_TAG_NULL(MA_TAG_CSPRIM1,LMA_VER2P,MA_TF_VER2P_OPT);

/* Busy  Subscriber Param */
PRIVATE MaTknElmtDef *maBusySubsParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
    &maTeBspCcbsPsbl,
    &maTeBspCcbsBusy,
 &maTeSeqTerm,
 NULLP,
};

/* No Subscriber Reply Param */
PRIVATE MaTknElmtDef *maNoSubsRplyParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};


/* Forwarding Violation Param */
PRIVATE MaTknElmtDef *maFwdViolationParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

/* PwRegFailCause */
PRIVATE MaTknElmtDef
    maTePwRegFailCause = DEFINE_ENUM(LMA_VER2P,MA_TF_VER2P_MAND,
                                              maPwRegFailCauseEnums);

PRIVATE MaTknElmtDef *maPwRegFailCauseTkns[] =
{
 &maTePwRegFailCause,
 NULLP,
};

/* Forwarding Failed  Param */
PRIVATE MaTknElmtDef *maFwdFailedParamTkns[] =
{
 &maTeSeqOptVer2PAnd4,
    &maTeExt4Cont,
 &maTeSeqTerm,
 NULLP,
};

/* ATI Not Allowed Param */
PRIVATE MaTknElmtDef *maATINotAllParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

/* Sub Busy for MT-SMS Param */
PRIVATE MaTknElmtDef maTeSbfmpGprsCnxnSuspended =
         DEFINE_NULL(LMA_VER2P,MA_TF_VER2P_OPT);

PRIVATE MaTknElmtDef *maSubBusyForMTSMSParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
    &maTeSbfmpGprsCnxnSuspended,
 &maTeSeqTerm,
 NULLP,
};


/* Message Wait List Full Param */
PRIVATE MaTknElmtDef *maMsgWaitListFullParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

/* Resource Limitation Param */
PRIVATE MaTknElmtDef *maResLmtParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};


/* No Group Call Nb Param */
PRIVATE MaTknElmtDef *maNoGrpCallNbParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};


/* Incompatible Terminal Param */
PRIVATE MaTknElmtDef *maIncompTermParamTkns[] =
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

#if (MAP_REL98 || MAP_REL99)

PRIVATE MaTknElmtDef *maUnAuthReqNetParamTkns[] = 
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

/* position Method Failure Diagnostic */
PRIVATE MaTknElmtDef maTePosiMethFailDiag = 
      DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT,maChkPosiMethFailDiag,maPosiMethFailDiagEnums);


PRIVATE MaTknElmtDef *maPosiMethFailParamTkns[] = 
{
 &maTeSeqOptVer2P,
    &maTePosiMethFailDiag,
    &maTeExtCont1,
 &maTeSeqTerm,
 NULLP,
};

/* Unauthorized LCS client diagnostic */
PRIVATE MaTknElmtDef maUnAuthLcsClientDiag =
      DEFINE_TAG_U_ENUM(MA_TAG_CSPRIM0,LMA_VER2P,MA_TF_VER2P_OPT,maChkUnAuthLcsClientDiag,maUnAuthLcsClientParamEnums);

PRIVATE MaTknElmtDef *maUnAuthLcsClientParamTkns[] =  
{
 &maTeSeqOptVer2P,
    &maUnAuthLcsClientDiag,
    &maTeExtCont1,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maUnKwnOrUnRchLcsClientParamTkns[] =  
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_REL98 || MAP_REL99 */
#if MAP_REL99

PRIVATE MaTknElmtDef *maTargCellOutGcaParamTkns[] =  
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maAtsiNotAllParamTkns[] =      
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maAtmNotAllParamTkns[] =     
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maIllegalSsOprParamTkns[] =  
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maSsNotAvaiParamTkns[] =    
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maSsSubsViolationParamTkns[] = 
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maInfoNotAvaiParamTkns[] =   
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

PRIVATE MaTknElmtDef *maMmEventNotSupParamTkns[] = 
{
 &maTeSeqOptVer2P,
    &maTeExtCont,
 &maTeSeqTerm,
 NULLP,
};

#endif /* MAP_REL99 */

PRIVATE MaTknElmtDef *maDlgPduExtContTkns[] =
{
  &maTeExtContSeq,
  NULLP,
};

/* Table for Data base definitions for the Retrurn error types */

PUBLIC MaTknElmtDef **maAllSSErrPduDefs[] =
{
   &maRoamNotAllParamTkns[0],       /* Token element list pointer */
   &maCallBarredParamTkns[0],       /* Token element list pointer */
   &maCugRejectParamTkns[0],        /* Token element list pointer */
   &maSSIncompCauseTkns[0],         /* Token element list pointer */
   &maSSErrStatusTkns[0],           /* Token element list pointer */
   &maSMDlvyFailCauseTkns[0],       /* Token element list pointer */
   &maAbsSubsSMParamTkns[0],        /* Token element list pointer */
   &maExtSysFailParamTkns[0],       /* Token element list pointer */
   &maDataMissParamTkns[0],         /* Token element list pointer */
   &maUnexDataParamTkns[0],         /* Token element list pointer */
   &maFacNotSupParamTkns[0],        /* Token element list pointer */
   &maOrNotAllParamTkns[0],         /* Token element list pointer */
   &maUnknownSubsParamTkns[0],      /* Token element list pointer */
   &maNumberChangedParamTkns[0],    /* Token element list pointer */
   &maUnidentSubParamTkns[0],       /* Token element list pointer */
   &maIllegalSubsParamTkns[0],      /* Token element list pointer */
   &maIllegalEqpParamTkns[0],       /* Token element list pointer */
   &maBearServNotProvParamTkns[0],  /* Token element list pointer */
   &maTeleServNotProvParamTkns[0],  /* Token element list pointer */
   &maTrcBufferFullParamTkns[0],    /* Token element list pointer */
   &maNoRoamNbParamTkns[0],         /* Token element list pointer */
   &maAbsSubsParamTkns[0],          /* Token element list pointer */
   &maBusySubsParamTkns[0],         /* Token element list pointer */
   &maNoSubsRplyParamTkns[0],       /* Token element list pointer */
   &maFwdViolationParamTkns[0],     /* Token element list pointer */
   &maPwRegFailCauseTkns[0],        /* Token element list pointer */
   &maFwdFailedParamTkns[0],        /* Token element list pointer */
   &maATINotAllParamTkns[0],        /* Token element list pointer */
   &maSubBusyForMTSMSParamTkns[0],  /* Token element list pointer */
   &maMsgWaitListFullParamTkns[0],  /* Token element list pointer */
   &maResLmtParamTkns[0],           /* Token element list pointer */
   &maNoGrpCallNbParamTkns[0],      /* Token element list pointer */
   &maIncompTermParamTkns[0],       /* Token element list pointer */
#if (MAP_REL98 || MAP_REL99)
   &maUnAuthReqNetParamTkns[0],     
   &maPosiMethFailParamTkns[0],     
   &maUnAuthLcsClientParamTkns[0],  
   &maUnKwnOrUnRchLcsClientParamTkns[0],
#endif /* MAP_REL98 || MAP_REL99 */
#if MAP_REL99
   &maTargCellOutGcaParamTkns[0],   
   &maAtsiNotAllParamTkns[0],       
   &maAtmNotAllParamTkns[0],        
   &maIllegalSsOprParamTkns[0],     
   &maSsNotAvaiParamTkns[0],        
   &maSsSubsViolationParamTkns[0],  
   &maInfoNotAvaiParamTkns[0],      
   &maMmEventNotSupParamTkns[0],    
#endif /* MAP_REL99 */
   &maDlgPduExtContTkns[0],
#if MAP_REL99
#if MAP_SEC
   &maSecTransTkns[0],
#endif
#endif
};


PUBLIC MaMsgDef maAllSSReqPDUDefs[] = 
{
#if (MAP_VLR || MAP_HLR)

  /* Register SS Request */
  {MAT_REGSS,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maRegSSReqTkns[0]},        /* token element list pointer */

  /* Erase SS Request */
  {MAT_ERASESS,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maEraseSSReqTkns[0]},        /* token element list pointer */

  /* Activate SS Request */
  {MAT_ACTVSS,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maActvSSReqTkns[0]},        /* token element list pointer */

  /* Deactivate SS Request */
  {MAT_DACTVSS,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maDactvSSReqTkns[0]},        /* token element list pointer */

  /* Interrogate SS Request */
  {MAT_INTERSS,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maInterSSReqTkns[0]},        /* token element list pointer */
  
  /* Register Password Request */
  {MAT_REGPASSWD,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maRegPasswdReqTkns[0]},    /* token element list pointer */
  
  /* Get Password Request */
  {MAT_GETPASSWD,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maGetPasswdReqTkns[0]},    /* token element list pointer */
  
  /* Process Unstructured SS Request */
  {MAT_PROCUSSREQ,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maProcUSSReqReqTkns[0]},    /* token element list pointer */
  
  /* Process Unstructured Data Request */
  {MAT_PROCUSSDATA,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maProcUSSDatReqTkns[0]},    /* token element list pointer */
  
  /* Unstructured SS Request */
  {MAT_USSREQ,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maUSSReqReqTkns[0]},        /* token element list pointer */
  
  /* Unstructured SS Notify Request */
  {MAT_USSNOTIFY,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maUSSNotifyReqTkns[0]},    /* token element list pointer */
#endif /* VLR || HLR */
  
#if (MAP_VLR || MAP_HLR || MAP_GSN)
  /* Ready For SM Request */
  {MAT_SMRDY,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSMRdyReqTkns[0]},        /* token element list pointer */
#endif /* MAP_VLR || MAP_HLR  || MAP_GSN */

  /* B interface operation */
#if MAP_MSC
  /* Detach IMSI request */
  {MAT_DET_IMSI,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maDetIMSIReqTkns[0]},        /* token element list pointer */
#endif   /* MSC */

#if (MAP_MSC || MAP_VLR || MAP_GSN)
  /* Check IMEI Request */
  {MAT_CHKIMEI,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maChkIMEIReqTkns[0]},      /* token element list pointer */
#endif /* MAP_MSC || MAP_VLR || MAP_GSN */
  
#if MAP_MSC
  /* Trace Subscriber Activity Request */
  {MAT_TRACESUBSACTV,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maTrSubsActvReqTkns[0]},      /* token element list pointer */
#endif   /* MSC */

#if (MAP_MSC || MAP_HLR)
  /* Send Routing Info Request */
  {MAT_ROUTINFO,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maRoutInfoReqTkns[0]},    /* token element list pointer */
  
  /* Send Routing Info For SM Request */
  {MAT_ROUTINFOSM,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maRoutInfoSMReqTkns[0]},    /* token element list pointer */
  
  /* Report For SM Delivery Request */
  {MAT_SMDEL,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSMDelReqTkns[0]},        /* token element list pointer */
  
  /* Alert Service Center Request */
  {MAT_ALRTSC,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maAlrtSCReqTkns[0]},        /* token element list pointer */
  
  /* Inform Service Center Request */
  {MAT_INFSC,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maInfSCReqTkns[0]},        /* token element list pointer */

  /* Alert Service Center Without Result */
  {MAT_ALRTSCWRSLT,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maAlrtSCWRsltReqTkns[0]},      /* token element list pointer */

  /* SS Invocation Notify        */
  {MAT_SSINV_NOTIFY,     /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSsInvNotifyReqTkns[0]},        /* token element list pointer */
#endif    /* MSC || HLR */

#if (MAP_VLR || MAP_HLR)
  /* Update Location Request */
  {MAT_UPLOC,            /* Message type */
  &maMsgFlgs0[0],         /* Message flags */
  &maUpLocReqTkns[0]},        /* token element list pointer */
#endif /* MAP_VLR || MAP_HLR */
 
#if (MAP_VLR || MAP_HLR || MAP_GSN)
  /* Cancel Location Request */
  {MAT_CANCELLOC,                /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maCancelLocReqTkns[0]},       /* token element list pointer */

  /* Purge MS Request */
  {MAT_PURGE,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maPurgeReqTkns[0]},        /* token element list pointer */

  /* Send Authentication Info Request */
  {MAT_AUTHINFO,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maAuthInfoReqTkns[0]},        /* token element list pointer */

  /* Insert Subscriber Data Request */
  {MAT_INSSUBSDATA,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maInsSubsDataReqTkns[0]},      /* token element list pointer */

  /* Delete Subscriber Data Request */
  {MAT_DELSUBSDATA,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maDelSubsDataReqTkns[0]},      /* token element list pointer */

  /* Reset request */
  {MAT_RESET,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maResetReqTkns[0]},          /* token element list pointer */
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */
 
#if (MAP_VLR || MAP_HLR)
  /* Restore Data Request */
  {MAT_RESTOREDATA,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maRestDatReqTkns[0]},      /* token element list pointer */
#endif /* MAP_VLR || MAP_HLR */
 
#if (MAP_VLR || MAP_HLR || MAP_GSN)
  /* Activate Trace Mode Request */
  {MAT_ACTVTRACE,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maActvTrReqTkns[0]},      /* token element list pointer */

  /* Deactivate Trace Mode Request */
  {MAT_DACTVTRACE,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maDactvTrReqTkns[0]},      /* token element list pointer */
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */
 
#if (MAP_VLR || MAP_HLR)
  /* Send IMSI Request */
  {MAT_SNDIMSI,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSndIMSIReqTkns[0]},     /* token element list pointer */

  /* Begin Subscriber Activity Request */
  {MAT_BEGIN_SUBS_ACTV,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maBgnSubsActvReqTkns[0]},    /* token element list pointer */

  /* Note Subscriber Present */
  {MAT_NOTSUBPRES,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maNotSubPresReqTkns[0]},      /* token element list pointer */
#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
  /* Send Parameters */
  {MAT_SNDPARAM,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSndParamReqTkns[0]},      /* token element list pointer */
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR)
  /* Provide Roaming Number */
  {MAT_PROVROAMNMB,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maProvRoamNmbReqTkns[0]},      /* token element list pointer */

  /* Set Reporting State         */
  {MAT_SETRPTSTATE,      /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSetRptStateReqTkns[0]},        /* token element list pointer */

  /* Status Report               */
  {MAT_STARPT,           /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maStaRptReqTkns[0]},        /* token element list pointer */

  /* Remote User Free            */
  {MAT_RMTUSRFREE,       /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maRmtUsrFreeReqTkns[0]},        /* token element list pointer */
#endif  /* (VLR) || (HLR) */
 
#if (MAP_VLR || MAP_HLR)
  /* Register CC Entry           */
  {MAT_REGCCENT,         /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maRegCcEntReqTkns[0]},        /* token element list pointer */

  /* Erase  CC Entry           */
  {MAT_ERASECCENT,         /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maEraseCcEntReqTkns[0]},        /* token element list pointer */
#endif /* MAP_VLR || MAP_HLR */
 
#if MAP_MSC
  /* Prepare Handover Request */
  {MAT_PRE_HO,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maPreHoReqTkns[0]},        /* token element list pointer */

  /* Perform Handover Request */
  {MAT_PER_HO,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maPerHoReqTkns[0]},        /* token element list pointer */

  /* Send End Signal Request */
  {MAT_SNDENDSIG,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSndEndSigReqTkns[0]},        /* token element list pointer */
  
  /* Process Access Signalling Request */
  {MAT_PROCACCSIG,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maProcAccSigReqTkns[0]},       /* token element list pointer */
  
  /* Forward Access Signalling Request */
  {MAT_FWDACCSIG,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maFwdAccSigReqTkns[0]},       /* token element list pointer */
  
  /* Preapre Subsequent Handover Request */
  {MAT_PRE_SUBSHO,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maPreSubsHoReqTkns[0]},       /* token element list pointer */
  
  /* Perform Subsequent Handover Request */
  {MAT_PER_SUBSHO,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maPerSubsHoReqTkns[0]},       /* token element list pointer */
  
  /* Note Internal Handover Request */
  {MAT_NOTEINTERHO,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maNoteInterHoReqTkns[0]},       /* token element list pointer */
#endif /* MAP_MSC */
 
#if (MAP_MSC || MAP_GSN)
  /* Forward Short Message Service Request */
  {MAT_FWDSM,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maFwdSMReqTkns[0]},       /* token element list pointer */

  /* MT-Forward Short Message Service Request */
  {MAT_MT_FWDSM,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maMtFwdSMReqTkns[0]},       /* token element list pointer */
#endif /* MAP_MSC || MAP_GSN */
 
#if MAP_MSC
  /* Resume Call Handling        */
  {MAT_RESCALLHANDL,     /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maResCallHandlReqTkns[0]},        /* token element list pointer */

  /* Prepare Group Call          */
  {MAT_PREP_GRPCALL,     /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maPrepGrpCallReqTkns[0]},        /* token element list pointer */

  /* Process Group Call Signalling */
  {MAT_PRO_GRPCALLSIG,   /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maProGrpCallSigReqTkns[0]},        /* token element list pointer */

  /* Forward Group Call Signalling */
  {MAT_FWD_GRPCALLSIG,   /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maFwdGrpCallSigReqTkns[0]},        /* token element list pointer */

  /* Send Group Call End Signal  */
  {MAT_SND_GRPCALLENDSIG,/* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSndGrpCallEndSigReqTkns[0]},        /* token element list pointer */

  /* Provide SIWFS Number    */
  {MAT_PROV_SIWFS_NMB,   /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maProvSiwfsNmbReqTkns[0]},        /* token element list pointer */

  /* SIWFS Signalling Modify     */
  {MAT_SIWFS_SIGMOD,     /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSiwfsSigModReqTkns[0]},        /* token element list pointer */

#endif  /* MSC */

#if MAP_VLR
  /* Send Identification Request */
  {MAT_SNDID,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSndIdReqTkns[0]},        /* token element list pointer */

#endif  /* MAP_VLR */
#if (MAP_HLR || MAP_MLC)

  /* Any Time Interrogation      */
  {MAT_ANY_INTER,         /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maAnyInterReqTkns[0]},        /* token element list pointer */
#endif /* MAP_HLR || MAP_MLC */

#if (MAP_HLR || MAP_GSN)
  /* Update GPRS Location Req.   */
  {MAT_GPRS_UPLOC,       /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maGprsUpLocReqTkns[0]},        /* token element list pointer */

  /* Send Routing Info For GPRS  */
  {MAT_GPRS_ROUTINFO,    /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maGprsRoutInfoReqTkns[0]},        /* token element list pointer */

  /* Note MS Present for GPRS    */
  {MAT_GPRS_NOTEMSPRES,   /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maGprsNoteMsPresReqTkns[0]},        /* token element list pointer */

  /* Failure Report              */
  {MAT_FAILRPT,           /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maFailRptReqTkns[0]},        /* token element list pointer */
#endif  /*(MAP_HLR || MAP_GSN)*/

#if (MAP_VLR || MAP_HLR || MAP_GSN)
#if (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5))

  /* Provide Subscriber Info     */
  {MAT_PROVSUBSINFO,     /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maProvSubsInfoReqTkns[0]},        /* token element list pointer */
#endif  /* (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5)) */
#endif  /*(MAP_VLR || MAP_HLR)*/

#if (MAP_REL98 || MAP_REL99)
#if (MAP_HLR || MAP_MLC)
  /* Send Routing Info For LCS */
  {MAT_SENDROUTINFOFORLCS,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maRoutInfoForLcsReqTkns[0]},     /* token element list pointer */
#endif /* MAP_HLR || MAP_MLC */

#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL99 && MAP_REL4 && MAP_GSN))
  {MAT_PROVSUBSLOC,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maPrvSubsLocReqTkns[0]},     /* token element list pointer */

  {MAT_SUBSLOCRPT,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maSubsLocRptReqTkns[0]},     /* token element list pointer */

#endif /* MAP_MSC || MAP_MLC */
#endif
#endif /* MAP_REL98 || MAP_REL99 */

#if MAP_REL99
#if (MAP_VLR || MAP_HLR || MAP_GSN)

  /* Send Authentication Failure Report Request */
  {MAT_AUTHFAILRPT,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maAuthFailRptReqTkns[0]},     /* token element list pointer */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR || MAP_GSN)

  /* Note MM Event request */
  {MAT_NOTE_MMEVT,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maNoteMmEventReqTkns[0]},     /* token element list pointer */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_MSC || MAP_HLR)

  /* IST alerting request */
  {MAT_IST_ALERT,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maIstAlertReqTkns[0]},     /* token element list pointer */

  /* IST command request */
  {MAT_IST_COMMAND,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maIstCmdReqTkns[0]},     /* token element list pointer */

#endif /* MAP_MSC || MAP_HLR */

#if MAP_HLR

  /* Anytime subscription Interrogation request */
  {MAT_ANY_SUBSDATA_INTER,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maAnyTimeSubsInterroReqTkns[0]},     /* token element list pointer */

  /* Anytime Modification */
  {MAT_ANY_MOD,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maAnyTimeModReqTkns[0]},     /* token element list pointer */

  /* Note subscriber data modified */
  {MAT_NOTE_SUBSDATA_MOD,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maNoteSubsDataModReqTkns[0]},     /* token element list pointer */

#endif /* MAP_HLR */

#if MAP_REL6
#if MAP_MSC
  /* Release Resources request */
  {MAT_REL_RES,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maRelResReqTkns[0]},     /* token element list pointer */
#endif /* MAP_MSC */
#endif /* MAP_REL6 */

#if MAP_SEC

  /* Secure transport request */

  {MAT_SEC_TRANS_CLASS1,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maSecTransTkns[0]},     /* token element list pointer */

  {MAT_SEC_TRANS_CLASS2,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maSecTransTkns[0]},     /* token element list pointer */

  {MAT_SEC_TRANS_CLASS3,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maSecTransTkns[0]},     /* token element list pointer */

  {MAT_SEC_TRANS_CLASS4,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maSecTransTkns[0]},     /* token element list pointer */

#endif 
#endif /* MAP_REL99 */
#ifdef XWEXT /* xingzhou.xu: added for paging detect 2006/10/16 */
  {MAT_PAGING_DETECT,               /* Message type */
  &maMsgFlgs0[0],                   /* Message flags */
  &maXWPagingDetectReqTkns[0]},     /* token element list pointer */
#endif
};

PUBLIC MaMsgDef maAllSSRspPDUDefs[] = 
{
#if (MAP_VLR || MAP_HLR)

  /* Register SS Response */
  {MAT_REGSS,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maRegSSRspTkns[0]},        /* token element list pointer */
  
  /* Erase SS Response */
  {MAT_ERASESS,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maEraseSSRspTkns[0]},        /* token element list pointer */
  
  /* Activate SS Response */
  {MAT_ACTVSS,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maActvSSRspTkns[0]},        /* token element list pointer */

  /* Deactivate SS Response */
  {MAT_DACTVSS,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maDactvSSRspTkns[0]},        /* token element list pointer */

  /* Interrogate SS Response */
  {MAT_INTERSS,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maInterSSRspTkns[0]},        /* token element list pointer */

  /* Register Password Response */
  {MAT_REGPASSWD,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maRegPasswdRspTkns[0]},    /* token element list pointer */

  /* Get Password Response */
  {MAT_GETPASSWD,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maGetPasswdRspTkns[0]},    /* token element list pointer */

  /* Process Unstructured SS Response */
  {MAT_PROCUSSREQ,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maProcUSSReqRspTkns[0]},        /* token element list pointer */

  /* Process Unstructured SS Response */
  {MAT_PROCUSSDATA,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maProcUSSDatRspTkns[0]},    /* token element list pointer */

  /* Unstructured SS Response */
  {MAT_USSREQ,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maUSSReqRspTkns[0]},        /* token element list pointer */

#endif /* VLR || HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
  /* SM Ready */
  {MAT_SMRDY,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSMRdyRspTkns[0]},        /* token element list pointer */
#endif /* VLR || HLR || MAP_GSN */

#if (MAP_MSC || MAP_VLR || MAP_GSN)
  /*  Check IMEI Response */
  {MAT_CHKIMEI,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maChkIMEIRspTkns[0]},      /* token element list pointer */
#endif   /* MAP_MSC || MAP_VLR || MAP_GSN */

#if (MAP_MSC || MAP_HLR)
  /*  Send Routing Info Response */
  {MAT_ROUTINFO,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maRoutInfoRspTkns[0]},    /* token element list pointer */

  /* Send Routing Info For SM Response */
  {MAT_ROUTINFOSM,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maRoutInfoSMRspTkns[0]},    /* token element list pointer */

  /* Report For SM Delivery Response */
  {MAT_SMDEL,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSMDelRspTkns[0]},        /* token element list pointer */

  /* SS Invocation Notify        */
  {MAT_SSINV_NOTIFY,         /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSsInvNotifyRspTkns[0]},        /* token element list pointer */
#endif    /* MSC || HLR */

#if (MAP_VLR || MAP_HLR)
  /* Update Location Response */
  {MAT_UPLOC,            /* Message type */
  &maMsgFlgs0[0],                 /* Message flags */
  &maUpLocRspTkns[0]},        /* token element list pointer */
#endif /* MAP_VLR || MAP_HLR */
 
#if (MAP_VLR || MAP_HLR || MAP_GSN)
  /* Cancel Location Response */
  {MAT_CANCELLOC,        /* Message type */
  &maMsgFlgs0[0],                 /* Message flags */
  &maCancelLocRspTkns[0]},        /* token element list pointer */

  /* Purge MS Response */
  {MAT_PURGE,            /* Message type */
  &maMsgFlgs0[0],      /* Message flags */
  &maPurgeRspTkns[0]},  /* token element list pointer */

  /* Send Authentication Info Response */
  {MAT_AUTHINFO,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maAuthInfoRspTkns[0]},        /* token element list pointer */

  /* Insert Subscriber Data Response */
  {MAT_INSSUBSDATA,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maInsSubsDataRspTkns[0]},      /* token element list pointer */

  /* Delete Subscriber Data Response */
  {MAT_DELSUBSDATA,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maDelSubsDataRspTkns[0]},      /* token element list pointer */
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */
 
#if (MAP_VLR || MAP_HLR)
  /* Restore Data Response */
  {MAT_RESTOREDATA,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maRestDatRspTkns[0]},      /* token element list pointer */
#endif /* MAP_VLR || MAP_HLR */
 
#if (MAP_VLR || MAP_HLR || MAP_GSN)
  /* Activate Trace        */
  {MAT_ACTVTRACE    ,      /* Message index */
  &maMsgFlgs0[0],               /* Message flags */
  &maActvTrRspTkns[0]},      /* token element list pointer */

  /* Deactivate Trace      */
  {MAT_DACTVTRACE,     /* Message index */
  &maMsgFlgs0[0],               /* Message flags */
  &maDactvTrRspTkns[0]},      /* token element list pointer */
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */
 
#if (MAP_VLR || MAP_HLR)
  /* Send IMSI Response */
  {MAT_SNDIMSI,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSndIMSIRspTkns[0]},     /* token element list pointer */
#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
  /* Send Parameters */
  {MAT_SNDPARAM,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSndParamRspTkns[0]},      /* token element list pointer */
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR)
  /* Provide Roaming Number */
  {MAT_PROVROAMNMB,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maProvRoamNmbRspTkns[0]},      /* token element list pointer */

  /* Set Reporting State         */
  {MAT_SETRPTSTATE,      /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSetRptStateRspTkns[0]},        /* token element list pointer */

  /* Status Report               */
  {MAT_STARPT    ,       /* Message type */
  &maMsgFlgs0[0],      /* Message flags */
  &maStaRptRspTkns[0]}, /* token element list pointer */

  /* Remote User Free            */
  {MAT_RMTUSRFREE,       /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maRmtUsrFreeRspTkns[0]},        /* token element list pointer */
#endif  /* (VLR) || (HLR) */
 
#if (MAP_VLR || MAP_HLR)
  /* Register CC Entry           */
  {MAT_REGCCENT,         /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maRegCcEntRspTkns[0]},        /* token element list pointer */

  /* Erase    CC Entry           */
  {MAT_ERASECCENT,            /* Message type */
  &maMsgFlgs0[0],           /* Message flags */
  &maEraseCcEntRspTkns[0]},  /* token element list pointer */
#endif /* MAP_VLR || MAP_HLR */
 
#if MAP_MSC
  /* Prepare Handover Response */
  {MAT_PRE_HO,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maPreHoRspTkns[0]},        /* token element list pointer */
  
  /* Perform Handover Response */
  {MAT_PER_HO,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maPerHoRspTkns[0]},        /* token element list pointer */

#if MAP_REL99
  /* Send End Signal Response */
  {MAT_SNDENDSIG,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSndEndSigRspTkns[0]},        /* token element list pointer */
#endif /* MAP_REL99 */

  /* Preapre Subsequent Handover Response */
  {MAT_PRE_SUBSHO,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maPreSubsHoRspTkns[0]},       /* token element list pointer */
  
  /* Perform Subsequent Handover Response */
  {MAT_PER_SUBSHO,        /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maPerSubsHoRspTkns[0]},       /* token element list pointer */
#endif /* MAP_MSC */
 
#if (MAP_MSC || MAP_GSN)
  /* Forward Short Message Service Request */
  {MAT_FWDSM,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maFwdSMRspTkns[0]},       /* token element list pointer */

  /* MO-Forward Short Message Service Request */
  {MAT_MT_FWDSM,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maMtFwdSMRspTkns[0]},       /* token element list pointer */
#endif /* MAP_MSC || MAP_GSN */
 
#if MAP_MSC
  /* Resume Call Handling  Message Service Request */
  {MAT_RESCALLHANDL,             /* Message type */
  &maMsgFlgs0[0],              /* Message flags */
  &maResCallHandlRspTkns[0]},   /* token element list pointer */

  /* Prepare Group Call          */
  {MAT_PREP_GRPCALL,     /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maPrepGrpCallRspTkns[0]},        /* token element list pointer */

  /* Send Group Call End Signal  */
  {MAT_SND_GRPCALLENDSIG,/* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSndGrpCallEndSigRspTkns[0]},        /* token element list pointer */

  /* Provide SIWFS Number    */
  {MAT_PROV_SIWFS_NMB,   /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maProvSiwfsNmbRspTkns[0]},        /* token element list pointer */

  /* SIWFS Signalling Modify     */
  {MAT_SIWFS_SIGMOD,     /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSiwfsSigModRspTkns[0]},        /* token element list pointer */
#endif  /* MSC */

#if MAP_VLR
  /* Send Identification Response */
  {MAT_SNDID,            /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maSndIdRspTkns[0]},        /* token element list pointer */
#endif  /*MAP_VLR */

#if (MAP_HLR || MAP_MLC)
  /* Any Time Interrogation      */
  {MAT_ANY_INTER,         /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maAnyInterRspTkns[0]},        /* token element list pointer */
#endif /* MAP_HLR || MAP_MLC */

#if (MAP_HLR || MAP_GSN)
  /* Update GPRS Location Rsp.   */
  {MAT_GPRS_UPLOC,       /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maGprsUpLocRspTkns[0]},        /* token element list pointer */

  /* Send Routing Info For GPRS  */
  {MAT_GPRS_ROUTINFO,    /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maGprsRoutInfoRspTkns[0]},        /* token element list pointer */

  /* GPRS Note Ms Present Rsp.   */
  {MAT_GPRS_NOTEMSPRES,       /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maGprsNoteMsPresRspTkns[0]},        /* token element list pointer */

  /* Failure Report Rsp          */
  {MAT_FAILRPT,    /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maFailRptRspTkns[0]},        /* token element list pointer */
#endif  /*(MAP_HLR || MAP_GSN)*/

#if (MAP_VLR || MAP_HLR || MAP_GSN)
#if (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5))
  /* Provide Subscriber Info     */
  {MAT_PROVSUBSINFO,     /* Message type */
  &maMsgFlgs0[0],               /* Message flags */
  &maProvSubsInfoRspTkns[0]},        /* token element list pointer */
#endif  /* (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5)) */
#endif  /*(MAP_VLR || MAP_HLR)*/

#if (MAP_REL98 || MAP_REL99)

#if (MAP_HLR || MAP_MLC)
  /* Send Routing Info For LCS */
  {MAT_SENDROUTINFOFORLCS,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maRoutInfoForLcsRspTkns[0]},     /* token element list pointer */
#endif /* MAP_HLR || MAP_MLC */

#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL99 && MAP_REL4 && MAP_GSN))
  {MAT_PROVSUBSLOC,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maPrvSubsLocRspTkns[0]},     /* token element list pointer */

  {MAT_SUBSLOCRPT,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maSubsLocRptRspTkns[0]},     /* token element list pointer */
#endif /* MAP_MSC || MAP_MLC */
#endif

#endif /* MAP_REL98 || MAP_REL99 */

#if MAP_REL99

#if (MAP_VLR || MAP_HLR || MAP_GSN)

  /* Send Authentication Failure Report Response */
  {MAT_AUTHFAILRPT,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maAuthFailRptRspTkns[0]},    /* token element list pointer */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR || MAP_GSN)

  /* Note MM Event response */
  {MAT_NOTE_MMEVT,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maNoteMmEventRspTkns[0]},     /* token element list pointer */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN*/

#if (MAP_MSC || MAP_HLR)

  /* IST alerting response */
  {MAT_IST_ALERT,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maIstAlertRspTkns[0]},     /* token element list pointer */

  /* IST command response */
  {MAT_IST_COMMAND,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maIstCmdRspTkns[0]},     /* token element list pointer */

#endif /* MAP_MSC || MAP_HLR */


#if MAP_HLR

  /* Anytime subscription Interrogation request */
  {MAT_ANY_SUBSDATA_INTER,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maAnyTimeSubsInterroRspTkns[0]},     /* token element list pointer */

  /* Anytime Modification */
  {MAT_ANY_MOD,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maAnyTimeModRspTkns[0]},     /* token element list pointer */

  /* Note subscriber data modified */
  {MAT_NOTE_SUBSDATA_MOD,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maNoteSubsDataModRspTkns[0]},     /* token element list pointer */

#endif /* MAP_HLR */

#if MAP_REL6
#if MAP_MSC
  /* Release Resources response*/
  {MAT_REL_RES,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maRelResRspTkns[0]},     /* token element list pointer */
#endif /* MAP_MSC */
#endif /* MAP_REL6 */
#if MAP_SEC

  /* Secure transport request */

  {MAT_SEC_TRANS_CLASS1,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maSecTransTkns[0]},     /* token element list pointer */

  {MAT_SEC_TRANS_CLASS3,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maSecTransTkns[0]},     /* token element list pointer */

#endif 
#endif /* MAP_REL99 */

#ifdef XWEXT /* xingzhou.xu: added for paging detect 2006/10/16 */
  {MAT_PAGING_DETECT,               /* Message type */
  &maMsgFlgs0[0],                /* Message flags */
  &maXWPagingDetectRspTkns[0]},     /* token element list pointer */
#endif
};

#ifdef XWEXT
MaTknElmtDef * maTstExtConTkns[] = {
                         &maXWExtCont,
			      NULLP,
                   };
	
PUBLIC MaTknElmtDef  **maTstPduDefs[] = {
  &maTstExtConTkns[0],      /* token element list pointer */
};
#endif
/********************************************************************30**

         End of file:     ca_db2.c@@/main/12 - Fri Sep 16 02:48:04 2005

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:

*********************************************************************61*/
/********************************************************************80**
 
  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  aa    1. initial release
 
1.2          ---  aa    1. text changes
 
*********************************************************************81*/
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.3          ---      aa   1. Remove the Message Indexes from the message defination
                              as it is not used
 
             ---       aa  2. Changed the defination of Token elements as 
                              maTeDefFlgs? are changed.
 
             ---       aa  3. Changed the defination of CugSubsSeqOf 
                              from Mand to Opt.

1.4          ---      sg   1. Corrected the maRoutInfoSMRspTkns definition
  
             ---      sg   2. Tag values incorrect for LocInfoLMSI
                              and SM RP PRI for send routing info for SM

1.5          ---      ssk  1. Corrected the array size for FwdFeatLst
  
1.6          ---      ssk  1. phase 2+ gpr release.                   

/main/7      ---      jie  1. update for MAP 1.5 release.

             ---      jie  1. maTeMoFwdSmMsgToSnd definition is added for 
                              version 2 maFwdSMReqTkns.
                           2. Changed maTeAuthInfoReq to optional element.
  
             ---      jie  1. Rolling Upgrade compliance.

             ---      jie  1. Changed FwdSMRsp to optional.
                           2. Changed USSReqRsp to optional.

             ---      jie  1. Change for 3.9.0 REL_99 support.

             ---      yz   1. Correct the size of GgsnAddress.

             ---      jie  1. Change for MAP REL4 support without the MAPsec 
                              feature.

             ---      yz   1. Change SMDelRspChoice to optional.
                           2. Change UlRspChoice to mandatory.
                           3. Change UlrHlrNum to mandatory.

             ---      yz   1. Change to add extCont in dlgPDu.

             ---      jie  2. Change tag for private extension to MA_TAG_SEQ.

             ---      jie  1. changed maTeRiNetSigSeq sequence.

             ---      jie  1. changed definition of extension container.

             ---      jie  1. Corrected tag for maTeAbsSubsRsn.

/main/8      ---      jie  1. update for MAP 1.6 release.

             ---      yz   1. Correct OdbGen range.
                           2. Adding Phase 1 choice component.

             ---      jie  1. Change for 2002/09 rel99/rel4 release.
                           2. Adding Phase 1 choice component.

/main/9      ---      jie  1. update for MAP 1.7 release.

             ---      jie  1. SS User data tag changed to IA5 String.

             ---      jie  1. Phase-1 changes for June-03 specifications 
                              for release 4 & 5

             ---      jie  1. Phase-2 changes for June-03 specifications 
                              for release 4 & 5
/main/11     ---      zj   1. Update for MAP 2.1 release
             ---      st   1. REL5 CR688 implemented.
                           2. Bug fixes in encoding of errors for v4
                              SendRoutingInfoForGPRS response.
                           3. Corrected the definition for CUG
                              Information for Phase 1.
                           4. Enabled MA_MI_PROVSUBSINFO_RSP for REL5
                              GSN.
             ---      st   1. Changes related to Release 5 upgrade 5.10.0
/main/12     ---      rb   1. Updated for MAP sotware release 2.3
				ma001.203	st	  1. Added elemnts MAP+.	
				ma002.203	dv	  1. Guarded with flag MAP_MSC to remove warning
/main/12  ma006.203   dv   1. Moved the definition of maTeRspAddCap under the 
                              flag combination  MAP_VLR || MAP_HLR || MAP_GSN
/main/12  ma008.203   dm   1. To handle the crash in case of -ve suId.
                           2. To Improve the MAP Stack performance  
               		      replacing maBZero with cmZero;
                              which internally call direct system 
                              call(memset()) if not enable 
                              "DONT_USE_SYS_LIB" flag.
			   3. Remove warning and compilation error under
			      various flag combination.
*********************************************************************91*/
