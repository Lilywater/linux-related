#ifndef __MA_INITH__
#define __MA_INITH__
#define TSTINST_0     0          /* instance 0 */
extern  PUBLIC S16 ma_init_fun(SSTskId    tskId);
#endif /*__MA_INITH__*/