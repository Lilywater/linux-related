/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     map - error
  
     Type:     C include file
  
     Desc:     Error defines required by SS7 MAP
  
     File:     ma_err.h
  
     Sid:      ma_err.h@@/main/8 - Fri Sep 16 02:44:43 2005
  
     Prg:      aa
  
*********************************************************************21*/
  
#ifndef __MAERRH__
#define __MAERRH__
  
  
/* defines */

#define MALOGERROR(errCls, errCode, errVal, errDesc) \
    SLogError(maCb.maInit.ent, maCb.maInit.inst, maCb.maInit.procId, __FILE__, __LINE__, \
              errCls, errCode, errVal, errDesc) 

/* ma009.203 : Modification :Changed MALOGERROR macro to SLOGERROR to 
               avoid core dump in case of maCbPtr is NULL */
#ifndef SLOGERROR
#define SLOGERROR  SLogError
#endif

#define   EMA001      (ERRMA +    1)    /*    ca_bdy1.c: 392 */
#define   EMA002      (ERRMA +    2)    /*    ca_bdy1.c: 416 */
#define   EMA003      (ERRMA +    3)    /*    ca_bdy1.c: 434 */
#define   EMA004      (ERRMA +    4)    /*    ca_bdy1.c: 464 */
#define   EMA005      (ERRMA +    5)    /*    ca_bdy1.c:1041 */
#define   EMA006      (ERRMA +    6)    /*    ca_bdy1.c:1174 */
#define   EMA007      (ERRMA +    7)    /*    ca_bdy1.c:1196 */
#define   EMA008      (ERRMA +    8)    /*    ca_bdy1.c:1218 */
#define   EMA009      (ERRMA +    9)    /*    ca_bdy1.c:1747 */
#define   EMA010      (ERRMA +   10)    /*    ca_bdy1.c:1798 */
#define   EMA011      (ERRMA +   11)    /*    ca_bdy1.c:1811 */
#define   EMA012      (ERRMA +   12)    /*    ca_bdy1.c:1825 */
#define   EMA013      (ERRMA +   13)    /*    ca_bdy1.c:1839 */
#define   EMA014      (ERRMA +   14)    /*    ca_bdy1.c:1860 */
#define   EMA015      (ERRMA +   15)    /*    ca_bdy1.c:1878 */
#define   EMA016      (ERRMA +   16)    /*    ca_bdy1.c:1892 */
#define   EMA017      (ERRMA +   17)    /*    ca_bdy1.c:1905 */
#define   EMA018      (ERRMA +   18)    /*    ca_bdy1.c:2034 */
#define   EMA019      (ERRMA +   19)    /*    ca_bdy1.c:2195 */
#define   EMA020      (ERRMA +   20)    /*    ca_bdy1.c:2297 */
#define   EMA021      (ERRMA +   21)    /*    ca_bdy1.c:2408 */
#define   EMA022      (ERRMA +   22)    /*    ca_bdy1.c:2419 */
#define   EMA023      (ERRMA +   23)    /*    ca_bdy1.c:2430 */
#define   EMA024      (ERRMA +   24)    /*    ca_bdy1.c:2439 */
#define   EMA025      (ERRMA +   25)    /*    ca_bdy1.c:2452 */
#define   EMA026      (ERRMA +   26)    /*    ca_bdy1.c:2549 */
#define   EMA027      (ERRMA +   27)    /*    ca_bdy1.c:2559 */
#define   EMA028      (ERRMA +   28)    /*    ca_bdy1.c:2569 */
#define   EMA029      (ERRMA +   29)    /*    ca_bdy1.c:2578 */
#define   EMA030      (ERRMA +   30)    /*    ca_bdy1.c:2598 */
#define   EMA031      (ERRMA +   31)    /*    ca_bdy1.c:2692 */
#define   EMA032      (ERRMA +   32)    /*    ca_bdy1.c:2703 */
#define   EMA033      (ERRMA +   33)    /*    ca_bdy1.c:2714 */
#define   EMA034      (ERRMA +   34)    /*    ca_bdy1.c:2730 */
#define   EMA035      (ERRMA +   35)    /*    ca_bdy1.c:2762 */
#define   EMA036      (ERRMA +   36)    /*    ca_bdy1.c:2783 */
#define   EMA037      (ERRMA +   37)    /*    ca_bdy1.c:2835 */
#define   EMA038      (ERRMA +   38)    /*    ca_bdy1.c:2871 */
#define   EMA039      (ERRMA +   39)    /*    ca_bdy1.c:2885 */
#define   EMA040      (ERRMA +   40)    /*    ca_bdy1.c:2928 */
#define   EMA041      (ERRMA +   41)    /*    ca_bdy1.c:2951 */
#define   EMA042      (ERRMA +   42)    /*    ca_bdy1.c:2976 */
#define   EMA043      (ERRMA +   43)    /*    ca_bdy1.c:2987 */
#define   EMA044      (ERRMA +   44)    /*    ca_bdy1.c:3005 */
#define   EMA045      (ERRMA +   45)    /*    ca_bdy1.c:3017 */
#define   EMA046      (ERRMA +   46)    /*    ca_bdy1.c:3035 */
#define   EMA047      (ERRMA +   47)    /*    ca_bdy1.c:3056 */
#define   EMA048      (ERRMA +   48)    /*    ca_bdy1.c:3108 */
#define   EMA049      (ERRMA +   49)    /*    ca_bdy1.c:3122 */
#define   EMA050      (ERRMA +   50)    /*    ca_bdy1.c:3193 */
#define   EMA051      (ERRMA +   51)    /*    ca_bdy1.c:3621 */
#define   EMA052      (ERRMA +   52)    /*    ca_bdy1.c:4216 */
#define   EMA053      (ERRMA +   53)    /*    ca_bdy1.c:4662 */
#define   EMA054      (ERRMA +   54)    /*    ca_bdy1.c:4887 */
#define   EMA055      (ERRMA +   55)    /*    ca_bdy1.c:5182 */
#define   EMA056      (ERRMA +   56)    /*    ca_bdy1.c:5452 */
#define   EMA057      (ERRMA +   57)    /*    ca_bdy1.c:5534 */
#define   EMA058      (ERRMA +   58)    /*    ca_bdy1.c:5671 */
#define   EMA059      (ERRMA +   59)    /*    ca_bdy1.c:5872 */
#define   EMA060      (ERRMA +   60)    /*    ca_bdy1.c:5910 */
#define   EMA061      (ERRMA +   61)    /*    ca_bdy1.c:6088 */
#define   EMA062      (ERRMA +   62)    /*    ca_bdy1.c:6189 */
#define   EMA063      (ERRMA +   63)    /*    ca_bdy1.c:6340 */
#define   EMA064      (ERRMA +   64)    /*    ca_bdy1.c:6629 */
#define   EMA065      (ERRMA +   65)    /*    ca_bdy1.c:6744 */

#define   EMA066      (ERRMA +   66)    /*    ca_bdy2.c: 508 */
#define   EMA067      (ERRMA +   67)    /*    ca_bdy2.c: 860 */
#define   EMA068      (ERRMA +   68)    /*    ca_bdy2.c: 876 */
#define   EMA069      (ERRMA +   69)    /*    ca_bdy2.c: 901 */
#define   EMA070      (ERRMA +   70)    /*    ca_bdy2.c:1086 */
#define   EMA071      (ERRMA +   71)    /*    ca_bdy2.c:1103 */
#define   EMA072      (ERRMA +   72)    /*    ca_bdy2.c:1128 */
#define   EMA073      (ERRMA +   73)    /*    ca_bdy2.c:1169 */
#define   EMA074      (ERRMA +   74)    /*    ca_bdy2.c:1185 */
#define   EMA075      (ERRMA +   75)    /*    ca_bdy2.c:1209 */
#define   EMA076      (ERRMA +   76)    /*    ca_bdy2.c:1411 */
#define   EMA077      (ERRMA +   77)    /*    ca_bdy2.c:1427 */
#define   EMA078      (ERRMA +   78)    /*    ca_bdy2.c:1469 */
#define   EMA079      (ERRMA +   79)    /*    ca_bdy2.c:1484 */
#define   EMA080      (ERRMA +   80)    /*    ca_bdy2.c:1930 */
#define   EMA081      (ERRMA +   81)    /*    ca_bdy2.c:1960 */
#define   EMA082      (ERRMA +   82)    /*    ca_bdy2.c:1972 */
#define   EMA083      (ERRMA +   83)    /*    ca_bdy2.c:1983 */
#define   EMA084      (ERRMA +   84)    /*    ca_bdy2.c:2026 */
#define   EMA085      (ERRMA +   85)    /*    ca_bdy2.c:2048 */
#define   EMA086      (ERRMA +   86)    /*    ca_bdy2.c:2216 */
#define   EMA087      (ERRMA +   87)    /*    ca_bdy2.c:2231 */
#define   EMA088      (ERRMA +   88)    /*    ca_bdy2.c:2244 */
#define   EMA089      (ERRMA +   89)    /*    ca_bdy2.c:2255 */
#define   EMA090      (ERRMA +   90)    /*    ca_bdy2.c:2267 */
#define   EMA091      (ERRMA +   91)    /*    ca_bdy2.c:2281 */
#define   EMA092      (ERRMA +   92)    /*    ca_bdy2.c:2391 */
#define   EMA093      (ERRMA +   93)    /*    ca_bdy2.c:2406 */
#define   EMA094      (ERRMA +   94)    /*    ca_bdy2.c:2419 */
#define   EMA095      (ERRMA +   95)    /*    ca_bdy2.c:2432 */
#define   EMA096      (ERRMA +   96)    /*    ca_bdy2.c:2444 */
#define   EMA097      (ERRMA +   97)    /*    ca_bdy2.c:2463 */
#define   EMA098      (ERRMA +   98)    /*    ca_bdy2.c:3005 */
#define   EMA099      (ERRMA +   99)    /*    ca_bdy2.c:3014 */
#define   EMA100      (ERRMA +  100)    /*    ca_bdy2.c:3063 */
#define   EMA101      (ERRMA +  101)    /*    ca_bdy2.c:3075 */
#define   EMA102      (ERRMA +  102)    /*    ca_bdy2.c:3088 */
#define   EMA103      (ERRMA +  103)    /*    ca_bdy2.c:3102 */
#define   EMA104      (ERRMA +  104)    /*    ca_bdy2.c:3123 */
#define   EMA105      (ERRMA +  105)    /*    ca_bdy2.c:3310 */
#define   EMA106      (ERRMA +  106)    /*    ca_bdy2.c:3319 */
#define   EMA107      (ERRMA +  107)    /*    ca_bdy2.c:3366 */
#define   EMA108      (ERRMA +  108)    /*    ca_bdy2.c:3378 */
#define   EMA109      (ERRMA +  109)    /*    ca_bdy2.c:3389 */
#define   EMA110      (ERRMA +  110)    /*    ca_bdy2.c:3432 */
#define   EMA111      (ERRMA +  111)    /*    ca_bdy2.c:3450 */
#define   EMA112      (ERRMA +  112)    /*    ca_bdy2.c:3635 */
#define   EMA113      (ERRMA +  113)    /*    ca_bdy2.c:3652 */
#define   EMA114      (ERRMA +  114)    /*    ca_bdy2.c:3684 */
#define   EMA115      (ERRMA +  115)    /*    ca_bdy2.c:4017 */
#define   EMA116      (ERRMA +  116)    /*    ca_bdy2.c:4025 */
#define   EMA117      (ERRMA +  117)    /*    ca_bdy2.c:4045 */
#define   EMA118      (ERRMA +  118)    /*    ca_bdy2.c:4063 */
#define   EMA119      (ERRMA +  119)    /*    ca_bdy2.c:4083 */
#define   EMA120      (ERRMA +  120)    /*    ca_bdy2.c:4151 */
#define   EMA121      (ERRMA +  121)    /*    ca_bdy2.c:4161 */
#define   EMA122      (ERRMA +  122)    /*    ca_bdy2.c:4170 */
#define   EMA123      (ERRMA +  123)    /*    ca_bdy2.c:4179 */
#define   EMA124      (ERRMA +  124)    /*    ca_bdy2.c:4189 */
#define   EMA125      (ERRMA +  125)    /*    ca_bdy2.c:4218 */
#define   EMA126      (ERRMA +  126)    /*    ca_bdy2.c:4231 */
#define   EMA127      (ERRMA +  127)    /*    ca_bdy2.c:4296 */
#define   EMA128      (ERRMA +  128)    /*    ca_bdy2.c:4304 */
#define   EMA129      (ERRMA +  129)    /*    ca_bdy2.c:4314 */
#define   EMA130      (ERRMA +  130)    /*    ca_bdy2.c:4322 */
#define   EMA131      (ERRMA +  131)    /*    ca_bdy2.c:4339 */
#define   EMA132      (ERRMA +  132)    /*    ca_bdy2.c:4349 */
#define   EMA133      (ERRMA +  133)    /*    ca_bdy2.c:4364 */
#define   EMA134      (ERRMA +  134)    /*    ca_bdy2.c:4373 */
#define   EMA135      (ERRMA +  135)    /*    ca_bdy2.c:4395 */
#define   EMA136      (ERRMA +  136)    /*    ca_bdy2.c:4481 */
#define   EMA137      (ERRMA +  137)    /*    ca_bdy2.c:4636 */
#define   EMA138      (ERRMA +  138)    /*    ca_bdy2.c:4664 */
#define   EMA139      (ERRMA +  139)    /*    ca_bdy2.c:4677 */
#define   EMA140      (ERRMA +  140)    /*    ca_bdy2.c:4695 */
#define   EMA141      (ERRMA +  141)    /*    ca_bdy2.c:4708 */
#define   EMA142      (ERRMA +  142)    /*    ca_bdy2.c:4726 */
#define   EMA143      (ERRMA +  143)    /*    ca_bdy2.c:4834 */
#define   EMA144      (ERRMA +  144)    /*    ca_bdy2.c:5403 */
#define   EMA145      (ERRMA +  145)    /*    ca_bdy2.c:5939 */
#define   EMA146      (ERRMA +  146)    /*    ca_bdy2.c:7972 */
#define   EMA147      (ERRMA +  147)    /*    ca_bdy2.c:8061 */
#define   EMA148      (ERRMA +  148)    /*    ca_bdy2.c:8267 */
#define   EMA149      (ERRMA +  149)    /*    ca_bdy2.c:8310 */
#define   EMA150      (ERRMA +  150)    /*    ca_bdy2.c:8612 */
#define   EMA151      (ERRMA +  151)    /*    ca_bdy2.c:9015 */
#define   EMA152      (ERRMA +  152)    /*    ca_bdy2.c:9059 */
#define   EMA153      (ERRMA +  153)    /*    ca_bdy2.c:9447 */
#define   EMA154      (ERRMA +  154)    /*    ca_bdy2.c:9490 */
#define   EMA155      (ERRMA +  155)    /*    ca_bdy2.c:9617 */
#define   EMA156      (ERRMA +  156)    /*    ca_bdy2.c:10784 */
#define   EMA157      (ERRMA +  157)    /*    ca_bdy2.c:10793 */
#define   EMA158      (ERRMA +  158)    /*    ca_bdy2.c:11574 */
#define   EMA159      (ERRMA +  159)    /*    ca_bdy2.c:18621 */
#define   EMA160      (ERRMA +  160)    /*    ca_bdy2.c:19612 */
#define   EMA161      (ERRMA +  161)    /*    ca_bdy2.c:19731 */
#define   EMA162      (ERRMA +  162)    /*    ca_bdy2.c:19852 */
#define   EMA163      (ERRMA +  163)    /*    ca_bdy2.c:21333 */
#define   EMA164      (ERRMA +  164)    /*    ca_bdy2.c:21354 */
#define   EMA165      (ERRMA +  165)    /*    ca_bdy2.c:21422 */
#define   EMA166      (ERRMA +  166)    /*    ca_bdy2.c:21444 */
#define   EMA167      (ERRMA +  167)    /*    ca_bdy2.c:21464 */
#define   EMA168      (ERRMA +  168)    /*    ca_bdy2.c:21775 */
#define   EMA169      (ERRMA +  169)    /*    ca_bdy2.c:21806 */
#define   EMA170      (ERRMA +  170)    /*    ca_bdy2.c:22419 */

#define   EMA171      (ERRMA +  171)    /*    ca_bdy3.c:10840 */
#define   EMA172      (ERRMA +  172)    /*    ca_bdy3.c:10904 */
#define   EMA173      (ERRMA +  173)    /*    ca_bdy3.c:10917 */
#define   EMA174      (ERRMA +  174)    /*    ca_bdy3.c:11105 */
#define   EMA175      (ERRMA +  175)    /*    ca_bdy3.c:11180 */
#define   EMA176      (ERRMA +  176)    /*    ca_bdy3.c:11400 */
#define   EMA177      (ERRMA +  177)    /*    ca_bdy3.c:11439 */
#define   EMA178      (ERRMA +  178)    /*    ca_bdy3.c:11519 */
#define   EMA179      (ERRMA +  179)    /*    ca_bdy3.c:11535 */
#define   EMA180      (ERRMA +  180)    /*    ca_bdy3.c:11728 */
#define   EMA181      (ERRMA +  181)    /*    ca_bdy3.c:11877 */
#define   EMA182      (ERRMA +  182)    /*    ca_bdy3.c:11909 */
#define   EMA183      (ERRMA +  183)    /*    ca_bdy3.c:12059 */
#define   EMA184      (ERRMA +  184)    /*    ca_bdy3.c:12075 */
#define   EMA185      (ERRMA +  185)    /*    ca_bdy3.c:12121 */
#define   EMA186      (ERRMA +  186)    /*    ca_bdy3.c:12511 */
#define   EMA187      (ERRMA +  187)    /*    ca_bdy3.c:12519 */
#define   EMA188      (ERRMA +  188)    /*    ca_bdy3.c:13398 */
#define   EMA189      (ERRMA +  189)    /*    ca_bdy3.c:13860 */

#define   EMA190      (ERRMA +  190)    /*    ca_bdy4.c:1012 */
#define   EMA191      (ERRMA +  191)    /*    ca_bdy4.c:1028 */
#define   EMA192      (ERRMA +  192)    /*    ca_bdy4.c:1045 */
#define   EMA193      (ERRMA +  193)    /*    ca_bdy4.c:1061 */
#define   EMA194      (ERRMA +  194)    /*    ca_bdy4.c:1076 */
#define   EMA195      (ERRMA +  195)    /*    ca_bdy4.c:1093 */
#define   EMA196      (ERRMA +  196)    /*    ca_bdy4.c:1109 */
#define   EMA197      (ERRMA +  197)    /*    ca_bdy4.c:1128 */
#define   EMA198      (ERRMA +  198)    /*    ca_bdy4.c:1153 */
#define   EMA199      (ERRMA +  199)    /*    ca_bdy4.c:1172 */
#define   EMA200      (ERRMA +  200)    /*    ca_bdy4.c:1195 */
#define   EMA201      (ERRMA +  201)    /*    ca_bdy4.c:1210 */
#define   EMA202      (ERRMA +  202)    /*    ca_bdy4.c:1226 */
#define   EMA203      (ERRMA +  203)    /*    ca_bdy4.c:1245 */
#define   EMA204      (ERRMA +  204)    /*    ca_bdy4.c:1259 */
#define   EMA205      (ERRMA +  205)    /*    ca_bdy4.c:1274 */
#define   EMA206      (ERRMA +  206)    /*    ca_bdy4.c:1290 */
#define   EMA207      (ERRMA +  207)    /*    ca_bdy4.c:1310 */
#define   EMA208      (ERRMA +  208)    /*    ca_bdy4.c:1328 */
#define   EMA209      (ERRMA +  209)    /*    ca_bdy4.c:1343 */
#define   EMA210      (ERRMA +  210)    /*    ca_bdy4.c:1358 */
#define   EMA211      (ERRMA +  211)    /*    ca_bdy4.c:1378 */
#define   EMA212      (ERRMA +  212)    /*    ca_bdy4.c:1407 */
#define   EMA213      (ERRMA +  213)    /*    ca_bdy4.c:1432 */
#define   EMA214      (ERRMA +  214)    /*    ca_bdy4.c:1451 */
#define   EMA215      (ERRMA +  215)    /*    ca_bdy4.c:1465 */
#define   EMA216      (ERRMA +  216)    /*    ca_bdy4.c:1482 */
#define   EMA217      (ERRMA +  217)    /*    ca_bdy4.c:1498 */
#define   EMA218      (ERRMA +  218)    /*    ca_bdy4.c:1513 */
#define   EMA219      (ERRMA +  219)    /*    ca_bdy4.c:1528 */
#define   EMA220      (ERRMA +  220)    /*    ca_bdy4.c:1550 */
#define   EMA221      (ERRMA +  221)    /*    ca_bdy4.c:1562 */
#define   EMA222      (ERRMA +  222)    /*    ca_bdy4.c:3391 */
#define   EMA223      (ERRMA +  223)    /*    ca_bdy4.c:3465 */
#define   EMA224      (ERRMA +  224)    /*    ca_bdy4.c:3484 */
#define   EMA225      (ERRMA +  225)    /*    ca_bdy4.c:3552 */
#define   EMA226      (ERRMA +  226)    /*    ca_bdy4.c:3571 */
#define   EMA227      (ERRMA +  227)    /*    ca_bdy4.c:3580 */
#define   EMA228      (ERRMA +  228)    /*    ca_bdy4.c:3599 */
#define   EMA229      (ERRMA +  229)    /*    ca_bdy4.c:3631 */
#define   EMA230      (ERRMA +  230)    /*    ca_bdy4.c:3648 */
#define   EMA231      (ERRMA +  231)    /*    ca_bdy4.c:3657 */
#define   EMA232      (ERRMA +  232)    /*    ca_bdy4.c:4031 */
#define   EMA233      (ERRMA +  233)    /*    ca_bdy4.c:4040 */
#define   EMA234      (ERRMA +  234)    /*    ca_bdy4.c:4054 */
#define   EMA235      (ERRMA +  235)    /*    ca_bdy4.c:4068 */
#define   EMA236      (ERRMA +  236)    /*    ca_bdy4.c:4088 */
#define   EMA237      (ERRMA +  237)    /*    ca_bdy4.c:4108 */
#define   EMA238      (ERRMA +  238)    /*    ca_bdy4.c:4122 */
#define   EMA239      (ERRMA +  239)    /*    ca_bdy4.c:4141 */
#define   EMA240      (ERRMA +  240)    /*    ca_bdy4.c:4241 */
#define   EMA241      (ERRMA +  241)    /*    ca_bdy4.c:4803 */
#define   EMA242      (ERRMA +  242)    /*    ca_bdy4.c:4824 */
#define   EMA243      (ERRMA +  243)    /*    ca_bdy4.c:4989 */
#define   EMA244      (ERRMA +  244)    /*    ca_bdy4.c:5324 */
#define   EMA245      (ERRMA +  245)    /*    ca_bdy4.c:5334 */
#define   EMA246      (ERRMA +  246)    /*    ca_bdy4.c:5344 */
#define   EMA247      (ERRMA +  247)    /*    ca_bdy4.c:5364 */
#define   EMA248      (ERRMA +  248)    /*    ca_bdy4.c:5388 */
#define   EMA249      (ERRMA +  249)    /*    ca_bdy4.c:5398 */
#define   EMA250      (ERRMA +  250)    /*    ca_bdy4.c:5410 */
#define   EMA251      (ERRMA +  251)    /*    ca_bdy4.c:5422 */
#define   EMA252      (ERRMA +  252)    /*    ca_bdy4.c:5450 */
#define   EMA253      (ERRMA +  253)    /*    ca_bdy4.c:5460 */
#define   EMA254      (ERRMA +  254)    /*    ca_bdy4.c:5594 */
#define   EMA255      (ERRMA +  255)    /*    ca_bdy4.c:5849 */
#define   EMA256      (ERRMA +  256)    /*    ca_bdy4.c:6041 */
#define   EMA257      (ERRMA +  257)    /*    ca_bdy4.c:6209 */
#define   EMA258      (ERRMA +  258)    /*    ca_bdy4.c:6410 */
#define   EMA259      (ERRMA +  259)    /*    ca_bdy4.c:6615 */
#define   EMA260      (ERRMA +  260)    /*    ca_bdy4.c:6841 */
#define   EMA261      (ERRMA +  261)    /*    ca_bdy4.c:6896 */
#define   EMA262      (ERRMA +  262)    /*    ca_bdy4.c:6984 */
#define   EMA263      (ERRMA +  263)    /*    ca_bdy4.c:7183 */
#define   EMA264      (ERRMA +  264)    /*    ca_bdy4.c:7193 */
#define   EMA265      (ERRMA +  265)    /*    ca_bdy4.c:7211 */
#define   EMA266      (ERRMA +  266)    /*    ca_bdy4.c:7226 */
#define   EMA267      (ERRMA +  267)    /*    ca_bdy4.c:7236 */
#define   EMA268      (ERRMA +  268)    /*    ca_bdy4.c:7255 */
#define   EMA269      (ERRMA +  269)    /*    ca_bdy4.c:8132 */
#define   EMA270      (ERRMA +  270)    /*    ca_bdy4.c:8981 */
#define   EMA271      (ERRMA +  271)    /*    ca_bdy4.c:9776 */
#define   EMA272      (ERRMA +  272)    /*    ca_bdy4.c:9821 */
#define   EMA273      (ERRMA +  273)    /*    ca_bdy4.c:9863 */
#define   EMA274      (ERRMA +  274)    /*    ca_bdy4.c:9903 */
#define   EMA275      (ERRMA +  275)    /*    ca_bdy4.c:9945 */

#define   EMA276      (ERRMA +  276)    /*   ca_ex_ms.c: 263 */
#define   EMA277      (ERRMA +  277)    /*   ca_ex_ms.c: 275 */
#define   EMA278      (ERRMA +  278)    /*   ca_ex_ms.c: 528 */
#define   EMA279      (ERRMA +  279)    /*   ca_ex_ms.c: 560 */
#define   EMA280      (ERRMA +  280)    /*   ca_ex_ms.c: 611 */

#define   EMA281      (ERRMA +  281)    /*      ca_mf.c: 516 */
#define   EMA282      (ERRMA +  282)    /*      ca_mf.c: 690 */
#define   EMA283      (ERRMA +  283)    /*      ca_mf.c: 811 */
#define   EMA284      (ERRMA +  284)    /*      ca_mf.c: 852 */
#define   EMA285      (ERRMA +  285)    /*      ca_mf.c: 922 */
#define   EMA286      (ERRMA +  286)    /*      ca_mf.c:1061 */
#define   EMA287      (ERRMA +  287)    /*      ca_mf.c:1325 */
#define   EMA288      (ERRMA +  288)    /*      ca_mf.c:1516 */
#define   EMA289      (ERRMA +  289)    /*      ca_mf.c:1613 */
#define   EMA290      (ERRMA +  290)    /*      ca_mf.c:1683 */
#define   EMA291      (ERRMA +  291)    /*      ca_mf.c:1761 */
#define   EMA292      (ERRMA +  292)    /*      ca_mf.c:1852 */
#define   EMA293      (ERRMA +  293)    /*      ca_mf.c:2008 */
#define   EMA294      (ERRMA +  294)    /*      ca_mf.c:2138 */
#define   EMA295      (ERRMA +  295)    /*      ca_mf.c:2284 */
#define   EMA296      (ERRMA +  296)    /*      ca_mf.c:3244 */
#define   EMA297      (ERRMA +  297)    /*      ca_mf.c:3339 */
#define   EMA298      (ERRMA +  298)    /*      ca_mf.c:3673 */
#define   EMA299      (ERRMA +  299)    /*      ca_mf.c:3727 */
#define   EMA300      (ERRMA +  300)    /*      ca_mf.c:3798 */
#define   EMA301      (ERRMA +  301)    /*      ca_mf.c:4794 */
#define   EMA302      (ERRMA +  302)    /*      ca_mf.c:5147 */
#define   EMA303      (ERRMA +  303)    /*      ca_mf.c:5232 */
#define   EMA304      (ERRMA +  304)    /*      ca_mf.c:5392 */
#define   EMA305      (ERRMA +  305)    /*      ca_mf.c:5685 */
#define   EMA306      (ERRMA +  306)    /*      ca_mf.c:5853 */
#define   EMA307      (ERRMA +  307)    /*      ca_mf.c:6289 */
#define   EMA308      (ERRMA +  308)    /*      ca_mf.c:6304 */
#define   EMA309      (ERRMA +  309)    /*      ca_mf.c:6317 */
#define   EMA310      (ERRMA +  310)    /*      ca_mf.c:8074 */
#define   EMA311      (ERRMA +  311)    /*      ca_mf.c:9013 */
#define   EMA312      (ERRMA +  312)    /*      ca_mf.c:9158 */
#define   EMA313      (ERRMA +  313)    /*      ca_mf.c:9370 */
#define   EMA314      (ERRMA +  314)    /*      ca_mf.c:10846 */
#define   EMA315      (ERRMA +  315)    /*      ca_mf.c:11204 */
#define   EMA316      (ERRMA +  316)    /*      ca_mf.c:11250 */
#define   EMA317      (ERRMA +  317)    /*      ca_mf.c:11883 */
#define   EMA318      (ERRMA +  318)    /*      ca_mf.c:12103 */
#define   EMA319      (ERRMA +  319)    /*      ca_mf.c:12216 */
#define   EMA320      (ERRMA +  320)    /*      ca_mf.c:12339 */
#define   EMA321      (ERRMA +  321)    /*      ca_mf.c:12485 */
#define   EMA322      (ERRMA +  322)    /*      ca_mf.c:12806 */
#define   EMA323      (ERRMA +  323)    /*      ca_mf.c:12930 */
#define   EMA324      (ERRMA +  324)    /*      ca_mf.c:12990 */
#define   EMA325      (ERRMA +  325)    /*      ca_mf.c:13068 */
#define   EMA326      (ERRMA +  326)    /*      ca_mf.c:13349 */
#define   EMA327      (ERRMA +  327)    /*      ca_mf.c:13509 */
#define   EMA328      (ERRMA +  328)    /*      ca_mf.c:13577 */
#define   EMA329      (ERRMA +  329)    /*      ca_mf.c:13660 */
#define   EMA330      (ERRMA +  330)    /*      ca_mf.c:13957 */

#define   EMA331      (ERRMA +  331)    /*         ma.h: 295 */

#define   EMA332      (ERRMA +  332)    /*    ma_acc1.c:6290 */

#define   EMA332      (ERRMA +  332)    /*      ma_mf.h: 914 */
#define   EMA333      (ERRMA +  333)    /*      ma_mf.h: 924 */
#define   EMA334      (ERRMA +  334)    /*      ma_mf.h: 936 */

#define   EMA335      (ERRMA +  335)    /*    ma_ptli.c: 717 */
#define   EMA336      (ERRMA +  336)    /*    ma_ptli.c: 754 */
#define   EMA337      (ERRMA +  337)    /*    ma_ptli.c: 804 */
#define   EMA338      (ERRMA +  338)    /*    ma_ptli.c: 869 */
#define   EMA339      (ERRMA +  339)    /*    ma_ptli.c: 910 */
#define   EMA340      (ERRMA +  340)    /*    ma_ptli.c: 951 */

#define   EMA341      (ERRMA +  341)    /*    ma_ptmi.c: 579 */
#define   EMA342      (ERRMA +  342)    /*    ma_ptmi.c: 613 */
#define   EMA343      (ERRMA +  343)    /*    ma_ptmi.c: 649 */
#define   EMA344      (ERRMA +  344)    /*    ma_ptmi.c: 683 */
#define   EMA345      (ERRMA +  345)    /*    ma_ptmi.c: 719 */
#define   EMA346      (ERRMA +  346)    /*    ma_ptmi.c: 754 */
#define   EMA347      (ERRMA +  347)    /*    ma_ptmi.c: 794 */

#define   EMA348      (ERRMA +  348)    /*    ma_ptui.c:3052 */
#define   EMA349      (ERRMA +  349)    /*    ma_ptui.c:3091 */
#define   EMA350      (ERRMA +  350)    /*    ma_ptui.c:3130 */
#define   EMA351      (ERRMA +  351)    /*    ma_ptui.c:3167 */
#define   EMA352      (ERRMA +  352)    /*    ma_ptui.c:3206 */
#define   EMA353      (ERRMA +  353)    /*    ma_ptui.c:3245 */
#define   EMA354      (ERRMA +  354)    /*    ma_ptui.c:3282 */
#define   EMA355      (ERRMA +  355)    /*    ma_ptui.c:3323 */
#define   EMA356      (ERRMA +  356)    /*    ma_ptui.c:3375 */
#define   EMA357      (ERRMA +  357)    /*    ma_ptui.c:3427 */
#define   EMA358      (ERRMA +  358)    /*    ma_ptui.c:3466 */
#define   EMA359      (ERRMA +  359)    /*    ma_ptui.c:3518 */
#define   EMA360      (ERRMA +  360)    /*    ma_ptui.c:3565 */
#define   EMA361      (ERRMA +  361)    /*    ma_ptui.c:3618 */
#define   EMA362      (ERRMA +  362)    /*    ma_ptui.c:3661 */
#define   EMA363      (ERRMA +  363)    /*    ma_ptui.c:3713 */
#define   EMA364      (ERRMA +  364)    /*    ma_ptui.c:3761 */
#define   EMA365      (ERRMA +  365)    /*    ma_ptui.c:3809 */
#define   EMA366      (ERRMA +  366)    /*    ma_ptui.c:3858 */
#define   EMA367      (ERRMA +  367)    /*    ma_ptui.c:3910 */
#define   EMA368      (ERRMA +  368)    /*    ma_ptui.c:3958 */
#define   EMA369      (ERRMA +  369)    /*    ma_ptui.c:4010 */
#define   EMA370      (ERRMA +  370)    /*    ma_ptui.c:4057 */
#define   EMA371      (ERRMA +  371)    /*    ma_ptui.c:4104 */
#define   EMA372      (ERRMA +  372)    /*    ma_ptui.c:4151 */
#define   EMA373      (ERRMA +  373)    /*    ma_ptui.c:4201 */
#define   EMA374      (ERRMA +  374)    /*    ma_ptui.c:4250 */
#define   EMA375      (ERRMA +  375)    /*    ma_ptui.c:4302 */
#define   EMA376      (ERRMA +  376)    /*    ma_ptui.c:4349 */
#define   EMA377      (ERRMA +  377)    /*    ma_ptui.c:4396 */
#define   EMA378      (ERRMA +  378)    /*    ma_ptui.c:4445 */
#define   EMA379      (ERRMA +  379)    /*    ma_ptui.c:4494 */
#define   EMA380      (ERRMA +  380)    /*    ma_ptui.c:4543 */
#define   EMA381      (ERRMA +  381)    /*    ma_ptui.c:4595 */
#define   EMA382      (ERRMA +  382)    /*    ma_ptui.c:4646 */
#define   EMA383      (ERRMA +  383)    /*    ca_bdy1.c:374 */
#define   EMA384      (ERRMA +  384)    /*    ca_bdy1.c:374 */
#define   EMA385      (ERRMA +  385)    /*    ca_bdy1.c:374 */
#define   EMA386      (ERRMA +  386)    /*    ca_bdy1.c:374 */
#define   EMA387      (ERRMA +  387)    /*    ca_bdy1.c:374 */
#define   EMA388      (ERRMA +  388)    /*    ca_bdy1.c:374 */
#define   EMA389      (ERRMA +  389)    /*    ca_bdy1.c:374 */
#define   EMA390      (ERRMA +  390)    /*    ca_bdy1.c:374 */
#define   EMA391      (ERRMA +  391)    /*    ca_bdy1.c:374 */
#define   EMA392      (ERRMA +  392)    /*    ca_bdy1.c:374 */
#define   EMA393      (ERRMA +  393)    /*    ca_bdy1.c:374 */
#define   EMA394      (ERRMA +  394)    /*    ca_bdy1.c:374 */
#define   EMA395      (ERRMA +  395)    /*    ca_bdy1.c:374 */
#define   EMA396      (ERRMA +  396)    /*    ca_bdy1.c:374 */
#define   EMA397      (ERRMA +  397)    /*    ca_bdy1.c:374 */
#define   EMA398      (ERRMA +  398)    /*    ca_bdy1.c:374 */
#define   EMA399      (ERRMA +  399)    /*    ca_bdy1.c:374 */
#define   EMA400      (ERRMA +  400)    /*    ca_bdy1.c:374 */
#define   EMA401      (ERRMA +  401)    /*    ca_bdy1.c:374 */
#define   EMA402      (ERRMA +  402)    /*    ca_bdy1.c:374 */
#define   EMA403      (ERRMA +  403)    /*    ca_bdy1.c:374 */
#define   EMA404      (ERRMA +  404)    /*    ca_bdy1.c:374 */
#define   EMA405      (ERRMA +  405)    /*    ca_bdy1.c:374 */


#endif /* _MAERRH_ */


/********************************************************************30**

         End of file:     ma_err.h@@/main/8 - Fri Sep 16 02:44:43 2005

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  aa   1. initial release

*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.2          ---      ssk  1. Added Phase 2+ variant

/main/3      ---      jie  1. update for MAP 1.5 release.

/main/4      ---      jie  1. update for MAP 1.6 release.

/main/5      ---      jie  1. update for MAP 1.7 release.

/main/7      ---      cp   1. update for MAP release 2.2
/main/8      ---     rbabu 1. update for MAP release 2.3
         ma002.203    dv   1. Introduced maCb global control block.
                           2. Moved global variables to maCb.
                           3. Introduced SS_MULTIPLE_PROCS to aid
                              in internal testing.
/main/8  ma009.203    dm   1. Modification :Changed MALOGERROR macro to SLOGERROR to 
	                      avoid core dump in case of maCbPtr is NULL 
*********************************************************************91*/
