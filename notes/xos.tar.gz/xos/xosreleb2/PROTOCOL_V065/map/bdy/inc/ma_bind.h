#ifndef __MA_BINDH__

#define  __MA_BINDH__

extern void maBndStReq(void);

#endif /* __MA_BINDH__ */