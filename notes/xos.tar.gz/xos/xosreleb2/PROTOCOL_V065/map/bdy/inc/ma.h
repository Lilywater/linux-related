/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     map
  
     Type:     C include file
  
     Desc:     Defines rqeuired by MAP.
  
     File:     ma.h
  
     Sid:      ma.h@@/main/9 - Fri Sep 16 02:44:29 2005
  
     Prg:      aa
  
*********************************************************************21*/
  
#ifndef __MAH__
#define __MAH__ 



/* general defines */
/* ma002.203 : Addition. Additional defines */
#ifdef SS_MULTIPLE_PROCS
#ifndef MA_MAX_INSTANCES
#define MA_MAX_INSTANCES 4
#endif
#define maCb (*maCbPtr)
#endif

#define MA_DLG_HASH_SIZE      67        /* dialogue hash size */
#define MA_INVOKE_HASH_SIZE   67        /* invoke hash size */
#define MA_MAX_PGTABLE_SIZE   40        /* Max PG table size */
#define MA_MAX_SEC_COMPS      200       /* MAPsec operation components table */

/* Change from 65535 to 0xFFFFFFFE */
#define MA_MAX_DLG_ID         0xFFFFFFFE      /* maximum dialogue Id */

#define MA_MAX_INVOKE_ID      126        /* maximum invoke Id */ 
#define MA_MAX_USAPS          8          /* maximum upper saps: modified    *
                                          * from 0xFFFE to 8 -- xingzhou.xu *
                                          * 2006/09/05                      */

/* one byte for tag + max. two bytes for len + sizeof TknStrE data array */
#define MA_MAX_PKARRAY_LEN    (MF_SIZE_TKNSTRE + 3)

#define MA_NETWORK_LOCUP_AC       1   /* Network Location Update    */
#define MA_CANCEL_LOC_AC          2   /* Location cancellation      */
#define MA_ROAM_NMB_ENQUIRY_AC    3   /* Roaming Number Enquiry     */
#define MA_LOCINFO_RET_AC         5   /* Location Info Retrieval    */
#define MA_RESET_AC              10   /* Reset                      */
#define MA_HO_CONTROL_AC         11   /* Handover Control           */
#define MA_EQP_MNGMT_AC          13   /* Equipment Management Cntxt */
#define MA_INFO_RET_AC           14   /* Info Retrieval             */
#define MA_INTVLRINFO_RET_AC     15   /* Inter Vlr Info Retrieval   */
#define MA_SUBS_DATA_MNGMT_AC    16   /* Subscriber Data Management */
#define MA_TRACING_AC            17   /* Tracing                    */
#define MA_NETFUNC_SS_AC         18   /* Network Func SS            */
#define MA_NETWORK_USS_AC        19   /* Network Uss                */
#define MA_SM_GATEWAY_AC         20   /* Short Message Gateway      */
#define MA_SM_MO_RELAY_AC        21   /* Short Message Mo Relay     */
#define MA_SM_ALERT_AC           23   /* Short Message Alert        */
#define MA_MWD_MNGMT_AC          24   /* Mwd Management             */
#define MA_SM_MT_RELAY_AC        25   /* Short Message Mt Relay     */
#define MA_IMSI_RET_AC           26   /* IMSI Retrieval             */
#define MA_MS_PURGING_AC         27   /* Purging                    */
#define MA_SUBS_INFO_ENQ_AC      28   /* Subscriber Info Enquiry    */
#define MA_ANY_TIME_ENQUIRY_AC   29   /* Any Time Enquiry           */
#define MA_CALL_CNTRL_TRANS_AC    6   /* Call Control Transfer      */
#define MA_SSINV_NOTIFY_AC       36   /* SS Invocation Notify       */
#define MA_SIWFS_ALLOC_AC        12   /* SIWFS Allocation           */
#define MA_GRP_CALL_CNTRL_AC     31   /* Group Call Control AC      */
#define MA_GPRS_UPLOC_AC         32   /* Gprs Location Update       */
#define MA_GPRS_LOCINFO_RET_AC   33   /* Gprs Location Info Ret     */
#define MA_FAILRPT_AC            34   /* Failure Report             */
#define MA_GPRS_NOTIFY_AC        35   /* Gprs Notify                */
#define MA_REPORTING_AC          7    /* Reporting                  */
#define MA_CALL_COMP_AC          8    /* Call Completion            */
#define MA_PAGING_DETECT_AC      40   /* Paging Detect              */

#if (MAP_REL98 || MAP_REL99)
#define MA_LOC_SVC_GATEWAY       37   /* Location Service Gateway   */
#define MA_LOC_SVC_ENQUIRY       38   /* Location Svc Enquiry       */
#endif /* MAP_REL98 || MAP_REL99 */
#if MAP_REL99
#define MA_IST_ALERTING          4    /* IST Alerting               */
#define MA_SVC_TERMINATION       9    /* Service   Termination      */
#define MA_NOTE_MMEVT_REPORT     42   /* Mobility Mgmt Event Notify */
#define MA_ANYTIME_INFO_HANDL    43   /* Any Time Info Handling     */
#define MA_SUBS_MOD_NOTIFY       22   /* Subs Data Mod Notify     */
#define MA_AUTH_FAIL_RPT         39   /* Authentication Fail Rpt  */
#define MA_AUTH_FAILRPT_AC       39   /* Auth Fail Rpt Cntxt        */
#endif /* MAP_REL99 */

#define MA_SEC_TRANS_HANDL_AC    40   /* Secure transport handling Cntxt */
#define MA_SIZE_SECPAYLOAD       3438 /* Max size of protected payload */
#define MA_RES_MGMT_AC           44   /* Secure Transport handling cntxt */

/* Defines for application context names for which user data is required */
#define MA_NETFUNC_SS         18         /* Network Functional SS */
#define MA_NETUSS_SS          19         /* Network Unstructured SS */
#define MA_SM_GATEWAY         20         /* Network Unstructured SS */

/* Invalid user Error */
#define MA_USR_ERR_NONE         0xFF
#define MA_PRV_ERR_NONE         0xFF


#define MA_MIN_ADDRSTRG       1          /* minimum address length */
#define MA_MAX_ADDRSTRG       20         /* maximum address length */

/* Upper SAP States */

#define MA_UNBOUND      0               /* unbound state */
#define MA_CONFIGURED   1               /* configured state */
#define MA_BND_DISABLED 2               /* bound but disabled state */
#define MA_BND_ENABLED  3               /* bound  disabled state */
#define MA_BND_WAIT_BNDCFM      4       /* waiting for bind confirm */

/* DSM State machine */
#define MA_DLG_IDLE             0       /* Dialogue idle */
#define MA_DLG_WAIT_USER_REQ    1       /* Wait for user request */
#define MA_DLG_WAIT_INIT_DATA   2       /* Wait Init Data */
#define MA_DLG_INITIATED        3       /* Dialogue Initiated */
#define MA_DLG_ACCEPTED         4       /* Dialogue Accepted */
#define MA_DLG_PENDING          5       /* Dialogue pending */
#define MA_DLG_ESTABLISHED      6       /* Dialogue Established */
#define MA_NMB_DSM_STATE        7       /* number of DSM states */

/* define SSM state machine */

#define MA_SSM_IDLE             0       /* SSM Idle state */
#define MA_SSM_WAITCFM          1       /* SSM wait for confirm */
#define MA_SSM_WAITRSP          2       /* SSM wait for response */

/* MAP user events */
#define MA_EV_OPEN_REQ          0       /* MAP Open Request */
#define MA_EV_OPEN_RSP          1       /* MAP Open Response */
#define MA_EV_CLOSE_REQ         2       /* MAP Close Request */
#define MA_EV_DELIM_REQ         3       /* MAP Delimeter Request */
#define MA_EV_ABRT_REQ          4       /* MAP Abort Request */         
#define MA_BEGIN                5       /* TC Begin */
#define MA_CONTINUE             6       /* TC - Continue */
#define MA_END                  7       /* TC - Abort */
#define MA_ABRT                 8       /* Tc-U Abrt and TC-P Abrt */
#define MA_EV_NOT_IND           9       /* Tc-U Abrt and TC-P Abrt */
#define MA_NMB_DSM_EVNT         10      /* number of DSM events */

/* define for MAPSec PG and PP */
#define MA_NMB_INIT_PG         5      /* Initialized PG number */
#define MA_MAX_NMB_PG          16     /* Max PG number */

/* define for MAPsec original component type */
#define MA_ORIG_CMP_OPR         1     /* operation invoke component */
#define MA_ORIG_CMP_ERR         2     /* operation error component */
#define MA_ORIG_CMP_USR         3     /* user info component */

/* define for MAPSec protection mode */
#define MA_PROT_MODE_0          0     /* protection mode 0 */
#define MA_PROT_MODE_1          1     /* protection mode 1 */
#define MA_PROT_MODE_2          2     /* protection mode 2 */

#define MA_NEID_LENGTH          6     /* NEID length */
#define MA_PLMN_ID_MASK         0xffffff00  /* MASK for 5 digit plmn id */
#define MA_INVALID_PPI          0xffff      /* invalid PPI value */

/* define for TCAP component */

#define MA_INVOKE               0       /* TC - Invoke */
#define MA_RET_RES_L            1       /* TC - result last */
#define MA_RET_RES_NL           2       /* TC - result not last */
#define MA_RET_ERR              3       /* TC - return error */
#define MA_REJECT               4       /* TC - reject */

/* defines for MAP PDU tags */
#define MA_TAG_OPEN_PDU         0xA0    /* Map Open PDU tag */
#define MA_TAG_ACCEPT_PDU       0xA1    /* Map Accept PDU tag */         
#define MA_TAG_CLOSE_PDU        0xA2    /* Map Close PDU tag */  
#define MA_TAG_REFUSE_PDU       0xA3    /* Map Refuse PDU tag */
#define MA_TAG_USRABRT_PDU      0xA4    /* Map User Abort PDU tag */     
#define MA_TAG_PRVABRT_PDU      0xA5    /* Map Provider Abort PDU tag */        

/* defines for src and dest reference tag */
#define MA_TAG_ORGREF           0x81   /* Source reference */
#define MA_TAG_DESTREF          0x80   /* Source reference */

 
/* #define for User Abort Tags */
#define MA_TAG_ABRT_USR_SPECIFIC 0x80   /* Abort User specific reason */
#define MA_TAG_ABRT_RESLIMIT     0x81   /* Abort user resource limitation */
#define MA_TAG_ABRT_RESUNAVAIL   0x82   /* Abort resource unavailable */
#define MA_TAG_ABRT_APC          0x83   /* Application procedure cancellation */

/* defines for timers */

#define MA_GAURD_TMR       1            /* Gaurd timer */
#define MA_OPR_TMR         2            /* invocation timer */
#define MA_TINT_TMR        3            /* Bnd Cfm timer */
#define MA_MAX_TMRS        2            /* Maximum number of timers */
#define MATQNUMENT         10           /* number of entries in timing Q */
#define MA_PERIOD          1            /* tick for gaurd timer */
#define MA_MAX_INTRETRY    2           /* Re.tx count */
#define MA_TINT_TMRVAL    50           /* Re.tx. interval for BndCfm*/

/* timer for Begin Subscriber Activity */
#define MA_BEGIN_SUBS_ACTV_TMR  15 

/* MAP-GSM layer name define */
#define MALAYERNAME    "MA"

/* debug macro */
#define MADBGP(_msgclass, _arg)                   \
   DBGP(&maCb.maInit, MALAYERNAME, _msgclass, _arg)

#if (MAP_REL98 || MAP_REL99)

#define IS_VALID_VERSION(x) ((x==LMA_VER1)   || \
                             (x==LMA_VER2)   || \
                             (x==LMA_VER2P)  || \
                             (x==LMA_VER4))
#else

#define IS_VALID_VERSION(x) ((x==LMA_VER1)   || \
                             (x==LMA_VER2)   || \
                             (x==LMA_VER2P))

#endif /* MAP_REL98 || MAP_REL99 */

#define MA_CHK_FOR_NULLP(ptr) \
{\
   if ((ptr) == NULLP)\
   {\
      MALOGERROR(ERRCLS_INT_PAR, EMA331, (ErrVal)0, \
                "invalid ptr."); \
      RETVALUE (RFAILED); \
   }\
}

    
#if MAP_SEC
/* 
 * ------------------------------------------------------
 * |  f  | mcc3 | mcc2 | mcc1 | mnc2 | mnc1 |  f  | mnc3 |
 * ------------------------------------------------------
 */
#define CAT_PLMNID_VAL(val, val1, val2) \
   val  = (U32)val1; \
   val  =  val << 16; \
   val |= (((U32) val2 & 0xff) << 8); \
   val |= (((U32)val2 & 0xff00)>>  8); \

/* 
 * ------------------------------------------------------
 * | ndc5 | ndc4 | ndc3 | ndc2 | ndc1 | cc3 | cc2 | cc1 |
 * ------------------------------------------------------
 */
#define CAT_PLMNID_164_VAL(val, val1, val2) \
   val  = (U32)val2; \
   val  =  val << 12; \
   val |= ((U32) val1 & 0x00000fff); \

#define GET_U16_LSB(val) (val & 0x000f)

#define GET_U32_LSB(val) (val & 0x0000000f)

#define MA_MIN_GT_ADDR_LEN        4  /* Min global title address length */

/* The worst case, encoding for security header and message authentication
 * code (MAC) will introduce 44 byte overhead for return result component.
 * If segmentation is used in a secure dialogue, the length has to be 
 * subtracted from maximum frame size configured.
 */
#define MA_MAX_SEC_HDR_LEN        44

#endif /* MAP_SEC */

#define MA_ENCODE_LEN(msglen,idx)\
{\
   MsgLen      tmpStrLen;\
   U32         lenByte;\
   if (msglen < 128)\
   {\
      pkArray[idx++] = (Data)msglen; \
   }\
   else \
   {\
      lenByte = 0;\
      tmpStrLen = msglen; \
      while (tmpStrLen > 0) \
      {\
         tmpStrLen >>= 8;\
         lenByte++; \
      }\
      tmpStrLen = lenByte;\
      for (; lenByte > 0; lenByte--)\
      {\
         pkArray[idx++] = (msglen  & 0xff);\
         msglen       >>=  8;\
      }\
      pkArray[idx++] = (MA_EOC_LEN | tmpStrLen);\
   }\
}

#define MA_MAX_SEGMENTS 100 /* max number of segments */
/* define offset for the first segmented operation response */
#define MA_OPRRSP_OFFSET 0 

#define MA_UPD_DEFAULT_QOS_PARAMS(s,dlgCp) \
   s->qosSet.msgPrior = s->maPrior;\
   s->qosSet.seqCtl = s->cfg.pClass;\
   s->qosSet.seqCtl = ((s->qosSet.seqCtl==PCLASS1)?TRUE:FALSE)

#define MA_UPD_QOS_PARAMS(s,dlgCp) \
   s->qosSet.msgPrior = s->maPrior;\
   if (dlgCp->maPrior.pres == TRUE)\
   {\
      s->qosSet.msgPrior = dlgCp->maPrior.val;\
      dlgCp->maPrior.pres = FALSE;\
   }\
   s->qosSet.seqCtl = s->cfg.pClass;\
   if (dlgCp->pClass.pres == TRUE)\
   {\
      s->qosSet.seqCtl = dlgCp->pClass.val;\
      dlgCp->pClass.pres = FALSE;\
   }\
   s->qosSet.seqCtl = ((s->qosSet.seqCtl==PCLASS1)?TRUE:FALSE)
#ifdef ZJ

#define MA_UPD_DLG(dlgCp, action) \
   if (dlgCp->upd == TRUE)\
   {\
      cmTuRunTimeUpd(&zjCb.tuCb, CMTU_DLG_CB, CMPFTHA_UPDTYPE_NORMAL,\
                     action, (Void *)dlgCp);\
   }

#define MA_UPD_INV(dlgCp, cmpCp, action) \
   if (dlgCp->upd == TRUE)\
   {\
      cmTuRunTimeUpd(&zjCb.tuCb, CMTU_INV_CB, CMPFTHA_UPDTYPE_NORMAL,\
                     action, (Void *)cmpCp);\
   }

#define MA_UPD_PEER(rtUpd) \
   if (rtUpd == TRUE)\
   {\
      cmTuUpdPeer(&zjCb.tuCb);\
   }

#define MA_UPD_PEER_DLG(dlgCp, action) \
   if (dlgCp->upd == TRUE)\
   {\
      cmTuRunTimeUpd(&zjCb.tuCb, CMTU_DLG_CB, CMPFTHA_UPDTYPE_NORMAL,\
                     action, (Void *)dlgCp);\
      cmTuUpdPeer(&zjCb.tuCb);\
   }

#endif /* ZJ */

#ifdef XW_IND_OPTIMIZE
#ifndef MA_STATIC_EVT_STRUCT
#define MAX_DLG_RESEVT 10
#endif
#endif


#endif /* __MAH__ */


/********************************************************************30**

         End of file:     ma.h@@/main/9 - Fri Sep 16 02:44:29 2005

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  aa    1. initial release
1.2          ---  aa    1. Corrected the defines for MAP PDU tags

*********************************************************************81*/
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.3          ---      sg   1. Changed the value of MA_MAX_DLG_ID
             ---      ssk  2. Added MAP Phase 2+ variant          

/main/4      ---      jie  1. update for MAP 1.5 release.

             ---      jie  1. change define MA_BND_WAIT_BNDCFM to 4.
                           2. define MA_AUTH_FAILRPT_AC for backward 
                              compatibility with PS release.

             ---      jie  1. Rolling Upgrade compliance.

/main/5      ---      jie  1. update for MAP 1.6 release.

             ---      yz   1. Addition of MAP segmentation feature from 1.5.

             ---      yz   1. Addition of MAP Segmentation feature.            

             ---      jie  3. Change for 2002/09 rel99/rel4 release.

/main/6      ---      jie  1. update for MAP 1.7 release.

             ---      ssk  4. Changes related to flexibly tune the MTP3 
                              priority and SCCP class parameters. 
/main/8      ---      cp   1. update for MAP release 2.2
/main/9      ---    rbabu  1. update for MAP release 2.3
         ma002.203    dv   1. Introduced maCb global control block.
                           2. Moved global variables to maCb.
                           3. Introduced SS_MULTIPLE_PROCS to aid
                              in internal testing.
*********************************************************************91*/

