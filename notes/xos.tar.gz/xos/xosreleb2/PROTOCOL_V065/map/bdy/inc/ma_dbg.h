
#ifndef __MA_DBG_H__
#define __MA_DBG_H__

#define MAX_NMB_SAP 8
#define MAX_NMB_DLG 15
#define MAX_NMB_OPR 100
#define MADBG_MAX_PLMN 10
#define MADBG_MAX_PP 10

#ifdef MA_CLI_ACCDBG
#define MAINST TSTINST_0

#define MADBG_SAP_0 MA_ACC_SAP_0
#define MADBG_SAP_1 MA_ACC_SAP_1
#define MADBG_SAP_2 MA_ACC_SAP_2
#define MADBG_SAP_3 MA_ACC_SAP_3
#define MADBG_SAP_4 MA_ACC_SAP_4
#define MADBG_SAP_5 MA_ACC_SAP_5
#define MADBG_SAP_6 MA_ACC_SAP_6
#define MADBG_SAP_7 MA_ACC_SAP_7

#define MADBG_START_DLGID MA_ACC_START_DLGID
#define MADBG_DLGID_RANGE MA_ACC_DLGID_RANGE

#define MADBG_INST_0 TSTINST_0
#define MADBG_INST_1 TSTINST_1
#define MADBG_REGION TSTREG
#define MADBG_POOL TSTPOOL
#define MADBG_PROCID0 TSTPROCID0
#define MADBG_SEL_LC MA_SEL_LC
#define MADBG_SEL_TC MA_SEL_TC
#else /*MA_CLI_ACCDBG*/
#define MAINST 0

#define MADBG_SAP_0 0
#define MADBG_SAP_1 1
#define MADBG_SAP_2 2
#define MADBG_SAP_3 3
#define MADBG_SAP_4 4
#define MADBG_SAP_5 5
#define MADBG_SAP_6 6
#define MADBG_SAP_7 7

#define MADBG_START_DLGID 1
#define MADBG_DLGID_RANGE 100

#define MADBG_INST_0 0
#define MADBG_INST_1 1
#define MADBG_REGION OWNREGION
#define MADBG_POOL 0
#define MADBG_PROCID0 0
#define MADBG_SEL_LC 0
#define MADBG_SEL_TC 1
#endif

#define MADBG_MAX_DLGS 100
#define MADBG_PRNT_STS 1 /*print  statistics*/
#define MADBG_ZERO_STS 0 /*zero  statistics*/
#define MADBG_PRNT_ZERO_STS 2 /*print and zero statistics*/

EXTERN XVOID Test_Init_MAP(CLI_ENV *pCliEnv);
EXTERN XVOID maShowSapStat(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv);
EXTERN VOID maShowMaCfg(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv);
EXTERN VOID maTstCaseRun(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv);
EXTERN VOID maShowDlgStat(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv);
EXTERN VOID maShowDbgStat(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv);
EXTERN XVOID maShowSts(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv);
EXTERN XVOID maDbgMAPCfg(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv);
EXTERN XVOID maDbgGenCfg(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv);
EXTERN XVOID maDbgSapCfg(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv);
EXTERN XVOID maDbgCntr(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv);
EXTERN XVOID maDbgBnd(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv);
EXTERN XVOID maDbgSetDbgmsk(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv);

EXTERN Void maSetDbgMaskFromShell(U32 dbgMask);

#endif /*__MA_DBG_H__*/
