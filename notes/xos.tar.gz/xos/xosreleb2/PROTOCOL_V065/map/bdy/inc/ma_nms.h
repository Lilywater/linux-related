/**********************************************************************

    Name:   ma_nms.h 

    Type:   C include file

    Desc:   

    File:   ma_nms.h

    Sid:    

    Created by: 

**********************************************************************/


#ifndef _MA_NMS_H_
#define _MA_NMS_H_

#ifdef __cplusplus
extern "C" {
#endif
/*--------------------------------------------------------*/

/*--------------------------------------------------------*/
extern void TestPrintGen();
extern void TestPrintSap();
extern int maTestPrint();
extern void maInitCfgData();
extern S16 maCfgMsg();
extern unsigned char maInitCfgCallback(unsigned short msgtype, unsigned int sepuense, unsigned char pack_end, tb_record* prow);
extern Void maResetCfgData();

/*receive init cfg data*/
extern S16 maRecvInitCfg(tb_record* prow);

/*init cfg data struct*/
extern void maInitCfgData();

#ifdef __cplusplus
}
#endif



#endif


