/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     map - database
  
     Type:     C include file
  
     Desc:     defines required by MAP Database 
  
     File:     ma_mf.h
  
     Sid:      ma_mf.h@@/main/10 - Fri Sep 16 02:45:13 2005
  
     Prg:      ssk
  
*********************************************************************21*/

#ifndef __MAMFH__
#define __MAMFH__


/* General define */
#define MAX_LEN_NA 0
#define MIN_LEN_NA 0
#define MA_MAX_SBYTE_VAL      127  /* maximum value in a signed byte value */
#define MA_NUMBITS_BYTE       8    /* number of bits in a byte */

/* define for Extended Tag Encoding */
#define    LONG_TAG_IND         0x1f     /* Long Tag Indication */

#define    MA_LEN_NA           0xFF
#define    MA_NA               0xFF
#define    MA_TAG_NA           0xFF

/* Token element flag defination */
#define    MA_TF_TE            0x0008   /* Single Token Element */
#define    MA_TF_TEL           0x0010   /* List of Token element  */

/* define for escape function */
#define   MA_SKIP_SEQ              0xFF
#define   MA_UNRECOGNIZED_VALUE    0xFF     /* unrecognized value */

/* This mask is used for Bit String exception handling */
#define   MA_DLET_BYTE1_MASK       0x80     /* DeferredLocationEventType */
#define   MA_DLET_BYTE2_MASK       0x00     /* DeferredLocationEventType */


#define    MA_TF_VER1_MASK         0x00C0   /* 2 bits for version 1 */
#define    MA_TF_VER2_MASK         0x0300   /* 2 bits for version 2 */
#define    MA_TF_VER2P_MASK        0x0C00   /* 2 bits for version 1 */

/* Flags for the version 1 */
#define    MA_TF_VER1_MAND        0x0040
#define    MA_TF_VER1_OPT         0x0080

/* Flags for the version 2 */
#define    MA_TF_VER2_MAND        0x0100
#define    MA_TF_VER2_OPT         0x0200

/* Flags for the version 2Plus */
#define    MA_TF_VER2P_MAND       0x0400
#define    MA_TF_VER2P_OPT        0x0800

/* 
** Flags for the message in version 1, version 2 and version 2+  
** Each define is of type MA_TF_VER1AND2AND2P_OPT[?] 
** Where '?' is a number.
** ? represents the binary number , by assuming the MAND as 0
** and OPT as 1.
*/

#define MA_TF_VER1AND2AND2P_OPT0 (MA_TF_VER2P_MAND | MA_TF_VER2_MAND | MA_TF_VER1_MAND) 
#define MA_TF_VER1AND2AND2P_OPT1 (MA_TF_VER2P_MAND | MA_TF_VER2_MAND | MA_TF_VER1_OPT ) 
#define MA_TF_VER1AND2AND2P_OPT2 (MA_TF_VER2P_MAND | MA_TF_VER2_OPT  | MA_TF_VER1_MAND) 
#define MA_TF_VER1AND2AND2P_OPT3 (MA_TF_VER2P_MAND | MA_TF_VER2_OPT  | MA_TF_VER1_OPT ) 
#define MA_TF_VER1AND2AND2P_OPT4 (MA_TF_VER2P_OPT  | MA_TF_VER2_MAND | MA_TF_VER1_MAND) 
#define MA_TF_VER1AND2AND2P_OPT5 (MA_TF_VER2P_OPT  | MA_TF_VER2_MAND | MA_TF_VER1_OPT ) 
#define MA_TF_VER1AND2AND2P_OPT6 (MA_TF_VER2P_OPT  | MA_TF_VER2_OPT  | MA_TF_VER1_MAND) 
#define MA_TF_VER1AND2AND2P_OPT7 (MA_TF_VER2P_OPT  | MA_TF_VER2_OPT  | MA_TF_VER1_OPT ) 

/* Flags for the version 4 */
#define    MA_TF_VER4_MAND       0x1000
#define    MA_TF_VER4_OPT        0x2000

/* 
** Flags for the messages in version 2 and 1  
** Each define is of type MA_TF_VER1AND2P_OPT[?] 
** Where '?' is a number.
** ? represents the binary number , by assuming the MAND as 0
** and OPT as 1.
*/
#define MA_TF_VER1AND2_OPT0 (MA_TF_VER2_MAND | MA_TF_VER1_MAND) 
#define MA_TF_VER1AND2_OPT1 (MA_TF_VER2_MAND | MA_TF_VER1_OPT ) 
#define MA_TF_VER1AND2_OPT2 (MA_TF_VER2_OPT  | MA_TF_VER1_MAND) 
#define MA_TF_VER1AND2_OPT3 (MA_TF_VER2_OPT  | MA_TF_VER1_OPT ) 

/* 
** Flags for the messages in version 1 and 2 Plus 
** Each define is of type MA_TF_VER1AND2P_OPT[?] 
** Where '?' is a number.
** ? represents the binary number , by assuming the MAND as 0
** and OPT as 1.
*/
#define MA_TF_VER1AND2P_OPT0 (MA_TF_VER2P_MAND | MA_TF_VER1_MAND) 
#define MA_TF_VER1AND2P_OPT1 (MA_TF_VER2P_MAND | MA_TF_VER1_OPT ) 
#define MA_TF_VER1AND2P_OPT2 (MA_TF_VER2P_OPT  | MA_TF_VER1_MAND) 
#define MA_TF_VER1AND2P_OPT3 (MA_TF_VER2P_OPT  | MA_TF_VER1_OPT ) 

/* 
** Flags for the messages in version 2 and 2 Plus 
** Each define is of type MA_TF_VER2AND2P_OPT[?] 
** Where '?' is a number.
** ? represents the binary number , by assuming the MAND as 0
** and OPT as 1.
*/
#define MA_TF_VER2AND2P_OPT0 (MA_TF_VER2P_MAND | MA_TF_VER2_MAND) 
#define MA_TF_VER2AND2P_OPT1 (MA_TF_VER2P_MAND | MA_TF_VER2_OPT ) 
#define MA_TF_VER2AND2P_OPT2 (MA_TF_VER2P_OPT  | MA_TF_VER2_MAND) 
#define MA_TF_VER2AND2P_OPT3 (MA_TF_VER2P_OPT  | MA_TF_VER2_OPT ) 
#define MA_TF_VER2PAND4_OPT3 (MA_TF_VER4_OPT  | MA_TF_VER2P_OPT ) 

#if (MAP_REL98 || MAP_REL99)
/*
** Flags for the messages in version 2P and 4 
** Each define is of type MA_TF_VER2PAND4_OPT[?] 
** Where '?' is a number.
** ? represents the binary number , by assuming the MAND as 0
** and OPT as 1.
*/
#define MA_TF_VER2PAND4_OPT0 (MA_TF_VER4_MAND | MA_TF_VER2P_MAND) 
#define MA_TF_VER2PAND4_OPT1 (MA_TF_VER4_MAND | MA_TF_VER2P_OPT ) 
#define MA_TF_VER2PAND4_OPT2 (MA_TF_VER4_OPT  | MA_TF_VER2P_MAND) 

/* 
** Flags for the message in version 1, version 2, version 2+ and Version 4
** Each define is of type MA_TF_ALL_OPT[?] 
** Where '?' is a number.
** ? represents the binary number , by assuming the MAND as 0
** and OPT as 1.
*/

#define MA_TF_ALL_OPT0 (MA_TF_VER4_MAND |MA_TF_VER2P_MAND | MA_TF_VER2_MAND | MA_TF_VER1_MAND) 
#define MA_TF_ALL_OPT7 (MA_TF_VER4_OPT |MA_TF_VER2P_OPT  | MA_TF_VER2_OPT  | MA_TF_VER1_OPT ) 

#else
#define MA_TF_ALL_OPT0 (MA_TF_VER2P_MAND | MA_TF_VER2_MAND | MA_TF_VER1_MAND) 
#define MA_TF_ALL_OPT7 (MA_TF_VER2P_OPT  | MA_TF_VER2_OPT  | MA_TF_VER1_OPT ) 


#endif /* MAP_REL98 || MAP_REL99 */

/* Token Element type */

#define    MA_TET_NULL         1        /* NULL */
#define    MA_TET_U8           2        /* Unsigned 8 bits */
#define    MA_TET_U8_ENUM      3        /* Unsigned 8 bit enumerated */
#define    MA_TET_INT          4        /* integer */
#define    MA_TET_STRS         5        /* binary small string */
#define    MA_TET_STR          6        /* binary regular string */
#define    MA_TET_STRM         7        /* binary medium string */
#define    MA_TET_STRE         8        /* binary large string */
#define    MA_TET_SEQ          9        /* Sequence of elements */
#define    MA_TET_SEQ_OF       10       /* Sequence of elements */
#define    MA_TET_SEQ_TERM     11       /* Sequence terminator */
#define    MA_TET_CHOICE       12       /* Choice */
#define    MA_TET_BITSTR       13       /* Bit String */
#define    MA_TET_STRUL        14       /* binary extra large string */
#define    MA_TET_EXT_CONT     15       /* extension container */
#define    MA_TET_OBJID        17       /* Object Id */
#ifdef MAP_PHASE2_EXT_MARK
#define    MA_TET_EXT_MARK     18       /* extension container */
#define    MA_NMB_OF_TET       18       /* Total number of Element type */
#else
#define    MA_NMB_OF_TET       17       /* Total number of Element type */
#endif

#ifdef XWEXT
#define    MA_TET_STR4         18        /* binary small string */
#endif

#define    MA_TET_EXTCONT_SIZE 5        /* Number of element for ExtCont */


#if ( (defined(DOS)) && (defined(PTRFAR)) )
#define MA_BUMP_STP(_addr, _len) maBumpStp(_addr, _len) 
#else
#define MA_BUMP_STP(_addr, _len) (*(_addr) += _len) 
#endif

/* define for TAGS */

#define MA_EOC_LEN        0x80      /* Length field for indefinate length */
#define MA_LEN_1_BYTE     0x81      /* Length field for long length encoding */
#define MA_TAG_EOC        0x00      /* EOC tag for indefinate length encoding*/

/* defines for general tags */
#define MA_TAG_BOOL            0x01     /* Boolean Tag */
#define MA_TAG_INTEGER         0x02     /* Integer tag */
#define MA_TAG_BITSTR          0x03     /* Bit string tag */
#define MA_TAG_OCTSTR          0x04     /* octet string tag */
#define MA_TAG_NULL            0x05     /* NULL tag */
#define MA_TAG_OBJID           0x06     /* Object Id */
/* ma007.203 : Added new tag to be used in Dialogue PDU */
#define MA_TAG_OBJDES          0x07     /* Object descriptor tag */
#define MA_TAG_EXT             0x28     /* External */
#define MA_TAG_NUMSTR          0x12     /* Numeric string tag */
#define MA_TAG_SEQ             0x30     /* sequence tag */
#define MA_TAG_ENUM            0x0A     /* enumerated tag */
#define MA_TAG_IA5STR          0x16     /* IA5 String */

/* Object Id for Map dialogue */
#define MA_TAG_SNGL_ASN1_TYPE  0xA0     /* Single ASN1 Type */
#define MA_TAG_DLGID_B1        0x04     /* Byte 1 */
#define MA_TAG_DLGID_B2        0x00     /* Byte 2 */
#define MA_TAG_DLGID_B3        0x00     /* Byte 3 */
#define MA_TAG_DLGID_B4        0x01     /* Byte 4 */
#define MA_TAG_DLGID_B5        0x01     /* Byte 5 */
#define MA_TAG_DLGID_B6        0x01     /* Byte 6 */
#define MA_TAG_DLGID_B7        0x01     /* Byte 7 */

/* The sixth byte of Object Id for Map Sec dialogue */
#define MA_TAG_PROT_DLGID_B6   0x03     /* Byte 6 */

/* Define for context specific tags for primitives */

#define MA_TAG_CSPRIM0     0x80     /* context specific primitive type 0 */
#define MA_TAG_CSPRIM1     0x81     /* context specific primitive type 1 */
#define MA_TAG_CSPRIM2     0x82     /* context specific primitive type 2 */
#define MA_TAG_CSPRIM3     0x83     /* context specific primitive type 3 */
#define MA_TAG_CSPRIM4     0x84     /* context specific primitive type 4 */
#define MA_TAG_CSPRIM5     0x85     /* context specific primitive type 5 */
#define MA_TAG_CSPRIM6     0x86     /* context specific primitive type 6 */
#define MA_TAG_CSPRIM7     0x87     /* context specific primitive type 7 */
#define MA_TAG_CSPRIM8     0x88     /* context specific primitive type 8 */
#define MA_TAG_CSPRIM9     0x89     /* context specific primitive type 9 */
#define MA_TAG_CSPRIM10    0x8A     /* context specific primitive type A */
#define MA_TAG_CSPRIM11    0x8B     /* context specific primitive type B */
#define MA_TAG_CSPRIM12    0x8C     /* context specific primitive type C */
#define MA_TAG_CSPRIM13    0x8D     /* context specific primitive type C */
#define MA_TAG_CSPRIM14    0x8E     /* context specific primitive type C */
#define MA_TAG_CSPRIM15    0x8F     /* context specific primitive type C */

#define MA_TAG_CSPRIM16    0x90     /* context specific primitive type C */
#define MA_TAG_CSPRIM17    0x91     /* context specific primitive type C */
#define MA_TAG_CSPRIM18    0x92     /* context specific primitive type C */
#define MA_TAG_CSPRIM19    0x93     /* context specific primitive type C */
#define MA_TAG_CSPRIM20    0x94     /* context specific primitive type C */
#define MA_TAG_CSPRIM21    0x95     /* context specific primitive type C */
#define MA_TAG_CSPRIM22    0x96     /* context specific primitive type C */
#define MA_TAG_CSPRIM23    0x97     /* context specific primitive type C */
#define MA_TAG_CSPRIM24    0x98     /* context specific primitive type C */
#define MA_TAG_CSPRIM25    0x99     /* context specific primitive type C */
#define MA_TAG_CSPRIM26    0x9A     /* context specific primitive type C */
#define MA_TAG_CSPRIM27    0x9B     /* context specific primitive type C */
#define MA_TAG_CSPRIM28    0x9C     /* context specific primitive type C */
#define MA_TAG_CSPRIM29    0x9D     /* context specific primitive type C */
#ifdef MAP_CH_PLUS
#define MA_TAG_CSPRIM30    0x9E     /* context specific primitive type C */
#endif

/* defines for context specific tags for constructors */

#define MA_TAG_CSCONST0    0xA0     /* context specific constrcutor type 0 */
#define MA_TAG_CSCONST1    0xA1     /* context specific constructor type 1 */
#define MA_TAG_CSCONST2    0xA2     /* context specific constructor type 2 */
#define MA_TAG_CSCONST3    0xA3     /* context specific constructor type 3 */
#define MA_TAG_CSCONST4    0xA4     /* context specific constructor type 4 */
#define MA_TAG_CSCONST5    0xA5     /* context specific constructor type 5 */
#define MA_TAG_CSCONST6    0xA6     /* context specific constructor type 6 */
#define MA_TAG_CSCONST7    0xA7     /* context specific constructor type 7 */
#define MA_TAG_CSCONST8    0xA8     /* context specific constructor type 8 */
#define MA_TAG_CSCONST9    0xA9     /* context specific constructor type 9 */
#define MA_TAG_CSCONST10   0xAA     /* context specific constructor type A */
#define MA_TAG_CSCONST11   0xAB     /* context specific constructor type B */
#define MA_TAG_CSCONST12   0xAC     /* context specific constructor type C */
#define MA_TAG_CSCONST13   0xAD     /* context specific constructor type D */
#define MA_TAG_CSCONST14   0xAE     /* context specific constructor type E */
#define MA_TAG_CSCONST15   0xAF     /* context specific constructor type F */
#define MA_TAG_CSCONST16   0xB0     /* context specific constructor type B */
#define MA_TAG_CSCONST17   0xB1     /* context specific constructor type B */
#define MA_TAG_CSCONST18   0xB2     /* context specific constructor type B */
#define MA_TAG_CSCONST19   0xB3     /* context specific constructor type B */
#define MA_TAG_CSCONST20   0xB4     /* context specific constructor type B */
#define MA_TAG_CSCONST21   0xB5     /* context specific constructor type B */
#define MA_TAG_CSCONST22   0xB6     /* context specific constructor type B */
#define MA_TAG_CSCONST23   0xB7     /* context specific constructor type B */
#define MA_TAG_CSCONST24   0xB8     /* context specific constructor type B */
#define MA_TAG_CSCONST25   0xB9     /* context specific constructor type B */
#define MA_TAG_CSCONST26   0xBA     /* context specific constructor type B */
#define MA_TAG_CSCONST27   0xBB     /* context specific constructor type B */
#define MA_TAG_CSCONST28   0xBC     /* context specific constructor type B */

/* define for internal message index */

enum MaSSReq {
#if (MAP_VLR || MAP_HLR)

  MA_MI_REGSS_REQ,              /* Message index */
  MA_MI_ERASESS_REQ,            /* Message index */
  MA_MI_ACTVSS_REQ,             /* Message index */
  MA_MI_DACTVSS_REQ,            /* Message index */
  MA_MI_INTERSS_REQ,            /* Message index */
  MA_MI_REGPASSWD_REQ,          /* Message index */
  MA_MI_GETPASSWD_REQ,          /* Message index */
  MA_MI_PROCUSS_REQ,            /* Message index */
  MA_MI_PROCUSSDAT_REQ,         /* Message index */
  MA_MI_USS_REQ,                /* Message index */
  MA_MI_USSNOTIFY_REQ,          /* Message index */
#endif /* VLR || HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
  MA_MI_SMRDY_REQ,              /* Message index */
#endif /* VLR || HLR || MAP_GSN */

#if MAP_MSC
  MA_MI_DET_IMSI_REQ,           /* Message index */
#endif   /* MSC */

#if (MAP_MSC || MAP_VLR || MAP_GSN)
  MA_MI_CHKIMEI_REQ,            /* Message index */
#endif   /* MAP_MSC || MAP_VLR || MAP_GSN */

#if MAP_MSC
  MA_MI_TRACESUBSACTV_REQ,      /* Message index */
#endif   /* MSC */

#if (MAP_MSC || MAP_HLR)
  MA_MI_ROUTINFO_REQ,           /* Message index */
  MA_MI_ROUTINFOSM_REQ,         /* Message index */
  MA_MI_SMDEL_REQ,              /* Message index */
  MA_MI_ALRTSC_REQ,             /* Message index */
  MA_MI_INFSC_REQ,              /* Message index */
  MA_MI_ALRTSCWRSLT_REQ,        /* Message index */
  MA_MI_SSINV_NOTIFY_REQ, /* Message Index */

#endif  /* MSC || HLR */

#if (MAP_VLR || MAP_HLR)
  MA_MI_UPLOC_REQ,              /* message index */
#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
  MA_MI_CANCELLOC_REQ,          /* message index */
  MA_MI_PURGE_REQ,              /* Message index */
  MA_MI_AUTHINFO_REQ,           /* Message index */
  MA_MI_INSSUBSDATA_REQ,        /* Message index */
  MA_MI_DELSUBSDATA_REQ,        /* Message index */
  MA_MI_RESET_REQ,              /* Message index */
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */
 
#if (MAP_VLR || MAP_HLR)
  MA_MI_RESTOREDATA_REQ,        /* Message index */
#endif /* MAP_VLR || MAP_HLR */
 
#if (MAP_VLR || MAP_HLR || MAP_GSN)
  MA_MI_ACTVTRACE_REQ,          /* Message index */
  MA_MI_DACTVTRACE_REQ,         /* Message index */
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */
 
#if (MAP_VLR || MAP_HLR)
  MA_MI_SNDIMSI_REQ,            /* Message index */
  MA_MI_BGNSUBSACTV_REQ,        /* Message index */
  MA_MI_NOTSUBPRES_REQ,         /* Message index */
#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
  MA_MI_SNDPARAM_REQ,           /* Message index */
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR)
  MA_MI_PROVROAMNMB_REQ,                /* Message index */
  MA_MI_SETRPTSTATE_REQ,      /* Message type */
  MA_MI_STARPT_REQ,           /* Message type */
  MA_MI_RMTUSRFREE_REQ,       /* Message type */
#endif  /* (VLR) || (HLR) */

#if (MAP_VLR || MAP_HLR)
  MA_MI_REGCCENT_REQ,         /* Message type */
  MA_MI_ERASECCENT_REQ,         /* Message type */
#endif /* MAP_VLR || MAP_HLR */

#if MAP_MSC
  MA_MI_PREHO_REQ,              /* Message index */
  MA_MI_PERHO_REQ,              /* Message index */
  MA_MI_SNDENDSIG_REQ,          /* Message index */
  MA_MI_PROCACCSIG_REQ,         /* Message index */
  MA_MI_FWDACCSIG_REQ,          /* Message index */
  MA_MI_PRESUBSHO_REQ,          /* Message index */
  MA_MI_PERSUBSHO_REQ,          /* Message index */
  MA_MI_NOTEINTERHO_REQ,        /* Message index */
#endif /* MAP_MSC */
 
#if (MAP_MSC || MAP_GSN)
  MA_MI_FWDSM_REQ,              /* Message index */
  MA_MI_MTFWDSM_REQ,            /* Message type */
#endif /* MAP_MSC || MAP_GSN */
 
#if MAP_MSC
  MA_MI_RESCALLHANDL_REQ,     /* Message type */
  MA_MI_PREPGRPCALL_REQ,     /* Message type */
  MA_MI_PROGRPCALLSIG_REQ,   /* Message type */
  MA_MI_FWDGRPCALLSIG_REQ,   /* Message type */
  MA_MI_SNDGRPCALLENDSIG_REQ,     /* Message type */
  MA_MI_PROVSIWFSNMB_REQ,   /* Message type */
  MA_MI_SIWFSSIGMOD_REQ,     /* Message type */
#endif  /* MSC */

#if MAP_VLR
  /* Send Identification Request */
  MA_MI_SNDID_REQ,              /* Message index */
#endif  /* MAP_VLR */

#if (MAP_HLR || MAP_MLC)
  MA_MI_ANYINTER_REQ,         /* Message type */
#endif /* MAP_HLR || MAP_MLC */

#if (MAP_HLR || MAP_GSN)
  MA_MI_GPRSUPLOC_REQ,       /* Message type */
  MA_MI_GPRSROUTINFO_REQ,    /* Message type */
  MA_MI_GPRSNOTEMSPRES_REQ,   /* Message type */
  MA_MI_FAILRPT_REQ,           /* Message type */
#endif  /*(MAP_HLR || MAP_GSN)*/

#if (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5))
  MA_MI_PROVSUBSINFO_REQ,     /* Message type */
#endif  /* MAP_VLR || MAP_HLR */

#if (MAP_REL98 || MAP_REL99)

#if (MAP_HLR || MAP_MLC)
  MA_MI_ROUTINFOFORLCS_REQ,   /* Message type */
#endif /* MAP_HLR || MAP_MLC */

#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL99 && MAP_REL4 && MAP_GSN))
  MA_MI_PRVSUBSLOC_REQ,       /* Message type */
  MA_MI_SUBSLOCRPT_REQ,       /* Message type */
#endif  /*(MAP_MSC || MAP_MLC)*/
#endif

#endif /* MAP_REL98 || MAP_REL99 */

#if MAP_REL99
#if (MAP_VLR || MAP_HLR || MAP_GSN)
  MA_MI_AUTHFAILRPT_REQ,         /* Message index */
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
  MA_MI_NOTMMEV_REQ,       /* Message type */
#endif /* MAP_VLR || MAP_HLR */

#if (MAP_MSC || MAP_HLR)
  MA_MI_ISTALRT_REQ,              /* Message index */
  MA_MI_ISTCMD_REQ,               /* Message index */
#endif /* MAP_MSC || MAP_HLR */

#if MAP_HLR
  MA_MI_ANYSUBSINTER_REQ,       /* Message type */
  MA_MI_ANYMOD_REQ,             /* Message type */
  MA_MI_NOTSUBSMOD_REQ,         /* Message type */
#endif /* MAP_HLR */

#if MAP_REL6
#if MAP_MSC
  
  MA_MI_RELRES_REQ,           /* Message type */

#endif /* MAP_MSC */
#endif /* MAP_REL6 */

#endif /* MAP_REL99 */

#if MAP_SEC
  MA_MI_SECTRANS_CLASS1_REQ,  
  MA_MI_SECTRANS_CLASS2_REQ,  
  MA_MI_SECTRANS_CLASS3_REQ,  
  MA_MI_SECTRANS_CLASS4_REQ,  
#endif 

#ifdef XWEXT /* xingzhou.xu: added for paging detect 2006/10/16 */
  MA_MI_XW_DETECT_REQ,
#endif
  /*
  ** The following enum value is introduced to avoid the 
  ** trailing comma Warning coming from some of the compilers.
  */
  MA_MI_REQ_TERM
};

enum MaSSRsp
{

#if (MAP_VLR || MAP_HLR)

  MA_MI_REGSS_RSP,              /* Message index */
  MA_MI_ERASE_SS_RSP,           /* Message index */
  MA_MI_ACTVSS_RSP,             /* Message index */
  MA_MI_DACTVSS_RSP,            /* Message index */
  MA_MI_INTERSS_RSP,            /* Message index */
  MA_MI_REGPASSWD_RSP,          /* Message index */
  MA_MI_GETPASSWD_RSP,          /* Message index */
  MA_MI_PROCUSS_RSP,            /* Message index */
  MA_MI_PROCUSSDAT_RSP,         /* Message index */
  MA_MI_USS_RSP,                /* Message index */
#endif /* VLR || HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
  MA_MI_SMRDY_RSP,              /* Message index */
#endif /* VLR || HLR || MAP_GSN */

#if (MAP_MSC || MAP_VLR || MAP_GSN)
  MA_MI_CHKIMEI_RSP,            /* Message index */
#endif   /* MAP_MSC || MAP_VLR || MAP_GSN */

#if (MAP_MSC || MAP_HLR)

  MA_MI_ROUTINFO_RSP,           /* Message index */
  MA_MI_ROUTINFOSM_RSP,         /* Message index */
  MA_MI_SMDEL_RSP,              /* Message index */
  MA_MI_SSINV_NOTIFY_RSP,   /* SS Invoke Response */

#endif  /* MSC || HLR */

#if (MAP_VLR || MAP_HLR)
  MA_MI_UPLOC_RSP,              /* message index */
#endif /* MAP_VLR || MAP_HLR */
 
#if (MAP_VLR || MAP_HLR || MAP_GSN)
  MA_MI_CANCELLOC_RSP,
  MA_MI_PURGE_RSP,
  MA_MI_AUTHINFO_RSP,           /* Message index */
  MA_MI_INSSUBSDATA_RSP,        /* Message index */
  MA_MI_DELSUBSDATA_RSP,        /* Message index */
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */
 
#if (MAP_VLR || MAP_HLR)
  MA_MI_RESTOREDATA_RSP,        /* Message index */
#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
  MA_MI_ACTVTRACE_RSP,          /* Message index */
  MA_MI_DACTVTRACE_RSP,         /* Message index */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR)
  MA_MI_SNDIMSI_RSP,            /* Message index */
#endif /* MAP_VLR || MAP_HLR */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
  MA_MI_SNDPARAM_RSP,           /* Message index */
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR)
  MA_MI_PROVROAMNMB_RSP,        /* Message index */
  MA_MI_SETRPTSTATE_RSP,        /* Message index */
  MA_MI_STARPT_RSP,             /* Message index */
  MA_MI_RMTUSRFREE_RSP,         /* Message index */
#endif  /* (VLR) || (HLR) */

#if (MAP_VLR || MAP_HLR)
  MA_MI_REGCCENT_RSP,           /* Message index */
  MA_MI_ERASECCENT_RSP,         /* Message index */
#endif /* MAP_VLR || MAP_HLR */

#if MAP_MSC
  MA_MI_PREHO_RSP,              /* Message index */
  MA_MI_PERHO_RSP,              /* Message index */

#if MAP_REL99
  MA_MI_SNDENDSIG_RSP,          /* Message index */
#endif /* MAP_REL99 */

  MA_MI_PRESUBSHO_RSP,          /* Message index */
  MA_MI_PERSUBSHO_RSP,          /* Message index */
#endif /* MAP_MSC */
 
#if (MAP_MSC || MAP_GSN)
  MA_MI_FWDSM_RSP,              /* Message index */
  MA_MI_MTFWDSM_RSP,            /* Message type */
#endif /* MAP_MSC || MAP_GSN */
 
#if MAP_MSC
  MA_MI_RESCALLHANDL_RSP,               /* Message index */
  MA_MI_PREPGRPCALL_RSP,                /* Message index */
  MA_MI_SNDGRPCALLENDSIG_RSP,           /* Message index */
  MA_MI_PROVSIWFSNMB_RSP,               /* Message index */
  MA_MI_SIWFSSIGMOD_RSP,                /* Message index */
#endif  /* MSC */

#if MAP_VLR
  /* Send Identification Response */
  MA_MI_SNDID_RSP,              /* Message index */
#endif  /* MAP_VLR */

#if (MAP_HLR || MAP_MLC)
  MA_MI_ANYINTER_RSP,         /* Message type */
#endif /* MAP_HLR || MAP_MLC */

#if (MAP_HLR || MAP_GSN)
  MA_MI_GPRSUPLOC_RSP,
  MA_MI_GPRSROUTINFO_RSP,
  MA_MI_GPRSNOTEMSPRES_RSP,
  MA_MI_FAILRPT_RSP,           /* Message type */
#endif /* MAP_HLR || MAP_GSN */

/*  modified to include for REL5 GSN*/
#if (MAP_VLR || MAP_HLR || (MAP_GSN && MAP_REL5))
  MA_MI_PROVSUBSINFO_RSP,
#endif /* (MAP_VLR || MAP_HLR) */

#if (MAP_REL98 || MAP_REL99)

#if (MAP_HLR || MAP_MLC)
  MA_MI_ROUTINFOFORLCS_RSP,   /* Message type */
#endif /* MAP_HLR || MAP_MLC */

#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL99 && MAP_REL4 && MAP_GSN))
  MA_MI_PRVSUBSLOC_RSP,       /* Message type */
  MA_MI_SUBSLOCRPT_RSP,       /* Message type */
#endif  /*(MAP_MSC || MAP_MLC)*/
#endif

#endif /* MAP_REL98 || MAP_REL99 */

#if MAP_REL99

#if (MAP_VLR || MAP_HLR || MAP_GSN)
  MA_MI_AUTHFAILRPT_RSP,         /* Message index */
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
  MA_MI_NOTMMEV_RSP,       /* Message type */
#endif /* MAP_VLR || MAP_HLR */

#if (MAP_MSC || MAP_HLR)
  MA_MI_ISTALRT_RSP,              /* Message index */
  MA_MI_ISTCMD_RSP,              /* Message index */
#endif /* MAP_MSC || MAP_HLR */

#if MAP_HLR
  MA_MI_ANYSUBSINTER_RSP,       /* Message type */
  MA_MI_ANYMOD_RSP,             /* Message type */
  MA_MI_NOTSUBSMOD_RSP,         /* Message type */
#endif /* MAP_HLR */
   
#if MAP_REL6
#if MAP_MSC
  
  MA_MI_RELRES_RSP,           /* Message type */

#endif /* MAP_MSC */
#endif /* MAP_REL6 */

#endif /* MAP_REL99 */

#if MAP_SEC
  MA_MI_SECTRANS_CLASS1_RSP,  
  MA_MI_SECTRANS_CLASS3_RSP,  
#endif 

#ifdef XWEXT /* xingzhou.xu: added for paging detect 2006/10/16 */
  MA_MI_XW_DETECT_RSP,
#endif
  /*
  ** The following enum value is introduced to avoid the 
  ** trailing comma Warning coming from some of the compilers.
  */
  MA_MI_RSP_TERM
};

/* Enumerated values for return error codes for which parameters exist */
enum MaSSRetErr {

   MA_MI_ROAM_NOT_ALL_RE,
   MA_MI_CALL_BARRED_RE,
   MA_MI_CUG_REJECT_RE,
   MA_MI_SS_INCOMP_RE,
   MA_MI_SS_ERR_STATUS_RE,
   MA_MI_SM_DLVY_FAIL_RE,
   MA_MI_ABS_SUBS_SM_RE,
   MA_MI_EXT_SYS_FAIL_RE,
   MA_MI_DATA_MISS_RE,
   MA_MI_UNEX_DATA_RE,
   MA_MI_FAC_NOT_SUP_RE,
   MA_MI_OR_NOT_ALL_RE,
   MA_MI_UNKNOWN_SUBS_RE,
   MA_MI_NUMBER_CHANGED_RE,
   MA_MI_UNIDENT_SUB_RE,
   MA_MI_ILLEGAL_SUBS_RE,
   MA_MI_ILLEGAL_EQP_RE,
   MA_MI_BEAR_SERV_NOT_PROV_RE,
   MA_MI_TELE_SERV_NOT_PROV_RE,
   MA_MI_TRC_BUFFER_FULL_RE,
   MA_MI_NO_ROAM_NB_RE,
   MA_MI_ABS_SUBS_RE,
   MA_MI_BUSY_SUBS_RE,
   MA_MI_NO_SUBS_RPLY_RE,
   MA_MI_FWD_VIOLATION_RE,
   MA_MI_PW_REG_FAIL_RE,
   MA_MI_FWD_FAILED_RE,
   MA_MI_ATI_NOT_ALL_RE,
   MA_MI_SUB_BUSY_FOR_MTSMS_RE,
   MA_MI_MSG_WAIT_LIST_FULL_RE,
   MA_MI_RES_LMT_RE,
   MA_MI_NO_GRP_CALL_NB_RE,
   MA_MI_INCOMP_TERM_RE,
#if (MAP_REL98 || MAP_REL99)
   MA_MI_UNAUTH_REQ_NET_RE,
   MA_MI_POSI_METH_FAIL_RE,
   MA_MI_UNAUTH_LCS_CLIENT_RE,
   MA_MI_UNKWN_OR_UNRCH_LCS_CLIENT_RE,
#endif /* MAP_REL98 || MAP_REL99 */
#if MAP_REL99
   MA_MI_TARG_CELL_OUT_GCA_RE,
   MA_MI_ATSI_NOT_ALL_RE,
   MA_MI_ATM_NOT_ALL_RE,
   MA_MI_ILLEGAL_SS_OPR_RE,
   MA_MI_SS_NOT_AVAI_RE,
   MA_MI_SS_SUBS_VIOLATION_RE,
   MA_MI_INFO_NOT_AVAI_RE,
   MA_MI_EVENT_NOT_SUP_RE,
#endif /* MAP_REL99 */
   MA_MI_DLGPDU,
#if MAP_SEC
   MA_MI_SEC_TRANS_ERR_RE,
#endif

  /*
  ** The following enum value is introduced to avoid the 
  ** trailing comma Warning coming from some of the compilers.
  */
  MA_MI_ERR_TERM
};

#ifdef MA_SEG
#define MA_UPD_MAND_FLG \
  if(ctlp->segSz > 0)\
  {\
     if(ctlp->level == 1)\
     {\
        if(ctlp->mandFlg1 == FALSE)\
        {\
           ctlp->mandFlg1 = maChkEleMand(ctlp);\
        }\
     }\
     if(ctlp->level == 2)\
     {\
        if(ctlp->mandFlg2 == FALSE)\
        {\
           ctlp->mandFlg2 = maChkEleMand(ctlp);\
        }\
     }\
  }

#ifdef DEBUGP 
/* Take into account the smaller size of the first segment */  
#define  MA_UPD_OFFSET_ARRAY \
  if(ctlp->segSz > 0)\
  {\
     if(ctlp->offIdx >= 0)\
     {\
        MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, \
              "SEG LEVEL = %ld\n",ctlp->level));\
        if((ctlp->offLevel == 0) && (ctlp->level <= 2))\
        {\
           ctlp->offLevel = ctlp->level;\
           ctlp->offIdx1 = 0;\
        MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, \
              "SEG INIT-%ld:seg level = %ld\n",ctlp->segSz, ctlp->offLevel));\
        }\
        if(ctlp->offLevel == ctlp->level)\
        {\
           MsgLen mBufLen;\
           SFndLenMsg(ctlp->mBuf, &mBufLen);\
           ctlp->offset1[(++ctlp->offIdx1)] = (U32)mBufLen;\
           if(ctlp->offIdx1 > 0) \
              ctlp->offset1[ctlp->offIdx1-1] = \
                      ctlp->offset1[ctlp->offIdx1]-\
                      ctlp->offset1[ctlp->offIdx1-1];\
           MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, \
                  "SEG OFFSET:Parameter Length=%ld octets\n",ctlp->offset1[ctlp->offIdx1-1]));\
           if ((ctlp->offIdx == 0) && \
           ((U32)mBufLen <=  (ctlp->segSz - MA_OPRRSP_OFFSET)))\
           {\
              ctlp->offset[ctlp->offIdx] = (U32)mBufLen;\
              MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, \
                  "SEG BEGIN:offset=%ld octets\n",ctlp->offset[ctlp->offIdx]));\
           }\
           else if((ctlp->offIdx > 0) && \
           (((U32)mBufLen - ctlp->offset[ctlp->offIdx-1])<=  ctlp->segSz))\
           {\
              ctlp->offset[ctlp->offIdx] = (U32)mBufLen;\
              MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, \
                  "SEG UPD:segment no=%ld segment offset=%ld\n",(ctlp->offIdx+1),ctlp->offset[ctlp->offIdx]));\
           }\
           else if(((U32)mBufLen - ctlp->offset[ctlp->offIdx])<= ctlp->segSz)\
           {\
              ctlp->offset[(++ctlp->offIdx)] = (U32)mBufLen;\
              MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, \
                  "SEG CREATE:segment no=%ld segment offset=%ld\n",(ctlp->offIdx+1),ctlp->offset[ctlp->offIdx]));\
           }\
           else\
           {\
              ctlp->offIdx=-1;\
              MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, \
                  "SEG ERROR: Parameter size exceed segmentation size\n:"));\
           }\
        }\
     }\
  }
#else
/* Take into account the smaller size of the first segment */  
#define  MA_UPD_OFFSET_ARRAY \
  if(ctlp->segSz > 0)\
  {\
     if(ctlp->offIdx >= 0)\
     {\
        if((ctlp->offLevel == 0) && (ctlp->level <= 2))\
        {\
           ctlp->offLevel = ctlp->level;\
        }\
        if(ctlp->offLevel == ctlp->level)\
        {\
           MsgLen mBufLen;\
           SFndLenMsg(ctlp->mBuf, &mBufLen);\
           if ((ctlp->offIdx == 0) && \
           ((U32)mBufLen <=  (ctlp->segSz - MA_OPRRSP_OFFSET)))\
           {\
              ctlp->offset[ctlp->offIdx] = (U32)mBufLen;\
           }\
           else if((ctlp->offIdx > 0) && \
           (((U32)mBufLen - ctlp->offset[ctlp->offIdx-1])<=  ctlp->segSz))\
           {\
              ctlp->offset[ctlp->offIdx] = (U32)mBufLen;\
           }\
           else if(((U32)mBufLen - ctlp->offset[ctlp->offIdx])<= ctlp->segSz)\
           {\
              ctlp->offset[(++ctlp->offIdx)] = (U32)mBufLen;\
           }\
           else\
           {\
              ctlp->offIdx=-1;\
           }\
        }\
     }\
  }
#endif

#define MA_INCREASE_LEVEL ctlp->level++
#define MA_DECREASE_LEVEL ctlp->level--
#else
#define MA_UPD_MAND_FLG 

#define  MA_UPD_OFFSET_ARRAY 

#define MA_INCREASE_LEVEL 

#define MA_DECREASE_LEVEL 

#endif /* MA_SEG */
#ifdef MA_ASN_NO_INDEF_LEN
#ifdef MA_SEG
#define MA_SEG_TOP_SEQ_CHECK  \
if ((ctlp->segSz == 0 ) || (ctlp->level != 1) || (ctlp->offLevel != 2))
#else
#define MA_SEG_TOP_SEQ_CHECK if (1)
#endif /* MA_SEG */
#if (ERRCLASS & ERRCLS_ADD_RES)
#define MA_ENC_DEF_LEN(curLen, orgLen)\
MA_SEG_TOP_SEQ_CHECK\
{\
  if ((curLen - orgLen) <= MA_MAX_SBYTE_VAL)\
  {\
     ret = SRepMsg((U8)(curLen-orgLen), ctlp->mBuf, orgLen-1);\
     if (ret != ROK)\
     {\
        MALOGERROR(ERRCLS_DEBUG, EMA333, (ErrVal)ret, "SRepMsg() Failed");\
        RETVALUE(ret);\
     }\
  }\
  else\
  {\
     if ((ret = maEncLen(ctlp->mBuf, orgLen, curLen)) != ROK)\
     {\
        MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, \
              "maEncLen failed, Len(%d).\n", (curLen-orgLen)));\
        MALOGERROR(ERRCLS_DEBUG, EMA334, (ErrVal)ret, "maEncLen() Failed");\
        RETVALUE(ret);\
     }\
  }\
}\
else\
{\
 pkArray[0] = MA_TAG_EOC;\
 pkArray[1] = MA_TAG_EOC;\
 ret = SAddPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);\
 if (ret != ROK)\
 {\
  MALOGERROR(ERRCLS_ADD_RES, EMA335, (ErrVal)ret, "SAddPstMsgMult() Failed");\
  RETVALUE(ret);\
 }\
}
#else /* ERRCLASS & ERRCLS_ADD_RES */
#define MA_ENC_DEF_LEN(curLen, orgLen)\
MA_SEG_TOP_SEQ_CHECK \
{\
  if ((curLen - orgLen) <= MA_MAX_SBYTE_VAL)\
  {\
     ret = SRepMsg((U8)(curLen-orgLen), ctlp->mBuf, orgLen-1);\
  }\
  else\
  {\
     if ((ret = maEncLen(ctlp->mBuf, orgLen, curLen)) != ROK)\
     {\
        MADBGP(MA_DBGMASK_ENCODE, (maCb.maInit.prntBuf, \
              "maEncLen failed, Len(%d).\n", (curLen-orgLen)));\
        RETVALUE(ret);\
     }\
  }\
}\
else\
{\
 pkArray[0] = MA_TAG_EOC;\
 pkArray[1] = MA_TAG_EOC;\
 ret = SAddPstMsgMult(pkArray, (MsgLen)2, ctlp->mBuf);\
 if (ret != ROK)\
 {\
  RETVALUE(ret);\
 }\
}
#endif /* ERRCLASS & ERRCLS_ADD_RES */
#endif /* MA_ASN_NO_INDEF_LEN */
#endif  /* __MAMFH__ */

  
/********************************************************************30**
  
         End of file:     ma_mf.h@@/main/10 - Fri Sep 16 02:45:13 2005
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  aa   1. initial release

*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.2          ---      aa   1. Removed MA_TF_NA  as it is not used

1.3          ---      ssk  1. Added Phase 2+ variant

1.4          ---      ssk  1. added the dummy terminator value to 
                           protect the code from the compiler warnings.

             ---      ssk  1. added new context specific tags .        

             ---      ssk  2. The combinations of versions were moved 
                           from this file to lma.h.

/main/5      ---      jie  1. update for MAP 1.5 release.

             ---      jie  1. Change for MAP REL4 support without the MAPsec 
                              feature.

             ---      yz   1. Change for adding extCont in dlgPdu.

/main/6      ---      jie  1. update for MAP 1.6 release.

             ---      yz   1. Addition of MAP segmentation feature from 1.5.

             ---      yz   1. Addition of MAP Segmentation feature.
            
             ---      jie  1. Change for 2002/09 rel99/rel4 release.

/main/7      ---      jie  1. update for MAP 1.7 release.

             ---      jie  1. Addition for definite length encoding

             ---      ssk  1. Added Debug prints for segmentation.
                           2. Definite length encoding logic fixed 
                              for segmentation.
/main/9      ---      cp   1. update for MAP 1.7 release.
             ---      st   1. Change the MA_SEG_TOP_SEQ_CHECK to
                              avoid compilation problem.
                           2. Enabled MA_MI_PROVSUBSINFO_RSP for REL5
                              GSN.
/main/10     ---   rbabu   1.update for MAP 2.3 release.
ma001.203             st   1. Additional value for MAP +.
         ma002.203    dv   1. Introduced maCb global control block.
                           2. Moved global variabled to maCb.
                           3. Introduced SS_MULTIPLE_PROCS to aid
                              in internal testing.
/main/10  ma007.203  dm    1. Added new tag to be used in Dialogue PDU 
*********************************************************************91*/
