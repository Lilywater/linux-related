/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/
/********************************************************************20**
  
     Name:     TCAP Message encoder/decoder Database
  
     Type:     C Source file
  
     Desc:     C source code for TCAP message encoding/decoding 
               database
  
     File:     ct_db.c
  
     Sid:      ct_db.c@@/main/15 - Fri Nov 17 10:34:40 2000
  
     Prg:      nj
  
*********************************************************************21*/


/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif
#ifdef CCITT96
               CCITT 96
#endif

************************************************************************/

/*
*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000031     SS7 - TCAP
*
*/
 

/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* Common timer */
#include "cm_ss7.h"
#include "cm_hash.h"       /* Common hashing */
#include "cm_asn.h"        /* Common asn.1 */
#include "cm_err.h"        /* Common error */
#include "stu.h"           /* Tcap services */
#include "spt.h"           /* Sccp layer */
#include "lst.h"           /* Layer management, TCAP */
#include "st.h"            /* Tcap */
#include "st_mf.h"         /* Tcap */
#include "st_db.h"         /* Tcap ASN.1 tag defines */
#include "st_err.h"        /* Tcap error */

#ifdef ST_FTHA
#include "sht.h"           /* SHT */
#include "mrs.h"           /* MRS */
#endif /* ST_FTHA */

#ifdef ZT
#include "cm_ftha.h"
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#ifdef ZT_DFTHA
#include "cmztdt.h"
#include "cmztdtlb.h"
#endif /* ZT_DFTHA */
#include "zt.h"            /* Tcap PSF defines */
#include "lzt.h"
#endif /* ZT */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer */
#include "ssi.x"           /* System services */
#include "cm5.x"           /* Common timer */
#include "cm_ss7.x"        /* Common */
#include "cm_hash.x"       /* Common hashing */
#include "cm_asn.x"        /* Common asn.1 */
#include "cm_lib.x"        /* Common */
#include "stu.x"           /* Tcap layer */
#include "spt.x"           /* Sccp layer */
#include "lst.x"           /* Layer management, TCAP */
#include "st_mf.x"         /* Tcap */

#ifdef ZT
#include "cm_ftha.x"
#include "cm_pftha.x"      /* Common PSF typedefs */
#include "cm_psfft.x"
#endif /* ZT */

#ifdef ST_FTHA
#include "sht.x"           /* SHT */
/* st005.301 - Deleted - mrs.x included under ZT */
#endif /* ST_FTHA */

#include "st.x"            /* Tcap */
 
#ifdef ZT
/* st005.301 - Added - mrs.x included here */
#include "mrs.x"           /* MRS */
#ifdef ZT_DFTHA
#include "cmztdt.x"
#include "cmztdtlb.x"
#endif /* ZT_DFTHA */
#include "lzt.x"
#include "zt.x"            /* Tcap PSF typedefs */
#endif /* ZT */



/* local defines */

/* local externs */

/* forward references */

/* functions in other modules */
EXTERN  S16   stEdcBuffer   ARGS((CmAsnMsgCp   *msgCp));
  
/* public variable declarations */
/*
*   Naming Convention : Letter "C" is appended to the element names which
*   are of constructor type and "P" is appended for the primitive types.
*   Element "setSeqTerm" mark the end of the corresponding constructor type.
*   Letter "M" is appended to the element names which are mandatory element
*   and letter "O" is appended for the optional elements.
*/

/* Protocol Flags */

/* Flag for Mandatory elements in ITU-1988 version of TCAP */
PUBLIC U32 flagItu88M  = TYPE_TO_FLAG(CM_ASN_ITU_1988, ELMNT_MAND); 

/* Flag for Optional elements in ITU-1988 version of TCAP */
PUBLIC U32 flagItu88O  = TYPE_TO_FLAG(CM_ASN_ITU_1988, ELMNT_OPT); 

/* Flag for Mandatory elements in ITU-1992 version of TCAP */
PUBLIC U32 flagItu92M  = TYPE_TO_FLAG(CM_ASN_ITU_1992, ELMNT_MAND); 

/* Flag for Optional elements in ITU-1992 version of TCAP */
PUBLIC U32 flagItu92O  = TYPE_TO_FLAG(CM_ASN_ITU_1992, ELMNT_OPT); 

/* Flag for Mandatory elements in ITU-1996 version of TCAP */
PUBLIC U32 flagItu96M  = TYPE_TO_FLAG(CM_ASN_ITU_1996, ELMNT_MAND); 

/* Flag for Optional elements in ITU-1996 version of TCAP */
PUBLIC U32 flagItu96O  = TYPE_TO_FLAG(CM_ASN_ITU_1996, ELMNT_OPT); 

/* Flag for Mandatory elements in all ITU versions of TCAP */
PUBLIC U32 flagItuM  = (TYPE_TO_FLAG(CM_ASN_ITU_1988, ELMNT_MAND) |
                        TYPE_TO_FLAG(CM_ASN_ITU_1992, ELMNT_MAND) |
                        TYPE_TO_FLAG(CM_ASN_ITU_1996, ELMNT_MAND));

/* Flag for Optional elements in all ITU versions of TCAP */
PUBLIC U32 flagItuO  = (TYPE_TO_FLAG(CM_ASN_ITU_1988, ELMNT_OPT) |
                        TYPE_TO_FLAG(CM_ASN_ITU_1992, ELMNT_OPT) |
                        TYPE_TO_FLAG(CM_ASN_ITU_1996, ELMNT_OPT));


/* Flag for Mandatory elements in all versions of TCAP */
PUBLIC U32 flagAllM  = (TYPE_TO_FLAG(CM_ASN_ITU_1988, ELMNT_MAND)  |
                        TYPE_TO_FLAG(CM_ASN_ITU_1992, ELMNT_MAND)  |
                        TYPE_TO_FLAG(CM_ASN_ITU_1996, ELMNT_MAND)  |
                        TYPE_TO_FLAG(CM_ASN_ANSI_1988, ELMNT_MAND) |
                        TYPE_TO_FLAG(CM_ASN_ANSI_1992, ELMNT_MAND) |
                        TYPE_TO_FLAG(CM_ASN_ANSI_1996, ELMNT_MAND));

/* Flag for Optional elements in all versions of TCAP */
PUBLIC U32 flagAllO  = (TYPE_TO_FLAG(CM_ASN_ITU_1988, ELMNT_OPT)  |
                        TYPE_TO_FLAG(CM_ASN_ITU_1992, ELMNT_OPT)  |
                        TYPE_TO_FLAG(CM_ASN_ITU_1996, ELMNT_OPT)  |
                        TYPE_TO_FLAG(CM_ASN_ANSI_1988, ELMNT_OPT) |
                        TYPE_TO_FLAG(CM_ASN_ANSI_1992, ELMNT_OPT) |
                        TYPE_TO_FLAG(CM_ASN_ANSI_1996, ELMNT_OPT));

/* private variable declarations */

/******************************************************************************
                PROTOCOL MESSAGE ELEMENT DEFINITIONS
******************************************************************************/

/* Element definitions for ITU Dialogue Portion */

/* Optioanl Element for start of dialogue portion */
PRIVATE CmElmntDef ituDlgPrtnCO = 
{
/* add by xingzhou.xu for INTE_CAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituDlgPrtnCO", /* Parameter Description */
#endif
   TET_SEQ,                     /* Token Element type */
   TAG(ST_ITU_DLG_PRTN_TAG),    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(StItuDlgEv),          /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItu92O,                 /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* External Element */
PRIVATE CmElmntDef ituExternalCM = 
{
/* add by xingzhou.xu for INTE_CAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituExternalCM", /* Parameter Description */
#endif
   TET_SEQ,                     /* Token Element type */
   TAG(ST_ITU_EXTERNAL_TAG),    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(StItuDlgEv),          /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItu92M,                 /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Single ASN.1 Type */
PRIVATE CmElmntDef ituAsn1TypeCM = 
{
/* add by xingzhou.xu for INTE_CAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituAsn1TypeCM", /* Parameter Description */
#endif
   TET_SEQ,                     /* Token Element type */
   TAG(ST_ITU_SNGL_ASN1_TAG),   /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(StItuDlgType),        /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItu92M,                 /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Element to indicate start of Mandatory Dialogue Pdu choice type */
PRIVATE CmElmntDef ituDlgApduChoiceCM = 
{
/* add by xingzhou.xu for INTE_CAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituDlgApduChoiceCM", /* Parameter Description */
#endif
   TET_CHOICE,                  /* Token Element type */
   TAG_NULL,                    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(StItuDlgType),        /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItu92M,                 /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Object Identifier */
PRIVATE CmElmntDef ituDlgAsIdPM = 
{
/* add by xingzhou.xu for INTE_CAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituDlgAsIdPM", /* Parameter Description */
#endif
   TET_STR12,                   /* Token Element type */
   TAG(ST_ITU_OBJID_TAG),       /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   sizeof(PTR),                 /* sequence size */
   sizeof(TknStr12),            /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItu92M,                 /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Dialogue APDU types */

/* Unidirectional Dialogue (AUDT-apdu) */
PRIVATE CmElmntDef ituDlgUniCM = 
{
/* add by xingzhou.xu for INTE_CAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituDlgUniCM", /* Parameter Description */
#endif
   TET_SEQ,                     /* Token Element type */
   TAG(ST_ITU_DLG_UNI_TAG),     /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(StItuDlgUni),         /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItu92M,                 /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};

/* Request Dialogue (AARQ-apdu) */
PRIVATE CmElmntDef ituDlgReqCM = 
{
/* add by xingzhou.xu for INTE_CAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituDlgReqCM", /* Parameter Description */
#endif
   TET_SEQ,                     /* Token Element type */
   TAG(ST_ITU_DLG_REQ_TAG),     /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(StItuDlgReq),         /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItu92M,                 /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Response Dialogue (AARE-apdu) */
PRIVATE CmElmntDef ituDlgRspCM = 
{
/* add by xingzhou.xu for INTE_CAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituDlgRspCM", /* Parameter Description */
#endif
   TET_SEQ,                     /* Token Element type */
   TAG(ST_ITU_DLG_RSP_TAG),     /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(StItuDlgRsp),         /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItu92M,                 /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Abort Dialogue (ABRT-apdu) */
PRIVATE CmElmntDef ituDlgAbtCM = 
{
/* add by xingzhou.xu for INTE_CAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituDlgAbtCM", /* Parameter Description */
#endif
   TET_SEQ,                     /* Token Element type */
   TAG(ST_ITU_DLG_ABT_TAG),     /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(StItuDlgAbt),         /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItu92M,                 /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Protocol Version */
PRIVATE CmElmntDef ituProtVerPO =
{
/* add by xingzhou.xu for INTE_CAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituProtVerPO", /* Parameter Description */
#endif
   TET_STR4,                    /* Token Element type */
   TAG(ST_ITU_PROT_VER_TAG),    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   2,                           /* maximum length */
   sizeof(PTR),                 /* sequence size */
   sizeof(TknStr4),             /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItu92O,                 /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};
 

/* Application Context Name - Constructor */
PRIVATE CmElmntDef ituDlgAcnCM =
{
/* add by xingzhou.xu for INTE_CAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituDlgAcnCM", /* Parameter Description */
#endif
   TET_SEQ,                     /* Token Element type */
   TAG(ST_ITU_ACN_TAG),         /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(StAcn) + sizeof(TknU8),/* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItu92M,                 /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};
 

/* Application Context Name - primitive */
PRIVATE CmElmntDef ituDlgAcnPM = 
{
/* add by xingzhou.xu for INTE_CAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituDlgAcnPM", /* Parameter Description */
#endif
   TET_STR256,                  /* Token Element type */
   TAG(ST_ITU_OBJID_TAG),       /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   sizeof(PTR),                 /* sequence size */
   sizeof(StAcn),               /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItu92M,                 /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* User Information */
PRIVATE CmElmntDef ituDlgUsrInfoPO =
{
/* add by xingzhou.xu for INTE_CAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituDlgUsrInfoPO", /* Parameter Description */
#endif
   TET_ESC,                     /* Token Element type */
   TAG(ST_ITU_USRINFO_TAG),     /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   sizeof(PTR),                 /* sequence size */
   sizeof(TknBuf),              /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItu92O,                 /* token defination flags */
   NULLP,                       /* list of enumerated values */
   stEdcBuffer                  /* user function */
};


/* Result */
PRIVATE CmElmntDef ituDlgResultCM =
{
/* add by xingzhou.xu for INTE_CAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituDlgResultCM", /* Parameter Description */
#endif
   TET_SEQ,                     /* Token Element type */
   TAG(ST_ITU_RESULT_TAG),      /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(TknU8),               /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItu92M,                 /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Integer */
PRIVATE CmElmntDef ituIntegerPM =
{
/* add by xingzhou.xu for INTE_CAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituIntegerPM", /* Parameter Description */
#endif
   TET_U8,                      /* Token Element type */
   TAG(ST_ITU_INTEGER_TAG),     /* tag value */
   1,                           /* minimum length */
   1,                           /* maximum length */
   sizeof(PTR),                 /* sequence size */
   sizeof(TknU8),               /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Result Source Diagonostic */
PRIVATE CmElmntDef ituDlgResSrcDiagCM =
{
/* add by xingzhou.xu for INTE_CAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituDlgResSrcDiagCM", /* Parameter Description */
#endif
   TET_SEQ,                     /* Token Element type */
   TAG(ST_ITU_RES_DIAG_TAG),    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(TknU8)+sizeof(TknU8), /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItu92M,                 /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Choice for Result Source type */
PRIVATE CmElmntDef ituDlgSrcChoiceCM =
{
/* add by xingzhou.xu for INTE_CAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituDlgSrcChoiceCM", /* Parameter Description */
#endif
   TET_CHOICE,                  /* Token Element type */
   TAG_NULL,                    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(TknU8) + sizeof(TknU8) + sizeof(TknU8),/* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItu92M,                 /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Dialogue Service Provider */
PRIVATE CmElmntDef ituDlgSpCM =
{
/* add by xingzhou.xu for INTE_CAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituDlgSpCM", /* Parameter Description */
#endif
   TET_SEQ,                     /* Token Element type */
   TAG(ST_ITU_DLG_SP_TAG),      /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(TknU8),               /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItu92M,                 /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Dialogue Service User */
PRIVATE CmElmntDef ituDlgSuCM =
{
/* add by xingzhou.xu for INTE_CAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituDlgSuCM", /* Parameter Description */
#endif
   TET_SEQ,                     /* Token Element type */
   TAG(ST_ITU_DLG_SU_TAG),      /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(TknU8),               /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItu92M,                 /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Abort Source */
PRIVATE CmElmntDef ituAbrtSrcPM =
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituAbrtSrcPM", /* Parameter Description */
#endif
   TET_U8,                      /* Token Element type */
   TAG(ST_ITU_ABT_SRC_TAG),     /* tag value */
   1,                           /* minimum length */
   1,                           /* maximum length */
   sizeof(PTR),                 /* sequence size */
   sizeof(TknU8),               /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItu92M,                 /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Component Portion Elements */

/* Element to indicate start of Component choice type */
PRIVATE CmElmntDef ituCompChoiceCM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituCompChoiceCM", /* Parameter Description */
#endif
   TET_CHOICE,                  /* Token Element type */
   TAG_NULL,                    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(StItuCompEv),         /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Invoke Component */
PRIVATE CmElmntDef ituCompInvCM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituCompInvCM", /* Parameter Description */
#endif
   TET_SEQ,                     /* Token Element type */
   TAG(ST_ITU_COMP_INV_TAG),    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(StItuCompInv),        /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Return result Last Component */
PRIVATE CmElmntDef ituCompResLCM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituCompResLCM", /* Parameter Description */
#endif
   TET_SEQ,                     /* Token Element type */
   TAG(ST_ITU_COMP_RES_TAG),    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(StItuCompRes),        /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Return Error Component */
PRIVATE CmElmntDef ituCompErrCM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituCompErrCM", /* Parameter Description */
#endif
   TET_SEQ,                     /* Token Element type */
   TAG(ST_ITU_COMP_ERR_TAG),    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(StItuCompErr),        /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Reject Component */
PRIVATE CmElmntDef ituCompRejCM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituCompRejCM", /* Parameter Description */
#endif
   TET_SEQ,                     /* Token Element type */
   TAG(ST_ITU_COMP_REJ_TAG),    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(StItuCompRej),        /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Return Result Not Last Component */
PRIVATE CmElmntDef ituCompResNLCM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituCompResNLCM", /* Parameter Description */
#endif
   TET_SEQ,                     /* Token Element type */
   TAG(ST_ITU_COMP_RNL_TAG),    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(StItuCompRes),        /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Invoke Id */
PRIVATE CmElmntDef ituInvIdPM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituInvIdPM", /* Parameter Description */
#endif
   TET_U8,                      /* Token Element type */
   TAG(ST_ITU_INV_ID_TAG),      /* tag value */
   1,                           /* minimum length */
   1,                           /* maximum length */
   sizeof(PTR),                 /* sequence size */
   sizeof(TknU8),               /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Linked Id */
PRIVATE CmElmntDef ituLnkIdPO = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituLnkIdPO", /* Parameter Description */
#endif
   TET_U8,                      /* Token Element type */
   TAG(ST_ITU_LNKD_ID_TAG),     /* tag value */
   1,                           /* minimum length */
   1,                           /* maximum length */
   sizeof(PTR),                 /* sequence size */
   sizeof(TknU8),               /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuO,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Element to indicate start of operation code choice type */
PRIVATE CmElmntDef ituOpCodeChoiceCM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituOpCodeChoiceCM", /* Parameter Description */
#endif
   TET_CHOICE,                  /* Token Element type */
   TAG_NULL,                    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(TknU8) + sizeof(TknStr32),/* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Element to indicate start of operation code choice type */
PRIVATE CmElmntDef ituOpCodeChoiceCO = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituOpCodeChoiceCO", /* Parameter Description */
#endif
   TET_CHOICE,                  /* Token Element type */
   TAG_NULL,                    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(TknU8) + sizeof(TknStr32),/* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuO,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Mandatory Local Operation Code */
PRIVATE CmElmntDef ituCompLOpCodePM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituCompLOpCodePM", /* Parameter Description */
#endif
   TET_STR32,                   /* Token Element type */
   TAG(ST_ITU_LCL_OPCODE_TAG),  /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   sizeof(PTR),                 /* sequence size */
   sizeof(TknStr32),            /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Mandatory Global Operation Code */
PRIVATE CmElmntDef ituCompGOpCodePM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituCompGOpCodePM", /* Parameter Description */
#endif
   TET_STR32,                   /* Token Element type */
   TAG(ST_ITU_GBL_OPCODE_TAG),  /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   sizeof(PTR),                 /* sequence size */
   sizeof(TknStr32),            /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Mandatory Component Parameters */
PRIVATE CmElmntDef ituCompParamPM =
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituCompParamPM", /* Parameter Description */
#endif
   TET_ESC,                     /* Token Element type */
   TAG_NULL,                    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   sizeof(PTR),                 /* sequence size */
   sizeof(TknBuf),              /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   stEdcBuffer                  /* user function */
};


/* Optional Component Parameters */
PRIVATE CmElmntDef ituCompParamPO =
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituCompParamPO", /* Parameter Description */
#endif
   TET_ESC,                     /* Token Element type */
   TAG_NULL,                    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   sizeof(PTR),                 /* sequence size */
   sizeof(TknBuf),              /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuO,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   stEdcBuffer                  /* user function */
};


/* Sequence */
PRIVATE CmElmntDef ituSequenceCO = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituSequenceCO", /* Parameter Description */
#endif
   TET_SEQ,                     /* Token Element type */
   TAG(ST_ITU_SEQ_TAG),         /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(StItuCompRes) - sizeof(TknU8),  /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuO,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Element to indicate start of Error Code choice type */
PRIVATE CmElmntDef ituErrCodeChoiceCM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituErrCodeChoiceCM", /* Parameter Description */
#endif
   TET_CHOICE,                  /* Token Element type */
   TAG_NULL,                    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(TknU8) + sizeof(TknStr32),/* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Mandatory Local Error Code */
PRIVATE CmElmntDef ituCompLErrCodePM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituCompLErrCodePM", /* Parameter Description */
#endif
   TET_STR32,                   /* Token Element type */
   TAG(ST_ITU_LCL_ERRCODE_TAG), /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   sizeof(PTR),                 /* sequence size */
   sizeof(TknStr32),            /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Mandatory Global Error Code */
PRIVATE CmElmntDef ituCompGErrCodePM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituCompGErrCodePM", /* Parameter Description */
#endif
   TET_STR32,                   /* Token Element type */
   TAG(ST_ITU_GBL_ERRCODE_TAG), /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   sizeof(PTR),                 /* sequence size */
   sizeof(TknStr32),            /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Mandatory Choice for Invoke id or Null */
PRIVATE CmElmntDef ituInvIdChoiceCM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituInvIdChoiceCM", /* Parameter Description */
#endif
   TET_CHOICE,                  /* Token Element type */
   TAG_NULL,                    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(TknU8) + sizeof(TknU8),/* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Null */
PRIVATE CmElmntDef ituNullTagPM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituNullTagPM", /* Parameter Description */
#endif
   TET_NULL,                    /* Token Element type */
   TAG(ST_NULL_TAG),            /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   sizeof(PTR),                 /* sequence size */
   sizeof(TknU8),               /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Mandatory Choice for problem code */
PRIVATE CmElmntDef ituProbCodeChoiceCM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituProbCodeChoiceCM", /* Parameter Description */
#endif
   TET_CHOICE,                  /* Token Element type */
   TAG_NULL,                    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   0,                           /* sequence size */
   sizeof(TknU8) + sizeof(TknU8),/* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* General Problem Code */
PRIVATE CmElmntDef ituGenProbCodePM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituGenProbCodePM", /* Parameter Description */
#endif
   TET_U8,                      /* Token Element type */
   TAG(ST_ITU_GEN_PRBCODE_TAG), /* tag value */
   /* st023.301 - Modification, length of integer decoding should be checked */
   1,                           /* minimum length */
   1,                           /* maximum length */
   sizeof(PTR),                 /* sequence size */
   sizeof(TknU8),               /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Invoke Problem Code */
PRIVATE CmElmntDef ituInvProbCodePM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituInvProbCodePM", /* Parameter Description */
#endif
   TET_U8,                      /* Token Element type */
   TAG(ST_ITU_INV_PRBCODE_TAG), /* tag value */
   /* st023.301 - Modification, length of integer decoding should be checked */
   1,                           /* minimum length */
   1,                           /* maximum length */
   sizeof(PTR),                 /* sequence size */
   sizeof(TknU8),               /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Return Result Problem Code */
PRIVATE CmElmntDef ituResProbCodePM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituResProbCodePM", /* Parameter Description */
#endif
   TET_U8,                      /* Token Element type */
   TAG(ST_ITU_RES_PRBCODE_TAG), /* tag value */
   /* st023.301 - Modification, length of integer decoding should be checked */
   1,                           /* minimum length */
   1,                           /* maximum length */
   sizeof(PTR),                 /* sequence size */
   sizeof(TknU8),               /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/* Return Error Problem Code */
PRIVATE CmElmntDef ituErrProbCodePM = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "ituErrProbCodePM", /* Parameter Description */
#endif
   TET_U8,                      /* Token Element type */
   TAG(ST_ITU_ERR_PRBCODE_TAG), /* tag value */
   /* st023.301 - Modification, length of integer decoding should be checked */
   1,                           /* minimum length */
   1,                           /* maximum length */
   sizeof(PTR),                 /* sequence size */
   sizeof(TknU8),               /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   &flagItuM,                   /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};




/* Element to indicate end of a sequence */
PRIVATE CmElmntDef setSeqTerm = 
{
/* add by xingzhou.xu for TCAP debuging encode 2006/03/30 */
#ifdef CM_ASN_DBG
   "setSeqTerm", /* Parameter Description */
#endif
   TET_SETSEQ_TERM,             /* Token Element type */
   TAG_NULL,                    /* tag value */
   MIN_LEN_NA,                  /* minimum length */
   MAX_LEN_NA,                  /* maximum length */
   sizeof(PTR),                 /* element size */
   0,                           /* Event structure size */
   REP_CNTR_NA,                 /* counter for repeatable elements */
   NULLP,                       /* token defination flags */
   NULLP,                       /* list of enumerated values */
   NULLP                        /* user function */
};


/******************************************************************************
                            Message Definitions
******************************************************************************/

/* Dialogue Portion Definition */

PUBLIC CmElmntDef *stItuDlgDef[] =
{
   &ituDlgPrtnCO,           /* Dialogue Portion */
   &ituExternalCM,
   &ituDlgAsIdPM,           /* Dialogue-as-ID value */
   &ituAsn1TypeCM,          /* Single-ASN.1-Type */
   &ituDlgApduChoiceCM,     /* choice for dialogue PDUs */
   
   &ituDlgUniCM,            /* Unidirectional Dialogue (AUDT-apdu) */
   &ituProtVerPO,           /* Protocol Version */
   &ituDlgAcnCM,            /* Application Context Name */
   &ituDlgAcnPM,
   &setSeqTerm,
   &ituDlgUsrInfoPO,        /* User Information */
   &setSeqTerm,

   &ituDlgReqCM,            /* Dialogue Request (AARQ-apdu) */
   &ituProtVerPO,           /* Protocol Version */
   &ituDlgAcnCM,            /* Application Context Name */
   &ituDlgAcnPM,
   &setSeqTerm,
   &ituDlgUsrInfoPO,        /* User Information */
   &setSeqTerm,

   &ituDlgRspCM,            /* Dialogue Response (AARE-apdu) */
   &ituProtVerPO,           /* Protocol Version */
   &ituDlgAcnCM,            /* Application Context Name */
   &ituDlgAcnPM,
   &setSeqTerm,
   &ituDlgResultCM,         /* Result */
   &ituIntegerPM,
   &setSeqTerm,
   &ituDlgResSrcDiagCM,     /* Result Source Diagnostic */
   &ituDlgSrcChoiceCM,      /* Choice for service user/service provider */
   &ituDlgSuCM,             /* Dialogue Service User */
   &ituIntegerPM,
   &setSeqTerm,
   &ituDlgSpCM,             /* Dialogue Service Provider */
   &ituIntegerPM,
   &setSeqTerm,
   &setSeqTerm,
   &setSeqTerm,
   &ituDlgUsrInfoPO,        /* User Information */
   &setSeqTerm,

   &ituDlgAbtCM,            /* Dialogue Abort (ABRT-apdu) */
   &ituAbrtSrcPM,           /* Abort Source */
   &ituDlgUsrInfoPO,        /* User Information */
   &setSeqTerm,

   &setSeqTerm,             /* End of choice for dialogue PDUs */
   &setSeqTerm,             /* End of ASN.1 type */
   &setSeqTerm,             /* End of External type */
   &setSeqTerm,             /* End of Dialogue portion */
   NULLP
}; /* End of stItuDlgDef */


/* Component Portion definition */

PUBLIC CmElmntDef *stItuCompDef[] =
{
   &ituCompChoiceCM,        /* Choice for comp type */

   &ituCompInvCM,           /* Invoke component */
   &ituInvIdPM,             /* Invoke Id */ 
   &ituLnkIdPO,             /* Linked Id */
   &ituOpCodeChoiceCM,      /* Choice for Local/Global Operation Code */
   &ituCompLOpCodePM,       /* Local Operation Code */
   &ituCompGOpCodePM,       /* Global Operation Code */
   &setSeqTerm,
   &ituCompParamPO,         /* Component Parameters */
   &setSeqTerm,

   &ituCompResLCM,          /* Return Result Last component */
   &ituInvIdPM,             /* Invoke Id */ 
   &ituSequenceCO,          /* Sequence */
   &ituOpCodeChoiceCM,      /* Choice for Local/Global Operation Code */
   &ituCompLOpCodePM,       /* Local Operation Code */
   &ituCompGOpCodePM,       /* Global Operation Code */
   &setSeqTerm,
   &ituCompParamPM,         /* Component Parameters */
   &setSeqTerm,
   &setSeqTerm, 

   &ituCompErrCM,           /* Return Error component */
   &ituInvIdPM,             /* Invoke Id */ 
   &ituErrCodeChoiceCM,     /* Choice for local/global error code */
   &ituCompLErrCodePM,      /* Local Error code */
   &ituCompGErrCodePM,      /* Global Error code */
   &setSeqTerm,
   &ituCompParamPO,         /* Component Parameters */
   &setSeqTerm,

   &ituCompRejCM,           /* Reject component */
   &ituInvIdChoiceCM,       /* Choice for Null tag or Invoke Id tag */
   &ituInvIdPM,             /* Invoke Id */ 
   &ituNullTagPM,           /* Null Tag */
   &setSeqTerm,
   &ituProbCodeChoiceCM,    /* Choice for type of problem code */
   &ituGenProbCodePM,
   &ituInvProbCodePM,
   &ituResProbCodePM,
   &ituErrProbCodePM,
   &setSeqTerm,
   &setSeqTerm,

   &ituCompResNLCM,         /* Return Result Not Last component */
   &ituInvIdPM,             /* Invoke Id */ 
   &ituSequenceCO,          /* Sequence */
   &ituOpCodeChoiceCO,      /* Choice for Local/Global Operation Code */
   &ituCompLOpCodePM,       /* Local Operation Code */
   &ituCompGOpCodePM,       /* Global Operation Code */
   &setSeqTerm,
   &ituCompParamPM,         /* Component Parameters */
   &setSeqTerm,
   &setSeqTerm, 

   &setSeqTerm,             /* End of Choice for comp type */
   NULLP                    /* End of Components Definition */
}; /* End of stItuCompDef */


PUBLIC CmElmntDef **stMsgDbDef[] =
{
    stItuCompDef,
    stItuDlgDef

};


/********************************************************************30**

         End of file:     ct_db.c@@/main/15 - Fri Nov 17 10:34:40 2000

*********************************************************************31*/

/********************************************************************40**

       Notes:

*********************************************************************41*/



/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

          Revision history:

*********************************************************************61*/


/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  mma   1. initial release

1.2          ---  mma   1. miscellaneous changes
 
1.3          ---  mma   1. remove some unused local variables
 
1.4          ---  mma   1. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92

1.5          ---  mma   1. remove constPrim from encode/decode funcs.
             ---  mma   2. removed ACG and DIG type encode/decode

1.6          ---  lc    1. added stEncLong function
             ---  lc    2. changed stEncTransId function
             ---  ak    3. replaced ss_ms/ss_pt.[hx] with ssi.[hx]

1.7          ---  ak    1. include cm5.[hx]

1.8          ---  ak    1. added stPkIntegerVal and stUnpkIntegerVal
                           to encode and decode integers in BER format.

1.9          ---  aa    1. Changes due to TCAP uuper interface changes.
             ---  aa    2. surrounded instances of ANSI88 with ANSI92.

1.10         ---  aa    1. miscellaneous changes

1.11         ---  aa    1. Changes due to removing of Serror's

*********************************************************************81*/


/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.12         ---      aa   1. Include cm_ss7.x before lst.x
             ---     aa   2. Added the check for length of Component Id

1.13         ---      nj   1. Rewrote the file.
1.14         ---      nj   1. Added support for ITU-96.
1.15         st002.28 nj   1. Corrected the tag value define for ANSI parameter set.
/main/15     ---      nj   1. Changes for distributed FTHA
            st005.301 zr   1. File mrs.x included under ZT  
/main/15    st023.301 jz   1. Corrected the length value for ITU problem code.
  
*********************************************************************91*/
