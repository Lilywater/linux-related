/********************************************************

*********************************************************/
#ifdef SSI_WITH_CLI_ENABLED

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_llist.h"
#include "cm5.h"
#include "cm_ss7.h"
#include "cm_hash.h"       /* common hash */
#include "cm_err.h"        /* common error */
#include "stu.h"           /* tcap services user */
#include "spt.h"           /* sccp layer */
#include "lst.h"           /* layer management, TCAP */
#include "st.h"            /* tcap */
#include "st_mf.h"         /* tcap */
#include "st_db.h"         /* tcap Database */
#include "st_err.h"        /* tcap error */
#ifdef STTST
#include "st_acc.h"        /* Tcap Test*/
#endif
#ifdef ST_FTHA
#include "sht.h"           /* SHT */
#endif /* ST_FTHA */

#ifdef ZT
#include "cm_ftha.h"       /* Common FTHA */
#include "mrs.h"           /* Message router interface */
#include "cm_pftha.h"      /* Common protocol FTHA */
#include "cm_psfft.h"
#ifdef ZT_DFTHA
#include "cmztdt.h"
#include "cmztdtlb.h"
#endif /* ZT_DFTHA */
#include "mrs.h"
#include "zt.h"            /* Tcap PSF defines */
#include "lzt.h"
#include "zt_acc.h"        /* Tcap PSF test */
#endif /* ZT */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_llist.x"
#include "cm5.x"
#include "cm_ss7.x"        /* Common */
#include "cm_hash.x"       /* Common hash */
#include "stu.x"           /* Tcap layer */
#include "lst.x"           /* Layer management, TCAP */
#include "spt.x"           /* Sccp layer */
#include "st_mf.x"         /* Tcap */
/* st014.301 -Add- include cm_lib.x */
#include "cm_lib.x"        /* Common library */       

#ifdef ZT
#include "cm_ftha.x"       /* Common FTHA */
#include "mrs.x"           /* Message router interface */
#include "cm_pftha.x"      /* Common protocol FTHA */
#include "cm_psfft.x"
#ifdef ZT_DFTHA
#include "cmztdt.x"
#include "cmztdtlb.x"
#endif /* ZT_DFTHA */
#include "lzt.x"
#endif /* ZT */

#ifdef ST_FTHA
#include "sht.x"           /* SHT */
#endif /* ST_FTHA */

#include "st.x"            /* Tcap */
#ifdef STTST
#include "st_acc.x"        /* Tcap Test*/
#endif

#ifdef ZT
#include "mrs.x"
#include "zt.x"            /* Tcap PSF typedefs */
#include "zt_acc.x"        /* Tcap PSF test */
#endif /* ZT */

#include "xosshell.h"

#ifdef CP_OAM_SUPPORT
#include "sm.h"
#include "sm.x"
#include "cp_tab_def.h"
#include "cp_oam_stru.x"
#include "cp_oam_stru.h"
#include "oam_interface.h"
#include "st_nms.h"
#include "st_cfg.h"
#include "oam_tab_def.h"
#include "cp_oam_stru.x"
#include "st_oam.x"
#endif

#include "st_init.h"

#ifdef CP_OAM_SUPPORT
EXTERN CmLListCp gStSmQ[CP_TCAP_CONFIG_Q_TOTAL_NUM];
EXTERN U32 stCfgTbl[];
EXTERN unsigned char stInitCfgCallback(U16 msgtype, U32 sequense, U8 pack_end, tb_record * prow);
EXTERN S16  smRegCb(Ent entId, CmLListCp *smSaQ, U8 reqQNum, FUNC_SM_SEND_REQQ smSendReqQ, FUNC_SM_RESET_CFG_DATA smResetCfgData);
#endif

/* Extern var. */
EXTERN U8 stAccSPSapSSN;

/* Extern Func */


/*
*
*       Fun:   stInitHdr
*
*       Desc:  Initialize the LM request header
*
*       Ret:   None
*
*       Notes: None
*
*       File:  st_init.c
*
*/
#ifdef ANSI
PUBLIC Void stInitHdr
(
Header     *hdr,          /* Management header */
TranId      transId       /* Transaction Id */
)
#else
PUBLIC Void stInitHdr(hdr, transId)
Header     *hdr;          /* Management header */
TranId      transId;      /* Transaction Id */
#endif
{
   TRC2(stInitHdr)

   hdr->msgType          = 0;
   hdr->msgLen           = 0;
   hdr->entId.ent        = 0;
   hdr->entId.inst       = 0;
   hdr->elmId.elmnt      = 0;
   hdr->elmId.elmntInst1 = 0;
   hdr->elmId.elmntInst2 = 0;
   hdr->elmId.elmntInst3 = 0;
   hdr->seqNmb           = 0;
   hdr->version          = 0;

#ifdef ST_LMINT3
   hdr->response.prior      = PRIOR0;
   hdr->response.route      = RTESPEC;
   hdr->response.mem.region = TSTREG;
   hdr->response.mem.pool   = TSTPOOL;
   hdr->transId             = transId;
#ifdef LCSMSTMILST
   hdr->response.selector   = ST_SEL_LC;
#else
   hdr->response.selector   = ST_SEL_TC;
#endif /* LCSMSTMILST */
#endif /* ST_LMINT3 */

  RETVOID;
} /* End of stInitHdr */



/*
*
* Fun  : stInitSmPst
*
* Desc: init SM post structure
*
* Ret  : None
*
* Notes: none
* 
* File:   st_init.c
*
*/
#ifdef ANSI
PUBLIC Void stInitSmPst
(
Pst *smPst,  /* pst structure */
Ent dstEnt,   /* destination entity */
Inst dstInst   /* destination instance */
)
#else
PUBLIC Void stInitSmPst(smPst, dstEnt, dstInst)
Pst *smPst;   /* pst structure */
Ent dstEnt;    /* destination entity */
Inst dstInst;  /* destination instance */
#endif
{
	
   smPst->dstEnt = dstEnt;
   smPst->dstInst = dstInst;
   smPst->dstProcId = SFndProcId();

   smPst->srcEnt      =  ENTSM;
   smPst->srcInst     = TSTINST_0;
   smPst->srcProcId = SFndProcId();
   
   smPst->pool         = DFLT_POOL;
   smPst->region      = DFLT_REGION;
   smPst->prior        = PRIOR0;
   smPst->route       = RTESPEC;
#ifdef LCSMSTMILST   
   smPst->selector   = ST_SEL_LC;
#else
   smPst->selector   = ST_SEL_TC;
#endif

	RETVOID;
}

#if 0

/*                                     
*
*       Fun:   stGenCfg
*
*       Desc:  TCAP General Configuration
*
*       Ret:   ROK - ok
*
*       Notes: None
*
*       File:  st_init.c
*
*/
#ifdef ANSI
PUBLIC  S16 stGenCfg
(
U32     loDlgId,         /* Low dialogue Id */
U32     hiDlgId,         /* High Dialogue Id */
Bool    bitMapFlag,      /* Boolean for Bitmap for dialogue ids */
TranId  transId          /* Transaction Id */
)
#else
PUBLIC  S16 stGenCfg(loDlgId, hiDlgId, bitMapFlag, transId)
U32     loDlgId;         /* Low dialogue Id */
U32     hiDlgId;         /* High Dialogue Id */
Bool    bitMapFlag;      /* Boolean for Bitmap for dialogue ids */
TranId  transId;         /* Transaction Id */
#endif
{
   StMngmt    cfg;       /* configuration */
   Pst smPst;

   TRC2(stAccGenCfg)
   
#ifdef ZT_DFTHA
   UNUSED(loDlgId);
   UNUSED(hiDlgId);
   UNUSED(bitMapFlag);
#endif /* ZT_DFTHA */

   stInitSmPst(&smPst, ENTST, TSTINST_0);
   smPst.event = EVTNONE;
   
   /* Prepare header */
   stInitHdr(&cfg.hdr, transId);

   cfg.hdr.msgType     = TCFG;                      /* configuration */
   cfg.hdr.entId.ent   = ENTST;                     /* entity */
   cfg.hdr.entId.inst  = TSTINST_0;                 /* instance */
   cfg.hdr.elmId.elmnt = STGEN;                     /* general */

   /* set configuration parameters */
   cfg.t.cfg.s.genCfg.nmbSaps = ST_MAX_SAPS; /* number of saps */    
   cfg.t.cfg.s.genCfg.nmbDlgs = (ST_MAX_SAPS * ST_MAX_DLGS); /* number of dlg - sys wide */
   cfg.t.cfg.s.genCfg.nmbInvs = (ST_MAX_SAPS * ST_MAX_INVS); /* number of opr - sys wide */
   cfg.t.cfg.s.genCfg.timeRes = ST_PERIOD0;      /* timer resolution */
   cfg.t.cfg.s.genCfg.sapTimeRes = ST_PERIOD1;   /* timer resolution */

   cfg.t.cfg.s.genCfg.nmbBins = ST_SYS_NMBBIN;  /* no. of bins - sys wide */
   cfg.t.cfg.s.genCfg.loDlgId = loDlgId;
   cfg.t.cfg.s.genCfg.hiDlgId = hiDlgId;
   cfg.t.cfg.s.genCfg.bitMapFlg = bitMapFlag;
   cfg.t.cfg.s.genCfg.errCntrlFlg = FALSE;


   /* layer manager */
#ifdef LCSMSTMILST
   cfg.t.cfg.s.genCfg.smPst.selector  = ST_SEL_LC;     /* selector */
#else
   cfg.t.cfg.s.genCfg.smPst.selector  = ST_SEL_TC;     /* selector */
#endif

   cfg.t.cfg.s.genCfg.smPst.region    = TSTREG;        /* region */
   cfg.t.cfg.s.genCfg.smPst.pool      = TSTPOOL;       /* pool */
   cfg.t.cfg.s.genCfg.smPst.prior     = PRIOR0;        /* priority */
   cfg.t.cfg.s.genCfg.smPst.route     = RTESPEC;       /* route */
   
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   cfg.t.cfg.s.genCfg.smPst.dstProcId = ST_PROC_ID0;  /* dst proc id */
#else 
   cfg.t.cfg.s.genCfg.smPst.dstProcId = SFndProcId();  /* dst proc id */
#endif
   cfg.t.cfg.s.genCfg.smPst.dstEnt    = ENTSM;         /* dst entity */
   cfg.t.cfg.s.genCfg.smPst.dstInst   = TSTINST_0;     /* dst inst */
#ifdef SS_MULTIPLE_PROCS
   cfg.t.cfg.s.genCfg.smPst.srcProcId = STACC_PROC_ID0;  /* src proc id */
#else 
   cfg.t.cfg.s.genCfg.smPst.srcProcId = SFndProcId();  /* src proc id */
#endif
   cfg.t.cfg.s.genCfg.smPst.srcEnt    = ENTST;         /* src entity */
   cfg.t.cfg.s.genCfg.smPst.srcInst   = TSTINST_0;     /* src inst */

   cmCopy((U8 *)&cfg.t.cfg.s.genCfg.smPst, (U8 *)&smPst,
          (U32)sizeof(Pst));

   (Void) SmMiLstCfgReq(&smPst, &cfg);

   RETVALUE(ROK);

} /* end of stGenCfg */



/*
*
*       Fun:   stCntrlReq
*
*       Desc:  Send Control Request to TCAP on the LM interface
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  st_init.c
*
*/
#ifdef ANSI
PUBLIC  S16 stCntrlReq
(
SuId    suId,            /* Sap Id */
U8      elmnt,           /* Element */
U8      action,          /* Enable/disable */
U8      subAction,       /* Trace/alarm */
U32     par,             /* Debug Mask or procId */
TranId  transId          /* Transaction Id */
)
#else
PUBLIC  S16 stCntrlReq(suId, elmnt, action, subAction, par, transId)
SuId    suId;            /* Sap Id */
U8      elmnt;           /* Element */
U8      action;          /* Enable/disable */
U8      subAction;       /* Trace/alarm */
U32     par;             /* Debug Mask or procId */
TranId  transId;         /* Transaction Id */
#endif 
{
   Pst            smPst;
   StMngmt    cntrl;       /* Control */

   TRC2(stCntrlReq)

   stInitSmPst(&smPst, ENTST, TSTINST_0);
   smPst.event      = EVTLSTCNTRLREQ;
   
   stInitHdr(&cntrl.hdr, transId);
   cntrl.hdr.msgType          = TCNTRL;        /* Control */
   cntrl.hdr.entId.ent        = ENTST;         /* entity */
   cntrl.hdr.entId.inst       = TSTINST_0;     /* instance */
   cntrl.hdr.elmId.elmnt      = elmnt;         /* TC User sap */
   cntrl.hdr.elmId.elmntInst1 = suId;          /* sap id */

   cntrl.t.cntrl.action    = action;
   cntrl.t.cntrl.subAction = subAction;

   if ((elmnt == STGRTCUSAP) || (elmnt == STGRSPSAP) || (elmnt == STALLSAP))
   {
      cntrl.t.cntrl.par.dstProcId = par;
   }
#ifdef DEBUGP
   cntrl.t.cntrl.dbg.dbgMask = par;
#else
   UNUSED(par);
#endif /* DEBUGP */

   /* give Control request to layer */
   (Void) SmMiLstCntrlReq(&smPst, &cntrl);

   RETVALUE(ROK);
} /* end of stCntrlReq */


/*
*
* Fun : stBndCtlReq
*
* Desc: Send bind control requeset to TCAP on the LM interface
*
* Ret  : ROK -Success
*          RFAlLED - Failed
* Notes: None
*
* File  : st_init.c
*
*/
#ifdef ANSI
PUBLIC  S16 stBndCtlReq
(
U16 nmbSap
)
#else
PUBLIC  S16 stBndCtlReq(U16 nmbSap)
#endif 
{
	S32 i;
	
	for (i=0; i<nmbSap; i++)
	   {
		if ( ROK != stCntrlReq(i, STSPSAP, ABND_ENA, 0, NOTUSED, i))
	   	{
	   		RETVALUE(RFAILED);
	   	}
	   }

	RETVALUE(ROK);

}


/*
*
*       Fun:   stTUSapCfg
*
*       Desc:  Configure Tcap User Sap
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  st_acc1.c
*
*/
#ifdef ANSI
PUBLIC  S16 stTUSapCfg
(
SuId    suId,            /* Sap Id */
Swtch   swtch,           /* Protocol switch */
U32     loDlgId,         /* Low dialogue Id */
U32     hiDlgId,         /* High Dialogue Id */
TranId  transId          /* Transaction Id */
)
#else
PUBLIC  S16 stTUSapCfg(suId, swtch, loDlgId, hiDlgId, transId)
SuId    suId;            /* Sap Id */
Swtch   swtch;           /* Protocol switch */
U32     loDlgId;         /* Low dialogue Id */
U32     hiDlgId;         /* High Dialogue Id */
TranId  transId;         /* Transaction Id */
#endif 
{
   StMngmt    cfg;         /* configuration */
   Pst smPst;

   TRC2(stTUSapCfg)
   
#ifdef ZT_DFTHA
   UNUSED(loDlgId);
   UNUSED(hiDlgId);
#endif /* ZT_DFTHA */

   stInitSmPst(&smPst, ENTST, TSTINST_0);
   smPst.event = EVTCFGREQ;
   
   stInitHdr(&cfg.hdr, transId);

   cfg.hdr.msgType          = TCFG;          /* configuration */
   cfg.hdr.entId.ent        = ENTST;         /* entity */
   cfg.hdr.entId.inst       = TSTINST_0;     /* instance */
   cfg.hdr.elmId.elmnt      = STTCUSAP;      /* TC User sap */
   cfg.hdr.elmId.elmntInst1 = suId;          /* sap id */

   /* update the upper interface parameters */

#ifdef LCSTUISTU
   cfg.t.cfg.s.tuSapCfg.tuSel    = ST_SEL_LC;  /* loosely coupled */
#else
   cfg.t.cfg.s.tuSapCfg.tuSel    = ST_SEL_MA;  /* loosely coupled */
#endif

   cfg.t.cfg.s.tuSapCfg.tuMemId.region = TSTREG;  /* defualt region */
   cfg.t.cfg.s.tuSapCfg.tuMemId.pool   = TSTPOOL; /* defualt pool */
   cfg.t.cfg.s.tuSapCfg.tuPrior        = PRIOR0;  /* defualt priority */
   cfg.t.cfg.s.tuSapCfg.tuRoute        = RTESPEC; /* default route */

   /* configuration parameters */
   cfg.t.cfg.s.tuSapCfg.swtch  = swtch;

   /* Enable Timers for ITU only */
   if ((swtch == LST_SW_ITU88) || (swtch == LST_SW_ITU92) ||
       (swtch == LST_SW_ITU96))
   {
      cfg.t.cfg.s.tuSapCfg.t1.enb  = TRUE;
      cfg.t.cfg.s.tuSapCfg.t1.val  = ST_T1;
      cfg.t.cfg.s.tuSapCfg.t2.enb  = TRUE;
      cfg.t.cfg.s.tuSapCfg.t2.val  = ST_T2;
   }
   else
   {
      cfg.t.cfg.s.tuSapCfg.t1.enb  = FALSE;
      cfg.t.cfg.s.tuSapCfg.t2.enb  = FALSE;
   }

   /* Dialogue Id range */
   cfg.t.cfg.s.tuSapCfg.loDlgId = loDlgId;
   cfg.t.cfg.s.tuSapCfg.hiDlgId = hiDlgId;

/* st043.301 - Addition - Added configurable dlgHshSize */
#ifdef LSTV3
   cfg.t.cfg.s.tuSapCfg.dlgHshSize= 157;
#endif /* LSTV3 */

   /* Resource configuration */
   cfg.t.cfg.s.tuSapCfg.nmbDlgs = ST_SAP_DLGS;
   cfg.t.cfg.s.tuSapCfg.nmbInvs = ST_SAP_INVS;
   cfg.t.cfg.s.tuSapCfg.nmbBins = ST_SAP_BINS;

 /* st005.301 -Added- Rolling Upgrade feature */
#ifdef ST_RUG
   cfg.t.cfg.s.tuSapCfg.remIntfValid = stAccRemIntf;
   cfg.t.cfg.s.tuSapCfg.intfVer = stAccUIntfVer;
#endif

   /* give configuration request to layer */
   (Void) SmMiLstCfgReq(&smPst, &cfg);

   RETVALUE(ROK);
} /* end of stTUSapCfg */


/*
*
*       Fun:   stSPSapCfg
*
*       Desc:  Configure Tcap Lower Sap
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  st_acc1.c
*
*/
#ifdef ANSI
PUBLIC  S16 stSPSapCfg
(
SuId    suId,            /* Sap Id */
SpId    spId,            /* TCAP lower Sap Id */
Swtch   swtch,           /* Protocol switch */
TranId  transId          /* Transaction Id */
)
#else
PUBLIC  S16 stSPSapCfg(suId, spId, swtch, transId)
SuId    suId;            /* Sap Id */
SpId    spId;            /* TCAP lower Sap Id */
Swtch   swtch;           /* Protocol switch */
TranId  transId;         /* Transaction Id */
#endif 
{
   StMngmt    cfg;         /* configuration */
   Pst smPst;

   TRC2(stSPSapCfg)

   stInitSmPst(&smPst, ENTST, TSTINST_0);
   smPst.event = EVTLSTCFGREQ;
   
   stInitHdr(&cfg.hdr, transId);
   cfg.hdr.msgType          = TCFG;          /* configuration */
   cfg.hdr.entId.ent        = ENTST;         /* entity */
   cfg.hdr.entId.inst       = TSTINST_0;     /* instance */
   cfg.hdr.elmId.elmnt      = STSPSAP;       /* TC User sap */
   cfg.hdr.elmId.elmntInst1 = suId;          /* sap id */

   /* update the lower interface parameters */

#ifdef LCSTLISPT
   cfg.t.cfg.s.spSapCfg.spSel    = ST_SEL_LC;  /* loosely coupled */
#else
   cfg.t.cfg.s.spSapCfg.spSel    = ST_SEL_SP;  /* tightly coupled */
#endif

   cfg.t.cfg.s.spSapCfg.spMemId.region = TSTREG;  /* defualt region */
   cfg.t.cfg.s.spSapCfg.spMemId.pool   = TSTPOOL; /* defualt pool */
   cfg.t.cfg.s.spSapCfg.spPrior        = PRIOR0;  /* defualt priority */
   cfg.t.cfg.s.spSapCfg.spRoute        = RTESPEC; /* default route */
#ifdef SS_MULTIPLE_PROCS
   cfg.t.cfg.s.spSapCfg.spProcId       =  ST_PROC_ID0;
#else 
   cfg.t.cfg.s.spSapCfg.spProcId       = SFndProcId();
#endif
   cfg.t.cfg.s.spSapCfg.spEnt          = ENTSP;
   cfg.t.cfg.s.spSapCfg.spInst         = TSTINST_0;
   cfg.t.cfg.s.spSapCfg.spId           = spId;    /* lower sap Id */
   cfg.t.cfg.s.spSapCfg.spTmr          = 0;       /* SCCP Timer */
   cfg.t.cfg.s.spSapCfg.ssn            = stAccSPSapSSN; 
#ifdef SPT2
   cfg.t.cfg.s.spSapCfg.tIntTmr.enb    = TRUE;    /* Bind Confirm Timer */
   cfg.t.cfg.s.spSapCfg.tIntTmr.val    = ST_TMR_BND_CFM;
#endif /* SPT2 */

   /* configuration parameters */
   cfg.t.cfg.s.spSapCfg.swtch  = swtch;

 /* st005.301 -Added- Rolling Upgrade feature */
#ifdef ST_RUG
   cfg.t.cfg.s.spSapCfg.remIntfValid = stAccRemIntf;
   cfg.t.cfg.s.spSapCfg.intfVer = SPTIFVER;
#endif

   /* give configuration request to layer */
   (Void) SmMiLstCfgReq(&smPst, &cfg);

   RETVALUE(ROK);
} /* end of stSPSapCfg */



/*
*
* Fun : stCfg
*
* Desc: Send bind control requeset to TCAP on the LM interface
*
* Ret  : ROK -Success
*          RFAlLED - Failed
* Notes: None
*
* File  : st_init.c
*
*/
#ifdef ANSI
PUBLIC  S16 stCfg
(
S32 sapNmb
)
#else
PUBLIC  S16 stBndCtlReq(sapNmb)
S32 sapNmb;
#endif 
{
	S32 i;

	for (i=0; i<sapNmb; i++)
	{
		if (ROK != stGenCfg(0, 0, 0, i+1))
		{
			RETVALUE(RFAILED);
		}
	
		if (ROK != stTUSapCfg(i, LST_SW_ITU92, 0, 0, i+1))
		{
			RETVALUE(RFAILED);
		}
		
		if (ROK != stSPSapCfg(i, i, LST_SW_ITU92, i+1))
		{
			RETVALUE(RFAILED);
		}
	}

	RETVALUE(ROK);
}

#endif


/*
  * Fun   : st_init_fun
  *
  * Decs : Start TAPA Tsck
  *
  * Ret   : ROK
  *           RFAILED
  *
  * Noets: none
  *
  * File   : st_init.c
  *
  */
#ifdef ANSI
PUBLIC S16 st_init_fun
(
SSTskId    tskId
)
#else
PUBLIC S16 st_init_fun(tskId)
SSTskId    tskId;
#endif
{
	   t_XOSMUTEXID *plock = NULL;

#ifdef STTST	
   SSTskId    tskId2;
#endif
   Pst nmsPst;
#if (defined(ST_OAM_TST) && defined(STTST))
   Buffer *mBuf;
#endif

   nmsPst.route = RTESPEC;
   nmsPst.dstEnt = ENTTST;
   nmsPst.dstInst = TSTINST_0;
   nmsPst.dstProcId = SFndProcId();

   nmsPst.srcEnt = ENTST;
   nmsPst.srcInst = TSTINST_0;
   nmsPst.srcProcId = SFndProcId();
   
   nmsPst.pool   = DFLT_POOL;
   nmsPst.region = DFLT_REGION;
   nmsPst.prior = PRIOR0;
   nmsPst.selector = 0;
   
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
  #ifdef SS_MULTIPLE_PROCS
   ProcId tstPrc[1];
#endif 
   TRC1(st_init_fun)
#ifdef SS_MULTIPLE_PROCS
   /* Add first proc Id */
   tstPrc[0] = STACC_PROC_ID0;
   if (SAddProcIdLst(1, tstPrc) != ROK)
   {
       STLOGERROR(ERRCLS_DEBUG, ESTXXX, 0, "tst() Could not add procId\
to the list");
       RETVALUE(RFAILED);
   }
#endif /* SS_MULTIPLE_PROCS */

#ifdef STTST   
   /* initialize the TU layer control block */
   stInitAccCb();
#endif

   /****** create all tapa tasks ******/
   /* Register Layer Management tasks */
#if STTST
   SRegTTsk(ENTSM, TSTINST_0, TTNORM, 0,(PAIFS16) smActvInit, smActvTsk);
#endif   
   SRegTTsk(ENTST, TSTINST_0, TTNORM, 0,(PAIFS16) stActvInit, stActvTsk);


#ifdef STTST   
   /* Register Layer 3 (SCCP) tasks */
   SRegTTsk(ENTSP, TSTINST_0, TTNORM, 0,(PAIFS16) spActvInit, spActvTsk);
#endif

#if (defined(ST_OAM_TST) && defined(STTST))
   SRegTTsk(ENTTST, TSTINST_0, TTNORM, 0,(PAIFS16) NULLP, nmsTstActvTsk);
#endif

   /* create a single system thread */
#ifdef STTST
   if(tskId == 0)
   {
       SCreateSTsk(PRIOR0, &tskId);
   }
#else
	if (tskId == 0) /* if the globle task not exsit, create */
	{
		SCreateSTsk(0, &tskId);
	}
#endif /* STTST */

#if (defined(ST_OAM_TST) && defined(STTST))
   SCreateSTsk(PRIOR0, &tskId2); /* for Net Management Task */
#endif

   /****** attach all TAPA tasks to the same system thread ******/
#if STTST
   SAttachTTsk(ENTSM, TSTINST_0, tskId);
   SAttachTTsk(ENTST, TSTINST_0, tskId);
#else
   SAttachTTsk(ENTST, TSTINST_0, tskId);
#endif

#ifdef STTST
   SAttachTTsk(ENTSP, TSTINST_0, tskId);
#endif

#if (defined(ST_OAM_TST) && defined(STTST))
   SAttachTTsk(ENTTST, TSTINST_0, tskId2);
   SGetMsg(DFLT_POOL, DFLT_REGION, &mBuf);

   SPstTsk(&nmsPst, mBuf);
#endif

#if 0
   /****** start layer configuration ******/
   if (ROK != stCfg(ST_MAX_SAPS))
   {
   	RETVALUE(RFAILED);
   }

   /****** bind control ******/
   if (ROK != stBndCtlReq(ST_MAX_SAPS))
   {
   	RETVALUE(RFAILED);
   }
#endif

#ifdef CP_OAM_SUPPORT /* xingzhou.xu: add for net management --05/25/2006 */
    stInitCfgData();

   if( ROK != smRegCb((Ent)ENTST, gStSmQ, sizeof(gStSmQ)/sizeof(CmLListCp), smStSendReqQ, stResetCfgData))
   {
      RETVALUE(RFAILED);
   }

	if( OAM_CALL_SUCC != register_msg_proc(CP_MODULE_ID_SS7_TCAP,  APP_SYNC_MSG,  stInitCfgCallback, NULL))
	{
      RETVALUE(RFAILED);
   } 	

   (unsigned char)get_resource(xwCpSS7NwkTable, sizeof(CP_OAM_SS7_NETWORK_TAB), xwCpSS7NwkTable_ROW_NUM);
   (unsigned char)get_resource(xwCpSS7UpTable, sizeof(CP_OAM_SS7_UP_TAB), xwCpSS7UpTable_ROW_NUM);
   (unsigned char)get_resource(xwCpSS7SsnTable, sizeof(CP_OAM_SS7_SSN_TAB), xwCpSS7SsnTable_ROW_NUM);
   (unsigned char)get_resource(xwCpTcapGenCfg, sizeof(StGenCfgTab), xwCpTcapGenCfg_ROW_NUM);
   
   if( OAM_CALL_SUCC != app_register(CP_MODULE_ID_SS7_TCAP, &stCfgTbl[0], sizeof(stCfgTbl)/sizeof(stCfgTbl[0])))
   {
      RETVALUE(RFAILED);
   }
#endif /* CP_OAM_SUPPORT */

   RETVALUE(ROK);
}

#if STTST
#ifdef ANSI
PUBLIC S16 tst1
(
Void
)
#else
PUBLIC S16 tst(Void)
#endif
{
#ifdef STCLI
    st_init_fun(0);
#else
    tstTCAP();
#endif
}
#endif

#endif /* SSI_WITH_CLI_ENABLED */
