/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**

     Name:     SS7 TCAP

     Type:     C source file
  
     Desc:     C source code for dialogue handler, component handler
               and transaction handler routines for ANSI (88 & 92 & 96)
               variant of TCAP, supplied by TRILLIUM.

     File:     ct_bdy3.c
  
     Sid:      ct_bdy3.c@@/main/14 - Fri Nov 17 10:34:33 2000
  
     Prg:      nj
  
*********************************************************************21*/

/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif
#ifdef CCITT96
               CCITT 96
#endif
 
************************************************************************/

/*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000011     Multiprocessor Operating System
*     1000030     SS7 - SCCP
*
*/

/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* Common timer */
#include "cm_ss7.h"        /* SS7 Specific */
#include "cm_hash.h"       /* common hash */
#include "cm_err.h"        /* common error */
#include "stu.h"           /* Tcap Upper Interface */
#include "spt.h"           /* Tcap Lwer Interface */
#include "lst.h"           /* TCAP layer management Interface */
#include "st.h"            /* Tcap */
#include "st_mf.h"         /* Tcap Message functions */
#include "st_db.h"         /* Tcap ASN.1 Database */
#include "st_err.h"        /* Tcap error */

#ifdef ST_FTHA
#include "sht.h"           /* SHT */
#include "mrs.h"           /* MRS */
#endif /* ST_FTHA */

#ifdef ZT
#include "cm_ftha.h"
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#ifdef ZT_DFTHA
#include "cmztdt.h"
#include "cmztdtlb.h"
#endif /* ZT_DFTHA */
#include "zt.h"            /* Tcap PSF defines */
#include "lzt.h"
#endif /* ZT */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* Common Timer */
#include "cm_ss7.x"        /* common SS7 Specific */
#include "cm_hash.x"       /* common hash */
#include "stu.x"           /* Tcap Upper Interface  */
#include "spt.x"           /* Tcap Lower interface */
#include "lst.x"           /* TCAP layer management Interface */
#include "st_mf.x"         /* Tcap Message functions */

#ifdef ZT
#include "cm_ftha.x"
#include "cm_pftha.x"      /* Common PSF typedefs */
#include "cm_psfft.x"
#endif /* ZT */

#ifdef ST_FTHA
#include "sht.x"           /* SHT */
/* st005.301 - Deleted - mrs.x included under ZT */
#endif /* ST_FTHA */

#include "st.x"            /* Tcap */
  
#ifdef ZT
/* st005.301 - Added - mrs.x included here */
#include "mrs.x"
#ifdef ZT_DFTHA
#include "cmztdt.x"
#include "cmztdtlb.x"
#endif /* ZT_DFTHA */
#include "lzt.x"
#include "zt.x"            /* Tcap PSF typedefs */
#endif /* ZT */



/* local defines */

/* local externs */
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifndef SS_MULTIPLE_PROCS
EXTERN  StCb   stCb;       /* TCAP control block*/ 
#ifdef ZT
EXTERN  ZtCb   ztCb;       /* PSF control block*/ 
#endif /* ZT */

/* st014.301 -Add- declaration stDataParam and stMgmntParam variables */
EXTERN  StDataParam  stDataParam;
EXTERN  StMgmntParam stMgmntParam;
#endif /* SS_MULTIPLE_PROCS */



/********************************************************************30**
 
         End of file:     ct_bdy3.c@@/main/14 - Fri Nov 17 10:34:33 2000
 
*********************************************************************31*/
 

/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 

/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
 

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  mma   1. initial release
 
1.2          ---  mma   1. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92

1.3          ---  mma   1. removed references to ANSI parameters

1.4          ---  lc    1. changed stANComponents to support invalid
                           component ID
             ---  lc    2. changed the order of transmitting the components
                           to the TCAP user in the following functions:
                           stTRPUniR, stTRPQryWoPerR, stTRPQryWPerR, 
                           stTRPConWPerR, stTRPConWoPerR, stTRPRespR
             ---  ak    3. modified all routines to use new stDlgCp
                           remove all uses of stTransCp.
             ---  ak    4. Use Pst structure.
             ---  ak    5. All Stu-DatReq/UDatReq/DatInd/UDatInd now
                           support a priority field (msgPrior).
             ---  ak    6. replaced ss_ms/ss_pt.[hx] with ssi.[hx]

1.5          ---  ak    1. include cm5.[hx]

1.6          ---  ak    1. added ANSI 1992 support (ABORT package types)
                           and new problem codes, component sequences...
             ---  ak    2. ANSI 1992 switches now ABORT dialogs on error.
             ---  ak    3. more statistics collection (ANSI T1.115)
             ---  ak    4. update s->curDlgCp in stTRPQryWPerR.
1.7          ---  aa    1. Changes due to TCAP uuper interface changes.
             ---  aa    2. surrounded instances of ANSI88 with ANSI92. 

1.8          ---  aa    1. Added trace Indication 

1.9          ---  aa    1. Changed the LST_SW_CCITTxx to LST_SW_ITUxx and
                           LST_SW_ANSIxx to LST_SW_ANSxx
             ---  aa    2. Removed the compilation error
             ---  aa    3. Removed the function stFindAnsOrgId as it is not used
             ---  aa    4. Initialize the curSuDlgId and curSpDlgId in SAP structure
                           from the dialogue event structure before using it in
                           functions the StUiStuDatInd and StUiStuCmpInd to the upper user. 

1.10         ---  aa    1. Changes due to serror.
             ---  aa    2. Functions which were called from a PUBLIC function
                           matrix are made PUBLIC (as they are called directly
                           now)
             ---  aa    3. Added the new functions to check the state of TRP
                           for the Data Request event.
             ---  aa    4. miscellaneous cahnges.

*********************************************************************81*/


/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.11         ---      aa   1. SCCP UDatReq now needs a unique Id to be passed in
                             the UDatEvnt structure for class 1 SCCP messages.
                             made changes in the code to pass the spDlgId as 
                             Sequenced Control Number 

             ---     aa   2. Send the REJECT message to peer on receiving 
                             unrecognized package type for ANS88 .
             ---     aa   3. Check for the NULL stDlgCp pointer in stComponentsAN 
                             as it will be NULL in case of ANS Unidirectional 
                             message.
             ---     aa   4. fixed the bug in stTRPUniS (ret == stBldMsg)..
/main/14     ---     as   1. DFT/HA release. 
                          2. Modified the ZT_DFTHA flag to ZT, surrounding
                              stAllocDlg function. Now, the alternate stAllocDlg
                              funtion shall be used for both DFTHA and FTHA.

3.1+      st005.301   zr   1. Rolling Upgrade Feature - #if ANSI define section
                              is modified to make it available for ANSI88, ANSI92,
                              ANSI96.
                           2. Fix for ztRunTimeUpd call in stAnsiCHGetComps routine
                           3. File mrs.x included under zt
3.1+      st007.301   zr   Changes for TC-User Distribution Feature
                           - Upper to lower SAP association is made
                             by a special routine
                           - Added new routines
                                  - stAnsiTHGenPAbtTcUserDist
                                  - stAnsiTHGenRejTcUserDist
                                  - stAnsiTHRxMsgTcUserDist
                                  - stAnsiTHRxIncMsgTcUserDist

3.1+         st009.301 zr   1. Add more debug prints throughout the entire 
                               file.

3.1+         st014.301 zr   1. Handle Support for STU and SPT interface changes
                               - Support for conveying imp and isni parameters 
                                 are provided in transaction handler and in
                                 dialogue handler routines                     
3.1+         st015.301 zr   1. Added routine stAnsiCHUCancel for canceling
                               sending and receiving side invokes 
                            2. In stAnsiDHTxUAbt routine use of mBuf is 
                               corrected for removing O2 compilation warning
                            3. In stAnsiCHGetComps routine smEvent initialzed
                               to avaid O2 compilation warning.
                            4. In stAnsiIsmExec routine check is provided for
                               invalid event.

3.1+        st016.301 zr   1. In stAnsiCHPutComps routine, before setting the 
                              problem code it is verified that the component
                              is decoded properly. 

3.1+        st017.301 zr   1. Before sending Component Indication check is 
                              made to make sure that the dialogue control 
                              point is not deleted due to Abort message from 
                              TC-User.

                           2. In stAnsiCHPutComps routine, changes are made
                              to make sure that the dialogue control point
                              is not deallocated by some dialogue terminating
                              message from TC-User.

                           3. In stAnsiDHRxUni and stAnsiDHRxRsp routines, 
                              before deallocating the dialogue, check is made 
                              to make sure that it has not already been 
                              deallocated by some dialogue terminating message 
                              from TC-User.

                            4. In stAnsiTHRxMsg routine, terminating message
                               flag of the dialogue control point is set
                               for Response message.

                            5. In stAnsiTHTxUAbt routine, if dialogue 
                               terminating message has already come from peer, 
                               then stop sending the abort message to SCCP

3.1+        st018.301 as   1.  Allow RESPONSE to be sent in S_TSM_CWOPTX state
                           2.  Allow RESPONSE to be sent in S_TSM_CWOPRX state

3.1+        st022.301 jz   1. In stAnsiTHRxMsg routine, for Response message, 
                              copy source and destination address in dialogue
                              control point if ST_CHG_ADDR flag is enabled.

3.1+        st023.301 jz   1. Fixed debug print error.

3.1+        st025.301 jz   1. Message buffer freed when component & dialog
                              portions were absent in stAnsiDHRxRsp()

3.1+        st026.301 ds   1. Notify local user with local reject if badly 
                              formed reject component received from the remote.
3.1+        st027.301 ds   1. Replace SPutMsg call with STFREEUSERBUF call to avoid
                              mem corruption on double deallocation.
3.1+        st029.301 yk   1. Add suDlgId and spDlgId parameters in StUiStuUDatInd.
3.1+        st030.301 yk   1. Added check on return value of stCompQLast to avoid memory Leak.
3.1+        st032.301 yk    1. Initialization of uDatEv is done in various functions.
3.1+       st034.301   yk   1. Code Added for SS_MULTIPLE_PROCS
3.1+       st043.301  mkm   1. Changes for addition of suDlgId parameter in stAllocDlg.
*********************************************************************91*/
