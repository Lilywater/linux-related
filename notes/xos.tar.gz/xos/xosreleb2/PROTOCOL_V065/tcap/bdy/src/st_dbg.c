/**********************************************************************

        Name:   st_dbg.c - Debug print for the TCAP

        Type:   C source file

        Desc:   C code for the TCAP layer debug print

        File:   st_dbg.c

        Sid:    st_dbg.c - 2006/04/04

        Created by:     xingzhou.xu

**********************************************************************/
#ifdef SSI_WITH_CLI_ENABLED
/* header include files (.h) */

//------------------- xingzhou.xu ---------------
//---------------------------------------------

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"
#include "cm_ss7.h"
#include "cm_asn.h"
#include "cm_hash.h"       /* common hash */
#include "cm_err.h"        /* common error */
#include "stu.h"           /* tcap services user */
#include "spt.h"           /* sccp layer */
#include "lst.h"           /* layer management, TCAP */
#include "st.h"            /* tcap */
#include "st_mf.h"         /* tcap */
#include "st_db.h"         /* Tcap database */
#include "st_err.h"        /* tcap error */
#ifdef STTST
#include "st_acc.h"        /* Tcap Test*/
#endif

#ifdef ST_FTHA
#include "sht.h"           /* SHT */
#endif /* ST_FTHA */

#ifdef ZT
#include "cm_ftha.h"       /* Common FTHA */
#include "mrs.h"           /* Message router interface */
#include "cm_pftha.h"      /* Common protocol FTHA */
#include "cm_psfft.h"
#ifdef ZT_DFTHA
#include "cmztdt.h"
#include "cmztdtlb.h"
#endif /* ZT_DFTHA */
#include "mrs.h"
#include "zt.h"            /* Tcap PSF defines */
#include "lzt.h"
#include "zt_acc.h"        /* Tcap PSF test */
#endif

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"
#include "cm_ss7.x"        /* Common */
#include "cm_hash.x"       /* Common hash */
#include "cm_asn.x"
#include "stu.x"           /* Tcap layer */
#include "lst.x"           /* Layer management, TCAP */
#include "spt.x"           /* Sccp layer */
#include "st_mf.x"         /* Tcap */

#ifdef ZT
#include "cm_ftha.x"       /* Common FTHA */
#include "mrs.x"           /* Message router interface */
#include "cm_pftha.x"      /* Common protocol FTHA */
#include "cm_psfft.x"
#ifdef ZT_DFTHA
#include "cmztdt.x"
#include "cmztdtlb.x"
#endif /* ZT_DFTHA */
#include "lzt.x"
#endif /* ZT */

#ifdef ST_FTHA
#include "sht.x"           /* SHT */
#endif /* ST_FTHA */

#include "st.x"            /* Tcap */
#ifdef STTST
#include "st_acc.x"        /* Tcap Test*/
#endif

#ifdef ZT
#include "mrs.x"
#include "zt.x"            /* Tcap PSF typedefs */
#include "zt_acc.x"        /* Tcap PSF test */
#endif /* ZT */

/* st007.301 - Added - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
#include "cm_lib.x"
#endif /* ST_TC_USER_DIST */

#include "oam_public_data_def.h"
#include "clishell.h"
#include "st_oam.x"
#include "st_dbg.h"        /* Debug Print*/


/* extern variable */
EXTERN U32	cmAsnDbg;

/* extern functions */
EXTERN XS32 XOS_StrToNum ARGS((XCHAR *pStr, XU32 *iValue));
EXTERN U8* cmMemset ARGS((U8 *str, U8 val, PTR len));
EXTERN VOID stDynCfgCallback ARGS((unsigned int tableid, 
									unsigned short msgtype, 
									unsigned int sequence, 
									unsigned char pack_end, 
									tb_record *prow));

/* local defines */

/* local externs */
#ifdef STTST
EXTERN  StAccCb      stAccCb;  /* TCAP Acceptance Test control block */
#endif
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifndef SS_MULTIPLE_PROCS
EXTERN  StCb         stCb;
#endif
/* public var. */
U32   gTcapTransId = 0;

/* local var. */
PRIVATE	Txt		*sapStatus[] = {"", "UNBND", "CFGD", "BND", "WTBNDCFM", "BNDPEND"};
PRIVATE	Txt		*lmSel[]	 = {"LOOSELY", "TIGHTLY"};
PRIVATE	Txt		*tuSel[]	 = {"LOOSELY", "TIGHTLY-TU", "TIGHTLY-MA", "TIGHTLY-IS_41", 
								"TIGHTLY-INAP", "TIGHTLY-CAP", "TIGHTLY-DSTU",
								"TIGHTLY-LLDF"};
PRIVATE	Txt		*spSel[]	 = {"LOOSELY", "TIGHTLY-SP", "TIGHTLY-SUA"};
PRIVATE	Txt		*swtch[]	 = {"UNKOWN", "ITU88", "ITU92", "ANSI88", "ANSI92", "ANSI96", 
								"ETS96", "ITU96"};
PRIVATE	Txt		*sw[]	 	= {"TEST", "ITU88", "ANSI88", "ANSI92", "ITU92", "Q767", 
								"CHINA", "JAPAN"};
PRIVATE	Txt		*initReason[]= {"NORMAL END", "POWER UP", "SWITCH", "SOFTWARE ERROR",
								"DEADMAN TIMER FIRED", "EXTERNAL", "SHUTDOWN"};
#ifdef CMSS7_SPHDROPT
PRIVATE	Txt		*spHdrOpt[]= {"NON OPTIONS", "NO SP POINTCODE"};
#endif
PRIVATE	Txt		*ssf[]= {"INTERNATIONAL", "SPARE", "NATIONAL", "RESERVED"};
PRIVATE	Txt		*niInd[]= {"INTERNATIONAL", "NATIONAL"};
PRIVATE	Txt		*rtgInd[]= {"Global Title", "SSN"};
PRIVATE	Txt		*dhaSt[]= {"IDLE", "APP CONTEXT MODE SENT", "APP CONTEXT MODE RECEIVED", 
							"APP CONTEXT MODE ACTIVE" ,"APP CONTEXT MODE SET"};
PRIVATE	Txt		*tslSt[]= {"ERROR", "IDLE", "INIT SENT", "INIT RECEIVED", "INIT ACTIVE"};

/************************************************************/
/*****  Functions: Set all the status of TCAP layer  ******/
/************************************************************/

U32 stGetTransId()
{
    return gTcapTransId++;
}

/* 
 * Function name: stHdrInit
 * Des:		      Init hdr 
 * Return Value : ROK or RFAILED
 */
Void stHdrInit(Header *hdr) 
{

	TRC2(stHdrInit);

	hdr->elmId.elmnt = 0;
	hdr->elmId.elmntInst1 = 0;
	hdr->elmId.elmntInst2 = 0;
	hdr->elmId.elmntInst3 = 0;
	hdr->entId.ent = ENTST;
	hdr->entId.inst = ST_INST_0;
	hdr->seqNmb = 0;
	hdr->version = 0;
	hdr->msgType = 0;
	hdr->msgLen = sizeof(StMngmt);
#ifdef ST_LMINT3
	hdr->transId = stGetTransId();

#ifdef LCSMSTMILST
	hdr->response.selector = ST_SEL_LC;	/* LC */
#else
	hdr->response.selector = ST_SEL_TC;	/* TC */
#endif
	hdr->response.mem.region = DFLT_REGION;
	hdr->response.mem.pool = DFLT_POOL;
	hdr->response.route = RTESPEC;
	hdr->response.prior = PRIOR1;
#endif /* SP_LMINT3 */
   
	RETVOID;
}

Void smStPstInit(Pst *smStPst)
{
	TRC2(smStPstInit);
	
	cmMemset((U8 *)smStPst, 0, sizeof(Pst));
	
#ifdef LCSMSTMILST
	smStPst->selector = ST_SEL_LC;
#else
	smStPst->selector = ST_SEL_TC;
#endif
	
	smStPst->event     = 0;
	smStPst->region = DFLT_REGION;       /* region */
	smStPst->pool = DFLT_POOL;           /* pool */
	smStPst->prior = PRIOR1;                  /* priority */
	smStPst->route = RTESPEC;                  /* route */
	smStPst->dstProcId = SFndProcId();   /* destination processor id */
	smStPst->dstEnt = ENTST;             /* dst entity   (always ENTST) */
	smStPst->dstInst = ST_INST_0;         /* dst instance (unused) */
	smStPst->srcProcId = SFndProcId();   /* source processor id */
	smStPst->srcEnt = ENTSM;            /* source entity */
	smStPst->srcInst = SM_INST;         /* src instance (unused) */
  
	RETVOID;
	
}


/***********************************************
 * Func: stSetDbgmsk
 * 
 * desc: the function enable/disable error control
 *       flag in TCAP
 *
 * return: void
 *
 * auth & date: xingzhou.xu 2006/08/24
 *
 ***********************************************/
PUBLIC VOID stSetErrCtrl(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
	if (siArgc != 2)
	{
		XOS_CliExtPrintf(pCliEnv, "��������!\r\n");
		RETVOID;
	}

	if (0 == atol(ppArgv[1]))
	{
		stCb.genCfg.errCntrlFlg = FALSE;
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n", 
			"local error control flag", "FALSE");
	}
	
	if (1 == atol(ppArgv[1]))
	{
		stCb.genCfg.errCntrlFlg = TRUE;
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n", 
			"local error control flag", "TRUE");
	}

	RETVOID;
}

/***********************************************
 * Func: stSetTrc
 * 
 * desc: the function enable/disable trace control
 *       flag in TCAP
 *
 * return: void
 *
 * auth & date: xingzhou.xu 2006/08/29
 *
 ***********************************************/
PUBLIC VOID stSetTrc(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
	StMngmt    cntrl;       /* Control */
	Pst	smStPst;


	if (siArgc != 2)
	{
		XOS_CliExtPrintf(pCliEnv, "��������!\r\n");
		RETVOID;
	}
	
	memset(&smStPst, 0, sizeof(Pst));
	memset(&cntrl, 0, sizeof(StMngmt));
	smStPstInit(&smStPst);
	stHdrInit(&cntrl.hdr);
	
	cntrl.hdr.msgType          = TCNTRL;        /* Control */
	cntrl.hdr.entId.ent        = ENTST;         /* entity */
	cntrl.hdr.entId.inst       = 0;     		/* instance */
	cntrl.hdr.elmId.elmnt      = STGEN;         /* General */
	cntrl.hdr.elmId.elmntInst1 = 1;          	/* sap id */
	cntrl.t.cntrl.subAction    = SATRC;

	if (0 == atol(ppArgv[1]))
	{
		cntrl.t.cntrl.action    = ADISIMM;
		XOS_CliExtPrintf(pCliEnv, "%-15s : %s\r\n", 
			"trace flag", "OFF");
	}
	
	if (1 == atol(ppArgv[1]))
	{
		cntrl.t.cntrl.action    = AENA;
		XOS_CliExtPrintf(pCliEnv, "%-15s : %s\r\n", 
			"trace flag", "ON");
	}

	/* give Control request to layer */
	(Void) SmMiLstCntrlReq(&smStPst, &cntrl);

	RETVOID;
}

/***********************************************
 * Func: stSetDbgmsk
 * 
 * desc: the function enable/disable all kinds
 *       of debug print flags in TCAP
 *
 * return: void
 *
 * auth & date: xingzhou.xu 2006/08/24
 *
 ***********************************************/
PUBLIC VOID stSetDbgmsk(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
	U32	dbgMsk = 0;
	TskInit	*init = &stCb.init;
#if 0	
	if (siArgc != 3)
#else
	if (siArgc != 2)
#endif
	{
		XOS_CliExtPrintf(pCliEnv, "��������!\r\n");
		RETVOID;
	}

	XOS_StrToNum(ppArgv[1], &dbgMsk);
#ifdef DEBUGP
#if 0
	switch(atol(ppArgv[2]))
	{
		case 1:		/* enable */
		{
			if (dbgMsk & DBGMASK_SI)
			{
				init->dbgMask |= DBGMASK_SI;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"DBGMASK_SI","ON");
			}
			if (dbgMsk & DBGMASK_MI)
			{
				init->dbgMask |= DBGMASK_MI;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"DBGMASK_MI","ON");
			}
			if (dbgMsk & DBGMASK_UI)
			{
				init->dbgMask |= DBGMASK_UI;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"DBGMASK_UI","ON");
			}
			if (dbgMsk & DBGMASK_LI)
			{
				init->dbgMask |= DBGMASK_LI;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"DBGMASK_LI","ON");
			}
			if (dbgMsk & DBGMASK_PI)
			{
				init->dbgMask |= DBGMASK_PI;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"DBGMASK_PI","ON");
			}
			if (dbgMsk & DBGMASK_PLI)
			{
				init->dbgMask |= DBGMASK_PLI;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"DBGMASK_PLI","ON");
			}
			if (dbgMsk & ST_DBGMASK_GEN)
			{
				init->dbgMask |= ST_DBGMASK_GEN;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"ST_DBGMASK_GEN","ON");
			}
			if (dbgMsk & ST_DBGMASK_ENCODE)
			{
				init->dbgMask |= ST_DBGMASK_ENCODE;
				cmAsnDbg = CM_ASN_DBG_ON;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"ST_DBGMASK_ENCODE","ON");
			}
			if (dbgMsk & ST_DBGMASK_DECODE)
			{
				init->dbgMask |= ST_DBGMASK_DECODE;
				cmAsnDbg = CM_ASN_DBG_ON;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"ST_DBGMASK_DECODE","ON");
			}
			if (dbgMsk & ST_DBGMASK_SM)
			{
				init->dbgMask |= ST_DBGMASK_SM;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"ST_DBGMASK_SM","ON");
			}
			if (dbgMsk & ST_DBGMASK_NORMAL)
			{
				init->dbgMask |= ST_DBGMASK_NORMAL;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"ST_DBGMASK_NORMAL","ON");
			}
			if (0 == dbgMsk)
			{
				init->dbgMask |= 0xFFFFFFFF;
				cmAsnDbg = CM_ASN_DBG_ON;
				XOS_CliExtPrintf(pCliEnv, "%s %s\r\n",
					"ALL DEBUG MASK","ON");
			}
		}
		break;

		case 0:		/* disable */
		{
			if (dbgMsk & DBGMASK_SI)
			{
				init->dbgMask &= ~DBGMASK_SI;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"DBGMASK_SI","OFF");
			}
			if (dbgMsk & DBGMASK_MI)
			{
				init->dbgMask &= ~DBGMASK_MI;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"DBGMASK_MI","OFF");
			}
			if (dbgMsk & DBGMASK_UI)
			{
				init->dbgMask &= ~DBGMASK_UI;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"DBGMASK_UI","OFF");
			}
			if (dbgMsk & DBGMASK_LI)
			{
				init->dbgMask &= ~DBGMASK_LI;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"DBGMASK_LI","OFF");
			}
			if (dbgMsk & DBGMASK_PI)
			{
				init->dbgMask &= ~DBGMASK_PI;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"DBGMASK_PI","OFF");
			}
			if (dbgMsk & DBGMASK_PLI)
			{
				init->dbgMask &= ~DBGMASK_PLI;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"DBGMASK_PLI","OFF");
			}
			if (dbgMsk & ST_DBGMASK_GEN)
			{
				init->dbgMask &= ~ST_DBGMASK_GEN;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"ST_DBGMASK_GEN","OFF");
			}
			if (dbgMsk & ST_DBGMASK_ENCODE)
			{
				init->dbgMask &= ~ST_DBGMASK_ENCODE;
				if (!(init->dbgMask & ST_DBGMASK_DECODE))
					cmAsnDbg = CM_ASN_DBG_OFF;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"ST_DBGMASK_ENCODE","OFF");
			}
			if (dbgMsk & ST_DBGMASK_DECODE)
			{
				init->dbgMask &= ~ST_DBGMASK_DECODE;
				if (!(init->dbgMask & ST_DBGMASK_ENCODE))
					cmAsnDbg = CM_ASN_DBG_OFF;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"ST_DBGMASK_DECODE","OFF");
			}
			if (dbgMsk & ST_DBGMASK_SM)
			{
				init->dbgMask &= ~ST_DBGMASK_SM;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"ST_DBGMASK_SM","OFF");
			}
			if (dbgMsk & ST_DBGMASK_NORMAL)
			{
				init->dbgMask &= ~ST_DBGMASK_NORMAL;
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"ST_DBGMASK_NORMAL","OFF");
			}
			if (0 == dbgMsk)
			{
				init->dbgMask &= 0x00000000;
				cmAsnDbg = CM_ASN_DBG_OFF;
				XOS_CliExtPrintf(pCliEnv, "%s %s\r\n",
					"ALL DEBUG MASK","OFF");
			}
		}
		break;

		default:
			XOS_CliExtPrintf(pCliEnv, "����2����!\r\n");
			break;
	}
#else /* if 0 */
	if (dbgMsk & DBGMASK_SI)
	{
		init->dbgMask |= DBGMASK_SI;
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"DBGMASK_SI","ON");
	}
	if (dbgMsk & DBGMASK_MI)
	{
		init->dbgMask |= DBGMASK_MI;
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"DBGMASK_MI","ON");
	}
	if (dbgMsk & DBGMASK_UI)
	{
		init->dbgMask |= DBGMASK_UI;
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"DBGMASK_UI","ON");
	}
	if (dbgMsk & DBGMASK_LI)
	{
		init->dbgMask |= DBGMASK_LI;
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"DBGMASK_LI","ON");
	}
	if (dbgMsk & DBGMASK_PI)
	{
		init->dbgMask |= DBGMASK_PI;
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"DBGMASK_PI","ON");
	}
#ifdef ZT	
	if (dbgMsk & DBGMASK_PLI)
	{
		init->dbgMask |= DBGMASK_PLI;
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"DBGMASK_PLI","ON");
	}
#endif /* ZT */	
	if (dbgMsk & ST_DBGMASK_GEN)
	{
		init->dbgMask |= ST_DBGMASK_GEN;
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"ST_DBGMASK_GEN","ON");
	}
	if (dbgMsk & ST_DBGMASK_ENCODE)
	{
		init->dbgMask |= ST_DBGMASK_ENCODE;
		cmAsnDbg = CM_ASN_DBG_ON;
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"ST_DBGMASK_ENCODE","ON");
	}
	if (dbgMsk & ST_DBGMASK_DECODE)
	{
		init->dbgMask |= ST_DBGMASK_DECODE;
		cmAsnDbg = CM_ASN_DBG_ON;
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"ST_DBGMASK_DECODE","ON");
	}
	if (dbgMsk & ST_DBGMASK_SM)
	{
		init->dbgMask |= ST_DBGMASK_SM;
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"ST_DBGMASK_SM","ON");
	}
	if (dbgMsk & ST_DBGMASK_NORMAL)
	{
		init->dbgMask |= ST_DBGMASK_NORMAL;
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
					"ST_DBGMASK_NORMAL","ON");
	}
	if (0 == dbgMsk)
	{
		init->dbgMask &= 0x0;
		cmAsnDbg = CM_ASN_DBG_OFF;
		XOS_CliExtPrintf(pCliEnv, "%s %s\r\n",
					"ALL DEBUG MASK","OFF");
	}
#endif /* if 0 */

#else
	XOS_CliExtPrintf(pCliEnv, "DEBUGP����δ����!\r\n");
#endif /* DEBUGP */
	RETVOID;
}


/************************************************************/
/*****  Functions: Print all the status of TCAP layer  ******/
/************************************************************/


/*************************************************************
 * Print layer debug mask
 */
PUBLIC Bool stPrintLayerDbgmsk(CLI_ENV *pCliEnv, U32 mask)
{
	Bool enable=FALSE;
	
#ifdef DEBUGP
	if (mask & DBGMASK_SI)
	{
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"DBGMASK_SI","ON");
		enable=TRUE;
	}
	else
	{
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"DBGMASK_SI","OFF");
	}
	
	if (mask & DBGMASK_MI)
	{
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"DBGMASK_MI","ON");
		enable=TRUE;
	}
	else
	{
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"DBGMASK_MI","OFF");
	}
	
	if (mask & DBGMASK_UI)
	{
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"DBGMASK_UI","ON");
		enable=TRUE;
	}
	else
	{
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"DBGMASK_UI","OFF");
	}
	
	if (mask & DBGMASK_LI)
	{
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"DBGMASK_LI","ON");
		enable=TRUE;
	}
	else
	{
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"DBGMASK_LI","OFF");
	}
	
	if (mask & ST_DBGMASK_GEN)
	{
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"ST_DBGMASK_GEN","ON");
		enable=TRUE;
	}
	else
	{
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"ST_DBGMASK_GEN","OFF");
	}
	
	if (mask & ST_DBGMASK_ENCODE)
	{
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"ST_DBGMASK_ENCODE","ON");
		enable=TRUE;
	}
	else
	{
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"ST_DBGMASK_ENCODE","OFF");
	}
	
	if (mask & ST_DBGMASK_DECODE)
	{
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"ST_DBGMASK_DECODE","ON");
		enable=TRUE;
	}
	else
	{
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"ST_DBGMASK_DECODE","OFF");
	}
	
	if (mask & ST_DBGMASK_SM)
	{
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"ST_DBGMASK_SM","ON");
		enable=TRUE;
	}
	else
	{
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"ST_DBGMASK_SM","OFF");
	}
	
	if (mask & ST_DBGMASK_NORMAL)
	{
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"ST_DBGMASK_NORMAL","ON");
		enable=TRUE;
	}
	else
	{
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n",
			"ST_DBGMASK_NORMAL","OFF");
	}
#else	
	XOS_CliExtPrintf(pCliEnv, "DEBUGP����δ����!\r\n");
#endif /* DEBUGP */
	RETVALUE(enable);
}

PUBLIC VOID stPrintDbgmsk(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
	StCb *lStCb = &stCb;
#ifdef DEBUGP
	stPrintLayerDbgmsk(pCliEnv, lStCb->init.dbgMask);
#else
	XOS_CliExtPrintf(pCliEnv, "DEBUGP macro not defined!\r\n");
#endif
	RETVOID;
}
/*****************************************************************
 * Print post information
 */
PRIVATE VOID stPrintPostInfo(CLI_ENV *pCliEnv, Pst *pPst, Txt *desc)
{
	XOS_CliExtPrintf(pCliEnv, "---------- %s Post Information ----------\r\n", desc);
	
	XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "memory region", pPst->region);
	XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "memory pool", pPst->pool);
	
	XOS_CliExtPrintf(pCliEnv, "%-25s : %#x\r\n", "source entity", pPst->srcEnt);
	XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "source instance", pPst->srcInst);
	XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "source ProcId", pPst->srcProcId);
	XOS_CliExtPrintf(pCliEnv, "%-25s : %#x\r\n", "destination entity", pPst->dstEnt);
	XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "destination instance", pPst->dstInst);
	XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "destination ProcId", pPst->dstProcId);
	
	XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "message priority", pPst->prior);
	XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "message route", pPst->route);
	XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "message event", pPst->event);

	XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n", "post selector", lmSel[pPst->selector]);
	XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "interface version", pPst->intfVer);

	RETVOID;
}


/*****************************************************************
 * Print General configuration
 */
 
PRIVATE VOID stPrintGenCfg(CLI_ENV *pCliEnv, StGenCfg *cfg)
{
	 XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "max saps", cfg->nmbSaps);
	 XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "max dialogs", cfg->nmbDlgs);
	 XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "max invokes", cfg->nmbInvs);
	 XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "max hash list bins", cfg->nmbBins);
	 XOS_CliExtPrintf(pCliEnv, "%-25s : %d(100ms)\r\n", "timer resolution", 
	 					cfg->timeRes);
	 XOS_CliExtPrintf(pCliEnv, "%-25s : %d(100ms)\r\n", "sap timer resolution", 
	 					cfg->sapTimeRes);
	 XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "lower limit on dialog id",
	 					cfg->loDlgId);
	 XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "higher limit on dialog id", 
	 					cfg->hiDlgId);
	 XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n", "bitmap for dialog ids", 
	 					cfg->bitMapFlg?"TRUE":"FALSE");
	 XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n", "local error control flag", 
	 					cfg->errCntrlFlg?"TRUE":"FALSE");
	RETVOID;
}

/*****************************************************************
 * Print event count
 */
 
PRIVATE VOID stPrintStEvCnt(CLI_ENV *pCliEnv, StEvCnt *cnt, CLI_ENV *desc, U16 *nNum)
{
	if(cnt->cnt)
	{
		XOS_CliExtPrintf(pCliEnv, "%-41s : %d\r\n", desc, cnt->cnt);
		(*nNum) ++;
	}
	
}

/*********************************************************************
 * Print Sap statistics
 */
  
VOID stPrintStSapSts(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
	SuId	suId = 0;
	U8		nNum = 0;
	StTUSap	*sap=NULLP;
	StSapSts *sts = NULLP;
	U16		evntCount = 0;

	if (siArgc > 2)
	{
		XOS_CliExtPrintf(pCliEnv, "��������!\r\n");
		RETVOID;
	}
	
	if (1 == siArgc) /* print sts info on all configured sap */
	{
	    XOS_CliExtPrintf(pCliEnv, "----------------------Statistics----------------------\r\n");

		for (suId=0; suId<stCb.genCfg.nmbSaps; suId++)
		{
			if (NULLP != (sap = stCb.tuSapLst[suId]))
			{
				sts = &sap->sts;
				XOS_CliExtPrintf(pCliEnv, "\n------------- Suid(%d) -- SpId(%d) -------------\r\n",
										sap->suId, sap->spId);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n", "Switch", swtch[sap->cfg.swtch]);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d-%d-%d %d:%d:%d.%d\r\n", 
										"Start sts time", sts->dt.year+1900, sts->dt.month,
										sts->dt.day, sts->dt.hour, sts->dt.min, 
										sts->dt.sec, sts->dt.tenths);
				XOS_CliExtPrintf(pCliEnv, "------------ Messages Sts ------------\r\n");
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "total transmitted", sts->msgTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "unidirect transmitted", sts->uniTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "abort transmitted", sts->abtTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "begin transmitted", sts->bgnTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "continue transmitted", sts->cntTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "total received", sts->msgRx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "unidirect received", sts->uniRx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "abort received", sts->abtRx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "begin received", sts->bgnRx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "continue received", sts->cntRx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "end received", sts->endRx);
				
				XOS_CliExtPrintf(pCliEnv, "------------ Components Sts ----------\r\n");
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "total transmitted", sts->cmpTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "invoke transmitted", sts->invTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "returnResult transmitted", sts->resTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "returnError transmitted", sts->errTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "reject transmitted", sts->rejTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "total received", sts->cmpRx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "invoke received", sts->invRx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "returnResult received", sts->abtRx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "begin received", sts->bgnRx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "continue received", sts->cntRx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "end received", sts->endRx);
				
				XOS_CliExtPrintf(pCliEnv, "------------- abnormal Sts -----------\r\n");
				/* ALL The following counters are maintained for both ITU and ANSI */
				stPrintStEvCnt(pCliEnv,&sts->urCmpRx, 
								(CLI_ENV *)"unkownCmp received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->inCmpRx, 
								(CLI_ENV *)"incorrectCmp received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->bdCmpRx, 
								(CLI_ENV *)"badlyStrcutCmp received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->urLidRx, 
								(CLI_ENV *)"unkownLinkedId received", &evntCount);

				stPrintStEvCnt(pCliEnv,&sts->urIidRRRx, 
								(CLI_ENV *)"returnResult unkownInvId received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxResRx, 
								(CLI_ENV *)"unexpectedReturnResult received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->urIidRERx, 
								(CLI_ENV *)"returnError unkownInvId received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxErrRx, 
								(CLI_ENV *)"unexpectedReturnError received", &evntCount);
				if (!evntCount)
					XOS_CliExtPrintf(pCliEnv, "NULL\r\n");
				else
					evntCount = 0;

				XOS_CliExtPrintf(pCliEnv, "----------- TU problem Sts -----------\r\n");
				/* TC User generated problems */
				stPrintStEvCnt(pCliEnv,&sts->dupIdRx, 
								(CLI_ENV *)"duplicateInvId received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->urOprRx, 
								(CLI_ENV *)"unkownInvOpCode received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->inPrmINRx,
								(CLI_ENV *) "incorrectInvParam received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->rsrcInvRx, 
								(CLI_ENV *)"invResourceLimit received", &evntCount);

				stPrintStEvCnt(pCliEnv,&sts->rlsInvRx, 
								(CLI_ENV *)"InvInitRelease received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxLrspRx, 
								(CLI_ENV *)"unexpectedInvLinkedResp received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxLoprRx, 
								(CLI_ENV *)"unexpectedInvLinkedOp received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->inPrmRRRx, 
								(CLI_ENV *)"incorrectReturnResultParam received", &evntCount);
				   
				stPrintStEvCnt(pCliEnv,&sts->urErrRx, 
								(CLI_ENV *)"returnError unkownErrCode received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxEcdRx, 
								(CLI_ENV *)"returnError unexpectedErrCode received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->inPrmRERx, 
								(CLI_ENV *)"returnError incorrectParam received", &evntCount);

				/* TC User generated problems */
				stPrintStEvCnt(pCliEnv,&sts->dupIdTx, 
								(CLI_ENV *)"duplicateInvId transmitted", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->urOprTx, 
								(CLI_ENV *)"unkownInvOpCode transmitted", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->inPrmINTx, 
								(CLI_ENV *)"incorrectInvParam transmitted", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->rsrcInvTx, 
								(CLI_ENV *)"invResourceLimit transmitted", &evntCount);

				stPrintStEvCnt(pCliEnv,&sts->rlsInvTx, 
								(CLI_ENV *)"InvInitRelease transmitted", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxLrspTx, 
								(CLI_ENV *)"unexpectedInvLinkedResp transmitted", 
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxLoprTx, 
								(CLI_ENV *)"unexpectedInvLinkedOp transmitted", 
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->inPrmRRTx, 
								(CLI_ENV *)"incorrectReturnResultParam transmitted", 
								&evntCount);
				   
				stPrintStEvCnt(pCliEnv,&sts->urErrTx, 
								(CLI_ENV *)"returnError unkownErrCode transmitted",
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxEcdTx, 
								(CLI_ENV *)"returnError unexpectedErrCode transmitted",
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->inPrmRETx, 
								(CLI_ENV *)"returnError incorrectParam transmitted",
								&evntCount);
				if (!evntCount)
					XOS_CliExtPrintf(pCliEnv, "NULL\r\n");
				else
					evntCount = 0;


				XOS_CliExtPrintf(pCliEnv, "---- Transaction portion error Sts ---\r\n");
				/* Protocol error detected in Transaction portion - with P-abort cause */

				/* The following five counters are maintained for both ITU and ANSI */
				stPrintStEvCnt(pCliEnv,&sts->urMsgTx, 
								(CLI_ENV *)"unkownMsgType transmitted", 
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->inTrnTx, 
								(CLI_ENV *)"incorrectTransactionPortion transmitted",
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->bdTrnTx, 
								(CLI_ENV *)"badFormatTransactionPortion transmitted",
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->urTidTx, 
								(CLI_ENV *)"unkownTransactionId transmitted", 
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->rsrcLTx, 
								(CLI_ENV *)"resourceLimit transmitted", 
								&evntCount);
#if 0
				if (!evntCount)
					XOS_CliExtPrintf(pCliEnv, "NULL\r\n");
				else
					evntCount = 0;

				XOS_CliExtPrintf(pCliEnv, "----- Component portion error Sts ----\r\n");
#endif
				/* Protocol error detected in conponent portion - with problem code */

				/* ALL The following counters are maintained for both ITU and ANSI */
				stPrintStEvCnt(pCliEnv,&sts->urCmpTx, 
								(CLI_ENV *)"unkownCmp transmitted", 
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->inCmpTx, 
								(CLI_ENV *)"incorrectCmpPortion transmitted", 
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->bdCmpTx, 
								(CLI_ENV *)"badStructCmpPortion transmitted", 
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->urLidTx, 
								(CLI_ENV *)"unkownInvLinkedId transmitted", 
								&evntCount);

				stPrintStEvCnt(pCliEnv,&sts->urIidRRTx, 
								(CLI_ENV *)"returnResult unkownInvId transmitted", 
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxResTx, 
								(CLI_ENV *)"unexpectedReturnResult transmitted",
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->urIidRETx, 
								(CLI_ENV *)"returnError unkownInvId transmitted",
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxErrTx, 
								(CLI_ENV *)"unexpectedReturnError transmitted", 
								&evntCount);
				if (!evntCount)
					XOS_CliExtPrintf(pCliEnv, "NULL\r\n");
				else
					evntCount = 0;

				nNum ++;
			}
		}
	}

	if (2 == siArgc) /* print sts on the specific sap */
	{
		suId = (SuId)atol(ppArgv[1]);

		if (NULLP != (sap = stCb.tuSapLst[suId]))
			{
				sts = &sap->sts;
				XOS_CliExtPrintf(pCliEnv, "------------- Suid(%d) -- SpId(%d) -------------\r\n",
										sap->suId, sap->spId);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n", "Switch", swtch[sap->cfg.swtch]);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d-%d-%d %d:%d:%d.%d\r\n", 
										"Start sts time", sts->dt.year+1900, sts->dt.month,
										sts->dt.day, sts->dt.hour, sts->dt.min, 
										sts->dt.sec, sts->dt.tenths);
				XOS_CliExtPrintf(pCliEnv, "------------ Messages Sts ------------\r\n");
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "total transmitted", sts->msgTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "unidirect transmitted", sts->uniTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "abort transmitted", sts->abtTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "begin transmitted", sts->bgnTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "continue transmitted", sts->cntTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "total received", sts->msgRx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "unidirect received", sts->uniRx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "abort received", sts->abtRx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "begin received", sts->bgnRx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "continue received", sts->cntRx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "end received", sts->endRx);
				
				XOS_CliExtPrintf(pCliEnv, "----------- Components Sts ----------\r\n");
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "total transmitted", sts->cmpTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "invoke transmitted", sts->invTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "returnResult transmitted", sts->resTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "returnError transmitted", sts->errTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "reject transmitted", sts->rejTx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "total received", sts->cmpRx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "invoke received", sts->invRx);
				XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "returnResult received", sts->abtRx);
				
				XOS_CliExtPrintf(pCliEnv, "------------ abnormal Sts -----------\r\n");
				/* ALL The following counters are maintained for both ITU and ANSI */
				stPrintStEvCnt(pCliEnv,&sts->urCmpRx, 
								(CLI_ENV *)"unkownCmp received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->inCmpRx, 
								(CLI_ENV *)"incorrectCmp received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->bdCmpRx, 
								(CLI_ENV *)"badlyStructCmp received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->urLidRx, 
								(CLI_ENV *)"unkownLinkedId received", &evntCount);

				stPrintStEvCnt(pCliEnv,&sts->urIidRRRx, 
								(CLI_ENV *)"returnResult unkownInvId received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxResRx, 
								(CLI_ENV *)"unexpectedReturnResult received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->urIidRERx, 
								(CLI_ENV *)"returnError unkownInvId received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxErrRx, 
								(CLI_ENV *)"unexpectedReturnError received", &evntCount);
				if (!evntCount)
					XOS_CliExtPrintf(pCliEnv, "NULL\r\n");
				else
					evntCount = 0;

				XOS_CliExtPrintf(pCliEnv, "----------- TU problem Sts ----------\r\n");
				/* TC User generated problems */
				stPrintStEvCnt(pCliEnv,&sts->dupIdRx, 
								(CLI_ENV *)"duplicateInvId received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->urOprRx, 
								(CLI_ENV *)"unkownInvOpCode received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->inPrmINRx,
								(CLI_ENV *) "incorrectInvParam received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->rsrcInvRx, 
								(CLI_ENV *)"invResourceLimit received", &evntCount);

				stPrintStEvCnt(pCliEnv,&sts->rlsInvRx, 
								(CLI_ENV *)"InvInitRelease received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxLrspRx, 
								(CLI_ENV *)"unexpectedInvLinkedResp received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxLoprRx, 
								(CLI_ENV *)"unexpectedInvLinkedOp received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->inPrmRRRx, 
								(CLI_ENV *)"incorrectReturnResultParam received", &evntCount);
				   
				stPrintStEvCnt(pCliEnv,&sts->urErrRx, 
								(CLI_ENV *)"returnError unkownErrCode received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxEcdRx, 
								(CLI_ENV *)"returnError unexpectedErrCode received", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->inPrmRERx, 
								(CLI_ENV *)"returnError incorrectParam received", &evntCount);

				/* TC User generated problems */
				stPrintStEvCnt(pCliEnv,&sts->dupIdTx, 
								(CLI_ENV *)"duplicateInvId transmitted", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->urOprTx, 
								(CLI_ENV *)"unkownInvOpCode transmitted", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->inPrmINTx, 
								(CLI_ENV *)"incorrectInvParam transmitted", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->rsrcInvTx, 
								(CLI_ENV *)"invResourceLimit transmitted", &evntCount);

				stPrintStEvCnt(pCliEnv,&sts->rlsInvTx, 
								(CLI_ENV *)"InvInitRelease transmitted", &evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxLrspTx, 
								(CLI_ENV *)"unexpectedInvLinkedResp transmitted", 
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxLoprTx, 
								(CLI_ENV *)"unexpectedInvLinkedOp transmitted", 
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->inPrmRRTx, 
								(CLI_ENV *)"incorrectReturnResultParam transmitted", 
								&evntCount);
				   
				stPrintStEvCnt(pCliEnv,&sts->urErrTx, 
								(CLI_ENV *)"returnError unkownErrCode transmitted",
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxEcdTx, 
								(CLI_ENV *)"returnError unexpectedErrCode transmitted",
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->inPrmRETx, 
								(CLI_ENV *)"returnError incorrectParam transmitted",
								&evntCount);
				if (!evntCount)
					XOS_CliExtPrintf(pCliEnv, "NULL\r\n");
				else
					evntCount = 0;

				/* Protocol error detected in Transaction portion - with P-abort cause */

				XOS_CliExtPrintf(pCliEnv, "--- Transaction portion error Sts ---\r\n");
				/* The following five counters are maintained for both ITU and ANSI */
				stPrintStEvCnt(pCliEnv,&sts->urMsgTx, 
								(CLI_ENV *)"unkownMsgType transmitted", 
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->inTrnTx, 
								(CLI_ENV *)"incorrectTransactionPortion transmitted",
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->bdTrnTx, 
								(CLI_ENV *)"badFormatTransactionPortion transmitted",
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->urTidTx, 
								(CLI_ENV *)"unkownTransactionId transmitted", 
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->rsrcLTx, 
								(CLI_ENV *)"resourceLimit transmitted", 
								&evntCount);
#if 0				
				if (!evntCount)
					XOS_CliExtPrintf(pCliEnv, "NULL\r\n");
				else
					evntCount = 0;

				XOS_CliExtPrintf(pCliEnv, "---- Component portion error Sts ----\r\n");
#endif				
				/* Protocol error detected in component portion - with problem code */

				/* ALL The following counters are maintained for both ITU and ANSI */
				stPrintStEvCnt(pCliEnv,&sts->urCmpTx, 
								(CLI_ENV *)"unkownCmp transmitted", 
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->inCmpTx, 
								(CLI_ENV *)"incorrectCmpPortion transmitted", 
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->bdCmpTx, 
								(CLI_ENV *)"badStructCmpPortion transmitted", 
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->urLidTx, 
								(CLI_ENV *)"unkownInvLinkedId transmitted", 
								&evntCount);

				stPrintStEvCnt(pCliEnv,&sts->urIidRRTx, 
								(CLI_ENV *)"returnResult unkownInvId transmitted", 
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxResTx, 
								(CLI_ENV *)"unexpectedReturnResult transmitted",
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->urIidRETx, 
								(CLI_ENV *)"returnError unkownInvId transmitted",
								&evntCount);
				stPrintStEvCnt(pCliEnv,&sts->uxErrTx, 
								(CLI_ENV *)"unexpectedReturnError transmitted", 
								&evntCount);
				if (!evntCount)
					XOS_CliExtPrintf(pCliEnv, "NULL\r\n");
				else
					evntCount = 0;

				nNum ++;
			}
		else
		{
			XOS_CliExtPrintf(pCliEnv, "TuSap(%d) not configured!\n", suId);
			RETVOID;
		}
	}
	
	XOS_CliExtPrintf(pCliEnv, "------------------ End of Statistics ------------------\r\n");

}

/*****************************************************************
 * Print bit map
 */
 
VOID stPrintBitMap(CLI_ENV *pCliEnv, StBitMap *bitMap)
{
	U16 i;
	U16 nNum = 0;
	
	XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "bitmap size", bitMap->size);
	
	for(i=0;i<bitMap->size;i++)
	{
		if (bitMap->map[i])
		{
			XOS_CliExtPrintf(pCliEnv, "%-10s%-15d : %d", "bitmap", i, bitMap->map[i]);
			nNum ++;
		}
	}

	if (!nNum)
	{
		XOS_CliExtPrintf(pCliEnv, "%-25s : %s", "bitmap", "all bits are not used");
	}
	XOS_CliExtPrintf(pCliEnv, " \r\n");
	
}

/*****************************************************************
 * Print One TUSap
 */

VOID stPrintStTUSap(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
	SuId	suId = 0;
	U8		nNum = 0;
	StTUSap	*sap=NULLP;

	if (2 < siArgc)
	{
		XOS_CliExtPrintf(pCliEnv, "��������!\r\n");
		RETVOID;
	}
	
	if (1 == siArgc)
	{
	    XOS_CliExtPrintf(pCliEnv, "SuId   SpId   Ssn   Status  Coupling  Switch  invTimer  rejTimer \r\n");
	    XOS_CliExtPrintf(pCliEnv, "-----------------------------------------------------------------\r\n");

		for (suId=0; suId<stCb.genCfg.nmbSaps; suId++)
		{
			if (NULLP != (sap = stCb.tuSapLst[suId]))
			{
				XOS_CliExtPrintf(pCliEnv, " %-4d   %-4d   %-3d   %-6s %-8s  %-6s  %-8d  %-8d \r\n",
					sap->suId, sap->spId, sap->ssn, sapStatus[sap->hlSt],
					tuSel[sap->cfg.tuSel], swtch[sap->cfg.swtch], sap->cfg.t1.val, sap->cfg.t2.val);
				nNum ++;
			}
		}
	}

	if (2 == siArgc)
	{
		suId = (SuId)atol(ppArgv[1]);

		if (NULLP != (sap = stCb.tuSapLst[suId]))
			{
			    XOS_CliExtPrintf(pCliEnv, "SuId   SpId   Ssn   Status  Coupling  Switch  invTimer  rejTimer \r\n");
			    XOS_CliExtPrintf(pCliEnv, "-----------------------------------------------------------------\r\n");

				XOS_CliExtPrintf(pCliEnv, " %-4d   %-4d   %-3d   %-6s %-8s  %-6s  %-8d  %-8d \r\n",
					sap->suId, sap->spId, sap->ssn, sapStatus[sap->hlSt],
					tuSel[sap->cfg.tuSel], swtch[sap->cfg.swtch], sap->cfg.t1.val, sap->cfg.t2.val);

				nNum ++;
			}
		else
		{
			XOS_CliExtPrintf(pCliEnv, "TuSap(%d) not configured!\n", suId);
			RETVOID;
		}
	}
	
    XOS_CliExtPrintf(pCliEnv, "-----------------------------------------------------------------\r\n");
	
	XOS_CliExtPrintf(pCliEnv, "total: %d \r\n",nNum);

	RETVOID;
/*   CmHashListCp dlgHlCp;         /* Hash list of dialogues */
	
}

/*******************************************************************
 * Print SPSap
 */
 
VOID stPrintStSPSap(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
	SuId	suId = 0;
	U8		nNum = 0;
	StSPSap	*sap=NULLP;

	if (2 < siArgc)
	{
		XOS_CliExtPrintf(pCliEnv, "��������!\r\n");
		RETVOID;
	}
	
	if (1 == siArgc)
	{
	    XOS_CliExtPrintf(pCliEnv, "SuId   SpId   Ssn   Status  Coupling  Switch \r\n");
	    XOS_CliExtPrintf(pCliEnv, "---------------------------------------------\r\n");

		for (suId=0; suId<stCb.genCfg.nmbSaps; suId++)
		{
			if (NULLP != (sap = stCb.spSapLst[suId]))
			{
				XOS_CliExtPrintf(pCliEnv, "%-4d   %-4d   %-4d   %-6s %-8s  %-6s \r\n",
					sap->suId, sap->spId, sap->ssn, sapStatus[sap->hlSt],
					spSel[sap->cfg.spSel], swtch[sap->cfg.swtch]);
				nNum ++;
			}
		}
	}

	if (2 == siArgc)
	{
		suId = (SuId)atol(ppArgv[1]);

		if (NULLP != (sap = stCb.spSapLst[suId]))
			{
			    XOS_CliExtPrintf(pCliEnv, "SuId   SpId   Ssn   Status  Selector  Switch \r\n");
			    XOS_CliExtPrintf(pCliEnv, "---------------------------------------------\r\n");

				XOS_CliExtPrintf(pCliEnv, "%-4d   %-4d   %-4d  %-6s %-8s  %-6s \r\n",
					sap->suId, sap->spId, sap->ssn, sapStatus[sap->hlSt],
					spSel[sap->cfg.spSel], swtch[sap->cfg.swtch]);

				nNum ++;
			}
		else
		{
			XOS_CliExtPrintf(pCliEnv, "SpSap(%d) not configured!\n", suId);
			RETVOID;
		}
	}
	
    XOS_CliExtPrintf(pCliEnv, "---------------------------------------------\r\n");
	
	XOS_CliExtPrintf(pCliEnv, "total: %d \r\n",nNum);

	RETVOID;
}


/*****************************************************************
	Print short address
*/

PRIVATE VOID stPrintShrtAddrs(CLI_ENV *pCliEnv, ShrtAddrs *addr, CLI_ENV *desc)
{
	int i;
	
	XOS_CliExtPrintf(pCliEnv, "------- %s -------\r\n", desc);
	XOS_CliExtPrintf(pCliEnv, "%-32s : %d\r\n",
					"length", addr->length);
	
	if(addr->length < SHRTADRLEN)
	{
		XOS_CliExtPrintf(pCliEnv, "%-32s : ","address digits");
		for(i=0;i<addr->length;i++)
		{
			XOS_CliExtPrintf(pCliEnv, "%x",addr->strg[i]);
		}
		XOS_CliExtPrintf(pCliEnv, "\r\n");
		
	}

	RETVOID;
}

/*****************************************************************
 * Print global title
 */
 
PRIVATE VOID stPrintGlbTi(CLI_ENV *pCliEnv, GlbTi *gt, CLI_ENV *desc)
{

   TRC2(cmCopyGt)
  
   if (gt->format == GTFRMT_0)
      RETVOID;

	XOS_CliExtPrintf(pCliEnv, "------- GT in %s -------\r\n", desc);
	switch(gt->format)
	{
		case GTFRMT_1:
			XOS_CliExtPrintf(pCliEnv, "%-32s : %s\r\n",
							"odd/even indicator", gt->gt.f1.oddEven?"EVEN":"ODD");
			XOS_CliExtPrintf(pCliEnv, "%-32s : %d\r\n", 
							"nature of address", gt->gt.f1.natAddr);
			break;
			
		case GTFRMT_2:
			XOS_CliExtPrintf(pCliEnv, "%-32s : %d\r\n",
							"translation type", gt->gt.f2.tType);
			break;
			
		case GTFRMT_3:
			XOS_CliExtPrintf(pCliEnv, "%-32s : %d\r\n",
							"translation type", gt->gt.f3.tType);
			XOS_CliExtPrintf(pCliEnv, "%-32s : %d\r\n",
							"numbering plan", gt->gt.f3.numPlan);
			XOS_CliExtPrintf(pCliEnv, "%-32s : %d\r\n",
							"encoding scheme", gt->gt.f3.encSch);
			break;
			
		case GTFRMT_4:
			XOS_CliExtPrintf(pCliEnv, "%-32s : %d\r\n",
							"translation type", gt->gt.f4.tType);
			XOS_CliExtPrintf(pCliEnv, "%-32s : %d\r\n",
							"numbering plan", gt->gt.f4.numPlan);
			XOS_CliExtPrintf(pCliEnv, "%-32s : %d\r\n",
							"encoding scheme", gt->gt.f4.encSch);
			XOS_CliExtPrintf(pCliEnv, "%-32s : %d\r\n",
							"nature of address", gt->gt.f4.natAddr);
			break;
			
		case GTFRMT_5:
			XOS_CliExtPrintf(pCliEnv, "%-32s : %d\r\n",
							"IP address", gt->gt.f5.ipAddr);
			break;

		default:
			XOS_CliExtPrintf(pCliEnv, "GT format(%d) error!\r\n", gt->format);
			break;
	}
	stPrintShrtAddrs(pCliEnv, &gt->addr, (CLI_ENV *)"BCD address in GT");
		
}

/*****************************************************************
 * Print Sccp address
 */
 
PRIVATE VOID stPrintSpAddr(CLI_ENV *pCliEnv, SpAddr *addr, CLI_ENV *desc)
{
	XOS_CliExtPrintf(pCliEnv, "\n---------- %s ----------\r\n", desc);
#ifdef CMSS7_SPHDROPT
	if ((0 == addr->spHdrOpt) || (1 == addr->spHdrOpt))
		XOS_CliExtPrintf(pCliEnv, "%-32s : %s\r\n",
						"SCCP header filling options", spHdrOpt[addr->spHdrOpt]);
	else
		XOS_CliExtPrintf(pCliEnv, "%-32s : %s(%d)\r\n",
						"SCCP header filling options", "ERROR", addr->spHdrOpt);

#endif /* CMSS7_SPHDROPT */      
	XOS_CliExtPrintf(pCliEnv, "%-32s : %s\r\n", "address presence", addr->pres?"TRUE":"FALSE");

	if ((addr->sw>=0) && (addr->sw<=7))
		XOS_CliExtPrintf(pCliEnv, "%-32s : %s\r\n", "switch", sw[addr->sw]);
	else
		XOS_CliExtPrintf(pCliEnv, "%-32s : %s(%d)\r\n", "switch", "ERROR", addr->sw);
		
	XOS_CliExtPrintf(pCliEnv, "%-32s : %s\r\n", "sub-service presence", addr->ssfPres?"TRUE":"FALSE");
	if (TRUE == addr->ssfPres)
		XOS_CliExtPrintf(pCliEnv, "%-32s : %s\r\n", "sub-service field", ssf[addr->ssf]);
	
	if ((0 == addr->niInd) || (1 == addr->niInd))
		XOS_CliExtPrintf(pCliEnv, "%-32s : %s\r\n", 
						"national/international indicator", niInd[addr->niInd]);
	else
		XOS_CliExtPrintf(pCliEnv, "%-32s : %s(%d)\r\n", 
						"national/international indicator", "ERROR", addr->niInd);

	if ((1==addr->rtgInd) || (0 == addr->rtgInd))
		XOS_CliExtPrintf(pCliEnv, "%-32s : %s\r\n",
						"routing mode", rtgInd[addr->rtgInd]);
	else
		XOS_CliExtPrintf(pCliEnv, "%-32s : %s(%d)\r\n",
						"routing mode", "ERROR", addr->rtgInd);
		
	XOS_CliExtPrintf(pCliEnv, "%-32s : %s\r\n", "ssn indicator", addr->ssnInd?"TRUE":"FALSE");
	if (addr->ssnInd)
		XOS_CliExtPrintf(pCliEnv, "%-32s : %d\r\n", "sub-system number", addr->ssn);
		
	XOS_CliExtPrintf(pCliEnv, "%-32s : %s\r\n", "point code indicator", addr->pcInd?"TRUE":"FALSE");
	if (addr->ssnInd)
		XOS_CliExtPrintf(pCliEnv, "%-32s : %#x\r\n", "point code", addr->pc);

	stPrintGlbTi(pCliEnv,&addr->gt,desc);
	
	RETVOID;
}

/*****************************************************************
 * Print one dialog
 */
 
VOID stPrintOneDialog(CLI_ENV *pCliEnv, StDlgCp  *dlgCp)
{
	if (dlgCp == NULLP)
		RETVOID;

	XOS_CliExtPrintf(pCliEnv, "\n--------suDlgId(%d)-spDlgId(%d)-dstDlgId(%d)-dstDlgIdLen(%d)--------\r\n",
		dlgCp->suDlgId, dlgCp->spDlgId, dlgCp->dstDlgId, dlgCp->dstDlgIdLen);

	if (TRUE != dlgCp->dstAddr.pres)
		XOS_CliExtPrintf(pCliEnv, "%-32s : %s\r\n", 
					"dstAddr presence", "FALSE");
	else
		stPrintSpAddr(pCliEnv, &dlgCp->dstAddr, (CLI_ENV *)"dstAddr");
		
	if (TRUE != dlgCp->srcAddr.pres)
		XOS_CliExtPrintf(pCliEnv, "%-32s : %s\r\n", 
					"srcAddr presence", "FALSE");
	else
		stPrintSpAddr(pCliEnv, &dlgCp->srcAddr, (CLI_ENV *)"srcAddr");

	if ((dlgCp->dhaSt>=0) && (dlgCp->dhaSt<=4))
		XOS_CliExtPrintf(pCliEnv, "%-32s : %s\r\n", 
						"DHA machine status", dhaSt[dlgCp->dhaSt]);
	else
		XOS_CliExtPrintf(pCliEnv, "%-32s : %s(%d)\r\n", 
						"DHA machine status", "ERROR", dlgCp->dhaSt);
		
	if ((dlgCp->tslSt>=100) && (dlgCp->tslSt<=104))
	XOS_CliExtPrintf(pCliEnv, "%-32s : %s\r\n",
					"TSL machine status", tslSt[dlgCp->tslSt-100]);
	else
	XOS_CliExtPrintf(pCliEnv, "%-32s : %s(%d)\r\n",
					"TSL machine status", "ERROR", dlgCp->tslSt-100);
	
	XOS_CliExtPrintf(pCliEnv, "%-32s ? %s\r\n", 
					"Is the first backward message", dlgCp->firstBackMsg?"YES":"NO");
#if 0
	if(dlgCp->sapCp && dlgCp->sapCp->spId)
		XOS_CliExtPrintf(pCliEnv, "%-32s : %d\r\n", 
						"sap control point", dlgCp->sapCp->spId);
#endif 

	if(dlgCp->opc)
		XOS_CliExtPrintf(pCliEnv, "%-32s : %#x\r\n", 
						"origination point code", dlgCp->opc);
	
#ifdef ZT
	XOS_CliExtPrintf(pCliEnv, "%-32s : %s\r\n", 
					"warm start update flag", dlgCp->wsUpdFlg?"YES":"NO");
#endif /* ZT */

	RETVOID;
}
/*****************************************************************
 * Print all dialog in one sap
 */
 
VOID stPrintAllDialogInOneSap(CLI_ENV *pCliEnv, SpId spId)
{
	StDlgCp  *dlgCp=NULLP;
	StTUSap *sap=NULLP;
	U32		uNum = 0;

	if(spId < stCb.genCfg.nmbSaps)
	{
		sap = stCb.tuSapLst[spId];
	}
	if (sap == NULLP)
	{
		XOS_CliExtPrintf(pCliEnv, "SapId(%d) > cfgNmb(%d) , or sap is NULLP!\r\n", 
				spId, stCb.genCfg.nmbSaps);
		RETVOID;
	}

	while (cmHashListGetNext(&sap->dlgHlCp, NULLP, (PTR *)&dlgCp) == ROK)
	{
		stPrintOneDialog(pCliEnv, dlgCp);
		uNum ++;
	}

	if (0 == uNum)
	{
		XOS_CliExtPrintf(pCliEnv, "no dialog exist!\r\n");
	}

	RETVOID;	
}


/*****************************************************************
 * Print one dialog by id
 */
 
VOID stPrintOneDialogById(CLI_ENV *pCliEnv, SpId spId, StDlgId  suDlgId)
{
	StDlgCp  *dlgCp=NULLP;
	StTUSap *sap=NULLP;

	if(spId < stCb.genCfg.nmbSaps)
	{
		sap = stCb.tuSapLst[spId];
	}
	if (sap == NULLP)
	{
		XOS_CliExtPrintf(pCliEnv, "SapId(%d) > cfgNmb(%d) , or sap is NULLP!\r\n", 
				spId, stCb.genCfg.nmbSaps);
		RETVOID;
	}
	
	if (ROK != stFndDlg(&sap->dlgHlCp, &sap->suDlgHlCp, suDlgId, ST_USE_SUDLGID,&dlgCp))
	{
		XOS_CliExtPrintf(pCliEnv, "dialog(%d) in sap(%d) not found!\r\n",
						suDlgId, spId);
		RETVOID;
	}
	stPrintOneDialog(pCliEnv, dlgCp);

	RETVOID;
}

/*****************************************************************
 * Print one dialog in brief
 */
 
VOID stPrintOneDialogInBrief(CLI_ENV *pCliEnv, StDlgCp  *dlgCp)
{
	if (dlgCp == NULLP)
		RETVOID;
	
	XOS_CliExtPrintf(pCliEnv, "\n--------suDlgId(%d)-spDlgId(%d)-dstDlgId(%d)-dstDlgIdLen(%d)--------\r\n",
		dlgCp->suDlgId, dlgCp->spDlgId, dlgCp->dstDlgId, dlgCp->dstDlgIdLen);

	RETVOID;
}
VOID stPrintAllDialogInBrief(CLI_ENV *pCliEnv)
{
	int i;
	StDlgCp  *dlgCp=NULLP;
	StTUSap *sap=NULLP;
	StDlgCp   *tmpDlg;
	U32		uNum = 0;

	for(i=0;i< stCb.genCfg.nmbSaps; i++)
	{
		sap = stCb.tuSapLst[i];
		if (sap != NULLP)
		{
			tmpDlg=NULLP;
			while (cmHashListGetNext(&sap->dlgHlCp, (PTR)tmpDlg, (PTR *)&dlgCp) == ROK)
			{
				stPrintOneDialogInBrief(pCliEnv, dlgCp);
				tmpDlg = dlgCp;
				uNum ++;
			}
		}
	}

	if (0 == uNum)
	{
		XOS_CliExtPrintf(pCliEnv, "no dialog exist!\r\n");
	}

	RETVOID;
}

/*****************************************************************
 * Print dialog
 */
 
VOID stPrintDialog(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
	int par1, par2;
	
	switch(siArgc)
	{
	case 3:
		{
			par1 = atol(ppArgv[1]);
			par2 = atol(ppArgv[2]);

			stPrintOneDialogById(pCliEnv, (SpId)par1, (StDlgId)par2);
		}
		break;

	case 2:
		{
			par1 = atol(ppArgv[1]);
			stPrintAllDialogInOneSap(pCliEnv, (SpId)par1);
		}
		break;

	case 1:
		{
			stPrintAllDialogInBrief(pCliEnv);
		}
		break;
			
	default:
        XOS_CliExtPrintf(pCliEnv, "\r\n���������������");
		break;
	}

        RETVOID;
}

/*****************************************************************
 * Print task initialization
 */

PRIVATE VOID stPrintTskInit(CLI_ENV *pCliEnv, TskInit *init)
{
#ifdef SS_MULTIPLE_PROCS
	XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "processor", init->proc);
#endif /* SS_MULTIPLE_PROCS */

	XOS_CliExtPrintf(pCliEnv, "%-25s : %#x\r\n", "entity", init->ent);
	XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "instance", init->inst);
	XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "region", init->region);
	XOS_CliExtPrintf(pCliEnv, "%-25s : %d\r\n", "pool", init->pool);
	XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n", "reason", initReason[init->reason]);
	XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n", "CfgDone", init->cfgDone?"TRUE":"FALSE");
	XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n", "Accounting", init->acnt?"TRUE":"FALSE");
	XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n", "unsolicited status", init->usta?"TRUE":"FALSE");
	XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n", "trace", init->trc?"ON":"OFF");
	stPrintPostInfo(pCliEnv, &init->lmPst, "LM");
}

/*****************************************************************
 * Print TCAP control block 
 */

VOID stPrintStCb(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
	double memUsage = 0;
	StCb *lStCb = &stCb;

	XOS_CliExtPrintf(pCliEnv, "----- Task Initialization Structure -----\r\n");
	
	stPrintTskInit(pCliEnv, &lStCb->init);
	
#ifdef DEBUGP
	XOS_CliExtPrintf(pCliEnv, "--------- Debug Mask Information --------\r\n");
	stPrintLayerDbgmsk(pCliEnv,  lStCb->init.dbgMask);
#endif	

	XOS_CliExtPrintf(pCliEnv, "--------- General Configuration ---------\r\n");
	stPrintGenCfg(pCliEnv, &lStCb->genCfg);
	
	XOS_CliExtPrintf(pCliEnv, "----------- Memory Information ----------\r\n");
	XOS_CliExtPrintf(pCliEnv, "%-25s : %d Bytes\r\n", "memory reserved", 
	 				lStCb->memSize);
	XOS_CliExtPrintf(pCliEnv, "%-25s : %d Bytes\r\n", "memory allocated", 
	 				lStCb->allocMem);
	if (0 != lStCb->memSize)
		memUsage = (double)(lStCb->allocMem)/(lStCb->memSize);
	XOS_CliExtPrintf(pCliEnv, "%-25s : %f%%\r\n", "memory usage", memUsage*100);
	
	XOS_CliExtPrintf(pCliEnv, "----------- Other Information -----------\r\n");
	XOS_CliExtPrintf(pCliEnv, "%-25s : %s\r\n", "layer timer flag", 
	 				lStCb->tmrFlag?"TRUE":"FALSE");

	RETVOID;
}


/*****************************************************************
 * Print TUSap bit map
 */
 
VOID stPrintTuSapBitMap(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
	SuId	suId = 0;
	StTUSap *sap=NULLP;
	U16		nNum = 0;

	if (siArgc > 2)
	{
		XOS_CliExtPrintf(pCliEnv, "��������!\r\n");
		RETVOID;
	}

	if (2 == siArgc)
	{
		suId = (SuId)atol(ppArgv[1]);
		
		if(suId < stCb.genCfg.nmbSaps)
		{
			sap = stCb.tuSapLst[suId];
		}
		if (sap == NULLP)
		{
			XOS_CliExtPrintf(pCliEnv, "sapId(%d) > cfgNmb(%d), or sap not configed!\r\n", 
					suId, stCb.genCfg.nmbSaps);
			RETVOID;
		}
		XOS_CliExtPrintf(pCliEnv, "\n------------- Suid(%d) -- SpId(%d) -------------\r\n",
										sap->suId, sap->spId);
		stPrintBitMap(pCliEnv, &sap->bitMap);
		XOS_CliExtPrintf(pCliEnv, "------------------------------------------------\r\n");
	}

	if (1 == siArgc)
	{
		for (suId = 0;suId < stCb.genCfg.nmbSaps; suId++)
		{
			sap = stCb.tuSapLst[suId];
			
			if (sap != NULLP)
			{
				XOS_CliExtPrintf(pCliEnv, "\n------------- Suid(%d) -- SpId(%d) -------------\r\n",
										sap->suId, sap->spId);
				stPrintBitMap(pCliEnv, &sap->bitMap);
				nNum ++;
			}
		}
		XOS_CliExtPrintf(pCliEnv, "------------------------------------------------\r\n");
		XOS_CliExtPrintf(pCliEnv, "Total: %d\r\n", nNum);
	}

	RETVOID;
}
#if 0
XVOID stPrintRegionInfo(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
	if (siArgc > 2)
	{
		printf("������������!\n");
		RETVOID;
	}
	
	if (atol(ppArgv[1]) < 0)
	{
		printf("��������!\n");
		RETVOID;
	}

	SRegInfoShow((Region)atol(ppArgv[1]));

	RETVOID;
}
#endif
XVOID stPrintSts(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
	SuId	suId = 0;
	StTUSap	*sap=NULLP;
	Action	action;
	StMngmt	sts;
	Pst		pst;
	U32		uNum = 0;

	/* init var. */
	memset(&action, 0, sizeof(Action));
	memset(&sts, 0, sizeof(StMngmt));
	memset(&pst, 0, sizeof(Pst));
	
	pst.dstEnt = ENTST;
	pst.dstInst = 0;
	pst.dstProcId = SFndProcId();

	pst.srcEnt = ENTSM;
	pst.dstInst = 0;
	pst.srcProcId = SFndProcId();

	pst.pool = 0;
	pst.region = 0;
	pst.route = RTE_PROTO;
	pst.selector = 0;
	
	sts.hdr.elmId.elmnt      = STTCUSAP;
	
	if (siArgc > 3)
	{
		XOS_CliExtPrintf(pCliEnv, "��������!\r\n");
		RETVOID;
	}
	switch (siArgc)
	{
		case 1:
			for (suId=0; suId<stCb.genCfg.nmbSaps; suId++)
			{
				if (NULLP != (sap = stCb.tuSapLst[suId]))
				{
					action = NOZEROSTS;
					sts.hdr.elmId.elmntInst1 = suId;
					StMiLstStsReq(&pst, action, &sts);
					uNum ++;
				}
			}
			break;

		case 2:
			suId = (SuId)atol(ppArgv[1]);

			if (NULLP != (sap = stCb.tuSapLst[suId]))
			{
					action = NOZEROSTS;
					sts.hdr.elmId.elmntInst1 = suId;
					StMiLstStsReq(&pst, action, &sts);
					uNum ++;
			}
			break;

		case 3:
			if ((0 != atol(ppArgv[2])) && (1 != atol(ppArgv[2])))
				XOS_CliExtPrintf(pCliEnv, "��������!\r\n");
			else
			{
				if (-1 == atol(ppArgv[1])) /* for all saps */
				{
					for (suId=0; suId<stCb.genCfg.nmbSaps; suId++)
					{
						if (NULLP != (sap = stCb.tuSapLst[suId]))
						{
							action = (Action)atol(ppArgv[2]);
							sts.hdr.elmId.elmntInst1 = suId;
							StMiLstStsReq(&pst, action, &sts);
							uNum ++;
						}
					}
					
				}
				else /* for specific sap */
				{
					suId = (SuId)atol(ppArgv[1]);

					if (NULLP != (sap = stCb.tuSapLst[suId]))
					{
							action = NOZEROSTS;
							sts.hdr.elmId.elmntInst1 = suId;
							StMiLstStsReq(&pst, action, &sts);
							uNum ++;
					}
				}
			}
				
			break;

		default:
			XOS_CliExtPrintf(pCliEnv, "��������!\r\n");
			RETVOID;
			
	}

	if (!uNum)
	{
		XOS_CliExtPrintf(pCliEnv, "SAP ID����!\r\n");
	}
	RETVOID;
}

#ifdef CP_OAM_SUPPORT
XVOID stDynCfgDbg(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
	U32 tableid = 271;
	U16 msgtype = 2;
	U32 sequence = 1;
	U8 pack_end = TRUE;

	tb_record row;
	StGenCfgTab stGenCfgTab;

	cmMemset((U8 *)&row, 0, sizeof(tb_record));

	switch(siArgc)
	{
		case 4:
		{
			if (0 != atol(ppArgv[1]))	/* the first argument must be 0 */
			{
				printf("��������!\r\n");
				RETVOID;
			}

			/* argument must be a non-zero value */
			if ((atol(ppArgv[2]) < 0) || (atol(ppArgv[3]) < 0))
			{
				printf("��������С��0!\r\n");
				RETVOID;
			}

			row.head.mask[0] = 0x01;
			row.head.mask[0] |= 0x02;
			row.head.col_count = 2;
			stGenCfgTab.invTmr = atol(ppArgv[2]);
			stGenCfgTab.rejTmr = atol(ppArgv[3]);				
		}
		break;
		
		case 3:
		{
			switch(atol(ppArgv[1]))
			{
				case 0:
					printf("��������!\r\n");
					RETVOID;
					break;
					
				case 1:
					row.head.mask[0] = 0x01;
					row.head.col_count = 1;
					stGenCfgTab.invTmr = atol(ppArgv[2]);
					break;

				case 2:
					row.head.mask[0] = 0x02;
					row.head.col_count = 1;
					stGenCfgTab.rejTmr = atol(ppArgv[3]);
					break;
					
				default:
					printf("����ֵ����!\r\n");
					RETVOID;
			}				
		}
		break;

		case 2:
		case 1:
		default:
			printf("��������!\r\n");
			RETVOID;
	}

	row.panytbrow = (StGenCfgTab*)&stGenCfgTab;
	row.tableid = tableid;
	stDynCfgCallback(tableid, msgtype, sequence, pack_end, &row);
	
	RETVOID;
}
#endif /* CP_OAM_SUPPORT */

#endif /* SSI_WITH_CLI_ENABLED */


/*added by wanglijun for set dbgmask from shell*/
#ifdef ST_DEBUG
U32 g_stDbgMask = DBGMASK_LI|DBGMASK_UI|DBGMASK_MI;
#else
U32 g_stDbgMask = 0;
#endif

Void stSetDbgMaskFromShell(U32 dbgMask)
{
  g_stDbgMask = dbgMask;
#ifdef DEBUGP
  stCb.init.dbgMask = g_stDbgMask;
#endif
  RETVOID;
}



