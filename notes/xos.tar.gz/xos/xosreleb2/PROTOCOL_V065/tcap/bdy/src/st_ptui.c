/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     tcap - portable - upper interface
  
     Type:     C source file
  
     Desc:     C source code for the tcap upper interface primitives.

     File:     st_ptui.c
  
     Sid:      st_ptui.c@@/main/14 - Fri Nov 17 10:34:20 2000
  
     Prg:      nj
  
*********************************************************************21*/


/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif
#ifdef CCITT96
               CCITT 96
#endif
#if SS7_ANS
      -12      ANSI
#endif
#if SS7_ANS88
      -12      ANSI 88
#endif
#if SS7_ANS92
      -12      ANSI 92
#endif
#if SS7_ANS96
      -12      ANSI 96
#endif
#if SS7_ETSI
               ETSI
#endif
 
************************************************************************/


/*
  
The following functions are provided in this file:

     StUiStuDatInd       st - upper interface - Data Indication
     StUiStuUDatInd      st - upper interface - Unit Data Indication
     StUiStuCmpInd       st - upper interface - Component Indication
     StUiStuCmpCfm       st - upper interface - Component Confirm
     StUiStuSteInd       st - upper interface - State Indication
     StUiStuSteCfm       st - upper interface - State Confirm
     StUiStuNotInd       st - upper interface - Notice Indication
     StUiStuStaInd       st - upper interface - Status Indication   
     StUiStuBndCfm       st - upper interface - Bind Confirm   


It should be noted that not all of these functions may be required
by a particular TCAP layer service user.

It is assumed that the following functions are provided in the TCAP level:

     StUiStuBndReq       st - upper interface - Bind Request
     StUiStuUbndReq      st - upper interface - Unbind Request
     StUiStuDatReq       st - upper interface - Data Request
     StUiStuUDatReq      st - upper interface - Data Request
     StUiStuCmpReq       st - upper interface - Component Request
     StUiStuSteReq       st - upper interface - State Request
     StUiStuSteRsp       st - upper interface - State Response
  
*/

  
/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000011     Multiprocessor Operating System
*     1000030     SS7 - SCCP
*/
  
  

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* Common timer */
#include "cm_ss7.h"        /* ss7 layer */
#include "cm_hash.h"       /* Common hash */
#include "cm_err.h"        /* common error */
#include "stu.h"           /* Tcap upper interface */
#include "lst.h"           /* Layer management specific defines */
#include "st.h"            /* TCAP layer defines */
#include "st_err.h"        /* TCAP layer Error defines */

#ifdef ST_FTHA
#include "sht.h"           /* SHT */
#endif /* ST_FTHA */

#ifdef ZT
#include "cm_ftha.h"
#include "cm_pftha.h"
#include "cm_psfft.h"
#endif /* ZT */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* Common timer */
#include "cm_ss7.x"        /* common ss7 */
#include "cm_hash.x"       /* Common hash */
#include "stu.x"           /* Tcap upper interface */
#include "lst.x"           /* Layer management specific structures */
#include "st_mf.x"         /* Tcap */

#ifdef ST_FTHA
#include "sht.x"           /* SHT */
#endif /* ST_FTHA */

#ifdef ZT
#include "cm_ftha.x"
#include "cm_pftha.x"
#include "cm_psfft.x"
#endif /* ZT */

/* st007.301 - Added - spt.x included under ST_TC_USER_DIST */
#include "spt.x"

#include "st.x"            /* TCAP layer specific structures */


/* local defines */

/* local externs */
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifndef SS_MULTIPLE_PROCS
EXTERN  StCb   stCb;       /* TCAP layer control block */
#endif /* SS_MULTIPLE_PROCS */

/* forward references */
/* st014.301 - Add - dataParam  field */
#ifdef STUV2
PRIVATE S16 PtUiStuDatInd    ARGS((Pst            *pst,
                                   SuId            suId,
                                   U8              msgType,
                                   StDlgId         suDlgId,
                                   StDlgId         spDlgId, 
                                   SpAddr         *destAddr,
                                   SpAddr         *srcAddr,
                                   Bool            compsPres,
                                   StOctet        *prvAbrtCause,
                                   StQosSet       *stQosSet,
                                   Dpc             opc,
                                   StDlgEv        *stDlgEv,
                                   StDataParam    *dataParam,      
                                   Buffer         *uiBuf));
#else  /* not STUV2 */
PRIVATE S16 PtUiStuDatInd    ARGS((Pst            *pst,
                                   SuId            suId,
                                   U8              msgType,
                                   StDlgId         suDlgId,
                                   StDlgId         spDlgId, 
                                   SpAddr         *destAddr,
                                   SpAddr         *srcAddr,
                                   Bool            compsPres,
                                   StOctet        *prvAbrtCause,
                                   StQosSet       *stQosSet,
                                   Dpc             opc,
                                   StDlgEv        *stDlgEv,
                                   Buffer         *uiBuf));
#endif /* STUV2 */

/* st014.301 - Add - dataParam  field */
#ifdef STUV2
/* st029.301 - Add - suDlgId and spDlgId are added for STUV3 */
#ifdef STUV3
PRIVATE S16 PtUiStuUDatInd   ARGS((Pst            *pst,
                                   SuId            suId,
                                   StDlgId	   suDlgId,
                                   StDlgId	   spDlgId,
                                   SpAddr         *destAddr,
                                   SpAddr         *srcAddr,
                                   StQosSet       *stQosSet,
                                   Dpc             opc,
                                   StDlgEv        *stDlgEv,
                                   StDataParam    *dataParam,      
                                   Buffer         *uiBuf));
#else /* not STUV3 */
PRIVATE S16 PtUiStuUDatInd   ARGS((Pst            *pst,
                                   SuId            suId,
                                   SpAddr         *destAddr,
                                   SpAddr         *srcAddr,
                                   StQosSet       *stQosSet,
                                   Dpc             opc,
                                   StDlgEv        *stDlgEv,
                                   StDataParam    *dataParam,      
                                   Buffer         *uiBuf));
#endif
#else  /* not STUV2 */
PRIVATE S16 PtUiStuUDatInd   ARGS((Pst            *pst,
                                   SuId            suId,
                                   SpAddr         *destAddr,
                                   SpAddr         *srcAddr,
                                   StQosSet       *stQosSet,
                                   Dpc             opc,
                                   StDlgEv        *stDlgEv,
                                   Buffer         *uiBuf));
#endif /* STUV2 */

PRIVATE S16 PtUiStuCmpInd    ARGS((Pst            *pst,
                                   SuId            suId,
                                   StDlgId         suDlgId,
                                   StDlgId         spDlgId, 
                                   StComps        *compEv,
                                   Dpc             opc,
                                   Status          status,
                                   Buffer         *cpBuf));

PRIVATE S16 PtUiStuCmpCfm    ARGS((Pst            *pst,
                                   SuId            suId,
                                   StDlgId         suDlgId,
                                   StDlgId         spDlgId));

/* st014.301 - Add - dataParam  field */
#ifdef STUV2
PRIVATE S16 PtUiStuNotInd    ARGS((Pst            *pst,
                                   SuId            suId,
                                   StDlgId         suDlgId,
                                   StDlgId         spDlgId, 
                                   SpAddr         *destAddr,
                                   SpAddr         *srcAddr,
                                   StDataParam    *dataParam,      
                                   RCause          ret));
#else  /* not STUV2 */
PRIVATE S16 PtUiStuNotInd    ARGS((Pst            *pst,
                                   SuId            suId,
                                   StDlgId         suDlgId,
                                   StDlgId         spDlgId, 
                                   SpAddr         *destAddr,
                                   SpAddr         *srcAddr,
                                   RCause          ret));
#endif /* STUV2 */

/* st014.301 - Add - Sccp State, Restricted importance level fields  */
#ifdef STUV2
PRIVATE S16 PtUiStuSteInd    ARGS((Pst            *pst,
                                   SuId            suId,
                                   CmSS7SteMgmt   *steMgmt,
                                   StMgmntParam   *mgmntParam));
#else /* not STUV2 */
PRIVATE S16 PtUiStuSteInd    ARGS((Pst            *pst,
                                   SuId            suId,
                                   CmSS7SteMgmt   *steMgmt));
#endif /* STUV2 */

/* st014.301 - Add - Sccp State, Restricted importance level fields  */
#ifdef STUV2
PRIVATE S16 PtUiStuSteCfm    ARGS((Pst            *pst,
                                   SuId            suId,
                                   CmSS7SteMgmt   *steMgmt,
                                   StMgmntParam   *mgmntParam));
#else /* not STUV2 */
PRIVATE S16 PtUiStuSteCfm    ARGS((Pst            *pst,
                                   SuId            suId,
                                   CmSS7SteMgmt   *steMgmt));
#endif /* STUV2 */

PRIVATE S16 PtUiStuStaInd    ARGS((Pst            *pst,
                                   SuId            suId,
                                   Status          status));

#ifdef STU2
PRIVATE S16 PtUiStuBndCfm    ARGS((Pst            *pst,
                                   SuId            suId,
                                   U8              status));
#endif /* STU2 */


/* functions in other modules */
  
/* public variable declarations */

/* private variable declarations */

/*
   The following matrices define the mapping between the primitives called
   by the upper interface of TCAP and the corresponding primitives of the
   TCAP service user(s).

   The parameter MAXSTUI defines the maximum number of service users on top
   of TCAP. There is an array of functions per primitive invoked by TCAP.
   Every array is MAXSTUI long (i.e. there are as many functions as the number
   of service users).

   The dispatching is performed by the configurable variable: selector.
   The selector is configured on a per SAP basis.

   The selectors are:

   0 - loosely coupled (#define LCSTUISTU)
   1 - TCAP USER (#define TU)
   2 - TCAP USER - MAP (#define MA)
   3 - TCAP USER - IS-41 (#define IA)
   4 - TCAP USER - INAP (#define IE)
   5 - TCAP USER - CAP (#define QC)
*/


/* TCAP Data Indication primitive */

PUBLIC StuDatInd stUiDatIndMt [MAXSTUI] =
{
#ifdef LCSTUISTU
   cmPkStuDatInd,        /* 0 - loosely coupled */
#else
   PtUiStuDatInd,        /* 0 - tightly coupled, portable */
#endif

#ifdef TU
   TuLiStuDatInd,        /* 1 - tightly coupled, TCAP user */
#else
   PtUiStuDatInd,        /* 1 - tightly coupled, portable */
#endif

#ifdef MA
   MaLiStuDatInd,        /* 2 - tightly coupled, TCAP user - MAP */
#else
   PtUiStuDatInd,        /* 2 - tightly coupled, portable */
#endif

#ifdef IA
   IaLiStuDatInd,        /* 3 - tightly coupled, TCAP user - IS-41 */
#else
   PtUiStuDatInd,        /* 3 - tightly coupled, portable */
#endif

#ifdef IE
   IeLiStuDatInd,        /* 4 - tightly coupled, TCAP user - INAP */
#else
   PtUiStuDatInd,        /* 4 - tightly coupled, portable */
#endif

/* st002.301 - Incorporating CAP support for TCAP */
#ifdef QC
   QcLiStuDatInd,        /* 5 - tightly coupled, TCAP user - CAP */
#else
   PtUiStuDatInd,        /* 5 - tightly coupled, portable */
#endif

/* st013.301 - Incorporating DSTU support for TCAP */
#ifdef DSTU 
   DstuLiStuDatInd,      /* 6 - tightly coupled, TCAP user - DSTU */
#else
   PtUiStuDatInd,        /* 6 - tightly coupled, portable */
#endif

/* st013.301 - Incorporating lower LDF function support for TCAP */
#ifdef DSDT 
   DsdtUiStuDatInd,      /* 7 - tightly coupled, TCAP-LLDF */
#else
   PtUiStuDatInd,        /* 7 - tightly coupled, portable */
#endif
};


/* TCAP Unit Data Indication primitive */

PUBLIC StuUDatInd stUiUDatIndMt [MAXSTUI] =
{
#ifdef LCSTUISTU
   cmPkStuUDatInd,       /* 0 - loosely coupled */
#else
   PtUiStuUDatInd,       /* 0 - tightly coupled, portable */
#endif

#ifdef TU
   TuLiStuUDatInd,       /* 1 - tightly coupled, TCAP user */
#else
   PtUiStuUDatInd,       /* 1 - tightly coupled, portable */
#endif

#ifdef MA
   MaLiStuUDatInd,       /* 2 - tightly coupled, TCAP user - MAP */
#else
   PtUiStuUDatInd,       /* 2 - tightly coupled, portable */
#endif

#ifdef IA
   IaLiStuUDatInd,       /* 3 - tightly coupled, TCAP user - IS-41 */
#else
   PtUiStuUDatInd,       /* 3 - tightly coupled, portable */
#endif

#ifdef IE
   IeLiStuUDatInd,       /* 4 - tightly coupled, TCAP user - INAP */
#else
   PtUiStuUDatInd,       /* 4 - tightly coupled, portable */
#endif

/* st002.301 - Incorporating CAP support for TCAP */
#ifdef QC
   QcLiStuUDatInd,       /* 5 - tightly coupled, TCAP user - CAP */
#else
   PtUiStuUDatInd,         /* 5 - tightly coupled, portable */
#endif

/* st013.301 - Incorporating DSTU support for TCAP */
#ifdef DSTU 
   DstuLiStuUDatInd,     /* 6 - tightly coupled, TCAP user - DSTU */
#else
   PtUiStuUDatInd,       /* 6 - tightly coupled, portable */
#endif

/* st013.301 - Incorporating lower LDF function support for TCAP */
#ifdef DSDT 
   DsdtUiStuUDatInd,     /* 7 - tightly coupled, TCAP-LLDF */
#else
   PtUiStuUDatInd,       /* 7 - tightly coupled, portable */
#endif
};


/* TCAP Component Indication primitive */

PUBLIC StuCmpInd stUiCmpIndMt [MAXSTUI] =
{
#ifdef LCSTUISTU
   cmPkStuCmpInd,        /* 0 - loosely coupled */ 
#else
   PtUiStuCmpInd,        /* 0 - tightly coupled, portable */
#endif

#ifdef TU
   TuLiStuCmpInd,        /* 1 - tightly coupled, TCAP user */
#else
   PtUiStuCmpInd,        /* 1 - tightly coupled, portable */
#endif

#ifdef MA
   MaLiStuCmpInd,        /* 2 - tightly coupled, TCAP user -MAP */
#else
   PtUiStuCmpInd,        /* 2 - tightly coupled, portable */
#endif

#ifdef IA
   IaLiStuCmpInd,        /* 3 - tightly coupled, TCAP user - IS-41 */
#else
   PtUiStuCmpInd,        /* 3 - tightly coupled, portable */
#endif

#ifdef IE
   IeLiStuCmpInd,        /* 4 - tightly coupled, TCAP user - INAP */
#else
   PtUiStuCmpInd,        /* 4 - tightly coupled, portable */
#endif

/* st002.301 - Incorporating CAP support for TCAP */
#ifdef QC
   QcLiStuCmpInd,        /* 5 - tightly coupled, TCAP user - CAP */
#else
   PtUiStuCmpInd,        /* 5 - tightly coupled, portable */
#endif

/* st013.301 - Incorporating DSTU support for TCAP */
#ifdef DSTU 
   DstuLiStuCmpInd,      /* 6 - tightly coupled, TCAP user - DSTU */
#else
   PtUiStuCmpInd,        /* 6 - tightly coupled, portable */
#endif

/* st013.301 - Incorporating lower LDF function support for TCAP */
#ifdef DSDT 
   DsdtUiStuCmpInd,      /* 7 - tightly coupled, TCAP-LLDF */
#else
   PtUiStuCmpInd,        /* 7 - tightly coupled, portable */
#endif
};


/* TCAP Component Confirm primitive */

PUBLIC StuCmpCfm stUiCmpCfmMt [MAXSTUI] =
{
#ifdef LCSTUISTU
   cmPkStuCmpCfm,        /* 0 - loosely coupled */ 
#else
   PtUiStuCmpCfm,        /* 0 - tightly coupled, portable */
#endif

#ifdef TU
   TuLiStuCmpCfm,        /* 1 - tightly coupled, TCAP user */
#else
   PtUiStuCmpCfm,        /* 1 - tightly coupled, portable */
#endif

#ifdef MA
   MaLiStuCmpCfm,        /* 2 - tightly coupled, TCAP user - MAP */
#else
   PtUiStuCmpCfm,        /* 2 - tightly coupled, portable */
#endif

#ifdef IA
   IaLiStuCmpCfm,        /* 3 - tightly coupled, TCAP user - IS-41 */
#else
   PtUiStuCmpCfm,        /* 3 - tightly coupled, portable */
#endif

#ifdef IE
   IeLiStuCmpCfm,        /* 4 - tightly coupled, TCAP user - INAP */
#else
   PtUiStuCmpCfm,        /* 4 - tightly coupled, portable */
#endif

/* st002.301 - Incorporating CAP support for TCAP */
#ifdef QC
   QcLiStuCmpCfm,        /* 5 - tightly coupled, TCAP user - CAP */
#else
   PtUiStuCmpCfm,        /* 5 - tightly coupled, portable */
#endif

/* st013.301 - Incorporating DSTU support for TCAP */
#ifdef DSTU 
   DstuLiStuCmpCfm,      /* 6 - tightly coupled, TCAP user - DSTU */
#else
   PtUiStuCmpCfm,        /* 6 - tightly coupled, portable */
#endif

/* st013.301 - Incorporating lower LDF function support for TCAP */
#ifdef DSDT 
   DsdtUiStuCmpCfm,      /* 7 - tightly coupled, TCAP-LLDF */
#else
   PtUiStuCmpCfm,        /* 7 - tightly coupled, portable */
#endif
};


/* TCAP Notice Indication primitive */

PUBLIC StuNotInd stUiNotIndMt [MAXSTUI] =
{
#ifdef LCSTUISTU
   cmPkStuNotInd,        /* 0 - loosely coupled */ 
#else
   PtUiStuNotInd,        /* 0 - tightly coupled, portable */
#endif

#ifdef TU
   TuLiStuNotInd,        /* 1 - tightly coupled, TCAP user */
#else
   PtUiStuNotInd,        /* 1 - tightly coupled, portable */
#endif

#ifdef MA
   MaLiStuNotInd,        /* 2 - tightly coupled, TCAP user - MAP */
#else
   PtUiStuNotInd,        /* 2 - tightly coupled, portable */
#endif

#ifdef IA
   IaLiStuNotInd,        /* 3 - tightly coupled, TCAP user - IS-41 */
#else
   PtUiStuNotInd,        /* 3 - tightly coupled, portable */
#endif

#ifdef IE
   IeLiStuNotInd,        /* 4 - tightly coupled, TCAP user - INAP */
#else
   PtUiStuNotInd,        /* 4 - tightly coupled, portable */
#endif

/* st002.301 - Incorporating CAP support for TCAP */
#ifdef QC
   QcLiStuNotInd,        /* 5 - tightly coupled, TCAP user - CAP */
#else
   PtUiStuNotInd,        /* 5 - tightly coupled, portable */
#endif

/* st013.301 - Incorporating DSTU support for TCAP */
#ifdef DSTU 
   DstuLiStuNotInd,      /* 6 - tightly coupled, TCAP user - DSTU */
#else
   PtUiStuNotInd,        /* 6 - tightly coupled, portable */
#endif

/* st013.301 - Incorporating lower LDF function support for TCAP */
#ifdef DSDT 
   DsdtUiStuNotInd,      /* 7 - tightly coupled, TCAP-LLDF */
#else
   PtUiStuNotInd,        /* 7 - tightly coupled, portable */
#endif
};


/* TCAP State Indication primitive */

PUBLIC StuSteInd stUiSteIndMt [MAXSTUI] =
{
#ifdef LCSTUISTU
   cmPkStuSteInd,        /* 0 - loosely coupled */ 
#else
   PtUiStuSteInd,        /* 0 - tightly coupled, portable */
#endif

#ifdef TU
   TuLiStuSteInd,        /* 1 - tightly coupled, TCAP user */
#else
   PtUiStuSteInd,        /* 1 - tightly coupled, portable */
#endif

#ifdef MA
   MaLiStuSteInd,        /* 2 - tightly coupled, TCAP user - MAP */
#else
   PtUiStuSteInd,        /* 2 - tightly coupled, portable */
#endif

#ifdef IA
   IaLiStuSteInd,        /* 3 - tightly coupled, TCAP user - IS-41 */
#else
   PtUiStuSteInd,        /* 3 - tightly coupled, portable */
#endif

#ifdef IE
   IeLiStuSteInd,        /* 4 - tightly coupled, TCAP user - INAP */
#else
   PtUiStuSteInd,        /* 4 - tightly coupled, portable */
#endif

/* st002.301 - Incorporating CAP support for TCAP */
#ifdef QC
   QcLiStuSteInd,        /* 5 - tightly coupled, TCAP user - CAP */
#else
   PtUiStuSteInd,        /* 5 - tightly coupled, portable */
#endif

/* st013.301 - Incorporating DSTU support for TCAP */
#ifdef DSTU 
   DstuLiStuSteInd,      /* 6 - tightly coupled, TCAP user - DSTU */
#else
   PtUiStuSteInd,        /* 6 - tightly coupled, portable */
#endif

/* st013.301 - Incorporating lower LDF function support for TCAP */
#ifdef DSDT 
   DsdtUiStuSteInd,      /* 7 - tightly coupled, TCAP-LLDF */
#else
   PtUiStuSteInd,        /* 7 - tightly coupled, portable */
#endif
};


/* TCAP State Confirm primitive */

PUBLIC StuSteCfm stUiSteCfmMt [MAXSTUI] =
{
#ifdef LCSTUISTU
   cmPkStuSteCfm,        /* 0 - loosely coupled */ 
#else
   PtUiStuSteCfm,        /* 0 - tightly coupled, portable */
#endif

#ifdef TU
   TuLiStuSteCfm,        /* 1 - tightly coupled, TCAP user */
#else
   PtUiStuSteCfm,        /* 1 - tightly coupled, portable */
#endif

#ifdef MA
   MaLiStuSteCfm,        /* 2 - tightly coupled, TCAP user - MAP */
#else
   PtUiStuSteCfm,        /* 2 - tightly coupled, portable */
#endif

#ifdef IA
   IaLiStuSteCfm,        /* 3 - tightly coupled, TCAP user - IS-41 */
#else
   PtUiStuSteCfm,        /* 3 - tightly coupled, portable */
#endif

#ifdef IE
   IeLiStuSteCfm,        /* 4 - tightly coupled, TCAP user - INAP */
#else
   PtUiStuSteCfm,        /* 4 - tightly coupled, portable */
#endif

/* st002.301 - Incorporating CAP support for TCAP */
#ifdef QC
   QcLiStuSteCfm,        /* 5 - tightly coupled, TCAP user - CAP */
#else
   PtUiStuSteCfm,        /* 5 - tightly coupled, portable */
#endif

/* st013.301 - Incorporating DSTU support for TCAP */
#ifdef DSTU 
   DstuLiStuSteCfm,      /* 6 - tightly coupled, TCAP user - DSTU */
#else
   PtUiStuSteCfm,        /* 6 - tightly coupled, portable */
#endif

/* st013.301 - Incorporating lower LDF function support for TCAP */
#ifdef DSDT 
   DsdtUiStuSteCfm,      /* 7 - tightly coupled, TCAP-LLDF */
#else
   PtUiStuSteCfm,        /* 7 - tightly coupled, portable */
#endif
};

PUBLIC StuStaInd stUiStaIndMt [MAXSTUI] =
{
#ifdef LCSTUISTU
   cmPkStuStaInd,        /* 0 - loosely coupled */
#else
   PtUiStuStaInd,        /* 0 - tightly coupled, portable */
#endif

#ifdef TU
   TuLiStuStaInd,        /* 1 - tightly coupled, TCAP user */
#else
   PtUiStuStaInd,        /* 1 - tightly coupled, portable */
#endif

#ifdef MA
   MaLiStuStaInd,        /* 2 - tightly coupled, TCAP user - MAP */
#else
   PtUiStuStaInd,        /* 2 - tightly coupled, portable */
#endif

#ifdef IA
   IaLiStuStaInd,        /* 3 - tightly coupled, TCAP user - IS-41 */
#else
   PtUiStuStaInd,        /* 3 - tightly coupled, portable */
#endif

#ifdef IE
   IeLiStuStaInd,        /* 4 - tightly coupled, TCAP user - INAP */
#else
   PtUiStuStaInd,        /* 4 - tightly coupled, portable */
#endif

/* st002.301 - Incorporating CAP support for TCAP */
#ifdef QC
   QcLiStuStaInd,        /* 5 - tightly coupled, TCAP user - CAP */
#else
   PtUiStuStaInd,        /* 5 - tightly coupled, portable */
#endif

/* st013.301 - Incorporating DSTU support for TCAP */
#ifdef DSTU 
   DstuLiStuStaInd,      /* 6 - tightly coupled, TCAP user - DSTU */
#else
   PtUiStuStaInd,        /* 6 - tightly coupled, portable */
#endif

/* st013.301 - Incorporating lower LDF function support for TCAP */
#ifdef DSDT 
   DsdtUiStuStaInd,      /* 7 - tightly coupled, TCAP-LLDF */
#else
   PtUiStuStaInd,        /* 7 - tightly coupled, portable */
#endif
};

#ifdef STU2
PUBLIC StuBndCfm stUiBndCfmMt [MAXSTUI] =
{
#ifdef LCSTUISTU
   cmPkStuBndCfm,        /* 0 - loosely coupled */
#else
   PtUiStuBndCfm,        /* 0 - tightly coupled, portable */
#endif

#ifdef TU
   TuLiStuBndCfm,        /* 1 - tightly coupled, TCAP user */
#else
   PtUiStuBndCfm,        /* 1 - tightly coupled, portable */
#endif

#ifdef MA
   MaLiStuBndCfm,        /* 2 - tightly coupled, TCAP user - MAP */
#else
   PtUiStuBndCfm,        /* 2 - tightly coupled, portable */
#endif

#ifdef IA
   IaLiStuBndCfm,        /* 3 - tightly coupled, TCAP user - IS-41 */
#else
   PtUiStuBndCfm,        /* 3 - tightly coupled, portable */
#endif

#ifdef IE
   IeLiStuBndCfm,        /* 4 - tightly coupled, TCAP user - INAP */
#else
   PtUiStuBndCfm,        /* 4 - tightly coupled, portable */
#endif

/* st002.301 - Incorporating CAP support for TCAP */
#ifdef QC
   QcLiStuBndCfm,        /* 5 - tightly coupled, TCAP user - CAP */
#else
   PtUiStuBndCfm,        /* 5 - tightly coupled, portable */
#endif

/* st013.301 - Incorporating DSTU support for TCAP */
#ifdef DSTU 
   DstuLiStuBndCfm,      /* 6 - tightly coupled, TCAP user - DSTU */
#else
   PtUiStuBndCfm,        /* 6 - tightly coupled, portable */
#endif

/* st013.301 - Incorporating lower LDF function support for TCAP */
#ifdef DSDT 
   DsdtUiStuBndCfm,      /* 7 - tightly coupled, TCAP-LLDF */
#else
   PtUiStuBndCfm,        /* 7 - tightly coupled, portable */
#endif
};
#endif /* STU2 */


/*
 *     support functions
 */

/*
*     upper interface functions
*/


/* 
* 
*       Fun:   upper interface - TCAP Unit Data Indication
*  
*       Desc:  call Unit Data Indication through matrix selector
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  st_ptui.c
* 
*/
#ifdef ANSI
PUBLIC S16 StUiStuUDatInd
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
/* st029.301 - Add - suDlgId and spDlgId are added for STUV3 */
#ifdef STUV3
StDlgId	 suDlgId,
StDlgId	 spDlgId,
#endif
SpAddr   *destAddr,         /* TCAP dest address */
SpAddr   *srcAddr,          /* TCAP src address */
StQosSet *stQosSet,         /* TCAP Quality of Service */
Dpc       opc,              /* originating point code */
StDlgEv  *stDlgEv,          /* TCAP Dialog portion event */
/* st014.301 - Add - new parameter for imp, isni fields */
#ifdef STUV2
StDataParam *dataParam,     /* new structure having imp and isni */
#endif /* STUV2 */
Buffer   *uiBuf             /* TCAP Dialog portion user info buffer */
)
#else
/* st014.301 - Modify - routine prototype modified to include new parameter */
#ifdef STUV2
/* st029.301 - Add - suDlgId and spDlgId are added for STUV3 */
#ifdef STUV3
PUBLIC S16 StUiStuUDatInd(pst, suId, suDlgId, spDlgId, destAddr, srcAddr, stQosSet, opc,
                         stDlgEv, dataParam, uiBuf)
#else /* not STUV3 */
PUBLIC S16 StUiStuUDatInd(pst, suId, destAddr, srcAddr, stQosSet, opc,
                         stDlgEv, dataParam, uiBuf)
#endif
#else /* not STUV2 */
PUBLIC S16 StUiStuUDatInd(pst, suId, destAddr, srcAddr, stQosSet, opc,
                         stDlgEv, uiBuf)
#endif /* STUV2 */
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
/* st029.301 - Add - suDlgId and spDlgId are added for STUV3 */
#ifdef STUV3
StDlgId   suDlgId;
StDlgId   spDlgId;
#endif
SpAddr   *destAddr;         /* TCAP dest address */
SpAddr   *srcAddr;          /* TCAP src address */
StQosSet *stQosSet;         /* TCAP Quality of Service */
Dpc       opc;              /* originating point code */
StDlgEv  *stDlgEv;          /* TCAP Dialog portion event */
/* st014.301 - Add - new parameter for imp, isni fields */
#ifdef STUV2
StDataParam *dataParam;     /* new structure having imp and isni */
#endif /* STUV2 */
Buffer   *uiBuf;            /* TCAP Dialog portion user info buffer */
#endif
{
   TRC2(StUiStuUDatInd)

   /* st014.301 -Modify- call callback routine based on interface version */
#ifdef STUV2
/* st029.301 - Add - suDlgId and spDlgId are added for STUV3 */
#ifdef STUV3
   RETVALUE((*stUiUDatIndMt[pst->selector])(pst, suId, suDlgId, spDlgId, destAddr, 
				   srcAddr, stQosSet, opc, stDlgEv, dataParam,  uiBuf));
#else /* STUV3 */
   RETVALUE((*stUiUDatIndMt[pst->selector])(pst, suId, destAddr, 
				   srcAddr, stQosSet, opc, stDlgEv, dataParam, uiBuf));
#endif
#else /* STUV2 */
   RETVALUE((*stUiUDatIndMt[pst->selector])(pst, suId, destAddr, srcAddr,
				   stQosSet, opc, stDlgEv,uiBuf));
#endif /* STUV2 */

} /* end of StUiStuUDatInd */


/* 
* 
*       Fun:   upper interface - TCAP Data Indication
*  
*       Desc:  call Data Indication through matrix selector
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  st_ptui.c
* 
*/
#ifdef ANSI
PUBLIC S16 StUiStuDatInd
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
U8        msgType,          /* message type */
StDlgId   suDlgId,          /* user dialog id */
StDlgId   spDlgId,          /* provider dialog id */
SpAddr   *destAddr,         /* TCAP dest address */
SpAddr   *srcAddr,          /* TCAP src address */
Bool      compsPres,        /* terminating dialog */
StOctet  *prvAbrtCause,     /* Abort information if abort component */
StQosSet *stQosSet,         /* TCAP Quality of Service */
Dpc       opc,              /* originating point code */
StDlgEv  *stDlgEv,          /* TCAP Dialog portion event */
/* st014.301 - Add - new parameter for imp, isni fields */
#ifdef STUV2
StDataParam *dataParam,     /* new structure having imp and isni */
#endif /* STUV2 */
Buffer   *uiBuf             /* TCAP Dialog portion user info buffer */
)
#else
/* st014.301 - Modify - routine prototype modified to include new parameter */
#ifdef STUV2
PUBLIC S16 StUiStuDatInd(pst, suId, msgType, suDlgId, spDlgId,
                           destAddr, srcAddr, compsPres, prvAbrtCause,
                           stQosSet, opc, stDlgEv,dataParam,uiBuf)
#else  /* not STUV2 */
PUBLIC S16 StUiStuDatInd(pst, suId, msgType, suDlgId, spDlgId,
                         destAddr, srcAddr, compsPres, prvAbrtCause,
                         stQosSet, opc, stDlgEv,uiBuf)
#endif /* STUV2 */
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
U8        msgType;          /* message type */
StDlgId   suDlgId;          /* user dialog id */
StDlgId   spDlgId;          /* provider dialog id */
SpAddr   *destAddr;         /* TCAP dest address */
SpAddr   *srcAddr;          /* TCAP src address */
Bool      compsPres;        /* terminating dialog */
StOctet  *prvAbrtCause;     /* Abort information if abort component */
StQosSet *stQosSet;         /* TCAP Quality of Service */
Dpc       opc;              /* originating point code */
StDlgEv  *stDlgEv;          /* TCAP Dialog portion event */
/* st014.301 - Add - new parameter for imp, isni fields */
#ifdef STUV2
StDataParam *dataParam;     /* new structure having imp and isni */
#endif /* STUV2 */
Buffer   *uiBuf;            /* TCAP Dialog portion user info buffer */
#endif
{
   TRC2(StUiStuDatInd)

   /* st014.301 -Modify- call callback routine based on interface version */
#ifdef STUV2
   RETVALUE((*stUiDatIndMt[pst->selector])(pst, suId, msgType, suDlgId, 
                                           spDlgId, destAddr, srcAddr, 
                                           compsPres, prvAbrtCause, stQosSet,
                                           opc, stDlgEv,dataParam,uiBuf));
#else           
   RETVALUE((*stUiDatIndMt[pst->selector])(pst, suId, msgType, suDlgId, 
                                           spDlgId, destAddr, srcAddr, 
                                           compsPres, prvAbrtCause, stQosSet,
                                           opc, stDlgEv,uiBuf));
#endif /* STUV2 */

} /* end of StUiStuDatInd */


/*  
*  
*       Fun:   upper interface - TCAP Component Indication
*   
*       Desc:  call Component Indication through matrix selector
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  st_ptui.c
*  
*/ 
#ifdef ANSI
PUBLIC S16 StUiStuCmpInd
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
StDlgId   suDlgId,          /* dialog Id */
StDlgId   spDlgId,          /* dialog Id */
StComps  *compEv,           /* component */
Dpc       opc,              /* originating point code */
Status    status,           /* status */
Buffer   *cpBuf             /* Component parameter buffer */
)
#else
PUBLIC S16 StUiStuCmpInd(pst, suId, suDlgId, spDlgId, compEv, opc,
                         status,cpBuf)
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
StDlgId   suDlgId;          /* dialog Id */
StDlgId   spDlgId;          /* dialog Id */
StComps  *compEv;           /* component */
Dpc       opc;              /* originating point code */
Status    status;           /* status */
Buffer   *cpBuf;            /* Component parameter buffer */
#endif
{
   TRC2(StUiStuCmpInd)

   RETVALUE((*stUiCmpIndMt[pst->selector])(pst, suId, suDlgId, 
                                           spDlgId, compEv, opc, status,
                                           cpBuf));
} /* end of StUiStuCmpInd */


/*  
*  
*       Fun:   upper interface - TCAP Component Confirm
*   
*       Desc:  call Component Confirm through matrix selector
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  st_ptui.c
*  
*/ 
#ifdef ANSI
PUBLIC S16 StUiStuCmpCfm
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
StDlgId   suDlgId,          /* dialog Id */
StDlgId   spDlgId           /* dialog Id */
)
#else
PUBLIC S16 StUiStuCmpCfm(pst, suId, suDlgId, spDlgId)
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
StDlgId   suDlgId;          /* dialog Id */
StDlgId   spDlgId;          /* dialog Id */
#endif
{
   TRC2(StUiStuCmpCfm)

   RETVALUE((*stUiCmpCfmMt[pst->selector])(pst, suId, suDlgId, 
                                           spDlgId));
} /* end of StUiStuCmpCfm */
 

/*  
*  
*       Fun:   upper interface - TCAP Service Indication
*   
*       Desc:  call Service Indication through matrix selector
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  st_ptui.c
*  
*/ 
#ifdef ANSI
PUBLIC S16 StUiStuNotInd
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
StDlgId   suDlgId,          /* dialog id */
StDlgId   spDlgId,          /* dialog id */
SpAddr   *destAddr,         /* TCAP dest address */
SpAddr   *srcAddr,          /* TCAP src address */
/* st014.301 - Add - new parameter for imp, isni fields */
#ifdef STUV2
StDataParam *dataParam,     /* new structure having imp and isni */
#endif /* STUV2 */
RCause    ret               /* return cause */
)
#else
/* st014.301 - Modify - routine prototype modified to include new parameter */
#ifdef STUV2
PUBLIC S16 StUiStuNotInd(pst, suId, suDlgId, spDlgId, destAddr, srcAddr,
                         dataParam, ret)
#else  /*  STUV2 */
PUBLIC S16 StUiStuNotInd(pst, suId, suDlgId, spDlgId, destAddr, srcAddr,
                         ret)
#endif /* STUV2 */
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
StDlgId   suDlgId;          /* dialog id */
StDlgId   spDlgId;          /* dialog id */
SpAddr   *destAddr;         /* TCAP dest address */
SpAddr   *srcAddr;          /* TCAP src address */
/* st014.301 - Add - new parameter for imp, isni fields */
#ifdef STUV2
StDataParam *dataParam;     /* new structure having imp and isni */
#endif /* STUV2 */
RCause    ret;              /* return cause */
#endif
{
   TRC2(StUiStuNotInd)

   /* st014.301 -Modify- call callback routine based on interface version */
#ifdef STUV2
   RETVALUE((*stUiNotIndMt[pst->selector])(pst, suId, suDlgId, 
                                           spDlgId, destAddr, srcAddr, 
                                           dataParam, ret));
#else  /* not STUV2 */
   RETVALUE((*stUiNotIndMt[pst->selector])(pst, suId, suDlgId, 
                                           spDlgId, destAddr, srcAddr, ret));
#endif /* STUV2 */
} /* end of StUiStuNotInd */


/*  
*  
*       Fun:   upper interface - TCAP SSN and PC state Indication
*   
*       Desc:  call Ste Indication through matrix selector
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  st_ptui.c
*  
*/ 
#ifdef ANSI
PUBLIC S16 StUiStuSteInd
(
Pst          *pst,              /* post structure */
SuId          suId,             /* service user id */
CmSS7SteMgmt *steMgmt           /* Status management structure */
/* st014.301 - Add - Sccp State, Restricted importance level fields  */
#ifdef STUV2
,StMgmntParam *mgmntParam        /* other parameters like sccp state and ril */
#endif /* STUV2 */
)
#else
/* st014.301 -Modify -Routine prototype modified to include sccpState, ril */
#ifdef STUV2
PUBLIC S16 StUiStuSteInd(pst, suId, steMgmt, mgmntParam)
#else
PUBLIC S16 StUiStuSteInd(pst, suId, steMgmt)
#endif /* STUV2 */
Pst          *pst;              /* post structure */
SuId          suId;             /* service user id */
CmSS7SteMgmt *steMgmt;          /* Status management structure */
/* st014.301 - Add - Sccp State, Restricted importance level fields  */
#ifdef STUV2
StMgmntParam *mgmntParam;       /* other parameters like sccp state and ril */
#endif /* STUV2 */
#endif
{
   TRC2(StUiStuSteInd)

   /* st014.301 -Modify- call callback routine based on interface version */
#ifdef STUV2
   RETVALUE((*stUiSteIndMt[pst->selector])(pst, suId, steMgmt,mgmntParam));
#else
   RETVALUE((*stUiSteIndMt[pst->selector])(pst, suId, steMgmt));
#endif /* STUV2 */
   
} /* end of StUiStuSteInd */


/*  
*  
*       Fun:   upper interface - TCAP SSN and PC state Confirm 
*   
*       Desc:  call Ste Confirm through matrix selector
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  st_ptui.c
*  
*/ 
#ifdef ANSI
PUBLIC S16 StUiStuSteCfm
(
Pst          *pst,              /* post structure */
SuId          suId,             /* service user id */
CmSS7SteMgmt *steMgmt           /* Status management structure */
/* st014.301 - Add - Sccp State, Restricted importance level fields  */
#ifdef STUV2
,StMgmntParam *mgmntParam        /* other parameters like sccp state and ril */
#endif /* STUV2 */
)
#else
/* st014.301 -Modify -Routine prototype modified to include sccpState, ril */
#ifdef STUV2
PUBLIC S16 StUiStuSteCfm(pst, suId, steMgmt, mgmntParam)
#else /* not STUV2 */
PUBLIC S16 StUiStuSteCfm(pst, suId, steMgmt)
#endif /* STUV2 */
Pst          *pst;              /* post structure */
SuId          suId;             /* service user id */
CmSS7SteMgmt *steMgmt;          /* Status management structure */
/* st014.301 - Add - Sccp State, Restricted importance level fields  */
#ifdef STUV2
StMgmntParam *mgmntParam;       /* other parameters like sccp state and ril */
#endif /* STUV2 */
#endif
{
   TRC2(StUiStuSteCfm)

   /* st014.301 -Modify- call callback routine based on interface version */
#ifdef STUV2
   RETVALUE((*stUiSteCfmMt[pst->selector])(pst, suId, steMgmt, mgmntParam));
#else
   RETVALUE((*stUiSteCfmMt[pst->selector])(pst, suId, steMgmt));
#endif /* STUV2 */

} /* end of StUiStuSteCfm */
 

/*  
*  
*       Fun:   upper interface - TCAP Status Indication
*   
*       Desc:  call Status Indication through matrix selector
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  st_ptui.c
*  
*/ 
#ifdef ANSI
PUBLIC S16 StUiStuStaInd
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
Status    status            /* status */
)
#else
PUBLIC S16 StUiStuStaInd(pst, suId, status)
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
Status    status;           /* status */
#endif
{
   TRC2(StUiStuStaInd)

   RETVALUE((*stUiStaIndMt[pst->selector])(pst, suId, status));

} /* end of StUiStuStaInd */


#ifdef STU2
/*  
*  
*       Fun:   upper interface - TCAP Bind Confirm
*   
*       Desc:  call Bind Confirm through matrix selector
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  st_ptui.c
*  
*/ 
#ifdef ANSI
PUBLIC S16 StUiStuBndCfm
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
U8        status            /* status */
)
#else
PUBLIC S16 StUiStuBndCfm(pst, suId, status)
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
U8        status;           /* status */
#endif
{
   TRC2(StUiStuBndCfm)

   RETVALUE((*stUiBndCfmMt[pst->selector])(pst, suId, status));

} /* end of StUiStuBndCfm */
#endif /* STU2 */


/*
*     portable functions
*/
 

/* 
* 
*       Fun:   portable - TCAP Unit Data Indication
*  
*       Desc:  user defined unit data indication
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  st_ptui.c
* 
*/
#ifdef ANSI
PRIVATE S16 PtUiStuUDatInd
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
/* st029.301 - Add - suDlgId and spDlgId are added for STUV3 */
#ifdef STUV3		    
StDlgId  suDlgId,
StDlgId  spDlgId,
#endif
SpAddr   *destAddr,         /* TCAP dest address */
SpAddr   *srcAddr,          /* TCAP src address */
StQosSet *stQosSet,         /* TCAP Quality of Service */
Dpc       opc,              /* originating point code */
StDlgEv  *stDlgEv,          /* TCAP Dialog portion event */
/* st014.301 - Add - isni field */
#ifdef STUV2
StDataParam *dataParam,     /* new structure having imp and isni */
#endif /* STUV2 */
Buffer   *uiBuf             /* TCAP Dialog portion user info buffer */
)
#else
/* st014.301 -Modify- routine prototype modified to include isni field */ 
#ifdef STUV2
/* st029.301 - Add - suDlgId and spDlgId are added for STUV3 */
#ifdef STUV3
PUBLIC S16 PtUiStuUDatInd(pst, suId, suDlgId, spDlgId, destAddr, srcAddr, stQosSet, opc, stDlgEv, dataParam,  uiBuf)
#else /* STUV3 */
PUBLIC S16 PtUiStuUDatInd(pst, suId, destAddr, srcAddr, stQosSet, opc,
                            stDlgEv, dataParam, uiBuf)
#endif
#else /* STUV2 */
PUBLIC S16 PtUiStuUDatInd(pst, suId, destAddr, srcAddr, stQosSet, opc,
                          stDlgEv, uiBuf)
#endif /* STUV2 */
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
/* st029.301 - Add - suDlgId and spDlgId are added for STUV3 */
#ifdef STUV3
StDlgId   suDlgId;
SuDlgId   stDlgId;
#endif
SpAddr   *destAddr;         /* TCAP dest address */
SpAddr   *srcAddr;          /* TCAP src address */
StQosSet *stQosSet;         /* TCAP Quality of Service */
Dpc       opc;              /* originating point code */
StDlgEv  *stDlgEv;          /* TCAP Dialog portion event */
/* st014.301 - Add - isni field */
#ifdef STUV2
StDataParam *dataParam;     /* new structure having imp and isni */
#endif /* STUV2 */
Buffer   *uiBuf;            /* TCAP Dialog portion user info buffer */
#endif
{
   TRC2(PtUiStuUDatInd)

   UNUSED(pst);
   UNUSED(suId);               
/* st029.301 - Add - suDlgId and spDlgId are added for STUV3 */
#ifdef STUV3
   UNUSED(suDlgId);
   UNUSED(spDlgId);
#endif
   UNUSED(destAddr);          
   UNUSED(srcAddr);         
   UNUSED(stQosSet);      
   UNUSED(opc);          
   UNUSED(stDlgEv);     
   /* st014.301 -Add- dataParam field added in the unused param list */
#ifdef STUV2
   UNUSED(dataParam);
#endif /* STUV2 */   
   UNUSED(uiBuf);      

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST320, (ErrVal)0, "PtUiStuUDatInd () Failed");
#endif

   RETVALUE(ROK);
} /* end of PtUiStuUDatInd */


/* 
* 
*       Fun:   portable - TCAP Data Indication
*  
*       Desc:  user defined data indication
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  st_ptui.c
* 
*/
#ifdef ANSI
PRIVATE S16 PtUiStuDatInd
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
U8        msgType,          /* message type */
StDlgId   suDlgId,          /* user dialog id */
StDlgId   spDlgId,          /* provider dialog id */
SpAddr   *destAddr,         /* TCAP dest address */
SpAddr   *srcAddr,          /* TCAP src address */
Bool      compsPres,        /* terminating dialog */
StOctet  *prvAbrtCause,     /* Abort information if abort component */
StQosSet *stQosSet,         /* TCAP Quality of Service */
Dpc       opc,              /* originating point code */
StDlgEv  *stDlgEv,          /* TCAP Dialog portion event */
/* st014.301 - Add - new parameter for imp, isni fields */
#ifdef STUV2
StDataParam *dataParam,     /* new structure having imp and isni */
#endif /* STUV2 */
Buffer   *uiBuf             /* TCAP Dialog portion user info buffer */
)
#else
/* st014.301 - Modify - routine prototype modified to include new parameter */
#ifdef STUV2
PUBLIC S16 PtUiStuDatInd(pst, suId, msgType, spDlgId, suDlgId,
                         destAddr, srcAddr, compsPres, prvAbrtCause,
                         stQosSet, opc, stDlgEv,dataParam, uiBuf)
#else
PUBLIC S16 PtUiStuDatInd(pst, suId, msgType, suDlgId, spDlgId,
                         destAddr, srcAddr, compsPres, prvAbrtCause,
                         stQosSet, opc, stDlgEv,uiBuf)
#endif /* STUV2 */
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
U8        msgType;          /* message type */
StDlgId   suDlgId;          /* user dialog id */
StDlgId   spDlgId;          /* provider dialog id */
SpAddr   *destAddr;         /* TCAP dest address */
SpAddr   *srcAddr;          /* TCAP src address */
Bool      compsPres;        /* terminating dialog */
StOctet  *prvAbrtCause;     /* Abort information if abort component */
StQosSet *stQosSet;         /* TCAP Quality of Service */
Dpc       opc;              /* originating point code */
StDlgEv  *stDlgEv;          /* TCAP Dialog portion event */
/* st014.301 - Add - new parameter for imp, isni fields */
#ifdef STUV2
StDataParam *dataParam;     /* new structure having imp and isni */
#endif /* STUV2 */
Buffer   *uiBuf;            /* TCAP Dialog portion user info buffer */
#endif
{
   TRC2(PtUiStuDatInd)

   UNUSED(pst);
   UNUSED(suId);               
   UNUSED(msgType);               
   UNUSED(suDlgId);               
   UNUSED(spDlgId);          
   UNUSED(destAddr);         
   UNUSED(srcAddr);         
   UNUSED(compsPres);         
   UNUSED(prvAbrtCause);         
   UNUSED(stQosSet);      
   UNUSED(opc);          
   UNUSED(stDlgEv);     
   /* st014.301 -Add- dataParam field added in the unused param list */
#ifdef STUV2
   UNUSED(dataParam);
#endif /* STUV2 */
   UNUSED(uiBuf);      

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST321, (ErrVal)0, "PtUiStuDatInd () Failed");
#endif

   RETVALUE(ROK);
} /* end of PtUiStuDatInd */
 

/*  
*  
*       Fun:   portable - TCAP Component Indication
*   
*       Desc:  user defined Component indication
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  st_ptui.c
*  
*/ 
#ifdef ANSI
PRIVATE S16 PtUiStuCmpInd
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
StDlgId   suDlgId,          /* dialog Id */
StDlgId   spDlgId,          /* dialog Id */
StComps  *compEv,           /* component */
Dpc       opc,              /* originating point code */
Status    status,           /* status */
Buffer   *cpBuf             /* Component parameter buffer */
)
#else
PUBLIC S16 PtUiStuCmpInd(pst, suId, suDlgId, spDlgId, compEv, opc,
                         status,cpBuf)
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
StDlgId   suDlgId;          /* dialog Id */
StDlgId   spDlgId;          /* dialog Id */
StComps  *compEv;           /* component */
Dpc       opc;              /* originating point code */
Status    status;           /* status */
Buffer   *cpBuf;            /* Component parameter buffer */
#endif
{
   TRC2(PtUiStuCmpInd)

   UNUSED(pst);
   UNUSED(suId);               
   UNUSED(suDlgId);               
   UNUSED(spDlgId);          
   UNUSED(compEv);         
   UNUSED(opc);          
   UNUSED(status);     
   UNUSED(cpBuf);      

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST322, (ErrVal)0, "PtUiStuCmpInd () Failed");
#endif

   RETVALUE(ROK);
} /* end of PtUiStuCmpInd */


/*  
*  
*       Fun:   portable - TCAP Component confirm
*   
*       Desc:  user defined Component confirm
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  st_ptui.c
*  
*/ 
#ifdef ANSI
PRIVATE S16 PtUiStuCmpCfm
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
StDlgId   suDlgId,          /* dialog Id */
StDlgId   spDlgId           /* dialog Id */
)
#else
PUBLIC S16 PtUiStuCmpCfm(pst, suId, suDlgId, spDlgId)
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
StDlgId   suDlgId;          /* dialog Id */
StDlgId   spDlgId;          /* dialog Id */
#endif
{
   TRC2(PtUiStuCmpCfm)

   UNUSED(pst);
   UNUSED(suId);               
   UNUSED(suDlgId);               
   UNUSED(spDlgId);          

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST323, (ErrVal)0, "PtUiStuCmpCfm () Failed");
#endif

   RETVALUE(ROK);
} /* end of PtUiStuCmpCfm */


/* 
* 
*       Fun:   portable - TCAP Noticee Indication
*  
*       Desc:  TC-Notice indication
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  st_ptui.c
* 
*/
#ifdef ANSI
PRIVATE S16 PtUiStuNotInd
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
StDlgId   suDlgId,          /* dialog id */
StDlgId   spDlgId,          /* dialog id */
SpAddr   *destAddr,         /* TCAP dest address */
SpAddr   *srcAddr,          /* TCAP src address */
/* st014.301 - Add - new parameter for imp, isni fields */
#ifdef STUV2
StDataParam *dataParam,     /* new structure having imp and isni */
#endif /* STUV2 */
RCause    ret               /* return cause */
)
#else
/* st014.301 - Modify - routine prototype modified to include new parameter */
#ifdef STUV2
PUBLIC S16 PtUiStuNotInd(pst, suId, suDlgId, spDlgId, destAddr, srcAddr,
                         dataParam, ret)
#else /* not STUV2 */
PUBLIC S16 PtUiStuNotInd(pst, suId, suDlgId, spDlgId, destAddr, srcAddr,
                         ret)
#endif /* STUV2 */
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
StDlgId   suDlgId;          /* dialog id */
StDlgId   spDlgId;          /* dialog id */
SpAddr   *destAddr;         /* TCAP dest address */
SpAddr   *srcAddr;          /* TCAP src address */
/* st014.301 - Add - new parameter for imp, isni fields */
#ifdef STUV2
StDataParam *dataParam;     /* new structure having imp and isni */
#endif /* STUV2 */
RCause    ret;              /* return cause */
#endif
{
   TRC2(PtUiStuNotInd)

   UNUSED(pst);
   UNUSED(suId);               
   UNUSED(suDlgId);               
   UNUSED(spDlgId);          
   UNUSED(destAddr);         
   UNUSED(srcAddr);         
   /* st014.301 -Add- dataParam field added in the unused param list */
#ifdef STUV2
   UNUSED(dataParam);
#endif /* STUV2 */
   UNUSED(ret);      

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST324, (ErrVal)0, "PtUiStuNotInd () Failed");
#endif

   RETVALUE(ROK);
} /* end of PtUiStuNotInd */


/* 
* 
*       Fun:   portable - TCAP State Indication
*  
*       Desc:  user defined state indication
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  st_ptui.c
* 
*/
#ifdef ANSI
PRIVATE S16 PtUiStuSteInd
(
Pst          *pst,              /* post structure */
SuId          suId,             /* service user id */
CmSS7SteMgmt *steMgmt           /* Status management structure */
/* st014.301 - Add - Sccp State, Restricted importance level fields  */
#ifdef STUV2
,StMgmntParam   *mgmntParam
#endif /* STUV2 */
)
#else
/* st014.301 -Modify -Routine prototype modified to include sccpState, ril */
#ifdef STUV2
PUBLIC S16 PtUiStuSteInd(pst, suId, steMgmt, mgmntParam)
#else /* not STUV2 */
PUBLIC S16 PtUiStuSteInd(pst, suId, steMgmt)
#endif /* STUV2 */
Pst          *pst;              /* post structure */
SuId          suId;             /* service user id */
CmSS7SteMgmt *steMgmt;          /* Status management structure */
/* st014.301 - Add - Sccp State, Restricted importance level fields  */
#ifdef STUV2
StMgmntParam *mgmntParam;
#endif /* STUV2 */
#endif
{
   TRC2(PtUiStuSteInd)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(steMgmt);
   /* st014.301 -Add- mgmntParam added to unused param. list */
#ifdef STUV2
   UNUSED(mgmntParam);
#endif /* STUV2 */   

#if (ERRCLASS & ERRCLS_DEBUG)
   STLOGERROR(ERRCLS_DEBUG, EST325, (ErrVal)0, "PtUiStuSteInd () Failed");
#endif

   RETVALUE(ROK);
} /* end of PtUiStuSteInd */


/* 
* 
*       Fun:   portable - TCAP State Confirm 
*  
*       Desc:  user defined state confirm
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  st_ptui.c
* 
*/
#ifdef ANSI
PRIVATE S16 PtUiStuSteCfm
(
Pst          *pst,              /* post structure */
SuId          suId,             /* service user id */
CmSS7SteMgmt *steMgmt           /* Status management structure */
/* st014.301 - Add - Sccp State, Restricted importance level fields  */
#ifdef STUV2
,StMgmntParam   *mgmntParam
#endif /* STUV2 */
)
#else
/* st014.301 -Modify -Routine prototype modified to include sccpState, ril */
#ifdef STUV2
PUBLIC S16 PtUiStuSteCfm(pst, suId, steMgmt, mgmntParam)
#else /* not STUV2 */
PUBLIC S16 PtUiStuSteCfm(pst, suId, steMgmt)
#endif /* STUV2 */
Pst          *pst;              /* post structure */
SuId          suId;             /* service user id */
CmSS7SteMgmt *steMgmt;          /* Status management structure */
/* st014.301 - Add - Sccp State, Restricted importance level fields  */
#ifdef STUV2
StMgmntParam *mgmntParam;
#endif /* STUV2 */
#endif
{
   TRC2(PtUiStuSteCfm)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(steMgmt);
   /* st014.301 -Add- mgmntParam added to unused param. list */
#ifdef STUV2
   UNUSED(mgmntParam);
#endif /* STUV2 */

#if (ERRCLASS & ERRCLS_DEBUG)
   STLOGERROR(ERRCLS_DEBUG, EST326, (ErrVal)0, "PtUiStuSteCfm () Failed");
#endif

   RETVALUE(ROK);
} /* end of PtUiStuSteCfm */


/* 
* 
*       Fun:   portable - TCAP Status Indication
*  
*       Desc:  Status indication
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  st_ptui.c
* 
*/
#ifdef ANSI
PRIVATE S16 PtUiStuStaInd
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
Status    status            /* status */
)
#else
PUBLIC S16 PtUiStuStaInd(pst, suId, status)
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
Status    status;           /* status */
#endif
{
   TRC2(PtUiStuStaInd)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(status);

#if (ERRCLASS & ERRCLS_DEBUG)
   STLOGERROR(ERRCLS_DEBUG, EST327, (ErrVal)0, "PtUiStuStaInd () Failed");
#endif

   RETVALUE(ROK);
} /* end of PtUiStuStaInd */


#ifdef STU2
/* 
* 
*       Fun:   portable - TCAP Bind Confirm
*  
*       Desc:  Bind Confirm
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  st_ptui.c
* 
*/
#ifdef ANSI
PRIVATE S16 PtUiStuBndCfm
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
U8        status            /* status */
)
#else
PUBLIC S16 PtUiStuBndCfm(pst, suId, status)
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
U8        status;           /* status */
#endif
{
   TRC2(PtUiStuBndCfm)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(status);

#if (ERRCLASS & ERRCLS_DEBUG)
   STLOGERROR(ERRCLS_DEBUG, EST328, (ErrVal)0, "PtUiStuBndCfm () Failed");
#endif

   RETVALUE(ROK);
} /* end of PtUiStuBndCfm */
#endif /* STU2 */


/********************************************************************30**

         End of file:     st_ptui.c@@/main/14 - Fri Nov 17 10:34:20 2000

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/


/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:

*********************************************************************61*/


/********************************************************************80**
 
  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  mma   1. initial release
 
1.2          ---  mma   1. change SPkU8 to SPkU32
 
1.3          ---  mma   1. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92
 
1.4          ---  mma   1. removed ACG and Digits parameters
             ---  mma   2. eliminated ANSI parameters from component
 
1.5          ---  lc    1. added packing functions to support Service
                           Indication
             ---  ak    2. added functions to support PC State Indication.
             ---  ak    3. added stInvokeTimer to PkStComp routine.
             ---  ak    4. changed primitives to accept two dialog Ids.
             ---  ak    5. added StuStaCfm functionality to return SpDlgId
                           to TCAP user.
             ---  ak    6. extended matrices to support two LC interfaces
                           SEL_LC_NEW and SEL_LC_OLD.
             ---  ak    7. added msgPrior parameter to UDatInd and DatInd
             ---  ak    8. replaced ss_ms.[hx] and ss_pt.[hx] with ssi.[hx]
 
1.6          ---  ak    1. defined error numbers.
 
1.7          ---  ak    1. include cm5.[hx]
 
1.8          ---  ak    1. added StDlgEv struct to (U)Dat-Req/Ind primitives
             ---  ak    2. changed msgPrior to Qos parameter.
             ---  ak    3. StaXXX changes to CmpXXX
             ---  ak    4. added StaInd for *real* status indication.
             ---  ak    5. added opc parameter to CmpInd, (U)DatInd.
             ---  ak    6. renamed SrvInd -> NotInd.
             ---  ak    7. Added stAbrtInfo to DatInd primitive.
             ---  ak    8. packing primitives return SPstTsk ret-value
             ---  ak    9. remove SEL_LC_OLD support.
 
1.9          ---  aa    1. Changes due to TCAP upper interface changes
 
1.10         ---  aa    1. Changes due to removing of serror's
 
*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.11         ---      aa   1. Removed the backward compatibility from the matri
                      aa   2. Include cm_ss7.h
 
1.12         ---      nj   1. Rewrote the file.
1.13         ---      nj   1. Added packing function and matrix entries for
                              new primitive XxYyStuBndCfm at the upper interface.

                           2. Packing functions have been removed from this
                              file. They have been moved to file stu.c

                           3. Added one more interface for INAP in the primitive
                              switch tables.

/main/14     ---      nj   1. Changed copyright header
3.1+   st002.301   zr,as   1. Incorporating CAP support for TCAP layer
3.1+   st007.301   zr      1. spt.x included for TC-User Distribution Feature
3.1+   st013.301     akp   1. TCAP API Lower interface functions are added
                           to TCAP upper interface matrix under DSTU flag.

                           2. TCAP LLDF API Lower interface functions are added
                           to TCAP upper interface matrix under DSDT flag.
3.1+      st014.301   zr   1. Handle SPT and STU interface change -
                              - imp, isni, sccpState and ril fields are
                              added in primitives
3.1+      st029.301   yk   1. suDlgId and spDlgId are added for UDatInd
3.1+       st034.301   yk   1. Code Added for SS_MULTIPLE_PROCS
*********************************************************************91*/
