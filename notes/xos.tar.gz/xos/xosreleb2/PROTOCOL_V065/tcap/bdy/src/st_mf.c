/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/
/********************************************************************20**
  
     Name:     TCAP Message encoder/decoder
  
     Type:     C Source file
  
     Desc:     C source code for TCAP message encoding/decoding 
               routines
  
     File:     ct_mf.c
  
     Sid:      ct_mf.c@@/main/4 - Fri Nov 17 10:34:46 2000
  
     Prg:      nj
  
*********************************************************************21*/


/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif
#ifdef CCITT96
               CCITT 96
#endif

************************************************************************/

/*
*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000031     SS7 - TCAP
*
*/
 

/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* Common timer */
#include "cm_ss7.h"        /* SS7 specific */
#include "cm_hash.h"       /* Common hashing */
#include "cm_asn.h"        /* Common asn.1 */
#include "cm_err.h"        /* Common error */
#include "stu.h"           /* Tcap Upper interface */
#include "spt.h"           /* Tcap lower interface */
#include "lst.h"           /* Layer management, TCAP */
#include "st.h"            /* Tcap */
#include "st_mf.h"         /* Tcap encoding/decoding */
#include "st_db.h"         /* Tcap ASN.1 tag defines */
#include "st_err.h"        /* Tcap error */

#ifdef ST_FTHA
#include "sht.h"           /* SHT */
#include "mrs.h"           /* MRS */
#endif /* ST_FTHA */

#ifdef ZT
#include "cm_ftha.h"
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#ifdef ZT_DFTHA
#include "cmztdt.h"
#include "cmztdtlb.h"
#endif /* ZT_DFTHA */
#include "zt.h"            /* Tcap PSF defines */
#include "lzt.h"
#endif /* ZT */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer */
#include "ssi.x"           /* System services */
#include "cm5.x"           /* Common timer */
#include "cm_ss7.x"        /* Common */
#include "cm_hash.x"       /* Common hashing */
#include "cm_asn.x"        /* Common asn.1 */
#include "cm_lib.x"        /* Common */
#include "stu.x"           /* Tcap layer */
#include "spt.x"           /* Sccp layer */
#include "lst.x"           /* Layer management, TCAP */
#include "st_mf.x"         /* Tcap */

#ifdef ZT
#include "cm_ftha.x"
#include "cm_pftha.x"      /* Common PSF typedefs */
#include "cm_psfft.x"
#endif /* ZT */

#ifdef ST_FTHA
#include "sht.x"           /* SHT */
/* st005.301 - Deleted - mrs.x included under ZT */
#endif /* ST_FTHA */

#include "st.x"            /* Tcap */
 
#ifdef ZT
/* st005.301 - Added - mrs.x included here */
#include "mrs.x"           /* MRS */
#ifdef ZT_DFTHA
#include "cmztdt.x"
#include "cmztdtlb.x"
#endif /* ZT_DFTHA */
#include "lzt.x"
#include "zt.x"            /* Tcap PSF typedefs */
#endif /* ZT */

 

/* local defines */

/* local externs */

/* forward references */

PRIVATE S16  stEncLen      ARGS((MsgLen      len,
                                 Data       *pkArray,
                                 MsgLen     *nmb));

PRIVATE S16  stDecMsgElm   ARGS((TknU8      *elmEv,
                                 StTag       tag,
                                 MsgLen      maxLen,
                                 Bool        mandFlg,
                                 Buffer     *mBuf,
                                 CmAsnErr   *err));

PRIVATE S16  stGetLen      ARGS((Buffer     *mBuf,
                                 MsgLen      offset,
                                 MsgLen     *len,
                                 MsgLen     *lfLen,
                                 Bool       *eocFlag));

PRIVATE S16  stFindLen     ARGS((Buffer     *mBuf,
                                 MsgLen      offset,
                                 MsgLen     *len,
                                 MsgLen     *lfLen,
                                 Bool       *eocFlag));

PRIVATE S16 stChkDlgEv     ARGS((PTR         dlgEv,
                                 Swtch       pSwtch,
                                 U8         *abtCause));

PRIVATE U8   stMapErrCode  ARGS((CmAsnErr   *err,
                                 U8          prtnType,
                                 Swtch       pSwtch));

PRIVATE U8   stGetMsgType  ARGS((StTag       tag));

PRIVATE U16  stChkPAbtCauseVal  ARGS((U8     pAbtCause,
                                      Swtch  pSwtch));

PRIVATE U16  stChkProbCodeVal   ARGS((U8     probType,
                                      U8     probCode,
                                      Swtch  pSwtch));

PRIVATE S16  stU32ToStr    ARGS((U32         val,
                                 U8         *str,
                                 MsgLen     *len,
                                 U8          order));

/* st016.301 -Add- routine stSetProbCode */
PRIVATE Void stSetProbCode  ARGS((PTR       compEv,
                                  Bool      *probCode,
                                  Swtch     pSwtch));

PUBLIC  S16  stEdcBuffer   ARGS((CmAsnMsgCp *msgCp));


/* functions in other modules */
  
/* public variable declarations */
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifndef SS_MULTIPLE_PROCS
EXTERN  StCb         stCb;         /* Tcap Control Block */
#endif /* SS_MULTIPLE_PROCS */
EXTERN  CmElmntDef **stMsgDbDef[]; /* Tcap Database message definition array */

/* private variable declarations */


/*
 *     support functions
 */


/*
*
*       Fun:    stEncComp
*
*       Desc:   Encode a Component in ASN.1 format
*
*       Ret:    ROK        Success
*               RFAILED    Failure
*
*       Notes:  None
*
*       File:   ct_mf.c
*
*/
#ifdef ANSI
PUBLIC S16 stEncComp
(
PTR       compEv,       /* Component Event Structure */
Swtch     pSwtch,       /* Protocol Switch */
Buffer   *mBuf          /* Buffer to return the encoded component */
)
#else
PUBLIC S16 stEncComp(compEv, pSwtch, mBuf)
PTR       compEv;       /* Component Event Structure */
Swtch     pSwtch;       /* Protocol Switch */
Buffer   *mBuf;         /* Buffer to return the encoded component */
#endif
{
   CmAsnErr     err;     /* Error structure returned by ASN.1 Encoder */
   CmElmntDef **compDef; /* Database definition of components */
   U8           pType;   /* Protocol type */

   TRC2(stEncComp);

   /* Get the Database definition of the Component portion */
   compDef = (CmElmntDef **)stGetMsgDef(ST_DBTYPE_COMP, pSwtch);

   /* Map the protocol switch to protocol type understood by ASN.1 module */
   pType   = stGetProtType(pSwtch);

   /* st015.301 -Add- check for invalid prototype switch */
   if (pType == ST_DEF_PROTTYPE)
   {
       STDBGP(ST_DBGMASK_ENCODE, (stCb.init.prntBuf,
             "stEncComp:Error in protocol switch value\n"));   
       RETVALUE(RFAILED);
   }
   /* Encode the component */
   if (cmEncMsg((TknU8 *)compEv, mBuf, pType, compDef,
                stCb.init.region, stCb.init.pool, &err, NULLP) != ROK)
   {

      STDBGP(ST_DBGMASK_ENCODE, (stCb.init.prntBuf,
             "stEncComp:Error Code(%x), Element Tag(%x)\n",
              err.errCode, err.tag.val[0]));

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST288, (ErrVal)err.errCode,
                 "stEncComp:cmEncMsg Failed");
#endif

      RETVALUE(RFAILED);
   }

   STDBGP(ST_DBGMASK_ENCODE, (stCb.init.prntBuf,
          "stEncComp:Component encoded successfully\n"));

   RETVALUE(ROK);
} /* End of stEncComp */


/*
*
*       Fun:    stEncDlg
*
*       Desc:   Encode a the dialogue portion in ASN.1 format
*
*       Ret:    ROK        Success
*               RFAILED    Failure
*
*       Notes:  mBuf passed to this routine may contains the ASN.1 encoded
*               components.
*
*       File:   ct_mf.c
*
*/
#ifdef ANSI
PUBLIC S16 stEncDlg
(
PTR       dlgEv,        /* Dialogue Portion Event Structure */
Swtch     pSwtch,       /* Protocol Switch */
Buffer   *mBuf          /* Buffer to return the encoded message */
)
#else
PUBLIC S16 stEncDlg(dlgEv, pSwtch, mBuf)
PTR       dlgEv;        /* Dialogue Portion Event Structure */
Swtch     pSwtch;       /* Protocol Switch */
Buffer   *mBuf;         /* Buffer to return the encoded message */
#endif
{
   CmAsnErr     err;     /* Error structure returned by ASN.1 Encoder */
   CmElmntDef **dlgDef;  /* Database definition of components */
   Buffer      *dlgBuf;  /* Buffer to hold the encoded dialogue portion */
   MsgLen       compLen; /* Component portion length */
   U8           pType;   /* Protocol type */
   S16          ret;     /* return value */

   TRC2(stEncDlg)

   /* Check if dialogue portion is valid for the protocol type */
   switch(pSwtch)
   {
      case LST_SW_ITU92:
      case LST_SW_ITU96:



         /* If dialogue event not present, return here */
         if (((TknU8 *)dlgEv)->pres == FALSE)
         {
            RETVALUE(ROK);
         }
         break;

      default:
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_ENCODE, (stCb.init.prntBuf,
                "stEncDlg:Unknown protocol switch(%d)\n",pSwtch));
         RETVALUE(RFAILED);
   }

   /* check if mBuf already contains the components */
   compLen = 0;
   (Void)SFndLenMsg(mBuf, &compLen);

   /* If components are already present in mBuf then allocate a separate
      message buffer to encode dialogue portion otherwise use mBuf */

   if (compLen > 0)
   {
      if ((ret = SGetMsg(stCb.init.region, stCb.init.pool, &dlgBuf)) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         STLOGERROR(ERRCLS_DEBUG, EST289, (ErrVal)ret,
                    "stEncDlg:SGetMsg Failed");
#endif
         RETVALUE(RFAILED);
      }
   }
   else
   {
      dlgBuf = mBuf;
   }

   /* Get the database definition of dialogue portion */
   dlgDef = (CmElmntDef **)stGetMsgDef(ST_DBTYPE_DLG, pSwtch);

   /* Map the protocol switch to protocol type understood by ASN.1 module */
   pType  = stGetProtType(pSwtch);

   /* st015.301 -Add- check for invalid prototype switch */
   if (pType == ST_DEF_PROTTYPE)
   {
       STDBGP(ST_DBGMASK_ENCODE, (stCb.init.prntBuf,
             "stEncComp:Error in protocol switch value"));   
       RETVALUE(RFAILED);
   }

   /* Encode the dialogue portion */
   if (cmEncMsg((TknU8 *)dlgEv, dlgBuf, pType, dlgDef,
                stCb.init.region, stCb.init.pool, &err, NULLP) != ROK)
   {
      /* Deallocate the message buffer, if it was allocated in this routine */
      if (compLen > 0)
      {
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(dlgBuf);
      }

      STDBGP(ST_DBGMASK_ENCODE, (stCb.init.prntBuf,
             "stEncDlg:Error Code(%x), Element Tag(%x)\n",
              err.errCode, err.tag.val[0]));

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST290, (ErrVal)err.errCode,
                 "stEncDlg:cmEncMsg Failed");
#endif

      RETVALUE(RFAILED);
   }

   if (compLen > 0)
   {
      /* Component portion is present, dialogue was encoded in a separate
         buffer, so merge both the buffers */

      (Void)SCatMsg(mBuf, dlgBuf, M2M1);

      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(dlgBuf);
   }

   STDBGP(ST_DBGMASK_ENCODE, (stCb.init.prntBuf,
          "stEncDlg:Dialogue portion encoded successfully\n"));

   RETVALUE(ROK);
} /* End of stEncDlg */


/*
*
*       Fun:    stEncMsg
*
*       Desc:   Encode a TCAP message in ASN.1 format
*
*       Ret:    ROK        Success
*               RFAILED    Failure
*
*       Notes:  mBuf already contains encoded component and dialogue portion.
*               mBuf is empty only if the service user chose not to include
*               component and dialogue portion for this message.
*
*       File:   ct_mf.c
*
*/
#ifdef ANSI
PUBLIC S16 stEncMsg
(
StMsgEv  *msgEv,        /* Transaction Portion Event Structure */
Swtch     pSwtch,       /* Protocol Switch */
Buffer   *mBuf          /* Buffer to return the encoded message */
)
#else
PUBLIC S16 stEncMsg(msgEv, pSwtch, mBuf)
StMsgEv  *msgEv;        /* Transaction Portion Event Structure */
Swtch     pSwtch;       /* Protocol Switch */
Buffer   *mBuf;         /* Buffer to return the encoded message */
#endif
{
   CmAsnErr     err;     /* Error structure returned by ASN.1 Encoder */
   U8           msgTag;  /* Message Tag */
   MsgLen       tmpLen;
   Bool         errFlag; /* To Indicate encoding errors */
   U8           pkArray[ST_MAX_TRNS_PRTN_LEN];
   U8           idx;     /* Index into pkArray */
   S16          ret;     /* return value */

   TRC2(stEncMsg)

   /* st015.301 -Add- Initialize msgTag */
   msgTag = ST_INV_MSG_TAG;


   UNUSED(pSwtch);

   errFlag = FALSE;
   tmpLen  = 0;
   idx     = 0;       /* Initialize the index to pkArray */

   /* Encoding of Transaction Portion */
   switch(msgEv->msgType.val)
   {
      case ST_MSG_TYP_UNI:
         msgTag = ST_ITU_MSG_UNI_TAG;
         break;

      case ST_MSG_TYP_BGN:
         msgTag = ST_ITU_MSG_BGN_TAG;

         /* Check if mandatory element is missing */
         if (msgEv->orgTrnsId.pres == FALSE)
         {
            errFlag        = TRUE;
            err.errCode    = CM_ASN_MAND_MIS;
            err.tag.len    = 1;
            err.tag.val[0] = ST_ITU_ORG_TID_TAG;
            break;
         }

         /* Convert the transaction id to Integer */
         stU32ToStr(msgEv->orgTrnsId.val, &pkArray[idx], &tmpLen, FALSE);
         idx += tmpLen; 
         pkArray[idx++] = (U8)tmpLen;
         pkArray[idx++] = ST_ITU_ORG_TID_TAG;
         break;

      case ST_MSG_TYP_CNT:
         msgTag = ST_ITU_MSG_CNT_TAG;

         /* Check if mandatory element is missing */
         if (msgEv->orgTrnsId.pres == FALSE)
         {
            errFlag        = TRUE;
            err.errCode    = CM_ASN_MAND_MIS;
            err.tag.len    = 1;
            err.tag.val[0] = ST_ITU_ORG_TID_TAG;
            break;
         }

         if (msgEv->dstTrnsId.pres == FALSE)
         {
            errFlag        = TRUE;
            err.errCode    = CM_ASN_MAND_MIS;
            err.tag.len    = 1;
            err.tag.val[0] = ST_ITU_DST_TID_TAG;
            break;
         }

         tmpLen = msgEv->trnsIdLen.val;

         /* Convert the destination transaction id to Integer */
         stU32ToStr(msgEv->dstTrnsId.val, &pkArray[idx], &tmpLen, FALSE);
         idx += tmpLen; 
         pkArray[idx++] = (U8)tmpLen;
         pkArray[idx++] = ST_ITU_DST_TID_TAG;

         tmpLen = 0;

         stU32ToStr(msgEv->orgTrnsId.val, &pkArray[idx], &tmpLen, FALSE);
         idx += tmpLen; 
         pkArray[idx++] = (U8)tmpLen;
         pkArray[idx++] = ST_ITU_ORG_TID_TAG;
         break;

      case ST_MSG_TYP_END:
         msgTag = ST_ITU_MSG_END_TAG;

         /* Check if mandatory element is missing */
         if (msgEv->dstTrnsId.pres == FALSE)
         {
            errFlag        = TRUE;
            err.errCode    = CM_ASN_MAND_MIS;
            err.tag.len    = 1;
            err.tag.val[0] = ST_ITU_DST_TID_TAG;
            break;
         }

         tmpLen = msgEv->trnsIdLen.val;

         /* Convert the destination transaction id to Integer */
         stU32ToStr(msgEv->dstTrnsId.val, &pkArray[idx], &tmpLen, FALSE);
         idx += tmpLen; 
         pkArray[idx++] = (U8)tmpLen;
         pkArray[idx++] = ST_ITU_DST_TID_TAG;
         break;

      case ST_MSG_TYP_PABT:
         msgTag = ST_ITU_MSG_ABT_TAG;

         /* Check if mandatory element is missing */
         if (msgEv->pAbtCause.pres == FALSE)
         {
            errFlag        = TRUE;
            err.errCode    = CM_ASN_MAND_MIS;
            err.tag.len    = 1;
            err.tag.val[0] = ST_ITU_PABT_TAG;
            break;
         }

         if (msgEv->dstTrnsId.pres == FALSE)
         {
            errFlag        = TRUE;
            err.errCode    = CM_ASN_MAND_MIS;
            err.tag.len    = 1;
            err.tag.val[0] = ST_ITU_DST_TID_TAG;
            break;
         }

         pkArray[idx++] = msgEv->pAbtCause.val;
         pkArray[idx++] = 1;
         pkArray[idx++] = ST_ITU_PABT_TAG;

         tmpLen = msgEv->trnsIdLen.val;

         stU32ToStr(msgEv->dstTrnsId.val, &pkArray[idx], &tmpLen, FALSE);
         idx += tmpLen; 
         pkArray[idx++] = (U8)tmpLen;
         pkArray[idx++] = ST_ITU_DST_TID_TAG;
         break;

      case ST_MSG_TYP_UABT:
         msgTag = ST_ITU_MSG_ABT_TAG;

         if (msgEv->dstTrnsId.pres == FALSE)
         {
            errFlag        = TRUE;
            err.errCode    = CM_ASN_MAND_MIS;
            err.tag.len    = 1;
            err.tag.val[0] = ST_ITU_DST_TID_TAG;
            break;
         }

         tmpLen = msgEv->trnsIdLen.val;

         stU32ToStr(msgEv->dstTrnsId.val, &pkArray[idx], &tmpLen, FALSE);
         idx += tmpLen; 
         pkArray[idx++] = (U8)tmpLen;
         pkArray[idx++] = ST_ITU_DST_TID_TAG;
         break;

      default:
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_ENCODE, (stCb.init.prntBuf,
                "stEncDlg:Unknown message type(%d)\n",msgEv->msgType.val));
         break;
   }  /* end of switch */

   /* Check for encoding errors */
   if (errFlag)
   {
      STDBGP(ST_DBGMASK_ENCODE, (stCb.init.prntBuf,
             "stEncMsg:Error Code(%x), Element Tag(%x)\n",
              err.errCode, err.tag.val[0]));

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST291, (ErrVal)err.tag.val[0],
                 "stEncMsg:Mandatory Element missing");
#endif

      RETVALUE(RFAILED);
   }

   /* For Uni message, need to put only message tag and length */
   if (idx != 0)
   {
      /* Put the encoded transaction portion at the front of the buffer */
      ret = SAddPreMsgMult(pkArray, (MsgLen)idx, mBuf);

#if (ERRCLASS & ERRCLS_ADD_RES)
      if (ret != ROK)
      {
         STLOGERROR(ERRCLS_ADD_RES, EST292, (ErrVal)ret,
                    "stEncMsg: SAddPreMsgMult Failed");
         RETVALUE(RFAILED);
      }  
#endif
   }

   /* put message tag and length in the buffer */
   if (stPutTagLen(mBuf, msgTag) != ROK)
   {
      RETVALUE(RFAILED);
   }

   STDBGP(ST_DBGMASK_ENCODE, (stCb.init.prntBuf,
          "stEncMsg:Message(%x) encoded successfully\n", msgTag));

   RETVALUE(ROK);
} /* End of stEncMsg */




/*
*
*       Fun:    stDecComp
*
*       Desc:   Decode a Component coded in ASN.1 format
*
*       Ret:    ROK        Success
*               RFAILED    Failure, problem code is reported by 'probCode'
*
*       Notes:  None
*
*       File:   ct_mf.c
*
*/

#ifdef ANSI
PUBLIC S16 stDecComp
(
PTR       compEv,       /* Component Event Structure */
Swtch     pSwtch,       /* Protocol Switch */
Buffer   *mBuf,         /* Buffer holding the component to be decoded */
U8       *probCode,     /* To return decoding error, if any */
Bool     *lastCmp,      /* Flag for the last component in mBuf */
/* st016.301 -Add- parameter compDec */
Bool     *compDec       /* Flag to see whether component is decoded */
)
#else
/* st016.301 -Add- parameter compDec */
PUBLIC S16 stDecComp(compEv, pSwtch, mBuf, probCode, lastCmp, compDec)
PTR       compEv;       /* Component Event Structure */
Swtch     pSwtch;       /* Protocol Switch */
Buffer   *mBuf;         /* Buffer holding the component to be decoded */
U8       *probCode;     /* To return decoding error, if any */
Bool     *lastCmp;      /* Flag for the last component in mBuf */
/* st016.301 -Add- parameter compDec */
Bool     *compDec;      /* Flag to see whether component is decoded */
#endif
{
   CmAsnErr     err;     /* Error structure to return decoding errors */
   CmElmntDef **compDef; /* Database definition of components */
   MsgLen       msgLen;  /* Length of the message buffer */
   MsgLen       lfLen;   /* Length of length field */
   MsgLen       idx;     /* Index to traverse thru the buffer */
   Bool         eocFlag; /* Indicate if EOC form of length encoding is used */
   Buffer      *compBuf; /* Component buffer */
   Data        *tmpArray;/* Temp. array to remove a component from mBuf */
   MsgLen       tmpLen;
   Data         tmpData;
   U8           pType;   /* Protocol Type */
   S16          ret;     /* return value */
   Buffer      *uBuf;
   MsgLen       tmpIdx;

   TRC2(stDecComp)

   /* Initialize the component event structure */
   stZeroEv((Data *)compEv, ST_TYP_CMP_PRTN, pSwtch);

   *lastCmp = FALSE;     /* Last component flag */

   /* st016.301 -Add- Initialize variable compDec */
   *compDec = FALSE;

   /* Examine first byte for the component portion Tag */
   if (SExamMsg(&tmpData, mBuf, 0) != ROK)
   {
      /* st009.301 -Add- print debug information */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stDecComp:first byte of component portion tag not ok\n"));
      err.errCode = CM_ASN_MAND_MIS;
      *probCode   = stMapErrCode(&err, ST_TYP_CMP_PRTN, pSwtch);     
      RETVALUE(RFAILED);
   }

   /* If component portion Tag is not removed already then remove it */
   if ((tmpData == ST_ITU_COMP_PRTN_TAG) &&
       (stRemTagLen(mBuf, &tmpData, &tmpLen) != ROK))
   {
      err.errCode = CM_ASN_LEN_ERR;
      *probCode   = stMapErrCode(&err, ST_TYP_CMP_PRTN, pSwtch);     
      /* st009.301 -Add- print debug information */
      STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
             "stDecComp:Failed to remove ITU component portion tag\n"));
      RETVALUE(RFAILED);
   }

   /* Find the length of first component excluding tag and length field */
   if (stFindLen(mBuf, 1, &idx, &lfLen, &eocFlag) != ROK)
   {
      /* st016.301 -Modify- For length encoding problem, set problem code for 
       * badly structured component
       */
      *probCode   = ST_GEN_BD_COMP;
      RETVALUE(RFAILED);
   }
   tmpIdx = idx;

   /* add lengths of tag and length and EOC field, if present */
   idx += lfLen + 1 + (eocFlag * EOC_TAG_LEN);
 
   /* Find length of all the components in the buffer */
   (Void)SFndLenMsg(mBuf, &msgLen);

   /* Component length should not be zero */
   if (tmpIdx == 0)
   {
      if (idx == msgLen)
      {
         err.errCode = CM_ASN_MAND_MIS;
        *probCode    = stMapErrCode(&err, ST_TYP_CMP_PRTN, pSwtch);     
      }
      else
      {
         /* st016.301 -Modify- set problem code for badly structured 
          * component */
        *probCode    =   ST_GEN_BD_COMP;   
      }
      RETVALUE(RFAILED);
   }

   /* Check if buffer contains one or more components */
   if (msgLen != idx)
   {
      /* Allocate a new buffer to separate out one component from mBuf */
      if (SGetMsg(stCb.init.region, stCb.init.pool, &compBuf) != ROK)
      {
         err.errCode = CM_ASN_RES_ERR;
         *probCode = stMapErrCode(&err, ST_TYP_CMP_PRTN, pSwtch);     

         RETVALUE(RFAILED);
      }

      /* Allocate memory to remove first component from mBuf */
      tmpArray = stAlloc(idx+1);
      if (tmpArray == (Data *)NULLP)
      {
         err.errCode = CM_ASN_RES_ERR;
         *probCode = stMapErrCode(&err, ST_TYP_CMP_PRTN, pSwtch);     

         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(compBuf);
         RETVALUE(RFAILED);
      }

      /* Remove the first component from the buffer */
      if (SRemPreMsgMult(tmpArray, idx, mBuf) != ROK)
      {
         err.errCode = CM_ASN_LEN_ERR;
         *probCode = stMapErrCode(&err, ST_TYP_CMP_PRTN, pSwtch);     

         (Void)stFree(tmpArray, idx+1);
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(compBuf);
         RETVALUE(RFAILED);
      }

      /* Copy the component to the component buffer */
      ret = SAddPstMsgMult(tmpArray, idx, compBuf);

#if (ERRCLASS & ERRCLS_ADD_RES)
      if (ret != ROK)
      {
         err.errCode = CM_ASN_RES_ERR;
         *probCode = stMapErrCode(&err, ST_TYP_CMP_PRTN, pSwtch);     
         (Void)stFree(tmpArray, idx+1);
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(compBuf);

         STLOGERROR(ERRCLS_ADD_RES, EST295, (ErrVal)ret,
                    "stDecComp: SAddPstMsgMult() Failed");
         RETVALUE(RFAILED);
      }
#endif

      /* Deallocate the memory */
      stFree(tmpArray, idx+1);
   }
   else
   {
      /* Only one component in mBuf, decode it */
      compBuf  = mBuf;
   
      *lastCmp = TRUE;
   }

   /* Get the database definition of components */
   compDef = (CmElmntDef **)stGetMsgDef(ST_DBTYPE_COMP, pSwtch);

   /* Map the protocol switch to protocol type understood by ASN.1 module */
   pType = stGetProtType(pSwtch);

   /* st015.301 -Add- check for invalid prototype switch */
   if (pType == ST_DEF_PROTTYPE)
   {
       STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
             "stEncComp:Error in protocol switch value\n"));   
       RETVALUE(RFAILED);
   }

   /* st016.301 -Add- set compDec flag */
   *compDec = TRUE;

   /* Decode the component */
   if (cmDecMsg((TknU8 *)compEv, compBuf, pType, compDef,
                stCb.init.region, stCb.init.pool,
                CM_ASN_GEN_ERR, &err, &uBuf) != ROK)
   {
      *probCode = stMapErrCode(&err, ST_TYP_CMP_PRTN, pSwtch);

      /* st016.301 -Add- overwrite problem code for invalid encoding of
       * invoke component */
      if (err.errCode == CM_ASN_MAND_MIS)
         stSetProbCode(compEv, probCode, pSwtch);
      
      /* If the buffer was allocated here then deallocate it here */
      if (!*lastCmp)
      {
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(compBuf);
      }
      RETVALUE(RFAILED);
   }

   /* In case of Reject Component check for the problem code and problem type
      values */
   switch(pSwtch)
   {
       case LST_SW_ITU88:
       case LST_SW_ITU92:
       case LST_SW_ITU96:

          /* If Null was present instead on Invoke Id then make invoke Id
             present token False. */
          if (((StItuCompEv *)compEv)->compType.val == ST_COMP_TYP_REJ)
          {
             if (((StItuCompEv *)compEv)->comp.rej.invNull.val == ST_REJ_INV_NULL)
             {
                ((StItuCompEv *)compEv)->comp.rej.invokeId.pres = FALSE;
             }

             if (stChkProbCodeVal(((StItuCompEv *)compEv)->comp.rej.probType.val,
                                  ((StItuCompEv *)compEv)->comp.rej.probCode.val,
                                  pSwtch) != ROK)
             {
                *probCode = ST_GEN_MT_COMP;

                /* If the buffer was allocated here then deallocate it here */
                if (!*lastCmp)
                {
                   /* st027.301 - Modify - Modify the user buf free mechanism */ 
                   STFREEUSERBUF(compBuf);
                }
                RETVALUE(RFAILED);
             }
          }
          break;

   }

   /* If there were more than one components in mBuf then a message buffer was
      allocated, release it now */
   if (!*lastCmp)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(compBuf);
   }

   RETVALUE(ROK);
} /* End of stDecComp */


/*
*
*       Fun:    stDecDlg
*
*       Desc:   Decode the dialogue portion coded in ASN.1 format
*
*       Ret:    ROK        Success
*               RFAILED    Failure
*
*       Notes:  Buffer passed to this routine may have component portion
*               also. If component portion is present in the buffer return
*               it untouched in the same buffer.
*
*       File:   ct_mf.c
*
*/
#ifdef ANSI
PUBLIC S16 stDecDlg
(
PTR       dlgEv,        /* Dialogue Event Structure */
Swtch     pSwtch,       /* Protocol Switch */
Buffer   *mBuf,         /* Buffer holding the component to be decoded */
U8       *abtCause      /* To return abort cause corresponding to decoding errors */
)
#else
PUBLIC S16 stDecDlg(dlgEv, pSwtch, mBuf, abtCause)
PTR       dlgEv;        /* Dialogue Event Structure */
Swtch     pSwtch;       /* Protocol Switch */
Buffer   *mBuf;         /* Buffer holding the component to be decoded */
U8       *abtCause;     /* To return abort cause corresponding to decoding errors */
#endif
{
   CmAsnErr     err;     /* Error structure to return decoding errors */
   CmElmntDef **dlgDef;  /* Database definition of dialogue portion */
   MsgLen       msgLen;  /* buffer length */
   MsgLen       lfLen;   /* Length of length field */
   MsgLen       idx;     /* Index to traverse thru the buffer */
   Bool         eocFlag; /* Indicate if EOC form of length encoding is used */
   Buffer      *dlgBuf;  /* Buffer to hold dialogue portion */
   Data        *tmpArray;/* Temp. array to remove dialogue portion from mBuf */
   U8           pType;   /* Protocol Type */
   S16          ret;     /* return value */
   Buffer      *uBuf;
   Bool         bufFlag;

   TRC2(stDecDlg)

   /* Initialize the dialogue event structure */
   stZeroEv((Data *)dlgEv, ST_TYP_DLG_PRTN, pSwtch);

   bufFlag = FALSE;

   /* Find the length of the dialogue portion excluding tag and length field */
   if (stFindLen(mBuf, 1, &idx, &lfLen, &eocFlag) != ROK)
   {
      *abtCause = ST_PABT_BD_DLGP;
      RETVALUE(RFAILED);
   }
   /* Dialogue portion length should not be zero */
   if (idx == 0)
   {
      *abtCause = ST_PABT_BD_DLGP;
      RETVALUE(RFAILED);
   }
   /* Total dialogue portion length */
   idx += lfLen + 1 + (eocFlag * EOC_TAG_LEN);

   /* Find length of dialogue portion and all the components, if any in mBuf */
   (Void)SFndLenMsg(mBuf, &msgLen);

   /* Check if buffer contains anything other than dialogue portion */
   if (msgLen != idx)
   {
      /* Allocate a new buffer to separate out the dialogue portion from
         mBuf */
      if (SGetMsg(stCb.init.region, stCb.init.pool, &dlgBuf) != ROK)
      {
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stDecDlg:SGetMsg failed\n"));
         *abtCause = ST_PABT_LM_RSRC;
         RETVALUE(RFAILED);
      }

      /* Separate buffer has been allocated */
      bufFlag = TRUE;

      /* Allocate buffer to tmpArray to remove dialogue portion */
      tmpArray = stAlloc(idx+1);
      if (tmpArray == (Data *)NULLP)
      {
         *abtCause = ST_PABT_LM_RSRC;
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stDecDlg:Memory allocation failure\n"));
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(dlgBuf);
         RETVALUE(RFAILED);
      }

      /* Remove the dialogue portion from the buffer */
      if (SRemPreMsgMult(tmpArray, idx, mBuf) != ROK)
      {
         *abtCause = ST_PABT_BD_DLGP;

         (Void)stFree(tmpArray, idx+1);
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(dlgBuf);
         RETVALUE(RFAILED);
      }

      /* Copy the dialogue portion to the dialogue buffer */
      ret = SAddPstMsgMult(tmpArray, (MsgLen)idx, dlgBuf);

#if (ERRCLASS & ERRCLS_ADD_RES)
      if (ret != ROK)
      {
         *abtCause = ST_PABT_LM_RSRC;
         (Void)stFree(tmpArray, idx+1);
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(dlgBuf);

         STLOGERROR(ERRCLS_ADD_RES, EST296, (ErrVal)ret,
                    "stDecDlg: SAddPstMsgMult() Failed");
         RETVALUE(RFAILED);
      }
#endif

      /* Free the allocated buffer to tmpArray */
      stFree(tmpArray, idx+1);
   }
   else
   {
      /* Only dialogue portion is there in mBuf, decode it */
      dlgBuf = mBuf;
   }

   /* Get the database definition of dialogue portion */
   dlgDef = (CmElmntDef **)stGetMsgDef(ST_DBTYPE_DLG, pSwtch);

   /* Map the protocol switch to protocol type understood by ASN.1 module */
   pType = stGetProtType(pSwtch);

   /* st015.301 -Add- check for invalid prototype switch */
   if (pType == ST_DEF_PROTTYPE)
   {
       STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
             "stEncComp:Error in protocol switch value\n"));   
       RETVALUE(RFAILED);
   }

   /* Decode the dialogue portion */
   if (cmDecMsg((TknU8 *)dlgEv, dlgBuf, pType, dlgDef,
                stCb.init.region, stCb.init.pool,
                CM_ASN_GEN_ERR, &err, &uBuf) != ROK)
   {
      *abtCause = ST_PABT_BD_DLGP;

      /* If buffer was allocated here then deallocate it here */
      if (bufFlag)
      {
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(dlgBuf);
      }
      RETVALUE(RFAILED);
   }

   /* Check the dialogue event structure for correct values */
   if (stChkDlgEv(dlgEv, pSwtch, abtCause) != ROK)
   {
      /* If buffer was allocated here then deallocate it here */
      if (bufFlag)
      {
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(dlgBuf);
      }
      /* st009.301 -Add- Debug print */
      if (abtCause != NULLP)
      {        
         STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
           "stDecDlg:Improper values in dialogue event struc.,abort cause(%d)\n"
            ,*abtCause));
      }   
      RETVALUE(RFAILED);
   }

   /* Dialogue is decoded, release the buffer if it was allocated here */
   if (bufFlag)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(dlgBuf);
   }
   else
   {
      /* Empty the buffer if it is not already empty, doesn't have any component
         portion to decode */
      (Void)SFndLenMsg(mBuf, &msgLen);
      if (msgLen != 0)
      {
         (Void)SInitMsg(mBuf);
      }
   }

   RETVALUE(ROK);
} /* End of stDecDlg*/


/*
*
*       Fun:    stDecMsg
*
*       Desc:   Decode the transaction portion in the TCAP message
*
*       Ret:    ROK        Success
*               RFAILED    Failure
*
*       Notes:  This functions decodes only the transaction portion.
*               if component or dialogue portions are present in the message
*               it leave them encoded in the buffer.
*
*       File:   ct_mf.c
*
*/
#ifdef ANSI
PUBLIC S16 stDecMsg
(
StMsgEv  *msgEv,        /* Transaction Portion Event Structure */
Swtch     pSwtch,       /* Protocol Switch */
Buffer   *mBuf,         /* Buffer holding the message to be decoded */
U8       *abtCause      /* To return abort cause corresponding to decoding errors */
)
#else
PUBLIC S16 stDecMsg(msgEv, pSwtch, mBuf, abtCause)
StMsgEv  *msgEv;        /* Transaction Portion Event Structure */
Swtch     pSwtch;       /* Protocol Switch */
Buffer   *mBuf;         /* Buffer holding the message to be decoded */
U8       *abtCause;     /* To return abort cause corresponding to decoding errors */
#endif
{
   CmAsnErr     err;        /* error structure */
   MsgLen       msgLen;     /* Total message buffer length */
   StTag        tag;        /* Message Element tag */
   MsgLen       idx;        /* Message buffer index */
   Data         tmpData;    /* Temporary data storage */
   Bool         dlgFlag;    /* To indicate the presence of dialogue portion */
   Bool         compFlag;   /* To indicate the presence of component portion */

   TRC2(stDecMsg)

   /* Initialize the transaction portion event structure */
   stZeroEv((Data *)msgEv, ST_TYP_TRN_PRTN, pSwtch);

   /* Get the message type and length */
   if (stRemTagLen(mBuf, &tag, &msgLen) != ROK)
   {
      msgEv->msgType.pres = TRUE;
      msgEv->msgType.val  = ST_MSG_TYP_UNK;

      err.errCode = CM_ASN_LEN_ERR;
      *abtCause = stMapErrCode(&err, ST_TYP_TRN_PRTN, pSwtch);

      RETVALUE(RFAILED);
   }

   /* If return OK, make msgType valid */
   msgEv->msgType.pres = TRUE;
   msgEv->msgType.val  = stGetMsgType(tag);


   /* switch on message type to remove the transaction portion */
   switch(msgEv->msgType.val)
   {
      /* Message type Unidirectional */
      case ST_MSG_TYP_UNI:
         break;

      /* Message type Begin */
      case ST_MSG_TYP_BGN:

         /* Decode origination transaction id */
         if (stDecMsgElm((TknU8 *)&msgEv->orgTrnsId, ST_ITU_ORG_TID_TAG, 4,
                         TRUE, mBuf, &err) != ROK)
         {
            *abtCause = stMapErrCode(&err, ST_TYP_TRN_PRTN, pSwtch);
            RETVALUE(RFAILED);
         }
         msgEv->trnsIdLen.pres = TRUE;
         msgEv->trnsIdLen.val  = msgEv->orgTrnsId.spare1;
         break;

      /* Message type Continue */
      case ST_MSG_TYP_CNT:

         /* Decode origination transaction id */
         if (stDecMsgElm((TknU8 *)&msgEv->orgTrnsId, ST_ITU_ORG_TID_TAG, 4,
                         TRUE, mBuf, &err) != ROK)
         {
            *abtCause = stMapErrCode(&err, ST_TYP_TRN_PRTN, pSwtch);
            RETVALUE(RFAILED);
         }

         msgEv->trnsIdLen.pres = TRUE;
         msgEv->trnsIdLen.val  = msgEv->orgTrnsId.spare1;

         /* Decode destination transaction id */
         if (stDecMsgElm((TknU8 *)&msgEv->dstTrnsId, ST_ITU_DST_TID_TAG, 4,
                         TRUE, mBuf, &err) != ROK)
         {
            *abtCause = stMapErrCode(&err, ST_TYP_TRN_PRTN, pSwtch);
            RETVALUE(RFAILED);
         }
         break;

      /* Message type End */
      case ST_MSG_TYP_END:

         /* Decode destination transaction id */
         if (stDecMsgElm((TknU8 *)&msgEv->dstTrnsId, ST_ITU_DST_TID_TAG, 4,
                         TRUE, mBuf, &err) != ROK)
         {
            *abtCause = stMapErrCode(&err, ST_TYP_TRN_PRTN, pSwtch);
            RETVALUE(RFAILED);
         }
         break;

      /* Message type Abort */
      case ST_MSG_TYP_PABT:

         /* Decode destination transaction id */
         if (stDecMsgElm((TknU8 *)&msgEv->dstTrnsId, ST_ITU_DST_TID_TAG, 4,
                         TRUE, mBuf, &err) != ROK)
         {
            *abtCause = stMapErrCode(&err, ST_TYP_TRN_PRTN, pSwtch);
            RETVALUE(RFAILED);
         }

         /* Decode abort cause */
         if (stDecMsgElm((TknU8 *)&msgEv->pAbtCause, ST_ITU_PABT_TAG, 1,
                         FALSE, mBuf, &err) != ROK)
         {
            *abtCause = stMapErrCode(&err, ST_TYP_TRN_PRTN, pSwtch);
            RETVALUE(RFAILED);
         }

         if (msgEv->pAbtCause.pres == FALSE)
         {
            msgEv->msgType.val = ST_MSG_TYP_UABT;
         }
         else
         {
            /* Check for the correctness of P-Abort Cause Value */
            if (stChkPAbtCauseVal(msgEv->pAbtCause.val, pSwtch) != ROK)
            {
               *abtCause = ST_PABT_IN_TRNP;
               RETVALUE(RFAILED);
            }
         }
         break;

      /* Message type Unknown */
      default:

         /* Decode origination transaction id */
         stDecMsgElm((TknU8 *)&msgEv->orgTrnsId, ST_ITU_ORG_TID_TAG, 4,
                     TRUE, mBuf, &err);

         /* Decode destination transaction id */
         stDecMsgElm((TknU8 *)&msgEv->dstTrnsId, ST_ITU_DST_TID_TAG, 4,
                     TRUE, mBuf, &err);

         *abtCause = ST_PABT_UR_MSGT;
         RETVALUE(RFAILED);

         break;
   }

   /* See if anything left in the message buffer */
   (Void)SFndLenMsg(mBuf, &msgLen);

   if (msgLen == 0)
   {
      RETVALUE(ROK);
   }

   /* Initialize the local variables */
   dlgFlag  = FALSE;
   compFlag = FALSE;
   idx      = 0;

   /* Check for correctness of dialogue portion tag and length and component
      portion tag and length here. Remove these tags and lengths later
      while decoding dialogue portion and component portion */

   /* Examine for the presence of dialogue portion */
   if (SExamMsg(&tmpData, mBuf, 0) == ROK)
   {
      /* Check if Dialogue Portion is present */
      if (tmpData == ST_ITU_DLG_PRTN_TAG)
      {
         dlgFlag = TRUE;
      }
      /* Check if component portion is present */
      else if (tmpData == ST_ITU_COMP_PRTN_TAG)
      {
         compFlag = TRUE;
      }
      else if (msgEv->msgType.val == ST_MSG_TYP_UABT)
      {
         /* For U-Abort message, it might be the user information with
            user defined syntax */
         RETVALUE(ROK);
      }
      /* Unrecognized Tag value */
      else
      {
         *abtCause = ST_PABT_IN_TRNP;
         RETVALUE(RFAILED);
      }
   }

   /* If dialogue portion is present then check for the component portion
      after the dialogue portion */

   if (dlgFlag)
   {
      MsgLen     lfLen = 0;
      Bool       eocFlag = FALSE;

      /* Dialogue portion shouldn't be present in ITU-88 TCAP messages */
      if (pSwtch == LST_SW_ITU88)
      {
         *abtCause = ST_PABT_BD_TRNP;
         RETVALUE(RFAILED);
      }

      /* Find the length of the dialogue portion excluding dialogue portion
         tag and length field */

      if (stFindLen(mBuf, 1, &idx, &lfLen, &eocFlag) != ROK)
      {
         *abtCause = ST_PABT_BD_TRNP;
         RETVALUE(RFAILED);
      }
      /* Length field can't contain zero */
      if (idx == 0)
      {
         *abtCause = ST_PABT_IN_TRNP;
         RETVALUE(RFAILED);
      }

      /* Total dialogue portion length */
      idx += lfLen + 1 + (eocFlag * EOC_TAG_LEN);

      /* Now Examine for the presence of Component portion */
      if (SExamMsg(&tmpData, mBuf, idx) == ROK)
      {
         if (tmpData == ST_ITU_COMP_PRTN_TAG)
         {
            compFlag = TRUE;
         }
         /* Unrecognized Tag value */
         else
         {
            *abtCause = ST_PABT_IN_TRNP;
            RETVALUE(RFAILED);
         }
      }
   }

   /* If component portion is present then check the component portion
      tag and length here */

   if (compFlag)
   {
      MsgLen     tmpIdx = 0;
      MsgLen     lfLen = 0;
      Bool       eocFlag = FALSE;

      /* Find the length of the Component portion excluding Component portion
         tag and length field */

      if (stFindLen(mBuf, (MsgLen)(idx + 1), &tmpIdx, &lfLen, &eocFlag) != ROK)
      {
         *abtCause = ST_PABT_BD_TRNP;
         RETVALUE(RFAILED);
      }
      /* Length field can't contain zero */
      if (tmpIdx == 0)
      {
         *abtCause = ST_PABT_IN_TRNP;
         RETVALUE(RFAILED);
      }
      /* Total component portion length */
      tmpIdx += lfLen + 1 + (eocFlag * EOC_TAG_LEN);
 
      /* Total length of component portion and dialogue portion, if present */
      idx += tmpIdx;
   }
   /* Check for the correct length */
   if (msgLen != idx)
   {
      *abtCause = ST_PABT_BD_TRNP;
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* End of stDecMsg */




/*
*
*       Fun:   stPutTagLen
*
*       Desc:  This function encodes Tag and length at the front of a buffer
*
*       Ret:   ROK (encoding successful) 
*              RFAILED (general failure)
*
*       Notes: This function encodes the length in short from if the length can
*              fitted in an octet else it uses indefinite form of length
*              encoding.
*
*       File:  ct_mf.c
*
*/
#ifdef ANSI
PUBLIC S16 stPutTagLen
(
Buffer   *mBuf,              /* Message buffer */
StTag     tag                /* Tag to be put ahead of mBuf */
)
#else
PUBLIC S16 stPutTagLen(mBuf, tag)
Buffer   *mBuf;              /* Message buffer */
StTag     tag;               /* Tag to be put ahead of mBuf */
#endif
{
   Data     pkArray[6];      /* Array to encode tag and length */
   Data     tmpArray[6];     /* Temporary Array */
   MsgLen   msgLen;
   MsgLen   idx;             /* Index thru the pkArray */
   MsgLen   numBytes;        /* Number of bytes copied */
   S16      ret;

   TRC2(stPutTagLen)

   /* st015.301 -Add- check for invalid msg tag */        
   if (tag == ST_INV_MSG_TAG)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, ESTXXX, (ErrVal)tag,
                 "stPutTagLen:Incorrect msg tag");
#endif /* ERRCLASS */
      RETVALUE(RFAILED);
   }
   (Void)SFndLenMsg(mBuf, &msgLen);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (msgLen <= 0)
   {
      STLOGERROR(ERRCLS_DEBUG, EST297, (ErrVal)msgLen,
                 "stPutTagLen:Incorrect msgLen");
      RETVALUE(RFAILED);
   }
#endif
      
   /* Encode the length */
   stEncLen((MsgLen)msgLen, tmpArray, &numBytes);

   /* Reverse the array contents */
   for (idx = 0; numBytes > 0; numBytes--)
   {
       pkArray[idx++] = tmpArray[numBytes - 1];
   }

   /* Put the Tag */
   pkArray[idx++] = tag;

   /* Add the array to the buffer */
   ret = SAddPreMsgMult(pkArray, (MsgLen)idx, mBuf);

#if (ERRCLASS & ERRCLS_ADD_RES)
   if (ret != ROK)
   {
      STLOGERROR(ERRCLS_ADD_RES, EST298, (ErrVal)ret,
                 "stPutTagLen: SAddPreMsgMult Failed");
      RETVALUE(RFAILED);
   }  
#endif

   RETVALUE(ROK);
}  /* End of stPutTagLen */


/*
*
*       Fun:   stEncLen
*
*       Desc:  This function encodes length
*
*       Ret:   ROK (encoding successful) 
*              RFAILED (general failure)
*
*       Notes: This function encodes the length in short from if the length can
*              be fitted in an octet else it uses long form of length
*              encoding.
*
*       File:  ct_mf.c
*
*/
#ifdef ANSI
PRIVATE S16 stEncLen
(
MsgLen    len,             /* Length to be encoded */
U8       *pkArray,         /* Attay to encode the length */
MsgLen   *nmb              /* Number of bytes copied in the array */
)
#else
PRIVATE S16 stEncLen(len, pkArray, nmb)
MsgLen    len;             /* Length to be encoded */
U8       *pkArray;         /* Attay to encode the length */
MsgLen   *nmb;             /* Number of bytes copied in the array */
#endif
{
   TRC2(stEncLen)

   /* Check if the length can be fitted in a single octet */
   if (len < ST_LEN_INDEF)
   {
      *pkArray = (U8)len;
      *nmb     = 1;
   }
   /* Encode long form of length encoding */
   else
   {
      U32   tmpLen = len;
      U8    idx = 0;


      /* Find the number of octets required to encode the length */
      while(tmpLen > 0)
      {
         tmpLen >>= 8;
         idx++;
      }

      /* number of octets for length field plus one octet for length of
         length field */
      *nmb = (idx + 1);

      /* Encode the length, first octet is the length field length in octets */
      *pkArray = (U8)(ST_LEN_INDEF | idx);

      for (; idx > 0; idx--)
      {
          *(pkArray + idx) = (U8)(len & 0xFF);   /* Copy the LSB */
          len >>= 8;                             /* Shift out the LSB */
      }
   }

   RETVALUE(ROK);
}  /* End of stEncLen */


/*
*
*       Fun:    stDecMsgElm
*
*       Desc:   Decode a TCAP message element in ASN.1 format
*
*       Ret:    ROK        Success
*               RFAILED    Failure, error code is reported by 'err'
*
*       Notes:  This function is used to decode all mandatory elements
*
*       File:   ct_mf.c
*
*/
#ifdef ANSI
PRIVATE S16 stDecMsgElm
(
TknU8     *elmEv,           /* Element Event Structure */
StTag      tag,             /* Origination or Destination */
MsgLen     maxLen,          /* Max length of element content */
Bool       mandFlag,        /* Mandatory Flag */
Buffer    *mBuf,            /* Message Buffer */
CmAsnErr  *err              /* To return any decoding error */
)
#else
PRIVATE S16 stDecMsgElm(elmEv, tag, maxLen, mandFlag, mBuf, err)
TknU8     *elmEv;           /* Element Event Structure */
StTag      tag;             /* Origination or Destination */
MsgLen     maxLen;          /* Max length of element content */
Bool       mandFlag;        /* Mandatory Flag */
Buffer    *mBuf;            /* Message Buffer */
CmAsnErr  *err;             /* To return any decoding error */
#endif
{
   /* Array to remove an element from the msg buffer */
   Data   unPkArray[ST_MAX_TRNS_PRTN_LEN];
   U8     idx;              /* Index thru the array */

   TRC2(stDecMsgElm)

   idx = 0;

   /* Check the Tag first */
   if ((SExamMsg(&unPkArray[0], mBuf, 0) != ROK) || ((U8)unPkArray[0] != tag))
   {
      if (mandFlag)
      {
         /* Mandatory element is missing */
         err->errCode = CM_ASN_MAND_MIS;
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
        "stDecMsgElm:Processing tag(%d),Mandatory elem missing,error code(%d)\n"
                ,tag, err->errCode));
         RETVALUE(RFAILED);
      }
      else
      {
         /* Optional element is missing, return OK */
         RETVALUE(ROK);
      }
   }

   /* Check the encoding of length field, it should be short form */
   if ((SExamMsg(&unPkArray[1], mBuf, 1) != ROK) || (unPkArray[1] >= 0x80))
   {
      err->errCode = CM_ASN_LEN_ERR;
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
             "stDecMsgElm:Legth field not properly encoded, error code(%d)\n", 
             err->errCode));
      RETVALUE(RFAILED);
   }

   /* Now remove the primitive including tag and length */
   if (SRemPreMsgMult(unPkArray, (MsgLen)(2 + unPkArray[1]), mBuf) != ROK)
   {
      err->errCode = CM_ASN_LEN_ERR;
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
             "stDecMsgElm:Couldnt remove tag and legth bytes, error code(%d)\n"
             ,err->errCode));
      RETVALUE(RFAILED);
   }

   /* check for the element which can have zero length */
   if (((U8)unPkArray[1] == 0) && (maxLen == 0))
   {
      /* Zero length OK */
      RETVALUE(ROK);
   }

   /* Check the length value */
   if ((maxLen != 0) &&
       ((unPkArray[1] > (Data)maxLen) || (unPkArray[1] <= (Data)0)))
   {
      err->errCode = CM_ASN_LEN_ERR;
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
             "stDecMsgElm:Length value(%d) not in proper range,error code(%d)\n"
             ,unPkArray[1],err->errCode));
      RETVALUE(RFAILED);
   }

   idx = 2;  /* points the index to the contents */
   switch(tag)
   {
       case ST_ITU_ORG_TID_TAG:
       case ST_ITU_DST_TID_TAG:

          elmEv->pres = TRUE;
          ST_STR_TO_U32(&unPkArray[idx], unPkArray[1], &(((TknU32 *)elmEv)->val));
          ((TknU32 *)elmEv)->spare1 = unPkArray[1];
          idx += unPkArray[1];
          break;

       case ST_ITU_PABT_TAG:

          elmEv->pres = TRUE;
          elmEv->val  = (U8)unPkArray[idx];
          break;

   }

   RETVALUE(ROK);
}  /* End of stDecMsgElm */


/*
*
*       Fun:   stRemTagLen
*
*       Desc:  This function removes Tag and length field bytes from the buffer.
*
*       Ret:   ROK (encoding successful) 
*              RFAILED (general failure)
*
*       Notes: If indefinite form of length encoding has been used, this
*              function removes two bytes of EOC tag and length from the end
*              of the buffer.
*
*       File:  ct_mf.c
*
*/
#ifdef ANSI
PUBLIC S16 stRemTagLen
(
Buffer   *mBuf,              /* Message buffer */
StTag    *tag,               /* Tag to be removed from the front of mBuf */
MsgLen   *msgLen             /* Length of the message without tag and length field */
)
#else
PUBLIC S16 stRemTagLen(mBuf, tag, msgLen)
Buffer  *mBuf;              /* Message buffer */
StTag   *tag;               /* Tag to be removed from the front of mBuf */
MsgLen  *msgLen;            /* Length of the message without tag and length field */
#endif
{
   MsgLen       totLen;    /* Total length of mBuf */
   MsgLen       lfLen;     /* length field length */
   U8           eocFlag;   /* flag to indicate if indefinite form of length encoding */
   Data         unPkArray[6];
   S16          ret;       /* Return value */

   TRC2(stRemTagLen)

   /* Get total length of the message */
   (Void)SFndLenMsg(mBuf, &totLen);

   /* See what the length field has */
   if (stFindLen(mBuf, (MsgLen)1, msgLen, &lfLen, &eocFlag) != ROK)
   {
      /* st009.301 -Add- print debug information */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                 "stRemTagLen:stFindLen routine execution failed\n"));
      RETVALUE(RFAILED);
   }
  
   /* Check if both lengths match */
   if (eocFlag)
   {
      if (totLen != (*msgLen + 1 + lfLen + 2))
      {
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
             "stRemTagLen:Total length(%d) not ok\n",totLen));
         RETVALUE(RFAILED);
      }
   }
   else
   {
      if (totLen != (*msgLen + 1 + lfLen))
      {
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
             "stRemTagLen:Total length(%d) not ok\n",totLen));
         RETVALUE(RFAILED);
      }
   }

   /* Remove message tag and length field */
   ret = SRemPreMsgMult(unPkArray, (MsgLen)(1+lfLen), mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      STLOGERROR(ERRCLS_DEBUG, EST299, (ErrVal)ret,
                 "stRemTagLen: SRemPreMsgMult Failed");
      RETVALUE(RFAILED);
   }
#endif

   /* Return the message tag */
   *tag = (StTag)unPkArray[0];

   /* if eoc form of length encoding, remove EOC tag and length from the
      message */
   if (eocFlag == TRUE)
   {
      (Void)SRemPstMsgMult(unPkArray, 2, mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         STLOGERROR(ERRCLS_DEBUG, EST300, (ErrVal)ret,
                    "stRemTagLen: SRemPreMsgMult Failed");
         RETVALUE(RFAILED);
      }
#endif
      /* Check if EOC bytes are present or not */
      if ((unPkArray[0] != ST_EOC_TAG) || (unPkArray[1] != ST_EOC_TAG))
      {
         RETVALUE(RFAILED);
      }
   }

   RETVALUE(ROK);
}  /* End of stRemTagLen */


/*
*
*      Fun:   stFndOrgTid
*
*      Desc:  Find the Originating Transaction Id in the Message Buffer
*
*      Ret:   ROK     (Org Tid was found)
*             RFAILED (otherwise)
*
*      Notes: Few TCAP messages (End, Abort) don't contain Originating 
*             Transaction Id, in this case this function just returns
*             RFAILED.
*
*      File:  ct_mf.c
*
*/
#ifdef ANSI
PUBLIC S16 stFndOrgTid
(
StDlgId   *spDlgId,   /* To return Org Tid */
Buffer    *mBuf       /* message buffer */
)
#else
PUBLIC S16 stFndOrgTid(spDlgId, mBuf)
StDlgId   *spDlgId;   /* To return Org Tid */
Buffer    *mBuf;      /* message buffer */
#endif
{
   MsgLen   len;      /* Length */
   StTag    msgTag;   /* Message Tag */
   StTag    elmTag;   /* Element Tag */
   Data     unPkArray[ST_MAX_TRNS_PRTN_LEN];
 
   TRC2(stFndOrgTid)
 
   /* st015.301 -Add- Initialize elmTag */
   elmTag = ST_INV_ELM_TAG;
   
   /* Skip the message tag and length */
   if (stRemTagLen(mBuf, &msgTag, &len) != ROK)
   {
      /* st009.301 -Add- print debug information */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stFndOrgTid:stRemTagLen routine execution failed\n"));
      RETVALUE(RFAILED);
   }
 
   /* Return for those messages, where origination Transaction Id is not
      present and for others return the originating Transaction id */

   switch(msgTag)
   {
      case ST_ITU_MSG_BGN_TAG:
      case ST_ITU_MSG_CNT_TAG:

         elmTag = ST_ITU_ORG_TID_TAG;
         break;

      case ST_ITU_MSG_UNI_TAG:
      case ST_ITU_MSG_END_TAG:
      case ST_ITU_MSG_ABT_TAG:

         RETVALUE(RFAILED);

   }
 
   /* Copy the first two bytes from mBuf to check for element tag and length */
   if ((SCpyMsgFix(mBuf, 0, 2, unPkArray, &len) != ROK) || (len != 2))
   {
      /* st009.301 -Add- print debug information */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stFndOrgTid:stCpyMsgFix routine execution failed\n"));
      RETVALUE(RFAILED);
   }

   /* Check the encoding of length field, it shouldn't be in long form */
   if ((unPkArray[0] != (Data)elmTag) || (unPkArray[1] > 0x80))
   {
      /* st009.301 -Add- print debug information */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stFndOrgTid:Length field is not encoded in long form\n"));
      RETVALUE(RFAILED);
   }

   /* Now remove the primitive including tag and length */
   if (SRemPreMsgMult(unPkArray, (MsgLen)(2 + unPkArray[1]), mBuf) != ROK)
   {
      /* st009.301 -Add- print debug information */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stFndOrgTid:SRemPreMsgMult routine execution failed\n"));
      RETVALUE(RFAILED);
   }

   ST_STR_TO_U32(&unPkArray[2], unPkArray[1], spDlgId);

   RETVALUE(ROK);
} /* stFndOrgTid */


/*
*
*      Fun:   stGetLen
*
*      Desc:  Get the length of an element encoded in the length field.
*             For EOC length encoding it returns length 1 octet.
*
*      Ret:   ROK (Decode was successful)
*             RFAILED (otherwise)
*
*      Notes: Offset points to the length field
*
*      File:  ct_mf.c
*
*/
#ifdef ANSI
PRIVATE S16 stGetLen
(
Buffer    *mBuf,      /* message buffer */
MsgLen     offset,    /* offset into the message buffer */
MsgLen    *len,       /* Returns the length */
MsgLen    *size,      /* Returns size of the length field */
Bool      *eocFlag    /* eoc flag */
)
#else
PRIVATE S16 stGetLen(mBuf, offset, len, size, eocFlag)
Buffer    *mBuf;      /* message buffer */
MsgLen     offset;    /* offset into the message buffer */
MsgLen    *len;       /* Returns the length */
MsgLen    *size;      /* Returns size of the length field */
Bool      *eocFlag;   /* eoc flag */
#endif
{
/* st044.301 - Adition - Declaration for total length variable */   
   MsgLen      totLen;    /* total length of the message */
   Data    tmpData;                     /* temporary data */
   Data    unPkArray[ST_MAX_LEN_BYTES]; /* array for unpacking length */


   TRC2(stGetLen)
   
   *eocFlag = FALSE;   /* not a eoc form of length encoding */
   *len     = 0;       /* Initialize the length */

/* st044.301 - Addition - Changes for checking if element length is greater than 
                          total length of message */
   /* get the total length of the message */
   (Void)SFndLenMsg (mBuf, &totLen);

   /* Examine the first byte of the length field */
   if (SExamMsg(&tmpData, mBuf, offset) != ROK)
   {
      /* st009.301 -Add- print debug information */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stGetLen:First byte of length field not ok\n"));
      RETVALUE(RFAILED);
   }

   /* check for the short form of length encoding format */
   if (tmpData < ST_LEN_INDEF)
   {

/* st044.301 - Addition - Check if element length is greater than the message length */
      /* if element length is greater than the message length, error */

      if ( (totLen - (offset + 1)) < (MsgLen)tmpData)
      {
        STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
               "stGetLen:Element Length is exceeding total message length\n"));
        RETVALUE(RFAILED);
      }

      *len  = (MsgLen)tmpData;
      *size = 1;
      
      RETVALUE(ROK);
   }

   /* Check for Long form of length encoding */
   if (tmpData > ST_LEN_INDEF)
   {
      MsgLen    i;    /* Temporary counter value */
      U16       ret;  /* Temporary return value */

      /* get the number of bytes in the length field */
      tmpData = tmpData & ~ST_LEN_INDEF;

      /* length field is sum of first byte & no. of bytes in length field */
      *size = (tmpData +1);

 /* st044.301 - Addition - Added check on length of length field size */
       if(tmpData > ST_MAX_LEN_BYTES)
       {
          STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
                 "stGetLen:Length of length is exceeding the max limit\n"));
          RETVALUE(RFAILED);
       }
 
      /* Copy the length field into an array, MSB at index 0 */
      ret = SCpyMsgFix(mBuf, (MsgLen)(offset + 1), tmpData, unPkArray, &i); 

      if ((ret != ROK) || (i != tmpData))
      {
         /* st009.301 -Add- print debug information */
         STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
                "stGetLen:Error in length decoding\n"));
         /* error in length decoding */
         RETVALUE(RFAILED);
      }

      /* Return the length */

      for(i = 0; i < (MsgLen)tmpData; i++)
      {
         *len = ((*len << 8) | (MsgLen)unPkArray[i]);
      }

/* st044.301 - Addition -  Added check in stGetlen() if length of 
                      element is greater than total message length. */

      /* if element length is greater than the message length, error */

      if ( (totLen - (offset + tmpData + 1)) < *len)
      {
        STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
               "stGetLen:Element Length is exceeding total message length\n"));
        RETVALUE(RFAILED);
      }

      RETVALUE(ROK);
   }

   /* What left is Indefinate form of length encoding */

   *size    = 1;       /* indicate the length of length field as 1 */ 
   *len     = 0;       /* Indicate the element length as 0 */
   *eocFlag = TRUE;    /* indicate a indefinate form of length encoding */

   RETVALUE(ROK);
} /* stGetLen */


/*
*
*       Fun:    stFindLen
*
*       Desc:   Return the length of the element and the length of length
*               field as well. In case of indefinate length encoding the
*               the length of length field is returned as 1 and eocFlg is
*               set to true.
*
*       Ret:    ROK     - ok
*
*       Notes:  The offset points to the tag.  It is necessary to know
*               if the tag is a constructor or a primitive. The primitive
*               length indicated to the caller does not include the
*               EOC tag at the end. It does include the nested EOC tags
*               of any elements within, encoded in the EOC format.
*
*       File:   ct_mf.c
*
*/
#ifdef ANSI
PRIVATE S16 stFindLen
(
Buffer    *mBuf,      /* message buffer */
MsgLen     offset,    /* offset into the message buffer */
MsgLen    *len,       /* Returns the length */
MsgLen    *lfLen,     /* Returns size of the length field */
Bool      *eocFlag    /* eoc flag */
)
#else
PRIVATE S16 stFindLen(mBuf, offset, len, lfLen, eocFlag)
Buffer    *mBuf;      /* message buffer */
MsgLen     offset;    /* offset into the message buffer */
MsgLen    *len;       /* Returns the length */
MsgLen    *lfLen;     /* Returns size of the length field */
Bool      *eocFlag;   /* eoc flag */
#endif
{
   MsgLen    totLen;     /* Total length of the message */ 
   MsgLen    curLen;     /* current length */
   MsgLen    msgIdx;     /* message index */
   U8        eocCntr;    /* keeps the count of EOC nesting */
   /* st037.301 - Change S16 to MsgLen */
   MsgLen       i;          /* loop counter & copied bytes counter */
   Data      unPkArray[MAX_LEN_BYTES];

   TRC2(stFindLen)

   if (stGetLen(mBuf, offset, len, lfLen, eocFlag) != ROK)
   {
      /* st009.301 -Add- print debug information */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
            "stFindLen:stGetLen execution failure\n"));
      RETVALUE(RFAILED);
   }

   if (!*eocFlag) 
   {
      /* short or long format, return */
      RETVALUE(ROK);
   }

   /* Now, calculate the length encoded in indefinite format */

   /* get the total length of the message */
   (Void)SFndLenMsg (mBuf, &totLen);

   curLen  = 0;      /* Initialize the current length counter */
   eocCntr = 0;      /* eoc nesting level is 0 */

   /* make message index point to the next byte after the length field */
   msgIdx = (offset + 1);

   /* loop until find the matching EOC tag */
   while (1) 
   {
      /* if length already read is equal or greater than message length
         return error */

      if (totLen <= curLen)
      {
         RETVALUE(RFAILED);
      }

      /* get the next two bytes */
      if ((SCpyMsgFix(mBuf, msgIdx, EOC_TAG_LEN, unPkArray, &i) != ROK) ||
          (i != EOC_TAG_LEN))
      {
         /* st009.301 -Add- print debug information */
         STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
                "stFindLen:Error in indefinite form length decoding\n"));
         /* error in length decoding */
         RETVALUE(RFAILED);
      }

      /* check if this was the EOC tag */
      if( (unPkArray[0] == ST_EOC_TAG) && (unPkArray[1] == ST_EOC_LEN))
      {
         /* if already encountered another EOC encoding within this
            type eg. seqeunce within sequence, decrement the eocCntr flag */

         if (eocCntr)
         {
            /* increment the length, the message index and eoc nesting 
               level */ 
            curLen += EOC_TAG_LEN;
            msgIdx += EOC_TAG_LEN;
            eocCntr--;
            continue;
         }
         else
         {
            /* no more nesting, got the EOC tag we want for this element */

            *lfLen   = 1;         /* length of the length field */
            *len     = curLen;    /* length of the element */
            *eocFlag = TRUE;      /* eoc flag is set to true */

            RETVALUE(ROK);
         }
      } /* endif */

      /* If not the EOC tag, then it must be the tag of some other
         element, increment the message index & current length 
         by the size of the tag */
     
      /* st002.301 - Problem for more than one octet long tag processing */
     
      /* get the next  byte */
      if ((SCpyMsgFix(mBuf, msgIdx, 1, unPkArray, &i) != ROK) ||
          (i != 1))
      {
         /* st009.301 -Add- print debug information */
         STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
                "stFindLen:Error in indefinite form length decoding\n"));
         /* error in length decoding */
         RETVALUE(RFAILED);
      }

      /* If tag is more than one octet long */
      if ((unPkArray[0] & LONG_TAG_IND) == LONG_TAG_IND)
      {
        msgIdx = msgIdx + 1;
        curLen = curLen + 1;
      
        /* skip upto the end octet of the tag and copy tag field value */
        do 
        {
          if ((SCpyMsgFix(mBuf, msgIdx, 1, unPkArray, &i) != ROK) ||
          (i != 1))
          {
             /* st009.301 -Add- print debug information */
             STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
            "stFindLen:Length decode problem,where tag is multi-octet long\n"));
             /* error in length decoding */
             RETVALUE(RFAILED);
           }
           msgIdx = msgIdx + 1;
           curLen = curLen + 1;
        } while (unPkArray[0] & TAG_MORE_BIT);
      }
      else  /* If tag is only one octet long, skip it */
      {
         msgIdx = msgIdx + 1;
         curLen = curLen  + 1;
      }

      /* Increment the msgIdx by the length of the element, in case
         of EOC format, increment EOC nesting counter */

      if (stGetLen(mBuf, msgIdx, len, lfLen, eocFlag) != ROK)
      {
         /* st009.301 -Add- print debug information */
         STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
                "stFindLen:stGetLen execution failed\n"));
         RETVALUE(RFAILED);
      }

      if (*eocFlag == FALSE) 
      {
         /* short or long form of length encoding */
         curLen = curLen + *len + *lfLen; 
         msgIdx = msgIdx + *len + *lfLen; 
      }
      else
      {
         /* Indefinite form of length encoding, increment the length and
            the message index by the size of EOC length field (1 byte) */

         curLen = curLen + *lfLen; 
         msgIdx = msgIdx + *lfLen; 

         /* Increment the eoc nesting counter */
         eocCntr++;
      }
   } /* end while */
} /* end of stFindLen */


/*
*
*       Fun:   stZeroEv
*
*       Desc:  This function initializes all elements in the event structures
*              to zero.
*
*       Ret:   ROK     - Success
*              RFAILED - Failure
*
*       Notes: None
*
*       File:  ct_mf.c
*
*/
#ifdef ANSI
PUBLIC S16 stZeroEv
(
Data      *ev,         /* Event structure */
U8         evType,     /* Event structure type */
Swtch      pSwtch      /* Protocol Switch */
)
#else
PUBLIC S16 stZeroEv(ev, evType, pSwtch)
Data      *ev;         /* Event structure */
U8         evType;     /* Event structure type */
Swtch      pSwtch;     /* Protocol Switch */
#endif
{

   TRC2(stZeroEv)

   switch(evType)
   {
      /* Transaction portion Event structrue */
      case ST_TYP_TRN_PRTN:
         cmZero(ev, sizeof(StMsgEv));
         break;

      /* Dialogue portion Event structure */
      case ST_TYP_DLG_PRTN:
         switch(pSwtch)
         {
            case LST_SW_ITU88:
            case LST_SW_ITU92:
            case LST_SW_ITU96:
               cmZero(ev, sizeof(StItuDlgEv));
               break;

         }
         break;

      /* Component portion Event structure */
      case ST_TYP_CMP_PRTN:
         switch(pSwtch)
         {
            case LST_SW_ITU88:
            case LST_SW_ITU92:
            case LST_SW_ITU96:
               cmZero(ev, sizeof(StItuCompEv));
               break;

         }
         break;

      default:
         break;
   }

   RETVALUE(ROK);
}  /* End of stZeroEv */


/*
*
*       Fun:   stInitItuDlgEv
*
*       Desc:  This function Prepares  the ITU dialogue event structure for
*              dialogue portion encoding.
*
*       Ret:   ROK     - Success
*              RFAILED - Failure
*
*       Notes: None
*
*       File:  ct_mf.c
*
*/
#ifdef ANSI
PUBLIC S16 stInitItuDlgEv
(
StItuDlgEv    *dlgEv,        /* Dialogue portion event structure */
U8             apduType,     /* Dialogue APDU type */
StAcn         *acn,          /* Application context name */
TknBuf        *usrInfo,      /* User Information */
U8             result,       /* Result */
U8             reason,       /* Abort Reason */
U8             src           /* Dialogue source */
)
#else
PUBLIC S16 stInitItuDlgEv(dlgEv, apduType, acn, usrInfo, result, reason, src)
StItuDlgEv    *dlgEv;        /* Dialogue portion event structure */
U8             apduType;     /* Dialogue APDU type */
StAcn         *acn;          /* Application context name */
TknBuf        *usrInfo;      /* User Information */
U8             result;       /* Result */
U8             reason;       /* Abort Reason */
U8             src;          /* Dialogue source */
#endif
{
   TRC2(stInitItuDlgEv)

   cmZero((Data *)dlgEv, sizeof(StItuDlgEv));

   dlgEv->pres.pres          = TRUE;
   dlgEv->exPres.pres        = TRUE;

   dlgEv->dlgAsIdVal.pres    = TRUE;
   dlgEv->dlgAsIdVal.len     = 7;
   dlgEv->dlgAsIdVal.val[0]  = ST_DLG_ID_VAL_B0;
   dlgEv->dlgAsIdVal.val[1]  = ST_DLG_ID_VAL_B1;
   dlgEv->dlgAsIdVal.val[2]  = ST_DLG_ID_VAL_B2;
   dlgEv->dlgAsIdVal.val[3]  = ST_DLG_ID_VAL_B3;
   dlgEv->dlgAsIdVal.val[4]  = ST_DLG_ID_VAL_B4;
   dlgEv->dlgAsIdVal.val[5]  = ST_DLG_ID_VAL_B5_S;
   dlgEv->dlgAsIdVal.val[6]  = ST_DLG_ID_VAL_B6;

   if (apduType == ST_DLG_TYP_UNI)
   {
      dlgEv->dlgAsIdVal.val[5]  = ST_DLG_ID_VAL_B5_U;
   }

   dlgEv->apduPres.pres              = TRUE;
   dlgEv->dlgApdu.dlgType.pres       = TRUE;
   dlgEv->dlgApdu.dlgType.val        = apduType;
   dlgEv->dlgApdu.apdu.uni.pres.pres = TRUE;

   switch(apduType)
   {
      case ST_DLG_TYP_UNI:
      case ST_DLG_TYP_REQ:

         dlgEv->dlgApdu.apdu.uni.pVer.pres     = TRUE;
         dlgEv->dlgApdu.apdu.uni.pVer.len      = 2;
         dlgEv->dlgApdu.apdu.uni.pVer.val[0]   = ST_ITU_PVER_B0;
         dlgEv->dlgApdu.apdu.uni.pVer.val[1]   = ST_ITU_PVER_B1;

         dlgEv->dlgApdu.apdu.uni.acnPres.pres  = TRUE;
         cmCopy((U8 *)acn, (U8 *)&dlgEv->dlgApdu.apdu.uni.acn, sizeof(StAcn));

         dlgEv->dlgApdu.apdu.uni.usrInfo.pres  = usrInfo->pres;
         dlgEv->dlgApdu.apdu.uni.usrInfo.val   = usrInfo->val;

         break;

      case ST_DLG_TYP_RSP:

         dlgEv->dlgApdu.apdu.rsp.pVer.pres     = TRUE;
         dlgEv->dlgApdu.apdu.rsp.pVer.len      = 2;
         dlgEv->dlgApdu.apdu.rsp.pVer.val[0]   = ST_ITU_PVER_B0;
         dlgEv->dlgApdu.apdu.rsp.pVer.val[1]   = ST_ITU_PVER_B1;

         dlgEv->dlgApdu.apdu.rsp.acnPres.pres  = TRUE;
         cmCopy((U8 *)acn, (U8 *)&dlgEv->dlgApdu.apdu.rsp.acn, sizeof(StAcn));

         dlgEv->dlgApdu.apdu.rsp.resPres.pres  = TRUE;
         dlgEv->dlgApdu.apdu.rsp.result.pres   = TRUE;
         dlgEv->dlgApdu.apdu.rsp.result.val    = result;
         dlgEv->dlgApdu.apdu.rsp.diagPres.pres = TRUE;
         dlgEv->dlgApdu.apdu.rsp.resSrc.pres   = TRUE;
         dlgEv->dlgApdu.apdu.rsp.resSrc.val    = src;
         dlgEv->dlgApdu.apdu.rsp.infoPres.pres = TRUE;
         dlgEv->dlgApdu.apdu.rsp.reason.pres   = TRUE;
         dlgEv->dlgApdu.apdu.rsp.reason.val    = reason;

         dlgEv->dlgApdu.apdu.rsp.usrInfo.pres = usrInfo->pres;
         dlgEv->dlgApdu.apdu.rsp.usrInfo.val  = usrInfo->val;

         break;

      case ST_DLG_TYP_ABT:

         dlgEv->dlgApdu.apdu.abt.abrtSrc.pres = TRUE;
         dlgEv->dlgApdu.apdu.abt.abrtSrc.val  = src;
         dlgEv->dlgApdu.apdu.abt.usrInfo.pres = usrInfo->pres;
         dlgEv->dlgApdu.apdu.abt.usrInfo.val  = usrInfo->val;

         break;
   }

   RETVALUE(ROK);
}  /* End of stInitItuDlgEv */


/*
*
*       Fun:   stChkDlgEv
*
*       Desc:  This function Checks the correctness of the ITU dialogue event
*              structure.
*
*       Ret:   ROK     - Success
*              RFAILED - Failure
*
*       Notes: None
*
*       File:  ct_mf.c
*
*/
#ifdef ANSI
PRIVATE S16 stChkDlgEv
(
PTR            ev,           /* Dialogue portion event structure */
Swtch          pSwtch,       /* Protocol swicth */
U8            *abtCause      /* Local abort cause */
)
#else
PRIVATE S16 stChkDlgEv(ev, pSwtch, abtCause)
PTR            ev;           /* Dialogue portion event structure */
Swtch          pSwtch;       /* Protocol swicth */
U8            *abtCause;     /* Local abort cause */
#endif
{
   StItuDlgEv  *dlgEv;

   TRC2(stChkDlgEv)

   switch(pSwtch)
   {
       case LST_SW_ITU92:
       case LST_SW_ITU96:

          dlgEv = (StItuDlgEv *)ev;
          break;

       default:
          RETVALUE(ROK);
   }

   /* The default abort cause */
   *abtCause = ST_PABT_BD_DLGP;

   if ((dlgEv->dlgAsIdVal.len != 7)                   ||
       (dlgEv->dlgAsIdVal.val[0] != ST_DLG_ID_VAL_B0) ||
       (dlgEv->dlgAsIdVal.val[1] != ST_DLG_ID_VAL_B1) ||
       (dlgEv->dlgAsIdVal.val[2] != ST_DLG_ID_VAL_B2) ||
       (dlgEv->dlgAsIdVal.val[3] != ST_DLG_ID_VAL_B3) ||
       (dlgEv->dlgAsIdVal.val[4] != ST_DLG_ID_VAL_B4) ||
       (dlgEv->dlgAsIdVal.val[6] != ST_DLG_ID_VAL_B6) ||
       ((dlgEv->dlgAsIdVal.val[5] != ST_DLG_ID_VAL_B5_S) &&
        (dlgEv->dlgAsIdVal.val[5] != ST_DLG_ID_VAL_B5_U)))
   {
      RETVALUE(RFAILED);
   }

   if ((dlgEv->dlgAsIdVal.val[5] == ST_DLG_ID_VAL_B5_U) &&
       (dlgEv->dlgApdu.dlgType.val != ST_DLG_TYP_UNI))
   {
      RETVALUE(RFAILED);
   }

   if ((dlgEv->dlgAsIdVal.val[5] == ST_DLG_ID_VAL_B5_S) &&
       (dlgEv->dlgApdu.dlgType.val == ST_DLG_TYP_UNI))
   {
      dlgEv->dlgApdu.dlgType.val = ST_DLG_TYP_REQ;
   }

   /* Check if the dialogue apdu contains the supported Protocol Version */
   if ((dlgEv->dlgApdu.dlgType.val != ST_DLG_TYP_ABT) &&
       (dlgEv->dlgApdu.apdu.uni.pVer.pres) &&
       ((dlgEv->dlgApdu.apdu.uni.pVer.len != 2) ||
        (dlgEv->dlgApdu.apdu.uni.pVer.val[0] != ST_ITU_PVER_B0) ||
        (dlgEv->dlgApdu.apdu.uni.pVer.val[1] != ST_ITU_PVER_B1)))
   {
      *abtCause = ST_PABT_NC_DLGP;
      RETVALUE(RFAILED);
   }

   switch(pSwtch)
   {
      case LST_SW_ITU92:
      case LST_SW_ITU96:
         if ((dlgEv->dlgApdu.dlgType.val == ST_DLG_TYP_ABT) &&
             (dlgEv->dlgApdu.apdu.abt.abrtSrc.val != ST_ABT_SRC_SU) &&
             (dlgEv->dlgApdu.apdu.abt.abrtSrc.val != ST_ABT_SRC_SP))
         {
            RETVALUE(RFAILED);
         }
         if (dlgEv->dlgApdu.dlgType.val == ST_DLG_TYP_RSP)
         {
            /* Check the result value */
            switch(dlgEv->dlgApdu.apdu.rsp.result.val)
            {
               case ST_DLG_RES_ACC:
               case ST_DLG_RES_REJ:
                  break;

               default:
                  RETVALUE(RFAILED);
            }

            /* Check the diagonostic value */
            switch(dlgEv->dlgApdu.apdu.rsp.reason.val)
            {
               case ST_DLG_DIAG_NULL:
               case ST_DLG_DIAG_NORES:
               case ST_DLG_DIAG_NOACN:
                  break;

               default:
                  RETVALUE(RFAILED);
            }
         }
         break;

   }

   RETVALUE(ROK);
}  /* End of stChkDlgEv */


/*
*
*       Fun:   stEncUsrInfo
*
*       Desc:  This function encodes Usr Information only in the dialogue
*              portion
*
*       Ret:   ROK (encoding successful) 
*              RFAILED (general failure)
*
*       Notes: This function is used to encode the dialogue portion only in the
*              active state of the dialogue when there shouldn't be any
*              dialogue apdu present.
*
*       File:  ct_mf.c
*
*/
#ifdef ANSI
PUBLIC S16 stEncUsrInfo
(
TknBuf     *uiBuf,       /* User Information */
Swtch       pSwtch,      /* Protocol switch */
Buffer     *mBuf         /* Message buffer */
)
#else
PUBLIC S16 stEncUsrInfo(uiBuf, pSwtch, mBuf)
TknBuf     *uiBuf;       /* User Information */
Swtch       pSwtch;      /* Protocol switch */
Buffer     *mBuf;        /* Message buffer */
#endif
{

   TRC2(stEncUsrInfo)

   UNUSED(pSwtch);

   /* Put dialogue portion Tag and length */
   if (stPutTagLen(uiBuf->val, ST_ITU_DLG_PRTN_TAG) != ROK)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(uiBuf->val);
      /* st009.301 -Add- print debug information */
      STDBGP(ST_DBGMASK_ENCODE, (stCb.init.prntBuf,
             "stEncUsrInfo:stPutTagLen execution failed\n"));
      RETVALUE(RFAILED);
   }

   /* Now concatenate the user information buffer to the message buffer */
   if (SCatMsg(mBuf, uiBuf->val, M2M1) != ROK)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(uiBuf->val);
      /* st009.301 -Add- print debug information */
      STDBGP(ST_DBGMASK_ENCODE, (stCb.init.prntBuf,
             "stEncUsrInfo:stCatMsg execution failed\n"));
      RETVALUE(RFAILED);
   }

   /* st027.301 - Modify - Modify the user buf free mechanism */ 
   STFREEUSERBUF(uiBuf->val);

   RETVALUE(ROK);
}  /* End of stEncUsrInfo */


/*
*
*       Fun:   stDecUsrInfo
*
*       Desc:  This function decodes Usr Information from the dialogue portion
*
*       Ret:   ROK (encoding successful) 
*              RFAILED (general failure)
*
*       Notes: This function is used to decode the dialogue portion only in the
*              active state of the dialogue when there shouldn't be any
*              dialogue apdu present.
*
*       File:  ct_mf.c
*
*/
#ifdef ANSI
PUBLIC S16 stDecUsrInfo
(
Buffer    **uiBuf,       /* User Information */
Swtch       pSwtch,      /* Protocol switch */
Buffer     *mBuf,        /* Message buffer */
U8         *abtCause     /* Abort Cause */
)
#else
PUBLIC S16 stDecUsrInfo(uiBuf, pSwtch, mBuf, abtCause)
Buffer    **uiBuf;       /* User Information */
Swtch       pSwtch;      /* Protocol switch */
Buffer     *mBuf;        /* Message buffer */
U8         *abtCause;    /* Abort Cause */
#endif
{
   MsgLen     idx;       /* Index to the buffer */
   MsgLen     lfLen;     /* Length field Length */
   Bool       eocFlag;   /* Flag for indefinite form of length encoding */
   MsgLen     msgLen;    /* Message buffer length */
   StTag      tag;       /* Element tag */
   MsgLen     len;
   Data      *tmpArray;  /* Temporary array to remove dialogue portion */
   S16        ret;
   Buffer    *chkBuf;    /* Test buffer */
   Bool       bufFlag;
   /* st019.301 - Addition */
   Bool       bufFlag2;
   StItuDlgEv dlgEv;

   TRC2(stDecUsrInfo)

   /* Default abort cause */
   *abtCause = ST_PABT_BD_DLGP;

   idx     = 0;
   lfLen   = 0;
   eocFlag = FALSE;
   bufFlag = FALSE;
   /* st019.301 - Addition */
   bufFlag2 = FALSE;

   /* Find the length of the dialogue portion excluding tag and length field */
   if (stFindLen(mBuf, 1, &idx, &lfLen, &eocFlag) != ROK)
   {
      /* st009.301 -Add- print debug information */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stDecUsrInfo:stFindLen execution failed\n"));
      RETVALUE(RFAILED);
   }

   /* Total dialogue portion length */
   idx += lfLen + 1 + (eocFlag * EOC_TAG_LEN);

   /* Find length of dialogue portion and all the components, if any in mBuf */
   (Void)SFndLenMsg(mBuf, &msgLen);

   /* Check if buffer contains anything other than dialogue portion */
   if (msgLen != idx)
   {
      /* Allocate a new buffer to separate out the dialogue portion from
         mBuf */

      if (SGetMsg(stCb.init.region, stCb.init.pool, uiBuf) != ROK)
      {
         *abtCause = ST_PABT_LM_RSRC;
         RETVALUE(RFAILED);
      }

      bufFlag = TRUE;

      /* Allocate buffer to tmpArray to remove dialogue portion */
      tmpArray = stAlloc(idx + 1);

      if (tmpArray == (Data *)NULLP)
      {
         *abtCause = ST_PABT_LM_RSRC;
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(*uiBuf);
         RETVALUE(RFAILED);
      }

      /* Remove the dialogue portion from the buffer */
      if (SRemPreMsgMult(tmpArray, idx, mBuf) != ROK)
      {
         (Void)stFree(tmpArray, idx + 1);
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(*uiBuf);
         /* st009.301 -Add- print debug information */
         STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
                "stDecUsrInfo:SRemPreMsgMult execution failed\n"));
         RETVALUE(RFAILED);
      }

      /* Copy the dialogue portion to the dialogue buffer */
      ret = SAddPstMsgMult(tmpArray, (MsgLen)idx, *uiBuf);

#if (ERRCLASS & ERRCLS_ADD_RES)
      if (ret != ROK)
      {
         (Void)stFree(tmpArray, idx + 1);
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(*uiBuf);
         STLOGERROR(ERRCLS_ADD_RES, EST301, (ErrVal)ret,
                    "stDecUsrInfo: SAddPstMsgMult() Failed");
         RETVALUE(RFAILED);
      }
#endif

      /* Free the allocated buffer to tmpArray */
      (Void)stFree(tmpArray, idx + 1);
   }
   else
   {
      /* Only dialogue portion is there in mBuf, decode it */
      *uiBuf = mBuf;
   }

   /* Create a copy of the dialogue buffer to test the syntax of the dialogue
      portion */
   if (SCpyMsgMsg(*uiBuf, stCb.init.region, stCb.init.pool, &chkBuf) != ROK)
   {
      *abtCause = ST_PABT_LM_RSRC;
      if (bufFlag)
      {
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(*uiBuf);
      }
      RETVALUE(RFAILED);
   }
   
   /* There shouldn't be any dialogue apdu present */ 
   if (stDecDlg((PTR)&dlgEv, pSwtch, chkBuf, abtCause) != ROK)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(chkBuf);
      /* st019.301 - Addition, initialiation */
      bufFlag2 = TRUE;

      /* Remove dialogue portion tag and length */
      if ((stRemTagLen(*uiBuf, &tag, &len) == ROK) &&
          (tag == ST_ITU_DLG_PRTN_TAG))
      {
         RETVALUE(ROK);
      }
   }

   /* st019.301 - Addition, if chkBuf hasn't been deallocated, 
    * then deallocate it */
   if (!bufFlag2)
   {
      /* Deallocate the message buffers allocated in this function */
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(chkBuf);
   }
   if (bufFlag)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(*uiBuf);
   }

   RETVALUE(RFAILED);
}  /* End of stDecUsrInfo */


/*
*
*       Fun:   stEdcBuffer
*
*       Desc:  This function encodes/decodes an element of buffer type
*
*       Ret:   ROK (encoding successful) 
*              RFAILED (general failure)
*
*       Notes: To encode, this function concatenate the element buffer to the
*              end of the message buffer after putting tag and length of the
*              element. To decode, this function remove the element with tag
*              and length and put the contents into a buffer as part of the 
*              event structure.
*
*       File:  ct_mf.c
*
*/
#ifdef ANSI
PUBLIC S16 stEdcBuffer
(
CmAsnMsgCp    *msgCp             /* message control pointer */
)
#else
PUBLIC S16 stEdcBuffer(msgCp)
CmAsnMsgCp    *msgCp;            /* message control pointer */
#endif
{
   CmElmntDef   *elmntDef;      /* element definition */
   TknBuf       *evntStr;       /* pointer to event structure */
   MsgLen        msgLen;        /* Msg Buffer length */
   U8            flag;          /* protocol flag */
   S16           ret;           /* return value */

   TRC2(stEdcBuffer)

   elmntDef = *msgCp->elmntDef;            /* get the element defintion */ 
   evntStr  = (TknBuf *)msgCp->evntStr;    /* get the event structure */

   /* get the protocol flags from the database element defintion */
   flag = FLAG_TO_TYPE(elmntDef->flagp, msgCp->proType);

   /* Check if element is to be encoded */
   if (msgCp->edFlag == ENCODE_ELMNT)
   {
      U8       pkArray[10];    /* Array to encode the element */
      U16      idx = 0;        /* Index into the pkArray */
      U8       lfLen = 0;      /* length field length */

      /* Event structure is not present, return from here */
      if (evntStr->pres == FALSE)
      {
         /* Element is not present, skip it */
         msgCp->evntStr += sizeof(TknBuf);
         msgCp->elmntDef++;

         /* element is mandatory, error!! */
         if (flag == ELMNT_MAND)
         {
            CM_ASN_ERR(msgCp, CM_ASN_MAND_MIS, &elmntDef->tag);  
            RETVALUE(RFAILED);
         }
         else     /* It's OK, element is optional anyway */
         {
            RETVALUE(ROK);
         }
      }

      /* Event structure is present but buffer is NULL then encode the Tag with
         zero length */
      if ((evntStr->val == NULLP) && (elmntDef->tag.val[0]))
      {
         pkArray[idx++] = elmntDef->tag.val[0];
         pkArray[idx++] = 0;

         /* Add the Tag and zero length to the message buffer */
#ifdef CM_ASN_SS
         ret = SAddPstMsgMult(pkArray, (MsgLen)idx, msgCp->mBuf);
#else
         CM_ASN_ADD_PST_MULT(pkArray, idx, msgCp, &ret);
#endif /* CM_ASN_SS */

         if (ret != ROK)
         {
            CM_ASN_ERR(msgCp, CM_ASN_RES_ERR, NULLP);  
            RETVALUE(ret);
         }
         RETVALUE(ROK);
      }

      /* If element tag is NULL then don't encode tag and length */
      if (elmntDef->tag.val[0])
      {
         (Void)SFndLenMsg(evntStr->val, &msgLen);

         /* Check if the length can be fitted in a single octet */
         if (msgLen < 0x80)
         {
            pkArray[idx++] = (U8)msgLen;
         }
         else
         { /* Encode long form of length encoding */
            while(msgLen > 0)
            {
                pkArray[idx++] = (msgLen & 0xFF);   /* Copy the LSB */
                msgLen       >>= 8;                 /* Shift out the LSB */
                lfLen++;
            }
            pkArray[idx++] = 0x80 | lfLen;
         }

         /* encode the tag into the array */
         pkArray[idx++] = elmntDef->tag.val[0];

         /* encode the tag and length */
         ret = SAddPreMsgMult(pkArray, (MsgLen)idx, evntStr->val);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
         {
            STLOGERROR(ERRCLS_ADD_RES, EST302, (ErrVal)ret,
                       "stEdcBuffer: SAddPreMsgMult Failed");
            RETVALUE(ret);
         }
#endif
      }

#ifdef CM_ASN_NO_INDEF_LEN
      /* If no indefinite length encoding is to be done then defer
         the concatenating of the buffer and set the user action
         required flag to TRUE, so that the common ASN.1 encoder
         can call this function again to concatenate the buffer */
 
      msgCp->usrActReq = TRUE;
      (Void)SFndLenMsg(evntStr->val, &msgLen);
      (*msgCp->elmntDef)->maxLen = msgLen;
#else
      /* Concatenate the event buffer to the end of mBuf */
#ifdef CM_ASN_SS
      ret = SCatMsg(msgCp->mBuf, evntStr->val, M1M2);
#else
      CM_ASN_CAT_MSG(msgCp, evntStr->val, M1M2, &ret);
#endif /* CM_ASN_SS */
 
#if (ERRCLASS & ERRCLS_ADD_RES)
      if (ret != ROK)
      {
         STLOGERROR(ERRCLS_ADD_RES, EST303, (ErrVal)ret,
                    "stEdcBuffer: SCatMsg Failed");
         RETVALUE(ret);
      }
#endif
 
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(evntStr->val);
#endif /* CM_ASN_NO_INDEF_LEN */
   }
 
#ifdef CM_ASN_NO_INDEF_LEN
   else if (msgCp->edFlag == PROCESS_LENGTH)
   {
      /* Restore the element definition here */
      (*msgCp->elmntDef)->maxLen = MAX_LEN_NA;

      /* Concatenate the event buffer to the end of mBuf */
      ret = SCatMsg(msgCp->mBuf, evntStr->val, M1M2);
 
#if (ERRCLASS & ERRCLS_ADD_RES)
      if (ret != ROK)
      {
         STLOGERROR(ERRCLS_ADD_RES, EST304, (ErrVal)ret,
                    "stEdcBuffer: SCatMsg Failed");
         RETVALUE(ret);
      }
#endif

 /* st043.301 - Addition - Added   STFREEUSERBUF to handle memory leaks caused by patch st041.301 */
      STFREEUSERBUF(evntStr->val);
      RETVALUE(ROK);
   }
#endif /* CM_ASN_NO_INDEF_LEN */

   /* Decode the Buffer here */
   else
   {
      U8     *tmpArray;      /* Temporary array to decode the element */
      Data    tmpData;
      MsgLen  tmpLen;

      /* check if this is a duplicate element */
      if (evntStr->pres == TRUE)
      {
         CM_ASN_ERR(msgCp, CM_ASN_DUP_ELMNT, &elmntDef->tag);  
         RETVALUE(RFAILED);
      }
 
#if CM_ASN_SS
      (Void)SFndLenMsg(msgCp->mBuf, &msgLen);  /* Find Message length */
      ret = SExamMsg(&tmpData, msgCp->mBuf, 0);/* find the tag of the element */
#else
      CM_ASN_FND_LEN(msgCp, &msgLen);
      CM_ASN_EXAM_MSG(&tmpData, msgCp, 0, &ret);
#endif /* CM_ASN_SS */

      /* check the tag against the database defintion of the element */
      if ((msgLen == 0) ||
          ((elmntDef->tag.val[0]) &&
           (tmpData != elmntDef->tag.val[0])))
      {
         if (flag == ELMNT_MAND)
         {
            /* element is mandatory, cannot be skipped */
            CM_ASN_ERR(msgCp, CM_ASN_MAND_MIS, &elmntDef->tag);  
            RETVALUE(RFAILED);
         }
         else
         {
            /* element is not mandatory, can be skipped */
            msgCp->evntStr += sizeof(TknBuf);
            msgCp->elmntDef++;

            RETVALUE(ROK);
         }
      } /* end if */
   
      /* Allocate memory to a temporary array to remove the element from mBuf */
      tmpArray = stAlloc(msgLen);

      if (tmpArray == (Data *)NULLP)
      {
         CM_ASN_ERR(msgCp, CM_ASN_RES_ERR, NULLP);
         RETVALUE(RFAILED);
      }

      /* If Tag in the database definition of the element is NULL then
         remove everything from mBuf and put in the event structure */
      if (elmntDef->tag.val[0])
      {
         /* Remove the element from message buffer */
         if ((ret = cmRemPrim(msgCp->mBuf, msgCp, tmpArray, (U16 *)&tmpLen))
             != ROK)
         {
            /* st023.301: Addition, Free the memory for the temporary array */
            stFree(tmpArray, msgLen);
            CM_ASN_ERR(msgCp, CM_ASN_LEN_ERR, &elmntDef->tag);  
            RETVALUE(RFAILED);
         }

         /* Take care of the zero length encoding here */
         if (tmpLen == 0)
         {
            /* Free the memory allocated to the temporary array */
            stFree(tmpArray, msgLen);

            /* make the element present in the event structure */
            evntStr->pres = TRUE;
            evntStr->val  = NULLP;

            RETVALUE(ROK);
         }
      }
      else
      {
         MsgLen   lfLen;
         Bool     eocFlag;
 
         /* Find the length of the buffer excluding tag and length field */
         if (cmFindLen(msgCp, 1, &tmpLen, &eocFlag, &lfLen) != ROK)
         {
            /* st023.301: Addition, Free the memory for the temporary array */
            stFree(tmpArray, msgLen);
            CM_ASN_ERR(msgCp, CM_ASN_LEN_ERR, &elmntDef->tag);  
            RETVALUE(RFAILED);
         }
         /* Add the lenth of tag and length field as well */
         tmpLen += 1 + lfLen + (eocFlag * EOC_TAG_LEN);

#ifdef CM_ASN_SS
         ret = SRemPreMsgMult(tmpArray, tmpLen, msgCp->mBuf);
#else
         CM_ASN_REM_PRE_MULT(tmpArray, tmpLen, msgCp, &ret);
#endif /* CM_ASN_SS */
         if (ret != ROK)
         {
            stFree(tmpArray, msgLen);
            RETVALUE(RFAILED);
         }
      }

      /* Allocate buffer to the event structure */
      if ((ret = SGetMsg(stCb.init.region, stCb.init.pool, &evntStr->val))
          != ROK)
      {
         stFree(tmpArray, msgLen);
         CM_ASN_ERR(msgCp, CM_ASN_RES_ERR, NULLP);

         RETVALUE(RFAILED);
      }
 
      /* Copy the element contents to the event buffer */
      ret = SAddPstMsgMult(tmpArray, tmpLen, evntStr->val);
 
#if (ERRCLASS & ERRCLS_ADD_RES)
      if (ret != ROK)
      {
         stFree(tmpArray, msgLen);
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(evntStr->val);

         STLOGERROR(ERRCLS_ADD_RES, EST305, (ErrVal)ret,
                    "stEdcBuffer: SAddPstMsgMult Failed");

         RETVALUE(ret);
      }
#endif

      /* Free the memory allocated to the temporary array */
      stFree(tmpArray, msgLen);

      /* make the element present in the event structure */
      evntStr->pres = TRUE;

   }  /* End of else */
 
   /* Increment the event structure pointer to point to the next
      element in the event structure */
   cmIncPtr((PTR *)&msgCp->evntStr, sizeof(TknBuf));

   /* Increment the database pointer to the next element defintion */
   msgCp->elmntDef++;

   RETVALUE(ROK);
} /* stEdcBuffer */


/*
*
*       Fun:   stMapErrCode
*
*       Desc:  This function maps the error code returned by ASN.1 encoder/
*              decoder to the P-Abort Cause or problem code depending on the
*              type of the message portion is being decoded.
*
*       Ret:   P-Abort Cause or problem code
*
*       Notes: None
*
*       File:  ct_mf.c
*
*/
#ifdef ANSI
PRIVATE U8 stMapErrCode
(
CmAsnErr   *err,        /* Error structure returned by ASN.1 module */
U8          prtnType,   /* Message portion type */
Swtch       pSwtch      /* Protocol Switch */
)
#else
PRIVATE U8 stMapErrCode(err, prtnType, pSwtch)
CmAsnErr   *err;        /* Error structure returned by ASN.1 module */
U8          prtnType;   /* Message portion type */
Swtch       pSwtch;     /* Protocol Switch */
#endif
{
   TRC2(stMapErrCode)

   switch(pSwtch)
   {
      case LST_SW_ITU88:
      case LST_SW_ITU92:
      case LST_SW_ITU96:


         switch(err->errCode)
         {
            case CM_ASN_MAND_MIS:
            case CM_ASN_TAG_ERR:
            case CM_ASN_UNDEF_PARAM:
            case CM_ASN_DUP_ELMNT:

               switch(prtnType)
               {
                  case ST_TYP_TRN_PRTN:
                     /* Incorrect Transaction portion */
                     RETVALUE(ST_PABT_IN_TRNP);

                  case ST_TYP_CMP_PRTN:
                     /* Mistyped component */
                     RETVALUE(ST_GEN_MT_COMP);
               }
               break;

            /* st016.301 -Add,Modify -For component portion, return 
             * problem code as ST_GEN_MT_COMP instead of 
             * ST_GEN_BD_COMP 
             */
            case CM_ASN_LEN_ERR:
            case CM_ASN_EXTRA_PARAM:

               switch(prtnType)
               {
                  case ST_TYP_TRN_PRTN:
                     /* Badly structured Transaction portion */
                     RETVALUE(ST_PABT_BD_TRNP);

                  case ST_TYP_CMP_PRTN:
                     /* st016.301 -Modify- change return value as mistyped
                      * component
                      */
                     /* Mistyped Component */
                     RETVALUE(ST_GEN_MT_COMP);
               }
               break;

            case CM_ASN_RES_ERR:

               switch(prtnType)
               {
                  case ST_TYP_TRN_PRTN:
                     /* Resource Limitation */
                     RETVALUE(ST_PABT_LM_RSRC);
               }
               break;

            default:
               break;
         }
         break;

      default:
         break;
   }

   RETVALUE(ST_PCODE_INVALID);
}  /* End of stMapErrCode */


/*
*
*       Fun:   stGetMsgDef
*
*       Desc:  This function returns the database definition for component
*              or dialogue portion.
*
*       Ret:   Pointer to the Database definition.
*
*       Notes: None
*
*       File:  ct_mf.c
*
*/
#ifdef ANSI
PUBLIC  PTR *stGetMsgDef
(
U8      defType,    /* Definition type, component or dialogue */
Swtch   pSwtch      /* Protocol Switch */
)
#else
PUBLIC  PTR *stGetMsgDef(defType, pSwtch)
U8      defType;    /* Definition type, component or dialogue */
Swtch   pSwtch;     /* Protocol Switch */
#endif
{
   TRC2(stGetMsgDef)

   switch(pSwtch)
   {

       case LST_SW_ITU88:
       case LST_SW_ITU92:
      case LST_SW_ITU96:


               RETVALUE((PTR *)stMsgDbDef[defType]);
               break;
   }

   RETVALUE(NULLP);
}  /* End of stGetMsgDef */


/*
*
*       Fun:    stGetMsgType
*
*       Desc:   Maps message type tag to the message type
*
*       Ret:    Message Type
*
*       Notes:  None
*
*       File:   ct_mf.c
*
*/
#ifdef ANSI
PRIVATE U8 stGetMsgType
(
StTag    tag         /* Message Tag */
)
#else
PRIVATE U8 stGetMsgType(tag)
StTag    tag;        /* Message Tag */
#endif
{
   TRC2(stGetMsgType)

   switch(tag)
   {
      case ST_ITU_MSG_UNI_TAG:
         RETVALUE(ST_MSG_TYP_UNI);

      case ST_ITU_MSG_BGN_TAG:
         RETVALUE(ST_MSG_TYP_BGN);

      case ST_ITU_MSG_CNT_TAG:
         RETVALUE(ST_MSG_TYP_CNT);

      case ST_ITU_MSG_END_TAG:
         RETVALUE(ST_MSG_TYP_END);

      case ST_ITU_MSG_ABT_TAG:
         RETVALUE(ST_MSG_TYP_PABT);


      default:
         RETVALUE(ST_MSG_TYP_UNK);
   }

}  /* End of stGetMsgType */


/*
*
*       Fun:    stChkPAbtCauseVal
*
*       Desc:   Checks the correctness of P-Abort Cause value
*
*       Ret:    ROK     - If pAbtCause is recognized
*               RFAILED - if pAbtCause is unrecognized
*
*       Notes:  None
*
*       File:   ct_mf.c
*
*/
#ifdef ANSI
PRIVATE U16 stChkPAbtCauseVal
(
U8       pAbtCause,
Swtch    pSwtch
)
#else
PRIVATE U16 stChkPAbtCauseVal(pAbtCause, pSwtch)
U8       pAbtCause;
Swtch    pSwtch;
#endif
{
   TRC2(stChkPAbtCauseVal)

   switch(pSwtch)
   {
      case LST_SW_ITU88:
      case LST_SW_ITU92:
      case LST_SW_ITU96:

         switch(pAbtCause)
         {
            case ST_PABT_UR_MSGT:
            case ST_PABT_UR_TRID:
            case ST_PABT_BD_TRNP:
            case ST_PABT_IN_TRNP:
            case ST_PABT_LM_RSRC:
               RETVALUE(ROK);

            default:
               RETVALUE(RFAILED);
         }
         break;


   }

   RETVALUE(RFAILED);
}  /* End of stChkPAbtCauseVal */


/*
*
*       Fun:    stChkProbCodeVal
*
*       Desc:   Checks the correctness of Problem Code
*
*       Ret:    ROK     - If problem code is recognized
*               RFAILED - if problem code is unrecognized
*
*       Notes:  None
*
*       File:   ct_mf.c
*
*/
#ifdef ANSI
PRIVATE U16 stChkProbCodeVal
(
U8       probType,
U8       probCode,
Swtch    pSwtch
)
#else
PRIVATE U16 stChkProbCodeVal(probType, probCode, pSwtch)
U8       probType;
U8       probCode;
Swtch    pSwtch;
#endif
{
   TRC2(stChkProbCodeVal)

   switch(pSwtch)
   {
      case LST_SW_ITU88:
      case LST_SW_ITU92:
      case LST_SW_ITU96:

         switch(probType)
         {
            case ST_PROB_TYP_GEN:
               switch(probCode)
               {
                  case ST_GEN_UR_COMP:
                  case ST_GEN_MT_COMP:
                  case ST_GEN_BD_COMP:
                     RETVALUE(ROK);
               }
               break;

            case ST_PROB_TYP_INV:
               switch(probCode)
               {
                  case ST_INV_DP_IVID:
                  case ST_INV_UR_OPRC:
                  case ST_INV_MT_PARM:
                  case ST_INV_LM_RSRC:
                  case ST_INV_IT_RLSE:
                  case ST_INV_UR_LKID:
                  case ST_INV_UX_LRSP:
                  case ST_INV_UX_LOPR:
                     RETVALUE(ROK);
               }
               break;

            case ST_PROB_TYP_RES:
               switch(probCode)
               {
                  case ST_RES_UR_IVID:
                  case ST_RES_UX_RRES:
                  case ST_RES_MT_PARM:
                     RETVALUE(ROK);
               }
               break;

            case ST_PROB_TYP_ERR:
               switch(probCode)
               {
                  case ST_ERR_UR_IVID:
                  case ST_ERR_UX_RERR:
                  case ST_ERR_UR_ERRC:
                  case ST_ERR_UX_ERRC:
                  case ST_ERR_MT_PARM:
                     RETVALUE(ROK);
               }
               break;
         }
         break;


   }

   RETVALUE(RFAILED);
}  /* End of stChkProbCodeVal */


/*
*
*       Fun:    stU32ToStr
*
*       Desc:   Convert a U32 value to String
*
*       Ret:    ROK        Success
*
*       Notes:  If len contains a non-zero value then "len" number of bytes
*               are copied to the string by inserting 0 value octet,
*               if required.
*
*       File:   ct_mf.c
*
*/
#ifdef ANSI
PRIVATE S16 stU32ToStr
(
U32      val,         /* value to be converted into string */
U8      *str,         /* String */
MsgLen  *len,         /* no of octets copied */
U8       order        /* flag indicates whether to put MSB or LSB first */
)
#else
PRIVATE S16 stU32ToStr(val, str, len, order)
U32      val;         /* value to be converted into string */
U8      *str;         /* String */
MsgLen  *len;         /* no of octets copied */
U8       order;       /* flag indicates whether to put MSB or LSB first */
#endif
{
   U8       tmpStr[sizeof(U32)];  /* Temporary string */
   MsgLen   i, j;

   TRC2(stU32ToStr)

   /* Take care of value 0 here */
   if ((val == 0) && (*len == 0))
   {
       str[0] = 0;
      *len    = 1;

       RETVALUE(ROK);
   }

   for (i = 0; val > 0;)
   {
       tmpStr[i++] = (Data)(val & 0xFF);   /* Copy the LSB */
       val >>= 8;                          /* Move the next byte */
   }

   /* If len is not zero and less than the number of bytes already copied
      in the string then insert extra null bytes */
   if ((*len != 0) && (*len > i))
   {
      for (; i < *len; )
      {
          tmpStr[i++] = (Data)0;
      }
   }

   /* Return the number of bytes copied in the string */
   *len = i;

   if (order == TRUE)   /* Put MSB first */
   {
      for (i = *len, j = 0; i > 0; i--, j++)
      {
          str[j] = tmpStr[i-1];
      }
   }
   else                 /* Put LSB first */
   {
      for (i = 0; i < *len; i++)
      {
          str[i] = tmpStr[i];
      }
   }

   RETVALUE(ROK);
}  /* End of stU32ToStr */

/* st016.301 -Add- routine stSetProbCode */

/*
*
*       Fun:    stSetProbCode
*
*       Desc:   Set the problem code in case of invalid encoding of invoke
*               component.
*
*       Ret:    None
*
*       Notes:  In case of invoke component encoding, if the encoder returns
*               error code as Mandatory Element Missing then this routine
*               will set the problem code to badly structured component
*
*       File:   ct_mf.c
*
*/
#ifdef ANSI
PRIVATE Void stSetProbCode
(
PTR       compEv,       /* Component Event Structure */
Bool      *probCode,    /* Problem Code */
Swtch     pSwtch        /* Protocol Switch */
)
#else
PRIVATE Void stSetProbCode(compEv, probCode, pSwtch)
PTR       compEv;       /* Component Event Structure */
Bool      *probCode;    /* Problem Code */
Swtch     pSwtch;       /* Protocol Switch */
#endif
{
   StItuCompEv *stItuCompEvnt;
   
   TRC2(stSetProbCode)

   switch(pSwtch)
   {
      case LST_SW_ITU88:
      case LST_SW_ITU92:
      case LST_SW_ITU96:

         
         /* Access the compEv passed to the routine */
         stItuCompEvnt = (StItuCompEv *)compEv;      
         if (stItuCompEvnt->compType.pres)
         {
            /* Check whether it is an invoke component */     
            if (stItuCompEvnt->compType.val == STU_INVOKE)
            {
               /* Check if any mandatory element is not decoded, the pres field
                * will be FALSE 
                */
               if ((stItuCompEvnt->comp.inv.invokeId.pres == FALSE) || 
                  (stItuCompEvnt->comp.inv.oprCode.pres == FALSE))
               {
                  /* Overwrite the problem code to badly structured comp. */
                  *probCode =  ST_GEN_BD_COMP;    
               }
            }
         }
         break;
      default:
         break;
   } /* End of switch */
   RETVOID;
}

/********************************************************************30**

         End of file:     ct_mf.c@@/main/4 - Fri Nov 17 10:34:46 2000

*********************************************************************31*/

/********************************************************************40**

       Notes:

*********************************************************************41*/



/********************************************************************50**

*********************************************************************51*/



/********************************************************************60**

          Revision history:

*********************************************************************61*/


/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      nj   1. initial release.
1.2          ---      nj   1. correcting typo of ss7_ans92   
             st001.27 nj   2. Fixed a bug in function stEdcBuffer.
             st002.27 nj   3. Fixed the code to support the user abort
                              information to be included in a itu88 u-abort
                              message.
1.3          st005.27 nj   1. Added one more check for the component portion
                              length and dialogue portion length encoding in the
                              stDecMsg and stDecAnsiMsg.
             st006.27 nj   2. Check if component portion length is zero.

             ---      nj   3. Added support for ITU-96.
  
1.4          st001.28 nj   1. Added changes to support only definite length
                              encoding by the ASN.1 encoder.

             st001.28      2. Fixed the code to take care of transaction id value 0

1.5          st007.28 1.   Fixed the user buffer encoding when
                              CM_ASN_NO_INDEF_LEN flag is defined.

1.6          st010.28 nj   1. Changed to return same number of octets in
                              destination transaction id as received.
/main/4      ---      nj   1. Changes for distributed FTHA
3.1+       st002.301 zr,as 1. Fix for processing tags more than 
                              one octet long

3.1+        st005.301 zr   1. Rolling Upgrade Feature
                           - Modified #if ANSI section to make it
                             available for ANSI88, ANSI92, ANSI96.
                           - File mrs.x included under ZT  

3.1+         st009.301 zr   1. Add more error logs and debug prints throughout
                               the entire file.
3.1+         st010.301 akp  1. Modified with proper Range Checks for reason and
                              result value of response Message as per ETSI specs. 
3.1+         st013.301 akp  1. Modified in the range check for warnings 
                              during compile time for reason and result values.
3.1+         st015.301  zr  1.In stChkDlg routine logic updated for compiler
                              warning. 
                            2. In stEncMsg, stFndOrgTid routines variables
                            are initialized and cheacked to avoid O2 compilation
                            warnings.
                            3. Protocol switch value is checked for invalid 
                            value.

3.1+         st016.301 zr  1. In stDecComp routine, a flag is set after 
                              decoding the component portion of the message.
                              If the routine - stDecComp fails before
                              decoding the component, the flag wont be
                              set.
                           2. stSetProbCode routine is added to set problem
                              code for invoke component encoding problems
                           3. In stDecComp routine, for Mandatory element
                              missing problem, stSetProbCode routine is called
                           4. In stMapErrCode routine, for component
                              portion of the message, if ASN error is with
                              length field or for exta parameter, the problem 
                              code is set as mistyped component instead of badly
                              structured component problem code, as was set 
                              earlier.
 
3.1+         st019.301 jz  1. Fixed double de-allocation problem in 
                              stDecUsrInfo().
                             
3.1+         st021.301 jz  1. Allow Problem code "Permission to release 
                              problem" and "Resource Unavailable" in 
                              stChkProbCodeVal().

3.1+         st023.301 jz  1. In stEdcBuffer(), added code to free 
                              memory assigned to temp array.
                           2. Added code to validate Bellcore problem code.
3.1+         st027.301 ds  1. Replace SPutMsg call with STFREEUSERBUF call to avoid
                              mem corruption on double deallocation.
3.1+       st034.301   yk   1. Code Added for SS_MULTIPLE_PROCS
3.1+         st037.301 mkm  1. Removal of warnings.
                            2. Change from hardcode variable size to MsgLen for LONG_MSG flag.
3.1+         st041.301 mkm  1. Removed STFREEUSERBUF to handle double deallocation of user buffer.
3.1+         st043.301 mkm  1. Addition of STFREEUSERBUF to handle memory leak caused due to patch st041.301.
3.1+         st044.301 mkm  1. Addition of check in stGetLen() if element length
                               is greater than total message length.
                            2. Addition for check in stGetLen() if length of length
                               is exceeding limit.   
*********************************************************************91*/
