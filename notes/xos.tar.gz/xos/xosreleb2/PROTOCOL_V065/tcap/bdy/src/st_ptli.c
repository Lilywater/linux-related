/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     tcap - portable - lower interface
  
     Type:     C source file
  
     Desc:     C source code for the TCAP lower interface primitives

     File:     st_ptli.c
  
     Sid:      st_ptli.c@@/main/13 - Fri Nov 17 10:34:15 2000
   
     Prg:      nj
  
*********************************************************************21*/

  
/*
The following functions are provided in this file:

     StLiSptBndReq      st - lower interface - Bind Request
     StLiSptUBndReq     st - lower interface - Unbind Request
     StLiSptUDatReq     st - lower interface - Unit Data Request
     StLiSptCordReq     st - lower interface - Coordination Request
     StLiSptCordRsp     st - lower interface - Coordination Response
     StLiSptSteReq      st - lower interface - SSN State change Request

It should be noted that not all of these functions may be required
by a particular data link layer service user.

It is assumed that the following functions are provided in TCAP:

     StLiSptUDatInd     st - lower interface - Unit Data Indication
     StLiSptStaInd      st - lower interface - Status Indication
     StLiSptCordInd     st - lower interface - Coordination Indication
     StLiSptCordCfm     st - lower interface - Coordination Confirm
     StLiSptSteInd      st - lower interface - State Indication
     StLiSptPCSteInd    st - lower interface - Point Code State Indication
     StLiSptBndCfm      st - lower interface - Bind Confirm
*/


/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000011     Multiprocessor Operating System
*     1000030     SS7 - SCCP
*
*/
 
   
/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* Common timer */
#include "cm_ss7.h"        /* ss7 layer */
#include "cm_hash.h"       /* Common hash */
#include "cm_err.h"        /* common error */
#include "spt.h"           /* Tcap Lower interface */
#include "stu.h"           /* Tcap upper interface */
#include "lst.h"           /* Layer management specific defines */
#include "st.h"            /* TCAP layer defines */
#include "st_err.h"        /* TCAP layer Error defines */

#ifdef ST_FTHA
#include "sht.h"           /* SHT */
#include "mrs.h"           /* MRS */
#endif /* ST_FTHA */

#ifdef ZT
#include "cm_ftha.h"
#include "cm_pftha.h"
#include "cm_psfft.h"
#endif /* ZT */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* Common timer */
#include "cm_ss7.x"        /* common ss7 */
#include "cm_hash.x"       /* Common hash */
#include "spt.x"           /* Tcap Lower interface */
#include "stu.x"           /* Tcap upper interface */
#include "lst.x"           /* Layer management specific structures */
#include "st_mf.x"         /* Tcap */

#ifdef ZT
#include "cm_ftha.x"
#include "cm_pftha.x"
#include "cm_psfft.x"
/* st005.301 - Added - mrs.x included here */
#include "mrs.x"           /* MRS */
#endif /* ZT */

#ifdef ST_FTHA
#include "sht.x"           /* SHT */
/* st005.301 - Deleted - mrs.x included under ZT */
#endif /* ST_FTHA */

#include "st.x"            /* TCAP layer specific structures */



/* local defines */

/* local externs */
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifndef SS_MULTIPLE_PROCS
EXTERN  StCb   stCb;       /* TCAP layer control block */
#endif /* SS_MULTIPLE_PROCS */

/* forward references */
PRIVATE S16 PtLiSptBndReq  ARGS((Pst         *pst,
                                 SuId         suId,
                                 SpId         spId,
                                 Ssn          ssn));

PRIVATE S16 PtLiSptUbndReq ARGS((Pst         *pst,
                                 SpId         spId,
                                 Reason       reason));

PRIVATE S16 PtLiSptUDatReq ARGS((Pst         *pst,
                                 SpId         spId,
                                 SpUDatEvnt  *event,
                                 Buffer      *mBuf));

PRIVATE S16 PtLiSptCordReq ARGS((Pst *pst, SpId spId, Ssn aSsn));
PRIVATE S16 PtLiSptCordRsp ARGS((Pst *pst, SpId spId, Ssn aSsn));
PRIVATE S16 PtLiSptSteReq  ARGS((Pst *pst, SpId spId, Ssn aSsn, U8 uStat));

#ifdef SPT2
PRIVATE S16 PtLiSptStaReq  ARGS((Pst *pst, SpId spId, U8 status, Dpc dpc,
                                 Ssn aSsn));
#endif /* SPT2 */


/* packing functions */

/* functions in other modules */
  
/* public variable declarations */

/* private variable declarations */


/*

The following matrices define the mapping between the primitives
called by the lower interface of TCAP and its providers (most likely
SCCP).

The parameter MAXSTLI defines the maximum number of service providers 
below TCAP. There is an array of functions per primitive
invoked by TCAP. Every array is MAXSTLI long (i.e. there
are as many functions as the number of service providers plus loosely coupled).
 
The dispatching is performed by the configurable variable: selector.
The selector is configured on a per SAP basis.

The selectors are:

   0 - loosely coupled - (#define LCSTLISPT)
   1 - tightly coupled - SS7 SCCP (#define SP)
   2 - tightly coupled - SIGTRAN SUA (#define SU)
  

*/



/* Bind Request primitive */

PRIVATE SptBndReq stLiSptBndReqMt[MAXSTLI] =
{
#ifdef LCSTLISPT
   cmPkSptBndReq,      /* 0 - loosely coupled */
#else
   PtLiSptBndReq,      /* 0 - tightly coupled, portable */
#endif

/*  Modified by xingzhou.xu 2006/03/24 for L3 test */
#if (defined(SP) || defined (L3))
   SpUiSptBndReq,       /* 1 - tightly coupled, SCCP */
#else
   PtLiSptBndReq,       /* 1 - tightly coupled, portable */
#endif

#ifdef SU
   SuUiSptBndReq       /* 2 - tightly coupled, SUA */
#else
   PtLiSptBndReq       /* 2 - tightly coupled, portable */
#endif
};



/* Unbind Request primitive */

PRIVATE SptUbndReq stLiSptUbndReqMt[MAXSTLI] =
{
#ifdef LCSTLISPT
   cmPkSptUbndReq,     /* 0 - loosely coupled */
#else
   PtLiSptUbndReq,     /* 0 - tightly coupled, portable */
#endif

#if (defined(SP) || defined (L3))
   SpUiSptUbndReq,      /* 1 - tightly coupled, SCCP */
#else
   PtLiSptUbndReq,      /* 1 - tightly coupled, portable */
#endif

#ifdef SU
   SuUiSptUbndReq       /* 2 - tightly coupled, SUA */
#else
   PtLiSptUbndReq       /* 2 - tightly coupled, portable */
#endif
};



/* Data Request primitive */

PRIVATE SptUDatReq stLiSptUDatReqMt[MAXSTLI] =
{
#ifdef LCSTLISPT
   cmPkSptUDatReq,     /* 0 - loosely coupled */
#else
   PtLiSptUDatReq,     /* 0 - tightly coupled, portable */
#endif

#if (defined(SP) || defined (L3))
   SpUiSptUDatReq,      /* 1 - tightly coupled, SCCP */
#else
   PtLiSptUDatReq,      /* 1 - tightly coupled, portable */
#endif

#ifdef SU
   SuUiSptUDatReq       /* 2 - tightly coupled, SUA */
#else
   PtLiSptUDatReq       /* 2 - tightly coupled, portable */
#endif
};



/* Ste Request primitive */

PRIVATE SptSteReq stLiSptSteReqMt[MAXSTLI] =
{
#ifdef LCSTLISPT
   cmPkSptSteReq,      /* 0 - loosely coupled */
#else
   PtLiSptSteReq,      /* 0 - tightly coupled, portable */
#endif

#if (defined(SP) || defined (L3))
   SpUiSptSteReq,       /* 1 - tightly coupled, SCCP */
#else
   PtLiSptSteReq,       /* 1 - tightly coupled, portable */
#endif

#ifdef SU
   SuUiSptSteReq       /* 2 - tightly coupled, SUA */
#else
   PtLiSptSteReq       /* 2 - tightly coupled, portable */
#endif
};



/* Cord Request primitive */

PRIVATE SptCordReq stLiSptCordReqMt[MAXSTLI] =
{
#ifdef LCSTLISPT
   cmPkSptCordReq,      /* 0 - loosely coupled */
#else
   PtLiSptCordReq,      /* 0 - tightly coupled, portable */
#endif

#if (defined(SP) || defined (L3))
   SpUiSptCordReq,       /* 1 - tightly coupled, SCCP */
#else
   PtLiSptCordReq,       /* 1 - tightly coupled, portable */
#endif

#ifdef SU
   SuUiSptCordReq       /* 2 - tightly coupled, SUA */
#else
   PtLiSptCordReq       /* 2 - tightly coupled, portable */
#endif
};



/* Cord Response primitive */

PRIVATE SptCordRsp stLiSptCordRspMt[MAXSTLI] =
{
#ifdef LCSTLISPT
   cmPkSptCordRsp,      /* 0 - loosely coupled */
#else
   PtLiSptCordRsp,      /* 0 - tightly coupled, portable */
#endif

#if (defined(SP) || defined (L3))
   SpUiSptCordRsp,       /* 1 - tightly coupled, SCCP */
#else
   PtLiSptCordRsp,       /* 1 - tightly coupled, portable */
#endif

#ifdef SU
   SuUiSptCordRsp       /* 2 - tightly coupled, SUA */
#else
   PtLiSptCordRsp       /* 2 - tightly coupled, portable */
#endif
};



/* Status request primitive */

#ifdef SPT2
PRIVATE SptStaReq stLiSptStaReqMt[MAXSTLI] =
{
#ifdef LCSTLISPT
   cmPkSptStaReq,       /* 0 - loosely coupled */
#else
   PtLiSptStaReq,       /* 0 - tightly coupled, portable */
#endif

#if (defined(SP) || defined (L3))
SpUiSptStaReq,        /* 1 - tightly coupled, SCCP */
#else
   PtLiSptStaReq,        /* 1 - tightly coupled, portable */
#endif

#ifdef SU
   SuUiSptStaReq       /* 2 - tightly coupled, SUA */
#else
   PtLiSptStaReq       /* 2 - tightly coupled, portable */
#endif
};
#endif /* SPT2 */
  

/*
 *     support functions
 */

/*
*     lower interface functions
*/

  
/*
*
*       Fun:   lower interface - SPT Bind Request
*
*       Desc:  This function resolves the Spt Bind Request primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 StLiSptBndReq
(
Pst    *pst,                    /* post structure */
SuId    suId,                   /* service user id */
SpId    spId,                   /* service provider id */
Ssn     ssn                     /* signaling system number */
)
#else
PUBLIC S16 StLiSptBndReq(pst, suId, spId, ssn)
Pst    *pst;                    /* post structure */
SuId    suId;                   /* service user id */
SpId    spId;                   /* service provider id */
Ssn     ssn;                    /* signaling system number */
#endif
{
   S16    ret;

   TRC3(StLiSptBndReq)

   STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
          "StLiSptBndReq:suId(%d), spId(%d)\n", suId, spId));

   switch (pst->dstEnt)
   {
#ifdef DP
      case ENTSP:
         if (pst->route == RTE_PROTO)
         {
            ret = (*stLiSptBndReqMt[pst->selector])(pst, suId, spId, ssn);
         }
         else
         {
            ret = DpUiSptBndReq(pst, suId, spId, ssn);
         }
         break;
#endif /* DP */

      default:
         /* jump to specific primitive in service user, depending on selector 
            configured */

         ret = (*stLiSptBndReqMt[pst->selector])(pst, suId, spId, ssn);
         break;
   }

   RETVALUE(ret);

} /* end of StLiSptBndReq */

  

/*
*
*       Fun:   lower interface SPT - Unbind Request
*
*       Desc:  This function resolves the Spt Unbind Request primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 StLiSptUbndReq
(
Pst    *pst,                    /* post structure */
SpId    spId,                   /* service provider id */
Reason  reason                  /* reason */
)
#else
PUBLIC S16 StLiSptUbndReq(pst, spId, reason)
Pst    *pst;                    /* post structure */
SpId    spId;                   /* service provider id */
Reason  reason;                 /* reason */
#endif
{
   S16    ret;

   TRC3(StLiSptUbndReq)

   switch (pst->dstEnt)
   {
#ifdef DP
      case ENTSP:
         if (pst->route == RTE_PROTO)
         {
            ret = (*stLiSptUbndReqMt[pst->selector])(pst, spId, reason);
         }
         else
         {
            ret = DpUiSptUbndReq(pst, spId, reason);
         }
         break;
#endif /* DP */

      default:
         /* jump to specific primitive in service user, depending on selector 
            configured */

         ret = (*stLiSptUbndReqMt[pst->selector])(pst, spId, reason);
         break;
   }

   RETVALUE(ret);

} /* end of StLiSptUbndReq */


/*
*
*       Fun:   lower interface - SPT Data Request
*
*       Desc:  This function resolves the SPT Unit Data Request primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 StLiSptUDatReq
(
Pst         *pst,               /* post structure */
SpId         spId,              /* service provider id */
SpUDatEvnt  *event,             /* SCCP event */
Buffer      *mBuf               /* message buffer */
)
#else
PUBLIC S16 StLiSptUDatReq(pst, spId, event, mBuf)
Pst         *pst;               /* post structure */
SpId         spId;              /* service provider id */
SpUDatEvnt  *event;             /* SCCP event */
Buffer      *mBuf;              /* message buffer */
#endif
{
   S16    ret;

   TRC3(StLiSptUDatReq)

   switch (pst->dstEnt)
   {
#ifdef DP
      case ENTSP:
         if (pst->route == RTE_PROTO)
         {
            ret = (*stLiSptUDatReqMt[pst->selector])(pst, spId, event, mBuf);
         }
         else
         {
            ret = DpUiSptUDatReq(pst, spId, event, mBuf);
         }
         break;
#endif /* DP */

      default:
         /* jump to specific primitive in service user, depending on selector 
            configured */

         ret = (*stLiSptUDatReqMt[pst->selector])(pst, spId, event, mBuf);
         break;
   }

   RETVALUE(ret);

} /* end of StLiSptUDatReq */

  

/*
*
*       Fun:   lower interface - SPT SSN State request 
*
*       Desc:  This function resolves the Spt SSN State Request primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 StLiSptSteReq
(
Pst    *pst,                    /* post structure */
SpId    spId,                   /* service provider id */
Ssn     aSsn,                   /* affected subsystem number */
UStat   uStat                   /* User Status */
)
#else
PUBLIC S16 StLiSptSteReq(pst, spId, aSsn, uStat)
Pst    *pst;                    /* post structure */
SpId    spId;                   /* service provider id */
Ssn     aSsn;                   /* affected subsystem number */
UStat   uStat;                  /* User Status */
#endif
{
   S16    ret;

   TRC3(StLiSptSteReq)

   switch (pst->dstEnt)
   {
#ifdef DP
      case ENTSP:
         if (pst->route == RTE_PROTO)
         {
            ret = (*stLiSptSteReqMt[pst->selector])(pst, spId, aSsn, uStat);
         }
         else
         {
            ret = DpUiSptSteReq(pst, spId, aSsn, uStat);
         }
         break;
#endif /* DP */

      default:
         /* jump to specific primitive in service user, depending on selector 
            configured */

         ret = (*stLiSptSteReqMt[pst->selector])(pst, spId, aSsn, uStat);
         break;
   }

   RETVALUE(ret);

} /* end of StLiSptSteReq */

  

/*
*
*       Fun:   lower interface - SPT Cord request 
*
*       Desc:  This function resolves the Spt Cord request primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 StLiSptCordReq
(
Pst    *pst,                    /* post structure */
SpId    spId,                   /* service provider id */
Ssn     aSsn                    /* affected subsystem number */
)
#else
PUBLIC S16 StLiSptCordReq(pst, spId, aSsn)
Pst    *pst;                    /* post structure */
SpId    spId;                   /* service provider id */
Ssn     aSsn;                   /* affected subsystem number */
#endif
{
   S16    ret;

   TRC3(StLiSptCordReq)

   switch (pst->dstEnt)
   {
#ifdef DP
      case ENTSP:
         if (pst->route == RTE_PROTO)
         {
            ret = (*stLiSptCordReqMt[pst->selector])(pst, spId, aSsn);
         }
         else
         {
            ret = DpUiSptCordReq(pst, spId, aSsn);
         }
         break;
#endif /* DP */

      default:
         /* jump to specific primitive in service user, depending on selector 
            configured */

         ret = (*stLiSptCordReqMt[pst->selector])(pst, spId, aSsn);
         break;
   }

   RETVALUE(ret);

} /* end of StLiSptCordReq */

  

/*
*
*       Fun:   lower interface - SPT Cord response 
*
*       Desc:  This function resolves the Spt Cord response primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 StLiSptCordRsp
(
Pst    *pst,                    /* post structure */
SpId    spId,                   /* service provider id */
Ssn     aSsn                    /* affected subsystem number */
)
#else
PUBLIC S16 StLiSptCordRsp(pst, spId, aSsn)
Pst    *pst;                    /* post structure */
SpId    spId;                   /* service provider id */
Ssn     aSsn;                   /* affected subsystem number */
#endif
{
   S16    ret;

   TRC3(StLiSptCordRsp)

   switch (pst->dstEnt)
   {
#ifdef DP
      case ENTSP:
         if (pst->route == RTE_PROTO)
         {
            ret = (*stLiSptCordRspMt[pst->selector])(pst, spId, aSsn);
         }
         else
         {
            ret = DpUiSptCordRsp(pst, spId, aSsn);
         }
         break;
#endif /* DP */

      default:
         /* jump to specific primitive in service user, depending on selector 
            configured */

         ret = (*stLiSptCordRspMt[pst->selector])(pst, spId, aSsn);
         break;
   }

   RETVALUE(ret);

} /* end of StLiSptCordRsp */


#ifdef SPT2
/*
*
*       Fun:   lower interface - SPT Status Request 
*
*       Desc:  This function resolves the Spt Status Request primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 StLiSptStaReq
(
Pst    *pst,                    /* post structure */
SpId    spId,                   /* service provider id */
U8      status,                 /* Type of status */
Dpc     dpc,                    /* Destination point code */
Ssn     ssn                     /* affected subsystem number */
)
#else
PUBLIC S16 StLiSptStaReq(pst, spId, status, dpc, ssn)
Pst    *pst;                    /* post structure */
SpId    spId;                   /* service provider id */
U8      status;                 /* Type of status */
Dpc     dpc;                    /* Destination point code */
Ssn     ssn;                    /* affected subsystem number */
#endif
{
   S16    ret;

   TRC3(StLiSptStaReq)

   switch (pst->dstEnt)
   {
#ifdef DP
      case ENTSP:
         if (pst->route == RTE_PROTO)
         {
            ret = (*stLiSptStaReqMt[pst->selector])(pst, spId, status, dpc, ssn);
         }
         else
         {
            ret = DpUiSptStaReq(pst, spId, status, dpc, ssn);
         }
         break;
#endif /* DP */

      default:
         /* jump to specific primitive in service user, depending on selector 
            configured */

         ret = (*stLiSptStaReqMt[pst->selector])(pst, spId, status, dpc, ssn);
         break;
   }

   RETVALUE(ret);

} /* end of StLiSptStaReq */
#endif /* SPT2 */


/*
*     portable functions 
*/


/*
*
*       Fun:   portable - SPT Bind Request
*
*       Desc:  This function binds the SPT layer service user
*              with the SPT layer service provider. The SPT
*              layer software will register this new service
*              user and will allocate a Service Access Point (SAP) for
*              this bind. The service user will specify the reference
*              number that will be used for the duration of this bind.
*              The Control Block for service provider is the SPT
*              Layer SAP, while the Control Block for the
*              service user is dependent on the protocol.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptli.c
*
*/
#ifdef ANSI
PRIVATE S16 PtLiSptBndReq
(
Pst    *pst,                    /* post structure */
SuId    suId,                   /* service user id */
SpId    spId,                   /* service provider id */
Ssn     ssn                     /* signaling system number */
)
#else
PRIVATE S16 PtLiSptBndReq(pst, suId, spId, ssn)
Pst    *pst;                    /* post structure */
SuId    suId;                   /* service user id */
SpId    spId;                   /* service provider id */
Ssn     ssn;                    /* signaling system number */
#endif
{            
   TRC3(PtLiSptBndReq)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(spId);
   UNUSED(ssn);

#if (ERRCLASS & ERRCLS_DEBUG)
   STLOGERROR(ERRCLS_DEBUG, EST306, ERRZERO, "PtLiSptBndReq () Failed");
#endif

   RETVALUE(ROK);
} /* end of PtLiSptBndReq  */

  

/*
*
*       Fun:   portable - SPT Unbind Request
*
*       Desc:  This function unbinds the SPT layer service
*              user from the SPT layer service provider.
*              The SPT Layer Service Access Point is deallocated.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptli.c
*
*/
#ifdef ANSI
PRIVATE S16 PtLiSptUbndReq
(
Pst    *pst,                    /* post structure */
SpId    spId,                   /* service provider id */
Reason  reason                  /* reason */
)
#else
PRIVATE S16 PtLiSptUbndReq(pst, spId, reason)
Pst    *pst;                    /* post structure */
SpId    spId;                   /* service provider id */
Reason  reason;                 /* reason */
#endif
{
   TRC3(PtLiSptUbndReq)

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(reason);

#if (ERRCLASS & ERRCLS_DEBUG)
   STLOGERROR(ERRCLS_DEBUG, EST307, ERRZERO, "PtLiSptUbndReq () Failed");
#endif

   RETVALUE(ROK);
} /* end of PtLiSptUbndReq  */

  

/*
*
*       Fun:   portable - SPT Data Request
*
*       Desc:  This function is used to transmit a message.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptli.c
*
*/
#ifdef ANSI
PRIVATE S16 PtLiSptUDatReq
(
Pst         *pst,               /* post structure */
SpId         spId,              /* service provider id */
SpUDatEvnt  *event,             /* SCCP event */
Buffer      *mBuf               /* message buffer */
)
#else
PRIVATE S16 PtLiSptUDatReq(pst, spId, event, mBuf)
Pst         *pst;               /* post structure */
SpId         spId;              /* service provider id */
SpUDatEvnt  *event;             /* SCCP event */
Buffer      *mBuf;              /* message buffer */
#endif
{
   TRC3(PtLiSptUDatReq)

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(event);
   UNUSED(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
   STLOGERROR(ERRCLS_DEBUG, EST308, ERRZERO, "PtLiSptUDatReq () Failed");
#endif

   RETVALUE(ROK);
} /* end of PtLiSptUDatReq */



/*
*
*       Fun:   portable - SCCP Coordination Request
*
*       Desc:  Subsystem coordination request
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  st_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 PtLiSptCordReq
(
Pst    *pst,                    /* post structure */
SpId    spId,                   /* service provider id */
Ssn     aSsn                    /* affected subsystem number */
)
#else
PUBLIC S16 PtLiSptCordReq(pst, spId, aSsn)
Pst    *pst;                    /* post structure */
SpId    spId;                   /* service provider id */
Ssn     aSsn;                   /* affected subsystem number */
#endif
{
   TRC3(PtLiSptCordReq)

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(aSsn);

#if (ERRCLASS & ERRCLS_DEBUG)
   STLOGERROR(ERRCLS_DEBUG, EST309, ERRZERO, "PtLiSptCordReq () Failed");
#endif

   RETVALUE(ROK);
}  /* end of PtLiSptCordReq */

  

/*
*
*       Fun:   portable - SCCP Coordination Response
*
*       Desc:  Subsystem Coordination Response
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  st_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 PtLiSptCordRsp
(
Pst    *pst,                    /* post structure */
SpId    spId,                   /* service provider id */
Ssn     aSsn                    /* affected subsystem number */
)
#else
PUBLIC S16 PtLiSptCordRsp(pst, spId, aSsn)
Pst    *pst;                    /* post structure */
SpId    spId;                   /* service provider id */
Ssn     aSsn;                   /* affected subsystem number */
#endif
{
   TRC3(PtLiSptCordRsp)

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(aSsn);

#if (ERRCLASS & ERRCLS_DEBUG)
   STLOGERROR(ERRCLS_DEBUG, EST310, ERRZERO, "PtLiSptCordRsp () Failed");
#endif

   RETVALUE(ROK);
}  /* end of PtLiSptCordRsp */

  

/*
*
*       Fun:   portable - SCCP State Request
*
*       Desc:  Subsystem State Change Request
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  st_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 PtLiSptSteReq
(
Pst    *pst,                    /* post structure */
SpId    spId,                   /* service provider id */
Ssn     aSsn,                   /* affected subsystem number */
UStat   uStat                   /* User Status */
)
#else
PUBLIC S16 PtLiSptSteReq(pst, spId, aSsn, uStat)
Pst    *pst;                    /* post structure */
SpId    spId;                   /* service provider id */
Ssn     aSsn;                   /* affected subsystem number */
UStat   uStat;                  /* User Status */
#endif
{
   TRC3(PtLiSptSteReq)

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(aSsn);
   UNUSED(uStat);

#if (ERRCLASS & ERRCLS_DEBUG)
   STLOGERROR(ERRCLS_DEBUG, EST311, ERRZERO, "PtLiSptSteReq () Failed");
#endif

   RETVALUE(ROK);
}  /* end of PtLiSptSteReq */


#ifdef SPT2
/*
*
*       Fun:   Portable - SPT Status Request 
*
*       Desc:  Point code and subsyatem status request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 PtLiSptStaReq
(
Pst    *pst,                    /* post structure */
SpId    spId,                   /* service provider id */
U8      status,                 /* Type of status */
Dpc     dpc,                    /* Destination point code */
Ssn     ssn                     /* affected subsystem number */
)
#else
PUBLIC S16 PtLiSptStaReq(pst, spId, status, dpc, ssn)
Pst    *pst;                    /* post structure */
SpId    spId;                   /* service provider id */
U8      status;                 /* Type of status */
Dpc     dpc;                    /* Destination point code */
Ssn     ssn;                    /* affected subsystem number */
#endif
{
   TRC3(PtLiSptStaReq)

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(status);
   UNUSED(dpc);
   UNUSED(ssn);

#if (ERRCLASS & ERRCLS_DEBUG)
   STLOGERROR(ERRCLS_DEBUG, EST312, ERRZERO, "PtLiSptStaReq () Failed");
#endif

   RETVALUE(ROK);
} /* end of PtLiSptStaReq */
#endif /* SPT2 */


/********************************************************************30**
  
         End of file:     st_ptli.c@@/main/13 - Fri Nov 17 10:34:15 2000
  
*********************************************************************31*/
  

/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/


/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/


/********************************************************************80**
 
  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  mma   1. initial release
 
1.2          ---  mma   1. miscellaneous changes
 
1.3          ---  ak    1. new interface support.
             ---  ak    2. extended matrices to support two LC interfaces
                           SEL_LC_NEW and SEL_LC_OLD.
             ---  ak    3. SptUDatReq now has prior in UDatEvnt structure
                           Use cmPkSpUDatEvnt routine to pack.
             ---  ak    4. replaced ss_ms.[hx] and ss_pt.[hx] with ssi.[hx]
 
1.4          ---  ak    1. defined error numbers.
 
1.5          ---  ak    1. include cm5.[hx]
 
1.6          ---  ak    1. removed all SEL_LC_OLD stuff
 
1.7          ---  aa    1. Changes to TCAP upper interface changes
 
1.8          ---  aa    1. miscellaneous changes
 
1.9          ---  aa    1. Changes due to removing of serror's
 
*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.10         ---      aa   1. Moved cm_ss7.x after gen.x as some of the typedef
                               used by other include files are moved from gen.x 
                               cm_ss7.x
                      aa    2. Include cm_ss7.h
             ---      aa    3. Chnaged the functions related to StLiSptBndReq (B
                               request to SCCP) as type parameter is removed fro
                               the primitive

1.11         ---      nj   1. Rewrote the file.
1.12         ---      nj   1. Added packing function and matrix entries for
                              new primitive XxYySptStaReq at the lower interface.

                           2. Removed packing functions from this file. These
                              functions have been moved to spt.c file.

/main/13     ---      nj   1. Added functions for LDF-SCCP
                      as   2. Added tight coupled functions for SUA provider
                              of SIGTRAN.
                              
3.1+        st005.301 zr   1. File mrs.x included under ZT                               
3.1+       st034.301   yk   1. Code Added for SS_MULTIPLE_PROCS
*********************************************************************91*/
