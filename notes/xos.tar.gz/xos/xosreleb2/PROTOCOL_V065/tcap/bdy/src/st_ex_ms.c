/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     SS7 TCAP  - external interface - mos
  
     Type:     C source file
  
     Desc:     Functions required for scheduling and initialization.
  
     File:     ct_ex_ms.c
  
     Sid:      ct_ex_ms.c@@/main/17 - Fri Nov 17 10:34:43 2000
    
     Prg:      nj
  
*********************************************************************21*/


/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif
#ifdef CCITT96
               CCITT 96
#endif
 
************************************************************************/


/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* common timers */
#include "cm_ss7.h"        /* ss7 layer */
#include "cm_err.h"        /* common error */
#include "cm_hash.h"       /* Common hash */
#include "lst.h"           /* layer management, TCAP */
#include "stu.h"           /* tcap services */
#include "spt.h"           /* tcap-sccp interface */

#ifdef ST_FTHA
#include "sht.h"           /* System Agent Interface */
#include "mrs.h"           /* MRS */
#endif /* ST_FTHA */

#include "st.h"            /* tcap */
#include "st_err.h"        /* tcap error */

#ifdef ZT
#include "cm_ftha.h"
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#ifdef ZT_DFTHA
#include "cmztdt.h"
#include "cmztdtlb.h"
#endif /* ZT_DFTHA */
#include "zt.h"            /* Tcap PSF defines */
#include "lzt.h"
#endif /* ZT */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* common timers */
#include "cm_ss7.x"        /* common */
#include "cm_hash.x"       /* Common hash */
#include "stu.x"           /* tcap layer */
#include "spt.x"           /* tcap-sccp interface */
#include "lst.x"           /* layer management, TCAP */
#include "st_mf.x"         /* Tcap */

#ifdef ZT
#include "cm_ftha.x"
#include "cm_pftha.x"      /* Common PSF typedefs */
#include "cm_psfft.x"
#endif /* ZT */

#ifdef ST_FTHA
#include "sht.x"           /* SHT */
/* st005.301 - Deleted - mrs.x included under ZT */
#endif /* ST_FTHA */

#include "st.x"            /* Tcap */

#ifdef ZT
/* st005.301 - Added - mrs.x included here */
#include "mrs.x"           /* MRS */
#ifdef ZT_DFTHA
#include "cmztdt.x"
#include "cmztdtlb.x"
#endif /* ZT_DFTHA */
#include "lzt.x"
#include "zt.x"            /* Tcap PSF typedefs */
#endif /* ZT */



/* local defines */

/* local externs */
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifndef SS_MULTIPLE_PROCS
EXTERN  StCb   stCb;       /* Tcap Control block */
#endif /* SS_MULTIPLE_PROCS */

/* forward references */

/* unpacking functions */

/* functions in other modules */

/* public variable declarations */

/* private variable declarations */


/*
 *     support functions
 */


/*
*
*       Fun:    initialize external
*
*       Desc:   Initializes variables used to interface with Upper/Lower
*               Layer  
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   ct_ex_ms.c
*
*/
#ifdef ANSI
PUBLIC S16 stInitExt
(
void
)
#else
PUBLIC S16 stInitExt()
#endif
{
   TRC2(stInitExt)

   RETVALUE(ROK);
} /* end of stInitExt */


/*
*
*       Fun:    TCAP activate task
*
*       Desc:   Processes received event from Upper/Lower/management Layer
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   ct_ex_ms.c
*
*/
#ifdef ANSI
PUBLIC S16 stActvTsk
(
Pst       *pst,             /* post */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 stActvTsk(pst, mBuf)
Pst       *pst;             /* post */
Buffer    *mBuf;            /* message buffer */
#endif
{
   S16 ret;
   
   TRC3(stActvTsk);
  
   /* Initialize the return value */
   ret = ROK;

   switch(pst->srcEnt)
   {
     case ENTTU:    /* TCAP User */
     case ENTMA:    /* MAP SM */
     case ENTIA:    /* IS-41 */
     case ENTIE:    /* INAP */
     /* st006.301 - Added - CAP support in upper interface */
     case ENTQC:    /* CAP */
     /* st013.301 - Added - TCAP API support in upper interface */
     case ENTDSTU:  /* TCAP API */

/* Loosley coupled upper interface */

       switch(pst->event)
       {
#ifdef LCSTUISTU
         case EVTSTUBNDREQ:             /* Bind request */
            ret =  cmUnpkStuBndReq(StUiStuBndReq, pst, mBuf);
            break;

         case EVTSTUUBNDREQ:            /* UnBind request */
            ret =  cmUnpkStuUbndReq(StUiStuUbndReq, pst, mBuf);
            break;

         case EVTSTUDATREQ:              /* Data request */
            ret =  cmUnpkStuDatReq(StUiStuDatReq, pst, mBuf);
            break;

         case EVTSTUUDATREQ:             /* Unstructured Data request */
            ret =  cmUnpkStuUDatReq(StUiStuUDatReq, pst, mBuf);
            break;

         case EVTSTUCMPREQ:              /* Component request */
            ret =  cmUnpkStuCmpReq(StUiStuCmpReq, pst, mBuf);
            break;

         case EVTSTUSTEREQ:              /* State request */
            ret =  cmUnpkStuSteReq(StUiStuSteReq, pst, mBuf);
            break;

         case EVTSTUSTERSP:              /* State response */
            ret =  cmUnpkStuSteRsp(StUiStuSteRsp, pst, mBuf);
            break;
#endif /* LCSTUISTU */

         default:

#if (ERRCLASS & ERRCLS_DEBUG)
            STLOGERROR(ERRCLS_DEBUG, EST283, (ErrVal)pst->event,
                       "stActvTsk:Unexpected event rx'd from TCap User");
#endif
           break;
       }

       break;

     case ENTSP:   /* SCCP */
     /* st006.301 - Added - SUA support in lower interface */
     case ENTSU:   /* SUA */

/* Loosley coupled lower interface */

       switch(pst->event)
       {
#ifdef LCSTLISPT
          case EVTSPTUDATIND:             /* Data indication */
             ret =  cmUnpkSptUDatInd(StLiSptUDatInd, pst, mBuf);
             break;

          case EVTSPTCRDIND:              /* Cord Ind */
             ret =  cmUnpkSptCordInd(StLiSptCordInd, pst, mBuf);
             break;

          case EVTSPTCRDCFM:              /* Cord Cfm */
             ret =  cmUnpkSptCordCfm(StLiSptCordCfm, pst, mBuf);
             break;

          case EVTSPTSTEIND:              /* State Ind */
             ret =  cmUnpkSptSteInd(StLiSptSteInd, pst, mBuf);
             break;

          case EVTSPTSTAIND:              /* Status Ind */
             ret =  cmUnpkSptStaInd(StLiSptStaInd, pst, mBuf);
             break;
 
          case EVTSPTPCSTEIND:            /* Point Code Status Ind */
             ret =  cmUnpkSptPCSteInd(StLiSptPCSteInd, pst, mBuf);
             break;

#ifdef SPT2
          case EVTSPTBNDCFM:              /* Bind Confirm */
             ret =  cmUnpkSptBndCfm(StLiSptBndCfm, pst, mBuf);
             break;

          case EVTSPTSTECFM:              /* Subsystem state Confirm */
             ret =  cmUnpkSptSteCfm(StLiSptSteCfm, pst, mBuf);
             break;

          case EVTSPTSTACFM:              /* Status Confirm */
             ret =  cmUnpkSptStaCfm(StLiSptStaCfm, pst, mBuf);
             break;
#endif /* SPT2 */
#endif /* LCSTLISPT */

          default:
#if (ERRCLASS & ERRCLS_DEBUG)
             STLOGERROR(ERRCLS_DEBUG, EST284, (ErrVal)pst->event,
                        "stActvTsk:Unexpected event rx'd from Lower Layer");
#endif
            break;
       }

       break;

     case ENTSM:    /* Stack Manager */
/* st001.301 - adding ENTSH as one of the source entities in CORE1 */
#ifndef TDS_CORE2
     case ENTSH:
#endif

/* Loosley coupled management interface */

       switch(pst->event)
       {
/* st011.301 -Add- Event Sht Cntrl Req */
#ifdef ST_FTHA
         case EVTSHTCNTRLREQ:             /* Control Request */
            ret =  cmUnpkMiShtCntrlReq(StMiShtCntrlReq, pst, mBuf);
            break;
#endif /* ST_FTHA */
#ifdef LCSTMILST
         case EVTLSTCFGREQ:             /* Configuration Request */
            ret =  cmUnpkLstCfgReq(StMiLstCfgReq, pst, mBuf);
            break;

         case EVTLSTUCFGREQ:            /* UnConfiguration Request */
            ret =  cmUnpkLstUcfgReq(StMiLstUcfgReq, pst, mBuf);
            break;

         case EVTLSTSTAREQ:             /* Status Request */
            ret =  cmUnpkLstStaReq(StMiLstStaReq, pst, mBuf);
            break;

         case EVTLSTSTSREQ:             /* Statistics Request */
            ret =  cmUnpkLstStsReq(StMiLstStsReq, pst, mBuf);
            break;

         case EVTLSTCNTRLREQ:           /* Control Request */
            ret =  cmUnpkLstCntrlReq(StMiLstCntrlReq, pst, mBuf);
            break;
#endif /* LCSTMILST */

         default:
#ifdef ZT
            /* Pass all unrecognized events to PSF */
            ztActvTsk(pst, mBuf);
#else
#if (ERRCLASS & ERRCLS_DEBUG)
            STLOGERROR(ERRCLS_DEBUG, EST285, (ErrVal)pst->event,
                       "stActvTsk:Unexpected event rx'd from LM");
#endif
#endif /* ZT */
          break;
       }
       break;

/* st001.301 - protecting handling of SH control request under TDS_CORE2 
               compile time flag */
#ifdef TDS_CORE2
     case ENTSH:    /* System Agent */

       switch(pst->event)
       {
#ifdef ST_FTHA
         case EVTSHTCNTRLREQ:             /* Control Request */
            ret =  cmUnpkMiShtCntrlReq(StMiShtCntrlReq, pst, mBuf);
            break;
#endif /* ST_FTHA */

         default:
#ifdef ZT
            /* Pass all unrecognized events to PSF */
            ztActvTsk(pst, mBuf);
#else
#if (ERRCLASS & ERRCLS_DEBUG)
            STLOGERROR(ERRCLS_DEBUG, EST286, (ErrVal)pst->event,
                       "stActvTsk:Unexpected event rx'd from SH");
#endif
#endif /* ZT */
          break;
       }
       break;
#endif /* TDS_CORE2 */

/* Loosley coupled peer interface */

#ifdef ZT
     case ENTST:   /* Peer TCAP */
        ztActvTsk(pst, mBuf);
        break;
#endif /* ZT */

     default:
#if (ERRCLASS & ERRCLS_DEBUG)
        STLOGERROR(ERRCLS_DEBUG, EST287, (ErrVal)pst->srcEnt, "stActvTsk:Bad Entity");
#endif
     break;

   }

 /* st005.301 -Added- Rolling Upgrade feature */
#ifdef ST_RUG
   /* Generate alarm for invalid version on any interfaces */
   if(ret == RINVIFVER) 
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE,
                          LCM_EVENT_INV_EVT,
                          LCM_CAUSE_DECODE_ERR,
                          pst->event, (U8)pst->intfVer);
   }
#endif /* ST_RUG */

   SExitTsk();

   RETVALUE(ret);
} /* end of stActvTsk */


/********************************************************************30**

         End of file:     ct_ex_ms.c@@/main/17 - Fri Nov 17 10:34:43 2000

*********************************************************************31*/



/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/



/********************************************************************60**

        Revision history:

*********************************************************************61*/


/********************************************************************80**
 
  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  mma   1. initial release
 
1.2          ---  mma   1. remove some unused local variables
 
1.3          ---  mma   1. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92
 
1.4          ---  mma   1. miscellaneous changes
 
1.5          ---  mma   1. removed ACG and DIGIT unpacking prototypes
 
1.6          ---  mma   1. change some unpk for swtch
 
1.7          ---  ak    1. added stInvokeTimer field to stUnpkStComp
             ---  ak    2. added MaxDlgs and MaxInvs fields in 
                           stUnpkMiLstCfgReq
             ---  ak    3. modified to use new MOS and Pst structure.
             ---  ak    4. added stActvTskNew in ew format.
             ---  ak    5. added msgPrior parameter to UDatReq and DatReq
             ---  ak    6. replaced ss_ms/ss_pt.[hx] with ssi.[hx]
             ---  ak    7. stUnpkMiLmi -> stUnpkMiLst
             ---  ak    8. lmi.[hx] and lmi_st.[hx] replaced by lst.[hx]
 
1.8          ---  ak    1. added new error numbers to replace ESTXXX
 
1.9          ---  ak    1. include cm5.[hx]
 
1.10         ---  ak    1. replaced msgPrior with stQosSet Stu(U)DatReq
             ---  ak    2. added stDlgEv, stAbrtInfo for Stu(U)DatReq
             ---  ak    3. StsReq and StaReq unpack only header info.
             ---  ak    4. moved common unpacking primitives to cm_bdy2.c
             ---  ak    5. functions check error status even if !ERRCHK
             ---  ak    6. stripped stActvTsk => no backward compatibility
                           with old system services.
             ---  ak    7. removed class unpacking from StTCUCfg structure
 
1.11         ---  aa    1. Changes due to TCAP upper interfce changes
 
1.12         ---  aa    1. miscellaneous changes
 
1.13         ---  aa    1. Changes due to removing of serror's
 
1.14         ---  aa    1. Fixed the bug in function stActvTskNew
             ---  aa    2. Changed the name of the function stActvTskNew to
                           stActvTsk
             ---  aa    3. Include cm_ss7.h
*********************************************************************81*/
 

/********************************************************************90**
 
  version    pat     init                   description
----------- -----    ----  ------------------------------------------------
1.14+        st010.26 nj   Added aDpc parameter in the StLiSptSteInd primitive.
 
1.15         ---      nj   Rewrote this file.

1.16         ---      nj   1. Added unpacking for new incoming primitives at
                              upper interface and lower interface under
                              STU2 and SPT2 flags.
                           2. Added support for fault tolerance.
                           3. Removed unpacking functions from this file. These
                              functions have been moved to file stu.c

/main/17     ---      nj   1. Modified for SHT interface.

3.1+        st001.301 as   1. In CORE1, control requests can be received from 
                              SH. The handling for this has been added in the 
                              function stActvTsk().

3.1+        st005.301 zr   1. Rolling Upgrade Feature
                           - Generate alarm for version mismatch
                           - File mrs.x included under ZT
                           
3.1+        st006.301 zr   1. Added case for ENTSU in lower interface 
                              section of stActvTsk routine 
                           2. Added case for ENTQC in upper interface 
                              section of  stActvTsk routine
3.1+        st011.301 akp  1. For CORE1 architecture, in stActvTsk routine, 
                              case for event SHT Control Req. added
3.1+        st013.301 akp  1. A new srcEnt ENTDSTU is added 
3.1+       st034.301   yk   1. Code Added for SS_MULTIPLE_PROCS
*********************************************************************91*/

