#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* common timer */
#include "cm_inet.h"	/* common sockets */

#include "ss_err.h"        /* errors */
#include "ss_dep.h"        /* implementation-specific */
#include "ss_queue.h"      /* queues */
#include "ss_task.h"       /* tasking */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */
#include "cm_llist.h"
#include "cm_ss7.h"

#include "lst.h"

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* common timer */
#include "cm_lib.x"
#include "cm_inet.x"	/* common sockets */

#include "ss_dep.x"        /* implementation-specific */
#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */
#include "cm_lib.x"       

#include "cm_llist.x"

#include "cm_ss7.x"
#include "sm.x"
#include "lst.x"

EXTERN Void smStPstInit(Pst * smStPst);
EXTERN Void stHdrInit(Header * hdr);

VOID stBndSpReq()
{
	StMngmt	cntrl;
	Pst		smStPst;
	
	cmMemset((U8*)&cntrl, 0, sizeof(StMngmt));
	
	stHdrInit(&cntrl.hdr);
	smStPstInit(&smStPst);
	
	smStPst.event  = EVTLSTCNTRLREQ;
	cntrl.hdr.msgType = TCNTRL;
	cntrl.hdr.entId.ent = ENTST;
	cntrl.hdr.entId.inst = 0;

	cntrl.hdr.elmId.elmnt = STGRSPSAP;
	cntrl.t.cntrl.action = ABND_ENA;
	cntrl.t.cntrl.subAction = SAGR_DSTPROCID;
	
	(Void)StMiLstCntrlReq(&smStPst, &cntrl);

}
