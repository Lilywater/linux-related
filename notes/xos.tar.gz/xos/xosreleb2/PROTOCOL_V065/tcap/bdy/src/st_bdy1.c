/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**

     Name:     SS7 TCAP

     Type:     C source file
  
     Desc:     C source code for TCAP Upper Layer, Lower Layer,
               System Service and Layer Management primitives 
               supplied by TRILLIUM.

     File:     st_bdy1.c
  
     Sid:      ct_bdy1.c@@/main/20 - Fri Nov 17 10:34:26 2000
  
     Prg:      nj
  
*********************************************************************21*/

/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif
#ifdef CCITT96
               CCITT 96
#endif
 
************************************************************************/

/*
  
Upper layer functions interface to the TCAP User layer protocol.
  
The following functions are provided in this file:
  
     StUiStuBndReq       Bind Request
     StUiStuUbndReq      Unbind Request
     StUiStuDatReq       Data Request
     StUiStuUDatReq      Unit Data Request
     StUiStuCmpReq       Component Request
     StUiStuSteReq       SSN State change Request
     StUiStuSteRsp       SSN State change Response
  
It is assumed that the following functions are provided in
the TCAP portable service user (st_ptui.c) file:
  
     StUiStuDatInd       Data Indication
     StUiStuUDatInd      Unit Data Indication
     StUiStuCmpInd       Component Indication
     StUiStuCmpCfm       Component Confirm
     StUiStuSteInd       SSN State change Indication
     StUiStuSteCfm       SSN State change Confirm
     StUiStuNotInd       Notice Indication
     StUiStuStaInd       Status Indication
     StUiStuBndCfm       Bind Confirm

*/

/*
  
Lower layer functions interface to the SCCP layer protocol.
  
The following functions are provided in this file:
  
     StLiSptUDatInd      Unit Data Indication
     StLiSptStaInd       Status Indication
     StLiSptCordInd      Coordination Indication
     StLiSptCordCfm      Coordination Confirm
     StLiSptSteInd       SSN State change Indication
     StLiSptPCSteInd     Point Code State change Indication
     StLiSptBndCfm       Bind Confirm
  
It is assumed that the following functions are provided in
the portable service provider file:
  
     StLiSptBndReq       Bind Request
     StLiSptUbndReq      Unbind Request
     StLiSptUDatReq      Unit Data Request
     StLiSptCordReq      Coordination Request
     StLiSptCordRsp      Coordination Response
     StLiSptSteReq       SSN State change Request
  
*/

/*
 
Layer management provides the necessary functions to control and
monitor the condition of each protocol layer.
  
The following functions are provided in this file:
  
     StMiLstCfgReq      Configure Request
     StMiLstUcfgReq     Unconfigure Request
     StMiLstStaReq      Solicited Status Request
     StMiLstStsReq      Statistics Request
     StMiLstCntrlReq    Control Request

It is assumed that the following functions are provided in
the layer management portable service provider (st_ptmi.c) file:
  
     StMiLstCfgCfm      Configuration Confirm
     StMiLstCntrlCfm    Control Confirm
     StMiLstStaInd      Unsolicited Status Indication
     StMiLstTrcInd      Trace Indication
     StMiLstStaCfm      Solicited status Confirm
     StMiLstStsCfm      Statistics Confirm
*/
  
/*
  
System services are the functions required by the protocol
layer for buffer management, timer management, date/time
management, resource checking and initialization.
  
The following functions are provided in this file:
  
     stActvInit       Activate task - initialize
     stActvTmr        Activate task - timer
  
It is assumed that the following functions are provided in
the system services portable service provider (ss_ptsp.c) file:
  
     SInitQueue     Initialize Queue
     SQueueFirst    Queue to First Place
     SQueueLast     Queue to Last Place
     SDequeueFirst  Dequeue from First Place
     SDequeueLast   Dequeue from Last Place
     SFndLenQueue   Find Length of Queue
  
     SGetMsg        Get Message
     SPutMsg        Put Message
  
     SAddPreMsg     Add Pre Message
     SAddPstMsg     Add Post Message
     SRemPreMsg     Remove Pre Message
     SRemPstMsg     Remove Post Message
     SFndLenMsg     Find Length of Message
  
     SGetSBuf       Get Static Buffer
  
     SChkRes        Check Resources
     SGetDateTime   Get Date and Time
     SGetSysTime    Get System Time
  
     SRegTmr        Register Activate Task - timer
  
*/

/*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000011     Multiprocessor Operating System
*     1000030     SS7 - SCCP
*
*/

/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_llist.h"
#include "cm5.h"           /* Common timer */
#include "cm_ss7.h"        /* SS7 Specific */
#include "cm_hash.h"       /* common hash */
#include "cm_err.h"        /* common error */
#include "cm_asn.h"        /* common ASN.1 Encoder/Decoder */
#include "stu.h"           /* Tcap Upper Interface */
#include "spt.h"           /* Tcap Lwer Interface */
#include "lst.h"           /* TCAP layer management Interface */
#include "st.h"            /* Tcap */
#include "st_mf.h"         /* Tcap Message functions */
#include "st_db.h"         /* Tcap ASN.1 Database */
#include "st_err.h"        /* Tcap error */

#ifdef ST_FTHA
#include "sht.h"           /* SHT */
#include "mrs.h"           /* MRS */
#endif /* ST_FTHA */

#ifdef ZT
#include "cm_ftha.h"
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#ifdef ZT_DFTHA
#include "cmztdt.h"
#include "cmztdtlb.h"
#endif /* ZT_DFTHA */
#include "zt.h"            /* Tcap PSF defines */
#include "lzt.h"
#endif /* ZT */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_llist.x"
#include "cm5.x"           /* Common Timer */
#include "cm_ss7.x"        /* common SS7 Specific */
#include "cm_hash.x"       /* common hash */
#include "cm_asn.x"        /* common ASN.1 Encoder/Decoder */
#include "stu.x"           /* Tcap Upper Interface  */
#include "spt.x"           /* Tcap Lower interface */
#include "lst.x"           /* TCAP layer management Interface */
#include "st_mf.x"         /* Tcap Message functions */

#ifdef ZT
#include "cm_ftha.x"
#include "cm_pftha.x"      /* Common PSF typedefs */
#include "cm_psfft.x"
#endif /* ZT */

#ifdef ST_FTHA
#include "sht.x"           /* SHT */
/* st005.301 - Deleted - mrs.x included under ZT */
#endif /* ST_FTHA */
#include "st.x"            /* Tcap */

#ifdef ZT
#ifdef ZT_DFTHA
#include "cmztdt.x"
#include "cmztdtlb.x"
#endif /* ZT_DFTHA */
/* st005.301 - Added - mrs.x included here */
#include "mrs.x"           /* MRS */
#include "lzt.x"
#include "zt.x"            /* Tcap PSF typedefs */
#endif /* ZT */

/* st005.301 - Added - Rolling Upgrade Feature */
#ifdef ST_RUG
#include "cm_lib.x"
#endif /* ST_RUG */


#ifdef SSI_WITH_CLI_ENABLED
#include "clishell.h"
#include "st_dbg.h"
#endif


/* local defines */

/* Check the dependencies for the various #defines */

/* st001.301 - deleted the code for printing error message in the case when 
 *             the flag ST_FTHA is not defined and the flag ZT is defined
 */

/* 2. Check for old STU interface */
#ifndef STU2
#warning "Please define STU2 in #ifdef ST section of envopt.h if no backward compatibility concerns"
#if (ZT && ST_FTHA)
#error "FTHA architechture requires STU2. Please define it in the #ifdef ST section of envopt.h"
#endif /* (ZT && ST_FTHA) */
#endif /* STU2 */

/* 3. Check for old SPT interface */
#ifndef SPT2
#warning "Please define SPT2 in #ifdef ST section of envopt.h if no backward compatibility concerns"
#if (ZT && ST_FTHA)
#error "FTHA architechture requires SPT2. Please define it in the #ifdef ST section of envopt.h"
#endif /* (ZT && ST_FTHA) */
#endif /* SPT2 */

/* 4. Check for Core1 and for ZT_DFTHA */
#ifndef TDS_CORE2
#ifdef ZT_DFTHA
#error "ZT_DFTHA cannot be define along with TDS_CORE2"
#endif /* ZT_DFTHA */
#endif /* TDS_CORE2 */

/* local externs */
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifndef SS_MULTIPLE_PROCS
#ifdef ZT
EXTERN  ZtCb   ztCb; /* TCAP PSF control block */
#endif /* ZT */
#endif /* SS_MULTILE_PROCS */

/* forward references */

/* functions in other modules */
  
/* public variable declarations */

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
PUBLIC  StGlCb   stGlCbLst[ST_MAX_INSTANCES];          /* TCAP control block*/ 
PUBLIC  StGlCb   *stGlCbPtr;
PUBLIC  StCb     *stCbPtr;
#else
PUBLIC  StCb   stCb;          /* TCAP control block*/ 
/* st014.301 -Add- define stDataParam and stMgmntParam variables */
PUBLIC  StDataParam  stDataParam; /* global variable to store imp and isni */
PUBLIC  StMgmntParam stMgmntParam;/* global variable to store sccpState & ril */

#endif

EXTERN U32 g_stDbgMask;

/* private variable declarations */


/*
 *     support functions
 */


/******************************************************************************
           Interface functions to the TCAP User layer
******************************************************************************/

/*
*
*       Fun:   TCAP User Bind Request
*
*       Desc:  This function binds an Upper Layer Entity to the TCAP
*              Layer software. The TCAP layer software will register this 
*              new User and will allocate a Service Access Point for this
*              bind. With this function both Entities will exchange ids to
*              their respective Control Blocks which will be used for this
*              bind.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 StUiStuBndReq
(
Pst    *pst,              /* Post structure */
SuId    suId,             /* service user id */
SpId    spId,             /* service provider (TCAP) id */
Ssn     ssn               /* sub system number */
)
#else
PUBLIC S16 StUiStuBndReq(pst, suId, spId, ssn)
Pst    *pst;              /* Post Structure */
SuId    suId;             /* service user id */
SpId    spId;             /* service provider (TCAP) id */
Ssn     ssn;              /* sub system number */
#endif
{
   StTUSap   *tuSapCp;     /* pointer to upper SAP */
   /* st007.301 -Modified- corrected comment */
   StSPSap   *spSapCp;     /* pointer to lower SAP */
   S16        ret;
   
   /* st007.301 - Added-  TC-User Distribution feature */
   SuId      spSapId;      /* Lower SAP Id */

/* st005.301 - Added - Rolling Upgrade feature */
#ifdef ST_RUG
   Bool       found;       /* flag for search */
   U16        i;           /* Counter */
#endif /* ST_RUG */

   TRC3(StUiStuBndReq)

   /* st038.301 - Addition - Initialise spSapCp */
   spSapCp = NULLP;

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StUiStuBndReq failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
          "StUiStuBndReq:suId(%d), spId(%d)\n", suId, spId));

   /* st007.301 -Added- Initialize lower SAP id */
   spSapId = ST_DEF_ASSOC_SAP_ID;

   /* If not active then don't accept the bind request */
#ifdef ZT
   if (!ztChkCRsetStatus())
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST145, (ErrVal)0, 
                 "StUiStuBndReq: Invalid PSF state");
#endif

      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSTUBNDREQ, 
                  (U8)spId);

      RETVALUE(RFAILED);
   }
#endif /* ZT */

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Check if spId is out of range */
   if (spId >= (SpId)stCb.genCfg.nmbSaps || spId < 0)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SPID, EVTSTUBNDREQ, (U8)spId);

      STLOGERROR(ERRCLS_INT_PAR, EST146, (ErrVal)spId,
                 "StUiStuBndReq():spId out of range");

      RETVALUE(RFAILED);
   }
#endif

   /* Check if Upper SAP is already created for the spId */
   if ((tuSapCp = *(stCb.tuSapLst + spId)) == NULLP)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSTUBNDREQ, (U8)spId);

#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST147, (ErrVal)spId,
                 "StUiStuBndReq():Upper Sap not configured");
#endif
      RETVALUE(RFAILED);
   }
  
   /* Check if Upper SAP is already bound */
   if (tuSapCp->hlSt == ST_SAP_BND_ENBL)
   {
      if ((tuSapCp->pstTU.dstProcId != pst->srcProcId) ||
          (tuSapCp->pstTU.dstEnt != pst->srcEnt) ||
          (tuSapCp->pstTU.dstInst != pst->srcInst) ||
          (tuSapCp->suId != suId))
      {
#ifdef STU2
         (Void)StUiStuBndCfm(&tuSapCp->pstTU, tuSapCp->suId, CM_BND_NOK);
#endif /* STU2 */
         
         /* st009.301 -Add- Debug Prints */
         if (tuSapCp != NULLP)
         {        
            STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
              "StUiStuBndReq:Mismatch of ProcId(%d) or Ent(%d) or Inst.(%d)\n",
                                tuSapCp->pstTU.dstProcId,tuSapCp->pstTU.dstEnt,
                                tuSapCp->pstTU.dstInst ));
         }   
         RETVALUE(RFAILED);
      }

#ifdef STU2
      (Void)StUiStuBndCfm(&tuSapCp->pstTU, tuSapCp->suId, CM_BND_OK);
#endif /* STU2 */
      RETVALUE(ROK);
   }

   /* copy bind configuration parameters in TCAP upper sap */
   tuSapCp->suId            = suId;                  /* TCAP User Id */

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if ( tuSapCp->pstTU.route == RTE_PROTO)
      tuSapCp->pstTU.dstProcId = CMFTHA_RES_RSETID;
   else
      tuSapCp->pstTU.dstProcId = pst->srcProcId;
#else
      tuSapCp->pstTU.dstProcId = pst->srcProcId;
#endif /* SS_MULTIPLE_PROCS */

   tuSapCp->pstTU.dstEnt    = pst->srcEnt;
   /* st008.301 - Modify - corrected instance info. in pst structure */ 
   tuSapCp->pstTU.dstInst   = pst->srcInst;
   tuSapCp->ssn             = ssn;

/* st005.301 - Added - Rolling Upgrade feature */
#ifdef ST_RUG
   found = FALSE;
  
   /* If Sap structure does not contain version information */
   if(tuSapCp->remIntfValid == FALSE)
   {
      /* Search version information from main control block of TCAP */
      for(i=0;((i < stCb.numIntfInfo) && (found == FALSE));i++)
      {
         /* For upper interface */
         if(stCb.intfInfo[i].intf.intfId == STUIF)
         {
            switch(stCb.intfInfo[i].grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if((stCb.intfInfo[i].dstProcId == pst->srcProcId) &&
                     (stCb.intfInfo[i].dstEnt.ent ==pst->srcEnt) &&
                     (stCb.intfInfo[i].dstEnt.inst == pst->srcInst))       
                     found = TRUE;
                  break;                               
               case SHT_GRPTYPE_ENT:
                  if((stCb.intfInfo[i].dstEnt.ent ==pst->srcEnt) &&
                     (stCb.intfInfo[i].dstEnt.inst == pst->srcInst))
                    found = TRUE;
                  break;
               default:
                  /* not possible */
                  break; 
            } /* switch */                  
         } /* if */ 
      }  /* for */

      /* Version information found, update sap structure */ 
      if(found == TRUE)
      {         
         tuSapCp->pstTU.intfVer = stCb.intfInfo[i-1].intf.intfVer;
         tuSapCp->remIntfValid = TRUE;

         /* st005.301 - Deleted Run time update call for ZT */

      } /* if found */
      else  /* Not found */
      {
         /*  Sap cannot be bound if remote ver info is not available
         * Generate NOK to user layer with reason 
         * LCM_REASON_SWVER_NAVAIL
         */
         stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_BND_FAIL,
                  LCM_CAUSE_SWVER_NAVAIL, EVTSTUBNDREQ, (U8)spId);
         (Void)StUiStuBndCfm(&tuSapCp->pstTU, tuSapCp->suId, CM_BND_NOK);
         /* st009.301 -Add-  Print debug info */
         STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
                "StUiStuBndReq:Interface version not provided for SAP %d\n",
                 spId));
         RETVALUE(RFAILED);
      } 
   } /* if(tuSapCp->remIntfValid == FALSE) */

#endif /* ST_RUG */

   /* Change the state of the upper SAP */
   tuSapCp->hlSt = ST_SAP_BND_ENBL;            /* high level state bound */

#ifdef SPT2
   ret = ROK;

   /* st007.301 - Added - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
   /* Set upper to lower SAP association if not done already */
   if (tuSapCp->assocLSapId == ST_DEF_ASSOC_SAP_ID)
   {
      /* Find the lower SAP and set lower to upper SAP association */     
      spSapId = stFindLSapId(spId);
      
      /* If lower SAP is found with same SSN and switch 
       * Set upper to lower SAP association */
      if (spSapId !=  ST_DEF_ASSOC_SAP_ID)
         tuSapCp->assocLSapId = spSapId;
   }        
#else   
   spSapId = spId;
#endif /* ST_TC_USER_DIST  */
   
   /* st007.301 - Modified - TC-user Distribution Feature */           
   /* If associated lower SAP is found */
   if ( spSapId != ST_DEF_ASSOC_SAP_ID)
   {        
      if ((spSapCp = *(stCb.spSapLst + spSapId)) != NULLP)
      {
         if (spSapCp->hlSt == ST_SAP_BND_PEND)
         {
            spSapCp->ssn = ssn;
            spSapCp->hlSt = ST_SAP_WAIT_BNDCFM;
             /* wait for bind confirmation */

            /* start a timer */
            stStartSapTmr(ST_BND_ACK_TMR, (PTR)spSapCp);

            ret = StLiSptBndReq(&spSapCp->pstSP, spSapCp->suId, spSapCp->spId,
                             spSapCp->ssn);
         }
      } /* If associated lower SAP is found */   
   }
#else  /* SPT2 */

   /* Check if lower SAP is already created for the spId */
   if ((spSapCp = *(stCb.spSapLst + spId)) == NULLP)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSTUUBNDREQ, (U8)spId);

#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST148, (ErrVal)spId,
                 "StUiStuBndReq:Lower Sap not configured");
#endif
      RETVALUE(RFAILED);
   }
  
   /* Change the state of the lower SAP */
   spSapCp->hlSt = ST_SAP_BND_ENBL;            /* high level state bound */
   spSapCp->ssn  = ssn;
   
   /* bind with SCCP */
   ret = StLiSptBndReq(&spSapCp->pstSP, spSapCp->suId, spSapCp->spId,
                       spSapCp->ssn);

   /* send a status indication to stack manager */
   stSendAlarm(LCM_CATEGORY_INTERFACE, LST_EVENT_BND_OK, LCM_CAUSE_UNKNOWN,
               EVTSTUBNDREQ, spId);
#endif /* SPT2 */

#ifdef STU2
   (Void)StUiStuBndCfm(&tuSapCp->pstTU, tuSapCp->suId, CM_BND_OK);
#endif /* STU2 */

#ifdef ZT
   ztRunTimeUpd(ZT_TUSAP_CB,
                CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_MOD,
                (Void *)tuSapCp);

   ztRunTimeUpd(ZT_SPSAP_CB,
                CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_MOD,
                (Void *)spSapCp);
   ztUpdPeer();
#endif /* ZT */

   RETVALUE(ret);
} /* end of StUiStuBndReq */


/*
*
*       Fun:   TCAP User Unbind Request
*
*       Desc:  This function unbinds a TCAP SAP from an Upper Layer Entity
*              The SAP is NOT deallocated.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 StUiStuUbndReq
(
Pst    *pst,              /* Post structure */
SpId    spId,             /* service provider (TCAP) id */
Reason  reason
)
#else
PUBLIC S16 StUiStuUbndReq(pst, spId, reason)
Pst    *pst;              /* Post Structure */
SpId    spId;             /* service provider (TCAP) id */
Reason  reason;
#endif
{
   StTUSap   *tuSapCp;    /* pointer to the upper SAP */
   S16        ret;        /* Return value */
#ifndef SPT2
   StSPSap   *spSapCp;    /* pointer to the lower SAP */
#endif /* SPT2 */
  
   TRC3(StUiStuUbndReq)

   UNUSED(pst);

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StUiStuUbndReq failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
          "StUiStuUbndReq:spId(%d), reason(%d)\n", spId, reason));

   /* If not active then don't accept the unbind request */
#ifdef ZT
   if (!ztChkCRsetStatus())
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST149, (ErrVal)0, 
                 "StUiStuUbndReq: Invalid PSF state");
#endif

      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSTUUBNDREQ, 
                  (U8)spId);

      RETVALUE(RFAILED);
   }
#endif /* ZT */

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Check if spId is out of range */
   if (spId >= (SpId)stCb.genCfg.nmbSaps || spId < 0)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SPID, EVTSTUUBNDREQ, (U8)spId);

      STLOGERROR(ERRCLS_INT_PAR, EST150, (ErrVal)spId,
                 "StUiStuUbndReq():spId out of range");

      RETVALUE(RFAILED);
   }
#endif

   /* Check if upper SAP is already created for the spId */
   if ((tuSapCp = *(stCb.tuSapLst + spId)) == NULLP)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSTUUBNDREQ, (U8)spId);

#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST151, (ErrVal)spId,
                 "StUiStuUbndReq:Upper Sap not configured");
#endif
      RETVALUE(RFAILED);
   }
  
   /* Check if upper SAP is already unbound */
   if (tuSapCp->hlSt == ST_SAP_UNBND)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSTUUBNDREQ, (U8)spId);

      RETVALUE(ROK);
   }

   /* free all dialog control points in the Hash List */
   stFreeAllDlg(&tuSapCp->dlgHlCp);

/* st005.301 - Added - Rolling Upgrade Feature */
#ifdef ST_RUG
   /* On SAP being unbound mark the remote interface version *
    * as invalid */
   tuSapCp->remIntfValid = FALSE;
#endif /* ST_RUG */

   /* st007.301 - Added - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST   
   /* Reset the associatiom */
   tuSapCp->assocLSapId = ST_DEF_ASSOC_SAP_ID;
#endif /* ST_TC_USER_DIST */

   /* Update SAP state */
   tuSapCp->hlSt = ST_SAP_UNBND;  /* high level state unbound */

#ifdef ZT
   ztRunTimeUpd(ZT_TUSAP_CB,
                CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_MOD,
                (Void *)tuSapCp);
   ztUpdPeer();
#endif /* ZT */

#ifdef SPT2
   ret = ROK;
#else

   /* Check if lower SAP is already created for the spId */
   if ((spSapCp = *(stCb.spSapLst + spId)) == NULLP)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSTUUBNDREQ, (U8)spId);

#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST152, (ErrVal)spId,
                 "StUiStuUbndReq:Lower Sap not configured");
#endif
      RETVALUE(RFAILED);
   }
  
   /* Check if lower SAP is already unbound */
   if (spSapCp->hlSt == ST_SAP_UNBND)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSTUUBNDREQ, (U8)spId);

      RETVALUE(ROK);
   }

   spSapCp->hlSt = ST_SAP_UNBND;  /* high level state unbound */

   /* send unbind request to SCCP */
   ret = StLiSptUbndReq(&spSapCp->pstSP, spSapCp->spId, reason);

#endif /* SPT2 */

   /* SAP still exists so can be bound again with a BndReq */

   RETVALUE(ret);
} /* end of StUiStuUbndReq */


/*
*
*       Fun:   TCAP Data Request
*
*       Desc:  Request to send a TCAP Message for structured dialogue
*
*       Ret:   ROK      - ok
*
*       Notes: This is the entry point for all of the TCAP message types
*              except Uni type.
*
*       File:  st_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 StUiStuDatReq
(
Pst      *pst,           /* Post structure */
SpId      spId,          /* service provider id */
U8        msgType,       /* TCAP message type */
StDlgId   suDlgId,       /* service user dialog id */
StDlgId   spDlgId,       /* service provider dialogue id */
SpAddr   *dstAddr,       /* SCCP destination address - if needed */
SpAddr   *srcAddr,       /* SCCP source address - if needed */
Bool      endFlag,       /* If true then pre-arranged termination */
StQosSet *qos,           /* Quality of Service set for SCCP */
StDlgEv  *dlgEv,         /* tcap dialog portion event */
/* st014.301 - Add - new parameter for imp, isni fields */
#ifdef STUV2
StDataParam  *dataParam, /* other parameters of data primitive */
#endif /* STUV2 */
Buffer   *uiBuf          /* User info buffer */
)
#else
/* st014.301 - Modify - routine prototype modified to include new parameter */
#ifdef STUV2
PUBLIC S16 StUiStuDatReq(pst, spId, msgType, suDlgId, spDlgId, dstAddr,
                            srcAddr, endFlag, qos, dlgEv, dataParam, uiBuf)
#else /*  not STUV2 */
PUBLIC S16 StUiStuDatReq(pst, spId, msgType, suDlgId, spDlgId, dstAddr,
                         srcAddr, endFlag, qos, dlgEv, uiBuf)
#endif /* STUV2 */
Pst      *pst;           /* Post structure */
SpId      spId;          /* service provider id */
U8        msgType;       /* TCAP message type */
StDlgId   suDlgId;       /* service user dialog id */
StDlgId   spDlgId;       /* service provider dialogue id */
SpAddr   *dstAddr;       /* SCCP destination address - if needed */
SpAddr   *srcAddr;       /* SCCP source address - if needed */
Bool      endFlag;       /* If true then pre-arranged termination */
StQosSet *qos;           /* Quality of Service set for SCCP */
StDlgEv  *dlgEv;         /* tcap dialog portion event */
/* st014.301 - Add - new parameter for imp, isni fields */
#ifdef STUV2
StDataParam  *dataParam; /* other parameters of data primitive */
#endif /* STUV2 */
Buffer   *uiBuf;         /* User info buffer */
#endif
{
   StTUSap    *tuSapCp;  /* upper SAP for this dialogue */
   StSPSap    *spSapCp;  /* lower SAP for this dialogue */
   StDlgCp    *dlgCp;    /* dlg control point for this dialogue */
   Bool        dlgFlag;  /* flag to indicate if dlgCp is current */
   S16         ret;      /* return value indicating success or failure */
   StAcn       acn;      /* Application context name */
   TknBuf      usrInfo;  /* Token for User information */
   U8          abtReason;/* Abort reason */
   U8          abtCause; /* Abort Cause */
   /* st007.301 - Added - TC-User Distribution Feature */
   SuId      spSapId;      /* Lower SAP Id */
   /* st026.301 - Added - Temporary dialogue ID to send the comp
    * confirm in case of the tight coupling mode */
   StDlgId   tmpSpDlgId;

   TRC3(StUiStuDatReq)

   UNUSED(pst);

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Entered StUiStuDatReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StUiStuDatReq failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
          "StUiStuDatReq:spId(%d), msgType(%d), suDlgId(%ld), spDlgId(%ld)\n",
          spId, msgType, suDlgId, spDlgId));

   /* If not active then don't accept the data request */
#ifdef ZT
   if (!ztChkNCRsetStatus(spDlgId))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST153, (ErrVal)0, 
                 "StUiStuDatReq: Invalid PSF state");
#endif

      /* st023.301 - addition - free the user buffer in case of error */
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(uiBuf);

      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSTUDATREQ, 
                  (U8)spId);

      RETVALUE(RFAILED);
   }
#endif /* ZT */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (spId >= (SpId)stCb.genCfg.nmbSaps || spId < 0)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(uiBuf);

      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SPID, EVTSTUDATREQ, (U8)spId);

      STLOGERROR(ERRCLS_INT_PAR, EST154, (ErrVal)spId,
                 "StUiStuDatReq():spId out of range");

      RETVALUE(RFAILED);
   }
#endif

   /* Get the Upper SAP associated to the spId */
   if ((tuSapCp = *(stCb.tuSapLst + spId)) == NULLP)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(uiBuf);
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSTUDATREQ, (U8)spId);

#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST155, (ErrVal)spId,
                 "StUiStuDatReq:Upper Sap not configured");
#endif
      RETVALUE(RFAILED);
   }
 
   /* check state of the Upper SAP */
   if (tuSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(uiBuf);
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSTUDATREQ, (U8)spId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
             "StUiStuDatReq:Upper SAP(%d) is not bound, SAP state is %d\n", 
             spId, tuSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   /* st007.301 - Added - TC-User Distribution Feature */
   /* Find or Make association from upper to lower SAP */
   spSapId = stMakeUtoLSapAssoc(spId);
#ifdef ST_TC_USER_DIST   
   if (spSapId == ST_DEF_ASSOC_SAP_ID)
   {  
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(uiBuf);
      /* Generate alarm to LM and return */     
      stSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_UI_INV_EVT,
                     LST_CAUSE_SPSAP_ASSOC_FAIL, EVTSTUDATREQ, (U8)spId);
      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
             "StUiStuDatReq:No lower SAP can be associated for upper SAP(%d)\n",
             spId));
      RETVALUE(RFAILED);
   }  
#endif /* ST_TC_USER_DIST */
   
   /* st007.301 - Modified - TC-User Distribution Feature */
   /* Get the Lower SAP associated to the spId */
   if ((spSapCp = *(stCb.spSapLst + spSapId)) == NULLP)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(uiBuf);
      /* st012.301 -Modify- changed spId to spSapId */
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSTUDATREQ, (U8)spSapId);

#if (ERRCLASS & ERRCLS_INT_PAR)
      /* st012.301 -Modify- changed spId to spSapId */
      STLOGERROR(ERRCLS_INT_PAR, EST156, (ErrVal)spSapId,
                 "StUiStuDatReq:Lower Sap not configured");
#endif
      RETVALUE(RFAILED);
   }
 
   /* check state of the Lower SAP */
   if (spSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(uiBuf);
      /* st012.301 -Modify- changed spId to spSapId */
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSTUDATREQ, (U8)spSapId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
             "StUiStuDatReq:Lower SAP(%d) is not bound, SAP state is %d\n",
             spSapId, spSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   /* Get the new style message type */
   (Void)stGetNewMsgType(&msgType);

   /* If message type is unknown, return error */
   if (msgType == ST_MSG_TYP_UNK)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(uiBuf);

      if (!stCb.errCntrlFlg)
      {
         stSendAlarm(LCM_CATEGORY_PROTOCOL, LST_EVENT_UNKN_MSG,
                     LCM_CAUSE_UNKNOWN, EVTSTUDATREQ, (U8)msgType);

#if (ERRCLASS & ERRCLS_INT_PAR)
         STLOGERROR(ERRCLS_INT_PAR, EST157, (ErrVal)msgType,
                    "StUiStuDatReq:Unknown msgType");
#endif
         RETVALUE(RFAILED);
      }
      else
      {
         switch(tuSapCp->cfg.swtch)
         {
            case LST_SW_ITU88:
            case LST_SW_ITU92:
            case LST_SW_ITU96:
               abtCause = STU_ABORT_UNREC_MSG; /* Unrecognized message type */
               break;
            default:
               /* st009.301 -Add-  Print debug info */
               STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
                      "StUiStuDatReq: Protocol switch(%d) not supported\n",
                      tuSapCp->cfg.swtch));
               RETVALUE(RFAILED);
         }
         /* Generate local abort to the user */
         stGenLocPAbt(tuSapCp, suDlgId, spDlgId, abtCause, qos,
                      dstAddr, srcAddr);
         RETVALUE(ROK);
      }
   }

   /* flag to indicate if dlgCp points to a valid dialogue instance */
   dlgFlag = FALSE;

   /* Get the dialogue if already exists in the dialogue table maintained
      on per SAP basis */
   if (spDlgId == 0)
   {
      /* Use suDlgId to find the dialouge instance in the Dialogue hash list */
      if (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, suDlgId, ST_USE_SUDLGID, &dlgCp) == ROK)
      {
         /* Indicate dlgCp containes the current dlg control point */
         dlgFlag = TRUE;     
      }
   }
   else
   {
      if (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, spDlgId, ST_USE_SPDLGID, &dlgCp) == ROK)
      {
         dlgFlag = TRUE;
      }
   }
 
   /* Create dialogue if not already exists and the message being sent
      is BEGIN */
/* st044.301 - Addition - Added condition for ANS96 when need to create dialogue */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
#else  /* SS7_ANSXX */
   if ((dlgFlag != TRUE) && (msgType == ST_MSG_TYP_BGN))
#endif /* SS7_ANSXX */
   {
#ifndef ZT         
/* st043.301 - Modification - Added suDlgId parameter in stAllocDlg */
      if ((ret = stAllocDlg(tuSapCp, &dlgCp, suDlgId)) != ROK)
#else
      if ((ret = stAllocDlg(tuSapCp, &dlgCp, suDlgId, 0,
                            NULLP, CMFTHA_IF_UPPER)) != ROK)
#endif /* ZT */
      {
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(uiBuf);
         if (stCb.errCntrlFlg)
         {
            switch(tuSapCp->cfg.swtch)
            {
               case LST_SW_ITU88:
               case LST_SW_ITU92:
               case LST_SW_ITU96:
                  abtCause = STU_ABORT_RESOURCE; /* Resource not available */
                  break;
               default:
                  /* st009.301 -Add-  Print debug info */
                  STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
                         "StUiStuDatReq: Protocol switch(%d) not supported\n",
                         tuSapCp->cfg.swtch));
                  RETVALUE(RFAILED);
            }
            /* Generate local abort to the user */
            stGenLocPAbt(tuSapCp, suDlgId, spDlgId, abtCause, qos,
                         dstAddr, srcAddr);
            RETVALUE(ROK);
         }
         RETVALUE(RFAILED);
      }
   }
   /* Otherwise raise an Alarm to inform user that the message type is not
      expected here */
   else
   {
/* st044.301 - Addition - Added condition for ANS96 for uexpected message type   */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
#else  /* SS7_ANSXX */
      if ((dlgFlag != TRUE) && (msgType != ST_MSG_TYP_BGN))
#endif /* SS7_ANSXX */
      {
         /* st023.301 - addition - free the user buffer in case of error */
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(uiBuf);

         if (!stCb.errCntrlFlg)
         {
            stSendAlarm(LCM_CATEGORY_PROTOCOL, LST_EVENT_UX_MSG,
                        LCM_CAUSE_UNKNOWN, EVTSTUDATREQ, (U8)msgType);

#if (ERRCLASS & ERRCLS_INT_PAR)
            STLOGERROR(ERRCLS_INT_PAR, EST158, (ErrVal)msgType,
                       "StUiStuDatReq():Unexpected msgType");
#endif   /* ERRCLASS & ERRCLS_INT_PAR */

            RETVALUE(RFAILED);
         }
         else
         {
            /* Generate local abort to the user */
            stGenLocPAbt(tuSapCp, suDlgId, spDlgId, STU_ABORT_UNEXP_MSG, qos,
                         dstAddr, srcAddr);
            RETVALUE(ROK);
         }
      }
   }
 
   /* Save the User's dialogue Id, if not already saved */
   if (dlgCp->suDlgId == 0)
   {
      dlgCp->suDlgId = suDlgId;
   }

   /* If the user infor buffer has zero length then treat it as NULL buffer */
   if (uiBuf != NULLP)
   {
      MsgLen   bufLen;

      (Void)SFndLenMsg(uiBuf, &bufLen);
      if (bufLen == 0)
      {
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(uiBuf);
      }
   }

   /* Initialize the return value */
   ret = ROK;

   /* st.026.301 - Add - Save the dalogue ID in the temp for later use */
   tmpSpDlgId = dlgCp->spDlgId;

   /* st014.301 -Addition- initialise the global strucutre stDataParam */
#ifdef SPTV2
   stDataParam.imp.pres = NOTPRSNT;
#endif /* SPTV2 */

#if (defined(SS7_ANS96) && defined(SPTV2))
   stDataParam.isni.isniPres = NOTPRSNT;
#endif

#ifdef STUV2
   stInitStuDataParam(dataParam, tuSapCp->cfg.swtch);
#endif /* STUV2 */

   switch(tuSapCp->cfg.swtch)
   {
      case LST_SW_ITU88:
      case LST_SW_ITU92:
      case LST_SW_ITU96:

         acn.pres     = FALSE;
         usrInfo.pres = FALSE;
         usrInfo.val  = NULLP;
         abtReason    = 0;

         /* Copy the dialogue event structure to the local variables */
         if ((tuSapCp->cfg.swtch != LST_SW_ITU88) && (dlgEv) && (dlgEv->pres))
         {
            acn.pres = TRUE;
            acn.len  = (U8)dlgEv->apConName.len;
            if (acn.len == 0)
            {
               acn.pres = FALSE;
            }
            ST_CPY_STR(acn.val, dlgEv->apConName.string, acn.len);

            if (dlgEv->resPres)
            {
               abtReason = dlgEv->resReason;
            }
         }

         /* user information */
         if (uiBuf != NULLP)
         {
            usrInfo.pres = TRUE;
            usrInfo.val  = uiBuf;
         }

         switch(msgType)
         {
            case ST_MSG_TYP_BGN:

               /* save dst and src SCCP  addresses in dialog control point */
               cmCopySpAddr(dstAddr, &dlgCp->dstAddr);
               cmCopySpAddr(srcAddr, &dlgCp->srcAddr);
 
               ret = stDHTxBgn(dlgCp, &acn, &usrInfo, qos);
               break;

            case ST_MSG_TYP_CNT:

               /* Save dst and src SCCP  addresses in dialog control point
                  only for the first backward continue */
               stChkTsmStAddr(dlgCp, dstAddr, srcAddr);
 
               ret = stDHTxCnt(dlgCp, &acn, &usrInfo, qos);
               break;

            case ST_MSG_TYP_END:
               stChkTsmStAddr(dlgCp, dstAddr, srcAddr);
               stDHTxEnd(dlgCp, endFlag, &acn, &usrInfo, qos);
               break;

            case ST_MSG_TYP_UABT:

               stChkTsmStAddr(dlgCp, dstAddr, srcAddr);
               stDHTxUAbt(dlgCp, abtReason, ST_ABT_SRC_SU, &acn, &usrInfo, qos);
               break;

            default:
               /* st009.301 -Add-  Print debug info */
               STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
                      "StUiStuDatReq: Message type(%d) not supported\n",
                      msgType));
               break;
         }
         break;

      default:
         /* st009.301 -Add-  Print debug info */
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "StUiStuDatReq: Protocol switch(%d) not supported\n",
                tuSapCp->cfg.swtch));
         break;
   }

   /* st025.301 - Modification - free the user buffer in case of error */
   if (ret != ROK)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(uiBuf);
      if (stCb.errCntrlFlg)
      {
         /* Generate local abort to the user */
         stGenLocPAbt(tuSapCp, suDlgId, spDlgId, STU_ABORT_MISC_ERR, qos,
                      dstAddr, srcAddr);
      }
      RETVALUE(ROK);
   }

   /* st026.301 - Modify - Moved from the end of this proc to here as we may
    * return depending on the message type. */
#ifdef ZT
   ztUpdPeer();
#endif /* ZT */

   /* st026.301 - Add - Check if this is begin package and the 
    * dialogue is still valid */
   switch (tuSapCp->cfg.swtch)
   {

      case LST_SW_ITU88:
      case LST_SW_ITU92:
      case LST_SW_ITU96:
           if ( msgType != ST_MSG_TYP_BGN )
              RETVALUE(ROK);
           break;


      default:
           break;
   } /* switch */

   /* st026.301 - Add - Check the dialoge control point for validity as it may
    * not be valid in the tight coupling mode */
   if ( stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, tmpSpDlgId, ST_USE_SPDLGID, &dlgCp) == ROK )
   {
      /* If user passed spDlgId as zero, let it know the spDlgId */
      if ((spDlgId == 0) || (spDlgId != dlgCp->spDlgId))
      {
         (Void)StUiStuCmpCfm(&tuSapCp->pstTU,
                             tuSapCp->suId,
                             suDlgId,
                             dlgCp->spDlgId);
      }
   } /* End st026.301 */

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Leaving StUiStuDatReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif
   RETVALUE(ROK);
}  /* end of StUiStuDatReq */


/*
*
*       Fun:   TCAP Unstructured Data Request
*
*       Desc:  Request to send Unidirectional Message of TCAP
*
*       Ret:   ROK      - ok
*
*       Notes: This is the entry point for the unidirectional message.
*
*       File:  st_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 StUiStuUDatReq
(
Pst      *pst,           /* Post structure */
SpId      spId,          /* provider id */
StDlgId   suDlgId,       /* dialog id */
StDlgId   spDlgId,       /* Dialog Id assigned by TCAP (0 in BEGIN) */
SpAddr   *dstAddr,       /* SCCP destination address - if needed */
SpAddr   *srcAddr,       /* SCCP source address - if needed */
StQosSet *qos,           /* TCAP Quality of Service */
StDlgEv  *dlgEv,         /* tcap dialog portion event */
/* st014.301 - Add - new parameter for imp, isni fields */
#ifdef STUV2
StDataParam  *dataParam, /* other parameters of data primitive */
#endif /* STUV2 */
Buffer   *uiBuf          /* user information buffer */
)
#else
/* st014.301 - Modify - routine prototype modified to include new parameter */
#ifdef STUV2
PUBLIC S16 StUiStuUDatReq(pst, spId, suDlgId, spDlgId, dstAddr, srcAddr,
                          qos, dlgEv, dataParam, uiBuf)
#else /*  not STUV2 */
PUBLIC S16 StUiStuUDatReq(pst, spId, suDlgId, spDlgId, dstAddr, srcAddr,
                          qos, dlgEv, uiBuf)
#endif /* STUV2 */
Pst      *pst;           /* Post structure */
SpId      spId;          /* provider id */
StDlgId   suDlgId;       /* dialog id */
StDlgId   spDlgId;       /* Dialog Id assigned by TCAP (0 in BEGIN) */
SpAddr   *dstAddr;       /* SCCP destination address - if needed */
SpAddr   *srcAddr;       /* SCCP source address - if needed */
StQosSet *qos;           /* TCAP Quality of Service */
StDlgEv  *dlgEv;         /* tcap dialog portion event */
/* st014.301 - Add - new parameter for imp, isni fields */
#ifdef STUV2
StDataParam  *dataParam; /* other parameters of data primitive */
#endif /* STUV2 */
Buffer   *uiBuf;         /* user information buffer */
#endif
{
   StTUSap    *tuSapCp;  /* upper SAP for this dialogue */
   StSPSap    *spSapCp;  /* lower SAP for this dialogue */
   StDlgCp    *dlgCp;    /* dlg control point for this dialogue */
   Bool        dlgFlag;  /* flag to indicate if dlgCp is current */
   StAcn       acn;      /* Token for application context name */
   TknBuf      usrInfo;  /* Token for user information */

   /* st007.301 - Added - TC-User Distribution Feature */
   SuId      spSapId;     /* Lower SAP Id */

   TRC3(StUiStuUDatReq)

   UNUSED(pst);

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Entered StUiStuUDatReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StUiStuUDatReq failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
          "StUiStuUDatReq:spId(%d), suDlgId(%ld), spDlgId(%ld)\n",
          spId, suDlgId, spDlgId));

   /* If not active then don't accept the data request */
#ifdef ZT
   if (!ztChkNCRsetStatus(spDlgId))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST159, (ErrVal)0, 
                 "StUiStuUDatReq: Invalid PSF state");
#endif
      /* st023.301 - addition - free the user buffer in case of error */
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(uiBuf);

      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSTUUDATREQ, 
                  (U8)spId);

      RETVALUE(RFAILED);
   }
#endif /* ZT */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (spId >= (SpId)stCb.genCfg.nmbSaps || spId < 0)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(uiBuf);
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SPID, EVTSTUUDATREQ, (U8)spId);

      STLOGERROR(ERRCLS_INT_PAR, EST160, (ErrVal)spId,
                 "StUiStuUDatReq():spId out of range");

      RETVALUE(RFAILED);
   }
#endif

   /* Get the Upper SAP associated to the spId */
   if ((tuSapCp = *(stCb.tuSapLst + spId)) == NULLP)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(uiBuf);
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSTUUDATREQ, (U8)spId);

#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST161, (ErrVal)spId,
                 "StUiStuUDatReq:Upper Sap not configured");
#endif
      RETVALUE(RFAILED);
   }
 
   /* check state of the Upper SAP */
   if (tuSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(uiBuf);

      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSTUUDATREQ, (U8)spId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
             "StUiStuUDatReq:Upper SAP(%d) not bound, state is (%d)\n",
             spId, tuSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   /* st007.301 - Added - TC-User Distribution Feature */
   /* Find or Make association from upper to lower SAP */
   spSapId = stMakeUtoLSapAssoc(spId);

#ifdef ST_TC_USER_DIST   
   /* No lower SAP exists for this upper SAP */
   if (spSapId == ST_DEF_ASSOC_SAP_ID)
   {  
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(uiBuf);
      /* Generate alarm to LM and return */     
      stSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_UI_INV_EVT,
                     LST_CAUSE_SPSAP_ASSOC_FAIL, EVTSTUDATREQ, (U8)spId);
      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
            "StUiStuUDatReq:No lower SAP can be associated for upper SAP(%d)\n",
            spId));
      RETVALUE(RFAILED);
   }  
#endif /* ST_TC_USER_DIST */   

   /* st007.301 - Modified - TC-User Distribution Feature */
   /* Get the Lower SAP associated to the spId */
   if ((spSapCp = *(stCb.spSapLst + spSapId)) == NULLP)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(uiBuf);
      /* st012.301 -Modified- spId changed to spSapId */
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSTUUDATREQ, (U8)spSapId);

#if (ERRCLASS & ERRCLS_INT_PAR)
      /* st012.301 -Modified- spId changed to spSapId */
      STLOGERROR(ERRCLS_INT_PAR, EST162, (ErrVal)spSapId,
                 "StUiStuUDatReq:Lower Sap not configured");
#endif
      RETVALUE(RFAILED);
   }
 
   /* check state of the Lower SAP */
   if (spSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(uiBuf);
      /* st012.301 -Modified- spId changed to spSapId */
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSTUUDATREQ, (U8)spSapId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
             "StUiStuDatReq:Lower SAP(%d) not bound\n",spSapId));
      RETVALUE(RFAILED);
   }

   dlgFlag = FALSE;

   /* Get the dialogue if already exists in the dialogue table maintained
      on per SAP basis */
   if (spDlgId == 0)
   {
      if (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, suDlgId, ST_USE_SUDLGID, &dlgCp) == ROK)
      {
         /* Indicate dlgCp containes the current dlg control point */
         dlgFlag = TRUE;     
         spDlgId = dlgCp->spDlgId;
      }
   }
   else
   {
      if (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, spDlgId, ST_USE_SPDLGID, &dlgCp) == ROK)
      {
         dlgFlag = TRUE;
      }
   }
 
   /* Dialogue should already exists for Uni Message. Since component portion
      is mandatory and dialogue is created in the component request */

   if (dlgFlag != TRUE)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(uiBuf);

#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST163, (ErrVal)0,
                 "StUiStuUDatReq:Dialogue doesn't exist");
#endif
      RETVALUE(RFAILED);
   }
 
   /* Copy SCCP addresses in the associated dialogue control point */
   cmCopySpAddr(dstAddr, &dlgCp->dstAddr);
   cmCopySpAddr(srcAddr, &dlgCp->srcAddr);

   /* If the user infor buffer has zero length then treat it as NULL buffer */
   if (uiBuf != NULLP)
   {
      MsgLen   bufLen;

      (Void)SFndLenMsg(uiBuf, &bufLen);
      if (bufLen == 0)
      {
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(uiBuf);
      }
   }

   /* st014.301 -Addition- initialise the global strucutre stDataParam */
#ifdef SPTV2
   stDataParam.imp.pres = NOTPRSNT;
#endif /* SPTV2 */

#if (defined(SS7_ANS96) && defined(SPTV2))
   stDataParam.isni.isniPres = NOTPRSNT;
#endif

#ifdef STUV2
   stInitStuDataParam(dataParam, tuSapCp->cfg.swtch);
#endif /* STUV2 */

   switch(tuSapCp->cfg.swtch)
   {
      case LST_SW_ITU88:
      case LST_SW_ITU92:
      case LST_SW_ITU96:

         acn.pres     = FALSE;
         usrInfo.pres = FALSE;
         usrInfo.val  = NULLP;

         if ((dlgEv) && (dlgEv->pres))
         {
            acn.pres = TRUE;
            acn.len  = (U8)dlgEv->apConName.len;
            ST_CPY_STR(acn.val, dlgEv->apConName.string, acn.len);

            if (uiBuf != NULLP)
            {
               usrInfo.pres = TRUE;
               usrInfo.val  = uiBuf;
            }
         }

         stDHTxUni(dlgCp, &acn, &usrInfo, qos);
         break;


      default:
         /* st009.301 -Add-  Print debug info */
         STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
             "StUiStuUDatReq: Protocol switch(%d) not supported\n",
             tuSapCp->cfg.swtch));
         break;
   }

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Leaving StUiStuUDatReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif
   RETVALUE(ROK);
}  /* end of StUiStuUDatReq */


/*
*
*       Fun:   TCAP User Component Request
*
*       Desc:  This function asks the component coordinator to handle
*              the given component.
*
*       Ret:   ROK      - ok
*
*       Notes: For a UNI the invoke ID is not associated 
*
*       File:  st_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 StUiStuCmpReq
(
Pst      *pst,           /* Post structure */
SpId      spId,          /* service provider id number */
StDlgId   suDlgId,       /* dialog ID for this component */
StDlgId   spDlgId,       /* Dialog Id assigned by TCAP (0 in BEGIN) */
StComps  *oCompEv,       /* component being passed */
Buffer   *cpBuf          /* component parameters being passed */
)
#else
PUBLIC S16 StUiStuCmpReq(pst, spId, suDlgId, spDlgId, oCompEv, cpBuf)
Pst      *pst;           /* Post structure */
SpId      spId;          /* service provider id number */
StDlgId   suDlgId;       /* dialog ID for this component */
StDlgId   spDlgId;       /* Dialog Id assigned by TCAP (0 in BEGIN) */
StComps  *oCompEv;       /* component being passed */
Buffer   *cpBuf;         /* component parameters being passed */
#endif
{
   StTUSap      *tuSapCp;      /* upper SAP for this dialogue */
   StDlgCp      *dlgCp;        /* dlg control point for this dialogue */
   StInvCp      *invCp;        /* Inv control point */
   Bool          dlgFlag;      /* flag to indicate if dlgCp is current */
   PTR           nCompEv;      /* Pointer to new style component event */
   StItuCompEv   ituCompEv;    /* Component Event for Itu TCAP */
   U8            probType;     /* Problem type */
   StInvId       invId;        /* Invoke Id */

   TRC3(StUiStuCmpReq)

   UNUSED(pst);

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Entered StUiStuCmpReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StUiStuCmpReq failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
          "StUiStuCmpReq:spId(%d), suDlgId(%ld), spDlgId(%ld)\n",
          spId, suDlgId, spDlgId));

   /* If not active then don't accept the component request */
#ifdef ZT
   if (!ztChkNCRsetStatus(spDlgId))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST164, (ErrVal)0, 
                 "StUiStuCmpReq: Invalid PSF state");
#endif

      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSTUCMPREQ, 
                  (U8)spId);

      RETVALUE(RFAILED);
   }
#endif /* ZT */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (spId >= (SpId)stCb.genCfg.nmbSaps || spId < 0)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(cpBuf);
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SPID, EVTSTUCMPREQ, (U8)spId);

      STLOGERROR(ERRCLS_INT_PAR, EST165, (ErrVal)spId,
                 "StUiStuCmpReq():spId out of range");

      RETVALUE(RFAILED);
   }
#endif

   /* Get the Upper SAP associated to the spId */
   if ((tuSapCp = *(stCb.tuSapLst + spId)) == NULLP)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(cpBuf);
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSTUCMPREQ, (U8)spId);

#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST166, (ErrVal)spId,
                 "StUiStuCmpReq:Upper Sap not configured");
#endif
      RETVALUE(RFAILED);
   }
 
   /* check state of the Upper SAP */
   if (tuSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(cpBuf);
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSTUCMPREQ, (U8)spId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
             "StUiStuCmpReq:Upper SAP(%d) is not bound, SAP state is %d\n", 
             spId,tuSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   dlgFlag = FALSE;

   /* Get the dialogue if already exists in the dialogue table maintained
      on per SAP basis */
   if (spDlgId == 0)
   {
      if (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, suDlgId, ST_USE_SUDLGID, &dlgCp) == ROK)
      {
         /* Indicate dlgCp containes the current dlg control point */
         dlgFlag = TRUE;     
      }
   }
   else
   {
      if (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, spDlgId, ST_USE_SPDLGID, &dlgCp) == ROK)
      {
         dlgFlag = TRUE;
      }
   }
 
   /* The timer reset operation is allowed only for ITU-96 TCAP */
   if ((tuSapCp->cfg.swtch != LST_SW_ITU96) &&
       (oCompEv->stCompType == STU_TMR_RESET))
   {
      /* st023.301 - addition - free the user buffer in case of error */
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(cpBuf);

#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST167, (ErrVal)0,
                 "StUiStuCmpReq:Timer reset not allowed for this protocol type");
#endif
      RETVALUE(RFAILED);
   }

   /* Dialogue should already be established for timer reset operation */
   if ((tuSapCp->cfg.swtch == LST_SW_ITU96) &&
       (oCompEv->stCompType == STU_TMR_RESET))
   {
      if (dlgFlag != TRUE)
      {
         /* st023.301 - addition - free the user buffer in case of error */
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(cpBuf);

#if (ERRCLASS & ERRCLS_INT_PAR)
         STLOGERROR(ERRCLS_INT_PAR, EST168, (ErrVal)0,
                    "StUiStuCmpReq:Dialogue doesn't exist for timer reset");
#endif
         RETVALUE(RFAILED);
      }
      if (stFndInv(&dlgCp->invHlCp, oCompEv->stInvokeId.octet, &invCp)
                   != ROK)
      {
         /* st023.301 - addition - free the user buffer in case of error */
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(cpBuf);

#if (ERRCLASS & ERRCLS_INT_PAR)
         STLOGERROR(ERRCLS_INT_PAR, EST169, (ErrVal)0,
                    "StUiStuCmpReq:Invoke doesn't exist for timer reset");
#endif
         RETVALUE(RFAILED);
      }
      /* Stop the existing timer and restart it */
      stStopTmr(ST_INV_TMR, invCp);
      if (stStartTmr(ST_INV_TMR, (PTR)invCp) != ROK)
      {
         /* st023.301 - addition - free the user buffer in case of error */
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(cpBuf);

#if (ERRCLASS & ERRCLS_INT_PAR)
         STLOGERROR(ERRCLS_INT_PAR, EST170, (ErrVal)0,
                "StUiStuCmpReq:Timer couldn't be refreshed, timer value 0");
#endif
         RETVALUE(RFAILED);
      }
      RETVALUE(ROK);
   }

   /* Dialogue should already exist for the cancel request */
   if ((oCompEv->cancelFlg) && (!dlgFlag))
   {
      /* st023.301 - addition - free the user buffer in case of error */
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(cpBuf);

#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST171, (ErrVal)0,
                 "StUiStuCmpReq:Dialogue doesn't exist for cancel request");
#endif
      RETVALUE(RFAILED);
   }

   /* st028.301 - Modify - TCAP doesn't allocate a
    * new dialogue if spDlgId != 0 */
   /* Create dialogue if not already exists */
   if (dlgFlag != TRUE && spDlgId == 0)
   {
   
#ifndef ZT         
/* st043.301 - Modification - Added suDlgId parameter in stAllocDlg */
      if (stAllocDlg(tuSapCp, &dlgCp, suDlgId) != ROK)
#else
      if (stAllocDlg(tuSapCp, &dlgCp, suDlgId, 0, 
                     NULLP, CMFTHA_IF_UPPER) != ROK)
#endif /* ZT */ 
      {
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(cpBuf);
         if (stCb.errCntrlFlg)
         {
            switch(tuSapCp->cfg.swtch)
            {
               case LST_SW_ITU88:
               case LST_SW_ITU92:
               case LST_SW_ITU96:
                  probType = STU_PROB_GENERAL; /* General Problem Type */
                  invId    = oCompEv->stInvokeId.octet;
                  break;
               default:
                  /* st009.301 -Add-  Print debug info */
                  STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
                         "StUiStuCmpReq: Protocol switch(%d) not supported\n",
                         tuSapCp->cfg.swtch));
                  RETVALUE(RFAILED);
            }
            /* Generate local Reject to the user */
            stGenLocRej(tuSapCp, suDlgId, spDlgId, invId, probType,
                        STU_RSRC_UNAVAIL);
            RETVALUE(ROK);
         }
         RETVALUE(RFAILED);
      }
   }
   /* st028.301 - Add - Release the user buffer and return
    * reject */
   else if(dlgFlag != TRUE && spDlgId != 0)
   {
      invId    = oCompEv->stInvokeId.octet;

      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "StUiStuCmpReq: Component with invokeId(%d) rejected \
              as dialouge doesn't exist and spDlgId is non zero\n", invId));

      STFREEUSERBUF(cpBuf);
      /* Generate local Reject to the user */
      stGenLocRej(tuSapCp, suDlgId, spDlgId, invId,
                  STU_PROB_INVOKE,
                  STU_UNREC_OPR);
      RETVALUE(ROK);
   }

   /* Save the User's dialogue Id, if not already saved */
   if (dlgCp->suDlgId == 0)
   {
      dlgCp->suDlgId = suDlgId;
   }

   switch(tuSapCp->cfg.swtch)
   {
      case LST_SW_ITU88:
      case LST_SW_ITU92:
      case LST_SW_ITU96:

         /* Check If a previous Invoke has to be canceled */
         if (oCompEv->cancelFlg)
         {
           (Void)stCHUCancel(dlgCp, oCompEv->stInvokeId.octet);
           break;
         }

         nCompEv = (PTR)&ituCompEv;

         /* A separate dialogue event structure has been defined in order to use
            common ASN.1 encoder/decoder, so copy the old style component event
            to the new component event */

         if (stCpyItuCompEv(oCompEv, (StItuCompEv *)nCompEv, &cpBuf, M1M2) != ROK)
         {
            /* st023.301 - addition - free the user buffer in case of error */
            /* st027.301 - Modify - Modify the user buf free mechanism */ 
            STFREEUSERBUF(cpBuf);

            if (stCb.errCntrlFlg)
            {
               /* Generate local Reject to the user */
               stGenLocRej(tuSapCp, suDlgId, spDlgId, oCompEv->stInvokeId.octet,
                           STU_PROB_GENERAL, STU_UNREC_COMP);
               RETVALUE(ROK);
            }
            else
            {
               stSendAlarm(LCM_CATEGORY_PROTOCOL, LST_EVENT_INV_COMPEV,
                           LCM_CAUSE_UNKNOWN, EVTSTUCMPREQ, (U8)spId);
               RETVALUE(RFAILED);
            }
         }

         /* Call Component handler function to process the Component event */
         if (stCHTxComp(dlgCp, (StItuCompEv *)nCompEv, oCompEv->stInvokeTimer,
                        oCompEv->opClass) != ROK)
         {
            /* st023.301 - addition - free the user buffer in case of error */
            /* st027.301 - Modify - Modify the user buf free mechanism */ 
            STFREEUSERBUF(cpBuf);

            RETVALUE(RFAILED);
         }
         break;

   }


   /* If user passed spDlgId as zero, let it know the spDlgId */
   if ((spDlgId == 0) || (spDlgId != dlgCp->spDlgId))
   {
      (Void)StUiStuCmpCfm(&tuSapCp->pstTU,
                           tuSapCp->suId,
                           suDlgId,
                           dlgCp->spDlgId);
   }

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Leaving StUiStuCmpReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif
   RETVALUE(ROK);
}   /* End of StUiStuCmpReq */


/*
*
*       Fun:   TCAP User state request 
*
*       Desc:  This function is used by TCAP layer to indicate to its peer
*              for SSN state change. The rqeuest is passed on to SSCP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 StUiStuSteReq
(
Pst           *pst,           /* Post structure */
SpId           spId,          /* service user id */
CmSS7SteMgmt  *steMgmt        /* State managemnet */
)
#else
PUBLIC S16 StUiStuSteReq(pst, spId, steMgmt)
Pst           *pst;           /* Post structure */
SpId           spId;          /* service user id */
CmSS7SteMgmt  *steMgmt;       /* State managemnet */
#endif
{
   StTUSap    *tuSapCp;       /* pointer to upper SAP */
   StSPSap    *spSapCp;       /* pointer to lower SAP */
   /* st007.301 - Added - TC-User Distribution Feature */
   SuId      spSapId;      /* Lower SAP Id */

   TRC3(StUiStuSteReq)

   UNUSED(pst);

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StUiStuSteReq failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
          "StUiStuSteReq:spId(%d)\n", spId));

   /* If not active then don't accept the data request */
#ifdef ZT
   if (!ztChkCRsetStatus())
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST172, (ErrVal)0, 
                 "StUiStuSteReq: Invalid PSF state");
#endif

      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSTUSTEREQ, 
                  (U8)spId);

      RETVALUE(RFAILED);
   }
#endif /* ZT */

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Check if spId is out of range */
   if (spId >= (SpId)stCb.genCfg.nmbSaps || spId < 0)
   {
      STLOGERROR(ERRCLS_INT_PAR, EST173, (ErrVal)spId,
                 "StUiStuSteReq():spId out of range");

      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SPID, EVTSTUSTEREQ, (U8)spId);

      RETVALUE(RFAILED);
   }
#endif

   /* Check if Upper SAP is already created for the spId */
   if ((tuSapCp = *(stCb.tuSapLst + spId)) == NULLP)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSTUSTEREQ, (U8)spId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
             "StUiStuSteReq:Upper Sap(%d) is not configured\n", spId));
      RETVALUE(RFAILED);
   }
  
   /* Check if Upper SAP is already bound */
   if (tuSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSTUSTEREQ, (U8)spId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
             "StUiStuSteReq:Upper SAP(%d) is not bound, SAP state is %d\n",
              spId, tuSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   /* st007.301 - Added - TC-User Distribution Feature */
   /* Find or Make association from upper to lower SAP */
   spSapId = stMakeUtoLSapAssoc(spId);

#ifdef ST_TC_USER_DIST   
   /* No lower SAP exists for this upper SAP */
   if (spSapId == ST_DEF_ASSOC_SAP_ID)
   {  
      /* Generate alarm to LM and return */     
      stSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_UI_INV_EVT,
                     LST_CAUSE_SPSAP_ASSOC_FAIL, EVTSTUSTEREQ, (U8)spId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
             "StUiStuSteReq:No lower SAP can be associated for upper SAP(%d)\n",
             spId));
      RETVALUE(RFAILED);
   }  
#endif /* ST_TC_USER_DIST */
   
   /* st007.301 - Modified - TC-User Distribution Feature */
   /* Check if lower SAP is already created for the spId */
   if ((spSapCp = *(stCb.spSapLst + spSapId)) == NULLP)
   {
      /* st012.301 -Modified- spId changed to spSapId */
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSTUSTEREQ, (U8)spSapId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
                 "StUiStuSteReq:Lower Sap(%d) is not configured\n",spSapId));
      RETVALUE(RFAILED);
   }
  
   /* Check if lower SAP is bound and enabled */
   if (spSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      /* st012.301 -Modified- spId changed to spSapId */
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSTUSTEREQ, (U8)spSapId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
             "StUiStuSteReq:Lower SAP(%d) not bound, SAP state is %d\n",
             spSapId,spSapCp->hlSt));
      RETVALUE(RFAILED);
   }
   switch(steMgmt->evntType)
   {
#ifdef STU2
      case EVTSSN_STA_REQ:

#ifdef SPT2
        StLiSptStaReq(&spSapCp->pstSP, spSapCp->spId,
                      steMgmt->mgmt.staReq.status,
                      steMgmt->mgmt.staReq.dpc,
                      steMgmt->mgmt.staReq.ssn);
#endif /* SPT2 */
        break;
#endif /* STU2 */

      case EVTSSN_STE_REQ:

        StLiSptSteReq(&spSapCp->pstSP, spSapCp->spId,
                      steMgmt->mgmt.steReq.aSsn,
                      steMgmt->mgmt.steReq.uStat);
        break;

      case EVTSSN_CORD_REQ:

        StLiSptCordReq(&spSapCp->pstSP, spSapCp->spId,
                       steMgmt->mgmt.cordReq.aSsn);
        break;

      default:

#if (ERRCLASS & ERRCLS_INT_PAR)
        STLOGERROR(ERRCLS_INT_PAR, EST174, (ErrVal)steMgmt->evntType, 
                   "StUiStuSteReq:bad Event type");

        RETVALUE(RFAILED);
#endif
        break;
   }

   RETVALUE(ROK);
} /* end of StUiStuSteReq */


/*
*
*       Fun:   TCAP User state response
*
*       Desc:  This function is used by TCAP layer to indicate to its peer
*              for SSN state change. The rqeuest is passed on to SSCP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 StUiStuSteRsp
(
Pst           *pst,           /* Post structure */
SpId           spId,          /* service user id */
CmSS7SteMgmt  *steMgmt        /* State managemnet */
)
#else
PUBLIC S16 StUiStuSteRsp(pst, spId, steMgmt)
Pst           *pst;           /* Post structure */
SpId           spId;          /* service user id */
CmSS7SteMgmt  *steMgmt;       /* State managemnet */
#endif
{
   StTUSap    *tuSapCp;       /* pointer to upper SAP */
   StSPSap    *spSapCp;       /* pointer to lower SAP */
   /* st007.301 - Added - TC-User Distribution feature */
   SuId      spSapId;      /* Lower SAP Id */

   TRC3(StUiStuSteRsp)

   UNUSED(pst);

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StUiStuSteRsp failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
          "StUiStuSteRsp:spId(%d)\n", spId));

   /* If not active then don't accept the data request */
#ifdef ZT
   if (!ztChkCRsetStatus())
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST175, (ErrVal)0, 
                 "StUiStuSteRsp: Invalid PSF state");
#endif

      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSTUSTERSP, 
                  (U8)spId);

      RETVALUE(RFAILED);
   }
#endif /* ZT */

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Check if spId is out of range */
   if (spId >= (SpId)stCb.genCfg.nmbSaps || spId < 0)
   {
      STLOGERROR(ERRCLS_INT_PAR, EST176, (ErrVal)spId,
                 "StUiStuSteRsp:spId out of range");

      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SPID, EVTSTUSTERSP, (U8)spId);

      RETVALUE(RFAILED);
   }
#endif

   /* Check if upper SAP is already created for the spId */
   if ((tuSapCp = *(stCb.tuSapLst + spId)) == NULLP)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSTUSTERSP, (U8)spId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
             "StUiStuSteRsp:Upper Sap(%d) is not configured\n", spId));
      RETVALUE(RFAILED);
   }
  
   /* Check if upper SAP is bound and enabled */
   if (tuSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSTUSTERSP, (U8)spId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
             "StUiStuSteRsp:Upper SAP(%d) is not bound, SAP state is %d\n",
             spId, tuSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   /* st007.301 - Added - TC-User Distribution Feature */
   /* Find or Make association from upper to lower SAP */
   spSapId = stMakeUtoLSapAssoc(spId);

#ifdef ST_TC_USER_DIST   
   /* No lower SAP exists for this upper SAP */
   if (spSapId == ST_DEF_ASSOC_SAP_ID)
   {  
      /* Generate alarm to LM and return */     
      stSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_UI_INV_EVT,
                     LST_CAUSE_SPSAP_ASSOC_FAIL, EVTSTUSTERSP, (U8)spId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
            "StUiStuSteRsp:No lower SAP can be associated for upper SAP (%d)\n",
            spId));
      RETVALUE(RFAILED);
   }  
#endif /* ST_TC_USER_DIST */
   
   /* st007.301 - Modified - TC-User Distribution Feature */
   /* Check if lower SAP is already created for the spId */
   if ((spSapCp = *(stCb.spSapLst + spSapId)) == NULLP)
   {
      /* st012.301 -Modify- changed spId to spSapId */ 
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSTUSTERSP, (U8)spSapId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
             "StUiStuSteRsp:Lower Sap(%d) is not configured\n", spSapId));
      RETVALUE(RFAILED);
   }
  
   /* Check if lower SAP is bound and enabled */
   if (spSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      /* st012.301 -Modify- changed spId to spSapId */ 
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSTUSTERSP, (U8)spSapId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_UI, (stCb.init.prntBuf,
             "StUiStuSteRsp:Lower SAP(%d) not bound, SAP state %d\n",
             spSapId,spSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   StLiSptCordRsp(&spSapCp->pstSP, spSapCp->spId, steMgmt->mgmt.cordRsp.aSsn);

   RETVALUE(ROK);
} /* end of StUiStuSteRsp */


/*
*     interface functions to the SCCP layer protocol.
*/

/*
*
*       Fun:   SCCP Data Indication
*
*       Desc:  This function informs the TCAP Layer that valid data
*              has been received.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 StLiSptUDatInd
(
Pst        *pst,              /* post structure */
SuId        suId,             /* service user id */
Dpc         opc,              /* calling address originating point code */
SpUDatEvnt *uDataEv,          /* unit data event */
Buffer     *mBuf              /* message buffer pointer */
)
#else
PUBLIC S16 StLiSptUDatInd(pst, suId, opc, uDataEv, mBuf)
Pst        *pst;              /* post structure */
SuId        suId;             /* service user id */
Dpc         opc;              /* calling address originating point code */
SpUDatEvnt *uDataEv;          /* unit data event */
Buffer     *mBuf;             /* message buffer pointer */
#endif
{
   StSPSap   *spSapCp;        /* TCAP lower sap */
   StTUSap   *tuSapCp;        /* TCAP upper sap */
   StQosSet   qos;            /* Quality of service set */
   StMsgEv    msgEv;          /* Transaction portion event structure */
#ifdef ZT
   StDlgId    dlgId;          /* dialogue Id */
#ifdef ZT_DFTHA
   Bool       bgnFlag;        /* flag for BEGIN message */
#endif /* ZT_DFTHA */   
#endif /* ZT */   
   /* st007.301 - Added - TC-User Distribution Feature */
   SpId       tuSapId;        /* Upper SAP Id */
   Reason     reason;         /* Failure reason */

   TRC3(StLiSptUDatInd)

   UNUSED(pst);

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StLiSptUDatInd failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_LI, (stCb.init.prntBuf, "StLiSptUDatInd:suId(%d)\n", suId));

#ifdef ZT
   /* Initialize the dlgId variable */
   dlgId = 0;
#endif /* ZT */   

   /* If not active then don't accept the data indication */
#ifdef ZT
   /* check the incoming message if not the first one, then check
    * the resource set status for this msg, if not then just go ahead
    * and don't check any things.
    */
#ifdef ZT_DFTHA
   if(ZT_IS_DIST_FTHA)
   {
      if ((ztChkBgnMsg(suId, mBuf, &bgnFlag, &dlgId) == ROK) && 
           (bgnFlag != TRUE))
      {
         if (!ztChkNCRsetStatus(dlgId))
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            STLOGERROR(ERRCLS_INT_PAR, EST177, (ErrVal)0, 
                       "StLiSptUDatInd: Invalid PSF state");
#endif
            stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                        LCM_CAUSE_PROT_NOT_ACTIVE, EVTSPTUDATIND, 
                        (U8)suId);

            /* st025.301-addition, free the message buffer in case of error */
            /* st027.301 - Modify - Modify the user buf free mechanism */ 
            STFREEUSERBUF(mBuf);
            RETVALUE(RFAILED);
         }
      }
   }
   else
#endif /* ZT_DFTHA */
   {
      if (!ztChkNCRsetStatus(dlgId))
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         STLOGERROR(ERRCLS_INT_PAR, EST178, (ErrVal)0, 
                    "StLiSptUDatInd: Invalid PSF state");
#endif
         stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                     LCM_CAUSE_PROT_NOT_ACTIVE, EVTSPTUDATIND, 
                     (U8)suId);

         /* st025.301 - addition, free the message buffer in case of error */
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(mBuf);
         RETVALUE(RFAILED);
      }
   }
#endif /* ZT */
   
#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate buffer pointer */
   if (mBuf == NULLP)
   {
       STLOGERROR(ERRCLS_INT_PAR, EST179, (ErrVal)mBuf,
                  "StLiSptUDatInd:Null Message Buffer");
       RETVALUE(RFAILED);
   }

   /* Check if spId is out of range */
   if (suId >= (SpId)stCb.genCfg.nmbSaps || suId < 0)
   {
      STLOGERROR(ERRCLS_INT_PAR, EST180, (ErrVal)suId, 
                 "StLiSptUDatInd:suId out of range");

      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SUID, EVTSPTUDATIND, (U8)suId);

      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

      RETVALUE(RFAILED);
   }
#endif

   /* Check if lower SAP is created for the suId */
   if ((spSapCp = *(stCb.spSapLst + suId)) == NULLP)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSPTUDATIND, (U8)suId);

      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptUDatInd:Lower SAP(%d) does not exist\n", suId));
      RETVALUE(RFAILED);
   }
  
   /* Check if the lower SAP is enabled */
   if (spSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSPTUDATIND, (U8)suId);

      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptUDatInd:Lower SAP(%d) is not bound, SAP state is %d\n",
             suId,spSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   /* st007.301 - Added - TC-User Distribution Feature */
   reason = 0; /* Initialize reason code */
   /* Find or Make association from lower to upper SAP */
   tuSapId = stMakeLtoUSapAssoc(suId,mBuf,uDataEv,TRUE, &reason);
  
#ifdef ST_TC_USER_DIST
   /* Check if any decoding error occured */
   if (reason == ST_DEC_PROB)
   {
     /* st027.301 - Modify - Modify the user buf free mechanism */ 
     STFREEUSERBUF(mBuf);
 
     /* Decoding problem already handled in stMakeLtoUSapAssoc, return */
     RETVALUE(ROK);
   }  
   
   /* If association cannot be found or established */
   if (tuSapId == ST_DEF_ASSOC_SAP_ID)
   {  
      /* Generate alarm to LM  */     
      stSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_UI_INV_EVT,
                     LST_CAUSE_TUSAP_ASSOC_FAIL, EVTSTUDATREQ, (U8)suId);
      
      /* Handle association problem according to protocol specification */
      stHandleAssocFail(suId,mBuf,uDataEv);
      
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);
      
      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
           "StLiSptUDatInd:Upper SAP cannot be associated for lower SAP(%d)\n",
           suId));
      RETVALUE(RFAILED);
   }  
#endif /* ST_TC_USER_DIST */
   
   /* st007.301 - Modified - TC-User Distribution Feature,
    *             Deleted  - Comment */
   /* Check if upper SAP is created for the suId */
   if ((tuSapCp = *(stCb.tuSapLst + tuSapId)) == NULLP)
   {
      /* st012.301 -Modify- changed suId to tuSapId */ 
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSPTUDATIND, (U8)tuSapId);

      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptUDatInd:Upper Sap(%d) is not configured\n", tuSapId));
      RETVALUE(RFAILED);
   }
  
   /* Check if the upper SAP is enabled */
   if (tuSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      /* st012.301 -Modify- changed suId to tuSapId */ 
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSPTUDATIND, (U8)tuSapId);

      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptUDatInd:Upper SAP(%d) is not bound, SAP state is %d\n",
             tuSapId, tuSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   /* Generate a trace of the received event, if trace is enabled */
   if (stCb.init.trc)
   {
      stGenTrc(spSapCp->suId, LST_MSG_RECVD, mBuf);
   }

   /* Fill up quality of service set to be passed transparently to the user */
   qos.msgPrior = uDataEv->prior;
   qos.retOpt   = uDataEv->qos.retOpt;
   qos.seqCtl   = uDataEv->qos.pClass == PCLASS1 ? TRUE:FALSE;

   /* st014.301 -Addition- initialise the global strucutre stDataParam */
   stInitSptDataParam(uDataEv);

   /* Decode the transaction portion */
   if (stDecMsg(&msgEv, tuSapCp->cfg.swtch, mBuf,
                &msgEv.pAbtCause.val) != ROK)
   {
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
             "stLiSptUDatInd:Mesasge decoding problem, cause(%d)\n",
             msgEv.pAbtCause.val));

      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);   /* discard the message */

      switch(tuSapCp->cfg.swtch)
      {
         case LST_SW_ITU88:
         case LST_SW_ITU92:
         case LST_SW_ITU96:


             /* st009.301 -Add-  Print debug info */
             STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
               "StLiSptUDatInd:Receieved incorrect message for lower SAP(%d)\n",
               suId));
            /* Handle the incorrect message event */
            stTHRxIncMsg(tuSapCp, &msgEv, &qos, &uDataEv->cgAddr,
                         &uDataEv->cdAddr);
            break;

      }
#ifdef ZT
      ztUpdPeer();
#endif /* ZT */
      RETVALUE(ROK);
   }

   /* increment the resource statistics */
   stUpdRsrcSts(&tuSapCp->sts, ST_STS_RX_MSG, msgEv.msgType.val,
                tuSapCp->cfg.swtch);

   switch(tuSapCp->cfg.swtch)
   {
      case LST_SW_ITU88:
      case LST_SW_ITU92:
      case LST_SW_ITU96:


         /* Handle the Itu Tcap Message */
         (Void)stTHRxMsg(tuSapCp, &msgEv, mBuf, &qos, &uDataEv->cgAddr,
                         &uDataEv->cdAddr, opc);
         break;

   }

#ifdef ZT
   ztUpdPeer();
#endif /* ZT */

   RETVALUE(ROK);
}  /* end of StLiSptUDatInd */


/*
*
*       Fun:   SCCP Status Indication
*
*       Desc:  This function informs the TCAP Layer that a status is avail
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 StLiSptStaInd
(
Pst        *pst,                   /* post structure */
SuId        suId,                  /* service user id */
Dpc         pc,                    /* destination point code */
SpUDatEvnt *uDataEv,               /* unit data event */
RCause      cause,                 /* return cause */
Buffer     *mBuf                   /* message buffer */
)
#else
PUBLIC S16 StLiSptStaInd(pst, suId, pc, uDataEv, cause, mBuf)
Pst        *pst;                   /* post structure */
SuId        suId;                  /* service user id */
Dpc         pc;                    /* destination point code */
SpUDatEvnt *uDataEv;               /* unit data event */
RCause      cause;                 /* return cause */
Buffer     *mBuf;                  /* message buffer */
#endif
{

   StTUSap   *tuSapCp;             /* TCAP Upper sap */
   StSPSap   *spSapCp;             /* TCAP Lower sap */
   StDlgCp   *dlgCp;               /* dialog control point */
   StDlgId    spDlgId;             /* dialogue id */
   /* st007.301 - TC-User Distribution Feature */
   SpId       tuSapId;             /* Upper SAP Id */
/* st035.301 - Modification to Search Upper SAP based on DialogId */
#ifdef ST_TC_USER_DIST
   StDlgId    dlgId;          /* return Dialogue Id */                
   Bool       bgnFlag;        /* return flag for BEGIN message */
   StDlgId    origDlgId;      /* originating dialogue Id */
   U8         pduType;        /* PDU type */
/* st036.301 - Correction of st035.301, Adding declaration of reason  */
   Reason     reason;         /* Failure reason */
#endif /* ST_TC_USER_DIST */

   TRC3(StLiSptStaInd)

   UNUSED(pst);
   UNUSED(pc);     

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StLiSptStaInd failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
          "StLiSptStaInd:suId(%d), cause(%d)\n", suId, cause));

#if (ERRCLASS & ERRCLS_INT_PAR)
  /* validate buffer pointer */
  if (mBuf == NULLP)
  {
     STLOGERROR(ERRCLS_INT_PAR, EST181, (ErrVal)mBuf,
                "StLiSptStaInd(): Null Buffer Ptr");

     RETVALUE(RFAILED);
  }

   /* Check if suId is out of range */
   if (suId >= (SpId)stCb.genCfg.nmbSaps || suId < 0)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SUID, EVTSPTSTAIND, (U8)suId);

      STLOGERROR(ERRCLS_INT_PAR, EST182, (ErrVal)suId, 
                 "StLiSptStaInd(): suId out of range");

      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);
      RETVALUE(RFAILED);
   }
#endif

   /* Check if Lower SAP is already created for the suId */
   if ((spSapCp = *(stCb.spSapLst + suId)) == NULLP)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSPTSTAIND, (U8)suId);

      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptStaInd:Lower SAP(%d) does not exist\n", suId));
      RETVALUE(RFAILED);
   }
  
   /* Check if Lower SAP is bound and enabled */
   if (spSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSPTSTAIND, (U8)suId);

      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptStaInd:Lower SAP(%d) is not bound, SAP state is %d\n",
             suId, spSapCp->hlSt));
      RETVALUE(RFAILED);
   }
/* st035.301 - Modification to Search Upper SAP based on DialogId */
#ifndef ST_TC_USER_DIST
   /* Without TC-User Distribution Feature, the upper and
    * associated lower SAP has the same Id */
   tuSapId = suId;
#else /* ST_TC_USER_DIST */
      /* Initialize the return values */
      dlgId = 0;
      bgnFlag = FALSE;
           
      /* Get the dialogue ID by decoding the message */
      /* determine PDU type */
      if (stDecPduHdr(mBuf, stCb.spSapLst[suId]->cfg.swtch, 
                      ST_MSG_DIRECTION, &pduType,&origDlgId, 
                      &dlgId,&bgnFlag) == ROK)
      {             
         /* Find the associated upper SAP */ 
         tuSapId = stFindUSapId(suId,origDlgId,bgnFlag);
      }
      else 
      {
         /* Decoding problem, handle 
          * according to specific protocol */
/* st036.301 - Correction of st035.301 */          
         tuSapId = stHandleDecProblem(suId,mBuf,
                                      uDataEv,dlgId,&reason,bgnFlag);          
        
      } /* if - Decoding Problem */       

#endif /* ST_TC_USER_DIST */  

   /* st007.301 - Added - TC-User Distribution Feature */
   /* st041.301 - Deletion- Removed stMakeLtoUSapAssoc */

#ifdef ST_TC_USER_DIST   
   if (tuSapId == ST_DEF_ASSOC_SAP_ID)
   {  
      /* Generate alarm to LM and return */     
      stSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_LI_INV_EVT,
                     LST_CAUSE_TUSAP_ASSOC_FAIL, EVTSTAIND, (U8)suId);
      
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);
      
      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
          "StLiSptStaInd:Upper SAP cannot be associated for lower SAP(%d)\n",
          suId));
      RETVALUE(RFAILED);
   }  
#endif /* ST_TC_USER_DIST */
   
   /* st007.301 - Modified - TC-User Distribution Feature */
   /* Check if Upper SAP is already created for the suId */
   if ((tuSapCp = *(stCb.tuSapLst + tuSapId)) == NULLP)
   {
      /* st012.301 -Modify- changed suId to tuSapId */ 
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSPTSTAIND, (U8)tuSapId);

      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptStaInd:Upper Sap(%d) is not configured\n", tuSapId));
      RETVALUE(RFAILED);
   }
  
   /* Check if Upper SAP is bound and enabled */
   if (tuSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      /* st012.301 -Modify- changed suId to tuSapId */ 
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSPTSTAIND, (U8)tuSapId);

      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptStaInd:Upper SAP(%d) is not bound, SAP state is %d\n",
             tuSapId, tuSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   /* st014.301 -Addition- initialise the global strucutre stDataParam */
   stInitSptDataParam(uDataEv);

   /* Initialize the dialogue Id */
   spDlgId = 0;

   /* find the Originating transaction id in incoming message */
   if (stFndOrgTid(&spDlgId, mBuf) == ROK)
   {
      /* If not active then don't accept the component request */
#ifdef ZT
      if (!ztChkNCRsetStatus(spDlgId))
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         STLOGERROR(ERRCLS_INT_PAR, EST183, (ErrVal)0, 
                    "StLiSptStaInd: Invalid PSF state");
#endif
         stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                     LCM_CAUSE_PROT_NOT_ACTIVE, EVTSPTSTAIND, 
                     (U8)suId);

         RETVALUE(RFAILED);
      }
#endif /* ZT */

      /* use spDlgId to get the associated dialog */
      if (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, spDlgId, ST_USE_SPDLGID, &dlgCp) == ROK)
      {
         /* st014.301 -Modify- if STUV2 is defined, then pass imp and isni 
          * information in Notice Indiaction from the global structure */
#ifdef STUV2
        StUiStuNotInd(&tuSapCp->pstTU, tuSapCp->suId, dlgCp->suDlgId, 
                       dlgCp->spDlgId, &uDataEv->cgAddr, &uDataEv->cdAddr,
                       &stDataParam, cause);
#else /* not STUV2 */              
         StUiStuNotInd(&tuSapCp->pstTU, tuSapCp->suId, dlgCp->suDlgId, 
                       dlgCp->spDlgId, &uDataEv->cgAddr, &uDataEv->cdAddr,
                       cause);
#endif /* STUV2 */
      }
/* st035.301 - Modification to Search Upper SAP based on DialogId */
      else
      {
         STLOGERROR(ERRCLS_INT_PAR, EST338, (ErrVal)spDlgId,
                "StLiSptStaInd(): Cannot find Dialog for DialogId");
      }   
   }
   else if (tuSapCp->cfg.swtch == LST_SW_ITU96)
   {
      /* st014.301 -Modify- if STUV2 is defined, then pass imp and isni 
       * information in Notice Indiaction from the global structure */
#ifdef STUV2
      StUiStuNotInd(&tuSapCp->pstTU, tuSapCp->suId, 0, 
                    0, &uDataEv->cgAddr, &uDataEv->cdAddr, &stDataParam, cause);
#else /* not STUV2 */
      StUiStuNotInd(&tuSapCp->pstTU, tuSapCp->suId, 0, 
                    0, &uDataEv->cgAddr, &uDataEv->cdAddr,
                    cause);
#endif /* STUV2 */
      
   }

   /* drop the buffer as it is not used */
   /* st027.301 - Modify - Modify the user buf free mechanism */ 
   STFREEUSERBUF(mBuf);

   RETVALUE(ROK);
} /* end of StLiSptStaInd */


/*
*
*       Fun:   SCCP Cord Indication
*
*       Desc:  This function informs the TCAP Layer about the state
*              intention of peer for SSN state change 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 StLiSptCordInd
(
Pst      *pst,                   /* post structure */
SuId      suId,                  /* service user id */
Ssn       aSsn,                  /* sub system number */
Smi       smi                    /* Sub-System multiplicity indicator */
)
#else
PUBLIC S16 StLiSptCordInd(pst, suId, aSsn, smi)
Pst      *pst;                   /* post structure */
SuId      suId;                  /* service user id */
Ssn       aSsn;                  /* sub system number */
Smi       smi;                   /* Sub-System multiplicity indicator */
#endif
{
   StTUSap      *tuSapCp;        /* TCAP upper sap */
   StSPSap      *spSapCp;        /* TCAP lower sap */
   CmSS7SteMgmt  steMgmt;        /* state management structure */
   /* st007.301 - TC-User Distribution Feature */
   SpId       tuSapId;             /* Upper SAP Id */

   TRC3(StLiSptCordInd)

   UNUSED(pst);

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StLiSptCordInd failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
          "StLiSptCordInd:suId(%d), aSsn(%d)\n", suId, aSsn));

   /* If not active then don't accept the coordination indication */
#ifdef ZT
   if (!ztChkCRsetStatus())
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST184, (ErrVal)0, 
                 "StLiSptCordInd: Invalid PSF state");
#endif
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSPTCRDIND, 
                  (U8)suId);

      RETVALUE(RFAILED);
   }
#endif /* ZT */

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Check if suId is out of range */
   if (suId >= (SpId)stCb.genCfg.nmbSaps || suId < 0)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SUID, EVTSPTCRDIND, (U8)suId);

      STLOGERROR(ERRCLS_INT_PAR, EST185, (ErrVal)suId, 
                 "StLiSptCordInd:suId out of range");

      RETVALUE(RFAILED);
   }
#endif

   /* Check if Lower SAP is already created for the suId */
   if ((spSapCp = *(stCb.spSapLst + suId)) == NULLP)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSPTCRDIND, (U8)suId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptCordInd:Lower SAP(%d) does not exist\n", suId));
      RETVALUE(RFAILED);
   }
  
   /* Check if Lower SAP is bound and enabled */
   if (spSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSPTCRDIND, (U8)suId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptCordInd:Lower SAP(%d) is not bound, SAP state is %d\n",
             suId, spSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   /* st007.301 - Added - TC-User Distribution Feature */
   /* Find or Make association from lower to upper SAP */
   tuSapId = stMakeLtoUSapAssoc(suId,NULLP,NULLP,FALSE,NULLP);
   
#ifdef ST_TC_USER_DIST   
   if (tuSapId == ST_DEF_ASSOC_SAP_ID)
   {  
      /* Generate alarm to LM and return */     
      stSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_LI_INV_EVT,
                     LST_CAUSE_TUSAP_ASSOC_FAIL, EVTSPTCRDIND, (U8)suId);
      
      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
           "StLiSptCordInd:Upper SAP cannot be associated for lower SAP(%d)\n",
           suId));
      RETVALUE(RFAILED);
   }  
#endif /* ST_TC_USER_DIST */
   
   /* st007.301 - Modified - TC-User Distribution Feature */
   /* Check if Upper SAP is already created for the suId */
   if ((tuSapCp = *(stCb.tuSapLst + tuSapId)) == NULLP)
   {
      /* st012.301 -Modify- changed suId to tuSapId */ 
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SUID, EVTSPTCRDIND, (U8)tuSapId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptCordInd:Upper Sap(%d) is not configured\n",tuSapId));
      RETVALUE(RFAILED);
   }
  
   /* Check if Upper SAP is bound and enabled */
   if (tuSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      /* st012.301 -Modify- changed suId to tuSapId */ 
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSPTCRDIND, (U8)tuSapId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptCordInd:Upper SAP(%d) is not bound, SAP state is %d\n",
             tuSapId,tuSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   steMgmt.evntType          = EVTSSN_CORD_IND;
   steMgmt.mgmt.cordInd.aSsn = aSsn; 
   steMgmt.mgmt.cordInd.smi  = smi;

   /* st014.301 -Modify- pass default values for sccpState and ril fields */
#ifdef STUV2
   /* Send default values for sccpState and ril */
   stMgmntParam.sccpState = STUIF_VER2_STEIND_DEF_SCCPSTATE_VAL;
   stMgmntParam.ril       = STUIF_VER2_STEIND_DEF_RIL_VAL;
   (Void)StUiStuSteInd(&tuSapCp->pstTU, tuSapCp->suId, &steMgmt, &stMgmntParam);
#else /* not STUV2 */  
   (Void)StUiStuSteInd(&tuSapCp->pstTU, tuSapCp->suId, &steMgmt);
#endif /* STUV2 */
   RETVALUE(ROK);
} /* end of StLiSptCordInd */


/*
*
*       Fun:   SCCP Cord Confirm
*
*       Desc:  This function informs the TCAP Layer about the state of SSN
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 StLiSptCordCfm
(
Pst      *pst,                   /* post structure */
SuId      suId,                  /* service user id */
Ssn       aSsn,                  /* sub system number */
Smi       smi                    /* SMI */
)
#else
PUBLIC S16 StLiSptCordCfm(pst, suId, aSsn, smi)
Pst      *pst;                   /* post structure */
SuId      suId;                  /* service user id */
Ssn       aSsn;                  /* sub system number */
Smi       smi;                   /* SMI */
#endif
{
   StTUSap      *tuSapCp;        /* TCAP upper sap */
   StSPSap      *spSapCp;        /* TCAP lower sap */
   CmSS7SteMgmt  steMgmt;        /* state management structure */
   /* st007.301 - TC-User Distribution Feature */
   SpId         tuSapId;         /* Upper SAP Id */

   TRC3(StLiSptCordCfm)

   UNUSED(pst);

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StLiSptCordCfm failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
          "StLiSptCordCfm:suId(%d), aSsn(%d)\n", suId, aSsn));

   /* If not active then don't accept the coordination confirm */
#ifdef ZT
   if (!ztChkCRsetStatus())
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST186, (ErrVal)0, 
                 "StLiSptCordCfm: Invalid PSF state");
#endif
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSPTCRDCFM, 
                  (U8)suId);

      RETVALUE(RFAILED);
   }
#endif /* ZT */

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Check if suId is out of range */
   if (suId >= (SpId)stCb.genCfg.nmbSaps || suId < 0)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SUID, EVTSPTCRDCFM, (U8)suId);

      STLOGERROR(ERRCLS_INT_PAR, EST187, (ErrVal)suId, 
                 "StLiSptCordCfm:suId out of range");

      RETVALUE(RFAILED);
   }
#endif

   /* Check if Lower SAP is already created for the suId */
   if ((spSapCp = *(stCb.spSapLst + suId)) == NULLP)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSPTCRDCFM, (U8)suId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptCordCfm:Lower SAP(%d) does not exist\n",suId));
      RETVALUE(RFAILED);
   }
  
   /* Check if Lower SAP is bound and enabled */
   if (spSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSPTCRDCFM, (U8)suId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptCordCfm:Lower SAP(%d) is not bound, SAP state is %d\n",
             suId, spSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   /* st007.301 - Added - TC-User Distribution Feature */
   /* Find or Make association from lower to upper SAP */
   tuSapId = stMakeLtoUSapAssoc(suId,NULLP,NULLP,FALSE,NULLP);

#ifdef ST_TC_USER_DIST   
   if (tuSapId == ST_DEF_ASSOC_SAP_ID)
   {  
      /* Generate alarm to LM and return */     
      stSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_LI_INV_EVT,
                     LST_CAUSE_TUSAP_ASSOC_FAIL, EVTSPTCRDCFM, (U8)suId);
      
      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
          "StLiSptCordCfm:Upper SAP cannot be associated for lower SAP(%d)\n",
          suId));
      RETVALUE(RFAILED);
   }  
#endif /* ST_TC_USER_DIST */
   
   /* st007.301 - Modified - TC-User Distribution Feature */
   /* Check if Upper SAP is already created for the suId */
   if ((tuSapCp = *(stCb.tuSapLst + tuSapId)) == NULLP)
   {
      /* st012.301 -Modify- changed suId to tuSapId */ 
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSPTCRDCFM, (U8)tuSapId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptCordCfm:Upper Sap(%d) is not configured\n",tuSapId));
      RETVALUE(RFAILED);
   }
  
   /* Check if Upper SAP is bound and enabled */
   if (tuSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      /* st012.301 -Modify- changed suId to tuSapId */ 
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSPTCRDCFM, (U8)tuSapId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptCordCfm:Upper SAP(%d) is not bound, SAP state is %d\n",
             tuSapId, tuSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   steMgmt.evntType          = EVTSSN_CORD_CFM;
   steMgmt.mgmt.cordCfm.aSsn = aSsn; 
   steMgmt.mgmt.cordCfm.smi  = smi;

   /* st014.301 -Modify- pass default values for sccpState and ril fields */
#ifdef STUV2
   /* Send default values for sccpState and ril */
   stMgmntParam.sccpState = STUIF_VER2_STEIND_DEF_SCCPSTATE_VAL;
   stMgmntParam.ril       = STUIF_VER2_STEIND_DEF_RIL_VAL;
   (Void)StUiStuSteInd(&tuSapCp->pstTU, tuSapCp->suId, &steMgmt, &stMgmntParam);
#else /* not STUV2 */
   (Void)StUiStuSteCfm(&tuSapCp->pstTU, tuSapCp->suId, &steMgmt);
#endif /* STUV2 */
   
   RETVALUE(ROK);
} /* end of StLiSptCordCfm */


/*
*
*       Fun:   SCCP Ste Indication
*
*       Desc:  This function informs the TCAP Layer about the state of SSN 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 StLiSptSteInd
(
Pst      *pst,                   /* post structure */
SuId      suId,                  /* service user id */
Dpc       aDpc,                  /* Affected destination point code */
Ssn       aSsn,                  /* sub system number */
UStat     uStat,                 /* status */
Smi       smi                    /* SMI */
)
#else
PUBLIC S16 StLiSptSteInd(pst, suId, aDpc, aSsn, uStat, smi)
Pst      *pst;                   /* post structure */
SuId      suId;                  /* service user id */
Dpc       aDpc;                  /* Affected destination point code */
Ssn       aSsn;                  /* sub system number */
UStat     uStat;                 /* status */
Smi       smi;                   /* SMI */
#endif
{
   StTUSap      *tuSapCp;        /* TCAP upper sap */
   StSPSap      *spSapCp;        /* TCAP lower sap */
   CmSS7SteMgmt  steMgmt;        /* state management structure */
   /* st007.301 - TC-User Distribution Feature */
   SpId         tuSapId;         /* Upper SAP Id */

   TRC3(StLiSptSteInd)

   UNUSED(pst);

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StLiSptSteInd failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
          "StLiSptSteInd:suId(%d), aSsn(%d), uStat(%d)\n", suId, aSsn, uStat));

   /* If not active then don't accept the state change indication */
#ifdef ZT
   if (!ztChkCRsetStatus())
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST188, (ErrVal)0, 
                 "StLiSptSteInd: Invalid PSF state");
#endif
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSPTSTEIND, 
                  (U8)suId);

      RETVALUE(RFAILED);
   }
#endif /* ZT */

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Check if suId is out of range */
   if (suId >= (SpId)stCb.genCfg.nmbSaps || suId < 0)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SUID, EVTSPTSTEIND, (U8)suId);

      STLOGERROR(ERRCLS_INT_PAR, EST189, (ErrVal)suId, 
                 "StLiSptSteInd:suId out of range");
      RETVALUE(RFAILED);
   }
#endif

   /* Check if Lower SAP is already created for the suId */
   if ((spSapCp = *(stCb.spSapLst + suId)) == NULLP)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSPTSTEIND, (U8)suId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptSteInd:Lower SAP(%d) does not exist\n",suId));
      RETVALUE(RFAILED);
   }
  
   /* Check if Lower SAP is bound and enabled */
   if (spSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSPTSTEIND, (U8)suId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptSteInd:Lower SAP(%d) is not bound,SAP state is %d\n",
             suId, spSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   /* st007.301 - Added - TC-User Distribution Feature */
   /* Find or Make association from lower to upper SAP */
   tuSapId = stMakeLtoUSapAssoc(suId,NULLP,NULLP,FALSE,NULLP);

#ifdef ST_TC_USER_DIST   
   if (tuSapId == ST_DEF_ASSOC_SAP_ID)
   {  
      /* Generate alarm to LM and return */     
      stSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_LI_INV_EVT,
                     LST_CAUSE_TUSAP_ASSOC_FAIL, EVTSPTSTEIND, (U8)suId);
      
      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptSteInd:Upper SAP cannot be associated for lower SAP(%d)\n",
             suId));
      RETVALUE(RFAILED);
   }  
#endif /* ST_TC_USER_DIST */
   
   /* st007.301 - Modified - TC-User Distribution Feature */
   /* Check if Upper SAP is already created for the suId */
   if ((tuSapCp = *(stCb.tuSapLst + tuSapId)) == NULLP)
   {
      /* st012.301 -Modify- changed suId to tuSapId */ 
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSPTSTEIND, (U8)tuSapId);

      /* st012.301 -Modify- changed suId to tuSapId */ 
      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptSteInd:Upper Sap(%d) is not configured\n", tuSapId));
      RETVALUE(RFAILED);
   }
  
   /* Check if Upper SAP is bound and enabled */
   if (tuSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      /* st012.301 -Modify- changed suId to tuSapId */ 
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSPTSTEIND, (U8)tuSapId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptSteInd:Upper SAP(%d) is not bound,SAP state is %d\n",
             tuSapId, tuSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   steMgmt.evntType          = EVTSSN_STE_IND;
   steMgmt.mgmt.steInd.aDpc  = aDpc; 
   steMgmt.mgmt.steInd.aSsn  = aSsn; 
   steMgmt.mgmt.steInd.smi   = smi;
   steMgmt.mgmt.steInd.uStat = uStat;

   /* st014.301 -Modify- pass default values for sccpState and ril fields */
#ifdef STUV2
   /* Send default values for sccpState and ril */
   stMgmntParam.sccpState = STUIF_VER2_STEIND_DEF_SCCPSTATE_VAL;
   stMgmntParam.ril       = STUIF_VER2_STEIND_DEF_RIL_VAL;
   (Void)StUiStuSteInd(&tuSapCp->pstTU, tuSapCp->suId, &steMgmt, &stMgmntParam);
#else /* not STUV2 */
   (Void)StUiStuSteInd(&tuSapCp->pstTU, tuSapCp->suId, &steMgmt);
#endif /* STUV2 */

   RETVALUE(ROK);
} /* end of StLiSptSteInd */

#ifdef SPT2

/*
*       Fun:   StLiSptBndCfm
*
*       Desc:  Bind confirmation
*
*       Ret:   ROK   - ok
*
*
*       File:  st_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 StLiSptBndCfm
(
Pst    *pst,                    /* post structure */
SuId    suId,                   /* service user id */
U8      status                  /* bind request status */
)
#else
PUBLIC S16 StLiSptBndCfm(pst, suId, status)
Pst    *pst;                    /* post structure */
SuId    suId;                   /* service user id */
U8      status;                 /* bind request status */
#endif
{
   /* st007.301 - Modified - TC-User Distribution Feature */
#ifndef ST_TC_USER_DIST
   StTUSap      *tuSapCp;        /* TCAP upper sap */
#endif /* ST_TC_USER_DIST */  
   StSPSap      *spSapCp;        /* TCAP lower sap */

   TRC3(StLiSptBndCfm)

   UNUSED(pst);

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StLiSptBndCfm :failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
          "StLiSptBndCfm:suId(%d), status(%d)\n", suId, status));

   /* If not active then don't accept the state change indication */
#ifdef ZT
   if (!ztChkCRsetStatus())
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST190, (ErrVal)0, 
                 "StLiSptBndCfm: Invalid PSF state");
#endif
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSPTBNDCFM, 
                  (U8)suId);

      RETVALUE(RFAILED);
   }
#endif /* ZT */

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Check if suId is out of range */
   if (suId >= (SuId)stCb.genCfg.nmbSaps || suId < 0)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SUID, EVTSPTBNDCFM, (U8)suId);

      STLOGERROR(ERRCLS_INT_PAR, EST191, (ErrVal)suId, 
                 "StLiSptBndCfm:suId out of range");
      RETVALUE(RFAILED);
   }
#endif

   /* Check if Lower SAP is already created for the suId */
   if ((spSapCp = *(stCb.spSapLst + suId)) == NULLP)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSPTBNDCFM, (U8)suId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptBndCfm:Lower SAP(%d) does not exist\n", suId));
      RETVALUE(RFAILED);
   }
  
/* st007.301 - Modified - TC-User Distribution Feature */
#ifndef ST_TC_USER_DIST
   /* Check if Upper SAP is already created for the suId */
   if ((tuSapCp = *(stCb.tuSapLst + suId)) == NULLP)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSPTBNDCFM, (U8)suId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptBndCfm:Upper Sap(%d) is not configured\n",suId));
      RETVALUE(RFAILED);
   }
#endif /* ST_TC_USER_DIST */
  
   /* Check for proper state */
   if (spSapCp->hlSt != ST_SAP_WAIT_BNDCFM)
   {
      /* Ignore this bind confirm */
      RETVALUE(ROK);
   }

   /* stop timer */
   stStopSapTmr(ST_BND_ACK_TMR, (PTR)spSapCp);

   /* Reset the bind attempts counter */
   spSapCp->bndRetryCnt = 0;

   /* Confirmation indicates failure */
   if (status == CM_BND_NOK)
   {
      spSapCp->hlSt = ST_SAP_UNBND;
      stSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_BND_FAIL,
                  LCM_CAUSE_UNKNOWN, EVTSPTBNDCFM, (U8)suId);
      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptBndCfm:Bind not ok for lower SAP(%d)\n", suId));
      RETVALUE(ROK);
   }

   /* change lower sap status */
   spSapCp->hlSt = ST_SAP_BND_ENBL;

#ifdef ZT
   ztRunTimeUpd(ZT_SPSAP_CB,
                CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_MOD,
                (Void *)spSapCp);
   ztUpdPeer();
#endif /* ZT */

   RETVALUE(ROK);

} /* StLiSptBndCfm */


/*
*
*       Fun:   Point code and subsystem status confirm
*
*       Desc:  This function informs the TCAP Layer about the state of SSN 
*              and point code.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 StLiSptStaCfm
(
Pst      *pst,                   /* post structure */
SuId      suId,                  /* service user id */
U8        status,                /* Status type */
Dpc       dpc,                   /* Affected destination point code */
Ssn       ssn,                   /* sub system number */
UStat     uStat,                 /* status */
Smi       smi                    /* SMI */
/* st014.301 -Add- sccpState, ril fields added */
#ifdef SPTV2
, U8      sccpState,             /* remote sccp status */
U8        ril                    /* restricted importance level */
#endif /* SPTV2 */
)
#else
/* st014.301 -Modify- Routine prototype changed to include sccpState, ril
 * fields */
#ifdef SPTV2
PUBLIC S16 StLiSptStaCfm(pst, suId, status, dpc, ssn, uStat, smi, sccpState, 
                         ril)
#else /* not SPTV2 */
PUBLIC S16 StLiSptStaCfm(pst, suId, status, dpc, ssn, uStat, smi)
#endif /* SPTV2 */
Pst      *pst;                   /* post structure */
SuId      suId;                  /* service user id */
U8        status;                /* Status type */
Dpc       dpc;                   /* Affected destination point code */
Ssn       ssn;                   /* sub system number */
UStat     uStat;                 /* status */
Smi       smi;                   /* SMI */
/* st014.301 -Add- sccpState, ril fields */
#ifdef SPTV2
U8        sccpState;             /* remote sccp status */
U8        ril;                   /* restricted importance level */
#endif /* SPTV2 */
#endif
{
   StTUSap      *tuSapCp;        /* TCAP upper sap */
   StSPSap      *spSapCp;        /* TCAP lower sap */
   CmSS7SteMgmt  steMgmt;        /* state management structure */
   /* st007.301 - TC-User Distribution Feature */
   SpId         tuSapId;         /* Upper SAP Id */

   TRC3(StLiSptStaCfm)

   UNUSED(pst);

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StLiSptStaCfm failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
          "StLiSptStaCfm:suId(%d), status(%d), dpc(%ld), ssn(%d), uStat(%d)\n",
          suId, status, dpc, ssn, uStat));

   /* If not active then don't accept the state change indication */
#ifdef ZT
   if (!ztChkCRsetStatus())
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST192, (ErrVal)0, 
                 "StLiSptStaCfm: Invalid PSF state");
#endif
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSPTSTACFM, 
                  (U8)suId);

      RETVALUE(RFAILED);
   }
#endif /* ZT */

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Check if suId is out of range */
   if (suId >= (SpId)stCb.genCfg.nmbSaps || suId < 0)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SUID, EVTSPTSTACFM, (U8)suId);

      STLOGERROR(ERRCLS_INT_PAR, EST193, (ErrVal)suId, 
                 "StLiSptStaCfm:suId out of range");
      RETVALUE(RFAILED);
   }
#endif

   /* Check if Lower SAP is already created for the suId */
   if ((spSapCp = *(stCb.spSapLst + suId)) == NULLP)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSPTSTACFM, (U8)suId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptStaCfm:Lower SAP(%d) does not exist\n", suId));
      RETVALUE(RFAILED);
   }
  
   /* Check if Lower SAP is bound and enabled */
   if (spSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSPTSTACFM, (U8)suId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptStaCfm:Lower SAP(%d) is not bound,SAP state is %d\n",
             suId,spSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   /* st007.301 - Added - TC-User Distribution Feature */
   /* Find or Make association from lower to upper SAP */
   tuSapId = stMakeLtoUSapAssoc(suId,NULLP,NULLP,FALSE,NULLP);

#ifdef ST_TC_USER_DIST    
   if (tuSapId == ST_DEF_ASSOC_SAP_ID)
   {  
      /* Generate alarm to LM and return */     
      stSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_LI_INV_EVT,
                     LST_CAUSE_TUSAP_ASSOC_FAIL, EVTSPTSTACFM, (U8)suId);
      
      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptStaCfm:Upper SAP cannot be associated for lower SAP(%d)\n",
             suId));
      RETVALUE(RFAILED);
   }  
#endif /* ST_TC_USER_DIST */
   
   /* st007.301 - Modified - TC-User Distribution Feature */
   /* Check if Upper SAP is already created for the suId */
   if ((tuSapCp = *(stCb.tuSapLst + tuSapId)) == NULLP)
   {
      /* st012.301 -Modify- changed suId to tuSapId */ 
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSPTSTACFM, (U8)tuSapId);

      /* st012.301 -Modify- changed suId to tuSapId */ 
      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptStaCfm:Upper Sap(%d) is not configured\n",tuSapId));
      RETVALUE(RFAILED);
   }
  
   /* Check if Upper SAP is bound and enabled */
   if (tuSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      /* st012.301 -Modify- changed suId to tuSapId */ 
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSPTSTACFM, (U8)tuSapId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptStaCfm:Upper SAP(%d) is not bound,SAP state is %d\n",
             tuSapId, tuSapCp->hlSt));
      RETVALUE(RFAILED);
   }

#ifdef STU2
   steMgmt.evntType           = EVTSSN_STA_CFM;
   steMgmt.mgmt.staCfm.status = status; 
   steMgmt.mgmt.staCfm.dpc    = dpc; 
   steMgmt.mgmt.staCfm.ssn    = ssn; 
   steMgmt.mgmt.staCfm.ustat  = uStat;
   steMgmt.mgmt.staCfm.smi    = smi;

/* st014.301 -Modify- if STUV2 flag is enabled, pass sccpState and ril in State
 * Confirm primitive to TC-user */
#ifdef STUV2
#ifdef SPTV2   
   stMgmntParam.sccpState = sccpState;
   stMgmntParam.ril       = ril;
#else /* SPTV2 not defined */
   /* Send default value */
   stMgmntParam.sccpState = STUIF_VER2_STEIND_DEF_SCCPSTATE_VAL;
   stMgmntParam.ril       = STUIF_VER2_STEIND_DEF_RIL_VAL;
#endif /* SPTV2 */   
   (Void)StUiStuSteCfm(&tuSapCp->pstTU, tuSapCp->suId, &steMgmt, &stMgmntParam);
#else   /* not STUV2 */
   (Void)StUiStuSteCfm(&tuSapCp->pstTU, tuSapCp->suId, &steMgmt);
#endif /* STUV2 */
#endif /* STU2 */

   RETVALUE(ROK);
} /* end of StLiSptStaCfm */


/*
*
*       Fun:   Subsystem state confirm
*
*       Desc:  This function confirms the receipt of subsystem state change
*              request primitive by SCCP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 StLiSptSteCfm
(
Pst      *pst,                   /* post structure */
SuId      suId,                  /* service user id */
U8        status                 /* Status */
)
#else
PUBLIC S16 StLiSptSteCfm(pst, suId, status)
Pst      *pst;                   /* post structure */
SuId      suId;                  /* service user id */
U8        status;                /* Status */
#endif
{
   StTUSap      *tuSapCp;        /* TCAP upper sap */
   StSPSap      *spSapCp;        /* TCAP lower sap */
   CmSS7SteMgmt  steMgmt;        /* state management structure */
   /* st007.301 - TC-User Distribution Feature */
   SpId         tuSapId;         /* Upper SAP Id */

   TRC3(StLiSptSteCfm)

   UNUSED(pst);

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StLiSptSteCfm failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
          "StLiSptSteCfm:suId(%d), status(%d)\n", suId, status));

   /* If not active then don't accept the state change confirmation */
#ifdef ZT
   if (!ztChkCRsetStatus())
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST194, (ErrVal)0, 
                 "StLiSptSteCfm: Invalid PSF state");
#endif
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSPTSTECFM, 
                  (U8)suId);

      RETVALUE(RFAILED);
   }
#endif /* ZT */

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Check if suId is out of range */
   if (suId >= (SpId)stCb.genCfg.nmbSaps || suId < 0)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SUID, EVTSPTSTECFM, (U8)suId);

      STLOGERROR(ERRCLS_INT_PAR, EST195, (ErrVal)suId, 
                 "StLiSptSteCfm:suId out of range");
      RETVALUE(RFAILED);
   }
#endif

   /* Check if Lower SAP is already created for the suId */
   if ((spSapCp = *(stCb.spSapLst + suId)) == NULLP)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSPTSTECFM, (U8)suId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptSteCfm:Lower SAP(%d) does not exist\n", suId));
      RETVALUE(RFAILED);
   }
  
   /* Check if Lower SAP is bound and enabled */
   if (spSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSPTSTECFM, (U8)suId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptSteCfm:Lower SAP(%d) is not bound,SAP state is %d\n",
             suId,spSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   /* st007.301 - Added - TC-User Distribution Feature */
   /* Find or Make association from lower to upper SAP */
   /* st012.301 -Modify- association setting should be outside
    * ST_TC_USER_DIST flag */ 
   tuSapId = stMakeLtoUSapAssoc(suId,NULLP,NULLP,FALSE,NULLP);

#ifdef ST_TC_USER_DIST   
   if (tuSapId == ST_DEF_ASSOC_SAP_ID)
   {  
      /* Generate alarm to LM and return */     
      stSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_LI_INV_EVT,
                     LST_CAUSE_TUSAP_ASSOC_FAIL, EVTSPTSTACFM, (U8)suId);
      
      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptSteCfm:Upper SAP cannot be associated for lower SAP(%d)\n",
             suId));
      RETVALUE(RFAILED);
   }  
#endif /* ST_TC_USER_DIST */
   
   /* st007.301 - Modified - TC-User Distribution Feature */
   /* Check if Upper SAP is already created for the suId */
   if ((tuSapCp = *(stCb.tuSapLst + tuSapId)) == NULLP)
   {
      /* st012.301 -Modify- changed suId to tuSapId */ 
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSPTSTECFM, (U8)tuSapId);

      /* st012.301 -Modify- changed suId to tuSapId */ 
      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptSteCfm:Upper Sap(%d) is not configured\n", tuSapId));
      RETVALUE(RFAILED);
   }
  
   /* Check if Upper SAP is bound and enabled */
   if (tuSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      /* st012.301 -Modify- changed suId to tuSapId */ 
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSPTSTECFM, (U8)tuSapId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptSteCfm:Upper SAP(%d) is not bound,SAP state is %d\n",
             tuSapId,tuSapCp->hlSt));
      RETVALUE(RFAILED);
   }

#ifdef STU2
   steMgmt.evntType           = EVTSSN_STE_CFM;
   steMgmt.mgmt.steCfm.status = status; 

   /* st014.301 -Modify- pass default values for sccpState and ril fields */
#ifdef STUV2
   /* Send default values for sccpState and ril */
   stMgmntParam.sccpState = STUIF_VER2_STEIND_DEF_SCCPSTATE_VAL;
   stMgmntParam.ril       = STUIF_VER2_STEIND_DEF_RIL_VAL;
   (Void)StUiStuSteCfm(&tuSapCp->pstTU, tuSapCp->suId, &steMgmt, &stMgmntParam);
#else /* not STUV2 */
   (Void)StUiStuSteCfm(&tuSapCp->pstTU, tuSapCp->suId, &steMgmt);
#endif /* STUV2 */
#endif /* STU2 */

   RETVALUE(ROK);
} /* end of StLiSptSteCfm */
#endif /* SPT2 */


/*
*
*       Fun:   SCCP PC Ste Indication
*
*       Desc:  This function informs the TCAP Layer about the state of 
*              Point Code.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 StLiSptPCSteInd
(
Pst      *pst,                   /* post structure */
SuId      suId,                  /* service user id */
Dpc       aDpc,                  /* destination point code */
Sps       sps                    /* status */
/* st014.301 -Add- sccpState, ril fields are added */
#ifdef SPTV2
, U8      sccpState,             /* remote sccp status */
U8        ril                    /* restricted importance level */
#endif /* SPTV2 */
)
#else
/* st014.301 -Modify- Routine prototype changed to include sccpSatte, ril
 * fields */
#ifdef SPTV2
PUBLIC S16 StLiSptPCSteInd(pst, suId, aDpc, sps, sccpState, ril)
#else
PUBLIC S16 StLiSptPCSteInd(pst, suId, aDpc, sps)
#endif /* SPTV2 */
Pst      *pst;                   /* post structure */
SuId      suId;                  /* service user id */
Dpc       aDpc;                  /* destination point code */
Sps       sps;                   /* status */
/* st014.301 -Add- sccpState, ril fields are added */
#ifdef SPTV2
U8        sccpState;             /* remote sccp status */
U8        ril;                   /* restricted importance level */
#endif /* SPTV2 */
#endif
{
   StTUSap      *tuSapCp;        /* TCAP upper sap */
   StSPSap      *spSapCp;        /* TCAP lower sap */
   CmSS7SteMgmt  steMgmt;        /* state management structure */
   /* st007.301 - TC-User Distribution Feature */
   SpId         tuSapId;         /* Upper SAP Id */

   TRC3(StLiSptPCSteInd)

   UNUSED(pst);

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StLiSptPCSteInd failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
          "StLiSptPCSteInd:suId(%d), aDpc(%ld), sps(%d)\n", suId, aDpc, sps));

   /* If not active then don't accept the point code state indication */
#ifdef ZT
   if (!ztChkCRsetStatus())
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST196, (ErrVal)0, 
                 "StLiSptPCSteInd: Invalid PSF state");
#endif
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSPTPCSTEIND, 
                  (U8)suId);

      RETVALUE(RFAILED);
   }
#endif /* ZT */

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Check if suId is out of range */
   if (suId >= (SpId)stCb.genCfg.nmbSaps || suId < 0)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SUID, EVTSPTPCSTEIND, (U8)suId);

      STLOGERROR(ERRCLS_INT_PAR, EST197, (ErrVal)suId, 
                 "StLiSptPCSteInd:suId out of range");

      RETVALUE(RFAILED);
   }
#endif

   /* Check if Lower SAP is already created for the suId */
   if ((spSapCp = *(stCb.spSapLst + suId)) == NULLP)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSPTPCSTEIND, (U8)suId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptPCSteInd:Lower SAP(%d) does not exist\n", suId));
      RETVALUE(RFAILED);
   }
  
   /* Check if Lower SAP is bound and enabled */
   if (spSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSPTPCSTEIND, (U8)suId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptPCSteInd:Lower SAP(%d) is not bound,SAP state is %d\n",
             suId,spSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   /* st007.301 - Added - TC-User Distribution Feature */
   /* Find or Make association from lower to upper SAP */   
   tuSapId = stMakeLtoUSapAssoc(suId,NULLP,NULLP,FALSE,NULLP);

#ifdef ST_TC_USER_DIST   
   if (tuSapId == ST_DEF_ASSOC_SAP_ID)
   {  
      /* Generate alarm to LM and return */     
      stSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_LI_INV_EVT,
                     LST_CAUSE_TUSAP_ASSOC_FAIL, EVTSPTPCSTEIND, (U8)suId);
      
      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
           "StLiSptPCSteInd:Upper SAP cannot be associated for lower SAP(%d)\n",              suId));
      RETVALUE(RFAILED);
   }  
#endif /* ST_TC_USER_DIST */
   
   /* st007.301 - Modified - TC-User Distribution Feature */
   /* Check if Upper SAP is already created for the suId */
   if ((tuSapCp = *(stCb.tuSapLst + tuSapId)) == NULLP)
   {
      /* st012.301 -Modify- changed suId to tuSapId */ 
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LCM_CAUSE_INV_SAP, EVTSPTPCSTEIND, (U8)tuSapId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptPCSteInd:Upper Sap(%d) is not configured\n", tuSapId));
      RETVALUE(RFAILED);
   }
  
   /* Check if Upper SAP is bound and enabled */
   if (tuSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      /* st012.301 -Modify- changed suId to tuSapId */ 
      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT,
                  LST_CAUSE_SAP_UBND, EVTSPTPCSTEIND, (U8)tuSapId);

      /* st009.301 -Add-  Print debug info */
      STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
             "StLiSptPCSteInd:Upper SAP(%d) is not bound, SAP state is %d\n",
             tuSapId, tuSapCp->hlSt));
      RETVALUE(RFAILED);
   }

   steMgmt.evntType          = EVTPC_STE_IND;
   steMgmt.mgmt.PCSteInd.dpc = aDpc; 
   steMgmt.mgmt.PCSteInd.sps = sps;

/* st014.301 -Modify- if STUV2 flag is enabled, pass sccpState and ril in State
 * Confirm primitive to TC-user */
#ifdef STUV2
#ifdef SPTV2
   stMgmntParam.sccpState = sccpState;
   stMgmntParam.ril       = ril;
   (Void)StUiStuSteInd(&tuSapCp->pstTU, tuSapCp->suId, &steMgmt, &stMgmntParam);
#else /* SPTV2 not defined */
   stMgmntParam.sccpState = STUIF_VER2_STEIND_DEF_SCCPSTATE_VAL;
   stMgmntParam.ril       = STUIF_VER2_STEIND_DEF_RIL_VAL;
   (Void)StUiStuSteInd(&tuSapCp->pstTU, tuSapCp->suId, &steMgmt, &stMgmntParam);
#endif /* SPTV2 */   
#else  /* not STUV2 */   
   (Void)StUiStuSteInd(&tuSapCp->pstTU, tuSapCp->suId, &steMgmt);
#endif /* STUV2 */

   RETVALUE(ROK);
} /* end of StLiSptPCSteInd */



/*
*     interface functions to layer management
*/

/*
*
*       Fun:   Configuration Request
*
*       Desc:  This function is used by the Layer Management to
*              configure the layer.
*
*       Ret:   ROK      - ok
*
*       Notes: Configuration must be performed in the following sequence:
*              1) general configuration (STGEN);
*              2) TCAP Upper sap configuration (STTCUSAP).
*              3) TCAP Lower sap configuration (STSPSAP).
*
*       File:  st_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 StMiLstCfgReq
(
Pst      *pst,                /* post structure */
StMngmt  *cfg                 /* configuration structure */
)
#else
PUBLIC S16 StMiLstCfgReq(pst, cfg)
Pst      *pst;                /* post structure */
StMngmt  *cfg;                /* configuration structure */
#endif
{
   StTUSap   *tuSapCp;        /* TCAP upper sap */
   StSPSap   *spSapCp;        /* TCAP lower sap */
   Size       memSize;        /* memory size */
   SpId       spId;           /* SAP Id */
   Size       sapLstSize;     /* Size of list of pointers to SAP */
   S16        ret;            /* return code */
   U16        idx;            /* index */
   /* st007.301 - Modified - Corrected type of variable */ 
   Reason     reason;         /* primitive failure reason */
/* st005.301 - Added - Rolling Upgrade feature */
#ifdef ST_RUG
   U16        maxSaps;        /* Maximum number of upper * 
                                 and lower Saps together */ 
   Size       maxIntfSize;    /* Maximum interface version info size */

#endif /* ST_RUG */

#if (ERRCLASS & ERRCLS_INT_PAR)
   U32        totDlgs;        /* Total dialogues */
   U32        totInvs;        /* Total Invokes */
#endif /* ERRCLS */

   TRC3(StMiLstCfgReq)

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StMiLstCfgReq failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
          "StMiLstCfgReq:elmnt(%d), elmntInst1(%d)\n",
           cfg->hdr.elmId.elmnt,
           cfg->hdr.elmId.elmntInst1));

   /* If general configuration not already done, use the post structure 
      received in this CfgReq for sending Alarms */
   if (!stCb.init.cfgDone)
   {
      stCb.init.lmPst.selector  = pst->selector;
      stCb.init.lmPst.region    = pst->region;
      stCb.init.lmPst.pool      = pst->pool;
      stCb.init.lmPst.prior     = pst->prior;
      stCb.init.lmPst.route     = pst->route;
      stCb.init.lmPst.dstProcId = pst->srcProcId;
      stCb.init.lmPst.dstEnt    = pst->srcEnt;
      stCb.init.lmPst.dstInst   = pst->srcInst;
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
     #ifdef SS_MULTIPLE_PROCS
      stCb.init.lmPst.srcProcId =stCb.init.procId; 
     #else
      stCb.init.lmPst.srcProcId = SFndProcId();
     #endif
      stCb.init.lmPst.srcEnt    = stCb.init.ent;
      stCb.init.lmPst.srcInst   = stCb.init.inst;
      stCb.init.lmPst.event     = EVTNONE;
      /* st005.301 - Added - Rolling Upgrade feature */
#ifdef ST_RUG
      /*  LM interface version number will be used *        
       *  by TCAP to  generate alarms and trace    *
       *  indications                              */
      stCb.init.lmPst.intfVer = pst->intfVer;
#endif /* ST_RUG */
   }
   /* elmnt contains the type of configuration requested */  
   switch (cfg->hdr.elmId.elmnt)
   {
      /* general configuration */
      case STGEN:

         /* If this is the first general configuration request */
         if (!stCb.init.cfgDone)
         {
            /* copy general configuration parameters */
            cmCopy( (U8 *)&cfg->t.cfg.s.genCfg,
                    (U8 *)&stCb.genCfg,
                    sizeof(StGenCfg) );

            /* validate configuration parameters */
#if (ERRCLASS & ERRCLS_INT_PAR)
            if ((stCb.genCfg.nmbSaps > (U16)ST_MAX_LNKS) ||
                (stCb.genCfg.nmbSaps <= (U16)0))
            {
               STLOGERROR(ERRCLS_INT_PAR, EST198, (ErrVal)stCb.genCfg.nmbSaps, 
                          "StMiLstCfgReq():Incorrect # of Saps");
               stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                           LST_REASON_INVALID_NMBSAPS);
               RETVALUE(RFAILED);
            }

            if (stCb.genCfg.timeRes <= 0)
            {
               STLOGERROR(ERRCLS_INT_PAR, EST199, (ErrVal)stCb.genCfg.timeRes, 
                          "StMiLstCfgReq():Incorrect Timer resolution");
               stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                           LST_REASON_INVALID_TMRRES);
               RETVALUE(RFAILED);
            }

            if (stCb.genCfg.sapTimeRes <= 0)
            {
               STLOGERROR(ERRCLS_INT_PAR, EST200, (ErrVal)stCb.genCfg.sapTimeRes,
                          "StMiLstCfgReq():Incorrect Timer resolution");
               stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                           LST_REASON_INVALID_TMRRES);
               RETVALUE(RFAILED);
            }
#endif /* ERRCLASS */

            /* Compute memory necessary to run */
            /* for list of SAPs, Dialogues, invocations and hash list bins */

            memSize = (stCb.genCfg.nmbSaps * SBUFSIZE(sizeof(StTUSap)))   +
                      (stCb.genCfg.nmbSaps * SBUFSIZE(sizeof(StTUSap *))) + 
                      (stCb.genCfg.nmbSaps * SBUFSIZE(sizeof(StSPSap)))   +
                      (stCb.genCfg.nmbSaps * SBUFSIZE(sizeof(StSPSap *))) + 
                      (stCb.genCfg.nmbDlgs * SBUFSIZE(sizeof(StDlgCp)))   + 
                      (stCb.genCfg.nmbInvs * SBUFSIZE(sizeof(StInvCp)))   +
                      (stCb.genCfg.nmbBins * SBUFSIZE(sizeof(CmListEnt)));

            /* Add memory required for the Itu State tables */
            memSize += (ST_MAX_ITU_TSM_SIZE * sizeof(SMTblEnt)) +
                       (ST_MAX_ITU_ISM_SIZE * sizeof(SMTblEnt));


/* st005.301 - Added - Rolling Upgrade feature */    
#ifdef ST_RUG            
            /* Memory is calculated by taking into account max
               number of SAPs and size of Version Information */

            maxSaps = 2 * (stCb.genCfg.nmbSaps);
            maxIntfSize = maxSaps * sizeof(ShtVerInfo);

           /* Add memory for interface version information */
            memSize += maxIntfSize;
#endif /* ST_RUG */

            {
               /* If a bitMap is to be kept for the dialogue ids */
               if (stCb.genCfg.bitMapFlg)
               {
                  U32    bits;

                  /* Compute the size of the bitmap */
                  if ((stCb.genCfg.hiDlgId > 0) && (stCb.genCfg.loDlgId > 0) &&
                      (stCb.genCfg.hiDlgId > stCb.genCfg.loDlgId))
                  {
                     bits = stCb.genCfg.hiDlgId - stCb.genCfg.loDlgId;
                  }
                  else
                  {
                     /* st009.301 -Add-  Print debug info */
                     STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
                            "StMiLstCfgReq:Invalid dialogue range\
                            low dialogue (%ld), high dialogue (%ld)\n",
                            stCb.genCfg.loDlgId, stCb.genCfg.hiDlgId));
                     stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                                 LST_REASON_INVALID_DLGRANGE);
                     RETVALUE(RFAILED);
                  }

                  /* Compute the number of octets required for bitmap */
                  memSize += (bits / 8) + 1;
               }
            }
            /* get static memory needed for all control blocks and tables */
            ret = SGetSMem(stCb.init.region, memSize, &stCb.init.pool);

            if (ret != ROK)
            {
               /* st009.301 -Add-  Print debug info */
               STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
                      "StMiLstCfgReq:SGetSMem routine failed\n"));
               stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                           LCM_REASON_MEM_NOAVAIL);
               RETVALUE(RFAILED);
            }

            /* Store the size of the memory reserved */
            stCb.memSize = memSize;
/* st005.301 - Added - Rolling Upgrade feature */
#ifdef ST_RUG
           /* Allocate memory for interface version info. */
            stCb.intfInfo =(ShtVerInfo *)stAlloc(maxIntfSize);

            /* If memory allocation fails inform Layer Manager */
            if (stCb.intfInfo == NULLP) 
            {    
               /* free static memory */
               (Void) SPutSMem(stCb.init.region, stCb.init.pool);
              
               /* st009.301 -Add-  Print debug info */
               STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
                      "StMiSptCfgReq:Interface info. alloc. fail\n"));
               stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                           LCM_REASON_MEM_NOAVAIL);

               RETVALUE(RFAILED);
            }
#endif /* ST_RUG */
    
            /* Compute the size of the SAP list, same for both upper and
               lower Saps */
            sapLstSize = stCb.genCfg.nmbSaps * sizeof(StTUSap *);

            /* allocate Upper SAP list */
            stCb.tuSapLst = (StTUSap **)stAlloc(sapLstSize);

            if (stCb.tuSapLst == NULLP)
            {  
/* st005.301 - Added - Rolling Upgrade feature */
#ifdef ST_RUG
               stFree((Data *)stCb.intfInfo, maxIntfSize);
#endif /* ST_RUG */
               SPutSMem(stCb.init.region, stCb.init.pool);

               /* st009.301 -Add-  Print debug info */
               STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
                      "StMiSptCfgReq:Upper SAP List alloc. fail\n"));
               stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                           LCM_REASON_MEM_NOAVAIL);
               RETVALUE(RFAILED);
            }

            /* initialize the Upper SAP list */
            for (idx = 0; idx < stCb.genCfg.nmbSaps; idx++)
            {
               *(stCb.tuSapLst + idx) = NULLP;
            }

            /* allocate Lower SAP list */
            stCb.spSapLst = (StSPSap **)stAlloc(sapLstSize);

            if (stCb.spSapLst == NULLP)
            { 
/* st005.301 - Added - Rolling Upgrade feature */
#ifdef ST_RUG
               stFree((Data *)stCb.intfInfo, maxIntfSize);
#endif /* ST_RUG */
               
               stFree((Data *)stCb.tuSapLst, sapLstSize);
               SPutSMem(stCb.init.region, stCb.init.pool);
               /* st009.301 -Add-  Print debug info */
               STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
                      "StMiLstCfgReq:Lower SAP List alloc. fail\n"));
               stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                           LCM_REASON_MEM_NOAVAIL);
               RETVALUE(RFAILED);
            }

            /* initialize the Lower SAP list */
            for (idx = 0; idx < stCb.genCfg.nmbSaps; idx++)
            {
               *(stCb.spSapLst + idx) = NULLP;
            }

            /* Initialize the timing queue */
            for (idx = 0; idx < STTQNUMENT; idx++)
            {
               stCb.tq[idx].first    = NULLP;
               stCb.sapTq[idx].first = NULLP;
            }

            /* register timer: */
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
/* st037.301 - removal of warnings. */
           #ifdef SS_MULTIPLE_PROCS
            if ((ret = SRegTmr(stCb.init.procId,stCb.init.ent, stCb.init.inst,
                               stCb.genCfg.timeRes,
                               (PAIFTMRS16)stActvTmr)) != ROK)
           #else 
            if ((ret = SRegTmr(stCb.init.ent, stCb.init.inst,
                               stCb.genCfg.timeRes,
                               (PFS16)stActvTmr)) != ROK)
           #endif
            {
/* st005.301 - Added - Rolling Upgrade feature */
#ifdef ST_RUG
               stFree((Data *)stCb.intfInfo, maxIntfSize);
#endif /* ST_RUG */
               stFree((Data *)stCb.tuSapLst, sapLstSize);
               stFree((Data *)stCb.spSapLst, sapLstSize);
               SPutSMem(stCb.init.region, stCb.init.pool);

               /* st009.301 -Add-  Print debug info */
               STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
                      "StMiLstCfgReq:Timer(Gen.) registration fail\n"));
               stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                           LCM_REASON_REGTMR_FAIL);

               RETVALUE(RFAILED);
            }

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
/* st037.301 - removal of warnings. */
           #ifdef SS_MULTIPLE_PROCS
            if ((ret = SRegTmr(stCb.init.procId,stCb.init.ent, stCb.init.inst,
                               stCb.genCfg.sapTimeRes,
                               (PAIFTMRS16)stActvSapTmr)) != ROK)
           #else 
            if ((ret = SRegTmr(stCb.init.ent, stCb.init.inst,
                               stCb.genCfg.sapTimeRes,
                               (PFS16)stActvSapTmr)) != ROK)
           #endif
            {
/* st005.301 - Added - Rolling Upgrade feature */
#ifdef ST_RUG
               stFree((Data *)stCb.intfInfo, maxIntfSize);
#endif /* ST_RUG */
               stFree((Data *)stCb.tuSapLst, sapLstSize);
               stFree((Data *)stCb.spSapLst, sapLstSize);
               SPutSMem(stCb.init.region, stCb.init.pool);

               /* st009.301 -Add-  Print debug info */
               STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
                      "StMiLstCfgReq:Timer(SAP) registration fail\n"));
               stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                           LCM_REASON_REGTMR_FAIL);

               RETVALUE(RFAILED);
            }

            /* Initialize Protocol State Machine Tables */


            /* Initialize Transaction State Tables */
            stItuTsmInit(&stCb.smTbls.ituTsm);

            /* Initialize Invocation State Tables */
            stItuIsmInit(&stCb.smTbls.ituIsm);

            /* Mark the completion of the configuration */
            stCb.init.cfgDone = TRUE;
         }
         /* Initialize layer manager post structure, this code is needed in
            case of loosely coupled interface with the layer manager */

         cmCopy( (U8 *)&cfg->t.cfg.s.genCfg.smPst,(U8 *)&stCb.init.lmPst,
                                                            sizeof(Pst) );

         stCb.init.lmPst.srcProcId = stCb.init.procId;
         stCb.init.lmPst.srcEnt    = stCb.init.ent;
         stCb.init.lmPst.srcInst   = stCb.init.inst;
         stCb.init.lmPst.event     = EVTNONE;


         {
            /* Can disable the bitmap during reconfiguration request, if it was
               enabled during first general configuration */
            if (stCb.init.cfgDone)
            {
               if ((stCb.genCfg.bitMapFlg) && !(cfg->t.cfg.s.genCfg.bitMapFlg))
               {
                  stCb.genCfg.bitMapFlg = FALSE;
               }
            }
         }

         /* Local protocol error handling flag */
         stCb.errCntrlFlg = cfg->t.cfg.s.genCfg.errCntrlFlg;

         /* Send configuration confirm*/
         stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_OK, LCM_REASON_NOT_APPL);
         break;

      /* TCAP Upper Sap configuration */
      case STTCUSAP:

         spId = cfg->hdr.elmId.elmntInst1;    /* SAP Id */

         /* General configuration is required to be done before sap config */
         if (!stCb.init.cfgDone)
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            STLOGERROR(ERRCLS_INT_PAR, EST201, (ErrVal)0, 
                       "StMiLstCfgReq():Gen Cfg not done");
#endif
            stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                        LCM_REASON_GENCFG_NOT_DONE);

            RETVALUE(RFAILED);
         }

         /* validate configuration parameters */

#if (ERRCLASS & ERRCLS_INT_PAR)
         /* validate the SAP Id */
         if (( spId >= (SpId)stCb.genCfg.nmbSaps) || ( spId < 0))
         {
            STLOGERROR(ERRCLS_INT_PAR, EST202, (ErrVal)spId, 
                       "StMiLstCfgReq():spId out of range");
            stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                        LCM_REASON_INVALID_SAP);

            RETVALUE(RFAILED);
         }
         /* st004.301 - Deletion - Fix for number of dialogues, 
          * invokes limit check */
         /* Number of dialogues, invokes limit check not req.
          * in reconfiguration */
         
#endif /* ERRCLASS */

         if ((tuSapCp = *(stCb.tuSapLst + spId)) == NULLP)
         {

            /* st004.301 - Addition - Fix for number of dialogues, 
             * invokes limit check */
            /* During new SAP configuration check for number of 
             * dialogues, invokes limit */
 
#if (ERRCLASS & ERRCLS_INT_PAR)

            /* Validate the max number of dlg/inv. Max dlgs/invs for all 
            ** the SAPs should be less then or equal to the max dlgs/invs 
            ** configured at the general configuration time 
            */

            totDlgs = 0;
            totInvs = 0;
            for (idx = 0; idx < stCb.genCfg.nmbSaps; idx++)
            {
               if ((tuSapCp = *(stCb.tuSapLst + idx)) != NULLP)
               {
                  totDlgs += tuSapCp->cfg.nmbDlgs;
                  totInvs += tuSapCp->cfg.nmbInvs;
                }
            }
            if ((totDlgs + cfg->t.cfg.s.tuSapCfg.nmbDlgs) > stCb.genCfg.nmbDlgs)
            {
               STLOGERROR(ERRCLS_INT_PAR, EST203, (ErrVal)spId, 
                       "StMiLstCfgReq():nmbDlgs exceeds the system wide max");
               stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                        LCM_REASON_INVALID_PAR_VAL);
 
               RETVALUE(RFAILED);
            }
            if ((totInvs + cfg->t.cfg.s.tuSapCfg.nmbInvs) > stCb.genCfg.nmbInvs)
            {
               STLOGERROR(ERRCLS_INT_PAR, EST204, (ErrVal)spId, 
                       "StMiLstCfgReq():nmbInvs exceeds the system wide max");
               stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                        LCM_REASON_INVALID_PAR_VAL);
 
               RETVALUE(RFAILED);
            }
          
#endif /* ERRCLASS */
            
            /* Allocate and initialize a Upper SAP */
            if ((ret = stAllocTUSap(&cfg->t.cfg.s.tuSapCfg, spId, &reason)) != ROK)
            {
               stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, reason);
               RETVALUE(RFAILED);
            }
         }
         else /* Reconfiguration */
         {
            tuSapCp->cfg.t1.enb = cfg->t.cfg.s.tuSapCfg.t1.enb;
            tuSapCp->cfg.t1.val = cfg->t.cfg.s.tuSapCfg.t1.val;
            tuSapCp->cfg.t2.enb = cfg->t.cfg.s.tuSapCfg.t2.enb;
            tuSapCp->cfg.t2.val = cfg->t.cfg.s.tuSapCfg.t2.val;
         }
/* st005.301 - Added - Rolling Upgrade feature */
#ifdef ST_RUG

         /* If SAP Config structure contains valid interface 
         * version number */
         if(cfg->t.cfg.s.tuSapCfg.remIntfValid == TRUE)
         {
            tuSapCp = *(stCb.tuSapLst + spId);
            if (tuSapCp != NULLP)
            {
               /* SAP Config request contains valid interface 
               * version number remIntfValid and intfVer 
               * fields are reconfigurable */
               tuSapCp->remIntfValid = TRUE;
               tuSapCp->pstTU.intfVer  =  cfg->t.cfg.s.tuSapCfg.intfVer;
               tuSapCp->verContEnt = ENTSM; /* Version controller is SM */
            }
            else
            {
               STLOGERROR(ERRCLS_INT_PAR, EST206, (ErrVal)spId, 
                       "StMiLstCfgReq():Sap control point null");
               RETVALUE(RFAILED);
            }
         } /* if cfg structure contains remIntfValid as TRUE */
         else
         {
            if (tuSapCp != NULLP)
               tuSapCp->verContEnt = ENTNC; /* Version controller unknown */
         }  
#endif /* ST_RUG */

         /* Send configuration confirm OK */
         stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_OK, LCM_REASON_NOT_APPL);
         break;   

      /* TCAP Lower Sap configuration */
      case STSPSAP:

         spId = cfg->hdr.elmId.elmntInst1;    /* SAP Id */

         if (!stCb.init.cfgDone)
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            STLOGERROR(ERRCLS_INT_PAR, EST205, (ErrVal)0, 
                       "StMiLstCfgReq():Gen Cfg not done");
#endif
            stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                        LCM_REASON_GENCFG_NOT_DONE);
            RETVALUE(RFAILED);
         }

         /* validate configuration parameters */

#if (ERRCLASS & ERRCLS_INT_PAR)
         /* validate the SAP Id */
         if (( spId >= (SpId)stCb.genCfg.nmbSaps) || ( spId < 0))
         {
            STLOGERROR(ERRCLS_INT_PAR, EST206, (ErrVal)spId, 
                       "StMiLstCfgReq():spId out of range");
            stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                        LCM_REASON_INVALID_SAP);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLASS */

         if ((spSapCp = *(stCb.spSapLst + spId)) == NULLP)
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            /* st007.301 - Added -TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
            /* Check whether SSN info. in config structure is fine */
            if (stCheckSPSapSSN(cfg->t.cfg.s.spSapCfg.ssn,
                               cfg->t.cfg.s.spSapCfg.swtch,&reason) != ROK)
            {
               /* st009.301 -Add-  Print debug info */
               STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
                      "StMiLstCfgReq:SSN(%d) info in SAP config. not ok\n",
                      cfg->t.cfg.s.spSapCfg.ssn));
               stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,reason);
               RETVALUE(RFAILED);
            }
#endif /* ST_TC_USER_DIST */            
#endif /* ERRCLASS */
                 
            /* Allocate and initialize a lower SAP */
            if ((ret = stAllocSPSap(&cfg->t.cfg.s.spSapCfg, spId, &reason)) != ROK)
            {
               /* st009.301 -Add-  Print debug info */
               STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
                          "StMiLstCfgReq:Lower SAP allocation failed\n"));
               stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, reason);
               RETVALUE(RFAILED);
            }
            
			/* st007.301 - Added - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
            /* Get the allocated lower SAP */
            spSapCp = *(stCb.spSapLst + spId);   
           
            /* Set SSN info in the SAP structure */
            spSapCp->ssn = cfg->t.cfg.s.spSapCfg.ssn;
           
            /* Set the association in the upper SAP structure for all 
            * existing upper SAPs */
            stSetAssocLSapId(spId,FALSE);
#endif /* ST_TC_USER_DIST */
        
/* st005.301 - Added - Rolling Upgrade Feature */
#ifdef ST_RUG
    /* If SAP Config structure contains valid interface 
     * version number */
           spSapCp = *(stCb.spSapLst + spId);
           if ( spSapCp != NULLP)
           {
              if(cfg->t.cfg.s.spSapCfg.remIntfValid == TRUE)
              {
                 /* SAP Config request contains
                  * valid interface version number */
                spSapCp->remIntfValid = TRUE;
                spSapCp->pstSP.intfVer  =  cfg->t.cfg.s.spSapCfg.intfVer;
              }
           }
           
           /* If remote ver not configured by layer mgr check if we have *
            * information needed to set the version number already       *
            * For upper SAP, the version number will be filled in on     *
            * getting a set version request or on getting a bind request *
            * from service user                                          */
     
           if(cfg->t.cfg.s.spSapCfg.remIntfValid == FALSE)
           {
              Bool       found;          /* Used in searching */
              U16        i;              /* Counter */
      
              found = FALSE;
  
              /* if LM did not configure version, check stored data */      
              for(i=0;((i < stCb.numIntfInfo) && (found == FALSE));i++)
              {
                 if(stCb.intfInfo[i].intf.intfId == SPTIF)
                 {
                    switch(stCb.intfInfo[i].grpType)
                    {
                       case SHT_GRPTYPE_ALL:
                          if ((stCb.intfInfo[i].dstProcId == 
                                           cfg->t.cfg.s.spSapCfg.spProcId) &&
                             (stCb.intfInfo[i].dstEnt.ent == 
                                           cfg->t.cfg.s.spSapCfg.spEnt) &&
                             (stCb.intfInfo[i].dstEnt.inst == 
                                          cfg->t.cfg.s.spSapCfg.spInst))
                           
                            found = TRUE;
                           
                          break;
                        case SHT_GRPTYPE_ENT:
                           if ((stCb.intfInfo[i].dstEnt.ent == 
                                              cfg->t.cfg.s.spSapCfg.spEnt) &&
                              (stCb.intfInfo[i].dstEnt.inst == 
                                             cfg->t.cfg.s.spSapCfg.spInst))
                           
                            found = TRUE;                           
                        default:
                           /* not possible */
                           break;
                    } /* switch */                    
                 } /* if it is for interface type SPT */
              } /* for */

              if(found == TRUE)
              {
                 spSapCp->pstSP.intfVer = stCb.intfInfo[i-1].intf.intfVer;
                 spSapCp->remIntfValid = TRUE;
              } 
           } /* if remIntfVer is FALSE */                       
#endif /* ST_RUG */

         }
         else  /* Reconfiguration */

         {
            /* st007.301 - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
            
            /* If SSN value is changed at reconfiguration, reset the association fields */
            if (spSapCp->ssn != cfg->t.cfg.s.spSapCfg.ssn)
            {
               /* Check whether SSN info. in config structure is fine */
               if (stCheckSPSapSSN(cfg->t.cfg.s.spSapCfg.ssn,
                               cfg->t.cfg.s.spSapCfg.swtch,&reason) != ROK)
               {
                  stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,reason);
                  RETVALUE(RFAILED);
               }
               /* Reset assocLSapId in all associated  upper SAP structure */
               stSetAssocLSapId(spId,TRUE);
               
               /* Copy the new SSN info into the SAP structure */
               spSapCp->ssn = cfg->t.cfg.s.spSapCfg.ssn;
               spSapCp->cfg.ssn = cfg->t.cfg.s.spSapCfg.ssn;
               
               /* Set new association in upper SAP structure */
               stSetAssocLSapId(spId,FALSE);
            }
#endif /* ST_TC_USER_DIST */
            
            spSapCp->cfg.ssn = cfg->t.cfg.s.spSapCfg.ssn; 

#ifdef SPT2
            spSapCp->cfg.tIntTmr.enb = cfg->t.cfg.s.spSapCfg.tIntTmr.enb;
            spSapCp->cfg.tIntTmr.val = cfg->t.cfg.s.spSapCfg.tIntTmr.val;
#endif /* SPT2 */
            spSapCp->cfg.spTmr = cfg->t.cfg.s.spSapCfg.spTmr;

            /* initialize the timers */
            (Void)cmInitTimers(spSapCp->timers, (U8)ST_MAX_SAP_TMR);

/* st005.301 - Added - Rolling Upgrade feature */
#ifdef ST_RUG
            /* If SAP Config structure contains valid interface version  */
            if(cfg->t.cfg.s.spSapCfg.remIntfValid == TRUE)
            {
               /* SAP Config request contains valid interface version number */
               spSapCp->remIntfValid = TRUE;
               spSapCp->pstSP.intfVer = cfg->t.cfg.s.spSapCfg.intfVer;
            }             
#endif /* ST_RUG */
         }/* else - Reconfiguration */

         /* Send configuration confirm OK */
         stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_OK, LCM_REASON_NOT_APPL);
         break;   
      /* Incorrect Element value */
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         STLOGERROR(ERRCLS_INT_PAR, EST207, (ErrVal)cfg->hdr.elmId.elmnt, 
                    "StMiLstCfgReq:Incorrect elmnt value");
#endif
         stSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, LCM_REASON_INVALID_ELMNT);
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of StMiLstCfgReq */


/*
*
*       Fun:   UnConfiguration Request
*
*       Desc:  This function is used by the Layer Management to
*              unconfigure the layer.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 StMiLstUcfgReq
(
Pst      *pst,                /* post structure */
StMngmt  *uCfg                /* Unconfiguration structure */
)
#else
PUBLIC S16 StMiLstUcfgReq(pst, uCfg)
Pst      *pst;                /* post structure */
StMngmt  *uCfg;               /* Unconfiguration structure */
#endif
{
   StTUSap   *tuSapCp;        /* TCAP upper sap */
   StSPSap   *spSapCp;        /* TCAP lower sap */
   SpId       spId;           /* SAP Id */

   TRC3(StMiLstUcfgReq)

   UNUSED(pst);

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StMiLstUcfgReq failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
          "StMiLstUcfgReq:elmnt(%d), elmntInst1(%d)\n",
           uCfg->hdr.elmId.elmnt,
           uCfg->hdr.elmId.elmntInst1));

   /* If already unconfigured, return from here */
   if (!stCb.init.cfgDone)
   {
      RETVALUE(ROK);
   }

   /* elmnt contains the type of Unconfiguration requested */  
   switch (uCfg->hdr.elmId.elmnt)
   {
      /* general Unconfiguration */
      case STGEN:

         stShutDown();

         /* Send an alarm that general unconfiguration went OK */
         stSendAlarm(LCM_CATEGORY_INTERFACE, LST_EVENT_GEN_UCFGOK,
                     LCM_CAUSE_UNKNOWN, EVTLSTUCFGREQ, (U8)0);

         break;

      /* TCAP Upper Sap unconfiguration */
      case STTCUSAP:

         spId = uCfg->hdr.elmId.elmntInst1;    /* SAP Id */

#if (ERRCLASS & ERRCLS_INT_PAR)
         /* validate the SAP Id */
         if (( spId >= (SpId)stCb.genCfg.nmbSaps) || ( spId < 0))
         {
            stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_MI_INV_EVT,
                        LCM_CAUSE_INV_SPID, EVTLSTUCFGREQ, (U8)spId);

            STLOGERROR(ERRCLS_INT_PAR, EST208, (ErrVal)spId, 
                       "StMiLstUcfgReq():spId out of range");
            RETVALUE(RFAILED);
         }
#endif
         if ((tuSapCp = *(stCb.tuSapLst + spId)) == NULLP)
         {
            stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_MI_INV_EVT,
                        LCM_CAUSE_INV_SAP, EVTLSTUCFGREQ, (U8)spId);
            /* st009.301 -Add-  Print debug info */
            STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
                   "StMiLstUcfgReq:Upper Sap(%d) is not configured\n",
                   spId));

            RETVALUE(RFAILED);
         }

         /* Free the Upper SAP */
         (Void)stFreeTUSap(spId);
         break;   

      /* TCAP Lower Sap unconfiguration */
      case STSPSAP:

         spId = uCfg->hdr.elmId.elmntInst1;    /* SAP Id */

#if (ERRCLASS & ERRCLS_INT_PAR)
         /* validate the SAP Id */
         if (( spId >= (SpId)stCb.genCfg.nmbSaps) || ( spId < 0))
         {
            stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_MI_INV_EVT,
                        LCM_CAUSE_INV_SPID, EVTLSTUCFGREQ, (U8)spId);

            STLOGERROR(ERRCLS_INT_PAR, EST209, (ErrVal)spId, 
                       "StMiLstUcfgReq():spId out of range");
            RETVALUE(RFAILED);
         }
#endif
         if ((spSapCp = *(stCb.spSapLst + spId)) == NULLP)
         {
            stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_MI_INV_EVT,
                        LCM_CAUSE_INV_SAP, EVTLSTUCFGREQ, (U8)spId);

            /* st009.301 -Add-  Print debug info */
            STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
                   "StMiLstUcfgReq:Lower SAP(%d) is not configured\n",
                   spId));
            RETVALUE(RFAILED);
         }

         /* Free the Lower SAP */
         (Void)stFreeSPSap(spId);
         break;   

      /* Incorrect Element value */
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         STLOGERROR(ERRCLS_INT_PAR, EST210, (ErrVal)uCfg->hdr.elmId.elmnt, 
                    "StMiLstUcfgReq:Incorrect elmnt value");
         RETVALUE(RFAILED);
#endif
         break;
   }

   RETVALUE(ROK);
} /* end of StMiLstUcfgReq */


/*
*
*       Fun:   Management Status Request
*
*       Desc:  This function is used by the Layer Management to
*              gather solicited status information.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 StMiLstStaReq
(
Pst      *pst,            /* post structure */
StMngmt  *sta             /* management structure */
)
#else
PUBLIC S16 StMiLstStaReq(pst, sta)
Pst      *pst;            /* post structure */
StMngmt  *sta;            /* management structure */
#endif
{
   StTUSap    *tuSapCp;   /* TCAP Upper sap */
   StSPSap    *spSapCp;   /* TCAP Lower sap */
   SpId        spId;      /* TCAP sap Id */

#ifdef ST_LMINT3
   Pst         rPst;      /* Reply post */
#endif /* ST_LMINT3 */

   TRC3(StMiLstStaReq)

   UNUSED(pst);

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StMiLstStaReq failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
          "StMiLstStaReq:elmnt(%d), elmntInst1(%d)\n",
           sta->hdr.elmId.elmnt,
           sta->hdr.elmId.elmntInst1));
 
   /* st015.301 -Add- get SAP Id from header */
   spId = sta->hdr.elmId.elmntInst1;
   
   /* st011.301-Modified- Make use of spId, if the element is not STGEN */
   /* st013.301-Added- Make use of spid, if the element is not STSID */
   if ((sta->hdr.elmId.elmnt != STGEN)
       && (sta->hdr.elmId.elmnt != STSID))
   {
      /* st015.301 -Delete- SAP ID is accessed outside the block */     
    
      /* validate the sap id range */
      if ((spId >= (SpId)stCb.genCfg.nmbSaps)|| (spId < 0))
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST211, (ErrVal)spId,
                 "StMiLstStaReq:spId out of range");
#endif
      stSendLmCfm(pst, TSSTA, &sta->hdr, LCM_PRIM_NOK,
                  LCM_REASON_INVALID_SAP);
      RETVALUE(RFAILED);
      }
   } /* End of st011.301 */      
   /* End of st013.301 */ 
   /* check which kind of status is requested */
   switch (sta->hdr.elmId.elmnt)
   {
      /* st011.301 - Addition - general configuration verification */   
      case STGEN: 

         if (!stCb.init.cfgDone)
         {
            stSendLmCfm(pst, TSSTA, &sta->hdr, 
                   LCM_PRIM_NOK, LCM_REASON_GENCFG_NOT_DONE);
            STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
                   "StMiLstStaReq:General Configuration is not Done\n"));
            RETVALUE(RFAILED);
         }  
         break; /* end of  st011.301 */
      
      /* status for TCAP Upper Sap */
      case STTCUSAP:

         /* Get the Upper SAP from the Upper SAP list */
         if ((tuSapCp = *(stCb.tuSapLst + spId)) == NULLP)
         {
            stSendLmCfm(pst, TSSTA, &sta->hdr, LCM_PRIM_NOK, LCM_REASON_INVALID_SAP);

            /* st009.301 -Add-  Print debug info */
            STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
                   "StMiLstStaReq:Upper Sap(%d) is not configured\n",
                   spId));
            RETVALUE(RFAILED);
         }
   
         sta->t.ssta.s.sapSta.swtch = tuSapCp->cfg.swtch;
         sta->t.ssta.s.sapSta.hlSt  = tuSapCp->hlSt;

/* st005.301 - Added - Rolling Upgrade feature */
#ifdef ST_RUG
         /* Send self and remote version information and remIntfValid flag */
         sta->t.ssta.s.sapSta.remIntfValid = tuSapCp->remIntfValid;
         sta->t.ssta.s.sapSta.selfIntfVer = STUIFVER;
         sta->t.ssta.s.sapSta.remIntfVer = tuSapCp->pstTU.intfVer;
         
#endif /* ST_RUG */
         break;

      /* status for TCAP Lower Sap */
      case STSPSAP:

         /* Get the Lower SAP from the Lower SAP list */
         if ((spSapCp = *(stCb.spSapLst + spId)) == NULLP)
         {
            stSendLmCfm(pst, TSSTA, &sta->hdr, LCM_PRIM_NOK, LCM_REASON_INVALID_SAP);

            /* st009.301 -Add-  Print debug info */
            STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
                   "StMiLstStaReq:Lower Sap(%d) is not configured\n",
                   spId));
            RETVALUE(RFAILED);
         }
   
         sta->t.ssta.s.sapSta.swtch = spSapCp->cfg.swtch;
         sta->t.ssta.s.sapSta.hlSt  = spSapCp->hlSt;

/* st005.301 - Added - Rolling Upgrade feature */
#ifdef ST_RUG
         /* Send self and remote version information and remIntfValid flag */
         sta->t.ssta.s.sapSta.remIntfValid = spSapCp->remIntfValid;
         sta->t.ssta.s.sapSta.selfIntfVer = SPTIFVER;
         sta->t.ssta.s.sapSta.remIntfVer = spSapCp->pstSP.intfVer;
         
#endif /* ST_RUG */
         break;

      /* system id */
      case STSID: 
         (Void) stGetSId(&sta->t.ssta.s.sysId);
         break;

      /* Unrecognized elmnt value */
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         STLOGERROR(ERRCLS_INT_PAR, EST212, (ErrVal)sta->hdr.elmId.elmnt,
                    "StMiLstStaReq(): Incorrect elmnt value");
#endif
         stSendLmCfm(pst, TSSTA, &sta->hdr, LCM_PRIM_NOK, LCM_REASON_INVALID_ELMNT);
         RETVALUE(RFAILED);
   }

   (Void)SGetDateTime(&sta->t.ssta.dt);

#ifdef ST_LMINT3

   sta->cfm.status = LCM_PRIM_OK;
   sta->cfm.reason = LCM_REASON_NOT_APPL;
   stBldReplyPst(&rPst, &sta->hdr, pst);
   (Void)StMiLstStaCfm(&rPst, sta);
#else
   (Void)StMiLstStaCfm(&stCb.init.lmPst, sta);
#endif /* ST_LMINT3 */

   RETVALUE(ROK);
} /* end of StMiLstStaReq */


/*
*
*       Fun:   Control Request
*
*       Desc:  This function is used by the Layer Management to
*              control the TCAP layer software
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 StMiLstCntrlReq
(
Pst      *pst,                /* post structure */
StMngmt  *cntrl               /* management structure */
)
#else
PUBLIC S16 StMiLstCntrlReq(pst, cntrl)
Pst      *pst;                /* post structure */
StMngmt  *cntrl;              /* management structure */
#endif
{
   StTUSap   *tuSapCp;        /* TCAP Upper sap */
   StSPSap   *spSapCp;        /* TCAP Lower sap */
   SpId       spId;           /* Sap Id */
   U16        reason;         /* Failure reason */
   U16        i;              /* Index */

   TRC3(StMiLstCntrlReq)

   UNUSED(pst);

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StMiLstCntrlReq failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
          "StMiLstCntrlReq:elmnt(%d), elmntInst1(%d)\n",
           cntrl->hdr.elmId.elmnt,
           cntrl->hdr.elmId.elmntInst1));

#ifdef ZT
   if ((cntrl->hdr.elmId.elmnt == STGEN) &&
       (((cntrl->t.cntrl.action == AENA) && (cntrl->t.cntrl.subAction == SAUSTA)) || 
       ((cntrl->t.cntrl.action == ADISIMM) && (cntrl->t.cntrl.subAction == SAUSTA))))
   {
      if (!ztChkCRsetStatus())
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         STLOGERROR(ERRCLS_INT_PAR, EST213, (ErrVal)0, 
                    "StMiLstCntrlReq: Invalid PSF state");
#endif

         stSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK,
                     LCM_REASON_INVALID_STATE);
         RETVALUE(RFAILED);
      }
   }
#endif /* ZT */

   reason = LCM_REASON_NOT_APPL;

   /* elmnt defines type of control required */
   switch (cntrl->hdr.elmId.elmnt)
   {
      /* general control */
      case STGEN:

         /* Action to be taken */
         switch (cntrl->t.cntrl.action)
         {
            case AENA:     /* Enable */

               /* Sub-Action */
               switch (cntrl->t.cntrl.subAction)
               {
                  /* Unsolicited alarms */
                  case SAUSTA:
                     stCb.init.usta = TRUE;
#ifdef ZT
                     ztRunTimeUpd(ZT_LYR_CB, 
                                  CMPFTHA_UPDTYPE_SYNC, 
                                  CMPFTHA_ACTN_MOD,
                                  (Void *)&stCb);
#endif /* ZT */
                     break;

                  /* Message Trace */
                  case SATRC:
                     stCb.init.trc = TRUE;
#ifdef ZT
                     ztRunTimeUpd(ZT_LYR_CB, 
                                  CMPFTHA_UPDTYPE_SYNC, 
                                  CMPFTHA_ACTN_MOD,
                                  (Void *)&stCb);
#endif /* ZT */
                     break;

                  /* Debug info */
                  case SADBG:
#ifdef DEBUGP
                     stCb.init.dbgMask |= cntrl->t.cntrl.dbg.dbgMask;

/* st042.301 - Deletion - Do not generate RT update for Debug Enable/Disable.
   Debug Control Req are sent to each copy of TCAP for which it is required. */  

#endif /* DEBUGP */
                     break;

                  default:
                    reason = LCM_REASON_INVALID_SUBACTION;
                    break;
               }
               break;

            case ADISIMM:  /* Disable */

               /* Sub-Action */
               switch (cntrl->t.cntrl.subAction)
               {
                  /* Unsolicited alarms */
                  case SAUSTA:
                     stCb.init.usta = FALSE;
#ifdef ZT
                     ztRunTimeUpd(ZT_LYR_CB, 
                                  CMPFTHA_UPDTYPE_SYNC, 
                                  CMPFTHA_ACTN_MOD,
                                  (Void *)&stCb);
#endif /* ZT */
                     break;

                  /* Message Trace */
                  case SATRC:
                     stCb.init.trc = FALSE;
#ifdef ZT
                     ztRunTimeUpd(ZT_LYR_CB, 
                                  CMPFTHA_UPDTYPE_SYNC, 
                                  CMPFTHA_ACTN_MOD,
                                  (Void *)&stCb);
#endif /* ZT */
                     break;

                  /* Debug info */
                  case SADBG:
#ifdef DEBUGP
                     stCb.init.dbgMask &= ~(cntrl->t.cntrl.dbg.dbgMask);

/* st042.301 - Deletion - Do not generate RT update for Debug Enable/Disable.
   Debug Control Req are sent to each copy of TCAP for which it is required. */  

#endif /* DEBUGP */
                     break;

                  default:
                    reason = LCM_REASON_INVALID_SUBACTION;
                    break;
               }
               break;

            case ASHUTDOWN:  /* Shutdown the TCAP layer */
               stShutDown();
               break;

            default:
               reason = LCM_REASON_INVALID_ACTION;
               break;
         }
         break;

      /* control the Upper Sap */
      case STTCUSAP:

         spId = cntrl->hdr.elmId.elmntInst1;

         if ((spId >= (SpId)stCb.genCfg.nmbSaps) || (spId < 0))
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            STLOGERROR(ERRCLS_INT_PAR, EST214, (ErrVal)spId,
                       "StMiLstCntrlReq(): Incorrect spId");
#endif
            reason = LCM_REASON_INVALID_SAP;
            break;
         }

         if ((tuSapCp = *(stCb.tuSapLst + spId)) == NULLP)
         {
            /* st009.301 -Add-  Print debug info */
            STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
                   "StMiLstCntrlReq:Upper Sap(%d) is not configured\n",
                   spId));
            reason = LCM_REASON_INVALID_SAP;
            break;
         }

         switch (cntrl->t.cntrl.action)
         {
            /* Disable the Upper Sap */
            case AUBND_DIS:
               stDisableTUSap(tuSapCp);
#ifdef ZT
               ztRunTimeUpd(ZT_TUSAP_CB, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD,
                            (Void *)tuSapCp);
#endif /* ZT */ 
               break;

#ifdef ST_LMINT3
            /* Run Audits to remove hanging resources */
            case AAUDIT:
               stRunAudits(spId, cntrl->t.cntrl.cbType, cntrl->t.cntrl.nmbCb,
                           cntrl->t.cntrl.expTime);
               break;
#endif /* ST_LMINT3 */

           /* st035.301 - Addition - Deletion of SAPs */
            /* Deletion of Upper SAP */
            case ADEL:
               /* Free the Upper SAP */
               (Void)stFreeTUSap(spId);
               break;   

            default:
               reason = LCM_REASON_INVALID_ACTION;
               break;
         }
         break;

      /* control the Lower Sap */
      case STSPSAP:

         spId = cntrl->hdr.elmId.elmntInst1;

         if ((spId >= (SpId)stCb.genCfg.nmbSaps) || (spId < 0))
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            STLOGERROR(ERRCLS_INT_PAR, EST215, (ErrVal)spId,
                       "StMiLstCntrlReq(): Incorrect spId");
#endif
            reason = LCM_REASON_INVALID_SAP;
            break;
         }

         if ((spSapCp = *(stCb.spSapLst + spId)) == NULLP)
         {
            reason = LCM_REASON_INVALID_SAP;
            break;
         }

         switch (cntrl->t.cntrl.action)
         {
            /* Enable the Lower Sap */
            case ABND_ENA:
               /* st007.301 - Added - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
               /* In TC-User distribution feature, SSN is a mandatory
                * parameter during lower SAP configuration. If SSN
                * is unknown  during control request, then indicate
                * an unusual situation */
               if (spSapCp->cfg.ssn == SS_UNKNOWN)
               {        
                    reason = LCM_REASON_INVALID_ACTION;
                    break;
               }     
#endif /* ST_TC_USER_DIST */
                    
               /* If SSN is not configured then take the SSN from upper SAP */
               if (spSapCp->cfg.ssn == SS_UNKNOWN)
               {
                  if (((tuSapCp = *(stCb.tuSapLst + spId)) == NULLP) ||
                      (tuSapCp->hlSt != ST_SAP_BND_ENBL))
                  {
                     spSapCp->hlSt = ST_SAP_BND_PEND;
#ifdef ZT
                     ztRunTimeUpd(ZT_SPSAP_CB,
                                  CMPFTHA_UPDTYPE_SYNC,
                                  CMPFTHA_ACTN_MOD,
                                  (Void *)spSapCp);
#endif /* ZT */
                     break;
                  }

                  spSapCp->ssn = tuSapCp->ssn;
               }
               else
               {
                  /* st007.301 - Added - TC-User Distribution Feature */    
#ifndef ST_TC_USER_DIST                  
                  spSapCp->ssn = spSapCp->cfg.ssn;
#endif /* ST_TC_USER_DIST */                  
               }
/* st005.301 - Added - Rolling Upgrade feature */
#ifdef ST_RUG  
               /* Bind cannot be performed in SAP does not have valid *
                * remote interface version i.e ver sync not done      */

               if(spSapCp->remIntfValid == FALSE)
               {
                  reason = LCM_REASON_SWVER_NAVAIL;
                  break;
               }
#endif /* ST_RUG */

               stEnableSPSap(spId);
               spSapCp->contEnt = ENTNC;
#ifdef ZT
               ztRunTimeUpd(ZT_SPSAP_CB, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD,
                            (Void *)spSapCp);
#endif  /* ZT */
               break;

            /* Disable the Lower Sap */
            case AUBND_DIS:
               stDisableSPSap(spId);
               spSapCp->contEnt = ENTSM;
#ifdef ZT
               ztRunTimeUpd(ZT_SPSAP_CB, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD,
                            (Void *)spSapCp);
#endif  /* ZT */
               break;
            
           /* st035.301 - Addition - Deletion of SAPs */
            /* Deletion of Lower SAP */
            case ADEL:
               /* Free the Lower SAP */
               (Void)stFreeSPSap(spId);
               break;   

            default:
               reason = LCM_REASON_INVALID_ACTION;
               break;
         }
         break;

      /* control the Group of Upper Sap */
      case STGRTCUSAP:

         if (cntrl->t.cntrl.subAction != SAGR_DSTPROCID)
         {
            reason = LCM_REASON_INVALID_SUBACTION;
            break;
         }

         switch (cntrl->t.cntrl.action)
         {
            /* Disable the Upper Sap */
            case AUBND_DIS:
               for (i = 0; i < stCb.genCfg.nmbSaps; i++)
               {
                   if (((tuSapCp = *(stCb.tuSapLst + (SpId)i)) != NULLP) &&
                       (tuSapCp->pstTU.dstProcId == 
                                          cntrl->t.cntrl.par.dstProcId))
                   {
                      stDisableTUSap(tuSapCp);
#ifdef ZT
                      ztRunTimeUpd(ZT_TUSAP_CB, CMPFTHA_UPDTYPE_SYNC,
                                   CMPFTHA_ACTN_MOD, (Void *)tuSapCp);
#endif  /* ZT */
                   }
               }
               break;
            
           /* st035.301 - Addition - Deletion of SAPs */
            /* Deletion of Group of Upper SAPs  */
            case ADEL:
               for (i = 0; i < stCb.genCfg.nmbSaps; i++)
               {
                   if (((tuSapCp = *(stCb.tuSapLst + (SpId)i)) != NULLP) &&
                       (tuSapCp->pstTU.dstProcId == 
                                          cntrl->t.cntrl.par.dstProcId))
                   {
                     /* Free the Upper SAP */
                     (Void)stFreeTUSap((SpId)i);
                   }
               }
               break;   

            default:
               reason = LCM_REASON_INVALID_ACTION;
               break;
         }
         break;

      /* control the Group of Lower Sap */
      case STGRSPSAP:

         if (cntrl->t.cntrl.subAction != SAGR_DSTPROCID)
         {
            reason = LCM_REASON_INVALID_SUBACTION;
            break;
         }

         switch (cntrl->t.cntrl.action)
         {
            /* Enable the Lower Sap */
            case ABND_ENA:
               for (i = 0; i < stCb.genCfg.nmbSaps; i++)
               {
                  if (((spSapCp = *(stCb.spSapLst + (SuId)i)) != NULLP) &&
                     (spSapCp->pstSP.dstProcId == cntrl->t.cntrl.par.dstProcId))
                  {
                          
                     /* st007.301 - Added - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
                     /* In TC-User distribution feature, SSN is a mandatory
                     * parameter during lower SAP configuration. If SSN
                     * is unknown  during control request, then indicate
                     * an unusual situation */
                     if (spSapCp->cfg.ssn == SS_UNKNOWN)
                     {        
                        reason = LCM_REASON_INVALID_ACTION;
                        break;
                     }     
#endif /* ST_TC_USER_DIST */
                     /* st007.301 - Modified - Lower SAP enable procedure */    
                     if (spSapCp->cfg.ssn == SS_UNKNOWN)
                     {
                         if (((tuSapCp = *(stCb.tuSapLst + (SpId)i)) == NULLP)
                            ||(tuSapCp->hlSt != ST_SAP_BND_ENBL))
                         {
                            spSapCp->hlSt = ST_SAP_BND_PEND;
#ifdef ZT
                            ztRunTimeUpd(ZT_SPSAP_CB,
                                         CMPFTHA_UPDTYPE_SYNC,
                                         CMPFTHA_ACTN_MOD,
                                         (Void *)spSapCp);
#endif /* ZT */
                            break;
                         }
                         spSapCp->ssn = tuSapCp->ssn;
                      }
                      else
                      {
                        /* st007.301 -Modified- TC-User Distribution Feature */
#ifndef ST_TC_USER_DIST    
                         spSapCp->ssn = spSapCp->cfg.ssn;
#endif /* ST_TC_USER_DIST */                         
                      }
/* st005.301 - Added - Rolling Upgrade feature */
#ifdef ST_RUG  
                      /* Bind cannot be performed in SAP does not have valid *
                       * remote interface version i.e ver sync not done      */

                      if(spSapCp->remIntfValid == FALSE)
                      {
                         reason = LCM_REASON_SWVER_NAVAIL;
                         break;
                      }
#endif /* ST_RUG */

                      stEnableSPSap((SuId)i);
                      spSapCp->contEnt = ENTNC;
#ifdef ZT
                      ztRunTimeUpd(ZT_SPSAP_CB, CMPFTHA_UPDTYPE_SYNC,
                                   CMPFTHA_ACTN_MOD, (Void *)spSapCp);
#endif  /* ZT */
                   }
               }
               break;

            /* Disable the Lower Sap */
            case AUBND_DIS:
               for (i = 0; i < stCb.genCfg.nmbSaps; i++)
               {
                   if (((spSapCp = *(stCb.spSapLst + (SuId)i)) != NULLP) &&
                       (spSapCp->pstSP.dstProcId == 
                            cntrl->t.cntrl.par.dstProcId))
                   {
                      stDisableSPSap((SuId)i);
                      spSapCp->contEnt = ENTSM;
#ifdef ZT
                      ztRunTimeUpd(ZT_SPSAP_CB, CMPFTHA_UPDTYPE_SYNC,
                                   CMPFTHA_ACTN_MOD, (Void *)spSapCp);
#endif  /* ZT */
                   }
               }
               break;

           /* st035.301 - Addition - Deletion of SAPs */
            /* Deletion of Group of Lower SAPs */
            case ADEL:
               for (i = 0; i < stCb.genCfg.nmbSaps; i++)
               {
                   if (((spSapCp = *(stCb.spSapLst + (SuId)i)) != NULLP) &&
                       (spSapCp->pstSP.dstProcId == 
                            cntrl->t.cntrl.par.dstProcId))
                   {
                     /* Free the Lower SAP */
                     (Void)stFreeSPSap((SuId)i);
                   }
               }
               break;   

            default:
               reason = LCM_REASON_INVALID_ACTION;
               break;
         }
         break;

      /* control the Group of Upper/Lower Sap */
      case STALLSAP:

         if (cntrl->t.cntrl.subAction != SAGR_DSTPROCID)
         {
            reason = LCM_REASON_INVALID_SUBACTION;
            break;
         }

         switch (cntrl->t.cntrl.action)
         {
            /* Enable the Sap */
            case ABND_ENA:
               for (i = 0; i < stCb.genCfg.nmbSaps; i++)
               {
                   if (((spSapCp = *(stCb.spSapLst + (SuId)i)) != NULLP) &&
                       (spSapCp->pstSP.dstProcId == cntrl->t.cntrl.par.dstProcId))
                   {
                      /* st007.301 - Added - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
                      /* In TC-User distribution feature, SSN is a mandatory
                      * parameter during lower SAP configuration. If SSN
                      * is unknown  during control request, then indicate
                      * an unusual situation */
                      if (spSapCp->cfg.ssn == SS_UNKNOWN)
                      {        
                         reason = LCM_REASON_INVALID_ACTION;
                         break;
                      }     
#endif /* ST_TC_USER_DIST */
                      /* st007.301 - Modified - Lower SAP enable procedure */    
                      if (spSapCp->cfg.ssn == SS_UNKNOWN)
                      {
                         if (((tuSapCp = *(stCb.tuSapLst + (SpId)i)) == NULLP) ||
                             (tuSapCp->hlSt != ST_SAP_BND_ENBL))
                         {
                            spSapCp->hlSt = ST_SAP_BND_PEND;
#ifdef ZT
                            ztRunTimeUpd(ZT_SPSAP_CB,
                                         CMPFTHA_UPDTYPE_SYNC,
                                         CMPFTHA_ACTN_MOD,
                                         (Void *)spSapCp);
#endif /* ZT */
                            break;
                         }
                         spSapCp->ssn = tuSapCp->ssn;
                      }
                      else
                      {
                         /* st007.301 -Modified- TC-User Distribution Feature */
#ifndef ST_TC_USER_DIST    
                         spSapCp->ssn = spSapCp->cfg.ssn;
#endif /* ST_TC_USER_DIST */                         
                      }

 /* st005.301 - Added - Rolling Upgrade feature */
#ifdef ST_RUG  
                      /* Bind cannot be performed in SAP does not have valid *
                      * remote interface version i.e ver sync not done      */

                      if(spSapCp->remIntfValid == FALSE)
                      {
                         reason = LCM_REASON_SWVER_NAVAIL;
                         break;
                      }
#endif /* ST_RUG */
                      stEnableSPSap((SuId)i);
                      spSapCp->contEnt = ENTNC;
#ifdef ZT
                      ztRunTimeUpd(ZT_SPSAP_CB, CMPFTHA_UPDTYPE_SYNC,
                                   CMPFTHA_ACTN_MOD, (Void *)spSapCp);
#endif  /* ZT */
                   }
               }
               break;

            /* Disable the Sap */
            case AUBND_DIS:
               for (i = 0; i < stCb.genCfg.nmbSaps; i++)
               {
                   if (((tuSapCp = *(stCb.tuSapLst + (SpId)i)) != NULLP) &&
                       (tuSapCp->pstTU.dstProcId == cntrl->t.cntrl.par.dstProcId))
                   {
                      stDisableTUSap(tuSapCp);
#ifdef ZT
                      ztRunTimeUpd(ZT_TUSAP_CB, CMPFTHA_UPDTYPE_SYNC,
                                   CMPFTHA_ACTN_MOD, (Void *)tuSapCp);
#endif  /* ZT */
                   }

                   if (((spSapCp = *(stCb.spSapLst + (SuId)i)) != NULLP) &&
                       (spSapCp->pstSP.dstProcId == cntrl->t.cntrl.par.dstProcId))
                   {
                      stDisableSPSap((SuId)i);
                      spSapCp->contEnt = ENTSM;
#ifdef ZT
                      ztRunTimeUpd(ZT_SPSAP_CB, CMPFTHA_UPDTYPE_SYNC,
                                   CMPFTHA_ACTN_MOD, (Void *)spSapCp);
#endif  /* ZT */
                   }
               }
               break;

           /* st035.301 - Addition - Deletion of SAPs */
            /* Deletion of All upper/lower SAPs */
            case ADEL:
               for (i = 0; i < stCb.genCfg.nmbSaps; i++)
               {
                   if (((tuSapCp = *(stCb.tuSapLst + (SpId)i)) != NULLP) &&
                       (tuSapCp->pstTU.dstProcId == 
                                          cntrl->t.cntrl.par.dstProcId))
                   {
                     /* Free the Upper SAP */
                     (Void)stFreeTUSap((SpId)i);
                   }
               }
               for (i = 0; i < stCb.genCfg.nmbSaps; i++)
               {
                   if (((spSapCp = *(stCb.spSapLst + (SuId)i)) != NULLP) &&
                       (spSapCp->pstSP.dstProcId == 
                            cntrl->t.cntrl.par.dstProcId))
                   {
                     /* Free the Lower SAP */
                     (Void)stFreeSPSap((SuId)i);
                   }
               }

            default:
               reason = LCM_REASON_INVALID_ACTION;
               break;
         }
         break;

      /* Unrecognized Elmnt value */
      default:
         reason = LCM_REASON_INVALID_ELMNT;
         break;
   }

   if (reason != LCM_REASON_NOT_APPL)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST216, (ErrVal)reason,
                 "StMiLstCntrlReq(): Incorrect action/subaction/elmnt");
#endif
      stSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, reason);
      RETVALUE(RFAILED);
   }

#ifdef ZT
   if (cntrl->t.cntrl.action != ASHUTDOWN)
      ztUpdPeer();
#endif /* ZT */

   stSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_OK, LCM_REASON_NOT_APPL);

   RETVALUE(ROK);
} /* end of StMiLstCntrlReq */


PUBLIC S16 StAddTuSapGenSts(StTUSap    *tuSapCp, StSapSts  *sts, Action action)
{
	Bool ansiFlag=FALSE;
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
	switch(tuSapCp->cfg.swtch)
	{
		case LST_SW_ANS96:
		case LST_SW_ANS92:
		case LST_SW_ANS88:
			ansiFlag=TRUE;
			break;
		default:
			break;
	}
#endif	
	/* Copy the resource usage information */
	sts->actTrns += tuSapCp->allocDlg;
	sts->actInv  += tuSapCp->allocInv;
	sts->usedTrns += tuSapCp->usedDlg;
	sts->usedInv  += tuSapCp->usedInv;

	sts->msgTx += tuSapCp->sts.msgTx;
	sts->uniTx += tuSapCp->sts.uniTx;
	sts->abtTx += tuSapCp->sts.abtTx;

	/* The following three counters are maintained for ITU only */
	if(!ansiFlag)
	{
	   sts->bgnTx += tuSapCp->sts.bgnTx;
	   sts->cntTx += tuSapCp->sts.cntTx;
	   sts->endTx += tuSapCp->sts.endTx;
	}

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
	/* The following five counters are maintained for ANSI only */
	if(ansiFlag)
	{
		sts->qwpTx += tuSapCp->sts.qwpTx;
		sts->qnpTx += tuSapCp->sts.qnpTx;
		sts->cwpTx += tuSapCp->sts.cwpTx;
		sts->cnpTx += tuSapCp->sts.cnpTx;
		sts->rspTx += tuSapCp->sts.rspTx;
	}
#endif

	/* Message Rx Statistics */

	/* The following three counters are maintained for both ITU and ANSI */
	sts->msgRx += tuSapCp->sts.msgRx;
	sts->uniRx += tuSapCp->sts.uniRx;
	sts->abtRx += tuSapCp->sts.abtRx;

	/* The following three counters are maintained for ITU only */
	if(!ansiFlag)
	{
		sts->bgnRx += tuSapCp->sts.bgnRx;
		sts->cntRx += tuSapCp->sts.cntRx;
		sts->endRx += tuSapCp->sts.endRx;
	}

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
	/* The following five counters are maintained for ANSI only */
	if(ansiFlag)
	{
		sts->qwpRx += tuSapCp->sts.qwpRx;
		sts->qnpRx += tuSapCp->sts.qnpRx;
		sts->cwpRx += tuSapCp->sts.cwpRx;
		sts->cnpRx += tuSapCp->sts.cnpRx;
		sts->rspRx += tuSapCp->sts.rspRx;
	}
#endif

	/* Component Tx Statistics */

	/* The following five counters are maintained for both ITU and ANSI */
	sts->cmpTx += tuSapCp->sts.cmpTx;
	sts->invTx += tuSapCp->sts.invTx;
	sts->resTx += tuSapCp->sts.resTx;
	sts->errTx += tuSapCp->sts.errTx;
	sts->rejTx += tuSapCp->sts.rejTx;

	/* Component Rx Statistics */

	/* The following five counters are maintained for both ITU and ANSI */

	sts->cmpRx += tuSapCp->sts.cmpRx;
	sts->invRx += tuSapCp->sts.invRx;
	sts->resRx += tuSapCp->sts.resRx;
	sts->errRx += tuSapCp->sts.errRx;
	sts->rejRx += tuSapCp->sts.rejRx;

	/* add by shu.bu 2003/08/07 for resource audit */
#ifdef UT_RES_AUD
	sts->resAudTmrFails += tuSapCp->sts.resAudTmrFails;
	sts->resRelDlg += tuSapCp->sts.resRelDlg;
#endif /* UT_RES_AUD */

	/* Note: In this implementation it gives the next available transaction Id
	and that can be used to determine total number of used transaction ids.
	A wrap around counter is being used to allocate the transaction ids */

	sts->drop += tuSapCp->sts.drop;

	if (action == ZEROSTS)
	{
	  cmZero((Data *)&tuSapCp->sts, sizeof(StSapSts));

	  /* update the date and time */
	  SGetDateTime(&tuSapCp->sts.dt);
	  SGetSysTime(&tuSapCp->sts.ticks);
	}
		
	RETVALUE(ROK);
}

PUBLIC S16 StAddTuSapAbtSts(StTUSap    *tuSapCp, StSapSts  *sts, Action action)
{
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
	Bool ansiFlag=FALSE;
	switch(tuSapCp->cfg.swtch)
	{
		case LST_SW_ANS96:
		case LST_SW_ANS92:
		case LST_SW_ANS88:
			ansiFlag=TRUE;
			break;
		default:
			break;
	}
#endif	

   sts->abtRx += tuSapCp->sts.abtRx;
   sts->abtTx += tuSapCp->sts.abtTx;

/* Protocol error detected in Transaction portion - with P-abort cause */
/* The following five counters are maintained for both ITU and ANSI */
   sts->urMsgRx.cnt += tuSapCp->sts.urMsgRx.cnt;
   sts->inTrnRx.cnt += tuSapCp->sts.inTrnRx.cnt;
   sts->bdTrnRx.cnt += tuSapCp->sts.bdTrnRx.cnt;
   sts->urTidRx.cnt += tuSapCp->sts.urTidRx.cnt;
   sts->rsrcLRx.cnt += tuSapCp->sts.rsrcLRx.cnt;

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
/* The following five counters are maintained for ANSI only */
	if(ansiFlag)
	{
		sts->prRlsRx.cnt += tuSapCp->sts.prRlsRx.cnt;
		sts->urDlgRx.cnt += tuSapCp->sts.urDlgRx.cnt;
		sts->bdDlgRx.cnt += tuSapCp->sts.bdDlgRx.cnt;
		sts->msDlgRx.cnt += tuSapCp->sts.msDlgRx.cnt;
		sts->inDlgRx.cnt += tuSapCp->sts.inDlgRx.cnt;
	}
#endif

/* The following five counters are maintained for both ITU and ANSI */
   sts->urMsgTx.cnt += tuSapCp->sts.urMsgTx.cnt;
   sts->inTrnTx.cnt += tuSapCp->sts.inTrnTx.cnt;
   sts->bdTrnTx.cnt += tuSapCp->sts.bdTrnTx.cnt;
   sts->urTidTx.cnt += tuSapCp->sts.urTidTx.cnt;
   sts->rsrcLTx.cnt += tuSapCp->sts.rsrcLTx.cnt;

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
/* The following five counters are maintained for ANSI only */
	if(ansiFlag)
	{
		sts->prRlsTx.cnt += tuSapCp->sts.prRlsTx.cnt;
		sts->urDlgTx.cnt += tuSapCp->sts.urDlgTx.cnt;
		sts->bdDlgTx.cnt += tuSapCp->sts.bdDlgTx.cnt;
		sts->msDlgTx.cnt += tuSapCp->sts.msDlgTx.cnt;
		sts->inDlgTx.cnt += tuSapCp->sts.inDlgTx.cnt;
	}
#endif	   
	if (action == ZEROSTS)
	{
	  cmZero((Data *)&tuSapCp->sts, sizeof(StSapSts));

	  /* update the date and time */
	  SGetDateTime(&tuSapCp->sts.dt);
	  SGetSysTime(&tuSapCp->sts.ticks);
	}

   RETVALUE(ROK);
}

PUBLIC S16 StAddTuSapRejSts(StTUSap    *tuSapCp, StSapSts  *sts,Action action)
{
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
	Bool ansiFlag=FALSE;
	switch(tuSapCp->cfg.swtch)
	{
		case LST_SW_ANS96:
		case LST_SW_ANS92:
		case LST_SW_ANS88:
			ansiFlag=TRUE;
			break;
		default:
			break;
	}
#endif	
   sts->rejRx += tuSapCp->sts.rejRx;
   sts->rejTx += tuSapCp->sts.rejTx;

/* Protocol error detected in conponent portion - with problem code */

/* ALL The following counters are maintained for both ITU and ANSI */
   sts->urCmpRx.cnt += tuSapCp->sts.urCmpRx.cnt;
   sts->inCmpRx.cnt += tuSapCp->sts.inCmpRx.cnt;
   sts->bdCmpRx.cnt += tuSapCp->sts.bdCmpRx.cnt;
   sts->urLidRx.cnt += tuSapCp->sts.urLidRx.cnt;
   sts->urIidRRRx.cnt += tuSapCp->sts.urIidRRRx.cnt;
   sts->uxResRx.cnt += tuSapCp->sts.uxResRx.cnt;
   sts->urIidRERx.cnt += tuSapCp->sts.urIidRERx.cnt;
   sts->uxErrRx.cnt += tuSapCp->sts.uxErrRx.cnt;

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
/* The following five counters are maintained for ANSI only */
	if(ansiFlag)
	{
		sts->inEncRx.cnt += tuSapCp->sts.inEncRx.cnt;
	}
#endif

/* TC User generated problems */

   sts->dupIdRx.cnt += tuSapCp->sts.dupIdRx.cnt;
   sts->urOprRx.cnt += tuSapCp->sts.urOprRx.cnt;
   sts->inPrmINRx.cnt += tuSapCp->sts.inPrmINRx.cnt;
   sts->rsrcInvRx.cnt += tuSapCp->sts.rsrcInvRx.cnt;
   sts->rlsInvRx.cnt += tuSapCp->sts.rlsInvRx.cnt;
   sts->uxLrspRx.cnt += tuSapCp->sts.uxLrspRx.cnt;
   sts->uxLoprRx.cnt += tuSapCp->sts.uxLoprRx.cnt;
   sts->inPrmRRRx.cnt += tuSapCp->sts.inPrmRRRx.cnt;
   sts->urErrRx.cnt += tuSapCp->sts.urErrRx.cnt;
   sts->uxEcdRx.cnt += tuSapCp->sts.uxEcdRx.cnt;
   sts->inPrmRERx.cnt += tuSapCp->sts.inPrmRERx.cnt;

/* Protocol error detected in Transaction portion - with P-abort cause */

/* Protocol error detected in conponent portion - with problem code */

/* ALL The following counters are maintained for both ITU and ANSI */
   sts->urCmpTx.cnt += tuSapCp->sts.urCmpTx.cnt;
   sts->inCmpTx.cnt += tuSapCp->sts.inCmpTx.cnt;
   sts->bdCmpTx.cnt += tuSapCp->sts.bdCmpTx.cnt;
   sts->urLidTx.cnt += tuSapCp->sts.urLidTx.cnt;
   sts->urIidRRTx.cnt += tuSapCp->sts.urIidRRTx.cnt;
   sts->uxResTx.cnt += tuSapCp->sts.uxResTx.cnt;
   sts->urIidRETx.cnt += tuSapCp->sts.urIidRETx.cnt;
   sts->uxErrTx.cnt += tuSapCp->sts.uxErrTx.cnt;

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
/* The following five counters are maintained for ANSI only */
	if(ansiFlag)
	{
		sts->inEncTx.cnt += tuSapCp->sts.inEncTx.cnt;
	}
#endif

/* TC User generated problems */

   sts->dupIdTx.cnt += tuSapCp->sts.dupIdTx.cnt;
   sts->urOprTx.cnt += tuSapCp->sts.urOprTx.cnt;
   sts->inPrmINTx.cnt += tuSapCp->sts.inPrmINTx.cnt;
   sts->rsrcInvTx.cnt += tuSapCp->sts.rsrcInvTx.cnt;
   sts->rlsInvTx.cnt += tuSapCp->sts.rlsInvTx.cnt;
   sts->uxLrspTx.cnt += tuSapCp->sts.uxLrspTx.cnt;
   sts->uxLoprTx.cnt += tuSapCp->sts.uxLoprTx.cnt;
   sts->inPrmRRTx.cnt += tuSapCp->sts.inPrmRRTx.cnt;
   sts->urErrTx.cnt += tuSapCp->sts.urErrTx.cnt;
   sts->uxEcdTx.cnt += tuSapCp->sts.uxEcdTx.cnt;
   sts->inPrmRETx.cnt += tuSapCp->sts.inPrmRETx.cnt;

	if (action == ZEROSTS)
	{
	  cmZero((Data *)&tuSapCp->sts, sizeof(StSapSts));

	  /* update the date and time */
	  SGetDateTime(&tuSapCp->sts.dt);
	  SGetSysTime(&tuSapCp->sts.ticks);
	}

   RETVALUE(ROK);
}

/*
*
*       Fun:   Statistics Request
*
*       Desc:  This function is used by the Layer Management to
*              gather solicited statistics information from TCAP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 StMiLstStsReq
(
Pst      *pst,               /* post structure */
Action    action,            /* action */
StMngmt  *sts                /* management structure */
)
#else
PUBLIC S16 StMiLstStsReq(pst, action, sts)
Pst      *pst;               /* post structure */
Action    action;            /* action */
StMngmt  *sts;               /* management structure */
#endif
{
   StTUSap    *tuSapCp;      /* TCAP Upper sap */
   SpId        spId;         /* TCAP sap Id */

#ifdef ST_LMINT3
   Pst         rPst;         /* Reply post */
#endif /* ST_LMINT3 */

   TRC3(StMiLstStsReq)
  
   UNUSED(pst);

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "StMiLstStsReq failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
          "StMiLstStsReq:action(%d), elmnt(%d), elmntInst1(%d)\n",
           action,
           sts->hdr.elmId.elmnt,
           sts->hdr.elmId.elmntInst1));
   if (sts->hdr.elmId.elmnt == STGEN)
   {
		cmZero((Data *)&sts->t.sts.sapSts, sizeof(StSapSts));
		switch(sts->hdr.elmId.elmntInst1)
		{
			case CP_TCAP_STS_GEN:
		   		for(spId=0;spId<stCb.genCfg.nmbSaps;spId++)
		   		{
					if ((tuSapCp = *(stCb.tuSapLst + spId)) != NULLP)
						StAddTuSapGenSts(tuSapCp, &sts->t.sts.sapSts,action);
		   		}
				break;
			case CP_TCAP_STS_ABT:
		   		for(spId=0;spId<stCb.genCfg.nmbSaps;spId++)
		   		{
					if ((tuSapCp = *(stCb.tuSapLst + spId)) != NULLP)
						StAddTuSapRejSts(tuSapCp, &sts->t.sts.sapSts,action);
		   		}
				break;
			case CP_TCAP_STS_REJ:
		   		for(spId=0;spId<stCb.genCfg.nmbSaps;spId++)
		   		{
					if ((tuSapCp = *(stCb.tuSapLst + spId)) != NULLP)
						StAddTuSapAbtSts(tuSapCp, &sts->t.sts.sapSts,action);
		   		}
				break;
		}
   }
   else if (sts->hdr.elmId.elmnt == STTCUSAP)
   {
	   spId = sts->hdr.elmId.elmntInst1;

	   /* validate management structure */

#if (ERRCLASS & ERRCLS_INT_PAR)

	   /* validate the sap id range */
	   if ((spId >= (SpId)stCb.genCfg.nmbSaps)|| (spId < 0)) 
	   {
	      stSendLmCfm(pst, TSTS, &sts->hdr, LCM_PRIM_NOK, LCM_REASON_INVALID_SAP);

	      STLOGERROR(ERRCLS_INT_PAR, EST217, (ErrVal)spId,
	                 "StMiLstStsReq:spId out of range");
	      RETVALUE(RFAILED);
	   }

#endif

	   /* Get the SAP definition from the SAP list */
	   if ((tuSapCp = *(stCb.tuSapLst + spId)) == NULLP)
	   {
	      /* st009.301 -Add-  Print debug info */
	      STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
	             "StMiLstStsReq:Upper Sap(%d) not configured\n", spId));
	      stSendLmCfm(pst, TSTS, &sts->hdr, LCM_PRIM_NOK, LCM_REASON_INVALID_SAP);
	      RETVALUE(RFAILED);
	   }

   /* copy statistics information */
	   cmCopy((U8 *)&tuSapCp->sts, (U8 *)&sts->t.sts.sapSts, sizeof(StSapSts));

   /* Copy the resource usage information */
	   sts->t.sts.sapSts.actTrns = tuSapCp->allocDlg;
	   sts->t.sts.sapSts.actInv  = tuSapCp->allocInv;
	   sts->t.sts.sapSts.usedTrns = tuSapCp->usedDlg;
	   sts->t.sts.sapSts.usedInv  = tuSapCp->usedInv;
#ifdef ZT_DFTHA
	   if (!ZT_IS_DIST_FTHA)
#endif /* ZT_DFTHA */
	   {
	      sts->t.sts.sapSts.trnsId  = tuSapCp->dlgIdPool;
	   }

	   /* Copy the protocol swicth */
	   sts->t.sts.sapSts.swtch = tuSapCp->cfg.swtch;

	   /* get the date and time */
	   SGetDateTime(&sts->t.sts.dt);

	   SGetSysTime(&sts->t.sts.ticks);   /* Current time in system ticks */

	   /* Duration of the statistics */
	   stGetDateTimeDura(&sts->t.sts.dt, &tuSapCp->sts.dt, &sts->t.sts.dura);

	   /* Duration is system ticks */
	   sts->t.sts.duraT = sts->t.sts.ticks - tuSapCp->sts.ticks;   

	   /* clear statistics counter if so requested */
	   if (action == ZEROSTS)
	   {
	      cmZero((Data *)&tuSapCp->sts, sizeof(StSapSts));

	      /* update the date and time */
	      SGetDateTime(&tuSapCp->sts.dt);
	      SGetSysTime(&tuSapCp->sts.ticks);
	   }
   }
   else
   {
	      stSendLmCfm(pst, TSTS, &sts->hdr, LCM_PRIM_NOK, LCM_REASON_INVALID_ELMNT);

	      STLOGERROR(ERRCLS_INT_PAR, EST218, (ErrVal)sts->hdr.elmId.elmnt,
	                 "StMiLstStsReq(): Incorrect Elmnt");
	      RETVALUE(RFAILED);
   }
   
#ifdef ST_LMINT3
   sts->cfm.status = LCM_PRIM_OK;
   sts->cfm.reason = LCM_REASON_NOT_APPL;
   stBldReplyPst(&rPst, &sts->hdr, pst);
   (Void)StMiLstStsCfm(&rPst, sts);
#else
   (Void)StMiLstStsCfm(&stCb.init.lmPst, sts);
#endif /* ST_LMINT3 */

   RETVALUE(ROK);
} /* end of StMiLstStsReq */

#ifdef ST_FTHA
/*
*
*       Fun:   System Agent control request
*
*       Desc:  This function is used by the System Agent to
*              control TCAP layer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 StMiShtCntrlReq
(
Pst *pst,                        /* post structure          */
ShtCntrlReqEvnt *reqInfo         /* system agent control request event */
)
#else
PUBLIC S16 StMiShtCntrlReq(pst, reqInfo)
Pst *pst;                      /* post structure          */
ShtCntrlReqEvnt *reqInfo;      /* system agent control request event */
#endif
{
   Pst repPst;               /* reply post structure */
   ShtCntrlCfmEvnt cfmInfo;  /* system agent control confirm event */
   StTUSap *tuSapCp;           
   StSPSap *spSapCp;           
   S16 i;                    /* Counter */
   
   TRC3 (StMiShtCntrlReq);

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(pst->dstProcId,pst->dstEnt, pst->dstInst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0, 
                 "stMiShtCntrlReq failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

#ifdef ZT
/* st005.301 - Added- Rolling Upgrade Feature */
#ifdef ST_RUG
   if ( (reqInfo->reqType != SHT_REQTYPE_GETVER) &&
        (reqInfo->reqType != SHT_REQTYPE_SETVER))
   {
#endif /* ST_RUG */
      if (!ztChkCRsetStatus())
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         STLOGERROR(ERRCLS_INT_PAR, EST219, (ErrVal)0,
                 "StMiShtCntrlReq(): Incorrect Elmnt");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_MI_INV_EVT,
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSHTCNTRLREQ, (U8)0);
         RETVALUE(ROK);
      }
#ifdef ST_RUG
   } /* if reqtype is not of getver or setver type */
   else
   {
     ztChkCfgCRsetValid();
   }
#endif /* ST_RUG */
#endif /* ZT */


   /* fill reply pst structure */
   repPst.dstProcId = pst->srcProcId;
   repPst.dstEnt    = pst->srcEnt;
   repPst.dstInst   = pst->srcInst;
   repPst.prior     = reqInfo->hdr.response.prior;
   repPst.route     = reqInfo->hdr.response.route;
   repPst.selector  = reqInfo->hdr.response.selector;
   repPst.prior     = reqInfo->hdr.response.prior;
   repPst.region    = reqInfo->hdr.response.mem.region;
   repPst.pool      = reqInfo->hdr.response.mem.pool;
   repPst.event     = EVTSHTCNTRLCFM;
   repPst.srcProcId = pst->dstProcId;
   repPst.srcEnt    = ENTST;
   repPst.srcInst   = pst->dstInst;

   /* fill reply transaction Id */
   cfmInfo.transId = reqInfo->hdr.transId;

   /* check if general configuration done */
   if (stCb.init.cfgDone != TRUE)
   {
      cfmInfo.status.status = LCM_PRIM_NOK;
      cfmInfo.status.reason = LCM_REASON_GENCFG_NOT_DONE;
      
      StMiShtCntrlCfm(&repPst, &cfmInfo);
      RETVALUE(ROK);
   }

   /* fill status value */
   cfmInfo.status.reason = LCM_REASON_NOT_APPL;
    
   switch (reqInfo->reqType)
   {
      case SHT_REQTYPE_BND_ENA:   /* system agent control bind enable */

         switch (reqInfo->s.bndEna.grpType)
         {
            case SHT_GRPTYPE_ALL: 

               /* always done only for Lower SAP */
               for (i = 0; i < stCb.genCfg.nmbSaps; i++)
               {
                  spSapCp = stCb.spSapLst[i];

                  if ((spSapCp != (StSPSap *)NULLP) &&
                      (spSapCp->pstSP.dstProcId == reqInfo->s.bndEna.dstProcId) &&
                      (spSapCp->pstSP.dstEnt == reqInfo->s.bndEna.dstEnt.ent) &&
                      (spSapCp->pstSP.dstInst == reqInfo->s.bndEna.dstEnt.inst) &&
                      (spSapCp->contEnt != ENTSM))
                  {
                     
                     /* st007.301 - Added - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
                     /* In TC-User distribution feature, SSN is a mandatory
                     * parameter during lower SAP configuration. If SSN
                     * is unknown  during control request, then indicate
                     * an unusual situation */
                     if (spSapCp->cfg.ssn == SS_UNKNOWN)
                     {        
                        cfmInfo.status.reason = LCM_REASON_INVALID_ACTION;
                        break;
                     }     
#endif /* ST_TC_USER_DIST */
                    
                     /* If SSN is not configured then take the SSN from upper SAP */
                     if (spSapCp->cfg.ssn == SS_UNKNOWN)
                     {
                        if (((tuSapCp = *(stCb.tuSapLst + (SpId)i)) == NULLP) ||
                            (tuSapCp->hlSt != ST_SAP_BND_ENBL))
                        {
                           spSapCp->hlSt = ST_SAP_BND_PEND;
#ifdef ZT
                           ztRunTimeUpd(ZT_SPSAP_CB,
                                        CMPFTHA_UPDTYPE_SYNC,
                                        CMPFTHA_ACTN_MOD,
                                        (Void *)spSapCp);
#endif /* ZT */
                           break;
                        }

                        spSapCp->ssn = tuSapCp->ssn;
                     }
                     else
                     {
                        /* st007.301 - Added - TC-User Distribution Feature */      
#ifndef ST_TC_USER_DIST                             
                        spSapCp->ssn = spSapCp->cfg.ssn;                     
#endif /* ST_TC_USER_DIST */                         
                     }

/* st005.301 - Added- Rolling Upgrade feature */
#ifdef ST_RUG  
                     /* Bind cannot be performed in SAP does not have valid *
                     * remote interface version i.e ver sync not done      */

                     if(spSapCp->remIntfValid == FALSE)
                     {
                        cfmInfo.status.reason = LCM_REASON_SWVER_NAVAIL;
                        break;
                     }
#endif /* ST_RUG */
                     stEnableSPSap((SuId)i);

#ifdef ZT

                     ztRunTimeUpd(ZT_SPSAP_CB, CMPFTHA_UPDTYPE_SYNC,
                                  CMPFTHA_ACTN_MOD, (Void *)spSapCp);
#endif /* ZT */
                  }
               }
               break;
               
            case SHT_GRPTYPE_ENT:

               for (i = 0; i < stCb.genCfg.nmbSaps; i++)
               {
                  spSapCp = stCb.spSapLst[i];

                  if ((spSapCp != (StSPSap *)NULLP) &&
                      (spSapCp->pstSP.dstEnt == reqInfo->s.bndEna.dstEnt.ent) &&
                      (spSapCp->pstSP.dstInst == reqInfo->s.bndEna.dstEnt.inst) &&
                      (spSapCp->contEnt != ENTSM))
                  {
                     /* st007.301 - Added - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
                     /* In TC-User distribution feature, SSN is a mandatory
                     * parameter during lower SAP configuration. If SSN
                     * is unknown  during control request, then indicate
                     * an unusual situation */
                     if (spSapCp->cfg.ssn == SS_UNKNOWN)
                     {        
                        cfmInfo.status.reason = LCM_REASON_INVALID_ACTION;
                        break;
                     }     
#endif /* ST_TC_USER_DIST */
                    
                     /* If SSN is not configured then take the SSN from upper SAP */
                     if (spSapCp->cfg.ssn == SS_UNKNOWN)
                     {
                        if (((tuSapCp = *(stCb.tuSapLst + (SpId)i)) == NULLP) ||
                            (tuSapCp->hlSt != ST_SAP_BND_ENBL))
                        {
                           spSapCp->hlSt = ST_SAP_BND_PEND;
#ifdef ZT
                           ztRunTimeUpd(ZT_SPSAP_CB,
                                        CMPFTHA_UPDTYPE_SYNC,
                                        CMPFTHA_ACTN_MOD,
                                        (Void *)spSapCp);
#endif /* ZT */
                           break;
                        }

                        spSapCp->ssn = tuSapCp->ssn;
                     }
                     else
                     {
#ifndef ST_TC_USER_DIST                             
                        spSapCp->ssn = spSapCp->cfg.ssn;                     
#endif /* ST_TC_USER_DIST */                         
                     }
/* st005.301 - Added- Rolling Upgrade feature */
#ifdef ST_RUG  
                     /* Bind cannot be performed in SAP does not have valid *
                     * remote interface version i.e ver sync not done      */

                     if(spSapCp->remIntfValid == FALSE)
                     {
                        cfmInfo.status.reason = LCM_REASON_SWVER_NAVAIL;
                        break;
                     }
 
#endif /* ST_RUG */
                     stEnableSPSap((SuId)i);
#ifdef ZT
                     ztRunTimeUpd(ZT_SPSAP_CB, CMPFTHA_UPDTYPE_SYNC,
                                  CMPFTHA_ACTN_MOD, (Void *)spSapCp);
#endif /* ZT */
                 }
               }
               break;
 
            default:
               cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
               break;
         }
         break;

      case SHT_REQTYPE_UBND_DIS:  /* system agent control unbind disable */
/* st005.301 - Added- Rolling Upgrade Feature */         
#ifdef ST_RUG
         /* Delete the stored version information for that SAP *
          * Loop in the stored version information store and   *
          * delete all version information entries to the dest */ 
         for(i = stCb.numIntfInfo -1; i >= 0; i--)
         {
            if(stCb.intfInfo[i].grpType == 
                             reqInfo->s.ubndDis.grpType)
            {
               switch(stCb.intfInfo[i].grpType)
               {
                  case SHT_GRPTYPE_ALL:
                     if(stCb.intfInfo[i].dstProcId == 
                           reqInfo->s.ubndDis.dstProcId &&
                        stCb.intfInfo[i].dstEnt.ent ==
                           reqInfo->s.ubndDis.dstEnt.ent &&
                        stCb.intfInfo[i].dstEnt.inst == 
                           reqInfo->s.ubndDis.dstEnt.inst)
                     {
#ifdef ZT
                        /* Delete The interface version at  *
                         * standby/shadows                  */
                        ztRunTimeUpd(ZT_VERINFO_CB, CMPFTHA_UPDTYPE_SYNC, 
                                   CMPFTHA_ACTN_DEL, (Void *)&stCb.intfInfo[i]);
#endif /* ZT */
                        /* delete the version information by*
                         * copying the last version infor   *
                         * into current location            */
                        cmMemcpy((U8 *)&(stCb.intfInfo[i]), 
                                 (U8 *)&(stCb.intfInfo[stCb.numIntfInfo-1]),
                                              sizeof(ShtVerInfo)); 
                        stCb.numIntfInfo--;
                     }
                     break;
                             
                  case SHT_GRPTYPE_ENT:
                     if(stCb.intfInfo[i].dstEnt.ent ==
                           reqInfo->s.ubndDis.dstEnt.ent &&
                        stCb.intfInfo[i].dstEnt.inst == 
                           reqInfo->s.ubndDis.dstEnt.inst)
                     {
#ifdef ZT
                        /* Delete The interface version at  *
                         * standby/shadows                  */
                        ztRunTimeUpd(ZT_VERINFO_CB, CMPFTHA_UPDTYPE_SYNC, 
                                     CMPFTHA_ACTN_DEL, 
                                     (Void *)&stCb.intfInfo[i]);
#endif /* ZT */
                        /* delete the version information by*
                         * copying the last version infor   *
                         * into current location            */
                        cmMemcpy((U8 *)&(stCb.intfInfo[i]), 
                                 (U8 *)&(stCb.intfInfo[stCb.numIntfInfo-1]),
                                              sizeof(ShtVerInfo));
                        stCb.numIntfInfo--;
                     }
                     break;
               } /* switch */ 
            } /* if */
         } /* for */
#endif /* ST_RUG */

         switch (reqInfo->s.ubndDis.grpType)
         {
            case SHT_GRPTYPE_ALL:

               for (i = 0; i < stCb.genCfg.nmbSaps; i++)
               {
                  spSapCp = stCb.spSapLst[i];

                  if ((spSapCp != (StSPSap *)NULLP) &&
                      (spSapCp->pstSP.dstProcId == reqInfo->s.ubndDis.dstProcId) &&
                      (spSapCp->pstSP.dstEnt == reqInfo->s.ubndDis.dstEnt.ent) &&
                      (spSapCp->pstSP.dstInst == reqInfo->s.ubndDis.dstEnt.inst) &&
                      (spSapCp->contEnt != ENTSM))
                  {
                     stDisableSPSap((SuId)i);
/* st005.301 - Added- Rolling Upgrade Feature */
#ifdef ST_RUG
                     spSapCp->remIntfValid = FALSE;
#endif /* ST_RUG */

#ifdef ZT
                     ztRunTimeUpd(ZT_SPSAP_CB, CMPFTHA_UPDTYPE_SYNC,
                                  CMPFTHA_ACTN_MOD, (Void *)spSapCp);
#endif /* ZT */
                  }
               }

               for (i = 0; i < stCb.genCfg.nmbSaps; i++)
               {
                  tuSapCp = stCb.tuSapLst[i];

                  if ((tuSapCp != (StTUSap *)NULLP) &&
                      (tuSapCp->pstTU.dstProcId == reqInfo->s.ubndDis.dstProcId) &&
                      (tuSapCp->pstTU.dstEnt == reqInfo->s.ubndDis.dstEnt.ent) &&
                      (tuSapCp->pstTU.dstInst == reqInfo->s.ubndDis.dstEnt.inst))
                  {
                     stDisableTUSap(tuSapCp);
/* st005.301 - Added- Rolling Upgrade Feature */
#ifdef ST_RUG
                     tuSapCp->remIntfValid = FALSE;
#endif /* ST_RUG */
#ifdef ZT
                     ztRunTimeUpd(ZT_TUSAP_CB, CMPFTHA_UPDTYPE_SYNC,
                                  CMPFTHA_ACTN_MOD, (Void *)tuSapCp);
#endif /* ZT */
                  }
               }
               break;

            case SHT_GRPTYPE_ENT:

               for (i = 0; i < stCb.genCfg.nmbSaps; i++)
               {
                  spSapCp = stCb.spSapLst[i];

                  if ((spSapCp != (StSPSap *)NULLP) &&
                      (spSapCp->pstSP.dstEnt == reqInfo->s.ubndDis.dstEnt.ent) &&
                      (spSapCp->pstSP.dstInst == reqInfo->s.ubndDis.dstEnt.inst) &&
                      (spSapCp->contEnt != ENTSM))
                  {
                     stDisableSPSap((SuId)i);

/* st005.301 - Added- Rolling Upgrade Feature */
#ifdef ST_RUG
                     spSapCp->remIntfValid = FALSE;
#endif /* ST_RUG */
#ifdef ZT
                     ztRunTimeUpd(ZT_SPSAP_CB, CMPFTHA_UPDTYPE_SYNC,
                                  CMPFTHA_ACTN_MOD, (Void *)spSapCp);
#endif /* ZT */
                  }
               }

               for (i = 0; i < stCb.genCfg.nmbSaps; i++)
               {
                  tuSapCp = stCb.tuSapLst[i];

                  if ((tuSapCp != (StTUSap *)NULLP) &&
                      (tuSapCp->pstTU.dstEnt == reqInfo->s.ubndDis.dstEnt.ent) &&
                      (tuSapCp->pstTU.dstInst == reqInfo->s.ubndDis.dstEnt.inst))
                  {
                     stDisableTUSap(tuSapCp);

/* st005.301 - Added- Rolling Upgrade Feature */
#ifdef ST_RUG
                     tuSapCp->remIntfValid = FALSE;
#endif /* ST_RUG */
#ifdef ZT
                     ztRunTimeUpd(ZT_TUSAP_CB, CMPFTHA_UPDTYPE_SYNC,
                                  CMPFTHA_ACTN_MOD, (Void *)tuSapCp);
#endif /* ZT */
                  }
               }
               break;
            default:
               cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
               break;
         }
         break;

/* st005.301 - Added- Rolling Upgrade feature */
#ifdef ST_RUG

         case SHT_REQTYPE_GETVER:   /* system agent control Get Version */
            stGetVer(&cfmInfo.t.gvCfm);
            break;
   
          case SHT_REQTYPE_SETVER:  /* system agent control Set Version */
             stSetVer(&reqInfo->s.svReq, &cfmInfo.status); 
#ifdef ZT
             /* Send The interface version to standby/shadows  */
             if(cfmInfo.status.reason == LCM_REASON_NOT_APPL)
                  ztRunTimeUpd(ZT_VERINFO_CB, CMPFTHA_UPDTYPE_SYNC, 
                            CMPFTHA_ACTN_MOD, (Void *)&reqInfo->s.svReq);
                             
#endif /* ZT */
             break; 

#endif /* ST_RUG */

           default:
              cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
              break;
   }

   /* Response is sent without waiting for bind or unbind to complete */

   /* If we are not able to find any SAP to start bind enable or
      unbind disable, still a success response is returned by the
      protocol layer */

   if (cfmInfo.status.reason != LCM_REASON_NOT_APPL)
   {
      cfmInfo.status.status = LCM_PRIM_NOK;
   }
   else
   {
      cfmInfo.status.status = LCM_PRIM_OK;
   }
   
#ifdef ZT
   ztUpdPeer();
#endif /* ZT */

/* st005.301 - Added- Rolling Upgrade feature */
#ifdef ST_RUG
   /* Fill in request type */
   cfmInfo.reqType = reqInfo->reqType;
#endif /* ST_RUG */
   /* send the response */
   StMiShtCntrlCfm(&repPst, &cfmInfo);
       
   RETVALUE(ROK);
} /* end StMiShtCntrlReq */
#endif /* ST_FTHA */


/*
*     interface functions to system services
*/
  
/*
*
*       Fun:   Activate Task - initialize
*
*       Desc:  Invoked by system services to initialize a task.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
#ifdef ANSI
PUBLIC S16 stActvInit
(
ProcId proc,           /* Proc Id * */
Ent      ent,                   /* entity */
Inst     inst,                  /* instance */
Region   region,                /* region */
Reason   reason,                 /* reason */
void **xxCb            /* protocol control block */
)
#else
PUBLIC S16 stActvInit(proc, ent, inst, region, reason)
ProcId proc;           /* Proc Id */
Ent      ent;                   /* entity */
Inst     inst;                  /* instance */
Region   region;                /* region */
Reason   reason;                /* reason */
void     **xxCb;            /* protocol control block */
#endif
#else
#ifdef ANSI
PUBLIC S16 stActvInit
(
Ent      ent,                   /* entity */
Inst     inst,                  /* instance */
Region   region,                /* region */
Reason   reason                 /* reason */
)
#else
PUBLIC S16 stActvInit(ent, inst, region, reason)
Ent      ent;                   /* entity */
Inst     inst;                  /* instance */
Region   region;                /* region */
Reason   reason;                /* reason */
#endif
#endif
{
#ifdef SSI_WITH_CLI_ENABLED
	S32 retPrtl;
	S32 retSt;
#endif /* SSI_WITH_CLI_ENABLED */
   CmElmntDef **msgDef;         /* Database definition */
   U16 i = 0;
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   PRIVATE U16 stNumCallsToInit = 0;
#endif
 
   TRC3(stActvInit)

#ifdef SSI_WITH_CLI_ENABLED
	retPrtl = XOS_RegistCmdPrompt( SYSTEM_MODE, "prtl",  "Э��ģʽ", "�޲���" );

	retSt = XOS_RegistCmdPrompt( retPrtl, "tcap", "TCAP Э��", "�޲���" );

	XOS_RegistCommand(retSt,
		              stPrintStCb,
					  "showcb",
					  "��ʾ����ƿ���Ϣ",
					  "�����ʽ:showcb\r\n\r\n�޲���\r\n");

	XOS_RegistCommand(retSt,
		              stPrintStSPSap,
					  "showlsap",
					  "��ʾ�²�ҵ����ʵ���ƿ���Ϣ",
					  "�����ʽ:showlsap [����1]\r\n\r\n����1: ҵ����ʵ�ID����ѡ��\r\n������������ʾ���������õ��²�ҵ����ʵ���ƿ�\r\n");
	
	XOS_RegistCommand(retSt,
		              stPrintStTUSap,
					  "showusap",
					  "��ʾ�ϲ�ҵ����ʵ���ƿ���Ϣ",
					  "�����ʽ:showuap [����1]\r\n\r\n����1: ҵ����ʵ�ID����ѡ��\r\n������������ʾ���������õ��ϲ�ҵ����ʵ���ƿ�\r\n");
	
	XOS_RegistCommand(retSt,
		              stPrintDbgmsk,
					  "showdbgmask",
					  "��ʾ��������",
					  "�����ʽ:showdbgmask\r\n\r\n�޲���\r\n");
	
	XOS_RegistCommand(retSt,
		              stSetDbgmsk,
					  "setdbgmask",
					  "���õ�������",
#if 1					  
					  "�����ʽ:setdbgmask <����1>\r\n\r\n����1: �������ͣ���ѡ\r\n0\t\t�ر���������\r\n0xFFFFFFFF\t����������\r\n0x00000001\t��DBGMASK_SI\r\n0x00000002\t��DBGMASK_MI\r\n0x00000004\t��DBGMASK_UI\r\n0x00000008\t��DBGMASK_LI\r\n0x00000100\t��ST_DBGMASK_GEN\r\n0x00000200\t��ST_DBGMASK_ENCODE\r\n0x00000400\t��ST_DBGMASK_DECODE\r\n0x00000800\t��ST_DBGMASK_SM\r\n0x00001000\t��ST_DBGMASK_NORMAL\r\n\r\n����򿪶�����룬���Խ���Ӧ�Ĳ�������ӣ���Ϊ�������롣\r\n��:����UI��MI������Խ�0x6(2+4)��Ϊ�������룬������:\r\nsetdbgmask 0x6\r\n");
#else
					  "�����ʽ:setdbgmask <����1> <����2>\r\n\r\n����1: �������ͣ���ѡ\r\n0xFFFFFFFF\t������������в���\r\n0x00000001\t��DBGMASK_SI���в���\r\n0x00000002\t��DBGMASK_MI���в���\r\n0x00000004\t��DBGMASK_UI���в���\r\n0x00000008\t��DBGMASK_LI���в���\r\n0x00000100\t��ST_DBGMASK_GEN���в���\r\n0x00000200\t��ST_DBGMASK_ENCODE���в���\r\n0x00000400\t��ST_DBGMASK_DECODE���в���\r\n0x00000800\t��ST_DBGMASK_SM���в���\r\n0x00001000\t��ST_DBGMASK_NORMAL���в���\r\n\r\n����2: ����ѡ���ѡ\r\n0\t�ر�\r\n1\t��\r\n\r\n����򿪶�����룬���Խ���Ӧ�Ĳ�������ӣ���Ϊ�������롣\r\n��:����UI��MI������Խ�0x6(2+4)��Ϊ�������룬������:\r\nsetdbgmask 0x6 1\r\n");
#endif
	XOS_RegistCommand(retSt,
		              stSetErrCtrl,
					  "seterrctrl",
					  "���ô�����Ʊ�־",
					  "�����ʽ:seterrctrl <����1>\r\n\r\n����1: ����ѡ���ѡ\r\n0\t�ر�\r\n1\t��\r\n");
	
	XOS_RegistCommand(retSt,
		              stSetTrc,
					  "settrc",
					  "���ø��ٱ�־",
					  "�����ʽ:settrc <����1>\r\n\r\n����1: ����ѡ���ѡ\r\n0\t�ر�\r\n1\t��\r\n");
	
	XOS_RegistCommand(retSt,
		              stPrintSts,
					  "showsts",
					  "��ʾҵ����ʵ��ͳ����Ϣ",
					  "�����ʽ:showsts [����1] [����2]\r\n\r\n����1: ҵ����ʵ�ID����ѡ\r\n-1\t\t������ҵ����ʵ������Ĭ��ѡ��\r\n�����Ǹ�ֵ\t��ָ����ҵ����ʵ����\r\n\r\n����2: �������Ƿ����㣬��ѡ\r\n0\t����\r\n1\t�����㣬Ĭ��ѡ��\r\n\r\n������������ʾ���������õ�ҵ����ʵ�ͳ����Ϣ���Ҳ��Լ���������\r\n");
	
	XOS_RegistCommand(retSt,
		              stPrintDialog,
					  "showdlg",
					  "��ʾ�Ի���Ϣ",
					  "�����ʽ:showdlg [����1] [����2]\r\n\r\n����1: ҵ����ʵ�ID����ѡ��\r\n\r\n����2: �Ի�ID����ѡ��\r\n\r\n������������������ʾָ���ĶԻ���Ϣ��\r\nֻ�в���1��������ʾ��ҵ����ʵ�����жԻ���Ϣ��\r\n�޲�������ʾ���жԻ��ĸ�Ҫ��Ϣ\r\n");

	XOS_RegistCommand(retSt,
		              stPrintTuSapBitMap,
					  "showbitmap",
					  "��ʾ�ϲ�ҵ����ʵ��λͼ��Ϣ",
					  "�����ʽ:showbitmap [����1]\r\n\r\n����1: �ϲ�ҵ����ʵ�ID����ѡ��������������ʾ���������õ�ҵ����ʵ��λͼ��Ϣ\r\n");
#if 0	
	XOS_RegistCommand(retSt,
		              stPrintRegionInfo,
					  "showregion",
					  "��ʾ�ڴ�������Ϣ",
					  "�����ʽ:showregion <����1>\r\n\r\n����1: �ڴ�����ID����ѡ");
#endif	
#ifdef CP_OAM_SUPPORT
	XOS_RegistCommand(retSt,
		              stDynCfgDbg,
					  "dyncfg",
					  "���ܶ�̬����",
					  "�����ʽ:dyncfg <����1> <����2> [����3]\r\n\r\n����1: Ҫ�·����У���ѡ\r\n0\t�·�������\r\n1\t�·���һ��\r\n2\t�·��ڶ���\r\n\r\n����2: ����ֵ����ѡ\r\n\r\n����3: �ڶ�������ֵ����ѡ��������1Ϊ0ʱ��ֵ�������\r\n");
#endif /* CP_OAM_SUPPORT */
#endif /* SSI_WITH_CLI_ENABLED */

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (reason != SHUTDOWN)
   {
      if(!stNumCallsToInit)
      {
         for(;i < ST_MAX_INSTANCES;i++)
              cmZero((Data *)&stGlCbLst[i], sizeof (StGlCb));
      }
      if(stNumCallsToInit >= ST_MAX_INSTANCES)
         RETVALUE(FALSE);
      stGlCbLst[stNumCallsToInit].used = TRUE;
      *xxCb = (void *) &stGlCbLst[stNumCallsToInit];
      stGlCbPtr = &stGlCbLst[stNumCallsToInit];
      stNumCallsToInit++;
   }
#endif
   cmZero ((U8 *)&stCb, sizeof (StCb));

   /* save initialization parameters */
   stCb.init.ent    = ent;
   stCb.init.inst   = inst;
   stCb.init.region = region;
   stCb.init.reason = reason;
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   stCb.init.procId = proc;
#else
   stCb.init.procId = SFndProcId();
#endif

   /* Disable the alrams */
   stCb.init.usta = FALSE;

   /* Configuration not done yet */
   stCb.init.cfgDone = FALSE;

   /* Disable the trace */
   stCb.init.trc = FALSE;

/* st005.301 - Added- Initialize stCb block  */
   stCb.allocMem = 0;
   stCb.memSize = 0;
   
#ifdef ST_RUG
/* Initialize fields related to interface version */   
   stCb.numIntfInfo = 0;
   stCb.intfInfo = (ShtVerInfo *)NULLP;
#endif /* ST_RUG */
#ifdef DEBUGP
   /* Initialize the debug mask */
   stCb.init.dbgMask = 0;
#endif

   /* timing queue control point for layer */
   stCb.tqCp.nxtEnt = 0;
   stCb.tqCp.tmrLen = STTQNUMENT;
   stCb.sapTqCp.nxtEnt = 0;
   stCb.sapTqCp.tmrLen = STTQNUMENT;

   /* timing queue table: array of STTQNUMENT pointers */
   for(i=0; i < STTQNUMENT; i++)
   {
      stCb.tq[i].first = (CmTimer *)NULLP;
      stCb.tq[i].tail = (CmTimer *)NULLP;
      stCb.sapTq[i].first = (CmTimer *)NULLP;
      stCb.sapTq[i].tail = (CmTimer *)NULLP;
   }

   /* Initialize the ASN.1 Database definitions */

   /* Get the Database definition of the Itu Component portion */
   msgDef = (CmElmntDef **)stGetMsgDef(ST_DBTYPE_COMP, LST_SW_ITU92);

   /* Initialize the database definition */
   cmInitMsgDb(msgDef);

   /* Get the Database definition of the Itu Dialogue portion */
   msgDef = (CmElmntDef **)stGetMsgDef(ST_DBTYPE_DLG, LST_SW_ITU92);

   /* Initialize the database definition */
   cmInitMsgDb(msgDef);


   /* perform external initialization, if needed */
   /* (stInitExt is in file st_ex_ms.c) */

   (Void) stInitExt();  

   /* By default enable the timers */
   stCb.tmrFlag = FALSE;

   /* By default disable the error control flag */
   stCb.errCntrlFlg = FALSE;

#ifdef ST_USTA
   stCb.init.usta = TRUE;
#endif

#ifdef DEBUGP
#ifdef ST_DEBUG
   stCb.init.dbgMask = g_stDbgMask;
#endif
#endif

#ifdef ZT
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   stCb.psfCb = (Void *)&(ztCbLst[stNumCallsToInit - 1]);
#endif   
/* st036.301   -  ztActvInit is put outside SS_MULTIPLE_PROCS.*/
   ztActvInit(ent, inst, region, reason);
#endif /* ZT */


   RETVALUE(ROK);
} /* end of stActvInit */


/*
*
*       Fun:   Activate Task - timer
*
*       Desc:  Invoked by system services to activate a task with
*              a timer tick.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
#ifdef ANSI
PUBLIC S16 stActvTmr
(
ProcId  proc,
Ent     ent,
Inst    inst
)
#else
PUBLIC S16 stActvTmr(proc, ent, inst)
ProcId  proc;
Ent     ent;
Inst    inst;
#endif
#else
#ifdef ANSI
PUBLIC S16 stActvTmr
(
Void
)
#else
PUBLIC S16 stActvTmr()
#endif
#endif
{
   TRC3(stActvTmr)  
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   if (SGetXxCb(proc,ent, inst, (void *)&stGlCbPtr) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST337, (ErrVal)0,
                 "stActvTmr failed: can not derive stCb");
#endif
      RETVALUE(RFAILED);
   }
/* STDBGP(DBGMASK_MI, (stCb.init.prntBuf,
           "----------TCAP--------(proc(%d),entt(%d),inst(%d))------\n",
                          proc,ent,inst)); */
#endif
   /* Process the timers only if they are enabled */
   if (!stCb.tmrFlag)
   {
      cmPrcTmr(&stCb.tqCp, stCb.tq, (PFV) stTmrEvnt);
   }

   RETVALUE(ROK);
} /* end of stActvTmr */
 

/*
*
*       Fun:   Activate Task - timer
*
*       Desc:  Invoked by system services to activate a task with
*              a timer tick.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 stActvSapTmr
(
Void
)
#else
PUBLIC S16 stActvSapTmr()
#endif
{
   TRC3(stActvSapTmr)  

   /* Process the timers only if they are enabled */
   if (!stCb.tmrFlag)
   {
      cmPrcTmr(&stCb.sapTqCp, stCb.sapTq, (PFV) stTmrEvnt);
   }

   RETVALUE(ROK);
} /* end of stActvSapTmr */
 

/********************************************************************30**
 
         End of file:     ct_bdy1.c@@/main/20 - Fri Nov 17 10:34:26 2000
 
*********************************************************************31*/
 

/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 

/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
 

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  mma   1. initial release
 
1.2          ---  mma   1. remove some unused local variables
 
1.3          ---  mma   1. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92

1.4          ---  mma   1. removed constPrim from database
             ---  mma   2. removed ANSI88 parameter handling

1.5          ---  mma   1. remove stSkipHdr function and prototype

1.6          ---  mma   1. remove ifdef ERRCHK from around some ret

1.7          ---  lc    1. modified stFindTrans to support ST_ANSI_QRY_PRM
                           and ST_ANSI_QRY_NO_PRM
                  lc    2. changed the order of transmitting components
                           to the TCAP user in functions: stDHATRUni,
                           stDHATRBegin, stDHATREnd, stDHATRContinue,
                           stDHATRPAbort, stDHATRUAbort
             ---  ak    3. modified all routines to use new StDlgCp
                           and remove all uses of stTransCp
             ---  ak    4. stStartTmr uses passed Invoke Timer if non-zero.
                           uses configured value otherwise.
             ---  ak    5. stInsHashDlg, stFindHashDlg etc. now use
                           s->curSpDlgId (stSpDlgId) as the hash key.
             ---  ak    6. reversed changes from item 1.7-2 above.
             ---  ak    7. use Pst structure in place of BndCfg
             ---  ak    8. All Stu-DatReq/UDatReq/DatInd/UDatInd now
                           support a priority field.
             ---  ak    9. replaced ss_ms/ss_pt.[hx] with ssi.[hx]

1.8          ---  ak    1. replaced ESTXXX with number.

1.9          ---  ak    1. common timing queue routines
             ---  ak    2. Component portion is OPTIONAL in BEGIN/CONT/END

1.10         ---  fmg   1. changed S16 to U16 for 'i' in stStrCmp
             ---  fmg   2. changed MsgLen to U16 for 'i' in stStrCmp
             ---  ak    3. fixed ANSI component id decoding

1.11         ---  ak    1. added stDbDlgArry for dialog portion encoding
             ---  ak    2. made all state machine primitives PRIVATE.
             ---  ak    3. replaced timer Q routines with cm_bdy5 routines
             ---  ak    4. added primitives to encode/decode dialog portion
             ---  ak    5. split P_ABORT and U_ABORT
             ---  ak    6. removed empty function stGenCntrlReq.
             ---  fmg   7. fixed uninitialized variable problem in stSynBegin
             ---  fmg   8. Change VOID to Void in stDHATCContinue
             ---  ak    9. stHashInv now reads protocol class from s->curComp

1.12         ---  ak    1. surrounded instances of ANSI transId with ifdefs

1.13         ---  aa    1. Changes due to TCAP uuper interface changes.
             ---  aa    2. surrounded instances of ANSI88 with ANSI92 .

1.14         ---  aa    3. Added trace Indication 

1.15         ---  aa    1. Fixed the Bug in functions stRemHashInvk and stRemHashInvk
             ---  aa    2. Changed the functions stBldMsg, stDecMsg and 
                           stSndPAbrt to send the destination transaction Id in
                           the outgoing message same as in the incoming message.
                           (previoulsy it was alwyas send as 4 bytes)
             ---  aa    3. Change the type of Orignating and Destination Trid
                           to ST_STRING from ST_U32 in the message data base.
             ---  aa    4. Added a new function stU32ToStr, to convert a U32
                           value to a StStr.
             ---  aa    5. Changed the LST_SW_CCITTxx to LST_SW_ITUxx and
                           LST_SW_ANSIxx to LST_SW_ANSxx

1.16         ---  aa    1. Changes due to serror.
             ---  aa    2. Functions which were called from a PUBLIC function
                           matrix are made PUBLIC (as they are called directly
                           now)
             ---  aa    3. Added the new functions to check the state of TSL
                           for the Data Request event.
             ---  aa    4. miscellaneous cahnges.

*********************************************************************81*/


/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.17         ---      aa   1. Fixed the bug in stISMInvTmr and stISMRejTmr functions
                             (The SAP structure "s" variables were not initialized)
             ---     aa   2. SCCP UDatReq now needs a unique Id to be passed in
                             the UDatEvnt structure for class 1 SCCP messages.
                             made changes in the code to pass the spDlgId as 
                             Sequenced Control Number 
             ---     aa   3. Fixed the bugs in stEncDlg and stDecDlg functions. 
                             the Value given for Dialogue OBJ ID in Q.773 are
                             ASN/1 encoded and in the code they were are again
                             encoded using the ASN.1 rules for OBJ ID, because
                             of which the first encoded bytes was 0x11 instead
                             00.
             ---     aa   4. Initialized the apn.len = 0 in stInsHashDlg function
             ---     aa   5. Fixed the bug in function stBldDlg. (The length 
                             for the external tag was not computed corrcetly)
             ---     aa   6. Added the check in stDecMsg for received TCAP message
                             length. 
             ---     aa   7. Initialized the invokeId to ST_INV_INVKID in case of 
                             unrecognized component type (function stCCComponents)
            ---      aa   8. Added the check in stDecMsg for the component portion
                             length field.
            ---      aa   9. Corrected the code related ST_INV_INVKID bug.
 
1.18         ---      aa   1. fix the bug related to wrong provider abort cause
            ---      aa   2. The message was getting freed twice if the component
                             type was unknown and the lastCmp flag was not set
                             to False
            ---      sg   3. Fixed bugs in stRemHashInv and stRemHashDlg
            ---      nj   4. Added a new function 'stFindOrgTrans' to find
                             originating transaction id in mBuf.
            ---      nj   5. Timer was getting started after StuCmpInd. In
                             tightly coupled case, user migtht send a Abort
                             which would result in deletion of the corresponding
                             dialogue control point and when we returns from
                             StuCompInd we would be starting the timer for
                             non-existing invocation. To take care of this timer
                             start has been moved before calling StuCmpInd.

            ---      nj   6. Fixed a bug in stInsHashInv, stFindHashInv and
                             stRemHashInv to allow invoke id to take value
                             from -128 to 127. Earlier it allowed values
                             0 to 127.

            ---      nj   7. Modified the code to change tslSt (Transaction
                             state) before calling StLiSptUDatReq.

            ---      nj   8. Corrected the order of the SCCP addresses (source
                             and destination) while making a call to stSndPAbrt
                             to match the prototype (destination first then
                             followed by the source address).

            ---      nj   9. Store the Destination sccp address received in the
                             first backward continue as it might have been
                             changed by the peer.

1.19         ---      nj   1. Rewrote this file. This file now contains the
                              interface primitives which were there in st_bdy2.c
                              previously.

             ---      nj   2. Allowed empty user info buffer to be treated as
                              the buffer not present.
             ---      nj   3. Fixed the code to support the user abort
                              information to be included in a itu88 u-abort
                              message.

             ---      nj   4. Made changes to support CfgCfm, CntrlCfm and
                              bind confirm.
                      nj   5. Made changes to support PSF.
             ---      nj   6. Added Support for ITU-96.

1.20         ---      nj   1. Fixed the lower Sap bind procedure to copy
                              the correct SSN value from the corresponding
                              upper SAP.

1.21         ---      nj   1. Added group SAP enable/disable control request

1.22         ---      nj   1. Added a state in lower SAP to initiate bind procedure
                              on lower SAP when the corresponding upper SAP is
                              being bound if the lower SAP has received a BIND reuqest
                              earlier from the layer manager.

1.23         ---      nj   1. Modified the code to pass opc to the TCAP-User in
                              StuDatInd, StuCmpInd and StuUDatInd primitives.

/main/20     ---      nj   1. Changes for distributed FTHA
                           2. Modified the ZT_DFTHA flag to ZT, surrounding
                              stAllocDlg function. Now, the alternate stAllocDlg
                              funtion shall be used for both DFTHA and FTHA.

3.1+      st001.301   as   1. The flag ST_FTHA need not be defined when ZT is 
                              defined. This dependency has been removed from 
                              the code.

3.1+      st004.301   zr   1. Fix for number of dialogues, invokes limit check

3.1+      st005.301   zr   1. Rolling upgrade changes, under the compile flag
                              ST_RUG, as per tcr0020.txt:
                           -  During general configuration, memory allocation
                              for storing interface version information and 
                              configuration of LM interface version number 
                              within lmPst. 
                           -  Initializing upper interface version number 
                              in pst->intfVer within upper SAP during config.
                           -  Initializing lower interface version number in 
                              pst->intfVer within lower SAP during config.
                           -  Providing self and remote interface version number
                              to LM in upper SAP status. 
                           -  While handling bind request from upper user, 
                              remote interface version information for upper 
                              user is searched in the stored interface version 
                              informations and pst->intfVer within upper SAP is 
                              initialized accordingly, in case, version 
                              information for the upper user is not found from 
                              the stored version informations, a bind confirm 
                              with CM_BND_NOK is generated to user.
                           -  While handling unbind request from upper user,
                              remIntfVer is set as FALSE
                           -  In the system agent control request, handling for 
                              request type SHT_REQTYPE_GETVER and
                              SHT_REQTYPE_SETVER.
                           -  While handling control request, if the request 
                              type is Bind Enable, then check is provided to
                              make sure that version information is provided beforehand.
                           -  File -  mrs.x included under ZT
3.1+      st007.301   zr   1. TC-User Distribution Feature
                              - In all primitives upper to lower SAP association
                                is done by a special routine
                              - In all primitives lower to upper SAP association
                                is done by a special routine
                              - During lower SAP configuration and reconfiguration,
                                validation of SSN info. is done
                              - During various control requests involving lower SAP,
                                taking the SSN from the upper SAP is restricted 
3.1+     st008.301   zr    1. Corrected instance info in pst structure in
                              StUiStuBndReq routine                             
3.1+     st009.301    zr   1. Add more debug prints throughout the entire file.
3.1+     st011.301   akp   1. Added in element STGEN of status request to 
                              query whether general configuration is done 
                              or not.
3.1+     st012.301    zr   1. Association is made outside of flag 
                              ST_TC_USER_DIST in routine StLiSptSteCfm
                           2. Sap Id is properly passed in alarms and debug 
                              prints
3.1+     st013.301   akp   1. During status request query for the system Id, 
                           there should not use of spId. if check statement
                           of element STGEN modified by ANDing element STSID.  
3.1+     st014.301    zr  1. Handle Support for STU and SPT interface changes 
                          - New parameters  are introduced in some
                              primitives,
                              Primitive Name        Parameter
                              - StUiStuDatReq       imp, isni
                              - StUiStuUDatReq      imp, isni
                              - StLiSptStaCfm       sccpState, ril
                              - StLiSptPCSteInd     sccpState, ril         
                          - Support for conveying the new parameters
                            are provided in affected primitives
3.1     st015.301     zr  1. Handle Component Cancel request for deleting
                          from sending or receiving side invoke hash list   
                          2. In Status request routine removed O2 compilation
                          warning.
3.1+      st023.301   jz  1. Deallocate the user buffer in error scenarios.
3.1+      st025.301   jz  1. Free the user buffer in some error cases.
3.1       st026.301   ds  For tight coupling mode send the spDlgId in component
                          confirm message if dialogue Cp is still valid.
                          Change in proc StUiStuDatReq()
3.1+      st027.301   ds  Replace SPutMsg call with STFREEUSERBUF call to avoid
                          mem corruption on double deallocation.
3.1+      st028.301   ds  TCAP doesn't allocate new dialogue if spDlgId is not
                          ZERO.
3.1+      st034.301   yk  1. Code Added for SS_MULTIPLE_PROCS
3.1+      st035.301   mkm 1. Addition of SAP deletion in Control Request.
                          2. Changes for proper handling of StLiSptStaInd for ST_TC_USER_DIST flag.
3.1+      st036.301   mkm 1. Correction of patch st035.301. 
                          2. Increase number of bins in dialogue hash list.
                          3. put ztActvInit outside SS_MULTIPLE_PROCS flag
                          4. In test case 209, replace  STACC_PROC_ID0 with par. 
3.1+      st037.301   mkm 1. Removal of warnings.
                          2. Change from hardcode variable size to MsgLen for LONG_MSG flag.
3.1+       st038.301   mkm 1. Modify Test case Ids to remove error of duplicate case.
                           2. Initilaisation of variables used uninitialised.
                           3. Putting stDecAnsiMsgHdr under ANSI flags.
                           4. Replace SFndProcId with STACC_PROC_ID0 for SS_MULTIPLE_PROCS Flag.
3.1+       st041.301   mkm 1. Removed stMakeLtoUSapAssoc for correct handling of StLiSptStaInd.
3.1+       st042.301   mkm 1. Removed RT Update for Debug Enable/Disable since Debug Control Req 
                              are sent to each copy of TCAP on which it has to be enabled/disabled.
3.1+       st043.301  mkm   1. Changes for addition of suDlgId parameter in stAllocDlg.
3.1+       st044.301  mkm   1. Changes for addition of condition for ANS96 when need to create dialogue.
*********************************************************************91*/
