/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/
/********************************************************************20**
  
     Name:     TCAP - body 4
  
     Type:     C Source file
  
     Desc:     C source code for support functions used by TCAP software 
               supplied by TRILLIUM.
  
     File:     ct_bdy4.c
  
     Sid:      ct_bdy4.c@@/main/3 - Fri Nov 17 10:34:37 2000

     Prg:      nj
  
*********************************************************************21*/

/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif
#ifdef CCITT96
               CCITT 96
#endif

************************************************************************/
 
/* header include files (.h) */
#include "envopt.h"        /* Environment options */
#include "envdep.h"        /* Environment dependent */
#include "envind.h"        /* Environment independent */
#include "gen.h"           /* General layer */
#include "ssi.h"           /* System services */
#include "cm5.h"           /* Common timer */
#include "cm_ss7.h"
#include "cm_hash.h"       /* Common hashing */
#include "cm_asn.h"        /* Common asn.1 */
#include "cm_err.h"        /* Common error */
#include "stu.h"           /* Tcap services */
#include "spt.h"           /* Sccp layer */
#include "lst.h"           /* Layer management, TCAP */
#include "st.h"            /* Tcap */
#include "st_mf.h"         /* Tcap */
#include "st_db.h"         /* Tcap ASN.1 tag defines */
#include "st_err.h"        /* Tcap error */

#ifdef ST_FTHA
#include "sht.h"           /* SHT */
#include "mrs.h"           /* MRS */
#endif /* ST_FTHA */

#ifdef ZT
#include "cm_ftha.h"
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#ifdef ZT_DFTHA
#include "cmztdt.h"
#include "cmztdtlb.h"
#endif /* ZT_DFTHA */
#include "zt.h"            /* Tcap PSF defines */
#include "lzt.h"
#endif /* ZT */

/* header/extern include files (.x) */
  
#include "gen.x"           /* General layer */
#include "ssi.x"           /* System services */
#include "cm5.x"           /* Common timer */
#include "cm_ss7.x"        /* Common */
#include "cm_hash.x"       /* Common hashing */
#include "cm_asn.x"        /* Common asn.1 */
#include "cm_lib.x"        /* Common */
#include "stu.x"           /* Tcap layer */
#include "spt.x"           /* Sccp layer */
#include "lst.x"           /* Layer management, TCAP */
#include "st_mf.x"         /* Tcap */

#ifdef ZT
#include "cm_ftha.x"
#include "cm_pftha.x"      /* Common PSF typedefs */
#include "cm_psfft.x"
#endif /* ZT */

#ifdef ST_FTHA
#include "sht.x"           /* SHT */
/* st005.301 - Deleted - mrs.x deleted here */
#endif /* ST_FTHA */

#include "st.x"            /* Tcap */
 
#ifdef ZT
#ifdef ZT_DFTHA
#include "cmztdt.x"
#include "cmztdtlb.x"
#endif /* ZT_DFTHA */
/* st005.301 - Added - mrs.x included under ZT */
#include "mrs.x"           /* MRS */
#include "lzt.x"
#include "zt.x"            /* Tcap PSF typedefs */
#endif /* ZT */



/* local defines */

/* local externs */
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifndef SS_MULTIPLE_PROCS
EXTERN  StCb   stCb;       /* TCAP layer control block */
#ifdef ZT
EXTERN  ZtCb   ztCb;       /* PSF control block */
#endif /* ZT */
/* st014.301 -Add- stDataParam structure containing isni and ril */
EXTERN StDataParam stDataParam;
#endif /* SS_MULTIPLE_PROCS */

/* forward references */

/* st007.301 - Added TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
PRIVATE S16 stDecItuMsgHdr       ARGS ((Buffer   *mBuf,
                                        MsgLen   offset,
                                        U8       pduType,
                                        U8       msgDirection,
                                        StDlgId  *peerDlgId, 
                                        StDlgId  *myDlgId));
/* st038.301 - Addition - Putting stDecAnsiMsgHdr under ANSI flags */

#endif /* ST_TC_USER_DIST */

/* functions in other modules */
  
/* public variable declarations */

/* private variable declarations */


/*
 *     support functions
 */


/*
*
*       Fun:   stTmrEvnt
*
*       Desc:  process the timer expiry event
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void stTmrEvnt
(
PTR       cb,        /* control block */
S16       event      /* timer event, identify the timer which has expired */
)
#else
PUBLIC Void stTmrEvnt(cb, event)
PTR       cb;        /* control block */
S16       event;     /* timer event, identify the timer which has expired*/
#endif
{
#ifdef SPT2
   StSPSap        *spSapCp;    /* Lower SAP                  */
#endif /* SPT2 */
#ifdef ZT
#ifdef ZT_DFTHA
   StInvCp        *invCp;      /* pointer to invoke Cb       */
   StDlgId        dlgId;       /* dialogue Id                */
   CmFthaRsetId   rsetId;      /* resource set Id            */
#endif /* ZT_DFTHA */
   ZtRsetCb       *rsetCb;     /* pointer to resource set Cb */
#endif /* ZT */

   TRC2(stTmrEvnt)
 
#if (ERRCLASS & ERRCLS_DEBUG)
   if (cb == NULLP)
   {
      STLOGERROR(ERRCLS_DEBUG, EST260, (ErrVal)event,
                 "stTmrEvnt: Timer expired for non-existant control block");
      RETVOID;
   }
#endif

#ifdef ZT
   /* st015.301 -Add- Initialize rsetCb */
   rsetCb = NULLP;
   
   /* checking if resource set is ACTIVE */
   switch(event)
   {
      case ST_INV_TMR:
      case ST_REJ_TMR:
      
#ifdef ZT_DFTHA
         if(ZT_IS_DIST_FTHA)
         {
            /* get resource set from the invoke control block */
            invCp  = (StInvCp *)cb;
            dlgId  = invCp->dlgCp->spDlgId;
            rsetId = (CmFthaRsetId)((dlgId >> 24) & 0xff);
            rsetCb = ztCb.rsetCbLst[rsetId];
         }
         else 
#endif /* ZT_DFTHA */
         {
            rsetCb = ztCb.rsetCbLst[CMFTHA_RES_RSETID];         
         }
         break;
         
      case ST_BND_ACK_TMR:
      
#ifdef ZT_DFTHA
         if(ZT_IS_DIST_FTHA)
         {
            /* get critical resource set Id */
            rsetId = ztCb.critRsetId;
            rsetCb = ztCb.rsetCbLst[rsetId];
         }
         else 
#endif /* ZT_DFTHA */ 
         {
            rsetCb = ztCb.rsetCbLst[CMFTHA_RES_RSETID];
         }
         break;            
   }

   /* st015.301 -Add- Check if rsetCb is NULL */
   if (rsetCb == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, ESTXXX, (ErrVal)0, 
                 "stTmrEvnt: Resource set block null");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

      RETVOID;
   }
   if (rsetCb->state != CMPFTHA_STATE_ACTIVE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST261, (ErrVal)0, 
                 "stTmrEvnt: Rx'd on sby/oos Tcap");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

      stSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_INV_TMR_EVT,
                  LCM_CAUSE_PROT_NOT_ACTIVE, NOTUSED, NOTUSED);
      RETVOID;
   }
#endif /* ZT */

   switch(event)
   {
      case ST_INV_TMR:

#ifdef ZT_DFTHA 
         if(ZT_IS_DIST_FTHA)
         {
            if (ztQTmr(cb, event) == TRUE)
            {
               RETVOID;
            }
         }
#endif /* ZT_DFTHA */ 

         /* Execute the ISM */
         (Void)stItuIsmExec((StInvCp *)cb, E_INV_TMR, NULLP, NULLP);
         break;

      case ST_REJ_TMR:

#ifdef ZT_DFTHA 
         if(ZT_IS_DIST_FTHA)
         {
            if (ztQTmr(cb, event) == TRUE)
            {
               RETVOID;
            }
         }
#endif /* ZT_DFTHA */ 

         /* Execute the ISM */
         (Void)stItuIsmExec((StInvCp *)cb, E_REJ_TMR, NULLP, NULLP);
         break;

#ifdef SPT2
      case ST_BND_ACK_TMR:

         spSapCp = (StSPSap *)cb;

         /* If TCAP is waiting for bind confirm */
         if (spSapCp->hlSt == ST_SAP_WAIT_BNDCFM)
         {
            /* If retry count hasn't exceeded the max then reissue bind req */
            if (spSapCp->bndRetryCnt < ST_MAX_INTRETRY)
            {
               /* Increment the bind attempts counter */
               spSapCp->bndRetryCnt++;

               /* start a timer */
               stStartSapTmr(ST_BND_ACK_TMR, (PTR)spSapCp);

               /* Reissue bind to Service provider */
               (Void)StLiSptBndReq(&spSapCp->pstSP, spSapCp->suId,
                                    spSapCp->spId, spSapCp->ssn);
            }
            /* If retry count has exceeded the max then generate alarm
               to LM and return from here */
            else
            {
               spSapCp->bndRetryCnt = 0;
               spSapCp->hlSt        = ST_SAP_UNBND;
               stSendAlarm(LCM_CATEGORY_PROTOCOL, LCM_EVENT_BND_FAIL,
                           LCM_CAUSE_UNKNOWN, NOTUSED, NOTUSED);
               RETVOID;
            }
         }
         /* Bind timer should not be running in any other SAP state */
         else
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            STLOGERROR(ERRCLS_DEBUG, EST262, (ErrVal)spSapCp->hlSt,
                       "stTmrEvent:Invalid SAP state");
#endif /* ERRCLASS */
            RETVOID;
         }
         break;
#endif /* SPT2 */

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         STLOGERROR(ERRCLS_INT_PAR, EST263, (ErrVal)event,
                    "stTmrEvent: Invalid event");
#endif /* ERRCLASS */
         break;
   }

#ifdef ZT
   ztUpdPeer();
#endif /* ZT */

   RETVOID;
} /* stTmrEvnt */


/*
*
*       Fun:   stStartTmr
*
*       Desc:  start control block timer
*
*       Ret:   ROK     - Timer started
*              RFAILED - Didn't start the timer
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 stStartTmr
(
S16       timer,     /* timer number, identify which timer to start */
PTR       cp         /* Control point */
)
#else
PUBLIC S16 stStartTmr(timer, cp)
S16       timer;     /* timer number, identify which timer to start */
PTR       cp;        /* Control point */
#endif
{
   StInvCp  *invCp;  /* Invoke Control Point */
   U16       wait;   /* Time to wait for timer expiry */
   U8        tmrNum;

 
   TRC2(stStartTmr)
 
   invCp = (StInvCp *)cp;
   /* st027.301 - Add - Addition of code below to avoid more than one 
    * timers running simultaneously */
   /* Before going further check if the given timer is already started
    * on this control block */
   for (tmrNum = 0; tmrNum < ST_MAX_TMR ; tmrNum++)
   {
      if (invCp->timers[tmrNum].tmrEvnt == timer)
      {
        /* Log the debug and get outta here */
#if (ERRCLASS & ERRCLS_INT_PAR)
        STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf, 
               "stStartTmr: Can not start more than one same timers on the \
                same invoke control block with \n spDlgId(%ld) and timerVal(%d)\n", 
                invCp->dlgCp->spDlgId, timer));
#endif
        RETVALUE(RFAILED);
       }
    }

   wait = 0;
   switch (timer)
   {
      case ST_INV_TMR:
         if ((wait = invCp->invTmr) == 0)
         {
            if (invCp->dlgCp->sapCp->cfg.t1.enb)
            {
                wait = invCp->dlgCp->sapCp->cfg.t1.val;
            }
         }
         break;

      case ST_REJ_TMR:
         if (invCp->dlgCp->sapCp->cfg.t2.enb)
         {
            wait = invCp->dlgCp->sapCp->cfg.t2.val;
         }
         break;
   }

   /* wait time should be non-zero */

   if (wait != 0)
   {
      CmTmrArg tmrArg;
 
      tmrArg.tqCp   = &(stCb.tqCp);  /* Timing Queue control point */
      tmrArg.tq     = stCb.tq;       /* Timing Queue */
      tmrArg.max    = ST_MAX_TMR;    /* Maximum number of simultaneous timers */
      tmrArg.timers = invCp->timers; /* Timer control blocks */
 
      tmrArg.cb     = (PTR)invCp;    /* Control block to return in case of timer expiry */
      tmrArg.evnt   = (U8)timer;     /* Timer event for this timer */
      tmrArg.wait   = wait;          /* timer duration */
      tmrArg.tNum   = 0;
 
      cmPlcCbTq(&tmrArg);            /* Place the timer on the timing queue */

      RETVALUE(ROK);
   }

   RETVALUE(RFAILED);
} /* stStartTmr */


/*
*
*       Fun:   stStartSapTmr
*
*       Desc:  start sap control block timer
*
*       Ret:   ROK     - Timer started
*              RFAILED - Didn't start the timer
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 stStartSapTmr
(
S16       timer,     /* timer number, identify which timer to start */
PTR       cp         /* Control point */
)
#else
PUBLIC S16 stStartSapTmr(timer, cp)
S16       timer;     /* timer number, identify which timer to start */
PTR       cp;        /* Control point */
#endif
{
   StSPSap  *sapCp;  /* Lower TCAP Sap */
   U16       wait;   /* Time to wait for timer expiry */
 
   TRC2(stStartSapTmr)
 
   sapCp = (StSPSap *)cp;

   wait = 0;
   switch (timer)
   {
#ifdef SPT2
      case ST_BND_ACK_TMR:
         if (sapCp->cfg.tIntTmr.enb)
         {
            wait = sapCp->cfg.tIntTmr.val;
         }
         break;
#endif
   }

   /* wait time should be non-zero */

   if (wait != 0)
   {
      CmTmrArg tmrArg;
 
      tmrArg.tqCp   = &(stCb.sapTqCp); /* Timing Queue control point */
      tmrArg.tq     = stCb.sapTq;      /* Timing Queue */
      tmrArg.max    = ST_MAX_SAP_TMR;  /* Maximum number of simultaneous timers */
      tmrArg.timers = sapCp->timers;   /* Timer control blocks */
 
      tmrArg.cb     = (PTR)sapCp;  /* Control block to return in case of timer expiry */
      tmrArg.evnt   = (U8)timer;   /* Timer event for this timer */
      tmrArg.wait   = wait;        /* timer duration */
      tmrArg.tNum   = 0;
 
      cmPlcCbTq(&tmrArg);          /* Place the timer on the timing queue */

      RETVALUE(ROK);
   }

   RETVALUE(RFAILED);
} /* stStartSapTmr */


/*
*
*       Fun:   stStopTmr
*
*       Desc:  stop control block timer
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void stStopTmr
(
S16       timer,     /* timer number, identify which timer to stop */
StInvCp  *invCp      /* Control Point */
)
#else
PUBLIC Void stStopTmr(timer, invCp)
S16       timer;     /* timer number, identify which timer to stop */
StInvCp  *invCp;     /* Control Point */
#endif
{
   U8       tmrNum;
   CmTmrArg tmrArg;
 
   TRC2(stStopTmr)
 
   /* search in the timer queue of the cb for this timer event */
 
   for (tmrNum = 0; tmrNum < (U8)ST_MAX_TMR; tmrNum++)
   {
      if (invCp->timers[tmrNum].tmrEvnt == timer)
      {
         tmrArg.tqCp   = &(stCb.tqCp);
         tmrArg.tq     = stCb.tq;
         tmrArg.timers = invCp->timers;
         tmrArg.max    = ST_MAX_TMR;

         tmrArg.cb     = (PTR)invCp;
         tmrArg.evnt   = timer;
         tmrArg.wait   = 0;
         tmrArg.tNum   = tmrNum;

         cmRmvCbTq(&tmrArg);
      }
   }

   RETVOID;
} /* stStopTmr */


/*
*
*       Fun:   stStopSapTmr
*
*       Desc:  stop sap control block timer
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void stStopSapTmr
(
S16       timer,     /* timer number, identify which timer to stop */
PTR       cb         /* Control block */
)
#else
PUBLIC Void stStopSapTmr(timer, cb)
S16       timer;     /* timer number, identify which timer to stop */
PTR       cb;        /* Control block */
#endif
{
   U8       tmrNum;
   CmTmrArg tmrArg;
 
   TRC2(stStopSapTmr)
 
   /* search in the timer queue of the cb for this timer event */
 
   for (tmrNum = 0; tmrNum < (U8)ST_MAX_SAP_TMR; tmrNum++)
   {
      if (((StSPSap *)cb)->timers[tmrNum].tmrEvnt == timer)
      {
         tmrArg.tqCp   = &(stCb.sapTqCp);
         tmrArg.tq     = stCb.sapTq;
         tmrArg.timers = ((StSPSap *)cb)->timers;
         tmrArg.max    = ST_MAX_SAP_TMR;

         tmrArg.cb     = cb;
         tmrArg.evnt   = timer;
         tmrArg.wait   = 0;
         tmrArg.tNum   = tmrNum;

         cmRmvCbTq(&tmrArg);
      }
   }

   RETVOID;
} /* stStopSapTmr */


/*
*
*       Fun:   stAlloc
*
*       Desc:  This function returns a pointer to a block of at least
*              <size> bytes suitably aligned for any use.
*
*       Ret:   pointer to memory, when successfully allocated
*              NULLP, otherwise
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Data *stAlloc
(
Size  size                    /* size */
)
#else
PUBLIC Data *stAlloc(size)
Size  size;                   /* size */
#endif
{
   Data *pData;               /* pointer to data allocated by system */

   TRC2(stAlloc)
 
   /* allocate list of pointers */
   if (SGetSBuf(stCb.init.region, stCb.init.pool, &pData, size) != ROK)
   {
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stAlloc:SGetSBuf failedi\n"));
      RETVALUE(NULLP);
   }
   else
   {
      cmZero(pData, size);

      /* increment the memory allocation counter */
      stCb.allocMem += size;

      RETVALUE(pData);
   }
} /* end of stAlloc */


/*
*
*       Fun:   stFree
*
*       Desc:  The argument to stFree() is a pointer to a block
*              previously allocated by stAlloc().  After stFree()
*              is performed this space is made available for further
*              allocation.  If ptr is a NULL pointer, no action occurs.
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void stFree
(
Data  *data,         /* pointer to data */
Size   size          /* size */
)
#else
PUBLIC Void stFree(data, size)
Data  *data;         /* pointer to data */
Size   size;         /* size */
#endif
{
   TRC2(stFree)
 
   (Void) SPutSBuf(stCb.init.region,
                   stCb.init.pool,
                   data,
                   size);
 
#if (ERRCLASS & ERRCLS_DEBUG)
   if (stCb.allocMem < size)
   {
      STLOGERROR(ERRCLS_DEBUG, EST264, (ErrVal)size,
                 "stFree(): free memsize more than allocated memsize");
      RETVOID;
   }
#endif
   /* decrement the memory alloc'd counter */
   stCb.allocMem -= size;

   RETVOID;
} /* end of stFree */
 

/*
*
*       Fun:   stShutDown
*
*       Desc:  This function takes care of shutting down TCAP. This function
*              release all the resources occupied by TCAP and leaves it 
*              in a state when TCAP task was created with no configuration.
*              While cleaning up it does not generate any indication to any
*              of the upper/lower layers.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 stShutDown
(
Void
)
#else
PUBLIC S16 stShutDown(Void)
#endif
{
   StTUSap   *tuSapCp;        /* TCAP upper sap */
   StSPSap   *spSapCp;        /* TCAP lower sap */
   Size       sapLstSize;     /* Size of list of pointers to SAP */
   Size       smSize;         /* State table size */
   U16        idx;
   
   TRC2(stShutDown)

   /* If general configuration not already done, reject the request */
   if (!stCb.init.cfgDone)
   {
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stShutDown:Layer is not yet configured,so cannot shut down\n"));
      RETVALUE(RFAILED);
   }

   /* Deregister the timer activation functions */
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
/* st037.301 - removal of warnings. */
#ifdef SS_MULTIPLE_PROCS
   (Void)SDeregTmr(stCb.init.procId,stCb.init.ent, stCb.init.inst, stCb.genCfg.timeRes,
                   (PAIFTMRS16)stActvTmr);

   (Void)SDeregTmr(stCb.init.procId,stCb.init.ent, stCb.init.inst, stCb.genCfg.sapTimeRes,
                   (PAIFTMRS16)stActvSapTmr);
#else
   (Void)SDeregTmr(stCb.init.ent, stCb.init.inst, stCb.genCfg.timeRes,
                   (PFS16)stActvTmr);

   (Void)SDeregTmr(stCb.init.ent, stCb.init.inst, stCb.genCfg.sapTimeRes,
                   (PFS16)stActvSapTmr);
#endif

/* st005.301 - Added - Rolling Upgrade feature */
#ifdef ST_RUG
   /* Free up memory for interface version info in stCb */
   if (stCb.intfInfo != NULLP)
      /* Total number of upper and lower Saps are 
       * 2 * (stCb.genCfg.nmbSaps) */ 
      stFree((Data *)stCb.intfInfo,2 * (stCb.genCfg.nmbSaps)
                                      * sizeof(ShtVerInfo) );
      stCb.numIntfInfo = 0;
#endif /* ST_RUG */

   /* Deallocate all upper and lower Saps */
   for (idx = 0; idx < stCb.genCfg.nmbSaps; idx++)
   {
      if ((tuSapCp = *(stCb.tuSapLst + idx)) != NULLP)
      {
         (Void)stFreeTUSap(idx);
      }
      if ((spSapCp = *(stCb.spSapLst + idx)) != NULLP)
      {
         (Void)stFreeSPSap(idx);
      }
   }

   /* Compute the size of the SAP list, same for both upper and lower
      Saps */
   sapLstSize = stCb.genCfg.nmbSaps * sizeof(StTUSap *);

   /* Deallocate Upper SAP list */
   stFree((Data *)stCb.tuSapLst, sapLstSize);

   /* Deallocate Lower SAP list */
   stFree((Data *)stCb.spSapLst, sapLstSize);

   /* Deallocate Protocol state tables */

   /* Deallocate Itu TSM */
   smSize = ST_MAX_ITU_TSM_SIZE * sizeof(SMTblEnt);
   stFree((Data *)stCb.smTbls.ituTsm.tbl, smSize);

   /* Deallocate Itu ISM */
   smSize = ST_MAX_ITU_ISM_SIZE * sizeof(SMTblEnt);
   stFree((Data *)stCb.smTbls.ituIsm.tbl, smSize);




   /* Release the static memory */
   if (SPutSMem(stCb.init.region, stCb.init.pool) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST265, (ErrVal)0,
                 "stShutDown:SPutSMem failed");
#endif
      RETVALUE(RFAILED);
   }

#if (ERRCLASS & ERRCLS_DEBUG)
   if (stCb.allocMem != 0)
   {
      STLOGERROR(ERRCLS_DEBUG, EST266, (ErrVal)stCb.allocMem,
                 "stShutDown:Memory Leakage");
   }
#endif

   /* Zero the memory counters */
   stCb.memSize  = 0;
   stCb.allocMem = 0;

   /* Initialize timing queue control point for layer */
   stCb.tqCp.nxtEnt = 0;
   stCb.tqCp.tmrLen = STTQNUMENT;
   stCb.sapTqCp.nxtEnt = 0;
   stCb.sapTqCp.tmrLen = STTQNUMENT;

   /* Initialize timing queue table: array of STTQNUMENT pointers */
   for(idx=0; idx < STTQNUMENT; idx++)
   {
      stCb.tq[idx].first = (CmTimer *)NULLP;
      stCb.tq[idx].tail = (CmTimer *)NULLP;
      stCb.sapTq[idx].first = (CmTimer *)NULLP;
      stCb.sapTq[idx].tail = (CmTimer *)NULLP;
   }

   /* Initialize the General configuration structure */
   cmZero((Data *)&stCb.genCfg, sizeof(StGenCfg));

   stCb.init.cfgDone = FALSE;

/* Reninitialize everything */
/* st043.301 - addition - Adding stActvInit in stShutDown to re-initialize the instance with proper reason */
#ifdef SS_MULTIPLE_PROCS
   /* Putting  xxCb as NULLP, since its unused in stActvInit function */ 
   stActvInit (stCb.init.procId, stCb.init.ent, stCb.init.inst,
               stCb.init.region, SHUTDOWN, NULLP);
#else
   stActvInit (stCb.init.ent, stCb.init.inst,
               stCb.init.region, stCb.init.reason);
#endif /* SS_MULTIPLE_PROCS */

   RETVALUE(ROK);
} /* End of stShutDown */


/*
*
*       Fun:   stGenTrc
*
*       Desc:  Send a trace indication to the Layer Manager
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void stGenTrc
(
SuId      suId,      /* Lower SAP Id */
U16       evnt,      /* event */
Buffer   *mBuf       /* buffer for tracing */
)
#else
PUBLIC  Void stGenTrc(suId, evnt, mBuf)
SuId      suId;      /* Lower SAP Id */
U16       evnt;      /* event */
Buffer   *mBuf;      /* buffer for tracing */
#endif
{
   StMngmt    trc;                      
   MsgLen     msgLen;
   U16        i;
  
   TRC2(stGenTrc)
/* st005.301 - Added- Rolling Upgrade feature */
#ifdef ST_RUG
   /* If general configuration not done the lmPst is *
    * not valid and we cant generate any traces      */
  
   if (stCb.init.cfgDone == FALSE)
   {
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
         "General configuration not done, no trace will be generated\n"));
      RETVOID;
   }
#endif /* ST_RUG */

   trc.hdr.msgLen     = 0;               /* optional - message length */
   trc.hdr.version    = 0;               /* optional - version */
   trc.hdr.seqNmb     = 0;               /* optional - sequence number */
   trc.hdr.msgType    = TTRC;            /* message type */
   trc.hdr.entId.ent  = stCb.init.ent;   /* entity id */
   trc.hdr.entId.inst = stCb.init.inst;  /* instance id */
 
   /* SAP where event occured */
   trc.hdr.elmId.elmnt      = STSPSAP;   /* Lower SAP */
   trc.hdr.elmId.elmntInst1 = suId;      /* SAP number */
   trc.hdr.elmId.elmntInst2 = 0;         /* optional - element instance */
   trc.hdr.elmId.elmntInst3 = 0;         /* optional - element instance */
 
   /* event */
   trc.t.trc.evnt = evnt;                /* event to be traced */

   for (i = 0; i < LST_MAX_TRC_LEN; i++) /* event parameters */
   {
       trc.t.trc.evntParm[i] = 0;
   }
 
   /* find length of message buffer */
   (Void)SFndLenMsg(mBuf, &msgLen);
 
   /* trace upto LST_MAX_TRC_LEN bytes of message buffer */
   if (msgLen > LST_MAX_TRC_LEN)
   {
      msgLen = LST_MAX_TRC_LEN;
   }
 
   for (i = 0; i < (U16)msgLen; i++)
   {
       (Void)SExamMsg(&trc.t.trc.evntParm[i], mBuf, i);
   }

   /* store length of trace */
   trc.t.trc.len = msgLen;
 
   /* initialize date and time in trace structure */
   SGetDateTime(&trc.t.trc.dt);
 
   /* call management trace indication primitive */
   StMiLstTrcInd(&stCb.init.lmPst, &trc);
 
   RETVOID;
} /* stGenTrc */
 

/*
*
*       Fun:   stSendAlarm
*
*       Desc:  Send alarm to the layer manager
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void stSendAlarm
(
U16   category,           /* category */
U16   event,              /* event generated */
U16   cause,              /* cause */
U8    par1,               /* parameter 1 */
U8    par2                /* parameter 2 */
)
#else
PUBLIC  Void stSendAlarm(category, event, cause, par1, par2)
U16   category;           /* category */
U16   event;              /* event generated */
U16   cause;              /* cause */
U8    par1;               /* parameter 1 */
U8    par2;               /* parameter 2 */
#endif
{
   StMngmt  usta;   /* Management structure */
 
   TRC2(stSendAlarm)

   if (stCb.init.usta == FALSE)
   {
      RETVOID;
   }

/* st005.301 - Added- Rolling Upgrade feature */
#ifdef ST_RUG
   /* If general configuration not done the lmPst is *
   * not valid and we cant generate any alarms       */
  
   if ( stCb.init.cfgDone == FALSE)
   {
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
         "General configuration not done, no alarms can be generated\n"));
      RETVOID;
   }       

#endif /* ST_RUG */
 
   usta.hdr.msgType          = TUSTA;
   usta.hdr.entId.ent        = stCb.init.ent;
   usta.hdr.entId.inst       = stCb.init.inst;
 
#ifdef ST_LMINT3
   (Void) SGetDateTime(&usta.t.usta.alarm.dt);
   usta.t.usta.alarm.category = category;
   usta.t.usta.alarm.event    = event;
   usta.t.usta.alarm.cause    = cause;
   usta.t.usta.evntParm1      = par1;
   usta.t.usta.evntParm2      = par2;
#else
   (Void)SGetDateTime(&usta.t.usta.dt);
   usta.hdr.elmId.elmntInst1 = par1;
   usta.hdr.elmId.elmntInst2 = par2;
   usta.t.usta.evnt          = event;
   usta.t.usta.diag.pres     = TRUE;
   usta.t.usta.diag.len      = 2;
   usta.t.usta.diag.val[0]   = GetHiByte(cause);
   usta.t.usta.diag.val[1]   = GetLoByte(cause);
#endif /* ST_LMINT3 */

	/* xingzhou.xu: added for controlling the indication to sm 
	 *                                        --2006/08/25
	 */
#ifdef DEBUGP
	if (0 != stCb.init.dbgMask & ST_DBGMASK_SM) 
	{
		(Void)StMiLstStaInd(&(stCb.init.lmPst), &usta);
	}
#endif /* DEBUGP */
   RETVOID;
} /* end of stSendAlarm */


/*
 *
 *      Fun:   stSendLmCfm
 *
 *      Desc:  This function sends control and configuration confirms to
 *             layer management
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
        File:  ct_bdy4.c
 *
 */

#ifdef ANSI
PUBLIC S16 stSendLmCfm
(
Pst    *pst,                    /* post */
U8      cfmType,                /* confirm type */
Header *hdr,                    /* header */
U16     status,                 /* confirm status */
U16     reason                  /* failure reason */
)
#else
PUBLIC S16 stSendLmCfm(pst, cfmType, hdr, status, reason)
Pst    *pst;                    /* post */
U8      cfmType;                /* confirm type */
Header *hdr;                    /* header */
U16     status;                 /* confirm status */
U16     reason;                 /* failure reason */
#endif
{
#ifdef ST_LMINT3
   StMngmt   cfm;      /* management structure */
   Pst       rPst;     /* reply post */
#else
   U16       event;    /* alarm event */
#endif /* ST_LMINT3 */

   TRC2(stSendLmCfm)

#ifdef ST_LMINT3

   cmZero((Data *)&cfm, sizeof(StMngmt));
   cfm.hdr.msgType    = cfmType;
   cfm.hdr.entId.ent  = stCb.init.ent;
   cfm.hdr.entId.inst = stCb.init.inst;
   cfm.hdr.transId    = hdr->transId;
   cfm.cfm.status     = status;
   cfm.cfm.reason     = reason;

   /* prepare reply post structure */
   stBldReplyPst(&rPst, hdr, pst);


   switch(cfmType)
   {
      case TCFG:
         /* send configuration confirm */
         (Void)StMiLstCfgCfm(&rPst, &cfm);
         break;

      case TCNTRL:
         /* send control confirm */
         (Void)StMiLstCntrlCfm(&rPst, &cfm);
         break;

      case TSSTA:
        /* send solicited status confirm */
         (Void)StMiLstStaCfm(&rPst, &cfm);
         break;

      case TSTS:
        /* send Statistics confirm */
         (Void)StMiLstStsCfm(&rPst, &cfm);
         break;

      default:
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stSendLmCfm:Unrecognized confirm type(%d)\n",cfmType));
         RETVALUE(RFAILED);
   }
#else

   event = 0;

    /* provide backward compatibility here */
   switch (cfmType)
   {
      case TCNTRL:
         break;

      case TCFG:
         if (status == LCM_PRIM_OK)
         {
            if (hdr->elmId.elmnt == STGEN)
            {
               event = LST_EVENT_GENCFG_OK;
            }
            else
            {
               event = LST_EVENT_SAPCFG_OK;
            }
         }
         else
         {
            if (hdr->elmId.elmnt == STGEN)
            {
               event = LST_EVENT_GENCFG_NOK;
            }
            else
            {
               event = LST_EVENT_SAPCFG_NOK;
            }
         }
         break;

      case TSSTA:
         break;

      case TSTS:
         break;

      default:
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stSendLmCfm:Unrecognized confirm type(%d)",cfmType));
         RETVALUE(RFAILED);
    } /* end switch */

    /* Send Alarm */
    if (event != 0)
    {
       stSendAlarm(LCM_CATEGORY_INTERFACE, event, LCM_CAUSE_UNKNOWN, NOTUSED,
                   NOTUSED);
    }
#endif 

   RETVALUE(ROK);
} /* end of stSendLmCfm */


/*
*
*       Fun:   stAllocTUSap
*
*       Desc:  Allocate and configure TCAP upper Sap
*
*       Ret:   ROK      - success
*              RFAILED  - failed
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16  stAllocTUSap
(
StTUSapCfg  *cfg,      /* Upper Sap Configuration structure */
SpId         spId,     /* Sap Id */
/* st015.301-Modified- reason parameter's datatype modified from U16 */
Reason      *reason    /* Return Failure reason */
)
#else
PUBLIC  S16 stAllocTUSap(cfg, spId, reason)
StTUSapCfg  *cfg;      /* Upper Sap Configuration structure */
SpId         spId;     /* Sap Id */
/* st015.301-Modified- reason parameter's datatype modified from U16 */
Reason      *reason;   /* Return Failure reason */
#endif
{
   StTUSap  *tuSapCp;      /* Pointer to upper Sap */
   S16       ret;          /* return value */
   U16       bits;         /* # of bits required in bitmap */

   TRC2(stAllocTUSap)

   /* allocate memory for the upper sap */
   tuSapCp = (StTUSap *) stAlloc(sizeof(StTUSap));

   if (tuSapCp == NULLP)
   {
      *reason = LCM_REASON_MEM_NOAVAIL;

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST267, (ErrVal)0,
                 "stAllocTUSap(): Memory allocation failed");
#endif
      RETVALUE(RFAILED);
   }
   else /* xingzhou.xu: added for init the contrl block --2006/08/18 */
   {
   		cmZero((Data *)tuSapCp, sizeof(StTUSap));
   }

   /* initialize new sap */
   tuSapCp->spId = spId;           /* Id of this SAP */

   /* suId will be sent later in Bind Request from the service user */
   tuSapCp->suId = 0;              /* Service User's Id */

   /* copy Upper Sap configuration parameters */
   cmCopy( (U8 *)cfg,
           (U8 *)&tuSapCp->cfg,
           sizeof(StTUSapCfg) );

   /* clear statistics counter */
   cmZero((Data *)&tuSapCp->sts, sizeof(StSapSts));

   /* update the date and time */
   (Void)SGetDateTime(&tuSapCp->sts.dt);
   (Void)SGetSysTime(&tuSapCp->sts.ticks);

   {
      /* Initialize the dialogue Id pool for this Sap */
      tuSapCp->dlgIdPool = 1;  /* first available dialogue id */

      /* if loDlgId and hiDlgId has been configured, use that */
      if ((cfg->loDlgId > 0) && (cfg->hiDlgId > 0))
      {
         tuSapCp->dlgIdPool = cfg->loDlgId;    /* start dialogue id */

         /* If a bitMap is to be kept for the dialogue ids */
         if (stCb.genCfg.bitMapFlg)
         {
            /* Compute the size of the bitmap */
            if (tuSapCp->cfg.hiDlgId > tuSapCp->cfg.loDlgId)
            {
               bits = tuSapCp->cfg.hiDlgId - tuSapCp->cfg.loDlgId;
            }
            else
            {
               /* st020.301 - Addition, free memory assigned to tuSapCp */
               stFree((Data *)tuSapCp, sizeof(StTUSap));
               *reason = LST_REASON_INVALID_DLGRANGE;
               /* st009.301 -Add- Debug prints */
               STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                 "stAllocTUSap:Invalid dialogue range in SAP(%d) cfg req \
                 low dialogue(%ld) high dialogue(%ld)\n",
                 spId,tuSapCp->cfg.loDlgId,tuSapCp->cfg.hiDlgId));
               RETVALUE(RFAILED);
            }

            /* Compute the number of octets required for bitmap */
            tuSapCp->bitMap.size = (bits / 8) + 1;

            /* Allocate memory to bitmap */
            tuSapCp->bitMap.map = (U8 *)stAlloc(tuSapCp->bitMap.size);

            if (tuSapCp->bitMap.map == NULLP)
            {
               tuSapCp->bitMap.size = 0;
               /* st020.301 - Addition, free memory assigned to tuSapCp */
               stFree((Data *)tuSapCp, sizeof(StTUSap));
               *reason = LCM_REASON_MEM_NOAVAIL;
               /* st009.301 -Add- Debug prints */
               STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                 "stAllocTUSap:Memory not available for SAP(%d)bit map alloc.",
                 spId));
               RETVALUE(RFAILED);
            }
         }
      }
   }

 /* st005.301 - Added- Rolling Upgrade feature */
#ifdef ST_RUG

   /* Initialize remote intreface version to be unknown */
   tuSapCp->remIntfValid = FALSE;
#endif /* ST_RUG */

   tuSapCp->binPool = cfg->nmbBins;    /* init the number of hash bins */

/* st043.301 - Modification - Replace ST_NMB_BIN_DLG with dlgHshSize */
#ifdef LSTV3            
   if (tuSapCp->binPool < cfg->dlgHshSize)
#else
   if (tuSapCp->binPool < ST_NMB_BIN_DLG)
#endif /* LSTV3 */
   {
      /* st020.301 - Addition, free memory assigned to tuSapCp and bit map */
      if (tuSapCp->bitMap.map != NULLP)
      {
         stFree((Data *)tuSapCp->bitMap.map, sizeof(tuSapCp->bitMap.size));
      }
      stFree((Data *)tuSapCp, sizeof(StTUSap));
      *reason = LCM_REASON_INVALID_PAR_VAL;

      /* insuffecient number of bins */
#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST268, (ErrVal) tuSapCp->binPool,
                  "stAllocTUSap(): Insuffecient bins");
#endif
      RETVALUE(RFAILED);
   }

   /* Initialize the hash list of dialogues */
   ret = cmHashListInit(&tuSapCp->dlgHlCp,  /* HL control point */
/* st043.301 - Modification - Replace ST_NMB_BIN_DLG with dlgHshSize */
#ifdef LSTV3            
                        cfg->dlgHshSize,     /* HL bins for a dialogue */
#else
                        ST_NMB_BIN_DLG,     /* HL bins for a dialogue */
#endif /* LSTV3 */
                        0,                  /* Offset of HL Entry */
                        FALSE,              /* Allow dup. keys ? */
                        0,                  /* HL key type */
                        stCb.init.region,   /* Mem region for HL */
                        stCb.init.pool);    /* Mem pool for HL */
 
   if (ret != ROK)
   {
      /* st020.301 - Addition, free memory assigned to tuSapCp and bit map */
      if (tuSapCp->bitMap.map != NULLP)
      {
         stFree((Data *)tuSapCp->bitMap.map, sizeof(tuSapCp->bitMap.size));
      }
      stFree((Data *)tuSapCp, sizeof(StTUSap));
      *reason = LCM_REASON_HASHING_FAILED;

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST269, (ErrVal) ret,
                  "stAllocTUSap(). Could not init HL of dlg");
#endif
      RETVALUE(ret);
   }

/* st043.301 - Addition - Initialize the new hash list of dialogues added for suDlgHlCp */  
   /* Initialize the hash list of dialogues */
   ret = cmHashListInit(&tuSapCp->suDlgHlCp,        /* HL control point */
#ifdef LSTV3            
                        cfg->dlgHshSize,            /* HL bins for a dialogue */
#else
                        ST_NMB_BIN_DLG,             /* HL bins for a dialogue */
#endif /* LSTV3 */
                        offsetOf(StDlgCp, suEnt),   /* Offset of HL Entry */
                        FALSE,                      /* Allow dup. keys ? */
                        0,                          /* HL key type */
                        stCb.init.region,           /* Mem region for HL */
                        stCb.init.pool);            /* Mem pool for HL */
   

   if (ret != ROK)
   {
      /* st020.301 - Addition, free memory assigned to tuSapCp and bit map */
      if (tuSapCp->bitMap.map != NULLP)
      {
         stFree((Data *)tuSapCp->bitMap.map, sizeof(tuSapCp->bitMap.size));
      }
      stFree((Data *)tuSapCp, sizeof(StTUSap));
      *reason = LCM_REASON_HASHING_FAILED;

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST269, (ErrVal) ret,
                  "stAllocTUSap(). Could not init HL of dlg");
#endif
      RETVALUE(ret);
   }

   /* decrement the number of bins avialable */
/* st043.301 - Modification - Replace ST_NMB_BIN_DLG with dlgHshSize */
#ifdef LSTV3             
   tuSapCp->binPool = (tuSapCp->binPool - cfg->dlgHshSize);
#else
   tuSapCp->binPool = (tuSapCp->binPool - ST_NMB_BIN_DLG);
#endif /* LSTV3 */
  
   /* update the TCAP user pst */
   tuSapCp->pstTU.selector  = cfg->tuSel;
   tuSapCp->pstTU.prior     = cfg->tuPrior;
   tuSapCp->pstTU.route     = cfg->tuRoute;
   tuSapCp->pstTU.region    = cfg->tuMemId.region;
   tuSapCp->pstTU.pool      = cfg->tuMemId.pool;
 
   /* dstProcId, dstEnt, and dstInst are assigned during bind request */
   tuSapCp->pstTU.dstProcId = PROCIDNC;
   tuSapCp->pstTU.dstEnt    = ENTNC;
   tuSapCp->pstTU.dstInst   = INSTNC;
   tuSapCp->pstTU.srcProcId = stCb.init.procId;
   tuSapCp->pstTU.srcEnt    = stCb.init.ent;
   tuSapCp->pstTU.srcInst   = stCb.init.inst;
   tuSapCp->pstTU.event     = EVTNONE;

   /* Initialize the resource counters */
   tuSapCp->allocDlg        = 0;  /* Total allocated dialogues */
   tuSapCp->allocInv        = 0;  /* Total allocated invokes */
   tuSapCp->usedDlg			= 0;  /* Total used dialogues */
   tuSapCp->usedInv			= 0;  /* Total used invokes */

   /* update the pointer to the TCAP sap in the table of saps */
   stCb.tuSapLst[spId] = tuSapCp;

   tuSapCp->hlSt = ST_SAP_CFGRD;  /* state is configured */

/* st007.301 -Added- TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
   /* Initialize lower SAP association field */
   tuSapCp->assocLSapId = ST_DEF_ASSOC_SAP_ID;
#endif /* ST_TC_USER_DIST */
   
   RETVALUE(ROK);
} /* stAllocTUSap */


/*
*
*       Fun:   stAllocSPSap
*
*       Desc:  Allocate and configure TCAP lower Sap
*
*       Ret:   ROK      - success
*              RFAILED  - failed
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16  stAllocSPSap
(
StSPSapCfg  *cfg,      /* Lower Sap Configuration structure */
SuId         suId,     /* Sap Id */
/* st015.301-Modified- reason parameter's datatype modified from U16 */
Reason      *reason    /* Return Failure reason */
)
#else
PUBLIC  S16 stAllocSPSap(cfg, suId, reason)
StSPSapCfg  *cfg;      /* Lower Sap Configuration structure */
SuId         suId;     /* Sap Id */
/* st015.301-Modified- reason parameter's datatype modified from U16 */
Reason      *reason;   /* Return Failure reason */
#endif
{
   StSPSap  *spSapCp;      /* Pointer to lower Sap */

   TRC2(stAllocSPSap)

   /* allocate memory for the lower sap */
   spSapCp = (StSPSap *) stAlloc(sizeof(StSPSap));

   if (spSapCp == NULLP)
   {
      *reason = LCM_REASON_MEM_NOAVAIL;

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST270, (ErrVal)0,
                 "stAllocSPSap(): Memory allocation failed");
#endif
      RETVALUE(RFAILED);
   }
   else /* xingzhou.xu: added for init the contrl block --2006/08/18 */
   {
   		cmZero((Data *)spSapCp, sizeof(StSPSap));
   }


   /* initialize new sap */
   spSapCp->suId = suId;          /* Id of this SAP */
   spSapCp->spId = cfg->spId;     /* service provider's (SCCP) Id */

   /* copy Lower Sap configuration parameters */
   cmCopy( (U8 *)cfg,
           (U8 *)&spSapCp->cfg,
           sizeof(StSPSapCfg) );

   /* update the SCCP pst */
   spSapCp->pstSP.selector  = cfg->spSel;
   spSapCp->pstSP.prior     = cfg->spPrior;
   spSapCp->pstSP.route     = cfg->spRoute;
   spSapCp->pstSP.region    = cfg->spMemId.region;
   spSapCp->pstSP.pool      = cfg->spMemId.pool;
 
   spSapCp->pstSP.dstProcId = cfg->spProcId;
   spSapCp->pstSP.dstEnt    = cfg->spEnt;
   spSapCp->pstSP.dstInst   = cfg->spInst;

   /* changes for Starent requirement */
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   spSapCp->pstSP.srcProcId =  stCb.init.procId;
#else
   spSapCp->pstSP.srcProcId =  SFndProcId();
#endif
   spSapCp->pstSP.srcEnt    = stCb.init.ent;
   spSapCp->pstSP.srcInst   = stCb.init.inst;

   spSapCp->pstSP.event     = EVTNONE;

   spSapCp->bndRetryCnt     = 0;

#ifdef ST_DIS_SAP
   spSapCp->contEnt = ENTSM;  /* SM is the controlling entity */
#else
   spSapCp->contEnt = ENTNC;  /* Unknown controlling entity */
#endif /* ST_DIS_SAP */

 /* st005.301 - Added- Rolling Upgrade feature */
#ifdef ST_RUG

   /* Initialize remote intreface version to be unknown */
   spSapCp->remIntfValid = FALSE;
#endif /* ST_RUG */

   /* update the pointer to the sap in the table of lower saps */
   stCb.spSapLst[suId]      = spSapCp;

   /* initialize the timers */
   (Void)cmInitTimers(spSapCp->timers, (U8)ST_MAX_SAP_TMR);

   /* make the state as configured */
   spSapCp->hlSt = ST_SAP_CFGRD;       /* state is configured */

/* st007.301 - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
   /* Initialize upper SAP association field */
   spSapCp->assocUSapId = ST_DEF_ASSOC_SAP_ID;
#endif /* ST_TC_USER_DIST */

   RETVALUE(ROK);
} /* stAllocSPSap */


/*
*
*       Fun:   stFreeTUSap 
*
*       Desc:  Remove a upper Sap and free all asociated memory
*
*       Ret:   ROK      - success
*              RFAILED  - failed
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 stFreeTUSap
(
SpId   spId
)
#else
PUBLIC  S16 stFreeTUSap(spId)
SpId   spId;
#endif
{
   StTUSap  *tuSapCp;        /* Pointer to the Upper Sap */

   TRC2(stFreeTUSap)

   /* get the pointer to the Upper Sap */
   tuSapCp = stCb.tuSapLst[spId];

   /* Free all the dialogues associated with this sap */ 
   (Void)stFreeAllDlg(&tuSapCp->dlgHlCp);

   /* de initialize the hash list of dialogues */
   cmHashListDeinit(&tuSapCp->dlgHlCp);
/* st043.301 - Addition - Deinitialize the new hash list */   
   cmHashListDeinit(&tuSapCp->suDlgHlCp);

#ifdef ZT_DFTHA
   if (!ZT_IS_DIST_FTHA)
#endif /* ZT_DFTHA */
   {
      /* Free memory if bitmap was allocated */
      if (stCb.genCfg.bitMapFlg)
      {
         stFree((Data *)tuSapCp->bitMap.map, tuSapCp->bitMap.size);
      }
   }

   /* Free the memory associated with this SAP */
   stFree((Data *)tuSapCp, sizeof(StTUSap));

   stCb.tuSapLst[spId] = NULLP;

   RETVALUE(ROK);
} /* stFreeTUSap */


/*
*
*       Fun:   stFreeSPSap 
*
*       Desc:  Remove a lower Sap and free all asociated memory
*
*       Ret:   ROK      - success
*              RFAILED  - failed
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 stFreeSPSap
(
SuId   suId
)
#else
PUBLIC  S16 stFreeSPSap(suId)
SuId   suId;
#endif
{
   StSPSap  *spSapCp;      /* Pointer to the Lower Sap */

   TRC2(stFreeSPSap)

   /* st007.301 - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST  
   /* Free up all the dialogues in upper SAP structure */         
   stFreeDlgUSapList(suId);
   /* Reset association field in upper SAP structure */
   stSetAssocLSapId(suId,TRUE);
#endif /* ST_TC_USER_DIST */ 
   
   /* get the pointer to the Sap */
   spSapCp = stCb.spSapLst[suId];

   /* Free the memory associated with this SAP */
   stFree((Data *)spSapCp, sizeof(StSPSap));

   stCb.spSapLst[suId] = NULLP;

   RETVALUE(ROK);
} /* stFreeSPSap */


/*
*
*
*       Fun:   stDisableTUSap
*
*       Desc:  This function unbinds and disables specified STTCUSAP.
*              It will cleanup all resources related to this SAP and
*              change the sap status
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  ct_bdy4.c
*
*/      
#ifdef ANSI
PUBLIC S16 stDisableTUSap
(
StTUSap       *tuSapCp     /* TCAP upper SAP */
)
#else
PUBLIC S16 stDisableTUSap(tuSapCp)
StTUSap       *tuSapCp;    /* TCAP upper SAP */
#endif
{
   TRC2(stDisableTUSap)

   if (tuSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      RETVALUE(ROK);
   }

   /* Free all the dialogues associated with this sap */ 
   (Void)stFreeAllDlg(&tuSapCp->dlgHlCp);

/* st005.301 - Added- Rolling Upgrade feature */
#ifdef ST_RUG
   if (tuSapCp->verContEnt == ENTNC)
   {  
      /* If the version controlling entity in the upper SAP is
       * Layer Manager, then do not mark the remote intreface 
       * version in the SAP as invalid */
      tuSapCp->remIntfValid = FALSE;
   }   
#endif /* ST_RUG */

   /* st007.301 - Added - TC-User Distribution Feature */   
#ifdef ST_TC_USER_DIST   
   /* Reset the association */
   tuSapCp->assocLSapId = ST_DEF_ASSOC_SAP_ID;
#endif /* ST_TC_USER_DIST */
   
   /* Change the sap status */
   tuSapCp->hlSt = ST_SAP_UNBND;

   RETVALUE(ROK);

} /* end of stDisableTUSap */


/*
*
*
*       Fun:   stDisableSPSap
*
*       Desc:  This function unbinds and disables specified STSPSAP.
*              It will cleanup all resources related to this SAP and
*              change the sap status
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  ct_bdy4.c
*
*/      
#ifdef ANSI
PUBLIC S16 stDisableSPSap
(
SuId      suId     /* Lower SAP service user id */
)
#else
PUBLIC S16 stDisableSPSap(suId)
SuId      suId;    /* Lower SAP service user id */
#endif
{
/* st007.301 - Modified - TC-User Distribution Feature */
/* Dont need to use upper SAP pointer */        
#ifndef ST_TC_USER_DIST        
   StTUSap    *tuSapCp;    /* TCAP Upper SAP */
#endif
   StSPSap    *spSapCp;    /* TCAP lower SAP */

   TRC2(stDisableSPSap)

   /* Get the lower Sap and check if it is already disbaled */
   spSapCp = stCb.spSapLst[suId];

   if (spSapCp->hlSt != ST_SAP_BND_ENBL)
   {
      RETVALUE(ROK);
   }

   /* st007.301 - Modified - TC-User Distribution Feature */
#ifndef ST_TC_USER_DIST
   /* If upper sap exists then terminate all the dialogues */
   if ((tuSapCp = stCb.tuSapLst[spSapCp->suId]) != NULLP)
   {
      /* Free all the dialogues associated with this sap */ 
      (Void)stFreeAllDlg(&tuSapCp->dlgHlCp);
   }
   /* st007.301 - Added - TC-User Distribution Feature */   
#else
   /* Free up all the dialogues in associated upper SAPs */
   stFreeDlgUSapList(suId);
#endif /* ST_TC_USER_DIST */   

   /* Change the sap status */
   spSapCp->hlSt = ST_SAP_UNBND;

   RETVALUE(ROK);
} /* end of stDisableSPSap */


/*
*
*
*       Fun:   stEnableSPSap
*
*       Desc:  This function enable and bind specified STSPSAP.
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  ct_bdy4.c
*
*/      
#ifdef ANSI
PUBLIC S16 stEnableSPSap
(
SuId      suId          /* Service user sap id */
)
#else
PUBLIC S16 stEnableSPSap(suId)
SuId      suId;         /* Service user sap id */
#endif
{
    StSPSap   *spSapCp; /* Lower SAP */

    TRC2(stEnableSPSap)

    /* Check the sap state, if already bound then return from here */
    spSapCp = stCb.spSapLst[suId];

    if (spSapCp->hlSt == ST_SAP_BND_ENBL)
    {
       RETVALUE(ROK);
    }

#ifdef SPT2
    if (spSapCp->hlSt == ST_SAP_WAIT_BNDCFM)
    {
       RETVALUE(ROK);
    }

    spSapCp->hlSt = ST_SAP_WAIT_BNDCFM;    /* wait for bind confirmation */

    /* start a timer */
    stStartSapTmr(ST_BND_ACK_TMR, (PTR)spSapCp);
#else
    spSapCp->hlSt = ST_SAP_BND_ENBL;
#endif /* SPT2 */

    /* bind Service provider */
    (Void)StLiSptBndReq(&spSapCp->pstSP, spSapCp->suId, spSapCp->spId,
                        spSapCp->ssn);
    RETVALUE(ROK);
} /* end of stEnableSPSap */


/*
*
*       Fun:   stAllocDlgId
*
*       Desc:  This function allocates a dialogue id for a dialogue
*
*       Ret:   ROK     -  when successfully allocated
*              RFAILED -  otherwise
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16  stAllocDlgId
(
StTUSap  *tuSapCp,           /* pointer to Upper Sap */
StDlgId  *dlgId              /* return the allocated dialogue ID */
)
#else
PUBLIC S16  stAllocDlgId(tuSapCp, dlgId)
StTUSap  *tuSapCp;           /* pointer to Upper Sap */
StDlgId  *dlgId;             /* return the allocated dialogue ID */
#endif
{
   StDlgId   bitMapPos;  /* position of dlg id in the bitmap */
  /* st002.301 - length increased for handling more simultaneous dialogues */
   U32       octIdx;     /* Octet index in the bit map */
   U8        bitIdx;     /* bit index in the octet */
   /* st002.301 - length increased for handling more simultaneous dialogues */ 
   U32       idx;        /* octet index to search the octet with free bit */
   U8        bitMask;    /* to mask a single bit in the octet */

   TRC2(stAllocDlgId)
 
   /* dlgIdPool contains the next available dialogue id */
   *dlgId  = tuSapCp->dlgIdPool;

   /* increment the dialogue id pool to the next available value */
   tuSapCp->dlgIdPool = (tuSapCp->dlgIdPool + 1);

   /* Keep the dialogue id within the configured range for dialogue id */
   /* check if high and low dlg id are configured */
   if (tuSapCp->cfg.hiDlgId > 0)
   {
      if (tuSapCp->dlgIdPool >= tuSapCp->cfg.hiDlgId)
      {
         tuSapCp->dlgIdPool = tuSapCp->cfg.loDlgId;
      }
   }

   /* roll over the dialogue id pool. skip the value 0 */
   if (tuSapCp->dlgIdPool == 0)
   {
      tuSapCp->dlgIdPool++;
   }

   /* If bitmap for dialogue id hasn't been initialized, assume this dialogue
      id is free and returns */
   if (tuSapCp->bitMap.size == 0)
   {
      RETVALUE(ROK);
   }

   /* find the bit position in the bitmap corresponding to this dlgId */
   bitMapPos = *dlgId - tuSapCp->cfg.loDlgId;
   
   octIdx = bitMapPos / 8;   /* octet index in the bitmap */
   bitIdx = bitMapPos % 8;   /* bit index in the octet */

   bitMask = (0x01 << bitIdx);

   /* Check if this dialogue id is free */
   if (!(tuSapCp->bitMap.map[octIdx] & bitMask))
   {
      /* dialogue id is free, Mark this dialogue id busy now */
      tuSapCp->bitMap.map[octIdx] |= bitMask;

      RETVALUE(ROK);
   }

   /* this dialogue id is busy, find next free dialogue id */
   idx       = octIdx;  /* start searching from this index onwards */

   while (TRUE)
   {
      U8   curOct;  /* octet to check for free bit */

      curOct = tuSapCp->bitMap.map[idx];

      /* check if any bit in this byte is free */
      if (curOct != 0xFF)
      {
         for (bitIdx = 0, bitMask = 0x01; bitIdx < 8; bitIdx++)
         {
             if (!(curOct & bitMask))
             {
                /* found a free bit, set it as used */
                tuSapCp->bitMap.map[idx] |= bitMask;
                *dlgId = idx * 8 + bitIdx + tuSapCp->cfg.loDlgId;

                /* It might be the extra bit in the map which is free */
                if (*dlgId >= tuSapCp->cfg.hiDlgId)
                {
                   break;
                }
                RETVALUE(ROK);
             }
             bitMask = bitMask << 1;
         }
      }

      /* Increment the index and wrap around if reaches the last entry */
      if (++idx == tuSapCp->bitMap.size)
      {
         idx = 0;
      }

      if (idx == octIdx)
      {
         /* traversed the entire bitmap without finding any free entry */
         *dlgId = 0;
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stAllocDlgId:No free entry for allocating the dialogue\n"));
         RETVALUE(RFAILED);
      }
   }

} /* end of stAllocDlgId */


/*
*
*       Fun:   stFreeDlgId
*
*       Desc:  This function Frees an allocated dialogue id
*
*       Ret:   ROK     - when successfully deallocated
*              RFAILED - otherwise
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16  stFreeDlgId
(
StTUSap  *tuSapCp,             /* pointer to Upper Sap */
StDlgId   dlgId                /* dialogue id to be deallocated */
)
#else
PUBLIC S16  stFreeDlgId(tuSapCp, dlgId)
StTUSap  *tuSapCp;             /* pointer to Sap */
StDlgId   dlgId;               /* dialogue id to be deallocated */
#endif
{
   StDlgId   bitMapPos;  /* position of dlg id in the bitmap */
   U16       octIdx;     /* Octet index in the bit map */
   U8        bitIdx;     /* bit index in the octet */
   U8        bitMask;    /* to mask a single bit in the octet */

   TRC2(stFreeDlgId)

   /* If bitmap for dialogue id hasn't been initialized, just returns */
   if (tuSapCp->bitMap.size == 0)
   {
      RETVALUE(ROK);
   }

   /* find the bit position in the bitmap corresponding to this dlgId */
   if (dlgId >= tuSapCp->cfg.loDlgId)
   {
      bitMapPos = dlgId - tuSapCp->cfg.loDlgId;
   }
   else
   {
      /* Invalid dialogue Id to be freed */
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stFreeDlgId:Invalid dialogue id(%ld) to be freed\n",dlgId));
      RETVALUE(RFAILED);
   }
   
   octIdx = bitMapPos / 8;   /* octet index in the bitmap */
   bitIdx = bitMapPos % 8;   /* bit index in the octet */

   bitMask = (0x01 << bitIdx);

   /* reset the bit to mark this dialogue id free */
   tuSapCp->bitMap.map[octIdx] &= ~bitMask;

   RETVALUE(ROK);
} /* end of stFreeDlgId */


#ifndef ZT

/*
*
*       Fun:   stAllocDlg 
*
*       Desc:  Allocate buffer for a new dialogue and insert into the hash
*              list of dialogues.
*
*       Ret:   ROK      - success
*              RFAILED  - failed
*
*       Notes:
*
*       File:  ct_bdy4.c
*
*/
/* st043.301- Addition - Added suDlgId as new parameter in stAllocDlg */
#ifdef ANSI
PUBLIC S16 stAllocDlg
(
StTUSap   *tuSapCp,   /* Sap control point */
StDlgCp  **dlgCp,      /* Dialogue control point */
StDlgId  suDlgId       /* service user dialogue Id     */
)
#else
PUBLIC  S16 stAllocDlg(tuSapCp, dlgCp, suDlgId)
StTUSap   *tuSapCp;   /* Sap control point */
StDlgCp  **dlgCp;     /* Dialogue control point */
StDlgId  suDlgId;     /* service user dialogue Id     */
#endif
{
   StDlgCp  *newDlg;       /* pointer to dialogue control point */
   S16       ret;          /* return value */

   TRC2(stAllocDlg)

   /* Check if configured limit on total number of active dialogue for this Sap
      has already reached */
   if (tuSapCp->allocDlg >= tuSapCp->cfg.nmbDlgs)
   {
      *dlgCp = NULLP;
      stSendAlarm(LCM_CATEGORY_INTERNAL, LST_EVENT_MAX_CFG, LST_CAUSE_DLG_ALOC,
                  NOTUSED, NOTUSED);

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST271, (ErrVal)tuSapCp->allocDlg,
                "stAllocDlg():Exceeds configured nmbDlgs");
#endif
      RETVALUE(RFAILED);
   }

   /* allocate memory */
   newDlg = (StDlgCp *) stAlloc(sizeof(StDlgCp));
   
   if (newDlg == NULLP)
   {
      *dlgCp = NULLP;
      stSendAlarm(LCM_CATEGORY_RESOURCE, LST_EVENT_ALOC_FAIL, LCM_CAUSE_UNKNOWN,
                  NOTUSED, NOTUSED);

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST272, (ErrVal)0,
                "stAllocDlg():Memory allocation failed");
#endif
      RETVALUE(RFAILED);
   }

   /* initialize the dialogue */
   newDlg->spDlgId      = 0;
/* st043.301 - Modification - Initialize the suDlgId */   
   newDlg->suDlgId      = suDlgId;
   newDlg->dstDlgId     = 0;
   newDlg->dstAddr.pres = FALSE;
   newDlg->srcAddr.pres = FALSE;
   newDlg->dhaSt        = S_DHA_IDLE;
   newDlg->tslSt        = S_TSM_IDLE;
   newDlg->firstBackMsg = FALSE;
   newDlg->compBuf      = NULLP;
   newDlg->compQ.qLen   = 0;
   newDlg->sapCp        = tuSapCp;
   /* st017.301 -Add- Initialize termMsg */
   newDlg->termMsg      = FALSE;

   /* st028.301 - Add - Intialize number of invokes allocated to ZERO */
   newDlg->allocInv     = 0;

   /* get a dialogue id for this dialogue */
   if (stAllocDlgId(tuSapCp, &newDlg->spDlgId) != ROK)
   {
      *dlgCp = NULLP;

      /* free the memory */
      stFree((Data *)newDlg, sizeof(StDlgCp));

      /* could not allocate a new dialogue ID */
      stSendAlarm(LCM_CATEGORY_PROTOCOL, LST_EVENT_ALOC_DLGID_FAIL,
                  LCM_CAUSE_UNKNOWN, NOTUSED, NOTUSED);

      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stAllocDlg:Could not allocate new dialogue Id\n"));
      RETVALUE(RFAILED);
   }

   /* check if hash list bins are available */
   if (tuSapCp->binPool < ST_NMB_BIN_INV)
   {
      *dlgCp = NULLP;

     /* st040.301 - Modification - Change Comment to remove warnings.  */
     /* st019.301 - Modification, free dialogue control block after 
      * freeing dialogue ID to avoid memory accessing violation
      */
      /* free the dialogue id */
      stFreeDlgId(tuSapCp, newDlg->spDlgId);

      /* free the memory */
      stFree((Data *)newDlg, sizeof(StDlgCp));

      /* no more hash list bins available, return error */
      stSendAlarm(LCM_CATEGORY_INTERNAL, LST_EVENT_HASH_FAIL,
                  LCM_CAUSE_UNKNOWN, NOTUSED, NOTUSED);


      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stAllocDlg:No more hash list bin available\n"));
      RETVALUE(RFAILED);
   }

   /* Allocate a hash list of invokes */
   ret = cmHashListInit(&newDlg->invHlCp,   /* HL control point */
                        ST_NMB_BIN_INV,     /* HL bins for a dialogue */
                        0,                  /* Offset of HL Entry */
#ifdef INVOKE_ID_FLAG
                        TRUE,               /* Allow dup. keys ? */
#else
                        FALSE,              /* Allow dup. keys ? */
#endif
                        0,                  /* HL key type */
                        stCb.init.region,   /* Mem region for HL */
                        stCb.init.pool);    /* Mem pool for HL */
 
   if (ret != ROK)
   {
      *dlgCp = NULLP;

     /* st040.301 - Modification - Change Comment to remove warnings.  */
      /* st019.301 - Modification, free dialogue control block after 
       * freeing dialogue ID to avoid memory accessing violation
       */

      /* free the dialogue id */
      stFreeDlgId(tuSapCp, newDlg->spDlgId);

      stSendAlarm(LCM_CATEGORY_RESOURCE, LST_EVENT_HASH_FAIL, LCM_CAUSE_UNKNOWN,
                  NOTUSED, NOTUSED);

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST273, (ErrVal) newDlg->spDlgId,
                "stAllocDlg: cmHashListInit Failed");
#endif /* ERRCLASS & ERRCLS_DEBUG */

     /* st040.301 - Modification - Change Comment to remove warnings.  */
      /* st019.301 - Modification, free dialogue control block after 
       * freeing dialogue ID to avoid memory accessing violation
       */
      /* free the memory */
      stFree((Data *)newDlg, sizeof(StDlgCp));

      RETVALUE(ret);
   }

   /* Insert the dialogue into the hash list of dialogues */
   ret = cmHashListInsert(&tuSapCp->dlgHlCp,       /* Hash List */
                          (PTR) newDlg,            /* Entry to be inserted */
                          (U8 *) &newDlg->spDlgId, /* Key */
                          sizeof(StDlgId));        /* Key Length */
 
   if (ret == RFAILED)
   {
      *dlgCp = NULLP;

     /* st040.301 - Modification - Change Comment to remove warnings.  */
      /* st019.301 - Modification, free dialogue control block after 
       * freeing dialogue ID to avoid memory accessing violation
       */
      /* free the dialogue id */
      stFreeDlgId(tuSapCp, newDlg->spDlgId);

      /* de initialize the hash list */
      cmHashListDeinit(&newDlg->invHlCp);

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST274, (ErrVal) newDlg->spDlgId,
                "stAllocDlg(). Could not insert hash list entry");
#endif /* ERRCLASS & ERRCLS_DEBUG */

     /* st040.301 - Modification - Change Comment to remove warnings.  */
      /* st019.301 - Modification, free dialogue control block after 
       * freeing dialogue ID to avoid memory accessing violation
       */
      /* free the memory */
      stFree((Data *)newDlg, sizeof(StDlgCp));

      RETVALUE(RFAILED);
   }

/* st043.301 - Addition - insert the dialogue in new hash list of dialogues  */
      /* Insert the dialogue into the hash list of dialogues */
   if(newDlg->suDlgId)
   {
      ret = cmHashListInsert(&tuSapCp->suDlgHlCp,    /* Hash List */
                            (PTR) newDlg,            /* Entry to be inserted */
                          (U8 *) &newDlg->suDlgId,   /* Key */
                          sizeof(StDlgId));          /* Key Length */
   }

   /* decrement the number of bins avialable */
   tuSapCp->binPool = (tuSapCp->binPool - ST_NMB_BIN_INV);

   *dlgCp = newDlg;

   tuSapCp->allocDlg++;   /* Increment number of dialogues allocates */
   tuSapCp->usedDlg++;   /* Increment number of dialogues used */

   /* TimeStamp when the dialogue control point was last accessed */
   SGetSysTime(&(*dlgCp)->tmStmp);

#ifdef ZT
   newDlg->wsUpdFlg = FALSE;
   ztAddMapping (newDlg->spDlgId, newDlg);
#endif /* ZT */ 

   RETVALUE(ROK);
} /* stAllocDlg */

#else /* ZT */

/*
*
*       Fun:   stAllocDlg 
*
*       Desc:  Allocate buffer for a new dialogue and insert into the hash
*              list of dialogues.
*
*       Ret:   ROK      - success
*              RFAILED  - failed
*
*       Notes:
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 stAllocDlg
(
StTUSap          *tuSapCp,      /* Sap control point            */
StDlgCp          **dlgCp,       /* Dialogue control point       */
StDlgId          suDlgId,       /* service user dialogue Id     */
StDlgId          spDlgId,       /* service provider dialogue Id */
SpAddr           *dstAddr,      /* destination SCCP address     */
CmFthaInterface  intfc          /* interface handled by layer   */
)
#else
PUBLIC  S16 stAllocDlg(tuSapCp, dlgCp, suDlgId, spDlgId, dstAddr, intfc)
StTUSap          *tuSapCp;      /* Sap control point            */
StDlgCp          **dlgCp;       /* Dialogue control point       */
StDlgId          suDlgId;       /* service user dialogue Id     */
StDlgId          spDlgId;       /* service provider dialogue Id */
SpAddr           *dstAddr;      /* destination SCCP address     */
CmFthaInterface  intfc;         /* interface handled by layer   */
#endif
{
   StDlgCp  *newDlg;       /* pointer to dialogue control point */
   S16       ret;          /* return value */

   TRC2(stAllocDlg)

   /* Check if configured limit on total number of active dialogue for this Sap
      has already reached */
   if (tuSapCp->allocDlg >= tuSapCp->cfg.nmbDlgs)
   {
      *dlgCp = NULLP;
      stSendAlarm(LCM_CATEGORY_INTERNAL, LST_EVENT_MAX_CFG, LST_CAUSE_DLG_ALOC,
                  NOTUSED, NOTUSED);

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST275, (ErrVal)tuSapCp->allocDlg,
                "stAllocDlg():Exceeds configured nmbDlgs");
#endif
      RETVALUE(RFAILED);
   }

   /* allocate memory */
   newDlg = (StDlgCp *) stAlloc(sizeof(StDlgCp));
   
   if (newDlg == NULLP)
   {
      *dlgCp = NULLP;
      stSendAlarm(LCM_CATEGORY_RESOURCE, LST_EVENT_ALOC_FAIL, LCM_CAUSE_UNKNOWN,
                  NOTUSED, NOTUSED);

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST276, (ErrVal)0,
                "stAllocDlg():Memory allocation failed");
#endif
      RETVALUE(RFAILED);
   }

   /* initialize the dialogue */
   newDlg->spDlgId      = 0;
/* st043.301 - Modify - Initialize the suDlgId */   
   newDlg->suDlgId      = suDlgId;
   newDlg->dstDlgId     = 0;
   newDlg->dstAddr.pres = FALSE;
   newDlg->srcAddr.pres = FALSE;
   newDlg->dhaSt        = S_DHA_IDLE;
   newDlg->tslSt        = S_TSM_IDLE;
   newDlg->firstBackMsg = FALSE;
   newDlg->compBuf      = NULLP;
   newDlg->compQ.qLen   = 0;
   newDlg->sapCp        = tuSapCp;

   /* get a dialogue id for this dialogue */
   if (spDlgId == 0)
   {
#ifdef ZT_DFTHA
      if(ZT_IS_DIST_FTHA)
      {

         /* In case of DFTHA use the function in ZT to allocate a dialogue id */
         if (ztAllocDlgId(tuSapCp, &newDlg->spDlgId, 
                       suDlgId, dstAddr, intfc) != ROK)
         {
            *dlgCp = NULLP;

            /* free the memory */
            stFree((Data *)newDlg, sizeof(StDlgCp));

            /* st009.301 -Add- Debug prints */
            STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stAllocDlg:Could not allocate new dlg. Id using ztAllocDlgId\n"));
            /* could not allocate a new dialogue ID */
            stSendAlarm(LCM_CATEGORY_PROTOCOL, LST_EVENT_ALOC_DLGID_FAIL,
                        LCM_CAUSE_UNKNOWN, NOTUSED, NOTUSED);

            RETVALUE(RFAILED);
         }
      }
      else 
#endif /* DFTHA */
      {
         /* get a dialogue id for this dialogue */
         if (stAllocDlgId(tuSapCp, &newDlg->spDlgId) != ROK)
         {
            *dlgCp = NULLP;
   
            /* free the memory */
            stFree((Data *)newDlg, sizeof(StDlgCp));
   
            /* st009.301 -Add- Debug prints */
            STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                   "stAllocDlg:No more hash list bins are available\n"));

            /* could not allocate a new dialogue ID */
            stSendAlarm(LCM_CATEGORY_PROTOCOL, LST_EVENT_ALOC_DLGID_FAIL,
                        LCM_CAUSE_UNKNOWN, NOTUSED, NOTUSED);
   
            RETVALUE(RFAILED);
         }
      }
   }
   else
   {
      newDlg->spDlgId = spDlgId;
/* st003.301 - code added to synchronise the dialogue Id allocation at sby */
#ifdef ZT_DFTHA
      if(ZT_IS_DIST_FTHA)
      {
         CmFthaRsetId   rsetId;      /* resource set Id            */
         ZtRsetCb       *rsetCb;     /* pointer to resource set Cb */

         rsetId = ZT_GET_RSETID(spDlgId);
         rsetCb = ztCb.rsetCbLst[rsetId];
         rsetCb->dlgIdPool = spDlgId+1;
      }
      else 
#endif /* ZT_DFTHA */
      {
         tuSapCp->dlgIdPool = spDlgId+1;
      }
   }

   /* check if hash list bins are available */
   if (tuSapCp->binPool < ST_NMB_BIN_INV)
   {
      *dlgCp = NULLP;

      /* free the memory */
      stFree((Data *)newDlg, sizeof(StDlgCp));

#ifdef ZT_DFTHA
      if(ZT_IS_DIST_FTHA)
      {
         /* free the dialogue id */
         ztFreeDlgId(newDlg->spDlgId);  
      }
      else 
#endif /* ZT_DFTHA */
      {
         /* free the dialogue id */
         stFreeDlgId(tuSapCp,newDlg->spDlgId);  
      }

      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stAllocDlg:Could not allocate new dialogue Id\n"));
      /* no more hash list bins available, return error */
      stSendAlarm(LCM_CATEGORY_INTERNAL, LST_EVENT_HASH_FAIL,
                  LCM_CAUSE_UNKNOWN, NOTUSED, NOTUSED);

      RETVALUE(RFAILED);
   }

   /* Allocate a hash list of invokes */
   ret = cmHashListInit(&newDlg->invHlCp,   /* HL control point */
                        ST_NMB_BIN_INV,     /* HL bins for a dialogue */
                        0,                  /* Offset of HL Entry */
#ifdef INVOKE_ID_FLAG
                        TRUE,               /* Allow dup. keys ? */
#else
                        FALSE,              /* Allow dup. keys ? */
#endif
                        0,                  /* HL key type */
                        stCb.init.region,   /* Mem region for HL */
                        stCb.init.pool);    /* Mem pool for HL */
 
   if (ret != ROK)
   {
      *dlgCp = NULLP;

      /* free the memory */
      stFree((Data *)newDlg, sizeof(StDlgCp));

#ifdef ZT_DFTHA
      if(ZT_IS_DIST_FTHA)
      {
         /* free the dialogue id */
         ztFreeDlgId(newDlg->spDlgId);  
      }
      else 
#endif /* ZT_DFTHA */
      {
         /* free the dialogue id */
         stFreeDlgId(tuSapCp,newDlg->spDlgId);  
      }

      stSendAlarm(LCM_CATEGORY_RESOURCE, LST_EVENT_HASH_FAIL, LCM_CAUSE_UNKNOWN,
                  NOTUSED, NOTUSED);

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST277, (ErrVal) newDlg->spDlgId,
                "stAllocDlg: cmHashListInit Failed");
#endif /* ERRCLASS & ERRCLS_DEBUG */

      RETVALUE(ret);
   }

   /* Insert the dialogue into the hash list of dialogues */
   ret = cmHashListInsert(&tuSapCp->dlgHlCp,       /* Hash List */
                          (PTR) newDlg,            /* Entry to be inserted */
                          (U8 *) &newDlg->spDlgId, /* Key */
                          sizeof(StDlgId));        /* Key Length */
 
   if (ret == RFAILED)
   {
      *dlgCp = NULLP;

      /* free the memory */
      stFree((Data *)newDlg, sizeof(StDlgCp));

#ifdef ZT_DFTHA
      if(ZT_IS_DIST_FTHA)
      {
         /* free the dialogue id */
         ztFreeDlgId(newDlg->spDlgId);  
      }
      else 
#endif /* ZT_DFTHA */
      {
         /* free the dialogue id */
         stFreeDlgId(tuSapCp,newDlg->spDlgId);  
      }

      /* de initialize the hash list */
      cmHashListDeinit(&newDlg->invHlCp);

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST278, (ErrVal) newDlg->spDlgId,
                "stAllocDlg(). Could not insert hash list entry");
#endif /* ERRCLASS & ERRCLS_DEBUG */

      RETVALUE(RFAILED);
   }

/* st043.301 - Addition - insert the dialogue into the new hash list */
      /* Insert the dialogue into the hash list of dialogues */
   if(newDlg->suDlgId)
   {
      ret = cmHashListInsert(&tuSapCp->suDlgHlCp,     /* Hash List */
                            (PTR) newDlg,             /* Entry to be inserted */
                            (U8 *) &newDlg->suDlgId,  /* Key */
                            sizeof(StDlgId));         /* Key Length */
   }

   /* decrement the number of bins avialable */
   tuSapCp->binPool = (tuSapCp->binPool - ST_NMB_BIN_INV);

   *dlgCp = newDlg;

   tuSapCp->allocDlg++;   /* Increment number of dialogues allocates */
   tuSapCp->usedDlg++;   /* Increment number of dialogues used */

   /* TimeStamp when the dialogue control point was last accessed */
   SGetSysTime(&(*dlgCp)->tmStmp);

   newDlg->wsUpdFlg=FALSE;
   ztAddMapping (newDlg->spDlgId, newDlg);

   RETVALUE(ROK);
} /* stAllocDlg */
#endif /* ZT */


/*
*
*       Fun:   stAllocInv
*
*       Desc:  Allocate a Invoke and inset into the hash list of invokes
*
*       Ret:   ROK      - success
*              RFAILED  - failed
*
*       Notes: Note
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 stAllocInv
(
StDlgCp   *dlgCp,     /* dialogue control point */
StInvId    invId,     /* Invoke ID */
StInvCp  **invCp      /* allocate invoke control point */
)
#else
PUBLIC  S16 stAllocInv(dlgCp, invId, invCp)
StDlgCp   *dlgCp;     /* dialogue control point */
StInvId    invId;     /* Invoke ID */
StInvCp  **invCp;     /* allocate invoke control point */
#endif
{
   StTUSap  *tuSapCp; /* Upper Sap */
   StInvCp  *newInv;  /* pointer to allocated control point */
   S16       ret;     /* return value */

   TRC2(stAllocInv)

   /* Get the Sap */
   tuSapCp = dlgCp->sapCp;

   /* Check if configured limit on total number of active invokes for this Sap
      has already reached */
   if (tuSapCp->allocInv >= tuSapCp->cfg.nmbInvs)
   {
      *invCp = NULLP;
      stSendAlarm(LCM_CATEGORY_INTERNAL, LST_EVENT_MAX_CFG, LST_CAUSE_INV_ALOC,
                  NOTUSED, NOTUSED);

#if (ERRCLASS & ERRCLS_INT_PAR)
      STLOGERROR(ERRCLS_INT_PAR, EST279, (ErrVal)tuSapCp->allocInv,
                "stAllocInv():Exceeds configured nmbInvs");
#endif
      RETVALUE(RFAILED);
   }

   /* allocate memory */
   newInv = (StInvCp *) stAlloc(sizeof(StInvCp));
   
   if (newInv == NULLP)
   {
      *invCp = NULLP;

      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stAllocInv:Could not allocate new invoke in dialogue(%ld)",
             dlgCp->spDlgId));
      stSendAlarm(LCM_CATEGORY_RESOURCE, LST_EVENT_ALOC_FAIL, LCM_CAUSE_UNKNOWN,
                  NOTUSED, NOTUSED);
      RETVALUE(RFAILED);
   }

   /* initialize the invoke control point */
   newInv->invId      = invId;
   newInv->invTmr     = 0;
   newInv->numLnkdInv = 0;
   newInv->ismSt      = S_ISM_IDLE;
   newInv->dlgCp      = dlgCp;

   /* Insert the invoke into the hash list of invokes */
   ret = cmHashListInsert(&dlgCp->invHlCp,         /* Hash List */
                          (PTR) newInv,            /* Entry */
                          (U8 *) &newInv->invId,   /* key */
                          sizeof(U8));             /* Key Length */
 
   if (ret != ROK)
   {
      *invCp = NULLP;
      (Void)stFree((Data *)newInv, sizeof(StInvCp)); /* free the memory */

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST280, (ErrVal) invId,
                "stAllocInv: Hash List insert failed");
#endif /* ERRCLASS & ERRCLS_DEBUG */

      RETVALUE(RFAILED);
   }

   /* initialize the timers */
   (Void)cmInitTimers(newInv->timers, (U8)ST_MAX_TMR);

   *invCp = newInv;

   dlgCp->sapCp->allocInv++;   /* Increment number of Invocation allocated */

   /* st029.301 - Add - invokes count */
   dlgCp->allocInv ++;
   dlgCp->sapCp->usedInv++;   /* Increment number of Invocation used */

   /* TimeStamp when the dialogue control point was last accessed */
   SGetSysTime(&dlgCp->tmStmp);
   SGetSysTime(&(*invCp)->tmStmp);

   RETVALUE(ROK);
} /* stAllocInv */


/*
*
*       Fun:   stFreeInv 
*
*       Desc:  Remove a invoke and free all asociated memory
*
*       Ret:   ROK      - success
*              RFAILED  - failed
*
*       Notes: <none>
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 stFreeInv
(
StInvCp   *invCp      /* Invoke control point */
)
#else
PUBLIC  S16 stFreeInv(invCp)
StInvCp   *invCp;     /* Invoke control point */
#endif
{
   StDlgCp *dlgCp;
   S16      ret;           /* return value */
   U8       tmrNum;        /* Timer number */

   TRC2(stFreeInv)

   dlgCp = invCp->dlgCp;
   /* st038.301 - Addition - Initialisation of ret */
   ret   = RFAILED;

   /* st028.301 - Add - Check if invoke ID count is <= 0 */
   if (dlgCp->allocInv <= 0)
   {
      STLOGERROR(ERRCLS_DEBUG, EST237, (ErrVal) ret,
                "stFreeInv: Double deallocation on invoke hashlist");
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stFreeInv:suDlgId(%d), spDlgId(%d), invId(%d), invPtr(0x%x),\n \
              allocInv(%d) \n",
              dlgCp->suDlgId, dlgCp->spDlgId, invCp->invId, invCp,
              dlgCp->allocInv));

      RETVALUE(RFAILED);
   }

   /* stop the timers with this invoke */
   /* st027.301 - Add -
    * Stop all the timers attached to this invoke */
   for (tmrNum = 0; tmrNum < ST_MAX_TMR; tmrNum++)
   {
     if (invCp->timers[tmrNum].tmrEvnt != TMR_NONE)
     {
        (Void) stStopTmr(invCp->timers[tmrNum].tmrEvnt, invCp);
     }
   }

   /* Delete the invocation from the hash list */
   ret = cmHashListDelete(&dlgCp->invHlCp, (PTR)invCp);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret == RFAILED)
   {
      STLOGERROR(ERRCLS_DEBUG, EST281, (ErrVal) ret,
                "stFreeInv: Hash list delete failed");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

   /* Free the memory associated with this invoke */
   stFree((Data *)invCp, sizeof(StInvCp));

   dlgCp->sapCp->allocInv--;   /* Decrement number of Invocation allocated */
   
   /* st029.301 - Add - invokes count */
   dlgCp->allocInv --;

   RETVALUE(ROK);
} /* stFreeInv */


/*
*
*       Fun:   stFreeAllInv 
*
*       Desc:  Removes all invokes in the Invoke Hash List
*
*       Ret:   ROK      - success
*              RFAILED  - failed
*
*       Notes: <none>
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 stFreeAllInv
(
CmHashListCp   *invHlCp      /* Invoke Hash List Control Point */
)
#else
PUBLIC  S16 stFreeAllInv(invHlCp)
CmHashListCp   *invHlCp;     /* Invoke Hash List Control Point */
#endif
{
   StInvCp *invCp;        /* pointer to invoke control point */

   TRC2(stFreeAllInv)

   while (cmHashListGetNext(invHlCp, NULLP, (PTR *)&invCp) == ROK)
   {
      /* removes a invoke from the hash list, frees the memory & timers */
      (Void)stFreeInv(invCp);

   } /* end while */

   RETVALUE(ROK);
} /* stFreeAllInv */


/*
*
*       Fun:   stFreeDlg 
*
*       Desc:  Remove a dialogue and free all asociated memory
*
*       Ret:   ROK      - success
*              RFAILED  - failed
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 stFreeDlg
(
StDlgCp   *dlgCp      /* dialogue control point */
)
#else
PUBLIC  S16 stFreeDlg(dlgCp)
StDlgCp   *dlgCp;     /* dialogue control point */
#endif
{
   StTUSap *tuSapCp;
   S16      ret;           /* return value */

   TRC2(stFreeDlg)

   if (dlgCp->compQ.qLen != 0)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(dlgCp->compBuf);

      dlgCp->compQ.qLen = 0;
   }

   /* Free all the invoke control points with this dialogue */
   (Void)stFreeAllInv(&dlgCp->invHlCp);

   /* deinitialize the hash list of invokes */
   (Void)cmHashListDeinit(&dlgCp->invHlCp);

   /* Get the upper sap control point */
   tuSapCp = dlgCp->sapCp;

   /* Delete the dialogue from the hash list of dialogues */
   ret = cmHashListDelete(&tuSapCp->dlgHlCp, (PTR)dlgCp);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret == RFAILED)
   {
      STLOGERROR(ERRCLS_DEBUG, EST282, (ErrVal) dlgCp->spDlgId,
                 "stFreeDlg: Could not delete hash list entry");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

/* st043.301 - Addition - Delete the dialgue from new hash list */
      ret = cmHashListDelete(&tuSapCp->suDlgHlCp, (PTR)dlgCp);
   
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret == RFAILED)
   {
      STLOGERROR(ERRCLS_DEBUG, EST282, (ErrVal) dlgCp->spDlgId,
                 "stFreeDlg: Could not delete hash list entry");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

   /* free the dialogue id */
#ifdef ZT_DFTHA
   if(ZT_IS_DIST_FTHA)
   {
      ztFreeDlgId(dlgCp->spDlgId);
   }
   else 
#endif /* ZT_DFTHA */
   {
      stFreeDlgId(dlgCp->sapCp, dlgCp->spDlgId);
   }

#ifdef ZT
   ztDelMapping(dlgCp->spDlgId, dlgCp);
#endif /* ZT */

   /* Free the memory associated with this dialogue */
   stFree((Data *)dlgCp, sizeof(StDlgCp));

   /* increment the number of bins available */
   tuSapCp->binPool += ST_NMB_BIN_INV;

   /* decrement number of dialogues allocated */
   tuSapCp->allocDlg--;

   RETVALUE(ROK);
} /* stFreeDlg */


/*
*
*       Fun:   stFreeAllDlg 
*
*       Desc:  Remove all dialogues in the dialogue Hash List
*
*       Ret:   ROK      - success
*              RFAILED  - failed
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 stFreeAllDlg
(
CmHashListCp   *dlgHlCp      /* Dialogue hash list control point */
)
#else
PUBLIC  S16 stFreeAllDlg(dlgHlCp)
CmHashListCp   *dlgHlCp;     /* Dialogue hash list control point */
#endif
{
   StDlgCp  *dlgCp;        /* pointer to dialogue control point */

   TRC2(stFreeAllDlg)

   while (cmHashListGetNext(dlgHlCp, NULLP, (PTR *)&dlgCp) == ROK)
   {
      /* removes a dialogue and associated invokes, frees the memory */
      (Void)stFreeDlg(dlgCp);
   }

   RETVALUE(ROK);
} /* stFreeAllDlg */


/*
*
*       Fun:   stFndDlg 
*
*       Desc:  This function finds a dialogue from the hash list
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ct_bdy4.c
*
*/
/* st043.301 - Addition - Added suDlgHlCp as parameter in stFndDlg */
#ifdef ANSI
PUBLIC S16  stFndDlg 
(
CmHashListCp  *dlgHlCp,       /* Dialogue Hash list control point */
CmHashListCp *suDlgHlCp,
StDlgId        dlgId,         /* dialogue id to search */
Bool           flag,          /* what to use for search */
StDlgCp      **dlgCp          /* returne the found dialogue */
)
#else
PUBLIC S16  stFndDlg (dlgHlCp, suDlgHlCp, dlgId, flag, dlgCp)
CmHashListCp  *dlgHlCp;       /* Dialogue Hash list control point */
CmHashListCp *suDlgHlCp;
StDlgId        dlgId;         /* dialogue id to search */
Bool           flag;          /* what to use for search */
StDlgCp      **dlgCp;         /* returne the found dialogue */
#endif
{
/* st043.301 - Removal - removed tmpDlg */   
/* StDlgCp   *tmpDlg;      dialogue control point */
   S16        ret;        /* return value */

   TRC2(stFndDlg)

   switch (flag)
   {

      case ST_USE_SPDLGID:

         if ((ret = cmHashListFind(dlgHlCp,              /* Hash List */
                                   (U8 *)&dlgId,         /* Key */
                                   sizeof(StDlgId),      /* Key length */
                                   0,
                                   (PTR *)dlgCp)) == ROK)
         {
            /* Update the time stamp */
            SGetSysTime(&(*dlgCp)->tmStmp);

            RETVALUE(ROK);
         }
         break;

      case ST_USE_SUDLGID:
/* st043.301 - Modification - Replace cmHashListGetNext with cmHashListFind */
         if ((ret = cmHashListFind(suDlgHlCp,              /* Hash List */
                                   (U8 *)&dlgId,         /* Key */
                                   sizeof(StDlgId),      /* Key length */
                                   0,
                                   (PTR *)dlgCp)) == ROK)
         {
            /* Update the time stamp */
            SGetSysTime(&(*dlgCp)->tmStmp);

            RETVALUE(ROK);
         }

         break;

   } /* end switch */

   RETVALUE(RFAILED);
} /* stFndDlg  */


/*
*
*       Fun:   stFndInv 
*
*       Desc:  This function finds a invoke from the hash list
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16  stFndInv 
(
CmHashListCp  *invHlCp,        /* Invoke Hash List control point */
StInvId        invId,          /* invoke id */
StInvCp      **invCp           /* return the found invocation */
)
#else
PUBLIC S16  stFndInv (invHlCp, invId, invCp)
CmHashListCp  *invHlCp;        /* Invoke Hash List control point */
StInvId        invId;          /* invoke id */
StInvCp      **invCp;          /* return the found invocation */
#endif
{
   S16   ret;

   TRC2(stFndInv)

   ret =  cmHashListFind(invHlCp,            /* Hash List */
                         (U8 *)&invId,       /* Key */
                         sizeof(StInvId),    /* Key Length */
                         0,
                         (PTR *)invCp);      /* Entry */

   if (ret == ROK)
   {
      /* Update the time stamp */
      SGetSysTime(&(*invCp)->tmStmp);
   }
   
   RETVALUE(ret);

} /* stFndInv  */

#ifdef INVOKE_ID_FLAG
/*
*
*       Fun:   stFndDupInv 
*
*       Desc:  This function finds a invoke from the hash list
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16  stFndDupInv 
(
CmHashListCp  *invHlCp,        /* Invoke Hash List control point */
StInvId        invId,          /* invoke id */
U8             dir,            /* Invoke Direction */
StInvCp      **invCp           /* return the found invocation */
)
#else
PUBLIC S16  stFndDupInv (invHlCp, invId, dir, invCp)
CmHashListCp  *invHlCp;        /* Invoke Hash List control point */
StInvId        invId;          /* invoke id */
U8             dir;            /* Invoke Direction */
StInvCp      **invCp;          /* return the found invocation */
#endif
{
   S16   ret;
   U8    seqNum;

   TRC2(stFndDupInv)

   seqNum = 0;

   ret =  cmHashListFind(invHlCp,            /* Hash List */
                         (U8 *)&invId,       /* Key */
                         sizeof(StInvId),    /* Key Length */
                         seqNum++,
                         (PTR *)invCp);      /* Entry */

   if (ret == ROK)
   {
      if ((*invCp)->dir != dir)
      {
         ret =  cmHashListFind(invHlCp,            /* Hash List */
                               (U8 *)&invId,       /* Key */
                               sizeof(StInvId),    /* Key Length */
                               seqNum++,
                               (PTR *)invCp);      /* Entry */
      }
     
      if (ret == ROK)
      {
         /* Update the time stamp */
         SGetSysTime(&(*invCp)->tmStmp);
      }
   }
   
   RETVALUE(ret);

} /* stFndDupInv  */
#endif


/*
*
*       Fun:    stCompQLast
*
*       Desc:   Add a component entry at the last of the component queue
*
*       Ret:    ROK      if successful
*               RFAILED  if failure
*
*       Notes:  None
*
*       File:   ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16  stCompQLast
(
StDlgCp     *dlgCp,            /* Associated dialogue */
Buffer      *mBuf,             /* buffer contains a component */
U8           compType,         /* component type */
TknInvId    *invId             /* Invoke Id associated with the component */
)
#else
PUBLIC S16  stCompQLast(dlgCp, mBuf, compType, invId)
StDlgCp     *dlgCp;            /* Associated dialogue */
Buffer      *mBuf;             /* buffer contains a component */
U8           compType;         /* component type */
TknInvId    *invId;            /* Invoke Id associated with the component */
#endif
{
   MsgLen  idx;

   TRC2(stCompQLast)

   if (dlgCp->compBuf == NULLP)
   {
      /* This is the first component */
      idx = 0;
      dlgCp->compBuf = mBuf;
   }
   else
   {
      /* Check if any space left in the queue for this component */
      if (dlgCp->compQ.qLen >= ST_MAX_COMPQ_ENTS)
      {
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
           "stCompQLast:Reached maximum, no more component entry possible \
           for dialogue (%ld)", dlgCp->spDlgId));
         RETVALUE(RFAILED);
      }

      /* Find the index in the buffer where this component is being inserted */
      SFndLenMsg(dlgCp->compBuf, &idx);

      /* Add the component to the last of the buffer */
      (Void)SCatMsg(dlgCp->compBuf, mBuf, M1M2);

      /* release the message buffer */
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);
   }

   dlgCp->compQ.q[dlgCp->compQ.qLen].type    = compType;
   dlgCp->compQ.q[dlgCp->compQ.qLen].invPres = invId->pres;
   dlgCp->compQ.q[dlgCp->compQ.qLen].invId   = invId->val;
   dlgCp->compQ.q[dlgCp->compQ.qLen].idx     = idx;

   /* Increment the queue length */
   dlgCp->compQ.qLen++;

   RETVALUE(ROK);
}  /* End of stCompQLast */


/*
*
*       Fun:    stRemOffMsgMult
*
*       Desc:   Remove bytes from a message at a given offset in the message
*
*       Ret:    ROK     - ok
*
*       Notes:  Offset (zero based ) points to the location in the buffer,
*               from where the bytes have to be removed.
*
*       File:   ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 stRemOffMsgMult
(
Buffer *mBuf,                  /* message buffer */
MsgLen  offset,                /* Offset in the message */
MsgLen  bytes                  /* Number of bytes to be removed */
)
#else
PUBLIC S16 stRemOffMsgMult(mBuf, offset, bytes)
Buffer *mBuf;                  /* message buffer */
MsgLen  offset;                /* Offset in the message */
MsgLen  bytes;                 /* Number of bytes to be removed */
#endif
{
   MsgLen   msgLen;
   Buffer  *tmpBuf;            /* Temporary message buffer */
   Data    *tmpArray;
   S16      ret;               /* return value */
 
   TRC2(stRemOffMsgMult)
 
   (Void)SFndLenMsg(mBuf, &msgLen);
 
   tmpArray = stAlloc(bytes);
   if (tmpArray == NULLP)
   {
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stRemOffMsgMult:Memory allocation failure\n"));
      RETVALUE(RFAILED);
   }

   /* check if the bytes to be removed are the last bytes in the buffer */
   if (msgLen == offset + bytes)
   {
      ret = SRemPstMsgMult(tmpArray, (MsgLen)bytes, mBuf);
      if (ret != ROK)
      {
         /* st015.301 -Add- deallocate tmpArray */
         stFree(tmpArray, bytes);
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stRemOffMsgMult:SRemPstMsgMult routine failed\n"));
         RETVALUE(RFAILED);
      }
      
      /* st015.301 -Add- deallocate tmpArray */
      stFree(tmpArray, bytes);
      RETVALUE(ROK);
   }
 
   /* check if the bytes to be removed are the first bytes in the buffer */
   if (offset == 0)
   {
      ret = SRemPreMsgMult(tmpArray, (MsgLen)bytes, mBuf);
      if (ret != ROK)
      {
         /* st015.301 -Add- deallocate tmpArray */
         stFree(tmpArray, bytes);
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stRemOffMsgMult:SRemPstMsgMult routine failed\n"));
         RETVALUE(RFAILED);
      }
      /* st015.301 -Add- deallocate tmpArray */
      stFree(tmpArray, bytes);
      RETVALUE(ROK);
   }
 
 
   ret = SSegMsg(mBuf, offset, &tmpBuf);
   if (ret != ROK)
   {
      /* st015.301 -Add- deallocate tmpArray, tmpBuf */
      stFree(tmpArray, bytes);
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(tmpBuf);
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stRemOffMsgMult:SSegMsg routine failed\n"));
      RETVALUE(RFAILED);
   }
 
   ret = SRemPreMsgMult(tmpArray, (MsgLen)bytes, tmpBuf);
   if (ret != ROK)
   {
      /* st015.301 -Add- deallocate tmpArray, tmpBuf */
      stFree(tmpArray, bytes);
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(tmpBuf);
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stRemOffMsgMult:SRemPstMsgMult routine failed\n"));
      RETVALUE(RFAILED);
   }
 
   ret = SCatMsg(mBuf, tmpBuf, M1M2);
   if (ret != ROK)
   {
      /* st015.301 -Add- deallocate tmpArray,tmpBuf */
      stFree(tmpArray, bytes);
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(tmpBuf);
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stRemOffMsgMult:SCatMsg routine failed\n"));
      RETVALUE(RFAILED);
   }
 
   /* st027.301 - Modify - Modify the user buf free mechanism */ 
   STFREEUSERBUF(tmpBuf);

   stFree(tmpArray, bytes);
 
   RETVALUE(ROK);
}  /* End of stRemOffMsgMult */


/*
*
*       Fun:    stGetProtType
*
*       Desc:   Return the type (version of ITU or ANSI) of protocol being used
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC U8 stGetProtType
(
Swtch     swtch            /* Configured Protocol switch */
)
#else
PUBLIC U8 stGetProtType(swtch)
Swtch     swtch;           /* Configured Protocol switch */
#endif
{
   U8   pType;
   
   TRC2(stGetProtType)

   /* st015.301 -Add- Initialze pType */     
   pType = ST_DEF_PROTTYPE;

   switch(swtch)
   {
      case LST_SW_ITU88:
         pType = CM_ASN_ITU_1988;
         break;

      case LST_SW_ITU92:
      case LST_SW_ITU96:
         pType = CM_ASN_ITU_1992;
         break;
 
   }

  RETVALUE(pType);

}  /* End of stGetProtType */
 

/*
*
*       Fun:    stGetCompInvId
*
*       Desc:   Return the component type, the invoke Id and the parameter
*               buffer from the component event structure.
*
*       Ret:    ROK     - ok
*               RFAILED - failure
*
*       Notes:  None
*
*       File:   ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 stGetCompInvId
(
PTR           compEv,       /* Component event structure */
Swtch         pSwtch,       /* Protocol Switch */
U8           *compType,     /* Component type */
TknInvId     *invId,        /* Invoke Id */
Buffer      **pBuf          /* Parameters buffer */
)
#else
PUBLIC S16 stGetCompInvId(compEv, pSwtch, compType, invId, pBuf)
PTR           compEv;       /* Component event structure */
Swtch         pSwtch;       /* Protocol Switch */
U8           *compType;     /* Component type */
TknInvId     *invId;        /* Invoke Id */
Buffer      **pBuf;         /* Parameters buffer */
#endif
{
   StItuCompEv  *ituCompEv;

   TRC2(stGetCompInvId)

   /* Initialize the return values */
   *compType    = ST_COMP_TYP_UNK;
   *pBuf        = NULLP;
    invId->pres = FALSE;

   if (((TknU8 *)compEv)->pres == FALSE)
   {
      RETVALUE(ROK);
   }

   /* Component type is the first element in the event structure */
   *compType = ((TknU8 *)compEv)->val;

   switch(pSwtch)
   {
      case LST_SW_ITU88:
      case LST_SW_ITU92:
      case LST_SW_ITU96:

         ituCompEv = (StItuCompEv *)compEv;
         switch(*compType)
         {
            case ST_COMP_TYP_INV:

               if (ituCompEv->comp.inv.invokeId.pres)
               {
                  invId->pres = TRUE;
                  invId->val  = ituCompEv->comp.inv.invokeId.val;
               }

               if (ituCompEv->comp.inv.params.pres)
               {
                  *pBuf  = ituCompEv->comp.inv.params.val;
               }
               break;

            case ST_COMP_TYP_RES:
            case ST_COMP_TYP_RNL:

               if (ituCompEv->comp.res.invokeId.pres)
               {
                  invId->pres = TRUE;
                  invId->val  = ituCompEv->comp.res.invokeId.val;
               }

               if (ituCompEv->comp.res.params.pres)
               {
                  *pBuf  = ituCompEv->comp.res.params.val;
               }
               break;

            case ST_COMP_TYP_ERR:

               if (ituCompEv->comp.err.invokeId.pres)
               {
                  invId->pres = TRUE;
                  invId->val  = ituCompEv->comp.err.invokeId.val;
               }

               if (ituCompEv->comp.err.params.pres)
               {
                  *pBuf  = ituCompEv->comp.err.params.val;
               }
               break;

            case ST_COMP_TYP_REJ:

               if (ituCompEv->comp.rej.invokeId.pres)
               {
                  invId->pres = TRUE;
                  invId->val  = ituCompEv->comp.rej.invokeId.val;
               }
               break;

            default:
               /* st009.301 -Add- Debug Prints */
               if (compType != NULLP)
               {        
                  STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                         "stGetCompInvId:Unknown component(%d)\n",*compType));
               }   
               RETVALUE(RFAILED);
         }
         break;
 
      default:
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stGetCompInv:Protocol variant(%d) not supported\n",pSwtch));
         break;
   }

  RETVALUE(ROK);
}  /* End of stGetCompInvId */
 

/*
*
*       Fun:    stGetNewMsgType
*
*       Desc:   Check the correctness of the message type and convert it to
*               the new defines for message type.
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC U16 stGetNewMsgType
(
U8     *msgType
)
#else
PUBLIC U16 stGetNewMsgType(msgType)
U8     *msgType;
#endif
{
   TRC2(stGetNewMsgType)

   switch(*msgType)
   {
      case STU_UNI:
         *msgType = ST_MSG_TYP_UNI;
         break;

      case STU_BEGIN:
         *msgType = ST_MSG_TYP_BGN;
         break;

      case STU_CONTINUE:
         *msgType = ST_MSG_TYP_CNT;
         break;

      case STU_END:
         *msgType = ST_MSG_TYP_END;
         break;

      case STU_U_ABORT:
         *msgType = ST_MSG_TYP_UABT;
         break;

      case STU_P_ABORT:
         *msgType = ST_MSG_TYP_PABT;
         break;


      default:
         *msgType = ST_MSG_TYP_UNK;     /* Message type unknown */
   }

  RETVALUE(ROK);
}  /* End of stGetNewMsgType */


/*
*
*       Fun:    stGetOldMsgType
*
*       Desc:   Check the correctness of the message type and convert it to
*               the old defines for message type.
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC U16 stGetOldMsgType
(
U8     *msgType,      /* Message type */
Swtch   pSwtch        /* Protocol Switch */
)
#else
PUBLIC U16 stGetOldMsgType(msgType, pSwtch)
U8     *msgType;      /* Message type */
Swtch   pSwtch;       /* Protocol Switch */
#endif
{
   TRC2(stGetOldMsgType)

   switch(pSwtch)
   {
      case LST_SW_ITU88:
      case LST_SW_ITU92:
      case LST_SW_ITU96:

         switch(*msgType)
         {
            case ST_MSG_TYP_UNI:
               *msgType = STU_UNI;
               break;

            case ST_MSG_TYP_BGN:
               *msgType = STU_BEGIN;
               break;

            case ST_MSG_TYP_CNT:
               *msgType = STU_CONTINUE;
               break;

            case ST_MSG_TYP_END:
               *msgType = STU_END;
               break;

            case ST_MSG_TYP_UABT:
               *msgType = STU_U_ABORT;
               break;

            case ST_MSG_TYP_PABT:
               *msgType = STU_P_ABORT;
               break;

            default:
               *msgType =  ST_MSG_TYP_UNK;     /* Message type unknown */
               break;
         }
         break;
   }

  RETVALUE(ROK);
}  /* End of stGetOldMsgType */
 

/*
*
*       Fun:   Swap post structure
*
*       Desc:  swap the destination and source
*
*       Ret:   None
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void stSwapPst
(
Pst   *pst
)
#else
PUBLIC Void stSwapPst(pst)
Pst   *pst;
#endif
{
   Pst   tPst;

   TRC2(stSwapPst)
 
   /* copy into temprory space and swap */
   tPst.dstProcId = pst->srcProcId;
   tPst.dstEnt    = pst->srcEnt;
   tPst.dstInst   = pst->srcInst;
   tPst.srcProcId = pst->dstProcId;
   tPst.srcEnt    = pst->dstEnt;
   tPst.srcInst   = pst->dstInst;
 
   /* copy back */
   pst->dstProcId = tPst.dstProcId;
   pst->dstEnt    = tPst.dstEnt;
   pst->dstInst   = tPst.dstInst;
   pst->srcProcId = tPst.srcProcId;
   pst->srcEnt    = tPst.srcEnt;
   pst->srcInst   = tPst.srcInst;
 
   RETVOID;
 
} /* stSwapPst */

#ifdef ST_LMINT3

/*
*
*       Fun:   stBldReplyPst
*
*       Desc:  This function prepares the post structure required for sending
*              management confirm
*
*       Ret:   RETVOID
*
*       Notes: None.
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void stBldReplyPst
(
Pst    *rPst,                    /* reply post */
Header *hdr,                     /* mgmt header */
Pst    *iPst                     /* incoming post */
)
#else
PUBLIC Void stBldReplyPst(rPst, hdr, iPst)
Pst    *rPst;                    /* reply post */
Header *hdr;                     /* mgmt header */
Pst    *iPst;                    /* incoming post */
#endif
{
   TRC2(stBldReplyPst)
 
   rPst->srcEnt    = stCb.init.ent;
   rPst->srcInst   = stCb.init.inst;
   
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   rPst->srcProcId = stCb.init.procId;
#else 
   rPst->srcProcId = SFndProcId();
#endif
   rPst->dstEnt    = iPst->srcEnt;
   rPst->dstInst   = iPst->srcInst;
   rPst->dstProcId = iPst->srcProcId;
   rPst->selector  = hdr->response.selector;
   rPst->prior     = hdr->response.prior;
   rPst->route     = hdr->response.route;
   rPst->region    = hdr->response.mem.region;
   rPst->pool      = hdr->response.mem.pool;

/* st005.301 - Added- Rolling Upgrade feature */
#ifdef ST_RUG
   /* Generate reply using same version as one  *
    * used to form the request by the LM        */

   rPst->intfVer = iPst->intfVer;
#endif  

   RETVOID;
} /* end of stBldReplyPst */
#endif /* ST_LMINT3 */


/*
*
*       Fun:   stUpdRsrcSts
*
*       Desc:  Update Resource Statistics counters
*
*       Ret:   None
*
*       Notes: this function update statistics for message tx'd/rx'd,
*              components tx'd/rx'd.
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void stUpdRsrcSts
(
StSapSts *sts,       /* Upper Sap Statistics */
U8        stsType,   /* Statistics type to update */
U8        msgType,   /* Message/component type */
Swtch     pSwtch     /* Protocol Switch */
)
#else
PUBLIC Void stUpdRsrcSts(sts, stsType, msgType, pSwtch)
StSapSts *sts;       /* Upper Sap Statistics */
U8        stsType;   /* Statistics type to update */
U8        msgType;   /* Message/component type */
Swtch     pSwtch;    /* Protocol Switch */
#endif
{
   Bool   ituFlag;

   TRC2(stUpdRsrcSts)

   /* Set the protocol flag */
   switch(pSwtch)
   {
      case LST_SW_ITU88:
      case LST_SW_ITU92:
      case LST_SW_ITU96:

         ituFlag = TRUE;
         break;

      default:
         ituFlag = FALSE;
         break;
   }

   switch(stsType)
   {
      case ST_STS_TX_MSG:        /* Transmit message */
         sts->msgTx++;   /* Total messages tx'd */

         if (ituFlag)
         {
            switch(msgType)
            {
               case ST_MSG_TYP_UNI:
                  sts->uniTx++;
                  break;

               case ST_MSG_TYP_BGN:
                  sts->bgnTx++;
                  break;

               case ST_MSG_TYP_CNT:
                  sts->cntTx++;
                  break;

               case ST_MSG_TYP_END:
                  sts->endTx++;
                  break;

               case ST_MSG_TYP_UABT:
               case ST_MSG_TYP_PABT:
                  sts->abtTx++;
                  break;

               default:
                  break;
            }
         }
         break;
      case ST_STS_RX_MSG:        /* Receive message */
         sts->msgRx++;   /* Total messages rx'd */

         if (ituFlag)
         {
            switch(msgType)
            {
               case ST_MSG_TYP_UNI:
                  sts->uniRx++;
                  break;

               case ST_MSG_TYP_BGN:
                  sts->bgnRx++;
                  break;

               case ST_MSG_TYP_CNT:
                  sts->cntRx++;
                  break;

               case ST_MSG_TYP_END:
                  sts->endRx++;
                  break;

               case ST_MSG_TYP_UABT:
               case ST_MSG_TYP_PABT:
                  sts->abtRx++;
                  break;

               default:
                  break;
            }
         }
         break;
      case ST_STS_TX_COMP:       /* Transmit component */
         sts->cmpTx++;   /* Total components tx'd */

         switch(msgType)
         {
            case ST_COMP_TYP_INV:     /* Invoke Last */

               sts->invTx++;
               break;

            case ST_COMP_TYP_RES:     /* Return Result Last */
            case ST_COMP_TYP_RNL:     /* Return Result Not Last */
               sts->resTx++;
               break;

            case ST_COMP_TYP_ERR:     /* Return Error */
               sts->errTx++;
               break;

            case ST_COMP_TYP_REJ:     /* Reject */
               sts->rejTx++;
               break;

            default:
               break;
         }
         break;
      case ST_STS_RX_COMP:       /* Receive component */
         sts->cmpRx++;   /* Total components rx'd */

         switch(msgType)
         {
            case ST_COMP_TYP_INV:     /* Invoke Last */

               sts->invRx++;
               break;

            case ST_COMP_TYP_RES:     /* Return Result Last */
            case ST_COMP_TYP_RNL:     /* Return Result Not Last */
               sts->resRx++;
               break;

            case ST_COMP_TYP_ERR:     /* Return Error */
               sts->errRx++;
               break;

            case ST_COMP_TYP_REJ:     /* Reject */
               sts->rejRx++;
               break;

            default:
               break;
         }
         break;

      default:
         break;
   }

   RETVOID;
}  /* End of stUpdRsrcSts */ 


/*
*
*       Fun:   stUpdFaultSts
*
*       Desc:  Update Fault Statistics counters
*
*       Ret:   Void
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void stUpdFaultSts
(
StSapSts *sts,       /* Upper Sap Statistics */
U8        probType,  /* problem type to update the corresponding statistics*/
U8        probCode,  /* Problem Code */
Swtch     pSwtch,    /* protocol switch */
U8        stsType    /* Rx or TX */
)
#else
PUBLIC Void stUpdFaultSts(sts, probType, probCode, pSwtch, stsType)
StSapSts *sts;       /* Upper Sap Statistics */
U8        probType;  /* problem type to update the corresponding statistics*/
U8        probCode;  /* Problem Code */
Swtch     pSwtch;    /* protocol switch */
U8        stsType;   /* Rx or TX */
#endif
{
   Bool   ituFlag;

   TRC2(stUpdFaultSts)

   /* Set the protocol flag */
   switch(pSwtch)
   {
      case LST_SW_ITU88:
      case LST_SW_ITU92:
      case LST_SW_ITU96:

         ituFlag = TRUE;
         break;

      default:
         ituFlag = FALSE;
         break;
   }

   if (stsType == ST_STS_TX_MSG)
   {
      switch(probType)
      {
         case ST_STS_FAULT:
            /* Increment the message drop counter */
            sts->drop++;

            if (ituFlag)
            {
               switch(probCode)
               {
                  case ST_PABT_UR_MSGT:    /* Unrecognized message type */
                     sts->urMsgTx.cnt++;
                     if (sts->urMsgTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->urMsgTx.first);
                     }
                     break;

                  case ST_PABT_IN_TRNP:    /* Incorrect Transaction Portion */
                     sts->inTrnTx.cnt++;
                     if (sts->inTrnTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->inTrnTx.first);
                     }
                     break;

                  case ST_PABT_BD_TRNP:    /* Badly formatted Transaction Portion */
                     sts->bdTrnTx.cnt++;
                     if (sts->bdTrnTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->bdTrnTx.first);
                     }
                     break;

                  case ST_PABT_UR_TRID:    /* Unrecognized Transaction id */
                     sts->urTidTx.cnt++;
                     if (sts->urTidTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->urTidTx.first);
                     }
                     break;

                  case ST_PABT_LM_RSRC:    /* Resource Limitation */
                     sts->rsrcLTx.cnt++;
                     if (sts->rsrcLTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->rsrcLTx.first);
                     }
                     break;

                  default:
                     break;
               }
            }
            break;
   
         case ST_PROB_TYP_GEN:
            if (ituFlag)
            {
               switch(probCode)
               {
                  case ST_GEN_UR_COMP:     /* Unrecognized component */
                     sts->urCmpTx.cnt++;
                     if (sts->urCmpTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->urCmpTx.first);
                     }
                     break;
   
                  case ST_GEN_MT_COMP:     /* Mistyped component */
                     sts->inCmpTx.cnt++;
                     if (sts->inCmpTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->inCmpTx.first);
                     }
                     break;
   
                  case ST_GEN_BD_COMP:     /* Badly structured component */
                     sts->bdCmpTx.cnt++;
                     if (sts->bdCmpTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->bdCmpTx.first);
                     }
                     break;
   
                  default:
                     break;
               }
            }
            break;
   
         case ST_PROB_TYP_INV:
            if (ituFlag)
            {
               switch(probCode)
               {
                  case ST_INV_DP_IVID:     /* Duplicate Invoke Id */
                     sts->dupIdTx.cnt++;
                     if (sts->dupIdTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->dupIdTx.first);
                     }
                     break;
   
                  case ST_INV_UR_OPRC:     /* Unrecognized Operation code */
                     sts->urOprTx.cnt++;
                     if (sts->urOprTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->urOprTx.first);
                     }
                     break;
   
                  case ST_INV_MT_PARM:     /* Mistyped parameter */
                     sts->inPrmINTx.cnt++;
                     if (sts->inPrmINTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->inPrmINTx.first);
                     }
                     break;
   
                  case ST_INV_LM_RSRC:     /* Resource limitation */
                     sts->rsrcInvTx.cnt++;
                     if (sts->rsrcInvTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->rsrcInvTx.first);
                     }
                     break;
   
                  case ST_INV_IT_RLSE:     /* Initiating Release */
                     sts->rlsInvTx.cnt++;
                     if (sts->rlsInvTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->rlsInvTx.first);
                     }
                     break;
   
                  case ST_INV_UR_LKID:     /* Unrecognized linked Id */
                     sts->urLidTx.cnt++;
                     if (sts->urLidTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->urLidTx.first);
                     }
                     break;
   
                  case ST_INV_UX_LRSP:     /* Linked response unexpected */
                     sts->uxLrspTx.cnt++;
                     if (sts->uxLrspTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->uxLrspTx.first);
                     }
                     break;
   
                  case ST_INV_UX_LOPR:     /* Unexpected linked operation */
                     sts->uxLoprTx.cnt++;
                     if (sts->uxLoprTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->uxLoprTx.first);
                     }
                     break;
   
                  default:
                     break;
               }
            }
            break;
   
         case ST_PROB_TYP_RES:
            if (ituFlag)
            {
               switch(probCode)
               {
                  case ST_RES_UR_IVID:     /* Unrecognized Invoke Id */
                     sts->urIidRRTx.cnt++;
                     if (sts->urIidRRTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->urIidRRTx.first);
                     }
                     break;
   
                  case ST_RES_UX_RRES:     /* Return result unexpected */
                     sts->uxResTx.cnt++;
                     if (sts->uxResTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->uxResTx.first);
                     }
                     break;
   
                  case ST_RES_MT_PARM:     /* Return result mistyped parameter */
                     sts->inPrmRRTx.cnt++;
                     if (sts->inPrmRRTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->inPrmRRTx.first);
                     }
                     break;
   
               }
            }
            break;
   
         case ST_PROB_TYP_ERR:
            if (ituFlag)
            {
               switch(probCode)
               {
                  case ST_ERR_UR_IVID:     /* Unerecognized Invoke Id */
                     sts->urIidRETx.cnt++;
                     if (sts->urIidRETx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->urIidRETx.first);
                     }
                     break;
   
                  case ST_ERR_UX_RERR:     /* Unexpected return error Code */
                     sts->uxEcdTx.cnt++;
                     if (sts->uxEcdTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->uxEcdTx.first);
                     }
                     break;
   
                  case ST_ERR_UR_ERRC:     /* Unrecgnized error */
                     sts->urErrTx.cnt++;
                     if (sts->urErrTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->urErrTx.first);
                     }
                     break;
   
                  case ST_ERR_UX_ERRC:     /* Unexpected error */
                     sts->uxErrTx.cnt++;
                     if (sts->uxErrTx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->uxErrTx.first);
                     }
                     break;
   
                  case ST_ERR_MT_PARM:     /* Mistyped parameter */ 
                     sts->inPrmRETx.cnt++;
                     if (sts->inPrmRETx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->inPrmRETx.first);
                     }
                     break;
   
                  default:
                     break;
               }
            }
            break;


         default:
            break;
      }
   }
   else
   {
      switch(probType)
      {
         case ST_STS_FAULT:
            if (ituFlag)
            {
               switch(probCode)
               {
                  case ST_PABT_UR_MSGT:    /* Unrecognized message type */
                     sts->urMsgRx.cnt++;
                     if (sts->urMsgRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->urMsgRx.first);
                     }
                     break;

                  case ST_PABT_IN_TRNP:    /* Incorrect Transaction Portion */
                     sts->inTrnRx.cnt++;
                     if (sts->inTrnRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->inTrnRx.first);
                     }
                     break;

                  case ST_PABT_BD_TRNP:    /* Badly formatted Transaction Portion */
                     sts->bdTrnRx.cnt++;
                     if (sts->bdTrnRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->bdTrnRx.first);
                     }
                     break;

                  case ST_PABT_UR_TRID:    /* Unrecognized Transaction id */
                     sts->urTidRx.cnt++;
                     if (sts->urTidRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->urTidRx.first);
                     }
                     break;

                  case ST_PABT_LM_RSRC:    /* Resource Limitation */
                     sts->rsrcLRx.cnt++;
                     if (sts->rsrcLRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->rsrcLRx.first);
                     }
                     break;

                  default:
                     break;
               }
            }
            break;
   
         case ST_PROB_TYP_GEN:
            if (ituFlag)
            {
               switch(probCode)
               {
                  case ST_GEN_UR_COMP:     /* Unrecognized component */
                     sts->urCmpRx.cnt++;
                     if (sts->urCmpRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->urCmpRx.first);
                     }
                     break;
   
                  case ST_GEN_MT_COMP:     /* Mistyped component */
                     sts->inCmpRx.cnt++;
                     if (sts->inCmpRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->inCmpRx.first);
                     }
                     break;
   
                  case ST_GEN_BD_COMP:     /* Badly structured component */
                     sts->bdCmpRx.cnt++;
                     if (sts->bdCmpRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->bdCmpRx.first);
                     }
                     break;
   
                  default:
                     break;
               }
            }
            break;
   
         case ST_PROB_TYP_INV:
            if (ituFlag)
            {
               switch(probCode)
               {
                  case ST_INV_DP_IVID:     /* Duplicate Invoke Id */
                     sts->dupIdRx.cnt++;
                     if (sts->dupIdRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->dupIdRx.first);
                     }
                     break;
   
                  case ST_INV_UR_OPRC:     /* Unrecognized Operation code */
                     sts->urOprRx.cnt++;
                     if (sts->urOprRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->urOprRx.first);
                     }
                     break;
   
                  case ST_INV_MT_PARM:     /* Mistyped parameter */
                     sts->inPrmINRx.cnt++;
                     if (sts->inPrmINRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->inPrmINRx.first);
                     }
                     break;
   
                  case ST_INV_LM_RSRC:     /* Resource limitation */
                     sts->rsrcInvRx.cnt++;
                     if (sts->rsrcInvRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->rsrcInvRx.first);
                     }
                     break;
   
                  case ST_INV_IT_RLSE:     /* Initiating Release */
                     sts->rlsInvRx.cnt++;
                     if (sts->rlsInvRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->rlsInvRx.first);
                     }
                     break;
   
                  case ST_INV_UR_LKID:     /* Unrecognized linked Id */
                     sts->urLidRx.cnt++;
                     if (sts->urLidRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->urLidRx.first);
                     }
                     break;
   
                  case ST_INV_UX_LRSP:     /* Linked response unexpected */
                     sts->uxLrspRx.cnt++;
                     if (sts->uxLrspRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->uxLrspRx.first);
                     }
                     break;
   
                  case ST_INV_UX_LOPR:     /* Unexpected linked operation */
                     sts->uxLoprRx.cnt++;
                     if (sts->uxLoprRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->uxLoprRx.first);
                     }
                     break;
   
                  default:
                     break;
               }
            }
            break;
   
         case ST_PROB_TYP_RES:
            if (ituFlag)
            {
               switch(probCode)
               {
                  case ST_RES_UR_IVID:     /* Unrecognized Invoke Id */
                     sts->urIidRRRx.cnt++;
                     if (sts->urIidRRRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->urIidRRRx.first);
                     }
                     break;
   
                  case ST_RES_UX_RRES:     /* Return result unexpected */
                     sts->uxResRx.cnt++;
                     if (sts->uxResRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->uxResRx.first);
                     }
                     break;
   
                  case ST_RES_MT_PARM:     /* Return result mistyped parameter */
                     sts->inPrmRRRx.cnt++;
                     if (sts->inPrmRRRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->inPrmRRRx.first);
                     }
                     break;
   
               }
            }
            break;
   
         case ST_PROB_TYP_ERR:
            if (ituFlag)
            {
               switch(probCode)
               {
                  case ST_ERR_UR_IVID:     /* Unerecognized Invoke Id */
                     sts->urIidRERx.cnt++;
                     if (sts->urIidRERx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->urIidRERx.first);
                     }
                     break;
   
                  case ST_ERR_UX_RERR:     /* Unexpected return error Code */
                     sts->uxEcdRx.cnt++;
                     if (sts->uxEcdRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->uxEcdRx.first);
                     }
                     break;
   
                  case ST_ERR_UR_ERRC:     /* Unrecgnized error */
                     sts->urErrRx.cnt++;
                     if (sts->urErrRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->urErrRx.first);
                     }
                     break;
   
                  case ST_ERR_UX_ERRC:     /* Unexpected error */
                     sts->uxErrRx.cnt++;
                     if (sts->uxErrRx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->uxErrRx.first);
                     }
                     break;
   
                  case ST_ERR_MT_PARM:     /* Mistyped parameter */ 
                     sts->inPrmRERx.cnt++;
                     if (sts->inPrmRERx.first == (Ticks)0)
                     {
                        SGetSysTime(&sts->inPrmRERx.first);
                     }
                     break;
   
                  default:
                     break;
               }
            }
            break;


         default:
            break;
      } /* End of switch */
   } /* End of else */

   RETVOID;
}  /* End of stUpdFaultSts */


/*
*
*       Fun:   stCpyItuCompEv
*
*       Desc:  Copy the Component event structure passed by the TC-User 
*              to the new style component event structure or vise versa.
*
*       Ret:   ROK - if all parameters are valid
*              RFAILED - if any parameter is invalid
*
*       Notes: If order is M1M2: Copy oCompEv to nCompEv.
*              If order is M2M1: Copy nCompEv to oCompEv.
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 stCpyItuCompEv
(
StComps     *oCompEv,    /* Comp event structure passed by the TC-User */
StItuCompEv *nCompEv,    /* New Style Comp event structure */
Buffer     **cpBuf,      /* Component Parameters Buffer */ 
Order        order       /* Order */
)
#else
PUBLIC S16 stCpyItuCompEv(oCompEv, nCompEv, cpBuf, order)
StComps     *oCompEv;    /* Comp event structure passed by the TC-User */
StItuCompEv *nCompEv;    /* New Style Comp event structure */
Buffer     **cpBuf;      /* Component Parameters Buffer */ 
Order        order;      /* Order */
#endif
{

   TRC2(stCpyItuCompEv)
   
   if (order == M1M2)
   {
      if (*cpBuf != NULLP)
      {
         MsgLen    bufLen;

         (Void)SFndLenMsg(*cpBuf, &bufLen);
         if (bufLen == 0)
         {
            /* st027.301 - Modify - Modify the user buf free mechanism */ 
            STFREEUSERBUF(*cpBuf);
            *cpBuf = NULLP;
         }
      }

      /* Initialize the event structure */
      cmZero((Data *)nCompEv, sizeof(StItuCompEv));

      nCompEv->compType.pres = TRUE;

      switch(oCompEv->stCompType)
      {
         case STU_INVOKE:

            nCompEv->compType.val           = ST_COMP_TYP_INV; 
            nCompEv->comp.inv.pres.pres     = TRUE;
            nCompEv->comp.inv.invokeId.pres = oCompEv->stInvokeId.pres;
            nCompEv->comp.inv.invokeId.val  = oCompEv->stInvokeId.octet;
            nCompEv->comp.inv.linkedId.pres = oCompEv->stLinkedId.pres;
            nCompEv->comp.inv.linkedId.val  = oCompEv->stLinkedId.octet;
            nCompEv->comp.inv.oprType.pres  = TRUE;
            nCompEv->comp.inv.oprType.val   = oCompEv->stOpCodeFlg;
            nCompEv->comp.inv.oprCode.pres  = TRUE;
            nCompEv->comp.inv.oprCode.len   = (U8)oCompEv->stOpCode.len;

            ST_CPY_STR(nCompEv->comp.inv.oprCode.val, oCompEv->stOpCode.string,
                       oCompEv->stOpCode.len);

            if (*cpBuf != NULLP)
            {
               nCompEv->comp.inv.params.pres  = TRUE;
               nCompEv->comp.inv.params.val   = *cpBuf;
            }
            /* Validate the operation class */
            switch(oCompEv->opClass)
            {
               case 1:
               case 2:
               case 3:
               case 4:
                  break;
               default:
                  /* st009.301 -Add- Debug prints */
                  STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                         "stCpyItuCompEv:Unknown operation(%d)\n",
                         oCompEv->opClass));
                  RETVALUE(RFAILED);
            }
            break;

         case STU_RET_RES_L:
         case STU_RET_RES_NL:

            nCompEv->compType.val        = ST_COMP_TYP_RES; 

            if (oCompEv->stCompType == STU_RET_RES_NL)
            {
               nCompEv->compType.val     = ST_COMP_TYP_RNL; 
            }

            nCompEv->comp.res.pres.pres     = TRUE;
            nCompEv->comp.res.invokeId.pres = oCompEv->stInvokeId.pres;
            nCompEv->comp.res.invokeId.val  = oCompEv->stInvokeId.octet;

            if (*cpBuf != NULLP)
            {
               nCompEv->comp.res.seqPres.pres  = TRUE;
               nCompEv->comp.res.oprType.pres  = TRUE;
               nCompEv->comp.res.oprType.val   = oCompEv->stOpCodeFlg;
               nCompEv->comp.res.oprCode.pres  = TRUE;
               nCompEv->comp.res.oprCode.len   = (U8)oCompEv->stOpCode.len;

               ST_CPY_STR(nCompEv->comp.res.oprCode.val,
                          oCompEv->stOpCode.string, oCompEv->stOpCode.len);

               nCompEv->comp.res.params.pres  = TRUE;
               nCompEv->comp.res.params.val   = *cpBuf;
            }
            break;

         case STU_RET_ERR:

            nCompEv->compType.val           = ST_COMP_TYP_ERR;
            nCompEv->comp.err.pres.pres     = TRUE;
            nCompEv->comp.err.invokeId.pres = oCompEv->stInvokeId.pres;
            nCompEv->comp.err.invokeId.val  = oCompEv->stInvokeId.octet;
            nCompEv->comp.err.errType.pres  = TRUE;
            nCompEv->comp.err.errType.val   = oCompEv->stErrorCodeFlg;
            nCompEv->comp.err.errCode.pres  = TRUE;
            nCompEv->comp.err.errCode.len   = (U8)oCompEv->stErrorCode.len;

            ST_CPY_STR(nCompEv->comp.err.errCode.val, oCompEv->stErrorCode.string,
                       oCompEv->stErrorCode.len);

            if (*cpBuf != NULLP)
            {
               nCompEv->comp.err.params.pres  = TRUE;
               nCompEv->comp.err.params.val   = *cpBuf;
            }
            break;

         case STU_REJECT:

            nCompEv->compType.val           = ST_COMP_TYP_REJ;
            nCompEv->comp.rej.pres.pres     = TRUE;
            nCompEv->comp.rej.invNull.pres  = TRUE;
            if (oCompEv->stInvokeId.pres)
            {
               /* Invoke Id is present */
               nCompEv->comp.rej.invNull.val = ST_REJ_INV_ID;
            }
            else
            {
               /* Invoke Id not present, encode a NULL instead */
               nCompEv->comp.rej.invNull.val = ST_REJ_INV_NULL;
            }
            nCompEv->comp.rej.invokeId.pres = oCompEv->stInvokeId.pres;
            nCompEv->comp.rej.invokeId.val  = oCompEv->stInvokeId.octet;
            nCompEv->comp.rej.probType.pres = TRUE;

            switch(oCompEv->stProbCodeFlg)
            {
               case STU_PROB_GENERAL:
                  nCompEv->comp.rej.probType.val  = ST_PROB_TYP_GEN;
                  break;

               case STU_PROB_INVOKE:
                  nCompEv->comp.rej.probType.val  = ST_PROB_TYP_INV;
                  break;

               case STU_PROB_RET_RES:
                  nCompEv->comp.rej.probType.val  = ST_PROB_TYP_RES;
                  break;

               case STU_PROB_RET_ERR:
                  nCompEv->comp.rej.probType.val  = ST_PROB_TYP_ERR;
                  break;

               default:
                  nCompEv->comp.rej.probType.pres = FALSE;
                  break;
            }

            nCompEv->comp.rej.probCode.pres = TRUE;
            nCompEv->comp.rej.probCode.val  = oCompEv->stProbCode.string[0];
            break;

         default:
            /* st009.301 -Add- Debug prints */
            STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                   "stCpyItuCompEv:Unknown component type(%d)\n",
                    oCompEv->stCompType));
            RETVALUE(RFAILED);
      }
   }
   else
   {
      /* Initialize the event structure */
      cmZero((Data *)oCompEv, sizeof(StComps));

      switch(nCompEv->compType.val)
      {
         case ST_COMP_TYP_INV:

            oCompEv->stCompType       = STU_INVOKE;
            oCompEv->stInvokeId.pres  = nCompEv->comp.inv.invokeId.pres;
            oCompEv->stInvokeId.octet = nCompEv->comp.inv.invokeId.val;
            oCompEv->stLinkedId.pres  = nCompEv->comp.inv.linkedId.pres;
            oCompEv->stLinkedId.octet = nCompEv->comp.inv.linkedId.val;
            oCompEv->stOpCodeFlg      = nCompEv->comp.inv.oprType.val;
            oCompEv->stOpCode.len     = nCompEv->comp.inv.oprCode.len;

            ST_CPY_STR(oCompEv->stOpCode.string,
                       nCompEv->comp.inv.oprCode.val,
                       oCompEv->stOpCode.len);

            *cpBuf = nCompEv->comp.inv.params.val;
            break;

         case ST_COMP_TYP_RES:
         case ST_COMP_TYP_RNL:

            oCompEv->stCompType       = STU_RET_RES_L;
            if (nCompEv->compType.val  == ST_COMP_TYP_RNL)
            {
               oCompEv->stCompType    = STU_RET_RES_NL;
            }
            oCompEv->stInvokeId.pres  = nCompEv->comp.res.invokeId.pres;
            oCompEv->stInvokeId.octet = nCompEv->comp.res.invokeId.val;
            oCompEv->stOpCodeFlg      = nCompEv->comp.res.oprType.val;
            oCompEv->stOpCode.len     = nCompEv->comp.res.oprCode.len;

            ST_CPY_STR(oCompEv->stOpCode.string, nCompEv->comp.res.oprCode.val,
                       oCompEv->stOpCode.len);

            *cpBuf = nCompEv->comp.res.params.val;
            break;

         case ST_COMP_TYP_ERR:

            oCompEv->stCompType       = STU_RET_ERR;
            oCompEv->stInvokeId.pres  = nCompEv->comp.err.invokeId.pres;
            oCompEv->stInvokeId.octet = nCompEv->comp.err.invokeId.val;
            oCompEv->stErrorCodeFlg   = nCompEv->comp.err.errType.val;
            oCompEv->stErrorCode.len  = nCompEv->comp.err.errCode.len;

            ST_CPY_STR(oCompEv->stErrorCode.string,
                       nCompEv->comp.err.errCode.val,
                       oCompEv->stErrorCode.len);

            *cpBuf = nCompEv->comp.err.params.val;
            break;

         case ST_COMP_TYP_REJ:

            oCompEv->stCompType       = STU_REJECT;
            oCompEv->stInvokeId.pres  = nCompEv->comp.rej.invokeId.pres;
            oCompEv->stInvokeId.octet = nCompEv->comp.rej.invokeId.val;

            switch(nCompEv->comp.rej.probType.val)
            {
               case ST_PROB_TYP_GEN:
                  oCompEv->stProbCodeFlg = STU_PROB_GENERAL;
                  break;

               case ST_PROB_TYP_INV:
                  oCompEv->stProbCodeFlg = STU_PROB_INVOKE;
                  break;

               case ST_PROB_TYP_RES:
                  oCompEv->stProbCodeFlg = STU_PROB_RET_RES;
                  break;

               case ST_PROB_TYP_ERR:
                  oCompEv->stProbCodeFlg = STU_PROB_RET_ERR;
                  break;

               default:
                  oCompEv->stProbCodeFlg = STU_PROB_NONE;
                  break;
            }

            oCompEv->stProbCode.len   = 1;
            oCompEv->stProbCode.string[0] = nCompEv->comp.rej.probCode.val;
            break;

         default:
            /* st009.301 -Add- Debug prints */
            STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                   "stCpyItuCompEv:Unknown component type(%d)\n",
                    nCompEv->compType.val));
            RETVALUE(RFAILED);
      }
   }
      
   RETVALUE(ROK);
}  /* End of stCpyItuCompEv */



/*
*
*       Fun:   stCpyItuDlgEv
*
*       Desc:  Copy the Dialogue event structure passed by the TC-User 
*              to the new style Dialogue event structure or vise versa.
*
*       Ret:   Void
*
*       Notes: If order is M1M2: Copy oldDlgEv to newDlgEv.
*              If order is M2M1: Copy newDlgEv to oldDlgEv.
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void stCpyItuDlgEv
(
StDlgEv     *oldDlgEv,     /* Dlg event structure passed by the TC-User */
StItuDlgEv  *newDlgEv,     /* New Style Dlg event structure */
Buffer     **usrInfo,      /* User Information */ 
Order        order         /* Order */
)
#else
PUBLIC Void stCpyItuDlgEv(oldDlgEv, newDlgEv, usrInfo, order)
StDlgEv     *oldDlgEv;     /* Dlg event structure passed by the TC-User */
StItuDlgEv  *newDlgEv;     /* New Style Dlg event structure */
Buffer     **usrInfo;      /* User Information */ 
Order        order;        /* Order */
#endif
{

   TRC2(stCpyItuDlgEv)

   if (order == M1M2)
   {
      /* Copy from old type event structure to new type event structure */

      /* Initialize the event structure */
      cmZero((Data *)newDlgEv, sizeof(StItuDlgEv));

      /* In dialogue event not present, returns back */
      if (!oldDlgEv->pres)
      {
         RETVOID;
      }

      newDlgEv->pres.pres         = TRUE;
      newDlgEv->exPres.pres       = TRUE;

      newDlgEv->dlgAsIdVal.pres   = TRUE;
      newDlgEv->dlgAsIdVal.len    = 7;
      newDlgEv->dlgAsIdVal.val[0] = (U16) ST_DLG_ID_VAL_B0;
      newDlgEv->dlgAsIdVal.val[1] = (U16) ST_DLG_ID_VAL_B1;
      newDlgEv->dlgAsIdVal.val[2] = (U16) ST_DLG_ID_VAL_B2;
      newDlgEv->dlgAsIdVal.val[3] = (U16) ST_DLG_ID_VAL_B3;
      newDlgEv->dlgAsIdVal.val[4] = (U16) ST_DLG_ID_VAL_B4;

      if (oldDlgEv->stDlgType == STU_DLGP_UNI)
      {
         newDlgEv->dlgAsIdVal.val[5] = (U16) ST_DLG_ID_VAL_B5_U;
      }
      else
      {
         newDlgEv->dlgAsIdVal.val[5] = (U16) ST_DLG_ID_VAL_B5_S;
      }

      newDlgEv->dlgAsIdVal.val[6] = (U16) ST_DLG_ID_VAL_B6;

      newDlgEv->apduPres.pres = TRUE;
      newDlgEv->dlgApdu.dlgType.pres = TRUE;

      if (oldDlgEv->stDlgType != STU_DLGP_ABT)
      {
         newDlgEv->dlgApdu.apdu.uni.pres.pres    = TRUE;
         newDlgEv->dlgApdu.apdu.uni.pVer.pres    = TRUE;
         newDlgEv->dlgApdu.apdu.uni.pVer.len     = 2;
         newDlgEv->dlgApdu.apdu.uni.pVer.val[0]  = ST_ITU_PVER_B0;
         newDlgEv->dlgApdu.apdu.uni.pVer.val[1]  = ST_ITU_PVER_B1;

         if (oldDlgEv->apConName.len != 0)
         {
            newDlgEv->dlgApdu.apdu.uni.acnPres.pres = TRUE;
            newDlgEv->dlgApdu.apdu.uni.acn.pres  = TRUE;
            newDlgEv->dlgApdu.apdu.uni.acn.len   = (U8)oldDlgEv->apConName.len;

            ST_CPY_STR(newDlgEv->dlgApdu.apdu.uni.acn.val, 
                       oldDlgEv->apConName.string,
                       oldDlgEv->apConName.len);
         }
      }

      switch(oldDlgEv->stDlgType)
      {
         case STU_DLGP_UNI:
            newDlgEv->dlgApdu.dlgType.val = ST_DLG_TYP_UNI;

            if (*usrInfo != NULLP)
            {
               newDlgEv->dlgApdu.apdu.uni.usrInfo.pres = TRUE;
               newDlgEv->dlgApdu.apdu.uni.usrInfo.val  = *usrInfo;
            }
            break;

         case STU_DLGP_REQ:
            newDlgEv->dlgApdu.dlgType.val = ST_DLG_TYP_REQ;

            if (*usrInfo != NULLP)
            {
               newDlgEv->dlgApdu.apdu.req.usrInfo.pres = TRUE;
               newDlgEv->dlgApdu.apdu.req.usrInfo.val  = *usrInfo;
            }
            break;

         case STU_DLGP_RSP:
            newDlgEv->dlgApdu.dlgType.val = ST_DLG_TYP_RSP;

            if (oldDlgEv->resPres)
            {
               newDlgEv->dlgApdu.apdu.rsp.resPres.pres  = TRUE;
               newDlgEv->dlgApdu.apdu.rsp.result.pres   = TRUE;
               newDlgEv->dlgApdu.apdu.rsp.result.val    = oldDlgEv->result;
               newDlgEv->dlgApdu.apdu.rsp.diagPres.pres = TRUE;
               newDlgEv->dlgApdu.apdu.rsp.resSrc.pres   = TRUE;
               newDlgEv->dlgApdu.apdu.rsp.resSrc.val    = oldDlgEv->resSrc;
               newDlgEv->dlgApdu.apdu.rsp.reason.pres   = TRUE;
               newDlgEv->dlgApdu.apdu.rsp.reason.val    = oldDlgEv->resReason;
            }

            if (*usrInfo != NULLP)
            {
               newDlgEv->dlgApdu.apdu.rsp.usrInfo.pres = TRUE;
               newDlgEv->dlgApdu.apdu.rsp.usrInfo.val  = *usrInfo;
            }
            break;

         case STU_DLGP_ABT:
            newDlgEv->dlgApdu.dlgType.val = ST_DLG_TYP_ABT;
            newDlgEv->dlgApdu.apdu.abt.abrtSrc.pres = TRUE;
            newDlgEv->dlgApdu.apdu.abt.abrtSrc.val  = oldDlgEv->abrtSrc;

            if (*usrInfo != NULLP)
            {
               newDlgEv->dlgApdu.apdu.abt.usrInfo.pres = TRUE;
               newDlgEv->dlgApdu.apdu.abt.usrInfo.val  = *usrInfo;
            }
            break;
      }

   }
   else
   {
      /* Copy from new type event structure to old type event structure */

      /* Initialize the event structure */
      cmZero((Data *)oldDlgEv, sizeof(StDlgEv));

      /* If dialogue event is not present, returns back */
      if (!newDlgEv->pres.pres)
      {
         RETVOID;
      }

      oldDlgEv->pres = TRUE;

      if (newDlgEv->dlgApdu.dlgType.val != ST_DLG_TYP_ABT)
      {
         if (newDlgEv->dlgApdu.apdu.uni.acn.pres)
         {
            oldDlgEv->apConName.len = newDlgEv->dlgApdu.apdu.uni.acn.len;

            ST_CPY_STR(oldDlgEv->apConName.string,
                       newDlgEv->dlgApdu.apdu.uni.acn.val,
                       newDlgEv->dlgApdu.apdu.uni.acn.len);
         }
      }

      switch(newDlgEv->dlgApdu.dlgType.val)
      {
         case ST_DLG_TYP_UNI:
            oldDlgEv->stDlgType = STU_DLGP_UNI;

            if (newDlgEv->dlgApdu.apdu.uni.usrInfo.pres)
            {
               *usrInfo = newDlgEv->dlgApdu.apdu.uni.usrInfo.val;
            }
            break;

         case ST_DLG_TYP_REQ:
            oldDlgEv->stDlgType = STU_DLGP_REQ;

            if (newDlgEv->dlgApdu.apdu.req.usrInfo.pres)
            {
               *usrInfo = newDlgEv->dlgApdu.apdu.req.usrInfo.val;
            }
            break;

         case ST_DLG_TYP_RSP:
            oldDlgEv->stDlgType = STU_DLGP_RSP;

            if (newDlgEv->dlgApdu.apdu.rsp.result.pres)
            {
               oldDlgEv->resPres   = TRUE;
               oldDlgEv->result    = newDlgEv->dlgApdu.apdu.rsp.result.val;
               oldDlgEv->resSrc    = newDlgEv->dlgApdu.apdu.rsp.resSrc.val;
               oldDlgEv->resReason = newDlgEv->dlgApdu.apdu.rsp.reason.val;
            }

            switch (newDlgEv->dlgApdu.apdu.rsp.resSrc.val)
            {
               case ST_RES_SRC_SU: oldDlgEv->resSrc = ST_DLG_SU_TAG; break;
               case ST_RES_SRC_SP: oldDlgEv->resSrc = ST_DLG_SP_TAG; break;
            }

            if (newDlgEv->dlgApdu.apdu.rsp.usrInfo.pres)
            {
               *usrInfo = newDlgEv->dlgApdu.apdu.rsp.usrInfo.val;
            }
            break;

         case ST_DLG_TYP_ABT:
            oldDlgEv->stDlgType = ST_DLG_TYP_ABT;
            oldDlgEv->abrtSrc   = newDlgEv->dlgApdu.apdu.abt.abrtSrc.val;

            if (newDlgEv->dlgApdu.apdu.abt.usrInfo.pres)
            {
               *usrInfo = newDlgEv->dlgApdu.apdu.abt.usrInfo.val;
            }
            break;

         default:
            break;
      }

   }

   RETVOID;
}  /* End of stCpyItuDlgEv */


/*
*
*       Fun:   stGetDateTimeDura
*
*       Desc:  Get the time duration in DateTime structure firmat
*
*       Ret:   Void
*
*       Notes: None
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 stGetDateTimeDura
(
DateTime    *curDt,       /* Current Date */
DateTime    *lstDt,       /* Last Date */
Duration    *durDt        /* Duration */
)
#else
PUBLIC S16 stGetDateTimeDura(curDt, lstDt, durDt)
DateTime    *curDt;       /* Current Date */
DateTime    *lstDt;       /* Last Date */
Duration    *durDt;       /* Duration */
#endif
{
   TRC2(stGetDateTimeDura)

   if (curDt->tenths < lstDt->tenths)
   {
      curDt->sec--;
      curDt->tenths += 10;
   }
   if (curDt->sec < lstDt->sec)
   {
      curDt->min--;
      curDt->sec += 60;
   }
   if (curDt->min < lstDt->min)
   {
      curDt->hour--;
      curDt->min += 60;
   }
   if (curDt->hour < lstDt->hour)
   {
      curDt->day--;
      curDt->hour += 24;
   }
   if (curDt->day < lstDt->day)
   {
      curDt->month--;
      curDt->day += 30;
   }

   durDt->tenths = curDt->tenths - lstDt->tenths;
   durDt->secs   = curDt->sec    - lstDt->sec;
   durDt->mins   = curDt->min    - lstDt->min;
   durDt->hours  = curDt->hour   - lstDt->hour;
   durDt->days   = curDt->day    - lstDt->day;

   RETVALUE(ROK);
} /* End of stGetDateTimeDura */


/*
*
*       Fun:   stRunAudits
*
*       Desc:  Run the Audit procedure.
*
*       Ret:   Void
*
*       Notes: This function release the resources allocated to the
*              control blocks which haven't been accessed for more than
*              'expTime' time. These resources are assumed to be hanging
*               ones and thus are deleted.
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void stRunAudits
(
SpId         spId,         /* SAP Id */
U8           cbType,       /* Control block type */
U32          nmbCb,        /* Number of control blocks if not all */
Ticks        expTime       /* Expiry time for control blocks */
)
#else
PUBLIC Void stRunAudits(spId, cbType, nmbCb, expTime)
SpId         spId;         /* SAP Id */
U8           cbType;       /* Control block type */
U32          nmbCb;        /* Number of control blocks if not all */
Ticks        expTime;      /* Expiry time for control blocks */
#endif
{
   StTUSap   *sapCp;
   StDlgCp   *dlgCp;
   StInvCp   *invCp;
   PTR        lastDlgEnt;
   PTR        lastInvEnt;
   Ticks      curTime;
   Bool       updFlag;
   U32        cbCount;
   Bool       dlgFlag;     /* If dialogues control blockes are to be deleted */
   Bool       invFlag;     /* If invoke control blockes are to be deleted */
   Bool       allFlag;     /* If all unused control blocks are to be deleted */

   TRC2(stRunAudits)

   sapCp = stCb.tuSapLst[spId];

   cbCount = 0;

   /* Get the current time */
   SGetSysTime(&curTime);

   updFlag = FALSE;
   lastDlgEnt = NULLP;

   /* By default delete all control blocks */
   dlgFlag = TRUE;
   invFlag = TRUE;
   allFlag = TRUE;

   switch(cbType)
   {
      case LST_AUDIT_ALL_DLG:
         invFlag = FALSE;
         break;

      case LST_AUDIT_ALL_INV:
         dlgFlag = FALSE;
         break;

      case LST_AUDIT_PAR_DLG:
         allFlag = FALSE;
         invFlag = FALSE;
         break;

      case LST_AUDIT_PAR_INV:
         allFlag = FALSE;
         dlgFlag = FALSE;
         break;

      case LST_AUDIT_PAR_CB:
         allFlag = FALSE;
         break;

      case LST_AUDIT_ALL_CB:
         break;
   }

   while ( cmHashListGetNext(&sapCp->dlgHlCp, lastDlgEnt,
                             (PTR *)&dlgCp) == ROK )
   {
      /* If only some of the control blocka are to be deleted and that count
         has reached then return from here */
      if ((!allFlag) && (cbCount >= nmbCb))
      {
         RETVOID;
      }

      /* If the dialogue control point was last updated `expTime` before
         then assume it to unused and delete the dialogue */

/* st041.301 - Modify - Assign LastDlgEnt to dlgCp in case Dlg has not expired */ 
      if (dlgFlag) 
      {
         if((curTime - dlgCp->tmStmp) >  expTime)
         {
#ifdef ZT
            ztRunTimeUpd(ZT_DLG_CB,
                         CMPFTHA_UPDTYPE_NORMAL,
                         CMPFTHA_ACTN_DEL,
                         (Void *)dlgCp);
#endif /* ZT */
            updFlag = TRUE;
            cbCount++;
            (Void)stFreeDlg(dlgCp);
         }
         else
         {
            lastDlgEnt = (PTR)dlgCp;
         }
      }
      else if (invFlag)
      {
         lastDlgEnt = (PTR)dlgCp;
         lastInvEnt = NULLP;

         while ( cmHashListGetNext(&dlgCp->invHlCp, lastInvEnt,
                                   (PTR *)&invCp) == ROK )
         {
            if ((curTime - invCp->tmStmp) >  expTime)
            {
#ifdef ZT
               ztRunTimeUpd(ZT_INV_CB,
                            CMPFTHA_UPDTYPE_NORMAL,
                            CMPFTHA_ACTN_DEL,
                            (Void *)invCp);
#endif /* ZT */
               updFlag = TRUE;
               cbCount++;
               (Void)stFreeInv(invCp);
            }
            else
            {
               lastInvEnt = (PTR)invCp;
            }
         }
      }
#ifdef ZT
      if (updFlag)
      {
         ztUpdPeer();
      }
#endif /* ZT */
   }

   RETVOID;
} /* End of stRunAudits */

 /* st005.301 - Added- Rolling Upgrade feature */
#ifdef ST_RUG

/*
*
*       Fun  :  Get Interface Version handling
*
*       Desc :  Processes system agent control request primitive to 
*               get interface version.
*
*       Ret  :  ROK  - ok
*
*       Notes:  None
*
*       File :  ct_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 stGetVer
(
ShtGetVerCfm *getVerCfmInfo    /* to return interface version information */
)
#else
PUBLIC S16 stGetVer(getVerCfmInfo)
ShtGetVerCfm *getVerCfmInfo;  /* to return interface version information */
#endif
{
   TRC2(stGetVer)

   /* Fill list of upper interfaces IDs and their version number */
   getVerCfmInfo->numUif = 1;
   getVerCfmInfo->uifList[0].intfId  = STUIF;
   getVerCfmInfo->uifList[0].intfVer = STUIFVER;
     
   /* Fill list of lower interfaces IDs and their version number */
   getVerCfmInfo->numLif = 1;
   getVerCfmInfo->lifList[0].intfId  = SPTIF;
   getVerCfmInfo->lifList[0].intfVer = SPTIFVER;
            
#ifdef ZT  /* If FTHA/DFTHA layer */ 
   /* Fill peer interfaces ID and version number */
   
   ztGetVer(&(getVerCfmInfo->pif));
  
#endif /* ifdef ZT */

    RETVALUE(ROK);
}
/* st023.301 - Modification */
#endif /* ST_RUG */
 
 /* st005.301 - Added- Rolling Upgrade feature */
#ifdef ST_RUG

/*
*
*       Fun  :  Set Interface Version handling
*
*       Desc :  Processes system agent control request primitive to 
*               set interface version.
*
*       Ret  :  ROK  - ok
*
*       Notes:  None
*
*       File :  ct_bdy4.c
*
*/

#ifdef ANSI
PUBLIC Void stSetVer
(
ShtVerInfo *setVerInf,   /* to return interface version information */
CmStatus  *status
)
#else
PUBLIC Void stSetVer(setVerInf,status)
ShtVerInfo *setVerInf;  /* to return interface version information */
CmStatus  *status;
#endif 
{
   Bool       found;        /* used for searching */
   U16        i, counter;   /* Counters */
   ShtVerInfo *intfInf;     /* Pointer to interface version info */
   StTUSap    *tuSapCp;     /* pointer to upper SAP */
   StSPSap    *spSapCp;     /* pointer to lower SAP */

   TRC2(stSetVer)

   /* Initialize variables */
   found = FALSE;
   status->reason = LCM_REASON_NOT_APPL;

#ifdef ZT
   /* See if this is applicable to PSF       *
    * If PSF says it is not applicable (RNA) *
    * we analyze further                     */

   if(ztSetVer(&setVerInf->intf, status) != RNA)
   {
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stSetVer:PSF set version failed\n"));
      RETVOID;
   }  
#endif

   /* Validate version info */
   stChkVer(setVerInf->intf.intfId, setVerInf->intf.intfVer, status);   

   if(status->reason != LCM_REASON_NOT_APPL )
   {
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stSetVer:Version information not valid\n"));
      RETVOID;
   }   

   /* validate grptype */
   if ((setVerInf->grpType != SHT_GRPTYPE_ALL) &&
         (setVerInf->grpType != SHT_GRPTYPE_ENT))
   {
      status->reason = LCM_REASON_INVALID_PAR_VAL;
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stSetVer:Group type in version info structure not correct\n"));
      RETVOID;
   }

   /* See if stored information already exists */
   for(i=0; ((i < stCb.numIntfInfo) && (found == FALSE)); i++)
   {
      /* Get the  interface info from TCAP control block */  
      intfInf = &stCb.intfInfo[i];
      if(intfInf->intf.intfId == setVerInf->intf.intfId)
      {
         if(intfInf->grpType == setVerInf->grpType)
         {
            /* Store new version information specified in 
             *  this set version request  */
            switch(setVerInf->grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if ((intfInf->dstProcId == setVerInf->dstProcId) &&
                      (intfInf->dstEnt.ent == setVerInf->dstEnt.ent) &&
                      (intfInf->dstEnt.inst == setVerInf->dstEnt.inst))
                  {
                     intfInf->intf.intfVer = setVerInf->intf.intfVer;
                     found = TRUE;
                  }
                  break;
                  
               case SHT_GRPTYPE_ENT:
                  if ((intfInf->dstEnt.ent == setVerInf->dstEnt.ent) &&
                      (intfInf->dstEnt.inst == setVerInf->dstEnt.inst))
                  {
                     intfInf->intf.intfVer = setVerInf->intf.intfVer;
                     found = TRUE;
                  }
                  break;
            } /* Switch */
         } /* If group type matches */
      } /* If Interface Id matches */
   } /* for */

   /* In the worst case we should be required to store one version *
    * information for every configured sap in the layer.           */
   if(found == FALSE)
   {  
      /* Maximum number of upper and lower sap together
       *  is 2*stCb.genCfg.nmbSaps */

      if(stCb.numIntfInfo < 2* stCb.genCfg.nmbSaps)
      {
         /* Copy version info. to the TCAP control block */
         cmMemcpy((U8*) &stCb.intfInfo[i],(U8*)setVerInf, 
                  sizeof(ShtVerInfo));
         /* Increment total number of interface counter */ 
         stCb.numIntfInfo++;
      }
      else
      {
         /* Set error status */
         status->reason = LCM_REASON_EXCEED_CONF_VAL;
         RETVOID;
      }
   } /* if not found */
        
   /* Information in set version stored. Now update the SAPs */
   switch(setVerInf->intf.intfId)
   {
      /* Upper Interface */
      case STUIF: 
         /* Loop through all upper saps */
         for ( counter = 0; counter < stCb.genCfg.nmbSaps; ++counter )
         { 
            if ((tuSapCp = *(stCb.tuSapLst + counter)) == NULLP)
               continue;
              
            /* If it is an unbound SAP then the remote entity, instance *
             * and proc ID would not be available and hence we should   *
             * wait for bind to happen to set the remote interface ver  */

            if (tuSapCp->hlSt != ST_SAP_BND_ENBL)
               continue;

            switch(setVerInf->grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if ((tuSapCp->pstTU.dstProcId == setVerInf->dstProcId) &&
                      (tuSapCp->pstTU.dstEnt == setVerInf->dstEnt.ent)   &&
                      (tuSapCp->pstTU.dstInst == setVerInf->dstEnt.inst))
                  {
                     tuSapCp->pstTU.intfVer = setVerInf->intf.intfVer;
                     tuSapCp->remIntfValid = TRUE;
                  }
                  break;
                  
               case SHT_GRPTYPE_ENT:
                  if ((tuSapCp->pstTU.dstEnt == setVerInf->dstEnt.ent) &&
                      (tuSapCp->pstTU.dstInst == setVerInf->dstEnt.inst))
                  {     
                     tuSapCp->pstTU.intfVer = setVerInf->intf.intfVer;
                     tuSapCp->remIntfValid = TRUE;
                  }
                  break;

               default:
                  /* not possible */
                  break;
            } /* switch(setVerInf->grpType) */
         } /* End for */ 

         break; /* Case STUIF or upper interface */
         /* Lower Interface */

      case SPTIF: 
         /* Loop through all the saps */
         for ( counter = 0;counter < stCb.genCfg.nmbSaps;++counter )
         { 
            if ((spSapCp = *(stCb.spSapLst + counter)) == NULLP)
               continue;
             
            switch(setVerInf->grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if ((spSapCp->pstSP.dstProcId == setVerInf->dstProcId) &&
                      (spSapCp->pstSP.dstEnt == setVerInf->dstEnt.ent)   &&
                      (spSapCp->pstSP.dstInst == setVerInf->dstEnt.inst))
                  {
                     spSapCp->pstSP.intfVer = setVerInf->intf.intfVer;
                     spSapCp->remIntfValid = TRUE;
                  }
                  break;
                  
               case SHT_GRPTYPE_ENT:
                  if ((spSapCp->pstSP.dstEnt == setVerInf->dstEnt.ent) &&
                      (spSapCp->pstSP.dstInst == setVerInf->dstEnt.inst))
                  { 
                     spSapCp->pstSP.intfVer = setVerInf->intf.intfVer;
                     spSapCp->remIntfValid = TRUE;
                  }
                  break;

               default:
                  /* not possible */
                  break;

            } /* switch(setVerInf->grpType) */
         } /* End for */ 
         break; /* Case SPTIF or lower interface */
      default:
         /* not possible */
         break;
   } /* switch(setVerInf->intf.intfId) */
} /* End of routine */
#endif /* ifdef ST_RUG */

 
 /* st005.301 - Added- Rolling Upgrade feature */
#ifdef ST_RUG

/*
*
*       Fun  :  Check Version Info 
*
*       Desc :  Checks whether a particular interface 
*               version can be supported
*
*       Ret  :  Void
*
*       Notes:  None
*
*       File :  ct_bdy4.c
*
*/

#ifdef ANSI
PUBLIC Void stChkVer
(
CmIntfId  intfId,   /* interface ID */
CmIntfVer intfVer,  /* interface version */
CmStatus  *status   /* status after checking version info */
)
#else
PUBLIC Void stChkVer(intfId,intfVer,status)
CmIntfId  intfId;   /* interface ID */
CmIntfVer intfVer;  /* interface version */
CmStatus  *status;  /* status after checking version info */
#endif 
{  

   /* Validate Set Version Information  */
   switch(intfId)
   {
      /* Upper Interface */
      case STUIF:
         /* Check for version info, if it is lower or 
          * equal allow it, otherwise set reason value */

         if (STUIFVER < intfVer)  
            status->reason = LCM_REASON_VERSION_MISMATCH;
         break;

      /* Lower Interface */
      case SPTIF: 
         /* Check for version info, if it is lower or 
          * equal allow it, otherwise set reason value */

         if (SPTIFVER < intfVer)  
            status->reason = LCM_REASON_VERSION_MISMATCH;
         break;

      default:
         /* For unknown interface set reason value */
         status->reason = LCM_REASON_VERSION_MISMATCH;
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stChkVer:Unknown interface type(%d)\n",intfId));
         break;
   } /* switch */
} /* end function */

#endif /* ST_RUG */

 

/* st007.301 - Added - TC-User Distribution Feature  */

#ifdef ST_TC_USER_DIST

/*
*
*       Fun  :  Check Lower SAP SSN  
*
*       Desc :  Checks whether a lower SAP SSN info is valid and 
*               whether any other lower SAP has same SSN
*
*       Ret  :  ROK(Success)
*               RFAILED(failure)
*
*       Notes:  None
*
*       File :  ct_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 stCheckSPSapSSN
(
Ssn    ssn,     /* Subsystem Number */
Swtch  swtch,   /* Protocol Switch */
Reason *reason  /* Failure reason code */
)
#else
PUBLIC S16 stCheckSPSapSSN(ssn,swtch,reason)
Ssn    ssn;     /* Subsystem Number */
Swtch  swtch,   /* Protocol Switch */  
Reason *reason; /* Failure reason code */
#endif 
{
   StSPSap        *spSapCp;    /* Lower SAP pointer */
   S16            counter;     /* Loop Counter */

   TRC2(stCheckSPSapSSN)

   /* Check if the lower SAP SSN, set by LM is Ok */
   if (ssn == SS_UNKNOWN)
   {
      *reason = LST_REASON_SSN_ABSENT;
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stCheckSPSapSSN:SSN value 0 cannot be used\n"));
      RETVALUE(RFAILED);
   }

   /* Loop through the lower SAP list to check
    * whether the SSN is present in any other
    * lower SAP
    */
   for (counter = 0; counter < stCb.genCfg.nmbSaps; counter++)
   {
      if ((spSapCp = *(stCb.spSapLst + (SuId)counter)) != NULLP)
      {        
         /* Match for SSN and Protocol Switch */     
         if ((spSapCp->ssn == ssn) && (spSapCp->cfg.swtch == swtch))
         {
            *reason = LST_REASON_DUPLICATE_SSN;
            /* st009.301 -Add- Debug prints */
            STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                   "stCheckSPSapSSN:Duplicate lower SAP SSN\n"));
            RETVALUE(RFAILED);
         }
      } /* If lower SAP not NULL */   
   }
   RETVALUE(ROK);        
}

 

/* st007.301 - Added - TC-User Distribution Feature */

/*
*
*       Fun  :  Set Associated Lower SAP Id field 
*
*       Desc :  This routine searches the upper SAP list  
*               for matching lower SAP SSN, switch  
*               and sets the assocLSapId field in the upper 
*               SAP structure. Based on reset field value,
*               the routine either sets or resets the
*               assocLSapId field.
*               
*       Ret  :  None
*
*       Notes:  It is assumed that spSapId is valid
*
*       File :  ct_bdy4.c
*
*/

#ifdef ANSI
PUBLIC Void stSetAssocLSapId
(
SpId spSapId, /* Lower SAP ID */
Bool reset    /* Whether to reset the assocLSapId field */
)
#else
PUBLIC Void stSetAssocLSapId(spSapId,reset)
SpId spSapId; /* Lower SAP ID */
Bool reset;   /* Whether to reset the assocLSapId field */
#endif
{
   S16     counter;  /* Loop Counter */
   StTUSap *tuSapCp; /* Upper SAP pointer */
   
   TRC2(stSetAssocLSapId)
    
   /* Loop through the upper SAP list and set association */
   for (counter = 0; counter < stCb.genCfg.nmbSaps; counter++)
   {
      /* Get the upper SAP block */     
      tuSapCp = stCb.tuSapLst[counter];     
     
      /* If upper SAP not NULL match for association */
      if (tuSapCp != (StTUSap *)NULLP)
      {  
         /* Match the SSN and switch info. */
         if ((tuSapCp->ssn == stCb.spSapLst[spSapId]->ssn) &&
                (tuSapCp->cfg.swtch == stCb.spSapLst[spSapId]->cfg.swtch))
         {
            /* Set or reset the assocLSapId field */ 
            if (reset == FALSE)
               tuSapCp->assocLSapId = spSapId;
            else 
               tuSapCp->assocLSapId = ST_DEF_ASSOC_SAP_ID;
         } /* if block - SSN and switch match */
         
      } /* if block - upper SAP not NULL */
      
   } /* for loop */
}

 

/* st007.301 - Added - TC-User Distribution Feature */

/*
*
*       Fun  :  Free up dialogues in all associated 
*               Upper SAP
*
*       Desc :  This routine searches through the upper SAP list  
*               for matching  SSN, switch and free all the 
*               dialogues going there
*               
*       Ret  :  None
*
*       Notes:  It is assumed that spSapId is valid
*
*       File :  ct_bdy4.c
*
*/

#ifdef ANSI
PUBLIC Void stFreeDlgUSapList
(
SuId spSapId     /* Lower SAP ID */
)
#else
PUBLIC Void stFreeDlgUSapList(spId)
SuId spSapId;    /* Lower SAP ID */
#endif
{
   S16     counter;  /* Loop Counter */
   StTUSap *tuSapCp; /* Upper SAP pointer */
   
   TRC2(stFreeDlgUSapList)
    
   /* Loop through the upper SAP list and free up dialogues */
   for (counter = 0; counter < stCb.genCfg.nmbSaps; counter++)
   {
      /* Get the upper SAP block */     
      tuSapCp = stCb.tuSapLst[counter];     
     
      /* If upper SAP not NULL match for association */
      if (tuSapCp != (StTUSap *)NULLP)
      {  
         /* Match the SSN and switch info. */
         if ((tuSapCp->ssn == stCb.spSapLst[spSapId]->ssn) &&
             (tuSapCp->cfg.swtch == stCb.spSapLst[spSapId]->cfg.swtch))
         {     
            /* Free all the dialogues associated with this sap */ 
               (Void)stFreeAllDlg(&tuSapCp->dlgHlCp);               
         } /* if block - SSN and switch match */
            
      } /* if block - lower SAP not NULL */
      
   } /* for loop */
}

 

/* st007.301 - Added - TC-User Distribution Feature */

/*
*
*       Fun  :  Find Associated Lower SAP Id field 
*
*       Desc :  This routine searches through the
*               lower SAP list to match the upper SAP
*               SSN and switch that passed as
*               parameter to this routine.
*               
*       Ret  :  Lower SAP Id
*
*       Notes:  It is assumed that tuSapId is valid
*
*       File :  ct_bdy4.c
*
*/

#ifdef ANSI
PUBLIC SuId stFindLSapId
(
SpId tuSapId     /* Upper SAP ID */
)
#else
PUBLIC SuId stFindLSapId(tuSapId)
SpId tuSapId;    /* Upper SAP ID */
#endif
{
   S16     counter;  /* Loop Counter */
   StSPSap *spSapCp; /* Lower SAP pointer */
   Bool    found;    /* Search flag */
                        
   TRC2(stFindLSapId)

   found = FALSE;
   counter = 0;
   /* Loop through the lower SAP list to match the upper SAP */
   while ((counter < stCb.genCfg.nmbSaps) && (!found))
   {
      /* Get the lower SAP block */     
      spSapCp = stCb.spSapLst[counter];     
     
      /* If lower SAP not NULL match for association */
      if (spSapCp != (StSPSap *)NULLP)
      {  
         /* Match the SSN and switch info. */
         if ((spSapCp->ssn == stCb.tuSapLst[tuSapId]->ssn) &&
             (spSapCp->cfg.swtch == stCb.tuSapLst[tuSapId]->cfg.swtch))
         {
            /* Match is found set the  association field */
            stCb.tuSapLst[tuSapId]->assocLSapId = counter;     
          
            /* Indicate a match is found */
            found = TRUE;
         } /* if block - SSN and switch match */
            
      } /* if block - lower SAP not NULL */
      ++counter;
   } /* while */

   if (found)
   {        
      RETVALUE(counter - 1);
   }
   else
   {        
      /* If no lower SAP is found return an invalid SAP Id value */
      RETVALUE(ST_DEF_ASSOC_SAP_ID);
   }   
}

 

/* st007.301 - Added - TC-User Distribution Feature */

/*
*
*       Fun  :  Find Associated Upper SAP Id field 
*
*       Desc :  This routine is used to find the
*               associated upper SAP of the
*               lower SAP that is passed as
*               a parameter to this routine.
*
*               Algorithm:
*               .If no association exists or if associated
*                SAP exists in other processor, search
*                for finding associated upper SAP first 
*                on same processor.
*
*               .If associated upper SAP is in bound state
*                  .If dialoge Id is valid
*                     .If dialogue control block is found
*                       .return associated upper SAP
*                     .Else search in the upper SAP list
*                      to find the associated upper SAP
*                  .Else if dialogue id is not valid
*                   return associated upper SAP
*               .Else if upper SAP is not bound
*                  .If dialogue Id is valid
*                     .search in upper SAP list
*                     .If found return the Id
*                     .Else return fail
*                  .Else if dialogue Id is not valid
*                     .serach in upper SAP list
*                     .If found return the SAP Id
*                     .Else return fail
*               
*               
*       Ret  :  Upper SAP Id
*
*       Notes:  
*
*       File :  ct_bdy4.c
*
*/

#ifdef ANSI
PUBLIC SpId stFindUSapId
(
SuId       spSapId,           /* Lower SAP ID */
StDlgId    dlgId,             /* dialogue Id */
Bool       firstOrMgmtMsg     /* flag to indicate first/mgmt msg. */
)
#else
PUBLIC SpId stFindUSapId(spSapId,dlgId,firstOrMgmtMsg)
SuId       spSapId;           /* Lower SAP ID */
StDlgId    dlgId;             /* dialogue Id  */
Bool       firstOrMgmtMsg;    /* flag to indicate first or mgmt msg. */
#endif
{
   StTUSap   *tuSapCp; /* Upper SAP pointer */
   SpId      tuSapId;  /* Upper SAP Id */
   StDlgCp   *dlgCp;      /* dialogue control point */
   
   /* Initialize associated upper SAP Id and sap pointer */
   tuSapId = ST_DEF_ASSOC_SAP_ID;
   tuSapCp = NULLP;

   if (stCb.spSapLst[spSapId]->assocUSapId != ST_DEF_ASSOC_SAP_ID)
   {
      /* Get the upper SAP as per assocUSapId */
      tuSapCp = *(stCb.tuSapLst + stCb.spSapLst[spSapId]->assocUSapId);
   }   
   
   /* If upper SAP does not exists, or association has not made already
    * or associated upper SAP is not in the same processor,
    * search through the  upper SAP list to find a match */
   if ((tuSapCp == (StTUSap *)NULLP) || 
       (stCb.spSapLst[spSapId]->assocUSapId == ST_DEF_ASSOC_SAP_ID) ||
       (tuSapCp->pstTU.dstProcId != stCb.init.procId))
   {
      /* Search in all upper SAPs to find a match */     
      tuSapId = stSearchUSapList(spSapId,dlgId,firstOrMgmtMsg,TRUE);
      
      /* If associated upper SAP was found, update
       * association fields */
      if (tuSapId != ST_DEF_ASSOC_SAP_ID)
      {        
         /* Update association field in lower SAP */     
         stCb.spSapLst[spSapId]->assocUSapId = tuSapId;
         /* Update association field in upper SAP */
         stCb.tuSapLst[tuSapId]->assocLSapId = spSapId;
      }   
      RETVALUE(tuSapId);
   }        
   
   /* if associated upper SAP is bound */
   if ( tuSapCp->hlSt == ST_SAP_BND_ENBL)
   {
      /* If Dialogue Id is valid */
      if (dlgId != 0)
      {
         /* st043.301 - Modify - Add suDlgHlCp */
         /* use diaogue Id to get the associated dialogue */
         if (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, dlgId, 
                      ST_USE_SPDLGID, &dlgCp) == ROK)
         {
            /* Dialogue control block found, return upper SAP id */
            RETVALUE(tuSapCp->spId); 
         }
         /* Dialogue control block not found, search in other SAPs */
         else
         {
            /* Search from the upper SAP list to find a match and return */
            tuSapId = stSearchUSapList(spSapId,dlgId,firstOrMgmtMsg,TRUE);
            RETVALUE(tuSapId);     
         } /* else - Dialogue control block not found */
         
      } /* if valid dialogue Id */
      /* Else search cannot be done based on dialogue Id */
      else
      {
         RETVALUE(tuSapCp->spId);
      }
      
   } /* if associated upper  SAP is bound */ 

   /* Else if the associated upper SAP not bound */
   else
   {
      /* If Dialogue Id is valid */
      if (dlgId != 0)
      {
         /* Search in all upper SAPs to find a match */
         tuSapId = stSearchUSapList(spSapId,dlgId,firstOrMgmtMsg,TRUE);
             
         /* Dialogue found in other upper SAP  */
         if (tuSapId != ST_DEF_ASSOC_SAP_ID)
         {
            /* Update association field in lower SAP */     
            stCb.spSapLst[spSapId]->assocUSapId = tuSapId;
            /* Update association field in upper SAP */
            stCb.tuSapLst[tuSapId]->assocLSapId = spSapId;
            RETVALUE(tuSapId);
         }
         /* Dialogue not found in any upper SAP */
         else
         {
            /* st009.301 -Add- Debug prints */
            STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                   "stFindUSapId:Dialogue(%ld) not found in any upper SAP\n",
                   dlgId));
            RETVALUE(ST_DEF_ASSOC_SAP_ID);     
         }                     
         
      } /* if valid dialogue Id */
      /* Else search cannot be done based on dialogue Id */
      else
      {
         /* Search in all upper SAPs to find a match */     
         tuSapId = stSearchUSapList(spSapId,0,firstOrMgmtMsg,TRUE);
         if (tuSapId != ST_DEF_ASSOC_SAP_ID)
         {        
            /* Update association field in lower SAP */     
            stCb.spSapLst[spSapId]->assocUSapId = tuSapId;
            /* Update association field in upper SAP */
            stCb.tuSapLst[tuSapId]->assocLSapId = spSapId;
         }   
         RETVALUE(tuSapId);
      }  
   } /* Else - associated upper SAP not bound */
}

 

/* st007.301 - Added - TC-User Distribution Feature */

/*
*
*       Fun  :  Search in upper SAPs to match dialogue Id  
*
*       Desc :  This routine searches in the upper
*               SAP list to see whether a dialoge exists in the
*               list  and returns back the found SAP.
*               If dialogue  is invalid, the selection of upper SAP
*               is done based on SSN,switch,procId.
*               In case of statistics updation the upper SAP
*               need not be in Bind state. But in all other
*               case selection of upper SAP means that that SAP
*               should be in Bound state. The chkBndState parameter
*               takes care of these situations.
*
*               In case of first message and management messages
*               dialogue Id is invalid. In all other types of
*               messages dialogue Id is valid.
*               
*               In case of first message at first search is
*               made to find an upper SAP within the same
*               processor. If same proc upper SAP is not found
*               then in all other processor search is made to select 
*               the upper SAP.For management msgs search is made only 
*               in same proc. If dialogue Id is valid then check 
*               is made to determine whether the dialogue 
*               resides in any upper SAP.
*
*               In statistics updation cases at first search
*               is made if same proc bound upper SAP is found.
*               If no such SAP is found, any upper SAP which
*               has same SSN and switch but which can be in different
*               processor or in unbound state is returned.
*               
*       Ret  :  Upper SAP Id
*
*       Notes:  It is assumed that lower  SAP Id 
*               is valid that is passed to this 
*               routine
*               
*       File :  ct_bdy4.c
*
*/

#ifdef ANSI
PUBLIC SpId stSearchUSapList
(
SuId     spSapId,          /* Lower SAP ID */
StDlgId  dlgId,            /* Dialogue ID  */
Bool     firstOrMgmtMsg,   /* Flag to indicate first or mgmt
                              message */
Bool     chkBndState       /* Flag to indicate whether to test
                              SAP state */
)
#else
PUBLIC SpId stSearchUSapList(spSapId,dlgId,firstMsg,chkBndState)
SuId     spSapId;          /* Lower SAP ID  */
StDlgId  dlgId;            /* Dialogue ID   */
Bool     firstOrMgmtMsg;   /* Flag to indicate first or mgmt 
                              message */
Bool     chkBndState;      /* Flag to indicate whether to test
                              SAP state */
#endif
{

   S16     counter;   /* Loop Counter */
   S16     lastmatch; /* Index where a match is found with proc id match */
   S16     matchUbnd; /* Index where a match is found even if the SAP is unbound */ 
   StTUSap *tuSapCp;  /* Upper SAP pointer */
   StSPSap *spSapCp;  /* Lower SAp pointer */
   Bool    found;     /* Search flag */
   StDlgCp *dlgCp;    /* Dialogue control point */

   TRC2(stSearchUSapList)

   /* Initialize */        
   found = FALSE;
   counter = 0;
   lastmatch = -1;
   matchUbnd = -1;
   /* Get the lower SAP pointer */
   spSapCp = *(stCb.spSapLst + spSapId);
   
   /* Loop through the upper SAP list to find a match */
   while ((counter < stCb.genCfg.nmbSaps) && (found == FALSE))
   {
      /* Get the upper SAP pointer */     
      tuSapCp = stCb.tuSapLst[counter];     
     
      /* If upper SAP not NULL, check for match */
      if (tuSapCp != (StTUSap *)NULLP)
      {  
         /* Match the SSN and switch info. and SAP state */
         if ((spSapCp->ssn == tuSapCp->ssn) &&
             (spSapCp->cfg.swtch == tuSapCp->cfg.swtch) &&
             ((tuSapCp->hlSt == ST_SAP_BND_ENBL) || (chkBndState == FALSE))) 
         {
            /* If no need to search on dialogue ID */     
            if (dlgId == 0)
            {
               /* If SAP bound state needs to be checked */     
               if (chkBndState == TRUE)
               {        
                  /* Match destProcId against selfProcId */
                  if (tuSapCp->pstTU.dstProcId == stCb.init.procId)
                  {        
                     /* Indicate a match is found */
                     found = TRUE;
                  }
                  else
                  {  /* Store the SAP without procId match */   
                     lastmatch = counter;
                  }
               } /* If bound state needs to be checked */
               /* Else if SAP needs to be selected even if it is unbound */
               else   
               {  
                  /* Give preferenence if the SAP is bound and 
                   * it is in same processor */     
                  if ((tuSapCp->hlSt == ST_SAP_BND_ENBL) &&
                     (tuSapCp->pstTU.dstProcId == stCb.init.procId))     
                  {
                     found = TRUE;
                  }  
                  else   
                  {        
                     /* Store SAP which may be unbound or may be in different 
                      * processor */      
                     matchUbnd = counter;
                  }   
               }   
            }
            /* Else look for dialogue Id match */
            else
            {
               /* st043.301 - Modify - Changed stFndDlg */
               if (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, dlgId,
                            ST_USE_SPDLGID, &dlgCp) == ROK)
               {
                  /* Indicate a match is found */
                  found = TRUE;     
               }     
            }        
         } /* if block - SSN and switch match */
            
      } /* if block - Upper SAP not NULL */
      ++counter;
   } /* while */

   if (found)
   {        
      RETVALUE(counter - 1);
   }
   else
   {  
     /* If it is first or management message, even if same proc upper
      * SAP is not found, return any matched upper SAP in different 
      * processor */
      if ((firstOrMgmtMsg == TRUE) && (chkBndState == TRUE))
      {        
         if (lastmatch != -1)
         {        
            RETVALUE(lastmatch);
         }
         else
         {        
            /* If no upper SAP is found return an invalid ID */
            RETVALUE(ST_DEF_ASSOC_SAP_ID);
         }   
      }   
      
     /* If SAP need not be in bound state  */
      if (chkBndState == FALSE)
      {        
         if (matchUbnd != -1)
         {        
            RETVALUE(matchUbnd);
         }
         else
         {        
            /* If no upper SAP is found return an invalid ID */
            RETVALUE(ST_DEF_ASSOC_SAP_ID);
         }   
      }   
      /* If no upper SAP is found return an invalid SAP Id value */
      RETVALUE(ST_DEF_ASSOC_SAP_ID);
   }   
}
#endif /* ST_TC_USER_DIST */

 

/* st007.301 - Added - TC-User Distribution Feature */

/*
*
*       Fun  :  Get Associated Lower SAP Id field 
*
*       Desc :  This routine returns the Id of
*               the lower SAP that is associated
*               with the upper SAP Id passed as
*               parameter to this routine. No
*               seraching is done here
*               
*       Ret  :  Lower SAP Id
*
*       Notes:  It is assumed that upper SAP Id 
*               is valid and if ST_TC_USER_DIST
*               is defined, association from upper
*               to lower SAP is already made before
*               calling the routine
*               
*       File :  ct_bdy4.c
*
*/

#ifdef ANSI
PUBLIC SuId stGetLSapId
(
SpId tuSapId     /* Upper SAP ID */
)
#else
PUBLIC SuId stGetLSapId(tuSapId)
SpId tuSapId;    /* Upper SAP ID */
#endif
{
   TRC2(stGetLSapId)
           
#ifndef ST_TC_USER_DIST   
   RETVALUE(tuSapId);
#else
   /* Association has already made or found before calling
    * this routine, use the value directly from SAP structure */
   RETVALUE(stCb.tuSapLst[tuSapId]->assocLSapId); /* Lower Sap Id */
#endif /* ST_TC_USER_DIST */   
}

 

/* st007.301 - Added - TC-User Distribution Feature */

/*
*
*       Fun  :  Make association from upper to lower
*               SAP
*
*       Desc :  This routine makes association 
*               from upper to lower SAP. If ST_TC_USER_DIST
*               is not defined then the routine returns the 
*               same id that it takes as input. If ST_TC_USER_DIST
*               is defined then it first checks whether association 
*               is already made. If it is already made the routine
*               returns that value, otherwise it tries to set
*               association from upper to lower SAP by calling
*               appropriate routine.
*               
*       Ret  :  Lower SAP Id
*
*       Notes:  It is assumed that uppar SAP Id
*               is valid
*
*       File :  ct_bdy4.c
*
*/

#ifdef ANSI
PUBLIC SuId stMakeUtoLSapAssoc
(
SpId tuSapId     /* Upper SAP ID */
)
#else
PUBLIC SuId stMakeUtoLSapAssoc(tuSapId)
SpId tuSapId;    /* Upper SAP ID */
#endif
{
   SuId   spSapId; /* Lower SAP Id */
   
   TRC2(stMakeUtoLSapAssoc)

#ifndef ST_TC_USER_DIST
   /* Without TC-User Distribution Feature, the upper and
    * associated lower SAP has the same Id */
   spSapId = tuSapId;
#else   
   
   /* If  association already exists between upper and lower SAP
    * use the associated lower SAP id */
   if (stCb.tuSapLst[tuSapId]->assocLSapId != ST_DEF_ASSOC_SAP_ID)
   {
      spSapId = stCb.tuSapLst[tuSapId]->assocLSapId;
   }
   /* else try to set association by searching the lower SAP list */
   else
   {
      spSapId = stFindLSapId(tuSapId);
   }
   /* No lower SAP exists for this upper SAP */
   if (spSapId == ST_DEF_ASSOC_SAP_ID)
   {
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stMakeUtoLSapAssoc:No lower SAP exists for upper SAP(%d)\n",
             tuSapId));
      RETVALUE(ST_DEF_ASSOC_SAP_ID);
   }    
#endif /* ST_TC_USER_DIST */         
   
   RETVALUE(spSapId);
}

 

/* st007.301 - Added - TC-User Distribution Feature */

/*
*
*       Fun  :  Make association from lower to upper
*               SAP
*
*       Desc :  This routine makes association 
*               from upper to lower SAP. The searchWithDlgId
*               parameter determines whether it is called
*               during handling data primitive or during
*               handling management primitive. During data
*               primitive handling, depending on whether
*               it is the first message or subsequent message
*               appropriate actions are taken.
*               
*       Ret  :  Upper SAP Id
*
*       Notes:  It is assumed that lower SAP Id 
*               is valid
*
*       File :  ct_bdy4.c
*
*/

#ifdef ANSI
PUBLIC SpId stMakeLtoUSapAssoc
(
SuId       spSapId,         /* Lower SAP ID */
Buffer     *mBuf,           /* Message Buffer */
SpUDatEvnt *uDataEv,        /* unit data event */
Bool       searchWithDlgId, /* Flag to determine whether
                               search by dialogue Id possible */
Reason     *reason          /* Failure Reason code */
)
#else
/* st014.301 - modification - correcting syntax error */
PUBLIC SpId stMakeLtoUSapAssoc(spSapId,mBuf,uDataEv,searchWithDlgId,reason)
SuId       spSapId;         /* Lower SAP ID */
Buffer     *mBuf;           /* Message Buffer */
SpUDatEvnt *uDataEv;        /* unit data event */
Bool       searchWithDlgId; /* Flag to determine whether
                               search by dialogue Id possible */
Reason     *reason;         /* Failure Reason code */
#endif
{
   SpId       tuSapId;        /* Upper SAP Id */
#ifdef ST_TC_USER_DIST
   StDlgId    dlgId;          /* return Dialogue Id */                
   Bool       bgnFlag;        /* return flag for BEGIN message */
   StDlgId    origDlgId;      /* originating dialogue Id */
   U8         pduType;        /* PDU type */
#endif /* ST_TC_USER_DIST */

   TRC2(stMakeLtoUSapAssoc)

#ifndef ST_TC_USER_DIST
   /* Without TC-User Distribution Feature, the upper and
    * associated lower SAP has the same Id */
   tuSapId = spSapId;
#else   
   if (searchWithDlgId == TRUE)
   { 
      /* Initialize the return values */
      dlgId = 0;
      bgnFlag = FALSE;
           
      /* Get the dialogue ID by decoding the message */
      /* determine PDU type */
      if (stDecPduHdr(mBuf, stCb.spSapLst[spSapId]->cfg.swtch, 
                      ST_MSG_DIRECTION, &pduType,&origDlgId, 
                      &dlgId,&bgnFlag) == ROK)
      {             
         /* Find the associated upper SAP */ 
         tuSapId = stFindUSapId(spSapId,dlgId,bgnFlag);
      }
      else 
      {
         /* Decoding problem, handle 
          * according to specific protocol */
         tuSapId = stHandleDecProblem(spSapId,mBuf,
                                      uDataEv,dlgId,reason,bgnFlag);          
        
      } /* if - Decoding Problem */       
   }
   /* else search cannot be done based on dialogue Id, in management prim. */
   else
   {
      /* st029.301 - Modify - Third parameter is chaged from FALSE to TRUE as this 
         is the case of management case */
      tuSapId = stFindUSapId(spSapId,0,TRUE);
   }

   /* No upper SAP exists for this lower SAP */
   if (tuSapId == ST_DEF_ASSOC_SAP_ID)
   {
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stMakeLtoUSapAssoc:No upper SAP exists for lower SAP(%d)\n",
             spSapId));
      RETVALUE(ST_DEF_ASSOC_SAP_ID);
   }    
#endif /* ST_TC_USER_DIST */         
   
   RETVALUE(tuSapId);
}

 

/* st007.301 - Added - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
/*
*
*       Fun  :  Handle decoding problem               
*
*       Desc :  This routine handles decoding 
*               problem. It is called during 
*               handling any data primitive (indications)
*               decoding problem. It first tries to 
*               find the associated upper SAP. If
*               it cannot determine the upper SAP
*               then based on specific protocol 
*               it takes appropriate actions.
*
*               
*       Ret  :  Upper SAP Id
*
*       Notes:  It is assumed that lower SAP Id 
*               is valid
*
*       File :  ct_bdy4.c
*
*/

#ifdef ANSI
/* st036.301 - Change PRIVATE to PUBLIC for stHandleDecProblem */
PUBLIC SpId stHandleDecProblem
(
SuId       spSapId,         /* Lower SAP ID */
Buffer     *mBuf,           /* Message Buffer */
SpUDatEvnt *uDataEv,        /* unit data event */
StDlgId    dlgId,           /* Dialogue Id */
Reason     *reason,         /* Failure Reason code */
Bool       bgnFlag          /* Flag to indicate whether it is a Begin msg */
)
#else
PUBLIC SpId stHandleDecProblem(spSapId,mbuf,uDataEv,
                                dlgId,reason,bgnFlag)
SuId       spSapId;         /* Lower SAP ID */
Buffer     *mBuf;           /* Message Buffer */
SpUDatEvnt *uDataEv;        /* unit data event */
StDlgId    dlgId;           /* Dialogue Id */
Reason     *reason;         /* Failure Reason code */
Bool       bgnFlag;         /* Flag to indicate whether it is a Begin msg */
#endif
{
   SpId       tuSapId;        /* Upper SAP Id */
   StTUSap    *tuSapCp;       /* Upper SAP pointer */
   StSPSap    *spSapCp;       /* Lower SAP pointer */
   StQosSet   qos;            /* Quality of service set */
   StMsgEv    msgEv;          /* Transaction portion event structure */ 
   
   TRC2(stHandleDecProblem)        
   /* Initialize local variables */
   tuSapId = ST_DEF_ASSOC_SAP_ID;
   tuSapCp = NULLP;
   
   /* Get lower SAP pointer */
   spSapCp = stCb.spSapLst[spSapId];

   /* Set reason value to indicate decoding problem */     
   *reason = ST_DEC_PROB;     
         
   /* Try to find the associated upper SAP */
   tuSapId = stFindUSapId(spSapId,dlgId,bgnFlag);
   
   /* If upper SAP was found */
   if ( tuSapId != ST_DEF_ASSOC_SAP_ID)
   {        
      /* Get upper SAP pointer */
      tuSapCp = stCb.tuSapLst[tuSapId];
   }
   
   /* Generate a trace of the received event, if trace is enabled */
   if (stCb.init.trc)
   {
      stGenTrc(spSapCp->suId, LST_MSG_RECVD, mBuf);
   }

   /* Fill up quality of service set to be passed transparently to the user */
   qos.msgPrior = uDataEv->prior;
   qos.retOpt   = uDataEv->qos.retOpt;
   qos.seqCtl   = uDataEv->qos.pClass == PCLASS1 ? TRUE:FALSE;

   /* Decode the transaction portion, stDecMsg wont return ROK since
    * message has already been checked to be erroneous */
   if (stDecMsg(&msgEv, spSapCp->cfg.swtch, mBuf,
                &msgEv.pAbtCause.val) != ROK)
   {
      /* st009.301 -Add- Debug prints */     
      STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
             "stHandleDecProblem:Message decoding problem, cause(%d)\n",
             msgEv.pAbtCause.val));
      switch(spSapCp->cfg.swtch)
      {
         case LST_SW_ITU88:
         case LST_SW_ITU92:
         case LST_SW_ITU96:

            /* Handle the incorrect message event */
            if (tuSapCp != NULLP)     
               stTHRxIncMsg(tuSapCp, &msgEv, &qos, &uDataEv->cgAddr,
                            &uDataEv->cdAddr);
            else
               stTHRxIncMsgTcUserDist(spSapId, &msgEv, &qos, 
                                      &uDataEv->cgAddr, &uDataEv->cdAddr);
            break;

      } /* switch */
#ifdef ZT
            ztUpdPeer();
#endif /* ZT */
   } /* If decoding the transaction portion is not ok  */
   RETVALUE(tuSapId);   
}
 

/* st007.301 - Added - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
/*
*
*       Fun  :  Handle Lower to Upper SAP Association
*               Failure
*
*       Desc :  During upper to lower SAP association
*               failure case, this routine takes
*               actions based on protocol.
*                                             
*               
*       Ret  : Void 
*
*       Notes:  It is assumed that lower SAP Id 
*               is valid
*
*       File :  ct_bdy4.c
*
*/

#ifdef ANSI
PUBLIC Void stHandleAssocFail
(
SuId       spSapId,         /* Lower SAP ID */
Buffer     *mBuf,           /* Message Buffer */
SpUDatEvnt *uDataEv         /* unit data event */
)
#else
PUBLIC Void stHandleAssocFail(spSapId,mbuf,uDataEv)
SuId       spSapId;         /* Lower SAP ID */
Buffer     *mBuf;           /* Message Buffer */
SpUDatEvnt *uDataEv;        /* unit data event */
#endif
{
   StSPSap    *spSapCp;       /* Lower SAP pointer */
   StQosSet   qos;            /* Quality of service set */
   StMsgEv    msgEv;          /* Transaction portion event structure */ 

   TRC2(stHandleAssocFail)
   /* Get the lower SAP pointer */
   spSapCp = stCb.spSapLst[spSapId];
   
   /* Generate a trace of the received event, if trace is enabled */
   if (stCb.init.trc)
   {
      stGenTrc(spSapCp->suId, LST_MSG_RECVD, mBuf);
   }

   /* Fill up quality of service set to be passed transparently to the user */
   qos.msgPrior = uDataEv->prior;
   qos.retOpt   = uDataEv->qos.retOpt;
   qos.seqCtl   = uDataEv->qos.pClass == PCLASS1 ? TRUE:FALSE;

   /* Decode the transaction portion, already it has been checked that
    * there is no decoding problem.*/
   if (stDecMsg(&msgEv, spSapCp->cfg.swtch, mBuf,
                &msgEv.pAbtCause.val) == ROK)
   {        
      switch(spSapCp->cfg.swtch)
      {
         case LST_SW_ITU88:
         case LST_SW_ITU92:
         case LST_SW_ITU96:

            /* Handle the Itu Tcap Message */
            (Void)stTHRxMsgTcUserDist(spSapId, &msgEv, &qos, &uDataEv->cgAddr,
                            &uDataEv->cdAddr);
            break;

      } /* switch */
   } /* If decoding is ok */   
#ifdef ZT
      ztUpdPeer();
#endif  /* ZT */
            
}  
#endif /* ST_TC_USER_DIST */

/* st007.301 - Added - TC-User Distribution Feature */



/*
*
*       Fun:   stDecItuMsgHdr
*
*       Desc:  Decode ITU-T transaction component from the TCAP PDU.
*              
*       Ret:   ROK/RFAILED
*
*       Notes: none
*
*       File:  ct_bdy4.c 
*
*/
#ifdef ANSI
PRIVATE S16 stDecItuMsgHdr
(
Buffer      *mBuf,         /* message Buffer */
MsgLen      offset,        /* offset         */
U8          pduType,       /* Pdu Type       */
U8          msgDirection,  /* Message Direction */
StDlgId     *peerDlgId,    /* Peer Dialogue id  */
StDlgId     *myDlgId       /* My Dialogue Id    */
)
#else
PRIVATE S16 stDecItuMsgHdr (mBuf, offset, pduType, 
                               msgDirection, peerDlgId, myDlgId)
Buffer      *mBuf;         /* Message buffer  */
MsgLen      offset;        /* Offset          */
U8          pduType;       /* Pdu Type        */
U8          msgDirection;  /* Message Direction */
StDlgId     *peerDlgId;    /* Peer Dialogue id */
StDlgId     *myDlgId;      /* My Dialogue id   */
#endif
{
   U8          tidArray[4]; /* Transaction id */
   Cntr        i;           /* Counters i     */
   Cntr        j;           /* Counters i     */
   U8          tag;         /* tag            */
   U8          len;         /* length         */

   TRC2 (stDecItuMsgHdr)

   *peerDlgId = 0;
   *myDlgId = 0; 
   j = 0;

   for (;;)
   {
      if (ROK != SExamMsg((Data *)&tag, mBuf, offset++))
      { 
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stDecItuMsgHdr:Execution of sExamMsg failed\n"));
         RETVALUE(RFAILED);
      }
      
      if ((ROK != SExamMsg((Data *)&len, mBuf, offset++)) || (len > 4))
      {
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stDecItuMsgHdr:Execution of sExamMsg failed\n"));
         RETVALUE(RFAILED);
      }
  
      for (i = 0; i < len; i++)
      {
         if (ROK != SExamMsg(&tidArray[i], mBuf, offset++))
         {
            /* st009.301 -Add- Debug prints */
            STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                   "stDecItuMsgHdr:Execution of sExamMsg failed\n"));
            RETVALUE(RFAILED);
         }
      }

      switch (tag)
      {
         case ST_ITU_ORG_TID_TAG:
            for (i = 0; i < len; i++)
            {
               *peerDlgId <<= 8;
               *peerDlgId |= ((U32)tidArray[i] & 0xff);
            }
            break;

         case ST_ITU_DST_TID_TAG:
            for (i = 0; i < len; i++)
            {
               *myDlgId <<= 8;
               *myDlgId |= ((U32)tidArray[i] & 0xff);
            }
            break;

         default:
            /* st009.301 -Add- Debug prints */
            STDBGP(DBGMASK_LI, (stCb.init.prntBuf,
                   "stDecPduHdr: Wrong tag value(%d) in the message\n",tag));
            RETVALUE(RFAILED);
      }

      switch (pduType)
      {
         case ST_ITU_MSG_BGN_TAG:
         case ST_ITU_MSG_END_TAG:
         case ST_ITU_MSG_ABT_TAG:
            RETVALUE(ROK);

         case ST_ITU_MSG_CNT_TAG:
            if (j == 1) RETVALUE(ROK);
            j++;
      }
   }

   /* RETVALUE(ROK); */
   
} /* stDecItuMsgHdr */


/*
*
*       Fun:   stDecPduHdr
*
*       Desc:  Decode PDU header and get the contents - message type and
*       transaction portion. This function makes sure that the PDU buffer
*       is left intact (unlike its TCAP counterpart)
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 stDecPduHdr 
(
Buffer     *mBuf,          /* message buffer    */
Swtch      swtch,          /* TCAP switch       */
U8         msgDirection,   /* message direction */
U8         *pduType,       /* pdu Type          */
StDlgId    *peerDlgId,     /* peer dialogue id  */
StDlgId    *myDlgId,       /* my dialogue   id  */
Bool       *bgnFlag        /* begin flag        */
)
#else
PUBLIC S16 stDecPduHdr (mBuf, swtch, msgDirection, pduType, peerDlgId, 
                        myDlgId,bgnFlag)
Buffer     *mBuf;          /* message buffer    */
Swtch      swtch;          /* TCAP switch       */
U8         msgDirection;   /* Message direction */
U8         *pduType;       /* Pdu  Type         */
StDlgId    *peerDlgId;     /* Peer Dialogue id  */
StDlgId    *myDlgId;       /* My Dialogue   id  */
Bool       *bgnFlag;       /* begin flag        */
#endif
{
   U8        octet;   /* octet */
   U8        offset;  /* Offset */
   U8        length;  /* length */
   S16       ret;     /* return value */

   TRC2(stDecPduHdr)

   /* decode message type */
   if (ROK != SExamMsg((Data *)pduType, mBuf, 0))
   {
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
             "stDecPduHdr:Message type decoding failed\n"));
      RETVALUE(RFAILED);
   }

   /* decode message length portion */
   if (ROK != SExamMsg((Data *)&octet, mBuf, 1))
   {
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
             "stDecPduHdr:Message length decoding failed\n"));
      RETVALUE(RFAILED);
   }

   offset = 2;
   
   /* if MSB set, long form or EOC form */
   if (octet & (U8) 0x80)
   {
      /* long form - skip the message length to get the transaction component
       * offset */
      if ((length = (octet & (U8) 0x7F) ) != 0)
      {
         offset += length;
      }
   }

   *bgnFlag = FALSE;
   /* based on the TCAP variant */
   switch (swtch)
   {

      case LST_SW_ITU88:
      case LST_SW_ITU92:
      case LST_SW_ITU96:
      {
         switch (*pduType)
         {
            /* no dialog IDs in unidirectional messages */
            case ST_ITU_MSG_UNI_TAG:
            {
               *peerDlgId = 0;
               *myDlgId   = 0;
               *bgnFlag = TRUE; 
               break;
            }
            case ST_ITU_MSG_BGN_TAG:
            {
               *bgnFlag = TRUE;
               /* Fall Through */
            }
            case ST_ITU_MSG_END_TAG:
            case ST_ITU_MSG_CNT_TAG:
            case ST_ITU_MSG_ABT_TAG:
            {
               ret = stDecItuMsgHdr(mBuf, offset, *pduType,msgDirection, 
                                                     peerDlgId, myDlgId);
               RETVALUE(ret);
            }

            default:
            {
               /* st009.301 -Add- Debug prints */
               STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
                      "stDecPduHdr: Wrong PDU type(%d)\n", *pduType));
               RETVALUE(RFAILED);
            }
         }
         break;
      }

      default:
      {
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
                "stDecPduHdr: Protocol switch(%d) not supported\n",swtch));
         RETVALUE(RFAILED);
      }
   }
   
   RETVALUE(ROK); 
   
} /* stDecPduHdr */
#endif /* ST_TC_USER_DIST */


/* st014.301 -Add- routine added to retreive stDataParam information */
/*
*
*       Fun:   stGetDataParam
*
*       Desc:  This routine returns the stored isni and imp information, which
*              will be passed to SCCP in SpUDatEvnt.
*              
*       Ret:   none
*
*       Notes: none
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void stGetDataParam 
(
SpUDatEvnt  *uDatEv    /* SCCP Unit Data Event */
)
#else
PUBLIC Void stGetDataParam (uDatEv)
SpUDatEvnt  *uDatEv;   /* SCCP Unit Data Event */
#endif
{
   TRC2(stGetDataParam)
   
   /* retrieve information from stDataParam structure */ 
#if (defined(SS7_ANS96) && defined(SPTV2))
   cmMemcpy((U8*)&uDatEv->isni, (U8*)&stDataParam.isni, sizeof(SpIsni));
#endif

#if defined(SPTV2)
   cmMemcpy((U8*)&uDatEv->imp, (U8*)&stDataParam.imp, sizeof(TknU8));     
#endif

   RETVOID;
} /* stGetDataParam */

#ifdef STUV2
/*
*
*       Fun:   stInitStuDataParam
*
*       Desc:  This routine stores the isni(Intermediate Signalling
*              Network Identification) and imp(Message Importance) 
*              information in an internal TCAP structure. This information is
*              passed from the TC-user to TCAP.
*              
*       Ret:   none
*
*       Notes: The logic is as follows:
*                 If STUV2 is enabled, then these fields will be initialized
*                 with the values received at STU interface.
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void stInitStuDataParam 
(
StDataParam *dataParam,   /* data primitive parameters like imp, isni */
Swtch        swtch        /* protocol switch */
)
#else
PUBLIC Void stInitStuDataParam (dataParam, swtch)
StDataParam *dataParam;  /* data primitive parameters like imp, isni */
Swtch        swtch;      /* protocol switch */
#endif
{
   TRC2(stInitStuDataParam)
   
#ifdef STUV2
   cmMemcpy((U8*)&stDataParam.imp, (U8*)&dataParam->imp, sizeof(TknU8));     
#endif /* STUV2 */
   
#if (defined(SS7_ANS96) && defined(STUV2))
   if (swtch == LST_SW_ANS96)
      cmMemcpy((U8*)&stDataParam.isni, (U8*)&dataParam->isni, sizeof(SpIsni));
#endif /* SS7_ANS96 && STUV2 */           

   RETVOID;
} /* stInitStuDataParam */
#endif /* STUV2 */

/*
*
*       Fun:   stInitSptDataParam
*
*       Desc:  This routine stores the isni(Intermediate Signalling
*              Network Identification) and imp(Message Importance) 
*              information in an internal TCAP structure, 
*              
*       Ret:   none
*
*       Notes: The logic is as follows:
*              1. If STUV2 is enabled, then initialize imp and isni, because 
*                 these fields needs to be passed to TC-User
*              2. If SPTV2 is enabled, then these fields will be initialized
*                 with the values received at SPT interface.
*
*       File:  ct_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void stInitSptDataParam 
(
SpUDatEvnt *uDataEv                /* unit data event */
)
#else
PUBLIC Void stInitSptDataParam (uDataEv)
SpUDatEvnt *uDataEv;               /* unit data event */
#endif
{
   TRC2(stInitSptDataParam)
   
#ifdef STUV2
   stDataParam.imp.pres = NOTPRSNT;
#endif /* STUV2 */

#if (defined(SS7_ANS96) && defined(STUV2))
   stDataParam.isni.isniPres = NOTPRSNT;
#endif

#ifdef SPTV2
   cmMemcpy((U8*)&stDataParam.imp, (U8*)&uDataEv->imp, sizeof(TknU8));     
#endif /* SPTV2 */
   
#if (defined(SS7_ANS96) && defined(SPTV2))
   cmMemcpy((U8*)&stDataParam.isni, (U8*)&uDataEv->isni, sizeof(SpIsni));
#endif /* SS7_ANS96 && SPTV2 */           

   RETVOID;
} /* stInitSptDataParam */
/********************************************************************30**

         End of file:     ct_bdy4.c@@/main/3 - Fri Nov 17 10:34:37 2000

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/


/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      nj   1. initial release.

1.2          st001.27 nj   1. Allowed the empty component parameters buffer to
                              be treated as the buffer not present.
 
            st005.27 nj    2. Changed in stCpyAnsiCompEv function to make the
                              parameter buffer present flag TRUE unconditionally.
                              This causes the encoder to encode the parameter tag
                              with length 0 if the parameters are not present.

            ---      nj    3. Added support for PSF.
                           4. Added support for LMINT3.
                           5. Added routines for bind timer at SPT interface
                              for SPT2.
                           6. Added support for ITU-96.

1.3          st005.28 nj   1. Fixed a bug in function stSendLmCfm when sending a
                              positive alarm for configuration OK.

1.4          st006.28 nj   1. Keeping the backward compatibility at STU interface
                              changed the result source in dialogue event structrue
                              to the old values.

1.5          st009.28 nj   1. Added support to allow same invoke id to be
                              used in both transmit and receive direction.

1.6          st014.28 nj   1. While freeing a dialogue, the component buffer
                              was not getting deallocated.

/main/3      ---      nj   1. Changes for distributed FTHA
                           2. Modified the ZT_DFTHA flag to ZT, surrounding
                              stAllocDlg function. Now, the alternate stAllocDlg
                              funtion shall be used for both DFTHA and FTHA.
3.1+     st002.301  zr,as  1. Bitmap length increased for handling more 
                              simultaneous dialogues   
3.1+     st003.301  zr     1. Changes to synchronise the dialogue Id allocation
                              at standby      

3.1+     st005.301  zr     1. Rolling Upgrade Feature
                           - Allocation of version info. in stCb
                           - Addition of stSetVer and stGetVer routines
                           - In Trace Indication and Alarm Indications
                             version info. configurations is checked before
                             processing the Alarm or Trace
                           - File mrs.x included under ZT  
3.1+     st007.301  zr     1. Changes for  TC-User Distribution Feature
                           - association field in lower and upper SAP is
                             initialized in proper places
                           - during disabling lower SAP dialogues are
                             deleted in all associated upper SAPs
                           - association field is reset(both in upper and lower SAP)
                             whenever the SAP is disabled
                           - New routines added
                              - stDecItuMsgHdr
                              - stDecAnsiMsgHdr
                              - stHandleDecProblem
                              - stCheckSPSapSSN
                              - stSetAssocLSapId
                              - stFreeDlgUSapList
                              - stFindLSapId
                              - stFindUSapId
                              - stSearchUSapList
                              - stGetLSapId
                              - stMakeLtoUSapAssoc
                              - stMakeUtoLSapAssoc
                              - stHandleAssocFail

3.1+      st009.301 zr     1. Add more error logs and debug prints throughout
                              the entire file.

3.1+      st014.301 zr     1. New routine stGetDataParam added which is used 
                              for retrieving  the isni(Intermediate 
                              Signalling Network Id) and imp(Message importance)
                              info
3.1+      st015.301 zr     1. Reason parameter is  changed to Reason datatype 
                              instead of U16.
                           2. In stRemOffMsgMult routine memory leakage 
                              problem is corrected.
                           3. In stGetProtType routine variable initialized
                              and checked to avaid O2 compilation warning
                           4. In stTmrEvnt routine resource set cb is checked
                              for NULL value.
3.1+      st017.301 zr     1. In stAllocDlg routine, initialization of termMsg
                              is done

3.1+      st019.301 jz     1. In stAllocDlg(), free dialogue control block 
                              after freeing dialogue ID to avoid memory 
                              accessing problem.

3.1+      st020.301 jz     1. In stAllocTUSap(), added code to free memory 
                              assigned to tuSapCp and bit map in failure case.

3.1+      st023.301 jz     1. Fixed comment error.
3.1+      st027.301 ds     1. Replace SPutMsg call with STFREEUSERBUF call to avoid
                              mem corruption on double deallocation.
                           2. On deallocation of invoke control block 
                              stop all the timers which were started.
3.1+      st028.301 ds     1. Added invoke count in dlg Cb.
3.1+      st029.301 yk     1. Modify the parameter of stFindUSapId from FALSE to TRUE 
                              in the case of management cases.
3.1+      st031.301 yk     1. Removed prntBuf from stStartTmr as it was not used.
3.1+       st034.301   yk   1. Code Added for SS_MULTIPLE_PROCS
3.1+      st036.301  mkm  1. Correction of patch st035.301. 
                          2. Increase number of bins in dialogue hash list.
                          3. put ztActvInit outside SS_MULTIPLE_PROCS flag
                          4. In test case 209, replace  STACC_PROC_ID0 with par. 
3.1+      st037.301   mkm 1. Removal of warnings.
                          2. Change from hardcode variable size to MsgLen for LONG_MSG flag.
3.1+       st038.301   mkm 1. Modify Test case Ids to remove error of duplicate case.
                           2. Initilaisation of variables used uninitialised.
                           3. Putting stDecAnsiMsgHdr under ANSI flags.
                           4. Replace SFndProcId with STACC_PROC_ID0 for SS_MULTIPLE_PROCS Flag.
3.1+       st040.301   mkm 1. Modify comment to remove Compile time warnings.        
3.1+       st041.301   mkm 1. Proper handling in case Dlg has not expired in stRunAudits.
3.1+       st043.301   mkm 1. Adding stActvInit in stShutDown to re-init the instance with proper reason.
                           2. Replace ST_NMB_BIN_DLG with configurable dlgHshSize.                       
                           3. Changes for new hash list added for dialogues with suDlgId.                
*********************************************************************91*/
