/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/
  
/********************************************************************20**
  
     Name:     TCAP - layer management interface - portable
  
     Type:     C source file
  
     Desc:     C source code for the TCAP Layer Manager interface
               primitives, mapping to layer manager.

     File:     st_ptmi.c
  
     Sid:      st_ptmi.c@@/main/12 - Fri Nov 17 10:34:17 2000
  
     Prg:      nj
  
*********************************************************************21*/
  
  
/*
  
The following functions are provided in this file:

     StMiLstCfgCfm      Configuration Confirm
     StMiLstCntrlCfm    Control Confirm
     StMiLstStaInd      Status Indication
     StMiLstStaCfm      Status Confirm
     StMiLstStsCfm      Statistics Confirm
     StMiLstTrcInd      Trace Indication
   
It should be noted that not all of these functions may be required
by a particular layer management service user.

It is assumed that the following functions are provided in TCAP.

     StMiLstCfgReq      Configure Request
     StMiLstUcfgReq     UnConfigure Request
     StMiLstStaReq      Status Request
     StMiLstStsReq      Statistics Request
     StMiLstCntrlReq    Control Request
   
*/
  
/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* Common timer */
#include "cm_ss7.h"        /* ss7 layer */
#include "cm_hash.h"       /* Common hash */
#include "cm_err.h"        /* common error */
#include "stu.h"           /* Tcap upper interface */
#include "lst.h"           /* Layer management specific defines */
#include "st.h"            /* TCAP layer defines */
#include "st_err.h"        /* TCAP layer Error defines */

#ifdef ZT
#include "cm_ftha.h"
#include "cm_pftha.h"
#include "cm_psfft.h"
#endif /* ZT */

#ifdef ST_FTHA
#include "sht.h"           /* System Agent defines */
#include "mrs.h"           /* MRS */
#endif /* ST_FTHA */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* Common timer */
#include "cm_ss7.x"        /* common ss7 */
#include "cm_hash.x"       /* Common hash */
#include "stu.x"           /* Tcap upper interface */
#include "lst.x"           /* Layer management specific structures */
#include "st_mf.x"         /* Tcap */

#ifdef ZT
#include "cm_ftha.x"
#include "cm_pftha.x"
#include "cm_psfft.x"
/* st005.301 - Added - mrs.x included here */
#include "mrs.x"           /* MRS */
#endif /* ZT */

#ifdef ST_FTHA
#include "sht.x"           /* SHT */
/* st005.301 - Deleted - mrs.x included under ZT */
#endif /* ST_FTHA */

/* st007.301 - Added- spt.x added  */
#include "spt.x"

#include "st.x"            /* TCAP layer specific structures */

  

/* local defines */

/* local externs */
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifndef SS_MULTIPLE_PROCS
EXTERN  StCb   stCb;       /* TCAP layer control block */
#endif

/* forward references */
/* st031.301 - Add - Condition added to avoid warnings */
/* st033.301 - Modify - Modify condition to avoid compilation errors */
#if (!defined(LCSTMILST) || !defined(SM))
PRIVATE S16 PtMiLstStaInd ARGS((Pst *pst, StMngmt *usta));
PRIVATE S16 PtMiLstStaCfm ARGS((Pst *pst, StMngmt *sta));
PRIVATE S16 PtMiLstStsCfm ARGS((Pst *pst, StMngmt *sts)); 
PRIVATE S16 PtMiLstTrcInd ARGS((Pst *pst, StMngmt *trc));
#endif

#ifdef ST_FTHA
PRIVATE S16 PtMiShtCntrlCfm ARGS((Pst *pst, ShtCntrlCfmEvnt *cfmInfo));
#endif /* ST_FTHA */

#ifdef ST_LMINT3
/* st031.301 - Add - Condition added to avoid warnings */
/* st033.301 - Modify - Modify condition to avoid compilation errors */
#if (!defined(LCSTMILST) || !defined(SM))
PRIVATE S16 PtMiLstCfgCfm   ARGS((Pst *pst, StMngmt *cfm));
PRIVATE S16 PtMiLstCntrlCfm ARGS((Pst *pst, StMngmt *cfm));
#endif
#endif /* ST_LMINT3 */


/* functions in other modules */
  
/* public variable declarations */

/* private variable declarations */

/*
   The following matrices define the mapping between the primitives called
   by the layer management interface of TCAP and the corresponding primitives
   of the TCAP service user(s).
 
   The parameter MAXSTMI defines the maximum number of service users on top of
   TCAP. There is an array of functions per primitive invoked by TCAP. Every
   array is MAXSTMI long (i.e. there are as many functions as the number of
   service users).
 
   The dispatching is performed by the configurable variable: selector.
   The selector is configured during general configuration.
 
The selectors are:
 
   0 - loosely coupled -  (#define LCSTMILST)
   1 - tightly coupled -  (#define SM)
*/

/* Status Indication primitive */
 
PRIVATE LstStaInd StMiLstStaIndMt[MAXSTMI] =
{
#ifdef LCSTMILST
   cmPkLstStaInd,        /* 0 - loosely coupled */
#else
   PtMiLstStaInd,        /* 0 - tightly coupled, portable */
#endif

#ifdef SM
   SmMiLstStaInd,        /* 1 - tightly coupled, layer management */
#else
   PtMiLstStaInd,        /* 1 - tightly coupled, portable */
#endif
};


/* Status confirm primitive */
 
PRIVATE LstStaCfm StMiLstStaCfmMt[MAXSTMI] =
{
#ifdef LCSTMILST
   cmPkLstStaCfm,        /* 0 - loosely coupled */
#else
   PtMiLstStaCfm,        /* 0 - tightly coupled, portable */
#endif

#ifdef SM
   SmMiLstStaCfm,        /* 1 - tightly coupled, layer management */
#else
   PtMiLstStaCfm,        /* 1 - tightly coupled, portable */
#endif
};


/* Statistics confirm primitive */
 
PRIVATE LstStsCfm StMiLstStsCfmMt[MAXSTMI] =
{
#ifdef LCSTMILST
   cmPkLstStsCfm,        /* 0 - loosely coupled  */
#else
   PtMiLstStsCfm,        /* 0 - tightly coupled, portable */
#endif

#ifdef SM
   SmMiLstStsCfm,        /* 1 - tightly coupled, layer management */
#else
   PtMiLstStsCfm,        /* 1 - tightly coupled, portable */
#endif
};
 

/* Trace Indication primitive */
 
PRIVATE LstTrcInd StMiLstTrcIndMt[MAXSTMI] =
{
#ifdef LCSTMILST
   cmPkLstTrcInd,        /* 0 - loosely coupled */
#else
   PtMiLstTrcInd,        /* 0 - tightly coupled, portable */
#endif

#ifdef SM
   SmMiLstTrcInd,        /* 1 - tightly coupled, layer management */
#else
   PtMiLstTrcInd,        /* 1 - tightly coupled, portable */
#endif
};


/* Configuration confirm primitive */
 
#ifdef ST_LMINT3
PRIVATE LstCfgCfm StMiLstCfgCfmMt[MAXSTMI] =
{
#ifdef LCSTMILST
   cmPkLstCfgCfm,        /* 0 - loosely coupled */
#else
   PtMiLstCfgCfm,        /* 0 - tightly coupled, portable */
#endif

#ifdef SM
   SmMiLstCfgCfm,        /* 1 - tightly coupled, layer management */
#else
   PtMiLstCfgCfm,        /* 1 - tightly coupled, portable */
#endif
};


/* Control Confirm primitive */
 
PRIVATE LstCntrlCfm StMiLstCntrlCfmMt[MAXSTMI] =
{
#ifdef LCSTMILST
   cmPkLstCntrlCfm,      /* 0 - loosely coupled */
#else
   PtMiLstCntrlCfm,      /* 0 - tightly coupled, portable */
#endif

#ifdef SM
   SmMiLstCntrlCfm,      /* 1 - tightly coupled, layer management */
#else
   PtMiLstCntrlCfm,      /* 1 - tightly coupled, portable */
#endif
};
#endif /* ST_LMINT3 */

#ifdef ST_FTHA
/* System agent control Confirm primitive */
PRIVATE ShtCntrlCfm StMiShtCntrlCfmMt[MAXSTMI] =
{
   /* st008.301 -Delete- Earlier cmPkShtCntrlCfm was placed under LCSTMILST 
    * flag, otherwise PtMiShtCntrlCfm routine would be called. Now the entry
    * PtMiShtCntrlCfm has been removed and cmPkMiShtCntrlCfm is no longer kept
    * under any flag */
   cmPkMiShtCntrlCfm,      /* 0 - loosely coupled */

#ifdef TRI_SH   /* xingzhou.xu: change marco SH into TRI_SH, becuase SH is a CPU type in tornadov2.2 --2006/09/13 */ 
   ShMiShtCntrlCfm,      /* 1 - tightly coupled, System Agent */
#else
   PtMiShtCntrlCfm,      /* 1 - tightly coupled, portable */
#endif
};
#endif /* ST_FTHA */


/*
 *     support functions
 */

/*
*     layer management interface functions 
*/
 
/*
*
*       Fun:   Status Indication
*
*       Desc:  This function is used to indicate the status of TCAP
*              to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 StMiLstStaInd
(
Pst       *pst,           /* post structure */
StMngmt   *usta           /* unsolicited status */
)
#else
PUBLIC S16 StMiLstStaInd(pst, usta)
Pst       *pst;           /* post structure */   
StMngmt   *usta;          /* unsolicited status */
#endif
{
   TRC3(StMiLstStaInd)

   /* jump to specific primitive depending on configured selector */

   RETVALUE((*StMiLstStaIndMt[pst->selector])(pst, usta)); 

} /* end of StMiLstStaInd */


/*
*
*       Fun:   Status Confirm
*
*       Desc:  This function is used to return the status of TCAP
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 StMiLstStaCfm
(
Pst       *pst,           /* post structure */   
StMngmt   *sta            /* solicited status */
)
#else
PUBLIC S16 StMiLstStaCfm(pst, sta)
Pst       *pst;           /* post structure */   
StMngmt   *sta;           /* solicited status */
#endif
{
   TRC3(StMiLstStaCfm)

   /* jump to specific primitive depending on configured selector */

   RETVALUE((*StMiLstStaCfmMt[pst->selector])(pst, sta)); 

} /* end of StMiLstStaCfm */


/*
*
*       Fun:   Statistics Confirm
*
*       Desc:  This function is used to return the statistics of TCAP
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 StMiLstStsCfm
(
Pst       *pst,           /* post structure */   
StMngmt   *sts            /* Statistics */
)
#else
PUBLIC S16 StMiLstStsCfm(pst, sts)
Pst       *pst;           /* post structure */   
StMngmt   *sts;           /* statistics */
#endif
{
   TRC3(StMiLstStsCfm)

   /* jump to specific primitive depending on configured selector */

   RETVALUE((*StMiLstStsCfmMt[pst->selector])(pst, sts)); 

} /* end of StMiLstStsCfm */



/*
*
*       Fun:   Trace Indication
*
*       Desc:  This function is used to indicate the trace of TCAP
*              to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 StMiLstTrcInd
(
Pst       *pst,           /* post structure */   
StMngmt   *trc            /* Trace */
)
#else
PUBLIC S16 StMiLstTrcInd(pst, trc)
Pst       *pst;           /* post structure */   
StMngmt   *trc;           /* Trace */
#endif
{
   TRC3(StMiLstTrcInd)

   /* jump to specific primitive depending on configured selector */

   RETVALUE((*StMiLstTrcIndMt[pst->selector])(pst, trc)); 

} /* end of StMiLstTrcInd */ 



#ifdef ST_LMINT3
/*
*
*       Fun:   Configuration Confirm
*
*       Desc:  This function is used to confirm the configuration of TCAP
*              to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 StMiLstCfgCfm
(
Pst       *pst,           /* post structure */   
StMngmt   *cfm            /* Confirm Structure */
)
#else
PUBLIC S16 StMiLstCfgCfm(pst, cfm)
Pst       *pst;           /* post structure */   
StMngmt   *cfm;           /* Confirm Structure */
#endif
{
   TRC3(StMiLstCfgCfm)

   /* jump to specific primitive depending on configured selector */

   RETVALUE((*StMiLstCfgCfmMt[pst->selector])(pst, cfm)); 

} /* end of StMiLstCfgCfm */ 


/*
*
*       Fun:   Control Confirm
*
*       Desc:  This function is used to confirm the control of TCAP
*              to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 StMiLstCntrlCfm
(
Pst       *pst,           /* post structure */   
StMngmt   *cfm            /* Confirm Structure */
)
#else
PUBLIC S16 StMiLstCntrlCfm(pst, cfm)
Pst       *pst;           /* post structure */   
StMngmt   *cfm;           /* Confirm Structure */
#endif
{
   TRC3(StMiLstCntrlCfm)

   /* jump to specific primitive depending on configured selector */

   RETVALUE((*StMiLstCntrlCfmMt[pst->selector])(pst, cfm)); 

} /* end of StMiLstCntrlCfm */ 
#endif /* ST_LMINT3 */


/* portable functions */

/* st031.301 - Add - Condition added to avoid warnings */
/* st033.301 - Modify - Modify condition to avoid compilation errors */
#if (!defined(LCSTMILST) || !defined(SM))
/*
*
*       Fun:   Portable Status Confirm
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptmi.c
*
*/
#ifdef ANSI
PRIVATE S16 PtMiLstStaCfm
(
Pst       *pst,           /* post structure */   
StMngmt   *sta            /* solicited status */
)
#else
PRIVATE S16 PtMiLstStaCfm(pst, sta)
Pst       *pst;           /* post structure */   
StMngmt   *sta;           /* solicited status */
#endif
{
   TRC3(PtMiLstStaCfm);

   UNUSED(pst);
   UNUSED(sta);

#if (ERRCLASS & ERRCLS_DEBUG)
   STLOGERROR(ERRCLS_DEBUG, EST313, ERRZERO, "PtMiLstStaCfm () Failed");
#endif

  RETVALUE(ROK);
} /* end of PtMiLstStaCfm */

  

/*
*
*       Fun:   Portable Status Indication
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptmi.c
*
*/
#ifdef ANSI
PRIVATE S16 PtMiLstStaInd
(
Pst       *pst,           /* post structure */   
StMngmt   *usta           /* unsolicited status */
)
#else
PRIVATE S16 PtMiLstStaInd(pst, usta)
Pst       *pst;           /* post structure */   
StMngmt   *usta;          /* unsolicited status */
#endif
{
   TRC3(PtMiLstStaInd);

   UNUSED(pst);
   UNUSED(usta);

#if (ERRCLASS & ERRCLS_DEBUG)
   STLOGERROR(ERRCLS_DEBUG, EST314, ERRZERO, "PtMiLstStaCfm () Failed");
#endif

  RETVALUE(ROK);
} /* end of PtMiLstStaInd */

  

/*
*
*       Fun:   Portable Statistics Confirm
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  st_ptmi.c
*
*/
#ifdef ANSI
PRIVATE S16 PtMiLstStsCfm
(
Pst       *pst,           /* post structure */   
StMngmt   *sts            /* statistics */
)
#else
PRIVATE S16 PtMiLstStsCfm(pst, sts)
Pst       *pst;           /* post structure */   
StMngmt   *sts;           /* statistics */
#endif
{
   TRC3(PtMiLstStsCfm);

   UNUSED(pst);
   UNUSED(sts);

#if (ERRCLASS & ERRCLS_DEBUG)
   STLOGERROR(ERRCLS_DEBUG, EST315, ERRZERO, "PtMiLstStaCfm () Failed");
#endif

  RETVALUE(ROK);
} /* end of PtMiLstStsCfm */

  

/*
*
*       Fun:   Portable Trace Indication
*
*       Desc:  
*
*       Ret:   None
*
*       Notes: None
*
*       File:  st_ptmi.c
*
*/
#ifdef ANSI
PRIVATE S16 PtMiLstTrcInd
(
Pst       *pst,           /* post structure */   
StMngmt   *trc            /* trace */
)
#else
PRIVATE S16 PtMiLstTrcInd(pst, trc)
Pst       *pst;           /* post structure */   
StMngmt   *trc;           /* trace */
#endif
{
   TRC3(PtMiLstTrcInd);

   UNUSED(pst);
   UNUSED(trc);

#if (ERRCLASS & ERRCLS_DEBUG)
   STLOGERROR(ERRCLS_DEBUG, EST316, ERRZERO, "PtMiLstStaCfm () Failed");
#endif

  RETVALUE(ROK);
} /* end of PtMiLstTrcInd */


#ifdef ST_LMINT3
/*
*
*       Fun:   Portable Configuration confirm
*
*       Desc:  
*
*       Ret:   None
*
*       Notes: None
*
*       File:  st_ptmi.c
*
*/
#ifdef ANSI
PRIVATE S16 PtMiLstCfgCfm
(
Pst       *pst,           /* post structure */   
StMngmt   *cfm            /* confirm structure */
)
#else
PRIVATE S16 PtMiLstCfgCfm(pst, cfm)
Pst       *pst;           /* post structure */   
StMngmt   *cfm;           /* confirm structure */
#endif
{
   TRC3(PtMiLstCfgCfm);

   UNUSED(pst);
   UNUSED(cfm);

#if (ERRCLASS & ERRCLS_DEBUG)
   STLOGERROR(ERRCLS_DEBUG, EST317, ERRZERO, "PtMiLstCfgCfm () Failed");
#endif

  RETVALUE(ROK);
} /* end of PtMiLstCfgCfm */


/*
*
*       Fun:   Portable Control Confirm
*
*       Desc:  
*
*       Ret:   None
*
*       Notes: None
*
*       File:  st_ptmi.c
*
*/
#ifdef ANSI
PRIVATE S16 PtMiLstCntrlCfm
(
Pst       *pst,           /* post structure */   
StMngmt   *cfm            /* confirm structure */
)
#else
PRIVATE S16 PtMiLstCntrlCfm(pst, cfm)
Pst       *pst;           /* post structure */   
StMngmt   *cfm;           /* confirm structure */
#endif
{
   TRC3(PtMiLstCntrlCfm);

   UNUSED(pst);
   UNUSED(cfm);

#if (ERRCLASS & ERRCLS_DEBUG)
   STLOGERROR(ERRCLS_DEBUG, EST318, ERRZERO, "PtMiLstCntrlCfm () Failed");
#endif

  RETVALUE(ROK);
} /* end of PtMiLstCntrlCfm */
#endif /* ST_LMINT3 */
#endif /* if ((!LCSTMILST) & (!SM)) */

#ifdef ST_FTHA
/*
 *
 *       Fun:   System agent control Confirm
 *
 *       Desc:  This function is used to send the system agent control confirm 
 *              primitive
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  st_ptmi.c
 *
 */
#ifdef ANSI
PUBLIC S16 StMiShtCntrlCfm
(
Pst *pst,                /* post structure */
ShtCntrlCfmEvnt *cfmInfo     /* system agent control confirm event */
)
#else
PUBLIC S16 StMiShtCntrlCfm(pst, cfmInfo)
Pst *pst;                /* post structure */
ShtCntrlCfmEvnt *cfmInfo;    /* system agent control confirm event */
#endif
{
   TRC3(StMiShtCntrlCfm);

   /* jump to specific primitive depending on configured selector */
   (*StMiShtCntrlCfmMt[pst->selector])(pst, cfmInfo); 

   RETVALUE(ROK);
} /* end of StMiShtCntrlCfm */ 

#ifndef TRI_SH
/*
 *
 *       Fun:   System agent portable control Confirm
 *
 *       Desc:  This function is used to send the system agent control confirm 
 *              primitive
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  st_ptmi.c
 *
 */
#ifdef ANSI
PRIVATE S16 PtMiShtCntrlCfm
(
Pst *pst,                /* post structure */
ShtCntrlCfmEvnt *cfmInfo     /* system agent control confirm event */
)
#else
PRIVATE S16 PtMiShtCntrlCfm(pst, cfmInfo)
Pst *pst;                /* post structure */
ShtCntrlCfmEvnt *cfmInfo;    /* system agent control confirm event */
#endif
{
   TRC3(PtMiShtCntrlCfm);

   UNUSED(pst);
   UNUSED(cfmInfo);

#if (ERRCLASS & ERRCLS_DEBUG)
   STLOGERROR(ERRCLS_DEBUG, EST319, ERRZERO, "PtMiShtCntrlCfm () Failed");
#endif /* ERRCLASS */

   RETVALUE(ROK);
} /* end of PtMiShtCntrlCfm */ 
#endif /* TRI_SH */

#endif /* ST_FTHA */

/********************************************************************30**
  
         End of file:     st_ptmi.c@@/main/12 - Fri Nov 17 10:34:17 2000

*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/


/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/


/********************************************************************80**
 
  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  ak    1. initial release
1.2          ---  ak    1. defined error numbers.
 
1.3          ---  ak    1. include cm5.[hx]
 
1.4          ---  ak    1. StsCfm packs conditionally based on swtch.
             ---  ak    2. StaInd updated to pack new usta fields.
             ---  ak    3. check all return values.
             ---  ak    4. remove SEL_LC_OLD support.
 
1.5          ---  aa    1. Added function stPkStEvCnt (from cm_bdy2.c) 
             ---  aa    2. replaced cm2.x with cm_ss7.x
             ---  aa    3. changed function for packing/unpacking of Stat.
 
1.6          ---  fmg   1. wrapped stPkStEvCnt definition in ANS ifdef. 
 
1.7          ---  aa    1. Changed the LST_SW_CCITTxx to LST_SW_ITUxx and
                           LST_SW_ANSIxx to LST_SW_ANSxx
1.8          ---  aa    1. Changes due to removing of serror's
 
*********************************************************************81*/
 

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.9          ---      aa   1. Removed the backward compatibility from the matri
 
1.10         ---      nj   1. Rewrote the file.

1.11         ---      nj   1. Added support for ITU-96.
             ---      nj   2. Moved the packing functions from this file to lst.c

/main/12     ---      nj   1. Added changes for SHT interface 
3.1+       st005.301  zr   1. File mrs.x included under ZT flag
3.1+       st007.301  zr   1. spt.x included for TC-User Distribution Feature
3.1+       st008.301  zr   1. Deleted PtMiShtCntrlCfm entry in 
                              matrix StMiShtCntrlCfmMt
3.1+       st031.301  yk   1. Condition added to avoid warnings.
3.1+       st033.301   yk   1. Condition modified to avoid compilation error
3.1+       st034.301   yk   1. Code Added for SS_MULTIPLE_PROCS
*********************************************************************91*/
