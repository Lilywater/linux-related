/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**

     Name:     SS7 TCAP

     Type:     C source file
  
     Desc:     C source code for dialogue handler, component handler
               and transaction handler routines for ITU (88 & 92)
               variant of TCAP, supplied by TRILLIUM.

     File:     ct_bdy2.c
  
     Sid:      ct_bdy2.c@@/main/17 - Fri Nov 17 10:34:30 2000
  
     Prg:      nj
  
*********************************************************************21*/

/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif
#ifdef CCITT96
               CCITT 96
#endif
 
************************************************************************/

/*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000011     Multiprocessor Operating System
*     1000030     SS7 - SCCP
*
*/

/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* Common timer */
#include "cm_ss7.h"        /* SS7 Specific */
#include "cm_hash.h"       /* common hash */
#include "cm_err.h"        /* common error */
#include "stu.h"           /* Tcap Upper Interface */
#include "spt.h"           /* Tcap Lwer Interface */
#include "lst.h"           /* TCAP layer management Interface */
#include "st.h"            /* Tcap */
#include "st_mf.h"         /* Tcap Message functions */
#include "st_db.h"         /* Tcap ASN.1 Database */
#include "st_err.h"        /* Tcap error */

#ifdef ST_FTHA
#include "sht.h"           /* SHT */
#include "mrs.h"           /* MRS */
#endif /* ST_FTHA */

#ifdef ZT
#include "cm_ftha.h"
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#ifdef ZT_DFTHA
#include "cmztdt.h"
#include "cmztdtlb.h"
#endif /* ZT_DFTHA */
#include "zt.h"            /* Tcap PSF defines */
#include "lzt.h"
#endif /* ZT */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* Common Timer */
#include "cm_ss7.x"        /* common SS7 Specific */
#include "cm_hash.x"       /* common hash */
#include "stu.x"           /* Tcap Upper Interface  */
#include "spt.x"           /* Tcap Lower interface */
#include "lst.x"           /* TCAP layer management Interface */
#include "st_mf.x"         /* Tcap Message functions */

#ifdef ZT
#include "cm_ftha.x"
#include "cm_pftha.x"      /* Common PSF typedefs */
#include "cm_psfft.x"
#endif /* ZT */

#ifdef ST_FTHA
#include "sht.x"           /* SHT */
/* st005.301 - Deleted - mrs.x included under ZT */
#endif /* ST_FTHA */

#include "st.x"            /* Tcap */
  
#ifdef ZT
/* st005.301 - Added - mrs.x included here */
#include "mrs.x"
#ifdef ZT_DFTHA
#include "cmztdt.x"
#include "cmztdtlb.x"
#endif /* ZT_DFTHA */
#include "lzt.x"
#include "zt.x"            /* Tcap PSF typedefs */
#endif /* ZT */

  

/* local defines */

/* local externs */
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifndef SS_MULTIPLE_PROCS
EXTERN  StCb   stCb;     /* TCAP control block */ 
#ifdef ZT
EXTERN  ZtCb   ztCb;     /* PSF control block */ 
#endif /* ZT */
/* st014.301 -Add- declaration stDataParam and stMgmntParam variables */
EXTERN  StDataParam  stDataParam;
EXTERN  StMgmntParam stMgmntParam;

#endif /* SS_MULTIPLE_PROCS */

/* forward references */
PRIVATE S16  stCHGetComps      ARGS((StDlgCp      *dlgCp,
                                     Buffer      **mBuf));

PRIVATE S16  stCHDiscardComps  ARGS((StDlgCp      *dlgCp));

  /* st008.301 - Modify - Function prototype of stCHPutComps modified */

PRIVATE S16  stCHPutComps      ARGS((StTUSap      *tuSapCp,
                                     StDlgId      dlgId,
                                     Buffer       *mBuf));

PRIVATE S16  stCHRejInd        ARGS((StDlgCp      *dlgCp,
                                     PTR           compEv,
                                     Bool          lastCmp));

PRIVATE S16  stCHGenRej        ARGS((StDlgCp      *dlgCp,
                                     TknInvId     *invId,
                                     U8            probType,
                                     U8            probCode));

PRIVATE Void stIsmActOp        ARGS((PTR           invCp,
                                     PTR           data1,
                                     PTR           data2));

PRIVATE Void stIsmActTerm      ARGS((PTR           invCp,
                                     PTR           data1,
                                     PTR           data2));

PRIVATE Void stIsmActInvTmr    ARGS((PTR           invCp,
                                     PTR           data1,
                                     PTR           data2));

PRIVATE Void stIsmActRejTmr    ARGS((PTR           invCp,
                                     PTR           data1,
                                     PTR           data2));

PRIVATE Void stIsmActCmp       ARGS((PTR           invCp,
                                     PTR           data1,
                                     PTR           data2));

PRIVATE Void stIsmActRej       ARGS((PTR           invCp,
                                     PTR           data1,
                                     PTR           data2));

PRIVATE Void stIsmActIRes      ARGS((PTR           invCp,
                                     PTR           data1,
                                     PTR           data2));

PRIVATE Void stIsmActIErr      ARGS((PTR           invCp,
                                     PTR           data1,
                                     PTR           data2));

PRIVATE S16  stDHRxUni         ARGS((StDlgCp      *dlgCp,
                                     Buffer       *mBuf,
                                     StQosSet     *qos));

PRIVATE Void stDHRxBgn         ARGS((PTR           dlgCp,
                                     PTR           mBuf,
                                     PTR           qos));

PRIVATE Void stDHRxCnt         ARGS((PTR           dlgCp,
                                     PTR           mBuf,
                                     PTR           qos));

PRIVATE Void stDHRxEnd         ARGS((PTR           dlgCp,
                                     PTR           mBuf,
                                     PTR           qos));

PRIVATE Void stDHRxUAbt        ARGS((PTR           dlgCp,
                                     PTR           mBuf,
                                     PTR           qos));

PRIVATE Void stDHRxPAbt        ARGS((PTR           dlgCp,
                                     PTR           pAbtCause,
                                     PTR           qos));
 
PRIVATE S16  stDHGenPUAbt      ARGS((StDlgCp      *dlgCp,
                                     U8            abtCause,
                                     StAcn        *acn,
                                     StQosSet     *qos));
 

PRIVATE S16  stTHTxUni         ARGS((StDlgCp      *dlgCp,
                                     StQosSet     *qos,
                                     Buffer       *mBuf));

PRIVATE Void stTHTxBgn         ARGS((PTR           dlgCp,
                                     PTR           mBuf,
                                     PTR           qos));

PRIVATE Void stTHTxCnt         ARGS((PTR           dlgCp,
                                     PTR           mBuf,
                                     PTR           qos));

PRIVATE Void stTHTxEnd         ARGS((PTR           dlgCp,
                                     PTR           mBuf,
                                     PTR           qos));

PRIVATE Void stTHTxUAbt        ARGS((PTR           dlgCp,
                                     PTR           mBuf,
                                     PTR           qos));

PRIVATE Void stTHTxPAbt        ARGS((PTR           dlgCp,
                                     PTR           pAbtCause,
                                     PTR           qos));

PRIVATE S16  stTHGenPAbt       ARGS((StTUSap      *tuSapCp,
                                     StDlgId       dstDlgId,
                                     U8            dstDlgIdLen,
                                     U8            pAbtCause,
                                     StQosSet     *qos,
                                     SpAddr       *dstAddr,
                                     SpAddr       *srcAddr));

/* st007.301 - Added - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST

PRIVATE S16  stTHGenPAbtTcUserDist       
                                ARGS((SuId        spSapId,
                                     StDlgId      dstDlgId,
                                     U8           dstDlgIdLen,
                                     U8           pAbtCause,
                                     StQosSet     *qos,
                                     SpAddr       *dstAddr,
                                     SpAddr       *srcAddr));

#endif /* ST_TC_USER_DIST */

PRIVATE S16  stItuTsmExec      ARGS((StDlgCp      *dlgCp,
                                     StEvent       smEvent,
                                     PTR           data1,
                                     PTR           data2));

#ifdef ST_ENABLE_SM_ARRAY /* xingzhou.xu: added for state match --2006/09/13 */

PRIVATE S16 stGetItuTsmIdx(U8 smState, StEvent smEvent, U16 *tblIdx);
PRIVATE S16 stGetItuIsmIdx(U8 smState, StEvent smEvent, U16 *tblIdx);
#endif
/* functions in other modules */
  
/* public variable declarations */

/* private variable declarations */


/*
 *     support functions
 */


/************************************************************************
                   Component Handler Routines
************************************************************************/

/*
*
*       Fun:   stCHTxComps
*
*       Desc:  Process the Transmit Component event
*
*       Ret:   ROK       if successful
*              RFAILED   if failure
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16  stCHTxComp
(
StDlgCp      *dlgCp,          /* Associated dialogue */
StItuCompEv  *compEv,         /* Component event */
U16           invTmr,         /* Invoke Timer value */
U8            opClass         /* Operation Class */
)
#else
PUBLIC S16  stCHTxComp(dlgCp, compEv, invTmr, opClass)
StDlgCp      *dlgCp;          /* Associated dialogue */
StItuCompEv  *compEv;         /* Component event */
U16           invTmr;         /* Invoke Timer value */
U8            opClass;        /* Operation Class */
#endif
{
   StTUSap   *tuSapCp;     /* Upper Sap */
   StSPSap   *spSapCp;     /* Lower Sap */
   StInvCp   *invCp;       /* invocation control point */
   Buffer    *mBuf;        /* buffer to hold encoded invoke comp */
   TknInvId   invId;       /* Invoke Id */
   U8         compType;    /* Component type */
   S16        ret;
   /* st007.301 - Added - TC-User Distribution Feature */
   SuId      spSapId;      /* Lower SAP Id */
 
   TRC2(stCHTxComp)

   /* Get the upper sap */
   tuSapCp = dlgCp->sapCp;

   /* st007.301 - TC-User Distribution Feature */
   /* Find or Make association from upper to lower SAP */
   spSapId = stMakeUtoLSapAssoc(tuSapCp->spId);

#ifdef ST_TC_USER_DIST   
   if (spSapId == ST_DEF_ASSOC_SAP_ID)
   {        
      /* Generate alarm to LM and return */
      stSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_UI_INV_EVT,
                  LST_CAUSE_SPSAP_ASSOC_FAIL, EVTSTUCMPREQ, (U8)tuSapCp->spId);
      /* st009.301 -Add-  Print debug info */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
       "stCHTxComp:Lower SAP cant be associated for upper SAP(%d),dlg.(%ld)\n",
       tuSapCp->spId,dlgCp->spDlgId));
      RETVALUE(RFAILED);
   }
#endif /* ST_TC_USER_DIST */
   
   /* Get the lower SAP pointer */
   spSapCp = stCb.spSapLst[spSapId];

   /* Component type */
   compType = compEv->compType.val;

   invId.pres = TRUE;

   if (compType == ST_COMP_TYP_REJ)
   {
      /* Invoke Id is the third element in the event structure for
         the reject component */
      invId.val = compEv->comp.rej.invokeId.val;
   }
   else
   {
      /* For other components Invoke Id is the second element in the
         event structure */
      invId.val = compEv->comp.inv.invokeId.val;
   }

   if (compType == ST_COMP_TYP_INV)
   {
      /* Check the operation class for Invoke component */
      switch(opClass)
      {
         case 1:
         case 2:
         case 3:
         case 4:
            break;
         default:

            if (stCb.errCntrlFlg)
            {
	       /* st029.301 - Modify - STFREEUSERBUF is moved here because the 
                  parameter component will be freed only once here and not outside of 
                  the function where it is returned */

               if (((StItuCompEv *) compEv)->comp.inv.params.pres)
                  /* st027.301 - Modify - Modify the user buf free mechanism */ 
                  STFREEUSERBUF(compEv->comp.inv.params.val);

               /* st009.301 -Add-  Print debug info */
               STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                      "stCHTxComp:Unknown operation(%d) in dialogue(%ld)\n"
                      ,opClass,dlgCp->spDlgId));
               /* Generate local Reject to the user */
               stGenLocRej(tuSapCp, dlgCp->suDlgId, dlgCp->spDlgId, invId.val,
                           STU_PROB_INVOKE, STU_UNREC_OPCLASS);
               RETVALUE(ROK);
            }
            else
            {
               /* st009.301 -Add- Debug prints */
               STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                      "stCHTxComp:Unknown operation(%d) in dialogue (%ld)\n",
                      opClass,dlgCp->spDlgId));
               stSendAlarm(LCM_CATEGORY_PROTOCOL, LST_EVENT_INV_COMPEV,
                           LCM_CAUSE_UNKNOWN, EVTSTUCMPREQ, (U8)tuSapCp->spId);
               RETVALUE(RFAILED);
            }
            break;
      }

      /* search hash-table to see if this invocation exists */
      if ((ret = stFndInv(&dlgCp->invHlCp, invId.val, &invCp)) == ROK)
      {
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stCHTxComp:Duplicate Invoke Id (%d) in dialogue(%ld)\n",
                invId.val,dlgCp->spDlgId));
         if (!stCb.errCntrlFlg)
         {
            /* this is a duplicate Invoke Id */
            stSendAlarm(LCM_CATEGORY_PROTOCOL, LST_EVENT_DUP_INVID,
                        LCM_CAUSE_UNKNOWN, NOTUSED, (U8)invId.val);
         }
         else
         {
            /* Generate local Reject to the user */
            stGenLocRej(tuSapCp, dlgCp->suDlgId, dlgCp->spDlgId, invId.val,
                        STU_PROB_INVOKE, STU_DUP_INVOKE);
         }

         RETVALUE(RFAILED);
      }

      /* Allocate invocation */
      if (( ret = stAllocInv(dlgCp, invId.val, &invCp)) != ROK)
      {
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stCHTxComp:Invoke(%d) allocation failed in dialogue (%ld)\n",
                invId.val, dlgCp->spDlgId));
         if (stCb.errCntrlFlg)
         {
            /* Generate local Reject to the user */
            stGenLocRej(tuSapCp, dlgCp->suDlgId, dlgCp->spDlgId, invId.val,
                        STU_PROB_INVOKE, STU_RESOURCE_LIMIT);
         }

         RETVALUE(RFAILED);
      }

      invCp->invTmr  = invTmr;
      invCp->opClass = opClass;
   }

   /* Allocate message buffer to encode the component */
   if (SGetMsg(spSapCp->pstSP.region, spSapCp->pstSP.pool, &mBuf) != ROK)
   {
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
        "stCHTxComp:SGetMsg failed for encoding invoke(%d) in dialogue(%ld)\n",
        invId.val,dlgCp->spDlgId));
      if (!stCb.errCntrlFlg)
      {
         stSendAlarm(LCM_CATEGORY_RESOURCE, LST_EVENT_MSG_FAIL, LCM_CAUSE_UNKNOWN,
                     NOTUSED, NOTUSED);
      }
      else
      {
         /* Generate local Reject to the user */
         stGenLocRej(tuSapCp, dlgCp->suDlgId, dlgCp->spDlgId, invId.val,
                     STU_PROB_GENERAL, STU_RSRC_UNAVAIL);
      }

      RETVALUE(RFAILED);
   }

   /* build component in ASN.1 format */
   if (stEncComp((PTR)compEv, tuSapCp->cfg.swtch, mBuf) != ROK)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST220, (ErrVal)0,
                 "stCHTxComps:stEncComp Failed");
#endif
      if (stCb.errCntrlFlg)
      {
         /* Generate local Reject to the user */
         stGenLocRej(tuSapCp, dlgCp->suDlgId, dlgCp->spDlgId, invId.val,
                     STU_PROB_GENERAL, STU_ENC_FAILURE);
      }

      RETVALUE(RFAILED);
   }

   /* add this component to the last of the component queue */
   if (stCompQLast(dlgCp, mBuf, compType, &invId) != ROK)
   {
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
         "stCHTxComp:Cant add the invoke(%d) in component queue for dlg(%ld)\n",
          invId.val,dlgCp->spDlgId));
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

      if (!stCb.errCntrlFlg)
      {
         stSendAlarm(LCM_CATEGORY_RESOURCE, LST_EVENT_MSG_FAIL, LCM_CAUSE_UNKNOWN,
                     NOTUSED, NOTUSED);
      }
      else
      {
         /* Generate local Reject to the user */
         stGenLocRej(tuSapCp, dlgCp->suDlgId, dlgCp->spDlgId, invId.val,
                     STU_PROB_GENERAL, STU_RSRC_UNAVAIL);
      }

      RETVALUE(RFAILED);
   }

   if (compType == ST_COMP_TYP_REJ)
   {
      /* search hash-table to see if this invocation exists */
      if (stFndInv(&dlgCp->invHlCp, invId.val, &invCp) == ROK)
      {
#ifdef ZT
         ztRunTimeUpd(ZT_INV_CB,
                      CMPFTHA_UPDTYPE_NORMAL,
                      CMPFTHA_ACTN_DEL,
                      (Void *)invCp);
#endif /* ZT */

         /* st026.301: Addition - to check whether it is a remote invoke */
         if(compEv->comp.rej.probType.val != ST_PROB_TYP_INV)
         (Void)stFreeInv(invCp);
      }

      /* Increment the fault statistics counters */
      stUpdFaultSts(&tuSapCp->sts,
                    compEv->comp.rej.probType.val,
                    compEv->comp.rej.probCode.val,
                    tuSapCp->cfg.swtch, ST_STS_TX_MSG);
   }
   if (((StItuCompEv *) compEv)->comp.inv.params.pres)
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(compEv->comp.inv.params.val);

   RETVALUE(ROK);
}  /* End of stCHTxComp */


/*
*
*       Fun:   stCHUCancel
*
*       Desc:  Process the User Invoke Cancel request
*
*       Ret:   ROK       if successful
*              RFAILED   if failure
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16  stCHUCancel
(
StDlgCp   *dlgCp,          /* Dialogue control point */
U8         invId           /* Invoke Id */
)
#else
PUBLIC S16  stCHUCancel(dlgCp, invId)
StDlgCp   *dlgCp;          /* Dialogue control point */
U8         invId;          /* Invoke Id */
#endif
{
   StInvCp   *invCp;       /* invocation control point */
   Bool       found;       /* Flag to indicate if invoke entry is found in Q */
   U16        i;           /* counter to loop thru the Q */
   MsgLen     compLen;     /* length of the component */

   TRC2(stCHUCancel)

   /* search hash-table to see if this invocation exists */
   if (stFndInv(&dlgCp->invHlCp, invId, &invCp) != ROK)
   {
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
         "stCHTxComp:No memory available for encoding invoke(%d) in dlg (%ld)\n"
         ,invId, dlgCp->spDlgId));
      RETVALUE(RFAILED);
   }

   found = FALSE;

   for (i = 0; i < dlgCp->compQ.qLen; i++)
   {
       if ((found == FALSE) &&
           (dlgCp->compQ.q[i].type  == ST_COMP_TYP_INV) &&
           (dlgCp->compQ.q[i].invId == invId))
       {
          found = TRUE;

          /* Compute the size of the Invoke component */
          if ((i + 1) == dlgCp->compQ.qLen)
          {
             /* this is the last entry in the queue */
             (Void)SFndLenMsg(dlgCp->compBuf, &compLen);
             compLen -= dlgCp->compQ.q[i].idx;
          }
          else
          {
             compLen = dlgCp->compQ.q[i+1].idx - dlgCp->compQ.q[i].idx;
          }

          /* Remove component from the buffer */
          stRemOffMsgMult(dlgCp->compBuf, dlgCp->compQ.q[i].idx, compLen);
       }
       else if (found)
       {
          /* shift the components by one to fill the gap */
          dlgCp->compQ.q[i-1].type  = dlgCp->compQ.q[i].type;
          dlgCp->compQ.q[i-1].invId = dlgCp->compQ.q[i].invId;
          dlgCp->compQ.q[i-1].idx   = dlgCp->compQ.q[i].idx;
       }
   }

   if (found)
   {
      /* One component has been removed from the queue, so decrement the
         queue length counter */
      dlgCp->compQ.qLen--;
   }
#ifdef ZT
   else
   {
      ztRunTimeUpd(ZT_INV_CB,
                   CMPFTHA_UPDTYPE_NORMAL,
                   CMPFTHA_ACTN_DEL,
                   (Void *)invCp);
   }
#endif /* ZT */

   /* Free the Invoke control point */
   (Void)stFreeInv(invCp);

   RETVALUE(ROK);
}  /* End of stCHUCancel */


/*
*
*       Fun:   stCHGetComps
*
*       Desc:  Delivers components to dialogue handler
*
*       Ret:   ROK       if successful
*              RFAILED   if failure
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE S16  stCHGetComps
(
StDlgCp   *dlgCp,             /* Associated dialogue */
Buffer   **mBuf               /* Buffer to return components */
)
#else
PRIVATE S16  stCHGetComps(dlgCp, mBuf)
StDlgCp   *dlgCp;             /* Associated dialogue */
Buffer   **mBuf;              /* Buffer to return components */
#endif
{
   StTUSap  *tuSapCp;         /* Upper Sap */
   StSPSap  *spSapCp;         /* Lower Sap */
   StInvCp  *invCp;           /* Current Invocation */
   U16       i;
   
   TRC2(stCHGetComps)

   if (dlgCp->compQ.qLen == 0)
   {
      /* st007.301 - Modified - TC-User Distribution Feature */     
      /* No component in Q, just returns empty message buffer */
      /* Get the lower SAP */
      spSapCp = *(stCb.spSapLst + stGetLSapId(dlgCp->sapCp->spId));

      /* Allocate message buffer from SCCP region, SCCP deallocates it */
      if (SGetMsg(spSapCp->pstSP.region, spSapCp->pstSP.pool, mBuf) != ROK)
      {
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stCHGetComps:SGetMsg failed\n"));
         stSendAlarm(LCM_CATEGORY_RESOURCE, LST_EVENT_MSG_FAIL,
                     LCM_CAUSE_UNKNOWN, NOTUSED, NOTUSED);
         RETVALUE(RFAILED);
      }

      RETVALUE(ROK);
   }

   for (i = 0; i < dlgCp->compQ.qLen; i++)
   {
       if (dlgCp->compQ.q[i].type == ST_COMP_TYP_INV)
       {
          if (stFndInv(&dlgCp->invHlCp, dlgCp->compQ.q[i].invId, &invCp) != ROK)
          {
             /* st009.301 -Add- Debug prints */
             STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                    "stCHGetComps:Invoke(%d) not found in dialogue(%ld)\n",
                     dlgCp->compQ.q[i].invId,dlgCp->spDlgId));
             RETVALUE(RFAILED);
          }

          switch(invCp->opClass)
          {
             case ST_COMP_OPCLS1:
                stItuIsmExec(invCp, E_TX_OP1, NULLP, NULLP);
                break;

             case ST_COMP_OPCLS2:
                stItuIsmExec(invCp, E_TX_OP2, NULLP, NULLP);
                break;

             case ST_COMP_OPCLS3:
                stItuIsmExec(invCp, E_TX_OP3, NULLP, NULLP);
                break;

             case ST_COMP_OPCLS4:
                stItuIsmExec(invCp, E_TX_OP4, NULLP, NULLP);
                break;
          }
#ifdef ZT
          ztRunTimeUpd(ZT_INV_CB,
                       CMPFTHA_UPDTYPE_NORMAL,
                       CMPFTHA_ACTN_ADD,
                       (Void *)invCp);
#endif /* ZT */
       }

       /* Upepr SAP */
       tuSapCp = dlgCp->sapCp;

       /* Increment Resource Statistics */
       stUpdRsrcSts(&tuSapCp->sts, ST_STS_TX_COMP, dlgCp->compQ.q[i].type,
                    tuSapCp->cfg.swtch);
   }

   /* Returns components concatenated in the message buffer */
   *mBuf = dlgCp->compBuf;

   /* Mark the component queue empty */
   dlgCp->compQ.qLen = 0;

   dlgCp->compBuf = NULLP;

   /* Put tag and length of component portion */
   if (stPutTagLen(*mBuf, ST_ITU_COMP_PRTN_TAG) != ROK)
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
}  /* end of stCHGetComps */


/*
*
*       Fun:   stCHDiscardComps
*
*       Desc:  Discards all the components in the component buffer
*
*       Ret:   ROK       if successful
*              RFAILED   if failure
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE S16  stCHDiscardComps
(
StDlgCp   *dlgCp              /* Associated dialogue */
)
#else
PRIVATE S16  stCHDiscardComps(dlgCp)
StDlgCp   *dlgCp;             /* Associated dialogue */
#endif
{
   StInvCp  *invCp;
   U16       i;
   
   TRC2(stCHDiscardComps)

   for (i = 0; i < dlgCp->compQ.qLen; i++)
   {
       if ((dlgCp->compQ.q[i].type == ST_COMP_TYP_INV) &&
           (stFndInv(&dlgCp->invHlCp, dlgCp->compQ.q[i].invId, &invCp) == ROK))
       {
#ifdef ZT
          ztRunTimeUpd(ZT_INV_CB,
                       CMPFTHA_UPDTYPE_NORMAL,
                       CMPFTHA_ACTN_DEL,
                       (Void *)invCp);
#endif /* ZT */

          (Void)stFreeInv(invCp);

       }
   }

   if (dlgCp->compQ.qLen != 0)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(dlgCp->compBuf);

      dlgCp->compQ.qLen = 0;
   }

   RETVALUE(ROK);
}  /* end of stCHDiscardComps */


/*
*
*       Fun:   stCHPutComps
*
*       Desc:  Delivers components to the service user
*
*       Ret:   ROK       if successful
*              RFAILED   if failure
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE S16  stCHPutComps
(
/* st008.301 - Modify - Function prototype modified */
StTUSap   *tuSapCp,           /* Tcap Upper Sap */
StDlgId   dlgId,              /* Dialogue Id to search */
Buffer    *mBuf               /* Buffer containing components */
)
#else
PRIVATE S16  stCHPutComps(tuSapCp, dlgId, mBuf)
/* st008.301 - Modify - Function prototype modified */
StTUSap   *tuSapCp;           /* Tcap Upper Sap */
StDlgId   dlgId;              /* Dialogue Id to search */
Buffer    *mBuf;              /* Buffer containing components */
#endif
{
   StInvCp     *invCp;    /* Invoke Control point */
   StItuCompEv  compEv;   /* Component event structure */
   StComps      oCompEv;  /* Old style component event */
   U8           compType; /* component type */
   TknInvId     invId;    /* Invoke Id */
   Buffer      *pBuf;     /* Parameter buffer */
   Swtch        pSwtch;   /* Protocol Switch */
   U8           probCode; /* Problem code returned by decode function */
   Bool         lastComp; /* Flag to indicate the last component in the message */
   StEvent      smEvent;  /* Invoke state machine event */
   /* st008.301 - Add - Dialogue Control Point  */
   StDlgCp   *dlgCp;      /* Dialogue control point */ 
   /* st016.301 -Add- variable compDec */
   Bool      compDec;    /* Flag to specify whether component is decoded */

   TRC2(stCHPutComps)

   /* st008.301 -Add- Use the dialogue id to find the dialogue control block,
    * if it does not exist anymore, discard the message and return */
   if (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, dlgId, ST_USE_SPDLGID, &dlgCp) != ROK)
   {
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
            "stCHPutComps:Cannot find dialogue(%ld)\n",dlgId));
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf); /* Message discarded since dialog block not found */
      RETVALUE(ROK);
   }  
      
   /* Get the protocol switch from the Sap configuration */
   pSwtch = dlgCp->sapCp->cfg.swtch;

   lastComp = FALSE;

   /* Loop thru all the components in the buffer */
   while (!lastComp)
   {
      /* Decode the component */
      /* st016.301 -Add- parameter compDec */
      if (stDecComp((PTR)&compEv, pSwtch, mBuf, &probCode, &lastComp,
                    &compDec) != ROK)
      {
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(mBuf);  /* Deallocate the message buffer */

         /* Get the invoke Id, component type and parameter buffer */
         if (stGetCompInvId((PTR)&compEv, pSwtch, &compType, &invId, &pBuf)
             != ROK)
         {
            lastComp = TRUE;
            continue;
         }

         /* If parameter buffer was allocated then deallocate it */
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(pBuf); /* Deallocate parameter buffer */

         /* Don't generate Reject for error in Reject component itself */
         if (compType == ST_COMP_TYP_REJ)
         {
            lastComp = TRUE;
            /* st023.301 - Addition, generate a local reject to the user */
            stGenLocRej(tuSapCp, dlgCp->suDlgId, dlgCp->spDlgId, invId.val,
                        STU_PROB_GENERAL, STU_BAD_STRUC_COMP);
            continue;
         }

         /* Terminate the ISM for this invoke */
         if ((invId.pres) &&
             (stFndInv(&dlgCp->invHlCp, invId.val, &invCp) == ROK))
         {
            (Void)stItuIsmExec(invCp, E_TERM, NULLP, NULLP);
         }

         /* st016.301 -Add- if component is not decoded, compType wasnt
          * extracted, no need to set probCode
          */
         if (compDec)
         {
            /* Modify the problem code for unrecognized component type */
            if (compType == ST_COMP_TYP_UNK)
            {
               probCode = ST_GEN_UR_COMP;
            }
         }

         /* Generate the reject component */
         (Void)stCHGenRej(dlgCp, &invId, ST_PROB_TYP_GEN, probCode);

         lastComp = TRUE;
         continue;
      }

      stGetCompInvId((PTR)&compEv, dlgCp->sapCp->cfg.swtch, &compType, &invId,
                     &pBuf);

      if (lastComp)
      {
         /* Component has been decoded, so deallocate the message buffer */
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(mBuf);
      }

      /* Increment Statistics */
      stUpdRsrcSts(&dlgCp->sapCp->sts, ST_STS_RX_COMP, compType,
                   dlgCp->sapCp->cfg.swtch);

      switch(compType)
      {
         case ST_COMP_TYP_INV:

            if (compEv.comp.inv.linkedId.pres == TRUE)
            {
               StInvId    lnkId;

               lnkId = compEv.comp.inv.linkedId.val;

               if (stFndInv(&dlgCp->invHlCp, lnkId, &invCp) != ROK)
               {
                  /* st027.301 - Modify - Modify the user buf free mechanism */ 
                  STFREEUSERBUF(pBuf); /* Deallocate parameter buffer */
                  /* st009.301 -Add- Debug prints */
                  STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                       "stCHPutComps:Cannot find Invoke(%d) in dialogue(%ld)\n"
                       ,lnkId,dlgCp->spDlgId));
                  /* Generate reject component and send indication to the user */

                  (Void)stCHGenRej(dlgCp, &invId, ST_PROB_TYP_INV, ST_INV_UR_LKID); 
                  continue;
               }

               if (invCp->numLnkdInv < (U8)ST_MAX_LINKED_INV)
               {
                  invCp->lnkdInv[invCp->numLnkdInv] = lnkId;
                  invCp->numLnkdInv++;
#ifdef ZT
                  ztRunTimeUpd(ZT_INV_CB,
                               CMPFTHA_UPDTYPE_NORMAL,
                               CMPFTHA_ACTN_MOD,
                               (Void *)invCp);
#endif /* ZT */
               }
               else
               {
                  /* If no free entry available for this linked invoke */

                  /* st027.301 - Modify - Modify the user buf free mechanism */ 
                  STFREEUSERBUF(pBuf); /* Deallocate parameter buffer */

                  /* Generate reject component and send indication to the user */
                  (Void)stCHGenRej(dlgCp, &invId, ST_PROB_TYP_INV, ST_INV_LM_RSRC); 

                  continue;
               }
            }

            /* Copy the new style component event to the old style component
               event */
            stCpyItuCompEv(&oCompEv, &compEv, &pBuf, M2M1);

            /* Flag to indicate if it is the last component */
            oCompEv.stLastCmp = lastComp;

            StUiStuCmpInd( &dlgCp->sapCp->pstTU,
                            dlgCp->sapCp->suId,
                            dlgCp->suDlgId,
                            dlgCp->spDlgId,
                           &oCompEv,
                            dlgCp->opc,
                            STU_INVOKE,
                            pBuf );

            break;

         case ST_COMP_TYP_RES:
         case ST_COMP_TYP_RNL:

            if (stFndInv(&dlgCp->invHlCp, invId.val, &invCp) != ROK)
            {
               /* st027.301 - Modify - Modify the user buf free mechanism */ 
               STFREEUSERBUF(pBuf); /* Deallocate parameter buffer */

               /* Generate reject component and send indication to the user */
               (Void)stCHGenRej(dlgCp, &invId, ST_PROB_TYP_RES, ST_RES_UR_IVID); 
               /* st009.301 -Add- Debug prints */
               STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stCHPutComps:Can't find Invoke(%d) in dialogue(%ld)\n",
                invId.val,dlgCp->spDlgId));

               continue;
            }

            if (compType == ST_COMP_TYP_RES)
            {
               smEvent = E_RX_RRL;
            }
            else
            {
               smEvent = E_RX_RRNL;
            }

            if (stItuIsmExec(invCp, smEvent, (PTR)&compEv, (PTR)&lastComp)
                != ROK)
            {
               /* st027.301 - Modify - Modify the user buf free mechanism */ 
               STFREEUSERBUF(pBuf); /* Deallocate parameter buffer */

               /* st009.301 -Add- Debug prints */
               STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                 "stCHPutComps:ISM execution error -unexpected result\n"));
               /* Generate reject component and send indication to the user */
               (Void)stCHGenRej(dlgCp, &invId, ST_PROB_TYP_RES, ST_RES_UX_RRES); 

               continue;
            }
            break;

         case ST_COMP_TYP_ERR:

            if (stFndInv(&dlgCp->invHlCp, compEv.comp.res.invokeId.val, &invCp)
                != ROK)
            {
               /* st027.301 - Modify - Modify the user buf free mechanism */ 
               STFREEUSERBUF(pBuf); /* Deallocate parameter buffer */
               /* Generate reject component and send indication to the user */
               (Void)stCHGenRej(dlgCp, &invId, ST_PROB_TYP_ERR, ST_ERR_UR_IVID); 
               continue;
            }

            if (stItuIsmExec(invCp, E_RX_RE, (PTR)&compEv, (PTR)&lastComp)
                != ROK)
            {
               /* st027.301 - Modify - Modify the user buf free mechanism */ 
               STFREEUSERBUF(pBuf); /* Deallocate parameter buffer */
               /* Generate reject component and send indication to the user */
               (Void)stCHGenRej(dlgCp, &invId, ST_PROB_TYP_ERR, ST_ERR_UX_RERR); 
               continue;
            }
            break;

         case ST_COMP_TYP_REJ:

            if (compEv.comp.rej.probType.val == ST_PROB_TYP_INV)
            {
               if (stFndInv(&dlgCp->invHlCp, invId.val, &invCp) == ROK)
               {
                  stItuIsmExec(invCp, E_RX_REJ, (PTR)&compEv, (PTR)&lastComp);
                  continue;
               }
            }

            /* Send Reject component indication to the user */
            stCHRejInd(dlgCp, (PTR)&compEv, lastComp);
            break;

         default:
            /* st009.301 -Add-  Print debug info */
            STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                   "stCHPutComps:Invalid component type(%d) in dialogue(%ld)\n"
                   ,compType,dlgCp->spDlgId));
            break;
      } /* switch */
      
      /* st008.301 - Add - Use dialoge id to find the dialogue control point,
       * if it does not exist anymore, discard the message and return */
      if (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, dlgId, ST_USE_SPDLGID, &dlgCp) != ROK)
      {
         /* st017.301 -Modify- If mBuf hasnt been deallocated as part of last
          * component processing, deallocate it
          */
         if (!lastComp)     
            /* st027.301 - Modify - Modify the user buf free mechanism */ 
            STFREEUSERBUF(mBuf); /* Message discarded */
         RETVALUE(ROK);
      }   
   }

   RETVALUE(ROK);
}  /* End of stCHPutComps */


/*
*
*       Fun:   stCHRejInd
*
*       Desc:  Send Reject component indication to the TC-user
*
*       Ret:   ROK       if successful
*              RFAILED   if failure
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE S16 stCHRejInd
(
StDlgCp    *dlgCp,     /* Dialogue control point */
PTR         compEv,    /* Component event structure */
Bool        lastComp   /* Flag to indicate the last component */
)
#else
PRIVATE S16 stCHRejInd(dlgCp, compEv, lastComp)
StDlgCp    *dlgCp;     /* Dialogue control point */
PTR         compEv;    /* Component event structure */
Bool        lastComp;  /* Flag to indicate the last component */
#endif
{
   U8          probType;
   U8          probCode;
   StComps     oCompEv;
   Status      status;

   TRC2(stCHRejInd)

   probType = ((StItuCompEv *)compEv)->comp.rej.probType.val;
   probCode = ((StItuCompEv *)compEv)->comp.rej.probCode.val;

   /* Copy the new style component event to the old style component
      event */
   stCpyItuCompEv(&oCompEv, (StItuCompEv *)compEv, NULLP, M2M1);

   oCompEv.stLastCmp = lastComp;

   /* Initialize the status assuming Reject was generated by the Remote
      User */
   status = STU_COMP_REJ_USR;

   /* Now analyze the problem code to see if it was generated by the remote
      TCAP */
   switch(probType)
   {
      case ST_PROB_TYP_GEN:
         status = STU_COMP_REJ_REMOTE;
         break;

      case ST_PROB_TYP_INV:

         switch(probCode)
         {
            case ST_INV_UR_LKID:
               status = STU_COMP_REJ_REMOTE;
               break;
         }
         break;

      case ST_PROB_TYP_RES:

         switch(probCode)
         {
            case ST_RES_UR_IVID:
            case ST_RES_UX_RRES:
               status = STU_COMP_REJ_REMOTE;
               break;
         }
         break;

      case ST_PROB_TYP_ERR:

         switch(probCode)
         {
            case ST_ERR_UR_IVID:
            case ST_ERR_UX_RERR:
               status = STU_COMP_REJ_REMOTE;
               break;
         }
         break;
   }

   /* Increment the fault statistics counters */
   stUpdFaultSts(&dlgCp->sapCp->sts, probType, probCode,
                 dlgCp->sapCp->cfg.swtch, ST_STS_RX_MSG);

   StUiStuCmpInd( &dlgCp->sapCp->pstTU,
                   dlgCp->sapCp->suId,
                   dlgCp->suDlgId,
                   dlgCp->spDlgId,
                  &oCompEv,
                   dlgCp->opc,
                   status,
                   NULLP );

   RETVALUE(ROK);
} /* End of stCHRejInd */


/*
*
*       Fun:   stCHGenRej
*
*       Desc:  Generate a reject component and send indication to the user
*
*       Ret:   ROK       if successful
*              RFAILED   if failure
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE S16 stCHGenRej
(
StDlgCp    *dlgCp,     /* Dialogue control point */
TknInvId   *invId,     /* Pointer to Invoke Id */
U8          probType,  /* Type of the problem code */
U8          probCode   /* Problem Code */
)
#else
PRIVATE S16 stCHGenRej(dlgCp, invId, probType, probCode)
StDlgCp    *dlgCp;     /* Dialogue control point */
TknInvId   *invId;     /* Pointer to Invoke Id */
U8          probType;  /* Type of the problem code */
U8          probCode;  /* Problem Code */
#endif
{
   StTUSap      *tuSapCp; /* Upper Sap */
   StSPSap      *spSapCp; /* Lower Sap */
   StItuCompEv   compEv;  /* Component event structure */
   StComps       oCompEv;
   Buffer       *mBuf;    /* Message buffer */
   Buffer       *pBuf;    /* Parameter buffer */

   TRC2(stCHGenRej)

   /* st009.301 -Add-  Print debug info */
   STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
     "stCHGenRej:dialogue(%ld) invoke(%d), problem type(%d),problem code(%d)\n",
     dlgCp->spDlgId,invId->val, probType, probCode));
   
   /* Initialize the transaction portion event structure */
   (Void)stZeroEv((Data *)&compEv, ST_TYP_CMP_PRTN, dlgCp->sapCp->cfg.swtch);

   compEv.compType.pres = TRUE;
   compEv.compType.val  = ST_COMP_TYP_REJ;

   compEv.comp.rej.pres.pres = TRUE;

   /* If invoke Id can't be extracted then encode a NULL in the reject
      component */
   compEv.comp.rej.invNull.pres  = TRUE;

   if (invId->pres == FALSE)
   {
      /* Invoke id couldn't be extracted, encode Null instead */
      compEv.comp.rej.invNull.val   = ST_REJ_INV_NULL;
   }
   else
   {
      compEv.comp.rej.invNull.val   = ST_REJ_INV_ID;
   }
   compEv.comp.rej.invokeId.pres = TRUE;
   compEv.comp.rej.invokeId.val  = invId->val;

   compEv.comp.rej.probType.pres = TRUE;
   compEv.comp.rej.probType.val  = probType;
   compEv.comp.rej.probCode.pres = TRUE;
   compEv.comp.rej.probCode.val  = probCode;

   /* Get the upper Sap */
   tuSapCp = dlgCp->sapCp;

   /* st007.301 - Modified - TC-User Distribution Feature */
   /* Get the lower sap from the lower sap list */
   spSapCp = *(stCb.spSapLst + stGetLSapId(tuSapCp->spId));

   /* Allocate message buffer from the SCCP region */
   if (SGetMsg(spSapCp->pstSP.region, spSapCp->pstSP.pool, &mBuf) != ROK)
   {
      /* st009.301 -Add-  Print debug info */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stCHGenRej:SGetMsg failed\n"));
      stSendAlarm(LCM_CATEGORY_RESOURCE, LST_EVENT_MSG_FAIL, LCM_CAUSE_UNKNOWN,
                  NOTUSED, NOTUSED);
      RETVALUE(RFAILED);
   }

   /* Encode the Reject Component */
   if (stEncComp((PTR)&compEv, tuSapCp->cfg.swtch, mBuf) != ROK)
   {
      /* st009.301 -Add-  Print debug info */
      STDBGP(ST_DBGMASK_ENCODE, (stCb.init.prntBuf,
             "stCHGenRej:Reject component encode failure in dialogue(%ld)\n",
             dlgCp->spDlgId));
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);
      RETVALUE(RFAILED);
   }

   /* Store the reject component in the Component Queue */
   if (stCompQLast(dlgCp, mBuf, ST_COMP_TYP_REJ, invId) != ROK)
   {
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
           "stCHGenRej:Failed to add the component in the queue for dlg(%ld)\n",
           dlgCp->spDlgId));
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);
      stSendAlarm(LCM_CATEGORY_RESOURCE, LST_EVENT_MSG_FAIL, LCM_CAUSE_UNKNOWN,
                  NOTUSED, NOTUSED);
      RETVALUE(RFAILED);
   }

   /* Increment the fault statistics counters */
   stUpdFaultSts(&tuSapCp->sts, probType, probCode, tuSapCp->cfg.swtch, ST_STS_TX_MSG);

   if (invId->pres == FALSE)
   {
      compEv.comp.rej.invokeId.pres = FALSE;
   }

   /* Generate a Local Reject component indication to the service user */
   stCpyItuCompEv(&oCompEv, &compEv, &pBuf, M2M1);

   oCompEv.stLastCmp = TRUE;

   StUiStuCmpInd( &dlgCp->sapCp->pstTU,
                   dlgCp->sapCp->suId,
                   dlgCp->suDlgId,
                   dlgCp->spDlgId,
                  &oCompEv,
                   dlgCp->opc,
                   STU_COMP_REJ_QLOCAL,
                   NULLP );

   RETVALUE(ROK);
} /* End of stCHGenRej */


/*
*
*       Fun:    stIsmActOp
*
*       Desc:   ISM Action Routine for Operation Sent Event
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void stIsmActOp
(
PTR        invCp,      /* Invoke control point */
PTR        data1,      /* Data not used in this function */
PTR        data2       /* Data not used in this function */
)
#else
PRIVATE Void stIsmActOp (invCp, data1, data2)
PTR        invCp;      /* Invoke control point */
PTR        data1;      /* Data not used in this function */
PTR        data2;      /* Data not used in this function */
#endif
{
   TRC2(stIsmActOp)

   UNUSED(data1);
   UNUSED(data2);

   /* Start Invocation timer */
   stStartTmr(ST_INV_TMR, invCp);

   RETVOID;
}  /*End of stIsmActOp */


/*
*
*       Fun:    stIsmActTerm
*
*       Desc:   ISM Action Routine for Invocation Termination Event
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void stIsmActTerm
(
PTR        invCp,      /* Invoke control point */
PTR        data1,      /* Data not used in this function */
PTR        data2       /* Data not used in this function */
)
#else
PRIVATE Void stIsmActTerm (invCp, data1, data2)
PTR        invCp;      /* Invoke control point */
PTR        data1;      /* Data not used in this function */
PTR        data2;      /* Data not used in this function */
#endif
{
   TRC2(stIsmActTerm)

   UNUSED(data1);
   UNUSED(data2);

#ifdef ZT
   ztRunTimeUpd(ZT_INV_CB,
                CMPFTHA_UPDTYPE_NORMAL,
                CMPFTHA_ACTN_DEL,
                (Void *)invCp);
#endif /* ZT */

   /* Release the invoke control point */
   stFreeInv((StInvCp *)invCp);

   RETVOID;
}  /*End of stIsmActTerm */


/*
*
*       Fun:    stIsmActInvTmr
*
*       Desc:   ISM Action Routine for Invoke Timer Expiry Event
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void stIsmActInvTmr
(
PTR        invCp,      /* Invoke control point */
PTR        data1,      /* Data not used in this function */
PTR        data2       /* Data not used in this function */
)
#else
PRIVATE Void stIsmActInvTmr (invCp, data1, data2)
PTR        invCp;      /* Invoke control point */
PTR        data1;      /* Data not used in this function */
PTR        data2;      /* Data not used in this function */
#endif
{
   StTUSap    *tuSapCp;
   StDlgCp    *dlgCp;
   StComps     compEv;

   TRC2(stIsmActInvTmr)

   UNUSED(data1);
   UNUSED(data2);

   dlgCp   = ((StInvCp *)invCp)->dlgCp;
   tuSapCp = dlgCp->sapCp;

   /* build Cancel in Reject Component */
   cmZeroStComp(&compEv);

   compEv.stCompType       = STU_REJECT;
   compEv.cancelFlg        = TRUE;
   compEv.stLastCmp        = TRUE;
   compEv.stInvokeId.pres  = TRUE;
   compEv.stInvokeId.octet = ((StInvCp *)invCp)->invId;

   /* xingzhou.xu: added for indicating the problem --2006/09/13 */
   compEv.stProbCodeFlg        = STU_PROB_INVOKE;
   compEv.stProbCode.len       = 1;
   compEv.stProbCode.string[0] = STU_INVOKE_TIMEOUT;
 
#ifdef ZT
   ztRunTimeUpd(ZT_INV_CB,
                CMPFTHA_UPDTYPE_NORMAL,
                CMPFTHA_ACTN_DEL,
                (Void *)invCp);
#endif /* ZT */

   /* Release the invoke control point */
   stFreeInv((StInvCp *)invCp);

   StUiStuCmpInd( &tuSapCp->pstTU,
                   tuSapCp->suId,
                   dlgCp->suDlgId,
                   dlgCp->spDlgId,
                  &compEv,
                   dlgCp->opc,
                   STU_COMP_CANCEL,
                   NULLP );

   RETVOID;
}  /*End of stIsmActInvTmr */


/*
*
*       Fun:    stIsmActRejTmr
*
*       Desc:   ISM Action Routine for Reject Timer Expiry Event
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void stIsmActRejTmr
(
PTR        invCp,      /* Invoke control point */
PTR        data1,      /* Data not used in this function */
PTR        data2       /* Data not used in this function */
)
#else
PRIVATE Void stIsmActRejTmr (invCp, data1, data2)
PTR        invCp;      /* Invoke control point */
PTR        data1;      /* Data not used in this function */
PTR        data2;      /* Data not used in this function */
#endif
{
   TRC2(stIsmActRejTmr)

   UNUSED(data1);
   UNUSED(data2);

#ifdef ZT
   ztRunTimeUpd(ZT_INV_CB,
                CMPFTHA_UPDTYPE_NORMAL,
                CMPFTHA_ACTN_DEL,
                (Void *)invCp);
#endif /* ZT */

   /* Release the invoke control point */
   stFreeInv((StInvCp *)invCp);

   RETVOID;
}  /*End of stIsmActRejTmr */


/*
*
*       Fun:    stIsmActCmp
*
*       Desc:   ISM Action Routine for Component received Event
*
*       Ret:    RETVOID
*
*       Notes:  Component is of type Return-Result-Last,
*               Return-Result-Not-Last and Return-Error.
*
*       File:   ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void stIsmActCmp
(
PTR        invCp,      /* Invoke control point */
PTR        compEv,     /* Component event structure */
PTR        lastCmp     /* Last component flag */
)
#else
PRIVATE Void stIsmActCmp (invCp, compEv, lastCmp)
PTR        invCp;      /* Invoke control point */
PTR        compEv;     /* Component event structure */
PTR        lastCmp;    /* Last component flag */
#endif
{
   StTUSap    *tuSapCp;     /* Upper Sap */
   StDlgCp    *dlgCp;       /* Dialogue control point */
   U8          compType;    /* Component type */
   StComps     oCompEv;     /* old style component event */
   Buffer     *pBuf;        /* Parameters buffer */
   Bool        updFlag;
   /* st019.301 - Addition */
   Bool        freeFlag;    /* Invoke control free flag */

   TRC2(stIsmActCmp)

   dlgCp    = ((StInvCp *)invCp)->dlgCp;
   tuSapCp  = dlgCp->sapCp;
   updFlag  = FALSE;
   /* st019.301 - Addition */
   freeFlag = FALSE;

   compType = ((StItuCompEv *)compEv)->compType.val;

   if (compType != ST_COMP_TYP_RNL)
   {
      /* Stop invocation timer and start reject timer */
      stStopTmr(ST_INV_TMR, (StInvCp *)invCp);

      if (stStartTmr(ST_REJ_TMR, invCp) != ROK)
      {
#ifdef ZT
         ztRunTimeUpd(ZT_INV_CB,
                      CMPFTHA_UPDTYPE_NORMAL,
                      CMPFTHA_ACTN_DEL,
                      (Void *)invCp);
         updFlag = TRUE;
#endif /* ZT */

         /* st019.301 - Deletion, set the flag and free the invoke 
          * control block at the end of this function. We can not 
          * return from here because component still needed to be 
          * sent to user if case of reject timer can not be started.
          */
         freeFlag = TRUE;
      }
   }

#ifdef ZT
   if (!updFlag)
   {
      ztRunTimeUpd(ZT_INV_CB,
                   CMPFTHA_UPDTYPE_NORMAL,
                   CMPFTHA_ACTN_MOD,
                   (Void *)invCp);
   }
#endif /* ZT */

   if (compType == ST_COMP_TYP_REJ)
   {
      /* Increment the fault statistics counters */
      stUpdFaultSts(&tuSapCp->sts, ((StItuCompEv *)compEv)->comp.rej.probType.val,
                    ((StItuCompEv *)compEv)->comp.rej.probCode.val,
                    tuSapCp->cfg.swtch, ST_STS_RX_MSG);
   }

   /* Copy the new style component event to the old style component event */
   stCpyItuCompEv(&oCompEv, (StItuCompEv *)compEv, &pBuf, M2M1);

   oCompEv.stLastCmp = *(Bool *)lastCmp;

   /* Send the component to TC-User */
   StUiStuCmpInd( &tuSapCp->pstTU,
                   tuSapCp->suId,
                   dlgCp->suDlgId,
                   dlgCp->spDlgId,
                  &oCompEv,
                   dlgCp->opc,
                   oCompEv.stCompType,
                   pBuf );

   /* st019.301 - Addition, free the invoke control block if flag is set */
   if (freeFlag == TRUE)
   {
      (Void)stFreeInv((StInvCp *)invCp);
   }
   RETVOID;
}  /* End of stIsmActCmp */


/*
*
*       Fun:    stIsmActRej
*
*       Desc:   ISM Action Routine for Reject Component received Event
*
*       Ret:    RETVOID
*
*       Notes:  None 
*
*       File:   ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void stIsmActRej
(
PTR        invCp,      /* Invoke control point */
PTR        compEv,     /* Component event structure */
PTR        lastCmp     /* Last component flag */
)
#else
PRIVATE Void stIsmActRej (invCp, compEv, lastCmp)
PTR        invCp;      /* Invoke control point */
PTR        compEv;     /* Component event structure */
PTR        lastCmp;    /* Last component flag */
#endif
{
   StDlgCp    *dlgCp;       /* Dialogue control point */

   TRC2(stIsmActCmp)

   dlgCp = ((StInvCp *)invCp)->dlgCp;

#ifdef ZT
   ztRunTimeUpd(ZT_INV_CB,
                CMPFTHA_UPDTYPE_NORMAL,
                CMPFTHA_ACTN_DEL,
                (Void *)invCp);
#endif /* ZT */

   /* Free the instance of Invoke Control point */
   (Void)stFreeInv((StInvCp *)invCp);

   /* Send the indication to the TC-User */
   stCHRejInd(dlgCp, compEv, *(Bool *)lastCmp);

   RETVOID;
}  /* End of stIsmActRej */


/*
*
*       Fun:    stIsmActIRes
*
*       Desc:   ISM Action Routine for Invalid Return-Result Received Event
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void stIsmActIRes
(
PTR        invCp,      /* Invoke control point */
PTR        compEv,     /* Component event structure */
PTR        data1       /* Data not used in this function */
)
#else
PRIVATE Void stIsmActIRes (invCp, compEv, data1)
PTR        invCp;      /* Invoke control point */
PTR        compEv;     /* Component event structure */
PTR        data1;      /* Data not used in this function */
#endif
{
   StDlgCp  *dlgCp;  /* Dialogue control point */
   TknInvId  invId;  /* Invoke Id */

   UNUSED(data1);

   TRC2(stIsmActIRes)

   invId.pres = TRUE;
   invId.val  = ((StInvCp *)invCp)->invId;

   /* Deallocate the parameter buffer if present */
   if (((StItuCompEv *)compEv)->comp.res.params.pres)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(((StItuCompEv *)compEv)->comp.res.params.val);
   }

   dlgCp = ((StInvCp *)invCp)->dlgCp;

#ifdef ZT
   ztRunTimeUpd(ZT_INV_CB,
                CMPFTHA_UPDTYPE_NORMAL,
                CMPFTHA_ACTN_DEL,
                (Void *)invCp);
#endif /* ZT */

   /* Free the Invoke Control point */
   (Void)stFreeInv((StInvCp *)invCp);
   
   /* Generate reject component and send indication to the user */
   (Void)stCHGenRej(dlgCp, &invId, ST_PROB_TYP_RES, ST_RES_UX_RRES);

   RETVOID;
}  /* End of stIsmActIRes */


/*
*
*       Fun:    stIsmActIErr
*
*       Desc:   ISM Action Routine for Invalid Return-Error Received Event
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void stIsmActIErr
(
PTR        invCp,      /* Invoke control point */
PTR        compEv,     /* Component event structure */
PTR        data1       /* Data not used in this function */
)
#else
PRIVATE Void stIsmActIErr (invCp, compEv, data1)
PTR        invCp;      /* Invoke control point */
PTR        compEv;     /* Component event structure */
PTR        data1;      /* Data not used in this function */
#endif
{
   StDlgCp  *dlgCp;  /* Dialogue control point */
   TknInvId  invId;  /* Invoke Id */

   TRC2(stIsmActIErr)

   UNUSED(data1);

   invId.pres = TRUE;
   invId.val  = ((StInvCp *)invCp)->invId;

   /* Deallocate the parameter buffer if present */
   if (((StItuCompEv *)compEv)->comp.err.params.pres)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(((StItuCompEv *)compEv)->comp.err.params.val);
   }

   dlgCp = ((StInvCp *)invCp)->dlgCp;

#ifdef ZT
   ztRunTimeUpd(ZT_INV_CB,
                CMPFTHA_UPDTYPE_NORMAL,
                CMPFTHA_ACTN_DEL,
                (Void *)invCp);
#endif /* ZT */

   /* Free the Invoke Control point */
   (Void)stFreeInv((StInvCp *)invCp);
   
   /* Generate reject component and send indication to the user */
   (Void)stCHGenRej(dlgCp, &invId, ST_PROB_TYP_ERR, ST_ERR_UX_RERR);

   RETVOID;
}  /* End of stIsmActIErr */



/************************************************************************
                   Dialogue Handler Routines
************************************************************************/

/*
*
*       Fun:   stDHTxUni
*
*       Desc:  Dialogue handler routine to Transmit a Unidirectional message
*
*       Ret:   ROK     if successful
*              RFAILED if failure
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16  stDHTxUni
(
StDlgCp     *dlgCp,         /* Dlg control point */
StAcn       *acn,           /* Application context name */
TknBuf      *usrInfo,       /* User Information */
StQosSet    *qos            /* QOS parameters */
)
#else
PUBLIC S16  stDHTxUni(dlgCp, acn, usrInfo, qos)
StDlgCp     *dlgCp;         /* Dlg control point */
StAcn       *acn;           /* Application context name */
TknBuf      *usrInfo;       /* User Information */
StQosSet    *qos;           /* QOS parameters */
#endif
{
   StTUSap     *tuSapCp;    /* Upper Sap */
   Buffer      *mBuf;       /* Message Buffer */
   MsgLen       bufLen;     /* Message buffer length */
   StItuDlgEv   dlgEv;      /* Dialogue Event structure */

   TRC2(stDHTxUni)

   /* collect all the pending components for this dialogue from CH */
   if (stCHGetComps(dlgCp, &mBuf) != ROK)
   {
      /* st009.301 -Add -print the error */
      if (dlgCp != NULLP)
      {
         /* st025.301 - Modification, fixed debug message error */
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stDHTxUni:stCHGetComps failed for dialogue(%ld)\n",
                dlgCp->spDlgId));
      }        
      RETVALUE(RFAILED);
   }

   (Void)SFndLenMsg(mBuf, &bufLen);

   /* Component portion is mandatory in Uni Message */
   if (bufLen == 0)
   {
      stSendAlarm(LCM_CATEGORY_PROTOCOL, LST_EVENT_MAND_MIS, LCM_CAUSE_UNKNOWN,
                  NOTUSED, NOTUSED);

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST221, (ErrVal)0,
                 "stDHTxUni:Mandatory Component portion missing");
#endif
      RETVALUE(RFAILED);
   }

   /* Get the upper sap */
   tuSapCp = dlgCp->sapCp;

   /* Encode the dialogue portion, if application context name is present */
   if (acn->pres)
   {
      /* Prepares the dialogue event structure */
      stInitItuDlgEv(&dlgEv, ST_DLG_TYP_UNI, acn, usrInfo, 0, 0, 0);

      /* Encode the dialogue portion */
      if (stEncDlg((PTR)&dlgEv, tuSapCp->cfg.swtch, mBuf) != ROK)
      {
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
         STLOGERROR(ERRCLS_DEBUG, EST222, (ErrVal)0,
                    "stDHTxUni:stEncDlg failed");
#endif
         RETVALUE(RFAILED);
      }
 
      /* update the DH state */
      dlgCp->dhaSt = S_DHA_IDLE;
   }

   /* Call transaction Handler routine to send Uni message */
   stTHTxUni(dlgCp, qos, mBuf);

   RETVALUE(ROK);
}   /* End of stDHTxUni */


/*
*
*       Fun:   stDHTxBgn
*
*       Desc:  Dialogue handler routine to Transmit a Begin message
*
*       Ret:   ROK     if successful
*              RFAILED if failure
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16  stDHTxBgn
(
StDlgCp     *dlgCp,         /* Dlg control point */
StAcn       *acn,           /* Application context name */
TknBuf      *usrInfo,       /* User Information */
StQosSet    *qos            /* QOS parameters */
)
#else
PUBLIC S16  stDHTxBgn(dlgCp, acn, usrInfo, qos)
StDlgCp     *dlgCp;         /* Dlg control point */
StAcn       *acn;           /* Application context name */
TknBuf      *usrInfo;       /* User Information */
StQosSet    *qos;           /* QOS parameters */
#endif
{
   StTUSap     *tuSapCp;    /* Upper Sap */
   Buffer      *mBuf;       /* Message Buffer */
   StItuDlgEv   dlgEv;      /* Dialogue Event structure */

   TRC2(stDHTxBgn)

   /* collect all the pending components for this dialogue from CH */
   if (stCHGetComps(dlgCp, &mBuf) != ROK)
   {
      /* st009.301 -Add -print the error */
      if (dlgCp != NULLP)
      {
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stDHTxBgn:stCHGetComps failed for dialogue(%ld)\n",
                 dlgCp->spDlgId));
      }        
      RETVALUE(RFAILED);
   }

   /* Get the upper sap */
   tuSapCp = dlgCp->sapCp;

   /* Encode dialogue APDU, if present */

   if (acn->pres)
   {
      /* Prepares the dialogue event structure */
      stInitItuDlgEv(&dlgEv, ST_DLG_TYP_REQ, acn, usrInfo, 0, 0, 0);

      /* Encode the dialogue portion */
      if (stEncDlg((PTR)&dlgEv, tuSapCp->cfg.swtch, mBuf) != ROK)
      {
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
         STLOGERROR(ERRCLS_DEBUG, EST223, (ErrVal)0,
                    "stDHTxBgn:stEncDlg failed");
#endif
         RETVALUE(RFAILED);
      }
 
      /* update the DH state, Application Conext sent  */
      dlgCp->dhaSt = S_DHA_AC_TX;
   }

   /* Execute the Transaction State Machine */
   if (stItuTsmExec(dlgCp, E_TX_BGN, (PTR)mBuf, (PTR)qos) != ROK)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);
      (Void)stFreeDlg(dlgCp);

      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
        "stDHTxBgn:Execution of stItuTsmExec routine failed for dialogue(%ld)\n"
        ,dlgCp->spDlgId));
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
}   /* End of stDHTxBgn */


/*
*
*       Fun:   stDHTxCnt
*
*       Desc:  Dialogue handler routine to Transmit a Continue message
*
*       Ret:   ROK     if successful
*              RFAILED if failure
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16  stDHTxCnt
(
StDlgCp     *dlgCp,         /* Dlg control point */
StAcn       *acn,           /* Application context name */
TknBuf      *usrInfo,       /* User Information */
StQosSet    *qos            /* QOS parameters */
)
#else
PUBLIC S16  stDHTxCnt(dlgCp, acn, usrInfo, qos)
StDlgCp     *dlgCp;         /* Dlg control point */
StAcn       *acn;           /* Application context name */
TknBuf      *usrInfo;       /* User Information */
StQosSet    *qos;           /* QOS parameters */
#endif
{
   StTUSap     *tuSapCp;    /* Upper Sap */
   Buffer      *mBuf;       /* Message Buffer */
   StItuDlgEv   dlgEv;      /* Dialogue Event structure */

   TRC2(stDHTxCnt)

   /* collect all the pending components for this dialogue from CH */
   if (stCHGetComps(dlgCp, &mBuf) != ROK)
   {
      dlgCp->dhaSt = S_DHA_IDLE;
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stDHTxCnt:Execution of stCHGetComps failed, dialogue Id(%ld)\n",
             dlgCp->spDlgId));
      RETVALUE(RFAILED);
   }

   /* Get the upper sap */
   tuSapCp = dlgCp->sapCp;

   /* Encode dialogue APDU, if it is first backward message */

   if ((acn->pres) && (dlgCp->dhaSt == S_DHA_AC_RX))
   {
      /* Prepares the dialogue event structure */
      stInitItuDlgEv(&dlgEv, ST_DLG_TYP_RSP, acn, usrInfo, ST_DLG_RES_ACC,
                     ST_DLG_DIAG_NULL, ST_RES_SRC_SU);

      /* Encode the dialogue portion */
      if (stEncDlg((PTR)&dlgEv, tuSapCp->cfg.swtch, mBuf) != ROK)
      {
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
         STLOGERROR(ERRCLS_DEBUG, EST224, (ErrVal)0,
                    "stDHTxCnt:stEncDlg failed");
#endif
         RETVALUE(RFAILED);
      }
 
      /* update the DH state */
      dlgCp->dhaSt = S_DHA_AC_ACT;
   }

   /* Include only user defined information, if present, in the dialogue
      portion if the dialogue is active */

   else if ((usrInfo->pres) && (dlgCp->dhaSt == S_DHA_AC_ACT))
   {
      stEncUsrInfo(usrInfo, tuSapCp->cfg.swtch, mBuf);
   }

   /* Execute the Transaction State Machine */
   if (stItuTsmExec(dlgCp, E_TX_CNT, (PTR)mBuf, (PTR)qos) != ROK)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);
      (Void)stFreeDlg(dlgCp);

      stSendAlarm(LCM_CATEGORY_PROTOCOL, LST_EVENT_UX_MSG, LCM_CAUSE_UNKNOWN,
                  NOTUSED, NOTUSED);

      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
       "stDHTxCnt:Execution of stItuTsmExec routine failed for dialogue(%ld)\n",
       dlgCp->spDlgId));
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
}   /* End of stDHTxCnt */


/*
*
*       Fun:   stDHTxEnd
*
*       Desc:  Dialogue handler routine to Transmit a End message
*
*       Ret:   ROK     if successful
*              RFAILED if failure
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16  stDHTxEnd
(
StDlgCp     *dlgCp,         /* Dlg control point */
U8           endFlag,       /* flag for pre-arranged end */
StAcn       *acn,           /* Application context name */
TknBuf      *usrInfo,       /* User Information */
StQosSet    *qos            /* QOS parameters */
)
#else
PUBLIC S16  stDHTxEnd(dlgCp, endFlag, acn, usrInfo, qos)
StDlgCp     *dlgCp;         /* Dlg control point */
U8           endFlag;       /* flag for pre-arranged end */
StAcn       *acn;           /* Application context name */
TknBuf      *usrInfo;       /* User Information */
StQosSet    *qos;           /* QOS parameters */
#endif
{
   StTUSap    *tuSapCp;     /* Upper Sap */
   StItuDlgEv  dlgEv;       /* Dialogue Event structure */
   Buffer     *mBuf;        /* Message Buffer */

   TRC2(stDHTxEnd)

   /* If pre-arranged end, discard component, if any and free the dialogue */
   if (endFlag)
   {
      (Void)stCHDiscardComps(dlgCp);

#ifdef ZT
   ztRunTimeUpd(ZT_DLG_CB,
                CMPFTHA_UPDTYPE_NORMAL,
                CMPFTHA_ACTN_DEL,
                (Void *)dlgCp);
#endif /* ZT */

      (Void)stFreeDlg(dlgCp);

      RETVALUE(ROK);
   }

   /* collect all the pending components for this dialogue from CH */
   if (stCHGetComps(dlgCp, &mBuf) != ROK)
   {
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
       "stDHTxEnd:Execution of stCHGetComps routine failed for dialogue(%ld)\n",
       dlgCp->spDlgId));
      RETVALUE(RFAILED);
   }

   /* Get the upper sap */
   tuSapCp = dlgCp->sapCp;

   /* Encode dialogue APDU, if it is first backward message */
   if ((acn->pres) && (dlgCp->dhaSt == S_DHA_AC_RX))
   {
      /* Prepares the dialogue event structure */
      stInitItuDlgEv(&dlgEv, ST_DLG_TYP_RSP, acn, usrInfo, ST_DLG_RES_ACC,
                     ST_DLG_DIAG_NULL, ST_RES_SRC_SU);

      /* Encode the dialogue portion */
      if (stEncDlg((PTR)&dlgEv, tuSapCp->cfg.swtch, mBuf) != ROK)
      {
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
         STLOGERROR(ERRCLS_DEBUG, EST225, (ErrVal)0,
                    "stDHTxEnd:stEncDlg failed");
#endif

         RETVALUE(RFAILED);
      }
 
      /* update the DH state */
      dlgCp->dhaSt = S_DHA_AC_ACT;
   }

   /* Include only user defined information, if present, in the dialogue
      portion if the dialogue is active */

   else if ((usrInfo->pres) && (dlgCp->dhaSt == S_DHA_AC_ACT))
   {
      stEncUsrInfo(usrInfo, tuSapCp->cfg.swtch, mBuf);
   }

   /* Execute the Transaction State Machine */
   if (stItuTsmExec(dlgCp, E_TX_END, (PTR)mBuf, (PTR)qos) != ROK)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);
      (Void)stFreeDlg(dlgCp);

      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
       "stDHTxEnd:Execution of stItuTsmExec routine failed for dialogue(%ld)\n",
       dlgCp->spDlgId));
      stSendAlarm(LCM_CATEGORY_PROTOCOL, LST_EVENT_UX_MSG, LCM_CAUSE_UNKNOWN,
                  NOTUSED, NOTUSED);

      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
}   /* End of stDHTxEnd */


/*
*
*       Fun:   stDHTxUAbt
*
*       Desc:  Dialogue handler routine to Transmit a U-Abort message
*
*       Ret:   ROK     if successful
*              RFAILED if failure
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16  stDHTxUAbt
(
StDlgCp     *dlgCp,         /* Dlg control point */
U8           abtReason,     /* Abort Reason */
U8           src,           /* Dialogue source */
StAcn       *acn,           /* Application context name */
TknBuf      *usrInfo,       /* User Information */
StQosSet    *qos            /* QOS parameters */
)
#else
PUBLIC S16  stDHTxUAbt(dlgCp, abtReason, src, acn, usrInfo, qos)
StDlgCp     *dlgCp;         /* Dlg control point */
U8           abtReason;     /* Abort Reason */
U8           src;           /* Dialogue source */
StAcn       *acn;           /* Application context name */
TknBuf      *usrInfo;       /* User Information */
StQosSet    *qos;           /* QOS parameters */
#endif
{
   StTUSap     *tuSapCp;    /* Upper Sap */
   StSPSap     *spSapCp;    /* Lower Sap */
   Buffer      *mBuf;       /* Message Buffer */
   StItuDlgEv   dlgEv;      /* Dialogue Event structure */
   Swtch        pSwtch;     /* Protocol Switch */

   TRC2(stDHTxUAbt)

   /* Get the upper and lower sap pointers, get the protocol switch */
   tuSapCp = dlgCp->sapCp;
   
   /* st007.301 - Modified - TC-User Distribution Feature */
   spSapCp = *(stCb.spSapLst + stGetLSapId(dlgCp->sapCp->spId)); /* Lower Sap */
   pSwtch  = dlgCp->sapCp->cfg.swtch;

   /* Discards the components */
   (Void)stCHDiscardComps(dlgCp);

   /* Initialize the dialogue event structure */
   dlgEv.pres.pres = FALSE;

   switch(pSwtch)
   {
      case LST_SW_ITU88:
         break;

      case LST_SW_ITU96:
         if ((acn) && (acn->pres) &&
             (abtReason == ST_DLG_REFUSED) &&
             (dlgCp->dhaSt == S_DHA_AC_RX))
         {
            /* If acn is present then prepare AARE apdu */
            stInitItuDlgEv(&dlgEv, ST_DLG_TYP_RSP, acn, usrInfo,
                           ST_DLG_RES_REJ, ST_DLG_DIAG_NULL, src);
            break;
         }
         /* No break, Fall thru here to take care of the other abort reasons */

      case LST_SW_ITU92:
         if ((acn) && (acn->pres) &&
             (abtReason == ST_DLG_DIAG_NOACN) &&
             (abtReason == ST_DLG_DIAG_NOCDP) &&
             (dlgCp->dhaSt == S_DHA_AC_RX))
         {
            /* If acn is present then prepare AARE apdu */
            stInitItuDlgEv(&dlgEv, ST_DLG_TYP_RSP, acn, usrInfo,
                           ST_DLG_RES_REJ, abtReason, src);
         }
         else if (dlgCp->dhaSt != S_DHA_IDLE)
         {
            /* otherwise prepares AABT apdu */
            stInitItuDlgEv(&dlgEv, ST_DLG_TYP_ABT, NULLP, usrInfo,
                           0, 0, src);
         }
         break;
   }

   /* If dialogue event structure has been initialized above then encode
      the dialogue portion */
   if (dlgEv.pres.pres)
   {
      if (SGetMsg(spSapCp->pstSP.region, spSapCp->pstSP.pool, &mBuf)
          != ROK)
      {
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
              "stDHTxUAbt:SGetMsg failed for dialogue(%ld) encode\n",
              dlgCp->spDlgId));
         stSendAlarm(LCM_CATEGORY_RESOURCE, LST_EVENT_MSG_FAIL,
                     LCM_CAUSE_UNKNOWN, NOTUSED, NOTUSED);
         RETVALUE(RFAILED);
      }

      /* Encode the dialogue portion */
      if (stEncDlg((PTR)&dlgEv, tuSapCp->cfg.swtch, mBuf) != ROK)
      {
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
         STLOGERROR(ERRCLS_DEBUG, EST226, (ErrVal)0,
                    "stDHTxUAbt:stEncDlg failed");
#endif
         RETVALUE(RFAILED);
      }
   }
   else
   {
      /* If user information is present then use that buffer to encode
         transaction portion otherwise allocate another buffer */
      if (usrInfo->pres)
      {
         mBuf = usrInfo->val;
      }
      else
      {
         if (SGetMsg(spSapCp->pstSP.region, spSapCp->pstSP.pool, &mBuf)
             != ROK)
         {
            /* st009.301 -Add- Debug prints */
            STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stDHTxUAbt:user info encode buffer alloc fail in dialogue(%ld)\n"
             ,dlgCp->spDlgId));
            stSendAlarm(LCM_CATEGORY_RESOURCE, LST_EVENT_MSG_FAIL,
                        LCM_CAUSE_UNKNOWN, NOTUSED, NOTUSED);
            RETVALUE(RFAILED);
         }
      }
   }
 
   /* update the DH state */
   dlgCp->dhaSt = S_DHA_IDLE;

   /* Execute the Transaction State Machine */
   if (stItuTsmExec(dlgCp, E_TX_UABT, (PTR)mBuf, (PTR)qos) != ROK)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);
      (Void)stFreeDlg(dlgCp);

      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
         "stDHTxUAbt:stItuTsmExec routine execution failed for dialogue(%ld)\n",
         dlgCp->spDlgId));
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
}   /* End of stDHTxUAbt */


/*
*
*       Fun:   stDHRxUni
*
*       Desc:  Dialogue handler routine to Receive a UniDirectional message
*
*       Ret:   ROK     if successful
*              RFAILED if failure
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE S16 stDHRxUni
(
StDlgCp   *dlgCp,        /* Dialogue control point */
Buffer    *mBuf,         /* Buffer containing the components */
StQosSet  *qos           /* Quality of service set */
)
#else
PRIVATE S16 stDHRxUni(dlgCp, mBuf, qos)
StDlgCp   *dlgCp;        /* Dialogue control point */
Buffer    *mBuf;         /* Buffer containing the components */
StQosSet  *qos;          /* Quality of service set */
#endif
{
   StTUSap   *tuSapCp;   /* Upper Sap */
   StItuDlgEv dlgEv;     /* New style Dialogue event structure */
   StDlgEv    oDlgEv;    /* old style dialogue event structrue */
   Buffer    *usrInfo;   /* User information */
   Bool       dlgFlag;   /* Flag to indicate the presence of dialogue portion */
   Bool       compFlag;  /* Flag to indicate the presence of Component portion */
   Bool       abtFlag;   /* Flag to check errors */
   Data       tmpData;   /* Temporary variable */
   MsgLen     bufLen;    /* Message buffer length */
   U8         abtCause;  /* P-Abort Cause */
   /* st008.301 -Add- Dialogue Id */
   StDlgId    dlgId;     /* Temporarily store dialog */

   TRC2(stDHRxUni)

   /* Get the upper Sap */
   tuSapCp  = dlgCp->sapCp;

   /* Initialize the varaibles */
   dlgFlag     = FALSE;
   compFlag    = FALSE;
   abtFlag     = FALSE;
   oDlgEv.pres = FALSE;
   usrInfo     = NULLP;

   /* Message buffer should not be NULL here, component portion is mandatory
      in UNI messaage */

   if (mBuf == NULLP)
   {
      abtFlag = TRUE;
   }
   /* Examine for the presence of dialogue portion */
   else if (SExamMsg(&tmpData, mBuf, 0) == ROK)
   {
      /* Check if Dialogue Portion is present */
      if (tmpData == ST_ITU_DLG_PRTN_TAG)
      {
         dlgFlag = TRUE;
      }
      /* Check if component portion is present */
      else if (tmpData == ST_ITU_COMP_PRTN_TAG)
      {
         compFlag = TRUE;
      }
   }

   /* If dialogue portion is present, decode it */
   if ((dlgFlag) && (!abtFlag))
   {
      /* Decode the dialogue portion */
      if ((stDecDlg((PTR)&dlgEv, tuSapCp->cfg.swtch, mBuf, &abtCause) != ROK) ||

         /* If not unstructured dialogue, discard it */
         (dlgEv.dlgApdu.dlgType.val != ST_DLG_TYP_UNI))
      {
         abtFlag = TRUE;
      }
      else
      {
         /* Copy the new style dialogue event struct to the old style
            dialogue event structure */

         stCpyItuDlgEv(&oDlgEv, &dlgEv, &usrInfo, M2M1);

         /* Find if any component is present in the message buffer */
         (Void)SFndLenMsg(mBuf, &bufLen);

         if (bufLen > 0)
         {
            compFlag = TRUE;
         }
         else
         {
            /* Mandatory component portion is missing */
            abtFlag = TRUE;
         }
         /* st009.301 -Add- Debug prints */
         if (abtFlag)
         {        
            STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
                  "stDHRxUni:Dialogue Id (%ld): \
                  Dialogue portion decoding problem cause %d\n",
                  dlgCp->spDlgId,abtCause));
         }   
      }
   }

   /* If error, do some clean up */
   if (abtFlag)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);
      (Void)stFreeDlg(dlgCp);

      RETVALUE(RFAILED);
   }

   /* st008.301 -Add- Store the dialogue Id */
   dlgId = dlgCp->spDlgId;
   /* st029.301 - Add - Set value of suDlgId to 0 */
   dlgCp->suDlgId = 0;

   /* st014.301 -Send stDataParam information to TC-User via Data Indication */ 
#ifdef STUV2   
   /* Send data indication to the service user */
   StUiStuUDatInd( &tuSapCp->pstTU,
                    tuSapCp->suId,
   /* st029.301 - Add - Add the suDlgId and spDlgId paramenter */
#ifdef STUV3
                    dlgCp->suDlgId,
                    dlgCp->spDlgId,
#endif
                   &dlgCp->dstAddr,
                   &dlgCp->srcAddr,
                    qos,
                    dlgCp->opc,
                   &oDlgEv,
                   &stDataParam,
                    usrInfo ); 
#else  /* not STUV2 */   
   /* Send data indication to the service user */
   StUiStuUDatInd( &tuSapCp->pstTU,
                    tuSapCp->suId,
                   &dlgCp->dstAddr,
                   &dlgCp->srcAddr,
                    qos,
                    dlgCp->opc,
                   &oDlgEv,
                    usrInfo ); 
#endif /* STUV2 */

   if (compFlag)
   {
      /* st008.301 -Modify - Function prototype changed */ 
      /* send components to CC */
      stCHPutComps(tuSapCp, dlgId, mBuf);

      /* st017.301 -Add- Check to make sure that dialogue control point
       * hsnt been deleted due to some dialogue terminating message from
       * TC-User
       */
      if (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, dlgId, ST_USE_SPDLGID, &dlgCp) == ROK)
      {
         /* Free the instance of dialogue control point */
         (Void)stFreeDlg(dlgCp);
      }
   }

   RETVALUE(ROK);
}  /* End of stDHRxUni */



/*
*
*       Fun:   stDHRxBgn
*
*       Desc:  Dialogue handler routine to Receive a Begin message
*
*       Ret:   RETVOID
*
*       Notes: This function gets called from Transaction state table
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void stDHRxBgn
(
PTR        cp,           /* Control point */
PTR        data1,        /* First Data pointer */
PTR        data2         /* Second Data pointer */
)
#else
PRIVATE Void stDHRxBgn(cp, data1, data2)
PTR        cp;           /* Control point */
PTR        data1;        /* First Data pointer */
PTR        data2;        /* Second Data pointer */
#endif
{
   StDlgCp   *dlgCp;     /* Dialogue control point */
   Buffer    *mBuf;      /* message buffer */
   StQosSet  *qos;       /* Quality of service set */
   StTUSap   *tuSapCp;   /* Upper Sap */
   StItuDlgEv dlgEv;     /* New style Dialogue event structure */
   StDlgEv    oDlgEv;    /* old style dialogue event structrue */
   Buffer    *usrInfo;   /* User information */
   Bool       dlgFlag;   /* Dialogue present flag */
   Bool       compFlag;  /* Component present flag */
   U8         abtCause;  /* abort Cause */
   MsgLen     bufLen;    /* Message buffer length */
   Data       tmpData;   /* Temporary Data */
   S16        ret;       /* Return value */
   Bool       abtFlag;   /* If set then send abort */
   /* st008.301 -Add- Dialogue Id */
   StDlgId   dlgId;      /* Temporarily store dialog */ 
   
   TRC2(stDHRxBgn)

   /* Cast the function parameters to the appropriate structures */
   dlgCp = (StDlgCp  *)cp;     /* Dialogue control point */
   mBuf  = (Buffer   *)data1;  /* Message buffer, may have the components */
   qos   = (StQosSet *)data2;  /* Quality of service set */

   /* Get the upper Sap */
   tuSapCp  = dlgCp->sapCp;

   /* Initialize the varaibles */
   dlgFlag     = FALSE;
   compFlag    = FALSE;
   abtFlag     = FALSE;
   oDlgEv.pres = FALSE;
   usrInfo     = NULLP;

   cmZero((Data *)&dlgEv, sizeof(StItuDlgEv));

   /* Examine for the presence of dialogue portion */
   if ((mBuf != NULLP) && (SExamMsg(&tmpData, mBuf, 0) == ROK))
   {
      /* Check if Dialogue Portion is present */
      if (tmpData == ST_ITU_DLG_PRTN_TAG)
      {
         dlgFlag = TRUE;
      }
      /* Check if component portion is present */
      else if (tmpData == ST_ITU_COMP_PRTN_TAG)
      {
         compFlag = TRUE;
      }
   }

   /* If dialogue portion is present, decode it */
   if ((dlgFlag) && (!abtFlag))
   {
      /* Set Application context mode */
      dlgCp->dhaSt = S_DHA_AC_RX;

      /* Decode the dialogue portion */
      ret = stDecDlg((PTR)&dlgEv, tuSapCp->cfg.swtch, mBuf, &abtCause);

      if (ret != ROK)
      {
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_DECODE, (stCb.init.prntBuf,
               "stAnsiDHRxBgn:Dialogue(%ld): \
               Dialogue portion decoding problem cause %d\n",
               dlgCp->spDlgId,abtCause));

         abtFlag = TRUE;

      }

      /* If unexpected dialogue APDU, discard it */

      else if (dlgEv.dlgApdu.dlgType.val != ST_DLG_TYP_REQ)
      {
         abtCause = ST_PABT_BD_DLGP;
         abtFlag  = TRUE;
      }
      else
      {
         /* Copy the new style dialogue event struct to the old style
            dialogue event structure */

         stCpyItuDlgEv(&oDlgEv, &dlgEv, &usrInfo, M2M1);

         /* Find if any component is present in the message buffer */
         (Void)SFndLenMsg(mBuf, &bufLen);

         if (bufLen > 0)
         {
            compFlag = TRUE;
         }
      }
   }

   /* Generate U-Abort to Peer if abtFlag is set to TRUE */
   if (abtFlag)
   {
      TknBuf   uiBuf;

      /* st027.301 - Modify 
       * Undoing the change made by patch st026.301 below.*/
      /* st026.301 - Modify -
       * Commenting the deallocation of the mem buffer as this 
       * will be deallocated by the stTHRxMsg on return VOID */
      /* Discard the components */
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);   

      /* User Info Absent */
      uiBuf.pres = FALSE;

      switch(abtCause)
      {
         case ST_PABT_BD_DLGP:

            /* Send abort apdu to peer */
            stDHTxUAbt(dlgCp, ST_DLG_DIAG_NULL, ST_ABT_SRC_SP,
                       NULLP, &uiBuf, qos);
            break;

         case ST_PABT_NC_DLGP:

            /* Send Response APDU */
            stDHTxUAbt(dlgCp, ST_DLG_DIAG_NOCDP, ST_RES_SRC_SP,
                       &dlgEv.dlgApdu.apdu.req.acn, &uiBuf, qos);
            break;
      }

      RETVOID;
   }

#ifdef ZT
   ztRunTimeUpd(ZT_DLG_CB,
                CMPFTHA_UPDTYPE_NORMAL,
                CMPFTHA_ACTN_ADD,
                (Void *)dlgCp);
#endif /* ZT */

   if (!compFlag)
   {
      /* No component, disacrd the message buffer */
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);
   }

   /* st008.301 -Add- Store the dialogue Id */
   dlgId = dlgCp->spDlgId;

   /* st014.301 -Send stDataParam information to TC-User via Data Indication */ 
#ifdef STUV2   
   /* Send data indication to the service user */
   StUiStuDatInd( &tuSapCp->pstTU,
                   tuSapCp->suId,
                   STU_BEGIN,
                   dlgCp->suDlgId,
                   dlgCp->spDlgId,
                  &dlgCp->dstAddr,
                  &dlgCp->srcAddr,
                   compFlag,
                   NULLP,
                   qos,
                   dlgCp->opc,
                  &oDlgEv,
                  &stDataParam,
                   usrInfo ); 
#else  /* STUV2 */
   /* Send data indication to the service user */
   StUiStuDatInd( &tuSapCp->pstTU,
                   tuSapCp->suId,
                   STU_BEGIN,
                   dlgCp->suDlgId,
                   dlgCp->spDlgId,
                  &dlgCp->dstAddr,
                  &dlgCp->srcAddr,
                   compFlag,
                   NULLP,
                   qos,
                   dlgCp->opc,
                  &oDlgEv,
                  usrInfo );
#endif /* STUV2 */

   if (compFlag)
   {
      /* st008.301 -Modify- Function prototype modified */
      /* send components to CC */
      stCHPutComps(tuSapCp, dlgId, mBuf);
   }

   RETVOID;
}  /* End of stDHRxBgn */


/*
*
*       Fun:   stDHRxCnt
*
*       Desc:  Dialogue handler routine to Receive a Continue message
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void stDHRxCnt
(
PTR        cp,           /* Control point */
PTR        data1,        /* First Data pointer */
PTR        data2         /* Second Data pointer */
)
#else
PRIVATE Void stDHRxCnt(cp, data1, data2)
PTR        cp;           /* Control point */
PTR        data1;        /* First Data pointer */
PTR        data2;        /* Second Data pointer */
#endif
{
   StDlgCp     *dlgCp;      /* Dialogue control point */
   Buffer      *mBuf;       /* message buffer */
   StQosSet    *qos;        /* Quality of service set */
   StTUSap     *tuSapCp;    /* Upper Sap */
   Bool         dlgFlag;    /* Dialogue portion present flag */
   Bool         compFlag;   /* Component present flag */
   Bool         abtFlag;    /* Indicate whether to send abort */
   StItuDlgEv   dlgEv;      /* Dialogue event structure */
   StDlgEv      oDlgEv;     /* Old style dialogue event structure */
   U8           abtCause;   /* Abort Cause */
   MsgLen       bufLen;     /* Message buffer length */
   Data         tmpData;    /* Temporary Data */
   Buffer      *usrInfo;    /* User Information buffer */
   S16          ret;        /* Return Value */
   /* st008.301 -Add- Dialogue Id */
   StDlgId   dlgId;      /* Temporarily store dialog */

   TRC2(stDHRxCnt)

   /* Cast the function parameters to the appropriate structures */
   dlgCp = (StDlgCp  *)cp;     /* Dialogue control point */
   mBuf  = (Buffer   *)data1;  /* Message buffer, may have the components */
   qos   = (StQosSet *)data2;  /* Quality of service set */

   /* Get the upper Sap */
   tuSapCp  = dlgCp->sapCp;

   /* Initialize the varaibles */
   dlgFlag     = FALSE;
   compFlag    = FALSE;
   abtFlag     = FALSE;
   oDlgEv.pres = FALSE;
   usrInfo     = NULLP;

   cmZero((Data *)&dlgEv, sizeof(StItuDlgEv));

   /* Examine for the presence of dialogue portion */
   if ((mBuf != NULLP) && (SExamMsg(&tmpData, mBuf, 0) == ROK))
   {
      /* Check if Dialogue Portion is present */
      if (tmpData == ST_ITU_DLG_PRTN_TAG)
      {
         dlgFlag = TRUE;
      }
      /* Check if component portion is present */
      else if (tmpData == ST_ITU_COMP_PRTN_TAG)
      {
         compFlag = TRUE;
      }
   }

   /* Check the consistency of dialogue portion */
   if ((!dlgFlag) && (dlgCp->dhaSt == S_DHA_AC_TX) && (!abtFlag))
   {
      /* dialogue portion is missing in first backward message */
      abtCause = ST_PABT_BD_DLGP;
      abtFlag  = TRUE;
   }

   /* If dialogue apdu is present in first backward message, decode it */
   else if ((dlgFlag) && (dlgCp->dhaSt == S_DHA_AC_TX) && (!abtFlag))
   {
      /* Decode the dialogue portion */
      ret = stDecDlg((PTR)&dlgEv, tuSapCp->cfg.swtch, mBuf, &abtCause);

      if (ret != ROK)
      {
         abtFlag = TRUE;
      }

      /* If unexpected dialogue APDU, discard it */

      else if ((dlgEv.dlgApdu.dlgType.val != ST_DLG_TYP_RSP) ||
               ((dlgEv.dlgApdu.dlgType.val == ST_DLG_TYP_RSP) &&
                (dlgEv.dlgApdu.apdu.rsp.result.val != ST_DLG_RES_ACC)))
      {
         /* Abnormal Dialogue portion, generate local abort */
         abtCause = ST_PABT_BD_DLGP;
         abtFlag = TRUE;
      }
      else
      {
         /* Set the Application context mode Active */
         dlgCp->dhaSt = S_DHA_AC_ACT;

         /* Copy the new style dialogue event struct to the old style
            dialogue event structure */

         stCpyItuDlgEv(&oDlgEv, &dlgEv, &usrInfo, M2M1);

         /* Find if any component is present in the message buffer */
         (Void)SFndLenMsg(mBuf, &bufLen);

         if (bufLen > 0)
         {
            compFlag = TRUE;
         }
      }
   }
   else if ((dlgFlag) && (dlgCp->dhaSt == S_DHA_AC_ACT) && (!abtFlag))
   {
      /* Only user information can be present in the subsequent backward
         messages */

      if (stDecUsrInfo(&usrInfo, tuSapCp->cfg.swtch, mBuf, &abtCause) != ROK)
      {
         abtFlag = TRUE;
      }
      else
      {
         /* Find if any component is present in the message buffer */
         (Void)SFndLenMsg(mBuf, &bufLen);

         if (bufLen > 0)
         {
            compFlag = TRUE;
         }
      }
   }

   /* Generate U-Abort to remote user and P-Abort to local user */
   if (abtFlag)
   {
      /* Discard the components */
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

      /* Send P-Abort indication to local user and U-Abort to peer */
      stDHGenPUAbt(dlgCp, abtCause, &dlgEv.dlgApdu.apdu.req.acn, qos);

      RETVOID;
   }

#ifdef ZT
   /* Update dialogue control block only for first backward continue */
   if (dlgCp->firstBackMsg)
   {
      ztRunTimeUpd(ZT_DLG_CB,
                   CMPFTHA_UPDTYPE_NORMAL,
                   CMPFTHA_ACTN_MOD,
                   (Void *)dlgCp);
   }
#endif /* ZT */

   if (!compFlag)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);
   }

   /* st008.301 -Add- Store the dialogue Id */
   dlgId = dlgCp->spDlgId;

   /* st014.301 -Send stDataParam information to TC-User via Data Indication */ 
#ifdef STUV2   
   /* Send data indication to the service user */
   StUiStuDatInd( &tuSapCp->pstTU,
                   tuSapCp->suId,
                   STU_CONTINUE,
                   dlgCp->suDlgId,
                   dlgCp->spDlgId,
                  &dlgCp->dstAddr,
                  &dlgCp->srcAddr,
                   compFlag,
                   NULLP,
                   qos,
                   dlgCp->opc,
                  &oDlgEv,
                  &stDataParam,
                   usrInfo ); 
#else  /* STUV2 */
   /* Send data indication to the service user */
   StUiStuDatInd( &tuSapCp->pstTU,
                   tuSapCp->suId,
                   STU_CONTINUE,
                   dlgCp->suDlgId,
                   dlgCp->spDlgId,
                  &dlgCp->dstAddr,
                  &dlgCp->srcAddr,
                   compFlag,
                   NULLP,
                   qos,
                   dlgCp->opc,
                  &oDlgEv,
                   usrInfo );
#endif /* STUV2 */

   if (compFlag)
   {
      /* st008.301 -Modify- Function prototype modified */
      /* send components to CC */
      stCHPutComps(tuSapCp, dlgId, mBuf);
   }

   RETVOID;
}  /* End of stDHRxCnt */


/*
*
*       Fun:   stDHRxEnd
*
*       Desc:  Dialogue handler routine to Receive a End message sent by the
*              peer and to send a data indication to the TC-User
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void stDHRxEnd
(
PTR        cp,           /* Control point */
PTR        data1,        /* First Data pointer */
PTR        data2         /* Second Data pointer */
)
#else
PRIVATE Void stDHRxEnd(cp, data1, data2)
PTR        cp;           /* Control point */
PTR        data1;        /* First Data pointer */
PTR        data2;        /* Second Data pointer */
#endif
{
   StDlgCp   *dlgCp;     /* Dialogue control point */
   Buffer    *mBuf;      /* message buffer */
   StQosSet  *qos;       /* Quality of service set */
   StTUSap   *tuSapCp;   /* Upper Sap */
   StItuDlgEv dlgEv;     /* Dialogue event structure */
   U8         abtCause;  /* Abort Cause */
   StDlgId    suDlgId;   /* Service User dialogue Id */
   StDlgId    spDlgId;   /* Service provider dialogue Id */
   SpAddr     srcAddr;   /* Source SCCP Address */
   SpAddr     dstAddr;   /* Destination SCCP Address */
   Buffer    *usrInfo;   /* User Information */
   Bool       dlgFlag;   /* Dialogue present flag */
   Bool       compFlag;  /* Component present flag */
   Bool       abtFlag;   /* If set then send abort */
   MsgLen     bufLen;    /* Message buffer length */
   Data       tmpData;   /* Temporary data */
   StDlgEv    oDlgEv;    /* Old style dialogue event structure */
   S16        ret;
   Dpc        opc;
   /* st008.301 -Add- Dialogue Id added */
   StDlgId   dlgId;      /* Temporarily store dialog */

   TRC2(stDHRxEnd)

   /* Cast the function parameters to the appropriate structures */
   dlgCp = (StDlgCp  *)cp;     /* Dialogue control point */
   mBuf  = (Buffer   *)data1;  /* Message buffer, may have the components */
   qos   = (StQosSet *)data2;  /* Quality of service set */

   /* Get the upper Sap */
   tuSapCp = dlgCp->sapCp;

   /* Initialize the varaibles */
   dlgFlag     = FALSE;
   compFlag    = FALSE;
   abtFlag     = FALSE;
   oDlgEv.pres = FALSE;
   usrInfo     = NULLP;

   /* Examine for the presence of dialogue portion */
   if ((mBuf != NULLP) && (SExamMsg(&tmpData, mBuf, 0) == ROK))
   {
      /* Check if Dialogue Portion is present */
      if (tmpData == ST_ITU_DLG_PRTN_TAG)
      {
         dlgFlag = TRUE;
      }
      /* Check if component portion is present */
      else if (tmpData == ST_ITU_COMP_PRTN_TAG)
      {
         compFlag = TRUE;
      }
   }

   /* Check the consistency of dialogue portion */
   if ((!dlgFlag) && (dlgCp->dhaSt == S_DHA_AC_TX) && (!abtFlag))
   {
      /* dialogue portion is missing in first backward message */

      /* Abnormal Dialogue portion, generate local abort */
      abtCause = ST_PABT_BD_DLGP;
      abtFlag  = TRUE;
   }

   /* If dialogue apdu is present in first backward message, decode it */
   else if ((dlgFlag) && (dlgCp->dhaSt == S_DHA_AC_TX) && (!abtFlag))
   {
      /* Decode the dialogue portion */
      ret = stDecDlg((PTR)&dlgEv, tuSapCp->cfg.swtch, mBuf, &abtCause);

      if (ret != ROK)
      {
         /* Abnormal Dialogue portion, generate local abort */
         abtFlag = TRUE;
      }

      /* If unexpected dialogue APDU, discard it */

      else if ((dlgEv.dlgApdu.dlgType.val != ST_DLG_TYP_RSP) ||
               ((dlgEv.dlgApdu.dlgType.val == ST_DLG_TYP_RSP) &&
                (dlgEv.dlgApdu.apdu.rsp.result.val != ST_DLG_RES_ACC)))
      {
         /* Abnormal Dialogue portion, generate local abort */
         abtCause = ST_PABT_BD_DLGP;
         abtFlag  = TRUE;
      }
      else
      {
         /* Set the Application context mode Active */
         dlgCp->dhaSt = S_DHA_AC_ACT;

         /* Copy the new style dialogue event struct to the old style
            dialogue event structure */

         stCpyItuDlgEv(&oDlgEv, &dlgEv, &usrInfo, M2M1);

         /* Find if any component is present in the message buffer */
         (Void)SFndLenMsg(mBuf, &bufLen);

         if (bufLen > 0)
         {
            compFlag = TRUE;
         }
      }
   }
   /* Check for User Information in the subsequent messages */
   else if ((dlgFlag) && (dlgCp->dhaSt == S_DHA_AC_ACT) && (!abtFlag))
   {
      /* Only user information can be present in the subsequent backward
         messages */
      if (stDecUsrInfo(&usrInfo, tuSapCp->cfg.swtch, mBuf, &abtCause) != ROK)
      {
         /* Abnormal Dialogue portion, generate local abort */
         abtCause = ST_PABT_BD_DLGP;
         abtFlag  = TRUE;
      }
      else
      {
         /* Find if any component is present in the message buffer */
         (Void)SFndLenMsg(mBuf, &bufLen);

         if (bufLen > 0)
         {
            compFlag = TRUE;
         }
      }
   }

   /* Generate local abort if abtFlag is set TRUE */
   if (abtFlag)
   {
      /* Discard the components */
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);
      (Void)stDHRxPAbt((PTR)dlgCp, (PTR)&abtCause, (PTR)qos);
      RETVOID;
   }

   /* Copy the dialogue ids and addresses to temporary variables before
      freeing up the dialogue control point */

   suDlgId = dlgCp->suDlgId;
   spDlgId = dlgCp->spDlgId;

   cmCopySpAddr(&dlgCp->dstAddr, &dstAddr);
   cmCopySpAddr(&dlgCp->srcAddr, &srcAddr);

   opc = dlgCp->opc;

   if (compFlag != TRUE)
   {
      /* No component in the buffer, so release it */
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

#ifdef ZT
      ztRunTimeUpd(ZT_DLG_CB,
                   CMPFTHA_UPDTYPE_NORMAL,
                   CMPFTHA_ACTN_DEL,
                   (Void *)dlgCp);
#endif /* ZT */

      /* Free the instance of dialogue control point */
      (Void)stFreeDlg(dlgCp);
   }

   /* st008.301 -Add- Store the dialogue Id */
   dlgId = spDlgId;
 
   /* st014.301 -Send stDataParam information to TC-User via Data Indication */ 
#ifdef STUV2   
   /* Send data indication to the service user */
   StUiStuDatInd( &tuSapCp->pstTU,
                   tuSapCp->suId,
                   STU_END,
                   dlgCp->suDlgId,
                   dlgCp->spDlgId,
                  &dlgCp->dstAddr,
                  &dlgCp->srcAddr,
                   compFlag,
                   NULLP,
                   qos,
                   dlgCp->opc,
                  &oDlgEv,
                  &stDataParam,
                   usrInfo ); 
#else  /* STUV2 */
   /* Send data indication to the service user */
   StUiStuDatInd( &tuSapCp->pstTU,
                   tuSapCp->suId,
                   STU_END,
                   dlgCp->suDlgId,
                   dlgCp->spDlgId,
                  &dlgCp->dstAddr,
                  &dlgCp->srcAddr,
                   compFlag,
                   NULLP,
                   qos,
                   dlgCp->opc,
                  &oDlgEv,
                   usrInfo );
#endif /* STUV2 */  

   if (compFlag)
   {
      /* st008.301 -Modify- Function prototype modified */
      /* send components to CC */
      stCHPutComps(tuSapCp, dlgId, mBuf);

      /* st017.301 -Add- Check to make sure that dialogue control point
       * hsnt been deleted due to some dialogue terminating message from
       * TC-User
       */
      if (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, dlgId, ST_USE_SPDLGID, &dlgCp) != ROK)
      {
         RETVOID;
      }
#ifdef ZT
      ztRunTimeUpd(ZT_DLG_CB,
                   CMPFTHA_UPDTYPE_NORMAL,
                   CMPFTHA_ACTN_DEL,
                   (Void *)dlgCp);
#endif /* ZT */

      /* Free the instance of dialogue control point */
      (Void)stFreeDlg(dlgCp);
   }

   RETVOID;
}  /* End of stDHRxEnd */


/*
*
*       Fun:   stDHRxUAbt
*
*       Desc:  Dialogue handler routine to Receive a User-Abort message sent
*              by the peer and to send a data indication to the TC-User
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void stDHRxUAbt
(
PTR        cp,           /* Control point */
PTR        data1,        /* First Data pointer */
PTR        data2         /* Second Data pointer */
)
#else
PRIVATE Void stDHRxUAbt(cp, data1, data2)
PTR        cp;           /* Control point */
PTR        data1;        /* First Data pointer */
PTR        data2;        /* Second Data pointer */
#endif
{
   StDlgCp    *dlgCp;    /* Dialogue control point */
   Buffer     *mBuf;     /* message buffer */
   StQosSet   *qos;      /* Quality of service set */
   StTUSap    *tuSapCp;  /* Upper Sap */
   StItuDlgEv  dlgEv;    /* New style Dialogue event structure */
   StDlgEv     oDlgEv;   /* Old style dialogye event */
   Buffer     *usrInfo;  /* User Information */
   StDlgId     suDlgId;  /* Service user dialogue id */
   StDlgId     spDlgId;  /* Service provider dialogue id */
   SpAddr      srcAddr;  /* Source SCCP Address */
   SpAddr      dstAddr;  /* Destination SCCP Address */
   Bool        dlgFlag;  /* Flag to indicate presence of dialgue portion */
   U8          abtCause; /* Abort Cause */
   Bool        abtFlag;  /* Abort flag */
   Data        tmpData;  /* Temporary Data */
   S16         ret;      /* Return Value */
   Swtch       pSwtch;   /* Protocol switch */
   Dpc         opc;

   TRC2(stDHRxUAbt)

   /* Cast the function parameters to the appropriate structures */
   dlgCp = (StDlgCp  *)cp;     /* Dialogue control point */
   mBuf  = (Buffer   *)data1;  /* Message buffer, may have the components */
   qos   = (StQosSet *)data2;  /* Quality of service set */

   /* Get the upper Sap */
   tuSapCp = dlgCp->sapCp;
   pSwtch  = tuSapCp->cfg.swtch;

   /* Initialize the varaibles */
   dlgFlag     = FALSE;
   oDlgEv.pres = FALSE;
   usrInfo     = NULLP;

   /* Examine for the presence of dialogue portion */
   if ((mBuf != NULLP) && (SExamMsg(&tmpData, mBuf, 0) == ROK))
   {
      /* Check if Dialogue Portion is present */
      if (tmpData == ST_ITU_DLG_PRTN_TAG)
      {
         dlgFlag = TRUE;
      }
      else
      {
         /* It's the user information, pass it transparently to the user */
         usrInfo = mBuf;
         mBuf    = NULLP;
      }
   }
   else 
   {
      /* Deallocate the message buffer */
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);
   }

   /* Check the consistency of the dialogue portion with the protocol
      variant */
   switch(pSwtch)
   {
      case LST_SW_ITU92:
      case LST_SW_ITU96:
         break;

      default:
         if (dlgFlag)
         {
            /* Incorrect Transaction portion, generate local abort */
            /* st027.301 - Modify - Modify the user buf free mechanism */ 
            STFREEUSERBUF(mBuf);
            abtCause = ST_PABT_IN_TRNP;
            stDHRxPAbt((PTR)dlgCp, (PTR)&abtCause, (PTR)qos);
            RETVOID;
         }
         break;
   }

   /* Check the consistency of dialogue portion */
   if (((!dlgFlag) && (dlgCp->dhaSt != S_DHA_IDLE)) ||
       ((dlgFlag) && (dlgCp->dhaSt == S_DHA_IDLE)))
   {
      /* Abnormal Dialogue portion, generate local abort */
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stDHRxUAbt:Abnormal dialogue portion, send local abort\n"));
      abtCause = ST_PABT_BD_DLGP;
      stDHRxPAbt((PTR)dlgCp, (PTR)&abtCause, (PTR)qos);
      RETVOID;
   }

   /* If dialogue apdu is present, decode it */
   if (dlgFlag)
   {
      /* Decode the dialogue portion */
      if ((ret = stDecDlg((PTR)&dlgEv, tuSapCp->cfg.swtch, mBuf, &abtCause))
          != ROK)
      {
         /* st009.301 -Add- Debug prints */
         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stDHRxUAbt:Dialogue(%ld) decode failed, send local abort\n",
                dlgCp->spDlgId));
         /* Abnormal Dialogue portion, generate local abort */
         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(mBuf);
         stDHRxPAbt((PTR)dlgCp, (PTR)&abtCause, (PTR)qos);
         RETVOID;
      }

      /* Deallocate the message buffer */
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

      /* Default abort cause - abnormal dialogue portion */
      abtCause = ST_PABT_BD_DLGP;
      abtFlag  = FALSE;
      switch(dlgEv.dlgApdu.dlgType.val)
      {
         case ST_DLG_TYP_RSP:
            /* AARE apdu can be present only in the first backward message */
            if (dlgCp->dhaSt != S_DHA_AC_TX)
            {
               abtFlag = TRUE;
               break;
            }

            if (dlgEv.dlgApdu.apdu.rsp.result.val != ST_DLG_RES_REJ)
            {
               /* Abnormal Dialogue portion, generate local abort */
               abtFlag = TRUE;
               break;
            }

            /* If source isn't user than it should be AARE apdu with
               result source diag. as no common dialogue portion */
            if (dlgEv.dlgApdu.apdu.rsp.resSrc.val != ST_RES_SRC_SU)
            {
               if (dlgEv.dlgApdu.apdu.rsp.reason.val != ST_DLG_DIAG_NOCDP)
               {
                  /* Abnormal Dialogue portion, generate local abort */
                  abtFlag = TRUE;
               }
               else
               {
                  /* No common Dialogue portion, generate local abort */
                  abtCause = ST_PABT_NC_DLGP;
                  abtFlag  = TRUE;
               }
               break;
            }

            if ((dlgEv.dlgApdu.apdu.rsp.reason.val == ST_DLG_DIAG_NULL) ||
                (dlgEv.dlgApdu.apdu.rsp.reason.val == ST_DLG_DIAG_NORES))
            {
               if (pSwtch == LST_SW_ITU92)
               {
                  /* Illegal result source diag. val, generate local abort */
                  abtFlag = TRUE;
                  break;
               }
               else
               {
                  /* Set the result reason to Dialogue refused, if the result
                     is Rejected and the reason is No-reason-given or Null */
                  dlgEv.dlgApdu.apdu.rsp.reason.val = ST_DLG_REFUSED;
               }
            }
            break;

         case ST_DLG_TYP_ABT:
            if (dlgEv.dlgApdu.apdu.abt.abrtSrc.val != ST_ABT_SRC_SU)
            {
               /* Abnormal Dialogue portion, generate local abort */
               abtFlag = TRUE;
            }
            break;

         default:
            /* Abnormal Dialogue portion, generate local abort */
            abtFlag = TRUE;
            break;
      }

      /* send local P-Abort */
      if (abtFlag)
      {
         stDHRxPAbt((PTR)dlgCp, (PTR)&abtCause, (PTR)qos);
         RETVOID;
      }

      /* Copy the new style dialogue event struct to the old style
         dialogue event structure */
      stCpyItuDlgEv(&oDlgEv, &dlgEv, &usrInfo, M2M1);

      /* Set the Application context mode IDLE */
      dlgCp->dhaSt = S_DHA_IDLE;
   }

   /* Copy the dialogue ids and addresses to temporary variables before
      freeing up the dialogue control point */

   suDlgId = dlgCp->suDlgId;
   spDlgId = dlgCp->spDlgId;

   cmCopySpAddr(&dlgCp->dstAddr, &dstAddr);
   cmCopySpAddr(&dlgCp->srcAddr, &srcAddr);

   opc = dlgCp->opc;

#ifdef ZT
   ztRunTimeUpd(ZT_DLG_CB,
                CMPFTHA_UPDTYPE_NORMAL,
                CMPFTHA_ACTN_DEL,
                (Void *)dlgCp);
#endif /* ZT */

   /* Free the dialogue control point */
   (Void)stFreeDlg(dlgCp);

   /* st014.301 -Send stDataParam information to TC-User via Data Indication */ 
#ifdef STUV2   
    /* Send U-Abort indication to the service user */
   StUiStuDatInd( &tuSapCp->pstTU,
                   tuSapCp->suId,
                   STU_U_ABORT,
                   suDlgId,
                   spDlgId,
                  &dstAddr,
                  &srcAddr,
                   FALSE,
                   NULLP,
                   qos,
                   opc,
                  &oDlgEv,
                  &stDataParam,
                   usrInfo );
#else  /* STUV2 */
   /* Send U-Abort indication to the service user */
   StUiStuDatInd( &tuSapCp->pstTU,
                   tuSapCp->suId,
                   STU_U_ABORT,
                   suDlgId,
                   spDlgId,
                  &dstAddr,
                  &srcAddr,
                   FALSE,
                   NULLP,
                   qos,
                   opc,
                  &oDlgEv,
                   usrInfo ); 
#endif /* STUV2 */

   RETVOID;
}  /* End of stDHRxUAbt */


/*
*
*       Fun:   stDHRxPAbt
*
*       Desc:  Dialogue handler routine to Receive a Provider-Abort message
*              sent by the peer and to send the data indication to TC-User
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void stDHRxPAbt
(
PTR        cp,           /* Control point */
PTR        data1,        /* First Data pointer */
PTR        data2         /* Second Data pointer */
)
#else
PRIVATE Void stDHRxPAbt(cp, data1, data2)
PTR        cp;           /* Control point */
PTR        data1;        /* First Data pointer */
PTR        data2;        /* Second Data pointer */
#endif
{
   StDlgCp   *dlgCp;     /* Dialogue control point */
   U8         pAbtCause; /* message buffer */
   StQosSet  *qos;       /* Quality of service set */
   StTUSap   *tuSapCp;   /* Upper Sap */
   StOctet    abrtCause;
   StDlgId    suDlgId;   /* service user dialogue id */
   StDlgId    spDlgId;   /* service provider dialogue id */
   SpAddr     srcAddr;   /* Source SCCP Address */
   SpAddr     dstAddr;   /* Destination SCCP Address */
   StDlgEv    oDlgEv;    /* Old style dialogye event */
   Dpc        opc;

   TRC2(stDHRxPAbt)

   /* Cast the function parameters to the appropriate structures */
   dlgCp       = (StDlgCp  *)cp;     /* Dialogue control point */
   pAbtCause   = *(U8      *)data1;  /* P-Abort Cause */
   qos         = (StQosSet *)data2;  /* Quality of service set */
   oDlgEv.pres = FALSE;

   /* Get the upper Sap */
   tuSapCp = dlgCp->sapCp;

   /* Copy the dialogue ids and addresses to temporary variables before
      freeing up the dialogue control point */

   suDlgId = dlgCp->suDlgId;
   spDlgId = dlgCp->spDlgId;

   cmCopySpAddr(&dlgCp->dstAddr, &dstAddr);
   cmCopySpAddr(&dlgCp->srcAddr, &srcAddr);

   /* st009.301 -Add- Debug prints */
   STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
          "stDHRxPAbt: Dialogue handle routine recieved P-Abort \
          user dialogue(%ld), TCAP dialogue(%ld), abort cause(%d)\n",
          suDlgId, spDlgId, pAbtCause));
   
   abrtCause.pres  = TRUE;
   abrtCause.octet = pAbtCause;

   opc = dlgCp->opc;

#ifdef ZT
   ztRunTimeUpd(ZT_DLG_CB,
                CMPFTHA_UPDTYPE_NORMAL,
                CMPFTHA_ACTN_DEL,
                (Void *)dlgCp);
#endif /* ZT */

   /* Free the instance of dialogue control point */
   (Void)stFreeDlg(dlgCp);

   /* st014.301 -Send stDataParam information to TC-User via Data Indication */ 
#ifdef STUV2   
   /* Send P-Abort indication to the service user */
   StUiStuDatInd( &tuSapCp->pstTU,
                   tuSapCp->suId,
                   STU_P_ABORT,
                   suDlgId,
                   spDlgId,
                  &dstAddr,
                  &srcAddr,
                   FALSE,
                  &abrtCause,
                   qos,
                   opc,
                  &oDlgEv,
                  &stDataParam,
                   NULLP );
#else  /* STUV2 */
   /* Send P-Abort indication to the service user */
   StUiStuDatInd( &tuSapCp->pstTU,
                   tuSapCp->suId,
                   STU_P_ABORT,
                   suDlgId,
                   spDlgId,
                  &dstAddr,
                  &srcAddr,
                   FALSE,
                  &abrtCause,
                   qos,
                   opc,
                  &oDlgEv,
                   NULLP );
#endif /* STUV2 */

   RETVOID;
}  /* End of stDHRxPAbt */


/*
*
*       Fun:   stDHGenPUAbt
*
*       Desc:  Dialogue handler routine to generate local P-Abort Indication
*              and send U-Abort message to Peer
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE S16 stDHGenPUAbt
(
StDlgCp   *dlgCp,        /* Dialogue control point */
U8         abtCause,     /* Abort Cause */
StAcn     *acn,          /* Application context Name */
StQosSet  *qos           /* Quality of service set */
)
#else
PRIVATE S16 stDHGenPUAbt(dlgCp, abtCause, acn, qos)
StDlgCp   *dlgCp;        /* Dialogue control point */
U8         abtCause;     /* Abort Cause */
StAcn     *acn;          /* Application context Name */
StQosSet  *qos;          /* Quality of service set */
#endif
{
   StTUSap   *tuSapCp;   /* Upper Sap */
   StOctet    abrtCause;
   StDlgId    suDlgId;   /* service user dialogue id */
   StDlgId    spDlgId;   /* service provider dialogue id */
   SpAddr     srcAddr;   /* Source SCCP Address */
   SpAddr     dstAddr;   /* Destination SCCP Address */
   TknBuf     uiBuf;     /* User Information Buf */
   StDlgEv    oDlgEv;    /* Old style dialogye event */
   Dpc        opc;

   TRC2(stDHGenPUAbt)

   /* Get the upper Sap */
   tuSapCp = dlgCp->sapCp;

   oDlgEv.pres = FALSE;

   /* Copy the dialogue ids and addresses to temporary variables before
      freeing up the dialogue control point */

   suDlgId = dlgCp->suDlgId;
   spDlgId = dlgCp->spDlgId;

   cmCopySpAddr(&dlgCp->dstAddr, &dstAddr);
   cmCopySpAddr(&dlgCp->srcAddr, &srcAddr);

   /* st009.301 -Add- Debug prints */
   STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
          "stDHGenPUAbt:Generating U-Abt to remote user and P-Abt to local \
          user for user dialogue(%ld), TCAP dialogue (%ld),Abort cause(%d)\n",
          suDlgId, spDlgId, abtCause));
   opc = dlgCp->opc;

   /* User Info Absent */
   uiBuf.pres = FALSE;

   switch(abtCause)
   {
      case ST_PABT_BD_DLGP:

         /* Send abort apdu to peer */
         stDHTxUAbt(dlgCp, ST_DLG_DIAG_NULL, ST_ABT_SRC_SP,
                    NULLP, &uiBuf, qos);
         break;

      case ST_PABT_NC_DLGP:

         /* Send Response APDU */
         stDHTxUAbt(dlgCp, ST_DLG_DIAG_NOCDP, ST_RES_SRC_SP,
                    acn, &uiBuf, qos);
         break;
   }

   abrtCause.pres  = TRUE;
   abrtCause.octet = abtCause;

   /* st014.301 -Add- set imp and isni value as not present */
#ifdef STUV2
   stDataParam.imp.pres = NOTPRSNT;
#endif /* STUV2 */

#if (defined(SS7_ANS96) && defined(STUV2))
   stDataParam.isni.isniPres = NOTPRSNT;
#endif

   /* st014.301 -Send stDataParam information to TC-User via Data Indication */ 
#ifdef STUV2   
   /* Send P-Abort indication to the service user */
   StUiStuDatInd( &tuSapCp->pstTU,
                   tuSapCp->suId,
                   STU_P_ABORT,
                   suDlgId,
                   spDlgId,
                  &dstAddr,
                  &srcAddr,
                   FALSE,
                  &abrtCause,
                   qos,
                   opc,
                  &oDlgEv,
                  &stDataParam,
                   NULLP );
#else  /* STUV2 */
   /* Send P-Abort indication to the service user */
   StUiStuDatInd( &tuSapCp->pstTU,
                   tuSapCp->suId,
                   STU_P_ABORT,
                   suDlgId,
                   spDlgId,
                  &dstAddr,
                  &srcAddr,
                   FALSE,
                  &abrtCause,
                   qos,
                   opc,
                  &oDlgEv,
                   NULLP );
#endif /* STUV2 */

   RETVALUE(ROK);
}  /* End of stDHGenPUAbt */


/************************************************************************
                   Transaction Handler Routines
************************************************************************/

/*
*
*       Fun:   stTHTxUni
*
*       Desc:  TSM Action Routine to transmit the Begin Message
*
*       Ret:   ROK       if successful
*              RFAILED   if any failure
*
*       Notes: mBuf already contains the encoded dialogue portion and the
*              component portion. This routine encodes the transaction portion
*              adds it to mBuf to form the complete Unidirectional Message.
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE S16 stTHTxUni
(
StDlgCp     *dlgCp,       /* dialogue control point for this dialogue */
StQosSet    *qos,         /* QOS parameters */
Buffer      *mBuf         /* contains components and dialogue portion */
)
#else
PRIVATE S16 stTHTxUni(dlgCp, qos, mBuf)
StDlgCp     *dlgCp;       /* dialogue control point for this dialogue */
StQosSet    *qos;         /* QOS parameters */
Buffer      *mBuf;        /* contains components and dialogue portion */
#endif
{
   StTUSap    *tuSapCp;   /* Upper SAP */
   StSPSap    *spSapCp;   /* Lower SAP */
   StMsgEv     msgEv;     /* Transaction Portion Event structure */
   SpUDatEvnt  uDatEv;    /* SCCP Unit Data Event */

   TRC2(stTHTxUni)
#if 0 /* xingzhou.xu: modified for debug print */
   STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
#endif
   STDBGP(ST_DBGMASK_NORMAL, (stCb.init.prntBuf,
          "stTHTxUni:\n"));

   /* Get the Sap pointers */
   tuSapCp = dlgCp->sapCp;                     /* Upper Sap */

   /* st007.301 - Modified - TC-User Distribution Feature */
   spSapCp = *(stCb.spSapLst + stGetLSapId(tuSapCp->spId)); /* Lower Sap */
    
   /* Initialize the transaction portion event structure */
   (Void)stZeroEv((Data *)&msgEv, ST_TYP_TRN_PRTN, tuSapCp->cfg.swtch);

   /* prepare the transaction portion event structure */
   msgEv.msgType.pres   = TRUE;
   msgEv.msgType.val    = ST_MSG_TYP_UNI;

   /* Encode the transaction portion */
   if (stEncMsg(&msgEv, tuSapCp->cfg.swtch, mBuf) != ROK)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);
      (Void)stFreeDlg(dlgCp);

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST227, (ErrVal)0,
                 "stTHTxUni:stEncMsg Failed");
#endif
      RETVALUE(RFAILED);
   }

   /* st031.301 - Add - Initialization of uDatEv */
   cmZero((Data *)&uDatEv, sizeof(SpUDatEvnt));

   /* copy TC-user passed QoS parameters to the SCCP unit data event */
   uDatEv.qos.credit = 0;
   uDatEv.qos.pClass = qos->seqCtl == TRUE ? PCLASS1:PCLASS0;
   uDatEv.qos.retOpt = qos->retOpt;
   uDatEv.prior      = qos->msgPrior;
   uDatEv.tmr        = spSapCp->cfg.spTmr;
   uDatEv.sc         = dlgCp->spDlgId;
   uDatEv.esc        = TRUE;

   /* copy SCCP addresses */
   cmCopySpAddr(&dlgCp->dstAddr, &uDatEv.cdAddr);
   cmCopySpAddr(&dlgCp->srcAddr, &uDatEv.cgAddr);

   /* Generate Trace, if enabled */
   if (stCb.init.trc == TRUE)
   {
      stGenTrc(spSapCp->suId, LST_MSG_TXED, mBuf);
   }

   /* Free the dialogue control point, no response is expected to Uni */
   stFreeDlg(dlgCp);

   /* Increment the resource statistics counters */
   stUpdRsrcSts(&tuSapCp->sts, ST_STS_TX_MSG, ST_MSG_TYP_UNI,
                tuSapCp->cfg.swtch);

   /* st014.301- Add- Retrieve the isni and imp information */ 
   stGetDataParam(&uDatEv); 

   /* Send message to SCCP */
   (Void)StLiSptUDatReq(&spSapCp->pstSP, spSapCp->spId, &uDatEv, mBuf);

   RETVALUE(ROK);
}  /* End of stTHTxUni */


/*
*
*       Fun:   stTHTxBgn
*
*       Desc:  TSM Action Routine to transmit the Begin Message
*
*       Ret:   RETVOID
*
*       Notes: mBuf already contains the encoded dialogue portion and the
*              component portion. This routine encodes the transaction portion
*              adds it to mBuf to form the complete Begin Message.
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void stTHTxBgn
(
PTR        cp,           /* Control point */
PTR        data1,        /* First Data pointer */
PTR        data2         /* Second Data pointer */
)
#else
PRIVATE Void stTHTxBgn(cp, data1, data2)
PTR        cp;           /* Control point */
PTR        data1;        /* First Data pointer */
PTR        data2;        /* Second Data pointer */
#endif
{
   StDlgCp    *dlgCp;    /* Dialogue control point */
   Buffer     *mBuf;     /* message buffer */
   StQosSet   *qos;      /* Quality of service set */
   StTUSap    *tuSapCp;  /* Upper SAP */
   StSPSap    *spSapCp;  /* Lower SAP */
   StMsgEv     msgEv;    /* Transaction Portion Event structure */
   SpUDatEvnt  uDatEv;   /* SCCP Unit Data Event */

   TRC2(stTHTxBgn)

   /* Cast the function parameters to the appropriate structures */
   dlgCp = (StDlgCp  *)cp;     /* Dialogue control point */
   mBuf  = (Buffer   *)data1;  /* Message buffer, may have the components */
   qos   = (StQosSet *)data2;  /* Quality of service set */

#if 0 /* xingzhou.xu: modified for debug print -- 2006/08/30 */
   STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
#endif
   STDBGP(ST_DBGMASK_NORMAL, (stCb.init.prntBuf,
   		  "stTHTxBgn:OrigDlgId(%ld)\n", dlgCp->spDlgId));

   /* Get the Sap pointers */
   tuSapCp = dlgCp->sapCp;                     /* Upper Sap */
   
   /* st007.301 - Modified - TC-User Distribution Feature */
   spSapCp = *(stCb.spSapLst + stGetLSapId(tuSapCp->spId)); /* Lower Sap */
   
   /* Initialize the transaction portion event structure */
   (Void)stZeroEv((Data *)&msgEv, ST_TYP_TRN_PRTN, tuSapCp->cfg.swtch);

   /* prepare the transaction portion event structure */
   msgEv.msgType.pres   = TRUE;
   msgEv.msgType.val    = ST_MSG_TYP_BGN;
   msgEv.orgTrnsId.pres = TRUE;
   msgEv.orgTrnsId.val  = dlgCp->spDlgId;

   /* Encode the transaction portion */
   if (stEncMsg(&msgEv, tuSapCp->cfg.swtch, mBuf) != ROK)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);
      (Void)stFreeDlg(dlgCp);

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST228, (ErrVal)0,
                 "stTHTxBgn:stEncMsg Failed");
#endif
      RETVOID;
   }

#ifdef ZT
   ztRunTimeUpd(ZT_DLG_CB,
                CMPFTHA_UPDTYPE_NORMAL,
                CMPFTHA_ACTN_ADD,
                (Void *)dlgCp);
#endif /* ZT */

   /* st031.301 - Add - Initialization of uDatEv */
   cmZero((Data *)&uDatEv, sizeof(SpUDatEvnt));

   /* copy TC-user passed QoS parameters to the SCCP unit data event */
   uDatEv.qos.credit = 0;
   uDatEv.qos.pClass = qos->seqCtl == TRUE ? PCLASS1:PCLASS0;
   uDatEv.qos.retOpt = qos->retOpt;
   uDatEv.prior      = qos->msgPrior;
   uDatEv.tmr        = spSapCp->cfg.spTmr;
   uDatEv.sc         = dlgCp->spDlgId;
   uDatEv.esc        = FALSE;

   /* copy SCCP addresses */
   cmCopySpAddr(&dlgCp->dstAddr, &uDatEv.cdAddr);
   cmCopySpAddr(&dlgCp->srcAddr, &uDatEv.cgAddr);

   /* Generate Trace, if enabled */
   if (stCb.init.trc == TRUE)
   {
      stGenTrc(spSapCp->suId, LST_MSG_TXED, mBuf);
   }

   /* Increment the resource statistics counters */
   stUpdRsrcSts(&tuSapCp->sts, ST_STS_TX_MSG, ST_MSG_TYP_BGN,
                tuSapCp->cfg.swtch);

   /* st014.301- Add- Retrieve the isni and imp information */ 
   stGetDataParam(&uDatEv); 

   /* Send message to SCCP */
   (Void)StLiSptUDatReq(&spSapCp->pstSP, spSapCp->spId, &uDatEv, mBuf);

   RETVOID;
}  /* End of stTHTxBgn */


/*
*
*       Fun:   stTHTxCnt
*
*       Desc:  TSM Action Routine to transmit the Continue Message
*
*       Ret:   RETVOID
*
*       Notes: mBuf already contains the encoded dialogue portion and the
*              component portion. This routine encodes the transaction portion
*              adds it to mBuf to form the complete Continue Message.
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void stTHTxCnt
(
PTR        cp,           /* Control point */
PTR        data1,        /* First Data pointer */
PTR        data2         /* Second Data pointer */
)
#else
PRIVATE Void stTHTxCnt(cp, data1, data2)
PTR        cp;           /* Control point */
PTR        data1;        /* First Data pointer */
PTR        data2;        /* Second Data pointer */
#endif
{
   StDlgCp    *dlgCp;    /* Dialogue control point */
   Buffer     *mBuf;     /* message buffer */
   StQosSet   *qos;      /* Quality of service set */
   StTUSap    *tuSapCp;  /* Upper SAP */
   StSPSap    *spSapCp;  /* Lower SAP */
   StMsgEv     msgEv;    /* Transaction Portion Event structure */
   SpUDatEvnt  uDatEv;   /* SCCP Unit Data Event */

   TRC2(stTHTxCnt)

   /* Cast the function parameters to the appropriate structures */
   dlgCp = (StDlgCp  *)cp;     /* Dialogue control point */
   mBuf  = (Buffer   *)data1;  /* Message buffer, may have the components */
   qos   = (StQosSet *)data2;  /* Quality of service set */

#if 0 /* xingzhou.xu: modified for debug print -- 2006/08/30 */
   STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
#endif
   STDBGP(ST_DBGMASK_NORMAL, (stCb.init.prntBuf,
          "stTHTxCnt:OrigDlgId(%ld), DestDlgId(%ld)\n",
          dlgCp->spDlgId, dlgCp->dstDlgId));

   /* Get the Sap pointers */
   tuSapCp = dlgCp->sapCp;                     /* Upper Sap */
   
   /* st007.301 - Modified - TC-User Distribution Feature */
   spSapCp = *(stCb.spSapLst + stGetLSapId(tuSapCp->spId)); /* Lower Sap */

   /* Initialize the transaction portion event structure */
   (Void)stZeroEv((Data *)&msgEv, ST_TYP_TRN_PRTN, tuSapCp->cfg.swtch);

   /* prepare the transaction portion event structure */
   msgEv.msgType.pres   = TRUE;
   msgEv.msgType.val    = ST_MSG_TYP_CNT;
   msgEv.orgTrnsId.pres = TRUE;
   msgEv.orgTrnsId.val  = dlgCp->spDlgId;
   msgEv.dstTrnsId.pres = TRUE;
   msgEv.dstTrnsId.val  = dlgCp->dstDlgId;
   msgEv.trnsIdLen.pres = TRUE;
   msgEv.trnsIdLen.val  = dlgCp->dstDlgIdLen;

   /* Encode the transaction portion */
   if (stEncMsg(&msgEv, tuSapCp->cfg.swtch, mBuf) != ROK)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST229, (ErrVal)0,
                 "stTHTxCnt:stEncMsg failed");
#endif
      RETVOID;
   }

#ifdef ZT
   /* Update dialogue control block only for first backward continue */
   if (dlgCp->firstBackMsg)
   {
      ztRunTimeUpd(ZT_DLG_CB,
                   CMPFTHA_UPDTYPE_NORMAL,
                   CMPFTHA_ACTN_MOD,
                   (Void *)dlgCp);
   }
#endif /* ZT */

   /* st031.301 - Add - Initialization of uDatEv */
   cmZero((Data *)&uDatEv, sizeof(SpUDatEvnt));

   /* copy TC-user passed QoS parameters to the SCCP unit data event */
   uDatEv.qos.credit = 0;
   uDatEv.qos.pClass = qos->seqCtl == TRUE ? PCLASS1:PCLASS0;
   uDatEv.qos.retOpt = qos->retOpt;
   uDatEv.prior      = qos->msgPrior;
   uDatEv.tmr        = spSapCp->cfg.spTmr;
   uDatEv.sc         = dlgCp->spDlgId;
   uDatEv.esc        = FALSE;

   /* copy SCCP addresses */
   cmCopySpAddr(&dlgCp->dstAddr, &uDatEv.cdAddr);
   cmCopySpAddr(&dlgCp->srcAddr, &uDatEv.cgAddr);

   /* Generate Trace, if enabled */
   if (stCb.init.trc == TRUE)
   {
      stGenTrc(spSapCp->suId, LST_MSG_TXED, mBuf);
   }

   /* Increment the resource statistics counters */
   stUpdRsrcSts(&tuSapCp->sts, ST_STS_TX_MSG, ST_MSG_TYP_CNT,
                tuSapCp->cfg.swtch);
 
   /* st014.301- Add- Retrieve the isni and imp information */ 
   stGetDataParam(&uDatEv); 

   /* Send message to SCCP */
   (Void)StLiSptUDatReq(&spSapCp->pstSP, spSapCp->spId, &uDatEv, mBuf);

   RETVOID;
}  /* End of stTHTxCnt */


/*
*
*       Fun:   stTHTxEnd
*
*       Desc:  TSM Action Routine to transmit the End Message
*
*       Ret:   RETVOID
*
*       Notes: mBuf already contains the encoded dialogue portion and the
*              component portion. This routine encodes the transaction portion
*              adds it to mBuf to form the complete End Message.
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void stTHTxEnd
(
PTR        cp,           /* Control point */
PTR        data1,        /* First Data pointer */
PTR        data2         /* Second Data pointer */
)
#else
PRIVATE Void stTHTxEnd(cp, data1, data2)
PTR        cp;           /* Control point */
PTR        data1;        /* First Data pointer */
PTR        data2;        /* Second Data pointer */
#endif
{
   StDlgCp    *dlgCp;    /* Dialogue control point */
   Buffer     *mBuf;     /* message buffer */
   StQosSet   *qos;      /* Quality of service set */
   StTUSap    *tuSapCp;  /* Upper SAP */
   StSPSap    *spSapCp;  /* Lower SAP */
   StMsgEv     msgEv;    /* Transaction Portion Event structure */
   SpUDatEvnt  uDatEv;   /* SCCP Unit Data Event */

   TRC2(stTHTxEnd)

   /* Cast the function parameters to the appropriate structures */
   dlgCp = (StDlgCp  *)cp;     /* Dialogue control point */
   mBuf  = (Buffer   *)data1;  /* Message buffer, may have the components */
   qos   = (StQosSet *)data2;  /* Quality of service set */

#if 0 /* xingzhou.xu: modified for debug print -- 2006/08/30 */
   STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
#endif
   STDBGP(ST_DBGMASK_NORMAL, (stCb.init.prntBuf,
          "stTHTxEnd:DestDlgId(%ld)\n", dlgCp->dstDlgId));

   /* Get the Sap pointers */
   tuSapCp = dlgCp->sapCp;                     /* Upper Sap */
   
   /* st007.301 - Modified - TC-User Distribution Feature */
   spSapCp = *(stCb.spSapLst + stGetLSapId(tuSapCp->spId)); /* Lower Sap */

   /* Initialize the transaction portion event structure */
   (Void)stZeroEv((Data *)&msgEv, ST_TYP_TRN_PRTN, tuSapCp->cfg.swtch);

   /* prepare the transaction portion event structure */
   msgEv.msgType.pres   = TRUE;
   msgEv.msgType.val    = ST_MSG_TYP_END;
   msgEv.dstTrnsId.pres = TRUE;
   msgEv.dstTrnsId.val  = dlgCp->dstDlgId;
   msgEv.trnsIdLen.pres = TRUE;
   msgEv.trnsIdLen.val  = dlgCp->dstDlgIdLen;

   /* Encode the transaction portion */
   if (stEncMsg(&msgEv, tuSapCp->cfg.swtch, mBuf) != ROK)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST230, (ErrVal)0,
                 "stTHTxEnd:stEncMsg failed");
#endif
      RETVOID;
   }

   /* st031.301 - Add - Initialization of uDatEv */
   cmZero((Data *)&uDatEv, sizeof(SpUDatEvnt));

   /* copy TC-user passed QoS parameters to the SCCP unit data event */
   uDatEv.qos.credit = 0;
   uDatEv.qos.pClass = qos->seqCtl == TRUE ? PCLASS1:PCLASS0;
   uDatEv.qos.retOpt = qos->retOpt;
   uDatEv.prior      = qos->msgPrior;
   uDatEv.tmr        = spSapCp->cfg.spTmr;
   uDatEv.sc         = dlgCp->spDlgId;
   uDatEv.esc        = TRUE;

   /* copy SCCP addresses */
   cmCopySpAddr(&dlgCp->dstAddr, &uDatEv.cdAddr);
   cmCopySpAddr(&dlgCp->srcAddr, &uDatEv.cgAddr);

   /* Generate Trace, if enabled */
   if (stCb.init.trc == TRUE)
   {
      stGenTrc(spSapCp->suId, LST_MSG_TXED, mBuf);
   }

#ifdef ZT
   ztRunTimeUpd(ZT_DLG_CB,
                CMPFTHA_UPDTYPE_NORMAL,
                CMPFTHA_ACTN_DEL,
                (Void *)dlgCp);
#endif /* ZT */

   stFreeDlg(dlgCp);   /* Dialogue ended, free up the instance */

   /* Increment the resource statistics counters */
   stUpdRsrcSts(&tuSapCp->sts, ST_STS_TX_MSG, ST_MSG_TYP_END,
                tuSapCp->cfg.swtch);
 
   /* st014.301- Add- Retrieve the isni and imp information */ 
   stGetDataParam(&uDatEv); 

   /* Send message to SCCP */
   (Void)StLiSptUDatReq(&spSapCp->pstSP, spSapCp->spId, &uDatEv, mBuf);

   RETVOID;
}  /* End of stTHTxEnd */


/*
*
*       Fun:   stTHTxUAbt
*
*       Desc:  TSM Action Routine to transmit the U-Abort Message
*
*       Ret:   RETVOID
*
*       Notes: mBuf already contains the encoded dialogue portion (if to be
*              included). This routine encodes the transaction portion
*              adds it to mBuf to form the complete Abort Message.
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void stTHTxUAbt
(
PTR        cp,           /* Control point */
PTR        data1,        /* First Data pointer */
PTR        data2         /* Second Data pointer */
)
#else
PRIVATE Void stTHTxUAbt(cp, data1, data2)
PTR        cp;           /* Control point */
PTR        data1;        /* First Data pointer */
PTR        data2;        /* Second Data pointer */
#endif
{
   StDlgCp    *dlgCp;    /* Dialogue control point */
   Buffer     *mBuf;     /* message buffer */
   StQosSet   *qos;      /* Quality of service set */
   StTUSap    *tuSapCp;  /* Upper SAP */
   StSPSap    *spSapCp;  /* Lower SAP */
   StMsgEv     msgEv;    /* Transaction Portion Event structure */
   SpUDatEvnt  uDatEv;   /* SCCP Unit Data Event */
   /* st017.301 -Add- flag for whether dialoge terminating msg. has come */
   Bool       dlgTermFlag; /* Whether dlg. teminating msg. has come */

   TRC2(stTHTxUAbt)

   /* Cast the function parameters to the appropriate structures */
   dlgCp = (StDlgCp  *)cp;     /* Dialogue control point */
   mBuf  = (Buffer   *)data1;  /* Message buffer, may have the components */
   qos   = (StQosSet *)data2;  /* Quality of service set */

   STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
          "stTHTxUAbt:DestDlgId(%ld)\n", dlgCp->dstDlgId));

   /* Get the Sap pointers */
   tuSapCp = dlgCp->sapCp;                     /* Upper Sap */
   
   /* st007.301 - Modified - TC-User Distribution Feature */
   spSapCp = *(stCb.spSapLst + stGetLSapId(tuSapCp->spId)); /* Lower Sap */

   /* Initialize the transaction portion event structure */
   (Void)stZeroEv((Data *)&msgEv, ST_TYP_TRN_PRTN, tuSapCp->cfg.swtch);

   /* prepare the transaction portion event structure */
   msgEv.msgType.pres   = TRUE;
   msgEv.msgType.val    = ST_MSG_TYP_UABT;
   msgEv.dstTrnsId.pres = TRUE;
   msgEv.dstTrnsId.val  = dlgCp->dstDlgId;
   msgEv.trnsIdLen.pres = TRUE;
   msgEv.trnsIdLen.val  = dlgCp->dstDlgIdLen;

   /* Encode the transaction portion */
   if (stEncMsg(&msgEv, tuSapCp->cfg.swtch, mBuf) != ROK)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST231, (ErrVal)0,
                 "stTHTxUAbt:stEncMsg failed");
#endif
      RETVOID;
   }

   /* st031.301 - Add - Initialization of uDatEv */
   cmZero((Data *)&uDatEv, sizeof(SpUDatEvnt));

   /* copy TC-user passed QoS parameters to the SCCP unit data event */
   uDatEv.qos.credit = 0;
   uDatEv.qos.pClass = qos->seqCtl == TRUE ? PCLASS1:PCLASS0;
   uDatEv.qos.retOpt = qos->retOpt;
   uDatEv.prior      = qos->msgPrior;
   uDatEv.tmr        = spSapCp->cfg.spTmr;
   uDatEv.sc         = dlgCp->spDlgId;
   uDatEv.esc        = TRUE;

   /* copy SCCP addresses */
   cmCopySpAddr(&dlgCp->dstAddr, &uDatEv.cdAddr);
   cmCopySpAddr(&dlgCp->srcAddr, &uDatEv.cgAddr);

   /* Generate Trace, if enabled */
   if (stCb.init.trc == TRUE)
   {
      stGenTrc(spSapCp->suId, LST_MSG_TXED, mBuf);
   }

#ifdef ZT
   ztRunTimeUpd(ZT_DLG_CB,
                CMPFTHA_UPDTYPE_NORMAL,
                CMPFTHA_ACTN_DEL,
                (Void *)dlgCp);
#endif /* ZT */

   /* st017.301 -Add- store flag for dialogue termination */
   dlgTermFlag = dlgCp->termMsg;

   stFreeDlg(dlgCp);   /* Dialogue aborted, free up the instance */

   /* Increment the resource statistics counters */
   stUpdRsrcSts(&tuSapCp->sts, ST_STS_TX_MSG, ST_MSG_TYP_UABT,
                tuSapCp->cfg.swtch);

   /* st014.301- Add- Retrieve the isni and imp information */ 
   stGetDataParam(&uDatEv); 

   /* st017.301 -Modify- If dialogue terminating message has already come from
    * peer, then stop sending the abort message to SCCP
    */
   if (!dlgTermFlag)
   {
      /* Send message to SCCP */
      (Void)StLiSptUDatReq(&spSapCp->pstSP, spSapCp->spId, &uDatEv, mBuf);
   }
   else
   {
   	   /* xingzhou.xu: added to avoid memory leak -- 2006/09/04 */
   	   STFREEUSERBUF(mBuf);
   }

   RETVOID;
}  /* End of stTHTxUAbt */


/*
*
*       Fun:   stTHTxPAbt
*
*       Desc:  TSM Action Routine to transmit the P-Abort Message
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void stTHTxPAbt
(
PTR        cp,           /* Control point */
PTR        data1,        /* First Data pointer */
PTR        data2         /* Second Data pointer */
)
#else
PRIVATE Void stTHTxPAbt(cp, data1, data2)
PTR        cp;           /* Control point */
PTR        data1;        /* First Data pointer */
PTR        data2;        /* Second Data pointer */
#endif
{
   StDlgCp    *dlgCp;    /* Dialogue control point */
   U8          pAbtCause;/* P-Abort Cause */
   StQosSet   *qos;      /* Quality of service set */
   StTUSap    *tuSapCp;  /* Upper SAP */
   StSPSap    *spSapCp;  /* Lower SAP */
   StMsgEv     msgEv;    /* Transaction Portion Event structure */
   SpUDatEvnt  uDatEv;   /* SCCP Unit Data Event */
   Buffer     *mBuf;     /* Message buffer to prepare the Abort message */

   TRC2(stTHTxPAbt)

   /* Cast the function parameters to the appropriate structures */
   dlgCp     = (StDlgCp  *)cp;     /* Dialogue control point */
   pAbtCause = *(U8      *)data1;  /* P-Abort Cause */
   qos       = (StQosSet *)data2;  /* Quality of service set */

   STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
          "stTHTxPAbt:DestDlgId(%ld), PAbortCause(%d)\n",
          dlgCp->dstDlgId, pAbtCause));

   /* Get the Sap pointers */
   tuSapCp = dlgCp->sapCp;                     /* Upper Sap */
   
   /* st007.301 - Modified - TC-User Distribution Feature */
   spSapCp = *(stCb.spSapLst + stGetLSapId(tuSapCp->spId)); /* Lower Sap */

   /* Initialize the transaction portion event structure */
   (Void)stZeroEv((Data *)&msgEv, ST_TYP_TRN_PRTN, tuSapCp->cfg.swtch);

   /* prepare the transaction portion event structure */
   msgEv.msgType.pres   = TRUE;
   msgEv.msgType.val    = ST_MSG_TYP_PABT;
   msgEv.dstTrnsId.pres = TRUE;
   msgEv.dstTrnsId.val  = dlgCp->dstDlgId;
   msgEv.trnsIdLen.pres = TRUE;
   msgEv.trnsIdLen.val  = dlgCp->dstDlgIdLen;
   msgEv.pAbtCause.pres = TRUE;
   msgEv.pAbtCause.val  = pAbtCause;

   /* Allocate message buffer to build the abort message */
   if (SGetMsg(spSapCp->pstSP.region, spSapCp->pstSP.pool, &mBuf) != ROK)
   {
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stTHTxPAbt:SGetMsg failed\n"));
      stSendAlarm(LCM_CATEGORY_RESOURCE, LST_EVENT_MSG_FAIL, LCM_CAUSE_UNKNOWN,
                  NOTUSED, NOTUSED);
      RETVOID;
   }

   /* Encode the transaction portion */
   if (stEncMsg(&msgEv, tuSapCp->cfg.swtch, mBuf) != ROK)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST232, (ErrVal)0,
                 "stTHTxPAbt:stEncMsg failed");
#endif
      RETVOID;
   }

   /* st031.301 - Add - Initialization of uDatEv */
   cmZero((Data *)&uDatEv, sizeof(SpUDatEvnt));

   /* copy TC-user passed QoS parameters to the SCCP unit data event */
   uDatEv.qos.credit = 0;
   uDatEv.qos.pClass = qos->seqCtl == TRUE ? PCLASS1:PCLASS0;
   uDatEv.qos.retOpt = qos->retOpt;
   uDatEv.prior      = qos->msgPrior;
   uDatEv.tmr        = spSapCp->cfg.spTmr;
   uDatEv.sc         = dlgCp->spDlgId;
   uDatEv.esc        = TRUE;

   /* copy SCCP addresses */
   cmCopySpAddr(&dlgCp->dstAddr, &uDatEv.cdAddr);
   cmCopySpAddr(&dlgCp->srcAddr, &uDatEv.cgAddr);

   /* Generate Trace, if enabled */
   if (stCb.init.trc == TRUE)
   {
      stGenTrc(spSapCp->suId, LST_MSG_TXED, mBuf);
   }

#ifdef ZT
   ztRunTimeUpd(ZT_DLG_CB,
                CMPFTHA_UPDTYPE_NORMAL,
                CMPFTHA_ACTN_DEL,
                (Void *)dlgCp);
#endif /* ZT */

   stFreeDlg(dlgCp);   /* Dialogue aborted, free up the instance */

   /* Increment the resource statistics counters */
   stUpdRsrcSts(&tuSapCp->sts, ST_STS_TX_MSG, ST_MSG_TYP_PABT,
                tuSapCp->cfg.swtch);
 
   /* Increment the fault statistics counters */
   stUpdFaultSts(&tuSapCp->sts, ST_STS_FAULT, pAbtCause, tuSapCp->cfg.swtch, ST_STS_TX_MSG);

    /* st014.301- Add- set the isni and imp information as not present */ 
#if (defined(SPTV2) && defined(SS7_ANS96))
   uDatEv.isni.isniPres = NOTPRSNT;
#endif /* SPTV2 and SS7_ANS96 */

#ifdef SPTV2 
   /* Set the imp information */
   uDatEv.imp.pres = NOTPRSNT; 
#endif /* SPTV2 */ 

   /* Send message to SCCP */
   (Void)StLiSptUDatReq(&spSapCp->pstSP, spSapCp->spId, &uDatEv, mBuf);

   RETVOID;
}  /* End of stTHTxPAbt */


/*
*
*       Fun:   stTHGenPAbt
*
*       Desc:  Generate P-Abort Message and transmit it to Peer
*
*       Ret:   ROK       if successful
*              RFAILED   if any failure
*
*       Notes: This function is used to transmit P-Abort message only
*              when the instance of dialogue control point doesn't exist
*              otherwise stTHTxPAbt function is used.
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE S16 stTHGenPAbt
(
StTUSap     *tuSapCp,       /* TCAP Upper Sap */
StDlgId      dstDlgId,      /* Destination Transaction id */
U8           dstDlgIdLen,   /* Destination Transaction id length */
U8           pAbtCause,     /* Provider abort cause */
StQosSet    *qos,           /* QOS parameters */
SpAddr      *dstAddr,       /* Destination SCCP Address */
SpAddr      *srcAddr        /* Source SCCP Address */
)
#else
PRIVATE S16 stTHGenPAbt(tuSapCp, dstDlgId, dstDlgIdLen, pAbtCause, qos,
                        dstAddr, srcAddr)
StTUSap     *tuSapCp;       /* TCAP Upper Sap */
StDlgId      dstDlgId;      /* Destination Transaction id */
U8           dstDlgIdLen;   /* Destination Transaction id length */
U8           pAbtCause;     /* Provider abort cause */
StQosSet    *qos;           /* QOS parameters */
SpAddr      *dstAddr;       /* Destination SCCP Address */
SpAddr      *srcAddr;       /* Source SCCP Address */
#endif
{
   StSPSap    *spSapCp;   /* Lower SAP */
   StMsgEv     msgEv;     /* Transaction Portion Event structure */
   SpUDatEvnt  uDatEv;    /* SCCP Unit Data Event */
   Buffer     *mBuf;      /* Message buffer to prepare the Abort message */

   TRC2(stTHGenPAbt)

   STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
          "stTHGenPAbt:DestDlgId(%ld), PAbortCause(%d)\n",
          dstDlgId, pAbtCause));

   /* st007.301 - Modified - TC-User Distribution Feature */
   spSapCp = *(stCb.spSapLst + stGetLSapId(tuSapCp->spId)); /* Lower Sap */

   /* Initialize the transaction portion event structure */
   (Void)stZeroEv((Data *)&msgEv, ST_TYP_TRN_PRTN, tuSapCp->cfg.swtch);

   /* prepare the transaction portion event structure */
   msgEv.msgType.pres   = TRUE;
   msgEv.msgType.val    = ST_MSG_TYP_PABT;
   msgEv.dstTrnsId.pres = TRUE;
   msgEv.dstTrnsId.val  = dstDlgId;
   msgEv.trnsIdLen.pres = TRUE;
   msgEv.trnsIdLen.val  = dstDlgIdLen;
   msgEv.pAbtCause.pres = TRUE;
   msgEv.pAbtCause.val  = pAbtCause;

   /* Allocate message buffer to build the abort message */
   if (SGetMsg(spSapCp->pstSP.region, spSapCp->pstSP.pool, &mBuf) != ROK)
   {
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stTHGenPAbt:SGetMsg failed\n"));
      stSendAlarm(LCM_CATEGORY_RESOURCE, LST_EVENT_MSG_FAIL, LCM_CAUSE_UNKNOWN,
                  NOTUSED, NOTUSED);
      RETVALUE(RFAILED);
   }

   /* Encode the transaction portion */
   if (stEncMsg(&msgEv, tuSapCp->cfg.swtch, mBuf) != ROK)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST233, (ErrVal)0,
                 "stTHGenPAbt:stEncMsg failed");
#endif
      RETVALUE(RFAILED);
   }

   /* st031.301 - Add - Initialization of uDatEv */
   cmZero((Data *)&uDatEv, sizeof(SpUDatEvnt));

   /* copy TC-user passed QoS parameters to the SCCP unit data event */
   uDatEv.qos.credit = 0;
   uDatEv.qos.pClass = qos->seqCtl == TRUE ? PCLASS1:PCLASS0;
   uDatEv.qos.retOpt = qos->retOpt;
   uDatEv.prior      = qos->msgPrior;
   uDatEv.tmr        = spSapCp->cfg.spTmr;
   uDatEv.sc         = 0;
   uDatEv.esc        = TRUE;

   /* copy SCCP addresses */
   cmCopySpAddr(dstAddr, &uDatEv.cdAddr);
   cmCopySpAddr(srcAddr, &uDatEv.cgAddr);

   /* Generate Trace, if enabled */
   if (stCb.init.trc == TRUE)
   {
      stGenTrc(spSapCp->suId, LST_MSG_TXED, mBuf);
   }

   /* Increment the resource statistics counters */
   stUpdRsrcSts(&tuSapCp->sts, ST_STS_TX_MSG, ST_MSG_TYP_PABT,
                tuSapCp->cfg.swtch);
 
   /* Increment the fault statistics counters */
   stUpdFaultSts(&tuSapCp->sts, ST_STS_FAULT, pAbtCause, tuSapCp->cfg.swtch, ST_STS_TX_MSG);

   /* st014.301- Add- set the isni and imp information as not present */ 
#if (defined(SPTV2) && defined(SS7_ANS96))
   uDatEv.isni.isniPres = NOTPRSNT;
#endif /* SPTV2 && SS7_ANS96 */

#ifdef SPTV2 
   /* Set the imp information */
   uDatEv.imp.pres = NOTPRSNT; 
#endif /* SPTV2 */ 

   /* Send message to SCCP */
   (Void)StLiSptUDatReq(&spSapCp->pstSP, spSapCp->spId, &uDatEv, mBuf);

   RETVALUE(ROK);
}  /* End of stTHGenPAbt */



/* st007.301 - Added - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
/*
*
*       Fun:   stTHGenPAbtTcUserDist
*
*       Desc:  Generate P-Abort Message and transmit it to Peer
*
*       Ret:   ROK       if successful
*              RFAILED   if any failure
*
*       Notes: This function is used to transmit P-Abort message only
*              when the instance of dialogue control point doesn't exist
*              otherwise stTHTxPAbt function is used.Used only in
*              TC-user Distribution Feature.
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE S16 stTHGenPAbtTcUserDist
(
SuId         spSapId,       /* TCAP lower Sap */
StDlgId      dstDlgId,      /* Destination Transaction id */
U8           dstDlgIdLen,   /* Destination Transaction id length */
U8           pAbtCause,     /* Provider abort cause */
StQosSet    *qos,           /* QOS parameters */
SpAddr      *dstAddr,       /* Destination SCCP Address */
SpAddr      *srcAddr        /* Source SCCP Address */
)
#else
PRIVATE S16 stTHGenPAbtTcUserDist(spSapId, dstDlgId, dstDlgIdLen, 
                                  pAbtCause, qos,dstAddr, srcAddr)
StTUSap      spSapId;       /* TCAP lower Sap */
StDlgId      dstDlgId;      /* Destination Transaction id */
U8           dstDlgIdLen;   /* Destination Transaction id length */
U8           pAbtCause;     /* Provider abort cause */
StQosSet    *qos;           /* QOS parameters */
SpAddr      *dstAddr;       /* Destination SCCP Address */
SpAddr      *srcAddr;       /* Source SCCP Address */
#endif
{
   StSPSap    *spSapCp;   /* Lower SAP */
   StTUSap    *tuSapCp;   /* Upper SAP */
   SpId        tuSapId;   /* Upper SAP Id */
   StMsgEv     msgEv;     /* Transaction Portion Event structure */
   SpUDatEvnt  uDatEv;    /* SCCP Unit Data Event */
   Buffer     *mBuf;      /* Message buffer to prepare the Abort message */
   
   TRC2(stTHGenPAbtTcUserDist)

   STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
          "stTHGenPAbtTcUserDist:DestDlgId(%ld), PAbortCause(%d)\n",
          dstDlgId, pAbtCause));

   spSapCp = *(stCb.spSapLst + spSapId); /* Lower Sap */

   /* Initialize the transaction portion event structure */
   (Void)stZeroEv((Data *)&msgEv, ST_TYP_TRN_PRTN, spSapCp->cfg.swtch);

   /* prepare the transaction portion event structure */
   msgEv.msgType.pres   = TRUE;
   msgEv.msgType.val    = ST_MSG_TYP_PABT;
   msgEv.dstTrnsId.pres = TRUE;
   msgEv.dstTrnsId.val  = dstDlgId;
   msgEv.trnsIdLen.pres = TRUE;
   msgEv.trnsIdLen.val  = dstDlgIdLen;
   msgEv.pAbtCause.pres = TRUE;
   msgEv.pAbtCause.val  = pAbtCause;

   /* Allocate message buffer to build the abort message */
   if (SGetMsg(spSapCp->pstSP.region, spSapCp->pstSP.pool, &mBuf) != ROK)
   {
      /* st009.301 -Add- Debug prints */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                 "stTHGenPAbtTcUserDist:SGetMsg failed\n"));
      stSendAlarm(LCM_CATEGORY_RESOURCE, LST_EVENT_MSG_FAIL, LCM_CAUSE_UNKNOWN,
                  NOTUSED, NOTUSED);
      RETVALUE(RFAILED);
   }

   /* Encode the transaction portion */
   if (stEncMsg(&msgEv, spSapCp->cfg.swtch, mBuf) != ROK)
   {
      /* st027.301 - Modify - Modify the user buf free mechanism */ 
      STFREEUSERBUF(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
      STLOGERROR(ERRCLS_DEBUG, EST233, (ErrVal)0,
                 "stTHGenPAbtTcUserDist:stEncMsg failed");
#endif
      RETVALUE(RFAILED);
   }

   /* st031.301 - Add - Initialization of uDatEv */
   cmZero((Data *)&uDatEv, sizeof(SpUDatEvnt));

   /* copy TC-user passed QoS parameters to the SCCP unit data event */
   uDatEv.qos.credit = 0;
   uDatEv.qos.pClass = qos->seqCtl == TRUE ? PCLASS1:PCLASS0;
   uDatEv.qos.retOpt = qos->retOpt;
   uDatEv.prior      = qos->msgPrior;
   uDatEv.tmr        = spSapCp->cfg.spTmr;
   uDatEv.sc         = 0;
   uDatEv.esc        = TRUE;

   /* copy SCCP addresses */
   cmCopySpAddr(dstAddr, &uDatEv.cdAddr);
   cmCopySpAddr(srcAddr, &uDatEv.cgAddr);

   /* Generate Trace, if enabled */
   if (stCb.init.trc == TRUE)
   {
      stGenTrc(spSapCp->suId, LST_MSG_TXED, mBuf);
   }
   /* Find associated upper SAP Id */
   tuSapId = stSearchUSapList(spSapId,0,TRUE,FALSE);
   
   /* Statistics info cannot be updated if upper SAP not found  */
   if (tuSapId != ST_DEF_ASSOC_SAP_ID)
   {
      tuSapCp = stCb.tuSapLst[tuSapId];
      if (tuSapCp != (StTUSap*)NULLP)
      {     
         /* Increment the resource statistics counters */
         stUpdRsrcSts(&tuSapCp->sts, ST_STS_TX_MSG, ST_MSG_TYP_PABT,
                       tuSapCp->cfg.swtch);
 
         /* Increment the fault statistics counters */
         stUpdFaultSts(&tuSapCp->sts, ST_STS_FAULT, pAbtCause, 
                        tuSapCp->cfg.swtch, ST_STS_TX_MSG);

      }     
   }
   /* st014.301- Add- set the isni and imp information as not present */ 
#if (defined(SPTV2) && defined(SS7_ANS96))
   uDatEv.isni.isniPres = NOTPRSNT;
#endif /* SPTV2 && SS7_ANS96 */

#ifdef SPTV2 
   /* Set the imp information */
   uDatEv.imp.pres = NOTPRSNT; 
#endif /* SPTV2 */ 

   /* Send message to SCCP */
   (Void)StLiSptUDatReq(&spSapCp->pstSP, spSapCp->spId, &uDatEv, mBuf);

   RETVALUE(ROK);
}  /* End of stTHGenPAbtTcUserDist */
#endif /* ST_TC_USER_DIST */


/*
*
*       Fun:   stTHRxMsg
*
*       Desc:  Transaction Handler routine to process the received
*              Begin Message.
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 stTHRxMsg
(
StTUSap     *tuSapCp, /* Tcap Upper Sap */
StMsgEv     *msgEv,   /* Transaction portion event structure */
Buffer      *mBuf,    /* Message Buffer */
StQosSet    *qos,     /* Quality of Service set */
SpAddr      *dstAddr, /* Destination SCCP Address */
SpAddr      *srcAddr, /* Source SCCP Address */
Dpc          opc      /* Originating Point Code */
)
#else
PUBLIC S16 stTHRxMsg(tuSapCp, msgEv, mBuf, qos, dstAddr, srcAddr, opc)
StTUSap     *tuSapCp; /* Tcap Upper Sap */
StMsgEv     *msgEv;   /* Transaction portion event structure */
Buffer      *mBuf;    /* Message Buffer */
StQosSet    *qos;     /* Quality of Service set */
SpAddr      *dstAddr; /* Destination SCCP Address */
SpAddr      *srcAddr; /* Source SCCP Address */
Dpc          opc;     /* Originating Point Code */
#endif
{
   StDlgCp  *dlgCp;   /* Dialogue control point */
   StDlgId   spDlgId; /* Dialogue Id */

   TRC2(stTHRxMsg)

   /* Check the type of the message */
   switch(msgEv->msgType.val)
   {
      case ST_MSG_TYP_UNI:

#if 0 /* xingzhou.xu: modified for debug print -- 2006/08/30 */
	     STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
#endif
   	  	 STDBGP(ST_DBGMASK_NORMAL, (stCb.init.prntBuf,
                "stTHRxMsg:msgType(UNI)\n"));

#ifndef ZT   
/* st043.301 - Modification - Added suDlgId as parameter to stAllocDlg as  zero */
         if (stAllocDlg(tuSapCp, &dlgCp, 0) != ROK)
#else
         if (stAllocDlg(tuSapCp, &dlgCp, 0, 0, dstAddr, 
                        CMFTHA_IF_LOWER) != ROK)
#endif /* ZT  */ 
         {
            /* st027.301 - Modify - Modify the user buf free mechanism */ 
            STFREEUSERBUF(mBuf);   /* discard the message */
            /* st009.301 -Add- Debug prints */
            STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                   "stTHRxMsg:Dialogue allocation failed\n"));
            RETVALUE(RFAILED);
         }

         dlgCp->opc = opc;

         cmCopySpAddr(dstAddr, &dlgCp->dstAddr);
         cmCopySpAddr(srcAddr, &dlgCp->srcAddr);

         /* Pass the Uni Message indication to Dialogue Handler */
         stDHRxUni(dlgCp, mBuf, qos);
         break;

      case ST_MSG_TYP_BGN:

#if 0 /* xingzhou.xu: modified for debug print -- 2006/08/30 */
	     STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
#endif
   	  	 STDBGP(ST_DBGMASK_NORMAL, (stCb.init.prntBuf,
                "stTHRxMsg:msgType(BEGIN), OrigDlgId(%ld)\n",
                msgEv->orgTrnsId.val));

#ifndef ZT       
/* st043.301 - Modification - Added suDlgId as parameter to stAllocDlg as  zero */
         if (stAllocDlg(tuSapCp, &dlgCp, 0) != ROK)
#else
         if (stAllocDlg(tuSapCp, &dlgCp, 0, 0, dstAddr, 
                        CMFTHA_IF_LOWER) != ROK)
#endif /* ZT */
         {
            /* st027.301 - Modify - Modify the user buf free mechanism */ 
            STFREEUSERBUF(mBuf);   /* discard the message */

            /* Send P-Abort (Resource Limitation) message to peer */
            stTHGenPAbt(tuSapCp, msgEv->orgTrnsId.val, msgEv->trnsIdLen.val,
                        ST_PABT_LM_RSRC, qos, dstAddr, srcAddr);

            RETVALUE(RFAILED);
         }

         /* Store the destination dialogue Id and SCCP Addresses */
         dlgCp->dstDlgId = msgEv->orgTrnsId.val;
         dlgCp->dstDlgIdLen = msgEv->trnsIdLen.val;
         dlgCp->opc = opc;

         cmCopySpAddr(dstAddr, &dlgCp->dstAddr);
         cmCopySpAddr(srcAddr, &dlgCp->srcAddr);

         /* Execute the Transaction State Machine */
         if (stItuTsmExec(dlgCp, E_RX_BGN, (PTR)mBuf, (PTR)qos) != ROK)
         {
            /* st027.301 - Modify - Modify the user buf free mechanism */ 
            STFREEUSERBUF(mBuf);
            (Void)stFreeDlg(dlgCp);

            /* st009.301 -Add- Debug prints */
            STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
               "stTHRxMsg:Execution of stItuTsmExec failed for dialogue(%ld)\n",
               dlgCp->spDlgId));
            RETVALUE(RFAILED);
         }
         break;

      case ST_MSG_TYP_CNT:

#if 0 /* xingzhou.xu: modified for debug print -- 2006/08/30 */
	     STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
#endif
   	  	 STDBGP(ST_DBGMASK_NORMAL, (stCb.init.prntBuf,
                "stTHRxMsg:msgType(CONTINUE), OrigDlgId(%ld), DestDlgId(%ld)\n",
                msgEv->orgTrnsId.val, msgEv->dstTrnsId.val));

         spDlgId = msgEv->dstTrnsId.val;   /* dialogue Id */

         if (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, spDlgId, ST_USE_SPDLGID, &dlgCp) != ROK)
         {
            /* st027.301 - Modify - Modify the user buf free mechanism */ 
            STFREEUSERBUF(mBuf);   /* discard the message */

            /* st009.301 -Add- Debug prints */
            STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                   "stTHRxMsg:Dialogue not found (%ld)\n",spDlgId));
            /* Send P-Abort (Unrecognized Transaction Id) message to peer */
            stTHGenPAbt(tuSapCp, msgEv->orgTrnsId.val, msgEv->trnsIdLen.val,
                       ST_PABT_UR_TRID, qos, dstAddr, srcAddr);

            RETVALUE(RFAILED);
         }

         /* Store the destination dialogue Id, if not already stored */
         if (dlgCp->dstDlgId == 0)
         {
            dlgCp->dstDlgId    = msgEv->orgTrnsId.val;
            dlgCp->dstDlgIdLen = msgEv->trnsIdLen.val;
         }

         dlgCp->opc = opc;

         /* Save dst and src SCCP  addresses in dialog control point
            only for the first backward Continue */
         stChkTsmStAddr(dlgCp, dstAddr, srcAddr);
 
         /* Execute the Transaction State Machine */
         if (stItuTsmExec(dlgCp, E_RX_CNT, (PTR)mBuf, (PTR)qos) != ROK)
         {
            /* st027.301 - Modify - Modify the user buf free mechanism */ 
            STFREEUSERBUF(mBuf);
            /* st009.301 -Add- Debug prints */
            STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
               "stTHRxMsg:Execution of stItuTsmExec failed for dialogue(%ld)\n",
               dlgCp->spDlgId));
            (Void)stFreeDlg(dlgCp);

            RETVALUE(RFAILED);
         }
         break;

      case ST_MSG_TYP_END:

#if 0 /* xingzhou.xu: modified for debug print -- 2006/08/30 */
	     STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
#endif
   	  	 STDBGP(ST_DBGMASK_NORMAL, (stCb.init.prntBuf,
                "stTHRxMsg:msgType(END), DestDlgId(%ld)\n",
                msgEv->dstTrnsId.val));

         spDlgId = msgEv->dstTrnsId.val;   /* dialogue Id */

         if (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, spDlgId, ST_USE_SPDLGID, &dlgCp) != ROK)
         {
            /* st027.301 - Modify - Modify the user buf free mechanism */ 
            STFREEUSERBUF(mBuf);   /* discard the message */

            /* st009.301 -Add- Debug prints */
            STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                   "stTHRxMsg:Dialogue not found (%ld)\n",spDlgId));
            RETVALUE(RFAILED);
         }

         dlgCp->opc = opc;

         /* st017.301 -Add- set flag for dialogue terminating message */
         dlgCp->termMsg = TRUE;
         
         /* Execute the Transaction State Machine */
         if (stItuTsmExec(dlgCp, E_RX_END, (PTR)mBuf, (PTR)qos) != ROK)
         {
            /* st027.301 - Modify - Modify the user buf free mechanism */ 
            STFREEUSERBUF(mBuf);
            /* st009.301 -Add- Debug prints */
            STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
               "stTHRxMsg:Execution of stItuTsmExec failed for dialogue(%ld)\n",
               dlgCp->spDlgId));
            (Void)stFreeDlg(dlgCp);

            RETVALUE(RFAILED);
         }
         break;

      case ST_MSG_TYP_PABT:

         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stTHRxMsg:msgType(P-ABORT), DestDlgId(%ld), PAbortCause(%d)\n",
                msgEv->dstTrnsId.val, msgEv->pAbtCause.val));

         /* st027.301 - Modify - Modify the user buf free mechanism */ 
         STFREEUSERBUF(mBuf);   /* discard the message */

         spDlgId = msgEv->dstTrnsId.val;   /* dialogue Id */

         if (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, spDlgId, ST_USE_SPDLGID, &dlgCp) != ROK)
         {
            RETVALUE(RFAILED);
         }

         dlgCp->opc = opc;

         stUpdFaultSts(&tuSapCp->sts, ST_STS_FAULT, msgEv->pAbtCause.val,
                        tuSapCp->cfg.swtch, ST_STS_RX_MSG);

         /* Execute the Transaction State Machine */
         if (stItuTsmExec(dlgCp, E_RX_PABT, (PTR)&msgEv->pAbtCause.val,
                          (PTR)qos) != ROK)
         {
            /* st009.301 -Add- Debug prints */
            STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
               "stTHRxMsg:Execution of stItuTsmExec failed for dialogue(%ld)\n",
               dlgCp->spDlgId));
            (Void)stFreeDlg(dlgCp);

            RETVALUE(RFAILED);
         }
         break;

      case ST_MSG_TYP_UABT:

         STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
                "stTHRxMsg:msgType(U-ABORT), DestDlgId(%ld)\n",
                msgEv->dstTrnsId.val));

         spDlgId = msgEv->dstTrnsId.val;   /* dialogue Id */

         if (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, spDlgId, ST_USE_SPDLGID, &dlgCp) != ROK)
         {
            /* st027.301 - Modify - Modify the user buf free mechanism */ 
            STFREEUSERBUF(mBuf);   /* discard the message */
            RETVALUE(RFAILED);
         }

         dlgCp->opc = opc;

         /* Execute the Transaction State Machine */
         if (stItuTsmExec(dlgCp, E_RX_UABT, (PTR)mBuf, (PTR)qos) != ROK)
         {
            /* st027.301 - Modify - Modify the user buf free mechanism */ 
            STFREEUSERBUF(mBuf);
            /* st009.301 -Add- Debug prints */
            STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
               "stTHRxMsg:Execution of stItuTsmExec failed for dialogue(%ld)\n",
               dlgCp->spDlgId));
            (Void)stFreeDlg(dlgCp);

            RETVALUE(RFAILED);
         }
         break;

      default:
            /* Unrecognized message case has been taken care in stDecMsg */
            break;
   }

   RETVALUE(ROK);
}  /* End of stTHRxMsg */


/* st007.301 - Added - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
/*
*
*       Fun:   stTHRxMsgTcUserDist
*
*       Desc:  Transaction Handler routine to process the received
*              Message. Used in TC-User Distribution feature. This
*              routine is called when lower to upper SAP association
*              fails.
*              
*       Ret:   Void
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void stTHRxMsgTcUserDist
(
SuId        spSapId,  /* Tcap lower Sap */
StMsgEv     *msgEv,   /* Transaction portion event structure */
StQosSet    *qos,     /* Quality of Service set */
SpAddr      *dstAddr, /* Destination SCCP Address */
SpAddr      *srcAddr  /* Source SCCP Address */
)
#else
PUBLIC Void stTHRxMsgTcUserDist(spSapId, msgEv, qos, dstAddr, srcAddr, opc)
StTUSap     spSapId; /* Tcap Upper Sap */
StMsgEv     *msgEv;   /* Transaction portion event structure */
StQosSet    *qos;     /* Quality of Service set */
SpAddr      *dstAddr; /* Destination SCCP Address */
SpAddr      *srcAddr; /* Source SCCP Address */
#endif
{

   TRC2(stTHRxMsgTcUserDist)

   /* Check the type of the message */
   switch(msgEv->msgType.val)
   {
      case ST_MSG_TYP_UNI:
         /* Association should not fail for UNI messages */
         break;

      case ST_MSG_TYP_BGN:
         /* Association should not fail for Begin messages */
         break;

      case ST_MSG_TYP_CNT:

#if 0 /* xingzhou.xu: modified for debug print -- 2006/08/30 */
	     STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
#endif
   	  	 STDBGP(ST_DBGMASK_NORMAL, (stCb.init.prntBuf,
                "stTHRxMsgTcUserDist:msgType(CONTINUE), OrigDlgId(%ld), DestDlgId(%ld)\n",
                msgEv->orgTrnsId.val, msgEv->dstTrnsId.val));

         /* Send P-Abort (Unrecognized Transaction Id) message to peer */
         stTHGenPAbtTcUserDist(spSapId, msgEv->orgTrnsId.val, msgEv->trnsIdLen.val,
                                ST_PABT_UR_TRID, qos, dstAddr, srcAddr);

         break;

      case ST_MSG_TYP_END:
         /* In END message no action is necessary */
         break;

      case ST_MSG_TYP_PABT:
         /* In PABT message, no action is necessary */
         break;

      case ST_MSG_TYP_UABT:
         /* In UABT message, no action is necessary */
         break;

      default:
            /* Unrecognized message case has been taken care in stDecMsg */
            break;
   } /* switch */
}
#endif /* ST_TC_USER_DIST */


/*
*
*       Fun:   stTHRxIncMsg
*
*       Desc:  Transaction Handler routine to process the received
*              Incorrect Message.
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PUBLIC  S16 stTHRxIncMsg
(
StTUSap     *tuSapCp, /* Tcap Upper Sap */
StMsgEv     *msgEv,   /* Transaction portion event structure */
StQosSet    *qos,     /* Quality of Service set */
SpAddr      *dstAddr, /* Destination SCCP Address */
SpAddr      *srcAddr  /* Source SCCP Address */
)
#else
PUBLIC  S16 stTHRxIncMsg(tuSapCp, msgEv, qos, dstAddr, srcAddr)
StTUSap     *tuSapCp; /* Tcap Upper Sap */
StMsgEv     *msgEv;   /* Transaction portion event structure */
StQosSet    *qos;     /* Quality of Service set */
SpAddr      *dstAddr; /* Destination SCCP Address */
SpAddr      *srcAddr; /* Source SCCP Address */
#endif
{
   StDlgCp   *dlgCp;   /* Dialogue control point */

   TRC2(stTHRxIncMsg)

   /* Check the type of the message */
   switch(msgEv->msgType.val)
   {
      case ST_MSG_TYP_UNI:
         break;

      case ST_MSG_TYP_END:

         if ((msgEv->dstTrnsId.pres) &&
             (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, msgEv->dstTrnsId.val, ST_USE_SPDLGID,
                       &dlgCp) == ROK))
         {
            /* Increment the fault statistics counters */
            stUpdFaultSts(&tuSapCp->sts, ST_STS_FAULT, msgEv->pAbtCause.val,
                          tuSapCp->cfg.swtch, ST_STS_TX_MSG);

            /* Send p_abort to local user */
            (Void)stItuTsmExec(dlgCp, E_RX_PABT, (PTR)&msgEv->pAbtCause.val,
                               (PTR)qos);
         }
         break;

      case ST_MSG_TYP_UABT:
      case ST_MSG_TYP_PABT:

         if ((msgEv->dstTrnsId.pres) &&
             (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, msgEv->dstTrnsId.val, ST_USE_SPDLGID,
                       &dlgCp) == ROK))
         {
            /* Increment the fault statistics counters */
            stUpdFaultSts(&tuSapCp->sts, ST_STS_FAULT, msgEv->pAbtCause.val,
                          tuSapCp->cfg.swtch, ST_STS_TX_MSG);

            /* Send P-Abort to local user */
            (Void)stItuTsmExec(dlgCp, E_RX_PABT, (PTR)&msgEv->pAbtCause.val,
                               (PTR)qos);
         }
         break;

      case ST_MSG_TYP_BGN:

         /* If destination dialogue Id is present, send P-Abort to peer */
         if (msgEv->orgTrnsId.pres)
         {
            stTHGenPAbt(tuSapCp, msgEv->orgTrnsId.val, msgEv->trnsIdLen.val,
                        msgEv->pAbtCause.val, qos, dstAddr, srcAddr);
         }
         break;

      case ST_MSG_TYP_CNT:

         /* If destination dialogue Id is present, send P-Abort to peer */
         if (msgEv->orgTrnsId.pres)
         {
            stTHGenPAbt(tuSapCp, msgEv->orgTrnsId.val, msgEv->trnsIdLen.val,
                        msgEv->pAbtCause.val, qos, dstAddr, srcAddr);
         }

         /* If source dialogue Id is present, get the dialogue control point
            and free it */

         if ((msgEv->dstTrnsId.pres) &&
             (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, msgEv->dstTrnsId.val, ST_USE_SPDLGID,
                       &dlgCp) == ROK))
         {
            /* Send p_abort to local user */
            (Void)stItuTsmExec(dlgCp, E_RX_PABT, (PTR)&msgEv->pAbtCause.val,
                               (PTR)qos);
         }
            
         break;

      default:

         /* If destination dialogue Id is present, send P-Abort to peer */
         if (msgEv->orgTrnsId.pres)
         {
            stTHGenPAbt(tuSapCp, msgEv->orgTrnsId.val, msgEv->trnsIdLen.val,
                        msgEv->pAbtCause.val, qos, dstAddr, srcAddr);
         }

         /* If source dialogue Id is present, get the dialogue control point
            and free it */

         if ((msgEv->dstTrnsId.pres) &&
             (stFndDlg(&tuSapCp->dlgHlCp, &tuSapCp->suDlgHlCp, msgEv->dstTrnsId.val, ST_USE_SPDLGID,
                       &dlgCp) == ROK))
         {
            /* Send p_abort to local user */
            (Void)stItuTsmExec(dlgCp, E_RX_PABT, (PTR)&msgEv->pAbtCause.val,
                               (PTR)qos);
         }
            
         break;
   }

   RETVALUE(ROK);
}  /* End of stTHRxIncMsg */



/* st007.301 - Added - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
/*
*
*       Fun:   stTHRxIncMsgTcUserDist
*
*       Desc:  Transaction Handler routine to process the received
*              Incorrect Message.Used in TC-User Distribution
*              feature.
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PUBLIC  S16 stTHRxIncMsgTcUserDist
(
SuId        spSapId,  /* Tcap lower Sap */
StMsgEv     *msgEv,   /* Transaction portion event structure */
StQosSet    *qos,     /* Quality of Service set */
SpAddr      *dstAddr, /* Destination SCCP Address */
SpAddr      *srcAddr  /* Source SCCP Address */
)
#else
PUBLIC  S16 stTHRxIncMsgTcUserDist(spSapId, msgEv, qos, dstAddr, srcAddr)
SuId        spSapId;  /* Tcap lower Sap */
StMsgEv     *msgEv;   /* Transaction portion event structure */
StQosSet    *qos;     /* Quality of Service set */
SpAddr      *dstAddr; /* Destination SCCP Address */
SpAddr      *srcAddr; /* Source SCCP Address */
#endif
{
   TRC2(stTHRxIncMsgTcUserDist)

   /* Check the type of the message */
   switch(msgEv->msgType.val)
   {
      case ST_MSG_TYP_UNI:
         /* Cant do anything without destination Transaction Id */     
         break;

      case ST_MSG_TYP_END:
         /* Cant do anything without destination Transaction Id */     
         break;
         
      case ST_MSG_TYP_UABT:
      case ST_MSG_TYP_PABT:
         /* Cant do anything without destination Transaction Id */     
         break;

      case ST_MSG_TYP_BGN:

         /* If destination dialogue Id is present, send P-Abort to peer */
         if (msgEv->orgTrnsId.pres)
         {
            stTHGenPAbtTcUserDist(spSapId, msgEv->orgTrnsId.val, msgEv->trnsIdLen.val,
                        msgEv->pAbtCause.val, qos, dstAddr, srcAddr);
         }
         break;

      case ST_MSG_TYP_CNT:

         /* If destination dialogue Id is present, send P-Abort to peer */
         if (msgEv->orgTrnsId.pres)
         {
            stTHGenPAbtTcUserDist(spSapId, msgEv->orgTrnsId.val, msgEv->trnsIdLen.val,
                        msgEv->pAbtCause.val, qos, dstAddr, srcAddr);
         }
         break;

      default:

         /* If destination dialogue Id is present, send P-Abort to peer */
         if (msgEv->orgTrnsId.pres)
         {
            stTHGenPAbtTcUserDist(spSapId, msgEv->orgTrnsId.val, 
                                  msgEv->trnsIdLen.val,msgEv->pAbtCause.val, 
                                  qos, dstAddr, srcAddr);
         }
         break;
   }

   RETVALUE(ROK);
}
#endif /* ST_TC_USER_DIST */


/*
*
*       Fun:   stGenLocPAbt
*
*       Desc:  Routine to generate the local P-Abort message to the local user. This
*              is used to take care of the errors in the Data request primitive.
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void stGenLocPAbt
(
StTUSap     *tuSapCp,     /* Tcap Upper Sap */
StDlgId      suDlgId,     /* Service user dialogue id */
StDlgId      spDlgId,     /* Service provider dialogue id */
U8           pAbtCause,   /* Provider's abort cause */
StQosSet    *qos,         /* Quality of Service set */
SpAddr      *dstAddr,     /* Destination SCCP Address */
SpAddr      *srcAddr      /* Source SCCP Address */
)
#else
PUBLIC Void stGenLocPAbt(tuSapCp, suDlgId, spDlgId, pAbtCause, qos, dstAddr, srcAddr)
StTUSap     *tuSapCp;     /* Tcap Upper Sap */
StDlgId      suDlgId;     /* Service user dialogue id */
StDlgId      spDlgId;     /* Service provider dialogue id */
U8           pAbtCause;   /* Provider's abort cause */
StQosSet    *qos;         /* Quality of Service set */
SpAddr      *dstAddr;     /* Destination SCCP Address */
SpAddr      *srcAddr;     /* Source SCCP Address */
#endif
{
   StOctet    abrtCause;
   StDlgEv    oDlgEv;    /* Old style dialogye event */
   /* st024.301 - addition, added code to differentiate ANSI and ITU PAbrt */
   U8         msgType;

   TRC2(stGenLocPAbt)

   /* st009.301 -Add-  Print debug info */
   STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
          "Sending Local Abort to user for Sap(%d), user dialogue(%ld) \
           TCAP dialogue (%ld),abort cause(%d)\n",tuSapCp->suId,suDlgId,
           spDlgId,pAbtCause));

   abrtCause.pres  = TRUE;
   abrtCause.octet = pAbtCause;
   oDlgEv.pres     = FALSE;
   /* st038.301 - Addition - Initialise msgtype. */
   msgType         = STU_P_ABORT;

   /* st024.301 - addition, added code to differentiate ANSI and ITU PAbrt */
   switch(tuSapCp->cfg.swtch)
   {
      case LST_SW_ITU88:
      case LST_SW_ITU92:
      case LST_SW_ITU96:
         msgType = STU_P_ABORT;
         break;
      default:
         /* not possible */
         break;
   }

   /* st014.301 -Add- set isni value as Not Present */
#ifdef STUV2
   stDataParam.imp.pres = NOTPRSNT;
#endif /* STUV2 */

#if (defined(SS7_ANS96) && defined(STUV2))
   stDataParam.isni.isniPres = NOTPRSNT;
#endif /* STUV2 && SS7_ANS96 */

   /* st014.301 -Send isni information to TC-User via Data Indication */ 
#ifdef STUV2   
   /* Send P-Abort indication to the service user */
   StUiStuDatInd( &tuSapCp->pstTU,
                   tuSapCp->suId,
                   msgType,
                   suDlgId,
                   spDlgId,
                   dstAddr,
                   srcAddr,
                   FALSE,
                  &abrtCause,
                   qos,
                   0,
                  &oDlgEv,
                  &stDataParam,
                   NULLP );
#else  /* not STUV2 */
   /* Send P-Abort indication to the service user */
   StUiStuDatInd( &tuSapCp->pstTU,
                   tuSapCp->suId,
                   msgType,
                   suDlgId,
                   spDlgId,
                   dstAddr,
                   srcAddr,
                   FALSE,
                  &abrtCause,
                   qos,
                   0,
                  &oDlgEv,
                   NULLP );
#endif /* STUV2 */

   RETVOID;
}  /* End of stGenLocPAbt */


/*
*
*       Fun:   stGenLocRej
*
*       Desc:  Routine to generate the local Reject Component to the local user.
*              This is used to take care of the errors in the Data request
*              primitive.
*
*       Ret:   ROK       if successful
*              RFAILED   if failure
*
*       Notes: None
*
*       File:  ct_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 stGenLocRej
(
StTUSap     *tuSapCp,     /* Tcap Upper Sap */
StDlgId      suDlgId,     /* Service user dialogue id */
StDlgId      spDlgId,     /* Service provider dialogue id */
StInvId      invId,       /* Invoke Id */
U8           probType,    /* Problem Type */
U8           probCode     /* Problem Code */
)
#else
PUBLIC S16 stGenLocRej(tuSapCp, suDlgId, spDlgId, invId, probType, probCode)
StTUSap     *tuSapCp;     /* Tcap Upper Sap */
StDlgId      suDlgId;     /* Service user dialogue id */
StDlgId      spDlgId;     /* Service provider dialogue id */
StInvId      invId;       /* Invoke Id */
U8           probType;    /* Problem Type */
U8           probCode;    /* Problem Code */
#endif
{
   StComps   compEv;

   TRC2(stGenLocRej)

   /* st009.301 -Add-  Print debug info */
   STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
          "Generating local reject to user for Sap(%d),user dialogue ID(%ld),\
          TCAP dialogue Id(%ld),Problem type(%d),problem Code(%d)\n",
          tuSapCp->spId, suDlgId, spDlgId, probType, probCode));

   cmZero((Data *)&compEv, sizeof(StComps));

   compEv.stCompType = STU_REJECT;

   switch(tuSapCp->cfg.swtch)
   {
      case LST_SW_ITU88:
      case LST_SW_ITU92:
      case LST_SW_ITU96:
         compEv.stInvokeId.pres = TRUE;
         compEv.stInvokeId.octet = invId;
         compEv.stProbCodeFlg        = probType;
         compEv.stProbCode.len       = 1;
         compEv.stProbCode.string[0] = probCode;
         break;

   }
   compEv.stLastCmp = TRUE;

   StUiStuCmpInd( &tuSapCp->pstTU,
                   tuSapCp->suId,
                   suDlgId,
                   spDlgId,
                  &compEv,
                   (Dpc)0,
                   STU_COMP_REJ_LOCAL,
                   NULLP );

   RETVALUE(ROK);
} /* End of stGenLocRej */


/************************************************************************
                   Invocation State Machine
************************************************************************/

/*
*
*       Fun:    stItuIsmInit
*
*       Desc:   Initialize the Invocation State Table for ITU TCAP
*
*       Ret:    ROK        if successful
*               RFAILED    if failure
*
*       Notes:  None
*
*       File:   ct_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 stItuIsmInit
(
StSMList    *ism       /* Invocation state table */
)
#else
PUBLIC S16 stItuIsmInit (ism)
StSMList    *ism;      /* Invocation state table */
#endif
{
   SMTblEnt *smTbl;
   U16       idx=0;

   TRC2(stItuIsmInit)

   smTbl = (SMTblEnt *)stAlloc(ST_MAX_ITU_ISM_SIZE * sizeof(SMTblEnt));
   
   if (smTbl == (SMTblEnt *)NULLP)
   {
      /* st009.301 -Add- Print debug info */
      STDBGP(ST_DBGMASK_GEN, (stCb.init.prntBuf,
             "stItuIsmInit:ITU state table allocation failed\n"));
      stSendAlarm(LCM_CATEGORY_RESOURCE, LST_EVENT_ALOC_FAIL, LCM_CAUSE_UNKNOWN,
                  NOTUSED, NOTUSED);
      RETVALUE(RFAILED);
   }

#ifdef ST_ENABLE_SM_ARRAY /* xingzhou.xu: modified the state match mechanism --2006/09/13 */
   idx = ST_TABLE_TYPE_ISM;
#endif

   /*                  Current-State   Event     Next-State  Action-Routine
    *---------------------------------------------------------------------*/
   ST_SM_ENT(smTbl, idx, S_ISM_IDLE,  E_TX_OP1,  S_ISM_OPTX1, stIsmActOp);
   ST_SM_ENT(smTbl, idx, S_ISM_IDLE,  E_TX_OP2,  S_ISM_OPTX2, stIsmActOp);
   ST_SM_ENT(smTbl, idx, S_ISM_IDLE,  E_TX_OP3,  S_ISM_OPTX3, stIsmActOp);
   ST_SM_ENT(smTbl, idx, S_ISM_IDLE,  E_TX_OP4,  S_ISM_OPTX4, stIsmActOp);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX1, E_RX_RRL,  S_ISM_WFREJ, stIsmActCmp);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX1, E_RX_RE,   S_ISM_WFREJ, stIsmActCmp);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX1, E_RX_RRNL, S_ISM_OPTX1, stIsmActCmp);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX1, E_RX_REJ,  S_ISM_IDLE,  stIsmActRej);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX1, E_TERM,    S_ISM_IDLE,  stIsmActTerm);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX1, E_INV_TMR, S_ISM_IDLE,  stIsmActInvTmr);
   ST_SM_ENT(smTbl, idx, S_ISM_WFREJ, E_TERM,    S_ISM_IDLE,  stIsmActTerm);
   ST_SM_ENT(smTbl, idx, S_ISM_WFREJ, E_REJ_TMR, S_ISM_IDLE,  stIsmActRejTmr); 
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX2, E_RX_RE,   S_ISM_WFREJ, stIsmActCmp);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX2, E_RX_RRL,  S_ISM_IDLE,  stIsmActIRes);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX2, E_RX_RRNL, S_ISM_IDLE,  stIsmActIRes);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX2, E_RX_REJ,  S_ISM_IDLE,  stIsmActRej);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX2, E_TERM,    S_ISM_IDLE,  stIsmActTerm);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX2, E_INV_TMR, S_ISM_IDLE,  stIsmActInvTmr);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX3, E_RX_RRL,  S_ISM_WFREJ, stIsmActCmp);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX3, E_RX_RRNL, S_ISM_OPTX3, stIsmActCmp);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX3, E_RX_RE,   S_ISM_IDLE,  stIsmActIErr);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX3, E_RX_REJ,  S_ISM_IDLE,  stIsmActRej);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX3, E_TERM,    S_ISM_IDLE,  stIsmActTerm);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX3, E_INV_TMR, S_ISM_IDLE,  stIsmActInvTmr);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX4, E_RX_RRL,  S_ISM_IDLE,  stIsmActIRes);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX4, E_RX_RRNL, S_ISM_IDLE,  stIsmActIRes);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX4, E_RX_RE,   S_ISM_IDLE,  stIsmActIErr);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX4, E_RX_REJ,  S_ISM_IDLE,  stIsmActRej);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX4, E_TERM,    S_ISM_IDLE,  stIsmActTerm);
   ST_SM_ENT(smTbl, idx, S_ISM_OPTX4, E_INV_TMR, S_ISM_IDLE,  stIsmActInvTmr);

   ism->tbl  = smTbl;
#ifdef ST_ENABLE_SM_ARRAY /* xingzhou.xu: modified the state match mechanism --2006/09/13 */
   ism->size = ST_MAX_ITU_ISM_SIZE;
#else
   ism->size = idx;
#endif

   RETVALUE(ROK);
}  /* end of stItuIsmInit */


/*
*
*       Fun:    stItuIsmExec
*
*       Desc:   Execute one transition of the Invocation State Machine.
*
*       Ret:    ROK        if successful
*               RFAILED    if failure
*
*       Notes:  None
*
*       File:   ct_bdy2.c
*
*/
#ifdef ANSI
PUBLIC  S16 stItuIsmExec
(
StInvCp  *invCp,        /* INvoke Control point */
StEvent   smEvent,      /* State Machine Event */
PTR       data1,        /* Data to pass to the action routine */
PTR       data2         /* Data to pass to the action routine */
)
#else
PUBLIC  S16 stItuIsmExec(invCp, smEvent, data1, data2)
StInvCp  *invCp;        /* INvoke Control point */
StEvent   smEvent;      /* State Machine Event */
PTR       data1;        /* Data to pass to the action routine */
PTR       data2;        /* Data to pass to the action routine */
#endif
{
   SMTblEnt *smTbl;     /* State machine table */
   U16       smSize;    /* Size of the table */
   U16        i;         /* counter to go thru the table */

   TRC2(stItuIsmExec)

   smTbl  = stCb.smTbls.ituIsm.tbl;
   smSize = stCb.smTbls.ituIsm.size;

   /* Search the state machine list for a matching state-event pair. */

#ifdef ST_ENABLE_SM_ARRAY /* xingzhou.xu: modified the state match mechanism --2006/09/13 */
   if(stGetItuIsmIdx(invCp->ismSt,smEvent,&i) == ROK)
#else   	
   for(i = 0; i < smSize; i++)
#endif   	
   {
      if ((smTbl[i].curState == invCp->ismSt) &&
          (smTbl[i].smEvent  == smEvent))
      {
         invCp->ismSt = smTbl[i].nextState;

         /* Execute the transition's action routines. */

         if (smTbl[i].actRoutine != NULLP)
	         smTbl[i].actRoutine((PTR)invCp, data1, data2);
         else
         {
			 STLOGERROR(ERRCLS_DEBUG, ESTXXX, (ErrVal)i,
       	          "stItuIsmExec: ismTbl[i].actRoutine is NULLP !");
			 RETVALUE(RFAILED);     	    
         }

         RETVALUE(ROK);
      }
   }

   RETVALUE(RFAILED);
}  /* End of stItuIsmExec */


/************************************************************************
                   Transaction State Machine
************************************************************************/

/*
*
*       Fun:    stItuTsmInit
*
*       Desc:   Initialize the Transaction State Table for ITU TCAP
*
*       Ret:    ROK        if successful
*               RFAILED    if failure
*
*       Notes:  None
*
*       File:   ct_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 stItuTsmInit
(
StSMList    *tsm       /* Transaction state table */
)
#else
PUBLIC S16 stItuTsmInit (tsm)
StSMList    *tsm;      /* Transaction state table */
#endif
{
   SMTblEnt *smTbl;
   U16       idx=0;

   TRC2(stItuTsmInit)

   smTbl = (SMTblEnt *)stAlloc(ST_MAX_ITU_TSM_SIZE * sizeof(SMTblEnt));

   if (smTbl == (SMTblEnt *)NULLP)
   {
      stSendAlarm(LCM_CATEGORY_RESOURCE, LST_EVENT_ALOC_FAIL, LCM_CAUSE_UNKNOWN,
                  NOTUSED, NOTUSED);
      RETVALUE(RFAILED);
   }

#ifdef ST_ENABLE_SM_ARRAY /* xingzhou.xu: modified the state match mechanism --2006/09/13 */
   idx = ST_TABLE_TYPE_TSM;
#endif

   /*                  Current-State Event    Next-State  Action-Routine
    *---------------------------------------------------------------------*/
   ST_SM_ENT(smTbl, idx, S_TSM_IDLE, E_RX_BGN,  S_TSM_IR,   stDHRxBgn);
   ST_SM_ENT(smTbl, idx, S_TSM_IS,   E_RX_CNT,  S_TSM_ACT,  stDHRxCnt);
   ST_SM_ENT(smTbl, idx, S_TSM_IS,   E_RX_END,  S_TSM_IDLE, stDHRxEnd);
   ST_SM_ENT(smTbl, idx, S_TSM_IS,   E_RX_UABT, S_TSM_IDLE, stDHRxUAbt);
   ST_SM_ENT(smTbl, idx, S_TSM_IS,   E_RX_PABT, S_TSM_IDLE, stDHRxPAbt);
   ST_SM_ENT(smTbl, idx, S_TSM_ACT,  E_RX_CNT,  S_TSM_ACT,  stDHRxCnt);
   ST_SM_ENT(smTbl, idx, S_TSM_ACT,  E_RX_END,  S_TSM_IDLE, stDHRxEnd);
   ST_SM_ENT(smTbl, idx, S_TSM_ACT,  E_RX_UABT, S_TSM_IDLE, stDHRxUAbt);
   ST_SM_ENT(smTbl, idx, S_TSM_ACT,  E_RX_PABT, S_TSM_IDLE, stDHRxPAbt);
   ST_SM_ENT(smTbl, idx, S_TSM_IDLE, E_TX_BGN,  S_TSM_IS,   stTHTxBgn);
   ST_SM_ENT(smTbl, idx, S_TSM_IR,   E_TX_CNT,  S_TSM_ACT,  stTHTxCnt);
   ST_SM_ENT(smTbl, idx, S_TSM_IR,   E_TX_END,  S_TSM_IDLE, stTHTxEnd);
   ST_SM_ENT(smTbl, idx, S_TSM_IR,   E_TX_UABT, S_TSM_IDLE, stTHTxUAbt);
   ST_SM_ENT(smTbl, idx, S_TSM_IR,   E_TX_PABT, S_TSM_IDLE, stTHTxPAbt);
   ST_SM_ENT(smTbl, idx, S_TSM_IS,   E_TX_END,  S_TSM_IDLE, NULLP);
   ST_SM_ENT(smTbl, idx, S_TSM_IS,   E_TX_UABT, S_TSM_IDLE, NULLP);
   ST_SM_ENT(smTbl, idx, S_TSM_IS,   E_TX_PABT, S_TSM_IDLE, NULLP);
   ST_SM_ENT(smTbl, idx, S_TSM_ACT,  E_TX_CNT,  S_TSM_ACT,  stTHTxCnt);
   ST_SM_ENT(smTbl, idx, S_TSM_ACT,  E_TX_END,  S_TSM_IDLE, stTHTxEnd);
   ST_SM_ENT(smTbl, idx, S_TSM_ACT,  E_TX_UABT, S_TSM_IDLE, stTHTxUAbt);
   ST_SM_ENT(smTbl, idx, S_TSM_ACT,  E_TX_PABT, S_TSM_IDLE, stTHTxPAbt);

   tsm->tbl  = smTbl;
#ifdef ST_ENABLE_SM_ARRAY /* xingzhou.xu: modified the state match mechanism --2006/09/13 */
   tsm->size = ST_MAX_ITU_TSM_SIZE;
#else
   tsm->size = idx;
#endif

   RETVALUE(ROK);
}  /* end of stItuTsmInit */


/*
*
*       Fun:    stChkTsmStAddr
*
*       Desc:   Check TSM state and store the SCCP addresses.
*
*       Ret:    ROK        if successful
*               RFAILED    if failure
*
*       Notes:  Addresses are stored only for the first backward continue
*               or conversation message..otherwise already stored addresses
*               are assumed..this is to provide flexibility to TC_User to 
*               change it's source address in first backward message.
*
*       File:   ct_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 stChkTsmStAddr
(
StDlgCp  *dlgCp,        /* Dialogue Control point */
SpAddr   *dstAddr,      /* Destination SCCP Address */
SpAddr   *srcAddr       /* Source SCCP Address */
)
#else
PUBLIC S16 stChkTsmStAddr(dlgCp, dstAddr, srcAddr)
StDlgCp  *dlgCp;        /* Dialogue Control point */
SpAddr   *dstAddr;      /* Destination SCCP Address */
SpAddr   *srcAddr;      /* Source SCCP Address */
#endif
{

   TRC2(stChkTsmStAddr)
 
   /* st002.301 - Originating Address should not be changed in case of first 
                  backward Continue message, i.e. if the TSM is S_TSM_IS.
                  Code is modified to comply with this requirement */
  
   if (dlgCp->tslSt == S_TSM_IR)
   {
      cmCopySpAddr(dstAddr, &dlgCp->dstAddr);
      cmCopySpAddr(srcAddr, &dlgCp->srcAddr);
   }

   if (dlgCp->tslSt == S_TSM_IS)
   {
      cmCopySpAddr(dstAddr, &dlgCp->dstAddr);
   }

   RETVALUE(ROK);
}  /* End of stChkTsmStAddr */


/*
*
*       Fun:    stItuTsmExec
*
*       Desc:   Execute one transition of the Transaction State Machine.
*
*       Ret:    ROK        if successful
*               RFAILED    if failure
*
*       Notes:  None
*
*       File:   ct_bdy2.c
*
*/
#ifdef ANSI
PRIVATE S16 stItuTsmExec
(
StDlgCp  *dlgCp,        /* Dialogue Control point */
StEvent   smEvent,      /* Event to be acted upon */
PTR       data1,        /* Data pointer to be passed to the action routine */
PTR       data2         /* Data pointer to be passed to the action routine */
)
#else
PRIVATE S16 stItuTsmExec(dlgCp, smEvent, data1, data2)
StDlgCp  *dlgCp;        /* Dialogue Control point */
StEvent   smEvent;      /* Event to be acted upon */
PTR       data1;        /* Data pointer to be passed to the action routine */
PTR       data2;        /* Data pointer to be passed to the action routine */
#endif
{
   SMTblEnt *smTbl;     /* State machine table */
   U16       smSize;    /* Size of the table */
   U16        i;         /* counter to go thru the table */

   TRC2(stItuTsmExec)

   smTbl  = stCb.smTbls.ituTsm.tbl;
   smSize = stCb.smTbls.ituTsm.size;

   /* Search the state machine list for a matching state-event pair. */
#ifdef ST_ENABLE_SM_ARRAY /* xingzhou.xu: modified the state match mechanism --2006/09/13 */
   if(stGetItuTsmIdx(dlgCp->tslSt,smEvent,&i) == ROK)
#else   	
   for (i = 0; i < smSize; i++)
#endif   	
   {
      if ((smTbl[i].curState == dlgCp->tslSt) &&
          (smTbl[i].smEvent  == smEvent))
      {
         /* Check if the state machine is being executed for the first
            backward continue message */
         if (((dlgCp->tslSt == S_TSM_IR) || (dlgCp->tslSt == S_TSM_IS)) &&
             (smTbl[i].nextState == S_TSM_ACT))
         {
            dlgCp->firstBackMsg = TRUE;
         }
         else
         {
            dlgCp->firstBackMsg = FALSE;
         }
         
         dlgCp->tslSt = smTbl[i].nextState;

         /* Execute the transition's action routines. */

         if (smTbl[i].actRoutine != NULLP)
         {
            smTbl[i].actRoutine((PTR)dlgCp, data1, data2);
         }
         else
         {
            /* Action routine is NULL, clear up locally */
            (Void)stFreeDlg(dlgCp);

            /* st027.301 - Modify - Modify the user buf free mechanism */ 
            STFREEUSERBUF(data1);
         }

         RETVALUE(ROK);
      }
   }

   RETVALUE(RFAILED);
}  /* End of stItuTsmExec */

#ifdef ST_ENABLE_SM_ARRAY /* xingzhou.xu: modified the state match mechanism --2006/09/13 */

PRIVATE S16 stGetItuTsmIdx
(
U8	smState,        /*  */
StEvent   smEvent,      /* Event to be acted upon */
U16	*tblIdx
)
{
	S16 stateIdx=0, evtIdx=0;

	stateIdx = smState - ST_ITUTSM_ST_BASE;
	evtIdx = smEvent - ST_ITUTSM_EV_BASE;
#if (ERRCLASS & ERRCLS_INT_PAR)
      if ((stateIdx < 0)||
	  	(stateIdx >= ST_MAX_NUM_ITUTSM_ST) ||
	  	(evtIdx < 0)||
	  	(evtIdx >= ST_MAX_NUM_ITUTSM_EV))
	{
	      STLOGERROR(ERRCLS_INT_PAR, ESTXXX, (ErrVal)evtIdx,
       	          "stGetItuTsmEnt: invalid stateIdx or evtIdx !");
		RETVALUE(RFAILED);
	}
#endif
	(*tblIdx) = stateIdx*ST_MAX_NUM_ITUTSM_EV + evtIdx;
	
	RETVALUE(ROK);
	  
}


PRIVATE S16 stGetItuIsmIdx
(
U8	smState,        /*  */
StEvent   smEvent,      /* Event to be acted upon */
U16	*tblIdx
)
{
	S16 stateIdx=0, evtIdx=0;

	stateIdx = smState - ST_ITUISM_ST_BASE;
	evtIdx = smEvent - ST_ITUISM_EV_BASE;
#if (ERRCLASS & ERRCLS_INT_PAR)
      if ((stateIdx < 0)||
	  	(stateIdx >= ST_MAX_NUM_ITUISM_ST) ||
	  	(evtIdx < 0)||
	  	(evtIdx >= ST_MAX_NUM_ITUISM_EV))
	{
	      STLOGERROR(ERRCLS_INT_PAR, ESTXXX, (ErrVal)evtIdx,
       	          "stGetItuTsmEnt: invalid stateIdx or evtIdx !");
		RETVALUE(RFAILED);
	}
#endif
	(*tblIdx) = stateIdx*ST_MAX_NUM_ITUISM_EV + evtIdx;
	
	RETVALUE(ROK);
	  
}
#endif /* ST_ENABLE_SM_ARRAY */

/********************************************************************30**
 
         End of file:     ct_bdy2.c@@/main/17 - Fri Nov 17 10:34:30 2000

*********************************************************************31*/
 

/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 

/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
 
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  mma   1. initial release
 
1.2          ---  mma   1. remove some unused local variables
 
1.3          ---  mma   1. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92

1.4          ---  mma   1. miscellaneous changes

1.5          ---  lc    1. added support for StaInd from SCCP
             ---  lc    2. added new primitive support SrvInd with TCAP User
             ---  lc    3. set endFlg to TRUE in DatReq for termination of
                           the dialog
             ---  ak    4. added PCSteInd support to pass status from
                           SCCP to TCAP user.
             ---  ak    5. changes to reflect new StDlgCp structure.
             ---  ak    6. StMiLstCfgReq now uses stGen fields nmbDlgs and
                           nmbInvs for static memory allocation.
             ---  ak    7. support new interface.
             ---  ak    8. changed name of management primitives
                           MST**** -> SmMiLmi****
             ---  ak    9. added msgPrior parameter to UDAtReq and DatReq
             ---  ak    10. replaced ss_ms/ss_pt.[hx] with ssi.[hx]
             ---  ak    11. SmMiLmi -> StMiLst
             ---  ak    12. lm_pt.[hx] -> lst.[hx]

1.6          ---  ak    1. added new error numbers to replace ESTXXX

1.7          ---  ak    1. store stSuDlgId in when Continue recd from TU
             ---  ak    2. common Timing queue structures

1.8          ---  ak    1. CCITT and ANSI 92 support
             ---  ak    2. added stDlgEv stQosSet and opc to (U)DatReq
             ---  ak    3. added stAbrtInfo to DatReq primitive
             ---  ak    4. renamed StaReq -> CmpReq
             ---  ak    5. added checks to make sure we are bound before
                           accepting a packet (else generate Alarm)
             ---  ak    6. Added Unbind Request.
             ---  ak    7. statistics structure is filled in conditionally
                           in StsReq. Also, it returns stats and then zeros
                           on ZEROST
             ---  ak    8. switched the way cdAddr and cgAddr are treated
                           in SptUDatInd (cdAddr = DestAddr & cgAddr = SrcAddr)
             ---  ak    9. TCUCfg no longer has class field.

1.9          ---  ak    1. CfgReq: Sap config: no longer zero out dialog hash
                           table when reconfiguring an existing Sap.
             ---  aa    2. Changes due to TCAP uuper interface changes.
             ---  aa    3. surrounded instances of ANSI88 with ANSI92 as well. 

1.10         ---  aa    1. change SS7_XXX defines

1.11         ---  aa    1. Added trace Indication 

1.12         ---  aa    1. The length of the incoming transaction Id is passed
                           in stSndPAbrt function
             ---  aa    2. Changed the LST_SW_CCITTxx to LST_SW_ITUxx and
                           LST_SW_ANSIxx to LST_SW_ANSxx
             ---  aa    3. Initialize the curSuDlgId in the SAP structure to 0
                           on receiving the Unidirrectional message or ST_BEGIN
                           or ST_QRY_PRM or ST_QRY_NO_PRM

1.13         ---  aa    1. Changes due to serror.
             ---  aa    2. Functions which were called from a PUBLIC function
                           matrix are called directly now.
             ---  aa    3. Added the new functions to check the state of TSL
                           for the Data Request event.
             ---  aa    4. miscellaneous cahnges.

*********************************************************************81*/


/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.14         ---      aa   1. Fixed the bug in Function StUiStuDatReq (STLOGERROR
                             may reference a NULL pointer)
             ---     aa   2. Changed the function StUiStuBndReq as the Bnd Request
                             to SCCP (StLiSptBndReq) doest not require the nii
                             parameter.
             ---     aa   3. Fixed the bug in function StUiStuCmpReq (SQueueLast was
                             called twice in case ANS88 and ANS92 REJECT)

             ---     nj   4. added a function to find originating Transaction Id
                             in StLiSptStaInd and replaced the old function
                             stFindTrans with stFindOrgTrans.

             ---     nj   5. Added aDpc parameter in SteInd primitive at the
                             Lower (Spt) Interface.

             ---     nj   6. Allow the user to specify another source SCCP
                             address in the first backward continue message.

1.15         ---      nj   1. Rewrote this file. This file now contains the
                              ITU TCAP protocol state machine, previously
                              contained in st_bdy1.c.

1.16         ---      nj   1. Fixed the order of srcAddr and dstAddr in
                              StUiStuDatInd function call.
             ---      nj   2. Fixed the code to support the user abort
                              information to be included in a itu88 u-abort
                              message.
 
             ---      nj   3. Fixed number of stTHRxIncMsg function parameters
                              for non-ANSI C code.
 
                           4. Added a check for the operation classes in the
                              CmpReq primitive.

             ---      nj   5. Added Support for PSF.
             ---      nj   6. Added Support for ITU-96.

1.17         ---      nj   1. Corrected uDatEv.esc to indicate end of
                              sequence when a dialogue terminates.

1.18         ---      nj   1. Corrected the code in function stDHRxUAbt when checking
                              the validity of the received ABT apdu in the dialogue portion.

1.19         ---      nj   1. Pass pointer to dialogue event structure instead of passing
                              a NULL pointer in P-Abort DatInd.

1.20         ---      nj   1. Fixed a bug (STFREEUSERBUF called with NULLP) in
                              stDHRxUAbt function.

1.21         ---      nj   1. Changed code to return the same number of octets
                              in destination transaction id as received.

1.22         ---      nj   1. fixed the function declaration.

1.23         ---      nj   1. Fixed the status value in reject indication to the user
                              to a new status value, so that the user can distinguish
                              when a rejct component is queued in TCAP

1.24         ---      nj   1. Modified the code to pass opc to the TCAP-User in
                              StuDatInd, StuCmpInd and StuUDatInd primitives.

/main/17     ---      nj   1. Changed for distributed FT/HA
                           2. Modified the ZT_DFTHA flag to ZT, surrounding
                              stAllocDlg function. Now, the alternate stAllocDlg
                              funtion shall be used for both DFTHA and FTHA.
1.24+        st002.301 as  1. Originating Address should not be changed in case
                              of first backward Continue message, i.e. if the 
                              TSM is S_TSM_IS. Code is modified to comply with 
                              this requirement. Function stChkTsmStAddr is
                              accordingly modified.
                              
3.1+         st005.301 zr  1. File mrs.x included under ZT flag

3.1+         st007.301 zr  1. Changes for TC-User Distribution Feature
                              - Upper to lower SAP association is done
                                with a special routine
                              - New routines added
                                  - stTHGenPAbtTcUserDist
                                  - stTHRxMsgTcUserDist
                                  - stTHRxIncMsgTcUserDist

3.1+         st008.301 zr  1. Before sending Component Indication check is 
                              made to make sure that the dialogue control 
                              point is not deleted due to Abort message from 
                              TC-User.

3.1+         st009.301 zr   1. Add more debug prints throughout the entire 
                               file.

3.1+         st014.301 zr   1. Handle Support for STU and SPT interface changes 
                               - Support for conveying imp and isni are
                                 provided in transaction handler and in 
                                 dialogue handler routines

3.1+         st016.301 zr   1. In stCHPutComps routine, before setting the 
                               problem code it is verified that the component
                               is decoded properly. 

3.1+         st017.301 zr   1. In stCHPutComps routine, before deallocating
                               mBuf, check is added to make sure that it has
                               not already been deallocated.
                            2. In stDHRxUni and stDHRxEnd routines, before
                               deallocating the dialogue, check is made to make
                               sure that it has not already been deallocated
                               by some dialogue terminating message from
                               TC-User.
                            3. In stTHRxMsg routine, terminating message
                               flag of the dialogue control point is set
                               for End message.
                            4. In stTHTxUAbt routine, if dialogue terminating 
                               message has already come from peer, then stop 
                               sending the abort message to SCCP

3.1+        st019.301 jz    1. In stIsmActCmp(), free the invoke control
                               block at the end of the function.

3.1+        st023.301 jz    1. Generate a local reject to the user if decoding
                               of reject component failed.

3.1+        st024.301 jz    1. Added code to differentiate ANSI and ITU PAbrt

3.1+        st025.301 jz    1. Fixed debug print error.

3.1+        st026.301 ssk   1. Added a check before freeing invCp in rejTx.
3.1+        st027.301 ds    1. Replace SPutMsg call with STFREEUSERBUF call to avoid
                               mem corruption on double deallocation.
3.1+        st029.301 yk    1. Add suDlgId and spDlgId parameters in StUiStuUDatInd.
                            2. Remove STFREEUSERBUF for Component buffer in case of RFAIL
     		                 This will result into double deallocation of buffer as
                               buffer is freed outside the function also when it 
                               returns RFAIL.

3.1+        st031.301 yk    1. Initialization of uDatEv is done in various functions.
3.1+       st034.301   yk   1. Code Added for SS_MULTIPLE_PROCS
3.1+       st038.301   mkm 1. Modify Test case Ids to remove error of duplicate case.
                           2. Initilaisation of variables used uninitialised.
                           3. Putting stDecAnsiMsgHdr under ANSI flags.
                           4. Replace SFndProcId with STACC_PROC_ID0 for SS_MULTIPLE_PROCS Flag.
3.1+       st043.301  mkm   1. Changes for addition of suDlgId parameter in stAllocDlg.
*********************************************************************91*/
