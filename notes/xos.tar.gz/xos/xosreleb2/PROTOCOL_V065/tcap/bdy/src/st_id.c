/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     tcap
  
     Type:     C source file
  
     Desc:     product id file 
  
     File:     st_id.c
  
     Sid:      st_id.c@@/main/13 - Fri Nov 17 10:34:08 2000
  
     Prg:      na
  
*********************************************************************21*/


/* header include files (.h) */
  
#include "envopt.h"           /* environment options */
#include "envdep.h"           /* environment dependent */
#include "envind.h"           /* environment independent */
  
#include "gen.h"              /* general layer */
#include "ssi.h"              /* system services */
#include "lst.h"              /* layer management */
  
/* header/extern include files (.x) */
  
#include "gen.x"              /* general layer */
#include "ssi.x"              /* system services */

/* defines */
  
#define STSWMV 3              /* tcap - main version */
#define STSWMR 1              /* tcap - main revision */
#define STSWBV 0              /* tcap - branch version */
#define STSWBR 44             /* TCAP - For patch st044.301 */
#define STSWPN "1000031"      /* tcap - part number */
  
/* forward references */

#ifdef __cplusplus
EXTERN "C" {
#endif

PUBLIC S16 stGetSId ARGS((SystemId *s));

#ifdef __cplusplus
}
#endif

/* public variable declarations */
  
/* copyright banner */
  
PRIVATE CONSTANT Txt ban1[] ={"(c) COPYRIGHT 1989-2000, Trillium Digital Systems, Inc."};
PRIVATE CONSTANT Txt ban2[] ={"                 All rights reserved."};
  
/* system id */
  
PRIVATE CONSTANT SystemId sId ={
   STSWMV,                    /* main version */
   STSWMR,                    /* main revision */
   STSWBV,                    /* branch version */
   STSWBR,                    /* branch revision */
   STSWPN,                    /* part number */
};
  
/*
*     support functions
*/

  
/*
*
*       Fun:   get system id
*
*       Desc:  Get system id consisting of part number, main version and
*              revision and branch version and branch.
*
*       Ret:   TRUE      - ok
*
*       Notes: None
*
*       File:  st_id.c
*
*/
#ifdef ANSI
PUBLIC S16 stGetSId
(
SystemId *s                 /* system id */
)
#else
PUBLIC S16 stGetSId(s)
SystemId *s;                /* system id */
#endif
{
   TRC2(stGetSId)

   s->mVer  = sId.mVer;
   s->mRev  = sId.mRev;
   s->bVer  = sId.bVer;
   s->bRev  = sId.bRev;
   s->ptNmb = sId.ptNmb;

   RETVALUE(TRUE);
} /* stGetSid */
  

/********************************************************************30**

         End of file:     st_id.c@@/main/13 - Fri Nov 17 10:34:08 2000

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  mma   1. initial release

1.2          ---  mma   1. initial release

1.3          ---   ak   1. replaced ss_ms.[hx] and ss_pt.[hx] with ssi.[hx]
             ---   mc   2. change version
             ---   mc   3. change ban1 and ban2 to PUBLIC.
             ---   mc   4. rename ban1 and ban2 to stBan1 and stBan2.

1.4          ---   ak   1. change version

1.5          ---   ak   1. miscellaneous changes

1.6          ---   ak   1. change version

1.7          ---   aa   1. change version

1.8          ---   aa   1. change version

1.9          ---   aa   1. change version


*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.10         ---      aa   1. change version
             ---      aa   2. Removed lst.x

1.11         ---      nj   1. Changed version

1.12         ---      nj   1. Changed version to 2.8
/main/13     ---      as   1. Changed version to 3.1 for DFT/HA support

3.1+       st001.301  as   1. Branch revision 1 for st001.301
3.1+       st002.301 zr,as 1. Branch revision 2 for st002.301 
3.1+       st003.301  zr   1. Branch revision 3 for st003.301
3.1+       st004.301  zr   1. Branch revision 4 for st004.301
3.1+       st005.301  zr   1. Branch revision 5 for st005.301
3.1+       st007.301  zr   1. Branch revision 7 for st007.301
3.1+       st008.301  zr   1. Branch revision 8 for st008.301
3.1+       st009.301  zr   1. Branch revision 9 for st009.301
3.1+       st010.301  akp  1. Branch revision 10 for st010.301
3.1+       st011.301  akp  1. Branch revision 11 for st011.301
3.1+       st012.301  zr   1. Branch revision 12 for st012.301
3.1+       st013.301  akp  1. Branch revision 13 for st013.301
3.1+       st014.301  zr   1. Branch revision 14 for st014.301
3.1+       st015.301  zr   1. Branch revision 15 for st015.301
3.1+       st016.301  zr   1. Branch revision 16 for st016.301
3.1+       st017.301  zr   1. Branch revision 16 for st017.301
3.1+       st018.301  as   1. Branch revision 18 for st018.301
3.1+       st019.301  jz   1. Branch revision 18 for st019.301
3.1+       st020.301  jz   1. Branch revision 18 for st020.301
3.1+       st021.301  jz   1. Branch revision 21 for st021.301
3.1+       st022.301  jz   1. Branch revision 22 for st022.301
3.1+       st023.301  jz   1. Branch revision 23 for st023.301
3.1+       st024.301  jz   1. Branch revision 24 for st024.301
3.1+       st025.301  jz   1. Branch revision 24 for st025.301
3.1+       st026.301  ds   1. Branch revision 24 for st026.301
3.1+       st027.301  ds   1. Branch revision 27 for st027.301
3.1+       st028.301  ds   1. Branch revision 28 for st028.301
3.1+       st029.301  yk   1. Branch revision 29 for st029.301
3.1+       st030.301  yk   1. Branch revision 30 for st030.301
3.1+       st031.301  yk   1. Branch revision 31 for st031.301
3.1+       st032.301  yk   1. Branch revision 32 for st032.301
3.1+       st033.301  yk   1. Branch revision 33 for st033.301
3.1+       st034.301  yk   1. Branch revision 34 for st034.301
3.1+       st035.301  mkm  1. Branch revision 35 for st035.301
3.1+       st036.301  mkm  1. Branch revision 36 for st036.301
3.1+       st037.301  mkm  1. Branch revision 37 for st037.301
3.1+       st038.301  mkm  1. Branch revision 38 for st038.301
3.1+       st039.301  mkm  1. Branch revision 39 for st039.301
3.1+       st040.301  mkm  1. Branch revision 40 for st040.301
3.1+       st041.301  mkm  1. Branch revision 41 for st041.301
3.1+       st042.301  mkm  1. Branch revision 42 for st042.301
3.1+       st043.301  mkm  1. Branch revision 43 for st043.301
3.1+       st044.301  mkm  1. Branch revision 44 for st044.301
*********************************************************************91*/
