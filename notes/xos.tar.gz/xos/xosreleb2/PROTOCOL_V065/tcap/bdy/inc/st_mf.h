/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     SS7 TCAP
  
     Type:     C include file
  
     Desc:     Defines required by SS7 TCAP for Message Handling.
 
     File:     st_mf.h

     Sid:      st_mf.h@@/main/2 - Fri Nov 17 10:34:10 2000

     Prg:      nj

*********************************************************************21*/

#ifndef __STMFH__
#define __STMFH__

/* Message Types */
#define ST_MSG_TYP_UNI          1    /* Message Type Unidirectional */
#define ST_MSG_TYP_BGN          2    /* Message Type Begin */
#define ST_MSG_TYP_CNT          3    /* Message Type Continue */
#define ST_MSG_TYP_END          4    /* Message Type End */
#define ST_MSG_TYP_UABT         5    /* Message Type User Abort */
#define ST_MSG_TYP_PABT         6    /* Message Type Provider Abort */


#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)

/* ANSI Package Types */
#define ST_PKG_TYP_UNI          1    /* Package Type Unidirectional */
#define ST_PKG_TYP_QWP          2    /* Package Type Query w/ Permission */
#define ST_PKG_TYP_QWOP         3    /* Package Type Query w/o Permission */
#define ST_PKG_TYP_RSP          4    /* Package Type Response */
#define ST_PKG_TYP_CWP          5    /* Package Type Conversation w/ Perm */
#define ST_PKG_TYP_CWOP         6    /* Package Type Conversation w/o Perm */
#define ST_PKG_TYP_UABT         7    /* Package Type User Abort */
#define ST_PKG_TYP_PABT         8    /* Package Type Provider's Abort */

#endif

#define ST_MSG_TYP_UNK       0xFF    /* Message type Incorrect/unknown */


/* Dialogue apdu types */
#define ST_DLG_TYP_UNI          1    /* Dialogue Type Unidirectional */
#define ST_DLG_TYP_REQ          2    /* Dialogue Type Request */
#define ST_DLG_TYP_RSP          3    /* Dialogue Type Response */
#define ST_DLG_TYP_ABT          4    /* Dialogue Type Abort */


/* Component types */
#define ST_COMP_TYP_UNK         0    /* Component type Incorrect/unknown */
#define ST_COMP_TYP_INV         1    /* Component Type Invoke */
#define ST_COMP_TYP_RES         2    /* Component Type Return Result Last */
#define ST_COMP_TYP_ERR         3    /* Component Type Return Error */
#define ST_COMP_TYP_REJ         4    /* Component Type Reject */
#define ST_COMP_TYP_RNL         5    /* Component Type Return Result Not-Last */

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)

/* Ansi defines one extra component than Itu */
#define ST_COMP_TYP_INL         6    /* Component Type Invoke-Not-Last */
#endif


/* Operation Code Types */
#define ST_OP_TYP_LCL           1    /* Operation Type Local */
#define ST_OP_TYP_GBL           2    /* Operation Type Global */

/* Error Code Types */
#define ST_ERR_TYP_LCL          1    /* Error Type Local */
#define ST_ERR_TYP_GBL          2    /* Error Type Global */

/* Problem Code Types */
#define ST_PROB_TYP_GEN         1    /* General problem */
#define ST_PROB_TYP_INV         2    /* Invoke Component problem */
#define ST_PROB_TYP_RES         3    /* Return Result Component problem */
#define ST_PROB_TYP_ERR         4    /* Return Error Component problem */
#define ST_PROB_TYP_TRN         5    /* Transaction Portion Problem */

/* Parameters Basic ASN.1 Encoding type */
#define ST_PARAM_TYP_SEQ        1    /* Parameters Type SEQUENCE */
#define ST_PARAM_TYP_SET        2    /* Parameters Type SET */

/* For Reject Component Encoding */
#define ST_REJ_INV_ID           1    /* Invoke Id present */
#define ST_REJ_INV_NULL         2    /* Invoke Id not present, encode NULL */

/* Abort Source */
#define ST_ABT_SRC_SU           0    /* Abort source - User */
#define ST_ABT_SRC_SP           1    /* Abort source - Provider */

/* Result Source type */
#define ST_RES_SRC_SU           1    /* Result source - User */
#define ST_RES_SRC_SP           2    /* Result source - Provider */

/* Dialogue result values */
#define ST_DLG_RES_ACC          0    /* Result - Accepted */
#define ST_DLG_RES_REJ          1    /* Result - Reject Permanent */

/* Dialogue result diagonostic value for both service user and service provider */
#define ST_DLG_DIAG_NULL        0    /* Null */
#define ST_DLG_DIAG_NORES       1    /* No reason given */
#define ST_DLG_DIAG_NOACN       2    /* Application context name not supplied */
#define ST_DLG_DIAG_NOCDP       2    /* No common dialogue portion */

#if (SS7_ETSI)
/* Integer Value Range for ETSI */
#define ST_ETS_LO_INT_VAL       0
#define ST_ETS_HI_INT_VAL     127
#endif

/* Message portion types */
#define ST_TYP_TRN_PRTN         1    /* Transaction portion */
#define ST_TYP_DLG_PRTN         2    /* Dialogue portion */
#define ST_TYP_CMP_PRTN         3    /* Component portion */

/* ITU P-Abort Causes */
#define ST_PABT_UR_MSGT         0    /* Unrecognized message type */
#define ST_PABT_UR_TRID         1    /* Unrecognized Transaction id */
#define ST_PABT_BD_TRNP         2    /* Badly formatted Transaction Portion */
#define ST_PABT_IN_TRNP         3    /* Incorrect Transaction Portion */
#define ST_PABT_LM_RSRC         4    /* Resource Limitation */

#define ST_PABT_BD_DLGP         5    /* Bad Dialogue portion */
#define ST_PABT_NC_DLGP         6    /* No Common  Dialogue portion */


/* ITU General Problem Codes */
#define ST_GEN_UR_COMP          0    /* Unrecognized component */
#define ST_GEN_MT_COMP          1    /* Mistyped component */
#define ST_GEN_BD_COMP          2    /* Badly structured component */


/* ITU Invoke Problem Codes */
#define ST_INV_DP_IVID          0    /* Duplicate Invoke Id */
#define ST_INV_UR_OPRC          1    /* Unrecognized Operation code */
#define ST_INV_MT_PARM          2    /* Mistyped parameter */
#define ST_INV_LM_RSRC          3    /* Resource limitation */
#define ST_INV_IT_RLSE          4    /* Initiating Release */
#define ST_INV_UR_LKID          5    /* Unrecognized linked Id */
#define ST_INV_UX_LRSP          6    /* Linked response unexpected */
#define ST_INV_UX_LOPR          7    /* Unexpected linked operation */


/* ITU Return Result Problem Codes */
#define ST_RES_UR_IVID          0    /* Unrecognized Invoke Id */
#define ST_RES_UX_RRES          1    /* Return result unexpected */
#define ST_RES_MT_PARM          2    /* Return result mistyped parameter */


/* ITU Return Error problems */
#define ST_ERR_UR_IVID          0    /* Unerecognized Invoke Id */
#define ST_ERR_UX_RERR          1    /* Unexpected return error */
#define ST_ERR_UR_ERRC          2    /* Unrecgnized error */
#define ST_ERR_UX_ERRC          3    /* Unexpected error */
#define ST_ERR_MT_PARM          4    /* Mistyped parameter */ 


#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)

/* Operation Code Types */
#define ST_OP_TYP_NTL           1    /* Operation Type National */
#define ST_OP_TYP_PVT           2    /* Operation Type Private */

/* Error Code Types */
#define ST_ERR_TYP_NTL          1    /* Error Type National */
#define ST_ERR_TYP_PVT          2    /* Error Type Private */

/* ANSI P-Abort Cause */
#define ST_ANS_PABT_UR_PKGT     1    /* Unrecognized Package type */
#define ST_ANS_PABT_IN_TRNP     2    /* Incorrect Transaction Portion */
#define ST_ANS_PABT_BD_TRNP     3    /* Badly formatted Transaction Portion */
#define ST_ANS_PABT_UA_RTID     4    /* Unassigned Responding Transaction id */
#define ST_ANS_PABT_PB_PRLS     5    /* Permission to release problem */
#define ST_ANS_PABT_UL_RSRC     6    /* Resource Unavailable */


/* ANSI General Problem Codes */
#define ST_ANS_GEN_UR_COMP      1    /* Unrecognized component type */
#define ST_ANS_GEN_IN_COMP      2    /* Incorrect component portion */
#define ST_ANS_GEN_BD_COMP      3    /* Badly structured component portion */
#define ST_ANS_GEN_IN_CENC      4    /* Incorrect component coding */


/* ANSI Invoke Problem Codes */
#define ST_ANS_INV_DP_IVID      1     /* Duplicate Invoke Id */
#define ST_ANS_INV_UR_OPRC      2     /* Unrecognized Operation code */
#define ST_ANS_INV_IN_PARM      3     /* Incorrect parameter */
#define ST_ANS_INV_UR_CRID      4     /* Unrecognized correlation id */
/* st023.301 - Addition, added BellCore problem code */
#define ST_BELL_INV_MM_PARM     5     /* Missing Mandatory parameter */


/* ANSI Return Result Problem Codes */
#define ST_ANS_RES_UA_CRID      1     /* Unassigned Correlation Id */
#define ST_ANS_RES_UX_RRES      2     /* Return result unexpected */
#define ST_ANS_RES_IN_PARM      3     /* Incorrect parameter */
/* st023.301 - Addition, added BellCore problem code */
#define ST_BELL_RES_MM_PARM     4     /* Missing Mandatory parameter */


/* ANSI Return Error problems */
#define ST_ANS_ERR_UA_CRID      1     /* Unassigned Correlation Id */
#define ST_ANS_ERR_UX_RERR      2     /* Unexpected return error */
#define ST_ANS_ERR_UR_ERRC      3     /* Unrecgnized error */
#define ST_ANS_ERR_UX_ERRC      4     /* Unexpected error */
#define ST_ANS_ERR_IN_PARM      5     /* Incorrect parameter */
/* st023.301 - Addition, added BellCore problem code */
#define ST_BELL_ERR_MM_PARM     6     /* Missing Mandatory parameter */

#endif

#define ST_PCODE_INVALID     0xFF     /* Invalid fault code */

#endif  /* _STMFH_ */

/********************************************************************30**

         End of file:     st_mf.h@@/main/2 - Fri Nov 17 10:34:10 2000

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      nj   1. initial release.
/main/2      ---      nj   1. Changes for distributed FTHA
  
3.1+       st023.301  jz   1. Added hash define for Bellcore problem code.

*********************************************************************91*/
