/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     TCAP Message encoder/decoder
  
     Type:     C include file
  
     Desc:     defines required for encoding/decoding routines
  
     File:     st_db.h
  
     Sid:      st_db.h@@/main/3 - Fri Nov 17 10:34:00 2000
  
     Prg:      nj
  
*********************************************************************21*/

#ifndef __STDBH__
#define __STDBH__

/* Macros to fill the tag value in ASN.1 structure */

#define TAG(tag)  {1, {tag, 0x0, 0x0, 0x0}}
#define TAG_NULL  {0, {0x0, 0x0, 0x0, 0x0}}


/* ITU Transaction Portion */

/* ITU Message Tags */
#define ST_ITU_MSG_UNI_TAG    0x61     /* Unidirectional */
#define ST_ITU_MSG_BGN_TAG    0x62     /* Begin */
#define ST_ITU_MSG_END_TAG    0x64     /* End */
#define ST_ITU_MSG_CNT_TAG    0x65     /* Continue */
#define ST_ITU_MSG_ABT_TAG    0x67     /* Abort */

#define ST_ITU_ORG_TID_TAG    0x48     /* Originator Transaction Id */
#define ST_ITU_DST_TID_TAG    0x49     /* Destination Transaction Id */
#define ST_ITU_PABT_TAG       0x4A     /* P-Abort Cause Tag */


/* ITU Dialogue Portion */

/* Dialogue APDU Types */
#define ST_ITU_DLG_UNI_TAG    0x60     /* Unidirectional Dialogue */
#define ST_ITU_DLG_REQ_TAG    0x60     /* Request Dialogue */
#define ST_ITU_DLG_RSP_TAG    0x61     /* Response Dialogue */
#define ST_ITU_DLG_ABT_TAG    0x64     /* Abort Dialogue */

#define ST_ITU_DLG_PRTN_TAG   0x6B     /* dialogue portion tag */
#define ST_ITU_EXTERNAL_TAG   0x28     /* external tag */
#define ST_ITU_SNGL_ASN1_TAG  0xA0     /* single ASN.1 type tag */
#define ST_ITU_OBJID_TAG      0x06     /* object identifier tag */
#define ST_ITU_PROT_VER_TAG   0x80     /* protocol version tag */
#define ST_ITU_ACN_TAG        0xA1     /* application context name tag */
#define ST_ITU_USRINFO_TAG    0xBE     /* user information tag */
#define ST_ITU_ABT_SRC_TAG    0x80     /* abort source tag */
#define ST_ITU_RESULT_TAG     0xA2     /* result tag */
#define ST_ITU_RES_DIAG_TAG   0xA3     /* result source diagnostic tag */
#define ST_ITU_INTEGER_TAG    0x02     /* integer tag */
#define ST_ITU_DLG_SP_TAG     0xA2     /* Dialogue Service Provider */
#define ST_ITU_DLG_SU_TAG     0xA1     /* Dialogue Service User */

#define ST_DLG_ID_VAL_B0      0x00
#define ST_DLG_ID_VAL_B1      0x11
#define ST_DLG_ID_VAL_B2      0x86
#define ST_DLG_ID_VAL_B3      0x05
#define ST_DLG_ID_VAL_B4      0x01
#define ST_DLG_ID_VAL_B5_U    0x02
#define ST_DLG_ID_VAL_B5_S    0x01
#define ST_DLG_ID_VAL_B6      0x01

#define ST_ITU_PVER_B0        0x07
#define ST_ITU_PVER_B1        0x80


/* ITU Component Portion */

/* Component Types */
#define ST_ITU_COMP_INV_TAG       0xA1     /* Invoke Component */
#define ST_ITU_COMP_RES_TAG       0xA2     /* Return Result Last Component */
#define ST_ITU_COMP_ERR_TAG       0xA3     /* Return Error Component */
#define ST_ITU_COMP_REJ_TAG       0xA4     /* Reject Component */
#define ST_ITU_COMP_RNL_TAG       0xA7     /* Return Result Not-Last Component */

#define ST_ITU_COMP_PRTN_TAG      0x6C     /* Component Portion Tag */
#define ST_ITU_INV_ID_TAG         0x02     /* Invoke Id */
#define ST_ITU_LNKD_ID_TAG        0x80     /* Invoke Id */
#define ST_ITU_LCL_OPCODE_TAG     0x02     /* Local Operation Code */
#define ST_ITU_GBL_OPCODE_TAG     0x06     /* Global Operation Code */
#define ST_ITU_LCL_ERRCODE_TAG    0x02     /* Local Error Code */
#define ST_ITU_GBL_ERRCODE_TAG    0x06     /* Global Error Code */

#define ST_ITU_GEN_PRBCODE_TAG    0x80     /* General Problem Code */
#define ST_ITU_INV_PRBCODE_TAG    0x81     /* Invoke Problem Code */
#define ST_ITU_RES_PRBCODE_TAG    0x82     /* Return Result Problem Code */
#define ST_ITU_ERR_PRBCODE_TAG    0x83     /* Return Error Problem Code */

#define ST_ITU_SEQ_TAG            0x30     /* Sequence */
#define ST_ITU_SET_TAG            0x31     /* Set */


#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)

/* ANSI Specific defines */

/* ANSI Transaction Portion */

/* ANSI Package Types */
#define ST_ANS_MSG_UNI_TAG   0xE1       /* Uni-directional message */
#define ST_ANS_MSG_QWP_TAG   0xE2       /* Query with Permission */
#define ST_ANS_MSG_QWOP_TAG  0xE3       /* Query without Permission */
#define ST_ANS_MSG_RSP_TAG   0xE4       /* Response */
#define ST_ANS_MSG_CWP_TAG   0xE5       /* Conversation with Permission */
#define ST_ANS_MSG_CWOP_TAG  0xE6       /* Conversation without Permission */
#define ST_ANS_MSG_ABT_TAG   0xF6       /* Abort */

#define ST_ANS_TID_TAG       0xC7       /* Ansi Transaction ID */
#define ST_ANS_PABT_TAG      0xD7       /* Ansi P-Abort Cause Tag */
#define ST_ANS_UABT_TAG      0xD8       /* Ansi U-Abort Information Tag */
#define ST_ANS_COMP_SEQ_TAG  0xE8       /* Ansi Component Sequence */


/* ANSI-96 Dialogue Portion */

#define ST_ANS_DLG_PRTN_TAG  0xF9       /* Ansi Dialogue Portion */
#define ST_ANS_DLG_PVER_TAG  0xDA       /* Ansi Protocol Version */
#define ST_ANS_INT_ACN_TAG   0xDB       /* Ansi Integer Application Context */
#define ST_ANS_OBJ_ACN_TAG   0xDC       /* Ansi Object Identifier Application Context */
#define ST_ANS_USRINFO_TAG   0xFD       /* Ansi User Information */
#define ST_ANS_EXTERNAL_TAG  0x28       /* Ansi External */
#define ST_ANS_DRCT_REF_TAG  0x06       /* Ansi Direct Reference */
#define ST_ANS_IDRT_REF_TAG  0x02       /* Ansi Indirect Reference */
#define ST_ANS_DAT_DESC_TAG  0x07       /* Ansi Data Value Descriptor */
#define ST_ANS_INT_SECT_TAG  0x80       /* Ansi Integer Security Context */
#define ST_ANS_OBJ_SECT_TAG  0x81       /* Ansi Object Identifier Security Context */
#define ST_ANS_DLG_CONF_TAG  0xA2       /* Ansi Confidentiality Identifier */
#define ST_ANS_INTEGER_TAG   0x80       /* Ansi Integer */
#define ST_ANS_OBJID_TAG     0x81       /* Ansi Object Id */

#define ST_ANS_DLG_PVER      0x01       /* Current Protocol Version */


/* ANSI Component Portion */

/* ANSI Component Types */
#define ST_ANS_COMP_IVL_TAG  0xE9       /* Ansi Invoke-Last Component */
#define ST_ANS_COMP_RRL_TAG  0xEA       /* Ansi Return Result-Last Component */
#define ST_ANS_COMP_ERR_TAG  0xEB       /* Ansi Return Error Component */
#define ST_ANS_COMP_REJ_TAG  0xEC       /* Ansi Reject Component */
#define ST_ANS_COMP_INL_TAG  0xED       /* Ansi Invoke-Not-Last Component */
#define ST_ANS_COMP_RNL_TAG  0xEE       /* Ansi Result-Not-Last Component */

#define ST_ANS_COMP_ID_TAG      0xCF       /* Ansi Component Id */
#define ST_ANS_NTL_OPCODE_TAG   0xD0       /* Ansi Operation Code - National */
#define ST_ANS_PVT_OPCODE_TAG   0xD1       /* Ansi Operation Code - Private */
#define ST_ANS_NTL_ERRCODE_TAG  0xD3       /* Ansi Error Code - National */
#define ST_ANS_PVT_ERRCODE_TAG  0xD4       /* Ansi Error Code - National */
#define ST_ANS_PRBCODE_TAG      0xD5       /* Ansi Problem Code */
#define ST_ANS_PARAM_SEQ_TAG    0x30       /* Ansi Parameter Sequence */
#define ST_ANS_PARAM_SET_TAG    0xF2       /* Ansi Parameter Set */

/* Ansi Transaction Id length */
#define ST_ANS_TID_LEN0       0        /* length 0 */
#define ST_ANS_TID_LEN4       4        /* length 4 octets */
#define ST_ANS_TID_LEN8       8        /* length 8 octets */

#endif  /* End of ANSI specific defines */


#define ST_NULL_TAG           0x05     /* Null Tag */

#define ST_EOC_TAG            0x00     /* End of Contents Tag */
#define ST_EOC_LEN            0x00     /* End of contents length */
#define ST_LEN_INDEF          0x80     /* Code for Indefinite form of length */

/* Database define types */
#define ST_DBTYPE_COMP        0        /* Components */
#define ST_DBTYPE_DLG         1        /* Dialogue Portion */

/* st015.301 - Invalid message and element tag */
#define ST_INV_MSG_TAG  0xFF           /* Invalid message tag */ 
#define ST_INV_ELM_TAG  0xFF           /* Invalid element tag */

/* Maximum length of the Transaction Portion */
#define ST_MAX_TRNS_PRTN_LEN  20

#define ST_MAX_LEN_BYTES       4       /* Maximum length field length */


/* Macro Definitions */

/* Convert a  string starting at index 'idx' of length 'len' to U32 */
#define ST_STR_TO_U32(_s, _len, _val)                      \
{                                                          \
   U8       _idx;                                          \
   Data    *_str;                                          \
                                                           \
   *_val = 0;                                              \
   _str  = _s;                                             \
                                                           \
   for (_idx = 0; _idx < _len; _idx++)                     \
   {                                                       \
       *_val <<= 8;                                        \
       *_val |= ((U32)_str[_idx] & 0xff);                  \
   }                                                       \
}

#endif  /* __STDBH__ */

  
/********************************************************************30**
  
         End of file:     st_db.h@@/main/3 - Fri Nov 17 10:34:00 2000
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      nj   1. initial release.
1.2          ---      nj   1. Corrected the invoke id tag value  
1.3          ---      nj   1. Corrected the Ansi Parameter set/sequence tag value
/main/3      ---      nj   1. Changes for distributed FTHA
3.1+        st015.301 zr   1. define ST_INV_MSG_TAG, ST_INV_ELM_TAG
*********************************************************************91*/
