/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     Tcap - error
  
     Type:     C include file
  
     Desc:     Error defines required by SS7 TCAP
  
     File:     st_err.h
  
     Sid:      st_err.h@@/main/10 - Fri Nov 17 10:34:05 2000
  
     Prg:      nj
  
*********************************************************************21*/
  
#ifndef __STERRH__
#define __STERRH__
  
  
/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     10000031    SS7 - TCAP
*
*/

/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     10000030    SS7 - SCCP
*
*/
 
  
/* defines */

/* macro for SLOG ERROR */

#define STLOGERROR(errCls, errCode, errVal, errDesc)                \
    SLogError(stCb.init.ent, stCb.init.inst, stCb.init.procId,      \
              __FILE__, __LINE__, errCls, errCode, errVal, errDesc) 

#define   ESTBASE     000    
#define   ESTXXX      (ESTBASE)      /* reserved */

#define   EST001      (ERRST +    1)    /*    l3_bdy1.c: 229 */
#define   EST002      (ERRST +    2)    /*    l3_bdy1.c: 230 */
#define   EST003      (ERRST +    3)    /*    l3_bdy1.c: 231 */
#define   EST004      (ERRST +    4)    /*    l3_bdy1.c: 284 */
#define   EST005      (ERRST +    5)    /*    l3_bdy1.c: 285 */
#define   EST006      (ERRST +    6)    /*    l3_bdy1.c: 366 */
#define   EST007      (ERRST +    7)    /*    l3_bdy1.c: 367 */
#define   EST008      (ERRST +    8)    /*    l3_bdy1.c: 426 */
#define   EST009      (ERRST +    9)    /*    l3_bdy1.c: 427 */
#define   EST010      (ERRST +   10)    /*    l3_bdy1.c: 428 */
#define   EST011      (ERRST +   11)    /*    l3_bdy1.c: 487 */
#define   EST012      (ERRST +   12)    /*    l3_bdy1.c: 488 */
#define   EST013      (ERRST +   13)    /*    l3_bdy1.c: 489 */
#define   EST014      (ERRST +   14)    /*    l3_bdy1.c: 550 */
#define   EST015      (ERRST +   15)    /*    l3_bdy1.c: 551 */
#define   EST016      (ERRST +   16)    /*    l3_bdy1.c: 552 */
#define   EST017      (ERRST +   17)    /*    l3_bdy1.c: 553 */
#define   EST018      (ERRST +   18)    /*    l3_bdy1.c: 617 */
#define   EST019      (ERRST +   19)    /*    l3_bdy1.c: 618 */
#define   EST020      (ERRST +   20)    /*    l3_bdy1.c: 619 */
#define   EST021      (ERRST +   21)    /*    l3_bdy1.c: 620 */
#define   EST022      (ERRST +   22)    /*    l3_bdy1.c: 621 */

#define   EST023      (ERRST +   23)    /*   l3_ex_ms.c: 220 */

#define   EST024      (ERRST +   24)    /*    l3_ptui.c: 855 */
#define   EST025      (ERRST +   25)    /*    l3_ptui.c: 906 */
#define   EST026      (ERRST +   26)    /*    l3_ptui.c: 951 */
#define   EST027      (ERRST +   27)    /*    l3_ptui.c: 996 */
#define   EST028      (ERRST +   28)    /*    l3_ptui.c:1047 */
#define   EST029      (ERRST +   29)    /*    l3_ptui.c:1092 */
#define   EST030      (ERRST +   30)    /*    l3_ptui.c:1134 */
#define   EST031      (ERRST +   31)    /*    l3_ptui.c:1174 */
#define   EST032      (ERRST +   32)    /*    l3_ptui.c:1227 */

#define   EST033      (ERRST +   33)    /*    st_acc1.c: 634 */
#define   EST034      (ERRST +   34)    /*    st_acc1.c: 641 */
#define   EST035      (ERRST +   35)    /*    st_acc1.c: 648 */
#define   EST036      (ERRST +   36)    /*    st_acc1.c: 655 */
#define   EST037      (ERRST +   37)    /*    st_acc1.c: 662 */
#define   EST038      (ERRST +   38)    /*    st_acc1.c: 669 */
#define   EST039      (ERRST +   39)    /*    st_acc1.c: 676 */
#define   EST040      (ERRST +   40)    /*    st_acc1.c: 683 */
#define   EST041      (ERRST +   41)    /*    st_acc1.c: 691 */
#define   EST042      (ERRST +   42)    /*    st_acc1.c: 700 */
#define   EST043      (ERRST +   43)    /*    st_acc1.c:2103 */
#define   EST044      (ERRST +   44)    /*    st_acc1.c:2357 */
#define   EST045      (ERRST +   45)    /*    st_acc1.c:2359 */
#define   EST046      (ERRST +   46)    /*    st_acc1.c:2370 */
#define   EST047      (ERRST +   47)    /*    st_acc1.c:2372 */
#define   EST048      (ERRST +   48)    /*    st_acc1.c:2378 */
#define   EST049      (ERRST +   49)    /*    st_acc1.c:2380 */
#define   EST050      (ERRST +   50)    /*    st_acc1.c:2383 */
#define   EST051      (ERRST +   51)    /*    st_acc1.c:2388 */
#define   EST052      (ERRST +   52)    /*    st_acc1.c:2390 */
#define   EST053      (ERRST +   53)    /*    st_acc1.c:2396 */
#define   EST054      (ERRST +   54)    /*    st_acc1.c:2398 */
#define   EST055      (ERRST +   55)    /*    st_acc1.c:2400 */
#define   EST056      (ERRST +   56)    /*    st_acc1.c:2402 */
#define   EST057      (ERRST +   57)    /*    st_acc1.c:2404 */
#define   EST058      (ERRST +   58)    /*    st_acc1.c:2406 */
#define   EST059      (ERRST +   59)    /*    st_acc1.c:2412 */
#define   EST060      (ERRST +   60)    /*    st_acc1.c:2414 */
#define   EST061      (ERRST +   61)    /*    st_acc1.c:2417 */
#define   EST062      (ERRST +   62)    /*    st_acc1.c:2419 */
#define   EST063      (ERRST +   63)    /*    st_acc1.c:2422 */
#define   EST064      (ERRST +   64)    /*    st_acc1.c:2425 */
#define   EST065      (ERRST +   65)    /*    st_acc1.c:2428 */
#define   EST066      (ERRST +   66)    /*    st_acc1.c:2431 */
#define   EST067      (ERRST +   67)    /*    st_acc1.c:2434 */
#define   EST068      (ERRST +   68)    /*    st_acc1.c:2438 */
#define   EST069      (ERRST +   69)    /*    st_acc1.c:2449 */
#define   EST070      (ERRST +   70)    /*    st_acc1.c:2451 */
#define   EST071      (ERRST +   71)    /*    st_acc1.c:2483 */
#define   EST072      (ERRST +   72)    /*    st_acc1.c:2494 */
#define   EST073      (ERRST +   73)    /*    st_acc1.c:2496 */
#define   EST074      (ERRST +   74)    /*    st_acc1.c:2500 */
#define   EST075      (ERRST +   75)    /*    st_acc1.c:2553 */
#define   EST076      (ERRST +   76)    /*    st_acc1.c:2555 */
#define   EST077      (ERRST +   77)    /*    st_acc1.c:2566 */
#define   EST078      (ERRST +   78)    /*    st_acc1.c:2568 */
#define   EST079      (ERRST +   79)    /*    st_acc1.c:2574 */
#define   EST080      (ERRST +   80)    /*    st_acc1.c:2578 */
#define   EST081      (ERRST +   81)    /*    st_acc1.c:2580 */
#define   EST082      (ERRST +   82)    /*    st_acc1.c:2586 */
#define   EST083      (ERRST +   83)    /*    st_acc1.c:2591 */
#define   EST084      (ERRST +   84)    /*    st_acc1.c:2593 */
#define   EST085      (ERRST +   85)    /*    st_acc1.c:2597 */
#define   EST086      (ERRST +   86)    /*    st_acc1.c:2608 */
#define   EST087      (ERRST +   87)    /*    st_acc1.c:2610 */
#define   EST088      (ERRST +   88)    /*    st_acc1.c:2614 */

#define   EST089      (ERRST +   89)    /*    st_acc2.c:12136 */
#define   EST090      (ERRST +   90)    /*    st_acc2.c:12164 */
#define   EST091      (ERRST +   91)    /*    st_acc2.c:12192 */
#define   EST092      (ERRST +   92)    /*    st_acc2.c:12313 */
#define   EST093      (ERRST +   93)    /*    st_acc2.c:12341 */
#define   EST094      (ERRST +   94)    /*    st_acc2.c:12468 */
#define   EST095      (ERRST +   95)    /*    st_acc2.c:12597 */
#define   EST096      (ERRST +   96)    /*    st_acc2.c:12615 */
#define   EST097      (ERRST +   97)    /*    st_acc2.c:12619 */
#define   EST098      (ERRST +   98)    /*    st_acc2.c:12622 */
#define   EST099      (ERRST +   99)    /*    st_acc2.c:12644 */
#define   EST100      (ERRST +  100)    /*    st_acc2.c:12777 */
#define   EST101      (ERRST +  101)    /*    st_acc2.c:12795 */
#define   EST102      (ERRST +  102)    /*    st_acc2.c:12799 */
#define   EST103      (ERRST +  103)    /*    st_acc2.c:12802 */
#define   EST104      (ERRST +  104)    /*    st_acc2.c:12824 */
#define   EST105      (ERRST +  105)    /*    st_acc2.c:12850 */
#define   EST106      (ERRST +  106)    /*    st_acc2.c:12878 */
#define   EST107      (ERRST +  107)    /*    st_acc2.c:12885 */
#define   EST108      (ERRST +  108)    /*    st_acc2.c:12887 */
#define   EST109      (ERRST +  109)    /*    st_acc2.c:12889 */
#define   EST110      (ERRST +  110)    /*    st_acc2.c:12891 */
#define   EST111      (ERRST +  111)    /*    st_acc2.c:12993 */
#define   EST112      (ERRST +  112)    /*    st_acc2.c:13198 */
#define   EST113      (ERRST +  113)    /*    st_acc2.c:13243 */
#define   EST114      (ERRST +  114)    /*    st_acc2.c:13265 */
#define   EST115      (ERRST +  115)    /*    st_acc2.c:13273 */
#define   EST116      (ERRST +  116)    /*    st_acc2.c:13275 */
#define   EST117      (ERRST +  117)    /*    st_acc2.c:13277 */
#define   EST118      (ERRST +  118)    /*    st_acc2.c:13280 */
#define   EST119      (ERRST +  119)    /*    st_acc2.c:13283 */
#define   EST120      (ERRST +  120)    /*    st_acc2.c:13285 */
#define   EST121      (ERRST +  121)    /*    st_acc2.c:13287 */
#define   EST122      (ERRST +  122)    /*    st_acc2.c:13451 */
#define   EST123      (ERRST +  123)    /*    st_acc2.c:13473 */
#define   EST124      (ERRST +  124)    /*    st_acc2.c:13481 */
#define   EST125      (ERRST +  125)    /*    st_acc2.c:13483 */
#define   EST126      (ERRST +  126)    /*    st_acc2.c:13485 */
#define   EST127      (ERRST +  127)    /*    st_acc2.c:13488 */
#define   EST128      (ERRST +  128)    /*    st_acc2.c:13491 */
#define   EST129      (ERRST +  129)    /*    st_acc2.c:13493 */
#define   EST130      (ERRST +  130)    /*    st_acc2.c:13495 */
#define   EST131      (ERRST +  131)    /*    st_acc2.c:13523 */
#define   EST132      (ERRST +  132)    /*    st_acc2.c:13527 */
#define   EST133      (ERRST +  133)    /*    st_acc2.c:13530 */
#define   EST134      (ERRST +  134)    /*    st_acc2.c:13542 */
#define   EST135      (ERRST +  135)    /*    st_acc2.c:13550 */
#define   EST136      (ERRST +  136)    /*    st_acc2.c:13552 */
#define   EST137      (ERRST +  137)    /*    st_acc2.c:13554 */
#define   EST138      (ERRST +  138)    /*    st_acc2.c:13556 */
#define   EST139      (ERRST +  139)    /*    st_acc2.c:13651 */
#define   EST140      (ERRST +  140)    /*    st_acc2.c:13653 */
#define   EST141      (ERRST +  141)    /*    st_acc2.c:13671 */
#define   EST142      (ERRST +  142)    /*    st_acc2.c:13673 */
#define   EST143      (ERRST +  143)    /*    st_acc2.c:13691 */
#define   EST144      (ERRST +  144)    /*    st_acc2.c:13693 */

#define   EST145      (ERRST +  145)    /*    st_bdy1.c: 433 */
#define   EST146      (ERRST +  146)    /*    st_bdy1.c: 452 */
#define   EST147      (ERRST +  147)    /*    st_bdy1.c: 466 */
#define   EST148      (ERRST +  148)    /*    st_bdy1.c: 528 */
#define   EST149      (ERRST +  149)    /*    st_bdy1.c: 614 */
#define   EST150      (ERRST +  150)    /*    st_bdy1.c: 633 */
#define   EST151      (ERRST +  151)    /*    st_bdy1.c: 647 */
#define   EST152      (ERRST +  152)    /*    st_bdy1.c: 686 */
#define   EST153      (ERRST +  153)    /*    st_bdy1.c: 786 */
#define   EST154      (ERRST +  154)    /*    st_bdy1.c: 809 */
#define   EST155      (ERRST +  155)    /*    st_bdy1.c: 827 */
#define   EST156      (ERRST +  156)    /*    st_bdy1.c: 857 */
#define   EST157      (ERRST +  157)    /*    st_bdy1.c: 893 */
#define   EST158      (ERRST +  158)    /*    st_bdy1.c:1006 */
#define   EST159      (ERRST +  159)    /*    st_bdy1.c:1262 */
#define   EST160      (ERRST +  160)    /*    st_bdy1.c:1284 */
#define   EST161      (ERRST +  161)    /*    st_bdy1.c:1302 */
#define   EST162      (ERRST +  162)    /*    st_bdy1.c:1333 */
#define   EST163      (ERRST +  163)    /*    st_bdy1.c:1384 */
#define   EST164      (ERRST +  164)    /*    st_bdy1.c:1521 */
#define   EST165      (ERRST +  165)    /*    st_bdy1.c:1543 */
#define   EST166      (ERRST +  166)    /*    st_bdy1.c:1561 */
#define   EST167      (ERRST +  167)    /*    st_bdy1.c:1605 */
#define   EST168      (ERRST +  168)    /*    st_bdy1.c:1618 */
#define   EST169      (ERRST +  169)    /*    st_bdy1.c:1627 */
#define   EST170      (ERRST +  170)    /*    st_bdy1.c:1637 */
#define   EST171      (ERRST +  171)    /*    st_bdy1.c:1649 */
#define   EST172      (ERRST +  172)    /*    st_bdy1.c:1857 */
#define   EST173      (ERRST +  173)    /*    st_bdy1.c:1873 */
#define   EST174      (ERRST +  174)    /*    st_bdy1.c:1948 */
#define   EST175      (ERRST +  175)    /*    st_bdy1.c:2004 */
#define   EST176      (ERRST +  176)    /*    st_bdy1.c:2020 */
#define   EST177      (ERRST +  177)    /*    st_bdy1.c:2141 */
#define   EST178      (ERRST +  178)    /*    st_bdy1.c:2158 */
#define   EST179      (ERRST +  179)    /*    st_bdy1.c:2174 */
#define   EST180      (ERRST +  180)    /*    st_bdy1.c:2182 */
#define   EST181      (ERRST +  181)    /*    st_bdy1.c:2375 */
#define   EST182      (ERRST +  182)    /*    st_bdy1.c:2387 */
#define   EST183      (ERRST +  183)    /*    st_bdy1.c:2450 */
#define   EST184      (ERRST +  184)    /*    st_bdy1.c:2529 */
#define   EST185      (ERRST +  185)    /*    st_bdy1.c:2547 */
#define   EST186      (ERRST +  186)    /*    st_bdy1.c:2646 */
#define   EST187      (ERRST +  187)    /*    st_bdy1.c:2664 */
#define   EST188      (ERRST +  188)    /*    st_bdy1.c:2767 */
#define   EST189      (ERRST +  189)    /*    st_bdy1.c:2785 */
#define   EST190      (ERRST +  190)    /*    st_bdy1.c:2880 */
#define   EST191      (ERRST +  191)    /*    st_bdy1.c:2898 */
#define   EST192      (ERRST +  192)    /*    st_bdy1.c:3014 */
#define   EST193      (ERRST +  193)    /*    st_bdy1.c:3032 */
#define   EST194      (ERRST +  194)    /*    st_bdy1.c:3134 */
#define   EST195      (ERRST +  195)    /*    st_bdy1.c:3152 */
#define   EST196      (ERRST +  196)    /*    st_bdy1.c:3253 */
#define   EST197      (ERRST +  197)    /*    st_bdy1.c:3271 */
#define   EST198      (ERRST +  198)    /*    st_bdy1.c:3416 */
#define   EST199      (ERRST +  199)    /*    st_bdy1.c:3425 */
#define   EST200      (ERRST +  200)    /*    st_bdy1.c:3434 */
#define   EST201      (ERRST +  201)    /*    st_bdy1.c:3635 */
#define   EST202      (ERRST +  202)    /*    st_bdy1.c:3650 */
#define   EST203      (ERRST +  203)    /*    st_bdy1.c:3676 */
#define   EST204      (ERRST +  204)    /*    st_bdy1.c:3685 */
#define   EST205      (ERRST +  205)    /*    st_bdy1.c:3724 */
#define   EST206      (ERRST +  206)    /*    st_bdy1.c:3738 */
#define   EST207      (ERRST +  207)    /*    st_bdy1.c:3775 */
#define   EST208      (ERRST +  208)    /*    st_bdy1.c:3857 */
#define   EST209      (ERRST +  209)    /*    st_bdy1.c:3886 */
#define   EST210      (ERRST +  210)    /*    st_bdy1.c:3906 */
#define   EST211      (ERRST +  211)    /*    st_bdy1.c:3966 */
#define   EST212      (ERRST +  212)    /*    st_bdy1.c:4012 */
#define   EST213      (ERRST +  213)    /*    st_bdy1.c:4083 */
#define   EST214      (ERRST +  214)    /*    st_bdy1.c:4219 */
#define   EST215      (ERRST +  215)    /*    st_bdy1.c:4265 */
#define   EST216      (ERRST +  216)    /*    st_bdy1.c:4525 */
#define   EST217      (ERRST +  217)    /*    st_bdy1.c:4599 */
#define   EST218      (ERRST +  218)    /*    st_bdy1.c:4608 */
#define   EST219      (ERRST +  219)    /*    st_bdy1.c:4710 */

#define   EST220      (ERRST +  220)    /*    st_bdy2.c: 501 */
#define   EST221      (ERRST +  221)    /*    st_bdy2.c:1848 */
#define   EST222      (ERRST +  222)    /*    st_bdy2.c:1869 */
#define   EST223      (ERRST +  223)    /*    st_bdy2.c:1944 */
#define   EST224      (ERRST +  224)    /*    st_bdy2.c:2027 */
#define   EST225      (ERRST +  225)    /*    st_bdy2.c:2138 */
#define   EST226      (ERRST +  226)    /*    st_bdy2.c:2283 */
#define   EST227      (ERRST +  227)    /*    st_bdy2.c:3592 */
#define   EST228      (ERRST +  228)    /*    st_bdy2.c:3698 */
#define   EST229      (ERRST +  229)    /*    st_bdy2.c:3812 */
#define   EST230      (ERRST +  230)    /*    st_bdy2.c:3927 */
#define   EST231      (ERRST +  231)    /*    st_bdy2.c:4040 */
#define   EST232      (ERRST +  232)    /*    st_bdy2.c:4163 */
#define   EST233      (ERRST +  233)    /*    st_bdy2.c:4291 */

#define   EST234      (ERRST +  234)    /*    st_bdy3.c: 543 */
#define   EST235      (ERRST +  235)    /*    st_bdy3.c: 636 */
#define   EST236      (ERRST +  236)    /*    st_bdy3.c: 713 */
#define   EST237      (ERRST +  237)    /*    st_bdy3.c: 997 */
#define   EST238      (ERRST +  238)    /*    st_bdy3.c:1540 */
#define   EST239      (ERRST +  239)    /*    st_bdy3.c:1560 */
#define   EST240      (ERRST +  240)    /*    st_bdy3.c:1625 */
#define   EST241      (ERRST +  241)    /*    st_bdy3.c:1640 */
#define   EST242      (ERRST +  242)    /*    st_bdy3.c:1717 */
#define   EST243      (ERRST +  243)    /*    st_bdy3.c:1732 */
#define   EST244      (ERRST +  244)    /*    st_bdy3.c:1823 */
#define   EST245      (ERRST +  245)    /*    st_bdy3.c:1914 */
#define   EST246      (ERRST +  246)    /*    st_bdy3.c:2016 */
#define   EST247      (ERRST +  247)    /*    st_bdy3.c:2092 */
#define   EST248      (ERRST +  248)    /*    st_bdy3.c:2132 */
#define   EST249      (ERRST +  249)    /*    st_bdy3.c:3924 */
#define   EST250      (ERRST +  250)    /*    st_bdy3.c:4031 */
#define   EST251      (ERRST +  251)    /*    st_bdy3.c:4143 */
#define   EST252      (ERRST +  252)    /*    st_bdy3.c:4258 */
#define   EST253      (ERRST +  253)    /*    st_bdy3.c:4373 */
#define   EST254      (ERRST +  254)    /*    st_bdy3.c:4483 */
#define   EST255      (ERRST +  255)    /*    st_bdy3.c:4597 */
#define   EST256      (ERRST +  256)    /*    st_bdy3.c:4719 */
#define   EST257      (ERRST +  257)    /*    st_bdy3.c:4842 */
#define   EST258      (ERRST +  258)    /*    st_bdy3.c:4963 */
#define   EST259      (ERRST +  259)    /*    st_bdy3.c:5009 */

#define   EST260      (ERRST +  260)    /*    st_bdy4.c: 260 */
#define   EST261      (ERRST +  261)    /*    st_bdy4.c: 309 */
#define   EST262      (ERRST +  262)    /*    st_bdy4.c: 389 */
#define   EST263      (ERRST +  263)    /*    st_bdy4.c: 399 */
#define   EST264      (ERRST +  264)    /*    st_bdy4.c: 755 */
#define   EST265      (ERRST +  265)    /*    st_bdy4.c: 864 */
#define   EST266      (ERRST +  266)    /*    st_bdy4.c: 873 */
#define   EST267      (ERRST +  267)    /*    st_bdy4.c:1233 */
#define   EST268      (ERRST +  268)    /*    st_bdy4.c:1304 */
#define   EST269      (ERRST +  269)    /*    st_bdy4.c:1324 */
#define   EST270      (ERRST +  270)    /*    st_bdy4.c:1402 */
#define   EST271      (ERRST +  271)    /*    st_bdy4.c:1938 */
#define   EST272      (ERRST +  272)    /*    st_bdy4.c:1954 */
#define   EST273      (ERRST +  273)    /*    st_bdy4.c:2032 */
#define   EST274      (ERRST +  274)    /*    st_bdy4.c:2059 */
#define   EST275      (ERRST +  275)    /*    st_bdy4.c:2135 */
#define   EST276      (ERRST +  276)    /*    st_bdy4.c:2151 */
#define   EST277      (ERRST +  277)    /*    st_bdy4.c:2282 */
#define   EST278      (ERRST +  278)    /*    st_bdy4.c:2319 */
#define   EST279      (ERRST +  279)    /*    st_bdy4.c:2390 */
#define   EST280      (ERRST +  280)    /*    st_bdy4.c:2427 */
#define   EST281      (ERRST +  281)    /*    st_bdy4.c:2490 */
#define   EST282      (ERRST +  282)    /*    st_bdy4.c:2596 */

#define   EST283      (ERRST +  283)    /*   st_ex_ms.c: 321 */
#define   EST284      (ERRST +  284)    /*   st_ex_ms.c: 377 */
#define   EST285      (ERRST +  285)    /*   st_ex_ms.c: 419 */
#define   EST286      (ERRST +  286)    /*   st_ex_ms.c: 443 */
#define   EST287      (ERRST +  287)    /*   st_ex_ms.c: 461 */

#define   EST288      (ERRST +  288)    /*      st_mf.c: 337 */
#define   EST289      (ERRST +  289)    /*      st_mf.c: 426 */
#define   EST290      (ERRST +  290)    /*      st_mf.c: 458 */
#define   EST291      (ERRST +  291)    /*      st_mf.c: 690 */
#define   EST292      (ERRST +  292)    /*      st_mf.c: 706 */
#define   EST293      (ERRST +  293)    /*      st_mf.c: 939 */
#define   EST294      (ERRST +  294)    /*      st_mf.c: 952 */
#define   EST295      (ERRST +  295)    /*      st_mf.c:1122 */
#define   EST296      (ERRST +  296)    /*      st_mf.c:1339 */
#define   EST297      (ERRST +  297)    /*      st_mf.c:2044 */
#define   EST298      (ERRST +  298)    /*      st_mf.c:2068 */
#define   EST299      (ERRST +  299)    /*      st_mf.c:2366 */
#define   EST300      (ERRST +  300)    /*      st_mf.c:2384 */
#define   EST301      (ERRST +  301)    /*      st_mf.c:3272 */
#define   EST302      (ERRST +  302)    /*      st_mf.c:3443 */
#define   EST303      (ERRST +  303)    /*      st_mf.c:3470 */
#define   EST304      (ERRST +  304)    /*      st_mf.c:3492 */
#define   EST305      (ERRST +  305)    /*      st_mf.c:3624 */

#define   EST306      (ERRST +  306)    /*    st_ptli.c: 910 */
#define   EST307      (ERRST +  307)    /*    st_ptli.c: 954 */
#define   EST308      (ERRST +  308)    /*    st_ptli.c: 999 */
#define   EST309      (ERRST +  309)    /*    st_ptli.c:1041 */
#define   EST310      (ERRST +  310)    /*    st_ptli.c:1083 */
#define   EST311      (ERRST +  311)    /*    st_ptli.c:1128 */
#define   EST312      (ERRST +  312)    /*    st_ptli.c:1176 */

#define   EST313      (ERRST +  313)    /*    st_ptmi.c: 594 */
#define   EST314      (ERRST +  314)    /*    st_ptmi.c: 633 */
#define   EST315      (ERRST +  315)    /*    st_ptmi.c: 672 */
#define   EST316      (ERRST +  316)    /*    st_ptmi.c: 711 */
#define   EST317      (ERRST +  317)    /*    st_ptmi.c: 750 */
#define   EST318      (ERRST +  318)    /*    st_ptmi.c: 788 */
#define   EST319      (ERRST +  319)    /*    st_ptmi.c: 862 */

#define   EST320      (ERRST +  320)    /*    st_ptui.c:1068 */
#define   EST321      (ERRST +  321)    /*    st_ptui.c:1141 */
#define   EST322      (ERRST +  322)    /*    st_ptui.c:1198 */
#define   EST323      (ERRST +  323)    /*    st_ptui.c:1242 */
#define   EST324      (ERRST +  324)    /*    st_ptui.c:1296 */
#define   EST325      (ERRST +  325)    /*    st_ptui.c:1337 */
#define   EST326      (ERRST +  326)    /*    st_ptui.c:1378 */
#define   EST327      (ERRST +  327)    /*    st_ptui.c:1419 */
#define   EST328      (ERRST +  328)    /*    st_ptui.c:1461 */

#define   EST329      (ERRST +  329)    /*   tu_ex_ms.c: 209 */

#define   EST330      (ERRST +  330)    /*    tu_ptli.c: 726 */
#define   EST331      (ERRST +  331)    /*    tu_ptli.c: 769 */
#define   EST332      (ERRST +  332)    /*    tu_ptli.c: 827 */
#define   EST333      (ERRST +  333)    /*    tu_ptli.c: 897 */
#define   EST334      (ERRST +  334)    /*    tu_ptli.c: 960 */
#define   EST335      (ERRST +  335)    /*    tu_ptli.c:1002 */
#define   EST336      (ERRST +  336)    /*    tu_ptli.c:1044 */
/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#define   EST337      (ERRST +  337)    /*    st_bdy1.c:     */
/* st035.301 - Add - Proper handling of StLiSptStaInd  */
#define   EST338      (ERRST +  338)    /*    st_bdy1.c: 3220 */
#endif /* __STERRH__ */

/********************************************************************30**

         End of file:     st_err.h@@/main/10 - Fri Nov 17 10:34:05 2000

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**
 
  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  mma   1. initial release
 
1.2          ---  lc    1. added error codes
 
1.3          ---  ak    1. added error codes 440-462
1.4          ---  ak    1. added error codes 463-466
1.5          ---  aa    1. removed error codes not used
1.6          ---  aa    1. Added the new defines
             ---  aa    2. Changed the error base to zero
 
*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.7          ---      aa   1. Added new error code
 
1.8          ---      nj   1. Rewrote the file.

1.9          ---      nj   1. Updated the error codes for TCAP release 2.8
/main/10     ---      nj   1. Changes for distributed FTHA

3.1+       st034.301   yk   1. Code Added for SS_MULTIPLE_PROCS
3.1+       st035.301  mkm  1. Addition of SAP deletion in Control Request.
                           2. Changes for proper handling of StLiSptStaInd for ST_TC_USER_DIST flag.
*********************************************************************91*/
