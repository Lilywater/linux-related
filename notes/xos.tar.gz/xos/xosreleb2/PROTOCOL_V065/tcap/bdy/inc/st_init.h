/***********************************************
 *   copyright(c)   Beijing Xinwei Telecom Technology Inc. 
 *  
 * Filename: stinit.h
 * Desc      : for TCAP initialization
 * Author    : xingzhou.xu 
 *
 ************************************************/
 #ifndef ST_INIT_H
 #define ST_INIT_H

 //EXTERN S32 stInit(void);

 /* selector definition */
 #define ST_SEL_LC    0                        /* loosely coupled */
 #define ST_SEL_TC    1                        /* tightly coupled */

/* Timer defines */
#define ST_PERIOD0                 1   /* TCAP Timer resolution */
#define ST_PERIOD1                 1   /* PSF Timer resolution */
#define STACC_TMR_RES              1   /* Acceptance test Timer resolution */
#define ST_INIT_WAIT         	  100   /* Wait time to initialize the test cases */
#define ST_T1                             100   /* Invoke Timer */
#define ST_T2                                 5   /* Reject Timer */
#define ST_TMR_CLEANUP              2   /* cleanup timer */
#define ST_TMR_MSG_DELAY         10   /* Timer to wait for message */
#define ST_TMR_WAIT_TMR_EXP   10   /* wait for timer expiry - 10 sec */

#define ST_NUM_OF_CHECK_STATUS      5   /* num of times to check status */
#define ST_NUM_OF_CHECK_MSG            8   /* Transaction Id */

#define TSTREG        OWNREGION  /* memory region id */
#define TSTPOOL       0    /* memory pool id */
#define TSTINST_0     0          /* instance 0 */
#define TSTINST_1     1          /* instance 1 */
#define ST_TSTPRIOR   0          /* Priority */

/* Sap Ids */
#define ST_SAP_0    0
#define ST_SAP_1    1
#define ST_SAP_2    2
#define ST_SAP_3    3
#define ST_SAP_4    4
#define ST_SAP_5    5
#define ST_SAP_6    6
#define ST_SAP_7    7

/* Resources configured in the TCAP Layer */
#define ST_MAX_SAPS   8      /* Maximum number of Saps */
/* st013.301 -modified- maximum dialogue ids are added */
#define ST_MAX_DLGS 80000    /* Maximum number of dialogues */
#define ST_MAX_INVS 80000    /* Maximum number of invokes */
#define ST_SYS_NMBBIN   400005   /* Maximum no of hash list bins */
#if 0
#define ST_SAP_DLGS 10000    /* Maximum number of dialogues on a Sap */
#define ST_SAP_INVS 10000    /* Maximum number of Invokes on a Sap */
#define ST_SAP_BINS 50005   /* Maximum number of Hash List Bins on a Sap */
#endif

/* Maximum limit on the number of dialogues and invokes */
#define ST_MAX_SIM_DLGS   100  /* Maximum number of simultaneous dialogues */
#define ST_MAX_SIM_INVS    16  /* Maximum number of simultaneous invokes */
#define ST_MAX_SEQ_DLGS   500  /* Maximum number of sequential dialogues */
#define ST_MAX_SEQ_INVS   100  /* Maximum number of sequential invokes */
#define ST_MAX_COMPS        5  /* Max no of components */

/* Test Queue size, primitives received form the TCAP are stored in this queue */
#define ST_MSG_QSIZE 200     /* Queue Size */

#define TESTCLEANUPSTATE         50    /* Test state to clean up */

/* Event types */
#define ST_EVT_MSG_IND   1   /* Data Indication from TCAP Layer */
#define ST_EVT_CMP_IND   2   /* Component Indication from TCAP Layer */
#define ST_EVT_CMP_CFM   3   /* Component Confirm from TCAP Layer */
#define ST_EVT_STE_IND   4   /* State Indication from TCAP Layer */
#define ST_EVT_STE_CFM   5   /* State Confirm from TCAP Layer */
#define ST_EVT_NOT_IND   6   /* State Confirm from TCAP Layer */

#ifdef STU2
#define ST_EVT_BND_CFM   7   /* Bind Confirm from TCAP Layer */
#endif /* STU2 */

#ifdef SS_MULTIPLE_PROCS
#define ST_PROC_ID0	(200)
#endif

 #endif /* ST_INIT_H */
