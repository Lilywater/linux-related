#ifndef __ST_BINDH__

#define __ST_BINDH__

extern void stBndSpReq(void);
#endif /*__ST_BINDH__*/