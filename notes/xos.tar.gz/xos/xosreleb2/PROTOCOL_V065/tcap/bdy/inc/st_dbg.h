/**********************************************************************

    Name:   st_cfg.h - Debug print for the TCAP

    Type:   C include file

    Desc:   #define and macros for the TCAP layer Debug print

    File:   st_cfg.h

    Sid:    st_cfg.h - 2006/04/04

    Created by: xingzhou.xu

**********************************************************************/
#ifndef _ST_DBG_H_
#define _ST_DBG_H_
#ifdef SSI_WITH_CLI_ENABLED

/*--------Extern Functions------------------------*/
#ifdef __cplusplus
extern "C" {
#endif

extern XVOID stPrintStCb(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
extern XVOID stPrintStSPSap(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
extern XVOID stPrintStTUSap(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
extern XVOID stPrintStSapSts(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
extern XVOID stPrintSts(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
#ifdef DEBUGP
extern XVOID stSetDbgmsk(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
extern XVOID stPrintDbgmsk(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
#endif
extern XVOID stPrintDialog(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
extern XVOID stPrintTuSapBitMap(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);

#if 0
extern XVOID stPrintRegionInfo(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
#endif

extern XVOID stSetErrCtrl(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
extern XVOID stSetTrc(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);

#ifdef CP_OAM_SUPPORT
extern XVOID stDynCfgDbg(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
#endif /* CP_OAM_SUPPORT */

#ifdef __cplusplus
}
#endif

#endif /* SSI_WITH_CLI_ENABLED */

EXTERN Void stSetDbgMaskFromShell(U32 dbgMask);

#endif /* _ST_DBG_H_ */
