/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     SS7 TCAP
  
     Type:     C include file
  
     Desc:     Defines required by SS7 TCAP.
 
     File:     st.h

     Sid:      st.h@@/main/13 - Fri Nov 17 10:33:58 2000

     Prg:      nj

*********************************************************************21*/

#ifndef __STH__
#define __STH__

#define STLAYERNAME          "TCAP"

/*****************************************************************************
         Start Of Configuration Parameters Defines Block
*****************************************************************************/
/*****************************************************************************
         The Following defines are the configuration defines and can be
         changed to suit the particular requirements.
*****************************************************************************/
/* st005.301 -Added- Rolling Upgrade Feature */
/* Compile time define dependency checks */

/* Check for TDS_CORE2 */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
#ifndef TDS_CORE2
#error "Rolling Upgrade Feature is available in CORE II only"
#endif /* TDS_CORE2 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

/* Check for TDS_ROLL_UPGRADE_SUPPORT */
#ifdef ST_RUG
#ifndef TDS_ROLL_UPGRADE_SUPPORT
#error "ST_RUG cannot be defined without TDS_ROLL_UPGRADE_SUPPORT"
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* ST_RUG */

/* Check for ST_FTHA  */
#ifdef ST_RUG
#ifndef ST_FTHA
#error "ST_FTHA flag is mandatory for Rolling Upgrade. Please enable"
#endif /* ST_FTHA */
#endif /* ST_RUG */

/* Check for STU2  */
#ifdef ST_RUG
#ifndef STU2
#error "STU2 flag is mandatory for Rolling Upgrade.Please enable"
#endif /* STU2 */
#endif /* ST_RUG */

/* Check for SPT2  */
#ifdef ST_RUG
#ifndef SPT2
#error "SPT2 flag is mandatory for Rolling Upgrade.Please enable"
#endif /* SPT2 */
#endif /* ST_RUG */

/* Check for ST_LMINT3 */
#ifdef ST_RUG
#ifndef ST_LMINT3
#error "ST_LMINT3 flag is mandatory for Rolling Upgrade. Please enable"
#endif /* ST_LMINT3 */
#endif /* ST_RUG */

/* Check for SMST_LMINT3 */
#ifdef ST_RUG
#ifndef SMST_LMINT3
#error "SMST_LMINT3 flag is mandatory for Rolling Upgrade. Please enable"
#endif /* SMST_LMINT3 */
#endif /* ST_RUG */

/* Check for LST_LMINT3 */
#ifdef ST_RUG
#ifndef LST_LMINT3
#error "LST_LMINT3 flag is mandatory for Rolling Upgrade. Please enable"
#endif /* LST_LMINT3 */
#endif /* ST_RUG */

/* End of dependency checking for Rolling Upgrade */

/* st007.301 - Added - TC-User Distribution Feature */
/* Compile time define dependency checks */

/* st028.301 - Modify - Support TC-User Distribution Feature without 
   DFTHA Tcap */
#if 0
/* Check for TDS_CORE2 */
#ifdef ST_TC_USER_DIST
#ifndef TDS_CORE2
#error "TC-User Distribution Feature is available in CORE II only"
#endif /* TDS_CORE2 */
#endif /* ST_TC_USER_DIST */

/* Check for ST_FTHA  */
#ifdef ST_TC_USER_DIST
#ifndef ST_FTHA
#error "ST_FTHA flag is mandatory for TC-User Distribution. Please enable"
#endif /* ST_FTHA */
#endif /* ST_TC_USER_DIST */

/* Check for ZT   */
#ifdef ST_TC_USER_DIST
#ifndef ZT
#error "ZT(TCAP PSF) flag is mandatory for TC-User Distribution. Please enable"
#endif /* ZT */
#endif /* ST_TC_USER_DIST */

/* Check for ZT_DFTHA   */
#ifdef ST_TC_USER_DIST
#ifndef ZT_DFTHA
#error "ZT_DFTHA flag is mandatory for TC-User Distribution. Please enable"
#endif /* ZT_DFTHA */
#endif /* ST_TC_USER_DIST */
#endif /* If 0 */

/* Check for STU2  */
#ifdef ST_TC_USER_DIST
#ifndef STU2
#error "STU2 flag is mandatory for TC-User Distribution.Please enable"
#endif /* STU2 */
#endif /* ST_TC_USER_DIST */

/* Check for SPT2  */
#ifdef ST_TC_USER_DIST
#ifndef SPT2
#error "SPT2 flag is mandatory for TC-User Distribution.Please enable"
#endif /* SPT2 */
#endif /* ST_TC_USER_DIST */

/* Check for ST_LMINT3 */
#ifdef ST_TC_USER_DIST
#ifndef ST_LMINT3
#error "ST_LMINT3 flag is mandatory for TC-User Distribution. Please enable"
#endif /* ST_LMINT3 */
#endif /* ST_TC_USER_DIST */


/* End of dependency checking for TC User Distribution feature */

/* st007.301 - Added - TC-User Distribution Feature */
#define ST_DEF_ASSOC_SAP_ID -1    /* Deafault SAP Id for association */
#define ST_DEC_PROB          1    /* Message Decoding Problem */
#ifdef ST_TC_USER_DIST
#define ST_MSG_DIRECTION     1    /* Message Direction */
#endif /* ST_TC_USER_DIST */

#define ST_MAX_LNKS         16     /* Max number of TCAP upper/lower saps */

/* number of Upper/Lower interfaces allowed */
/* st013.301-Modified- MAXSTUI value is changed to 8 */
#define MAXSTUI              8     /* upper interface */
#define MAXSTLI              3     /* lower interface */

/* number of hash list bins in a dialogue and invoke */
/* st036.301 - Increasing bins for Dialogue Hast List */
#define ST_NMB_BIN_DLG       LST_NMB_BIN_DLG     /* hash list bins in dialogue HL */
#define ST_NMB_BIN_INV       LST_NMB_BIN_INV     /* hash list bins in Invoke HL */

/* Maximum number of simultaneous components for a TCAP message */
#define ST_MAX_COMPQ_ENTS    16

/* Maximum number of simultaneous linked invoke for an invocation */
/* st023.301 - Modification, incerase the hash define value for
   Maximum number of simultaneous linked invoke for an invocation 
*/
#define ST_MAX_LINKED_INV    5

/* Timer resolution */
#define ST_PERIOD            1

/* Maximum number of simultaneous timers */
#define ST_MAX_TMR           4

/* Maximum number of simultaneous timers at SAP */
#define ST_MAX_SAP_TMR       1
/* Note : One timer required at lower to wait for bind confirm */

/* Maximum number of timing queue entities */
#define STTQNUMENT          16

/* Number of retries for the bind request */
#define ST_MAX_INTRETRY      2

/* st013.301-Added- DSTU interface */
#ifndef ENTDSTU
#define ENTDSTU  0xaf
#endif

/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
/* SS_MULTIPLE_PROCS */
#ifndef ST_MAX_INSTANCES
#define ST_MAX_INSTANCES 2
#endif


/* st034.301 - Add - Added for SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
#define stCb ((stGlCb).stCb1)
/* st039.301 - Modify - Changes to remove compilation errors. */
#define stDataParam ((stGlCb)._stDataParam)
#define stMgmntParam ((stGlCb)._stMgmntParam)

#define stGlCb (*stGlCbPtr) 

#ifndef CMFTHA_RES_RSETID
#define CMFTHA_RES_RSETID 0x0
#endif
#endif

/* st043.301 - Added offsetOf macro for finding offset in hash list*/
#define offsetOf(type, mem) ((U16) \
		((U8 *)&((type *) 0)->mem - (U8 *)((type *) 0)))

/* st015.301 -Added- deafult values for internal TCAP use */
#define ST_DEF_PROTTYPE 255        /* Invalid protocol switch value */
/*****************************************************************************
         End Of Configuration Parameters Defines Block
*****************************************************************************/

/* High Level SAP States */

#define ST_SAP_UNBND         1     /* SAP unbound */
#define ST_SAP_CFGRD         2     /* SAP configured */
#define ST_SAP_BND_ENBL      3     /* SAP bound and enabled */
#define ST_SAP_WAIT_BNDCFM   4     /* Waiting for Bind Confirm */
#define ST_SAP_BND_PEND      5     /* Bind Pending */


/* Component operation classes */

#define ST_COMP_OPCLS1       1     /* Operation class 1 */
#define ST_COMP_OPCLS2       2     /* Operation class 2 */
#define ST_COMP_OPCLS3       3     /* Operation class 3 */
#define ST_COMP_OPCLS4       4     /* Operation class 4 */


/* Timer Identifiers */

#define ST_INV_TMR           1     /* invocation timer */
#define ST_REJ_TMR           2     /* rejection timer */
#define ST_BND_ACK_TMR       3     /* Bind acknowledgement timer */


/* Id to use for hash list search */

#define ST_USE_SPDLGID       1     /* use spDlgId */
#define ST_USE_SUDLGID       2     /* use suDlgId */

#define ST_INV_DIR_TX        1     /* Transmit Invoke */
#define ST_INV_DIR_RX        2     /* Receive Invoke */

/*  State machine MATRIX */
#ifndef ST_ENABLE_SM_ARRAY
#define ST_MAX_ITU_ISM_SIZE 35     /* Maximum number of entries in Itu Ism */
#define ST_MAX_ITU_TSM_SIZE 25     /* Maximum number of entries in Itu Tsm */
#endif

/* State Values for ITU Transaction State Machine */

#define S_TSM_IDLE         101     /* idle */
#define S_TSM_IS           102     /* initiation sent */
#define S_TSM_IR           103     /* initiation received */
#define S_TSM_ACT          104     /* active */

#ifdef ST_ENABLE_SM_ARRAY
#define ST_ITUTSM_ST_BASE S_TSM_IDLE
#define ST_ITUTSM_ST_MAX S_TSM_ACT
#define ST_MAX_NUM_ITUTSM_ST  (S_TSM_ACT-S_TSM_IDLE+1)
#endif

/* State Values for ITU Dialogue Handler */

#define S_DHA_IDLE           0     /* idle */
#define S_DHA_AC_TX          1     /* Application context mode sent */
#define S_DHA_AC_RX          2     /* Application context mode received */
#define S_DHA_AC_ACT         3     /* Application context mode Active */
#define S_DHA_AC_SET         4


/* State Values for ITU Invocation State Machine */

#define S_ISM_IDLE         105     /* Idle */
#define S_ISM_OPTX1        106     /* Operation Class 1 sent */
#define S_ISM_OPTX2        107     /* Operation Class 2 sent */
#define S_ISM_OPTX3        108     /* Operation Class 3 sent */
#define S_ISM_OPTX4        109     /* Operation Class 4 sent */
#define S_ISM_WFREJ        110     /* Waiting For Reject */

#ifdef ST_ENABLE_SM_ARRAY
#define ST_ITUISM_ST_BASE S_ISM_IDLE
#define ST_ITUISM_ST_MAX S_ISM_WFREJ
#define ST_MAX_NUM_ITUISM_ST  (ST_ITUISM_ST_MAX - ST_ITUISM_ST_BASE +1)
#endif

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)

#ifndef ST_ENABLE_SM_ARRAY_ANSI
#define ST_MAX_ANSI_ISM_SIZE 35    /* Maximum number of entries in Itu Ism */
#define ST_MAX_ANSI_TSM_SIZE 90    /* Maximum number of entries in Itu Tsm */
#endif

/* State Values for ANSI Transaction State Machine */

#define S_TSM_QWPTX        122     /* Query With Permission Sent */
#define S_TSM_QWOPTX       123     /* Query WithOut Permission Sent */
#define S_TSM_CWPTX        124     /* Conversation With Permission Sent */
#define S_TSM_CWOPTX       125     /* Conversation WithOut Permission Sent */
#define S_TSM_QWPRX        126     /* Query With Permission Received */
#define S_TSM_QWOPRX       127     /* Query WithOut Permission Received */
#define S_TSM_CWPRX        128     /* Conversation With Permission Received */
#define S_TSM_CWOPRX       129     /* Conversation WithOut Permission Received */

#ifdef ST_ENABLE_SM_ARRAY_ANSI
#define ST_ANSITSM_ST_BASE		S_TSM_IDLE  /*S_TSM_QWPTX*/
#define ST_ANSITSM_ST_MAX		S_TSM_CWOPRX
#define ST_MAX_NUM_ANSITSM_ST  (ST_ANSITSM_ST_MAX-ST_ANSITSM_ST_BASE+1)
#endif

/* State Values for ANSI Component State Machine */

#define S_ISM_OPPEND       132     /* An Invocation is sent */
#define S_ISM_OPPRGS       133     /* An Invocation is received */

#ifdef ST_ENABLE_SM_ARRAY_ANSI
#define ST_ANSIISM_ST_BASE S_ISM_IDLE /*S_ISM_OPPEND*/
#define ST_ANSIISM_ST_MAX S_ISM_OPPRGS
#define ST_MAX_NUM_ANSIISM_ST  (ST_ANSIISM_ST_MAX - ST_ANSIISM_ST_BASE +1)
#endif
 
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 */


/* Event Values for Transaction State Machine */

#define E_RX_BGN           141
#define E_TX_BGN           142
#define E_RX_CNT           143
#define E_TX_CNT           144
#define E_RX_END           145
#define E_TX_END           146
#define E_RX_UABT          147
#define E_RX_PABT          148
#define E_TX_UABT          149
#define E_TX_PABT          150

#ifdef ST_ENABLE_SM_ARRAY
#define ST_ITUTSM_EV_BASE E_RX_BGN
#define ST_ITUTSM_EV_MAX E_TX_PABT
#define ST_MAX_NUM_ITUTSM_EV  (ST_ITUTSM_EV_MAX-ST_ITUTSM_EV_BASE+1)
#endif

/* Event Values for Invocation State Machine */

#define E_TX_OP1           160
#define E_TX_OP2           161
#define E_TX_OP3           162
#define E_TX_OP4           163
#define E_RX_RRNL          164
#define E_RX_RRL           165
#define E_RX_RE            166
#define E_RX_REJ           167
#define E_TERM             168
#define E_INV_TMR          169     /* Invocation Timer Expired */
#define E_REJ_TMR          170     /* Reject Timer Expired */
/* st015.301 -Add- invalid event definition */
#define E_INV_EVNT         0       /* Invalid event */
 
#ifdef ST_ENABLE_SM_ARRAY
#define ST_ITUISM_EV_BASE E_TX_OP1
#define ST_ITUISM_EV_MAX E_REJ_TMR
#define ST_MAX_NUM_ITUISM_EV  (ST_ITUISM_EV_MAX-ST_ITUISM_EV_BASE+1)
#endif

#ifdef ST_ENABLE_SM_ARRAY
#define ST_MAX_ITU_TSM_SIZE ST_MAX_NUM_ITUTSM_ST*ST_MAX_NUM_ITUTSM_EV     /* Maximum number of entries in Itu Tsm */

#define ST_MAX_ITU_ISM_SIZE ST_MAX_NUM_ITUISM_ST*ST_MAX_NUM_ITUISM_EV     /* Maximum number of entries in Itu Tsm */

#define ST_TABLE_TYPE_TSM	0
#define ST_TABLE_TYPE_ISM	1

#endif

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)

/* Event Values for Ansi Transaction State Machine */

#define E_TX_QWP           181
#define E_TX_QWOP          182
#define E_TX_CWP           183
#define E_TX_CWOP          184
#define E_RX_QWP           185
#define E_RX_QWOP          186
#define E_RX_CWP           187
#define E_RX_CWOP          188
#define E_RX_RSP           189
#define E_TX_RSP           190
#define E_NO_RSP           191
#define E_APP_TERM         194
#define E_PROT_ERR         195
#define E_RX_LREJ          196

#ifdef ST_ENABLE_SM_ARRAY_ANSI
#define ST_ANSITSM_EV_BASE E_RX_UABT  /* E_TX_QWP */
#define ST_ANSITSM_EV_MAX E_RX_LREJ
#define ST_MAX_NUM_ANSITSM_EV  (ST_ANSITSM_EV_MAX-ST_ANSITSM_EV_BASE+1)
#endif

/* Event Values for Ansi Component State Machine */

#define E_TX_INV           201
#define E_TX_RES           202
#define E_TX_ERR           203
#define E_TX_REJ           204
#define E_TX_INL           205
#define E_TX_RNL           206
#define E_RX_INV           207
#define E_RX_RES           208
#define E_RX_ERR           209
#define E_RX_INL           210
#define E_RX_RNL           211
#define E_RX_UNKN          212

#ifdef ST_ENABLE_SM_ARRAY_ANSI
#define ST_ANSIISM_EV_BASE E_RX_REJ /*E_TX_INV*/
#define ST_ANSIISM_EV_MAX E_RX_UNKN
#define ST_MAX_NUM_ANSIISM_EV  (ST_ANSIISM_EV_MAX-ST_ANSIISM_EV_BASE+1)
#endif

#ifdef ST_ENABLE_SM_ARRAY_ANSI
#define ST_MAX_ANSI_TSM_SIZE ST_MAX_NUM_ANSITSM_ST*ST_MAX_NUM_ANSITSM_EV     /* Maximum number of entries in Itu Tsm */

#define ST_MAX_ANSI_ISM_SIZE ST_MAX_NUM_ANSIISM_ST*ST_MAX_NUM_ANSIISM_EV     /* Maximum number of entries in Itu Tsm */

#endif

#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 */


/* Statistics types */

#define ST_STS_TX_MSG        1     /* Transmit message statistics */
#define ST_STS_RX_MSG        2     /* Receive message statistics */
#define ST_STS_TX_COMP       3     /* Transmit Component statistics */
#define ST_STS_RX_COMP       4     /* Receive Component statistics */
#define ST_STS_FAULT         5     /* Fault statistics */

/* selector definition */
#define ST_SEL_LC		0						/* loosely coupled */
#define ST_SEL_TC		1						/* tightly coupled */
#define ST_SEL_TU		ST_SEL_TC				/* TCAP User - tightly coupled */
#define ST_SEL_SP		ST_SEL_TC				/* SP - tightly coupled */
#define ST_SEL_MA		2						/* MAP - tightly coupled */
#define ST_SEL_SU		2						/* SUA - tightly coupled */
#define ST_SEL_IA		3						/* IS-41 - tightly coupled */
#define ST_SEL_IE		4						/* INAP - tightly coupled */
#define ST_SEL_QC		5						/* CAP - tightly coupled */
#define ST_SEL_DSTU		6						/* DSTU - tightly coupled */
#define ST_SEL_DSDT		7						/* TCAP-LLDF - tightly coupled */

/* instance definition */
#define SM_INST			0

#define ST_INST_0		0
#define SM_INST_0		0
#define SP_INST_0		0
#define QC_INST_0		0
#define MA_INST_0		0

#define ST_INST_1		1
#define SM_INST_1		1
#define SP_INST_1		1
#define QC_INST_1		1
#define MA_INST_1		1

/* statistics definition */
enum CP_TCAP_STS_TYPE
{
	CP_TCAP_STS_GEN,
	CP_TCAP_STS_ABT,
	CP_TCAP_STS_REJ,
	CP_TCAP_STS_MAX,
};

/* Macro Definitions */

/* Macro for finding the length of a string */
#define ST_FND_STR_LEN(str, len)     \
{                                    \
   len = 0;                          \
   while (str[len++] != '\0');       \
                                     \
   len -= 1;                         \
}

/* Macro to do string copy */
#define ST_CPY_STR(dStr, sStr, len)  \
{                                    \
   U16  i;                           \
                                     \
   for (i = 0; i < (U16)len; i++)    \
   {                                 \
       dStr[i] = sStr[i];            \
   }                                 \
}

/* Initialize LM header */
#define ST_INIT_LM_HDR(type, sapId, suDlgId, spDlgId)  \
{                                                      \
   stCb.hdr.elmId.elmnt      = type;                   \
   stCb.hdr.elmId.elmntInst1 = sapId;                  \
   stCb.hdr.elmId.elmntInst2 = suDlgId;                \
   stCb.hdr.elmId.elmntInst3 = spDlgId;                \
}
 
/* Macro initializes a single entry of a State Table */
#ifdef ST_ENABLE_SM_ARRAY
#define ST_SM_ENT(smTbl, type, curSt, ev, nxtSt, actRtn)  \
{                                                        \
   U16 index;	\
   if(type == ST_TABLE_TYPE_TSM)	\
       index = (curSt-ST_ITUTSM_ST_BASE)*ST_MAX_NUM_ITUTSM_EV + (ev - ST_ITUTSM_EV_BASE); \
   else       \
       index = (curSt-ST_ITUISM_ST_BASE)*ST_MAX_NUM_ITUISM_EV + (ev - ST_ITUISM_EV_BASE); \
   smTbl[index].curState   = (StState)curSt;               \
   smTbl[index].smEvent    = (StEvent)ev;                  \
   smTbl[index].nextState  = (StState)nxtSt;               \
   smTbl[index].actRoutine = actRtn;                       \
}
#else
#define ST_SM_ENT(smTbl, idx, curSt, ev, nxtSt, actRtn)  \
{                                                        \
   smTbl[idx].curState   = (StState)curSt;               \
   smTbl[idx].smEvent    = (StEvent)ev;                  \
   smTbl[idx].nextState  = (StState)nxtSt;               \
   smTbl[idx].actRoutine = actRtn;                       \
   idx++;                                                \
}
#endif

#ifdef ST_ENABLE_SM_ARRAY_ANSI
#define ST_SM_ENT_ANSI(smTbl, type, curSt, ev, nxtSt, actRtn)  \
{                                                        \
   U16 index;	\
   if(type == ST_TABLE_TYPE_TSM)	\
       index = (curSt-ST_ANSITSM_ST_BASE)*ST_MAX_NUM_ANSITSM_EV + (ev - ST_ANSITSM_EV_BASE); \
   else       \
       index = (curSt-ST_ANSIISM_ST_BASE)*ST_MAX_NUM_ANSIISM_EV + (ev - ST_ANSIISM_EV_BASE); \
   smTbl[index].curState   = (StState)curSt;               \
   smTbl[index].smEvent    = (StEvent)ev;                  \
   smTbl[index].nextState  = (StState)nxtSt;               \
   smTbl[index].actRoutine = actRtn;                       \
}
#else
#define ST_SM_ENT_ANSI(smTbl, idx, curSt, ev, nxtSt, actRtn)  \
{                                                        \
   smTbl[idx].curState   = (StState)curSt;               \
   smTbl[idx].smEvent    = (StEvent)ev;                  \
   smTbl[idx].nextState  = (StState)nxtSt;               \
   smTbl[idx].actRoutine = actRtn;                       \
   idx++;                                                \
}
#endif


/* Debug Macro */
#define STDBGP(_msgClass, _arg)                                      \
   DBGP(&stCb.init, STLAYERNAME, _msgClass, _arg)

/* st027.301 - Modify - Modify the macro take care of NULL 

/* st023.301 - addition - macro to free user buffer */
/* st029.301 - Modify - Modify the macro to remove warning */
#define STFREEUSERBUF(_uiBuf)                                      \
if ((Buffer *)_uiBuf != (Buffer*) NULLP)                                               \
{                                                                  \
   (Void)SPutMsg((Buffer *)_uiBuf);                                          \
   _uiBuf = NULLP;                                                 \
}
#endif  /* _STH_ */

/********************************************************************30**

         End of file:     st.h@@/main/13 - Fri Nov 17 10:33:58 2000

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**
 
  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  mma   1. initial release
 
1.2          ---  bn    1. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92
 
1.3          ---  mma   1. miscellaneous changes
 
1.4          ---  ak    1. add MAXSTMI
             ---  ak    2. text changes
 
1.5          ---  ak    1. added ANSI 92 defines (SS7_ANS92)
             ---  ak    2. added defines for dialog portion (CCITT 92)
             ---  ak    3. defined TRP events for UABORT and ABORT_R
 
1.6          ---  aa    1. removed ST_MAX_MSG_LEN
             ---  aa    2. Chnaged MAXSTUI from 3 to 4 because of MAP
             ---  aa    3. misc changes
 
1.7          ---  aa    1. miscellaneous changes
 
1.8          ---  aa    1. changed the define ST_INV_INVKID fro 0xff to 0x80
                           as invokeId is S8 
 
1.9         ---   aa    1. Removed the defines which are not used (e.g defines
                           for different state machines)
 
*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.10         ---      aa   1. Added the define ST_DLG_ID_VAL_B0
             ---      aa   2. Changed the define for the followings
                              a) ST_INV_INVKID  from 0x80 to -128
                              b) ST_RESULT_TAG  from 0x82 to A2
             ---      aa   3. Removed ST_INV_INVKID as it is not used.
 
1.11         ---      nj   1. Rewrote the file.
1.12         ---      nj   1. Added new sap state to wait for bind confirm
                           2. Added define for no of retries for bind request

1.13         ---      nj   1. Added defines for Invoke direction

/main/13     ---      nj   1. Added a SAP state to mark bind pending operation on
                              the lower SAP.
3.1+      st002.301 zr,as  1. Changed the value of MAXSTUI for CAP support
3.1+      st005.301   zr   1. Compile time dependency checks added for
                              Rolling Upgrade Feature
3.1+      st007.301   zr   1. Added compile time flag dependecy check for
                              TC-User Distribution feature 
3.1+      st013.301  akp   1. Entity DSTU is defined here. THis has to
                           be removed with new release.
                           2. MAXSTUI value is changed to 8 because of
                           new DSTU interface.
3.1+      st015.301   zr   1. Added following default defines
                              - ST_DEF_PROTTYPE
                              - E_INV_EVNT
3.1+      st015.301   jz   1. Deallocate the user buffer in error scenarios.
3.1+      st027.301   ds   1. Modify the STFREEUSERBUF macro to take care of 
                              NULLpointer assignment.
3.1+      st028.301   ds   1. Support TC-User Distribution Feature without 
                              DFTHA/FTHA Tcap.
3.1+      st029.301   yk   1. STFREEUSERBUF modified to remove warnings
3.1+      st034.301   yk   1. Code Added for SS_MULTIPLE_PROCS
3.1+      st036.301   mkm  1. Correction of patch st035.301. 
                           2. Increase number of bins in dialogue hash list.
                           3. put ztActvInit outside SS_MULTIPLE_PROCS flag
                           4. In test case 209, replace  STACC_PROC_ID0 with par. 
3.1+      st039.301   mkm  1. Modification to remove Compiler errors.
3.1+      st043.301   mkm  1. Added offsetOf macro for finding offset in 
                              hash list of dialogues.
*********************************************************************91*/
