/***************************************************************
**
**  Xinwei Telecom Technology co., ltd. ShenZhen R&D center
**  
**  Core Network Department  platform team  
**
**  filename: parser.h 
**
**  description: : Interfaces, constants and types related to the XML parser.
**
**  author: zhanglei
**
**  data:   2006.3.7
**
***************************************************************
**                          history                     
**  
***************************************************************
**   author          data              modification            
**   zhanglei         2006.3.7              create  
**************************************************************/

#ifndef __XML_PARSER_H__
#define __XML_PARSER_H__


#ifdef __cplusplus
extern "C" {
#endif

#include "xostype.h"
#include "xoscfg.h"


#define xmlFree(x) free((x))
#define xmlMalloc(x) malloc(x)


#ifndef XOS_VXWORKS

/*
 * The different element types carried by an XML tree
 *
 * NOTE: This is synchronized with DOM Level1 values
 *       See http://www.w3.org/TR/REC-DOM-Level-1/
 */
typedef enum 
{
    XML_ELEMENT_NODE=		1,
    XML_ATTRIBUTE_NODE=		2,
    XML_TEXT_NODE=		3,
    XML_CDATA_SECTION_NODE=	4,
    XML_ENTITY_REF_NODE=	5,
    XML_ENTITY_NODE=		6,
    XML_PI_NODE=		7,
    XML_COMMENT_NODE=		8,
    XML_DOCUMENT_NODE=		9,
    XML_DOCUMENT_TYPE_NODE=	10,
    XML_DOCUMENT_FRAG_NODE=	11,
    XML_NOTATION_NODE=		12,
    XML_HTML_DOCUMENT_NODE=	13
} xmlElementType;

/*
 * Size of an internal character representation.
 *
 * Currently we use 8bit chars internal representation for memory efficiency,
 * but the parser is not tied to that, just define UNICODE to switch to
 * a 16 bits internal representation. Note that with 8 bits wide
 * xmlChars one can still use UTF-8 to handle correctly non ISO-Latin
 * input.
 */

#ifdef UNICODE
typedef XU16 xmlChar;
#else
typedef XS8 xmlChar;
#endif

#define BAD_CAST (xmlChar *)

/*
 * a DTD Attribute definition
 */
typedef enum 
{
    XML_ATTRIBUTE_CDATA = 1,
    XML_ATTRIBUTE_ID,
    XML_ATTRIBUTE_IDREF	,
    XML_ATTRIBUTE_IDREFS,
    XML_ATTRIBUTE_ENTITY,
    XML_ATTRIBUTE_ENTITIES,
    XML_ATTRIBUTE_NMTOKEN,
    XML_ATTRIBUTE_NMTOKENS,
    XML_ATTRIBUTE_ENUMERATION,
    XML_ATTRIBUTE_NOTATION
} xmlAttributeType;

typedef enum 
{
    XML_ATTRIBUTE_NONE = 1,
    XML_ATTRIBUTE_REQUIRED,
    XML_ATTRIBUTE_IMPLIED,
    XML_ATTRIBUTE_FIXED
} xmlAttributeDefault;

typedef struct _XOSxmlEnumeration xmlEnumeration;
typedef xmlEnumeration *xmlEnumerationPtr;
struct _XOSxmlEnumeration 
{
    struct _XOSxmlEnumeration    *next;	/* next one */
    XCONST xmlChar            *name;	/* Enumeration name */
};

typedef struct _XOSxmlAttribute xmlAttribute;
typedef xmlAttribute *xmlAttributePtr;
struct _XOSxmlAttribute 
{
    XCONST xmlChar         *elem;	/* Element holding the attribute */
    XCONST xmlChar         *name;	/* Attribute name */
    struct _XOSxmlAttribute   *next;       /* list of attributes of an element */
    xmlAttributeType       type;	/* The type */
    xmlAttributeDefault    def;		/* the default */
    XCONST xmlChar         *defaultValue;/* or the default value */
    xmlEnumerationPtr      tree;        /* or the enumeration tree if any */
    XCONST xmlChar         *prefix;      /* the namespace prefix if any */
};

/*
 * a DTD Element definition.
 */
typedef enum 
{
    XML_ELEMENT_CONTENT_PCDATA = 1,
    XML_ELEMENT_CONTENT_ELEMENT,
    XML_ELEMENT_CONTENT_SEQ,
    XML_ELEMENT_CONTENT_OR
} xmlElementContentType;

typedef enum 
{
    XML_ELEMENT_CONTENT_ONCE = 1,
    XML_ELEMENT_CONTENT_OPT,
    XML_ELEMENT_CONTENT_MULT,
    XML_ELEMENT_CONTENT_PLUS
} xmlElementContentOccur;

typedef struct _XOSxmlElementContent xmlElementContent;
typedef xmlElementContent *xmlElementContentPtr;
struct _XOSxmlElementContent 
{
    xmlElementContentType     type;	/* PCDATA, ELEMENT, SEQ or OR */
    xmlElementContentOccur    ocur;	/* ONCE, OPT, MULT or PLUS */
    XCONST xmlChar            *name;	/* Element name */
    struct _XOSxmlElementContent *c1;	/* first child */
    struct _XOSxmlElementContent *c2;	/* second child */
};

typedef enum 
{
    XML_ELEMENT_TYPE_EMPTY = 1,
    XML_ELEMENT_TYPE_ANY,
    XML_ELEMENT_TYPE_MIXED,
    XML_ELEMENT_TYPE_ELEMENT
} xmlElementTypeVal;

typedef struct _XOSxmlElement xmlElement;
typedef xmlElement *xmlElementPtr;
struct _XOSxmlElement 
{
    XCONST xmlChar          *name;	/* Element name */
    xmlElementTypeVal       type;	/* The type */
    xmlElementContentPtr content;	/* the allowed element content */
    xmlAttributePtr   attributes;	/* List of the declared attributes */
};

/*
 * A attribute of an XML node.
 */
typedef struct _XOSxmlAttr xmlAttr;
typedef xmlAttr *xmlAttrPtr;
struct _XOSxmlAttr 
{
#ifndef XML_WITHOUT_CORBA
    XVOID           *_private;	/* for Corba, must be first ! */
    XVOID           *vepv;	    /* for Corba, must be next ! */
#endif
    xmlElementType  type;       /* XML_ATTRIBUTE_NODE, must be third ! */
    struct _XOSxmlNode *node;	/* attr->node link */
    struct _XOSxmlAttr *next;	/* attribute list link */
    XCONST xmlChar   *name;     /* the name of the property */
    struct _XOSxmlNode *val;    /* the value of the property */

};

/*
 * An XML ID instance.
 */
typedef struct _XOSxmlID xmlID;
typedef xmlID *xmlIDPtr;
struct _XOSxmlID 
{
    struct _XOSxmlID    *next;	/* next ID */
    XCONST xmlChar    *value;	/* The ID name */
    xmlAttrPtr        attr;	/* The attribut holding it */
};

/*
 * An XML IDREF instance.
 */
typedef struct _XOSxmlRef xmlRef;
typedef xmlRef *xmlRefPtr;
struct _XOSxmlRef 
{
    struct _XOSxmlRef   *next;	/* next Ref */
    XCONST xmlChar      *value;	/* The Ref name */
    xmlAttrPtr          attr;	/* The attribut holding it */
};

/*
 * A buffer structure
 */
typedef enum 
{
    XML_BUFFER_ALLOC_DOUBLEIT,
    XML_BUFFER_ALLOC_EXACT
} xmlBufferAllocationScheme;

typedef struct _XOSxmlBuffer xmlBuffer;
typedef xmlBuffer *xmlBufferPtr;
struct _XOSxmlBuffer 
{
    xmlChar *content;		/* The buffer content UTF8 */
    XU32 use;		/* The buffer size used */
    XU32 size;		/* The buffer size */
    xmlBufferAllocationScheme alloc; /* The realloc method */
};

/*
 * A node in an XML tree.
 */
typedef struct _XOSxmlNode xmlNode;
typedef xmlNode *xmlNodePtr;
struct _XOSxmlNode 
{
#ifndef XML_WITHOUT_CORBA
    XVOID           *_private;	/* for Corba, must be first ! */
    XVOID           *vepv;	/* for Corba, must be next ! */
#endif
    xmlElementType  type;	/* type number in the DTD, must be third ! */
    struct _XOSxmlDoc  *doc;	/* the containing document */
    struct _XOSxmlNode *parent;	/* child->parent link */
    struct _XOSxmlNode *next;	/* next sibling link  */
    struct _XOSxmlNode *prev;	/* previous sibling link  */
    struct _XOSxmlNode *childs;	/* parent->childs link */
    struct _XOSxmlNode *last;	/* last child link */
    struct _XOSxmlAttr *properties;/* properties list */
    XCONST xmlChar  *name;       /* the name of the node, or the entity */

#ifndef XML_USE_BUFFER_CONTENT    
    xmlChar        *content;    /* the content */
#else
    xmlBufferPtr   content;     /* the content in a buffer */
#endif
};

/*
 * An XML document.
 */
typedef struct _XOSxmlDoc xmlDoc;
typedef xmlDoc *xmlDocPtr;
struct _XOSxmlDoc 
{
#ifndef XML_WITHOUT_CORBA
    XVOID           *_private;	/* for Corba, must be first ! */
    XVOID           *vepv;	/* for Corba, must be next ! */
#endif
    xmlElementType  type;       /* XML_DOCUMENT_NODE, must be second ! */
    XU8             *name;	/* name/filename/URI of the document */
    XCONST xmlChar  *version;	/* the XML version string */
    XCONST xmlChar  *encoding;   /* encoding, if any */
    XS32             compression;/* level of zlib compression */
    XS32             standalone; /* standalone document (no external refs) */

    struct _XOSxmlNode *root;	/* the document tree */
};

/*
 * Compatibility naming layer with libxml1
 */
#ifndef xmlChildrenNode
#define xmlChildrenNode childs
#endif

/**
 * Predefined values for some standard encodings
 */
typedef enum 
{
    XML_CHAR_ENCODING_ERROR=   -1, /* No XS8 encoding detected */
    XML_CHAR_ENCODING_NONE=	0, /* No XS8 encoding detected */
    XML_CHAR_ENCODING_UTF8=	1, /* UTF-8 */
    XML_CHAR_ENCODING_UTF16LE=	2, /* UTF-16 little endian */
    XML_CHAR_ENCODING_UTF16BE=	3, /* UTF-16 big endian */
    XML_CHAR_ENCODING_UCS4LE=	4, /* UCS-4 little endian */
    XML_CHAR_ENCODING_UCS4BE=	5, /* UCS-4 big endian */
    XML_CHAR_ENCODING_EBCDIC=	6, /* EBCDIC uh! */
    XML_CHAR_ENCODING_UCS4_2143=7, /* UCS-4 unusual ordering */
    XML_CHAR_ENCODING_UCS4_3412=8, /* UCS-4 unusual ordering */
    XML_CHAR_ENCODING_UCS2=	9, /* UCS-2 */
    XML_CHAR_ENCODING_8859_1=	10,/* ISO-8859-1 ISO Latin 1 */
    XML_CHAR_ENCODING_8859_2=	11,/* ISO-8859-2 ISO Latin 2 */
    XML_CHAR_ENCODING_8859_3=	12,/* ISO-8859-3 */
    XML_CHAR_ENCODING_8859_4=	13,/* ISO-8859-4 */
    XML_CHAR_ENCODING_8859_5=	14,/* ISO-8859-5 */
    XML_CHAR_ENCODING_8859_6=	15,/* ISO-8859-6 */
    XML_CHAR_ENCODING_8859_7=	16,/* ISO-8859-7 */
    XML_CHAR_ENCODING_8859_8=	17,/* ISO-8859-8 */
    XML_CHAR_ENCODING_8859_9=	18,/* ISO-8859-9 */
    XML_CHAR_ENCODING_2022_JP=  19,/* ISO-2022-JP */
    XML_CHAR_ENCODING_SHIFT_JIS=20,/* Shift_JIS */
    XML_CHAR_ENCODING_EUC_JP=   21 /* EUC-JP */
} xmlCharEncoding;


/* coding */
#define XML_INTERNAL_GENERAL_ENTITY		        1
#define XML_EXTERNAL_GENERAL_PARSED_ENTITY	    2
#define XML_EXTERNAL_GENERAL_UNPARSED_ENTITY	3
#define XML_INTERNAL_PARAMETER_ENTITY		    4
#define XML_EXTERNAL_PARAMETER_ENTITY		    5
#define XML_INTERNAL_PREDEFINED_ENTITY		    6

/*
 * An unit of storage for an entity, contains the string, the value
 * and the linkind data needed for the linking in the hash table.
 */
typedef struct _XOSxmlEntity xmlEntity;
typedef xmlEntity *xmlEntityPtr;
struct _XOSxmlEntity 
{
    XS32 type;			/* The entity type */
    XS32 len;			/* The lenght of the name */
    XCONST xmlChar  *name;	/* Name of the entity */
    XCONST xmlChar  *ExternalID;	/* External identifier for PUBLIC Entity */
    XCONST xmlChar  *SystemID;	/* URI for a SYSTEM or PUBLIC Entity */
    xmlChar *content;		/* The entity content or ndata if unparsed */
    XS32 length;			/* the content length */
    xmlChar *orig;		/* The entity cont without ref substitution */
    /* Extended when merging 2,3,5 */
    struct _XOSxmlNode    *children;/* NULL */
    struct _XOSxmlNode    *last;	/* NULL */
    XCONST xmlChar      *URI;	/* the full URI as computed */
};

/* Error code */
typedef enum 
{
    XML_ERR_OK = 0,
    XML_ERR_INTERNAL_ERROR,
    XML_ERR_NO_MEMORY,
    
    XML_ERR_DOCUMENT_START, /* 3 */
    XML_ERR_DOCUMENT_EMPTY,
    XML_ERR_DOCUMENT_END,

    XML_ERR_INVALID_HEX_CHARREF, /* 6 */
    XML_ERR_INVALID_DEC_CHARREF,
    XML_ERR_INVALID_CHARREF,
    XML_ERR_INVALID_CHAR,

    XML_ERR_CHARREF_AT_EOF, /* 10 */
    XML_ERR_CHARREF_IN_PROLOG,
    XML_ERR_CHARREF_IN_EPILOG,
    XML_ERR_CHARREF_IN_DTD,
    XML_ERR_ENTITYREF_AT_EOF,
    XML_ERR_ENTITYREF_IN_PROLOG,
    XML_ERR_ENTITYREF_IN_EPILOG,
    XML_ERR_ENTITYREF_IN_DTD,
    XML_ERR_PEREF_AT_EOF,
    XML_ERR_PEREF_IN_PROLOG,
    XML_ERR_PEREF_IN_EPILOG,
    XML_ERR_PEREF_IN_INT_SUBSET,

    XML_ERR_ENTITYREF_NO_NAME, /* 22 */
    XML_ERR_ENTITYREF_SEMICOL_MISSING,

    XML_ERR_PEREF_NO_NAME, /* 24 */
    XML_ERR_PEREF_SEMICOL_MISSING,

    XML_ERR_UNDECLARED_ENTITY, /* 26 */
    XML_WAR_UNDECLARED_ENTITY,
    XML_ERR_UNPARSED_ENTITY,
    XML_ERR_ENTITY_IS_EXTERNAL,
    XML_ERR_ENTITY_IS_PARAMETER,

    XML_ERR_UNKNOWN_ENCODING, /* 31 */
    XML_ERR_UNSUPPORTED_ENCODING, /*XS8 encoding USC4 little endian not supported*/

    XML_ERR_STRING_NOT_STARTED, /* 33 */
    XML_ERR_STRING_NOT_CLOSED,
    XML_ERR_NS_DECL_ERROR,

    XML_ERR_ENTITY_NOT_STARTED, /* 36 */
    XML_ERR_ENTITY_NOT_FINISHED,
    
    XML_ERR_LT_IN_ATTRIBUTE, /* 38 */
    XML_ERR_ATTRIBUTE_NOT_STARTED,
    XML_ERR_ATTRIBUTE_NOT_FINISHED,
    XML_ERR_ATTRIBUTE_WITHOUT_VALUE,
    XML_ERR_ATTRIBUTE_REDEFINED,

    XML_ERR_LITERAL_NOT_STARTED, /* 43 */
    XML_ERR_LITERAL_NOT_FINISHED,
    
    XML_ERR_COMMENT_NOT_FINISHED, /* 45 */

    XML_ERR_PI_NOT_STARTED, /* 47 */
    XML_ERR_PI_NOT_FINISHED,

    XML_ERR_NOTATION_NOT_STARTED, /* 49 */
    XML_ERR_NOTATION_NOT_FINISHED,

    XML_ERR_ATTLIST_NOT_STARTED, /* 51 */
    XML_ERR_ATTLIST_NOT_FINISHED,

    XML_ERR_MIXED_NOT_STARTED, /* 53 */
    XML_ERR_MIXED_NOT_FINISHED,

    XML_ERR_ELEMCONTENT_NOT_STARTED, /* 55 */
    XML_ERR_ELEMCONTENT_NOT_FINISHED,

    XML_ERR_XMLDECL_NOT_STARTED, /* 57 */
    XML_ERR_XMLDECL_NOT_FINISHED,

    XML_ERR_CONDSEC_NOT_STARTED, /* 59 */
    XML_ERR_CONDSEC_NOT_FINISHED,

    XML_ERR_EXT_SUBSET_NOT_FINISHED, /* 61 */

    XML_ERR_DOCTYPE_NOT_FINISHED, /* 62 */

    XML_ERR_MISPLACED_CDATA_END, /* 63 */
    XML_ERR_CDATA_NOT_FINISHED,

    XML_ERR_RESERVED_XML_NAME, /* 65 */

    XML_ERR_SPACE_REQUIRED, /* 66 */
    XML_ERR_SEPARATOR_REQUIRED,
    XML_ERR_NMTOKEN_REQUIRED,
    XML_ERR_NAME_REQUIRED,
    XML_ERR_PCDATA_REQUIRED,
    XML_ERR_URI_REQUIRED,
    XML_ERR_PUBID_REQUIRED,
    XML_ERR_LT_REQUIRED,
    XML_ERR_GT_REQUIRED,
    XML_ERR_LTSLASH_REQUIRED,
    XML_ERR_EQUAL_REQUIRED,

    XML_ERR_TAG_NAME_MISMATCH, /* 77 */
    XML_ERR_TAG_NOT_FINISED,

    XML_ERR_STANDALONE_VALUE, /* 79 */

    XML_ERR_ENCODING_NAME, /* 80 */

    XML_ERR_HYPHEN_IN_COMMENT, /* 81 */

    /* Added after 2.3.5 integration */
    XML_ERR_INVALID_ENCODING, /* 82 */

    XML_ERR_EXT_ENTITY_STANDALONE, /* 83 */

    XML_ERR_CONDSEC_INVALID, /* 84 */

    XML_ERR_VALUE_REQUIRED, /* 85 */

    XML_ERR_NOT_WELL_BALANCED, /* 86 */
    XML_ERR_EXTRA_CONTENT, /* 87 */
    XML_ERR_ENTITY_CHAR_ERROR, /* 88 */
    XML_ERR_ENTITY_PE_INTERNAL, /* 88 */
    XML_ERR_ENTITY_LOOP, /* 89 */
    XML_ERR_ENTITY_BOUNDARY, /* 90 */
    XML_ERR_INVALID_URI, /* 91 */
    XML_ERR_URI_FRAGMENT /* 92 */
}xmlParserErrors;

typedef struct _XOSxmlParserInputBuffer xmlParserInputBuffer;
typedef xmlParserInputBuffer *xmlParserInputBufferPtr;
struct _XOSxmlParserInputBuffer 
{
    /* Inputs */
    FILE          *file;    /* Input on file handler */
    XS32              fd;    /* Input on a file descriptor */
    
    xmlBufferPtr buffer;    /* Local buffer encoded in  UTF-8 */
    /* Added when merging 2.3.5 code */
    xmlBufferPtr raw;       /* if encoder != NULL buffer for raw input */
};

/**
 * an xmlParserInput is an input flow for the XML processor.
 * Each entity parsed is associated an xmlParserInput (except the
 * few predefined ones). This is the case both for internal entities
 * - in which case the flow is already completely in memory - or
 * external entities - in which case we use the buf structure for
 * progressive reading and I18N conversions to the internal UTF-8 format.
 */
typedef XVOID (* xmlParserInputDeallocate)(xmlChar *);
typedef struct _XOSxmlParserInput xmlParserInput;
typedef xmlParserInput *xmlParserInputPtr;
struct _XOSxmlParserInput 
{
    /* Input buffer */
    xmlParserInputBufferPtr buf;      /* UTF-8 encoded buffer */

    XCONST XS8 *filename;             /* The file analyzed, if any */
    XCONST XS8 *directory;            /* the directory/base of teh file */
    XCONST xmlChar *base;              /* Base of the array to parse */
    XCONST xmlChar *cur;               /* Current XS8 being parsed */
    XS32 length;                       /* length if known */
    XS32 line;                         /* Current line */
    XS32 col;                          /* Current column */
    XS32 consumed;                     /* How many xmlChars already consumed */
    xmlParserInputDeallocate free;    /* function to deallocate the base */
    /* added after 2.3.5 integration */
    XCONST xmlChar *end;               /* end of the arry to parse */
    XCONST xmlChar *encoding;          /* the encoding string for entity */
    XCONST xmlChar *version;           /* the version string for entity */
    XS32 standalone;                   /* Was that entity marked standalone */
};

/**
 * the parser can be asked to collect Node informations, i.e. at what
 * place in the file they were detected. 
 * NOTE: This is off by default and not very well tested.
 */
typedef struct _XOSxmlParserNodeInfo xmlParserNodeInfo;
typedef xmlParserNodeInfo *xmlParserNodeInfoPtr;

struct _XOSxmlParserNodeInfo 
{
  XCONST struct _XOSxmlNode* node;
  /* Position & line # that text that created the node begins & ends on */
  XU32 begin_pos;
  XU32 begin_line;
  XU32 end_pos;
  XU32 end_line;
};

typedef struct _XOSxmlParserNodeInfoSeq xmlParserNodeInfoSeq;
typedef xmlParserNodeInfoSeq *xmlParserNodeInfoSeqPtr;
struct _XOSxmlParserNodeInfoSeq 
{
  XU32 maximum;
  XU32 length;
  xmlParserNodeInfo* buffer;
};

/**
 * The parser is now working also as a state based parser
 * The recursive one use the stagte info for entities processing
 */
typedef enum 
{
    XML_PARSER_EOF = -1,	/* nothing is to be parsed */
    XML_PARSER_START = 0,	/* nothing has been parsed */
    XML_PARSER_MISC,		/* Misc* before XS32 subset */
    XML_PARSER_PI,		/* Whithin a processing instruction */
    XML_PARSER_DTD,		/* within some DTD content */
    XML_PARSER_PROLOG,		/* Misc* after internal subset */
    XML_PARSER_COMMENT,		/* within a comment */
    XML_PARSER_START_TAG,	/* within a start tag */
    XML_PARSER_CONTENT,		/* within the content */
    XML_PARSER_CDATA_SECTION,	/* within a CDATA section */
    XML_PARSER_END_TAG,		/* within a closing tag */
    XML_PARSER_ENTITY_DECL,	/* within an entity declaration */
    XML_PARSER_ENTITY_VALUE,	/* within an entity value in a decl */
    XML_PARSER_ATTRIBUTE_VALUE,	/* within an attribute value */
    XML_PARSER_EPILOG, 		/* the Misc* after the last end tag */
    /* added after 2.3.5 integration */
    XML_PARSER_SYSTEM_LITERAL,	/* within a SYSTEM value */
    XML_PARSER_IGNORE		/* within an IGNORED section */
} xmlParserInputState;

/**
 * The parser context.
 * NOTE This doesn't completely defines the parser state, the (current ?)
 *      design of the parser uses recursive function calls since this allow
 *      and easy mapping from the production rules of the specification
 *      to the actual code. The drawback is that the actual function call
 *      also reflect the parser state. However most of the parsing routines
 *      takes as the only argument the parser context pointer, so migrating
 *      to a state based parser for progressive parsing shouldn't be too hard.
 */
typedef struct _XOSxmlParserCtxt xmlParserCtxt;
typedef xmlParserCtxt *xmlParserCtxtPtr;
struct _XOSxmlParserCtxt 
{
    XVOID            *userData;        /* the document being built */
    xmlDocPtr           myDoc;        /* the document being built */
    XS32            wellFormed;        /* is the document well formed */
    XS32       replaceEntities;        /* shall we replace entities ? */
    XCONST xmlChar       *version;        /* the XML version string */
    XCONST xmlChar      *encoding;        /* encoding, if any */
    XS32            standalone;        /* standalone document */

    /* Input stream stack */
    xmlParserInputPtr  input;         /* Current input stream */
    XS32                inputNr;       /* Number of current input streams */
    XS32                inputMax;      /* Max number of input streams */
    xmlParserInputPtr *inputTab;      /* stack of inputs */

    /* Node analysis stack only used for DOM building */
    xmlNodePtr         node;          /* Current parsed Node */
    XS32                nodeNr;        /* Depth of the parsing stack */
    XS32                nodeMax;       /* Max depth of the parsing stack */
    xmlNodePtr        *nodeTab;       /* array of nodes */

    /*XS32 record_info;                  /* Whether node info should be kept */
    xmlParserNodeInfoSeq node_seq;    /* info about each node parsed */

    XS32 errNo;                        /* error code */

    XS32             hasPErefs;        /* the internal subset has PE refs */
    XS32              external;        /* are we parsing an external entity */

    XS32                 valid;        /* is the document valid */

    xmlParserInputState instate;      /* current type of input */
    XS32                 token;        /* next XS8 look-ahead */    

    XS8           *directory;        /* the data directory */

    /* Node name stack only used for HTML parsing */
    xmlChar           *name;          /* Current parsed Node */
    XS32                nameNr;        /* Depth of the parsing stack */
    XS32                nameMax;       /* Max depth of the parsing stack */
    xmlChar *         *nameTab;       /* array of nodes */

    XS32               nbChars;       /* number of xmlChar processed */
    XS32            checkIndex;       /* used by progressive parsing lookup */
    XS32             keepBlanks;       /* ugly but ... */

    /* Added after integration of 2.3.5 parser */
    XS32             disableSAX;       /* SAX callbacks are disabled */
    XS32               inSubset;       /* Parsing is in XS32 1/ext 2 subset */

    XS32                depth;         /* to prevent entity substitution loops */
    xmlParserInputPtr  entity;        /* used to check entities boundaries */
    XS32                charset;       /* encoding of the in-memory content
												actually an xmlCharEncoding */
    XS32                nodelen;       /* Those two fields are there to */
    XS32                nodemem;       /* Speed up large node parsing */
    XS32                pedantic;      /* signal pedantic warnings or loose
					 behaviour */
    XVOID              *_private;      /* For user data, libxml won't touch it */

};


xmlDocPtr  xmlParseFile(XCONST XS8 *filename);
xmlNodePtr xmlDocGetRootElement(xmlDocPtr doc);
XVOID xmlFreeDoc(xmlDocPtr cur);
XS32 xmlIsBlankNode(xmlNodePtr node);
xmlChar *xmlNodeListGetString(xmlDocPtr doc, xmlNodePtr list, XS32 inLine);
xmlChar * xmlGetProp(xmlNodePtr node, XCONST xmlChar *name);

#endif /*XOS_VXWORKS*/

#ifdef __cplusplus
}
#endif

#endif /* __XML_PARSER_H__ */

