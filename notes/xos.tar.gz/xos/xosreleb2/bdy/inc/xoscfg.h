/***************************************************************
**
**  Xinwei Telecom Technology co., ltd. ShenZhen R&D center
**  
**  Core Network Department  platform team  
**
**  filename: xosmodule.h
**
**  description: module managment defination 
**
**  author: wangzongyou
**
**  data:   2006.7.13
**
***************************************************************
**                          history                     
**  
***************************************************************
**   author          data              modification            
**************************************************************/
#ifndef _XOS_CONFIG_H_
#define _XOS_CONFIG_H_
#ifdef __cplusplus
extern "C" {
#endif /* _ _cplusplus */

/*-------------------------------------------------------------
                  ����ͷ�ļ�
--------------------------------------------------------------*/ 


/*-------------------------------------------------------------
                  �궨��
--------------------------------------------------------------*/

/*-------------------------------------------------------------
                  �ṹ��ö������
--------------------------------------------------------------*/



/* xos ƽ̨�ڲ�ģ���б�*/
typedef enum
{
	FID_XOSMIN = 0,
	FID_ROOT,
	FID_CLI,
	FID_TIME,
	FID_NTL,
	FID_IPC,	
	FID_TELNET,
	FID_TELNETD,	
	FID_TRACE,
	FID_FILE,
	FID_LOG,
	FID_IPCMGNT,
	FID_XOSMAX
	
}e_XOSFID;



/*-------------------------------------------------------------------------
              �ӿں���
-------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif /* _ _cplusplus */

#endif /* _XOS_CONFIG_H_ */

