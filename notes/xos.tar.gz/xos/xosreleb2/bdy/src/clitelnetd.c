/***************************************************************
**
**  Xinwei Telecom Technology co., ltd. ShenZhen R&D center
**  
**  Core Network Department  platform team  
**
**  filename: clitelnetd.c
**
**  description:  telnet server  
**
**  author: zhanglei 
**
**  data:   2006.9.4
**
***************************************************************
**                          history                     
**  
***************************************************************
**   author              data              modification            

**************************************************************/
#ifdef  __cplusplus
extern   "C"  {
#endif  /*  __cplusplus */

#include "xosxml.h"
#include "xostl.h"
#include "xoshash.h"
#include "clitelnetd.h"
#include "xosencap.h"
#include "xosmem.h"
#include "xosos.h"
#ifdef CLI_LOG
#include "clishell.h"
#endif

/*-------------------------------------------------------------------------
                                ģ���ڲ��궨��
-------------------------------------------------------------------------*/
#define TELNET_HANDLE            1
#define MAX_BUFF_SIZE            1024

/*-------------------------------------------------------------------------
                               ģ���ڲ����ݽṹ
-------------------------------------------------------------------------*/

/*Telnet D ���ݽṹ*/
typedef struct
{
    t_TelnetDCfg  telCfg;
    HLINKHANDLE   telLink;   
	t_IPADDR      clientIP[kCLI_MAX_CLI_TASK+1];
    XBOOL         tcpIsReady;	
} t_TelnetdCB;

/*-------------------------------------------------------------------------
                              ģ���ڲ�ȫ�ֱ���
-------------------------------------------------------------------------*/

XSTATIC t_TelnetdCB g_telnetdCb;

/*-------------------------------------------------------------------------
                             ģ���ڲ�����
-------------------------------------------------------------------------*/

XS32          telnetd_SendMsg2Clinet( t_XOSCOMMHEAD *pMsg );
XSTATIC XS32  telnetD_msgToNtl( XVOID* pContent, XS32 s32Len,  e_TLMSG msgType);
XSTATIC XS32  TelnetD_dataIndProc( t_XOSCOMMHEAD* pMsg );
XSTATIC XS32  telnetD_SendMsg2CLI( XU16 msgID, XS32 s32SID );
XSTATIC XS32  telnetD_MsgeConnIndProc( t_XOSCOMMHEAD* pMsg );
XSTATIC XS32  telnetD_MsgeInitAckProc( t_XOSCOMMHEAD* pMsg );

XSTATIC XBOOL telnetd_GetSessionIDByIP( t_IPADDR clientIP, XS32* p32SID );
XSTATIC XBOOL telnetd_GetClientIPBySessionID( XS32 s32SessionID, t_IPADDR* pIPAdd );
XSTATIC XBOOL telnetd_GetnewSessionIDByClientIP( t_IPADDR clientIP, XS32* p32SID );
XSTATIC XBOOL telnetd_ReleaseSIDByClientIP( t_IPADDR clientIP, XS32 *pSID );

XVOID telnetd_CLI2TelDShutdownClient( CLI_ENV* pCliEnv,  XS32 siArgc,  XCHAR **ppArgv );
XVOID telnetd_ShutdownTelClient( CLI_ENV* pCliEnv,  XS32 siArgc,  XCHAR **ppArgv );
/*-------------------------------------------------------------------------
                                       ģ��ӿں���
-------------------------------------------------------------------------*/

/************************************************************************
 ������:
 ����: 
 ����: 
 ���:
 ����:
 ˵��: ע�ᵽģ�������
************************************************************************/
XS8 TelnetD_Init( XVOID *p1, XVOID *p2 )
{
    XS32 ret  = 0; 

	p1 = p1;
	p2 = p2;

	XOS_MemSet( &g_telnetdCb, 0x00, sizeof( t_TelnetdCB ) );
    
    /*�������ļ�*/
    if( !XML_GetTelDCfgFromXosXml( &(g_telnetdCb.telCfg), "xos.xml") )
    {
         XOS_Trace(MD( FID_TELNETD, PL_ERR), "ERROR: read telnet server configure from xos.xml failed!"); 

#ifdef CLI_LOG
         cli_log_write( LOG_ERROR, "read telnet server configure from xos.xml failed!" );
#endif /* end  CLI_LOG  */
	
         return XERROR;
    }

	if ( 1 > g_telnetdCb.telCfg.maxTelClients || kCLI_MAX_CLI_TASK < g_telnetdCb.telCfg.maxTelClients )
	{
		XOS_Trace(MD( FID_TELNETD, PL_ERR), 
					  "ERROR: telnet cfg(connect number:%d) error!", 
					  g_telnetdCb.telCfg.maxTelClients ); 
#ifdef CLI_LOG
        cli_log_write( LOG_ERROR, 
		               "telnet client connect number %d is so biger than XOS CLI's kCLI_MAX_CLI_TASK = %d !",
				       g_telnetdCb.telCfg.maxTelClients,
					   kCLI_MAX_CLI_TASK);
#endif /* end  CLI_LOG  */
	     return XERROR;
	}

#ifdef CLI_LOG
        cli_log_write( LOG_NORMAL, 
		               "telnet client configure connect number %d, port:%d. !",
				       g_telnetdCb.telCfg.maxTelClients,
					   g_telnetdCb.telCfg.port );
#endif /* end  CLI_LOG  */

	g_telnetdCb.tcpIsReady = XFALSE;

	ret = 0;
	ret = XOS_RegistCmdPrompt( SYSTEM_MODE, "plat", "ƽ̨ģʽ", "�޲���" );
	if ( 0 > ret )
	{
		XOS_Trace( MD(FID_CLI, PL_ERR), "telnetd register command xos>plat failed!" );
	}
	if ( 0 > XOS_RegistCommand( ret, 
						        telnetd_CLI2TelDShutdownClient,
						        "showtelc",
						        "��ʾ CLI Telnet ������Ϣ.",
						        "������") )
	{
		XOS_Trace( MD(FID_CLI, PL_ERR), "telnetd register command xos>plat>showtelc failed!" );
#ifdef CLI_LOG 	
        cli_log_write( LOG_ERROR, "telnetd register command xos>plat>showtelc failed!" );
#endif /* end  CLI_LOG  */ 
	}

	if ( 0 > XOS_RegistCommand( ret, 
							    telnetd_ShutdownTelClient,
							    "shuttelc",
							    "�ر� CLI Telnet �ͻ�������",
							    "usage: shuttelc <SID>\r\ne.g:\r\n shuttelc 1\r\n") )
	{
		XOS_Trace( MD(FID_CLI, PL_ERR), "telnetd register command xos>plat>shuttelc failed!" );
#ifdef CLI_LOG 	
        cli_log_write( LOG_ERROR, "telnetd register command xos>plat>shuttelc failed!" );
#endif /* end  CLI_LOG  */ 
	}

#ifdef CLI_LOG 	
    cli_log_write( LOG_NORMAL, "telnet d init successfully!" );
#endif /* end  CLI_LOG  */ 

    return XSUCC;     
}

/************************************************************************
 ������: TelnetD_notice
 ����:   TelnetD ������Ϣ��������
 ����:   pMsg ����Ϣָ��
 ���:
 ����:   �ɹ�����XSUCC , ʧ�ܷ���XERROR 
 ˵��: 
************************************************************************/
XS8 TelnetD_notice( XVOID* p1, XVOID* p2)
{
	XS32 ret  = 0;
    t_LINKINIT linkInit;

	p1 = p1;
	p2 = p2;

    /*���� TCP Server ��·*/
    linkInit.appHandle = (HAPPUSER)TELNET_HANDLE;
    linkInit.linkType  = eTCPServer;
	linkInit.ctrlFlag  = eCompatibleTcpeen;
    ret = telnetD_msgToNtl( &linkInit, sizeof(t_LINKINIT), eLinkInit );
    if( XSUCC != XSUCC )
    {
          XOS_Trace(MD( FID_TELNETD, PL_ERR ), "ERROR: send msg to ntl error,start Telnet Server failed!");
#ifdef CLI_LOG 	
          cli_log_write( LOG_ERROR, "telnetD_msgToNtl() send msg to ntl error,start Telnet Server failed!" );
#endif /* end  CLI_LOG  */ 
          return XERROR;
    }

#ifdef CLI_LOG 	
    cli_log_write( LOG_NORMAL, "telnet d notice successfully!" );
#endif /* end  CLI_LOG  */ 
	
	return XSUCC;
}

/************************************************************************
 ������: TelnetD_msgProc()
 ����:  TelnetD ������Ϣ��������
 ����:  pMsg ����Ϣָ��
 ���:
 ����: �ɹ�����XSUCC , ʧ�ܷ���XERROR 
 ˵��: 
************************************************************************/
XS8 TelnetD_msgProc( XVOID *pMsg1, XVOID *pMsg2 )
{
	t_STARTACK     *pStartAck     = XNULL;	
	t_SENDERROR    *pErrorSend    = XNULL;
	t_LINKCLOSEIND *pLinkCloseInd = XNULL;
	t_XOSCOMMHEAD  *pMsg          = XNULL;
	XS32           ret            = 0; 
	XS32           s32SessionID   = 0;

	pMsg2 = pMsg2;
	
	/*������ڼ��*/
	if( pMsg1 == XNULLP )
	{
		XOS_Trace(MD( FID_TELNETD, PL_ERR), "IPC_msgProc() pMsg1 == XNULLP invalid input parameter!");
		return XERROR;
	}
	pMsg = (t_XOSCOMMHEAD*)pMsg1;	

	if ( FID_CLI == pMsg->datasrc.FID )
	{
		/*��������	APP->NTL */
		ret = telnetd_SendMsg2Clinet( pMsg );
		if( ret != XSUCC )
		{
			XOS_Trace(MD(FID_TELNETD, PL_ERR), "ERROR: telnetd_SendMsg2Clinet() send msg to ntl failed!");
			return XERROR;
		}
		return XSUCC;
	}
	
	if ( FID_NTL == pMsg->datasrc.FID )
	{
		switch (pMsg->msgID)
		{			
			/*��·��ʼ��ȷ�� NTL ->APP */
		case eInitAck:
			{			
				if ( XSUCC != telnetD_MsgeInitAckProc( pMsg ) )
				{
					XOS_Trace(MD( FID_TELNETD, PL_ERR), "msg InitAck Proc failed!" ); 
#ifdef CLI_LOG 	
				    cli_log_write( LOG_ERROR, "msg InitAck Proc failed!" );
#endif /*CLI_LOG*/
					return XERROR;
				}
			}         
			break;			
			
			/*��·����ȷ��	NTL ->APP */
		case eStartAck:
			{
				pStartAck = (t_STARTACK*)(pMsg->message);                                               
				if( pStartAck->linkStartResult == eSUCC )
				{
					g_telnetdCb.tcpIsReady = XTRUE;					 
				}
				else
				{
					/*����ʧ�ܴ���*/
					XOS_Trace(MD(FID_TELNETD, PL_ERR), "eStartAck msg  resault  error!");
#ifdef CLI_LOG 	
				    cli_log_write( LOG_ERROR, "eStartAck msg  resault  error!!" );
#endif /*CLI_LOG*/
					return XERROR;
				}
			}
			break;
			
			/* ���ݷ��ʹ��� NTL ->APP */
		case eErrorSend:
			{
				pErrorSend = (t_SENDERROR*)(pMsg->message);
#ifdef CLI_LOG 	
				cli_log_write( LOG_ERROR, "data send error(NTL ->APP), resion: %d", pErrorSend->errorReson );
#endif /*CLI_LOG*/ 
				XOS_Trace(MD( FID_TELNETD, PL_ERR), "data send error(NTL ->APP), resion: %d", pErrorSend->errorReson ); 
			}
			break;
			
			/*����ָʾ NTL ->APP */
		case eConnInd:
			{
				if ( XSUCC != telnetD_MsgeConnIndProc( pMsg ) )
				{
					XOS_Trace(MD( FID_TELNETD, PL_ERR), "Msg ConnInd Proc failed!" ); 
#ifdef CLI_LOG 	
				    cli_log_write( LOG_ERROR, "Msg ConnInd Proc failed!" );
#endif /*CLI_LOG*/
					return XERROR;
				}
			}
			break;
			
			/*�յ����� NTL ->APP*/
		case eDataInd:
			{
#ifdef CLI_LOG 	
				cli_log_write( LOG_DEBUG, " TELNETD received msg eDataInd!" );
#endif /*CLI_LOG*/ 

				if ( XSUCC != TelnetD_dataIndProc( pMsg ) )
				{
					XOS_Trace(MD( FID_TELNETD, PL_ERR), "eDataInd -> TelnetD_dataIndProc error" );
#ifdef CLI_LOG 	
				    cli_log_write(  LOG_ERROR, "eDataInd -> TelnetD_dataIndProc error" );
#endif /*CLI_LOG*/
					return XERROR;
				}
			}
			break;
			
			/* ��·�ر�ָʾ NTL ->APP*/	 
		case eStopInd:
			{
#ifdef CLI_LOG 	
				cli_log_write( LOG_DEBUG, " TELNETD received msg eStopInd!" );
#endif /*CLI_LOG*/

				pLinkCloseInd = (t_LINKCLOSEIND*)(pMsg->message);
				if ( XNULL == pLinkCloseInd )
				{
					XOS_Trace(MD( FID_TELNETD, PL_ERR), "XNULL == pLinkCloseInd" );
					return XERROR;
				}

				s32SessionID = 0;
				if( telnetd_ReleaseSIDByClientIP( pLinkCloseInd->peerAddr, &s32SessionID )	)
				{
				    if ( XSUCC == telnetD_SendMsg2CLI( MSG_IP_CLOSEIND, s32SessionID ) )
					{
#ifdef CLI_LOG 	
						cli_log_write(  LOG_NORMAL, 
							            "client closed, ip: %x, port: %d, session id: %d.",
										pLinkCloseInd->peerAddr.ip,
										pLinkCloseInd->peerAddr.port,
										s32SessionID );

#endif /*CLI_LOG*/
						return XSUCC;
					}
					else
					{
						XOS_Trace(MD( FID_TELNETD, PL_ERR),  
							          "send msg 2 CLI, try to close client(ip: %x, port: %d, session id: %d) failed!",
									  pLinkCloseInd->peerAddr.ip,
									  pLinkCloseInd->peerAddr.port,
									  s32SessionID );
#ifdef CLI_LOG 	
						cli_log_write(  LOG_ERROR, 
							            "send msg 2 CLI, try to close client(ip: %x, port: %d, session id: %d) failed!",
										pLinkCloseInd->peerAddr.ip,
										pLinkCloseInd->peerAddr.port,
										s32SessionID );

#endif /*CLI_LOG*/
					}
				}
			}
			break;
		
		default:			
			break;
		 }		 
	 }
     
     return XSUCC;
}

/************************************************************************
 ������:telnetd_SendMsg2Clinet
 ����:  ������Ϣ�� Telnet Client
 ����:  pMsg -��Ҫת������Ϣ
 ���:
 ����: �ɹ�����XSUCC , ʧ�ܷ���XERROR 
 ˵��:
************************************************************************/
XS32 telnetd_SendMsg2Clinet( t_XOSCOMMHEAD *pMsg )
{
    t_IPADDR clientAddr;
    t_DATAREQ dataReq;
	XCHAR* pData = XNULL;

    if(pMsg == XNULLP)
    {
		XOS_Trace( MD(FID_TELNETD, PL_ERR), "telnetd_SendMsg2Clinet() pMsg == XNULLP" );
        return XERROR;
    }

    /*�ȼ�� Telnet �ķ����ǲ��ǳɹ�*/
    if( !g_telnetdCb.tcpIsReady )
    {
		 XOS_Trace( MD(FID_TELNETD, PL_ERR), "g_telnetdCb.tcpIsReady = XFALSE." );
         return XERROR;
    }
    
    /*���Ҷ�Ӧ�� telnet client ��ַ*/
    if ( !telnetd_GetClientIPBySessionID( pMsg->subID, &clientAddr ) )
	{
		XOS_Trace( MD(FID_TELNETD, PL_ERR), "telnetd_GetClientIPBySessionID() failed!" );
		return XERROR;
	}
	
	pData = XOS_MemMalloc( FID_TELNETD, pMsg->length );
	if ( XNULL == pData )
	{
		 XOS_Trace( MD(FID_TELNETD, PL_ERR), "data malloc length %d failed!", pMsg->length );
		 return XERROR;
	}
	XOS_MemCpy( pData, pMsg->message, pMsg->length );

#ifdef CLI_LOG
	cli_log_write( LOG_DEBUG, " rev from CLI msg send NTL: %s", (XCHAR*)pMsg->message );
#endif /*CLI_LOG*/
   
    /*��������������Ϣ*/ 
    XOS_MemSet( &dataReq, 0, sizeof(t_DATAREQ) );

    dataReq.dstAddr.ip   = clientAddr.ip;
	dataReq.dstAddr.port = clientAddr.port;

    dataReq.linkHandle = g_telnetdCb.telLink;
    dataReq.msgLenth   = pMsg->length;
    dataReq.pData      = (XCHAR*)pData;

#ifdef CLI_LOG
	cli_log_write( LOG_DEBUG, "msg send 2 NTL: %s", dataReq.pData );
#endif /*CLI_LOG*/

  
    /*������Ϣ�� ntl */
    if ( XSUCC != telnetD_msgToNtl( &dataReq, sizeof(t_DATAREQ), eSendData ) )
	{
		XOS_Trace( MD(FID_TELNETD, PL_ERR), "telnetD_msgToNtl failed!" );
		return XERROR;
	}

    return XSUCC; 
}


XSTATIC XS32 telnetD_msgToNtl( XVOID* pContent, XS32 s32Len,  e_TLMSG msgType)
{
    XS32 s32Ret         = 0;
    t_XOSCOMMHEAD *pMsg = XNULL;
    
    if( XNULLP       == pContent  
		|| 0         >= s32Len
		|| eMinTlMsg >= msgType 
		|| eMaxTlMsg <= msgType )
    {
		XOS_Trace( MD(FID_TELNETD, PL_ERR), "telnetD_msgToNtl() parameter invalidate!" );
		return XERROR;
    }
	
	/*������Ϣ�ڴ�*/
	pMsg = (t_XOSCOMMHEAD*)XNULLP;
	pMsg = XOS_MsgMemMalloc( (XU32)FID_TELNETD, s32Len );
	if( pMsg == XNULLP )
	{
		XOS_Trace( MD(FID_TELNETD, PL_ERR), "XOS_MsgMemMalloc failed!" );
		return XERROR;
	}
	
	/*��д��Ϣ����*/
	pMsg->datasrc.PID  = XOS_GetLocalPID();
	pMsg->datasrc.FID  = (XU32)FID_TELNETD;

	pMsg->length       = s32Len;
	pMsg->msgID        = msgType;
	pMsg->prio         = eNormalMsgPrio;

	pMsg->datadest.FID = (XU32)FID_NTL;
	pMsg->datadest.PID = XOS_GetLocalPID();
	XOS_MemCpy( pMsg->message, pContent, s32Len );
	
	/*��������*/
	s32Ret = XOS_MsgSend( pMsg );
	if( XSUCC != s32Ret )
	{
		/*������Ϣ����Ӧ�ý���Ϣ�ڴ��ͷ�*/
		XOS_MsgMemFree( (XU32)FID_TELNETD, pMsg );
		
		XOS_Trace( MD(FID_TELNETD, PL_ERR), "XOS_MsgSend() failed!" );
		return XERROR;
	}
	
	return XSUCC;   
}

/************************************************************************
 ������: TelnetD_dataIndProc()
 ����:   ������ntl�յ�������
 ����:   pMsg ����Ϣ���ݵ��׵�ַ            
 ���:
 ����: �ɹ�����XSUCC , ʧ�ܷ���XERROR 
 ˵��: 
************************************************************************/
XSTATIC XS32 TelnetD_dataIndProc( t_XOSCOMMHEAD* pMsg )
{	
	t_DATAIND     *pDataInd   = XNULL;
	XS32 s32SubID             = 0;
	t_XOSCOMMHEAD* pTelnetMsg = XNULL;

    if( XNULL == pMsg )
    {  
		XOS_Trace( MD(FID_TELNETD, PL_ERR), "TelnetD_dataIndProc() parameter invalidate!" );
		return XERROR;
    }
    pDataInd = (t_DATAIND*)(pMsg->message);
    if( XNULLP == pDataInd || XNULLP == pDataInd->pData )
    {
		XOS_Trace( MD(FID_TELNETD, PL_ERR), "XNULLP == pDataInd || XNULLP == pDataInd->pData!" );
		return XERROR;
    }
	
    switch ( (XU32)(pDataInd->appHandle) )
    {
	case TELNET_HANDLE:
		{
			if ( !telnetd_GetSessionIDByIP( pDataInd->peerAddr, &s32SubID ) )
			{
				XOS_Trace( MD(FID_TELNETD, PL_ERR), 
						   "unkonw client ip %x, port:%d", 
						   pDataInd->peerAddr.ip,
						   pDataInd->peerAddr.port  );
#ifdef CLI_LOG 	
    cli_log_write( LOG_ERROR, "unkonw client ip %x, port:%d", 
				   pDataInd->peerAddr.ip,
				   pDataInd->peerAddr.port );
#endif /* end  CLI_LOG  */ 

				return XERROR;
			}

			if ( pDataInd->dataLenth < 1 )
			{
				XOS_Trace( MD(FID_TELNETD, PL_ERR), "pDataInd->dataLenth < 1" );
				return XERROR; 
			}
			
			pTelnetMsg = XOS_MsgMemMalloc( FID_TELNETD, pDataInd->dataLenth );
			if ( XNULLP == pTelnetMsg )
			{
				XOS_Trace( MD(FID_TELNETD, PL_ERR), "XOS_MsgMemMalloc() failed!" );
				return XERROR;
			}

			pTelnetMsg->datasrc.FID    = FID_TELNETD;
			pTelnetMsg->datasrc.FsmId  = 0;
   			pTelnetMsg->datasrc.PID    = 0;

			pTelnetMsg->datadest.FID   = FID_CLI;
			pTelnetMsg->datadest.FsmId = 0;
   			pTelnetMsg->datadest.PID   = 0;
			pTelnetMsg->prio           = eAdnMsgPrio;
			pTelnetMsg->msgID          = MSG_IP_DATAIND;
			pTelnetMsg->subID          = s32SubID;

			XOS_MemCpy( pTelnetMsg->message, pDataInd->pData,  pDataInd->dataLenth );

#ifdef CLI_LOG 	
    cli_log_write( LOG_DEBUG, "msg send NTL 2 CLI: %s.", (XCHAR*)pDataInd->pData );
#endif /* end  CLI_LOG  */ 

			if ( XSUCC != XOS_MsgSend( pTelnetMsg ) )
			{
				/*��������*/
				XOS_MsgMemFree( FID_TELNET, pTelnetMsg );
			}	
			
			return XSUCC;
		}
		break;
		
	default:
		break;
    }
	
    return XERROR;
}

/************************************************************************
 ������: telnetD_MsgeConnIndProc()
 ����:   ������ntl�յ���eConnInd��Ϣ
 ����:   pMsg ����Ϣ���ݵ��׵�ַ            
 ���:
 ����: �ɹ�����XSUCC , ʧ�ܷ���XERROR 
 ˵��: 
************************************************************************/
XSTATIC XS32 telnetD_MsgeConnIndProc( t_XOSCOMMHEAD* pMsg )
{
	t_DATAIND      *pDataInd    = XNULL;
	t_XOSCOMMHEAD  *pSen2CLIMsg = XNULL;
	XS32 s32SID = 0;

	if ( XNULL == pMsg )
	{
		XOS_Trace( MD(FID_TELNETD, PL_ERR), "telnetD_MsgeConnIndProc() parameter invalidate!" );
		return XERROR;
	}

	pDataInd = (t_DATAIND*)(pMsg->message);
	if( pDataInd == XNULL )
	{
		XOS_Trace(MD( FID_TELNETD, PL_ERR), "pDataInd == XNULL!");
		return XERROR;
	}
	
	if ( TELNET_HANDLE !=  (XU32)(pDataInd->appHandle) )
	{
		XOS_Trace(MD( FID_TELNETD, PL_ERR), "TELNET_HANDLE !=  pDataInd->appHandle.");
		return XERROR;
	}

	if ( !telnetd_GetnewSessionIDByClientIP( pDataInd->peerAddr, &s32SID ) )
	{
		XOS_Trace(MD( FID_TELNETD, PL_ERR), " telnetd_GetnewSessionIDByClientIP failed.");
		return XERROR;
	}

#ifdef CLI_LOG 	
	cli_log_write(  LOG_NORMAL, 
					"new telnet client connection, Session ID: %d,IP:%x, Port:%d.",
					s32SID,
					pDataInd->peerAddr.ip,
					pDataInd->peerAddr.port );
#endif /* end  CLI_LOG  */ 

	pSen2CLIMsg = (t_XOSCOMMHEAD*)XOS_MsgMemMalloc( (XU32)FID_TELNET, 1 );

	pSen2CLIMsg->datasrc.FID    = FID_TELNETD;
	pSen2CLIMsg->datasrc.FsmId  = 0;
   	pSen2CLIMsg->datasrc.PID    = 0;

	pSen2CLIMsg->datadest.FID   = FID_CLI;
	pSen2CLIMsg->datadest.FsmId = 0;
   	pSen2CLIMsg->datadest.PID   = 0;
	pSen2CLIMsg->prio           = eAdnMsgPrio;
	pSen2CLIMsg->msgID          = MSG_IP_CONNECTIND;
	pSen2CLIMsg->subID          = s32SID;

	XOS_MemCpy( pSen2CLIMsg->message, "", pSen2CLIMsg->length );

	if ( XSUCC != XOS_MsgSend( pSen2CLIMsg ) )
	{
		/*��������*/
		XOS_MsgMemFree( FID_TELNET, pSen2CLIMsg );

		return XERROR;
	}
	
	return XSUCC;
}



/************************************************************************
 ������: TelnetD_SendMsg2CLI()
 ����:   ������Ϣ��CLI
 ����:   pMsg ����Ϣ���ݵ��׵�ַ            
 ���:
 ����: �ɹ�����XSUCC , ʧ�ܷ���XERROR 
 ˵��: 
************************************************************************/
XSTATIC XS32 telnetD_SendMsg2CLI( XU16 msgID, XS32 s32SID )
{
	t_XOSCOMMHEAD  *pSen2CLIMsg = XNULL;

	pSen2CLIMsg = (t_XOSCOMMHEAD*)XOS_MsgMemMalloc( (XU32)FID_TELNET, 1 );

	pSen2CLIMsg->datasrc.FID    = FID_TELNETD;
	pSen2CLIMsg->datasrc.FsmId  = 0;
   	pSen2CLIMsg->datasrc.PID    = 0;

	pSen2CLIMsg->datadest.FID   = FID_CLI;
	pSen2CLIMsg->datadest.FsmId = 0;
   	pSen2CLIMsg->datadest.PID   = 0;
	pSen2CLIMsg->prio           = eAdnMsgPrio;
	pSen2CLIMsg->msgID          = msgID;
	pSen2CLIMsg->subID          = (XU16)s32SID;

	if ( msgID != MSG_IP_CLOSEIND )
	{
		XOS_MemCpy( pSen2CLIMsg->message, "", 1 );
	}

	if ( XSUCC != XOS_MsgSend( pSen2CLIMsg ) )
	{
		/*��������*/
		XOS_MsgMemFree( FID_TELNET, pSen2CLIMsg );
		XOS_Trace( MD(FID_TELNETD, PL_ERR), "XOS_MsgSend() failed!" );
		return XERROR;
	}

	return XSUCC;
}


/************************************************************************
 ������: telnetD_MsgeInitAckProc()
 ����:   ������ntl�յ��� eInitAck ��Ϣ
 ����:   pMsg ����Ϣ���ݵ��׵�ַ            
 ���:
 ����: �ɹ�����XSUCC , ʧ�ܷ���XERROR 
 ˵��: 
************************************************************************/
XSTATIC XS32 telnetD_MsgeInitAckProc( t_XOSCOMMHEAD* pMsg )
{
	t_LINKINITACK  *pLinkAck = XNULL;
	t_LINKSTART    telnetStart;
	XS32 s32Ret    = -1;

	if ( XNULL == pMsg )
	{
		XOS_Trace( MD(FID_TELNETD, PL_ERR), "telnetD_MsgeInitAckProc() parameter invalidate!" );
		return XERROR; 
	}

	pLinkAck = (t_LINKINITACK*)(pMsg->message);
	if( pLinkAck == XNULL )
	{
		XOS_Trace(MD( FID_TELNETD, PL_ERR), "pLinkAck == XNULL!");
		return XERROR;
	} 
	
	/*��鷵�صĽ��*/
	if( pLinkAck->lnitAckResult != eSUCC )
	{
		XOS_Trace(MD(FID_TELNETD, PL_ERR), "lnitAckResult != eSUCC!");
		return XERROR;
	}

	if ( TELNET_HANDLE != (XU32)(pLinkAck->appHandle ) )
	{
		XOS_Trace(MD(FID_TELNETD, PL_ERR), "appHandle != TELNET_HANDLE!");
		return XERROR;
	}
					 
	/* ��¼linkHandle */
	g_telnetdCb.telLink = pLinkAck->linkHandle;
	
	/*������·*/
	XOS_MemSet( &telnetStart, 0x00, sizeof(t_LINKSTART) );
	
	telnetStart.linkStart.tcpServerStart.allownClients = g_telnetdCb.telCfg.maxTelClients;
	telnetStart.linkStart.tcpServerStart.authenFunc    = XNULL;
	telnetStart.linkStart.tcpServerStart.myAddr.ip     = 0;
	telnetStart.linkStart.tcpServerStart.myAddr.port   = g_telnetdCb.telCfg.port;
	
	telnetStart.linkHandle = pLinkAck->linkHandle;
	
	s32Ret = telnetD_msgToNtl( &telnetStart, sizeof(t_LINKSTART), eLinkStart );
	if( s32Ret != XSUCC )
	{
		XOS_Trace(MD(FID_TELNETD, PL_ERR), "ERROR: telnetD_msgToNtl send eLinkStart msg  failed!");
		return XERROR;
	}	

	return XSUCC;
}

/************************************************************************
 ������: telnetd_GetSessionIDByIP()
 ����:   
 ����:               
 ���:
 ����:  
 ˵��: 
************************************************************************/ 
XSTATIC XBOOL telnetd_GetSessionIDByIP( t_IPADDR clientIP, XS32* p32SID )
{
	XS32 i = 0;

	if ( XNULL == p32SID )
	{
		return XFALSE; 
	}

	for( i = 1; i <= kCLI_MAX_CLI_TASK; i++ )
	{
		if (   ( g_telnetdCb.clientIP[i].ip   == clientIP.ip ) 
			&& ( g_telnetdCb.clientIP[i].port == clientIP.port ) )
		{
			*p32SID = i;
			return XTRUE;
		}
	}

	return XFALSE;
}

/************************************************************************
 ������: telnetd_GetClientIPBySessionID()
 ����:   
 ����:               
 ���:
 ����:  
 ˵��: 
************************************************************************/ 
XSTATIC XBOOL  telnetd_GetClientIPBySessionID( XS32 s32SessionID, t_IPADDR* pIPAdd )
{
	if ( XNULL == pIPAdd  || 1 > s32SessionID || kCLI_MAX_CLI_TASK < s32SessionID )
	{
		return XFALSE;
	}
	XOS_MemSet( pIPAdd, 0x00, sizeof( t_IPADDR ) );

	if (  0 < s32SessionID || kCLI_MAX_CLI_TASK >= s32SessionID )
	{
		pIPAdd->ip   = g_telnetdCb.clientIP[s32SessionID].ip;
		pIPAdd->port = g_telnetdCb.clientIP[s32SessionID].port;

		return XTRUE;
	}

	return XFALSE;
}

/************************************************************************
 ������: telnetd_ReleaseSIDByClientIP()
 ����:   
 ����:               
 ���:
 ����:  
 ˵��: 
************************************************************************/ 
XSTATIC XBOOL telnetd_ReleaseSIDByClientIP( t_IPADDR clientIP, XS32 *pSID )
{
	XS32 s32SessionID = -1;

	if ( XNULL == pSID )
	{
		return XTRUE;
	}

	if ( telnetd_GetSessionIDByIP( clientIP, &s32SessionID ) )
	{
		g_telnetdCb.clientIP[s32SessionID].port = 0;
		g_telnetdCb.clientIP[s32SessionID].ip   = 0;

		*pSID = s32SessionID;

		return XTRUE;
	}

	return XFALSE;
}

/************************************************************************
 ������: telnetd_GetnewSessionIDByClientIP()
 ����:   
 ����:               
 ���:
 ����:  
 ˵��: 
************************************************************************/ 
XSTATIC XBOOL telnetd_GetnewSessionIDByClientIP( t_IPADDR clientIP, XS32* p32SID )
{
	XS32  s32SID = 1;

	if ( XNULL == p32SID )
	{
		return XFALSE;
	}

	while (  0      != g_telnetdCb.clientIP[ s32SID ].ip 
		  && 0      != g_telnetdCb.clientIP[ s32SID ].port
		  && s32SID <= g_telnetdCb.telCfg.maxTelClients 
		  && s32SID <= kCLI_MAX_CLI_TASK )
	{
		s32SID++;
	}

	if ( kCLI_MAX_CLI_TASK < s32SID )
	{
		return XFALSE;
	}
	
	/*����*/
	g_telnetdCb.clientIP[ s32SID ].ip   = clientIP.ip;
	g_telnetdCb.clientIP[ s32SID ].port = clientIP.port;

	*p32SID = s32SID;

	return XTRUE;
}


/************************************************************************
 ������: telnetd_ShutdownTelClient(  )
 ����:   shuttelc �����.
 ����:   ��
 ���:   ��
 ����:	 ��
 ˵��:
************************************************************************/
XVOID telnetd_ShutdownTelClient( CLI_ENV* pCliEnv,  XS32 siArgc,  XCHAR **ppArgv )
{
	XS32  s32Value            = 0;
	XCHAR buff[MAX_BUFF_SIZE] = {0};

	XOS_CliExtPrintf( pCliEnv, "\r\n" );
	
	if ( 2 != siArgc )
	{
		XOS_CliExtPrintf( pCliEnv, "usage: shuttelc <SID>\r\ne.g:\r\n shuttelc 1\r\n");
		return;
	}
	
	XOS_StrToNum( ppArgv[ siArgc - 1 ], &s32Value );
	if ( 1 > s32Value || kCLI_MAX_CLI_TASK < s32Value )
	{
		XOS_CliExtPrintf( pCliEnv, "SID: %d error\r\n", s32Value );
		return ;
	}
	
	if ( 0 == g_telnetdCb.clientIP[s32Value].ip 
	  && 0 == g_telnetdCb.clientIP[s32Value].port )
	{
		XOS_CliExtPrintf( pCliEnv, "SID: %d error\r\n", s32Value );
		return;
	}
	
	if ( XSUCC == telnetD_SendMsg2CLI( MSG_IP_CLOSEIND, s32Value ) )
	{
		if ( telnetd_ReleaseSIDByClientIP( g_telnetdCb.clientIP[s32Value], &s32Value ) )
		{
			if ( XSUCC != XOS_IpNtoStr( g_telnetdCb.clientIP[s32Value].ip, buff, MAX_BUFF_SIZE ) )
			{
				return ;
			}
			XOS_CliExtPrintf( pCliEnv, 
							  "close telnet clinet(Session ID: %d,IP Adress: %s port: %d).\r\n", 
							  s32Value,
							  buff,
							  g_telnetdCb.clientIP[s32Value].port );
#ifdef CLI_LOG 	
			cli_log_write(  LOG_NORMAL,  
							"closed telnet clinet(Session ID: %d,IP Adress: %s port: %d).\r\n", 
							s32Value,
							buff,
							g_telnetdCb.clientIP[s32Value].port);
			
#endif /*CLI_LOG*/
		}
		return ;
	}	
				
    return ;
}


/************************************************************************
 ������: telnetd_CLI2TelDShutdownClient( XVOID )
 ����:   CLI �����.
 ����:   ��
 ���:   ��
 ����:	 ��
 ˵��:
************************************************************************/
XVOID telnetd_CLI2TelDShutdownClient( CLI_ENV* pCliEnv,  XS32 siArgc,  XCHAR **ppArgv )
{
	XS32 i                    = 0;
	XCHAR buff[MAX_BUFF_SIZE] = {0};
	XBOOL bFound              = XFALSE;

	XOS_CliExtPrintf( pCliEnv, "\r\n");

	for ( i = 1; i <= kCLI_MAX_CLI_TASK; i++ )
	{
		if (   0 == g_telnetdCb.clientIP[i].ip 
			&& 0 == g_telnetdCb.clientIP[i].port )
		{
			continue;
		}
		if ( XSUCC == XOS_IpNtoStr( g_telnetdCb.clientIP[i].ip, buff, MAX_BUFF_SIZE ) )
		{
			XOS_CliExtPrintf( pCliEnv, 
							  "telnet clinet(Session ID: %d,IP Adress: %s port: %d) online.\r\n", 
							  i,
							  buff,
							  g_telnetdCb.clientIP[i].port );

			bFound = XTRUE;
		}
	}

	if ( !bFound )
	{
		XOS_CliExtPrintf( pCliEnv, "can't find telnet clinet connetion.\r\n");
	}

	return ;
}

#ifdef  __cplusplus
}
#endif  /*  __cplusplus */




