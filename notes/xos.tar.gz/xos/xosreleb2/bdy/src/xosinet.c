/***************************************************************
**
**  Xinwei Telecom Technology co., ltd. ShenZhen R&D center
**  
**  Core Network Department  platform team  
**
**  filename: xosinet.c
**
**  description:  for windows 
**
**  author: wangzongyou
**
**  data:   2006.3.7
**
***************************************************************
**                          history                     
**  
***************************************************************
**   author          data              modification            
**   wangzongyou         2006.3.7              create  
**************************************************************/
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


/*------------------------------------------------------------------------
                  ����ͷ�ļ�
-------------------------------------------------------------------------*/ 
#include "xosinet.h"

#include "xostrace.h"
#include "xoscfg.h"
#include "xosmem.h"
#include "xosencap.h"



/*-------------------------------------------------------------------------
                 ģ���ڲ��궨��
-------------------------------------------------------------------------*/

#ifdef XOS_WIN32

#define INET_ERR             SOCKET_ERROR
#define INET_ERR_CODE        WSAGetLastError()
#define ERR_INPROGRESS       WSAEINPROGRESS  
#define ERR_ISCONN           WSAEISCONN
#define ERR_WOULDBLOCK       WSAEWOULDBLOCK
#define ERR_INADDRNONE       INADDR_NONE
#define ERR_NOTCONN          WSAENOTCONN
#define ERR_ALREADY          WSAEALREADY
#define ERR_AGAIN            WSAEWOULDBLOCK 
#define ERR_INVAL            WSAEINVAL
#define ERR_CONNREFUSED       WSAECONNREFUSED
#define ERR_PIPE             WSAENOTCONN
/* Changed ERR_TIMEOUT for pSos compilation */
#define ERR_TIMEDOUT         WSAETIMEDOUT
#define ERR_CONNRESET        WSAECONNRESET
#define ERR_CONNABORTED      WSAECONNABORTED
#else
#define INET_ERR             -1
#define INET_ERR_CODE        errno
#define ERR_INPROGRESS       EINPROGRESS
#define ERR_ISCONN           EISCONN
#define ERR_WOULDBLOCK       EWOULDBLOCK
#define ERR_INADDRNONE       -1
#define ERR_NOTCONN          ENOTCONN       
#define ERR_ALREADY          EALREADY
#define ERR_AGAIN            EAGAIN
/* EINVAL is not mapped because it is a valid error code here */
#define ERR_INVAL            0 
#define ERR_CONNREFUSED      ECONNREFUSED
#define ERR_PIPE             EPIPE 
/* Changed ERR_TIMEOUT for pSos compilation */
#define ERR_TIMEDOUT         ETIMEDOUT
#define ERR_CONNRESET        ECONNRESET
#define ERR_CONNABORTED      ECONNABORTED
#endif /* XOS_WIN32 */

/* added a win2k specific defines in. */
#ifdef XOS_WIN32
#ifdef WIN2K
#ifndef SIO_UDP_CONNRESET
#define SIO_UDP_CONNRESET _WSAIOW(IOC_VENDOR, 12)
#endif 
#endif /*WIN2K*/
#endif /*XOS_WIN32*/

#define XOS_INET_IPV4ADDR_SIZE      4

/*sock ��İ汾��Ϣ*/
#define XOS_INET_HIGH_VER     2
#define XOS_INET_LOW_VER      2

/* ת�� ASCII �� int  */
#define XOS_INET_ATOI(_intVal, _asciiVal)                                  \
{                                                                         \
   _intVal = (10 * _intVal) + (_asciiVal - '0');                          \
}


#define XOS_INET_GET_IPV4_ADDR_FRM_STRING(_value, _str)                    \
{                                                                         \
   XU16     _hiWord;                                                       \
   XU16     _loWord;                                                       \
                                                                          \
   _hiWord = 0;                                                           \
   _loWord = 0;                                                           \
   _hiWord = XOS_PutHiByte(_hiWord, (_str[0]));                               \
   _hiWord = XOS_PutLoByte(_hiWord, (_str[1]));                               \
   _loWord = XOS_PutHiByte(_loWord, (_str[2]));                               \
   _loWord = XOS_PutLoByte(_loWord, (_str[3]));                               \
   _value  = XOS_PutLoWord(_value, _loWord);                                  \
   _value  = XOS_PutHiWord(_value, _hiWord);                                  \
}

/*-------------------------------------------------------------------------
                 ģ���ڲ��ṹ��ö�ٶ���
-------------------------------------------------------------------------*/


/*-------------------------------------------------------------------------
                ģ���ڲ�ȫ�ֱ���
-------------------------------------------------------------------------*/


/*-------------------------------------------------------------------------
                ģ���ڲ�����
-------------------------------------------------------------------------*/
/************************************************************************
������:	XINET_AsciiToIpv4
���ܣ��ַ�����ip��ַת��
���룺pSockFd �� ������
                 backLog  ������ͬʱ���ӵ�������
�����
���أ�XSUCC         - successful
                XERROR     - failed                
˵����
************************************************************************/
XSTATIC XS16 XINET_AsciiToIpv4(XU8 numBytes, XCHAR* ipv4Addr, XU16 len, XCHAR* val)
{
   XU8              byteCount;          /* Byte Count */
   XU8              idx;                /* Index for string*/

   idx = 0;
   for (byteCount = 0; byteCount < numBytes; byteCount++)
   {
      while((val[idx] != '.') && (idx < len))
      {
#if (INPUT_PAR_CHECK)
         if (val[idx] < '0' || val[idx] > '9')
         {
            /* Not a digit */
            return(XERROR);
         }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

         /* Convert Ascii to integer */
         XOS_INET_ATOI(ipv4Addr[byteCount], val[idx]);

         /* move to the next index */
         idx++;
      }
      idx++;
   }
   
   return(XSUCC);
} 


/*-------------------------------------------------------------------------
                ģ��ӿں���
-------------------------------------------------------------------------*/

/************************************************************************
������:	XINET_Init
���ܣ���ʼ��sock lib��
���룺
�����
���أ�XSUCC	-	�ɹ�
		   XERROR	-	��Ҫָ��������		   
˵�����ڵ������е�sock����ǰ���ã�ֻ��window����Ҫ��
                 ��ȡ������Ϣʱ�õ���
************************************************************************/
XPUBLIC XS16 XINET_Init(void)
{

#ifdef XOS_WIN32

   XU16     version;
   XS32     err;
   WSADATA data;
 
   version = MAKEWORD(XOS_INET_HIGH_VER, XOS_INET_LOW_VER);
   err = WSAStartup(version, &data);
   if (err != 0)
   {
      return(XERROR);
   }
   
#endif
   
   return(XSUCC);
}

/************************************************************************
������:	XINET_GetNumRead
���ܣ���ȡ��ǰ���Զ������ݳ���
���룺pSockFd �� ������
               
�����dataLen  �� ���ݳ���
���أ�XSUCC         - successful
                XERROR     - failed                
˵����
************************************************************************/
XPUBLIC XS16 XINET_GetNumRead(t_XINETFD *sockFd, XU32* dataLen)
{
   XS32 ret;                     /* temporary return value */

#if (INPUT_PAR_CHECK)
   /* error check on parameters */
   if ((sockFd == XNULLP) || XOS_INET_INV_SOCK_FD(sockFd) ||
       (dataLen == XNULLP))
   {
      return(XERROR);
   }
#endif

#ifdef XOS_WIN32
   ret = ioctlsocket(sockFd->fd, FIONREAD, (u_long *)dataLen);     
#else 
#ifdef XOS_VXWORKS
   ret = ioctl(sockFd->fd, FIONREAD, (XS32)dataLen);
#else
   ret = ioctl(sockFd->fd, FIONREAD, dataLen);
#endif /* XOS_VXWORKS */
#endif /* XOS_WIN32 */
   

   /* For UDP socket assign the length of pending data in the 
      socket recv buffer to largest datagram size. 
      Removed recvfrom call & necessary processing for it. */
   
   if (ret == INET_ERR)
   {
      /* removed error check CONABORTED added for recvfrom call. 
         Also return value changed from RCLOSED to XSUCC */
      /*  Check for reset connection */
      if ((INET_ERR_CODE == ERR_CONNREFUSED) ||
          (INET_ERR_CODE == ERR_CONNRESET))
      {
         *dataLen = 0;
         return(XSUCC);
      }
     
      /* removed error check ERR_WOULDBLOCK */ 
      if (INET_ERR_CODE == ERR_AGAIN)
      {
         *dataLen = 0;
         return(XERROR);
      }

      return(XERROR);
   }

   return(XSUCC);
} /* end of cmInetGetNumRead */


/************************************************************************
������:	XINET_SendMsg
���ܣ��������ݵ�����
���룺pSockFd  ��sock ������ָ��
                pDstAddr ��Ŀ���ַָ��(tcp �������ӵ�udp ����Ϊ��)
                len  �� Ҫ���͵����ݳ���
                pData �� Ҫ�����������ݵ��׵�ַ
                
�����
���أ�XSUCC	-	�ɹ�
		   XERROR	-	��Ҫָ��������
		   eErrorNetBlock   ����������
		   eErrorLinkClosed ����·�ر�
		   eErrorOverflow    �������Ҫ���͵����ݳ��ȳ�����󳤶�
˵���������Ƿ��سɹ�������Ҳ��һ�����͵��Զˡ�
************************************************************************/
 XS16 XINET_SendMsg(t_XINETFD *pSockFd, t_IPADDR *pDstAddr, XS32 len, XCHAR* pData)
{
   XS32     ret;                 /* temporary return value */
   struct  sockaddr_in remAddr; /* remote Internet address */   
   t_INETSOCKADDR *pSockAddrPtr = (t_INETSOCKADDR*)XNULLP;
   XS16            sizeOfAddr = 0;


#if (INPUT_PAR_CHECK)
   /* error check on parameters */
   if ((pSockFd == XNULLP) || XOS_INET_INV_SOCK_FD(pSockFd) || (len == 0))
   {
      XOS_Trace(MD(FID_NTL, PL_ERR),"XINET_SendMsg-> bad input param");
      return(XERROR);
   }
#endif /* INPUT_PAR_CHECK */

   /* setup remote address */
   if (pDstAddr != XNULLP)
   {
      XOS_MemSet((XU8*)&remAddr, 0, sizeof(remAddr));
      remAddr.sin_family      = AF_INET;
      remAddr.sin_port        = XOS_INET_HTON_U16(pDstAddr->port);
      remAddr.sin_addr.s_addr = XOS_INET_HTON_U32(pDstAddr->ip);
      sizeOfAddr = sizeof(remAddr);
      pSockAddrPtr= (t_INETSOCKADDR *)&remAddr;
   }
   
   if ((len > 0) && ((XU32)len > XOS_INET_MAX_MSG_LEN))
   {
       XOS_Trace(MD(FID_NTL, PL_DBG),"XINET_SendMsg()-> data too long to send  ");
       return eErrorOverflow;
   }

   /*���ӵ�udp sock*/
   if (pDstAddr == XNULLP)
   {
    
      /* VxWorks sendto has some problem
       * with connected UDP socket, use send */
#ifndef XOS_VXWORKS
      ret = sendto(pSockFd->fd, (XCHAR *)pData, len, 0, 
                   (t_INETSOCKADDR*)XNULLP, sizeOfAddr);
#else
      ret = send(pSockFd->fd, (XCHAR*)pData, len, 0);
#endif /* end of SS_VW */
      
   }
   else
   {
        ret = sendto(pSockFd->fd, (XCHAR *)pData, len, 0, pSockAddrPtr, sizeOfAddr); 
   }
      

   /*��ȡ����������*/   
   if (ret == INET_ERR)
   {
      
      XOS_Trace(MD(FID_NTL, PL_DBG),"XINET_SendMsg()-> have some problem in sending ");
      if((INET_ERR_CODE == ERR_AGAIN)||
          (INET_ERR_CODE == ERR_WOULDBLOCK)||
          ((ret<len) &&(ret>0)))    /*������û�з�����*/
      {
         return eErrorNetBlock;
      }

      /*  Check if connection was closed */
      if ((INET_ERR_CODE == ERR_PIPE) ||
          (INET_ERR_CODE == ERR_CONNABORTED) || 
          (INET_ERR_CODE == ERR_CONNRESET))
      {
         return eErrorLinkClosed;
      }

      return XERROR;
   }

   return(XSUCC);

}

/************************************************************************
 ������:XINET_Select
 ����:   ��ѯ����socket
 ����:readFdS ��read����ָ��
              writeFdS  �� write����ָ��
              mSecTimeout  ����ʱʱ�䣻��λ����
              
 ���: numFdS ����⵽sock���ı������
 
 ����: �ɹ�����XSUCC, ʧ�ܷ���XERROR��
               ��ʱ����XINET_TIMEDOUT
 ˵��: ����ʱʱ��ָ��Ϊ��ʱ������ʱ�ĵȴ�
************************************************************************/

XPUBLIC XS16 XINET_Select(t_FDSET*  readFdS, t_FDSET *writeFdS, 
                                                         XU32  *mSecTimeout, XS16  *numFdS)
{
   XS32 ret;                     /* temporary return value */
   struct timeval  timeout;     /* timeout structure */
   struct timeval *timeoutPtr;
   XS32 errCode;

#if (INPUT_PAR_CHECK)
   /* error check on parameters */
   if (numFdS == XNULLP)
   {
      return(XERROR);
   }
#endif /* INPUT_PAR_CHECK */

   *numFdS = 0;

   if (mSecTimeout != XNULLP)
   {
      timeout.tv_sec  = *mSecTimeout / 1000;
      timeout.tv_usec = (*mSecTimeout % 1000) * 1000;
      timeoutPtr      = &timeout;
   }
   else
   {
      /* infinite timeout */ 
      timeoutPtr = (struct timeval * )XNULLP;
   }
      
   ret = select(FD_SETSIZE, readFdS, writeFdS, (t_FDSET*)XNULLP, timeoutPtr);

   /* timeout occured */
   if (ret == 0)
   { 
      return(XINET_TIMEOUT);
   }
   
   if (ret == INET_ERR)
   {
   /*��������*/
      switch(errCode = INET_ERR_CODE)
      {
         /*����Ĳ����ж�ʱ��������Ч
         �����������϶��ǿ�*/
         case ERR_INVAL:
            return(XSUCC);
         
         default:
            return(XERROR);

      } /* end of switch */
   }
   
   /* return number of ready file descriptors */
   *numFdS = ret;   

   return(XSUCC); 
} /* end of  cmInetSelect */


/************************************************************************
������:	XINET_RecvMsg
���ܣ��������Ͻ�������
���룺pSockFd  ��sock ������ָ��                
                linkType �� ��·������ (XOS_INET_STREAM =TCP ; XOS_INET_DGRAM =UDP )
                pLen  �� ����ʱ����1��ʾ�������е����ݡ�
                ctrFlag�� ���Ʊ�־λ,
                
�����pLen  ��������ܵ����ݵĳ���
                ppData ��������ܵ�������ָ��
                pFromAddr ��Ŀ���ַָ��(tcp �������ӵ�udp ����Ϊ��)
���أ�XSUCC	-	�ɹ�
		   XERROR	-	��Ҫָ��������
		   XINET_CLOSE     - �Զ˹ر�
		   
˵���������Ƿ��سɹ�������Ҳ��һ�����͵��Զˡ�
************************************************************************/
XPUBLIC XS16 XINET_RecvMsg(t_XINETFD *pSockFd, t_IPADDR* pFromAddr,  
                           XCHAR** ppData, XS32* pLen, XU8 linkType, XS32 ctrFlag)
{
    XS32           ret;            /* temporary return value */
    XU32           pendLen;        /* pending data length */
    XS32           bufLen;         /* entire number of received octets */
    XS32           curLen;         /* current number of octets in buffer */ 
    XCHAR       *pBuffer;        /*������Ϣ��ָ��*/
    XCHAR        *pBufPtr;         /* current buffer position */   
    XS32           remAddrLen;     /* length of remote address */
    t_INETSOCKADDR  remSockAddr;     /* to get packet's source IP address */
    XS32           recvLen;        /* number of received octets by recvmsg() */
    struct sockaddr_in  *pRemAddr;    /* remote Internet address */
    
#if (INPUT_PAR_CHECK)
   /* error check on parameters */
   if ((pSockFd == XNULLP) || XOS_INET_INV_SOCK_FD(pSockFd) ||
          (ppData == XNULLP) || (pLen == XNULLP))
   {
      XOS_Trace(MD(FID_NTL, PL_ERR),  "XINET_RecvMsg()-> bad input parm pSockFd:[%x] , ppData[%x]!", pSockFd, ppData);
      return(XERROR);
   }
#endif /* INPUT_PAR_CHECK */

   *ppData = (XCHAR*)XNULLP;

   /* INSURE fix 2 */

   pRemAddr = ( struct sockaddr_in  *)XNULLP;  

   /* clear the structure */   
   XOS_MemSet((XU8*)&remSockAddr, 0, sizeof(remSockAddr));

   /* get number of pending data */
   ret = XINET_GetNumRead(pSockFd, &pendLen);
   if (ret != XSUCC)
   {
      /* ret may be XERROR or ROUTRES */
      return(ret);
   }

   /* check if connection got closed */
   if (pendLen == 0)
   {
      /* if socket is not TCP return XSUCCDNA */
      if (linkType ==XOS_INET_STREAM )
      {
            return XINET_CLOSE;
      }
         
      else
      {
            XOS_Trace(MD(FID_NTL, PL_ERR),  "XINET_RecvMsg()-> udp sock recv 0 bytes");
            return XERROR;
      }
      
   }

   /* check if there are enough pending data to read */
   if ((*pLen == XOS_INET_READ_ANY) || ((XU32)*pLen <= pendLen))
   {
      if (*pLen == XOS_INET_READ_ANY)
      {
         /* 
            For TCP it can't be > XOS_INET_MAX_MSG_LEN. 
            For UDP it can't be > XOS_INET_MAX_UDPRAW_MSGSIZE. */ 
         if (linkType == XOS_INET_STREAM) 
         {
            /* max message length is limited to control the memory usage */
            if (pendLen > XOS_INET_MAX_MSG_LEN)
            {
                pendLen = XOS_INET_MAX_MSG_LEN;
            }

             /*֧��tcp ��װ*/
            if(ctrFlag == XOS_INET_CTR_COMPATIBLE_TCPEEN)
            {
                 /*tcp ��װ���֧��һ�ν���1900���ֽ�*/
                 if(pendLen > XOS_INET_COMPATY_TCPEEN_DATA_LEN)
                 {
                      pendLen = XOS_INET_COMPATY_TCPEEN_DATA_LEN;
                 }
            }
         }
         else
         {
            if (pendLen > XOS_INET_MAX_UDPRAW_MSGSIZE)
               pendLen = XOS_INET_MAX_UDPRAW_MSGSIZE;
         }
         /* read all pending data */ 
         bufLen = pendLen;
         *pLen = pendLen; 
      }
      else
      {
         /* max message length is limited to control the memory usage */
         if (pendLen > XOS_INET_MAX_MSG_LEN)
         {
            XOS_Trace(MD(FID_NTL, PL_ERR),  "XINET_RecvMsg()-> recieve too long bytes %l", pendLen);
            return(XERROR);
         }            
         /* read data length given by user */ 
         bufLen = *pLen;
      }

      /* set destination Internet address structure */
      if (pFromAddr == XNULLP || linkType == XOS_INET_STREAM)
      {
           remAddrLen = 0;         
      }
      else
      {
           remAddrLen = sizeof(remSockAddr); 
      }

      /* allocate flat receive buffer */
      pBuffer = (XCHAR*)XNULLP;
      
      pBuffer = (XCHAR*)XOS_MemMalloc(FID_NTL, bufLen);
      //ret = SGetSBuf(info->region, info->pool, &recvBuf, bufLen);
      if (pBuffer == XNULLP)
      {
         XOS_Trace(MD(FID_NTL, PL_EXP),  "XINET_RecvMsg()-> malloc memery faild !");
         return XERROR;
      }          
      curLen = bufLen;
      pBufPtr = pBuffer;
      
      /* 
       * maybe needs more than one recvfrom() call to read an entire 
       * message from a stream socket (TCP)
       */
      while (curLen > 0)
      {
         /* added separate recvfrom calls different OS */
 #ifdef XOS_VXWORKS
         if (remAddrLen)
         {
              recvLen = recvfrom(pSockFd->fd, (XCHAR*)pBufPtr, curLen, 0, 
                                &remSockAddr, (int *)&remAddrLen);
         }
            
         else
         {
              recvLen = recv(pSockFd->fd, (XCHAR *)pBufPtr, curLen, 0);
         }
            
#else         
#if ( defined(XOS_SOLARIS) || defined(XOS_LINUX))
         if (remAddrLen)
         {
               recvLen = recvfrom(pSockFd->fd, (XCHAR *)pBufPtr, curLen, 0, 
                    (struct sockaddr *)&remSockAddr, (socklen_t *)&remAddrLen);
         }
            
         else
         {
               recvLen = recvfrom(pSockFd->fd, (XCHAR *)pBufPtr, curLen, 0, 
                                (t_INETSOCKADDR*)XNULLP, (socklen_t *)&remAddrLen); 
         }
            
#else
          if (remAddrLen)
          {
                recvLen = recvfrom(pSockFd->fd, (XS8 *)pBufPtr, curLen, 0, 
                                &remSockAddr, (XS32*)&remAddrLen);
          }
            
          else
          {
               recvLen = recvfrom(pSockFd->fd, (XS8 *)pBufPtr, curLen, 0, 
                                (t_INETSOCKADDR*)XNULLP, (XS32*)&remAddrLen); 
          }
            
                                
#endif /* defined(XOS_SOLARIS) || defined(XOS_LINUX) */
#endif /* XOS_VXWORKS */ 
                                                         
         if (recvLen == INET_ERR)
         {
            /* cleanup */
            /* moved cleanup here */
            XOS_MemFree(FID_NTL, pBuffer);

            /*  In Windows the recvfrom function fails
             *  with error code which maps to either WSAECONNABORTED. If
             *  this happens then cmInetRecvMsg must return RCLOSED */
            if ((INET_ERR_CODE == ERR_CONNABORTED) || 
                (INET_ERR_CODE == ERR_CONNRESET))
            {
               *pLen = 0;
               return(XINET_CLOSE);
            }
            XOS_Trace(MD(FID_NTL, PL_EXP),  "XINET_RecvMsg()-> receive msg error errno[%d] !", INET_ERR_CODE);
            return(XERROR);
         } 
         curLen -= recvLen;
         pBufPtr += recvLen;

         /* 
          * a message is always read atomically on a datagram socket,
          * therefore it's ok to read less than pending data!
          */

         if (linkType == XOS_INET_DGRAM)
         {
            *pLen = recvLen;
            break; 
         }
      } /* while (curLen > 0) (only for stream sockets) */ 

      /* For UDP, it is possible to receive
       * a 0 byte datagram, in this case just return XSUCCDNA */
      if ((linkType == XOS_INET_DGRAM) && (*pLen == 0))
      {
         XOS_MemFree(FID_NTL, pBuffer);
         XOS_Trace(MD(FID_NTL, PL_EXP),  "XINET_RecvMsg()-> receive a 0 byte udp packect !");
         return(XERROR);
      }  
      *ppData = pBuffer;

      /* setup return destination Internet address */
      /* added the check of (remAddrLen > 0) */
      if ((pFromAddr != XNULLP) && (remAddrLen > 0))
      {

         pRemAddr = (struct sockaddr_in *)&remSockAddr;
         pFromAddr->port    = XOS_INET_NTOH_U16(pRemAddr->sin_port);
         pFromAddr->ip  = XOS_INET_NTOH_U32(pRemAddr->sin_addr.s_addr);
      }   
   }
   else
   {
      /* not enough data pending yet */
      return(XERROR);
   }

   return(XSUCC);
} /* end of cmInetRecvMsg */

/************************************************************************
������:	XINET_Socket
���ܣ���һ��socket
���룺type ��XOS_INET_STREAM   (TCP)
                             XOS_INET_DGRAM    (UDP)

�����sockFd �� ������
���أ�XSUCC	-	�ɹ�
		   XERROR	-	��Ҫָ��������
		   
˵����Ĭ���Ƿ�����ģʽ
************************************************************************/
XPUBLIC XS16 XINET_Socket(XU8 type,  t_XINETFD* sockFd)
{
   XS32 ret;                     /* temporary return value */
   XU32 optVal;
   
#ifdef WIN2K
   XS32 bytesReturned;
   XBOOL bNewBehavior;
#endif /* WIN2K && XOS_WIN32 */
  

#ifdef WIN2K
   bytesReturned = 0;
   bNewBehavior = XFALSE;
#endif /* XOS_WIN32 && WIN2K */  

   /* create socket */
   sockFd->fd = socket(AF_INET, type, 0);
   
   if (XOS_INET_INV_SOCK_FD(sockFd))
   {   
      /* Set sockFd->fd to invalid socket */
      sockFd->fd = XOS_INET_INV_SOCKFD;
      return(XERROR);   
   }
   
   /* set default options */
   optVal = XOS_INET_OPT_DISABLE;
   ret = XINET_SetOpt(sockFd, SOL_SOCKET, XOS_INET_OPT_BLOCK, &optVal); 
   if (ret != XSUCC) 
   {
      ret = XINET_CloseSock(sockFd);
      return(XERROR);
   }

   /*tcp��sock Ӧ�ô� reuse ѡ��*/
   if(type == XOS_INET_STREAM)
   {
       optVal = XOS_INET_OPT_ENABLE;
       ret = XINET_SetOpt(sockFd, SOL_SOCKET, XOS_INET_OPT_REUSEADDR, &optVal); 
       if (ret != XSUCC) 
       {
          ret = XINET_CloseSock(sockFd);
          return(XERROR);
       }
   }
   
#ifdef XOS_LINUX
   optVal = XOS_INET_OPT_ENABLE;
   ret = XINET_SetOpt(sockFd, SOL_SOCKET, XOS_INET_OPT_BSD_COMPAT, &optVal);
   if (ret != XSUCC) 
   {
      ret = XINET_CloseSock(sockFd);
      return(XERROR);
   }
#endif /* XOS_LINUX */

/*window 2000 ��udp ��sock��̫һ��*/
#if (defined(XOS_WIN32) && defined(WIN2K))   
   if(type == XOS_INET_DGRAM)
   {
      ret = WSAIoctl(sockFd->fd, SIO_UDP_CONNRESET, &bNewBehavior,
                     sizeof(bNewBehavior), XNULLP, 0, &bytesReturned,
                     XNULLP, XNULLP);
      if(ret == INET_ERR)
      {
         ret = XINET_CloseSock(sockFd);
         return(XERROR);
      }
   }
#endif /* WIN2K && XOS_WIN32 */   

   return(XSUCC);
} /* end of cmInetSocket */

/************************************************************************
������:	XINET_Bind
���ܣ���һ��socket
���룺pSockFd �� ������
                 pMyAddr  �����ص�ַ
�����

���أ�XSUCC	-	�ɹ�
		   XERROR	-	��Ҫָ��������
		   
˵����
************************************************************************/
XPUBLIC XS16 XINET_Bind(t_XINETFD   *pSockFd,  t_IPADDR *pMyAddr)
{
   XS32 ret;                     /* temporary return value */
   struct sockaddr_in srcAddr;  /* local Internet address/port */
   XU32    sizeOfAddr;            /* sizeof address passed to the bind call */
   t_INETSOCKADDR *sockAddrPtr; 

#if (INPUT_PAR_CHECK)
   /* error check on parameters */
   if ((pSockFd == XNULLP) || XOS_INET_INV_SOCK_FD(pSockFd) ||
       (pSockFd == XNULLP))
   {
      return(XERROR);
   }
#endif /* INPUT_PAR_CHECK */

   XOS_MemSet((XU8*)&srcAddr, 0, sizeof(srcAddr));
   srcAddr.sin_family      = AF_INET;
   srcAddr.sin_port        = XOS_INET_HTON_U16(pMyAddr->port);
   srcAddr.sin_addr.s_addr = XOS_INET_HTON_U32(pMyAddr->ip);
   sizeOfAddr              = sizeof(struct sockaddr_in);
   sockAddrPtr             = (t_INETSOCKADDR *)&srcAddr;

   ret = bind(pSockFd->fd, sockAddrPtr, sizeOfAddr); 
   if (ret == INET_ERR)
   {
      return(XERROR);
   }

   return(XSUCC); 
} /* end of cmInetBind */

/************************************************************************
������:	XINET_CloseSock
���ܣ���һ��socket
���룺sockFd �� ������
�����
���أ�XSUCC	-	�ɹ�
		   XERROR	-	��Ҫָ��������
		   
˵����
************************************************************************/
XPUBLIC XS16 XINET_CloseSock(t_XINETFD *pSockFd)
{
   XS32 ret;                     /* temporary return value */

#if (INPUT_PAR_CHECK)
   /* error check on parameters */
   if ((pSockFd == XNULLP) || XOS_INET_INV_SOCK_FD(pSockFd))
   {
      return(XERROR);
   }
#endif /* INPUT_PAR_CHECK */

#ifdef XOS_WIN32
   ret = closesocket(pSockFd->fd);
#else
   ret = close(pSockFd->fd);
#endif /* XOS_WIN32 */

   if (ret == INET_ERR) 
   {
       XOS_Trace(MD(FID_NTL, PL_WARN), "close sock : %d failed", pSockFd->fd);
       return(XERROR);
   }
   
  /* Set sockFd->fd to invalid socket */
   pSockFd->fd = XOS_INET_INV_SOCKFD;   
   return(XSUCC);
} /* end of cmInetClose */

/************************************************************************
������:	XINET_Connect
���ܣ�����һ������
���룺pSockFd �� ������
                 pServAddr  ���Զ˵�ַ
�����

���أ�XSUCC         - successful
                XSUCCDNA      - resource temporarily unavaiable
                RINPROGRESS - connection is in progress (only non-blocking)
                RISCONN     - connection is established (only non-blocking)
                XERROR     - failed
                XINET_CLOSE  - ���ӳ�ʱ�����Ӿܾ�
˵����
************************************************************************/

XPUBLIC XS16 XINET_Connect(t_XINETFD   *pSockFd, t_IPADDR *pServAddr)
{
   XS32 ret;                     /* temporary return value */
   struct sockaddr_in dstAddr;  /* foreign Internet address/port */
   XS32    sizeOfAddr;
   t_INETSOCKADDR *sockAddrPtr;  

#if (INPUT_PAR_CHECK)
   /* error check on parameters */
   if ((pSockFd == XNULLP) || XOS_INET_INV_SOCK_FD(pSockFd) ||
       (pServAddr == XNULLP))
   {
      return(XERROR);
   }
#endif /* INPUT_PAR_CHECK */


   XOS_MemSet((XU8*)&dstAddr, 0, sizeof(dstAddr));
   dstAddr.sin_family      = AF_INET;
   dstAddr.sin_port        = XOS_INET_HTON_U16(pServAddr->port);
   dstAddr.sin_addr.s_addr = XOS_INET_HTON_U32(pServAddr->ip);
   sizeOfAddr              = sizeof(struct sockaddr_in);
   sockAddrPtr             = (t_INETSOCKADDR *)&dstAddr;


   ret = connect(pSockFd->fd, sockAddrPtr, sizeOfAddr);
   if (ret == INET_ERR)
   {
      switch (INET_ERR_CODE)
      {
         /* non-blocking: connection is in progress */
         case ERR_INPROGRESS:
            return(XINET_INPROGRESS);
            break;   

         /* 
          * non-blocking: connection is established 
          * blocking    : connection is already established
          */
         case ERR_ISCONN:
            return(XINET_ISCONN);
            break;               

         /* resource temporarily unavailable */
         case ERR_WOULDBLOCK:
            return(XINET_INPROGRESS);
            break;
        
         /* non-blocking: connection is in progress */
         case ERR_ALREADY:
            return(XINET_INPROGRESS);
            break;

         case ERR_INVAL:
            return(XINET_INPROGRESS);
            break;

         /*  Check for connection refused and timeout errors */
         case ERR_CONNREFUSED:
         case ERR_TIMEDOUT:
            return XINET_CLOSE;
            break;

         /* it is a real error */ 
         default:
            return(XERROR);
            break;
      }
   }

   return(XSUCC);
} /* end of cmInetConnect */


/************************************************************************
������:	XINET_Listen
���ܣ�����һ��������
���룺pSockFd �� ������
                 backLog  ������ͬʱ���ӵ�������
�����
���أ�XSUCC         - successful
                XERROR     - failed                
˵����
************************************************************************/

XPUBLIC XS16 XINET_Listen(t_XINETFD *pSockFd, XS16 backLog)
{
   XS32 ret;                     /* temporary return value */


#if (INPUT_PAR_CHECK)
   /* error check on parameters */
   if ((pSockFd == (t_XINETFD*)XNULLP) || XOS_INET_INV_SOCK_FD(pSockFd) ||
       (backLog < MIN_BACK_LOG) || (backLog > MAX_BACK_LOG))
   {
      return(XERROR);
   }
#endif /* INPUT_PAR_CHECK */

   ret = listen(pSockFd->fd, backLog);
   if (ret == INET_ERR) 
   {
      return(XERROR);
   }

   return(XSUCC);
} /* end of cmInetListen */

/************************************************************************
������:	XINET_StrToIpAddr
���ܣ��ַ�����ip��ַת��
���룺len �� �ַ����ĳ���
                 val  ���ַ����׵�ַ
�����ip    ����ַ
���أ�XSUCC         - successful
                XERROR     - failed                
˵����
************************************************************************/
XPUBLIC XS16 XINET_StrToIpAddr(XU16  len, XCHAR *val, XU32 *ip)
{
   XU8              idx;                /* Index for string*/
   XU8              ipv4[XOS_INET_IPV4ADDR_SIZE]; /* IPV4 Address bytes */
   idx = 0;

   XOS_MemSet((XU8 *)ipv4, 0, XOS_INET_IPV4ADDR_SIZE);

   /* Check for IP Address */
   while ((val[idx] != '.') && (val[idx] != ':') && 
          (idx < len))
   {
#if (INPUT_PAR_CHECK)
      if (((val[idx] < '0') || (val[idx] > '9')) &&
          ((val[idx] < 'a') || (val[idx] > 'f')) &&
          ((val[idx] < 'A') || (val[idx] > 'F')))
      {
         /* Not a digit */
         return(XERROR);
      }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

      /* Convert Ascii to integer */
      XOS_INET_ATOI(ipv4[0], val[idx]);


      idx++; /* move to the next character */
   } /* while, try to determine IPV4 or IPV6 */


   if (val[idx] == '.')
   {
      idx++;
      XINET_AsciiToIpv4(3, (XCHAR*)&(ipv4[1]), (XU16)(len - idx), &(val[idx]));
         
      XOS_INET_GET_IPV4_ADDR_FRM_STRING( *ip, ipv4);
   } /* if, IPV4 */

   return(XSUCC);
} /* cmInetConvertStrToIpAddr */



/************************************************************************
������:	XINET_SetOpt
���ܣ� ����io ѡ��
���룺sockFd �� ������
                 level  ��ѡ����
                 type ������ѡ�������
                 value ������ѡ���ֵ
                 
�����
���أ�XSUCC         - successful
                XERROR     - failed                
˵���� ��һ��ֻ֧�������ͷ�����ѡ������õ�ʱ
                  �ټ�
************************************************************************/
XPUBLIC XS16 XINET_SetOpt(t_XINETFD *sockFd, XU32 level,XU32 type, XU32* value)
{
   XS32  ret = XSUCC;              /* temporary return value */
   XU32  disable = 0;            /* disable option */
   XU32  enable = 1;             /* enable option */
#if 0
   /* added for IPv4 options */
#ifdef IPV4_OPTS_SUPPORTED
#ifdef XOS_WIN32   
   int disableOpt = 0;
#endif /* XOS_WIN32 */   
#endif /* IPV4_OPTS_SUPPORTED */ 
 XU8   lpEnable = 1;           /* multicast loop enable */
 XU8   lpDisable = 0;          /* multicast loop disable */
#ifdef XOS_WIN32
   
#endif /* XOS_WIN32 */

   struct ip_mreq stMreq;
   CmInetMCastInf *mCast;
 #endif  
   XBOOL  boolEnable = XTRUE;      /* enable option */
   XBOOL  boolDisable = XFALSE;    /* disable option */
   XU32    *optVal;
   struct linger optLinger;

   
#if (INPUT_PAR_CHECK)
   /* error check on parameters */
   if ((sockFd == XNULLP) || XOS_INET_INV_SOCK_FD(sockFd))
   {
      return(XERROR);
   }
#endif /* INPUT_PAR_CHECK */

   switch (type) 
   {
      case XOS_INET_OPT_BLOCK:
          optVal = (XU32*)value;
          switch(*optVal)
          {
             case XOS_INET_OPT_ENABLE:
#ifdef XOS_WIN32
                ret = ioctlsocket(sockFd->fd, FIONBIO, (u_long *)&disable);     

#else
#ifdef XOS_VXWORKS
                ret = ioctl(sockFd->fd, (XS32)FIONBIO, (XS32)&disable);
#else
                ret = ioctl(sockFd->fd, (XS32)FIONBIO, &disable);
                  
#endif /* XOS_VXWORKS */

#endif /* XOS_WIN32 */

                sockFd->blocking = 1;
                break;
              
             case XOS_INET_OPT_DISABLE:
#ifdef XOS_WIN32
                ret = ioctlsocket(sockFd->fd, FIONBIO, (u_long*)&enable);     

#else
#ifdef XOS_VXWORKS
                ret = ioctl(sockFd->fd, (XS32)FIONBIO, (XS32)&enable);
#else
                ret = ioctl(sockFd->fd, (XS32)FIONBIO, &enable);
#endif /* XOS_VXWORKS */

#endif /* XOS_WIN32 */
             
                sockFd->blocking = 0;
                break;
             
             default:
                /* wrong value */ 
                return(XERROR);
                break;
          }
          break;
          
           case XOS_INET_OPT_RX_BUF_SIZE:
             optVal = (XU32*)value;
             ret = setsockopt(sockFd->fd, level, SO_RCVBUF, 
                              (char*)optVal, sizeof(*optVal));
             break;

          case XOS_INET_OPT_TX_BUF_SIZE:
             optVal = (XU32*)value;
             ret = setsockopt(sockFd->fd, level, SO_SNDBUF, 
                              (char*)optVal, sizeof(*optVal));
             break;

      case XOS_INET_OPT_REUSEADDR:
         optVal = (XU32*)value;
         if (*optVal == XOS_INET_OPT_ENABLE)
         {
            ret = setsockopt(sockFd->fd, level, SO_REUSEADDR, 
                             (char*)&boolEnable, sizeof(boolEnable));
         }
         else if (*optVal == XOS_INET_OPT_DISABLE)
         {
            ret = setsockopt(sockFd->fd, level, SO_REUSEADDR, 
                             (char*)&boolDisable, sizeof(boolDisable));
         }
         break;
         
     case  XOS_INET_OPT_LINGER:
         XOS_MemSet(&optLinger, 0, sizeof(optLinger));
         optVal = (XU32*)value;
         if (*optVal == XOS_INET_OPT_ENABLE)
         {
            optLinger.l_onoff = 1;
            optLinger.l_linger = 0;
            ret = setsockopt(sockFd->fd, level, SO_LINGER, 
                             (char*)&optLinger, sizeof(optLinger));
         }
         else if (*optVal == XOS_INET_OPT_DISABLE)
         {
            optLinger.l_onoff = 0;
            optLinger.l_linger = 1;
            ret = setsockopt(sockFd->fd, level, SO_LINGER, 
                             (char*)&optLinger, sizeof(optLinger));
         }

         break;
#if 0
      case XOS_INET_OPT_BROADCAST:
         optVal = (XU32*)value;
         if (*optVal == XOS_INET_OPT_ENABLE)
         {
            ret = setsockopt(sockFd->fd, level, SO_BROADCAST,
                             (char*)&boolEnable, sizeof(boolEnable));
          }
         else if (*optVal == XOS_INET_OPT_DISABLE)
         {
            ret = setsockopt(sockFd->fd, level, SO_BROADCAST,
                            (char*)&boolDisable, sizeof(boolDisable));
         }
         break; 

      case XOS_INET_OPT_KEEPALIVE:
         optVal = (XU32*)value;
         if (*optVal == XOS_INET_OPT_ENABLE)
         {
            ret = setsockopt(sockFd->fd, level, SO_KEEPALIVE,
                             (char*)&boolEnable, sizeof(boolEnable));
          }
         else if (*optVal == XOS_INET_OPT_DISABLE)
         {

            ret = setsockopt(sockFd->fd, level, SO_KEEPALIVE,
                            (char*)&boolDisable, sizeof(boolDisable));
         }
         break;

      

      case XOS_INET_OPT_TCP_NODELAY:
         optVal = (XU32*)value;
         if (*optVal == XOS_INET_OPT_ENABLE)
         {
            ret = setsockopt(sockFd->fd, level, TCP_NODELAY,
                             (char*)&boolEnable, sizeof(boolEnable));

         }
         else if (*optVal == XOS_INET_OPT_DISABLE)
         {
#ifndef SS_WINCE
            ret = setsockopt(sockFd->fd, level, TCP_NODELAY,
                             (char*)&boolDisable, sizeof(boolDisable));
#endif /* SS_WINCE */
         }
         break;

      case XOS_INET_OPT_ADD_MCAST_MBR:
         mCast = (CmInetMCastInf*)value;

         /* Copy the addresses to stMreq structure */

         stMreq.imr_multiaddr.s_addr = XOS_INET_HTON_XU32(mCast->mCastAddr);
         stMreq.imr_interface.s_addr = XOS_INET_HTON_XU32(mCast->localAddr);

         ret = setsockopt(sockFd->fd, level, IP_ADD_MEMBERSHIP,
                          (char*)&stMreq, sizeof(stMreq));
         break;

      case XOS_INET_OPT_DRP_MCAST_MBR:
         mCast = (CmInetMCastInf*)value;

         /* Copy the addresses to stMreq structure */
#ifdef SS_PS
         stMreq.imr_mcastaddr.s_addr = XOS_INET_HTON_XU32(mCast->mCastAddr);
#else
         stMreq.imr_multiaddr.s_addr = XOS_INET_HTON_XU32(mCast->mCastAddr);
#endif
         stMreq.imr_interface.s_addr = XOS_INET_HTON_XU32(mCast->localAddr);

         ret = setsockopt(sockFd->fd, level, IP_DROP_MEMBERSHIP,
                          (char*)&stMreq, sizeof(stMreq));
         break;




#if (defined(SUNOS)|| defined(XOS_WIN32) || defined(SS_PS) || defined(SS_VW_MCAST) \
     || defined(HPOS))
      case XOS_INET_OPT_MCAST_LOOP:
         optVal = (XU32*)value;
         if (*optVal == XOS_INET_OPT_ENABLE)
         {
#ifdef SS_VW            
            ret = setsockopt(sockFd->fd, level, IP_MULTICAST_LOOP,
                             (char *)&lpEnable, sizeof(lpEnable));
#else
            ret = setsockopt(sockFd->fd, level, IP_MULTICAST_LOOP,
                             (CONSTANT char *)&lpEnable, sizeof(lpEnable));
#endif /* SS_VW */           
         }
         else
         {
#ifdef SS_VW            
            ret = setsockopt(sockFd->fd, level, IP_MULTICAST_LOOP,
                             (char *)&lpDisable, sizeof(lpDisable));
#else
            ret = setsockopt(sockFd->fd, level, IP_MULTICAST_LOOP,
                             (CONSTANT char *)&lpDisable, sizeof(lpDisable));
#endif /* SS_VW */            
         }
         break;

      case XOS_INET_OPT_MCAST_IF:
         optVal = (XU32*)value;
         *optVal = XOS_INET_HTON_XU32((XU32)*optVal); 
         ret = setsockopt(sockFd->fd, level, IP_MULTICAST_IF,
                          (char *)optVal, sizeof(struct in_addr));
         break;
      
      case XOS_INET_OPT_MCAST_TTL:
         optVal = (XU32*)value;
         /* remove CONSTANT in setsockopt for VW */
#ifdef SS_VW      
         ret = setsockopt(sockFd->fd, level, IP_MULTICAST_TTL,
                          (char *)optVal, sizeof(XU8));
#else
         ret = setsockopt(sockFd->fd, level, IP_MULTICAST_TTL,
                          (CONSTANT char *)optVal, sizeof(XU8));
#endif /* SS_VW */         
         break;
#endif /* SUNOS || XOS_WIN32 || SS_PS || SS_VW_MCAST || HPOS */


      default:  
         /* wrong socket option type */
         return(XERROR);
         break;
 #endif
   }

   if (ret == INET_ERR)
   {
      return(XERROR);
   }          
   return(XSUCC);
} /* end of cmInetSetOpt */

/************************************************************************
������:	XINET_Accept
���ܣ�����һ������
���룺pSockFd ��
                 

�����pFromAddr
���أ�XSUCC	-	�ɹ�
		   XERROR	-	��Ҫָ��������
		   
˵����Ĭ���Ƿ�����ģʽ
************************************************************************/
XPUBLIC XS16 XINET_Accept(t_XINETFD   *pSockFd, t_IPADDR *pFromAddr, t_XINETFD  *pNewSockFd)
{
   XS32 ret;                         /* temporary return value */
   XS32 addrLen;                     /* address structure length */
   struct sockaddr_in  *peerAddr;   /* calling Internet address/port */
   t_INETSOCKADDR sockAddr;  
   XU32 optVal;

#if (INPUT_PAR_CHECK)
   /* error check on parameters */
   if ((pSockFd == XNULLP) || XOS_INET_INV_SOCK_FD(pSockFd))
   {
      return(XERROR);
   }
#endif /* INPUT_PAR_CHECK */

   /* change t_INETSOCKADDR to sockAddr */
   addrLen = sizeof(sockAddr);   

   /* INSURE fix */
  /* INSURE fix */
#if ( defined(SUNOS) || defined(XOS_LINUX)) 
   pNewSockFd->fd = accept(pSockFd->fd, (t_INETSOCKADDR*)&sockAddr, 
                          (socklen_t *)&addrLen);
#else
   pNewSockFd->fd = accept(pSockFd->fd, (t_INETSOCKADDR*)&sockAddr, 
                          (int*)&addrLen); 
#endif /* SUNOS || SS_LINUX */   
   

   /* added for IPv6/IPv4 socket distinguishing */
   
   if (XOS_INET_INV_SOCK_FD(pNewSockFd))
   {
      if (INET_ERR_CODE == ERR_WOULDBLOCK)
      {
         /* no connection present to accept */ 
         return(XERROR);
      }
      else
      {
         return(XERROR);
      }
   }     

   /* set default options for new socket file descriptor */
   optVal = XOS_INET_OPT_DISABLE;
   ret = XINET_SetOpt(pNewSockFd, SOL_SOCKET, XOS_INET_OPT_BLOCK, &optVal); 
   if ( ret != XSUCC) 
   {
      ret = XINET_CloseSock(pNewSockFd);
      return(XERROR);
   }


   peerAddr = (struct sockaddr_in *)&sockAddr;
   pFromAddr->port    = XOS_INET_NTOH_U16(peerAddr->sin_port);
   pFromAddr->ip = XOS_INET_NTOH_U32(peerAddr->sin_addr.s_addr);

   return(XSUCC);
} /* end of cmInetAccept */ 

/************************************************************************
������:	XINET_GetSockName
���ܣ���ȡsock ������ı��ص�ַ
���룺pSockFd ��������
                 
�����locAddr   �� ���ص�ַ(�����ֽ����)
���أ�XSUCC	-	�ɹ�
		   XERROR	-	��Ҫָ��������
		   
˵����
************************************************************************/
XPUBLIC XS16 XINET_GetSockName(t_XINETFD *sockFd, t_IPADDR* locAddr)
{
   struct sockaddr_in *sockAddr; 

   t_INETSOCKADDR lclSockAddr;
   XU32  size;
   XS16  ret;
   XS32  errCode;



#if (INPUT_PAR_CHECK)
   /* error check on parameters */
   if ((sockFd == XNULLP) || XOS_INET_INV_SOCK_FD(sockFd) ||
       (locAddr == XNULLP))
   {
      return(XERROR);
   }
#endif /* INPUT_PAR_CHECK */

   XOS_MemSet((XU8*)&lclSockAddr, 0, sizeof(lclSockAddr));
   size = sizeof(lclSockAddr);
   
#ifdef XOS_LINUX
   ret = getsockname(sockFd->fd, (t_INETSOCKADDR*)&lclSockAddr, 
                     (socklen_t *)&size);
#else
   ret = getsockname(sockFd->fd, (t_INETSOCKADDR*)&lclSockAddr, (int*)&size);
#endif   

   if(ret == INET_ERR)
   {
      switch(errCode = INET_ERR_CODE)
      {
         case ERR_INVAL:
             sockAddr = (struct sockaddr_in *)&lclSockAddr;

             locAddr->port = XOS_INET_NTOH_U16(sockAddr->sin_port);

             return(XSUCC);
         
         default:
             return(XERROR);
      }/* end of switch */

   }


   sockAddr = (struct sockaddr_in *)&lclSockAddr;
   locAddr->port    = XOS_INET_NTOH_U16(sockAddr->sin_port);
   locAddr->ip = XOS_INET_NTOH_U32(sockAddr->sin_addr.s_addr);

   return(XSUCC);
}





XPUBLIC XS16 XINET_End(void)

{
   
#ifdef XOS_WIN32

   XS32     err;
   err = WSACleanup();
   if (err != 0)
   {
      return(XERROR);
   }

#endif

   return(XSUCC);
}/* end of XINET_End() */


#ifdef __cplusplus
}
#endif /* __cplusplus */







