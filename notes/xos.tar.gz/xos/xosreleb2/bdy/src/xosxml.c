/***************************************************************
**
**  Xinwei Telecom Technology co., ltd. ShenZhen R&D center
**  
**  Core Network Department  platform team  
**
**  parser.c 
**
**  description: an XML 1.0 non-verifying parser
**
**  author: zhanglei
**
**  data:   2006.3.7
**
***************************************************************
**                          history                     
**  
***************************************************************
**   author          data              modification            
**   zhanglei         2006.4.7              create  
**************************************************************/

/**/
#include "xosxml.h"
#include "xmlparser.h"
#include "xosencap.h"

/************************************************************************
������  : XOS_ReadNtlGenCfg
����    : get XOS NTL configure informations
����    : filename   XOS �����ļ���
���    :
����    : XBOOL
˵����
************************************************************************/
XBOOL XOS_ReadNtlGenCfg( t_NTLGENCFG* pNtl, XCHAR* filename )
{

/* none Vxworks OS */
#ifndef XOS_VXWORKS

	xmlDocPtr  doc	    = NULL;
    xmlNodePtr cur      = NULL;
	xmlChar* pTempStr   = XNULL;

#endif

	/*�����Ϸ��Լ��*/
	if ( XNULL == pNtl || XNULL == filename )
	{
		return( XFALSE ); 
	}

	XOS_MemSet( pNtl, 0x00, sizeof(t_NTLGENCFG) );


#ifndef XOS_VXWORKS

	/*��ȡ�ļ�*/
    doc = xmlParseFile(filename);
    if (doc == XNULL) 
	{
		return( XFALSE );
	} 

	/*�ҵ����ڵ�*/
    cur = xmlDocGetRootElement(doc);
    if (cur == XNULL) 
	{
		xmlFreeDoc(doc);
		return( XFALSE );
    }
	if ( XOS_StrCmp( cur->name, "MODULES") ) 
	{
		xmlFreeDoc(doc);
		return( XFALSE );
    }
    cur = cur->xmlChildrenNode;
    while ( cur && xmlIsBlankNode ( cur ) )
    {
		cur = cur->next;
    }
    if ( cur == XNULL )
	{
		xmlFreeDoc(doc);
		return( XFALSE );
	}

	/*�ҵ� NTL ���ڵ�*/
    while ( cur != XNULL ) 
	{
        if ( !XOS_StrCmp(cur->name, "NTLGENCFG" ) )
		{
			break;
		}

		cur = cur->next;
    }
	if ( XNULL == cur )
	{
		xmlFreeDoc(doc);
		return( XFALSE ); 
	}
	cur = cur->xmlChildrenNode;
    while ( cur && xmlIsBlankNode ( cur ) )
    {
		cur = cur -> next;
    }
    if ( cur == XNULL )
	{
		xmlFreeDoc(doc);
		return( XFALSE );
	}
	/*���� NTL �ӽڵ�*/
	while ( cur != XNULL ) 
	{
		/*MAXUDPLINK �ڵ�*/
        if ( !XOS_StrCmp(cur->name, "MAXUDPLINK" ) )
		{
			pTempStr = xmlNodeListGetString( doc, cur->xmlChildrenNode, 1);
			if ( XNULL != pTempStr && XOS_StrLen(pTempStr) > 0 )
			{
				pNtl->maxUdpLink = (XU16)atol( pTempStr );
				xmlFree( pTempStr );
				pTempStr   = XNULL;
			}			
		}
		/*MAXTCPCLILINK �ڵ�*/
        if ( !XOS_StrCmp(cur->name, "MAXTCPCLILINK" ) )
		{
			pTempStr = xmlNodeListGetString( doc, cur->xmlChildrenNode, 1);
			if ( XNULL != pTempStr && XOS_StrLen(pTempStr) > 0 )
			{
				pNtl->maxTcpCliLink = (XU16)atol( pTempStr );
				xmlFree( pTempStr );
				pTempStr   = XNULL;
			}			
		}
		/*MAXTCPSERVLINK �ڵ�*/
        if ( !XOS_StrCmp(cur->name, "MAXTCPSERVLINK" ) )
		{
			pTempStr = xmlNodeListGetString( doc, cur->xmlChildrenNode, 1);
			if ( XNULL != pTempStr && XOS_StrLen(pTempStr) > 0 )
			{
				pNtl->maxTcpServLink = (XU16)atol( pTempStr );
				xmlFree( pTempStr );
				pTempStr   = XNULL;
			}			
		}
		/*FDSPERTHRPOLLING �ڵ�*/
        if ( !XOS_StrCmp(cur->name, "FDSPERTHRPOLLING" ) )
		{
			pTempStr = xmlNodeListGetString( doc, cur->xmlChildrenNode, 1);
			if ( XNULL != pTempStr && XOS_StrLen(pTempStr) > 0 )
			{
				pNtl->fdsPerThrPolling = (XU16)atol( pTempStr );
				xmlFree( pTempStr );
				pTempStr   = XNULL;
			}			
		}

		cur = cur->next;		
    }

	xmlFreeDoc(doc);

#endif /* end none XOS Vxworks */


/* XOS Vxworks begin */
#ifdef XOS_VXWORKS
	pNtl->maxUdpLink       = 500;       
    pNtl->maxTcpCliLink    = 500;
    pNtl->maxTcpServLink   = 100;    
    pNtl->fdsPerThrPolling = 256;
#endif /*  XOS Vxworks end  */


	return(XTRUE); 
}

/************************************************************************
������  : XML_ReadAttGenCfg
����    : get XOS ATT Server configure informations
����    : filename   XOS �����ļ���
���    :
����    : XBOOL
˵����
************************************************************************/
XBOOL XML_ReadAttGenCfg( t_ATTGENCFG* pAttGenCfg , XCHAR* filename )
{
/* none XOS Vxworks */
#ifndef XOS_VXWORKS
	xmlDocPtr  doc	    = NULL;
    xmlNodePtr cur      = NULL;
	xmlChar* pTempStr   = XNULL;
#endif

	if ( XNULL == pAttGenCfg )
	{
		return( XFALSE ); 
	}

	XOS_MemSet( pAttGenCfg, 0x00, sizeof(t_ATTGENCFG) );


/* none XOS Vxworks include WIN2K & TURBO LINUX */
#ifndef XOS_VXWORKS
    doc = xmlParseFile(filename);
    if (doc == XNULL) 
	{
		return( XFALSE );
	} 
    cur = xmlDocGetRootElement(doc);
    if (cur == XNULL) 
	{
		xmlFreeDoc(doc);
		return( XFALSE );
    }
	if ( XOS_StrCmp( cur->name, "MODULES") ) 
	{
		xmlFreeDoc(doc);
		return( XFALSE );
    }
    cur = cur->xmlChildrenNode;
    while ( cur && xmlIsBlankNode ( cur ) )
    {
		cur = cur -> next;
    }
    if ( cur == XNULL )
	{
		xmlFreeDoc(doc);
		return( XFALSE );
	}

    while ( cur != XNULL ) 
	{
        if ( !XOS_StrCmp(cur->name, "ATT_SERVER" ) )
		{
			break;
		}

		cur = cur->next;
    }
	if ( XNULL == cur )
	{
		xmlFreeDoc(doc);
		return( XFALSE ); 
	}
	cur = cur->xmlChildrenNode;
    while ( cur && xmlIsBlankNode ( cur ) )
    {
		cur = cur -> next;
    }
    if ( cur == XNULL )
	{
		xmlFreeDoc(doc);
		return( XFALSE );
	}

	while ( cur != XNULL ) 
	{
 		if ( !XOS_StrCmp(cur->name, "IP") )
		{
			pTempStr = xmlNodeListGetString( doc, cur->xmlChildrenNode, 1);
			if ( XNULL != pTempStr )
			{
				if( XSUCC != XOS_StrtoIp( pTempStr, &pAttGenCfg->ip ) )
				{
					xmlFree( pTempStr );
					goto OUT_LABLE;
				}
				xmlFree( pTempStr );
				pTempStr = XNULL;
			}

			pTempStr = xmlGetProp( cur, "port" );
			if ( XNULL != pTempStr )
			{
				pAttGenCfg->port = (XU16)atol( pTempStr );
				xmlFree( pTempStr );
				pTempStr = XNULL;
			}
		}

		if ( !XOS_StrCmp(cur->name, "MAX_CON_NUM") )
		{
			pTempStr = xmlNodeListGetString( doc, cur->xmlChildrenNode, 1);
			if ( XNULL != pTempStr )
			{
				pAttGenCfg->maxAtts = (XU16)atol( pTempStr );
				xmlFree( pTempStr );
				pTempStr = XNULL;
			}
		}

		cur = cur->next;		
    }

OUT_LABLE:
	xmlFreeDoc(doc);

#endif /*  none XOS Vxworks end WIN2K & TURBO LINUX  */

/*  XOS Vxworks begin  */
#ifdef XOS_VXWORKS
	pAttGenCfg->ip       = 0;
    pAttGenCfg->maxAtts  = 16;
    pAttGenCfg->port     = 1025;
#endif /* XOS Vxworks end */
	return XTRUE;
}


/************************************************************************
������  : XML_readMemCfg
����    : get XOS Memory configure informations
����    : filename   XOS �����ļ���
���    :
����    : 
˵��    ��
************************************************************************/
XS16 XML_readMemCfg( t_MEMCFG * pMemCfg, XCONST XS8 *filename )
{
#ifndef XOS_VXWORKS

	xmlDocPtr  doc	    = NULL;
    xmlNodePtr cur      = NULL;
	xmlChar*   pTempStr = XNULL;
	XU32       i        = 0;

#endif



	if ( XNULL == pMemCfg )
	{
		return XFALSE;
	}
	XOS_MemSet( pMemCfg, 0x00, sizeof(t_MEMCFG) );

	pMemCfg->pMemBlock =  (t_MEMBLOCK*)xmlMalloc( MAX_MEMBLOCK_NUM*sizeof( t_MEMBLOCK ) );
	if ( XNULL == pMemCfg->pMemBlock )
	{
		return( XFALSE );
	}
	XOS_MemSet( pMemCfg->pMemBlock, 0x00, MAX_MEMBLOCK_NUM*sizeof( t_MEMBLOCK ) );



/*  WIN2K & TURBO LINUX  */
#ifndef XOS_VXWORKS	

	doc = xmlParseFile( filename);
    if (doc == XNULL) 
	{
		XML_readMemCfgRelease( (t_MEMCFG*)pMemCfg );
		return( XFALSE );
	} 
    cur = xmlDocGetRootElement(doc);
    if (cur == XNULL) 
	{
		goto ERR_OUT_LABLE;
    }
	if ( XOS_StrCmp( cur->name, "MODULES") ) 
	{
		goto ERR_OUT_LABLE;
    }
    cur = cur->xmlChildrenNode;
    while ( cur && xmlIsBlankNode ( cur ) )
    {
		cur = cur -> next;
    }
    if ( cur == XNULL )
	{
		goto ERR_OUT_LABLE;
	}

    while ( cur != XNULL ) 
	{
        if ( !XOS_StrCmp(cur->name, "MEMORY_POOL" ) )
		{
			break;
		}

		cur = cur->next;
    }
	if ( XNULL == cur )
	{
		goto ERR_OUT_LABLE;
	}
	cur = cur->xmlChildrenNode;
    while ( cur && xmlIsBlankNode ( cur ) )
    {
		cur = cur ->next;
    }
    if ( cur == XNULL )
	{
		goto ERR_OUT_LABLE;
	}

	i = 0;
	while ( cur != XNULL && i < MAX_MEMBLOCK_NUM ) 
	{
		if ( !XOS_StrCmp(cur->name, "MEMORY_SIZE" ) )
		{
			pTempStr = xmlGetProp(cur, "num");
			if ( XNULL != pTempStr && XOS_StrLen(pTempStr) > 0 )
			{
				pMemCfg->pMemBlock[i].blockNums  = (XU32)atol( pTempStr );
				xmlFree( pTempStr );
				pTempStr   = XNULL;

				pTempStr = xmlNodeListGetString( doc, cur->xmlChildrenNode, 1);
				if ( XNULL != pTempStr && XOS_StrLen(pTempStr) > 0 )
				{
					pMemCfg->pMemBlock[i].blockSize = (XU32)atol( pTempStr );
					xmlFree( pTempStr );
					pTempStr   = XNULL;

					i++;
				}
			}			
		}

		cur = cur->next;		
    }
    pMemCfg->memTypes = i;

    return XSUCC;

ERR_OUT_LABLE:
	xmlFreeDoc(doc);
	XML_readMemCfgRelease( (t_MEMCFG*)pMemCfg );
	return( XERROR);
    
#endif  /*  WIN2K & TURBO LINUX  end*/



/*  XOS Vxworks begin  */
#ifdef XOS_VXWORKS

    pMemCfg->pMemBlock[ 0 ].blockNums  = 300;
	pMemCfg->pMemBlock[ 0 ].blockSize = 32;
    
   	pMemCfg->pMemBlock[ 1 ].blockNums  = 20+5030;
	pMemCfg->pMemBlock[ 1 ].blockSize = 64;

    pMemCfg->pMemBlock[ 2 ].blockNums  = 1000+0;
	pMemCfg->pMemBlock[ 2 ].blockSize = 128;
    
    pMemCfg->pMemBlock[ 3 ].blockNums  = 0;
	pMemCfg->pMemBlock[ 3 ].blockSize = 256;
    
    pMemCfg->pMemBlock[ 4 ].blockNums  = 10+0;
	pMemCfg->pMemBlock[ 4 ].blockSize = 512;
    
    pMemCfg->pMemBlock[ 5 ].blockNums  =1+1;
	pMemCfg->pMemBlock[ 5 ].blockSize = 1024;
    
    pMemCfg->pMemBlock[ 6 ].blockNums  = 20+0;
	pMemCfg->pMemBlock[ 6 ].blockSize = 2048;
    
    pMemCfg->pMemBlock[ 7 ].blockNums  = 20+0;
	pMemCfg->pMemBlock[ 7 ].blockSize = 4096;

    pMemCfg->pMemBlock[ 8 ].blockNums  = 2+2;
	pMemCfg->pMemBlock[ 8 ].blockSize = 8192;

    pMemCfg->pMemBlock[ 9 ].blockNums  = 20+0;
	pMemCfg->pMemBlock[ 9 ].blockSize = 16384;

    pMemCfg->pMemBlock[ 10 ].blockNums  = 3+5;
	pMemCfg->pMemBlock[10].blockSize = 32768;
	
    pMemCfg->pMemBlock[ 11 ].blockNums  = 1+2;
	pMemCfg->pMemBlock[ 11 ].blockSize = 65536;
	
    pMemCfg->pMemBlock[ 12 ].blockNums  = 3+0;
	pMemCfg->pMemBlock[ 12 ].blockSize = 131072;

	pMemCfg->pMemBlock[ 13 ].blockNums  = 0;
	pMemCfg->pMemBlock[ 13 ].blockSize = 262144;

	pMemCfg->pMemBlock[ 14 ].blockNums  = 0;
	pMemCfg->pMemBlock[ 14 ].blockSize = 524288;

	pMemCfg->pMemBlock[ 15 ].blockNums  = 2+0;
	pMemCfg->pMemBlock[ 15 ].blockSize = 1048576;


    pMemCfg->memTypes = 16;

    return XSUCC;

#endif /* XOS_VXWORKS*/


}

/************************************************************************
������  : XML_readMemCfgRelease
����    : �ͷ��ڴ�������Ϣ
����    : filename   XOS �����ļ���
���    :
����    : XBOOL
˵����
************************************************************************/
XS16 XML_readMemCfgRelease( t_MEMCFG * pMemCfg )
{
	if ( XNULL == pMemCfg )
	{
		return XTRUE;
	}

	xmlFree( pMemCfg->pMemBlock );
	
	return XTRUE;
}


/************************************************************************
������  : XML_GetTelDCfgFromXosXml
����    : get XOS Telnet Server configure informations
����    : filename   XOS �����ļ���
���    :
����    : XBOOL
˵����
************************************************************************/
XBOOL XML_GetTelDCfgFromXosXml( t_TelnetDCfg* pTelDCfg, XCHAR* szFileName )
{
	/* none XOS Vxworks */
#ifndef XOS_VXWORKS
	xmlDocPtr  doc	    = NULL;
    xmlNodePtr cur      = NULL;
	xmlChar* pTempStr   = XNULL;
#endif

	if ( XNULL == szFileName || XNULL == pTelDCfg )
	{
		return XFALSE;
	}
	XOS_MemSet( pTelDCfg, 0x00, sizeof(t_TelnetDCfg) );


/* none XOS Vxworks include WIN2K & TURBO LINUX */
#ifndef XOS_VXWORKS
    doc = xmlParseFile( szFileName );
    if (doc == XNULL) 
	{
		return( XFALSE );
	} 
    cur = xmlDocGetRootElement( doc );
    if (cur == XNULL) 
	{
		xmlFreeDoc(doc);
		return( XFALSE );
    }
	if ( XOS_StrCmp( cur->name, "MODULES") ) 
	{
		xmlFreeDoc(doc);
		return( XFALSE );
    }
    cur = cur->xmlChildrenNode;
    while ( cur && xmlIsBlankNode ( cur ) )
    {
		cur = cur -> next;
    }
    if ( cur == XNULL )
	{
		xmlFreeDoc(doc);
		return( XFALSE );
	}

    while ( cur != XNULL ) 
	{
        if ( !XOS_StrCmp(cur->name, "TELNET_SERVER" ) )
		{
			break;
		}

		cur = cur->next;
    }
	if ( XNULL == cur )
	{
		xmlFreeDoc(doc);
		return( XFALSE ); 
	}
	cur = cur->xmlChildrenNode;
    while ( cur && xmlIsBlankNode ( cur ) )
    {
		cur = cur -> next;
    }
    if ( cur == XNULL )
	{
		xmlFreeDoc(doc);
		return( XFALSE );
	}

	while ( cur != XNULL ) 
	{
 		if ( !XOS_StrCmp(cur->name, "IP") )
		{
			pTempStr = xmlNodeListGetString( doc, cur->xmlChildrenNode, 1);
			if ( XNULL != pTempStr )
			{
				if( XSUCC != XOS_StrtoIp( pTempStr, &pTelDCfg->ip ) )
				{
					xmlFree( pTempStr );
					goto OUT_LABLE;
				}
				xmlFree( pTempStr );
				pTempStr = XNULL;
			}

			pTempStr = xmlGetProp( cur, "port" );
			if ( XNULL != pTempStr )
			{
				pTelDCfg->port = (XU16)atol( pTempStr );
				xmlFree( pTempStr );
				pTempStr = XNULL;
			}
		}

		if ( !XOS_StrCmp(cur->name, "MAX_CON_NUM") )
		{
			pTempStr = xmlNodeListGetString( doc, cur->xmlChildrenNode, 1);
			if ( XNULL != pTempStr )
			{
				pTelDCfg->maxTelClients = (XU16)atol( pTempStr );
				xmlFree( pTempStr );
				pTempStr = XNULL;
			}
		}

		cur = cur->next;		
    }

	return XTRUE;

OUT_LABLE:
	xmlFreeDoc(doc);

	return XFALSE;

#endif /*  none XOS Vxworks end WIN2K & TURBO LINUX  */

/*  XOS Vxworks begin  */
#ifdef XOS_VXWORKS

	pTelDCfg->ip             = 0;
    pTelDCfg->maxTelClients  = 2;
    pTelDCfg->port           = 1024;

#endif /* XOS Vxworks end */

	return XTRUE;
}
