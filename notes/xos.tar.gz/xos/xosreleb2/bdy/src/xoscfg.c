/***************************************************************
**
**  Xinwei Telecom Technology co., ltd. ShenZhen R&D center
**  
**  Core Network Department  platform team  
**
**  filename: xoscfg.c
**
**  description:  ��ʱ�ļ�,��ģ�����ʱ,ģ�鶼ͨ����
                          �����ļ�����, ����Ҫ���.c �ļ�
**
**  author: wangzongyou
**
**  data:   2006.07.19
**
***************************************************************
**                          history                     
**  
***************************************************************
**   author          data              modification            

**************************************************************/
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


/*------------------------------------------------------------------------
                  ����ͷ�ļ�
-------------------------------------------------------------------------*/ 
#include "xosmodule.h"
#include "cmtimer.h"
#include "xosntl.h"
#include "xosipc.h"
#include "xosmem.h"
#include "xosencap.h"
#include "xostrace.h"
#include "xosmmgt.h"

#ifdef XOS_TELNETD
#include "clitelnetd.h"
#endif

#include "clishell.h"

#include "xoscfg.h"
/* t_XOSLOGINLIST * g_xosLogin;*/
/*-------------------------------------------------------------------------
                 ģ���ڲ��궨��
-------------------------------------------------------------------------*/
#ifdef XOS_MDLMGT
XS32  XOS_FIDROOT(HANDLE hDir,XS32 argc, XS8** argv);
XS32  XOS_FIDCLI(HANDLE hDir,XS32 argc, XS8** argv);
XS32  XOS_FIDNTL(HANDLE hDir,XS32 argc, XS8** argv);
XS32  XOS_FIDIPC(HANDLE hDir,XS32 argc, XS8** argv);
#ifdef XOS_TELNETD
XS32  XOS_FIDTELNETD(HANDLE hDir,XS32 argc, XS8** argv);
#endif
#ifdef XOS_TELNETS
XS32  XOS_FIDTELNETS(HANDLE hDir,XS32 argc, XS8** argv);
#endif
XS32  XOS_FIDTRACE(HANDLE hDir,XS32 argc, XS8** argv);
XS32  XOS_FIDTIME(HANDLE hDir,XS32 argc, XS8** argv);
#endif

/*-------------------------------------------------------------------------
                 ģ���ڲ��ṹ��ö�ٶ���
-------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------
                ģ���ڲ�ȫ�ֱ���
-------------------------------------------------------------------------*/
t_XOSFIDLIST XOS_ROOT =
{
	{
		"FID_ROOT",
		XNULL,
		FID_ROOT,
	},

	{
		XNULLP,
		XNULLP,
		XNULLP,
	},

	{
		XNULLP,
		XNULLP,
	},

	eXOSMode,
	XNULLP
};

t_XOSFIDLIST XOS_TIM =
{
	{
		"FID_TIME",
		XNULL,
		FID_TIME,
	},

	{
		TIM_InitTime,
	   	TIM_NoticeTime,
		XNULLP,
	},

	{
		XNULLP,
		XNULLP,
	},

	eXOSMode,
	XNULLP
};


t_XOSFIDLIST XOS_CLI =
{
	{
		"FID_CLI",
		XNULL,
		FID_CLI,
	},

	{
		XOS_CLIIniProc,
		XNULLP,
		XOS_CLICloseProc,
	},

	{
		XOS_CLIMsgProc,
		XNULLP,
	},

	eXOSMode,
	XNULLP
};

t_XOSFIDLIST XOS_NTL =
{
	{
		"FID_NTL",
		XNULL,
		FID_NTL,
	},

	{
		NTL_Init,
		XNULLP,	
		XNULL,
	},

	{
		NTL_msgProc,
		NTL_timerProc,
	},

	eXOSMode,
	XNULLP
};

t_XOSFIDLIST XOS_IPC =
{
	{
		"FID_IPC",
		XNULL,
		FID_IPC,
	},

	{
		IPC_Init,
		XNULLP,
		XNULL,
	},

	{
	       IPC_msgProc,
		XNULLP,
	},

	eXOSMode,
	XNULLP
};
t_XOSFIDLIST XOS_TRACE =
{
	{
		"FID_TRACE",
		XNULL,
		FID_TRACE,
	},

	{
		Trace_Init,
		XNULLP,
		XNULL,
	},

	{
	       Trace_msgProc,
		XNULLP,
	},

	eXOSMode,
	XNULLP
};
#ifdef XOS_TELNETD
t_XOSFIDLIST XOS_TelnetD =
{
	{
		"FID_TELNETD",
		XNULL,
		FID_TELNETD,
	},

	{
		TelnetD_Init,
		TelnetD_notice,
		XNULLP,
	},

	{
		TelnetD_msgProc,
		XNULLP,
	},

	eXOSMode,
	XNULLP
};
#endif

#ifdef XOS_TELNETS
t_XOSFIDLIST XOS_TelnetS =
{
	{
		"FID TELNET",
		XNULL,
		FID_TELNET,
	},

	{
		XOS_TelnetSInitProc,
		XNULLP,
		XNULLP,
	},

	{
		XOS_TelnetServerProc,
		XNULLP,
	},

	eXOSMode,
	XNULLP
};


#endif

#ifdef XOS_IPC_MGNT
t_XOSFIDLIST XOS_IPCMGNT=
{
	{
		"FID_IPCMGNT",
		XNULL,
		FID_IPCMGNT,
	},

	{
		XOS_IPCInit,
		XOS_IPCNotice,
		XNULLP,
	},

	{
		XOS_IPCChanMgntFunc,
		XOS_IPCTimerCallBack,/*timer func*/
	},

	eXOSMode,
	XNULLP
};
#endif
/*-------------------------------------------------------------------------
                ģ���ڲ�����
-------------------------------------------------------------------------*/


/*-------------------------------------------------------------------------
                ģ��ӿں���
-------------------------------------------------------------------------*/

/************************************************************************
 ������:
 ����:
 ����:
 ���:
 ����:
 ˵��: 
************************************************************************/
XPUBLIC XS32 XOS_cfgXosModule(t_XOSLOGINLIST *g_xosLogin)
{
#if 0
    g_xosLogin = (t_XOSLOGINLIST *)XOS_MemMalloc(FID_ROOT, FID_XOSMAX * sizeof(t_XOSLOGINLIST));

    if(g_xosLogin == XNULLP)
    {
        XOS_Trace(MD(FID_ROOT, PL_ERR), " XOS_cfgXosModule()-> malloc error!");
        return XERROR;
    }
    XOS_MemSet(g_xosLogin, 0, FID_XOSMAX * sizeof(t_XOSLOGINLIST));
#endif
    g_xosLogin[FID_ROOT].stack 	    = &XOS_ROOT;
    g_xosLogin[FID_ROOT].TID		= 0;
   
    
    g_xosLogin[FID_TIME].stack 	    = &XOS_TIM;
    XOS_StrNcpy(g_xosLogin[FID_TIME].taskname , "Tsk_Time", MAX_TID_NAME_LEN);
    g_xosLogin[FID_TIME].TID		= FID_TIME;
    g_xosLogin[FID_TIME].prio		= TSK_PRIO_HIGHER;
    g_xosLogin[FID_TIME].stacksize	= 64000;
    /* g_xosLogin[FID_TIME].timenum	= 0; */


    g_xosLogin[FID_CLI].stack 	    = &XOS_CLI;
    XOS_StrNcpy(g_xosLogin[FID_CLI].taskname 	,"Tsk_CLI", MAX_TID_NAME_LEN);
    g_xosLogin[FID_CLI].TID		    = FID_CLI;
    g_xosLogin[FID_CLI].prio		= TSK_PRIO_LOWER;
    g_xosLogin[FID_CLI].stacksize	= XNULL;
    /* g_xosLogin[FID_CLI].timenum	    = 0; */

#if 0

#ifdef XOS_TELNETD
	g_xosLogin[FID_TELNETD].stack 		= &XOS_TelnetD;
    XOS_StrNcpy(g_xosLogin[FID_TELNETD].taskname, "TASK TELNETD", MAX_TID_NAME_LEN);
    g_xosLogin[FID_TELNETD].TID		    = FID_TELNETD;
    g_xosLogin[FID_TELNETD].prio		= TSK_PRIO_NORMAL;  /*ֻ����дƽ̨�������ȼ���ö��*/
    g_xosLogin[FID_TELNETD].stacksize	= (XU16)XNULL;
    /* g_xosLogin[FID_TELNETD].timenum	    = 0; */
#endif

#ifdef XOS_TELNETS
	g_xosLogin[FID_TELNET].stack 		= &XOS_TelnetS;
    XOS_StrNcpy(g_xosLogin[FID_TELNET].taskname, "TASK TELNET SERVER", MAX_TID_NAME_LEN);
    g_xosLogin[FID_TELNET].TID		    = FID_TELNET;
    g_xosLogin[FID_TELNET].prio		    = TSK_PRIO_NORMAL;  /*ֻ����дƽ̨�������ȼ���ö��*/
    g_xosLogin[FID_TELNET].stacksize	= (XU16)XNULL;
    /* g_xosLogin[FID_TELNET].timenum	    = 0; */
#endif

    g_xosLogin[FID_NTL].stack 	    = &XOS_NTL;
    XOS_StrNcpy(g_xosLogin[FID_NTL].taskname , "Tsk_NTL", MAX_TID_NAME_LEN);
    g_xosLogin[FID_NTL].TID		    = FID_NTL;
    g_xosLogin[FID_NTL].prio		= TSK_PRIO_NORMAL;
    g_xosLogin[FID_NTL].stacksize	= XNULL;
    /* g_xosLogin[FID_NTL].timenum	    = 30; */

    g_xosLogin[FID_IPC].stack 	    = &XOS_IPC;
    XOS_StrNcpy(g_xosLogin[FID_IPC].taskname, "Tsk_IPC", MAX_TID_NAME_LEN);
    g_xosLogin[FID_IPC].TID		    = FID_IPC;
    g_xosLogin[FID_IPC].prio		= TSK_PRIO_NORMAL;
    g_xosLogin[FID_IPC].stacksize	= XNULL;
    /* g_xosLogin[FID_IPC].timenum	    = 0; */

   g_xosLogin[FID_TRACE].stack 	    = &XOS_TRACE;
    XOS_StrNcpy(g_xosLogin[FID_TRACE].taskname, "Tsk_TRACE", MAX_TID_NAME_LEN);
    g_xosLogin[FID_TRACE].TID		    = FID_TRACE;
    g_xosLogin[FID_TRACE].prio		= TSK_PRIO_NORMAL;
    g_xosLogin[FID_TRACE].stacksize	= XNULL;
    /* g_xosLogin[FID_TRACE].timenum	    = 0; */
#endif
#ifdef XOS_IPC_MGNT
    g_xosLogin[FID_IPCMGNT].stack 	    = &XOS_IPCMGNT;
    XOS_StrNcpy(g_xosLogin[FID_IPCMGNT].taskname, "Tsk_IPCMGNT", MAX_TID_NAME_LEN);
    g_xosLogin[FID_IPCMGNT].TID		    = FID_IPCMGNT;
    g_xosLogin[FID_IPCMGNT].prio		= TSK_PRIO_NORMAL;
    g_xosLogin[FID_IPCMGNT].stacksize	= XNULL;
    /* g_xosLogin[FID_IPC].timenum	    = 0; */
#endif

    return XSUCC;
}


#ifdef XOS_MDLMGT
XS32  XOS_FIDROOT(HANDLE hDir,XS32 argc, XS8** argv)
{
    t_XOSLOGINLIST RootLoginList;

    RootLoginList.stack     = &XOS_ROOT;
    XOS_StrNcpy(RootLoginList.taskname , "Tsk_ROOT", MAX_TID_NAME_LEN);
    RootLoginList.TID		= FID_ROOT;
    RootLoginList.prio      = TSK_PRIO_LOWEST;    

    XOS_MMStartFid(&RootLoginList,XNULLP,XNULLP);

    return XSUCC;
}


XS32  XOS_FIDCLI(HANDLE hDir,XS32 argc, XS8** argv)
{
    t_XOSLOGINLIST CLILoginList;

    CLILoginList.stack     = &XOS_CLI;
    XOS_StrNcpy(CLILoginList.taskname , "Tsk_CLI", MAX_TID_NAME_LEN);
    CLILoginList.TID		= FID_CLI;
    CLILoginList.prio      = TSK_PRIO_LOWER;    

    XOS_MMStartFid(&CLILoginList,XNULLP,XNULLP);

    return XSUCC;
}

XS32  XOS_FIDNTL(HANDLE hDir,XS32 argc, XS8** argv)
{
    t_XOSLOGINLIST NTLLoginList;

    NTLLoginList.stack     = &XOS_NTL;
    XOS_StrNcpy(NTLLoginList.taskname , "Tsk_NTL", MAX_TID_NAME_LEN);
    NTLLoginList.TID		= FID_NTL;
    NTLLoginList.prio      = TSK_PRIO_NORMAL;    

    XOS_MMStartFid(&NTLLoginList,XNULLP,XNULLP);

    return XSUCC;
}   
	
XS32  XOS_FIDIPC(HANDLE hDir,XS32 argc, XS8** argv)
{
    t_XOSLOGINLIST IPCLoginList;

    IPCLoginList.stack     = &XOS_IPC;
    XOS_StrNcpy(IPCLoginList.taskname , "Tsk_IPC", MAX_TID_NAME_LEN);
    IPCLoginList.TID		= FID_IPC;
    IPCLoginList.prio      = TSK_PRIO_NORMAL;    

    XOS_MMStartFid(&IPCLoginList,XNULLP,XNULLP);

    return XSUCC;
}

#ifdef XOS_TELNETD
XS32  XOS_FIDTELNETD(HANDLE hDir,XS32 argc, XS8** argv)
{
    t_XOSLOGINLIST TELNETDLoginList;

    TELNETDLoginList.stack     = &XOS_TelnetD;
    XOS_StrNcpy(TELNETDLoginList.taskname , "TASK TELNETD", MAX_TID_NAME_LEN);
    TELNETDLoginList.TID		= FID_TELNETD;
    TELNETDLoginList.prio      = TSK_PRIO_NORMAL;    

    XOS_MMStartFid(&TELNETDLoginList,XNULLP,XNULLP);

    return XSUCC;
}
#endif

#ifdef XOS_TELNETS
XS32  XOS_FIDTELNETS(HANDLE hDir,XS32 argc, XS8** argv)
{
    t_XOSLOGINLIST TELNETSLoginList;

    TELNETSLoginList.stack     = &XOS_TelnetS;
    XOS_StrNcpy(TELNETSLoginList.taskname , "TASK TELNETS", MAX_TID_NAME_LEN);
    TELNETSLoginList.TID		= FID_TELNET;
    TELNETSLoginList.prio      = TSK_PRIO_NORMAL;    

    XOS_MMStartFid(&TELNETSLoginList,XNULLP,XNULLP);

    return XSUCC;
}	
#endif


XS32  XOS_FIDTRACE(HANDLE hDir,XS32 argc, XS8** argv)
{
    t_XOSLOGINLIST TRACELoginList;

    TRACELoginList.stack     = &XOS_TRACE;
    XOS_StrNcpy(TRACELoginList.taskname , "Tsk_TRACE", MAX_TID_NAME_LEN);
    TRACELoginList.TID		= FID_TRACE;
    TRACELoginList.prio      = TSK_PRIO_NORMAL;    

    XOS_MMStartFid(&TRACELoginList,XNULLP,XNULLP);

    return XSUCC;
}
  
XS32  XOS_FIDTIME(HANDLE hDir,XS32 argc, XS8** argv)
{
    t_XOSLOGINLIST TIMELoginList;

    TIMELoginList.stack     = &XOS_TIM;
    XOS_StrNcpy(TIMELoginList.taskname , "Tsk_TIME", MAX_TID_NAME_LEN);
    TIMELoginList.TID		= FID_TIME;
    TIMELoginList.prio      = TSK_PRIO_HIGHER;    

    XOS_MMStartFid(&TIMELoginList,XNULLP,XNULLP);

    return XSUCC;
}
 
  
#endif

#ifdef __cplusplus
}
#endif /* __cplusplus */


