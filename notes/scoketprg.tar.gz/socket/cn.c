/*
 * =====================================================================================
 *
 *       Filename:  cn.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  08/01/2012 03:56:02 PM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Dr. Fritz Mehner (mn), mehner@fh-swf.de
 *        Company:  FH Südwestfalen, Iserlohn
 *
 * =====================================================================================
 */

#include <stdio.h>
main()
{
  int i,j;
  i = 0;
  j = j+i;
  printf("this is enough to do test,%d\n",j);

}
