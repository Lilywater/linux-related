int parseargs(char *string, char *args[], const char *seps);
int parsenargs(char *string, char *args[], int limit, const char *seps);
