/* dummy.h
 * see dummy.c for more information
 */
#ifndef _SENDIP_dummy_H
#define _SENDIP_dummy_H

#error "Don't include this, dumbass"

/* dummy HEADER
 */
typedef struct {
	//...
} dummy_header;

/* Defines for which parts have been modified
 */
#define dummy_MOD_*  1<<*

/* Options
 */
sendip_option dummy_opts[] = {
	//...
};

#endif  /* _SENDIP_dummy_H */
